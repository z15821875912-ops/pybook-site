# -*- coding: utf-8 -*-
"""PYbook 场景编辑器 —— 类 Unity/Cocos 的可视化场景编辑 + 真机播放。

用法:
    python 编辑器.py [场景.scene]

界面: 左侧对象层级 | 中间可拖拽视口(滚轮缩放/右键平移) | 右侧属性面板 | 顶部工具栏。

数据: 场景存为 .scene(JSON)。对象 = 节点：形(矩形/圆/文本/图片/相机) +
碰撞箱类型 实(0无 1实体 2角色 3动态 4触发，包围盒即碰撞箱) +
相机节点的 跟(跟随对象下标)。播放时生成两个文件到场景同目录:
    <名>_场景.pybk   场景模块: 平行数据列表 + <名>_绘制() + <名>_物理()
    <名>_预览.pybk   引用场景模块，真机窗口里跑物理+相机+绘制
再调 pybk_main.py 跑真引擎(SDL 窗口)，画面与真游戏完全一致。

用户游戏代码可以这样用场景（Godot 风格，WASD/方向键控制角色）:
    引用("我的场景_场景")
    window(normal, open)
    GOING:{
        win(800, 500, "我的游戏")
        ...这里写你自己的逻辑，改 Xs[0]/Ys[0] 等列表元素...
        vg.左 = 0
        if(key("a") or key("left")) { 左 = 1 }
        ...右/上/下 同理...
        vg.相机 = 我的场景_物理(形s, Xs, Ys, Ws, Hs, 实s, 跟s, 左, 右, 上, 下)
        color(16, 18, 26)
        clear()
        vg.画 = 我的场景_绘制(形s, Xs, Ys, Ws, Hs, 红s, 绿s, 蓝s, 文s, 号s, 图s, 见s,
                             实s, 跟s, 相机[0], 相机[1])
    }STOP
（注意：key() 返回布尔值，不能相加，要用 or 连接后置 1。）
"""

import json
import os
import re
import subprocess
import sys
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

PYBOOK_DIR = os.path.dirname(os.path.abspath(__file__))

SHAPES = [(0, "矩形"), (1, "圆"), (2, "文本"), (3, "图片"), (4, "相机")]
SHAPE_NAME = dict(SHAPES)

# 碰撞箱类型（Godot 风格）：0 无 1 实体(Static) 2 角色(Character) 3 动态(Rigid) 4 触发(Area)
SOLID_TYPES = [(0, "无"), (1, "实体"), (2, "角色"), (3, "动态"), (4, "触发")]
SOLID_NAME = dict(SOLID_TYPES)
碰撞色 = {1: "#4ade80", 2: "#38bdf8", 3: "#fb923c", 4: "#facc15"}

新场景 = {
    "名": "我的场景",
    "宽": 800,
    "高": 500,
    "背景": [16, 18, 26],
    "对象": [],
}


def 默认对象(形=0):
    o = {
        "名": SHAPE_NAME[形] + "对象",
        "形": 形,
        "x": 100, "y": 100, "w": 120, "h": 80,
        "红": 120, "绿": 180, "蓝": 255,
        "文本": "你好 PYbook",
        "字号": 18,
        "图片": "",
        "可见": True,
        "实": 0,
        "跟": -1,
    }
    if 形 == 4:   # 相机：视野 = 场景大小
        o["名"] = "相机"
        o["红"] = 250
        o["绿"] = 210
        o["蓝"] = 90
    return o


def py字符串(s):
    """把 Python 字符串转成 PYbook 字符串字面量。"""
    return '"' + str(s).replace("\\", "\\\\").replace('"', '\\"') + '"'


def sanitize(名):
    """场景名 → 可做文件名/函数名的安全串（保留中文与字母数字）。"""
    s = re.sub(r"[^\w\u4e00-\u9fff]+", "_", str(名)).strip("_")
    return s or "场景"


# ============================================================
# 代码生成：场景模块 + 预览程序
# ============================================================

def gen_场景模块(scene):
    """场景 → 可 引用() 的 .pybk 模块（Godot 风格：数据 + 绘制 + 物理）。

    引擎的模块系统只合并函数与顶层变量（类不跨模块），且函数只能读自己的
    参数，所以场景数据用平行列表（形s/Xs/…/实s/跟s）导出：
      - <名>_绘制(全部列表, 相机X, 相机Y)：按对象展开的绘制直线代码
      - <名>_物理(位置列表, 实s, 跟s, 左, 右, 上, 下)：角色键控移动、
        动态体重力、AABB 碰撞解算（角色/动态 推出 实体）、相机跟随，
        ret [相机X, 相机Y]（列表按引用传，用户改完元素再调即生效）
    碰撞箱 = 对象包围盒（实s: 0无 1实体 2角色 3动态 4触发）。
    相机是 形=4 的节点，跟s[相机] = 跟随对象的下标（-1 不跟）。"""
    名 = sanitize(scene["名"])
    os = scene["对象"]
    宽, 高 = scene["宽"], scene["高"]
    # 列表名 → 场景 JSON 键
    字段s = [("形s", "形", 0), ("Xs", "x", 0), ("Ys", "y", 0),
             ("Ws", "w", 0), ("Hs", "h", 0),
             ("红s", "红", 200), ("绿s", "绿", 200), ("蓝s", "蓝", 200),
             ("文s", "文本", ""), ("号s", "字号", 16),
             ("图s", "图片", ""), ("见s", "可见", None),
             ("实s", "实", 0), ("跟s", "跟", -1)]
    位置列表 = "形s, Xs, Ys, Ws, Hs"
    全部列表 = ", ".join(列表 for 列表, _k, _d in 字段s)
    L = []
    NL = chr(10)
    L.append("@ %s>场景模块>1" % 名)
    L.append("Memoryment@self")
    L.append("# 本文件由 PYbook 场景编辑器生成：数据列表 + 绘制 + 物理。")
    L.append("# 场景 %dx%d；碰撞箱=包围盒；实s: 0无 1实体 2角色 3动态 4触发；跟s: 相机跟随下标。" % (宽, 高))
    L.append("")
    for 列表, 键, 默认 in 字段s:
        值 = []
        for o in os:
            if 键 == "可见":
                值.append(1 if o.get("可见", True) else 0)
            elif 键 in ("文本", "图片"):
                值.append(py字符串(o.get(键, "")))
            else:
                值.append(o.get(键, 默认))
        L.append("vg.%s = [%s]" % (列表, ", ".join(str(v) for v in 值)))
    L.append("")
    # ---------------- 绘制 ----------------
    L.append("func %s_绘制(%s, 相机X, 相机Y) {" % (名, 全部列表))
    for i, o in enumerate(os):
        if o.get("形") == 4:
            continue   # 相机节点不画
        L.append("    if(见s[%d] == 1) {" % i)
        L.append("        if(形s[%d] == 0) {" % i)
        L.append("            color(红s[%d], 绿s[%d], 蓝s[%d])" % (i, i, i))
        L.append("            box(Xs[%d] - 相机X, Ys[%d] - 相机Y, Ws[%d], Hs[%d])" % (i, i, i, i))
        L.append("        }")
        L.append("        if(形s[%d] == 1) {" % i)
        L.append("            color(红s[%d], 绿s[%d], 蓝s[%d])" % (i, i, i))
        L.append("            圆(Xs[%d] - 相机X + Ws[%d] / 2, Ys[%d] - 相机Y + Hs[%d] / 2, Ws[%d] / 2)"
                 % (i, i, i, i, i))
        L.append("        }")
        L.append("        if(形s[%d] == 2) {" % i)
        L.append("            color(红s[%d], 绿s[%d], 蓝s[%d])" % (i, i, i))
        L.append("            字(Xs[%d] - 相机X, Ys[%d] - 相机Y, 文s[%d], 号s[%d])" % (i, i, i, i))
        L.append("        }")
        L.append("        if(形s[%d] == 3) {" % i)
        L.append("            图缩(Xs[%d] - 相机X, Ys[%d] - 相机Y, Ws[%d], Hs[%d], 图s[%d])" % (i, i, i, i, i))
        L.append("        }")
        L.append("    }")
    L.append("}")
    L.append("")
    # ---------------- 物理 ----------------
    L.append("func %s_物理(%s, 实s, 跟s, 左, 右, 上, 下) {" % (名, 位置列表))
    L.append("    # 1) 角色键控移动 / 动态体重力")
    L.append("    rm.around(%d) -> i {" % len(os))
    L.append("        if(实s[i] == 2) {")
    L.append("            if(左 > 0) { Xs[i] = Xs[i] - 4 }")
    L.append("            if(右 > 0) { Xs[i] = Xs[i] + 4 }")
    L.append("            if(上 > 0) { Ys[i] = Ys[i] - 4 }")
    L.append("            if(下 > 0) { Ys[i] = Ys[i] + 4 }")
    L.append("        }")
    L.append("        if(实s[i] == 3) {")
    L.append("            Ys[i] = Ys[i] + 6")
    L.append("        }")
    L.append("    }")
    L.append("    # 2) AABB 碰撞解算：角色/动态 推出 实体（沿穿透更小的轴）")
    L.append("    rm.around(%d) -> i {" % len(os))
    L.append("        if(实s[i] == 2 or 实s[i] == 3) {")
    L.append("            rm.around(%d) -> j {" % len(os))
    L.append("                if(实s[j] == 1) {")
    L.append("                    vg.ax = Xs[i]")
    L.append("                    if(Xs[j] > ax) { ax = Xs[j] }")
    L.append("                    vg.bx = Xs[i] + Ws[i]")
    L.append("                    if(Xs[j] + Ws[j] < bx) { bx = Xs[j] + Ws[j] }")
    L.append("                    vg.叠x = bx - ax")
    L.append("                    vg.ay = Ys[i]")
    L.append("                    if(Ys[j] > ay) { ay = Ys[j] }")
    L.append("                    vg.by = Ys[i] + Hs[i]")
    L.append("                    if(Ys[j] + Hs[j] < by) { by = Ys[j] + Hs[j] }")
    L.append("                    vg.叠y = by - ay")
    L.append("                    if(叠x > 0 and 叠y > 0) {")
    L.append("                        if(叠x < 叠y) {")
    L.append("                            if(Xs[i] + Ws[i] / 2 < Xs[j] + Ws[j] / 2) {")
    L.append("                                Xs[i] = Xs[i] - 叠x")
    L.append("                            } else {")
    L.append("                                Xs[i] = Xs[i] + 叠x")
    L.append("                            }")
    L.append("                        } else {")
    L.append("                            if(Ys[i] + Hs[i] / 2 < Ys[j] + Hs[j] / 2) {")
    L.append("                                Ys[i] = Ys[i] - 叠y")
    L.append("                            } else {")
    L.append("                                Ys[i] = Ys[i] + 叠y")
    L.append("                            }")
    L.append("                        }")
    L.append("                    }")
    L.append("                }")
    L.append("            }")
    L.append("        }")
    L.append("    }")
    L.append("    # 3) 相机：跟随第一个设置了 跟 的相机节点，否则 (0,0)")
    L.append("    vg.cx = 0")
    L.append("    vg.cy = 0")
    L.append("    rm.around(%d) -> i {" % len(os))
    L.append("        if(跟s[i] >= 0 and 跟s[i] < %d) {" % len(os))
    L.append("            vg.t = 跟s[i]")
    L.append("            cx = Xs[t] + Ws[t] / 2 - %d / 2" % 宽)
    L.append("            cy = Ys[t] + Hs[t] / 2 - %d / 2" % 高)
    L.append("        }")
    L.append("    }")
    L.append("    ret [cx, cy]")
    L.append("}")
    return NL.join(L) + NL


def gen_预览(scene):
    名 = sanitize(scene["名"])
    bg = scene["背景"]
    参数 = "形s, Xs, Ys, Ws, Hs, 红s, 绿s, 蓝s, 文s, 号s, 图s, 见s, 实s, 跟s"
    L = []
    NL = chr(10)
    L.append("@ %s>预览>1" % 名)
    L.append("")
    L.append("引用(%s)" % py字符串(名 + "_场景"))
    L.append("")
    L.append("window(normal, open)")
    L.append("")
    L.append("GOING:{")
    L.append("    win(%d, %d, \"PYbook 预览 · %s\")" % (scene["宽"], scene["高"], scene["名"]))
    L.append("    vg.左 = 0")
    L.append("    vg.右 = 0")
    L.append("    vg.上 = 0")
    L.append("    vg.下 = 0")
    L.append("    if(key(\"a\") or key(\"left\")) { 左 = 1 }")
    L.append("    if(key(\"d\") or key(\"right\")) { 右 = 1 }")
    L.append("    if(key(\"w\") or key(\"up\")) { 上 = 1 }")
    L.append("    if(key(\"s\") or key(\"down\")) { 下 = 1 }")
    L.append("    vg.相机 = %s_物理(形s, Xs, Ys, Ws, Hs, 实s, 跟s, 左, 右, 上, 下)" % 名)
    L.append("    color(%d, %d, %d)" % (bg[0], bg[1], bg[2]))
    L.append("    clear()")
    L.append("    vg.画 = %s_绘制(%s, 相机[0], 相机[1])" % (名, 参数))
    L.append("}STOP")
    return NL.join(L) + NL


# 编辑器主体
# ============================================================

class 场景编辑器:

    def __init__(self, root, 初始路径=None):
        self.root = root
        root.title("PYbook 场景编辑器")
        root.geometry("1180x720")

        self.scene = json.loads(json.dumps(新场景))   # 深拷贝
        self.path = None
        self.sel = None            # 选中对象下标
        self.zoom = 1.0
        self.ox = 40               # 场景原点在画布上的位置
        self.oy = 40
        self.drag = None           # (下标, dx, dy)
        self.pan = None
        self.运行中 = None         # Popen
        self._图片缓存 = {}

        self.建界面()
        self.绑事件()
        self.适应窗口()
        if 初始路径:
            self.打开(初始路径)
        else:
            self.刷新()
        self.root.after(200, self.轮询播放)

    # ---------------- UI ----------------

    def 建界面(self):
        f = ("Microsoft YaHei UI", 10)
        self.root.option_add("*Font", f)

        # 顶部工具栏
        bar = tk.Frame(self.root, bd=1, relief=tk.RAISED)
        bar.pack(side=tk.TOP, fill=tk.X)
        def 按钮(文字, 命令, 加粗=False):
            b = tk.Button(bar, text=文字, command=命令, relief=tk.FLAT,
                          bg="#2d2d3a", fg="#e8e8f0",
                          activebackground="#40405a",
                          font=(f[0], 10, "bold" if 加粗 else "normal"))
            b.pack(side=tk.LEFT, padx=2, pady=2)
            return b
        按钮("新建", self.新建)
        按钮("打开…", self.对话框打开)
        按钮("保存", self.对话框保存)
        tk.Frame(bar, width=8).pack(side=tk.LEFT)
        按钮("＋矩形", lambda: self.添加(0))
        按钮("＋圆", lambda: self.添加(1))
        按钮("＋文本", lambda: self.添加(2))
        按钮("＋图片", lambda: self.添加(3))
        按钮("＋相机", lambda: self.添加(4))
        tk.Frame(bar, width=8).pack(side=tk.LEFT)
        按钮("▶ 播放(真机)", self.播放, 加粗=True)
        self.停止钮 = 按钮("■ 停止", self.停止)
        self.停止钮.config(state=tk.DISABLED)
        tk.Frame(bar, width=8).pack(side=tk.LEFT)
        按钮("导出场景模块", self.对话框导出模块)
        按钮("场景设置…", self.场景设置)
        按钮("适应窗口", self.适应窗口)

        # 左：对象列表
        left = tk.Frame(self.root, width=210, bd=1, relief=tk.SUNKEN)
        left.pack(side=tk.LEFT, fill=tk.Y)
        tk.Label(left, text="对象（越靠下越在上层）", anchor="w",
                 bg="#23232e", fg="#9aa0b5").pack(fill=tk.X)
        self.列表 = tk.Listbox(left, exportselection=False,
                               bg="#1a1a24", fg="#e0e0ec",
                               selectbackground="#3a4a7a",
                               activestyle="none")
        self.列表.pack(fill=tk.BOTH, expand=True)
        self.列表.bind("<<ListboxSelect>>", lambda e: self.选中(self.列表.curselection()[0] if self.列表.curselection() else None))
        lb2 = tk.Frame(left)
        lb2.pack(fill=tk.X)
        def 小按钮(文字, 命令):
            return tk.Button(lb2, text=文字, command=命令, width=6,
                             bg="#2d2d3a", fg="#e8e8f0", relief=tk.FLAT,
                             activebackground="#40405a")
        小按钮("上移", lambda: self.移动层级(-1)).pack(side=tk.LEFT, padx=2, pady=2)
        小按钮("下移", lambda: self.移动层级(1)).pack(side=tk.LEFT, pady=2)
        小按钮("复制", self.复制).pack(side=tk.LEFT, pady=2)
        小按钮("删除", self.删除).pack(side=tk.LEFT, pady=2)

        # 中：视口
        self.画布 = tk.Canvas(self.root, bg="#101018", highlightthickness=0)
        self.画布.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        # 右：属性面板
        right = tk.Frame(self.root, width=230, bd=1, relief=tk.SUNKEN)
        right.pack(side=tk.RIGHT, fill=tk.Y)
        right.pack_propagate(False)
        tk.Label(right, text="属性", anchor="w", bg="#23232e",
                 fg="#9aa0b5").pack(fill=tk.X)
        wrap = tk.Frame(right, bg="#1e1e28")
        wrap.pack(fill=tk.BOTH, expand=True, padx=6, pady=4)
        self.属性区 = wrap
        self.属性变量 = {}
        行s = [("名", "名称"), ("形t", "类型"), ("x", "X"), ("y", "Y"),
               ("w", "宽"), ("h", "高"), ("红", "红"), ("绿", "绿"),
               ("蓝", "蓝"), ("文本", "文本"), ("字号", "字号"),
               ("图片", "图片路径")]
        self.属性行 = {}
        for key, 标签 in 行s:
            r = tk.Frame(wrap, bg="#1e1e28")
            r.pack(fill=tk.X, pady=1)
            tk.Label(r, text=标签, width=7, anchor="w", bg="#1e1e28",
                     fg="#b8bdd0").pack(side=tk.LEFT)
            if key == "形t":
                v = tk.Label(r, text="", bg="#1e1e28", fg="#7ec8ff", anchor="w")
                v.pack(side=tk.LEFT, fill=tk.X, expand=True)
                self.属性行[key] = v
                continue
            var = tk.StringVar()
            e = tk.Entry(r, textvariable=var, bg="#14141c", fg="#f0f0f8",
                         insertbackground="#f0f0f8", relief=tk.FLAT,
                         highlightthickness=1, highlightbackground="#33334a")
            e.pack(side=tk.LEFT, fill=tk.X, expand=True)
            e.bind("<Return>", lambda ev, k=key: self.应用属性(k))
            e.bind("<FocusOut>", lambda ev, k=key: self.应用属性(k))
            self.属性行[key] = e
            self.属性变量[key] = var
        self.可见变量 = tk.BooleanVar(value=True)
        tk.Checkbutton(wrap, text="可见", variable=self.可见变量,
                       command=lambda: self.应用属性("见"),
                       bg="#1e1e28", fg="#b8bdd0",
                       activebackground="#1e1e28",
                       selectcolor="#14141c").pack(anchor="w", pady=4)
        # Godot 风格：碰撞箱类型（包围盒即碰撞箱）
        rf = tk.Frame(wrap, bg="#1e1e28")
        rf.pack(fill=tk.X, pady=(4, 1))
        tk.Label(rf, text="碰撞箱", width=7, anchor="w", bg="#1e1e28",
                 fg="#b8bdd0").pack(side=tk.LEFT)
        self.碰撞变量 = tk.StringVar(value="无")
        self.碰撞钮 = tk.Button(rf, textvariable=self.碰撞变量, width=8,
                                command=lambda: self.应用属性("实"),
                                bg="#2d2d3a", fg="#e8e8f0", relief=tk.FLAT,
                                activebackground="#40405a")
        self.碰撞钮.pack(side=tk.LEFT)
        tk.Label(wrap, text="实体=墙 · 角色=键控 · 动态=受重力 · 触发=区域",
                 anchor="w", bg="#1e1e28", fg="#666c80",
                 font=("Microsoft YaHei UI", 8)).pack(fill=tk.X)
        # 相机跟随（仅相机节点）
        rcam = tk.Frame(wrap, bg="#1e1e28")
        rcam.pack(fill=tk.X, pady=2)
        tk.Label(rcam, text="跟随", width=7, anchor="w", bg="#1e1e28",
                 fg="#b8bdd0").pack(side=tk.LEFT)
        self.跟随变量 = tk.StringVar(value="不跟随")
        self.跟随框 = ttk.Combobox(rcam, textvariable=self.跟随变量,
                                   state="readonly", width=12)
        self.跟随框.bind("<<ComboboxSelected>>",
                         lambda e: self.应用属性("跟"))
        self.跟随框.pack(side=tk.LEFT, fill=tk.X, expand=True)

        # 底：状态栏
        self.状态 = tk.Label(self.root, text="就绪", anchor="w",
                             bg="#23232e", fg="#9aa0b5")
        self.状态.pack(side=tk.BOTTOM, fill=tk.X)

    def 绑事件(self):
        c = self.画布
        c.bind("<ButtonPress-1>", self.按下)
        c.bind("<B1-Motion>", self.拖动)
        c.bind("<ButtonRelease-1>", self.松开)
        c.bind("<ButtonPress-3>", self.右按下)
        c.bind("<B3-Motion>", self.右拖动)
        c.bind("<MouseWheel>", self.滚轮)
        c.bind("<Motion>", self.鼠标移动)
        self.root.bind("<Delete>", lambda e: self.删除())
        for 键, 步 in (("Left", -1), ("Right", 1), ("Up", -1), ("Down", 1)):
            dx = 步 if 键 in ("Left", "Right") else 0
            dy = 步 if 键 in ("Up", "Down") else 0
            self.root.bind("<%s>" % 键, lambda e, dx=dx, dy=dy: self.微调(dx, dy, 1))
            self.root.bind("<Shift-%s>" % 键, lambda e, dx=dx, dy=dy: self.微调(dx, dy, 10))
        self.root.protocol("WM_DELETE_WINDOW", self.关闭)

    # ---------------- 场景文件 ----------------

    def 新建(self):
        if not self.确认放弃():
            return
        self.scene = json.loads(json.dumps(新场景))
        self.path = None
        self.sel = None
        self.刷新()
        self.适应窗口()
        self.状态栏("新场景（记得保存）")

    def 对话框打开(self):
        if not self.确认放弃():
            return
        p = filedialog.askopenfilename(
            title="打开场景",
            initialdir=os.path.join(PYBOOK_DIR, "scenes") if os.path.isdir(os.path.join(PYBOOK_DIR, "scenes")) else PYBOOK_DIR,
            filetypes=[("PYbook 场景", "*.scene"), ("全部文件", "*.*")])
        if p:
            self.打开(p)

    def 打开(self, p):
        try:
            with open(p, encoding="utf-8") as f:
                data = json.load(f)
            for k, v in 新场景.items():
                data.setdefault(k, json.loads(json.dumps(v)))
            for o in data["对象"]:
                o.setdefault("实", 0)
                o.setdefault("跟", -1)
        except Exception as e:
            messagebox.showerror("打开失败", str(e))
            return
        self.scene = data
        self.path = p
        self.sel = None
        self.刷新()
        self.适应窗口()
        self.状态栏("已打开 " + p)

    def 对话框保存(self):
        p = self.path
        if not p:
            p = filedialog.asksaveasfilename(
                title="保存场景",
                initialdir=PYBOOK_DIR,
                initialfile=sanitize(self.scene["名"]) + ".scene",
                defaultextension=".scene",
                filetypes=[("PYbook 场景", "*.scene")])
            if not p:
                return False
        return self.保存(p)

    def 保存(self, p):
        try:
            with open(p, "w", encoding="utf-8") as f:
                json.dump(self.scene, f, ensure_ascii=False, indent=1)
        except Exception as e:
            messagebox.showerror("保存失败", str(e))
            return False
        self.path = p
        self.root.title("PYbook 场景编辑器 — " + os.path.basename(p))
        return True

    def 确认放弃(self):
        return True   # v1：场景可随时重新生成，不做脏检查

    # ---------------- 对象操作 ----------------

    def 添加(self, 形):
        o = 默认对象(形)
        if 形 == 4:   # 相机：视野盖住整个场景，从 (0,0) 起
            o["w"] = self.scene["宽"]
            o["h"] = self.scene["高"]
            o["x"] = 0
            o["y"] = 0
        else:
            o["x"] = int((self.画布.winfo_width() / 2 - self.ox) / self.zoom - o["w"] / 2)
            o["y"] = int((self.画布.winfo_height() / 2 - self.oy) / self.zoom - o["h"] / 2)
        self.scene["对象"].append(o)
        self.刷新()
        self.选中(len(self.scene["对象"]) - 1)

    def 选中(self, i):
        self.sel = i
        self.刷新()

    def 删除(self):
        if self.sel is None:
            return
        del self.scene["对象"][self.sel]
        self.sel = None
        self.刷新()

    def 复制(self):
        if self.sel is None:
            return
        o = json.loads(json.dumps(self.scene["对象"][self.sel]))
        o["x"] += 20
        o["y"] += 20
        self.scene["对象"].insert(self.sel + 1, o)
        self.选中(self.sel + 1)

    def 移动层级(self, 方向):
        """方向 -1 = 在列表里上移（更早画/更底层）。"""
        if self.sel is None:
            return
        j = self.sel + 方向
        对象s = self.scene["对象"]
        if not 0 <= j < len(对象s):
            return
        对象s[self.sel], 对象s[j] = 对象s[j], 对象s[self.sel]
        self.选中(j)

    def 微调(self, dx, dy, 步):
        if isinstance(self.root.focus_get(), tk.Entry) or self.sel is None:
            return
        o = self.scene["对象"][self.sel]
        o["x"] += dx * 步
        o["y"] += dy * 步
        self.刷新()

    # ---------------- 属性面板 ----------------

    def 载属性(self):
        for k in list(self.属性变量):
            self.属性变量[k].set("")
        self.可见变量.set(True)
        self.属性行["形t"].config(text="")
        self.碰撞变量.set("无")
        self.碰撞钮.config(bg="#2d2d3a")
        self.跟随框.config(state="disabled")
        self.跟随变量.set("不跟随")
        if self.sel is None:
            return
        o = self.scene["对象"][self.sel]
        self.属性行["形t"].config(text=SHAPE_NAME[o["形"]])
        表 = {"名": o.get("名", ""), "x": o["x"], "y": o["y"],
              "w": o["w"], "h": o["h"], "红": o["红"], "绿": o["绿"],
              "蓝": o["蓝"], "文本": o.get("文本", ""), "字号": o.get("字号", 18),
              "图片": o.get("图片", "")}
        for k, v in 表.items():
            self.属性变量[k].set(str(v))
        self.可见变量.set(bool(o.get("可见", True)))
        实 = o.get("实", 0)
        self.碰撞变量.set(SOLID_NAME.get(实, "无"))
        self.碰撞钮.config(bg=碰撞色.get(实, "#2d2d3a"))
        if o["形"] == 4:   # 相机：跟随下拉列出所有非相机对象
            self.跟随框.config(state="readonly")
            名单 = ["不跟随"] + [
                "%d. %s" % (i, self.scene["对象"][i].get("名", ""))
                for i in range(len(self.scene["对象"]))
                if self.scene["对象"][i]["形"] != 4]
            self.跟随框.config(values=名单)
            跟 = o.get("跟", -1)
            if 0 <= 跟 < len(self.scene["对象"]) and self.scene["对象"][跟]["形"] != 4:
                self.跟随变量.set("%d. %s" % (跟, self.scene["对象"][跟].get("名", "")))
            else:
                self.跟随变量.set("不跟随")
                o["跟"] = -1

    def 应用属性(self, key):
        if self.sel is None:
            return
        o = self.scene["对象"][self.sel]
        def 数(k, 默认=0):
            try:
                return int(float(self.属性变量[k].get()))
            except Exception:
                return o.get(k, 默认)
        if key == "名":
            o["名"] = self.属性变量["名"].get()
        elif key == "x":
            o["x"] = 数("x")
        elif key == "y":
            o["y"] = 数("y")
        elif key == "w":
            o["w"] = max(1, 数("w", 1))
        elif key == "h":
            o["h"] = max(1, 数("h", 1))
        elif key in ("红", "绿", "蓝"):
            o[key] = max(0, min(255, 数(key)))
        elif key == "文本":
            o["文本"] = self.属性变量["文本"].get()
        elif key == "字号":
            o["字号"] = max(6, 数("字号", 18))
        elif key == "图片":
            o["图片"] = self.属性变量["图片"].get().strip()
        elif key == "见":
            o["可见"] = bool(self.可见变量.get())
        elif key == "实":
            o["实"] = (o.get("实", 0) + 1) % 5
            if o["实"] != 0:
                o["实"] = o["实"] if o["实"] != 4 or o["形"] != 4 else 1
        elif key == "跟":
            文 = self.跟随变量.get()
            if 文 == "不跟随" or "。" in 文:
                o["跟"] = -1
            else:
                try:
                    序 = int(文.split(".")[0])
                    o["跟"] = 序 if 0 <= 序 < len(self.scene["对象"]) else -1
                except Exception:
                    o["跟"] = -1
        self.刷新()

    # ---------------- 视口 ----------------

    def 变换(self):
        """画布尺寸变化后把场景摆到中间并适配缩放（保持当前缩放则手动缩放）。"""
        w = max(self.画布.winfo_width(), 50)
        h = max(self.画布.winfo_height(), 50)
        z = min((w - 80) / self.scene["宽"], (h - 80) / self.scene["高"], 2.0)
        self.zoom = max(z, 0.1)
        self.ox = (w - self.scene["宽"] * self.zoom) / 2
        self.oy = (h - self.scene["高"] * self.zoom) / 2

    def 适应窗口(self):
        self.变换()
        self.刷新()

    def 到场景(self, ex, ey):
        return (ex - self.ox) / self.zoom, (ey - self.oy) / self.zoom

    def 到画布(self, sx, sy):
        return self.ox + sx * self.zoom, self.oy + sy * self.zoom

    def 命中(self, sx, sy):
        for i in range(len(self.scene["对象"]) - 1, -1, -1):
            o = self.scene["对象"][i]
            if o["x"] <= sx <= o["x"] + o["w"] and o["y"] <= sy <= o["y"] + o["h"]:
                return i
        return None

    def 按下(self, e):
        sx, sy = self.到场景(e.x, e.y)
        i = self.命中(sx, sy)
        self.选中(i)
        if i is not None:
            o = self.scene["对象"][i]
            self.drag = (i, sx - o["x"], sy - o["y"])

    def 拖动(self, e):
        if self.drag is None:
            return
        i, dx, dy = self.drag
        sx, sy = self.到场景(e.x, e.y)
        o = self.scene["对象"][i]
        o["x"] = int(sx - dx)
        o["y"] = int(sy - dy)
        self.刷新()

    def 松开(self, e):
        self.drag = None

    def 右按下(self, e):
        self.pan = (e.x, e.y, self.ox, self.oy)

    def 右拖动(self, e):
        if self.pan is None:
            return
        px, py, ox, oy = self.pan
        self.ox = ox + (e.x - px)
        self.oy = oy + (e.y - py)
        self.刷新()

    def 滚轮(self, e):
        if e.delta > 0:
            系数 = 1.15
        else:
            系数 = 1 / 1.15
        新z = max(0.1, min(4.0, self.zoom * 系数))
        实际 = 新z / self.zoom
        self.ox = e.x - (e.x - self.ox) * 实际
        self.oy = e.y - (e.y - self.oy) * 实际
        self.zoom = 新z
        self.刷新()

    def 鼠标移动(self, e):
        sx, sy = self.到场景(e.x, e.y)
        self.状态栏("鼠标 (%d, %d)   缩放 %.0f%%" % (sx, sy, self.zoom * 100))

    def 状态栏(self, 文本):
        self.状态.config(text=文本)

    def 刷新(self):
        self.画布.delete("all")
        宽, 高 = self.scene["宽"], self.scene["高"]
        x0, y0 = self.到画布(0, 0)
        x1, y1 = self.到画布(宽, 高)
        # 场景底色
        bg = self.scene["背景"]
        self.画布.create_rectangle(x0, y0, x1, y1, width=0,
                                   fill="#%02x%02x%02x" % (bg[0], bg[1], bg[2]))
        # 网格
        步 = 50
        gx = 步
        while gx < 宽:
            px, _ = self.到画布(gx, 0)
            self.画布.create_line(px, y0, px, y1, fill="#ffffff", stipple="gray25")
            gx += 步
        gy = 步
        while gy < 高:
            _, py = self.到画布(0, gy)
            self.画布.create_line(x0, py, x1, py, fill="#ffffff", stipple="gray25")
            gy += 步
        self.画布.create_rectangle(x0, y0, x1, y1, outline="#4a5a8a")
        # 对象（列表顺序 = 绘制顺序，越靠下越后画=上层；相机最后单独画框）
        for i, o in enumerate(self.scene["对象"]):
            if o["形"] == 4:
                continue
            if not o.get("可见", True) and i != self.sel:
                continue
            px, py = self.到画布(o["x"], o["y"])
            pw, ph = o["w"] * self.zoom, o["h"] * self.zoom
            色 = "#%02x%02x%02x" % (int(o["红"]) % 256, int(o["绿"]) % 256, int(o["蓝"]) % 256)
            if o["形"] == 1:
                self.画布.create_oval(px, py, px + pw, py + ph, width=0, fill=色)
            elif o["形"] == 2:
                self.画布.create_text(px + 2, py + 2, anchor="nw", fill=色,
                                      text=o.get("文本", ""),
                                      font=("Microsoft YaHei UI", max(8, int(o.get("字号", 18) * self.zoom * 0.75))))
            elif o["形"] == 3:
                self.画布.create_rectangle(px, py, px + pw, py + ph,
                                           width=1, outline=色)
                img = self.取图片(o.get("图片", ""))
                if img is not None:
                    self.画布.create_image(px, py, anchor="nw", image=img)
                else:
                    self.画布.create_text(px + 4, py + 4, anchor="nw",
                                          fill="#ff8080", text="?" + os.path.basename(o.get("图片", "")))
            else:
                self.画布.create_rectangle(px, py, px + pw, py + ph, width=0, fill=色)
            # 碰撞箱描边（Godot 风格颜色：实体绿/角色蓝/动态橙/触发黄）
            实 = o.get("实", 0)
            if 实 in 碰撞色:
                self.画布.create_rectangle(px, py, px + pw, py + ph,
                                           outline=碰撞色[实], width=2)
            if i == self.sel:
                self.画布.create_rectangle(px - 3, py - 3, px + pw + 3, py + ph + 3,
                                           outline="#ffd24a", width=2)
                self.画布.create_rectangle(px, py, px + 8, py + 8,
                                           width=0, fill="#ffd24a")
        # 相机节点（金色虚线取景框 + 跟随连线）
        for i, o in enumerate(self.scene["对象"]):
            if o["形"] != 4:
                continue
            px, py = self.到画布(o["x"], o["y"])
            pw, ph = o["w"] * self.zoom, o["h"] * self.zoom
            self.画布.create_rectangle(px, py, px + pw, py + ph,
                                       outline="#ffd24a", width=2, dash=(6, 4))
            self.画布.create_text(px + 6, py + 4, anchor="nw", fill="#ffd24a",
                                  text="相机 " + o.get("名", ""),
                                  font=("Microsoft YaHei UI", 9))
            跟 = o.get("跟", -1)
            if 0 <= 跟 < len(self.scene["对象"]) and self.scene["对象"][跟]["形"] != 4:
                t = self.scene["对象"][跟]
                tx, ty = self.到画布(t["x"] + t["w"] / 2, t["y"] + t["h"] / 2)
                self.画布.create_line(px + pw / 2, py + ph / 2, tx, ty,
                                      fill="#ffd24a", width=1, dash=(3, 3))
            if i == self.sel:
                self.画布.create_rectangle(px - 3, py - 3, px + pw + 3, py + ph + 3,
                                           outline="#ffe9a0", width=2)
        self.列表.delete(0, tk.END)
        for o in self.scene["对象"]:
            标记 = "" if o.get("可见", True) else " (隐)"
            if o["形"] == 4:
                标记 += " → " + (self.scene["对象"][o["跟"]].get("名", "")
                                 if 0 <= o.get("跟", -1) < len(self.scene["对象"]) else "不跟随")
            elif o.get("实", 0):
                标记 += " {" + SOLID_NAME[o["实"]] + "}"
            self.列表.insert(tk.END, "%s [%s]%s" % (o.get("名", ""), SHAPE_NAME[o["形"]], 标记))
        if self.sel is not None:
            self.列表.selection_set(self.sel)
            self.列表.see(self.sel)
        self.载属性()

    def 取图片(self, 路径):
        if not 路径:
            return None
        if 路径 in self._图片缓存:
            return self._图片缓存[路径]
        try:
            img = tk.PhotoImage(file=路径)
        except Exception:
            if not os.path.isabs(路径):
                try:
                    img = tk.PhotoImage(file=os.path.join(PYBOOK_DIR, 路径))
                except Exception:
                    self._图片缓存[路径] = None
                    return None
            else:
                self._图片缓存[路径] = None
                return None
        self._图片缓存[路径] = img
        return img

    # ---------------- 场景设置 ----------------

    def 场景设置(self):
        w = tk.Toplevel(self.root)
        w.title("场景设置")
        w.resizable(False, False)
        变 = {}
        行s = [("宽", self.scene["宽"]), ("高", self.scene["高"]),
               ("背景R", self.scene["背景"][0]), ("背景G", self.scene["背景"][1]),
               ("背景B", self.scene["背景"][2]), ("名", self.scene["名"])]
        for 标签, 值 in 行s:
            r = tk.Frame(w)
            r.pack(fill=tk.X, padx=8, pady=2)
            tk.Label(r, text=标签, width=6, anchor="w").pack(side=tk.LEFT)
            v = tk.StringVar(value=str(值))
            变[标签] = v
            tk.Entry(r, textvariable=v, width=14).pack(side=tk.LEFT)
        def 确定():
            def 整(k, 默认):
                try:
                    return int(float(变[k].get()))
                except Exception:
                    return 默认
            self.scene["宽"] = max(200, 整("宽", self.scene["宽"]))
            self.scene["高"] = max(150, 整("高", self.scene["高"]))
            self.scene["名"] = 变["名"].get().strip() or self.scene["名"]
            self.scene["背景"] = [max(0, min(255, 整("背景R", 0))),
                                  max(0, min(255, 整("背景G", 0))),
                                  max(0, min(255, 整("背景B", 0)))]
            for o in self.scene["对象"]:   # 相机视野始终 = 场景大小
                if o["形"] == 4:
                    o["w"] = self.scene["宽"]
                    o["h"] = self.scene["高"]
            w.destroy()
            self.适应窗口()
        tk.Button(w, text="确定", command=确定).pack(pady=6)
        w.transient(self.root)
        w.grab_set()

    # ---------------- 播放 / 导出 ----------------

    def 场景目录(self):
        return os.path.dirname(self.path) if self.path else PYBOOK_DIR

    def 场景基名(self):
        return sanitize(self.scene["名"])

    def 生成文件(self):
        """写 场景模块 + 预览 两个 .pybk，返回预览路径。"""
        基 = self.场景基名()
        目录 = self.场景目录()
        模块p = os.path.join(目录, 基 + "_场景.pybk")
        预览p = os.path.join(目录, 基 + "_预览.pybk")
        with open(模块p, "w", encoding="utf-8") as f:
            f.write(gen_场景模块(self.scene))
        with open(预览p, "w", encoding="utf-8") as f:
            f.write(gen_预览(self.scene))
        return 预览p

    def 播放(self):
        if not self.path:
            if not self.对话框保存():
                return
        self.保存(self.path)
        try:
            预览p = self.生成文件()
        except Exception as e:
            messagebox.showerror("生成失败", str(e))
            return
        日志 = open(os.path.join(self.场景目录(), 基名日志(self.场景基名())), "w", encoding="utf-8")
        标志 = 0
        if os.name == "nt":
            标志 = subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP
        try:
            self.运行中 = subprocess.Popen(
                [sys.executable, os.path.join(PYBOOK_DIR, "pybk_main.py"), 预览p],
                cwd=PYBOOK_DIR, stdout=日志, stderr=subprocess.STDOUT,
                creationflags=标志)
        except Exception as e:
            messagebox.showerror("启动失败", str(e))
            return
        self.停止钮.config(state=tk.NORMAL)
        self.状态栏("真机播放中：" + os.path.basename(预览p))

    def 轮询播放(self):
        if self.运行中 is not None:
            code = self.运行中.poll()
            if code is not None:
                self.停止钮.config(state=tk.DISABLED)
                if code == 0:
                    self.状态栏("播放结束")
                else:
                    self.状态栏("播放退出码 %d（详情见 _预览_运行.log）" % code)
                self.运行中 = None
        self.root.after(300, self.轮询播放)

    def 停止(self):
        if self.运行中 is not None and self.运行中.poll() is None:
            self.运行中.terminate()
            self.状态栏("已停止")

    def 对话框导出模块(self):
        if not self.path:
            if not self.对话框保存():
                return
        self.保存(self.path)
        try:
            基 = self.场景基名()
            模块p = os.path.join(self.场景目录(), 基 + "_场景.pybk")
            with open(模块p, "w", encoding="utf-8") as f:
                f.write(gen_场景模块(self.scene))
        except Exception as e:
            messagebox.showerror("导出失败", str(e))
            return
        名 = 基
        绘参数 = "形s, Xs, Ys, Ws, Hs, 红s, 绿s, 蓝s, 文s, 号s, 图s, 见s, 实s, 跟s, 相机X, 相机Y"
        messagebox.showinfo(
            "场景模块已导出",
            "已生成 " + 模块p + "\n\n在你自己的游戏 .pybk 里这样用（Godot 风格）：\n\n"
            "引用(%s)\nwindow(normal, open)\nGOING:{\n"
            "    win(%d, %d, \"我的游戏\")\n"
            "    …写你的逻辑，改 Xs[0]/Ys[0] 等列表元素即可驱动画面…\n"
            "    vg.左 = 0\n    vg.右 = 0\n    vg.上 = 0\n    vg.下 = 0\n"
            "    if(key(\"a\") or key(\"left\")) { 左 = 1 }\n"
            "    if(key(\"d\") or key(\"right\")) { 右 = 1 }\n"
            "    if(key(\"w\") or key(\"up\")) { 上 = 1 }\n"
            "    if(key(\"s\") or key(\"down\")) { 下 = 1 }\n"
            "    vg.相机 = %s_物理(形s, Xs, Ys, Ws, Hs, 实s, 跟s, 左, 右, 上, 下)\n"
            "    color(16, 18, 26)\n    clear()\n"
            "    vg.画 = %s_绘制(%s)\n}STOP\n\n"
            "注意：key() 返回布尔值不能相加，要用 or 连接。" % (
                py字符串(名 + "_场景"), self.scene["宽"], self.scene["高"],
                名, 名, 绘参数))

    # ---------------- 收尾 ----------------

    def 关闭(self):
        self.停止()
        self.root.destroy()


def 基名日志(基):
    return 基 + "_预览_运行.log"


def main():
    初始 = sys.argv[1] if len(sys.argv) > 1 else None
    root = tk.Tk()
    场景编辑器(root, 初始)
    root.mainloop()


if __name__ == "__main__":
    main()
