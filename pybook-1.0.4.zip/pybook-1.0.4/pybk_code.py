"""PYbook 编译后端。

流程：compile_and_run(src)
    pybk_front.tokenize → parse → 遍历 AST 生成 C（调 pybook_rt 运行时）
    → 写 out.c → gcc -O2 -o app.exe out.c pybook_rt.c → 运行 app.exe

要点：
    标识符（可含中文）改安全名：变量 v_1..、函数 f_1..，映射表以注释写在
    out.c 顶部；变量预声明为 Value v_N = rt_none()，赋值一律 rt_assign，
    读取一律 rt_chk 包裹；and/or 用语句提升实现短路；cd 块按 priority
    稳定排序提到本层最前（无并发）；GOING 体即 C 的 main 体。
    语义错误（未声明变量、ret 进 GOING、重复函数、函数未定义/参数个数
    不符、整数字面量超 64 位）抛 PybkCodegenError，按 AST 的 line 字段
    报 "第 N 行: 原因"。
仅用 Python 标准库。
"""

import os
import shutil
import subprocess
import sys
import time

from pybk_front import tokenize, parse, parse_module

# ---------------- --watch 热重载入口 ----------------
# pybk_main.py 保持不动：这里在 import 期识别 --watch 并把文件路径顶到 argv[1]，
# pybk_main 随后照常读文件、调 compile_and_run；watch 循环由 compile_and_run 接管。
_WATCH_MODE = False
if len(sys.argv) >= 2 and sys.argv[1] == '--watch':
    if len(sys.argv) < 3:
        print('用法: python pybk_main.py --watch 文件.pybk', file=sys.stderr)
        sys.exit(1)
    sys.argv = [sys.argv[0]] + sys.argv[2:]
    _WATCH_MODE = True
from pybk_front import (
    NumLit, StrLit, BoolLit, VarRef, BinOp, Unary, Call, InputExpr,
    Ret, VgAssign, IpAssign, NsShow, Around, Aging, CdBlock, VcChain,
    FnDef, Program, GoldDel, ListLit, Index, AssignIndex, MemoryMode,
    HmStmt, ClassDef, Member, MethodCall, AssignMember, CtorExpr,
    HmDraw, HmLive, HmFrame, HmPlay, GoStmt, GO_DIRECTIONS, GAME_CALLS, LIB_CALLS,
    HmBlockDef, HmUse, HmPageStmt, TestCheck,
    BreakStmt, ForIn, StrParts,
    Slice,
    Comp,
    MultiAssign,
    DictLit,
    Ternary, DictComp,
    TryCatch, OnError)

SPRITE_HELPERS_C = r'''

/* 绘(列表)：精灵属性读取（缺属性 → 带序号报错） */
static Value _pbk_sprop(Value obj, const char *name, long long idx)
{
    RtObject *o;
    size_t k;
    if (!IS_OBJ(obj)) {
        fprintf(stderr, "运行时错误: 绘 第 %lld 个元素不是对象\n");
        exit(1);
    }
    o = AS_OBJ(obj);
    for (k = 0; k < o->nprops; k++)
        if (strcmp(o->names[k], name) == 0)
            return o->vals[k];
    fprintf(stderr, "运行时错误: 绘 第 %lld 个元素缺少属性 %s\n", idx + 1, name);
    exit(1);
}
static Value _pbk_half(Value v, long long idx)
{
    if (IS_INT(v))
        return rt_int(AS_INT(v) / 2);
    if (IS_FLT(v))
        return rt_int((long long)(AS_FLT(v) / 2));
    fprintf(stderr, "运行时错误: 绘 第 %lld 个元素的宽/高需要是数字\n", idx + 1);
    exit(1);
}
'''

NL_CHAR = chr(10)   # net.send 自动补的行尾字符
# ---- 网页 UI 控件运行时（按钮/输入框/滑条）；CTXNAME 替换为画布 ctx 变量名 ----
_UI_RUNTIME = r"""window.__pybkUI = { focus: null, drag: null, text: {}, val: {} };
window.__pybkUI_KEY = function(e) {
  if (!window.__pybkUI.focus) return;
  var t = window.__pybkUI.text[window.__pybkUI.focus] || '';
  if (e.key === 'Backspace') { window.__pybkUI.text[window.__pybkUI.focus] = t.slice(0, -1); }
  else if (e.key.length === 1 && !e.ctrlKey && !e.metaKey) { window.__pybkUI.text[window.__pybkUI.focus] = t + e.key; }
};
window.__pybkUI_BTN = function(ctx, x, y, w, h, label) {
  var mx = window.__pybkMX || 0, my = window.__pybkMY || 0;
  var over = mx >= x && mx <= x + w && my >= y && my <= y + h;
  ctx.fillStyle = over ? 'rgb(90,170,255)' : 'rgb(60,120,220)';
  ctx.fillRect(x, y, w, h);
  ctx.fillStyle = '#ffffff';
  ctx.font = '16px sans-serif';
  var tw = ctx.measureText(label).width;
  ctx.fillText(label, x + w / 2 - tw / 2, y + h / 2 + 6);
  return (over && window.__pybkMH) ? 1 : 0;
};
window.__pybkUI_INP = function(ctx, id, x, y, w, h) {
  var mx = window.__pybkMX || 0, my = window.__pybkMY || 0;
  var over = mx >= x && mx <= x + w && my >= y && my <= y + h;
  if (window.__pybkMH && over) window.__pybkUI.focus = id;
  var focused = window.__pybkUI.focus === id;
  var txt = window.__pybkUI.text[id] || '';
  ctx.fillStyle = '#ffffff'; ctx.fillRect(x, y, w, h);
  ctx.strokeStyle = focused ? '#50fa7b' : '#8899bb'; ctx.lineWidth = 2;
  ctx.strokeRect(x, y, w, h);
  ctx.fillStyle = '#222222'; ctx.font = '15px sans-serif';
  var caret = (focused && (Math.floor(Date.now() / 400) % 2 === 0)) ? '|' : '';
  ctx.fillText(txt + caret, x + 8, y + h / 2 + 5);
  return txt;
};
window.__pybkUI_SLD = function(ctx, id, x, y, w, lo, hi, val) {
  var mx = window.__pybkMX || 0, my = window.__pybkMY || 0;
  var over = mx >= x - 10 && mx <= x + w + 10 && my >= y - 12 && my <= y + 12;
  if (window.__pybkUI.val[id] === undefined) window.__pybkUI.val[id] = val;
  if (window.__pybkMH && over) window.__pybkUI.drag = id;
  if (window.__pybkUI.drag === id) {
    if (!window.__pybkMD) window.__pybkUI.drag = null;
    else { var t = (mx - x) / w; t = Math.max(0, Math.min(1, t)); window.__pybkUI.val[id] = lo + t * (hi - lo); }
  }
  var v = window.__pybkUI.val[id];
  var kn = x + w * (v - lo) / (hi - lo);
  ctx.strokeStyle = '#8899bb'; ctx.lineWidth = 4;
  ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + w, y); ctx.stroke();
  ctx.fillStyle = '#50fa7b';
  ctx.beginPath(); ctx.arc(kn, y, 8, 0, Math.PI * 2); ctx.fill();
  ctx.fillStyle = '#ffffff'; ctx.font = '13px sans-serif';
  ctx.fillText(String(Math.round(v * 100) / 100), x + w + 14, y + 5);
  return v;
};"""

def _find_gcc():
    import os
    for c in (r'C:\Users\zhuli\mingw64\bin\x86_64-w64-mingw32-gcc.exe',
              r'C:\Users\zhuli\mingw64\bin\gcc.exe',
              r'C:\Users\zhuli\Desktop\gcc.exe'):
        if os.path.isfile(c):
            return c
    return 'gcc'
FALLBACK_GCC = _find_gcc()
RT_CACHE_DIR = 'rt_cache'                 # 运行时 .o 预编译缓存目录

INT_MIN, INT_MAX = -(2 ** 63), 2 ** 63 - 1

BIN_OPS = {
    '+': 'rt_add', '-': 'rt_sub', '*': 'rt_mul', '/': 'rt_div',
    '%': 'rt_mod', '//': 'rt_fdiv',
    '==': 'rt_eq', '!=': 'rt_ne',
    '<': 'rt_lt', '>': 'rt_gt', '<=': 'rt_le', '>=': 'rt_ge',
    'in': 'rt_in', 'not_in': 'rt_not_in',
}


class PybkCodegenError(Exception):
    """后端语义错误 / 编译失败，消息带行号或附 gcc 输出。"""


def cstr(s: str) -> str:
    """语言字符串 → C 字符串字面量（内容按 UTF-8 原样保留）。"""
    buf = ['"']
    for ch in s:
        if ch == '\\':
            buf.append('\\\\')
        elif ch == '"':
            buf.append('\\"')
        elif ch == '\n':
            buf.append('\\n')
        elif ch == '\t':
            buf.append('\\t')
        elif ch == '\r':
            buf.append('\\r')
        else:
            buf.append(ch)
    buf.append('"')
    return ''.join(buf)


class _PkAbort(Exception):
    pass


class Codegen:
    def __init__(self):
        self.vmap = {}        # 语言变量名 -> v_N
        self.fmap = {}        # 语言函数名 -> f_N
        self.hw_used = False  # 用过 hw.*（out.c 需要发射 rt_hw_* 原型）
        self.nv = 0
        self.nf = 0
        self.nt = 0           # 临时变量计数（_t/_n/_i 共用，保证唯一）
        self.fns = {}         # 语言函数名 -> 参数个数
        self.hm_block_c = {}  # web.块 组件名 -> (C 函数名, 参数个数)
        self.缺省参数 = {}    # 函数名 -> [默认值节点或 None]（对齐参数位）
        self.out = []
        self.depth = 0
        self.declared = set()  # 当前函数内可读的名字（预扫描赋值 ∪ 参数 ∪ 循环 at）
        self._已赋值 = set()   # 真正生成过赋值的名字（区别于 emit_locals 的预声明：
                               # rm.around 标量化靠它判断"进圈前是否已有旧值"）
        self.in_going = False
        self.hm_used = False
        self.test_used = False  # 出现过 查() 测试语句（决定退出码=失败数）
        self.page_begun = False  # 是否已发射 rt_page_begin
        self._pk_iv = None       # 标量化循环的 C 计数变量名
        self._pk_lv = None       # 标量化循环的 PYbook 循环变量名
        self._pk_live = None     # (候选集, 类型表)
        self.draw_n = 0          # web.draw.始 计数 → canvas/ctx 的序号
        self.in_draw = None      # 当前打开的画布序号（web.draw.始..终 之间非 None）
        self._canvas_size = {}   # 画布序号 -> (宽, 高)；web.draw.始(宽,高) 可调，缺省 400×300
        self.loop_depth = 0      # 循环嵌套深度（break 只能在循环内使用的检查用）
        self.hm_frames = []      # 待播放的帧：每帧是 [('raw', js) / ('val', 临时名)] 计划
        self._frame_plan = None  # 收集帧体时非 None：raw/draw_val 改写入计划
        self.play_n = 0          # web.播放 计数（页内多段播放时 JS 全局名去重）
        self.live_n = 0          # web.实时 计数（页内多块实时时 JS 全局名去重）
        self.wait_n = 0          # web.waitsec 计数（页内多个等待时 DOM id 去重）
        self.spr_helpers_on = None   # 【热修】绘() 精灵辅助开关：generate() 会判 is None
        self._live_sfx = None    # 正在编译的实时块后缀（js_expr 里 按键/按过 用）
        self._live_declared = set()  # 当前实时块里可用的 JS 变量名
        self._live_loop = 0      # 实时块里的循环深度（break 检查用）
        self.go_n = 0            # go 计数（同上）
        self.classes = {}        # 类名 -> ClassDef
        self.vtypes = {}         # 变量名 -> 类名（vg.x = lb.类名(...) 推断）
        self.cur_class = None    # 正在编译的方法所属类

    # ---- 基础 ----

    def err(self, node, msg):
        raise PybkCodegenError(f'第 {node.line} 行：{msg}')

    def emit(self, line):
        self.out.append('    ' * self.depth + line if line else '')

    def vname(self, name):
        if name not in self.vmap:
            self.nv += 1
            self.vmap[name] = f'v_{self.nv}'
        return self.vmap[name]

    def fname(self, name):
        if name not in self.fmap:
            self.nf += 1
            self.fmap[name] = f'f_{self.nf}'
        return self.fmap[name]

    def newtemp(self, prefix='_t'):
        self.nt += 1
        return f'{prefix}{self.nt}'

    def check_declared(self, ref: VarRef):
        if ref.name not in self.declared:
            self.err(ref, f"变量 '{ref.name}' 未声明（规则：写用 vg.名 = 值 声明；"
                          f"函数内只能读参数和自己赋过的变量——要先 vg.名 = 赋值 再用；"
                          f"检查是否拼写错误）")

    # ---- 表达式：返回 (前置语句列表, C 表达式文本) ----
    # 需要控制流的构造（and/or）把语句提升到前置列表，保证短路语义，
    # 且能嵌在 ns.show 参数等任何表达式位置。

    def expr(self, e):
        if isinstance(e, VarRef) and e.name in ('frame', 'sec')                 and e.name not in self.declared:
            # 内置帧数/秒数：插值和表达式里裸写 frame / sec 都可用
            return [], (f'rt_frames()' if e.name == 'frame' else f'rt_secs()')
        if isinstance(e, NumLit):
            if isinstance(e.value, float):
                return [], f'rt_float({e.value!r})'
            if not (INT_MIN <= e.value <= INT_MAX):
                self.err(e, f'整数字面量 {e.value} 超出 64 位有符号范围')
            return [], f'rt_int({e.value}LL)'
        if isinstance(e, StrLit):
            return [], f'rt_str({cstr(e.value)})'
        if isinstance(e, Call) and e.name == '空' and not e.args:
            return [], 'rt_none()'
        if isinstance(e, Call) and e.name in ('PK_BOX_I', 'PK_BOX_F'):
            nm = e.args[0].value
            return ([], f'rt_int(S_{self.vname(nm)})') if e.name.endswith('I')                 else ([], f'rt_float(S_{self.vname(nm)})')
        if isinstance(e, Call) and e.name == 'PK_LOOP_I':
            return [], f'rt_at({self._pk_iv})'   # 值域：循环变量装箱
        if isinstance(e, BoolLit):
            return [], f'rt_bool({1 if e.value else 0})'
        if isinstance(e, VarRef):
            self.check_declared(e)
            return [], f'rt_chk({self.vname(e.name)})'
        if isinstance(e, InputExpr):
            return [], f'rt_input({cstr(e.prompt)})'
        if isinstance(e, Unary):
            s, c = self.expr(e.operand)
            if e.op == '-':
                return s, f'rt_neg({c})'
            if e.op == 'not':
                return s, f'rt_not({c})'
            self.err(e, f"不支持的一元运算符 '{e.op}'")
        if isinstance(e, BinOp):
            if e.op in ('and', 'or'):
                return self.short_circuit(e)
            if e.op not in BIN_OPS:
                self.err(e, f"不支持的运算符 '{e.op}'")
            ls, lc = self.expr(e.left)
            rs, rc = self.expr(e.right)
            stmts = ls + rs
            # 带前置语句的操作数物化成临时，左右求值顺序确定为从左到右
            if ls:
                lc = self.materialize(stmts, lc)
            if rs:
                rc = self.materialize(stmts, rc)
            return stmts, f'{BIN_OPS[e.op]}({lc}, {rc})'
        if isinstance(e, ListLit):
            t = self.newtemp()
            stmts = [f'Value {t} = rt_list_new();']
            for it in e.items:
                s, c = self.expr(it)
                stmts += s
                stmts.append(f'rt_push(&{t}, {c});')
            return stmts, t
        if isinstance(e, Index):
            bs, bc = self.expr(e.base)
            is_, ic = self.expr(e.index)
            if bs:
                bc = self.materialize(bs, bc)
            stmts = bs + is_
            return stmts, f'rt_index({bc}, {ic})'
        if isinstance(e, DictLit):
            t = self.newtemp('_dc')
            stmts = [f'Value {t} = rt_dict_new();']
            for kk, vv in e.pairs:
                s1, c1 = self.expr(kk)
                stmts += s1
                s2, c2 = self.expr(vv)
                stmts += s2
                c1 = self.materialize(stmts, c1)
                c2 = self.materialize(stmts, c2)
                stmts.append(f'rt_dict_set(&{t}, {c1}, {c2});')
            return stmts, t
        if isinstance(e, StrParts):
            return self._interp_concat(e)
        if isinstance(e, Ternary):
            cs, cc = self.expr(e.cond)
            t = self.newtemp('_t3')
            stmts = cs
            stmts.append(f'Value {t} = rt_none();')
            stmts.append(f'if (rt_cond({cc})) {{')
            as_, ac = self.expr(e.then)
            stmts += as_
            ac = self.materialize(stmts, ac)
            stmts.append(f'{t} = {ac};')
            stmts.append('} else {')
            bs, bc = self.expr(e.els)
            stmts += bs
            bc = self.materialize(stmts, bc)
            stmts.append(f'{t} = {bc};')
            stmts.append('}')
            return stmts, t
        if isinstance(e, DictComp):
            dt = self.newtemp('_dc')
            stmts = [f'Value {dt} = rt_dict_new();']
            is_, ic = self.expr(e.iter)
            stmts += is_
            itv = self.materialize(stmts, ic)
            saved = self.vmap.pop(e.vars[0], None)
            slot = self.vname(e.vars[0])
            iv = self.newtemp('_ci')
            stmts.append(f'for (long long {iv} = 0; {iv} < rt_iter_len_ll({itv}); {iv}++) {{')
            stmts.append(f'Value {slot} = (IS_DICT({itv}) ? rt_dict_key_at({itv}, {iv}) : rt_index({itv}, rt_at({iv})));')
            had = e.vars[0] in self.declared
            self.declared.add(e.vars[0])
            slot2 = None
            saved2 = None
            had2 = False
            if len(e.vars) == 2:
                saved2 = self.vmap.pop(e.vars[1], None)
                slot2 = self.vname(e.vars[1])
                stmts.append(f'Value {slot2} = (IS_DICT({itv}) ? rt_index({itv}, {slot}) : rt_index({slot}, rt_int(1LL)));')
                had2 = e.vars[1] in self.declared
                self.declared.add(e.vars[1])
            ks_, kc = self.expr(e.key)
            stmts += ks_
            kc = self.materialize(stmts, kc)
            vs_, vc = self.expr(e.val)
            stmts += vs_
            vc = self.materialize(stmts, vc)
            if e.cond is not None:
                cs2, cc2 = self.expr(e.cond)
                stmts += cs2
                cc2 = self.materialize(stmts, cc2)
                stmts.append(f'if (rt_cond({cc2})) rt_dict_set(&{dt}, {kc}, {vc});')
            else:
                stmts.append(f'rt_dict_set(&{dt}, {kc}, {vc});')
            if not had:
                self.declared.discard(e.vars[0])
            if saved is not None:
                self.vmap[e.vars[0]] = saved
            else:
                self.vmap.pop(e.vars[0], None)
            if len(e.vars) == 2:
                if not had2:
                    self.declared.discard(e.vars[1])
                if saved2 is not None:
                    self.vmap[e.vars[1]] = saved2
                else:
                    self.vmap.pop(e.vars[1], None)
            stmts.append('}')
            return stmts, dt
        if isinstance(e, Slice):
            bs, bc = self.expr(e.base)
            if bs:
                bc = self.materialize(bs, bc)
            stmts = bs
            MISS = '-2147483648'          # 段缺省哨兵（C 侧判 INT_MIN）
            def _段(x, miss):
                if x is None:
                    return miss
                s2, c2 = self.expr(x)
                stmts.extend(s2)
                if s2:
                    return self.materialize(stmts, c2)
                return c2
            a = _段(e.start, MISS)
            b = _段(e.stop, MISS)
            c = _段(e.step, MISS)
            return stmts, f'rt_list_slice({bc}, {a}, {b}, {c})'
        if isinstance(e, Comp):
            lt = self.newtemp('_lc')
            stmts = [f'Value {lt} = rt_list_new();']
            is_, ic = self.expr(e.iter)
            stmts += is_
            itv = self.materialize(stmts, ic)
            saved = self.vmap.pop(e.var, None)
            slot = self.vname(e.var)
            iv = self.newtemp('_ci')
            stmts.append(f'for (long long {iv} = 0; {iv} < rt_list_len_ll({itv}); {iv}++) {{')
            stmts.append(f'Value {slot} = rt_index({itv}, rt_at({iv}));')
            had = e.var in self.declared
            self.declared.add(e.var)
            es_, ec = self.expr(e.expr)
            stmts += es_
            if es_:
                ec = self.materialize(stmts, ec)
            if e.cond is not None:
                cs_, cc = self.expr(e.cond)
                stmts += cs_
                cc = self.materialize(stmts, cc)
                stmts.append(f'if (rt_cond({cc})) rt_push(&{lt}, {ec});')
            else:
                stmts.append(f'rt_push(&{lt}, {ec});')
            if not had:
                self.declared.discard(e.var)
            if saved is not None:
                self.vmap[e.var] = saved
            else:
                self.vmap.pop(e.var, None)
            stmts.append('}')
            return stmts, lt
        if isinstance(e, Call):
            if e.name in ('add', 'remove', 'len', 'touch'):
                e = Call({'add': '添加', 'remove': '删掉', 'len': '长度',
                          'touch': '碰到'}[e.name], e.args, e.line)
            if e.name in GAME_CALLS:          # 游戏零件内置：key/win/clear/color/box/show/wait/end
                return self.gen_game_call(e)
            if e.name == 'tm.stop':           # tm.stop(秒) / tm.stop(数值, "s"/"ms")
                if len(e.args) not in (1, 2):
                    self.err(e, 'tm.stop 的写法：tm.stop(秒) 或 tm.stop(数值, "s"/"ms")')
                stmts = []
                args = []
                for a in e.args:
                    s2, c2 = self.expr(a)
                    stmts += s2
                    args.append(self.materialize(stmts, c2))
                unit = args[1] if len(args) == 2 else 'rt_str("s")'
                return stmts, f'rt_lib_tm_stop({args[0]}, {unit})'
            if e.name in LIB_CALLS:           # 标准库：te/mt/rd/list/file
                return self.gen_lib_call(e)
            if e.name in ('按键', '按过'):
                self.err(e, f'{e.name}() 只能在 web.实时 块里用（网页实时模式的键盘监测）')
            if e.name in ('添加', '长度'):        # 内置：添加(列表, 值) / 长度(列表或字符串)
                if e.name == '长度':
                    if len(e.args) != 1:
                        self.err(e, '长度 需要 1 个参数')
                    s, c = self.expr(e.args[0])
                    return s, f'rt_len({c})'
                if len(e.args) != 2 or not isinstance(e.args[0], VarRef):
                    self.err(e, '添加 的写法：list.添加(列表名, 值)')
                self.check_declared(e.args[0])
                s, c = self.expr(e.args[1])
                return s, f'rt_push(&{self.vname(e.args[0].name)}, {c})'
            if e.name == '删掉':
                if len(e.args) != 2 or not isinstance(e.args[0], VarRef):
                    self.err(e, '删掉 的写法：删掉(列表名, 元素)')
                self.check_declared(e.args[0])
                s, c = self.expr(e.args[1])
                return s, f'rt_list_remove({self.vname(e.args[0].name)}, {c})'
            if e.name == '碰到':
                if len(e.args) != 2:
                    self.err(e, '碰到 需要 2 个参数：碰到(a, b)')
                stmts = []
                args = []
                for a in e.args:
                    s2, c2 = self.expr(a)
                    stmts += s2
                    args.append(self.materialize(stmts, c2))
                return stmts, f'rt_touch({args[0]}, {args[1]})'
            if e.name not in self.fns:
                self.err(e, f"函数 '{e.name}' 未定义（规则：func 名(参数) {{...}} 定义；"
                          f"引用(\"模块\") 合并模块函数；标准库前缀 mt./te./list./dict./rd.——"
                          f"检查是否拼写错误或漏了前缀）")
            期望 = self.fns[e.name]
            if len(e.args) > 期望:
                self.err(e, f"函数 '{e.name}' 最多 {期望} 个参数，得到 {len(e.args)} 个")
            stmts = []
            args = []
            for a in e.args:
                s, c = self.expr(a)
                stmts += s
                args.append(self.materialize(stmts, c))
            if len(args) < 期望:               # 缺参用默认值补齐（默认值在调用处求值）
                缺省 = self.缺省参数.get(e.name, [])
                for 槽 in range(len(args), 期望):
                    节点 = 缺省[槽] if 槽 < len(缺省) else None
                    if 节点 is None:
                        self.err(e, f"函数 '{e.name}' 第 {槽 + 1} 个参数没有默认值")
                    s, c = self.expr(节点)
                    stmts += s
                    args.append(self.materialize(stmts, c))
            return stmts, f'{self.fname(e.name)}({", ".join(args)})'
        if isinstance(e, Member):
            st, base = self.expr(e.base)
            return st, f'rt_obj_get_prop({base}, {cstr(e.attr)})'
        if isinstance(e, MethodCall):
            return self.gen_methodcall(e)
        if isinstance(e, CtorExpr):
            return self.gen_ctor(e)
        self.err(e, f'不支持的表达式节点 {type(e).__name__}')

    # ---- 游戏零件内置调用（键监听 / 终端画布） ----

    # 标准库：语言名 → C 函数名（te/mt/rd 在 pybook_lib.c，
    # list 扩展在 pybook_rt.c，file 在 pybook_file.c）
    LIB_C_NAMES = {
        'te.split': 'rt_lib_te_split', 'te.replace': 'rt_lib_te_replace',
        'te.trim': 'rt_lib_te_trim', 'te.upper': 'rt_lib_te_upper',
        'te.lower': 'rt_lib_te_lower', 'te.has': 'rt_lib_te_has',
        'te.len': 'rt_lib_te_len', 'te.cut': 'rt_lib_te_cut',
        'te.join': 'rt_lib_te_join',
        'mt.sqrt': 'rt_lib_mt_sqrt', 'mt.pow': 'rt_lib_mt_pow',
        'mt.abs': 'rt_lib_mt_abs', 'mt.ceil': 'rt_lib_mt_ceil',
        'mt.floor': 'rt_lib_mt_floor', 'mt.mod': 'rt_lib_mt_mod',
        'mt.max': 'rt_lib_mt_max', 'mt.min': 'rt_lib_mt_min',
        'mt.dist': 'rt_lib_mt_dist', 'mt.prod': 'rt_lib_mt_prod', 'mt.sum': 'rt_lib_mt_sum', 'mt.sin': 'rt_lib_mt_sin',
        'dict.keys': 'rt_dict_keys', 'dict.values': 'rt_dict_values', 'dict.byvalue': 'rt_dict_byvalue',
        'safe.get': 'rt_safe_get', 'safe.at': 'rt_safe_at', 'js.parse': 'rt_js_parse', 'js.dump': 'rt_js_dump', 'csv.parse': 'rt_csv_parse', 'csv.dump': 'rt_csv_dump', 'mm.色': 'rt_mm_color', 'mm.draw_away': 'rt_mm_draw_away', 'mm.贴': 'rt_mm_blt', 'mm.color': 'rt_mm_color', 'mm.blt': 'rt_mm_blt', 'mm.动': 'rt_mm_anim', 'mm.anim': 'rt_mm_anim', 'list.flat': 'rt_list_flat', 'list.zip': 'rt_list_zip', 'list.count': 'rt_list_count',
        'mt.cos': 'rt_lib_mt_cos', 'mt.tan': 'rt_lib_mt_tan',
        'mt.pi': 'rt_lib_mt_pi',
        'rd.int': 'rt_lib_rd_int', 'rd.float': 'rt_lib_rd_float',
        'rd.pick': 'rt_lib_rd_pick', 'rd.shuffle': 'rt_lib_rd_shuffle',
        'tb.softmax': 'rt_tb_softmax', 'tb.crossent': 'rt_tb_crossent',
        'tb.crossent_grad': 'rt_tb_crossent_grad', 'tb.argmax': 'rt_tb_argmax',
        'tb.sgd': 'rt_tb_sgd', 'tb.adam': 'rt_tb_adam',
        'tb.shuffle': 'rt_tb_shuffle', 'tb.onehot': 'rt_tb_onehot', 'tb.batch': 'rt_tb_batch',
        'list.sort': 'rt_list_sort', 'list.sorted': 'rt_list_sorted', 'list.rsorted': 'rt_list_rsorted', 'list.reverse': 'rt_list_reverse', 'list.byfield': 'rt_list_byfield',
        'list.unique': 'rt_list_unique', 'list.merge': 'rt_list_merge',
        'list.find': 'rt_list_find', 'list.max': 'rt_list_max',
        'list.min': 'rt_list_min',
        # bs.* 位运算（实现在 pybook_bits.c）
        'bs.and': 'rt_bs_and', 'bs.or': 'rt_bs_or', 'bs.xor': 'rt_bs_xor',
        'bs.not': 'rt_bs_not', 'bs.shl': 'rt_bs_shl', 'bs.shr': 'rt_bs_shr',
        'bs.get': 'rt_bs_get', 'bs.set': 'rt_bs_set',
        'bs.popcount': 'rt_bs_popcount', 'bs.band': 'rt_bs_band',
        'bs.mask': 'rt_bs_mask', 'bs.hex': 'rt_bs_hex', 'bs.bin': 'rt_bs_bin',
        'bs.frombin': 'rt_bs_frombin', 'bs.fromhex': 'rt_bs_fromhex',
        '圆': 'rt_game_circle', 'circle': 'rt_game_circle',
        'mt.atan2': 'rt_lib_mt_atan2',
        'hw.open': 'rt_hw_open', 'hw.clearcolor': 'rt_hw_clearcolor',
        'hw.camera': 'rt_hw_camera', 'hw.box': 'rt_hw_box',
        'hw.fog': 'rt_hw_fog', 'hw.far': 'rt_hw_far', 'hw.wire': 'rt_hw_wire',
        'hw.line': 'rt_hw_line', 'hw.light': 'rt_hw_light',
        'hw.sphere': 'rt_hw_sphere', 'hw.cyl': 'rt_hw_cylv',
        'hw.fov': 'rt_hw_fov', 'hw.near': 'rt_hw_near',
        'hw.tex': 'rt_hw_tex', 'hw.texuse': 'rt_hw_texuse', 'hw.uv': 'rt_hw_uv',
        'hw.push': 'rt_hw_push', 'hw.pop': 'rt_hw_pop',
        'hw.shader': 'rt_hw_shader', 'hw.preset': 'rt_hw_preset',
        'hw.shaderuse': 'rt_hw_shaderuse', 'hw.uni': 'rt_hw_univ',
        'hw.grab': 'rt_hw_grab', 'hw.free': 'rt_hw_free',
        'hw.mdx': 'rt_hw_mdx', 'hw.mdy': 'rt_hw_mdy',
        'np.zeros': 'rt_np_zeros', 'np.range': 'rt_np_range',
        'np.add': 'rt_np_add', 'np.sub': 'rt_np_sub', 'np.mul': 'rt_np_mul',
        'np.scale': 'rt_np_scale', 'np.dot': 'rt_np_dot', 'np.norm': 'rt_np_norm',
        'np.normalize': 'rt_np_normalize', 'np.max': 'rt_np_max', 'np.min': 'rt_np_min',
        'np.sum': 'rt_np_sum', 'np.mean': 'rt_np_mean',
        'np.sin': 'rt_np_sin', 'np.cos': 'rt_np_cos', 'np.sqrt': 'rt_np_sqrt',
        'tb.mat': 'rt_tb_mat', 'tb.rand': 'rt_tb_rand',
        'tb.rows': 'rt_tb_rows', 'tb.cols': 'rt_tb_cols',
        'tb.dot': 'rt_tb_dot', 'tb.tr': 'rt_tb_tr',
        'tb.add': 'rt_tb_add', 'tb.mul': 'rt_tb_mul', 'tb.addrow': 'rt_tb_addrow',
        'tb.relu': 'rt_tb_relu', 'tb.relu_grad': 'rt_tb_relu_grad',
        'tb.sigmoid': 'rt_tb_sigmoid', 'tb.sigmoid_grad': 'rt_tb_sigmoid_grad',
        'tb.mse': 'rt_tb_mse', 'tb.mse_grad': 'rt_tb_mse_grad',
        'tb.lin': 'rt_tb_lin', 'tb.lin_dx': 'rt_tb_lin_dx',
        'tb.lin_dw': 'rt_tb_lin_dw', 'tb.lin_db': 'rt_tb_lin_db',
        'tb.step': 'rt_tb_step',
        'mp.vec_add': 'rt_lib_mp_vec_add', 'mp.vec_sub': 'rt_lib_mp_vec_sub',
        'mp.vec_scale': 'rt_lib_mp_vec_scale', 'mp.vec_dot': 'rt_lib_mp_vec_dot',
        'mp.vec_norm': 'rt_lib_mp_vec_norm', 'mp.vec_dist': 'rt_lib_mp_vec_dist',
        'mp.vec_cross': 'rt_lib_mp_vec_cross', 'mp.vec_lerp': 'rt_lib_mp_vec_lerp',
        'mp.mat_add': 'rt_lib_mp_mat_add', 'mp.mat_scale': 'rt_lib_mp_mat_scale',
        'mp.mat_mul': 'rt_lib_mp_mat_mul', 'mp.mat_transpose': 'rt_lib_mp_mat_transpose',
        'mp.mat_identity': 'rt_lib_mp_mat_identity', 'mp.mat_det': 'rt_lib_mp_mat_det',
        'mp.mat_inverse': 'rt_lib_mp_mat_inverse', 'mp.mat_vec_mul': 'rt_lib_mp_mat_vec_mul',
        'mp.mean': 'rt_lib_mp_mean', 'mp.var': 'rt_lib_mp_var', 'mp.std': 'rt_lib_mp_std',
        'mp.sum': 'rt_lib_mp_sum', 'mp.minmax': 'rt_lib_mp_minmax', 'mp.linspace': 'rt_lib_mp_linspace',
        'mp.clamp': 'rt_lib_mp_clamp', 'mp.smoothstep': 'rt_lib_mp_smoothstep',
        'mp.lerp': 'rt_lib_mp_lerp', 'mp.radians': 'rt_lib_mp_radians', 'mp.degrees': 'rt_lib_mp_degrees',
        'mp.rand_seed': 'rt_lib_mp_rand_seed', 'mp.rand_u01': 'rt_lib_mp_rand_u01',
        'mp.rand_normal': 'rt_lib_mp_rand_normal',
        'hw.frame': 'rt_hw_frame', 'hw.end': 'rt_hw_end',
        'hw.key': 'rt_hw_key', 'hw.hit': 'rt_hw_hit',
        'hw.mx': 'rt_hw_mx', 'hw.my': 'rt_hw_my',
        'hw.mdown': 'rt_hw_mdown', 'hw.mhit': 'rt_hw_mhit',
        'hw.text': 'rt_hw_text',
        '圆': 'rt_game_circle', 'circle': 'rt_game_circle',
        'mt.atan2': 'rt_lib_mt_atan2',
        'te.str': 'rt_lib_te_str',
        'net.listen': 'rt_net_listen', 'net.accept': 'rt_net_accept',
        'net.connect': 'rt_net_connect', 'net.recv': 'rt_net_read',
        'net.readline': 'rt_net_read_block', 'net.send': 'rt_net_write',
        'net.close': 'rt_net_close',
        'file.read': 'rt_file_read', 'file.write': 'rt_file_write',
        'file.add': 'rt_file_add', 'file.exists': 'rt_file_exists',
        'file.lines': 'rt_file_lines', 'file.del': 'rt_file_del',
        'tm.now': 'rt_lib_tm_now',
        '音.正弦': 'rt_mu_sine', '音.三角': 'rt_mu_tri',
        '音.快': 'rt_mu_quick',
        '音.放': 'rt_mu_play', '音.停': 'rt_mu_stop',
        '音.音': 'rt_mu_note', '音.奏': 'rt_mu_away', '音.谱': 'rt_mu_play_list',
        '调色板.红': 'rt_lib_pal_hong', '调色板.橙': 'rt_lib_pal_cheng',
        '调色板.黄': 'rt_lib_pal_huang', '调色板.绿': 'rt_lib_pal_lv',
        '调色板.青': 'rt_lib_pal_qing', '调色板.蓝': 'rt_lib_pal_lan',
        '调色板.紫': 'rt_lib_pal_zi', '调色板.白': 'rt_lib_pal_bai',
        '调色板.黑': 'rt_lib_pal_hei', '调色板.灰': 'rt_lib_pal_hui',
        '调色板.粉': 'rt_lib_pal_fen', '调色板.金': 'rt_lib_pal_jin',
    }

    def gen_lib_call(self, e):
        if e.name == 'hw.text':
            stmts = []
            args = []
            for k4, a4 in enumerate(e.args):
                if k4 == 3 and isinstance(a4, StrParts):
                    s4, c4 = self._interp_concat(a4)
                    stmts += s4
                    args.append(self.materialize(stmts, c4))
                    continue
                s5, c5 = self.expr(a4)
                stmts += s5
                args.append(self.materialize(stmts, c5))
            return stmts, f'rt_hw_text({", ".join(args)})'

        if e.name.startswith('ui.'):
            self.err(e, f'{e.name} 只在网页模式支持（写在 web.实时 块里）')
        # net.send 发一行：codegen 层自动补换行（rt_net_write 只发原样字节，
        # 这也是 C 层自测能构造半包场景的基础）
        if e.name == 'net.send':
            if len(e.args) != 2:
                self.err(e, 'net.send 需要 2 个参数')
            st_h, c_h = self.expr(e.args[0])
            st_t, c_t = self.expr(e.args[1])
            stmts = st_h + st_t
            tmp = self.materialize(stmts, f'rt_add({c_t}, rt_str({cstr(NL_CHAR)}))')
            return stmts, f'rt_net_write({c_h}, {tmp})'
        c_func = self.LIB_C_NAMES[e.name]
        if e.name.startswith('hw.'):
            self.hw_used = True
        want = LIB_CALLS[e.name]
        if e.name == 'hw.box' and len(e.args) == 12:
            pass                        # 带绕 x/y/z 旋转的写法：走 rt_hw_boxn
        elif e.name == 'hw.cyl' and len(e.args) == 10:
            pass                        # cyl 带自定义边数的写法：走 rt_hw_cylv
        elif e.name == 'hw.uni' and 2 <= len(e.args) <= 5:
            pass                        # uni("名字", a[, b[, c[, d]]])：1~4 个分量
        elif len(e.args) != want:
            self.err(e, f'{e.name} 需要 {want} 个参数，得到 {len(e.args)} 个')
        stmts = []
        args = []
        for a in e.args:
            s, c = self.expr(a)
            stmts += s
            args.append(self.materialize(stmts, c))
        if e.name == 'hw.box' and len(e.args) == 12:
            # rt_hw_boxn(nargs, (Value[]){ ... }) —— 复合字面量，C99
            return stmts, (f'rt_hw_boxn(12, (Value[]){{ {", ".join(args)} }})')
        if e.name == 'hw.cyl':
            # rt_hw_cylv(nargs, (Value[]){ ... }) —— 9 参或 10 参都走这里
            return stmts, (f'rt_hw_cylv({len(args)}, (Value[]){{ {", ".join(args)} }})')
        if e.name == 'hw.uni':
            # rt_hw_univ(nargs, (Value[]){ ... }) —— 2~5 个实参都走这里
            return stmts, (f'rt_hw_univ({len(args)}, (Value[]){{ {", ".join(args)} }})')
        return stmts, f'{c_func}({", ".join(args)})'

    def gen_sprites_draw(self, e):
        """绘(列表)：降级成对 rt_game_img_scaled 的逐元素循环。

        语义 = 对每个元素做 图缩(e.x - 宽/2, e.y - 高/2, e.宽, e.高, e.图)；
        元素缺 x/y/宽/高/图 任一属性 → _pbk_sprop 运行时报错并带是第几个元素。"""
        if len(e.args) != 1 or not isinstance(e.args[0], VarRef):
            self.err(e, '绘 的写法：绘(列表名)')
        self.check_declared(e.args[0])
        st, lst = self.expr(e.args[0])
        i = self.newtemp('_si')
        n = self.newtemp('_sn')
        el = self.newtemp('_se')
        lines = list(st)
        lines.append('{')
        lines.append(f'    long long {n} = AS_INT(rt_len({lst}));')
        lines.append(f'    long long {i};')
        lines.append(f'    for ({i} = 0; {i} < {n}; {i}++) {{')
        lines.append(f'        Value {el} = rt_index({lst}, rt_int({i}));')
        lines.append(f'        Value _sx = _pbk_sprop({el}, "x", {i});')
        lines.append(f'        Value _sy = _pbk_sprop({el}, "y", {i});')
        lines.append(f'        Value _sw = _pbk_sprop({el}, "宽", {i});')
        lines.append(f'        Value _sh = _pbk_sprop({el}, "高", {i});')
        lines.append(f'        Value _sp = _pbk_sprop({el}, "图", {i});')
        lines.append(f'        rt_game_img_scaled(rt_sub(_sx, _pbk_half(_sw, {i})), '
                      f'rt_sub(_sy, _pbk_half(_sh, {i})), _sw, _sh, _sp);')
        lines.append('    }')
        lines.append('}')
        return lines, 'rt_none()'

    def gen_game_call(self, e: Call):
        """游戏零件 → rt_game_*（运行时现行命名）。

        key/hit 的键名要字符串字面量（免运行时拆盒）；
        win 的标题要字符串字面量（rt_game_win 第三参是 const char*）；
        clear() 无参 → 用上一条 color(字面量,...) 记下的颜色清屏
        （老脚本 color(...); clear() 的写法），带 3 个参数则直接透传；
        wait(ms) → rt_game_frame()（帧末闸门：泵事件 + 键状态翻页 + 约60FPS，
        运行时已无裸 sleep 的 rt_wait）。"""
        name = e.name
        want = GAME_CALLS[name]
        if name == 'clear' and len(e.args) == 3:
            want = 3                        # clear(r,g,b) 直接透传的新写法
        if name == 'color' and len(e.args) == 1:
            want = 1                        # color(列表) 重载：参数是 [r,g,b] 列表
        if len(e.args) != want:
            self.err(e, f"{name} 需要 {want} 个参数，得到 {len(e.args)} 个")

        if name == 'color' and len(e.args) == 1:
            # color(列表)：取列表的 0/1/2 号元素当 R/G/B。列表来自 vg_ro 或
            # 调色板.颜色名（rt_lib_pal_*，返回新建 [r,g,b] 列表）；
            # 非列表仍走 rt_index 的既有报错（照旧退出），行为不变。
            st, c = self.expr(e.args[0])
            t = self.newtemp('_pal')
            for x in st:
                self.emit(x)
            self.emit(f'Value {t} = {c};')
            return [], (f'rt_game_color(rt_index({t}, rt_int(0LL)), '
                        f'rt_index({t}, rt_int(1LL)), rt_index({t}, rt_int(2LL)))')

        if name == '绘':
            return self.gen_sprites_draw(e)

        if name in ('key', 'hit'):
            a = e.args[0]
            if not isinstance(a, StrLit):
                self.err(e, f'{name} 的键名必须是字符串字面量，如 {name}("space")')
            return [], f'rt_game_{name}({cstr(a.value)})'

        if name == 'dirkeys':
            return [], 'rt_dirkeys()'
        if name == 'frame':
            return [], 'rt_frames()'
        if name == 'sec':
            return [], 'rt_secs()'

        if name in ('字', '图', '图缩', '线', '点'):   # 中文名字面量 → C 函数名映射
            c_name = {'字': 'rt_game_text', '图': 'rt_game_img',
                      '图缩': 'rt_game_img_scaled',
                      '线': 'rt_game_line', '点': 'rt_game_dot',
                      '圆': 'rt_game_circle', 'circle': 'rt_game_circle'}[name]
            stmts = []
            args = []
            for k2, a in enumerate(e.args):
                if k2 == 2 and isinstance(a, StrParts) and name in ('字', '图'):
                    s3, c3 = self._interp_concat(a)       # "得分 $分" / "$x+1" → rt_add 链
                    stmts += s3
                    args.append(self.materialize(stmts, c3))
                    continue
                s2, c2 = self.expr(a)
                stmts += s2
                args.append(self.materialize(stmts, c2))
            return stmts, f'{c_name}({", ".join(args)})'

        if name == 'win':
            title = e.args[2]
            if not isinstance(title, StrLit):
                self.err(e, 'win 的窗口标题必须是字符串字面量')
            st = []
            vs = []
            for a in e.args[:2]:
                s2, c2 = self.expr(a)
                st += s2
                vs.append(self.materialize(st, c2))
            return st, f'rt_game_win({vs[0]}, {vs[1]}, {cstr(title.value)})'

        if name == 'color':
            lits = []
            for a in e.args:
                if not isinstance(a, NumLit) or isinstance(a.value, float):
                    lits = None
                    break
                lits.append(int(a.value))
            if lits is not None:
                self._last_color = tuple(lits)   # 供无参 clear() 使用

        if name == 'clear' and want == 0:
            r, g, b = getattr(self, '_last_color', (0, 0, 0))
            return [], f'rt_game_clear({r}, {g}, {b})'

        if name == 'wait':
            s2, _c2 = self.expr(e.args[0])    # 参数照常求值（保持语法检查），时长交给帧闸门
            return s2, 'rt_game_frame()'

        stmts = []
        args = []
        for a in e.args:
            s2, c2 = self.expr(a)
            stmts += s2
            args.append(self.materialize(stmts, c2))
        return stmts, f'rt_game_{name}({", ".join(args)})'

    def materialize(self, stmts, c):
        t = self.newtemp()
        stmts.append(f'Value {t} = {c};')
        return t

    def short_circuit(self, e):
        ls, lc = self.expr(e.left)
        rs, rc = self.expr(e.right)
        t = self.newtemp()
        stmts = list(ls)
        stmts.append(f'Value {t} = rt_none();')
        if e.op == 'and':      # A 为假取 A，否则取 B
            stmts.append(f'if (rt_cond({lc})) {{')
            stmts += ['    ' + x for x in rs]
            stmts.append(f'    {t} = {rc};')
            stmts.append('} else {')
            stmts.append(f'    {t} = {lc};')
            stmts.append('}')
        else:                  # or：A 为真取 A，否则取 B
            stmts.append(f'if (rt_cond({lc})) {{')
            stmts.append(f'    {t} = {lc};')
            stmts.append('} else {')
            stmts += ['    ' + x for x in rs]
            stmts.append(f'    {t} = {rc};')
            stmts.append('}')
        return stmts, t

    # ---- 语句 ----

    def stmt(self, s):
        if isinstance(s, VgAssign):
            if self._pk_live and s.name in self._pk_live[0]:
                code, k = self._pk_scalar_expr(s.expr)
                want = self._pk_live[1].get(s.name, 'i')
                if k != want:
                    code = f'(long long)({code})' if want == 'i' else f'(double)({code})'
                self.emit(f'S_{self.vname(s.name)} = {code};')
                return
            st, c = self.expr(s.expr)
            for x in st:
                self.emit(x)
            self.emit(f'rt_assign(&{self.vname(s.name)}, {c});')
            self._已赋值.add(s.name)
            if isinstance(s.expr, CtorExpr):
                self.vtypes[s.name] = s.expr.class_name
        elif isinstance(s, MultiAssign):
            # 解包：a, b = 列表（一个列表值拆给多个目标）
            if len(s.values) == 1 and len(s.targets) > 1:
                st, c = self.expr(s.values[0])
                for x in st:
                    self.emit(x)
                src = self.newtemp()
                self.emit(f'Value {src} = {c};')
                for i, tg in enumerate(s.targets):
                    vi = self.newtemp()
                    self.emit(f'Value {vi} = rt_index({src}, rt_int({i}));')
                    if isinstance(tg, str):
                        self.emit(f'rt_assign(&{self.vname(tg)}, {vi});')
                    else:
                        self.check_declared(VarRef(tg.base.name, tg.line))
                        sti, ic = self.expr(tg.index)
                        for x in sti:
                            self.emit(x)
                        self.emit(f'rt_setindex(&{self.vname(tg.base.name)}, {ic}, {vi});')
                return
            # 右边先全部求值（交换语义正确），再逐个赋值
            vals = []
            for v in s.values:
                st, c = self.expr(v)
                for x in st:
                    self.emit(x)
                t = self.newtemp()          # 必须先物化：交换语义依赖右边先算完
                self.emit(f'Value {t} = {c};')
                vals.append(t)
            for tg, c in zip(s.targets, vals):
                if isinstance(tg, str):
                    self.emit(f'rt_assign(&{self.vname(tg)}, {c});')
                else:   # Index 目标：t[j] = 值
                    self.check_declared(VarRef(tg.base.name, tg.line))
                    sti, ic = self.expr(tg.index)
                    for x in sti:
                        self.emit(x)
                    self.emit(f'rt_setindex(&{self.vname(tg.base.name)}, {ic}, {c});')
        elif isinstance(s, IpAssign):
            self.emit(f'rt_assign(&{self.vname(s.name)}, rt_input({cstr(s.prompt)}));')
        elif isinstance(s, MemoryMode):
            self.emit(f'rt_set_memmode({s.mode});')
        elif isinstance(s, Call):               # 语句形态的调用（如 list.添加(...)）
            st, c = self.expr(s)
            for x in st:
                self.emit(x)
            self.emit(f'{c};')
        elif isinstance(s, AssignIndex):
            self.check_declared(VarRef(s.name, s.line))
            st, ic = self.expr(s.index)
            for x in st:
                self.emit(x)
            st2, vc = self.expr(s.expr)
            for x in st2:
                self.emit(x)
            self.emit(f'rt_setindex(&{self.vname(s.name)}, {ic}, {vc});')
        elif isinstance(s, AssignMember):
            st, obj_c = self.expr(s.base)
            for x in st:
                self.emit(x)
            st2, c = self.expr(s.expr)
            for x in st2:
                self.emit(x)
            self.emit(f'rt_obj_set_prop({obj_c}, {cstr(s.attr)}, {c});')
        elif isinstance(s, GoldDel):
            self.check_declared(VarRef(s.name, s.line))
            # NaN-boxing 后 8 字节盒子里没有 flags 字段：锁定走槽侧表（rt_gold），
            # 删除把盒子改写成删除位样（rt_destroy），行为与旧 flags |= 逐字对应。
            # 注意：函数名必须与 pybook_rt.c 里定义的一致——曾经写成
            # rt_slot_lock/rt_slot_del，导致 lock/del 生成的代码根本编不过。
            fn = 'rt_gold' if s.kind == 'gold' else 'rt_destroy'
            self.emit(f'{fn}(&{self.vname(s.name)});')
        elif isinstance(s, NsShow):
            if s.vc_cond is not None:        # 短vc：vc:条件?(替代内容)
                st, c = self.expr(s.vc_cond)
                for x in st:
                    self.emit(x)
                self.emit(f'if (rt_cond({c})) {{')
                self.depth += 1
                self._emit_show_parts(s, s.parts, s.magic)
                self.depth -= 1
                self.emit('} else {')
                self.depth += 1
                self._emit_show_parts(s, s.vc_alt, [])   # magic 只作用于主内容
                self.depth -= 1
                self.emit('}')
            else:
                self._emit_show_parts(s, s.parts, s.magic)
        elif isinstance(s, TestCheck):
            self.test_used = True
            st, c_e = self.expr(s.cond)
            for x in st:
                self.emit(x)
            self.emit(f'rt_test_check(rt_cond({c_e}), {cstr(s.name)});')
        elif isinstance(s, HmStmt):
            self.gen_hm(s)
        elif isinstance(s, HmUse):
            self.gen_hm_use(s)
        elif isinstance(s, HmPageStmt):
            self.gen_hm_page(s)
        elif isinstance(s, HmDraw):
            self.gen_draw(s)
        elif isinstance(s, HmFrame):
            self.gen_frame(s)
        elif isinstance(s, HmPlay):
            self.gen_play(s)
        elif isinstance(s, HmLive):
            self.gen_live(s)
        elif isinstance(s, GoStmt):
            self.gen_go(s)
        elif isinstance(s, Around):
            if not self.try_scalar_around(s):
                self.gen_around(s)
        elif isinstance(s, ForIn):
            self.gen_forin(s)
        elif isinstance(s, TryCatch):
            self.gen_trycatch(s)
        elif isinstance(s, OnError):
            self.gen_onerror(s)
        elif isinstance(s, Aging):
            self.emit('for (;;) {')
            self.depth += 1
            st, c = self.expr(s.cond)
            for x in st:
                self.emit(x)
            self.emit(f'if (rt_cond({c})) break;')
            self.loop_depth += 1
            self.block(s.body)
            self.loop_depth -= 1
            self.depth -= 1
            self.emit('}')
        elif isinstance(s, VcChain):
            self.gen_vc(s.arms)
        elif isinstance(s, BreakStmt):
            # PYbook 的 if/vc 链不生成 switch，C 的 break 在这里语义一致：
            # 跳出最近一层 loop（around/aging 的 for）
            if self.loop_depth == 0:
                self.err(s, 'break 只能在循环内使用')
            self.emit('break;')
        elif isinstance(s, CdBlock):
            # 单个 cd 落到这里（正常路径已被 block() 摘走）：按位置展开
            self.block(s.body)
        elif isinstance(s, Ret):
            if self.in_going:
                self.err(s, 'ret 不能出现在 GOING 里（规则：ret 只在 func 里用；'
                            'GOING 是主流程，把要复用的逻辑放进 func）')
            if s.expr is None:
                self.emit('rt_scope_leave();')
                self.emit('return rt_none();')
            else:
                st, c = self.expr(s.expr)
                for x in st:
                    self.emit(x)
                self.emit('rt_scope_leave();')
                self.emit(f'return {c};')
        else:
            self.err(s, f'不支持的语句节点 {type(s).__name__}')

    def _emit_show_parts(self, s, parts, magic):
        """一次 ns.show 的完整发射：magic 头 + TEXT/VAR/EXPR 部件 + 收尾。"""
        if magic:
            self.emit(f'rt_magic({cstr(",".join(magic))});')
        for kind, val in parts:
            if kind == 'TEXT':
                self.emit(f'rt_show_text({cstr(val)});')
            elif kind == 'EXPR':
                st, c = self.expr(val)
                for x in st:
                    self.emit(x)
                self.emit(f'rt_show_value({c});')
            else:
                st, c = self.expr(VarRef(val, s.line))
                for x in st:
                    self.emit(x)
                self.emit(f'rt_show_value({c});')
        self.emit('rt_show_end();')

    def block(self, stmts):
        """一层语句：cd 块按 priority 升序稳定排序提到本层最前，其余按书写顺序。"""
        cds = [s for s in stmts if isinstance(s, CdBlock)]
        rest = [s for s in stmts if not isinstance(s, CdBlock)]
        ordered = sorted(cds, key=lambda c: c.priority) + rest
        self.depth += 1
        for s in ordered:
            行 = getattr(s, 'line', None)
            if 行:
                self.emit(f'g_cur_line = {int(行)};')   # 运行时报错带行号
            self.stmt(s)
            # 语句边界：GC 只在这里回收（@5/@6）。求值途中绝不回收，
            # 否则没登记为根的临时值会被收走 → 悬挂指针。
            if not isinstance(s, Ret):
                self.emit('rt_gc_poll();')
        self.depth -= 1

    # ---- hm 网页输出分支 ----

    # rt_page_para_open 只接受运行时 page_style_css 的 token 方言（b/i/u/d/
    # c=R,G,B/bk=R,G,B/fm/fl/fr/l/m/r，翻译结果与 hm 样式表一一对应）。
    # f.名称 / fs.数字 两个 hm 专属样式在冻结版 pybook_rt.c 里没有对应
    # token（未知 token 会 rt_die），编译器无法下发，这里过滤——见验收说明。
    _HM_STYLE_DROP = ('f.', 'fs.')

    def hm_style(self, s) -> str:
        return ','.join(
            t for t in (item.strip() for item in s.magic)
            if t and not t.startswith(self._HM_STYLE_DROP))

    def _hm_parts(self, parts, line):
        """部件 → [(前置语句, Value C 表达式)]：TEXT→rt_str，VAR/EXPR→求值。"""
        out = []
        for kind, val in parts:
            if kind == 'TEXT':
                out.append(([], f'rt_str({cstr(val)})'))
            elif kind == 'EXPR':
                out.append(self.expr(val))
            else:
                out.append(self.expr(VarRef(val, line)))
        return out

    def _hm_concat(self, s):
        """parts 拼成一个 Value 字符串（rt_add 串联，运行时 malloc 不回收）。"""
        acc = None
        for st, c in self._hm_parts(s.parts, s.line):
            for x in st:
                self.emit(x)
            acc = c if acc is None else f'rt_add({acc}, {c})'
        return acc or 'rt_str("")'

    def _hm_concat_arg(self, part):
        """单个 part（表达式节点）转 JS 字面量（供 storage 等使用）。"""
        if isinstance(part, tuple) and part[0] == 'TEXT':
            return chr(39) + part[1].replace(chr(39), '') + chr(39)
        # 表达式节点：走 C 值再烘进页面不现实——web.storage 只支持常量
        if hasattr(part, 'value'):
            return chr(39) + str(part.value) + chr(39)
        return chr(39) + chr(39)

    def gen_hm(self, s):
        self.hm_used = True
        if not self.page_begun:      # 首条 hm 语句先落页面骨架头
            title = getattr(self, 'program_meta', '') or 'PYbook 页面'
            self.emit(f'rt_page_begin({cstr(title)});')
            self.page_begun = True
        if s.kind == 'line':
            self.emit('rt_page_hr();')
        elif s.kind == 'img':
            self.emit(f'rt_page_img({cstr(s.arg)});')
        elif s.kind == 'link':
            if s.parts and all(k == 'TEXT' for k, _v in s.parts):
                text_c = cstr(''.join(v for _k, v in s.parts))
            else:
                text_c = f'rt_str_of({self._hm_concat(s)})'
            self.emit(f'rt_page_link({text_c}, {cstr(s.arg)});')
        elif s.kind in ('big', 'mid'):
            level = 1 if s.kind == 'big' else 2
            self.emit(f'rt_page_h(rt_str_of({self._hm_concat(s)}), {level});')
        elif s.kind == 'show':
            self.emit(f'rt_page_para_open({cstr(self.hm_style(s))});')
            for st, c in self._hm_parts(s.parts, s.line):
                for x in st:
                    self.emit(x)
                self.emit(f'rt_page_value({c});')
            self.emit('rt_page_para_close();')
        elif s.kind == 'textbox':
            q = chr(39)
            self.raw('<input id=' + q + 'pybk_tb_' + s.arg + q + ' placeholder=' + q + s.parts[0][1] + q + ' style=' + q + 'font-size:16px;padding:6px 10px;border-radius:8px;border:1px solid #555;background:#14141c;color:#eee' + q + '>' + '\n')
            if s.magic and s.magic[0]:
                bid = s.magic[0]
                self.raw('<scr' + 'ipt>document.getElementById(' + q + 'pybk_tb_' + s.arg + q + ').addEventListener(' + q + 'keydown' + q + ',function(e){if(e.key===' + q + 'Enter' + q + '){window.__pybkBTN[' + q + bid + q + ']=1;}});</scr' + 'ipt>' + '\n')

        elif s.kind == 'button':
            q = chr(39)
            self.raw('<button id=' + q + 'pybk_btn_' + s.arg + q + ' style=' + q + 'font-size:16px;padding:6px 14px;border-radius:8px;border:0;background:#50fa7b;color:#111;cursor:pointer' + q + '>' + s.parts[0][1] + '</button>' + '\n')
            self.raw('<script>document.getElementById(' + q + 'pybk_btn_' + s.arg + q + ').addEventListener(' + q + 'mousedown' + q + ',function(){window.__pybkBTN[' + q + s.arg + q + ']=1;});document.addEventListener(' + q + 'mouseup' + q + ',function(){window.__pybkBTN[' + q + s.arg + q + ']=0;});</script>' + '\n')
        elif s.kind == 'audio':
            q = chr(39)
            self.raw('<audio id=' + q + 'pybk_audio' + q + ' src=' + q + s.parts[0][1] + q + ' preload=' + q + 'auto' + q + '></audio>' + '\n')
        elif s.kind == 'audio_stop':
            q = chr(39)
            self.raw('<script>var _a=document.getElementById(' + q + 'pybk_audio' + q + ');if(_a){_a.pause();_a.currentTime=0;}</script>' + '\n')
        elif s.kind == 'set':
            self.err(s, 'web.置 只能在 web.实时 块里用（页面烤完输入框才存在）')
        elif s.kind == 'align':
            self.raw('<div style=text-align:' + s.parts[0][1] + '>' + '\n')
        elif s.kind == 'gap':
            self.raw('<div style=height:' + s.parts[0][1] + 'px></div>' + '\n')
        elif s.kind == 'open':
            self.raw('<script>window.open(' + chr(39) + s.arg + chr(39) + ',' + chr(39) + '_blank' + chr(39) + ');</script>' + '\n')
        elif s.kind == 'style':
            self.raw('<style>' + s.arg + '</style>' + '\n')
        elif s.kind == 'storage':
            karg = self._hm_concat_arg(s.parts[0])
            varg = self._hm_concat_arg(s.parts[1])
            js = 'try{localStorage.setItem(' + karg + ',' + varg + ');}catch(e){}'
            self.raw('<scr' + 'ipt>' + js + '</scr' + 'ipt>' + '\n')
        elif s.kind == 'waitsec':
            self.raw('<div id=pybk_wait' + str(self.wait_n) + '></div>' + '\n')
            self.raw('<scr' + 'ipt>var w' + str(self.wait_n) + '=' + s.parts[0][1] + ';setInterval(function(){w' + str(self.wait_n) + '-=0.1;if(w' + str(self.wait_n) + '<=0)clearInterval(this)},100);</scr' + 'ipt>' + '\n')
            self.wait_n = getattr(self, 'wait_n', 0) + 1
        elif s.kind == 'title':
            self.raw('<script>document.title=' + chr(39) + s.arg + chr(39) + ';</script>' + '\n')
        else:
            self.err(s, f'未知的 web 语句 web.{s.kind}')

    # ---- web.draw 画布绘图 ----

    def raw(self, js):
        if self._frame_plan is not None:   # 帧体：JS 片段先进计划，web.播放 时统一发射
            self._frame_plan.append(('raw', js))
        else:
            self.emit(f'rt_page_raw({cstr(js)});')

    def draw_val(self, t):
        if self._frame_plan is not None:
            self._frame_plan.append(('val', t))
        else:
            self.emit(f'rt_page_text(rt_str_of({t}));')

    def _draw_param(self, e):
        st, c = self.expr(e)
        for x in st:
            self.emit(x)
        t = self.newtemp('_d')
        self.emit(f'Value {t} = {c};')
        return t

    def gen_draw(self, s):
        self.hm_used = True
        if not self.page_begun:      # 画布同样要落在页面骨架里
            title = getattr(self, 'program_meta', '') or 'PYbook 页面'
            self.emit(f'rt_page_begin({cstr(title)});')
            self.page_begun = True
        if s.cmd == 'begin':
            if self.in_draw is not None:
                self.err(s, 'web.draw.始 嵌套：上一块画布还没用 web.draw.终 结束')
            self.draw_n += 1
            self.in_draw = self.draw_n
            n = str(self.draw_n)
            w, h = 400, 300
            if len(s.params) == 2 and isinstance(s.params[0], NumLit) \
                    and isinstance(s.params[1], NumLit):
                w, h = s.params[0].value, s.params[1].value
            self._canvas_size[self.in_draw] = (w, h)
            self.raw('<canvas id="pybook-canvas-' + n + '" width="' + str(w)
                     + '" height="' + str(h) + '"></canvas>\n')
            self.raw('<script>\nconst ctx' + n + ' = document.getElementById(\'pybook-canvas-' + n + '\').getContext(\'2d\');\n')
            return
        if self.in_draw is None:
            self.err(s, f'web.draw.{s.cmd} 必须在 web.draw.始 之后使用')
        ctx = f'ctx{self.in_draw}'
        temps = []
        for k2, e2 in enumerate(s.params):
            if s.cmd == 'text' and k2 == 2 and isinstance(e2, StrParts):
                s3, c3 = self._interp_concat(e2)
                stmts += s3
                t = self.newtemp('_d')
                self.emit(f'Value {t} = {self.materialize(stmts, c3)};')
                temps.append(t)
            else:
                temps.append(self._draw_param(e2))
        if s.cmd == 'color':
            self.raw(ctx + ".fillStyle = 'rgb(")
            self.draw_val(temps[0])
            self.raw(',')
            self.draw_val(temps[1])
            self.raw(',')
            self.draw_val(temps[2])
            self.raw(")';\n")
            self.raw(ctx + ".strokeStyle = 'rgb(")
            self.draw_val(temps[0])
            self.raw(',')
            self.draw_val(temps[1])
            self.raw(',')
            self.draw_val(temps[2])
            self.raw(")';\n")
        elif s.cmd == 'circle':
            self.raw(ctx + '.beginPath();')
            self.raw(ctx + '.arc(')
            self.draw_val(temps[0])
            self.raw(',')
            self.draw_val(temps[1])
            self.raw(',')
            self.draw_val(temps[2])
            self.raw(',0,Math.PI*2);')
            self.raw(ctx + '.fill();')
            self.raw('\n')
        elif s.cmd == 'rect':
            self.raw(ctx + '.fillRect(')
            self.draw_val(temps[0])
            self.raw(',')
            self.draw_val(temps[1])
            self.raw(',')
            self.draw_val(temps[2])
            self.raw(',')
            self.draw_val(temps[3])
            self.raw(');\n')
        elif s.cmd == 'line':
            self.raw(ctx + '.beginPath();')
            self.raw(ctx + '.moveTo(')
            self.draw_val(temps[0])
            self.raw(',')
            self.draw_val(temps[1])
            self.raw(');\n')
            self.raw(ctx + '.lineTo(')
            self.draw_val(temps[2])
            self.raw(',')
            self.draw_val(temps[3])
            self.raw(');\n')
            self.raw(ctx + '.stroke();')
            self.raw('\n')
        elif s.cmd == 'clear':
            self.raw(ctx + ".fillStyle = 'rgb(")
            self.draw_val(temps[0])
            self.raw(',')
            self.draw_val(temps[1])
            self.raw(',')
            self.draw_val(temps[2])
            self.raw(")';\n")
            cw, ch = self._canvas_size.get(self.in_draw, (400, 300))
            self.raw(ctx + f'.fillRect(0, 0, {cw}, {ch});\n')
        elif s.cmd == 'text':
            self.raw(ctx + '.font = "')
            self.draw_val(temps[3])
            self.raw("px 'Microsoft YaHei UI', sans-serif\";\n")
            self.raw(ctx + '.fillText("')
            self.draw_val(temps[2])
            self.raw('", ')
            self.draw_val(temps[0])
            self.raw(',')
            self.draw_val(temps[1])
            self.raw(');\n')
        elif s.cmd in ('img_draw', 'img_scaled'):
            self.err(s, 'web.draw.图/图缩 要写在 web.实时 块里用（图片是异步加载的，静态画布画不上）')
        elif s.cmd == 'end':
            self.raw('</script>\n')
            self.in_draw = None
        else:
            self.err(s, f'未知的画布命令 {s.cmd}')

    # ---- web.帧 / web.播放 / go：帧动画与画布整体移动（仅原生模式）----

    def _need_canvas(self, s, what):
        if not self.in_going:
            self.err(s, f'{what} 只能写在 GOING 里')
        if self.in_draw is None:
            self.err(s, f'{what} 必须写在 web.draw.始 和 web.draw.终 之间')

    def gen_frame(self, s: HmFrame):
        """web.帧：把帧体的绘图语句收集成 JS 片段计划。

        参数表达式照常在当下求值（C 临时变量随语句位置发射），JS 文本
        存进计划，等 web.播放 时再包进 pybk_frames 数组统一发射。"""
        self.hm_used = True
        self._need_canvas(s, 'web.帧')
        for st in s.body:
            if isinstance(st, Call) and st.name == '绘':
                self.err(st, '绘 只能在窗口模式或 web.实时 里用（网页静态画布不支持精灵）')
            if not isinstance(st, HmDraw):
                self.err(st, 'web.帧 块里只能放 web.draw.* 绘图语句')
            if st.cmd in ('begin', 'end'):
                self.err(st, 'web.帧 里不能用 web.draw.始/终')
        plan = []
        self._frame_plan = plan
        for st in s.body:
            self.gen_draw(st)
        self._frame_plan = None
        self.hm_frames.append(plan)

    def gen_play(self, s: HmPlay):
        """web.播放(速度)：发射 pybk_frames 函数数组 + setInterval 循环。"""
        self.hm_used = True
        self._need_canvas(s, 'web.播放')
        if not self.hm_frames:
            self.err(s, 'web.播放 前必须至少有一个 web.帧')
        ctx = f'ctx{self.in_draw}'
        speed = self._draw_param(s.speed)
        self.play_n += 1
        sfx = '' if self.play_n == 1 else str(self.play_n)   # 多段播放时 JS 名去重
        fs, fi = f'pybk_frames{sfx}', f'pybk_frame{sfx}'
        self.raw(f'const {fs} = [\n')
        last = len(self.hm_frames) - 1
        for k, plan in enumerate(self.hm_frames):
            self.raw('function() {')
            for kind, x in plan:
                if kind == 'raw':
                    self.raw(x)
                else:
                    self.draw_val(x)
            self.raw('}' + (',\n' if k < last else '\n'))
        self.raw('];\n')
        self.raw(f'let {fi} = 0;\n')
        pw, ph = self._canvas_size.get(self.in_draw, (400, 300))
        self.raw('setInterval(function() {\n')
        self.raw(f'{ctx}.clearRect(0, 0, {pw}, {ph});\n')
        self.raw(f'{fs}[{fi} % {fs}.length]();\n')
        self.raw(f'{fi}++;\n')
        self.raw('}, 1000 / ')
        self.draw_val(speed)
        self.raw(');\n')
        self.hm_frames = []          # 已播放的帧清空：下一段播放只含其后的帧

    # ---- web.实时：浏览器里逐帧实时跑的块（PYbook→JavaScript 小编译器）----

    def gen_live(self, s: HmLive):
        """web.实时 { ... }：把块里的语句编译成 JS，写进当前画布的 <script>，
        setInterval 每秒 60 帧（或 web.实时(帧率)）循环执行。

        键盘：按键("left")=按住没放；按过("space")=这一帧刚按下（帧末清空）。
        变量：块里赋值过的名字成为 JS 变量；名字在 GOING 前文赋值过的，
        生成页面时把当时的值烤成初始值（数字）。"""
        self.hm_used = True
        if not self.page_begun:
            title = getattr(self, 'program_meta', '') or 'PYbook 页面'
            self.emit(f'rt_page_begin({cstr(title)});')
            self.page_begun = True
        self._need_canvas(s, 'web.实时')
        if self._frame_plan is not None:
            self.err(s, 'web.实时 不能写在 web.帧 里面')
        self.live_n += 1
        sfx = '' if self.live_n == 1 else str(self.live_n)
        self._live_sfx = sfx

        # 1) 收集块内赋值过的变量名（含嵌套），按首次出现顺序成为 JS 变量
        names = []

        def scan(sts):
            for st in sts:
                if isinstance(st, (VgAssign, AssignIndex)):
                    if st.name not in names:
                        names.append(st.name)
                elif isinstance(st, VcChain):
                    for _c, b in st.arms:
                        scan(b)
                elif isinstance(st, Around):
                    scan(st.body)

        scan(s.body)

        # 2) 键盘基建：keys=按住表，pressed=本帧刚按下集合（帧末清空）
        self.raw(f'const PYBK_KEYS{sfx} = {{}};\n')
        self.raw(f'const PYBK_PRESSED{sfx} = new Set();\n')
        self.raw(f'function PYBK_KEYMAP{sfx}(n) {{ var m = '
                 '{left:"ArrowLeft", right:"ArrowRight", up:"ArrowUp", down:"ArrowDown", '
                 'space:" ", enter:"Enter", esc:"Escape", '
                 '左:"ArrowLeft", 右:"ArrowRight", 上:"ArrowUp", 下:"ArrowDown", '
                 '空格:" ", 回车:"Enter"}; return m[n] !== undefined ? m[n] : n; }\n')
        self.raw(f'function PYBK_NUM{sfx}(v) {{ var n = parseFloat(v); '
                 f'if (!isNaN(n)) return n; '
                 f'try {{ var a = JSON.parse(v); if (Array.isArray(a)) return a; }} catch (e) {{}} '
                 f'return v; }}\n')
        self.raw(f'document.addEventListener("keydown", function(e) {{ '
                 f'if (!PYBK_KEYS{sfx}[e.key]) PYBK_PRESSED{sfx}.add(e.key); '
                 f'PYBK_KEYS{sfx}[e.key] = true; '
                 f'if (e.key.indexOf("Arrow") === 0 || e.key === " ") e.preventDefault(); }});\n')
        self.raw(f'document.addEventListener("keyup", function(e) {{ '
                 f'PYBK_KEYS{sfx}[e.key] = false; }});\n')
        # 鼠标：位置/按下/抬起（逻辑坐标按画布尺寸换算）
        mw, mh = self._canvas_size.get(self.in_draw, (400, 300))
        self.raw(('(function(){ var cv = document.getElementById("pybook-canvas-' + str(self.in_draw) + '");'
                 ' function hw_mm(e){ var r = cv.getBoundingClientRect();'
                 f' window.__pybkMX = (e.clientX - r.left) * {mw} / r.width;'
                 f' window.__pybkMY = (e.clientY - r.top) * {mh} / r.height; }}'
                 ' cv.addEventListener("mousemove", hw_mm);'
                 ' cv.addEventListener("mousedown", function(e){ hw_mm(e);'
                 ' window.__pybkMD = true; window.__pybkMH = true; window.__pybkCLICK = true; });'
                 ' document.addEventListener("mouseup", function(){ window.__pybkMD = false; });'
                 '})();\n'))
        # UI 控件运行时（按钮/输入框/滑条），CTXNAME 替换为本块 ctx 名
        self.raw(_UI_RUNTIME.replace('CTXNAME', 'ctx' + str(self.in_draw)))
        self.raw(f'window.__pybkBTN{sfx} = {{}};' + chr(10));        self.raw(f'window.__pybkTB{sfx} = {{}};' + chr(10));        self.raw(f'function PYBK_STR{sfx}(v) {{ return (typeof v === "object") ? JSON.stringify(v) : String(v); }}' + chr(10));        self.raw(f'function PYBK_STRLEN{sfx}(v) {{ var sv = (typeof v === "object") ? JSON.stringify(v) : String(v); var n2 = 0; for (var _i = 0; _i < sv.length; _i++) {{ n2 += (sv.charCodeAt(_i) & 0xF800) === 0xD800 ? 0 : 1; }} return n2; }}' + chr(10));        self.raw(f'setInterval(function() {{ var ins = document.querySelectorAll("[id^=pybk_tb_]"); for (var i2 = 0; i2 < ins.length; i2++) {{ window.__pybkTB{sfx}[ins[i2].id.replace("pybk_tb_", "")] = ins[i2].value; }} }}, 100);' + chr(10));
        # 2.5) 图片资源预加载：实时块里 web.draw.图/图缩 用到的路径先建 Image
        imgs = []

        def scan_img(sts):
            for st in sts:
                if isinstance(st, HmDraw) and st.cmd in ('img_draw', 'img_scaled'):
                    pth = st.params[-1]
                    if not isinstance(pth, StrLit):
                        self.err(st, 'web.draw.图/图缩 的文件名必须是字符串字面量，'
                                     '如 web.draw.图(10, 10, "飞机.png")')
                    if pth.value not in imgs:
                        imgs.append(pth.value)
                elif isinstance(st, VcChain):
                    for _c, b in st.arms:
                        scan_img(b)
                elif isinstance(st, (Around, ForIn)):
                    scan_img(st.body)

        scan_img(s.body)
        self.raw(f'const PYBK_IMGS{sfx} = {{}};\n')
        for pth in imgs:
            self.raw(f'PYBK_IMGS{sfx}[{cstr(pth)}] = new Image(); '
                     f'PYBK_IMGS{sfx}[{cstr(pth)}].src = {cstr(pth)};\n')

        # 3) JS 变量声明：块内赋值过的 ∪ GOING 前文声明过的；后者的初始值
        #    用 PYBK_NUM("…") 包住运行时烤进来的文本——数字转数，其余原样
        js_names = list(names)
        for name in self.vmap:
            if name in self.declared and name not in js_names:
                js_names.append(name)
        self._live_declared = set(js_names)
        for name in js_names:
            if name in self.vmap and name in self.declared:
                t = self.newtemp('_lv')
                self.emit(f'Value {t} = rt_chk({self.vname(name)});')
                self.raw(f'let V_{name} = PYBK_NUM{sfx}("')
                self.emit(f'rt_page_text(rt_str_of({t}));')
                self.raw('");\n')
            else:
                self.raw(f'let V_{name} = 0;\n')

        # 4) 帧函数：块体逐句翻译，帧末清空"刚按下"集合
        self.raw(f'function PYBK_LIVE{sfx}() {{\n')
        lines = []
        lines.append(f'__pybkCLICK{sfx} = (window.__pybkCLICK{sfx} === true);')
        lines.append(f'window.__pybkCLICK{sfx} = false;')
        self._live_loop = 0
        for st in s.body:
            self.live_stmt(st, lines)
        lines.append(f'PYBK_PRESSED{sfx}.clear();')
        lines.append('window.__pybkMH = false;')
        for ln_js in lines:
            self.raw('  ' + ln_js + '\n')
        self.raw('}\n')

        # 5) 驱动：先跑一帧再定时循环（固定步长，和显示器刷新率无关）
        fps = 60 if s.fps is None else int(s.fps)
        self.raw(f'PYBK_LIVE{sfx}();\n')
        self.raw(f'setInterval(PYBK_LIVE{sfx}, 1000 / {fps});\n')
        self._live_sfx = None
        self._live_declared = set()

    def live_stmt(self, s, lines):
        if isinstance(s, Call) and s.name in ('add', 'remove'):
            s = Call({'add': '添加', 'remove': '删掉'}[s.name], s.args, s.line)
        if isinstance(s, Call) and s.name == '绘':
            self.live_sprites(s, lines)
            return
        if isinstance(s, VgAssign):
            if s.name not in self._live_declared:
                self.err(s, f'web.实时 里用的变量 {s.name} 没有赋值过（写在块里或 GOING 前文）')
            lines.append(f'V_{s.name} = {self.js_expr(s.expr)};')
        elif isinstance(s, AssignIndex):
            if s.name not in self._live_declared:
                self.err(s, f'web.实时 里用的变量 {s.name} 没有赋值过')
            lines.append(f'V_{s.name}[{self.js_expr(s.index)}] = {self.js_expr(s.expr)};')
        elif isinstance(s, Call):
            if s.name == '添加':
                if len(s.args) != 2 or not isinstance(s.args[0], VarRef):
                    self.err(s, '实时块里 添加 的写法：添加(列表名, 值)')
                if s.args[0].name not in self._live_declared:
                    self.err(s, f'web.实时 里用的变量 {s.args[0].name} 没有赋值过')
                lines.append(f'V_{s.args[0].name}.push({self.js_expr(s.args[1])});')
            elif s.name == '删掉':
                if len(s.args) != 2 or not isinstance(s.args[0], VarRef):
                    self.err(s, '实时块里 删掉 的写法：删掉(列表名, 元素)')
                if s.args[0].name not in self._live_declared:
                    self.err(s, f'web.实时 里用的变量 {s.args[0].name} 没有赋值过')
                lines.append(f'V_{s.args[0].name}.splice(V_{s.args[0].name}.indexOf({self.js_expr(s.args[1])}), 1);')
            else:
                lines.append(f'{self.js_expr(s)};')
        elif isinstance(s, AssignMember):
            base = self.js_expr(s.base)
            if s.base not in () and isinstance(s.base, VarRef)                     and s.base.name not in self._live_declared:
                self.err(s, f'web.实时 里用的变量 {s.base.name} 没有赋值过')
            lines.append(f'{base}[{self.js_expr(StrLit(s.attr, s.line))}] = {self.js_expr(s.expr)};')
        elif isinstance(s, VcChain):
            self.live_vc(s.arms, lines)
        elif isinstance(s, Around):
            varname = getattr(s, 'var', 'at')
            self._live_declared.add(varname)
            self._live_loop += 1
            lines.append(f'for (let V_{varname} = 0; V_{varname} < '
                         f'{self.js_expr(s.times)}; V_{varname}++) {{')
            for st in s.body:
                self.live_stmt(st, lines)
            self._live_loop -= 1
            lines.append('}')
        elif isinstance(s, ForIn):
            self._live_declared.add(s.var)
            self._live_loop += 1
            self._live_for_n = getattr(self, '_live_for_n', 0) + 1
            i_name = f'_i{self._live_for_n}'
            lines.append(f'for (let {i_name} = 0; {i_name} < {self.js_expr(s.iter)}.length; {i_name}++) {{')
            lines.append(f'const V_{s.var} = {self.js_expr(s.iter)}[{i_name}];')
            for st in s.body:
                self.live_stmt(st, lines)
            self._live_loop -= 1
            lines.append('}')
        elif isinstance(s, BreakStmt):
            if self._live_loop == 0:
                self.err(s, 'break 只能在实时块的 rm.around 里使用')
            lines.append('break;')
        elif isinstance(s, HmDraw):
            lines.extend(self.live_draw(s))
        elif isinstance(s, NsShow):
            if s.vc_cond is not None:
                self.err(s, 'web.实时 里 ns 的 vc:条件?(替代) 写法暂不支持')
            pieces = []
            for kind, val in s.parts:
                if kind == 'TEXT':
                    pieces.append(cstr(val))
                elif kind == 'EXPR':
                    pieces.append(self.js_expr(val))
                else:
                    if val not in self._live_declared:
                        self.err(s, f'web.实时 里用的变量 {val} 没有赋值过')
                    pieces.append('V_' + val)
            lines.append('console.log(' + (' + '.join(pieces) if pieces else '""') + ');')
        elif isinstance(s, HmStmt) and s.kind == 'set':
            i_e = self.js_expr(s.parts[0])
            v_e = self.js_expr(s.parts[1])
            lines.append(f'__pybkTB{self._live_sfx}[{i_e}] = ({v_e});')
            lines.append(f'(function(){{ var el = document.getElementById("pybk_tb_" + {i_e}); if (el) el.value = ({v_e}); }})();')
        elif isinstance(s, Aging):
            self.err(s, 'web.实时 块里不用 rm.aging——块本身就是循环，块里的语句每帧跑一遍')
        elif isinstance(s, (HmFrame, HmPlay, GoStmt)):
            self.err(s, 'web.实时 块里不能用 web.帧/播放/go')
        elif isinstance(s, IpAssign):
            self.err(s, 'web.实时 里不能用 ip（页面生成完才在浏览器里跑，收不了输入）')
        else:
            self.err(s, f'web.实时 里暂时不支持这类语句（{type(s).__name__}）')

    def live_vc(self, arms, lines):
        cond, body = arms[0]
        rest = arms[1:]
        if cond is None:               # 结尾的 else 缺省分支
            for st in body:
                self.live_stmt(st, lines)
            return
        lines.append(f'if ({self.js_expr(cond)}) {{')
        for st in body:
            self.live_stmt(st, lines)
        if not rest:
            lines.append('}')
            return
        lines.append('} else {')
        self.live_vc(rest, lines)
        lines.append('}')

    def _js_ctx(self):
        return f'ctx{self.in_draw}'

    def _interp_concat(self, sp):
        """StrParts → (前置语句, C 表达式)：rt_str / rt_str_of 的 rt_add 链。
        $变量、$表达式（EXPR 部件）都支持。"""
        stmts = []
        acc = None
        for kind, val in sp.parts:
            if kind == 'TEXT':
                c = f'rt_str({cstr(val)})'
            elif kind == 'EXPR':
                s2, c2 = self.expr(val)
                stmts += s2
                c2 = self.materialize(stmts, c2)
                c = f'rt_str(rt_str_of({c2}))'
            else:
                seg = val.split('.')
                if len(seg) == 1 and seg[0] in ('frame', 'sec') and seg[0] not in self.declared:
                    值 = f'rt_frames()' if seg[0] == 'frame' else f'rt_secs()'
                    c = f'rt_str(rt_str_of({值}))'
                    acc = c if acc is None else f'rt_add({acc}, {c})'
                    continue
                if seg[0] not in self.declared:
                    self.err(sp, f'插值用的变量 {seg[0]} 没有赋值过'
                                 f'（规则：先 vg.{seg[0]} = 值 再 "$…{seg[0]}…"；'
                                 f'插值里可写 $(表达式) 但字符串里不能再嵌引号）')
                c = f'rt_chk({self.vname(seg[0])})'
                for attr in seg[1:]:
                    c = f'rt_obj_get_prop({c}, {cstr(attr)})'
                c = f'rt_str(rt_str_of({c}))'
            acc = c if acc is None else f'rt_add({acc}, {c})'
        return stmts, (acc or 'rt_str("")')

    _JS_MATH1 = {'mt.sqrt': 'Math.sqrt', 'mt.abs': 'Math.abs', 'mt.ceil': 'Math.ceil',
                 'mt.floor': 'Math.floor', 'mt.sin': 'Math.sin', 'mt.cos': 'Math.cos',
                 'mt.tan': 'Math.tan'}

    def js_expr(self, e):
        if isinstance(e, NumLit):
            return repr(e.value)
        if isinstance(e, StrLit):
            return cstr(e.value)
        if isinstance(e, Call) and e.name == '空' and not e.args:
            return 'null'
        if isinstance(e, BoolLit):
            return 'true' if e.value else 'false'
        if isinstance(e, VarRef):
            if e.name not in self._live_declared:
                self.err(e, f'web.实时 里用的变量 {e.name} 没有赋值过（写在块里或 GOING 前文）')
            return 'V_' + e.name
        if isinstance(e, Unary):
            if e.op == '-':
                return '(-' + self.js_expr(e.operand) + ')'
            if e.op == 'not':
                return '!(' + self.js_expr(e.operand) + ')'
            self.err(e, f"不支持的一元运算符 '{e.op}'")
        if isinstance(e, BinOp):
            if e.op == 'and':
                return f'({self.js_expr(e.left)} && {self.js_expr(e.right)})'
            if e.op == 'or':
                return f'({self.js_expr(e.left)} || {self.js_expr(e.right)})'
            if e.op == '//':
                return f'Math.floor(({self.js_expr(e.left)}) / ({self.js_expr(e.right)}))'
            if e.op in ('+', '-', '*', '/', '%', '==', '!=', '<', '>', '<=', '>='):
                return f'({self.js_expr(e.left)} {e.op} {self.js_expr(e.right)})'
            self.err(e, f"web.实时 里不支持的运算符 '{e.op}'")
        if isinstance(e, ListLit):
            return '[' + ', '.join(self.js_expr(it) for it in e.items) + ']'
        if isinstance(e, Index):
            return f'({self.js_expr(e.base)})[{self.js_expr(e.index)}]'
        if isinstance(e, StrParts):
            out = []
            for kind, val in e.parts:
                if kind == 'TEXT':
                    out.append(cstr(val))
                elif kind == 'EXPR':
                    out.append('(' + self.js_expr(val) + ')')
                else:
                    if val.split('.')[0] not in self._live_declared:
                        self.err(e, f'插值用的变量 {val} 没有赋值过')
                    out.append('V_' + val)
            return '(' + ' + '.join(out) + ')'
        if isinstance(e, Member):
            return f'({self.js_expr(e.base)})[{self.js_expr(StrLit(e.attr, e.line))}]'
        if isinstance(e, CtorExpr):
            cd = self.classes.get(e.class_name)
            if cd is None:
                self.err(e, f"未定义的类 '{e.class_name}'")
            kw = dict(e.kwargs)
            fields = []
            for pname, default in cd.props:
                vex = kw.pop(pname) if pname in kw else default
                if vex is None:
                    fields.append(f'{self.js_expr(StrLit(pname, e.line))}: 0')
                else:
                    fields.append(f'{self.js_expr(StrLit(pname, e.line))}: {self.js_expr(vex)}')
            for pname, vex in kw.items():
                fields.append(f'{self.js_expr(StrLit(pname, e.line))}: {self.js_expr(vex)}')
            return '{' + ', '.join(fields) + '}'
        if isinstance(e, MethodCall):
            self.err(e, 'web.实时 里暂时不支持方法调用（对象属性读写可以用）')
        if isinstance(e, Call):
            name = {'add': '添加', 'remove': '删掉', 'len': '长度', 'touch': '碰到',
                    'key': '按键', 'hit': '按过'}.get(e.name, e.name)
            args = e.args
            if name in ('按键', '按过'):
                if len(args) != 1:
                    self.err(e, f'{name} 需要 1 个参数，如 {name}("left")')
                k = self.js_expr(args[0])
                if name == '按键':
                    return f'(PYBK_KEYS{self._live_sfx}[PYBK_KEYMAP{self._live_sfx}({k})] === true)'
                return f'PYBK_PRESSED{self._live_sfx}.has(PYBK_KEYMAP{self._live_sfx}({k}))'
            if name == '长度':
                if len(args) != 1:
                    self.err(e, '长度 需要 1 个参数')
                return f'({self.js_expr(args[0])}).length'
            if name in ('圆', 'circle'):
                if len(args) != 3:
                    self.err(e, '圆 需要 3 个参数：圆(x, y, r)')
                cx = self._js_ctx()
                return (f'(function(x, y, r) {{ for (let dy = -r; dy <= r; dy++) {{ '
                        f'const w = Math.floor(Math.sqrt(r * r - dy * dy)); '
                        f'{cx}.fillRect(x - w, y + dy, w * 2, 1); }} }})'
                        f'({self.js_expr(args[0])}, {self.js_expr(args[1])}, {self.js_expr(args[2])})')
            if name == 'mx':
                return '(window.__pybkMX || 0)'
            if name == 'my':
                return '(window.__pybkMY || 0)'

            if name == 'mdown':
                return 'window.__pybkMD ? 1 : 0'
            if name == 'mhit':
                return '(window.__pybkMH ? 1 : 0)'
            if name == 'ui.按钮':
                if len(args) != 5:
                    self.err(e, 'ui.按钮 需要 5 个参数：ui.按钮(x, y, 宽, 高, 文本)')
                return ('__pybkUI_BTN(' + self._js_ctx() + ', ' + self.js_expr(args[0]) + ', ' + self.js_expr(args[1]) + ', ' + self.js_expr(args[2]) + ', ' + self.js_expr(args[3]) + ', ' + self.js_expr(args[4]) + ')')
            if name == 'ui.输入框':
                if len(args) != 5:
                    self.err(e, 'ui.输入框 需要 5 个参数：ui.输入框(编号, x, y, 宽, 高)')
                return ('__pybkUI_INP(' + self._js_ctx() + ', ' + self.js_expr(args[0]) + ', ' + self.js_expr(args[1]) + ', ' + self.js_expr(args[2]) + ', ' + self.js_expr(args[3]) + ', ' + self.js_expr(args[4]) + ')')
            if name == 'ui.滑条':
                if len(args) != 6:
                    self.err(e, 'ui.滑条 需要 6 个参数：ui.滑条(编号, x, y, 宽, 最小, 最大)')
                return ('__pybkUI_SLD(' + self._js_ctx() + ', ' + self.js_expr(args[0]) + ', ' + self.js_expr(args[1]) + ', ' + self.js_expr(args[2]) + ', ' + self.js_expr(args[3]) + ', ' + self.js_expr(args[4]) + ', ' + self.js_expr(args[5]) + ', (' + self.js_expr(args[4]) + ' + ' + self.js_expr(args[5]) + ') / 2)')
            if name in ('音.正弦', '音.三角'):
                if len(args) != 2:
                    self.err(e, f'{name} 需要 2 个参数：{name}(频率, 毫秒)')
                typ = 'sine' if name == '音.正弦' else 'triangle'
                return (f'(function(f, ms) {{ const ac = window.__pybkAC || '
                        f'(window.__pybkAC = new (window.AudioContext || window.webkitAudioContext)()); '
                        f'const o = ac.createOscillator(), g = ac.createGain(); '
                        f'o.type = \"{typ}\"; o.frequency.value = f; g.gain.value = 0.2; '
                        f'o.connect(g); g.connect(ac.destination); '
                        f'o.start(); o.stop(ac.currentTime + ms / 1000); }})'
                        f'({self.js_expr(args[0])}, {self.js_expr(args[1])})')
            if name == '线':
                if len(args) != 4:
                    self.err(e, '线 需要 4 个参数：线(x1, y1, x2, y2)')
                return (f'(function(x1, y1, x2, y2) {{ {self._js_ctx()}.beginPath(); '
                        f'{self._js_ctx()}.moveTo(x1, y1); {self._js_ctx()}.lineTo(x2, y2); '
                        f'{self._js_ctx()}.stroke(); }})'
                        f'({self.js_expr(args[0])}, {self.js_expr(args[1])}, '
                        f'{self.js_expr(args[2])}, {self.js_expr(args[3])})')
            if name == '点':
                if len(args) != 2:
                    self.err(e, '点 需要 2 个参数：点(x, y)')
                return (f'(function(x, y) {{ {self._js_ctx()}.fillRect(x - 2, y - 2, 4, 4); }})'
                        f'({self.js_expr(args[0])}, {self.js_expr(args[1])})')
            if name == '音.放':
                if len(args) != 1:
                    self.err(e, '音.放 需要 1 个参数：音.放(\"文件.mp3\")')
                return (f'(function(p) {{ const a = new Audio(p); '
                        f'window.__pybkAudio = a; a.play(); }})({self.js_expr(args[0])})')
            if name == '音.停':
                if args:
                    self.err(e, '音.停 不带参数')
                return '(function() { if (window.__pybkAudio) window.__pybkAudio.pause(); })()'
            if name == '音.音':
                if len(args) != 3:
                    self.err(e, '音.音 需要 3 个参数：音.音(名, 频率, 波形)')
                return ('(function(n,f,w){(window.__pybkNotes||(window.__pybkNotes={}))[n]={f:f,w:w};})'
                        '(' + self.js_expr(args[0]) + ',' + self.js_expr(args[1]) + ',' + self.js_expr(args[2]) + ')')
            if name in ('音.谱', '音.奏'):
                if name == '音.谱' and len(args) != 2:
                    self.err(e, '音.谱 需要 2 个参数：音.谱(表, 速度)')
                if name == '音.奏' and len(args) != 3:
                    self.err(e, '音.奏 需要 3 个参数：音.奏(表, 文件名, 速度)')
                L = self.js_expr(args[0])
                if name == '音.奏':
                    bpm = self.js_expr(args[2])
                    fn = self.js_expr(args[1])
                else:
                    bpm = self.js_expr(args[1])
                    fn = '""'
                js = ('(function(L,bpm,fn){'
                      'const AC=window.__pybkAC||(window.__pybkAC=new (window.AudioContext||window.webkitAudioContext)());'
                      'const spb=60/(bpm||120);'
                      'const midi=function(s){const m={"C":0,"D":2,"E":4,"F":5,"G":7,"A":9,"B":11};'
                      'let i=0,c=s[i++];if(!(c in m))return null;let v=m[c];'
                      'if(s[i]==="#"){v++;i++;}else if(s[i]==="b"){v--;i++;}'
                      'let o=parseInt(s.slice(i));if(isNaN(o))return null;return (o+1)*12+v;};'
                      'const N=window.__pybkNotes||{};'
                      'for(const row of (L||[])){let ct=AC.currentTime+0.06;'
                      'const toks=String(row).trim().split(/\\s+/).filter(Boolean);'
                      'for(const raw of toks){let parts=raw.split(":");let tok=parts[0];'
                      'let dur=(parts[1]?parseFloat(parts[1]):1)*spb;'
                      'if(tok==="."||tok==="_"||tok==="r"){ct+=dur;continue;}'
                      'let fr=null,w=0;if(N[tok]){fr=N[tok].f;w=N[tok].w;}'
                      'else{const mm=midi(tok);if(mm!=null)fr=440*Math.pow(2,(mm-69)/12);}'
                      'if(fr){const o=AC.createOscillator(),g=AC.createGain();'
                      'o.type=(w===1?"triangle":(w===2?"sawtooth":"sine"));'
                      'o.frequency.value=fr;g.gain.value=0.16;o.connect(g);g.connect(AC.destination);'
                      'o.start(ct);o.stop(ct+dur*0.95);}ct+=dur;}}return fn;})(')
                return js + L + ',' + bpm + ',' + fn + ')'
            if name == '碰到':
                if len(args) != 2:
                    self.err(e, '碰到 需要 2 个参数：碰到(a, b)')
                return (f'(function(a, b) {{ return Math.abs(a.x - b.x) * 2 < a.宽 + b.宽 '
                        f'&& Math.abs(a.y - b.y) * 2 < a.高 + b.高; }})'
                        f'({self.js_expr(args[0])}, {self.js_expr(args[1])})')
            if name == 'mt.pi':
                if args:
                    self.err(e, 'mt.pi 不带参数')
                return 'Math.PI'
            if name == 'mt.pow':
                if len(args) != 2:
                    self.err(e, 'mt.pow 需要 2 个参数')
                return f'Math.pow({self.js_expr(args[0])}, {self.js_expr(args[1])})'
            if name == 'mt.mod':
                if len(args) != 2:
                    self.err(e, 'mt.mod 需要 2 个参数')
                return f'(({self.js_expr(args[0])}) % ({self.js_expr(args[1])}))'
            if name in ('mt.max', 'mt.min'):
                if len(args) != 1:
                    self.err(e, f'{name} 需要 1 个参数（列表）')
                fn = 'Math.max' if name == 'mt.max' else 'Math.min'
                return f'{fn}(...({self.js_expr(args[0])}))'
            if name == 'mt.prod':
                if len(args) != 1:
                    self.err(e, 'mt.prod 需要 1 个参数（列表）')
                return f'({self.js_expr(args[0])}).reduce(function(a, b) {{ return a * b; }}, 1)'
            if name in self._JS_MATH1:
                if len(args) != 1:
                    self.err(e, f'{name} 需要 1 个参数')
                return f'{self._JS_MATH1[name]}({self.js_expr(args[0])})'
            if name == 'rd.int':
                if len(args) != 2:
                    self.err(e, 'rd.int 需要 2 个参数')
                a, b = self.js_expr(args[0]), self.js_expr(args[1])
                return f'(({a}) + Math.floor(Math.random() * (({b}) - ({a}) + 1)))'
            if name == 'rd.float':
                if args:
                    self.err(e, 'rd.float 不带参数')
                return 'Math.random()'
            if name == 'rd.pick':
                if len(args) != 1:
                    self.err(e, 'rd.pick 需要 1 个参数（列表）')
                return (f'(function(L) {{ return L[Math.floor(Math.random() * L.length)]; }})'
                        f'({self.js_expr(args[0])})')
            if name == 'web.click':
                return f'__pybkCLICK{self._live_sfx}'
            if name == 'web.mx':
                return f'(__pybkMX{self._live_sfx} || 0)'
            if name == 'web.my':
                return f'(__pybkMY{self._live_sfx} || 0)'
            if name == 'web.text':
                if len(e.args) != 1:
                    self.err(e, 'web.text(id) 需要 1 个参数')
                return f'(__pybkTB[{self.js_expr(e.args[0])}] || "")'
            if name == 'web.存':
                if len(e.args) != 2:
                    self.err(e, 'web.存(键, 缺省值) 需要 2 个参数')
                k = self.js_expr(e.args[0])
                d = self.js_expr(e.args[1])
                return (f'(function(){{ try {{ var v = localStorage.getItem({k});'
                        f' return v === null ? ({d}) : PYBK_NUM{self._live_sfx}(v); }}'
                        f' catch (err) {{ return ({d}); }} }})())')
            if name == 'web.down':
                if len(e.args) != 1:
                    self.err(e, 'web.down(id) 需要 1 个参数')
                return f'(__pybkBTN[{self.js_expr(e.args[0])}] || 0)'
            if name in GAME_CALLS:
                self.err(e, f'web.实时 里不能用游戏函数 {name}(...)（那是窗口模式的零件，网页里用 按键/按过）')
            if name == 'te.str':
                if len(e.args) != 1:
                    self.err(e, 'te.str 需要 1 个参数')
                return f'PYBK_STR({self.js_expr(e.args[0])})'
            if name == 'te.len':
                if len(e.args) != 1:
                    self.err(e, 'te.len 需要 1 个参数')
                return f'PYBK_STRLEN({self.js_expr(e.args[0])})'
            if name == 'mt.floor':
                if len(e.args) != 1:
                    self.err(e, 'mt.floor 需要 1 个参数')
                return f'Math.floor({self.js_expr(e.args[0])})'
            if name == 'mt.round':
                if len(e.args) != 1:
                    self.err(e, 'mt.round 需要 1 个参数')
                return f'Math.round({self.js_expr(e.args[0])})'
            if name in LIB_CALLS:
                self.err(e, f'web.实时 里暂时不支持 {name}(...)（网页实时模式只带 list/mt/rd/te.str 的一部分）')
            self.err(e, f"web.实时 里不知道 '{name}' 是什么（自定义函数暂不能在实时块里调用）")
        self.err(e, f'web.实时 里不支持的表达式：{type(e).__name__}')

    def live_sprites(self, s, lines):
        """绘(列表) 的网页实时实现：JS 遍历列表，逐精灵懒加载图片并 drawImage。

        元素缺 x/y/宽/高/图 任一属性 → throw（带是第几个元素）；
        图片走 PYBK_IMGS 缓存懒加载：运行时发现新路径就建 Image，
        第一帧没加载完（complete=false）就跳过，下一帧自然补上。"""
        if len(s.args) != 1 or not isinstance(s.args[0], VarRef):
            self.err(s, '绘 的写法：绘(列表名)')
        if s.args[0].name not in self._live_declared:
            self.err(s, f'web.实时 里用的变量 {s.args[0].name} 没有赋值过')
        im = f'PYBK_IMGS{self._live_sfx}'
        ctx = self._js_ctx()
        lines += [
            '(function () {',
            f'  var _l = V_{s.args[0].name};',
            '  var _need = ["x", "y", "宽", "高", "图"];',
            '  for (var _i = 0; _i < _l.length; _i++) {',
            '    var _e = _l[_i];',
            '    for (var _k = 0; _k < _need.length; _k++) {',
            '      if (!(_need[_k] in _e)) { throw "绘：第 " + (_i + 1) + " 个元素缺少属性 " + _need[_k]; }',
            '    }',
            '    var _pth = _e["图"];',
            f'    var _im = {im}[_pth];',
            f'    if (_im === undefined) {{ _im = new Image(); _im.src = _pth; {im}[_pth] = _im; }}',
            '    if (_im.complete && _im.naturalWidth > 0) {',
            f'      {ctx}.drawImage(_im, _e["x"] - _e["宽"] / 2, _e["y"] - _e["高"] / 2,',
            '                      _e["宽"], _e["高"]);',
            '    }',
            '  }',
            '})();',
        ]

    def live_draw(self, s):
        """web.draw.* 在实时块里：参数是 JS 表达式（不烤值），每帧重新求值。"""
        ctx = f'ctx{self.in_draw}'
        if s.cmd in ('begin', 'end'):
            self.err(s, 'web.实时 里不能用 web.draw.始/终')
        p = [self.js_expr(x) for x in s.params]
        out = []
        if s.cmd == 'color':
            out.append(f"{ctx}.fillStyle = 'rgb(' + ({p[0]}) + ',' + ({p[1]}) + ',' + ({p[2]}) + ')';")
            out.append(f"{ctx}.strokeStyle = {ctx}.fillStyle;")
        elif s.cmd == 'clear':
            out.append(f"{ctx}.fillStyle = 'rgb(' + ({p[0]}) + ',' + ({p[1]}) + ',' + ({p[2]}) + ')';")
            lcw, lch = self._canvas_size.get(self.in_draw, (400, 300))
            out.append(f'{ctx}.fillRect(0, 0, {lcw}, {lch});')
        elif s.cmd == 'circle':
            out.append(f'{ctx}.beginPath();')
            out.append(f'{ctx}.arc({p[0]}, {p[1]}, {p[2]}, 0, Math.PI * 2);')
            out.append(f'{ctx}.fill();')
        elif s.cmd == 'rect':
            out.append(f'{ctx}.fillRect({p[0]}, {p[1]}, {p[2]}, {p[3]});')
        elif s.cmd == 'line':
            out.append(f'{ctx}.beginPath();')
            out.append(f'{ctx}.moveTo({p[0]}, {p[1]});')
            out.append(f'{ctx}.lineTo({p[2]}, {p[3]});')
            out.append(f'{ctx}.stroke();')
        elif s.cmd == 'text':
            out.append(ctx + '.font = (' + p[3] + ') + "px \'Microsoft YaHei UI\', sans-serif";')
            out.append(f'{ctx}.fillText(({p[2]}), ({p[0]}), ({p[1]}));')
        elif s.cmd == 'img_draw':
            im = f'PYBK_IMGS{self._live_sfx}[{p[2]}]'
            out.append(f'var _pim = {im};')
            out.append(f'if (_pim.complete && _pim.naturalWidth > 0) '
                       f'{ctx}.drawImage(_pim, ({p[0]}), ({p[1]}));')
        elif s.cmd == 'img_scaled':
            im = f'PYBK_IMGS{self._live_sfx}[{p[4]}]'
            out.append(f'var _pim = {im};')
            out.append(f'if (_pim.complete && _pim.naturalWidth > 0) '
                       f'{ctx}.drawImage(_pim, ({p[0]}), ({p[1]}), ({p[2]}), ({p[3]}));')
        else:
            self.err(s, f'未知的画布命令 {s.cmd}')
        return out

    _GO_MOVE = {'右': ('X', ''), 'left': ('X', '-'), '左': ('X', '-'),
                'right': ('X', ''), '上': ('Y', '-'), 'up': ('Y', '-'),
                '下': ('Y', '+'), 'down': ('Y', '+')}

    def gen_go(self, s: GoStmt):
        """go(方向, 距离, 速度)：CSS transition + translate 平移整个画布。"""
        self.hm_used = True
        self._need_canvas(s, 'go')
        dist = self._draw_param(s.distance)
        speed = self._draw_param(s.speed)
        self.go_n += 1
        cv = 'pybk_canvas' if self.go_n == 1 else f'pybk_canvas{self.go_n}'
        axis, sign = self._GO_MOVE[s.direction]
        self.raw(f"const {cv} = document.getElementById('pybook-canvas-{self.in_draw}');\n")
        self.raw(f"{cv}.style.transition = 'transform ")
        self.draw_val(speed)
        self.raw("s';\n")
        self.raw(f"{cv}.style.transform = 'translate{axis}({sign}")
        self.draw_val(dist)
        self.raw("px)';\n")

    # ---- Godot 级热点优化：rm.around 标量化 ----
    # 分析循环体里"只做数值算术"的变量，整圈用 C 原生标量 S_x 携带，
    # 出口装回盒子；任何不支持的形态整圈回退 gen_around 老路径。

    def _pk_subst(self, e, lv, cands, kinds):
        """值域替换：候选读 → PK_BOX，循环变量读 → PK_LOOP_I。"""
        import copy
        def walk(x):
            if isinstance(x, VarRef):
                if x.name in cands:
                    k = kinds.get(x.name, 'i')
                    return Call('PK_BOX_' + k.upper(), [StrLit(x.name, x.line)], x.line)
                if x.name == lv:
                    return Call('PK_LOOP_I', [StrLit('i', x.line)], x.line)
                return x
            if isinstance(x, BinOp):
                x.left = walk(x.left)
                x.right = walk(x.right)
                return x
            if isinstance(x, Unary):
                x.operand = walk(x.operand)
                return x
            if isinstance(x, Index):
                x.base = walk(x.base)
                x.index = walk(x.index)
                return x
            if isinstance(x, Call):
                x.args = [walk(a) for a in x.args]
                return x
            if isinstance(x, ListLit):
                x.items = [walk(it) for it in x.items]
                return x
            if isinstance(x, VgAssign):
                x.expr = walk(x.expr)
                return x
            if isinstance(x, AssignIndex):
                x.expr = walk(x.expr)
                x.index = walk(x.index)
                return x
            if isinstance(x, VcChain):
                x.arms = [(walk(c) if c is not None else None, [walk(y) for y in b])
                          for c, b in x.arms]
                return x
            if isinstance(x, Around):
                x.times = walk(x.times) if getattr(x, 'times', None) is not None else x.times
                x.body = [walk(y) for y in x.body]
                return x
            if isinstance(x, NsShow):
                x.parts = [(k2, walk(v2) if k2 == 'EXPR' else v2) for k2, v2 in x.parts]
                return x
            if isinstance(x, TestCheck):
                x.cond = walk(x.cond)
                return x
            if isinstance(x, StrParts):
                newp = []
                for kind, val in x.parts:
                    if kind == 'VAR' and val in cands:
                        k = kinds.get(val, 'i')
                        newp.append(('EXPR', Call('PK_BOX_' + k.upper(), [StrLit(val, x.line)], x.line)))
                    elif kind == 'EXPR':
                        newp.append((kind, walk(val)))
                    else:
                        newp.append((kind, val))
                x.parts = newp
                return x
            return x
        return walk(copy.deepcopy(e))

    def _pk_static_kind(self, e, lv, cands, kinds, disq):
        """静态数值域：'i' | 'f'；不支持的形态抛 _PkAbort。"""
        if isinstance(e, NumLit):
            return 'f' if isinstance(e.value, float) else 'i'
        if isinstance(e, BoolLit):
            return 'i'
        if isinstance(e, VarRef):
            if e.name == lv:
                return 'i'
            if e.name in cands:
                return kinds.get(e.name, 'i')
            return 'i'                          # 普通读：整数取（列表/浮点会在运行时报"需要整数"）
        if isinstance(e, Unary) and e.op == '-':
            return self._pk_static_kind(e.operand, lv, cands, kinds, disq)
        if isinstance(e, BinOp):
            lk = self._pk_static_kind(e.left, lv, cands, kinds, disq)
            rk = self._pk_static_kind(e.right, lv, cands, kinds, disq)
            if e.op == '/':
                return 'f'
            if e.op in ('%', '//') and 'f' in (lk, rk):
                self._pk_abort('浮点取模')
            if lk == 'f' or rk == 'f':
                if e.op in ('+', '-', '*'):
                    return 'f'
            return 'i' if e.op in ('%', '//') else ('f' if 'f' in (lk, rk) else 'i')
        if isinstance(e, Index):
            if isinstance(e.base, VarRef):
                disq.add(e.base.name)           # 下标读到的元素按整数取
            return 'i'
        if isinstance(e, Call) and e.name == '长度':
            if isinstance(e.args[0], VarRef):
                disq.add(e.args[0].name)        # 传给 长度 的是列表
            return 'i'
        self._pk_abort('表达式含不支持形态 ' + type(e).__name__)
        return 'i'

    def _pk_walk_expr_only(self, e, lv, cands, kinds, disq):
        if e is None:
            return
        self._pk_static_kind(e, lv, cands, kinds, disq)

    def _pk_walk_stmts(self, sts, lv, cands, kinds, disq, assigned):
        for st in sts:
            if isinstance(st, VgAssign):
                if st.name == lv:
                    self._pk_abort('循环变量被赋值')
                assigned.add(st.name)
                if isinstance(st.expr, Index) and isinstance(st.expr.base, VarRef):
                    disq.add(st.expr.base.name)
                k = self._pk_static_kind(st.expr, lv, cands, kinds, disq)
                if st.name in kinds and kinds[st.name] != k:
                    disq.add(st.name)
                elif st.name not in kinds:
                    kinds[st.name] = k
            elif isinstance(st, AssignIndex):
                disq.add(st.name)               # 写列表的变量不是标量候选
                self._pk_walk_expr_only(st.expr, lv, cands, kinds, disq)
                self._pk_walk_expr_only(st.index, lv, cands, kinds, disq)
            elif isinstance(st, VcChain):
                for cond, body in st.arms:
                    if cond is not None:
                        self._pk_walk_expr_only(cond, lv, cands, kinds, disq)
                    self._pk_walk_stmts(body, lv, cands, kinds, disq, assigned)
            elif isinstance(st, Around):
                self._pk_walk_expr_only(getattr(st, 'times', None), lv, cands, kinds, disq)
                self._pk_walk_stmts(st.body, getattr(st, 'var', 'at'), set(), {}, set(), set())
            elif isinstance(st, NsShow):
                for kind, val in st.parts:
                    if kind == 'EXPR':
                        self._pk_walk_expr_only(val, lv, cands, kinds, disq)
            elif isinstance(st, TestCheck):
                self._pk_walk_expr_only(st.cond, lv, cands, kinds, disq)
            elif isinstance(st, (BreakStmt, Call)):
                if isinstance(st, Call):
                    for a in st.args:
                        self._pk_walk_expr_only(a, lv, cands, kinds, disq)
            else:
                self._pk_abort('语句 ' + type(st).__name__)

    def _pk_abort(self, why):
        raise _PkAbort(why)

    def try_scalar_around(self, s: Around):
        """成功：发出标量化循环并返回 True；任何不支持：返回 False 走老路径。"""
        try:
            return self._pk_emit(s)
        except _PkAbort:
            return False

    def _pk_emit(self, s: Around):
        import copy
        lv = getattr(s, 'var', 'at')
        cands = set()
        kinds = {}
        disq = set()
        assigned = set()
        self._pk_walk_stmts(s.body, lv, cands, kinds, disq, assigned)
        # 只有"进入本圈之前真正被赋过值"的变量才能标量化：标量化会在 for 之前
        # 先读一次旧值（rt_to_ll(v_x)）把盒装值收进局部标量。若某变量只在
        # 本圈循环体内首次赋值，它此刻还是 rt_none()，读它必然抛"需要整数"。
        # 注意不能用 self.declared —— emit_locals 预扫描把全函数变量都加进去了。
        cands = {x for x in assigned - disq
                 if x != lv and x in self._已赋值}
        if not cands:
            return False                        # 没有可标量化变量：老路径更省事
        kinds = {k: v for k, v in kinds.items() if k in cands}
        body = [self._pk_subst(x, lv, cands, kinds) for x in copy.deepcopy(s.body)]
        st0, cv0 = self.expr(s.times)
        for x in st0:
            self.emit(x)
        tv = self.newtemp()
        nv = self.newtemp('_n')
        iv = self.newtemp('_i')
        self._pk_iv = iv
        self._pk_lv = lv
        self.emit(f'Value {tv} = {cv0};')
        self.emit(f'long long {nv} = rt_loop_count({tv});')
        for name in sorted(cands):
            vn = self.vname(name)
            if kinds.get(name, 'i') == 'f':
                self.emit(f'double S_{vn} = (IS_FLT({vn}) ? AS_FLT({vn}) : (double)rt_to_ll({vn}));')
            else:
                self.emit(f'long long S_{vn} = rt_to_ll({vn});')
        self.emit(f'for (long long {iv} = 0; {iv} < {nv}; {iv}++) {{')
        self.depth += 1
        self.loop_depth += 1
        self._pk_live = (cands, kinds)
        for st in body:
            self._pk_stmt(st)
        self.loop_depth -= 1
        self.depth -= 1
        self.emit('}')
        for name in sorted(cands):
            vn = self.vname(name)
            box = f'rt_float(S_{vn})' if kinds.get(name, 'i') == 'f' else f'rt_int(S_{vn})'
            self.emit(f'rt_assign(&{vn}, {box});')
        self._pk_iv = None
        self._pk_lv = None
        self._pk_live = None
        return True

    def _pk_stmt(self, st):
        if isinstance(st, VgAssign) and st.name in self._pk_live[0]:
            code, k = self._pk_scalar_expr(st.expr)
            want = self._pk_live[1].get(st.name, 'i')
            if k != want:
                code = f'(long long)({code})' if want == 'i' else f'(double)({code})'
            self.emit(f'S_{self.vname(st.name)} = {code};')
            return
        if isinstance(st, Around):
            if not self.try_scalar_around(st):
                self.gen_around(st)
            return
        self.stmt(st)

    def _pk_scalar_expr(self, e):
        """标量域渲染：返回 (C 代码, 'i'|'f')。"""
        if isinstance(e, VarRef):
            if e.name in self._pk_live[0]:
                return (f'S_{self.vname(e.name)}', self._pk_live[1].get(e.name, 'i'))
            if e.name == self._pk_lv:
                return (self._pk_iv, 'i')
            return (f'rt_to_ll({self.vname(e.name)})', 'i')
        if isinstance(e, Call) and e.name in ('PK_BOX_I', 'PK_BOX_F'):
            nm = e.args[0].value
            return (f'S_{self.vname(nm)}', 'i' if e.name.endswith('I') else 'f')
        if isinstance(e, Call) and e.name == 'PK_LOOP_I':
            return (self._pk_iv, 'i')
        if isinstance(e, NumLit):
            return (repr(e.value), 'f' if isinstance(e.value, float) else 'i')
        if isinstance(e, BoolLit):
            return ('0' if e.value else '1', 'i')
        if isinstance(e, Unary) and e.op == '-':
            a, k = self._pk_scalar_expr(e.operand)
            return (f'(-{a})', k)
        if isinstance(e, BinOp):
            a, ka = self._pk_scalar_expr(e.left)
            b, kb = self._pk_scalar_expr(e.right)
            if e.op == '/':
                return (f'((double)({a}) / (double)({b}))', 'f')
            if e.op == '//':
                return (f'pk_fdiv((long long)({a}), (long long)({b}))', 'i')
            if e.op == '%':
                return (f'pk_mod((long long)({a}), (long long)({b}))', 'i')
            if e.op in ('and', 'or'):
                js = '&&' if e.op == 'and' else '||'
                return (f'(({a}) {js} ({b}))', 'i')
            if e.op in ('==', '!=', '<', '>', '<=', '>='):
                return (f'(({a}) {e.op} ({b}))', 'i')
            k = 'f' if 'f' in (ka, kb) else 'i'
            return (f'(({a}) {e.op} ({b}))', k)
        if isinstance(e, (Index, Call)) and self._pk_live:
            e2 = self._pk_subst(e, self._pk_lv, self._pk_live[0], self._pk_live[1])
            st, cv = self.expr(e2)
            for x in st:
                self.emit(x)
            return (f'rt_to_ll({cv})', 'i')
        self._pk_abort('标量表达式 ' + type(e).__name__)
        return ('0', 'i')

    def gen_around(self, s: Around):

        varname = getattr(s, 'var', 'at')
        st, c = self.expr(s.times)
        for x in st:
            self.emit(x)
        tv = self.newtemp()
        nv = self.newtemp('_n')
        iv = self.newtemp('_i')
        self.emit(f'Value {tv} = {c};')
        # 次数解码收进运行时 rt_loop_count（INT 直取；整值浮点截断；其余报
        # "rm.around 次数不是整数"），与旧的 tag/as 分支链逐字同义。
        self.emit(f'long long {nv} = rt_loop_count({tv});')
        self.emit(f'for (long long {iv} = 0; {iv} < {nv}; {iv}++) {{')
        self.emit(f'    Value {self.vname(varname)} = rt_at({iv});')
        self.depth += 1
        self.declared.add(varname)
        self.loop_depth += 1
        self.block(s.body)
        self.loop_depth -= 1
        self.declared.discard(varname)
        self.depth -= 1
        self.emit('}')

    def gen_onerror(self, s: OnError):
        """onerror err {...}：包住 GOING 其余全部语句（parse 层已重排进 s.body）。"""
        self.gen_trycatch(TryCatch(s.body, s.var, s.handler, s.line))

    def gen_trycatch(self, s: TryCatch):
        """try {...} catch e {...}：setjmp 包装。"""
        p = self.newtemp('_ep')
        slot = self.vname(s.var) if s.var else None
        self.emit('{')
        self.depth += 1
        self.emit(f'void *{p} = rt_err_push();')
        self.emit(f'if (setjmp(*(jmp_buf *){p}) == 0) {{')
        self.depth += 1
        self.block(s.body)
        self.emit(f'rt_err_pop({p});')
        self.depth -= 1
        self.emit('} else {')
        self.depth += 1
        if slot:
            had = s.var in self.declared
            self.emit(f'Value {slot} = rt_str(rt_err_msg());')
            self.declared.add(s.var)
            self.block(s.handler)
            if not had:
                self.declared.discard(s.var)
        else:
            self.block(s.handler)
        self.emit(f'rt_err_pop({p});')
        self.depth -= 1
        self.emit('}')
        self.depth -= 1
        self.emit('}')

    def gen_forin(self, s: ForIn):
        """for x in 列表 { ... }：逐元素循环。

        元素是 Value 副本（对象共享本体，改属性所有人可见）；循环变量用
        全新槽位遮蔽外层同名变量，循环结束后恢复外层映射。"""
        st, c = self.expr(s.iter)
        for x in st:
            self.emit(x)
        tv = self.newtemp()
        self.emit(f'Value {tv} = {c};')
        saved = self.vmap.pop(s.var, None)
        slot = self.vname(s.var)
        saved2 = self.vmap.pop(s.var2, None) if s.var2 else None
        slot2 = self.vname(s.var2) if s.var2 else None
        had2 = s.var2 in self.declared if s.var2 else False
        iv = self.newtemp('_i')
        # 长度每圈现取：循环里 删掉(...) 也不会越界
        self.emit(f'for (long long {iv} = 0; {iv} < rt_iter_len_ll({tv}); {iv}++) {{')
        self.depth += 1
        self.emit(f'Value {slot} = (IS_DICT({tv}) ? rt_dict_key_at({tv}, {iv}) : rt_index({tv}, rt_at({iv})));')
        if s.var2:
            self.emit(f'Value {slot2} = (IS_DICT({tv}) ? rt_index({tv}, {slot}) : rt_index({slot}, rt_int(1LL)));')
            self.declared.add(s.var2)
        had = s.var in self.declared
        self.declared.add(s.var)
        self.loop_depth += 1
        self.block(s.body)
        self.loop_depth -= 1
        if not had:
            self.declared.discard(s.var)   # 遮蔽退出：只收回循环自己的声明，不动外层
        if s.var2:
            if not had2:
                self.declared.discard(s.var2)
            if saved2 is not None:
                self.vmap[s.var2] = saved2
            else:
                self.vmap.pop(s.var2, None)
        self.depth -= 1
        self.emit('}')
        if saved is not None:
            self.vmap[s.var] = saved
        else:
            self.vmap.pop(s.var, None)
        if s.var2:
            if saved2 is not None:
                self.vmap[s.var2] = saved2
            else:
                self.vmap.pop(s.var2, None)

    def gen_vc(self, arms, nested=False):
        cond, body = arms[0]
        rest = arms[1:]
        if cond is None:               # 结尾的 vc- 缺省分支
            self.block(body)
            return
        st, c = self.expr(cond)
        for x in st:
            self.emit(x)
        self.emit(f'if (rt_cond({c})) {{')
        self.block(body)
        if not rest:
            self.emit('}')
            return
        self.emit('} else {')
        self.depth += 1
        self.gen_vc(rest, nested=True)
        self.depth -= 1
        self.emit('}')

    # ---- 函数 / 程序 ----

    @staticmethod
    def scan_assigned(stmts, acc):
        """按书写顺序收集本函数内会被赋值的变量名（含嵌套块），供预声明。"""
        for s in stmts:
            if isinstance(s, (VgAssign, IpAssign)):
                if s.name not in acc:
                    acc.append(s.name)
            elif isinstance(s, MultiAssign):
                for tg in s.targets:
                    if isinstance(tg, str) and tg not in acc:
                        acc.append(tg)   # 下标目标（Index）的基变量不算新声明
            elif isinstance(s, Around):
                Codegen.scan_assigned(s.body, acc)
            elif isinstance(s, ForIn):
                Codegen.scan_assigned(s.body, acc)
            elif isinstance(s, Aging):
                Codegen.scan_assigned(s.body, acc)
            elif isinstance(s, CdBlock):
                Codegen.scan_assigned(s.body, acc)
            elif isinstance(s, VcChain):
                for _c, b in s.arms:
                    Codegen.scan_assigned(b, acc)
            elif isinstance(s, (TryCatch, OnError)):
                Codegen.scan_assigned(s.body, acc)
                Codegen.scan_assigned(s.handler, acc)
        return acc

    def emit_locals(self, params, body):
        """规则 3：每个变量预声明 Value v_N = rt_none();（参数除外），
        并把槽地址登记为 GC 根——@5/@6 靠根集追踪可达对象。"""
        for name in self.scan_assigned(body, []):
            if name not in params:
                self.emit(f'Value {self.vname(name)} = rt_none();')
                self.emit(f'rt_root_add(&{self.vname(name)});')
                self.declared.add(name)

    def gen_fn(self, f: FnDef):
        if f.name in self.fns:
            self.err(f, f"函数 '{f.name}' 重复定义")
        self.fns[f.name] = len(f.params)
        默认 = getattr(f, 'defaults', None) or {}
        self.缺省参数[f.name] = [默认.get(p) for p in f.params]
        params = ', '.join(f'Value {self.vname(p)}' for p in f.params) or 'void'
        self.declared = set(f.params)
        self.in_going = False
        self.emit(f'Value {self.fname(f.name)}({params}) {{')
        self.depth += 1
        self.emit('rt_scope_enter();')      # GC 根作用域（支持递归嵌套）
        for p in f.params:                  # 参数也是 C 局部量，同样要登记
            self.emit(f'rt_root_add(&{self.vname(p)});')
        self.emit_locals(set(f.params), f.body)
        self.block(f.body)
        self.emit('rt_scope_leave();')
        self.emit('return rt_none();')      # 兜底
        self.depth -= 1
        self.emit('}')
        self.emit('')

    # ---- web.块（页面组件）：块 = 一个 void C 函数，调用点展开实参 ----

    def gen_hm_block(self, bd: HmBlockDef):
        cname, _np = self.hm_block_c[bd.name]
        saved = (self.declared, self.vtypes, self.in_going)
        saved_hm = (self.hm_used, self.page_begun)   # 块体不许污染全局页面标志
        self.declared = set(bd.params)
        self.vtypes = {}
        self.in_going = False
        params = ', '.join(f'Value {self.vname(p)}' for p in bd.params) or 'void'
        self.emit(f'static void {cname}({params}) {{')
        self.depth += 1
        self.emit('rt_scope_enter();')
        title = getattr(self, 'program_meta', '') or 'PYbook 页面'
        self.emit(f'rt_page_begin({cstr(title)});')  # 幂等：页面已开则是 no-op
        self.page_begun = True                       # 体内的 gen_hm 不再重复发
        for p in bd.params:
            self.emit(f'rt_root_add(&{self.vname(p)});')
        for st in bd.body:
            self.stmt(st)
        self.emit('rt_scope_leave();')
        self.depth -= 1
        self.emit('}')
        self.emit('')
        self.declared, self.vtypes, self.in_going = saved
        self.hm_used, self.page_begun = saved_hm

    def gen_hm_use(self, s: HmUse):
        if s.name not in self.hm_block_c:
            self.err(s, f"web.{s.name} 不是已定义的组件"
                        "（web.块 须在文件顶层定义）")
        cname, nparams = self.hm_block_c[s.name]
        if len(s.args) != nparams:
            self.err(s, f"web.{s.name} 需要 {nparams} 个参数，实际 {len(s.args)} 个")
        self.hm_used = True
        if not self.page_begun:      # 组件是页面第一条语句时也要先落骨架
            title = getattr(self, 'program_meta', '') or 'PYbook 页面'
            self.emit(f'rt_page_begin({cstr(title)});')
            self.page_begun = True
        args = []
        for a in s.args:
            st, c = self.expr(a)
            for x in st:
                self.emit(x)
            args.append(c)
        self.emit(f'{cname}({", ".join(args)});')

    def gen_hm_page(self, s: HmPageStmt):
        """web.页("名") { ... }：切换到子页缓冲烤内容，烤完切回主页。"""
        self.hm_used = True
        self.emit(f'rt_page_open({cstr(s.name)}, {cstr(s.name)});')
        saved = self.page_begun           # 子页骨架由 rt_page_open 负责
        self.page_begun = True
        for st in s.body:
            self.stmt(st)
        self.emit('rt_page_back();')
        self.page_begun = saved

    # ---- lb 类（OOP）----

    def collect_class(self, cd):
        if cd.name in self.classes:
            self.err(cd, f"类 '{cd.name}' 重复定义")
        self.classes[cd.name] = cd
        for m in cd.methods:
            full = cd.name + '.' + m.name
            if full in self.fns:
                self.err(m, f"方法 '{full}' 重复定义")
            self.fns[full] = 1 + len(m.params)   # slot0 = self

    def c_proto(self, name, params):
        args = ', '.join(f'Value {self.vname(p)}' for p in params) or 'void'
        return f'Value {self.fname(name)}({args});'

    def gen_class(self, cd):
        self.cur_class = cd.name
        for m in cd.methods:
            self.gen_method(cd, m)
        self.cur_class = None

    def gen_method(self, cd, m):
        full = cd.name + '.' + m.name
        params = ['self'] + list(m.params)
        self.declared = set(params)
        self.vtypes = {}
        self.in_going = False
        args = ', '.join(f'Value {self.vname(p)}' for p in params)
        self.emit(f'Value {self.fname(full)}({args}) {{')
        self.depth += 1
        self.emit('rt_scope_enter();')
        for p in params:
            self.emit(f'rt_root_add(&{self.vname(p)});')
        self.emit_locals(set(params), m.body)
        self.block(m.body)
        self.emit('rt_scope_leave();')
        self.emit('return rt_none();')
        self.depth -= 1
        self.emit('}')
        self.emit('')

    def gen_methodcall(self, e):
        if isinstance(e.base, VarRef) and e.base.name == 'self':
            cls = self.cur_class
            if cls is None:
                self.err(e, 'self 只能在类方法里使用')
        elif isinstance(e.base, VarRef):
            cls = self.vtypes.get(e.base.name)
            if cls is None:
                self.err(e, f"无法确定 '{e.base.name}' 的类：方法调用只支持 self 或由 lb.类名(...) 赋值的变量")
        else:
            self.err(e, '方法调用的对象只能是 self 或变量')
        cd = self.classes.get(cls)
        if cd is None:
            self.err(e, f"未定义的类 '{cls}'")
        found = next((m for m in cd.methods if m.name == e.name), None)
        if found is None:
            self.err(e, f"类 '{cls}' 没有方法 '{e.name}'")
        if len(e.args) != len(found.params):
            self.err(e, f"方法 '{cls}.{e.name}' 需要 {len(found.params)} 个参数，得到 {len(e.args)} 个")
        st, obj_c = self.expr(e.base)
        stmts = list(st)
        args = [obj_c]
        for a in e.args:
            s2, c2 = self.expr(a)
            stmts += s2
            args.append(self.materialize(stmts, c2))
        return stmts, f'{self.fname(cls + "." + e.name)}({", ".join(args)})'

    def gen_ctor(self, e):
        cd = self.classes.get(e.class_name)
        if cd is None:
            self.err(e, f"未定义的类 '{e.class_name}'")
        t = self.newtemp()
        stmts = [f'Value {t} = rt_obj_new({cstr(e.class_name)});']
        kw = dict(e.kwargs)
        for pname, default in cd.props:
            if pname in kw:
                vex = kw.pop(pname)
            elif default is not None:
                vex = default          # 未显式给的属性落类内默认值
            else:
                continue
            st, c = self.expr(vex)
            stmts += st
            stmts.append(f'rt_obj_set_prop({t}, {cstr(pname)}, {c});')
        return stmts, t

    def generate(self, program: Program) -> str:
        self.program_meta = program.meta
        if program.go_body is None:
            raise PybkCodegenError('GOING 缺失：程序必须包含 GOING 块')
        classes = program.classes or []
        for cd in classes:
            self.collect_class(cd)
        # 原型声明：类方法与普通函数可互相前向调用
        for f in program.fns:
            self.emit(self.c_proto(f.name, f.params))
        for cd in classes:
            for m in cd.methods:
                self.emit(self.c_proto(cd.name + '.' + m.name,
                                       ['self'] + m.params))
        self.emit('')
        for cd in classes:
            self.gen_class(cd)
        for f in program.fns:
            self.gen_fn(f)

        # ---- web.块（页面组件）：先分配 C 名发原型，再逐个生成函数体 ----
        hm_blocks = list((getattr(program, 'hm_blocks', None) or {}).values())
        for bd in hm_blocks:
            if bd.name in self.hm_block_c:
                self.err(bd, f"web.块 '{bd.name}' 重复定义")
            self.hm_block_c[bd.name] = ('hm_blk_' + str(len(self.hm_block_c)),
                                        len(bd.params))
        for bd in hm_blocks:                # 原型：组件互相调用与顺序解耦
            cname, _np = self.hm_block_c[bd.name]
            params = ', '.join(f'Value {self.vname(p)}' for p in bd.params) or 'void'
            self.emit(f'static void {cname}({params});')
        if hm_blocks:
            self.emit('')
        for bd in hm_blocks:
            self.gen_hm_block(bd)

        self.declared = set()
        self.vtypes = {}
        self.in_going = True
        self.emit('int main(void) {')
        self.depth += 1
        self.emit('setvbuf(stdout, NULL, _IONBF, 0);   /* 输出即时可见，供交互输入 */')
        self.emit('rt_scope_enter();')      # 主程序也是一层 GC 根作用域
        self.emit_locals(set(), program.go_body)
        if getattr(program, 'window_open', 0):
            win_i = None
            for k3, st3 in enumerate(program.go_body):
                if isinstance(st3, Call) and st3.name == 'win':
                    win_i = k3
                    break
            if win_i is None:
                raise PybkCodegenError(
                    'window(normal, open) 模式：GOING 里必须调用 win(宽, 高, "标题")'
                    '（它之前的语句只跑一次，之后的语句每帧跑）')
            self.block(program.go_body[:win_i + 1])       # 一次性初始化（含 win）
            self.emit('for (;;) {')
            self.depth += 1
            self.emit('if (rt_cond(rt_game_end())) break;')
            self.block(program.go_body[win_i + 1:])       # 每帧体
            self.emit('rt_game_show();')
            self.emit('rt_game_frame();')
            self.depth -= 1
            self.emit('}')
        else:
            self.block(program.go_body)
        if self.in_draw is not None:      # 缺 web.draw.终：自动补脚本闭合，保证页面有效
            close_c = cstr('</script>\n')
            self.emit(f'rt_page_raw({close_c});')
            self.in_draw = None
        if self.hm_used:
            self.emit('rt_page_save();')   # hm 页面落盘 pybook_page.html
        if self.test_used:
            self.emit('return (int)rt_test_summary();')   # 查() 汇总：失败数当退出码
        self.emit('rt_scope_leave();')
        self.emit('return 0;')
        self.depth -= 1
        self.emit('}')

        header = ['/* PYbook 名字映射（语言名 -> C 名） */']
        meta = ' '.join(str(program.meta).split())
        if meta:
            header.append(f'/* @ {meta} */')
        if self.fmap:
            header.append('/* 函数: ' + ', '.join(f'{k} -> {v}' for k, v in self.fmap.items()) + ' */')
        if self.vmap:
            header.append('/* 变量: ' + ', '.join(f'{k} -> {v}' for k, v in self.vmap.items()) + ' */')

        return ('\n'.join(header)
                + '\n\n#include <stdio.h>\n#include <stdlib.h>\n#include <string.h>\n#include <setjmp.h>\n#include "pybook_rt.h"\n#include "pybook_lib.h"\n\n'                + (self.hw_used and gen_hw_protos() or '')
                + SPRITE_HELPERS_C                + '\n'.join(self.out))

# ---------------- 3D_highway 原型发射 ----------------

def gen_hw_protos() -> str:
    """out.c 需要的 rt_hw_* 原型（实现在 pybook_hw3d.c）。"""
    fns = ['open:3', 'clearcolor:3', 'camera:5', 'box:9', 'frame:0', 'end:0', 'key:1', 'hit:1', 'mx:0', 'my:0', 'mdown:0', 'mhit:0', 'text:4', 'grab:0', 'free:0', 'mdx:0', 'mdy:0']
    lines = ['/* 3D_highway（实现在 pybook_hw3d.c） */']
    for f in fns:
        name, n = f.split(':')
        args = ', '.join(['Value'] * int(n)) or 'void'
        lines.append('Value rt_hw_' + name + '(' + args + ');')
    # box 的变长版：hw.box(...) 给 12 个实参时（带绕 x/y/z 旋转）走这里
    lines.append('Value rt_hw_boxn(int nargs, Value *av);')
    # 雾 / 视距 / 线框：编辑器与近景演示用
    lines.append('Value rt_hw_fog(Value, Value);')
    lines.append('Value rt_hw_far(Value);')
    lines.append('Value rt_hw_wire(Value);')
    # 画线 / 光照：gizmo 坐标轴、真实明暗
    lines.append('Value rt_hw_line(Value, Value, Value, Value, Value, Value, Value, Value, Value);')
    lines.append('Value rt_hw_light(Value, Value, Value, Value);')
    # 球 / 圆柱（cyl 走变长入口，9 或 10 参）
    lines.append('Value rt_hw_sphere(Value, Value, Value, Value, Value, Value, Value);')
    lines.append('Value rt_hw_cylv(int nargs, Value *av);')
    # 视口：竖直视场角 / 近裁剪面
    lines.append('Value rt_hw_fov(Value);')
    lines.append('Value rt_hw_near(Value);')
    # 贴图：加载 / 选择 / UV 平铺
    lines.append('Value rt_hw_tex(Value, Value);')
    lines.append('Value rt_hw_texuse(Value);')
    lines.append('Value rt_hw_uv(Value);')
    # 父子层级
    lines.append('Value rt_hw_push(Value, Value, Value, Value, Value, Value);')
    lines.append('Value rt_hw_pop(void);')
    # 可编程管线（GLSL）：编译着色器 / 内置着色器 / 启用 / 设 uniform
    lines.append('Value rt_hw_shader(Value, Value, Value);')
    lines.append('Value rt_hw_preset(Value, Value);')
    lines.append('Value rt_hw_shaderuse(Value);')
    lines.append('Value rt_hw_univ(int nargs, Value *av);')
    return '\n'.join(lines) + '\n'

# ---------- 全流程 ----------

# ---------------- 模块系统：引用("名") 的递归加载与合并 ----------------

_MEM_MODE_MAX_DEPTH = 8     # 引用嵌套深度上限（防循环引用拖垮编译器）


def _main_file_dir() -> str:
    """主文件所在目录。pybk_main.py 把 .pybk 路径放在 argv[1]；
    被嵌入调用（argv 不可用）时退回当前目录。"""
    if len(sys.argv) >= 2 and os.path.isfile(sys.argv[1]):
        return os.path.dirname(os.path.abspath(sys.argv[1])) or '.'
    return os.getcwd()


def _load_imports(program, base_dir: str, chain: list):
    """深度优先加载 program.imports 指向的模块单元。

    返回 (合并后的函数列表, 初始化语句列表)：被依赖的模块先合并；
    函数重名、循环引用、文件缺失都抛 PybkCodegenError（带行号）。"""
    if len(chain) > _MEM_MODE_MAX_DEPTH:
        raise PybkCodegenError('引用嵌套超过 8 层：' + ' -> '.join(chain))
    fns: list = []
    init_stmts: list = []
    classes: list = []
    for name, ln in (program.imports or []):
        if name in chain:
            raise PybkCodegenError(
                f'第 {ln} 行：循环引用：' + ' -> '.join(chain + [name]))
        path = os.path.join(base_dir, name + '.pybk')
        if not os.path.isfile(path):
            raise PybkCodegenError(f'第 {ln} 行：找不到文件: {name}.pybk')
        try:
            with open(path, encoding='utf-8-sig') as f:
                sub_src = f.read()
        except OSError as e:
            raise PybkCodegenError(f'第 {ln} 行：读取 {name}.pybk 失败：{e}')
        try:
            sub = parse_module(sub_src)
        except RecursionError:
            raise PybkCodegenError(f'第 {ln} 行：模块 {name}.pybk 嵌套太深')
        # 先合并该模块自己的依赖（深度优先），再合并它本身：
        # 依赖的函数/变量先入表，后加载者可以调用先加载者
        sub_fns, sub_inits, sub_classes = _load_imports(
            sub, os.path.dirname(path) or '.', chain + [name])
        for cd in sub_classes:
            if any(x.name == cd.name for x in classes):
                raise PybkCodegenError(
                    f'第 {ln} 行：类 {cd.name!r} 在引用的模块里重复定义')
            classes.append(cd)
        for f in sub_fns:
            if any(x.name == f.name for x in fns):
                raise PybkCodegenError(
                    f'第 {ln} 行：函数 {f.name!r} 在引用的模块里重复定义')
            fns.append(f)
        init_stmts.extend(sub_inits)
        for f in (sub.fns or []):
            if any(x.name == f.name for x in fns):
                raise PybkCodegenError(
                    f'第 {ln} 行：函数 {f.name!r} 重复定义（引用合并冲突）')
            fns.append(f)
        init_stmts.extend(sub.go_body or [])   # 模块的顶层 vg → 初始化语句
        for cd in (sub.classes or []):         # 模块的类也并入（大工程可按文件拆类）
            if any(x.name == cd.name for x in classes):
                raise PybkCodegenError(
                    f'第 {ln} 行：类 {cd.name!r} 重复定义（引用合并冲突）')
            classes.append(cd)
    return fns, init_stmts, classes


def _watch_loop(path: str) -> None:
    """--watch 模式：每 0.5 秒检查文件 mtime，变了就重新编译运行一次。
    单次编译失败把 gcc/语法错误完整打到 stderr 后继续等（循环不死）；
    Ctrl+C 退出。"""
    print('[watch] 监视 ' + path + '（每 0.5 秒检查修改；Ctrl+C 退出）', flush=True)
    last_mtime = None
    runs = 0
    while True:
        try:
            mtime = os.path.getmtime(path)
        except OSError:
            mtime = None
        if mtime != last_mtime:
            first = last_mtime is None
            last_mtime = mtime
            if first:
                print('[watch] 初次编译运行', flush=True)
            else:
                runs += 1
                print(f'[watch] 检测到修改，第 {runs} 次重跑', flush=True)
            try:
                with open(path, encoding='utf-8-sig') as f:
                    compile_and_run_once(f.read())
            except KeyboardInterrupt:
                raise
            except Exception as e:   # 语法/编译/运行错误都只报告，watch 不退出
                print(str(e), file=sys.stderr, flush=True)
        time.sleep(0.5)


def compile_and_run(src: str) -> str:
    """入口：--watch 模式进热重载循环；否则单次编译运行（行为与输出不变）。"""
    # 被管道/编辑器调用时输出强制 UTF-8；直接在控制台跑则保留系统编码
    if not sys.stdout.isatty():
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    if not sys.stderr.isatty():
        sys.stderr.reconfigure(encoding='utf-8', errors='replace')
    if _WATCH_MODE:
        _watch_loop(sys.argv[1] if len(sys.argv) >= 2 else '.')
        return ''
    return compile_and_run_once(src)


def compile_and_run_once(src: str) -> str:
    """单次：源码 → AST → out.c → gcc（.o 缓存 + 链接）→ 运行。

    语义错误抛 PybkCodegenError（带行号）；gcc 失败抛 PybkCodegenError
    （附 gcc 输出）；程序运行时非零退出抛 RuntimeError。
    正常时回显程序输出并作为返回值。
    """
    try:
        program = parse(src)
    except RecursionError:
        raise PybkCodegenError('表达式或括号嵌套太深，请拆分后再试')
    if program.imports:                       # 模块系统：合并被引用文件的函数与变量
        imported_fns, imported_inits, imported_classes = _load_imports(
            program, _main_file_dir(), ['<主文件>'])
        program.fns = imported_fns + (program.fns or [])
        program.go_body = imported_inits + (program.go_body or [])
        program.classes = imported_classes + (program.classes or [])
    gen = Codegen()
    c_code = gen.generate(program)
    c_path = f'out_{os.getpid()}_{int(time.time() * 1000) % 1000000}.c'
    with open(c_path, 'w', encoding='utf-8') as f:
        f.write(c_code)

    gcc = shutil.which('gcc') or FALLBACK_GCC
    # 链接出的 exe 会被杀软实时扫描锁住一小段时间；固定名 app.exe 在下一次
    # 编译时要覆盖它 → ld: cannot open output file app.exe: Permission denied。
    # 故改用「每进程唯一」的 exe 名，彻底避开与残留 exe 争用同一文件名；
    # 编译期的短重试只作兜底。
    exe = f'app_{os.getpid()}_{int(time.time() * 1000) % 1000000}.exe'
    game_flags = ['-DRT_GAME_SDL', '-static-libgcc', '-static-libstdc++', '-Wl,-Bstatic,-lwinpthread,-Bdynamic']
    sdl_flags = []
    if os.path.isdir('ucrt64/include/SDL2'):
        sdl_flags = ['-Iucrt64/include', '-Lucrt64/lib']

    # ---- 运行时预编译缓存（.o）：四个几乎不变的 .c 只有过期才重编 ----
    # 缓存在 rt_cache/ 目录；-DRT_GAME_SDL 会改变 pybook_rt.c 的编译产物，
    # 所以游戏模式的 .o 用独立文件名（.sdl.o），与普通模式互不污染。
    os.makedirs(RT_CACHE_DIR, exist_ok=True)
    objs = []
    for c_name in ('pybook_rt.c', 'pybook_lib.c', 'pybook_file.c',
                   'pybook_music.c', 'pybook_net.c', 'pybook_hw3d.c',
                   'pybook_np.c', 'pybook_tb.c', 'pybook_mt.c', 'pybook_json.c', 'pybook_csv.c', 'pybook_mm.c', 'mathplus.c', 'pybook_bits.c'):
        o_path = os.path.join(RT_CACHE_DIR,
                              c_name[:-2] + ('.sdl' if game_flags else '') + '.o')
        dep_mtime = os.path.getmtime(c_name)
        h_name = c_name[:-2] + '.h'
        if os.path.exists(h_name):
            dep_mtime = max(dep_mtime, os.path.getmtime(h_name))
        if not os.path.exists(o_path) or os.path.getmtime(o_path) < dep_mtime:
            cc = subprocess.run([gcc, '-O2', '-DMP_RT_BINDING', '-c', c_name, '-o', o_path]
                                + game_flags + sdl_flags,
                                capture_output=True, text=True, errors='replace')
            if cc.returncode != 0:
                raise PybkCodegenError('gcc 编译失败（运行时 ' + c_name
                                       + '）：\n' + (cc.stderr or cc.stdout))
        objs.append(o_path)

    build = None
    for _attempt in range(4):
        build = subprocess.run([gcc, '-O2'] + game_flags + sdl_flags +
                               ['-o', exe, c_path] + objs +
                               ['-lSDL2', '-lwinmm', '-lws2_32', '-lopengl32'],
                               capture_output=True, text=True, errors='replace')
        if build.returncode == 0 or 'Permission denied' not in (build.stderr or ''):
            break
        time.sleep(0.3 * (_attempt + 1))
    if build.returncode != 0:
        raise PybkCodegenError('gcc 编译失败：\n' + (build.stderr or build.stdout))

    # 注意：这里**不要**用 os.remove 清理本次生成的 exe。沙箱的 safe-delete
    # shim 会拦截 os.remove 并 fail-closed（回收站不可用），把错误打到 stderr，
    # 从而污染那些需要精确比对 stderr 的用例。残留的 app_*.exe 由外部 mv 清理。
    for _attempt in range(4):
        try:
            run = subprocess.run([exe if os.name == 'nt' else './' + exe],
                                 capture_output=True, text=True,
                                 encoding='utf-8', errors='replace')
            break
        except PermissionError:
            # 杀软可能短暂锁住刚链接出的 exe
            if _attempt == 3:
                raise
            time.sleep(0.3 * (_attempt + 1))
    if run.stdout:
        print(run.stdout, end='')
    if run.returncode != 0:
        if run.stderr:
            sys.stderr.write(run.stderr)
        raise RuntimeError(f'程序异常退出，退出码 {run.returncode}')
    if gen.hm_used and os.name == 'nt' and hasattr(os, 'startfile'):
        page = os.path.abspath('pybook_page.html')
        if os.path.exists(page):
            os.startfile(page)      # hm 程序：运行结束后自动弹浏览器
    return run.stdout


# ---------- 自测 ----------

SELF_TEST_SRC = '''@ 测试>样例>一
func 加倍(n) {
    ret n * 2
}
GOING:{
vg.名字 = "世界"
vg.次数 = 3
ns.show(你好 $名字！)/magic(b, c=0,200,255)
rm.around(次数) {
    ns.show(第 $at 圈)
}
if(次数 >= 3) {
    ns.show(次数不少)
}
else {
    ns.show(次数太少)
}
vg.结果 = list.加倍(21)
ns.show(结果=$结果)
}STOP
'''

if __name__ == '__main__':
    output = compile_and_run(SELF_TEST_SRC)
    for frag in ('42', '第 0 圈', '第 1 圈', '第 2 圈', '次数不少', '结果=42'):
        assert frag in output, f'自测失败：输出缺少 {frag!r}，实际 {output!r}'
    print('自测通过：42 / 第 0..2 圈 / 次数不少 / 结果=42 均出现')

    # ---- 帧动画 + go：只生成 C（不运行），核对 JS 骨架 ----
    ANIM_SRC = '''@ 动画>测试>一
GOING:{
web.draw.始
web.帧 {
    web.draw.色(255, 0, 0)
    web.draw.圆(200, 150, 80)
}
web.帧 {
    web.draw.色(0, 0, 255)
    web.draw.方(100, 100, 160, 160)
}
web.播放(2)
go(右, 100, 2)
web.draw.终
}STOP
'''
    anim_c = Codegen().generate(parse(ANIM_SRC))
    for frag in ('pybook-canvas-1',
                 'const pybk_frames = [',
                 'function() {',
                 'setInterval(function() {',
                 'ctx1.clearRect(0, 0, 400, 300);',
                 'pybk_frames[pybk_frame % pybk_frames.length]();',
                 "pybk_canvas.style.transition = 'transform ",
                 "pybk_canvas.style.transform = 'translateX("):
        assert frag in anim_c, f'帧动画自测失败：C 输出缺少 {frag!r}'
    assert anim_c.count('rt_page_raw("function() {")') == 2, 'pybk_frames 应包含两个帧函数'
    print('帧动画自测通过：pybk_frames 数组（两帧）/ setInterval 循环 / CSS transform 均已生成')

    # ---- 键盘监听 + 游戏零件：只生成 C（不运行），核对调用映射 ----
    GAME_SRC = '''@ game>move>fun
GOING:{
win(800, 600, "My Game")
rm.aging.while(end()) {
    if(key("right")) {
        vg.x = x + 5
    }
    show()
    wait(16)
}
}STOP
'''
    game_c = Codegen().generate(parse(GAME_SRC))
    for frag in ('rt_game_win(', 'rt_game_end()', 'rt_game_key("right")',
                 'rt_game_show()', 'rt_game_frame('):
        assert frag in game_c, f'游戏零件自测失败：C 输出缺少 {frag!r}'
    print('游戏零件自测通过：rt_game_win/rt_game_end/rt_game_key/rt_game_show/rt_game_frame 均已生成')
