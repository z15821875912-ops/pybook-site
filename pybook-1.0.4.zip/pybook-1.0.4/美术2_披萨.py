# -*- coding: utf-8 -*-
"""披萨塔 v2 精细像素美术生成器（全原创，致敬 Pizza Tower 的画风方向）。

输出 games/披萨塔2/ 目录。精细度规范：
  - 角色帧 24x28 像素（4 倍导出 = 96x112），跑步 6 帧、冲刺 6 帧（三档各 2 帧）
  - 每个精灵三层处理：深色描边 + 主体色 + 高光/阴影双色阶
  - 敌人 3 种 x 精细帧（奶酪兵 4 帧、飞叉幽灵 2 帧、披萨石 4 帧）
  - 场景：普通砖/裂纹砖/单向台/尖刺/检查点/塔门/大披萨/顶料x4/云x2/远山
  - UI：连击字牌大图、评价徽章 C/B/A/S/P、John 柱
"""
import os
import math
from PIL import Image, ImageDraw

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "games", "披萨塔2")
os.makedirs(OUT, exist_ok=True)

# ================= 调色板 =================
肤 = (255, 208, 168)
肤暗 = (226, 168, 130)
围红 = (232, 58, 58)
围暗 = (170, 34, 34)
白衣 = (244, 244, 248)
白暗 = (198, 198, 210)
裤灰 = (72, 72, 96)
裤暗 = (52, 52, 72)
鞋棕 = (124, 74, 42)
鞋暗 = (88, 50, 28)
发 = (58, 40, 32)
发暗 = (40, 27, 22)
眼白 = (255, 255, 255)
瞳 = (36, 28, 26)
线 = (32, 22, 22)
披萨红 = (226, 76, 58)
披萨饼 = (246, 206, 104)
披萨饼暗 = (216, 168, 74)
披萨酱 = (226, 76, 58)
芝士 = (255, 222, 112)
芝士暗 = (222, 180, 70)
橄榄 = (116, 156, 64)
砖主 = (214, 132, 72)
砖暗 = (168, 96, 52)
砖亮 = (238, 164, 104)
门红 = (188, 58, 54)
门暗 = (132, 34, 34)
金 = (255, 224, 96)
金暗 = (216, 176, 56)


def 保存(img, 名, 倍=4):
    img = img.resize((img.width * 倍, img.height * 倍), Image.NEAREST)
    img.save(os.path.join(OUT, 名 + ".png"))


def 新(w, h):
    img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    return img, ImageDraw.Draw(img)


def px(d, x, y, c):
    d.point((x, y), fill=c)


def 描边画(img, 色=(32, 22, 22, 255)):
    """给非透明像素加 1px 外描边（用于把手绘感统一）。"""
    w, h = img.size
    src = img.load()
    out = img.copy()
    dst = out.load()
    for y in range(h):
        for x in range(w):
            if src[x, y][3] == 0:
                for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    nx, ny = x + dx, y + dy
                    if 0 <= nx < w and 0 <= ny < h and src[nx, ny][3] > 0:
                        dst[x, y] = 色
                        break
    return out


# ================= 角色：大厨 =================
# 基准 24x28；头部 12x11、身体 10x9、腿脚 8x6
def 厨帧(名, *, 腿前=0, 腿后=0, 倾=0, 蹲=0, 表="正", 手="走", 围=0,
        汗=False, 转背=False, 光环=False, 尘=False, 墙=False):
    img, d = 新(24, 28)
    oy = 4 + 蹲 * 4
    ox = 2
    hx = ox + 3 + 倾
    # ---- 头部（带发+双阶肤色）----
    d.rectangle((hx, oy, hx + 11, oy + 10), fill=肤, outline=线)
    d.rectangle((hx, oy, hx + 11, oy + 3), fill=发)
    d.line((hx, oy + 3, hx + 11, oy + 3), fill=发暗)
    # 发际高光
    d.line((hx + 2, oy, hx + 8, oy), fill=(84, 60, 48))
    if 转背:
        # 背面：后脑勺头发覆盖
        d.rectangle((hx + 1, oy + 3, hx + 10, oy + 7), fill=发)
        d.rectangle((hx + 2, oy + 3, hx + 9, oy + 4), fill=发暗)
    else:
        # 眼睛（白底+瞳+高光）
        if 表 == "眯":
            d.line((hx + 3, oy + 5, hx + 5, oy + 5), fill=瞳)
            d.line((hx + 7, oy + 5, hx + 9, oy + 5), fill=瞳)
        elif 表 == "瞪":
            d.rectangle((hx + 2, oy + 4, hx + 5, oy + 7), fill=眼白, outline=线)
            d.rectangle((hx + 6, oy + 4, hx + 9, oy + 7), fill=眼白, outline=线)
            d.rectangle((hx + 3, oy + 5, hx + 4, oy + 6), fill=瞳)
            d.rectangle((hx + 7, oy + 5, hx + 8, oy + 6), fill=瞳)
            d.rectangle((hx + 6, oy + 8, hx + 8, oy + 9), fill=(122, 30, 30))  # 张嘴
        else:
            d.rectangle((hx + 3, oy + 4, hx + 4, oy + 6), fill=瞳)
            d.rectangle((hx + 7, oy + 4, hx + 8, oy + 6), fill=瞳)
            px(d, hx + 3, oy + 4, 眼白)
    # 鼻子（大鼻子是这个画风的脸）
    d.rectangle((hx + 5, oy + 6, hx + 6, oy + 7), fill=肤暗)
    # 腮红（冲刺红脸）
    if 表 == "瞪":
        d.rectangle((hx + 1, oy + 7, hx + 2, oy + 8), fill=(255, 150, 130))
        d.rectangle((hx + 9, oy + 7, hx + 10, oy + 8), fill=(255, 150, 130))
    # ---- 围巾 ----
    ty = oy + 11
    d.rectangle((hx, ty, hx + 11, ty + 1), fill=围红)
    d.line((hx, ty + 1, hx + 11, ty + 1), fill=围暗)
    if 围:
        d.rectangle((hx + 12 + 倾, ty, hx + 16 + 倾 + 围, ty + 1), fill=围红)
        px(d, hx + 16 + 倾 + 围, ty + 1, 围暗)
    # ---- 身体（白衣双阶）----
    d.rectangle((hx + 1, ty + 2, hx + 10, ty + 9 - 蹲), fill=白衣, outline=线)
    d.rectangle((hx + 1, ty + 6, hx + 10, ty + 9 - 蹲), fill=白暗)   # 下半阴影
    # 肚兜高光
    d.line((hx + 2, ty + 2, hx + 5, ty + 2), fill=(255, 255, 255))
    # ---- 手 ----
    if 手 == "冲":
        d.rectangle((hx + 11, ty + 3, hx + 16, ty + 5), fill=肤, outline=线)
        d.rectangle((hx + 15, ty + 3, hx + 16, ty + 5), fill=肤暗)
    elif 手 == "抓":
        d.rectangle((hx + 11, ty + 2, hx + 16, ty + 6), fill=肤, outline=线)
        d.line((hx + 13, ty + 2, hx + 13, ty + 6), fill=肤暗)   # 手指分缝
    elif 手 == "指":
        d.rectangle((hx + 11, ty + 2, hx + 15, ty + 3), fill=肤, outline=线)
    elif 手 == "举":
        d.rectangle((hx + 9, ty - 3, hx + 11, ty + 2), fill=肤, outline=线)
    # ---- 腿脚 ----
    ly = ty + 10 - 蹲
    d.rectangle((hx + 1 + 腿后, ly, hx + 3 + 腿后, ly + 3), fill=裤灰, outline=线)
    d.rectangle((hx + 6 + 腿前, ly, hx + 8 + 腿前, ly + 3), fill=裤灰, outline=线)
    d.rectangle((hx + 1 + 腿后, ly + 3, hx + 4 + 腿后, ly + 4), fill=鞋棕, outline=线)
    d.rectangle((hx + 6 + 腿前, ly + 3, hx + 9 + 腿前, ly + 4), fill=鞋棕, outline=线)
    # 墙贴版本：手向上抓姿势由调用方另外覆盖（墙模式专用帧）
    # ---- 光环（超级挑衅）----
    if 光环:
        d.ellipse((ox - 2, 0, ox + 22, 27), outline=(255, 224, 96, 200))
        d.ellipse((ox, 2, ox + 20, 25), outline=(255, 240, 160, 120))
    # ---- 尘土 ----
    if 尘:
        d.ellipse((0, 22, 8, 27), fill=(228, 206, 168, 190))
        d.ellipse((16, 23, 23, 27), fill=(228, 206, 168, 150))
    # ---- 汗滴 ----
    if 汗:
        d.polygon([(hx - 1, oy + 3), (hx + 1, oy + 3), (hx, oy + 6)], fill=(140, 200, 255))
    img = 描边画(img)
    保存(img, 名)


# 站立（呼吸 2 帧）
厨帧("厨_站A", 腿前=0, 腿后=0)
厨帧("厨_站B", 腿前=0, 腿后=0, 蹲=1)
# 走 4 帧
for k, (a, b) in enumerate([(2, -2), (1, 0), (-1, 2), (0, -1)]):
    厨帧(f"厨_走{k}", 腿前=a, 腿后=b, 围=1)
# 跑 6 帧（更大幅度的腿摆+身体前倾 1）
for k, (a, b) in enumerate([(3, -3), (2, -1), (0, 2), (-3, 3), (-1, 2), (2, 0)]):
    厨帧(f"厨_跑{k}", 腿前=a, 腿后=b, 倾=1, 围=2, 表="眯")
# 冲刺三档各 2 帧（Mach1/2/3：倾 1/2/3，表情递进，速度线在游戏层叠）
for 档, 倾 in ((1, 1), (2, 2), (3, 3)):
    for k, (a, b) in enumerate([(3, -3), (-3, 3)]):
        厨帧(f"厨_冲{档}_{k}", 腿前=a, 腿后=b, 倾=倾,
             表="眯" if 档 < 3 else "瞪", 手="冲", 围=2 + 档)
# 跳 / 落
厨帧("厨_跳", 腿前=-2, 腿后=2, 手="举", 表="瞪", 围=1)
厨帧("厨_落", 腿前=1, 腿后=-1, 表="正")
# 抓
厨帧("厨_抓", 手="抓", 表="瞪", 倾=1)
# 抓着敌人跑（2 帧举着）
for k, a in enumerate((2, -2)):
    厨帧(f"厨_抓跑{k}", 手="举", 腿前=a, 腿后=-a, 倾=1, 表="瞪", 围=2)
# 砸地（蹲死 + 尘）
厨帧("厨_砸", 蹲=2, 表="瞪", 尘=True)
# 爬墙 2 帧
for k, a in enumerate((0, 2)):
    img, d = 新(24, 28)
    # 复用厨帧再画向上抓的手
    img2 = Image.new("RGBA", (24, 28), (0, 0, 0, 0))
    d2 = ImageDraw.Draw(img2)
    画体(d2, 4, 5, a, -a, 表="瞪", 墙=True) if False else None
    厨帧(f"厨_爬{k}", 手="抓", 腿前=a, 腿后=-a, 表="瞪", 墙=True)
# 挑衅 2 帧
for k, 围 in enumerate((0, 2)):
    厨帧(f"厨_挑{k}", 手="指", 表="瞪", 围=围)
# 超级挑衅（金光环）
厨帧("厨_超挑", 手="举", 表="瞪", 光环=True, 围=3)
# 受伤
厨帧("厨_伤", 表="瞪", 手="举", 汗=True, 围=1)
# 背面（爬塔顶出逃时用）
厨帧("厨_背", 转背=True, 围=1)


def 画体(*a, **k):
    pass   # 占位（历史遗留，未使用）


# ================= 敌人 =================
# 奶酪怪 4 帧（走路摆动 + 眨眼）
for k, (腿, 眨) in enumerate([((1, -1), 0), ((2, -2), 0), ((-1, 1), 0), ((0, 0), 1)]):
    img, d = 新(18, 20)
    bx, by = 2, 2
    # 奶酪楔形主体
    d.polygon([(bx, by + 12), (bx + 14, by + 2), (bx + 14, by + 12)],
              fill=芝士, outline=线)
    d.line((bx, by + 12, bx + 14, by + 2), fill=芝士暗)
    d.ellipse((bx + 9, by + 5, bx + 12, by + 8), fill=芝士暗)   # 奶酪孔
    if 眨:
        d.line((bx + 4, by + 6, bx + 6, by + 6), fill=瞳)
        d.line((bx + 8, by + 6, bx + 10, by + 6), fill=瞳)
    else:
        d.rectangle((bx + 4, by + 5, bx + 5, by + 7), fill=瞳)
        d.rectangle((bx + 8, by + 5, bx + 9, by + 7), fill=瞳)
    d.line((bx + 5, by + 9, bx + 9, by + 9), fill=线)
    d.rectangle((bx + 3 + 腿[0], by + 13, bx + 5 + 腿[0], by + 15), fill=鞋棕, outline=线)
    d.rectangle((bx + 9 + 腿[1], by + 13, bx + 11 + 腿[1], by + 15), fill=鞋棕, outline=线)
    img = 描边画(img)
    保存(img, f"酪怪{k}")

# 飞叉幽灵 2 帧（浮动+叉子换手）
for k, 上 in enumerate((0, 1)):
    img, d = 新(20, 18)
    by = 2 + 上
    d.polygon([(4, by + 2), (15, by + 2), (15, by + 9), (12, by + 12),
               (10, by + 10), (8, by + 13), (6, by + 10), (4, by + 9)],
              fill=(196, 108, 214), outline=线)
    d.rectangle((5, by + 4, 7, by + 7), fill=眼白, outline=线)
    d.rectangle((11, by + 4, 13, by + 7), fill=眼白, outline=线)
    d.rectangle((6, by + 5, 6, by + 6), fill=瞳)
    d.rectangle((12, by + 5, 12, by + 6), fill=瞳)
    # 三叉
    叉色 = (188, 190, 208)
    d.line((15, by + 6, 19, by + 6), fill=叉色)
    d.line((19, by + 3, 19, by + 9), fill=叉色)
    px(d, 18, by + 3, 叉色); px(d, 20, by + 3, 叉色)
    px(d, 18, by + 9, 叉色); px(d, 20, by + 9, 叉色)
    img = 描边画(img)
    保存(img, f"叉灵{k}")

# 披萨滚石 4 帧（滚动旋转的番茄纹）
for k in range(4):
    img, d = 新(20, 20)
    rot = k * 90
    d.ellipse((1, 1, 18, 18), fill=披萨饼, outline=线)
    d.ellipse((3, 3, 16, 16), fill=披萨酱)
    # 旋转的芝士点（简易旋转：4 个点绕圈）
    for ang in (0, 90, 180, 270):
        a = math.radians(ang + k * 30)
        cx = 9 + int(4 * math.cos(a))
        cy = 9 + int(4 * math.sin(a))
        d.rectangle((cx - 1, cy - 1, cx + 1, cy + 1), fill=芝士)
    d.ellipse((8 - (k % 2), 8 - (k % 2), 10 + (k % 2), 10 + (k % 2)), fill=披萨饼暗)
    img = 描边画(img)
    保存(img, f"滚石{k}")

# ================= 场景砖块 =================
# 地砖（带高光+裂纹随机感）
img, d = 新(16, 16)
d.rectangle((0, 0, 15, 15), fill=砖主, outline=(96, 52, 30))
d.line((0, 0, 15, 0), fill=砖亮)
d.line((0, 7, 15, 7), fill=砖暗); d.line((0, 8, 15, 8), fill=(120, 66, 38))
d.line((7, 0, 7, 7), fill=砖暗); d.line((3, 8, 3, 15), fill=砖暗)
d.line((11, 8, 11, 15), fill=砖暗)
px(d, 5, 3, 砖亮); px(d, 12, 11, 砖亮)
保存(img, "地砖")

# 裂纹砖（Mach 可撞碎）
img, d = 新(16, 16)
d.rectangle((0, 0, 15, 15), fill=(206, 122, 84), outline=(110, 56, 34))
d.line((0, 0, 15, 0), fill=(230, 150, 110))
for (x0, y0, x1, y1) in ((3, 1, 6, 6), (6, 6, 4, 11), (6, 6, 12, 8),
                          (12, 8, 10, 14), (4, 11, 8, 15)):
    d.line((x0, y0, x1, y1), fill=(70, 30, 20))
保存(img, "裂砖")

# 单向平台（木梁）
img, d = 新(16, 8)
d.rectangle((0, 0, 15, 6), fill=(226, 168, 96), outline=(120, 70, 34))
d.line((0, 0, 15, 0), fill=(246, 196, 130))
d.line((0, 5, 15, 5), fill=(150, 94, 48))
for k in (3, 9, 14):
    px(d, k, 2, (170, 110, 60))
保存(img, "木台")

# 尖刺
img, d = 新(16, 10)
for k in range(4):
    d.polygon([(k * 4, 9), (k * 4 + 2, 0), (k * 4 + 4, 9)],
              fill=(206, 208, 224), outline=线)
    d.line((k * 4 + 2, 1, k * 4 + 3, 8), fill=(160, 162, 186))
保存(img, "尖刺")

# 检查点旗（2 帧：收/展）
for k in range(2):
    img, d = 新(16, 24)
    d.rectangle((3, 0, 4, 23), fill=(120, 90, 60), outline=线)
    if k == 0:
        d.polygon([(5, 1), (14, 3), (5, 6)], fill=围红, outline=线)
    else:
        d.polygon([(5, 1), (14, 5), (5, 9)], fill=围红, outline=线)
    img = 描边画(img)
    保存(img, f"旗{k}")

# 出逃门（塔门，大气派）
img, d = 新(26, 34)
d.rectangle((1, 0, 24, 33), fill=门红, outline=门暗)
d.rectangle((1, 0, 24, 3), fill=金)
d.line((1, 3, 24, 3), fill=金暗)
d.rectangle((5, 6, 20, 33), fill=门暗)
d.rectangle((6, 7, 19, 33), fill=(160, 44, 40))
d.ellipse((16, 18, 19, 21), fill=金)
img = 描边画(img)
保存(img, "塔门")

# 大披萨（收集品 100 分 / 终点）
img, d = 新(22, 22)
d.ellipse((1, 1, 20, 20), fill=披萨饼, outline=线)
d.ellipse((3, 3, 18, 18), fill=披萨酱)
d.ellipse((5, 5, 16, 16), fill=芝士)
for (x, y) in ((6, 7), (12, 6), (7, 12), (13, 13)):
    d.ellipse((x, y, x + 2, y + 2), fill=橄榄)
d.ellipse((9, 9, 12, 12), fill=披萨红)
img = 描边画(img)
保存(img, "大披萨")

# 顶料四种（收集品小件）
顶料色 = {"芝士": (芝士, 芝士暗), "番茄": ((232, 80, 64), (180, 52, 44)),
          "蘑菇": ((238, 226, 210), (198, 180, 164)), "香肠": ((164, 96, 60), (120, 66, 40))}
for 名, (主, 暗) in 顶料色.items():
    img, d = 新(14, 14)
    if 名 == "芝士":
        d.polygon([(1, 11), (7, 1), (12, 11)], fill=主, outline=线)
        d.ellipse((5, 4, 8, 7), fill=暗)
    elif 名 == "番茄":
        d.ellipse((1, 3, 12, 12), fill=主, outline=线)
        d.line((4, 4, 5, 2), fill=(60, 120, 50))
        d.line((6, 3, 8, 1), fill=(60, 120, 50))
        d.ellipse((3, 5, 5, 7), fill=(255, 150, 130))
    elif 名 == "蘑菇":
        d.ellipse((1, 2, 12, 9), fill=主, outline=线)
        d.rectangle((5, 8, 8, 12), fill=(246, 240, 226), outline=线)
        d.ellipse((3, 4, 5, 6), fill=暗)
        d.ellipse((8, 5, 10, 7), fill=暗)
    else:
        d.ellipse((1, 1, 12, 12), fill=主, outline=线)
        d.ellipse((3, 3, 6, 6), fill=暗)
        d.ellipse((7, 6, 10, 9), fill=暗)
    img = 描边画(img)
    保存(img, "料_" + 名)

# 约翰柱（逃亡触发柱）
img, d = 新(20, 34)
d.rectangle((2, 0, 17, 33), fill=(214, 132, 72), outline=(96, 52, 30))
d.line((2, 6, 17, 6), fill=砖暗)
d.line((2, 12, 17, 12), fill=砖暗)
d.line((2, 18, 17, 18), fill=砖暗)
d.line((2, 24, 17, 24), fill=砖暗)
# 约翰的脸
d.rectangle((5, 8, 14, 17), fill=(244, 244, 248), outline=线)
d.rectangle((7, 11, 8, 12), fill=瞳)
d.rectangle((11, 11, 12, 12), fill=瞳)
d.rectangle((7, 15, 12, 15), fill=线)
img = 描边画(img)
保存(img, "约翰柱")

# 云 2 朵（背景层）
for k, w in enumerate((28, 40)):
    img, d = 新(w, 14)
    d.ellipse((2, 4, w - 6, 13), fill=(255, 255, 255, 235))
    d.ellipse((6, 0, w - 14, 10), fill=(255, 255, 255, 235))
    d.ellipse((0, 7, w - 2, 13), fill=(255, 255, 255, 235))
    d.ellipse((4, 3, w - 10, 9), fill=(240, 246, 255))
    保存(img, f"云{k}")

# 远景塔剪影（背景第三层）
img, d = 新(48, 56)
d.polygon([(24, 0), (40, 55), (8, 55)], fill=(142, 96, 148))
d.polygon([(24, 0), (30, 20), (18, 20)], fill=(156, 108, 160))
for y in (16, 26, 36, 46):
    d.line((12 + (y - 16) // 4, y, 36 - (y - 16) // 4, y), fill=(122, 80, 128))
保存(img, "远塔", 倍=4)

# ================= UI =================
# 连击底牌（大）
img, d = 新(56, 30)
d.polygon([(0, 15), (8, 0), (48, 0), (55, 15), (48, 29), (8, 29)],
          fill=(226, 62, 62), outline=(126, 22, 22))
d.polygon([(3, 15), (9, 3), (47, 3), (52, 15), (47, 27), (9, 27)],
          fill=(246, 92, 92))
保存(img, "连击底")

# 评价徽章 5 档
评色 = {"C": ((160, 160, 176), (110, 110, 126)), "B": ((120, 200, 120), (70, 150, 80)),
        "A": ((120, 170, 250), (70, 110, 200)), "S": ((255, 224, 96), (216, 176, 56)),
        "P": ((255, 160, 230), (210, 90, 190))}
for 名, (主, 暗) in 评色.items():
    img, d = 新(30, 30)
    d.ellipse((1, 1, 28, 28), fill=主, outline=暗)
    d.ellipse((4, 4, 25, 25), outline=(255, 255, 255))
    # 字母用粗线条手绘
    cx = 15
    if 名 == "C":
        d.arc((8, 8, 22, 22), 40, 320, fill=暗, width=4)
    elif 名 == "B":
        d.line((11, 7, 11, 23), fill=暗, width=3)
        d.arc((11, 7, 21, 15), -90, 90, fill=暗, width=3)
        d.arc((11, 15, 21, 23), -90, 90, fill=暗, width=3)
    elif 名 == "A":
        d.line((8, 23, 15, 7), fill=暗, width=3)
        d.line((15, 7, 22, 23), fill=暗, width=3)
        d.line((11, 17, 19, 17), fill=暗, width=2)
    elif 名 == "S":
        d.arc((8, 6, 22, 16), 200, 40, fill=暗, width=4)
        d.arc((8, 14, 22, 24), 20, 220, fill=暗, width=4)
    else:   # P
        d.line((11, 23, 11, 7), fill=暗, width=3)
        d.arc((11, 7, 22, 17), -90, 90, fill=暗, width=3)
    img = 描边画(img, (30, 30, 40, 255))
    保存(img, "评_" + 名)

print("v2 精灵生成完成：", len(os.listdir(OUT)), "个 →", OUT)
