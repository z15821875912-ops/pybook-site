/* 出图探针：把 7 种着色器各渲一帧，存成 BMP（供 PPT 当真实截图用）。
 *
 * 为什么单独写一个：_shader_probe.c 只算指纹不落盘，而且是 240x180 的小窗，
 * 尺寸不够放进 1280x720 的幻灯片。这里用 1280x720、场景照 _proto_glsl.pybk 摆，
 * 每种配置连渲两帧（SwapBuffers 后后缓冲里是上一帧）再从 GL_BACK 读回。
 *
 * BMP 是零依赖最好写的格式；读回的 GL_RGB 像素是"下到上 + R,G,B"，
 * 与 BMP 的行序一致（BMP 也是下到上），但**通道序相反**：BMP 要 B,G,R，
 * 所以逐像素交换 R/B 再写（第一版忘了换，橙色球渲染成蓝色，反了）。
 *
 * 链接：gcc -O2 -DRT_GAME_SDL -static-libgcc -Wl,-Bstatic,-lwinpthread,-Bdynamic
 *        -Iucrt64/include -I. -o _shot.exe _shot.c rt_cache/ (所有 .sdl.o)
 *        -Lucrt64/lib -lSDL2 -lwinmm -lws2_32 -lopengl32
 */
#include "pybook_rt.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <GL/gl.h>

Value rt_hw_open(Value, Value, Value);
Value rt_hw_clearcolor(Value, Value, Value);
Value rt_hw_camera(Value, Value, Value, Value, Value);
Value rt_hw_box(Value, Value, Value, Value, Value, Value, Value, Value, Value);
Value rt_hw_sphere(Value, Value, Value, Value, Value, Value, Value);
Value rt_hw_cylv(int, Value *);
Value rt_hw_line(Value, Value, Value, Value, Value, Value, Value, Value, Value);
Value rt_hw_light(Value, Value, Value, Value);
Value rt_hw_fog(Value, Value);
Value rt_hw_far(Value);
Value rt_hw_ortho(Value);
/* 出图模式：0 = 3/4 斜视，1 = 正俯视；g_正交 0 = 透视，>0 = 正交半高 */
static int   g_模式 = 0;
static double g_正交 = 0.0;
Value rt_hw_push(Value, Value, Value, Value, Value, Value);
Value rt_hw_pop(void);
Value rt_hw_preset(Value, Value);
Value rt_hw_shader(Value, Value, Value);
Value rt_hw_shaderuse(Value);
Value rt_hw_univ(int, Value *);
Value rt_hw_frame(void);

#define W 1280
#define H 720

static unsigned char g_buf[W * H * 3];
static const char *g_out = ".";

/* ---------- BMP 小工具 ---------- */

static void put16(unsigned char *p, unsigned v)
{ p[0] = (unsigned char)(v & 0xFF); p[1] = (unsigned char)((v >> 8) & 0xFF); }

static void put32(unsigned char *p, unsigned long v)
{
    p[0] = (unsigned char)(v & 0xFF);
    p[1] = (unsigned char)((v >> 8) & 0xFF);
    p[2] = (unsigned char)((v >> 16) & 0xFF);
    p[3] = (unsigned char)((v >> 24) & 0xFF);
}

static void 存BMP(const char *名)
{
    char path[512];
    snprintf(path, sizeof path, "%s/%s.bmp", g_out, 名);

    FILE *f = fopen(path, "wb");
    if (!f) { printf("  ** 打不开 %s\n", path); return; }

    int row = W * 3;
    int pad = (4 - (row % 4)) % 4;
    unsigned long stride = (unsigned long)(row + pad);
    unsigned char hdr[54];
    memset(hdr, 0, sizeof hdr);

    hdr[0] = 'B'; hdr[1] = 'M';
    put32(hdr + 2, (unsigned long)(54 + stride * H));
    put32(hdr + 10, 54);
    put32(hdr + 14, 40);
    put32(hdr + 18, W);
    put32(hdr + 22, H);
    put16(hdr + 26, 1);
    put16(hdr + 28, 24);
    put32(hdr + 34, stride * H);

    fwrite(hdr, 1, 54, f);
    unsigned char zero[3] = { 0, 0, 0 };
    unsigned char line[W * 3];
    for (int y = 0; y < H; y++) {
        const unsigned char *s = g_buf + (size_t)y * row;
        for (int x = 0; x < W; x++) {          /* GL 给 R,G,B → BMP 要 B,G,R */
            line[x * 3 + 0] = s[x * 3 + 2];
            line[x * 3 + 1] = s[x * 3 + 1];
            line[x * 3 + 2] = s[x * 3 + 0];
        }
        fwrite(line, 1, row, f);
        if (pad) fwrite(zero, 1, pad, f);
    }
    fclose(f);
    printf("  存图 %s\n", path);
}

static void 布景(void);   /* 定义在本文件后半 */

/* 读回一帧并落盘 */
static void 出图(const char *名)
{
    memset(g_buf, 0, sizeof g_buf);
    glReadBuffer(GL_BACK);
    glPixelStorei(GL_PACK_ALIGNMENT, 1);
    glReadPixels(0, 0, W, H, GL_RGB, GL_UNSIGNED_BYTE, g_buf);
    while (glGetError() != GL_NO_ERROR) { /* 排干 */ }
    存BMP(名);
}

/* 连渲两帧同样的内容再读 —— 抵消 SwapBuffers 的"后缓冲滞后一帧" */
static void 两帧出图(const char *名)
{
    布景();
    rt_hw_frame();
    布景();
    rt_hw_frame();
    出图(名);
}

/* ---------- 场景（照 _proto_glsl.pybk 摆，角度写死）---------- */

static void 布景(void)
{
    rt_hw_clearcolor(rt_int(10), rt_int(14), rt_int(22));
    rt_hw_far(rt_int(900));
    rt_hw_fog(rt_int(0), rt_int(0));
    rt_hw_light(rt_float(0.55), rt_float(0.90), rt_float(0.42), rt_float(1.0));
    rt_hw_ortho(rt_float(g_正交));
    if (g_模式 == 1) {
        /* 正俯视：架在原点正上方 40 格，俯仰 -90 度看下去。
           z 给 0.1 而不是 0，避开创根号时的退化。 */
        rt_hw_camera(rt_float(0), rt_float(40), rt_float(0.1),
                     rt_float(0), rt_float(-1.5708));
    } else {
        rt_hw_camera(rt_float(9.5), rt_float(6.0), rt_float(9.5),
                     rt_float(3.93), rt_float(-0.40));
    }

    /* 地面：一整块很大的暗色板（大到看不见边，读作"无限地面"）+ 网格线。
       ⚠ hw.box 的 (x,y,z) 是**最小角**（draw_box 里 x1 = x + w），
       所以要让地面以原点为中心，x/z 必须传 -100，不能传 0——传 0 只会盖住
       +x+z 一个象限。同理 y 传 -1、h 传 1，顶面才落在 y=0，网格线才浮在它上面。
       （hw.sphere / hw.cyl 的 (x,y,z) 反而是中心，两套约定不一致，容易踩。）*/
    rt_hw_box(rt_int(-100), rt_int(-1), rt_int(-100),
              rt_int(200), rt_int(1), rt_int(200), rt_int(30), rt_int(36), rt_int(48));
    for (int g = -12; g <= 12; g++) {
        double p = g * 2.0;
        int R = 46, G = 132, B = 92;
        if (g == 0) { R = 214; G = 78; B = 78; }          /* 沿 z 的线，p=0 即 z 轴 → 红 */
        rt_hw_line(rt_float(p), rt_float(0.02), rt_float(-24),
                   rt_float(p), rt_float(0.02), rt_float(24),
                   rt_int(R), rt_int(G), rt_int(B));
        R = 46; G = 132; B = 92;
        if (g == 0) { R = 74; G = 118; B = 232; }         /* 沿 x 的线，p=0 即 x 轴 → 蓝 */
        rt_hw_line(rt_float(-24), rt_float(0.02), rt_float(p),
                   rt_float(24), rt_float(0.02), rt_float(p),
                   rt_int(R), rt_int(G), rt_int(B));
    }

    /* 左前：球 */
    rt_hw_sphere(rt_float(-5.5), rt_float(2.2), rt_float(-5.0), rt_float(2.2),
                 rt_int(236), rt_int(120), rt_int(96));

    /* 左后：圆柱 / 圆锥 / 六棱柱 */
    {
        Value a[10] = { rt_float(-5.5), rt_int(0), rt_float(3.5), rt_float(1.2), rt_int(4),
                        rt_float(1.2), rt_int(24), rt_int(120), rt_int(200), rt_int(235) };
        rt_hw_cylv(10, a);
    }
    {
        Value a[10] = { rt_float(-1.0), rt_int(0), rt_float(3.5), rt_float(1.6), rt_int(3),
                        rt_int(0), rt_int(24), rt_int(210), rt_int(190), rt_int(120) };
        rt_hw_cylv(10, a);
    }
    {
        Value a[10] = { rt_float(3.5), rt_int(0), rt_float(3.5), rt_float(1.1), rt_int(3),
                        rt_float(1.1), rt_int(6), rt_int(150), rt_int(225), rt_int(150) };
        rt_hw_cylv(10, a);
    }

    /* 中间：桌子 > 托盘 > 杯子（三层父子，角度写死；顺手验层级和着色器共存）*/
    rt_hw_push(rt_int(0), rt_int(0), rt_int(0), rt_int(0), rt_float(0.60), rt_int(0));
    rt_hw_box(rt_float(-2.4), rt_float(2.6), rt_float(-1.6),
              rt_float(4.8), rt_float(0.4), rt_float(3.2),
              rt_int(170), rt_int(122), rt_int(74));
    rt_hw_box(rt_float(-2.2), rt_int(0), rt_float(-1.4),
              rt_float(0.5), rt_float(2.6), rt_float(0.5),
              rt_int(128), rt_int(90), rt_int(54));
    rt_hw_box(rt_float(1.7), rt_int(0), rt_float(-1.4),
              rt_float(0.5), rt_float(2.6), rt_float(0.5),
              rt_int(128), rt_int(90), rt_int(54));

    rt_hw_push(rt_int(0), rt_int(3), rt_int(0), rt_int(0), rt_float(1.20), rt_int(0));
    {
        Value a[10] = { rt_int(0), rt_int(0), rt_int(0), rt_float(1.4), rt_float(0.3),
                        rt_float(1.4), rt_int(20), rt_int(205), rt_int(168), rt_int(92) };
        rt_hw_cylv(10, a);
    }

    rt_hw_push(rt_float(0.8), rt_float(0.3), rt_int(0), rt_int(0), rt_float(1.80), rt_int(0));
    {
        Value a[10] = { rt_int(0), rt_int(0), rt_int(0), rt_float(0.5), rt_int(1),
                        rt_float(0.5), rt_int(16), rt_int(240), rt_int(240), rt_int(246) };
        rt_hw_cylv(10, a);
    }
    rt_hw_sphere(rt_int(0), rt_int(1), rt_int(0), rt_float(0.5),
                 rt_int(240), rt_int(240), rt_int(246));
    rt_hw_pop();

    rt_hw_push(rt_float(-0.7), rt_float(0.3), rt_float(0.5), rt_int(0), rt_float(-1.50), rt_int(0));
    {
        Value a[10] = { rt_int(0), rt_int(0), rt_int(0), rt_float(0.4), rt_float(0.9),
                        rt_float(0.4), rt_int(16), rt_int(180), rt_int(212), rt_int(242) };
        rt_hw_cylv(10, a);
    }
    rt_hw_pop();

    rt_hw_pop();
    rt_hw_pop();

    /* 右：立方体 */
    rt_hw_push(rt_float(6.5), rt_float(2.5), rt_int(0), rt_int(0), rt_float(0.42), rt_int(0));
    rt_hw_box(rt_float(-1.5), rt_float(-1.5), rt_float(-1.5),
              rt_int(3), rt_int(3), rt_int(3), rt_int(255), rt_int(255), rt_int(255));
    rt_hw_pop();
}

/* 把整个文件读成 C 字符串（给 hw.shader 用） */
static char *读文件(const char *路径)
{
    FILE *f = fopen(路径, "rb");
    if (!f) { printf("** 读不到 %s\n", 路径); return NULL; }
    fseek(f, 0, SEEK_END);
    long n = ftell(f);
    fseek(f, 0, SEEK_SET);
    char *s = (char *)malloc((size_t)n + 1);
    if (!s) { fclose(f); return NULL; }
    size_t got = fread(s, 1, (size_t)n, f);
    s[got] = '\0';
    fclose(f);
    return s;
}

int main(int argc, char **argv)
{
    if (argc > 1) g_out = argv[1];

    rt_hw_open(rt_int(W), rt_int(H), rt_str("PYbook shot"));
    printf("GL_VERSION %s\n", (const char *)glGetString(GL_VERSION));

    const char *名字[6] = { "lambert", "toon", "fresnel", "checker", "normal", "unlit" };

    /* ① 固定管线 */
    rt_hw_shaderuse(rt_int(0));
    printf("\n[0] 固定管线\n");
    两帧出图("shot_0_fixed");

    /* ② 六个内置着色器装进 1..6 号槽，各出一张 */
    for (int i = 0; i < 6; i++) {
        Value r = rt_hw_preset(rt_int(1), rt_str(名字[i]));
        printf("\n[%d] %s  装载=%lld\n", i + 1, 名字[i], rt_to_ll(r));
        if (rt_to_ll(r) != 1) continue;
        rt_hw_shaderuse(rt_int(1));
        两帧出图((char *[]){ "shot_1_lambert", "shot_2_toon", "shot_3_fresnel",
                             "shot_4_checker", "shot_5_normal", "shot_6_unlit" }[i]);
    }

    /* ③ 自定义全息着色器（读 .vert/.frag，验 file.read 那条路） */
    char *vs = 读文件("_demo_glsl.vert");
    char *fs = 读文件("_demo_glsl.frag");
    if (vs && fs) {
        Value ok = rt_hw_shader(rt_int(7), rt_str(vs), rt_str(fs));
        printf("\n[7] 自定义全息  装载=%lld\n", rt_to_ll(ok));
        if (rt_to_ll(ok) == 1) {
            rt_hw_shaderuse(rt_int(7));
            Value u1[2] = { rt_str("uBoost"), rt_float(0.62) };
            rt_hw_univ(2, u1);
            Value u2[2] = { rt_str("uSteps"), rt_float(4.0) };
            rt_hw_univ(2, u2);
            Value u3[4] = { rt_str("uColorA"), rt_float(0.10), rt_float(0.55), rt_float(1.00) };
            rt_hw_univ(4, u3);
            Value u4[4] = { rt_str("uColorB"), rt_float(0.70), rt_float(0.95), rt_float(1.00) };
            rt_hw_univ(4, u4);
            Value u5[2] = { rt_str("uScan"), rt_float(4.0) };
            rt_hw_univ(2, u5);
            Value u6[2] = { rt_str("uTime"), rt_float(2.4) };
            rt_hw_univ(2, u6);
            两帧出图("shot_7_holo");
        }
    }
    free(vs); free(fs);

    /* ④ 正交投影（hw.ortho）：同一份场景，换投影看差别。
       正俯视 + 正交 = 编辑器顶部俯视图；正俯视 + 透视 = 对照组（近大远小）。 */
    rt_hw_shaderuse(rt_int(0));

    g_模式 = 0; g_正交 = 10.0;
    printf("\n[8] 正交 · 3/4 视角（半高 10）\n");
    两帧出图("shot_8_ortho34");

    g_模式 = 1; g_正交 = 20.0;
    printf("\n[9] 正交 · 正俯视（半高 20）—— 编辑器俯视图\n");
    两帧出图("shot_9_ortho_top");

    g_模式 = 1; g_正交 = 0.0;
    printf("\n[10] 透视 · 正俯视（对照组）\n");
    两帧出图("shot_10_persp_top");

    /* 负数半高应被钳成 0（= 透视）：出图须与 shot_10 逐字节相同，
       用来验 hw.ortho 的边界处理。 */
    g_模式 = 1; g_正交 = -5.0;
    printf("\n[11] 负半高 -5（应钳成 0 = 透视，须与 shot_10 相同）\n");
    两帧出图("shot_11_negclamp");

    g_模式 = 0; g_正交 = 0.0;          /* 复位，别影响后续 */


    printf("\n完成，输出目录 %s\n", g_out);
    return 0;
}
