# -*- coding: utf-8 -*-
"""打 PYbook 1.0.4 发布包。

包含策略沿用 1.0.3（整个目录 + 顶层文件夹名 pybook-1.0.4，排除 .git），
但**必须额外剔除会在 git push 时爆 GitHub 100MB 上限的构建产物**：
  · app_*.exe   351 个 / 166MB —— pybk_code.py 每次编译残留的 exe
  · 旧发布包 zip  92MB
  · __pycache__ / out_*.c / rt_cache/*.o —— 全部可重建
不剔除的话包会到 200MB 以上，push 直接被 GitHub 拒绝。
"""
import io
import os
import sys
import zipfile
import fnmatch

SRC = r'C:\Users\zhuli\Desktop\pybook'
DST = r'C:\Users\zhuli\Desktop\pybook官网\pybook-1.0.4.zip'
TOP = 'pybook-1.0.4'

# 目录名精确排除
#  · .git / __pycache__ / rt_cache          —— 可重建
#  · 发布打包_102                            —— 1.0.2 独立发布留下的暂存目录，
#                                              里面塞了整套 mingw64 工具链（cc1.exe 36MB、
#                                              lto1.exe 35MB、.a/.h 240MB，共 ~400MB）。
#                                              1.0.3 的发布包就没有它（实测包里 gcc/mingw 0 命中），
#                                              本版沿用：包只自带 SDL2，gcc 需系统 PATH 上有。
SKIP_DIRS = {'.git', '__pycache__', 'rt_cache', 'node_modules',
             '.trae-html-share-packages', '发布打包_102'}
# 文件名通配符排除
SKIP_FILES = [
    'app_*.exe',            # 编译残留 exe（最大头）
    '_shot.exe',            # 出图探针的编译产物（.c 在包里，可自行重建）
    'pybook-*.zip',         # 旧发布包
    'out_*.c',              # 生成的 C
    '*.o',                  # 目标文件
    '_glsl_smoke_report.txt',
    '_ortho_smoke_report.txt',
    '.DS_Store',
    'Thumbs.db',
    # 本地音乐素材（没有被任何程序引用，不属于语言发布包）
    'E3旋律.wav',
    'ItBoTime_旋律.wav',
    'ItBoTime_贝斯.wav',
]

def skip(name):
    for p in SKIP_FILES:
        if fnmatch.fnmatch(name, p):
            return True
    return False

kept, skipped_big, skipped_n = 0, 0, 0
skipped_bytes = 0

if os.path.exists(DST):
    os.remove(DST)

with zipfile.ZipFile(DST, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for root, dirs, files in os.walk(SRC):
        dirs[:] = [d for d in dirs if d not in SKIP_DIRS]
        for f in files:
            full = os.path.join(root, f)
            rel = os.path.relpath(full, SRC).replace('\\', '/')
            if skip(f):
                skipped_n += 1
                try:
                    skipped_bytes += os.path.getsize(full)
                except OSError:
                    pass
                continue
            z.write(full, TOP + '/' + rel)
            kept += 1

size = os.path.getsize(DST)
mb = size / 1024 / 1024
print('打进包的文件   : %d' % kept)
print('剔除的文件     : %d（%.1f MB）' % (skipped_n, skipped_bytes / 1024 / 1024))
print('pybook-1.0.4.zip: %.1f MB' % mb)

if mb > 95:
    sys.stderr.write('\n** 超过 95MB，GitHub push 会失败！需要再剔除东西。**\n')
    sys.exit(1)

# ---------- 验收：包里必须有这些关键文件，且关键源码是新的 ----------
MUST = [
    'pybk_front.py', 'pybk_code.py', 'pybk_bc.py', 'pybk_main.py', 'pybk_build.py',
    'pybook_hw3d.c', 'pybook_rt.c', 'pybook_lib.h',
    'CHANGELOG.md', 'PYBOOK_AI.md', 'PYbookIDE.exe',
    'SDL2.dll', 'ucrt64/include/SDL2/SDL.h',
    '3D演示.pybk',
]
z = zipfile.ZipFile(DST)
names = set(z.namelist())
missing = [m for m in MUST if (TOP + '/' + m) not in names]
print('\n关键文件检查：', '全在 ✓' if not missing else '**缺 %s**' % missing)

# 关键源码必须含本次新东西
checks = [
    ('pybook_hw3d.c', b'rt_hw_preset', 'GLSL 可编程管线'),
    ('pybook_hw3d.c', b'rt_hw_tex', '贴图'),
    ('pybook_hw3d.c', b'rt_hw_push', '父子层级'),
    ('pybook_hw3d.c', b'hw_gl_load', 'GL 2.0+ 入口加载'),
    ('pybk_front.py', "'hw.preset': 2", '前端注册 hw.preset'),
    ('pybk_front.py', "'hw.uni': 2", '前端注册 hw.uni'),
    ('pybk_code.py', 'rt_hw_univ', 'C 后端映射 hw.uni'),
    ('CHANGELOG.md', '1.0.4', 'CHANGELOG 1.0.4'),
]
bad = []
for path, needle, label in checks:
    data = z.read(TOP + '/' + path)
    nd = needle.encode('utf-8') if isinstance(needle, str) else needle
    if nd not in data:
        bad.append(label)
print('包内新特性检查：', '全部命中 ✓' if not bad else '**没命中: %s**' % bad)
print('\n结论：', '打包成功' if (not missing and not bad and mb <= 95) else '**有问题**')
