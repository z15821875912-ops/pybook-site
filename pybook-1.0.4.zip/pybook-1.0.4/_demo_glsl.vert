// 自定义着色器 · 顶点阶段（hw.shader 用 file.read 读进来）
// 约定参数：见 pybook_hw3d.c 里 hw.shader 的注释。
// 关键点：GLSL 用 #version 120，兼容 profile 下 gl_* 内建量由立即模式自动喂进来，
// 所以不用 VBO、不用 layout(location=...)，现有 glBegin 几何直接吃。
#version 120

varying vec3 vN;      // 视空间法线（gl_NormalMatrix 已作用过）
varying vec3 vC;      // 顶点本色（hw.box/sphere/cyl 的 r,g,b）
varying vec2 vUV;     // 纹理坐标（hw.uv 的平铺已经乘在里面）
varying vec3 vEye;    // 视空间位置（算菲涅尔和扫描线要用）

void main(){
  vN  = gl_NormalMatrix * gl_Normal;
  vC  = gl_Color.rgb;
  vUV = gl_MultiTexCoord0.xy;
  vEye = (gl_ModelViewMatrix * gl_Vertex).xyz;
  gl_Position = gl_ModelViewProjectionMatrix * gl_Vertex;
}
