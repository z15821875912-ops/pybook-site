/* PYbook 3D_highway 引擎 · OpenGL 真驱动版
 * 接口：
 *   hw.open(w,h,title)  hw.clearcolor(r,g,b)  hw.camera(x,y,z,yaw,pitch)
 *   hw.box(x,y,z,w,h,d,r,g,b) / (..., 绕x,绕y,绕z)   盒
 *   hw.sphere(x,y,z,半径,r,g,b)                      球
 *   hw.cyl(x,y,z,下半径,高,上半径,[边数,]r,g,b)       圆柱/圆锥
 *   hw.line(x1,y1,z1,x2,y2,z2,r,g,b)                 线段
 *   hw.light(方向x,方向y,方向z,强度)                  方向光
 *   hw.tex(槽,路径)  hw.texuse(槽)  hw.uv(重复)        贴图
 *   hw.push(x,y,z, 绕x,绕y,绕z)  hw.pop()              父子层级
 *   hw.fog(起,止)  hw.far(距离)  hw.fov(角度)  hw.near(距离)  hw.wire(0/1)
 *   --- 可编程管线（GLSL）：不指定就照旧走固定管线，老程序零改动 ---
 *   hw.preset(槽,名字)  hw.shader(槽,顶点源码,片段源码)  hw.shaderuse(槽)  hw.uni(名,值...)
 *   hw.frame()  hw.end()
 *   hw.key(name)  hw.hit(name)  hw.mx()  hw.my()  hw.mdown()  hw.mhit()
 *   hw.text(x,y,size,str)  hw.grab()  hw.free()  hw.mdx()  hw.mdy()
 *
 * 渲染：SDL 窗口 + OpenGL 固定管线（系统 opengl32.dll，零新增依赖）
 *   · 真 z-buffer 深度测试（告别画家排序的穿面瑕疵）
 *   · 硬件线性雾（GL_FOG）
 *   · 面明暗：按法线做方向光（Lambert + 环境光），hw.light 可调方向与强度
 *   · 球/柱：GL_TRIANGLE_STRIP/FAN 硬写细分，每帧共用一张 sin/cos 表
 *   · 文字：stb_truetype 光栅化 → GL 纹理 → 正交覆盖层（带缓存）
 * 坐标系：x 右 · y 上 · z 前方随 yaw；相机看向 (cos yaw, 0, sin yaw)。 */

#include "pybook_lib.h"

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#define SDL_MAIN_HANDLED
#include <SDL2/SDL.h>
#include <GL/gl.h>

/* 只取声明：stbtt_* 的实现由 pybook_rt.c 提供（全局符号，直接链接） */
#include "stb_truetype.h"
/* 同理：stbi_* 的实现也在 pybook_rt.c（"游戏.图"那套），这里只要声明。
   所以 hw.tex 能加载 png/jpg/bmp/tga，且零新增依赖。 */
#include "stb_image.h"

#include <windows.h>            /* MultiByteToWideChar：中文路径转 UTF-16 */

/* GL 2.0+ 的入口类型（PFNGL*PROC）。
   windows.h 必须先到位：glext.h 里的 APIENTRYP 依赖 APIENTRY 展开成 __stdcall。
   这里只要类型声明，不要原型 —— 入口全靠 SDL_GL_GetProcAddress 运行时取。 */
#include <GL/glext.h>

/* ================= 数值解码 ================= */

#include <stdarg.h>

/* 运行时错误出口（rt_die 是 pybook_rt.c 的私有函数，这里自备一份） */
static void hw_die(const char *fmt, ...)
{
    va_list ap;
    fprintf(stderr, "运行时错误: ");
    va_start(ap, fmt);
    vfprintf(stderr, fmt, ap);
    va_end(ap);
    fputc('\n', stderr);
    exit(1);
}

static double hw_num(Value v, const char *who)
{
    if (IS_FLT(v))
        return AS_FLT(v);
    if (IS_INT(v) || IS_BIGINT(v))
        return (double)rt_to_ll(v);
    if (IS_BOOL(v))
        return (double)AS_BOOL(v);
    hw_die("%s 需要数字参数", who);
    return 0;
}

static const char *hw_str(Value v, const char *who)
{
    if (IS_STR(v))
        return AS_STR(v) ? AS_STR(v) : "";
    hw_die("%s 需要文本参数", who);
    return "";
}

static int hw_u8(int x)
{
    return x < 0 ? 0 : x > 255 ? 255 : x;
}

/* ================= GL 2.0+ 入口加载（可编程管线的地基） =================
   血泪教训：Windows 的 opengl32.dll 只导出 GL 1.1 —— glCreateShader 这些
   GL 2.0+ 的入口在链接期根本找不到原型符号，必须用 SDL_GL_GetProcAddress
   在运行时取函数指针（_gl120_probe.c 实测：驱动真实版本是 OpenGL 4.6
   兼容 profile，GLSL 120 和 330 都能编译）。
   所以"用不了着色器"从来不是能力问题，只是缺这一张表。
   类型来自 <GL/glext.h>，活动工具链自带，不需要 GLEW / glad。 */
typedef struct {
    /* 着色器编译 / 链接 */
    PFNGLCREATESHADERPROC       CreateShader;
    PFNGLSHADERSOURCEPROC       ShaderSource;
    PFNGLCOMPILESHADERPROC      CompileShader;
    PFNGLGETSHADERIVPROC        GetShaderiv;
    PFNGLGETSHADERINFOLOGPROC   GetShaderInfoLog;
    PFNGLDELETESHADERPROC       DeleteShader;
    PFNGLCREATEPROGRAMPROC      CreateProgram;
    PFNGLATTACHSHADERPROC       AttachShader;
    PFNGLLINKPROGRAMPROC        LinkProgram;
    PFNGLGETPROGRAMIVPROC       GetProgramiv;
    PFNGLGETPROGRAMINFOLOGPROC  GetProgramInfoLog;
    PFNGLUSEPROGRAMPROC         UseProgram;
    PFNGLDELETEPROGRAMPROC      DeleteProgram;
    /* uniform */
    PFNGLGETUNIFORMLOCATIONPROC GetUniformLocation;
    PFNGLUNIFORM1FPROC          Uniform1f;
    PFNGLUNIFORM2FPROC          Uniform2f;
    PFNGLUNIFORM3FPROC          Uniform3f;
    PFNGLUNIFORM4FPROC          Uniform4f;
    PFNGLUNIFORM1IPROC          Uniform1i;
    PFNGLACTIVETEXTUREPROC      ActiveTexture;
    /* 预先取好，留给下一步（阴影贴图 / 后处理）—— 本版暂不使用 */
    PFNGLGENFRAMEBUFFERSPROC        GenFramebuffers;
    PFNGLBINDFRAMEBUFFERPROC        BindFramebuffer;
    PFNGLFRAMEBUFFERTEXTURE2DPROC   FramebufferTexture2D;
    PFNGLCHECKFRAMEBUFFERSTATUSPROC CheckFramebufferStatus;
    PFNGLGENRENDERBUFFERSPROC       GenRenderbuffers;
    PFNGLBINDRENDERBUFFERPROC       BindRenderbuffer;
    PFNGLRENDERBUFFERSTORAGEPROC    RenderbufferStorage;
} HwGL;

static HwGL glapi;
static int  g_gl_ok    = 0;   /* 着色器那条路必需的入口是否齐了 */
static int  g_gl_tried = 0;   /* 只在建好上下文后加载一次 */

static void hw_gl_load(void)
{
    if (g_gl_tried)
        return;
    g_gl_tried = 1;
#define HW_GET(field, pfn, name) glapi.field = (pfn)SDL_GL_GetProcAddress(name)
    HW_GET(CreateShader,          PFNGLCREATESHADERPROC,       "glCreateShader");
    HW_GET(ShaderSource,          PFNGLSHADERSOURCEPROC,       "glShaderSource");
    HW_GET(CompileShader,         PFNGLCOMPILESHADERPROC,      "glCompileShader");
    HW_GET(GetShaderiv,           PFNGLGETSHADERIVPROC,        "glGetShaderiv");
    HW_GET(GetShaderInfoLog,      PFNGLGETSHADERINFOLOGPROC,   "glGetShaderInfoLog");
    HW_GET(DeleteShader,          PFNGLDELETESHADERPROC,       "glDeleteShader");
    HW_GET(CreateProgram,         PFNGLCREATEPROGRAMPROC,      "glCreateProgram");
    HW_GET(AttachShader,          PFNGLATTACHSHADERPROC,       "glAttachShader");
    HW_GET(LinkProgram,           PFNGLLINKPROGRAMPROC,        "glLinkProgram");
    HW_GET(GetProgramiv,          PFNGLGETPROGRAMIVPROC,       "glGetProgramiv");
    HW_GET(GetProgramInfoLog,     PFNGLGETPROGRAMINFOLOGPROC,  "glGetProgramInfoLog");
    HW_GET(UseProgram,            PFNGLUSEPROGRAMPROC,         "glUseProgram");
    HW_GET(DeleteProgram,         PFNGLDELETEPROGRAMPROC,      "glDeleteProgram");
    HW_GET(GetUniformLocation,    PFNGLGETUNIFORMLOCATIONPROC, "glGetUniformLocation");
    HW_GET(Uniform1f,             PFNGLUNIFORM1FPROC,          "glUniform1f");
    HW_GET(Uniform2f,             PFNGLUNIFORM2FPROC,          "glUniform2f");
    HW_GET(Uniform3f,             PFNGLUNIFORM3FPROC,          "glUniform3f");
    HW_GET(Uniform4f,             PFNGLUNIFORM4FPROC,          "glUniform4f");
    HW_GET(Uniform1i,             PFNGLUNIFORM1IPROC,          "glUniform1i");
    HW_GET(ActiveTexture,         PFNGLACTIVETEXTUREPROC,      "glActiveTexture");
    HW_GET(GenFramebuffers,       PFNGLGENFRAMEBUFFERSPROC,    "glGenFramebuffers");
    HW_GET(BindFramebuffer,       PFNGLBINDFRAMEBUFFERPROC,    "glBindFramebuffer");
    HW_GET(FramebufferTexture2D,  PFNGLFRAMEBUFFERTEXTURE2DPROC, "glFramebufferTexture2D");
    HW_GET(CheckFramebufferStatus, PFNGLCHECKFRAMEBUFFERSTATUSPROC, "glCheckFramebufferStatus");
    HW_GET(GenRenderbuffers,      PFNGLGENRENDERBUFFERSPROC,   "glGenRenderbuffers");
    HW_GET(BindRenderbuffer,      PFNGLBINDRENDERBUFFERPROC,   "glBindRenderbuffer");
    HW_GET(RenderbufferStorage,   PFNGLRENDERBUFFERSTORAGEPROC, "glRenderbufferStorage");
#undef HW_GET
    g_gl_ok = (glapi.CreateShader && glapi.ShaderSource && glapi.CompileShader &&
               glapi.GetShaderiv && glapi.DeleteShader && glapi.CreateProgram &&
               glapi.AttachShader && glapi.LinkProgram && glapi.GetProgramiv &&
               glapi.UseProgram && glapi.DeleteProgram &&
               glapi.GetUniformLocation && glapi.Uniform1f && glapi.Uniform3f) ? 1 : 0;
}

/* ================= 状态 ================= */

static SDL_Window   *g_win = NULL;
static SDL_GLContext g_gl = NULL;
static int    g_w = 0, g_h = 0;
static Uint32 g_winid = 0;
static int    g_quit = 0;

static double g_camx, g_camy, g_camz, g_yaw, g_pitch;
static double g_sky_r = 110, g_sky_g = 160, g_sky_b = 255;
/* 雾与视距（hw.fog 可调）：编辑器等近景场景需要把雾推远或关掉 */
static double g_fog_start = 300.0, g_fog_end = 1500.0, g_far = 1600.0;
/* 线框模式：hw.wire(1) 后所有盒子画成描边（编辑器看结构很实用） */
static int    g_wire = 0;
/* 视口参数（hw.fov / hw.near 可调）：
   fovy 默认 70°（原硬编码值），near 默认 1.0。
   编辑器想要 45° 紧凑视角、或近处物体被裁掉，就分别调这两个。 */
static double g_fovy = 70.0;
static double g_near = 1.0;
/* 正交投影：0 = 透视（默认），> 0 = 正交，值是视野竖直半高（世界单位）。 */
static double g_ortho = 0.0;

static Uint8 g_kprev[SDL_NUM_SCANCODES], g_kcur[SDL_NUM_SCANCODES];
static int   g_mprev = 0, g_mcur = 0;

/* 贴图槽：hw.tex(槽,路径) 加载，hw.texuse(槽) 选择。槽 0 表示不用贴图。
   每张图上传成 GL 纹理；hw.uv(重复) 靠 GL_REPEAT 平铺。
   光照不用额外处理：GL_MODULATE 让顶点色（已含方向光）直接乘在贴图上。 */
#define HW_TEX_SLOTS 8
static GLuint g_texs[HW_TEX_SLOTS];
static int    g_texw[HW_TEX_SLOTS], g_texh[HW_TEX_SLOTS];
static int    g_curtex = 0;      /* 当前贴图槽（提交图元时记进图元里） */
static float  g_curuv  = 1.0f;   /* 当前 UV 重复次数 */

/* ---- 可编程管线（GLSL）----
   槽 0 = "不用着色器" → 走原来的固定管线（老程序零改动）。槽 1~7 放程序。
   着色器约定用 GLSL #version 120：兼容 profile 下 gl_Vertex / gl_Normal /
   gl_Color / gl_MultiTexCoord0 / gl_ModelViewProjectionMatrix / gl_NormalMatrix
   都由立即模式自动喂进来 —— 现有 glBegin 几何一行都不用改成 VBO。 */
#define HW_SHADER_SLOTS 8
static GLuint g_progs[HW_SHADER_SLOTS];
static GLint  g_ulight[HW_SHADER_SLOTS];  /* 每个程序里 uLight 的位置缓存 */
static int    g_curprog    = 0;   /* 帧开始时绑哪个程序（shaderuse 最后一次） */
static GLuint g_bound_prog = 0;   /* 当前真正 UseProgram 着的（0 = 固定管线） */
static GLuint g_white_tex  = 0;   /* 1x1 白纹理：着色器模式没贴图时顶上去 */

/* uniform 也走命令流：hw.uni 追加一条 OP_UNI，按脚本顺序生效。
   kind = 分量个数（1 → float，2/3/4 → vec2/vec3/vec4）。 */
#define HW_UNI_MAX 4096
typedef struct {
    char  name[64];
    int   kind;
    float v[4];
    GLint  loc;        /* 位置缓存：同一个程序只查一次 */
    GLuint loc_prog;
} HwUni;
static HwUni g_unis[HW_UNI_MAX];
static int   g_nunis = 0;

/* 场景表 */
#define HW_BOX_MAX 16384
typedef struct {
    float x, y, z, w, h, d;
    unsigned char r, g, b;
    float rx, ry, rz;      /* 绕自身中心的旋转（弧度，度序 XYZ）—— 0 即不转 */
    int   tex;             /* 贴图槽（0 = 纯色） */
    float uv;              /* UV 重复次数 */
} HwBox;

/* 线段表：hw.line 用（gizmo / 辅助线 / 包围盒全靠它） */
#define HW_LINE_MAX 16384
typedef struct {
    float x1, y1, z1, x2, y2, z2;
    unsigned char r, g, b;
} HwLine;

/* 球：hw.sphere(x,y,z, 半径, r,g,b) —— 位置取中心，不是角点 */
#define HW_SPHERE_MAX 4096
typedef struct {
    float x, y, z, rad;
    unsigned char r, g, b;
    int   tex;
    float uv;
} HwSphere;

/* 圆柱/圆锥：hw.cyl(x,y,z, 半径下, 高度, 半径上, 边数, r,g,b)
   半径下 == 半径上 → 圆柱；半径上 == 0 → 圆锥；半径下 == 0 → 倒锥。 */
#define HW_CYL_MAX 4096
typedef struct {
    float x, y, z, rb, h, rt;
    int   seg;
    unsigned char r, g, b;
    int   tex;
    float uv;
} HwCyl;

static HwBox  g_boxes[HW_BOX_MAX];
static int    g_nboxes = 0;
static HwLine g_lines[HW_LINE_MAX];
static int    g_nlines = 0;
static HwSphere g_spheres[HW_SPHERE_MAX];
static int    g_nspheres = 0;
static HwCyl  g_cyls[HW_CYL_MAX];
static int    g_ncyls = 0;

/* ---- 命令流（op stream）----
   图元不再"按类型分批画"，而是按脚本提交的顺序画。
   这是父子层级的前提：push/pop 只有在顺序执行时才有语义。
   每个 op 只记「类型 + 数据下标」，数据本体仍在上面那些数组里。 */
enum { OP_BOX = 0, OP_SPHERE, OP_CYL, OP_LINE, OP_PUSH, OP_POP,
       OP_UNI,     /* 设一个 uniform */
       OP_PROG };  /* 切换着色器程序（槽 0 = 回固定管线） */
#define HW_OP_MAX 65536
typedef struct {
    int   type;
    int   idx;                  /* 数据数组下标（PUSH/POP 不用） */
    float px, py, pz;           /* PUSH：平移 */
    float rx, ry, rz;           /* PUSH：旋转（弧度） */
} HwOp;

static HwOp  g_ops[HW_OP_MAX];
static int   g_nops = 0;
static int   g_depth = 0;       /* push 深度（防 glPopMatrix 打空栈） */
#define HW_MAX_DEPTH 20

/* 追加一个"无变换参数"的 op */
static void hw_op(int type, int idx)
{
    if (g_nops >= HW_OP_MAX)
        hw_die("hw：单帧图元/变换数超过上限 %d", HW_OP_MAX);
    HwOp *o = &g_ops[g_nops++];
    o->type = type;
    o->idx  = idx;
    o->px = o->py = o->pz = 0.0f;
    o->rx = o->ry = o->rz = 0.0f;
}

/* 方向光：hw.light 设置。默认从右上前方打过来，模拟原来的"假光照"观感 */
static float  g_lx = 0.45f, g_ly = 0.80f, g_lz = 0.40f;   /* 已归一化的方向（指向光源） */
static float  g_lamb = 0.55f;    /* 环境光底 */
static float  g_ldiff = 0.45f;   /* 漫反射强度 */

/* 键名 → 扫描码 */
static SDL_Scancode hw_scancode(const char *n)
{
    static const struct { const char *n; SDL_Scancode sc; } TAB[] = {
        {"right", SDL_SCANCODE_RIGHT}, {"left", SDL_SCANCODE_LEFT},
        {"up", SDL_SCANCODE_UP},       {"down", SDL_SCANCODE_DOWN},
        {"space", SDL_SCANCODE_SPACE}, {"enter", SDL_SCANCODE_RETURN},
        {"esc", SDL_SCANCODE_ESCAPE},  {"shift", SDL_SCANCODE_LSHIFT},
        {"a", SDL_SCANCODE_A}, {"b", SDL_SCANCODE_B}, {"c", SDL_SCANCODE_C},
        {"d", SDL_SCANCODE_D}, {"e", SDL_SCANCODE_E}, {"f", SDL_SCANCODE_F},
        {"g", SDL_SCANCODE_G}, {"h", SDL_SCANCODE_H}, {"i", SDL_SCANCODE_I},
        {"j", SDL_SCANCODE_J}, {"k", SDL_SCANCODE_K}, {"l", SDL_SCANCODE_L},
        {"m", SDL_SCANCODE_M}, {"n", SDL_SCANCODE_N}, {"o", SDL_SCANCODE_O},
        {"p", SDL_SCANCODE_P}, {"q", SDL_SCANCODE_Q}, {"r", SDL_SCANCODE_R},
        {"s", SDL_SCANCODE_S}, {"t", SDL_SCANCODE_T}, {"u", SDL_SCANCODE_U},
        {"v", SDL_SCANCODE_V}, {"w", SDL_SCANCODE_W}, {"x", SDL_SCANCODE_X},
        {"y", SDL_SCANCODE_Y}, {"z", SDL_SCANCODE_Z},
    };
    if (n == NULL)
        return SDL_SCANCODE_UNKNOWN;
    for (size_t i = 0; i < sizeof TAB / sizeof TAB[0]; i++)
        if (strcmp(TAB[i].n, n) == 0)
            return TAB[i].sc;
    if (n[1] == '\0' && n[0] >= '0' && n[0] <= '9')
        return (SDL_Scancode)(SDL_SCANCODE_1 + (n[0] - '1'));
    /* 单字符符号键：编辑器要用 [ ] 调 FOV、- = 调近裁剪面 */
    if (n[1] == '\0') {
        switch (n[0]) {
        case '-': return SDL_SCANCODE_MINUS;
        case '=': return SDL_SCANCODE_EQUALS;
        case '[': return SDL_SCANCODE_LEFTBRACKET;
        case ']': return SDL_SCANCODE_RIGHTBRACKET;
        case ',': return SDL_SCANCODE_COMMA;
        case '.': return SDL_SCANCODE_PERIOD;
        case '/': return SDL_SCANCODE_SLASH;
        case ';': return SDL_SCANCODE_SEMICOLON;
        case '\'': return SDL_SCANCODE_APOSTROPHE;
        case '\\': return SDL_SCANCODE_BACKSLASH;
        case '`': return SDL_SCANCODE_GRAVE;
        default: break;
        }
    }
    return SDL_SCANCODE_UNKNOWN;
}

/* ================= 字体（stb_truetype，静态副本独立于 pybook_rt.c） ================= */

static stbtt_fontinfo g_font;
static unsigned char *g_font_data = NULL;
static int g_font_ok = 0;

static void font_init(void)
{
    static const char *CAND[] = {
        "C:\\Windows\\Fonts\\msyh.ttc", "C:\\Windows\\Fonts\\msyh.ttf",
        "C:\\Windows\\Fonts\\simhei.ttf", "C:\\Windows\\Fonts\\simsun.ttc",
    };
    if (g_font_ok)
        return;
    for (int i = 0; i < 4; i++) {
        FILE *fp = fopen(CAND[i], "rb");
        if (fp == NULL)
            continue;
        fseek(fp, 0, SEEK_END);
        long n = ftell(fp);
        fseek(fp, 0, SEEK_SET);
        unsigned char *buf = (unsigned char *)malloc((size_t)n);
        if (buf != NULL && fread(buf, 1, (size_t)n, fp) == (size_t)n) {
            int off = stbtt_GetFontOffsetForIndex(buf, 0);
            if (off >= 0 && stbtt_InitFont(&g_font, buf, off)) {
                g_font_data = buf;   /* 常驻：光栅化还要读 */
                g_font_ok = 1;
                fclose(fp);
                return;
            }
        }
        free(buf);
        fclose(fp);
    }
    hw_die("hw.text：找不到系统中文字体（msyh/simhei/simsun）");
}

static unsigned utf8_at(const char *s, int i, int *adv)
{
    unsigned char c = (unsigned char)s[i];
    unsigned cp = c;
    *adv = 1;
    if (c >= 0xF0) {
        cp = ((c & 7u) << 18) | ((s[i+1] & 63u) << 12) | ((s[i+2] & 63u) << 6) | (s[i+3] & 63u);
        *adv = 4;
    } else if (c >= 0xE0) {
        cp = ((c & 15u) << 12) | ((s[i+1] & 63u) << 6) | (s[i+2] & 63u);
        *adv = 3;
    } else if (c >= 0xC0) {
        cp = ((c & 31u) << 6) | (s[i+1] & 63u);
        *adv = 2;
    }
    return cp;
}

/* 文字纹理缓存：键 = 字号|文本 */
#define TXT_MAX 256
typedef struct { char *key; GLuint tex; int w, h; } TxtEnt;
static TxtEnt g_txt[TXT_MAX];
static int g_ntxt = 0;

static GLuint text_texture(const char *s, int px, int *ow, int *oh)
{
    font_init();
    if (px < 6)  px = 6;
    if (px > 200) px = 200;
    char head[32];
    snprintf(head, sizeof head, "%d|", px);
    size_t klen = strlen(head) + strlen(s) + 1;
    char *key = (char *)malloc(klen);
    if (key == NULL)
        hw_die("hw.text：内存不足");
    snprintf(key, klen, "%s%s", head, s);

    GLuint tex = 0;
    for (int i = 0; i < g_ntxt; i++)
        if (strcmp(g_txt[i].key, key) == 0) {
            tex = g_txt[i].tex;
            *ow = g_txt[i].w;
            *oh = g_txt[i].h;
            free(key);
            return tex;
        }

    float scale = stbtt_ScaleForPixelHeight(&g_font, (float)px);
    int asc, desc, gap;
    stbtt_GetFontVMetrics(&g_font, &asc, &desc, &gap);
    int base = (int)(asc * scale) + 1;

    int W = 4;
    for (int i = 0; s[i];) {
        int adv = 1;
        unsigned cp = utf8_at(s, i, &adv);
        int a, l;
        stbtt_GetCodepointHMetrics(&g_font, (int)cp, &a, &l);
        W += (int)(a * scale) + 2;
        i += adv;
    }
    int H = px + 6;
    unsigned char *pix = (unsigned char *)calloc((size_t)W * H * 4, 1);
    if (pix == NULL)
        hw_die("hw.text：内存不足");
    int penx = 2;
    for (int i = 0; s[i];) {
        int adv = 1;
        unsigned cp = utf8_at(s, i, &adv);
        int bw, bh, ox, oy;
        unsigned char *bmp = stbtt_GetCodepointBitmap(&g_font, scale, scale,
                                                      (int)cp, &bw, &bh, &ox, &oy);
        if (bmp != NULL) {
            for (int j = 0; j < bh; j++) {
                int ty = base + oy + j;
                if (ty < 0 || ty >= H) continue;
                for (int k = 0; k < bw; k++) {
                    int tx = penx + ox + k;
                    if (tx < 0 || tx >= W) continue;
                    unsigned char *p = pix + ((size_t)ty * W + tx) * 4;
                    p[0] = 255; p[1] = 255; p[2] = 255;
                    p[3] = bmp[j * bw + k];
                }
            }
            stbtt_FreeBitmap(bmp, NULL);
        }
        int a, l;
        stbtt_GetCodepointHMetrics(&g_font, (int)cp, &a, &l);
        penx += (int)(a * scale);
        i += adv;
    }

    glGenTextures(1, &tex);
    glBindTexture(GL_TEXTURE_2D, tex);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, W, H, 0, GL_RGBA, GL_UNSIGNED_BYTE, pix);
    free(pix);

    if (g_ntxt == TXT_MAX) {          /* 满了逐出最旧 */
        glDeleteTextures(1, &g_txt[0].tex);
        free(g_txt[0].key);
        memmove(g_txt, g_txt + 1, sizeof(TxtEnt) * (TXT_MAX - 1));
        g_ntxt--;
    }
    g_txt[g_ntxt].key = key;
    g_txt[g_ntxt].tex = tex;
    g_txt[g_ntxt].w = W;
    g_txt[g_ntxt].h = H;
    g_ntxt++;
    *ow = W;
    *oh = H;
    return tex;
}

/* 文字队列（帧末统一画，保证浮在 3D 上） */
#define QTEXT_MAX 128
typedef struct { char *s; int x, y, size; } QText;
static QText g_qtext[QTEXT_MAX];
static int g_nqtext = 0;

/* ================= 事件 ================= */

static void pump(void)
{
    SDL_Event ev;
    while (SDL_PollEvent(&ev)) {
        if (ev.type == SDL_WINDOWEVENT && ev.window.event == SDL_WINDOWEVENT_CLOSE) {
            if (ev.window.windowID == g_winid) {
                SDL_SetRelativeMouseMode(SDL_FALSE);   /* 退出时还指针 */
                g_quit = 1;
            }
            continue;
        }
        if (ev.type == SDL_KEYDOWN && ev.key.keysym.scancode == SDL_SCANCODE_ESCAPE) {
            if (ev.key.windowID == 0 || ev.key.windowID == g_winid)
                g_quit = 1;
        }
    }
}

/* ================= 接口 ================= */

Value rt_hw_open(Value wv, Value hv, Value tv)
{
    long long w = (long long)hw_num(wv, "hw.open 的宽");
    long long h = (long long)hw_num(hv, "hw.open 的高");
    const char *title = hw_str(tv, "hw.open 的标题");
    SDL_SetMainReady();
    if (SDL_Init(SDL_INIT_VIDEO) != 0)
        hw_die("hw.open：SDL 初始化失败: %s", SDL_GetError());
    if (g_win != NULL) {              /* 重复开窗：先收旧的 */
        SDL_GL_DeleteContext(g_gl);
        SDL_DestroyWindow(g_win);
        g_gl = NULL;
        g_win = NULL;
    }
    SDL_GL_SetAttribute(SDL_GL_DOUBLEBUFFER, 1);
    SDL_GL_SetAttribute(SDL_GL_DEPTH_SIZE, 24);
    g_win = SDL_CreateWindow(title && *title ? title : "PYbook 3D",
                             SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
                             (int)w, (int)h,
                             SDL_WINDOW_SHOWN | SDL_WINDOW_RESIZABLE | SDL_WINDOW_OPENGL);
    if (g_win == NULL)
        hw_die("hw.open：创建窗口失败: %s", SDL_GetError());
    g_gl = SDL_GL_CreateContext(g_win);
    if (g_gl == NULL)
        hw_die("hw.open：创建 OpenGL 上下文失败: %s", SDL_GetError());
    g_w = (int)w;
    g_h = (int)h;
    g_winid = SDL_GetWindowID(g_win);
    g_quit = 0;
    g_nboxes = 0;
    g_nlines = 0;
    g_nqtext = 0;
    g_nspheres = 0;
    g_ncyls = 0;
    g_nops = 0;
    g_depth = 0;
    g_curtex = 0;
    g_curuv = 1.0f;
    /* 旧上下文的纹理随上下文一起销毁了，这里只清名字（不能 glDeleteTextures） */
    memset(g_texs, 0, sizeof g_texs);
    memset(g_texw, 0, sizeof g_texw);
    memset(g_texh, 0, sizeof g_texh);
    memset(g_kprev, 0, sizeof g_kprev);
    memset(g_kcur, 0, sizeof g_kcur);
    g_mprev = g_mcur = 0;
    /* 着色器状态：旧上下文的程序对象随上下文一起没了，只清名字 */
    memset(g_progs, 0, sizeof g_progs);
    for (int i = 0; i < HW_SHADER_SLOTS; i++)
        g_ulight[i] = -1;
    g_curprog = 0;
    g_bound_prog = 0;
    g_nunis = 0;
    g_white_tex = 0;
    hw_gl_load();                 /* 取 GL 2.0+ 入口（带上下文才取得到） */
    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_LEQUAL);
    return rt_none();
}

Value rt_hw_clearcolor(Value rv, Value gv, Value bv)
{
    g_sky_r = hw_num(rv, "hw.clearcolor 的 R");
    g_sky_g = hw_num(gv, "hw.clearcolor 的 G");
    g_sky_b = hw_num(bv, "hw.clearcolor 的 B");
    return rt_none();
}

Value rt_hw_camera(Value xv, Value yv, Value zv, Value yawv, Value pitchv)
{
    g_camx = hw_num(xv, "hw.camera 的 x");
    g_camy = hw_num(yv, "hw.camera 的 y");
    g_camz = hw_num(zv, "hw.camera 的 z");
    g_yaw  = hw_num(yawv, "hw.camera 的朝向");
    g_pitch = IS_NONE(pitchv) ? 0.0 : hw_num(pitchv, "hw.camera 的俯仰");
    return rt_none();
}

/* 旧签名 rt_hw_box(9 参) 保留为薄封装，内部转调带旋转的 rt_hw_boxn */
Value rt_hw_boxn(int nargs, Value *av)
{
    if (g_nboxes == HW_BOX_MAX)
        hw_die("hw.box：单帧盒子超过上限 %d", HW_BOX_MAX);
    HwBox *b = &g_boxes[g_nboxes++];
    b->x = (float)hw_num(av[0], "hw.box 的 x");
    b->y = (float)hw_num(av[1], "hw.box 的 y");
    b->z = (float)hw_num(av[2], "hw.box 的 z");
    b->w = (float)hw_num(av[3], "hw.box 的宽");
    b->h = (float)hw_num(av[4], "hw.box 的高");
    b->d = (float)hw_num(av[5], "hw.box 的深");
    b->r = (unsigned char)hw_u8((int)hw_num(av[6], "hw.box 的 R"));
    b->g = (unsigned char)hw_u8((int)hw_num(av[7], "hw.box 的 G"));
    b->b = (unsigned char)hw_u8((int)hw_num(av[8], "hw.box 的 B"));
    /* 可选：绕自身中心的旋转（弧度）。给 12 参即启用；0 表示不转。 */
    b->rx = (nargs >= 12) ? (float)hw_num(av[9],  "hw.box 的绕X") : 0.0f;
    b->ry = (nargs >= 12) ? (float)hw_num(av[10], "hw.box 的绕Y") : 0.0f;
    b->rz = (nargs >= 12) ? (float)hw_num(av[11], "hw.box 的绕Z") : 0.0f;
    /* 贴图取"提交时刻"的状态：之后改 hw.texuse 不影响已提交的图元 */
    b->tex = g_curtex;
    b->uv  = g_curuv;
    hw_op(OP_BOX, g_nboxes - 1);
    return rt_none();
}

Value rt_hw_box(Value xv, Value yv, Value zv, Value wv, Value hv, Value dv,
                Value rv, Value gv, Value bv)
{
    Value av[9] = { xv, yv, zv, wv, hv, dv, rv, gv, bv };
    return rt_hw_boxn(9, av);
}

Value rt_hw_text(Value xv, Value yv, Value sv, Value tv)
{
    if (g_nqtext == QTEXT_MAX)
        hw_die("hw.text：单帧文字超过上限 %d", QTEXT_MAX);
    QText *t = &g_qtext[g_nqtext++];
    t->x = (int)hw_num(xv, "hw.text 的 x");
    t->y = (int)hw_num(yv, "hw.text 的 y");
    t->size = (int)hw_num(sv, "hw.text 的字号");
    const char *s = hw_str(tv, "hw.text 的文本");
    t->s = strdup(s);                  /* 帧末释放 */
    return rt_none();
}

/* 方向光着色：法线 (nx,ny,nz) → 明暗系数。
   lambert = max(0, dot(n, L))，再混环境光。返回 [0, 1.6] 的乘子。 */
static float lit(float nx, float ny, float nz)
{
    /* 着色器模式：顶点色要让位给"纯反照率"。
       固定管线把光照烤进 gl_Color；可编程管线要用真法线在片元里算光照，
       所以这里返回 1.0 —— 送进 gl_Color 的就是图元本色，不会被重复乘一遍光。 */
    if (g_curprog != 0)
        return 1.0f;
    float d = nx * g_lx + ny * g_ly + nz * g_lz;
    if (d < 0.0f)
        d = 0.0f;
    return g_lamb + g_ldiff * d * 1.6f;
}

/* 画一个盒子：6 面 × 4 顶点（固定管线立即模式；深度测试管遮挡）
   每面按自身法线做方向光着色——这是真光照，不再是写死的 100%/62%/78%。 */
static void draw_box(const HwBox *b)
{
    float x0 = b->x,        y0 = b->y,        z0 = b->z;
    float x1 = b->x + b->w, y1 = b->y + b->h, z1 = b->z + b->d;
    GLfloat r = b->r / 255.0f, g = b->g / 255.0f, bl = b->b / 255.0f;

    /* 绕自身中心的旋转：把 8 个角点先移到中心坐标系，转完再移回去。
       用模型矩阵做，OpenGL 固定管线的 glTranslate/glRotate 即可。
       注意：旋转后法线也该跟着转，但盒子是轴对齐画 6 面（每面法线平行于轴），
       模型矩阵里的旋转会由 GL 自动作用到顶点；法线用的是"未旋转前"的面法线，
       所以这里额外用旋转矩阵把光方向反变换回物体空间，保证明暗跟着转。 */
    int rot = (b->rx != 0.0f || b->ry != 0.0f || b->rz != 0.0f);
    if (rot || g_wire)
        glPushMatrix();
    if (rot) {
        glTranslatef((x0 + x1) * 0.5f, (y0 + y1) * 0.5f, (z0 + z1) * 0.5f);
        glRotatef(b->rx * 57.29578f, 1.0f, 0.0f, 0.0f);
        glRotatef(b->ry * 57.29578f, 0.0f, 1.0f, 0.0f);
        glRotatef(b->rz * 57.29578f, 0.0f, 0.0f, 1.0f);
        glTranslatef(-(x0 + x1) * 0.5f, -(y0 + y1) * 0.5f, -(z0 + z1) * 0.5f);
    }

    if (g_wire) {
        /* 线框：12 条边，用亮化的本色描边 */
        glColor3f(r * 0.35f + 0.6f, g * 0.35f + 0.6f, bl * 0.35f + 0.6f);
        glNormal3f(0.0f, 1.0f, 0.0f);
        glBegin(GL_LINES);
        /* 底面 4 边 */
        glVertex3f(x0, y0, z0); glVertex3f(x1, y0, z0);
        glVertex3f(x1, y0, z0); glVertex3f(x1, y0, z1);
        glVertex3f(x1, y0, z1); glVertex3f(x0, y0, z1);
        glVertex3f(x0, y0, z1); glVertex3f(x0, y0, z0);
        /* 顶面 4 边 */
        glVertex3f(x0, y1, z0); glVertex3f(x1, y1, z0);
        glVertex3f(x1, y1, z0); glVertex3f(x1, y1, z1);
        glVertex3f(x1, y1, z1); glVertex3f(x0, y1, z1);
        glVertex3f(x0, y1, z1); glVertex3f(x0, y1, z0);
        /* 4 条竖边 */
        glVertex3f(x0, y0, z0); glVertex3f(x0, y1, z0);
        glVertex3f(x1, y0, z0); glVertex3f(x1, y1, z0);
        glVertex3f(x0, y0, z1); glVertex3f(x0, y1, z1);
        glVertex3f(x1, y0, z1); glVertex3f(x1, y1, z1);
        glEnd();
        glPopMatrix();
        return;
    }

    /* 六个面各算一次光照（法线固定为 ±X/±Y/±Z）。颜色用 clamp 防爆白。
       每个面发 (0,0)->(U,U) 的 UV：hw.uv(1) 是整张铺满一面，
       hw.uv(3) 就是 3x3 平铺（靠 GL_REPEAT）。
       GL_MODULATE 下顶点色会乘上贴图，所以"方向光 x 贴图"自动成立。 */
    float U = b->uv > 0.0f ? b->uv : 1.0f;
    float k;
    glBegin(GL_QUADS);
    /* 顶 (+Y) */
    k = lit(0.0f, 1.0f, 0.0f);
    glNormal3f(0.0f, 1.0f, 0.0f);              /* 着色器要用真法线（固定管线无视） */
    glColor3f(r * k > 1 ? 1 : r * k, g * k > 1 ? 1 : g * k, bl * k > 1 ? 1 : bl * k);
    glTexCoord2f(0, 0); glVertex3f(x0, y1, z0);
    glTexCoord2f(0, U); glVertex3f(x0, y1, z1);
    glTexCoord2f(U, U); glVertex3f(x1, y1, z1);
    glTexCoord2f(U, 0); glVertex3f(x1, y1, z0);
    /* 底 (-Y) */
    k = lit(0.0f, -1.0f, 0.0f);
    glNormal3f(0.0f, -1.0f, 0.0f);              /* 着色器要用真法线（固定管线无视） */
    glColor3f(r * k > 1 ? 1 : r * k, g * k > 1 ? 1 : g * k, bl * k > 1 ? 1 : bl * k);
    glTexCoord2f(0, 0); glVertex3f(x0, y0, z0);
    glTexCoord2f(U, 0); glVertex3f(x1, y0, z0);
    glTexCoord2f(U, U); glVertex3f(x1, y0, z1);
    glTexCoord2f(0, U); glVertex3f(x0, y0, z1);
    /* 前 (-Z) */
    k = lit(0.0f, 0.0f, -1.0f);
    glNormal3f(0.0f, 0.0f, -1.0f);              /* 着色器要用真法线（固定管线无视） */
    glColor3f(r * k > 1 ? 1 : r * k, g * k > 1 ? 1 : g * k, bl * k > 1 ? 1 : bl * k);
    glTexCoord2f(0, 0); glVertex3f(x0, y0, z0);
    glTexCoord2f(0, U); glVertex3f(x0, y1, z0);
    glTexCoord2f(U, U); glVertex3f(x1, y1, z0);
    glTexCoord2f(U, 0); glVertex3f(x1, y0, z0);
    /* 后 (+Z) */
    k = lit(0.0f, 0.0f, 1.0f);
    glNormal3f(0.0f, 0.0f, 1.0f);              /* 着色器要用真法线（固定管线无视） */
    glColor3f(r * k > 1 ? 1 : r * k, g * k > 1 ? 1 : g * k, bl * k > 1 ? 1 : bl * k);
    glTexCoord2f(0, 0); glVertex3f(x0, y0, z1);
    glTexCoord2f(U, 0); glVertex3f(x1, y0, z1);
    glTexCoord2f(U, U); glVertex3f(x1, y1, z1);
    glTexCoord2f(0, U); glVertex3f(x0, y1, z1);
    /* 左 (-X) */
    k = lit(-1.0f, 0.0f, 0.0f);
    glNormal3f(-1.0f, 0.0f, 0.0f);              /* 着色器要用真法线（固定管线无视） */
    glColor3f(r * k > 1 ? 1 : r * k, g * k > 1 ? 1 : g * k, bl * k > 1 ? 1 : bl * k);
    glTexCoord2f(0, 0); glVertex3f(x0, y0, z0);
    glTexCoord2f(U, 0); glVertex3f(x0, y0, z1);
    glTexCoord2f(U, U); glVertex3f(x0, y1, z1);
    glTexCoord2f(0, U); glVertex3f(x0, y1, z0);
    /* 右 (+X) */
    k = lit(1.0f, 0.0f, 0.0f);
    glNormal3f(1.0f, 0.0f, 0.0f);              /* 着色器要用真法线（固定管线无视） */
    glColor3f(r * k > 1 ? 1 : r * k, g * k > 1 ? 1 : g * k, bl * k > 1 ? 1 : bl * k);
    glTexCoord2f(0, 0); glVertex3f(x1, y0, z0);
    glTexCoord2f(0, U); glVertex3f(x1, y1, z0);
    glTexCoord2f(U, U); glVertex3f(x1, y1, z1);
    glTexCoord2f(U, 0); glVertex3f(x1, y0, z1);
    glEnd();

    if (rot || g_wire)
        glPopMatrix();
}

/* 绑定当前图元的贴图槽；槽 0 或未加载则关掉贴图（回到纯色）。
   顶点色仍由 lit() 给出，GL_MODULATE 负责把两者乘起来。 */
static void hw_bind_tex(int slot)
{
    /* 着色器模式：采样器读的是纹理单元 0，所以要显式 ActiveTexture。
       没贴图时绑 1x1 白纹理 —— 采样得到 (1,1,1)，对乘法是单位元，
       于是"有贴图/没贴图"可以共用同一段 GLSL，不会出现黑块。 */
    if (g_gl_ok && glapi.ActiveTexture)
        glapi.ActiveTexture(GL_TEXTURE0);
    if (slot > 0 && slot < HW_TEX_SLOTS && g_texs[slot] != 0) {
        glEnable(GL_TEXTURE_2D);
        glBindTexture(GL_TEXTURE_2D, g_texs[slot]);
    } else if (g_bound_prog != 0 && g_white_tex != 0) {
        glEnable(GL_TEXTURE_2D);
        glBindTexture(GL_TEXTURE_2D, g_white_tex);
    } else {
        glDisable(GL_TEXTURE_2D);
    }
}

/* ============ 球 / 圆柱（固定管线硬写：GL_TRIANGLE_FAN + 环带） ============
   为避免每个顶点都调一次 sin/cos（球 16×24 就是 700+ 次三角函数），
   每帧第一次画球/柱时才按当前最大分段算一次"细分表"，之后所有同类图元共用。
   分段数变化时才重算（链表保存每档的 sin/cos）。 */

typedef struct SegRow {
    int seg;
    float *s, *c;           /* 长度 seg+1，多一个是为了闭区间取整圈 */
    struct SegRow *next;
} SegRow;

static SegRow *g_segcache = NULL;

static const SegRow *seg_row(int seg)
{
    if (seg < 3)  seg = 3;
    if (seg > 64) seg = 64;
    for (SegRow *p = g_segcache; p; p = p->next)
        if (p->seg == seg)
            return p;
    SegRow *p = (SegRow *)malloc(sizeof(SegRow));
    if (!p)
        return NULL;
    p->seg = seg;
    p->s = (float *)malloc(sizeof(float) * (seg + 1));
    p->c = (float *)malloc(sizeof(float) * (seg + 1));
    if (!p->s || !p->c) {
        free(p->s); free(p->c); free(p);
        return NULL;
    }
    for (int i = 0; i <= seg; i++) {
        double a = 6.283185307179586 * (double)i / (double)seg;
        p->s[i] = (float)sin(a);
        p->c[i] = (float)cos(a);
    }
    p->next = g_segcache;
    g_segcache = p;
    return p;
}

/* 按法线定向光着色后再 clamp，和 draw_box 同一套 */
static void set_lit_color(float lr, float lg, float lb, float nx, float ny, float nz)
{
    float k = lit(nx, ny, nz);
    float r = lr * k, g = lg * k, b = lb * k;
    glColor3f(r > 1 ? 1 : r, g > 1 ? 1 : g, b > 1 ? 1 : b);
}

/* 球：按纬度切片，每片用 GL_TRIANGLE_STRIP 沿纬线扫一圈。
   顶点法线 = 归一化的相对中心向量，光照自然从暗到亮。 */
static void draw_sphere(const HwSphere *s)
{
    int RING = 16, SEG = 24;
    const SegRow *sr = seg_row(SEG);
    if (!sr)
        return;
    float lr = s->r / 255.0f, lg = s->g / 255.0f, lb = s->b / 255.0f;
    float U = s->uv > 0.0f ? s->uv : 1.0f;

    for (int i = 0; i < RING; i++) {
        double p0 = 3.14159265358979 * (double)i / (double)RING;
        double p1 = 3.14159265358979 * (double)(i + 1) / (double)RING;
        float sy0 = (float)sin(p0), cy0 = (float)cos(p0);
        float sy1 = (float)sin(p1), cy1 = (float)cos(p1);
        /* 纬度 → V：上极点是 0，下极点是 U（经度 → U 在循环里按 j 算） */
        float tv0 = (float)i / (float)RING * U;
        float tv1 = (float)(i + 1) / (float)RING * U;
        glBegin(GL_TRIANGLE_STRIP);
        for (int j = 0; j <= SEG; j++) {
            float nx, ny, nz;
            float uu = (float)j / (float)SEG * U;
            /* 上环：纬线 RING 段的第 i 片 */
            nx = sy0 * sr->c[j]; ny = cy0; nz = sy0 * sr->s[j];
            set_lit_color(lr, lg, lb, nx, ny, nz);
            glNormal3f(nx, ny, nz);        /* 球面法线 = 归一化的相对中心向量 */
            glTexCoord2f(uu, tv0);
            glVertex3f(s->x + s->rad * nx, s->y + s->rad * ny, s->z + s->rad * nz);
            /* 下环 */
            nx = sy1 * sr->c[j]; ny = cy1; nz = sy1 * sr->s[j];
            set_lit_color(lr, lg, lb, nx, ny, nz);
            glNormal3f(nx, ny, nz);
            glTexCoord2f(uu, tv1);
            glVertex3f(s->x + s->rad * nx, s->y + s->rad * ny, s->z + s->rad * nz);
        }
        glEnd();
    }
}

/* 圆柱 / 圆锥：侧面环带 + 上下两个扇面。
   rb=下半径, rt=上半径, h=高度（从 y 往上长）。
   半球法线近似：侧面法线取 (cos, 斜率, sin) 归一化，锥面会有正确的明暗过渡。 */
static void draw_cyl(const HwCyl *c)
{
    int SEG = c->seg;
    const SegRow *sr = seg_row(SEG);
    if (!sr)
        return;
    float lr = c->r / 255.0f, lg = c->g / 255.0f, lb = c->b / 255.0f;
    float U = c->uv > 0.0f ? c->uv : 1.0f;
    float y0 = c->y, y1 = c->y + c->h;
    float rb = c->rb, rt = c->rt;
    /* 侧面法线的竖直分量：底面到顶面半径差越大越斜。
       用 (rb - rt) / h 作为斜率，避免 h=0 时除零。 */
    float slope = c->h != 0.0f ? (rb - rt) / c->h : 0.0f;
    float ny = -slope;                 /* 外法线朝上为负斜率 */

    /* ---- 侧面：U 沿圆周绕一圈，V 沿高度 0->U ---- */
    if (rb > 0.0001f || rt > 0.0001f) {
        float nl = (float)sqrt((double)(1.0f + ny * ny));
        glBegin(GL_TRIANGLE_STRIP);
        for (int j = 0; j <= SEG; j++) {
            float cc = sr->c[j], ss = sr->s[j];
            float nx = cc / nl, nyy = ny / nl, nz = ss / nl;
            float uu = (float)j / (float)SEG * U;
            set_lit_color(lr, lg, lb, nx, nyy, nz);
            glNormal3f(nx, nyy, nz);
            glTexCoord2f(uu, 0.0f);
            glVertex3f(c->x + rb * cc, y0, c->z + rb * ss);
            set_lit_color(lr, lg, lb, nx, nyy, nz);
            glNormal3f(nx, nyy, nz);
            glTexCoord2f(uu, U);
            glVertex3f(c->x + rt * cc, y1, c->z + rt * ss);
        }
        glEnd();
    }

    /* ---- 顶盖（半径 > 0 才画），法线 +Y。
           UV 用平面映射：把 (x,z) 的圆盘直接映到 0..U 的方形上。 ---- */
    if (rt > 0.0001f) {
        set_lit_color(lr, lg, lb, 0.0f, 1.0f, 0.0f);
        glNormal3f(0.0f, 1.0f, 0.0f);
        glBegin(GL_TRIANGLE_FAN);
        glTexCoord2f(U * 0.5f, U * 0.5f);
        glVertex3f(c->x, y1, c->z);
        for (int j = 0; j <= SEG; j++) {
            glTexCoord2f((0.5f + 0.5f * sr->c[j]) * U, (0.5f + 0.5f * sr->s[j]) * U);
            glVertex3f(c->x + rt * sr->c[j], y1, c->z + rt * sr->s[j]);
        }
        glEnd();
    }

    /* ---- 底盖，法线 -Y，绕序反过来 ---- */
    if (rb > 0.0001f) {
        set_lit_color(lr, lg, lb, 0.0f, -1.0f, 0.0f);
        glNormal3f(0.0f, -1.0f, 0.0f);
        glBegin(GL_TRIANGLE_FAN);
        glTexCoord2f(U * 0.5f, U * 0.5f);
        glVertex3f(c->x, y0, c->z);
        for (int j = SEG; j >= 0; j--) {
            glTexCoord2f((0.5f + 0.5f * sr->c[j]) * U, (0.5f + 0.5f * sr->s[j]) * U);
            glVertex3f(c->x + rb * sr->c[j], y0, c->z + rb * sr->s[j]);
        }
        glEnd();
    }
}

/* 线框模式下的球/柱：用经纬线描边（粗粒度，够编辑器看位置用） */
static void draw_sphere_wire(const HwSphere *s)
{
    int RING = 8, SEG = 16;
    const SegRow *sr = seg_row(SEG);
    if (!sr)
        return;
    float k = 0.35f;
    glColor3f(s->r / 255.0f * k + 0.6f, s->g / 255.0f * k + 0.6f, s->b / 255.0f * k + 0.6f);
    glNormal3f(0.0f, 1.0f, 0.0f);
    glBegin(GL_LINES);
    for (int i = 1; i < RING; i++) {          /* 纬线圈 */
        double p = 3.14159265358979 * (double)i / (double)RING;
        float sy = (float)sin(p), cy = (float)cos(p);
        for (int j = 0; j < SEG; j++) {
            glVertex3f(s->x + s->rad * sy * sr->c[j], s->y + s->rad * cy,
                       s->z + s->rad * sy * sr->s[j]);
            glVertex3f(s->x + s->rad * sy * sr->c[j + 1], s->y + s->rad * cy,
                       s->z + s->rad * sy * sr->s[j + 1]);
        }
    }
    for (int j = 0; j < SEG; j++) {           /* 经线半圈 */
        for (int i = 0; i < RING; i++) {
            double p0 = 3.14159265358979 * (double)i / (double)RING;
            double p1 = 3.14159265358979 * (double)(i + 1) / (double)RING;
            float sy0 = (float)sin(p0), cy0 = (float)cos(p0);
            float sy1 = (float)sin(p1), cy1 = (float)cos(p1);
            glVertex3f(s->x + s->rad * sy0 * sr->c[j], s->y + s->rad * cy0,
                       s->z + s->rad * sy0 * sr->s[j]);
            glVertex3f(s->x + s->rad * sy1 * sr->c[j], s->y + s->rad * cy1,
                       s->z + s->rad * sy1 * sr->s[j]);
        }
    }
    glEnd();
}

static void draw_cyl_wire(const HwCyl *c)
{
    int SEG = c->seg;
    const SegRow *sr = seg_row(SEG);
    if (!sr)
        return;
    float y0 = c->y, y1 = c->y + c->h;
    float k = 0.35f;
    glColor3f(c->r / 255.0f * k + 0.6f, c->g / 255.0f * k + 0.6f, c->b / 255.0f * k + 0.6f);
    glNormal3f(0.0f, 1.0f, 0.0f);
    glBegin(GL_LINES);
    for (int j = 0; j < SEG; j++) {           /* 每一格的竖边 */
        glVertex3f(c->x + c->rb * sr->c[j], y0, c->z + c->rb * sr->s[j]);
        glVertex3f(c->x + c->rt * sr->c[j], y1, c->z + c->rt * sr->s[j]);
    }
    for (int j = 0; j <= SEG; j++) {          /* 上下两个圈 */
        glVertex3f(c->x + c->rb * sr->c[j], y0, c->z + c->rb * sr->s[j]);
        glVertex3f(c->x + c->rb * sr->c[j + 1], y0, c->z + c->rb * sr->s[j + 1]);
        if (c->rt > 0.0001f) {
            glVertex3f(c->x + c->rt * sr->c[j], y1, c->z + c->rt * sr->s[j]);
            glVertex3f(c->x + c->rt * sr->c[j + 1], y1, c->z + c->rt * sr->s[j + 1]);
        }
    }
    glEnd();
}

/* ============ 着色器 helper（编译 / 链接 / uniform / 内置着色器） ============
   注意 GLSL 版本选择：这里一律用 #version 120，不用 330 core。
   原因（_gl120_probe.c 实测）：兼容 profile 下 120 的着色器能直接读
   gl_Vertex / gl_Normal / gl_Color / gl_MultiTexCoord0 / gl_ModelViewProjectionMatrix，
   这些量由立即模式（glVertex3f / glNormal3f / glColor3f / glTexCoord2f）自动喂进来。
   → 现有 1400 行几何生成代码一行都不用改成 VBO/VAO，可编程管线直接"贴"上去。
   换 330 core 就得把 draw_box / draw_sphere / draw_cyl 全部重写成喂 buffer。 */

/* PYbook 的字符串字面量不支持转义、也不能跨行（词法层遇到换行就报未闭合）。
   所以着色器源码统一约定：字符串里写两字符的 \n 当换行、\t 当制表符。
   稍长的着色器建议写成 .vert/.frag 文件用 file.read 读进来 —— 编辑器里有
   语法高亮、也不受字符串规则捆住。这里做一次"折叠还原"，返回堆内存（调用方 free）。 */
static char *hw_unfold(const char *src)
{
    size_t n = strlen(src);
    char *out = (char *)malloc(n + 2);
    if (out == NULL)
        hw_die("hw.shader：内存不足");
    size_t k = 0;
    for (size_t i = 0; i < n; i++) {
        if (src[i] == '\\' && i + 1 < n) {
            char c = src[i + 1];
            if (c == 'n')  { out[k++] = '\n'; i++; continue; }
            if (c == 't')  { out[k++] = '\t'; i++; continue; }
            if (c == '\\') { out[k++] = '\\'; i++; continue; }
        }
        out[k++] = src[i];
    }
    out[k] = '\0';
    return out;
}

/* 设一个 uniform 的默认值（建好程序后调一次）。k = 分量个数。 */
static void hw_setu(GLuint prog, const char *name, int k,
                    float a, float b, float c, float d)
{
    if (!g_gl_ok || prog == 0)
        return;
    GLint l = glapi.GetUniformLocation(prog, name);
    if (l < 0)
        return;                          /* 着色器里没这个 uniform：跳过 */
    glapi.UseProgram(prog);
    switch (k) {
    case 1:  glapi.Uniform1f(l, a); break;
    case 2:  glapi.Uniform2f(l, a, b); break;
    case 3:  glapi.Uniform3f(l, a, b, c); break;
    default: glapi.Uniform4f(l, a, b, c, d); break;
    }
}

/* 编译一个阶段。失败返回 0，并把日志写进 out（可为 NULL）。 */
static GLuint hw_compile_stage(GLenum type, const char *src, char *out, int outn)
{
    GLuint s = glapi.CreateShader(type);
    if (s == 0)
        return 0;
    glapi.ShaderSource(s, 1, &src, NULL);
    glapi.CompileShader(s);
    GLint ok = 0;
    glapi.GetShaderiv(s, GL_COMPILE_STATUS, &ok);
    if (!ok) {
        if (out != NULL && outn > 0) {
            out[0] = '\0';
            if (glapi.GetShaderInfoLog)
                glapi.GetShaderInfoLog(s, outn, NULL, out);
        }
        glapi.DeleteShader(s);
        return 0;
    }
    return s;
}

/* 编译 + 链接一个程序。失败返回 0（日志进 out）。
   成功后自动设两个约定 uniform：uTex → 纹理单元 0，uTexMix → 1.0
   （这样"贴图 x 本色"开箱即用，没贴图的图元靠 1x1 白纹理兜底）。 */
static GLuint hw_build_program(const char *vs, const char *fs, char *out, int outn)
{
    GLuint v = hw_compile_stage(GL_VERTEX_SHADER, vs, out, outn);
    if (v == 0)
        return 0;
    GLuint f = hw_compile_stage(GL_FRAGMENT_SHADER, fs, out, outn);
    if (f == 0) {
        glapi.DeleteShader(v);
        return 0;
    }
    GLuint p = glapi.CreateProgram();
    glapi.AttachShader(p, v);
    glapi.AttachShader(p, f);
    glapi.LinkProgram(p);
    glapi.DeleteShader(v);               /* 删除是延迟的：链上了就无所谓 */
    glapi.DeleteShader(f);
    GLint ok = 0;
    glapi.GetProgramiv(p, GL_LINK_STATUS, &ok);
    if (!ok) {
        if (out != NULL && outn > 0) {
            out[0] = '\0';
            if (glapi.GetProgramInfoLog)
                glapi.GetProgramInfoLog(p, outn, NULL, out);
        }
        glapi.DeleteProgram(p);
        return 0;
    }
    /* 约定 sampler：uTex 固定指纹理单元 0。
       注意必须用 Uniform1i —— sampler2D 是整数类型，用 glUniform1f 设它会
       直接吃一个 GL_INVALID_OPERATION（_shader_probe.c 实测抓到的）。
       着色器里没用到 uTex 时它会被优化掉，位置是 -1，跳过即可。 */
    GLint tl = glapi.GetUniformLocation(p, "uTex");
    if (tl >= 0 && glapi.Uniform1i) {
        glapi.UseProgram(p);
        glapi.Uniform1i(tl, 0);
    }
    hw_setu(p, "uTexMix", 1, 1.0f, 0.0f, 0.0f, 0.0f);
    glapi.UseProgram(0);
    return p;
}

/* 应用一条 uniform（位置按程序缓存，同一个程序只查一次）。
   着色器里没声明的名字静默跳过 —— 脚本里多设几个不存在的 uniform 不该崩。 */
static void hw_apply_uni(HwUni *u)
{
    if (!g_gl_ok || g_bound_prog == 0 || u->name[0] == '\0')
        return;
    if (u->loc_prog != g_bound_prog) {
        u->loc = glapi.GetUniformLocation(g_bound_prog, u->name);
        u->loc_prog = g_bound_prog;
    }
    if (u->loc < 0)
        return;
    switch (u->kind) {
    case 1:  glapi.Uniform1f(u->loc, u->v[0]); break;
    case 2:  glapi.Uniform2f(u->loc, u->v[0], u->v[1]); break;
    case 3:  glapi.Uniform3f(u->loc, u->v[0], u->v[1], u->v[2]); break;
    default: glapi.Uniform4f(u->loc, u->v[0], u->v[1], u->v[2], u->v[3]); break;
    }
}

/* 1x1 白纹理：着色器模式下"这个图元没有贴图"时顶上去。
   采样得到 (1,1,1)，对乘法是单位元，所以一段 GLSL 能同时应付两种情况。 */
static void hw_white_tex(void)
{
    static const unsigned char px[4] = { 255, 255, 255, 255 };
    if (g_white_tex != 0)
        return;
    glGenTextures(1, &g_white_tex);
    glBindTexture(GL_TEXTURE_2D, g_white_tex);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, 1, 1, 0, GL_RGBA, GL_UNSIGNED_BYTE, px);
    glBindTexture(GL_TEXTURE_2D, 0);
}

/* ---- 内置着色器（hw.preset）----
   共同顶点阶段：把法线/本色/UV/视空间位置转成 varying 传给片段阶段。
   gl_NormalMatrix 会把模型view 的旋转正确作用到法线上 ——
   这一点比固定管线那套"轴对齐法线 + 烤光"还准（物体自转时光照跟着转）。 */
static const char *HW_PRESET_VS =
    "#version 120\n"
    "varying vec3 vN;\n"
    "varying vec3 vC;\n"
    "varying vec2 vUV;\n"
    "varying vec3 vEye;\n"
    "void main(){\n"
    "  vN = gl_NormalMatrix * gl_Normal;\n"
    "  vC = gl_Color.rgb;\n"
    "  vUV = gl_MultiTexCoord0.xy;\n"
    "  vEye = (gl_ModelViewMatrix * gl_Vertex).xyz;\n"
    "  gl_Position = gl_ModelViewProjectionMatrix * gl_Vertex;\n"
    "}\n";

/* 朗伯：环境光 + 漫反射，可选贴图。和固定管线观感最接近，做基准对照用。 */
static const char *HW_FS_LAMBERT =
    "#version 120\n"
    "varying vec3 vN; varying vec3 vC; varying vec2 vUV;\n"
    "uniform vec3 uLight; uniform sampler2D uTex; uniform float uTexMix;\n"
    "void main(){\n"
    "  float d = max(dot(normalize(vN), normalize(uLight)), 0.0);\n"
    "  vec3 alb = vC * mix(vec3(1.0), texture2D(uTex, vUV).rgb, uTexMix);\n"
    "  gl_FragColor = vec4(alb * (0.35 + 0.75 * d), 1.0);\n"
    "}\n";

/* 卡通：把连续光照量化成 N 档色阶（uSteps 可调），马上有"动漫感"。 */
static const char *HW_FS_TOON =
    "#version 120\n"
    "varying vec3 vN; varying vec3 vC; varying vec2 vUV;\n"
    "uniform vec3 uLight; uniform sampler2D uTex; uniform float uTexMix;\n"
    "uniform float uSteps;\n"
    "void main(){\n"
    "  float d = max(dot(normalize(vN), normalize(uLight)), 0.0);\n"
    "  float s = floor(d * uSteps + 0.5) / max(uSteps, 1.0);\n"
    "  vec3 alb = vC * mix(vec3(1.0), texture2D(uTex, vUV).rgb, uTexMix);\n"
    "  gl_FragColor = vec4(alb * (0.30 + 0.85 * s), 1.0);\n"
    "}\n";

/* 边缘光：视线越"擦过"表面越亮，科幻/全息感。uRim 是边缘色。 */
static const char *HW_FS_FRESNEL =
    "#version 120\n"
    "varying vec3 vN; varying vec3 vC; varying vec2 vUV; varying vec3 vEye;\n"
    "uniform vec3 uLight; uniform sampler2D uTex; uniform float uTexMix;\n"
    "uniform vec3 uRim; uniform float uRimPow;\n"
    "void main(){\n"
    "  vec3 N = normalize(vN);\n"
    "  vec3 V = normalize(-vEye);\n"
    "  float d = max(dot(N, normalize(uLight)), 0.0);\n"
    "  vec3 alb = vC * mix(vec3(1.0), texture2D(uTex, vUV).rgb, uTexMix);\n"
    "  float f = pow(1.0 - max(dot(N, V), 0.0), uRimPow);\n"
    "  gl_FragColor = vec4(alb * (0.25 + 0.70 * d) + uRim * f, 1.0);\n"
    "}\n";

/* 棋盘：完全不采样贴图，用 UV 现场算格子 —— 演示"程序化纹理"，也方便看 UV 对不对。 */
static const char *HW_FS_CHECKER =
    "#version 120\n"
    "varying vec3 vN; varying vec3 vC; varying vec2 vUV;\n"
    "uniform vec3 uLight; uniform float uScale; uniform vec3 uDark;\n"
    "void main(){\n"
    "  vec2 g = floor(vUV * uScale);\n"
    "  float k = mod(g.x + g.y, 2.0);\n"
    "  vec3 alb = mix(uDark, vC, k);\n"
    "  float d = max(dot(normalize(vN), normalize(uLight)), 0.0);\n"
    "  gl_FragColor = vec4(alb * (0.35 + 0.75 * d), 1.0);\n"
    "}\n";

/* 法线可视化：调 UV / 法线 / 细分问题时最有用的一张图。 */
static const char *HW_FS_NORMAL =
    "#version 120\n"
    "varying vec3 vN;\n"
    "void main(){ gl_FragColor = vec4(normalize(vN) * 0.5 + 0.5, 1.0); }\n";

/* 自发光：只出本色 x 贴图，不算光照。做 UI / 发光体 / 天空盒用。 */
static const char *HW_FS_UNLIT =
    "#version 120\n"
    "varying vec3 vC; varying vec2 vUV;\n"
    "uniform sampler2D uTex; uniform float uTexMix;\n"
    "void main(){\n"
    "  vec3 alb = vC * mix(vec3(1.0), texture2D(uTex, vUV).rgb, uTexMix);\n"
    "  gl_FragColor = vec4(alb, 1.0);\n"
    "}\n";

/* 名字 → 片段着色器源码。中英文别名都收。找不到返回 NULL。 */
static const char *hw_preset_fs_src(const char *n)
{
    /* 注意不能加 static：HW_FS_* 是变量（指针），不是编译期常量表达式，
       放进静态初始化器会报 "initializer element is not constant"。 */
    const struct { const char *n; const char *s; } TAB[] = {
        { "lambert", HW_FS_LAMBERT }, { "朗伯",   HW_FS_LAMBERT },
        { "toon",    HW_FS_TOON },    { "卡通",   HW_FS_TOON },
        { "fresnel", HW_FS_FRESNEL }, { "边缘",   HW_FS_FRESNEL },
        { "checker", HW_FS_CHECKER }, { "棋盘",   HW_FS_CHECKER },
        { "normal",  HW_FS_NORMAL },  { "法线",   HW_FS_NORMAL },
        { "unlit",   HW_FS_UNLIT },   { "自发光", HW_FS_UNLIT },
    };
    if (n == NULL)
        return NULL;
    for (size_t i = 0; i < sizeof TAB / sizeof TAB[0]; i++)
        if (TAB[i].n != NULL && strcmp(TAB[i].n, n) == 0)
            return TAB[i].s;
    return NULL;
}

/* 内置着色器的默认 uniform（可被 hw.uni 覆盖）。 */
static void hw_preset_defaults(GLuint p, const char *n)
{
    if (strcmp(n, "toon") == 0 || strcmp(n, "卡通") == 0) {
        hw_setu(p, "uSteps", 1, 4.0f, 0.0f, 0.0f, 0.0f);
    } else if (strcmp(n, "fresnel") == 0 || strcmp(n, "边缘") == 0) {
        hw_setu(p, "uRim", 3, 0.25f, 0.55f, 1.00f, 0.0f);
        hw_setu(p, "uRimPow", 1, 3.0f, 0.0f, 0.0f, 0.0f);
    } else if (strcmp(n, "checker") == 0 || strcmp(n, "棋盘") == 0) {
        hw_setu(p, "uScale", 1, 4.0f, 0.0f, 0.0f, 0.0f);
        hw_setu(p, "uDark", 3, 0.06f, 0.07f, 0.10f, 0.0f);
    }
    if (g_gl_ok)
        glapi.UseProgram(0);
}

/* 按提交顺序执行命令流。push/pop 直接映射到 GL 的矩阵栈。
   这是"父子层级"的落地点：父变换套在外面，子图元自然跟着转。
   线段做连续批处理（相邻的 OP_LINE 合进一个 glBegin）。 */
static void draw_ops(void)
{
    g_depth = 0;
    for (int i = 0; i < g_nops; i++) {
        HwOp *o = &g_ops[i];
        switch (o->type) {
        case OP_PUSH:
            if (g_depth >= HW_MAX_DEPTH)      /* 超深度：忽略，防爆栈 */
                break;
            glPushMatrix();
            glTranslatef(o->px, o->py, o->pz);
            glRotatef(o->rz * 57.29578f, 0.0f, 0.0f, 1.0f);
            glRotatef(o->ry * 57.29578f, 0.0f, 1.0f, 0.0f);
            glRotatef(o->rx * 57.29578f, 1.0f, 0.0f, 0.0f);
            g_depth++;
            break;
        case OP_POP:
            if (g_depth > 0) {
                glPopMatrix();
                g_depth--;
            }
            break;
        case OP_BOX:
            hw_bind_tex(g_boxes[o->idx].tex);
            draw_box(&g_boxes[o->idx]);
            break;
        case OP_SPHERE:
            hw_bind_tex(g_spheres[o->idx].tex);
            if (g_wire) draw_sphere_wire(&g_spheres[o->idx]);
            else        draw_sphere(&g_spheres[o->idx]);
            break;
        case OP_CYL:
            hw_bind_tex(g_cyls[o->idx].tex);
            if (g_wire) draw_cyl_wire(&g_cyls[o->idx]);
            else        draw_cyl(&g_cyls[o->idx]);
            break;
        case OP_UNI:
            hw_apply_uni(&g_unis[o->idx]);
            break;
        case OP_PROG: {
            /* 帧中间切着色器：槽 0 = 回固定管线。
               切完把流里"已经出现过"的 uniform 补设一遍 —— 用户很可能把
               hw.uni 写在 hw.shaderuse 前面，顺序不该成为坑。 */
            GLuint np = (o->idx > 0 && o->idx < HW_SHADER_SLOTS) ? g_progs[o->idx] : 0;
            g_bound_prog = np;
            if (g_gl_ok) {
                glapi.UseProgram(np);
                if (np != 0) {
                    if (g_ulight[o->idx] >= 0)
                        glapi.Uniform3f(g_ulight[o->idx], g_lx, g_ly, g_lz);
                    for (int k2 = 0; k2 < i; k2++)
                        if (g_ops[k2].type == OP_UNI)
                            hw_apply_uni(&g_unis[g_ops[k2].idx]);
                }
            }
            break;
        }
        case OP_LINE: {
            glDisable(GL_TEXTURE_2D);         /* 线段不贴图 */
            glNormal3f(0.0f, 1.0f, 0.0f);
            glBegin(GL_LINES);
            int j = i;
            for (; j < g_nops && g_ops[j].type == OP_LINE; j++) {
                const HwLine *l = &g_lines[g_ops[j].idx];
                glColor3f(l->r / 255.0f, l->g / 255.0f, l->b / 255.0f);
                glVertex3f(l->x1, l->y1, l->z1);
                glVertex3f(l->x2, l->y2, l->z2);
            }
            glEnd();
            i = j - 1;                        /* 批处理已吃掉 [i, j) */
            break;
        }
        default:
            break;
        }
    }
    while (g_depth > 0) {                     /* 脚本忘配对 pop：兜底清栈 */
        glPopMatrix();
        g_depth--;
    }
    glDisable(GL_TEXTURE_2D);
}

Value rt_hw_frame(void)
{
    if (g_win == NULL)
        hw_die("hw.frame：还没开窗口（先调用 hw.open）");

    int winW = g_w, winH = g_h;
    SDL_GetWindowSize(g_win, &winW, &winH);   /* 窗口可拉伸：视口跟随 */
    glViewport(0, 0, winW, winH);

    /* ---- 3D 走廊 ---- */
    glClearColor((GLfloat)(g_sky_r / 255.0), (GLfloat)(g_sky_g / 255.0),
                 (GLfloat)(g_sky_b / 255.0), 1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    glEnable(GL_DEPTH_TEST);
    /* 贴图环境（每帧设一次即可）：
       GL_MODULATE = 顶点色 x 贴图色 —— 方向光的明暗会自动作用在贴图上。
       alpha 裁剪处理带透明通道的 PNG：不做排序，避免半透明排序难题。 */
    glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
    glEnable(GL_ALPHA_TEST);
    glAlphaFunc(GL_GREATER, 0.01f);
    /* 雾：起步 >= 终止 视为关雾（编辑器看近景时不糊） */
    if (g_fog_end > g_fog_start) {
        glEnable(GL_FOG);
        GLfloat fogc[4] = { (GLfloat)(g_sky_r / 255.0), (GLfloat)(g_sky_g / 255.0),
                            (GLfloat)(g_sky_b / 255.0), 1.0f };
        glFogi(GL_FOG_MODE, GL_LINEAR);
        glFogfv(GL_FOG_COLOR, fogc);
        glFogf(GL_FOG_START, (GLfloat)g_fog_start);
        glFogf(GL_FOG_END, (GLfloat)g_fog_end);
    } else {
        glDisable(GL_FOG);
    }

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    {
        /* fovy 与近裁剪面都是可调的（hw.fov / hw.near）；
           近视距场景近处被裁掉 → 把 near 调小（如 0.1）。 */
        double fovy = g_fovy, n = g_near, f = g_far;
        if (f <= n) f = n + 1.0;              /* near 被调大到超过 far 时兜底 */
        if (g_ortho > 0.0) {
            /* 正交：半高直接是世界单位，不再乘 near —— 近大远小消失。
               等距对齐 / 三视图 / 编辑器俯视图靠的就是这个。 */
            double oh = g_ortho;
            double ow = oh * (double)winW / (double)winH;
            glOrtho(-ow, ow, -oh, oh, n, f);
        } else {
            double fh = n * tan(fovy * 3.14159265358979 / 360.0);
            double fw = fh * (double)winW / (double)winH;
            glFrustum(-fw, fw, -fh, fh, n, f);
        }
    }
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    /* FPS 相机：v' = 俯仰矩阵 · 偏航矩阵 · 平移。
     * GL 后调先作用到顶点，所以调用顺序 = 俯仰、偏航、平移——
     * 俯仰绕的是偏航后的视线横轴（局部 X），偏航绕世界竖轴。
     * 顺序写反会把"俯仰"变成绕视线轴的翻滚（老 bug 的根因）。
     * yaw+90°：让 (cos yaw, 0, sin yaw) 落到 GL 视线的 -Z。 */
    glRotated(-g_pitch * 180.0 / 3.14159265358979, 1.0, 0.0, 0.0);
    glRotated(g_yaw * 180.0 / 3.14159265358979 + 90.0, 0.0, 1.0, 0.0);
    glTranslated(-g_camx, -g_camy, -g_camz);

    /* 着色器模式：绑上"当前程序"（draw_ops 里还能靠 hw.shaderuse 中途切）。
       没指定过着色器就走原样的固定管线 —— 老程序一行不用改。
       uLight 由引擎每帧从 hw.light 灌进去，所以 hw.light 对着色器同样有效。
       注意固定管线的雾 / alpha 裁剪在兼容 profile 下是"片段着色器之后"的
       固定功能级，所以开着色器时 hw.fog 和透明 PNG 裁剪照样工作。 */
    g_bound_prog = 0;
    if (g_gl_ok && g_curprog > 0 && g_progs[g_curprog] != 0) {
        glapi.UseProgram(g_progs[g_curprog]);
        g_bound_prog = g_progs[g_curprog];
        if (g_white_tex == 0)
            hw_white_tex();
        if (g_ulight[g_curprog] >= 0)
            glapi.Uniform3f(g_ulight[g_curprog], g_lx, g_ly, g_lz);
    }
    draw_ops();
    if (g_bound_prog != 0) {
        glapi.UseProgram(0);
        g_bound_prog = 0;
    }

    /* ---- 文字覆盖层（正交，无深度无雾） ---- */
    glDisable(GL_FOG);
    glDisable(GL_DEPTH_TEST);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, winW, winH, 0, -1, 1);        /* 屏幕坐标：y 向下 */
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    for (int i = 0; i < g_nqtext; i++) {
        QText *t = &g_qtext[i];
        int tw, th;
        GLuint tex = text_texture(t->s, t->size, &tw, &th);
        if (tex != 0) {
            glEnable(GL_TEXTURE_2D);
            glBindTexture(GL_TEXTURE_2D, tex);
            glColor4f(1, 1, 1, 1);
            glBegin(GL_QUADS);
            glTexCoord2f(0, 0); glVertex2i(t->x,       t->y);
            glTexCoord2f(1, 0); glVertex2i(t->x + tw, t->y);
            glTexCoord2f(1, 1); glVertex2i(t->x + tw, t->y + th);
            glTexCoord2f(0, 1); glVertex2i(t->x,       t->y + th);
            glEnd();
            glDisable(GL_TEXTURE_2D);
        }
        free(t->s);
        t->s = NULL;
    }
    g_nqtext = 0;
    g_nboxes = 0;
    g_nlines = 0;
    g_nspheres = 0;
    g_ncyls = 0;
    g_nops = 0;
    g_depth = 0;
    /* uniform 表每帧清空（保持有界）；uniform 的值本身存在程序对象里，
       所以"开局设一次"的写法在后续帧照样生效，不必每帧重设。 */
    g_nunis = 0;

    glDisable(GL_BLEND);
    SDL_GL_SwapWindow(g_win);

    pump();
    memcpy(g_kprev, g_kcur, sizeof g_kcur);
    const Uint8 *ks = SDL_GetKeyboardState(NULL);
    for (int i = 0; i < SDL_NUM_SCANCODES; i++)
        g_kcur[i] = ks[i];
    g_mprev = g_mcur;
    g_mcur = (SDL_GetMouseState(NULL, NULL) & SDL_BUTTON_LMASK) ? 1 : 0;
    SDL_Delay(15);                       /* 约 60FPS */
    return rt_none();
}

/* ---- 鼠标锁定与增量（FPS 视角零件）---- */

Value rt_hw_grab(void)
{
    if (g_win == NULL)
        return rt_none();
    SDL_SetRelativeMouseMode(SDL_TRUE);   /* 锁指针：鼠标变隐形，只给移动量 */
    return rt_none();
}

Value rt_hw_free(void)
{
    SDL_SetRelativeMouseMode(SDL_FALSE);
    return rt_none();
}

Value rt_hw_mdx(void)
{
    if (g_win == NULL)
        return rt_int(0);
    int dx, dy;
    SDL_GetRelativeMouseState(&dx, &dy);
    return rt_int(dx);
}

Value rt_hw_mdy(void)
{
    if (g_win == NULL)
        return rt_int(0);
    int dx, dy;
    SDL_GetRelativeMouseState(&dx, &dy);
    return rt_int(dy);
}

/* hw.fog(起, 止)：调线性雾的起止距离。止 <= 起 即关雾。
   编辑器和近景演示常用 hw.fog(0, 0) 关掉雾。 */
Value rt_hw_fog(Value sv, Value ev)
{
    g_fog_start = hw_num(sv, "hw.fog 的起");
    g_fog_end   = hw_num(ev, "hw.fog 的止");
    return rt_none();
}

/* hw.far(距离)：设远裁剪面（视距）。默认 1600。 */
Value rt_hw_far(Value vv)
{
    double d = hw_num(vv, "hw.far 的距离");
    if (d > 1.0)
        g_far = d;
    return rt_none();
}

/* hw.wire(0/1)：切换线框模式（0 实心，非 0 描边）。 */
Value rt_hw_wire(Value vv)
{
    g_wire = (hw_num(vv, "hw.wire 的开关") != 0.0);
    return rt_none();
}

/* hw.line(x1,y1,z1, x2,y2,z2, r,g,b)：画一条 3D 线段。
   编辑器的 gizmo 坐标轴、包围盒、辅助线全靠它。 */
Value rt_hw_line(Value x1v, Value y1v, Value z1v,
                 Value x2v, Value y2v, Value z2v,
                 Value rv, Value gv, Value bv)
{
    if (g_nlines == HW_LINE_MAX)
        hw_die("hw.line：单帧线段超过上限 %d", HW_LINE_MAX);
    HwLine *l = &g_lines[g_nlines++];
    l->x1 = (float)hw_num(x1v, "hw.line 的 x1");
    l->y1 = (float)hw_num(y1v, "hw.line 的 y1");
    l->z1 = (float)hw_num(z1v, "hw.line 的 z1");
    l->x2 = (float)hw_num(x2v, "hw.line 的 x2");
    l->y2 = (float)hw_num(y2v, "hw.line 的 y2");
    l->z2 = (float)hw_num(z2v, "hw.line 的 z2");
    l->r = (unsigned char)hw_u8((int)hw_num(rv, "hw.line 的 R"));
    l->g = (unsigned char)hw_u8((int)hw_num(gv, "hw.line 的 G"));
    l->b = (unsigned char)hw_u8((int)hw_num(bv, "hw.line 的 B"));
    hw_op(OP_LINE, g_nlines - 1);
    return rt_none();
}

/* hw.light(方向x, 方向y, 方向z, 强度)：设方向光。
   方向是"指向光源"的向量，内部自动归一化；强度 0~1 映射到漫反射权重。
   不调用则用默认光（右上前方）。 */
Value rt_hw_light(Value xv, Value yv, Value zv, Value iv)
{
    double x = hw_num(xv, "hw.light 的方向x");
    double y = hw_num(yv, "hw.light 的方向y");
    double z = hw_num(zv, "hw.light 的方向z");
    double n = x * x + y * y + z * z;
    if (n < 1e-9) {
        x = 0.45; y = 0.80; z = 0.40;
        n = x * x + y * y + z * z;
    }
    n = 1.0 / sqrt(n);
    g_lx = (float)(x * n);
    g_ly = (float)(y * n);
    g_lz = (float)(z * n);
    double it = hw_num(iv, "hw.light 的强度");
    if (it < 0.0) it = 0.0;
    if (it > 1.0) it = 1.0;
    g_ldiff = (float)(it * 0.75);
    g_lamb  = (float)(0.95 - g_ldiff * 0.75);
    return rt_none();
}

/* hw.sphere(x, y, z, 半径, r, g, b)：画一个球（位置是球心，不是角点）。
   分段 16 纬 × 24 经；线框模式下自动改画经纬线。 */
Value rt_hw_sphere(Value xv, Value yv, Value zv, Value rv,
                   Value crv, Value cgv, Value cbv)
{
    if (g_nspheres == HW_SPHERE_MAX)
        hw_die("hw.sphere：单帧球数超过上限 %d", HW_SPHERE_MAX);
    HwSphere *s = &g_spheres[g_nspheres++];
    s->x   = (float)hw_num(xv, "hw.sphere 的 x");
    s->y   = (float)hw_num(yv, "hw.sphere 的 y");
    s->z   = (float)hw_num(zv, "hw.sphere 的 z");
    s->rad = (float)hw_num(rv, "hw.sphere 的半径");
    s->r = (unsigned char)hw_u8((int)hw_num(crv, "hw.sphere 的 R"));
    s->g = (unsigned char)hw_u8((int)hw_num(cgv, "hw.sphere 的 G"));
    s->b = (unsigned char)hw_u8((int)hw_num(cbv, "hw.sphere 的 B"));
    s->tex = g_curtex;
    s->uv  = g_curuv;
    hw_op(OP_SPHERE, g_nspheres - 1);
    return rt_none();
}

/* hw.cyl(x, y, z, 半径下, 高度, 半径上, r, g, b)              —— 9 参，边数默认 24
   hw.cyl(x, y, z, 半径下, 高度, 半径上, 边数, r, g, b)        —— 10 参，自定义边数
   底面在 y，向上长 h。半径下 == 半径上 → 圆柱；半径上 == 0 → 圆锥。 */
Value rt_hw_cylv(int nargs, Value *av)
{
    if (g_ncyls == HW_CYL_MAX)
        hw_die("hw.cyl：单帧圆柱数超过上限 %d", HW_CYL_MAX);
    int seg = 24;
    Value rv, gv, bv;
    if (nargs >= 10) {
        seg = (int)hw_num(av[6], "hw.cyl 的边数");
        if (seg < 3)  seg = 3;
        if (seg > 64) seg = 64;
        rv = av[7]; gv = av[8]; bv = av[9];
    } else {
        rv = av[6]; gv = av[7]; bv = av[8];
    }
    HwCyl *c = &g_cyls[g_ncyls++];
    c->x  = (float)hw_num(av[0], "hw.cyl 的 x");
    c->y  = (float)hw_num(av[1], "hw.cyl 的 y");
    c->z  = (float)hw_num(av[2], "hw.cyl 的 z");
    c->rb = (float)hw_num(av[3], "hw.cyl 的下半径");
    c->h  = (float)hw_num(av[4], "hw.cyl 的高度");
    c->rt = (float)hw_num(av[5], "hw.cyl 的上半径");
    c->seg = seg;
    c->r = (unsigned char)hw_u8((int)hw_num(rv, "hw.cyl 的 R"));
    c->g = (unsigned char)hw_u8((int)hw_num(gv, "hw.cyl 的 G"));
    c->b = (unsigned char)hw_u8((int)hw_num(bv, "hw.cyl 的 B"));
    c->tex = g_curtex;
    c->uv  = g_curuv;
    hw_op(OP_CYL, g_ncyls - 1);
    return rt_none();
}

/* hw.fov(张角)：竖直视场角（度）。默认 70。编辑器想要紧凑视角就用 45。 */
Value rt_hw_fov(Value vv)
{
    double d = hw_num(vv, "hw.fov 的角度");
    if (d < 5.0)   d = 5.0;
    if (d > 170.0) d = 170.0;
    g_fovy = d;
    return rt_none();
}

/* hw.near(距离)：近裁剪面。默认 1.0。
   贴着物体看时被裁掉半截 → 调小到 0.1。必须 > 0。 */
Value rt_hw_near(Value vv)
{
    double d = hw_num(vv, "hw.near 的距离");
    if (d < 0.01) d = 0.01;
    g_near = d;
    return rt_none();
}

/* hw.ortho(半高)：切正交投影。0（默认）= 透视，> 0 = 正交。
   半高 = 视野竖直方向的一半，单位是"世界单位" —— 写 30 就是上下各看 30 格。
   正交下物体不再近大远小，等距对齐、CAD 式三视图、编辑器俯视图都靠它：

       hw.ortho(30)     # 切正交，上下各看 30 格
       hw.ortho(0)      # 切回透视

   注意：正交下 hw.fov 不参与计算（视场由半高决定），
   但 hw.near / hw.far 照样裁剪 —— 俯视相机架太高时记得把 hw.far 调大。 */
Value rt_hw_ortho(Value vv)
{
    double d = hw_num(vv, "hw.ortho 的半高");
    if (d < 0.0) d = 0.0;
    g_ortho = d;
    return rt_none();
}

/* hw.push(x, y, z, 绕x, 绕y, 绕z)：压入一个父变换（节点树的"进节点"）。
   push 之后提交的所有图元都活在这个坐标系里——父节点转动时它们跟着转。
   必须和 hw.pop() 配对；忘写 pop 帧末会自动清栈，不会崩。
   旋转顺序 X→Y→Z，绕 push 的那个原点。

   典型用法（转动桌子，桌上的东西跟着转）：
       hw.push(桌x, 桌y, 桌z, 0, 桌朝向, 0)
       hw.box(0, 0, 0, 4, 0.3, 4, 140, 100, 60)      # 桌面（局部坐标）
       hw.box(-1, 0.5, 1, 1, 1, 1, 220, 220, 230)    # 杯子（自动跟着转）
       hw.box(1.2, 0.4, -0.8, 0.8, 0.8, 0.8, 180, 120, 90)
       hw.pop()

   可以嵌套（最多 %d 层）：桌子上面放托盘，托盘上再放杯子。 */
Value rt_hw_push(Value xv, Value yv, Value zv,
                 Value axv, Value ayv, Value azv)
{
    if (g_nops >= HW_OP_MAX)
        hw_die("hw.push：单帧图元/变换数超过上限 %d", HW_OP_MAX);
    HwOp *o = &g_ops[g_nops++];
    o->type = OP_PUSH;
    o->idx  = 0;
    o->px = (float)hw_num(xv, "hw.push 的 x");
    o->py = (float)hw_num(yv, "hw.push 的 y");
    o->pz = (float)hw_num(zv, "hw.push 的 z");
    o->rx = (float)hw_num(axv, "hw.push 的绕X");
    o->ry = (float)hw_num(ayv, "hw.push 的绕Y");
    o->rz = (float)hw_num(azv, "hw.push 的绕Z");
    return rt_none();
}

/* hw.pop()：弹出最近的 hw.push（节点树的"出节点"）。 */
Value rt_hw_pop(void)
{
    hw_op(OP_POP, 0);
    return rt_none();
}

/* hw.tex(槽, 路径)：把图片加载到贴图槽（1 ~ 7）。
   支持 png / jpg / bmp / tga（走 stb_image，和"游戏.图"同一个解码器）。
   成功返回 1，文件不存在或解码失败返回 0（不中断程序，方便脚本容错）。
   槽 0 固定表示"无贴图"，不能写入。
   中文路径没问题（内部转 UTF-16 再 _wfopen）。 */
Value rt_hw_tex(Value sv, Value pv)
{
    int slot = (int)hw_num(sv, "hw.tex 的槽位");
    const char *path = hw_str(pv, "hw.tex 的路径");
    if (slot < 1 || slot >= HW_TEX_SLOTS) {
        hw_die("hw.tex：槽位要在 1~%d 之间（0 是无贴图）", HW_TEX_SLOTS - 1);
        return rt_int(0);
    }
    if (g_win == NULL)
        hw_die("hw.tex：还没开窗口（先调用 hw.open）");

    wchar_t wpath[1024];
    if (MultiByteToWideChar(CP_UTF8, 0, path ? path : "", -1, wpath, 1024) <= 0)
        return rt_int(0);
    FILE *fp = _wfopen(wpath, L"rb");
    if (fp == NULL)
        return rt_int(0);
    int w = 0, h = 0, n = 0;
    unsigned char *data = stbi_load_from_file(fp, &w, &h, &n, 4);
    fclose(fp);
    if (data == NULL || w <= 0 || h <= 0)
        return rt_int(0);

    if (g_texs[slot] != 0)                 /* 重载同一槽：先删旧的 */
        glDeleteTextures(1, &g_texs[slot]);
    GLuint id = 0;
    glGenTextures(1, &id);
    glBindTexture(GL_TEXTURE_2D, id);
    glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, data);
    /* GL_REPEAT 是 hw.uv 能平铺的前提；不做 mipmap，就用线性过滤 */
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glBindTexture(GL_TEXTURE_2D, 0);
    stbi_image_free(data);
    g_texs[slot] = id;
    g_texw[slot] = w;
    g_texh[slot] = h;
    return rt_int(1);
}

/* hw.texuse(槽)：设定"当前贴图"。之后提交的 box / sphere / cyl 都会用它。
   槽 0 = 回到纯色。想只给部分图元贴图，就在中间切一次。 */
Value rt_hw_texuse(Value sv)
{
    int slot = (int)hw_num(sv, "hw.texuse 的槽位");
    if (slot < 0 || slot >= HW_TEX_SLOTS) {
        hw_die("hw.texuse：槽位要在 0~%d 之间", HW_TEX_SLOTS - 1);
        return rt_none();
    }
    g_curtex = slot;
    return rt_none();
}

/* hw.uv(重复次数)：设定"当前 UV 重复次数"。
   1 = 整张贴图铺满一个面；3 = 3x3 平铺；0.5 = 只显示贴图中心那一块。
   （>1 才是平铺，靠 GL_REPEAT 实现） */
Value rt_hw_uv(Value vv)
{
    double d = hw_num(vv, "hw.uv 的重复次数");
    if (d <= 0.0) d = 1.0;
    if (d > 64.0) d = 64.0;
    g_curuv = (float)d;
    return rt_none();
}

/* ===================== 可编程管线 API ===================== */

/* hw.shader(槽, 顶点源码, 片段源码)：把一段 GLSL 编译进着色器槽（1~7）。
   成功返回 1，编译/链接失败返回 0（不中断程序，脚本可以自己容错）。
   之后用 hw.shaderuse(槽) 启用；槽 0 表示"回到固定管线"。

   **源码请用 #version 120**（这是引擎的约定，见 hw_build_program 上方注释）：
   兼容 profile 下它可以直接读 gl_Vertex / gl_Normal / gl_Color /
   gl_MultiTexCoord0 / gl_ModelViewProjectionMatrix / gl_NormalMatrix，
   这些量由现成的 glBegin 几何自动喂进来，不用改成 VBO。

   PYbook 字符串不能跨行、也不支持转义，所以字符串里写两字符的 \n 会被
   还原成真换行。稍长一点的着色器请写成 .vert / .frag 文件，用 file.read 读：
       顶点 = file.read("光源.vert")
       片段 = file.read("光源.frag")
       好了 = hw.shader(1, 顶点, 片段)

   引擎自动喂这几个约定 uniform，不用自己设：
     uLight   vec3       —— hw.light 的方向（引擎每帧灌）
     uTex     sampler2D  —— 纹理单元 0，即 hw.texuse 选中的那张
     uTexMix  float      —— 0 = 不采样贴图，1 = 贴图 x 本色（默认 1） */
Value rt_hw_shader(Value sv, Value vsv, Value fsv)
{
    int slot = (int)hw_num(sv, "hw.shader 的槽位");
    if (slot < 1 || slot >= HW_SHADER_SLOTS) {
        hw_die("hw.shader：槽位要在 1~%d 之间（0 是固定管线）", HW_SHADER_SLOTS - 1);
        return rt_int(0);
    }
    if (g_win == NULL)
        hw_die("hw.shader：还没开窗口（先调用 hw.open）");
    hw_gl_load();
    if (!g_gl_ok) {
        fprintf(stderr, "hw.shader：取不到 GL 2.0+ 入口，着色器不可用\n");
        return rt_int(0);
    }
    char *vs = hw_unfold(hw_str(vsv, "hw.shader 的顶点源码"));
    char *fs = hw_unfold(hw_str(fsv, "hw.shader 的片段源码"));
    char log[2048] = {0};
    GLuint p = hw_build_program(vs, fs, log, sizeof log);
    free(vs);
    free(fs);
    if (p == 0) {
        fprintf(stderr, "hw.shader 槽 %d 编译失败:\n%s\n", slot, log);
        return rt_int(0);
    }
    if (g_progs[slot] != 0)
        glapi.DeleteProgram(g_progs[slot]);
    g_progs[slot] = p;
    g_ulight[slot] = glapi.GetUniformLocation(p, "uLight");
    return rt_int(1);
}

/* hw.preset(槽, 名字)：装一个内置着色器，省得自己写 GLSL。
   名字（中英都行）：
     lambert/朗伯  环境光 + 漫反射 + 可选贴图（和固定管线最接近，做基准用）
     toon/卡通     光照量化成 4 档色阶（改 uSteps）
     fresnel/边缘  视线擦过表面时发亮（uRim 边缘色 / uRimPow 锐度）
     checker/棋盘  按 UV 现场算格子，不采样贴图（uScale / uDark）
     normal/法线   把法线画成颜色，调 UV 和法线问题的利器
     unlit/自发光  只出本色 x 贴图，不算光照（UI / 发光体 / 天空盒）
   返回 1 成功、0 失败。装完用 hw.shaderuse(槽) 启用。 */
Value rt_hw_preset(Value sv, Value nv)
{
    int slot = (int)hw_num(sv, "hw.preset 的槽位");
    if (slot < 1 || slot >= HW_SHADER_SLOTS) {
        hw_die("hw.preset：槽位要在 1~%d 之间（0 是固定管线）", HW_SHADER_SLOTS - 1);
        return rt_int(0);
    }
    if (g_win == NULL)
        hw_die("hw.preset：还没开窗口（先调用 hw.open）");
    hw_gl_load();
    if (!g_gl_ok)
        return rt_int(0);
    const char *name = hw_str(nv, "hw.preset 的名字");
    const char *fs = hw_preset_fs_src(name);
    if (fs == NULL) {
        fprintf(stderr, "hw.preset：没有内置着色器 %s。"
                        "可用：lambert/朗伯 toon/卡通 fresnel/边缘 "
                        "checker/棋盘 normal/法线 unlit/自发光\n",
                name != NULL ? name : "(空)");
        return rt_int(0);
    }
    char log[2048] = {0};
    GLuint p = hw_build_program(HW_PRESET_VS, fs, log, sizeof log);
    if (p == 0) {
        fprintf(stderr, "hw.preset 槽 %d 编译失败:\n%s\n", slot, log);
        return rt_int(0);
    }
    hw_preset_defaults(p, name);
    if (g_progs[slot] != 0)
        glapi.DeleteProgram(g_progs[slot]);
    g_progs[slot] = p;
    g_ulight[slot] = glapi.GetUniformLocation(p, "uLight");
    return rt_int(1);
}

/* hw.shaderuse(槽)：之后的图元用这个着色器画；0 = 回固定管线。
   写进命令流，所以可以在一帧里穿插切换：
       a = hw.shaderuse(1)      # 世界用卡通着色器
       ... 画场景 ...
       a = hw.shaderuse(0)      # 辅助线 / gizmo 回固定管线（线没有法线）
       ... 画 gizmo ...
   （PYbook 里库调用不能当独立语句，所以要写成 变量 = hw.shaderuse(...)） */
Value rt_hw_shaderuse(Value sv)
{
    int slot = (int)hw_num(sv, "hw.shaderuse 的槽位");
    if (slot < 0 || slot >= HW_SHADER_SLOTS) {
        hw_die("hw.shaderuse：槽位要在 0~%d 之间（0 是固定管线）", HW_SHADER_SLOTS - 1);
        return rt_none();
    }
    g_curprog = slot;
    hw_op(OP_PROG, slot);
    return rt_none();
}

/* hw.uni(名字, a[, b[, c[, d]]])：设一个 uniform。
   1 个值 → float，2 个 → vec2，3 个 → vec3，4 个 → vec4。
   按命令流顺序生效；着色器里没声明的名字会被静默忽略（方便共用脚本）。
   注意：着色器请用 hw.uni 之外的名字，别覆盖 uLight / uTex / uTexMix。 */
Value rt_hw_univ(int nargs, Value *av)
{
    if (nargs < 2 || nargs > 5) {
        hw_die("hw.uni：写法是 hw.uni(\"名字\", a[, b[, c[, d]]])");
        return rt_none();
    }
    if (g_nunis >= HW_UNI_MAX)
        hw_die("hw.uni：单帧 uniform 数超过上限 %d", HW_UNI_MAX);
    HwUni *u = &g_unis[g_nunis++];
    const char *nm = hw_str(av[0], "hw.uni 的名字");
    snprintf(u->name, sizeof u->name, "%s", nm != NULL ? nm : "");
    u->kind = nargs - 1;
    for (int i = 0; i < 4; i++)
        u->v[i] = (i < u->kind) ? (float)hw_num(av[1 + i], "hw.uni 的值") : 0.0f;
    u->loc = -1;
    u->loc_prog = 0;
    hw_op(OP_UNI, g_nunis - 1);
    return rt_none();
}

Value rt_hw_end(void)
{
    if (g_win == NULL)
        return rt_int(0);
    pump();
    return rt_int(g_quit ? 1 : 0);
}

Value rt_hw_key(Value namev)
{
    if (g_win == NULL)
        return rt_int(0);
    pump();
    SDL_Scancode sc = hw_scancode(hw_str(namev, "hw.key 的键名"));
    if (sc == SDL_SCANCODE_UNKNOWN)
        return rt_int(0);
    return rt_int(g_kcur[sc] ? 1 : 0);
}

Value rt_hw_hit(Value namev)
{
    if (g_win == NULL)
        return rt_int(0);
    pump();
    SDL_Scancode sc = hw_scancode(hw_str(namev, "hw.hit 的键名"));
    if (sc == SDL_SCANCODE_UNKNOWN)
        return rt_int(0);
    return rt_int((g_kcur[sc] && !g_kprev[sc]) ? 1 : 0);
}

Value rt_hw_mx(void)
{
    if (g_win == NULL)
        return rt_int(0);
    int x, y;
    SDL_GetMouseState(&x, &y);
    return rt_int(x);
}

Value rt_hw_my(void)
{
    if (g_win == NULL)
        return rt_int(0);
    int x, y;
    SDL_GetMouseState(&x, &y);
    return rt_int(y);
}

Value rt_hw_mdown(void)
{
    if (g_win == NULL)
        return rt_int(0);
    pump();
    return rt_int((SDL_GetMouseState(NULL, NULL) & SDL_BUTTON_LMASK) ? 1 : 0);
}

Value rt_hw_mhit(void)
{
    if (g_win == NULL)
        return rt_int(0);
    pump();
    return rt_int((g_mcur && !g_mprev) ? 1 : 0);
}
