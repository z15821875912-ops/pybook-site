"""PYbook 桥接工具：源码 -> .pybc 字节码（可选立即用 pyvm.exe 运行）。

用法:
    python pybk_build.py 源.pybk [输出.pybc] [-r]

流程: 读源码 -> pybk_bc.compile_source(src) -> 写 .pybc -> 打印反汇编摘要。
-r: 编译后立即调用 pyvm.exe 运行（pyvm 的退出码作为本工具的退出码）。
编译错误写 stderr 并以退出码 1 结束。
"""

import os
import subprocess
import sys

from pybk_bc import compile_source, disasm, CompileError
from pybk_front import parse, PybkError

PYVM = 'pyvm.exe'


def die(msg):
    print(msg, file=sys.stderr)
    sys.exit(1)


def main():
    args = [a for a in sys.argv[1:] if a != '-r']
    run_after = '-r' in sys.argv[1:]
    if not 1 <= len(args) <= 2:
        die("用法: python pybk_build.py 源.pybk [输出.pybc] [-r]")
    path = args[0]
    out_path = args[1] if len(args) == 2 else os.path.splitext(path)[0] + '.pybc'

    try:
        src = open(path, encoding='utf-8-sig').read()
    except FileNotFoundError:
        die(f"找不到文件: {path}")

    try:
        data = compile_source(src)
    except (PybkError, CompileError) as e:
        die(str(e))

    with open(out_path, 'wb') as f:
        f.write(data)
    try:
        print(disasm(data))
    except Exception as e:
        # 反汇编摘要是尽力而为：已知 pybk_bc.disasm 对 'B' 操作数按 4 字节
        # 计长导致含 CALL 的模块错位（详见 test_report.md）。不影响编译产物。
        print(f"[警告] 反汇编摘要失败（字节码本身已生成）: {e}", file=sys.stderr)

    if run_after:
        if not os.path.exists(PYVM):
            die(f"找不到 {PYVM}，请先编译虚拟机")
        proc = subprocess.run([PYVM, out_path])
        sys.exit(proc.returncode)


if __name__ == '__main__':
    main()
