/* OpenGL 能力探针：搞清楚"我们到底站在哪一档"。
   关键问题：opengl32.dll 只导出 GL 1.1，但 GL 2.0+ 的入口可以靠
   SDL_GL_GetProcAddress 取到 —— 所以 GLSL / FBO / VAO 是不是真的可用？
   本探针真开上下文、真查字符串、真取函数指针、真编译一个 GLSL 程序。 */
#define SDL_MAIN_HANDLED
#include <SDL2/SDL.h>
#include <GL/gl.h>
#include <GL/glext.h>
#include <stdio.h>

static void 打印指针(const char *name, void *p)
{
    printf("    %-28s %s\n", name, p ? "可用" : "**取不到**");
}

static void 打印限制(const char *name, GLenum e)
{
    GLint v = -1;
    glGetIntegerv(e, &v);
    if (glGetError() == GL_NO_ERROR)
        printf("    %-28s %d\n", name, v);
    else
        printf("    %-28s （不支持）\n", name);
}

/* 真编译一个 GLSL 程序，确认整条路（取指针→编译→链接→取 uniform）通 */
static int 编译着色器(void)
{
    PFNGLCREATESHADERPROC     CreateShader     = (PFNGLCREATESHADERPROC)SDL_GL_GetProcAddress("glCreateShader");
    PFNGLSHADERSOURCEPROC     ShaderSource     = (PFNGLSHADERSOURCEPROC)SDL_GL_GetProcAddress("glShaderSource");
    PFNGLCOMPILESHADERPROC    CompileShader    = (PFNGLCOMPILESHADERPROC)SDL_GL_GetProcAddress("glCompileShader");
    PFNGLGETSHADERIVPROC      GetShaderiv      = (PFNGLGETSHADERIVPROC)SDL_GL_GetProcAddress("glGetShaderiv");
    PFNGLGETSHADERINFOLOGPROC GetShaderInfoLog = (PFNGLGETSHADERINFOLOGPROC)SDL_GL_GetProcAddress("glGetShaderInfoLog");
    PFNGLCREATEPROGRAMPROC    CreateProgram    = (PFNGLCREATEPROGRAMPROC)SDL_GL_GetProcAddress("glCreateProgram");
    PFNGLATTACHSHADERPROC     AttachShader     = (PFNGLATTACHSHADERPROC)SDL_GL_GetProcAddress("glAttachShader");
    PFNGLLINKPROGRAMPROC      LinkProgram      = (PFNGLLINKPROGRAMPROC)SDL_GL_GetProcAddress("glLinkProgram");
    PFNGLGETPROGRAMIVPROC     GetProgramiv     = (PFNGLGETPROGRAMIVPROC)SDL_GL_GetProcAddress("glGetProgramiv");
    PFNGLGETPROGRAMINFOLOGPROC GetProgramInfoLog = (PFNGLGETPROGRAMINFOLOGPROC)SDL_GL_GetProcAddress("glGetProgramInfoLog");
    PFNGLGETUNIFORMLOCATIONPROC GetUniformLocation = (PFNGLGETUNIFORMLOCATIONPROC)SDL_GL_GetProcAddress("glGetUniformLocation");

    if (!CreateShader || !ShaderSource || !CompileShader || !GetShaderiv ||
        !CreateProgram || !AttachShader || !LinkProgram || !GetProgramiv)
        return 0;

    /* 一个带方向光 + 贴图采样的最小着色器 —— 就是固定管线做不到的那套 */
    const char *vs =
        "#version 330 core\n"
        "layout(location=0) in vec3 Pos;\n"
        "layout(location=1) in vec3 Nrm;\n"
        "layout(location=2) in vec2 UV;\n"
        "uniform mat4 MVP;\n"
        "out vec3 vNrm; out vec2 vUV;\n"
        "void main(){ vNrm=Nrm; vUV=UV; gl_Position = MVP*vec4(Pos,1.0); }\n";
    const char *fs =
        "#version 330 core\n"
        "in vec3 vNrm; in vec2 vUV;\n"
        "uniform vec3 LightDir; uniform sampler2D Albedo;\n"
        "out vec4 Frag;\n"
        "void main(){\n"
        "  float d = max(dot(normalize(vNrm), normalize(LightDir)), 0.0);\n"
        "  Frag = vec4(texture(Albedo, vUV).rgb * (0.35 + 0.65*d), 1.0);\n"
        "}\n";

    GLuint v = CreateShader(GL_VERTEX_SHADER);
    GLuint f = CreateShader(GL_FRAGMENT_SHADER);
    ShaderSource(v, 1, &vs, NULL);
    ShaderSource(f, 1, &fs, NULL);
    CompileShader(v);
    CompileShader(f);

    GLint ok = 0;
    GetShaderiv(v, GL_COMPILE_STATUS, &ok);
    if (!ok) {
        char log[1024] = {0};
        if (GetShaderInfoLog) GetShaderInfoLog(v, sizeof log, NULL, log);
        printf("    顶点着色器编译失败: %s\n", log);
        return 0;
    }
    GetShaderiv(f, GL_COMPILE_STATUS, &ok);
    if (!ok) {
        char log[1024] = {0};
        if (GetShaderInfoLog) GetShaderInfoLog(f, sizeof log, NULL, log);
        printf("    片段着色器编译失败: %s\n", log);
        return 0;
    }

    GLuint p = CreateProgram();
    AttachShader(p, v);
    AttachShader(p, f);
    LinkProgram(p);
    GetProgramiv(p, GL_LINK_STATUS, &ok);
    if (!ok) {
        char log[1024] = {0};
        if (GetProgramInfoLog) GetProgramInfoLog(p, sizeof log, NULL, log);
        printf("    着色器程序链接失败: %s\n", log);
        return 0;
    }
    GLint loc = GetUniformLocation ? GetUniformLocation(p, "MVP") : -1;
    printf("    着色器程序编译+链接成功，uniform MVP 位置 = %d\n", loc);
    return 1;
}

static void 跑一轮(const char *标签, int 要core)
{
    printf("\n=== %s ===\n", 标签);
    SDL_GL_SetAttribute(SDL_GL_DOUBLEBUFFER, 1);
    SDL_GL_SetAttribute(SDL_GL_DEPTH_SIZE, 24);
    if (要core) {
        SDL_GL_SetAttribute(SDL_GL_CONTEXT_MAJOR_VERSION, 3);
        SDL_GL_SetAttribute(SDL_GL_CONTEXT_MINOR_VERSION, 3);
        SDL_GL_SetAttribute(SDL_GL_CONTEXT_PROFILE_MASK, SDL_GL_CONTEXT_PROFILE_CORE);
    }
    SDL_Window *w = SDL_CreateWindow("gl probe", 0, 0, 320, 240,
                                     SDL_WINDOW_HIDDEN | SDL_WINDOW_OPENGL);
    if (!w) { printf("    建窗失败: %s\n", SDL_GetError()); return; }
    SDL_GLContext c = SDL_GL_CreateContext(w);
    if (!c) { printf("    建上下文失败: %s\n", SDL_GetError()); SDL_DestroyWindow(w); return; }

    const char *ver = (const char *)glGetString(GL_VERSION);
    const char *ven = (const char *)glGetString(GL_VENDOR);
    const char *ren = (const char *)glGetString(GL_RENDERER);
    const char *sl  = (const char *)glGetString(GL_SHADING_LANGUAGE_VERSION);
    printf("    GL_VERSION      %s\n", ver ? ver : "(空)");
    printf("    GL_VENDOR       %s\n", ven ? ven : "(空)");
    printf("    GL_RENDERER     %s\n", ren ? ren : "(空)");
    printf("    GLSL            %s\n", sl ? sl : "(空)");

    printf("  -- 上限 --\n");
    打印限制("GL_MAX_LIGHTS", 0x0D31);
    打印限制("GL_MAX_TEXTURE_UNITS", 0x84E2);
    打印限制("GL_MAX_TEXTURE_SIZE", 0x0D33);
    打印限制("GL_MAX_VERTEX_ATTRIBS", 0x8869);
    打印限制("GL_MAX_COLOR_ATTACHMENTS", 0x8CDF);

    printf("  -- GL 2.0+ 入口（靠 SDL_GL_GetProcAddress 取）--\n");
    打印指针("glCreateShader",       SDL_GL_GetProcAddress("glCreateShader"));
    打印指针("glCreateProgram",      SDL_GL_GetProcAddress("glCreateProgram"));
    打印指针("glGenBuffers(VBO)",    SDL_GL_GetProcAddress("glGenBuffers"));
    打印指针("glGenVertexArrays(VAO)", SDL_GL_GetProcAddress("glGenVertexArrays"));
    打印指针("glGenFramebuffers(FBO)", SDL_GL_GetProcAddress("glGenFramebuffers"));
    打印指针("glActiveTexture",      SDL_GL_GetProcAddress("glActiveTexture"));
    打印指针("glUniformMatrix4fv",   SDL_GL_GetProcAddress("glUniformMatrix4fv"));
    打印指针("glDrawElements",       SDL_GL_GetProcAddress("glDrawElements"));

    printf("  -- 真编译一个 GLSL 程序 --\n");
    if (!编译着色器())
        printf("    失败\n");

    SDL_GL_DeleteContext(c);
    SDL_DestroyWindow(w);
}

int main(void)
{
    SDL_SetMainReady();
    if (SDL_Init(SDL_INIT_VIDEO) != 0) { printf("SDL init 失败\n"); return 1; }
    /* 第一轮：和 pybook_hw3d.c 现在一模一样的属性（不指定版本） */
    跑一轮("现状：不指定版本（hw3d 现在就是这么建的）", 0);
    /* 第二轮：显式要 3.3 core */
    跑一轮("显式要 3.3 core profile", 1);
    SDL_Quit();
    return 0;
}
