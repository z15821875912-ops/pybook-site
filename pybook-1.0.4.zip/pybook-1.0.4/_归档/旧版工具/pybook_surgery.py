"""PYbook_new.exe 手术脚本：把 PYZ 里的 pybook.cli 替换为 v2 编译桥接。

原 exe 不动，产出 PYbook_v2.exe。
"""
import marshal
import struct
import types
import zlib

SRC = r'C:\Users\zhuli\Downloads\PYbook_new.exe'
DST = r'C:\Users\zhuli\Downloads\PYbook_v2.exe'
BRIDGE = r'C:\Users\zhuli\Desktop\pybook\pybk_bridge_cli.py'
TARGET = 'pybook.cli'
MAGIC = b'MEI\x0c\x0b\x0a\x0b\x0e'

# ---------- 1. 读原包 ----------
data = open(SRC, 'rb').read()
pos = data.rfind(MAGIC)
pkglen, toc_off, toc_len, pyver = struct.unpack('!IIII', data[pos + 8:pos + 24])
libname = data[pos + 24:pos + 24 + 64]
base = len(data) - pkglen
toc_start = base + toc_off

entries = []          # (name, typ, flag, raw_blob, usize)
p = toc_start
while p < toc_start + toc_len:
    (entry_len,) = struct.unpack('!i', data[p:p + 4])
    epos, csize, usize = struct.unpack('!III', data[p + 4:p + 16])
    flag, typ = data[p + 16], data[p + 17]
    name = data[p + 18:p + entry_len].rstrip(b'\x00').decode('utf-8', 'replace')
    entries.append((name, typ, flag, data[base + epos:base + epos + csize], usize))
    p += entry_len
print(f'原 CArchive 条目 {len(entries)} 个')

# ---------- 2. 拆 PYZ ----------
pyz_i = next(i for i, e in enumerate(entries) if e[0].upper().startswith('PYZ'))
name, typ, flag, pyz_blob, _u = entries[pyz_i]
pyz = zlib.decompress(pyz_blob) if flag == 1 else pyz_blob
assert pyz[:4] == b'PYZ\x00'
pyz_magic = pyz[4:8]
(toc_pos,) = struct.unpack('!i', pyz[8:12])
ptoc = marshal.loads(pyz[toc_pos:])
print(f'PYZ 模块 {len(ptoc)} 个；数据起始偏移 {min(v[1] for _, v in ptoc)}')

# ---------- 3. 编译桥接模块并生成新 blob ----------
src = open(BRIDGE, encoding='utf-8').read()
new_code = compile(src, 'pybook/cli.py', 'exec')
new_cli = zlib.compress(marshal.dumps(new_code))
print(f'新 pybook.cli blob：{len(new_cli)} 字节')

# ---------- 4. 重组 PYZ ----------
min_off = min(v[1] for _, v in ptoc)
data_start = min_off
blobs, off, new_ptoc = [], data_start, []
for item in ptoc:
    nm, (t, o, ln) = item
    if nm == TARGET:
        blob = new_cli
    else:
        blob = pyz[o:o + ln]
    new_ptoc.append([nm, [t, off, len(blob)]])
    blobs.append(blob)
    off += len(blob)
data_part = b''.join(blobs)
toc_bytes = marshal.dumps(new_ptoc)
new_pyz = pyz[:8] + struct.pack('!i', len(data_part) + data_start - len(data_part) + data_start)[:0] \
    + b''  # 占位，下面统一拼
new_pyz = pyz[:8] + struct.pack('!i', data_start + len(data_part)) + \
    b'\x00' * (data_start - 12) + data_part + toc_bytes
# 自检：新 PYZ 必须能原样加载，且 pybook.cli 已是桥接版
chk_toc = marshal.loads(new_pyz[struct.unpack('!i', new_pyz[8:12])[0]:])
chk = dict(chk_toc)
_t, o, l = chk[TARGET]
d = new_pyz[o:o + l]
if d[:1] == b'\x78':
    d = zlib.decompress(d)
probe = marshal.loads(d)
assert any(c.co_name == 'run_source' for c in probe.co_consts
           if isinstance(c, types.CodeType))
assert any(c.co_name == 'run_source' for c in probe.co_consts
           if isinstance(c, types.CodeType))
print('新 PYZ 自检通过：pybook.cli 已是桥接版')

new_pyz_blob = zlib.compress(new_pyz) if flag == 1 else new_pyz

# ---------- 5. 重组 CArchive ----------
new_entries = [(n, t, f, new_pyz_blob if i == pyz_i else b, u)
               for i, (n, t, f, b, u) in enumerate(entries)]
data_section = b''
toc_items = []
for n, t, f, b, u in new_entries:
    epos = len(data_section)
    csize = len(b)
    toc_items.append((n, t, f, epos, csize, u))
    data_section += b
toc_bytes2 = b''
for n, t, f, epos, csize, u in toc_items:
    nb = n.encode('utf-8') + b'\x00'
    body = struct.pack('!III', epos, csize, u) + bytes([f, t]) + nb
    toc_bytes2 += struct.pack('!i', len(body) + 4) + body
cookie_len = 8 + 16 + 64
pkglen2 = len(data_section) + len(toc_bytes2) + cookie_len
cookie = MAGIC + struct.pack('!IIII', pkglen2, len(data_section), len(toc_bytes2), pyver) + libname
new_exe = data[:base] + data_section + toc_bytes2 + cookie
try:
    open(DST, 'wb').write(new_exe)
    print(f'产出 {DST}，{len(new_exe)} 字节（原 {len(data)}）')
except PermissionError:
    alt = DST.replace('.exe', '_new.exe')
    open(alt, 'wb').write(new_exe)
    print(f'目标被占用（编辑器正开着），改产出 {alt}，{len(new_exe)} 字节')
    print('请关闭正在运行的编辑器后，把 _new.exe 改名覆盖原文件即可。')
