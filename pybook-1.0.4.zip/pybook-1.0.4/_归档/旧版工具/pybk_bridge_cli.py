"""PYbook v2 编译桥接 —— 本模块替换原 v1 的 pybook.cli。

run_source 对 GUI 的接口签名与 v1 完全一致：
    run_source(source, filename, stdout, stdin, width)
但执行改为调用 PYbook v2 编译器（Python 前端 → 生成 C → gcc → 原生 exe）。
"""

import os
import shutil
import subprocess
import sys
import tempfile

try:
    from pybook.errors import PybookError
except ImportError:          # 兜底：v1 errors 缺失时自定义
    class PybookError(Exception):
        pass

_PYTHONS = [
    r'C:\Users\zhuli\AppData\Local\Programs\Python\Python311\python.exe',
]
_PIPELINES = [
    r'C:\Users\zhuli\Desktop\pybook\pybk_main.py',
]


def _find_python():
    for p in _PYTHONS:
        if os.path.exists(p):
            return p
    w = shutil.which('python') or shutil.which('python3')
    if w:
        return w
    raise RuntimeError('找不到系统 Python（v2 编译器需要它来跑前端）')


def _find_pipeline():
    for p in _PIPELINES:
        if os.path.exists(p):
            return p
    raise RuntimeError('找不到 v2 编译器管线 pybk_main.py')


def run_source(source, filename='', stdout=None, stdin=None, width=80):
    """执行一段 PYbook v2 源码：编译成 C → gcc → 运行原生 exe。"""
    if stdout is None:
        stdout = sys.stdout
    py = _find_python()
    pipe = _find_pipeline()
    fd, path = tempfile.mkstemp(suffix='.pybk', prefix='pybook_run_')
    with os.fdopen(fd, 'w', encoding='utf-8') as f:
        f.write(source)
    # 交互程序（用了 ip/input）：弹独立控制台窗口，键盘输入直达原生程序
    interactive = ('input(' in source) or ('vg(ip)' in source)
    if interactive:
        bat = path + '.run.bat'
        with open(bat, 'w', encoding='gbk') as f:
            f.write('@echo off\n')
            f.write('cd /d "%s"\n' % os.path.dirname(pipe))
            f.write('"%s" "%s" "%s"\n' % (py, pipe, path))
            f.write('pause\n')
        flags = 0
        if hasattr(subprocess, 'CREATE_NEW_CONSOLE'):
            flags = subprocess.CREATE_NEW_CONSOLE
        subprocess.call(['cmd', '/c', bat], creationflags=flags,
                        cwd=os.path.dirname(pipe))
        try:
            os.remove(path)
            os.remove(bat)
        except OSError:
            pass
        return None

    # 非交互程序：管道模式，输出实时回显到编辑器
    proc = subprocess.Popen(
        [py, pipe, path],
        stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        text=True, encoding='utf-8', errors='replace',
        cwd=os.path.dirname(pipe),
    )
    import threading

    def _drain_stderr(sink):
        try:
            for line in proc.stderr:
                sink.append(line)
        except Exception:
            pass

    err_lines = []
    threading.Thread(target=_drain_stderr, args=(err_lines,), daemon=True).start()

    try:
        for line in proc.stdout:
            stdout.write(line)   # 停止时 gui 的流会抛它自己的 Interrupted
    except BaseException:
        proc.kill()              # 异常退出前先杀掉原生程序
        raise
    proc.wait()
    try:
        os.remove(path)
    except OSError:
        pass

    err = ''.join(err_lines).strip()
    if proc.returncode != 0:
        raise PybookError(err or ('编译器/程序异常退出，代码 %d' % proc.returncode))


def run_file(path, stdout=None, stdin=None, width=80):
    """执行一个 .pybook 文件（保留 v1 接口）。"""
    with open(path, encoding='utf-8') as f:
        return run_source(f.read(), path, stdout, stdin, width)


def main(argv=None):
    """命令行入口（保留 v1 接口）。"""
    argv = list(sys.argv[1:] if argv is None else argv)
    if not argv:
        print('用法: pybook <文件.pybook>')
        return 2
    run_file(argv[0])
    return 0
