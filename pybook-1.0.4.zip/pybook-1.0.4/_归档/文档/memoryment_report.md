# Memoryment 一致性验收报告

- 验收对象：Memoryment（内存管理档位）在两条执行后端上的行为一致性
  - A 路（原生）：`python pybk_main.py 用例.pybk`（pybk_code → C → gcc → app.exe）
  - B 路（VM）：`pybk_bc.compile_source` → `pyvm.exe t.pybc`
- gcc：`C:\Users\zhuli\mingw64\bin\gcc.exe`
- 判定口径：退出码必须一致；stdout 剥离 ANSI 转义码后逐行一致；报错文案允许措辞差异，但"报错 vs 正常"的判定必须一致。
- 用例目录：`mm_tests\`；驱动脚本：`mm_accept.py`（可复跑）。
- 结论先行：**8 用例 × 双路全部一致，未发现缺陷，无需修复。** 附加 3 项探针（GOING 内声明、@2≡@self、函数内 del 槽位隔离）也全部一致。

## 一、语义实现现状（验收前核对）

两路均以 `pybook_rt` 的 `g_memmode` 为唯一语义源：

| 环节 | 原生（pybk_code.py） | 字节码（pybk_bc.py → pyvm.c） |
|---|---|---|
| Memoryment 声明 | `rt_set_memmode(mode);` | `SETMEM 0x35 (u8 mode)` → `rt_set_memmode` |
| del | `rt_destroy(&槽)` | `DEL 0x34` → `rt_destroy(slot)` |
| lock | `rt_gold`/锁定标志 | `GOLD 0x33` → `flags \|= F_LOCKED` |
| @3 及以上 | 前端 `parse_memoryment` 抛 `PybkError：…暂未实现…`（两路共用同一前端，天然同判） | 同左 |
| 删除后使用 | `rt_chk` → `rt_die("用已删除变量")` | `LOAD` 经 `rt_chk`，同一检查 |

## 二、8 用例 × 双路结果表

| 用例 | 覆盖点 | A 退出码 | B 退出码 | A 关键行为 | B 关键行为 | 结论 |
|---|---|---|---|---|---|---|
| mm01_normal_delete | @normal 删除（不使用） | 0 | 0 | 输出 `还活着 10` | 同 | 一致 |
| mm02_self_delete | @self 删字符串+列表 | 0 | 0 | 输出 `手动删除完成` | 同 | 一致 |
| mm03_self_use_after | @self 删后使用 | 1 | 1 | `运行时错误: 用已删除变量` | 同文案 | 一致 |
| mm04_at1_use_after | @1（≡@normal）删后使用 | 1 | 1 | `运行时错误: 用已删除变量` | 同文案 | 一致 |
| mm05_mode3_reject | @3 编译期拒绝 | 1 | 1 | `第 2 行：Memoryment 模式 3 暂未实现（当前支持 1/2/normal/self）` | 同文案（异常栈内） | 一致 |
| mm06_two_arounds_delete | 顺序两个 around 各带 del（@self） | 0 | 0 | `第一圈/第二圈/完成` | 同 | 一致 |
| mm07_gold_delete_use | lock+del 组合后使用 | 1 | 1 | `运行时错误: 用已删除变量`（del 不检查锁定，使用时被 F_DELETED 拦下） | 同 | 一致 |
| mm08_fn_memoryment | 函数内声明 Memoryment 后 del | 0 | 0 | 输出 `结果 7` | 同 | 一致 |

补充：stdout 全量比对（剥 ANSI、统一换行）8 例全部逐字节一致，含 mm01/02/06/08 的正常输出与 mm03/04/07 的空 stdout。

## 三、附加探针（超出 8 用例的边界确认）

| 探针 | A 路 | B 路 | 结论 |
|---|---|---|---|
| Memoryment 写在 GOING 体内（非 GOING 前） | rc=0，输出 `内嵌OK` | 同 | 一致 |
| @2 ≡ @self：删后使用 | rc=1（用已删除变量） | 同 | 一致 |
| 函数内 del 同名参数，不波及调用方变量（槽位隔离） | rc=0，输出 `主变量还在 0` | 同 | 一致 |

## 四、修复记录

无。两条后端的 Memoryment 行为完全一致，未发现需要修复的缺陷。

过程说明（非工具链问题）：首轮对比曾出现 4 例"B 路全失败"，根因是驱动脚本里 `open(路径, 'utf-8-sig')` 把编码串误放到了 buffering 参数位（`ValueError: invalid mode`），改正为 `open(路径, encoding='utf-8-sig')` 后全部消除。任务书里给出的 B 路命令模板 `open(用例,'utf-8')` 也有同样的位置参数笔误，复用时请加 `encoding=`。

## 五、交付物

- `mm_tests\`：8 个 Memoryment 用例（mm01–mm08）
- `mm_accept.py`：一致性驱动脚本（可复跑）
- `memoryment_report.md`：本文件
- 修复后的文件：无（无需修复）
