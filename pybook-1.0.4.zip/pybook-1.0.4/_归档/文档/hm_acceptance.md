# hm（网页输出）分支双后端接线与验收说明

## 交付物
- `pybk_code.py`（更新）：hm 语句 → rt_page_* 调用接线；compile_and_run 尾部自动开浏览器
- `pybk_bc.py`（更新）：遇 HmStmt 编译期拒绝（VM v1 边界）
- `ide_web_test.pybk` + `cat.png`（1×1 橙色 PNG，供 <img> 正常渲染）
- 本说明

## 原生后端接线（pybk_code.py）
- `web.big/mid` → `rt_page_h(rt_str_of(拼接Value), 1|2)`；$插值部件（TEXT/VAR/EXPR）
  用 `rt_add` 串成链后经一次 `rt_str_of` 收口（静态缓冲只调用一次，无别名风险）
- `web.show` → `rt_page_para_open(样式token)` + 逐部件 `rt_page_text`(原文，运行时转义)
  /`rt_page_value`(表达式求值) + `rt_page_para_close()`
- 样式串：`/magic` 列表原样以逗号连接下传——运行时 `page_style_css` 的 token
  方言（b/i/u/d/c=R,G,B/bk=R,G,B/fm/fl/fr/l/m/r）与任务样式表逐项对应，
  产出与编译期翻译完全相同的 CSS
- `web.img` → `rt_page_img("文件名")`；`web.line` → `rt_page_hr()`
- `web.link("文字","网址")` → `rt_page_link(文字, 网址)`
- 首条 hm 语句自动补 `rt_page_begin(meta)`；GOING 末尾自动补 `rt_page_save()`
- `$名字 未声明` 沿用既有 `check_declared` 路径，报错带行号
- `compile_and_run`：源码含 hm（编译时已知）且 app.exe 退出码 0 →
  `os.startfile(pybook_page.html)` 自动弹浏览器

## VM 后端（pybk_bc.py）
遇 HmStmt 抛 `CompileError: 第 N 行：hm 网页语句暂不支持 VM 模式，请用原生模式（F5）`；
非 hm 程序的字节码编译不受影响（已回归验证）。

## 验收结果
1. `python pybk_main.py ide_web_test.pybk` → rc=0，生成 `pybook_page.html`（588B），
   八项断言全过：`<h1>`（含"欢迎来到 PYbook 的主页"）、`<h2>`、
   `style="font-weight:bold; color:rgb(0,200,255)"`、插值段落"答案=42"、`<hr>`、
   `<img src="cat.png">`、`<a href="https://example.com">点这里访问 Example</a>`；
   浏览器已由 os.startfile 自动打开。
2. 回归：`python tests/run_tests.py` → **96/96 通过**（用例集已由 86 扩至 96，
   新增 T17 内存系列，全部通过）；`python pybk_main.py games/dragon.pybk <
   games/通关输入.txt` → 正常通关，退出码 0。
3. VM 拒绝：pybk_bc 遇 hm 报"第 7 行：hm 网页语句暂不支持 VM 模式，请用原生模式（F5）"；
   tests/01基础.pybk 仍可正常编译字节码。

## 已知限制（运行时合同约束，非本次缺陷）
冻结版 `pybook_rt.c` 的 `page_style_css` 没有 `f.名称`/`fs.数字` 两个 token
（未知 token 会 `rt_die("不支持的样式 …")`），且 `rt_page_para_open` 只收 token
不收 CSS 原文，因此 hm 专属样式 `f./fs.` 暂无法渲染：编译器按任务样式表解析后
目前过滤下发（不崩溃、不产生错误样式），其余全部样式正常生效。建议后续给
`page_style_css` 增加 `f.`/`fs.` 两个 token 即可补全。

## 红线自查
未改动 pybk_front.py、pybook_rt.c/h、pyvm.c、tests\ 目录、旧语言文件；
pybk_bc.py 仅加 hm 拒绝分支；pybk_code.py 仅加 hm 接线。
