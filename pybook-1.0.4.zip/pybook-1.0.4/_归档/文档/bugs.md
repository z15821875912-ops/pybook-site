# PYbook v2 缺陷报告（bugs.md）

> **状态**：S3 关键字英文迁移已完成。B1-B9 全部修复。本文件为历史记录。

测试对象：PYbook v2（`pybk_main.py` + `pybk_front.py` + `pybk_code.py` + `pybook_rt.c`）
测试日期：2026-08-31
严重度分级：**崩溃 > 结果错误 > 该报错没报 > 报错信息差 > 体验**

> **语言主线声明（2026-09-05）**：v1 链（`demo.lang` / `lexer.py` / `parser.py` / `codegen.py` / `main.py`，类 C 语法）已归档至 `legacy/`，不再维护。PYbook 唯一主线 = v2（`pybk_*` 全家桶）。新语法/库/修复只针对 v2。

本次共 86 个自动化用例（`tests\cases.py` + `tests\run_tests.py`，结果见 `tests\results.md`），
另含若干手动探索。**未发现"崩溃"与"结果错误"级缺陷**；以下按严重度从高到低排列。
所有 bug 均只报告、未修复；每条给出最小复现。

---

## B3 lock 锁定后 list.添加 仍可修改列表（该报错没报）

- **严重度**：该报错没报
- **复现文件**（tests\T13_gold_push.pybk，最小复现如下）：

```
@ a>b>c
GOING:{
vg_ro.a = [1]
lock(a)
list.添加(a, 2)
ns.show($a)
}STOP
```

- **运行命令**：`C:\Users\zhuli\AppData\Local\Programs\Python\Python311\python.exe pybk_main.py tests\T13_gold_push.pybk`
- **期望**：lock(名) 锁定后再"赋值"应报运行时错误。同文件把 `list.添加(a, 2)` 换成
  `vg_ro.a[0] = 9` 时确实报 `运行时错误: 变量已锁定`（见 tests\T13_gold_setindex.pybk），
  因此 添加 这条变更路径也应拦截。
- **实际**：退出码 0，正常输出 `[1, 2]` —— 锁定后列表仍被追加成功。
- **根因线索**：`pybook_rt.c` 的 `rt_push()` 只检查 `F_DELETED`，未检查 `F_LOCKED`；
  而 `rt_setindex()` 两个都查，行为不一致。
- **关联用例**：T13_gold_push、T13_gold_setindex

---

## B1 语法/词法错误未被入口捕获，用户看到整屏 Python traceback（报错信息差）

- **严重度**：报错信息差（影响所有语法类错误，用户观感等同"编译器崩了"）
- **复现文件**（tests\E01_no_at.pybk，缺 @ 行）：

```
GOING:{
ns.show(x)
}STOP
```

- **运行命令**：`C:\Users\zhuli\AppData\Local\Programs\Python\Python311\python.exe pybk_main.py tests\E01_no_at.pybk`
- **期望**：按语言约定输出一行 `第 1 行：期望 'AT'，实际是 'GOING'`，退出码 1。
- **实际**：输出十几行 `Traceback (most recent call last): ...`，
  最后一行才是 `pybk_front.PybkError: 第 1 行：期望 'AT'，实际是 'GOING'`，退出码 1。
- **根因线索**：`pybk_main.py` 只捕获 `(PybkCodegenError, RuntimeError)`，
  前端的 `PybkError` 不在其内，直接裸抛。同类受影响用例：E01/E02/E03/E04/E05/E06、
  T06_dollar_empty、T06_show_unclosed、T07_magic_alias_err、T07_magic_color_partial、
  T10_vc_minus_solo、T10_vc_plus_mid、T11_cd_float、E07、E10、E11。
- **附带发现**：前端错误用全角冒号（`第 N 行：`），后端用半角（`第 N 行: `），
  修复时可顺手统一。
- **UTF-8 BOM 变体**：带 BOM 的文件（Windows 记见本常见）报
  `第 1 行：非法字符 '\ufeff'` + traceback（tests\E16_bom.pybk），
  前端宜在读取时剥除 BOM 并给出更友好的提示。

---

## B8 布尔字面量是英文 true/false，与全中文语法割裂；写真/假 报误导性错误（报错信息差）

- **严重度**：报错信息差（兼设计确认项）
- **复现文件**（tests\E15_bool_cjk_literal.pybk）：

```
@ a>b>c
GOING:{
vg.d = 真
}STOP
```

- **运行命令**：`C:\Users\zhuli\AppData\Local\Programs\Python\Python311\python.exe pybk_main.py tests\E15_bool_cjk_literal.pybk`
- **期望**：布尔值显示为 真/假（`rt_str_of` 如此），语言定位"中文友好"，
  字面量 宜接受 真/假；若按现行设计只认 true/false，报错信息也应提示
  "布尔字面量请写 true/false"，而不是把 真 当成普通变量名。
- **实际**：`第 3 行: 变量 '真' 未声明`。
- **对照**：`vg.d = true` 正常，显示为 `真`（tests\T02_vars_ok.pybk）。
- **关联用例**：T02_vars_ok、E15_bool_cjk_literal

---

## B2 深层嵌套括号触发 Python 递归爆栈，无行号的英文报错（报错信息差）

- **严重度**：报错信息差（编译器本身未崩，被当作 RuntimeError 捕获，但对用户是黑话）
- **复现文件**（tests\E08_deep_nest.pybk，300 层嵌套括号）：

```
@ a>b>c
GOING:{
vg.x = ((((…(1)…))))   ← 共 300 层
}STOP
```

- **运行命令**：`C:\Users\zhuli\AppData\Local\Programs\Python\Python311\python.exe pybk_main.py tests\E08_deep_nest.pybk`
- **期望**：报 `第 2 行：表达式嵌套过深` 之类带行号的中文错误（或干脆正常编译）。
- **实际**：stderr 仅一行英文 `maximum recursion depth exceeded while calling a Python object`
  （RecursionError 属 RuntimeError 子类，被 pybk_main 兜住），无行号，退出码 1。
- **根因线索**：`pybk_front._Parser` 表达式解析为递归下降，每层括号约耗 8 层 Python 栈，
  Python 默认递归上限 1000，约 120+ 层括号即触顶。
- **关联用例**：E08_deep_nest

---

## B4 rm.around 次数非整数的报错前缀是英文 runtime error:（报错信息差）

- **严重度**：报错信息差
- **复现文件**（tests\T08_around_float_err.pybk）：

```
@ a>b>c
GOING:{
rm.around(2.5) {
    ns.show(x)
}
}STOP
```

- **运行命令**：`C:\Users\zhuli\AppData\Local\Programs\Python\Python311\python.exe pybk_main.py tests\T08_around_float_err.pybk`
- **期望**：与全局错误约定一致，输出 `运行时错误: rm.around 次数不是整数`。
- **实际**：`runtime error: rm.around 次数不是整数`（英文前缀），退出码 1。
- **根因线索**：`pybk_code.py` 的 `gen_around()` 自行 `fprintf(stderr, "runtime error: ...")`
  + `exit(1)`，未走 `pybook_rt.c` 的 `rt_die()` 统一出口。
- **关联用例**：T08_around_float_err

---

## B5 "到文件尾才发现"的错误行号被文件尾注释推大（报错信息差）

- **严重度**：报错信息差
- **复现文件**（tests\E14b_pure.pybk，STOP 写在了第 5 行、与 } 不同行）：

```
@ a>b>c
GOING:{
ns.show(x)
}
STOP
# 注释A
# 注释B
```

- **运行命令**：`C:\Users\zhuli\AppData\Local\Programs\Python\Python311\python.exe pybk_main.py tests\E14b_pure.pybk`
- **期望**：`第 5 行：STOP 必须紧跟在 } 之后（同一行）`（指向出错的 STOP）。
- **实际**：`第 8 行：STOP 必须紧跟在 } 之后（同一行）` —— 报错在消费完 STOP 后取
  "当前 token"（EOF）的行号，文件尾注释（及空行）全部被计入。
  受影响的还有"块缺少收尾的 }""期望 'AT'，实际是 'EOF'"等 EOF 锚定错误。
- **关联用例**：E05_stop_line、E06_missing_brace、E14_trailing_comment

---

## B6 相邻的 $变量 插值被拼接成一个不存在的名字（报错信息差）

- **严重度**：报错信息差
- **复现文件**（tests\E12_dollar_adjacent.pybk）：

```
@ a>b>c
GOING:{
rm.around(2) {
    ns.show($at$at)
}
}STOP
```

- **运行命令**：`C:\Users\zhuli\AppData\Local\Programs\Python\Python311\python.exe pybk_main.py tests\E12_dollar_adjacent.pybk`
- **期望**：两个插值分别取 at，输出 `00` / `01`；至少也不应报出一个用户没写过的变量名。
- **实际**：`第 4 行: 变量 'atat' 未声明` —— 插值预处理去掉内部 $ 后 "atat" 被词法成
  一个标识符。`$at $at`（中间有空格）则正常输出 `0 0`，空格作为文本保留。
- **根因线索**：`pybk_front._interp_expr()` 的"去掉内部 $"再分词策略，相邻标识符会粘连。
- **关联用例**：T08_around_ok、E12_dollar_adjacent

---

## B7 插值表达式遇逗号截断，报错误导（报错信息差）

- **严重度**：报错信息差
- **复现文件**（tests\E13_interp_comma.pybk）：

```
@ a>b>c
func 加(a, b) {
    ret a + b
}
GOING:{
ns.show($list.加(3, 4))
}STOP
```

- **运行命令**：`C:\Users\zhuli\AppData\Local\Programs\Python\Python311\python.exe pybk_main.py tests\E13_interp_comma.pybk`
- **期望**：要么支持，要么报"插值表达式里不能用逗号"这类点到原因的错误
  （语言说明本就写了插值不能用逗号）。
- **实际**：`第 6 行: 变量 'out' 未声明` —— $ 后文本在逗号处截断，
  只解析出 `out`，把保留字 out 当变量名报错，用户很难自我诊断。
  注：单参数的插值调用 `$list.加倍(21)` 实际可用（tests\T06_interp_call.pybk 输出 翻倍=42），
  与"插值里不能用小括号"的说明也不一致。
- **关联用例**：E13_interp_comma、T06_interp_call、T06_interp_paren_text

---

## B9 调用层缺参数/缺文件直接抛 Python traceback（体验）

- **严重度**：体验
- **复现命令**：
  - `python.exe pybk_main.py`（不给参数）→ `IndexError: list index out of range` traceback
  - `python.exe pybk_main.py tests\不存在.pybk` → `FileNotFoundError` traceback
- **期望**：一行中文用法提示 / "找不到文件：xxx"。
- **实际**：完整 Python traceback（退出码 1）。
- **说明**：属命令行入口的易用性问题，非语言缺陷。

---

## 观察（非缺陷，建议设计确认/文档同步）

| # | 观察 | 证据用例 |
|---|---|---|
| O1 | 插值里单参函数调用实际可用（`$list.加倍(21)` → 42），与"插值表达式里不能用小括号和逗号"的说明不一致，建议更新文档或收紧实现 | T06_interp_call、T06_interp_paren_text |
| O2 | 不支持函数前向引用：先定义的函数调用后定义的函数 → 编译期"未定义"；且语法要求所有 fv 必须在 GOING 之前 | T12_fn_forward |
| O3 | `-9223372036854775808` 无法书写：负号是独立一元运算符，字面量部分先越界报错（LLONG_MIN 写不出来） | T15_neg_min_literal |
| O4 | 链式比较 `1 < x < 3` 按 `(1 < x) < 3` 解释、布尔当 0/1 参与比较，与 Python 语义不同，文档未定义 | T14_chain_cmp |
| O5 | `vg_ro` 前缀不强制只读（可整体重新赋值），`vg` 也能装列表 —— 动态类型下 ro 只是命名约定 | T02_dynamic_ro |
| O6 | fm/fr/fl 对齐的"可见宽度"按 UTF-8 字节数近似（中文按 3 字节计），含中文的行在真实终端（中文占 2 列）会偏移数列；纯 ASCII 精确 | T07_align_ok |
| O7 | 每个函数独立作用域：函数内看不到 GOING 变量，函数间同名变量互不影响（合理，但文档未写明） | T12_fn_scope |
| O8 | `and`/`or` 返回操作数本身、`list.添加` 返回空盒、`/` 一律得浮点并按 `%.15g` 去尾零 —— 已按实现固化为测试预期 | T14_logic_ok、T05_add_ret_none、T14_arith_ok |
