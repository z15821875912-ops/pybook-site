# PYbook v2 实例测试结果

运行命令：`C:\Users\zhuli\AppData\Local\Programs\Python\Python311\python.exe pybk_main.py tests\案例名.pybk`
（在 C:\Users\zhuli\Desktop\pybook 下执行；比对时忽略行末 ANSI 转义码）

## 逐案例结果

- 01基础.pybk ✓
- 02算术.pybk ✓
- 03字符串.pybk ✓
- 04列表.pybk ✓
- 05计数循环.pybk ✓
- 06条件循环.pybk ✓
- 07判断链.pybk ✓
- 08顺序重排.pybk ✗（重跑 1 次仍不符，非偶发）
- 09函数.pybk ✓
- 10锁定报错.pybk ✓
- 11未声明报错.pybk ✓
- 12越界报错.pybk ✓

## 不符合案例详情

### 08顺序重排.pybk

- 预期输出顺序：一 / 普通 / 二
- 实际退出码：0（与预期一致）
- 实际输出（原文，每行末尾均带 ANSI 转义码 \x1b[0m，两次运行结果相同）：

```
一
二
普通
```

## 汇总

11/12 通过
