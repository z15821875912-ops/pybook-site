# PYbook v2 双后端对比验收报告

- 验收人：工具链与验收工程师
- 对比对象：
  - A 路（旧原生后端）：`python pybk_main.py <用例.pybk>`
  - B 路（新字节码后端）：`python pybk_build.py <用例.pybk> && pyvm.exe <用例.pybc>`
- 比对规则：退出码必须一致；stdout 去除 ANSI 转义码后逐行一致；双方都报错退出的用例视为通过（错误文案允许措辞差异）。
- 驱动脚本：`_accept.py`（保留在目录中，可复跑）。
- 注意：验收进行期间 `pyvm.c` 与 `pybk_bc.py` 曾被并行修改（pyvm.c 于 19:19 更新并重编后，此前大面积"未知指令 0x50"的假象消失）。本报告为最终稳定复跑结果，交付前如再改文件请重跑 `_accept.py`。

## 一、总表

| 用例 | 退出码 A/B | 结论 | 备注 |
|---|---|---|---|
| tests/01基础 | 0/0 | 一致 | 输出 `你好 PYbook 2 号`，符合预期 |
| tests/02算术 | 0/0 | 一致 | `3.5/3/1/14`，符合预期 |
| tests/03字符串 | 0/0 | 一致 | `你好世界/长度=4/你` |
| tests/04列表 | 0/0 | 一致 | `[10, 20, 30, 40]/20/40/4`，符合预期 |
| tests/05计数循环 | 0/0 | 一致 | `第 1/2/3 圈`，符合预期 |
| tests/06条件循环 | 0/0 | 一致 | `结束 n=3` |
| tests/07判断链 | 0/0 | 一致 | `良`，符合预期 |
| tests/08顺序重排 | 0/0 | 一致 | `一/二/普通`，符合预期（保持该顺序未动） |
| tests/09函数 | 0/0 | 一致 | `81`，符合预期 |
| tests/10锁定报错 | 1/1 | 双方报错 | A:`程序异常退出，退出码 1`；B:`运行时错误: 变量已锁定` |
| tests/11未声明报错 | 1/1 | 双方报错 | A:`第 3 行：变量 '不存在' 未声明`；B:`第 3 行：未声明的变量 '不存在'`（编译期报） |
| tests/12越界报错 | 1/1 | 双方报错 | A:`程序异常退出，退出码 1`；B:`运行时错误: 下标：下标越界` |
| guitest.pybk | 0/0 | 一致 | 含 magic，输出经 ANSI 剥离后一致 |
| final_test.pybk | **0/1** | **不一致** | 见缺陷 1 |
| test2.pybk | 0/0 | 一致 | 含 when 重排与函数调用，输出一致 |

结论：16 个用例 15 个通过；`final_test.pybk` 不一致，根因已定位（缺陷 1，责任在字节码编译器）。

## 二、缺陷 1：顺序 rm.around 的隐藏槽位冲突 → VM 槽位越界

- **责任方：pybk_bc.py（字节码编译器）**。只报告，未修复。
- 现象：`final_test.pybk` 在 B 路跑到第二个 `rm.around` 时，VM 报 `虚拟机错误: 槽位索引 7 越界（函数只有 7 个槽）`，退出码 1；A 路正常完整输出（含 `总分=175`、`翻倍=42`）。
- 机制：编译器为每层 around 分配隐藏槽 `@at{depth}` / `@cnt{depth}`，depth 取自会弹栈复用的 `loops` 深度，因此**顺序两个 around 的隐藏槽同名**；而 `new_slot()` 对已存在的键重新编号但不增加 `len(slots)`，导致第二个 around 实际访问的槽号等于 `nslots`，函数表里记录的槽位总数也随之偏小。
- 最小复现（以下均为真实运行结果）：

  ```
  @ t
  GOING:{
  vg.n = 2
  rm.around(n) {
      ns.show(a $at)
  }
  rm.around(n) {
      ns.show(b $at)
  }
  }STOP
  ```

  - A 路（pybk_main.py）：`a 0` `a 1` `b 0` `b 1`，退出码 0
  - B 路（pybk_build + pyvm）：`a 0` `a 1` 之后报 `虚拟机错误: 槽位索引 3 越界（函数只有 3 个槽）`，退出码 1
  - 对照组：单个 around 一切正常（已排除插值表达式 `$at+1` 等嫌疑）。
- 建议修法（供 bc 同事参考，未动代码）：隐藏槽名带全局唯一序号，或 `new_slot` 遇已存在键时强制新增槽位。

## 三、缺陷 2：pybk_bc.disasm 把 'B' 操作数按 4 字节计长

- **责任方：pybk_bc.py（disasm 反汇编器）**。只报告，未修复。
- 现象：`compile_source` 产物的指令流本身完全正确（按指令表逐函数走查全部对齐，VM 可正常执行），但 `disasm()` 的预扫描用 `4 if c in 'IB'` 计算操作数长度——`B`（u8，实际 1 字节）被当成 4 字节。凡含 `CALL`（规格 `UB`）的模块，反汇编必错位，最终抛 `未知操作码 0x??`。
- 影响：`pybk_build.py` 的"打印反汇编摘要"步骤对含函数调用的程序失败。已把 `pybk_build.py` 的摘要改为尽力而为（失败时 stderr 警告，不阻断编译产物）。
- 最小复现：任何带 `list.调用(...)` 的程序，如

  ```
  @ t
  func 加倍(n) {
      ret n * 2
  }
  GOING:{
  vg.r = list.加倍(21)
  ns.show($r)
  }STOP
  ```

  `compile_source` 成功，`disasm` 抛 `代码区偏移 …：未知操作码 0x…`。
- 建议修法：`size = 1 + sum(2 if c == 'U' else (1 if c == 'B' else 4) for c in spec)`。

## 四、其他记录

1. 任务一编译 `pyvm.exe`：`gcc -O2 pyvm.c pybook_rt.c -o pyvm.exe` 一次通过，未做任何修改。
2. `10/11/12` 三个报错用例：旧后端在运行期报错（A 路经 pybk_main 归一为 `程序异常退出，退出码 1`），新后端 11 在编译期报错、10/12 在 VM 运行期报错；退出码均 1/1，均"报错退出"，符合验收口径。
3. 验收过程中 pyvm.c/pybk_bc.py 有并行改动（过程记录，非最终状态问题）：19:19 前的 pyvm.c 与 pybk_bc 的容器格式曾不一致（B 路普遍报 `未知指令 0x50`，ip=1 即落在文件头魔数处）；更早版本的 pybk_bc 缺 `ListLit/Index/AssignIndex/GoldDel` 导入（NameError: ListLit / unhashable type: 'Index'）。两者在最终复跑时均已不存在。

## 五、交付物

- `pyvm.exe`（由当前 pyvm.c + pybook_rt.c 编译，-O2）
- `pybk_build.py`（桥接工具：编译、写 .pybc、打印反汇编摘要、`-r` 立即运行）
- `test_report.md`（本文件）
- 附件：`_accept.py`（验收驱动，可复跑）

---

# 游戏引擎集成验收（追加章节）

- 链路：`games/game_move.pybk` → pybk_front → pybk_code（GAME_CALLS → rt_win/clear/color/box/key/show/wait/end）→ gcc（默认控制台版游戏零件：GetAsyncKeyState 读键 + VT 转义渲染，CONOUT$ 直写）→ app.exe
- 样例 `games/game_move.pybk` 为新建（内容与任务样例一致）。

## 验收结果

| 项 | 结果 |
|---|---|
| tests/run_tests.py 全量回归 | ✅ **96/96 通过**（修复后复跑两次确认稳定） |
| pybk_front.py 前端自测 | ✅ 通过（if/elif/else/when/$插值/裸 ret/web/lb 类/帧动画/go/key 均正确，错误带行号） |
| games/game_move.pybk 可玩性 | ✅ 新控制台启动后循环稳定运行；合成方向键右移有效；ESC 退出，退出码 0 |
| ESC 短按退出 | ✅ 0.2 秒短按即可退出（见修复 3） |

## 发现与修复（均为集成层，未触碰 ns.show/rm/if-elif-else/Memoryment/lock/del 既有行为）

1. **残留 app.exe 进程锁死链接**：一名此前测试遗留的 app.exe（PID 32328）使后续所有用例的 gcc 链接报 `cannot open output file app.exe: Permission denied`，曾造成回归 54/96 假失败；另有被取消的回归留下的孤儿 run_tests 进程与现行用例流**交叉踩踏 out.c/app.exe**（失败详情里出现其他用例的输出）。处置：终止残留进程；`pybk_code.py` 的链接步骤对 "Permission denied" 增加 4 次退避重试（0.3s 递增）。**后续根治**：链接输出改为每进程唯一的 `app_<pid>_<n>.exe`，不再复用固定名 app.exe，从而不会去覆盖那个被锁住的残留文件（注意：不可用 os.remove 清理，沙箱 safe-delete shim 会 fail-closed 并把错误写进 stderr，污染精确比对 stderr 的用例）。
2. **app.exe 生成后被杀软实时扫描短暂锁定**：`CreateProcess` 抛 `PermissionError (WinError 32)`。处置：`pybk_code.py` 运行步骤对 PermissionError 同样重试 4 次。
3. **短按 ESC 可能被错过（真实 UX 缺陷）**：全屏 `box(0,0,800,600)` 在控制台按字符格重绘，实测**单帧约 1 秒**，`rt_end` 只在帧界轮询 `GetAsyncKeyState` 瞬时状态，0.2 秒的短按会整段落在两次轮询之间。处置：`pybook_rt.c` 控制台版 `rt_end` 增加两道捕获——`GetAsyncKeyState` 低位历史位（本进程上次轮询后按过）+ `PeekConsoleInput` 非破坏性扫描控制台输入队列中的 ESC KEY_EVENT（不消费事件，不影响 input() 复用）。复测：0.2 秒短按 → 5.5 秒内闩锁退出，退出码 0。

## 过程记录
- 首轮回归 42/96（根因 1 的遗留进程），清理后 86/96（残留孤儿进程），再次清理 + 链接重试后 91/96，加运行重试与 rt_end 修复后 **96/96**。
- SDL2 像素版（-DRT_GAME_SDL）未启用：机器上无 ucrt64/SDL2，且默认控制台版已完整满足验收；SDL 路径留待装齐 SDL2 后另行验证。
