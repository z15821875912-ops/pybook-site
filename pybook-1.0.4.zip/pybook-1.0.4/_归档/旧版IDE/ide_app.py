"""PYbook IDE 集成入口：组装同事的 ide_ui（主框架）与
ide_run（运行控制器）/ ide_highlight（语法高亮）/ ide_output（输出组件）。

接线内容（不改 ide_ui.py，用实例属性覆盖占位方法）：
    1. 编辑区挂 Highlighter（输入后 300ms 防抖高亮）；
    2. 用真实 IdeStream 替换流；
    3. _on_run 占位替换为真实运行：F5 原生 / Ctrl+B VM，工作线程执行，
       输出走 AnsiOutput；编译错误红显（write_tagged 'err'）。

用法：python ide_app.py           正常启动
      python ide_app.py --selftest  无头自测（见文末），退出码 0=通过
"""

import os
import sys
import threading
import tkinter as tk

_HERE = os.path.dirname(os.path.abspath(__file__))
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)

import ide_highlight
import ide_output
import ide_run
import ide_ui

SELFTEST_SRC = '''@ ide>集成>测试
GOING:{
vg.答案 = 6 * 7
ns.show(你好 v2！)/magic(b, c=0,200,255)
ns.show(答案=$答案)
}STOP
'''


def wire(app: ide_ui.PybookIDE):
    """把真实组件接进 PybookIDE 实例（覆盖占位，不动类定义）。"""
    # 1) 语法高亮
    app.highlighter = ide_highlight.Highlighter(app.text)
    _orig_set_text = app.set_text

    def _set_text_hl(s):
        _orig_set_text(s)
        app.highlighter.highlight()

    app.set_text = _set_text_hl          # 打开文件/装载文本后立即重高亮

    # 2) 真实流（转发到 AnsiOutput / ide_run.stop）
    app.stream = ide_run.IdeStream(output=app.output,
                                   input_bar=app.input_bar)

    # 3) 真实运行逻辑（替换占位 _on_run；菜单/工具栏/快捷键均引用
    #    self._on_run，实例属性优先于类方法，改这里即可全局生效）
    def _on_run(mode):
        src = app.get_text()
        app.output.clear()
        app.stream.write_tagged(
            f'▶ {"VM 字节码" if mode == "vm" else "原生 C"} 模式运行\n',
            'out-bold')
        app.set_run_enabled(True)

        def worker():
            try:
                ide_run.run_in_editor(src, app.stream, mode)
            finally:
                app.root.after(0, lambda: app.set_run_enabled(False))

        threading.Thread(target=worker, daemon=True).start()

    app._on_run = _on_run


def main():
    root = tk.Tk()
    root.geometry('1180x760')               # 默认窗口尺寸
    root.minsize(900, 600)                  # 最小窗口尺寸
    root.configure(bg=ide_ui.THEME['bg'])   # 残留默认灰底统一覆盖为深色
    app = ide_ui.PybookIDE(root)
    wire(app)

    if '--selftest' in sys.argv:
        return _selftest(root, app)

    root.mainloop()
    return 0


# ---------------------------------------------------------------- 无头自测

def _selftest(root: tk.Tk, app: ide_ui.PybookIDE):
    """自动验收：装载样例 → F5 原生 → 校验输出内容与 ANSI 着色 → 退出。"""
    import ide_output  # noqa: F401（_verify 走模块级引用）

    root.withdraw()                      # 自测不弹窗
    app.set_text(SELFTEST_SRC)
    result = {'done': False}

    def poll():
        if app.stream is not None and getattr(app, '_run_thread_alive', False):
            pass
        # 运行结束的标志：按钮恢复可用（set_run_enabled(False)）
        if str(app.btn_run_native['state']) == 'normal' and \
                app.output.text.get('1.0', 'end').strip():
            result['done'] = True
            root.after(200, check)
        else:
            root.after(150, poll)

    def check():
        try:
            ok, detail = _verify(app)
        except Exception as e:           # noqa
            ok, detail = False, f'校验异常: {e!r}'
        print(detail)
        print('自测' + ('通过' if ok else '失败'))
        root.destroy()
        app._selftest_ok = ok

    app.set_run_enabled(True)
    app._on_run('native')
    root.after(300, poll)
    root.mainloop()
    return 0 if getattr(app, '_selftest_ok', False) else 1


def _verify(app):
    text = app.output.text
    content = text.get('1.0', 'end')
    ok = True
    lines = []
    if '你好 v2！' not in content:
        return False, '输出缺少 你好 v2！，实际：' + repr(content[:200])
    if '答案=42' not in content:
        return False, '输出缺少 答案=42，实际：' + repr(content[:200])
    lines.append('输出内容 OK（含 你好 v2！ / 答案=42）')

    # 「你好 v2！」必须是加粗青色（magic b + c=0,200,255 → #00c8ff）
    idx = text.search('你好 v2！', '1.0', stopindex='end')
    if not idx:
        return False, '没在输出区找到目标文本'
    tags = text.tag_names(idx)
    want_bold = ide_output._tag_name(True, '#00c8ff')
    if want_bold not in tags:
        ok = False
        lines.append(f'着色 FAIL：期望 tag {want_bold}，实际 {tags}')
    else:
        lines.append(f'加粗青色 OK（tag={want_bold}）')

    # 「答案=42」应为普通文本（无着色 tag）
    idx2 = text.search('答案=42', '1.0', stopindex='end')
    tags2 = [t for t in text.tag_names(idx2) if t.startswith('out-')]
    if tags2:
        ok = False
        lines.append(f'答案=42 不应着色，实际 tags={tags2}')
    else:
        lines.append('答案=42 普通文本 OK')

    # 语法高亮抽查：编辑区里 GOING 应为橙色前缀码
    hidx = app.text.search('GOING', '1.0', stopindex='end')
    htags = app.text.tag_names(hidx)
    if 'hl-prefix' in htags:
        lines.append('语法高亮 OK（GOING=hl-prefix 橙）')
    else:
        ok = False
        lines.append(f'语法高亮 FAIL：GOING tags={htags}')
    return ok, '\n'.join(lines)


if __name__ == '__main__':
    sys.exit(main())
