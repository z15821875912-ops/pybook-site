"""PYbook v2 语法高亮器：基于 tkinter Text 的 tag 着色，输入后 300ms 防抖。

配色（深色主题）：关键字紫、前缀码橙、字符串绿、数字橙、注释灰（斜体）、
内置 input 青、默认文字 #cdd6f4。
词表来自 pybk_front.KEYWORDS；ns.show(...) 的裸文本区域不做词法判断，
按普通正则逐行扫描（裸文本里命中的关键字也会着色，属可接受的近似）。
"""

import re
import tkinter as tk
from tkinter import font as tkfont

from pybk_front import KEYWORDS

# 前缀码（vg./ns./rm. 这类命名空间前缀）单独配色，其余关键字归紫色
PREFIXES = {'vg', 'vg_ro', 'ns', 'rm', 'ip', 'web', 'when', 'func', 'lock',
            'del', 'list', 'GOING', 'STOP'}
# 内置输出/输入函数单独配色（青）
BUILTINS = {'input'}

# 深色主题语法配色（tag 名不变，只换色值）
THEME = {
    'hl-keyword': '#cba6f7',   # 关键字 紫
    'hl-prefix':  '#fab387',   # 前缀码 橙
    'hl-string':  '#a6e3a1',   # 字符串 绿
    'hl-number':  '#fab387',   # 数字 橙
    'hl-comment': '#6c7086',   # 注释 灰（斜体）
    'hl-builtin': '#89dceb',   # 内置 out/input 青
}

TOKEN_RE = re.compile(
    r'#(?s:.[^\n]*)'                                  # 注释到行末
    r'|"(?:[^"\\\n]|\\.)*"'                           # 字符串
    r'|\d+(?:\.\d+)?'                                 # 数字
    r'|[\u4e00-\u9fffA-Za-z_][\u4e00-\u9fff0-9A-Za-z_]*'  # 标识符/关键字
)


class Highlighter:
    def __init__(self, text_widget: tk.Text):
        self.text = text_widget
        italic = tkfont.Font(font=text_widget['font'])
        italic.configure(slant='italic')
        self._font_italic = italic
        for name, color in THEME.items():
            if name == 'hl-comment':
                self.text.tag_config(name, foreground=color, font=italic)
            else:
                self.text.tag_config(name, foreground=color)
        for name in THEME:
            self.text.tag_lower(name)
        self.text.tag_lower('sel')
        self._after_id = None
        self.text.bind('<KeyRelease>', self._on_key)

    # ---- 事件 ----

    def _on_key(self, event=None):
        if self._after_id is not None:
            self.text.after_cancel(self._after_id)
        self._after_id = self.text.after(300, self.highlight)

    # ---- 高亮 ----

    def highlight(self):
        self._after_id = None
        content = self.text.get('1.0', 'end-1c')
        for name in THEME:
            self.text.tag_remove(name, '1.0', 'end')
        for i, line in enumerate(content.split('\n'), start=1):
            for m in TOKEN_RE.finditer(line):
                tag = self._classify(m.group(0))
                if tag:
                    self.text.tag_add(tag, f'{i}.{m.start()}', f'{i}.{m.end()}')

    def _classify(self, tok: str):
        if tok.startswith('#'):
            return 'hl-comment'
        if tok.startswith('"'):
            return 'hl-string'
        if tok[0].isdigit():
            return 'hl-number'
        if tok in BUILTINS:
            return 'hl-builtin'
        if tok in KEYWORDS:
            return 'hl-prefix' if tok in PREFIXES else 'hl-keyword'
        return None
