"""IDE 运行控制器：把编辑区源码跑起来（原生 C 后端或 VM 后端）。

对外合同：
    run_in_editor(source, stream, mode='native')
        stream 需实现 write(text) 与 write_tagged(text, tag)。
        mode='native'：编译到 C → gcc → 运行 app.exe，输出流式写入；
            含 input( 或 vg(ip) 的源码改弹独立控制台窗口（CREATE_NEW_CONSOLE）
            运行 python pybk_main.py 临时文件（交互输入在新窗口完成）。
        mode='vm'：pybk_bc.compile_source → 写 .pybc → pyvm.exe 运行
            （pyvm.exe 缺失时先用 gcc 编译 pyvm.c pybook_rt.c）。
        编译/语义错误 → stream.write_tagged(信息, 'err')。
    stop()：杀掉当前运行的子进程。

调用方应把 run_in_editor 放在工作线程；本模块内的阻塞（等待子进程、
逐行读）只发生在该线程，tkinter 主线程不受影响。
"""

import os
import shutil
import subprocess
import sys
import threading

_HERE = os.path.dirname(os.path.abspath(__file__))
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)

PYBOOK_DIR = _HERE if os.path.basename(_HERE) == 'pybook' \
    else r'C:\Users\zhuli\Desktop\pybook'
FALLBACK_GCC = r'C:\Users\zhuli\mingw64\bin\gcc.exe'

C_NEW_CONSOLE = getattr(subprocess, 'CREATE_NEW_CONSOLE', 0)

_LOCK = threading.Lock()
_PROC = None          # 当前子进程（原生 exe / pyvm / 控制台 python）
_INTERACTIVE = False  # 当前是否为控制台窗口运行


def _gcc():
    return shutil.which('gcc') or FALLBACK_GCC


def _has_input(src: str) -> bool:
    return 'input(' in src or 'vg(ip)' in src


def run_in_editor(source, stream, mode='native'):
    global _PROC, _INTERACTIVE
    with _LOCK:
        try:
            if mode == 'vm':
                _run_vm(source, stream)
            else:
                _run_native(source, stream)
        finally:
            _PROC = None
            _INTERACTIVE = False


def stop():
    proc = _PROC
    if proc is not None and proc.poll() is None:
        try:
            proc.terminate()
        except OSError:
            pass


class IdeStream:
    """UI 侧流适配（ide_ui.PybookIDE 的合同组件）。

    write / write_ansi / write_tagged 转发到 AnsiOutput（其内部队列保证
    线程安全）；输入栏 submit() 缓存行，readline() 供将来就地交互用；
    stop() 转 ide_run.stop()；run() 把 run_in_editor 放进工作线程。
    """

    def __init__(self, output=None, input_bar=None):
        self.output = output
        self.input_bar = input_bar
        self._cond = threading.Condition()
        self._lines = []

    # ---- 输出 ----

    def write(self, text):
        if self.output is not None:
            self.output.write(text)

    def write_ansi(self, text):
        # AnsiOutput 本身就解析 ANSI，直接转发
        self.write(text)

    def write_tagged(self, text, tag):
        if self.output is not None:
            self.output.write_tagged(text, tag)

    # ---- 输入 ----

    def submit(self, line: str):
        with self._cond:
            self._lines.append(line)
            self._cond.notify_all()

    def readline(self, timeout=None):
        with self._cond:
            if not self._lines and timeout is not None:
                self._cond.wait(timeout)
            return self._lines.pop(0) if self._lines else ''

    # ---- 控制 ----

    def reset(self):
        with self._cond:
            self._lines.clear()

    def stop(self):
        stop()

    def run(self, source, mode='native'):
        threading.Thread(target=run_in_editor, args=(source, self, mode),
                         daemon=True).start()


# ---------------- 原生后端 ----------------

def _run_native(source, stream):
    global _PROC, _INTERACTIVE

    if _has_input(source):
        # 交互程序：弹独立控制台窗口，输入输出都在新窗口完成
        path = os.path.join(PYBOOK_DIR, '__ide_run.pybk')
        with open(path, 'w', encoding='utf-8') as f:
            f.write(source)
        stream.write_tagged('[已在新的控制台窗口运行，请在该窗口中完成输入]\n',
                            'info')
        proc = subprocess.Popen(
            [sys.executable, 'pybk_main.py', path],
            cwd=PYBOOK_DIR, creationflags=C_NEW_CONSOLE)
        _PROC, _INTERACTIVE = proc, True
        rc = proc.wait()
        if rc == 0:
            stream.write_tagged('[控制台程序已正常结束]\n', 'info')
        else:
            stream.write_tagged(f'[控制台程序已结束，退出码 {rc}]\n', 'err')
        return

    # 纯输出程序：AST → C → gcc → app.exe，流式回显
    from pybk_code import Codegen, PybkCodegenError
    from pybk_front import parse, PybkError
    try:
        program = parse(source)
        c_code = Codegen().generate(program)
    except (PybkError, PybkCodegenError) as e:
        stream.write_tagged(str(e) + '\n', 'err')
        return

    c_path = os.path.join(PYBOOK_DIR, 'out.c')
    with open(c_path, 'w', encoding='utf-8') as f:
        f.write(c_code)
    build = subprocess.run(
        [_gcc(), '-O2', '-o', 'app.exe', 'out.c', 'pybook_rt.c', 'pybook_lib.c', 'pybook_file.c'],
        cwd=PYBOOK_DIR, capture_output=True, text=True, errors='replace')
    if build.returncode != 0:
        stream.write_tagged('gcc 编译失败：\n' + (build.stderr or build.stdout),
                            'err')
        return

    exe = 'app.exe' if os.name == 'nt' else './app.exe'
    proc = subprocess.Popen(
        [exe], cwd=PYBOOK_DIR,
        stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        text=True, encoding='utf-8', errors='replace')
    _PROC = proc
    _pump(proc, stream)


def _pump(proc, stream):
    """逐行读子进程 stdout 写入 stream；stderr 起独立线程读，红显。"""
    err_thread = threading.Thread(target=_pump_err, args=(proc, stream),
                                  daemon=True)
    err_thread.start()
    for line in proc.stdout:
        stream.write(line)
    proc.stdout.close()
    rc = proc.wait()
    err_thread.join(timeout=2)
    if rc != 0:
        stream.write_tagged(f'[程序异常退出，退出码 {rc}]\n', 'err')


def _pump_err(proc, stream):
    for line in proc.stderr:
        stream.write_tagged(line, 'err')
    proc.stderr.close()


# ---------------- VM 后端 ----------------

def _run_vm(source, stream):
    global _PROC
    from pybk_bc import compile_source, CompileError
    from pybk_front import parse, PybkError
    try:
        data = compile_source(source)
    except (PybkError, CompileError) as e:
        stream.write_tagged(str(e) + '\n', 'err')
        return

    bc_path = os.path.join(PYBOOK_DIR, '__ide_run.pybc')
    with open(bc_path, 'wb') as f:
        f.write(data)

    vm = os.path.join(PYBOOK_DIR, 'pyvm.exe')
    if not os.path.exists(vm):
        stream.write_tagged('[pyvm.exe 不存在，正在编译虚拟机…]\n', 'info')
        build = subprocess.run(
            [_gcc(), '-O2', 'pyvm.c', 'pybook_rt.c', '-o', 'pyvm.exe'],
            cwd=PYBOOK_DIR, capture_output=True, text=True, errors='replace')
        if build.returncode != 0:
            stream.write_tagged('pyvm 编译失败：\n'
                                + (build.stderr or build.stdout), 'err')
            return

    proc = subprocess.Popen(
        [vm, bc_path], cwd=PYBOOK_DIR,
        stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        text=True, encoding='utf-8', errors='replace')
    _PROC = proc
    _pump(proc, stream)
