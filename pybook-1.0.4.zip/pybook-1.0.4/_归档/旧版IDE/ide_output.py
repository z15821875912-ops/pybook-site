"""PYbook IDE 的输出与输入组件（仅标准库：tkinter / queue / threading / re / time）。

三个部件：
  AnsiOutput  运行输出区：Text + 垂直滚动条 + 右上角"清空"按钮。
              write / write_ansi / write_tagged / clear 可在任意线程调用——
              内部只进队列，主线程定时器统一刷入 Text 控件（绝不跨线程碰控件）。
              ANSI 样式：0 重置、1 加粗、3 斜体、4 下划线、9 删除线、
              38;2;R;G;B 前景、48;2;R;G;B 背景（合同范围）；另兼容 30-37/90-97
              色板、38;5;N 256 色、22/23/24/29 关闭、39/49 默认色。
              跨调用拆散的转义序列自动凑齐；超过 max_lines（默认 5000）行裁掉旧行。
              样式 tag 命名：_tag_name(bold, color) → 'out-b<hex>'/'out-bold'/
              'out-<hex>'/'out-plain'；斜体/下划线/删除线/背景分别用
              'out-italic'/'out-under'/'out-strike'/'out-bg<hex>' 叠加。
  InputBar    单行输入栏：Entry + 发送按钮，回车即提交；可整体禁用/启用，可聚焦。
  IdeStream   编译器（工作线程）与界面（主线程）之间的线程安全流适配器：
              输出走 out_queue，输入走 in_queue，readline() 阻塞等用户提交一行，
              停止时返回 ''；readline 等待期间置位 input_requested 供界面启用输入栏。
              构造时可选 IdeStream(output=AnsiOutput, input_bar=InputBar)：
              内部自建主线程泵，把 out_queue 自动渲染到输出区并联动输入栏；
              不传（合同用法）则由调用方自行消费 out_queue。

自测：python ide_output.py  弹出测试窗口（上半输出区 + 测试按钮，下半输入栏，
另起线程每 0.5 秒写一条彩色行，并演示 readline/submit 的完整回路）。
红线：本文件不涉及任何编译器逻辑，不依赖 pybk_front / pybk_code。
"""

import queue
import re
import threading
import time
import tkinter as tk
from tkinter import font as tkfont
from tkinter import ttk

# 完整 CSI 转义：\x1b[ <参数> <结束字母>；只有 'm'（SGR 样式）会被渲染，其余忽略
_ANSI_CSI = re.compile(r'\x1b\[([0-9;]*)([A-Za-z])')

# ---- 深色主题（VS Code / Catppuccin 风）：所有颜色集中在此，勿散落魔法值 ----
THEME = {
    'output_bg':   '#11111b',   # 输出区/输入栏背景
    'fg':          '#cdd6f4',   # 默认文字
    'fg_dim':      '#a6adc8',   # 次要文字（info 标签）
    'fg_disabled': '#6c7086',   # 禁用态文字
    'selection':   '#45475a',   # 选中背景
    'cursor':      '#f5c2e7',   # 光标
    'hover':       '#313244',   # 悬停背景
    'border':      '#313244',   # 边框
    'err':         '#f38ba8',   # err 标签红
    # 字体：与编辑区同款等宽；界面文字用雅黑
    'mono_family': ('Cascadia Code', 'Consolas', 'Courier New'),
    'ui_family':   ('Microsoft YaHei UI', 'Microsoft YaHei'),
    'mono_size':   12,
    'ui_size':     10,
    # 30-37 标准前景 / 90-97 亮色前景（贴近 Windows Terminal 默认色板）
    'std_fg': {30: '#000000', 31: '#cd3131', 32: '#0dbc79', 33: '#e5e510',
               34: '#2472c8', 35: '#bc3fbc', 36: '#11a8cd', 37: '#e5e5e5'},
    'bright_fg': {90: '#767676', 91: '#f14c4c', 92: '#23d18b', 93: '#f5f543',
                  94: '#3b8eea', 95: '#d670d6', 96: '#29b8db', 97: '#ffffff'},
    # xterm-256 色的前 16 色
    'palette16': ('000000', 'cd3131', '0dbc79', 'e5e510', '2472c8',
                  'bc3fbc', '11a8cd', 'e5e5e5',
                  '767676', 'f14c4c', '23d18b', 'f5f543', '3b8eea',
                  'd670d6', '29b8db', 'ffffff'),
}

# 30-37 标准前景 / 90-97 亮色前景（值来自 THEME）
_STD_FG = THEME['std_fg']
_BRIGHT_FG = THEME['bright_fg']

TAG_ERR = 'out-err'      # 兼容旧引用
_TAG_STYLES = {
    'err':  {'foreground': THEME['err']},
    'info': {'foreground': THEME['fg_dim']},
    TAG_ERR: {'foreground': THEME['err']},
}


def _tag_name(bold, color):
    """(加粗?, '#rrggbb') → 样式 tag 名：'out-b<hex>' / 'out-bold' / 'out-<hex>' / 'out-plain'。"""
    if bold and color:
        return f'out-b{color[1:]}'
    if bold:
        return 'out-bold'
    return f'out-{color[1:]}' if color else 'out-plain'


def _xterm256(n):
    """xterm-256 色号 → '#rrggbb'。"""
    if n < 16:
        return '#' + THEME['palette16'][min(n, 15)]
    if n < 232:
        n -= 16
        steps = (0, 95, 135, 175, 215, 255)
        return '#%02x%02x%02x' % (steps[n // 36], steps[(n // 6) % 6], steps[n % 6])
    v = 8 + (n - 232) * 10
    return f'#{v:02x}{v:02x}{v:02x}'


def _pick_family(candidates):
    """候选字体名里返回第一个系统已安装的；都未安装则退回最后一个。"""
    try:
        installed = set(tkfont.families())
    except Exception:
        return candidates[-1]
    for name in candidates:
        if name in installed:
            return name
    return candidates[-1]


def _ui_font():
    """界面字体（按钮/标签）：雅黑 10 号。"""
    return (_pick_family(THEME['ui_family']), THEME['ui_size'])


def _flat_button(parent, text, command, fg=None, padx=8, pady=4):
    """扁平深色按钮（工具栏同款风格）：悬停变亮，禁用态不响应悬停。"""
    color = fg or THEME['fg']
    btn = tk.Button(parent, text=text, command=command,
                    font=_ui_font(), cursor='hand2', takefocus=0,
                    relief='flat', bd=0, highlightthickness=0,
                    bg=THEME['output_bg'], fg=color,
                    activebackground=THEME['hover'], activeforeground=color,
                    disabledforeground=THEME['fg_disabled'],
                    padx=padx, pady=pady)

    def _enter(_):
        if str(btn.cget('state')) != 'disabled':
            btn.config(bg=THEME['hover'])

    def _leave(_):
        btn.config(bg=THEME['output_bg'])

    btn.bind('<Enter>', _enter)
    btn.bind('<Leave>', _leave)
    return btn


def apply_dark_ttk_style(master):
    """ttk 控件统一切 clam 主题并配深色（滚动条/按钮/框架/标签）；幂等。"""
    style = ttk.Style(master)
    if style.theme_use() != 'clam':
        style.theme_use('clam')
    style.configure('TScrollbar',
                    background=THEME['hover'], troughcolor=THEME['output_bg'],
                    bordercolor=THEME['output_bg'], arrowcolor=THEME['fg_dim'],
                    lightcolor=THEME['hover'], darkcolor=THEME['hover'],
                    relief='flat')
    style.map('TScrollbar',
              background=[('pressed', THEME['selection']),
                          ('active', THEME['selection'])],
              arrowcolor=[('disabled', THEME['fg_disabled'])])
    style.configure('TButton',
                    background=THEME['hover'], foreground=THEME['fg'],
                    bordercolor=THEME['hover'], darkcolor=THEME['hover'],
                    lightcolor=THEME['hover'], focusthickness=0,
                    padding=(8, 4), relief='flat')
    style.map('TButton',
              background=[('disabled', THEME['output_bg']),
                          ('pressed', THEME['selection']),
                          ('active', THEME['selection'])],
              foreground=[('disabled', THEME['fg_disabled'])])
    style.configure('TFrame', background=THEME['output_bg'])
    style.configure('TLabel', background=THEME['output_bg'],
                    foreground=THEME['fg'])


class AnsiOutput(tk.Frame):
    """运行输出区。write / write_ansi / write_tagged / clear 可在任意线程调用。"""

    def __init__(self, master, max_lines=5000, refresh_ms=40, height=14, **kw):
        kw.setdefault('bg', THEME['output_bg'])
        super().__init__(master, **kw)
        apply_dark_ttk_style(self)
        self._max_lines = max_lines
        self._refresh_ms = refresh_ms
        self._q = queue.Queue()          # ('text'|'ansi'|'tagged'|'clear', 文本, 标签)

        # 字体：与编辑区同款等宽；粗体/斜体做成基础字体的变体，颜色按 _tag_name 懒创建
        fam = _pick_family(THEME['mono_family'])
        base = tkfont.Font(family=fam, size=THEME['mono_size'])
        self._font_bold = tkfont.Font(family=fam, size=THEME['mono_size'])
        self._font_bold.configure(weight='bold')
        self._font_italic = tkfont.Font(family=fam, size=THEME['mono_size'])
        self._font_italic.configure(slant='italic')

        # 顶部一行：右上角"清空"按钮（工具栏同款扁平深色）
        bar = tk.Frame(self, bg=THEME['output_bg'])
        bar.pack(fill='x')
        _flat_button(bar, '清空', self.clear).pack(side='right', padx=6, pady=4)

        body = tk.Frame(self, bg=THEME['output_bg'])
        body.pack(fill='both', expand=True)
        self.text = tk.Text(body, height=height, width=80, wrap='none', state='disabled',
                            font=base,
                            bg=THEME['output_bg'], fg=THEME['fg'],
                            insertbackground=THEME['fg'],
                            selectbackground=THEME['selection'],
                            selectforeground=THEME['fg'],
                            borderwidth=0, highlightthickness=1, relief='flat',
                            highlightbackground=THEME['border'],
                            highlightcolor=THEME['border'],
                            takefocus=False)
        scroll = ttk.Scrollbar(body, orient='vertical', command=self.text.yview)
        self.text.configure(yscrollcommand=scroll.set)
        scroll.pack(side='right', fill='y')
        self.text.pack(side='left', fill='both', expand=True)

        # 预置 tag：write_tagged 的语义标签 + 正交样式 + 色板
        for name, opt in (('err', {'foreground': THEME['err']}),
                          ('info', {'foreground': THEME['fg_dim']}),
                          (TAG_ERR, {'foreground': THEME['err']}),
                          ('out-bold', {'font': self._font_bold}),
                          ('out-italic', {'font': self._font_italic}),
                          ('out-under', {'underline': True}),
                          ('out-strike', {'overstrike': True})):
            self.text.tag_configure(name, **opt)
        for c in (list(_STD_FG.values()) + list(_BRIGHT_FG.values())
                  + ['#' + THEME['palette16'][0]]):
            self.text.tag_configure(_tag_name(False, c), foreground=c)
            self.text.tag_configure(_tag_name(True, c), foreground=c, font=self._font_bold)
        self._made_tags = set(self.text.tag_names())
        self.text.tag_lower('sel')

        # ANSI SGR 当前状态（跨多次 write_ansi 保持，直到收到 0 号复位）
        self._ansi = {'bold': False, 'italic': False, 'under': False, 'strike': False}
        self._fg = None                  # None 或 '#rrggbb'
        self._bg = None
        self._ansi_buf = ''              # 跨调用拆散的半截转义序列在这里等凑齐

        self.after(self._refresh_ms, self._drain_loop)

    def configure(self, cnf=None, **kw):
        """适配：height(行数) 映射到内部 Text，其余走 Frame。"""
        if cnf:
            kw.update(cnf)
        if 'height' in kw:
            self.text.configure(height=kw.pop('height'))
        return super().configure(**kw) if kw else None

    # ---------- 对外 API（线程安全：只进队列） ----------

    def write(self, text):
        """普通输出（无转义序列时与纯文本完全一致；兼容携带 ANSI 的旧调用方）。"""
        self._q.put(('ansi', text, None))

    def write_ansi(self, text):
        """含 ANSI 转义序列的输出。"""
        self._q.put(('ansi', text, None))

    def write_tagged(self, text, tag):
        """带标签输出：'err' 红色 / 'info' 灰色；'out-bold' 等样式 tag 也按其样式渲染。"""
        self._q.put(('tagged', text, tag))

    def clear(self):
        """清空输出区（同样走队列，保持与待输出内容的先后顺序）。"""
        self._q.put(('clear', '', None))

    def content(self):
        """当前全部文本（测试/调试用，须在主线程调用）。"""
        return self.text.get('1.0', 'end-1c')

    # ---------- 主线程刷新 ----------

    def _drain_loop(self):
        try:
            self._drain_once()
            self.after(self._refresh_ms, self._drain_loop)   # 控件销毁后由异常终止
        except tk.TclError:
            pass

    def _drain_once(self):
        items = []
        while True:
            try:
                items.append(self._q.get_nowait())
            except queue.Empty:
                break
        if not items:
            return
        self.text.config(state='normal')
        for kind, text, tag in items:
            if kind == 'text':
                self._append_ansi(text)
            elif kind == 'ansi':
                self._append_ansi(text)
            elif kind == 'tagged':
                self.text.insert('end', self._norm(text), (tag,))
            else:   # 'clear'
                self.text.delete('1.0', 'end')
                self._ansi_buf = ''
                self._reset_ansi()
        self._trim()
        self.text.config(state='disabled')
        self.text.see('end')

    def _norm(self, text):
        return text.replace('\r\n', '\n').replace('\r', '\n')

    def _trim(self):
        """超过 max_lines 行时裁掉最旧的行。"""
        total = int(self.text.index('end-1c').split('.')[0]) - 1
        if total > self._max_lines:
            self.text.delete('1.0', f'{total - self._max_lines + 1}.0')

    # ---------- ANSI 解析与渲染 ----------

    def _append_ansi(self, text):
        self._ansi_buf += self._norm(text)
        data = self._ansi_buf
        last = 0
        for m in _ANSI_CSI.finditer(data):
            if m.start() > last:
                self._emit_segment(data[last:m.start()])
            self._apply_sgr(m.group(1), m.group(2))
            last = m.end()
        tail = data[last:]
        cut = tail.find('\x1b')
        if cut >= 0:                       # 末尾是半截转义序列：留到下一批凑齐
            if cut > 0:
                self._emit_segment(tail[:cut])
            self._ansi_buf = tail[cut:]
        else:
            self._emit_segment(tail)
            self._ansi_buf = ''

    def _emit_segment(self, s):
        if not s:
            return
        tags = []
        primary = _tag_name(self._ansi['bold'], self._fg)
        if primary != 'out-plain':
            tags.append(self._ensure_tag(primary))
        if self._ansi['italic']:
            tags.append('out-italic')
        if self._ansi['under']:
            tags.append('out-under')
        if self._ansi['strike']:
            tags.append('out-strike')
        if self._bg:
            tags.append(self._ensure_tag('out-bg' + self._bg[1:]))
        self.text.insert('end', s, tuple(tags))

    def _ensure_tag(self, name):
        """tag 没配置过时按命名规则懒创建（真彩色/组合色不在预置色板里）。"""
        if name in self._made_tags:
            return name
        if name.startswith('out-b') and len(name) == 9:
            self.text.tag_configure(name, foreground='#' + name[5:], font=self._font_bold)
        elif name.startswith('out-bg') and len(name) == 9:
            self.text.tag_configure(name, background='#' + name[7:])
        elif name.startswith('out-') and len(name) == 7:
            self.text.tag_configure(name, foreground='#' + name[4:])
        self._made_tags.add(name)
        return name

    def _apply_sgr(self, params_str, final):
        if final != 'm':                   # 非 SGR（清屏、光标移动等）忽略
            return
        codes = [int(x) for x in params_str.split(';') if x != ''] or [0]
        i = 0
        while i < len(codes):
            c = codes[i]
            if c == 0:
                self._reset_ansi()
            elif c == 1:
                self._ansi['bold'] = True
            elif c == 3:
                self._ansi['italic'] = True
            elif c == 4:
                self._ansi['under'] = True
            elif c == 9:
                self._ansi['strike'] = True
            elif c == 22:
                self._ansi['bold'] = False
            elif c == 23:
                self._ansi['italic'] = False
            elif c == 24:
                self._ansi['under'] = False
            elif c == 29:
                self._ansi['strike'] = False
            elif c in _STD_FG:
                self._fg = _STD_FG[c]
            elif c in _BRIGHT_FG:
                self._fg = _BRIGHT_FG[c]
            elif c == 39:
                self._fg = None
            elif c == 49:
                self._bg = None
            elif c == 38 and i + 1 < len(codes) and codes[i + 1] == 2 and i + 4 < len(codes):
                self._fg = f'#{codes[i + 2]:02x}{codes[i + 3]:02x}{codes[i + 4]:02x}'
                i += 4
            elif c == 38 and i + 1 < len(codes) and codes[i + 1] == 5 and i + 2 < len(codes):
                self._fg = _xterm256(codes[i + 2])
                i += 2
            elif c == 48 and i + 1 < len(codes) and codes[i + 1] == 2 and i + 4 < len(codes):
                self._bg = f'#{codes[i + 2]:02x}{codes[i + 3]:02x}{codes[i + 4]:02x}'
                i += 4
            elif c == 48 and i + 1 < len(codes) and codes[i + 1] == 5 and i + 2 < len(codes):
                self._bg = _xterm256(codes[i + 2])
                i += 2
            # 其余代码 v1 一律忽略
            i += 1

    def _reset_ansi(self):
        self._ansi = {'bold': False, 'italic': False, 'under': False, 'strike': False}
        self._fg = None
        self._bg = None


class InputBar(tk.Frame):
    """单行输入栏：Entry + 发送按钮，回车即提交。"""

    def __init__(self, master, on_submit=None, **kw):
        kw.setdefault('bg', THEME['output_bg'])
        super().__init__(master, **kw)
        self.on_submit = on_submit
        self._enabled = True

        tk.Label(self, text='输入:', bg=THEME['output_bg'], fg=THEME['fg'],
                 font=_ui_font()).pack(side='left', padx=(6, 6), pady=6)
        self.entry = tk.Entry(self,
                              font=(_pick_family(THEME['mono_family']),
                                    THEME['mono_size']),
                              bg=THEME['output_bg'], fg=THEME['fg'],
                              insertbackground=THEME['cursor'], insertwidth=2,
                              selectbackground=THEME['selection'],
                              selectforeground=THEME['fg'],
                              relief='flat', bd=0, highlightthickness=1,
                              highlightbackground=THEME['border'],
                              highlightcolor=THEME['selection'],
                              disabledbackground=THEME['output_bg'],
                              disabledforeground=THEME['fg_disabled'])
        self.entry.pack(side='left', fill='x', expand=True, padx=(0, 6),
                        pady=6, ipady=4)
        self.entry.bind('<Return>', self._on_return)

        self.button = _flat_button(self, '发送', self.try_submit)
        self.button.pack(side='left', padx=(0, 6), pady=6)

    def _on_return(self, event=None):
        self.try_submit()
        return 'break'

    def try_submit(self):
        """取当前内容提交并清空输入框。空行不发送（'' 被保留为"停止"信号）。"""
        if not self._enabled:
            return
        line = self.entry.get()
        if line == '':
            return
        self.entry.delete(0, 'end')
        if self.on_submit:
            self.on_submit(line)

    def set_enabled(self, enabled):
        """禁用时输入框与按钮变灰。"""
        self._enabled = bool(enabled)
        state = 'normal' if self._enabled else 'disabled'
        self.entry.config(state=state)
        self.button.config(state=state)

    def focus_entry(self):
        """把焦点交给输入框（有输出等待时由界面调用）。"""
        self.entry.focus_set()


# IdeStream 用它唤醒阻塞在 readline() 里的线程（区别于用户提交的任意字符串）
_WAKE = object()


class IdeStream:
    """编译器（工作线程）与界面（主线程）之间的线程安全流适配器。

    工作线程调用 write / write_ansi / write_tagged / flush / readline；
    界面（主线程）调用 submit / stop / reset，并消费 out_queue。
    构造时给出 output（AnsiOutput）则内部自建主线程泵自动渲染；
    给出 input_bar 则随 input_requested 自动启用/聚焦输入栏。
    """

    def __init__(self, output=None, input_bar=None):
        self.out_queue = queue.Queue()            # ('text'|'ansi'|'tagged'|'clear', 文本, 标签)
        self.in_queue = queue.Queue()             # 用户提交的行（str）或 _WAKE
        self.input_requested = threading.Event()  # readline() 等待期间置位：界面据此启用输入栏
        self.finished = threading.Event()         # 工作线程结束时置位
        self._stop = threading.Event()
        self._gen = 0                             # 代数：reset 时 +1，用于让旧等待者退出

        self._output = output
        self._input_bar = input_bar
        if output is not None:
            try:
                output.after(30, self._pump)
            except (AttributeError, tk.TclError):
                pass

    # ---- 输出（工作线程调用） ----

    def write(self, text):
        self.out_queue.put(('text', text, None))

    def write_ansi(self, text):
        self.out_queue.put(('ansi', text, None))

    def write_tagged(self, text, tag):
        self.out_queue.put(('tagged', text, tag))

    def flush(self):
        pass

    # ---- 输入 ----

    def readline(self):
        """阻塞直到用户在输入栏提交一行；用户按"停止"或发生 reset 则返回 ''。

        调用时置位 input_requested，界面据此启用输入栏并聚焦。
        队列里的 _WAKE 是唤醒哨兵（stop/reset 留下）：读到它时——
        · 停止标志已置 → 返回 ''；
        · 自身属于旧一代（期间发生过 reset）→ 返回 ''（旧等待者退出，别污染新运行）；
        · 同一代且未停止 → 继续等（reset 留下的哨兵不影响新运行第一条 readline）。
        """
        mygen = self._gen
        while True:
            if self._stop.is_set():
                return ''
            self.input_requested.set()
            try:
                line = self.in_queue.get()
            finally:
                if mygen == self._gen:      # 旧一代退出时别去动新一代的事件状态
                    self.input_requested.clear()
            if line is not _WAKE and not self._stop.is_set():
                return line
            if self._stop.is_set() or mygen != self._gen:
                return ''
            # 同一代内的裸唤醒：继续等待

    def submit(self, line):
        """输入栏回车时由界面调用，唤醒 readline()。不要提交 ''（那是停止信号）。"""
        self.in_queue.put(line)

    # ---- 运行控制 ----

    def reset(self):
        """每次运行前调用：清空停止标志/队列/事件，并唤醒可能残留的等待者。

        上一代阻塞在 readline() 里的线程会带着 '' 退出（代数不匹配）；
        本代新调用的 readline() 不受哨兵影响，正常等待用户输入。
        """
        self._gen += 1
        self._stop.clear()
        self.input_requested.clear()
        self.finished.clear()
        for q in (self.out_queue, self.in_queue):
            while True:
                try:
                    q.get_nowait()
                except queue.Empty:
                    break
        self.in_queue.put(_WAKE)   # 唤醒阻塞中的旧等待者（它将因代数变化返回 ''）

    def stop(self):
        """停止按钮：置 _stop 事件，并唤醒阻塞中的 readline()（它将返回 ''）。"""
        self._stop.set()
        try:
            self.in_queue.put_nowait(_WAKE)
        except queue.Full:
            pass

    def is_stopped(self):
        return self._stop.is_set()

    # ---- 内置主线程泵（仅在构造时给了 output 时启用） ----

    def _pump(self):
        try:
            while True:
                kind, text, tag = self.out_queue.get_nowait()
                if kind == 'text' or kind == 'ansi':
                    self._output.write_ansi(text)
                elif kind == 'tagged':
                    self._output.write_tagged(text, tag)
                else:
                    self._output.clear()
        except queue.Empty:
            pass
        if self._input_bar is not None:
            waiting = self.input_requested.is_set()
            self._input_bar.set_enabled(waiting)
            if waiting:
                self._input_bar.focus_entry()
        try:
            self._output.after(30, self._pump)
        except (AttributeError, tk.TclError):
            pass


# ================= 自测窗口 =================

def _build_demo(root):
    """拼出自测窗口；返回内部对象便于自动化测试。"""
    closed = threading.Event()

    output = AnsiOutput(root)
    output.pack(fill='both', expand=True, padx=8, pady=(8, 4))

    buttons = ttk.Frame(root)
    buttons.pack(fill='x', padx=8)

    def add_button(text, cmd):
        ttk.Button(buttons, text=text, command=cmd).pack(side='left', padx=(0, 6))

    add_button('write', lambda: output.write('普通输出：hello PYbook\n'))
    add_button('write_ansi', lambda: output.write_ansi(
        '\033[1m加粗\033[0m  \033[3m斜体\033[0m  \033[4m下划线\033[0m  '
        '\033[9m删除线\033[0m  \033[38;2;220;60;60m红字\033[0m  '
        '\033[48;2;40;120;70m绿底\033[0m  \033[1;38;2;60;120;220m粗体蓝字\033[0m\n'))
    add_button('err', lambda: output.write_tagged('错误输出示例\n', 'err'))
    add_button('info', lambda: output.write_tagged('信息输出示例\n', 'info'))
    add_button('裁剪5000行', lambda: output.write(''.join(f'填充行 {i}\n' for i in range(5100))))

    status = ttk.Label(root, text='状态：待运行')
    colors = [(220, 60, 60), (60, 140, 220), (60, 170, 90), (200, 130, 40), (150, 80, 200)]

    input_bar = InputBar(root, on_submit=lambda line: stream.submit(line))
    input_bar.pack(fill='x', padx=8, pady=(4, 2))
    input_bar.set_enabled(False)
    stream = IdeStream(output=output, input_bar=input_bar)   # 内置泵：渲染 + 输入栏联动
    status.pack(anchor='w', padx=8, pady=(0, 8))

    def worker():
        """模拟"编译器工作线程"：输出、请求输入、处理输入。"""
        try:
            stream.write('模拟运行开始\n')
            for i in range(4):
                if stream.is_stopped():
                    return
                r, g, b = colors[i % len(colors)]
                stream.write_ansi(f'\033[1m\033[38;2;{r};{g};{b}m工作线程彩色行 {i}\033[0m\n')
                time.sleep(0.5)
            stream.write_tagged('输入演示：在下方输入并回车（输 stop 结束；点"停止"可随时中止）\n', 'info')
            while True:
                line = stream.readline()
                if line == '':
                    stream.write_tagged('检测到停止，工作线程已退出\n', 'err')
                    return
                stream.write_tagged(f'收到输入: {line}\n', 'info')
                if line.strip().lower() == 'stop':
                    stream.write_tagged('模拟运行结束\n', 'info')
                    return
        finally:
            stream.finished.set()

    def colorer():
        """每 0.5 秒一条彩色行，直到停止或窗口关闭。"""
        n = 0
        while not closed.is_set() and not stream.is_stopped():
            r, g, b = colors[n % len(colors)]
            stream.write_ansi(f'\033[38;2;{r};{g};{b}m每 0.5 秒的彩色行 #{n}\033[0m\n')
            n += 1
            closed.wait(0.5)

    def start_run():
        stream.reset()
        status.config(text='状态：运行中……（输入 stop 结束，或点"停止"）')
        threading.Thread(target=worker, daemon=True).start()
        threading.Thread(target=colorer, daemon=True).start()

    ttk.Button(buttons, text='重启', command=start_run).pack(side='right', padx=(0, 6))
    ttk.Button(buttons, text='停止', command=stream.stop).pack(side='right')

    def on_close():
        closed.set()
        stream.stop()
        root.destroy()

    root.protocol('WM_DELETE_WINDOW', on_close)
    root.after(200, start_run)
    return {'stream': stream, 'output': output, 'input_bar': input_bar,
            'closed': closed, 'start_run': start_run}


if __name__ == '__main__':
    _root = tk.Tk()
    _root.title('PYbook IDE 组件自测')
    _root.geometry('860x620')
    _root.config(bg=THEME['output_bg'])
    apply_dark_ttk_style(_root)
    _build_demo(_root)
    _root.mainloop()
