"""PYbook IDE 主框架：主窗口、布局、菜单、工具栏、编辑区（带行号）、
文件打开保存、状态栏。

不实现任何编译/运行逻辑——运行/停止回调目前只 print 占位；
输出区（AnsiOutput）、输入栏（InputBar）、运行控制器与 IdeStream 由同事交付
（ide_output.py / ide_run.py），本文件只摆放与接线；若同事文件尚未到位，
使用文件尾部的最小占位类兜底，保证窗口可以独立打开自测。
仅用 Python 标准库。

界面为深色现代主题（VS Code / Catppuccin 风）：所有颜色集中在 THEME 字典。
"""

import os
import sys
import threading
import tkinter as tk
from tkinter import filedialog, font as tkfont, messagebox, ttk

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))

# ---- 深色主题（VS Code / Catppuccin 风）：所有颜色集中在此，勿散落魔法值 ----
THEME = {
    # 背景
    'bg':          '#181825',   # 窗口/菜单/工具栏/行号槽
    'editor_bg':   '#1e1e2e',   # 编辑区
    'output_bg':   '#11111b',   # 输出区/输入栏/状态栏
    # 文字
    'fg':          '#cdd6f4',   # 默认文字
    'fg_dim':      '#a6adc8',   # 状态栏文字
    'fg_disabled': '#6c7086',   # 禁用态文字
    'linenum':     '#6c7086',   # 行号
    'linenum_cur': '#cba6f7',   # 当前行号
    # 控件点缀
    'cursor':      '#f5c2e7',   # 光标
    'selection':   '#45475a',   # 选中文本背景
    'hover':       '#313244',   # 悬停背景
    'border':      '#313244',   # 边框/分隔线
    'run':         '#a6e3a1',   # 运行按钮文字
    'stop':        '#f38ba8',   # 停止按钮文字
    # 字体（等宽/界面各取候选里第一个已安装的）
    'mono_family': ('Cascadia Code', 'Consolas', 'Courier New'),
    'ui_family':   ('Microsoft YaHei UI', 'Microsoft YaHei'),
    'mono_size':   12,
    'ui_size':     10,
}


def _pick_family(candidates):
    """候选字体名里返回第一个系统已安装的；都未安装则退回最后一个。"""
    try:
        installed = set(tkfont.families())
    except Exception:
        return candidates[-1]
    for name in candidates:
        if name in installed:
            return name
    return candidates[-1]


# ---- 同事组件：按合同导入，缺失时用本文件尾部的占位类兜底 ----
try:
    from ide_output import AnsiOutput, InputBar, apply_dark_ttk_style
    _USING_STUBS = False
except ImportError:
    AnsiOutput = InputBar = None      # 文件尾定义占位实现
    _USING_STUBS = True

    def apply_dark_ttk_style(root):   # 兜底：无同事组件时跳过 ttk 美化
        pass

try:
    from ide_run import IdeStream
except ImportError:
    IdeStream = None                  # 文件尾定义占位实现


class PybookIDE:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title('未命名 - PYbook IDE')
        self.root.geometry('1180x760')
        self.root.minsize(900, 600)
        self.root.config(bg=THEME['bg'])
        self.filepath = None
        self._dirty = False

        # 字体：等宽（编辑/输出）与界面字体，各取候选里第一个已安装的
        self.font_mono = tkfont.Font(family=_pick_family(THEME['mono_family']),
                                     size=THEME['mono_size'])
        self.font_lnum = tkfont.Font(family=self.font_mono.actual('family'),
                                     size=10)
        self.font_ui = tkfont.Font(family=_pick_family(THEME['ui_family']),
                                   size=THEME['ui_size'])

        self._dark_titlebar()
        apply_dark_ttk_style(root)
        self._build_menu()
        self._build_layout()
        self._build_statusbar()
        self._wire_stream()
        self._update_title()
        self.set_status('就绪')

    def _dark_titlebar(self):
        """Windows 深色标题栏：DWM 属性 20 置 1；失败（非 Windows/旧系统）静默跳过。"""
        try:
            import ctypes
            self.root.update_idletasks()
            hwnd = ctypes.windll.user32.GetParent(self.root.winfo_id())
            flag = ctypes.c_int(1)
            ctypes.windll.dwmapi.DwmSetWindowAttribute(
                hwnd, 20, ctypes.byref(flag), ctypes.sizeof(flag))
        except Exception:
            pass

    # ---------------------------------------------------------------- 布局

    def _build_menu(self):
        menu_kw = dict(tearoff=0, bd=0, relief='flat', font=self.font_ui,
                       bg=THEME['bg'], fg=THEME['fg'],
                       activebackground=THEME['hover'],
                       activeforeground=THEME['fg'])
        menubar = tk.Menu(self.root, **menu_kw)

        m_file = tk.Menu(menubar, **menu_kw)
        m_file.add_command(label='新建', accelerator='Ctrl+N',
                           command=self.new_file)
        m_file.add_command(label='打开', accelerator='Ctrl+O',
                           command=self.open_file)
        m_file.add_command(label='保存', accelerator='Ctrl+S',
                           command=self.save_file)
        m_file.add_command(label='另存为', command=self.save_file_as)
        m_file.add_separator()
        m_file.add_command(label='退出', command=self._on_quit)
        menubar.add_cascade(label='文件', menu=m_file)

        m_run = tk.Menu(menubar, **menu_kw)
        m_run.add_command(label='运行原生模式', accelerator='F5',
                          command=lambda: self._on_run('native'))
        m_run.add_command(label='运行VM模式', accelerator='Ctrl+B',
                          command=lambda: self._on_run('vm'))
        m_run.add_separator()
        self._menu_stop_index = m_run.index('end') + 1
        m_run.add_command(label='停止', accelerator='Shift+F5',
                          command=self._on_stop, state='disabled')
        menubar.add_cascade(label='运行', menu=m_run)
        self._menu_run = m_run

        m_help = tk.Menu(menubar, **menu_kw)
        m_help.add_command(label='关于', command=self._on_about)
        menubar.add_cascade(label='帮助', menu=m_help)

        self.root.config(menu=menubar)
        self.root.protocol('WM_DELETE_WINDOW', self._on_quit)

        for seq, fn in (('<Control-n>', lambda e: self.new_file()),
                        ('<Control-o>', lambda e: self.open_file()),
                        ('<Control-s>', lambda e: self.save_file()),
                        ('<F5>', lambda e: self._on_run('native')),
                        ('<Control-b>', lambda e: self._on_run('vm')),
                        ('<Shift-F5>', lambda e: self._on_stop())):
            self.root.bind(seq, fn)

    def _build_layout(self):
        # 工具栏：扁平深色按钮，悬停变亮
        toolbar = tk.Frame(self.root, bg=THEME['bg'])
        toolbar.pack(side='top', fill='x')
        self._toolbar_btn(toolbar, '新建', self.new_file).pack(
            side='left', padx=(6, 0), pady=4)
        self._toolbar_btn(toolbar, '打开', self.open_file).pack(
            side='left', pady=4)
        self._toolbar_btn(toolbar, '保存', self.save_file).pack(
            side='left', pady=4)
        tk.Frame(toolbar, width=3, bg=THEME['border']).pack(
            side='left', fill='y', padx=8, pady=6)
        self.btn_run_native = self._toolbar_btn(
            toolbar, '▶ 运行', lambda: self._on_run('native'), fg=THEME['run'])
        self.btn_run_native.pack(side='left', pady=4)
        self.btn_run_vm = self._toolbar_btn(
            toolbar, '▶ 运行VM', lambda: self._on_run('vm'), fg=THEME['run'])
        self.btn_run_vm.pack(side='left', pady=4)
        self.btn_stop = self._toolbar_btn(toolbar, '■ 停止', self._on_stop,
                                          fg=THEME['stop'])
        self.btn_stop.pack(side='left', pady=4)
        self.btn_stop.config(state='disabled')

        # 编辑区：左侧行号槽 + Text（深色、粉光标、宽选区）
        editor_wrap = tk.Frame(self.root, bg=THEME['bg'])
        editor_wrap.pack(side='top', fill='both', expand=True, padx=6,
                         pady=(6, 0))
        self.linenumbers = tk.Canvas(editor_wrap, width=48, bg=THEME['bg'],
                                     highlightthickness=0, bd=0)
        self.linenumbers.pack(side='left', fill='y')
        self.text = tk.Text(editor_wrap, wrap='none', undo=True,
                            font=self.font_mono, tabs='4c',
                            bg=THEME['editor_bg'], fg=THEME['fg'],
                            insertbackground=THEME['cursor'], insertwidth=2,
                            selectbackground=THEME['selection'],
                            selectforeground=THEME['fg'],
                            relief='flat', bd=0, highlightthickness=0,
                            padx=8, pady=4)
        yscroll = ttk.Scrollbar(editor_wrap, orient='vertical')
        self.text.config(yscrollcommand=self._on_text_scroll)
        yscroll.config(command=self.text.yview)
        self.editor_yscroll = yscroll
        yscroll.pack(side='right', fill='y')
        self.text.pack(side='left', fill='both', expand=True)
        self.text.bind('<<Modified>>', self._on_modified)
        self.text.bind('<Return>', self._on_return)
        self.text.bind('<Configure>', lambda e: self._redraw_linenums())
        self.text.bind('<KeyRelease>', lambda e: self._redraw_linenums())
        self.text.bind('<ButtonRelease-1>', lambda e: self._redraw_linenums())

        # 水平分隔：3px #313244
        tk.Frame(self.root, height=3, bg=THEME['border']).pack(
            side='top', fill='x', padx=6, pady=6)

        # 输出区 + 输入栏（同事组件，只摆放）
        self.output = AnsiOutput(self.root)
        self.output.pack(side='top', fill='both', expand=False, padx=6)
        self.output.configure(height=12)
        self.input_bar = InputBar(self.root, on_submit=self._on_input_submit)
        self.input_bar.pack(side='top', fill='x', padx=6, pady=(0, 6))

    def _build_statusbar(self):
        # 1px #313244 分隔线 + 深色状态条
        tk.Frame(self.root, height=1, bg=THEME['border']).pack(
            side='bottom', fill='x')
        self.status = tk.Label(self.root, text='', anchor='w', bd=0,
                               relief='flat', bg=THEME['output_bg'],
                               fg=THEME['fg_dim'], font=self.font_ui,
                               padx=10, pady=4)
        self.status.pack(side='bottom', fill='x')

    def _toolbar_btn(self, master, text, command, fg=None):
        """工具栏扁平按钮：深色底、8px 内边距、悬停 #313244（禁用态不响应）。"""
        color = fg or THEME['fg']
        btn = tk.Button(master, text=text, command=command,
                        font=self.font_ui, cursor='hand2', takefocus=0,
                        relief='flat', bd=0, highlightthickness=0,
                        bg=THEME['bg'], fg=color,
                        activebackground=THEME['hover'],
                        activeforeground=color,
                        disabledforeground=THEME['fg_disabled'],
                        padx=8, pady=4)

        def _enter(_):
            if str(btn.cget('state')) != 'disabled':
                btn.config(bg=THEME['hover'])

        def _leave(_):
            btn.config(bg=THEME['bg'])

        btn.bind('<Enter>', _enter)
        btn.bind('<Leave>', _leave)
        return btn

    def _wire_stream(self):
        """创建并接线 IdeStream（同事B的组件）。

        构造参数合同未定死：优先传输出区/输入栏引用，构造失败再退回无参。
        """
        try:
            self.stream = IdeStream(output=self.output,
                                    input_bar=self.input_bar)
        except TypeError:
            self.stream = IdeStream()
            for attr, val in (('output', self.output),
                              ('input_bar', self.input_bar)):
                if not hasattr(self.stream, attr):
                    setattr(self.stream, attr, val)
        # 输入栏提交 → stream.submit(line)（流内部会转交运行线程）
        self._input_submit = (
            lambda line: self.stream.submit(line)
            if hasattr(self.stream, 'submit') else None)

    # ---------------------------------------------------------------- 对外接口（合同）

    def get_text(self) -> str:
        return self.text.get('1.0', 'end-1c')

    def set_text(self, s: str):
        self.text.delete('1.0', 'end')
        self.text.insert('1.0', s)
        self._dirty = False
        self.text.edit_modified(False)         # 清掉 Tk 修改标志
        self._update_title()
        self._redraw_linenums()

    def set_status(self, msg: str):
        self.status.config(text=msg)

    def set_run_enabled(self, running: bool):
        """运行中禁用运行按钮、启用停止；结束后恢复。"""
        state = 'disabled' if running else 'normal'
        self.btn_run_native.config(state=state)
        self.btn_run_vm.config(state=state)
        self._menu_run.entryconfig(0, state=state)
        self._menu_run.entryconfig(1, state=state)
        stop_state = 'normal' if running else 'disabled'
        self.btn_stop.config(state=stop_state)
        self._menu_run.entryconfig(self._menu_stop_index, state=stop_state)
        if hasattr(self.input_bar, 'set_enabled'):
            self.input_bar.set_enabled(running)
        self.set_status('运行中…' if running else '就绪')

    # ---------------------------------------------------------------- 编辑行为

    def _on_return(self, event):
        """回车保持当前行缩进。"""
        line = self.text.get('insert linestart', 'insert lineend')
        indent = line[:len(line) - len(line.lstrip())]
        self.text.insert('insert', '\n' + indent)
        self.text.see('insert')
        return 'break'

    def _on_modified(self, event):
        if self.text.edit_modified():
            self.text.edit_modified(False)     # 复位，下次编辑会再次触发
            if not self._dirty:
                self._dirty = True
                self._update_title()
                self._redraw_linenums()

    def _on_text_scroll(self, first, last):
        self.editor_yscroll.set(first, last)   # 滚动条随文本同步
        self._redraw_linenums()                # 行号随滚动对齐

    def _redraw_linenums(self):
        canvas = self.linenumbers
        canvas.delete('all')
        cur = self.text.index('insert').split('.')[0]
        i = self.text.index('@0,0')
        while True:
            dline = self.text.dlineinfo(i)
            if dline is None:
                break
            line = i.split('.')[0]
            canvas.create_text(
                38, dline[1] + dline[3] // 2 - 1, text=line, anchor='e',
                font=self.font_lnum,
                fill=THEME['linenum_cur'] if line == cur else THEME['linenum'])
            i = self.text.index(f'{i}+1line')

    # ---------------------------------------------------------------- 文件

    def _update_title(self):
        name = os.path.basename(self.filepath) if self.filepath else '未命名'
        star = '*' if self._dirty else ''
        self.root.title(f'{name}{star} - PYbook IDE')

    def _mark_dirty(self):
        if not self._dirty:
            self._dirty = True
            self._update_title()

    def new_file(self):
        if self._dirty and not self._confirm_discard():
            return
        self.filepath = None
        self.set_text('')
        self.set_status('新建文件')

    def open_file(self):
        if self._dirty and not self._confirm_discard():
            return
        path = filedialog.askopenfilename(
            initialdir=SCRIPT_DIR,
            filetypes=[('PYbook 源码', '*.pybk'), ('所有文件', '*.*')])
        if not path:
            return
        try:
            with open(path, encoding='utf-8') as f:
                s = f.read()
        except OSError as e:
            messagebox.showerror('打开失败', str(e))
            return
        self.filepath = path
        self.set_text(s)
        self.set_status(f'已打开 {os.path.basename(path)}')

    def save_file(self):
        if self.filepath is None:
            return self.save_file_as()
        return self._write_to(self.filepath)

    def save_file_as(self):
        path = filedialog.asksaveasfilename(
            initialdir=SCRIPT_DIR, defaultextension='.pybk',
            initialfile='未命名.pybk',
            filetypes=[('PYbook 源码', '*.pybk'), ('所有文件', '*.*')])
        if not path:
            return False
        self.filepath = path
        return self._write_to(path)

    def _write_to(self, path):
        try:
            with open(path, 'w', encoding='utf-8') as f:
                f.write(self.get_text())
        except OSError as e:
            messagebox.showerror('保存失败', str(e))
            return False
        self.text.edit_modified(False)
        self._dirty = False
        self._update_title()
        self.set_status(f'已保存 {os.path.basename(path)}')
        return True

    def _confirm_discard(self):
        ans = messagebox.askyesnocancel('未保存', '当前文件已修改，保存更改？')
        if ans is None:
            return False                      # 取消操作
        if ans:
            return self.save_file()
        return True                           # 不保存但继续

    def _on_quit(self):
        if self._dirty and not self._confirm_discard():
            return
        self.root.destroy()

    # ---------------------------------------------------------------- 运行（占位）

    def _on_run(self, mode):
        # 红线：不实现运行逻辑，等同事的 ide_run 接上后由 run_source_in_editor 驱动
        print(f'[占位] 运行({mode})，源码 {len(self.get_text())} 字符')
        self.set_run_enabled(True)
        self.root.after(1500, lambda: self.set_run_enabled(False))  # 占位演示
        self.output.write(f'[占位] {mode} 模式运行尚未接入\n')

    def _on_stop(self):
        print('[占位] 停止()')
        if hasattr(self.stream, 'stop'):
            try:
                self.stream.stop()
            except Exception as e:
                print('[占位] stream.stop 失败:', e)

    def _on_input_submit(self, line):
        if self._input_submit is not None:
            self._input_submit(line)
        else:
            print(f'[占位] 输入: {line!r}')

    def _on_about(self):
        messagebox.showinfo(
            '关于', 'PYbook IDE\n类 Python 的中文友好编程语言的集成开发环境\n'
                    '编辑器框架 v1（运行组件由同事提供）')


# ================================================================ 占位兜底
# 仅当同事的 ide_output.py / ide_run.py 尚未交付时生效（_USING_STUBS=True）；
# 组件到位后这些定义会被真实导入覆盖。实现保持最小，只为窗口能独立打开自测。

if _USING_STUBS:

    class AnsiOutput(tk.Frame):
        def __init__(self, master):
            super().__init__(master, bg=THEME['output_bg'])
            bar = tk.Frame(self, bg=THEME['output_bg'])
            bar.pack(side='top', fill='x')
            tk.Button(bar, text='清空', command=self.clear, relief='flat',
                      bd=0, highlightthickness=0, bg=THEME['output_bg'],
                      fg=THEME['fg'], activebackground=THEME['hover'],
                      activeforeground=THEME['fg'],
                      disabledforeground=THEME['fg_disabled'],
                      padx=8, pady=4).pack(side='right', padx=6, pady=4)
            self.txt = tk.Text(self, height=10, state='disabled',
                               bg=THEME['output_bg'], fg=THEME['fg'],
                               insertbackground=THEME['cursor'],
                               selectbackground=THEME['selection'],
                               relief='flat', bd=0, highlightthickness=1,
                               highlightbackground=THEME['border'],
                               font=('Consolas', 12))
            ys = ttk.Scrollbar(self, orient='vertical',
                               command=self.txt.yview)
            self.txt.config(yscrollcommand=ys.set)
            ys.pack(side='right', fill='y')
            self.txt.pack(side='left', fill='both', expand=True)

        def _append(self, s):
            self.txt.config(state='normal')
            self.txt.insert('end', s)
            self.txt.see('end')
            self.txt.config(state='disabled')

        def write(self, text):
            self._append(text)

        def write_ansi(self, text):
            self._append(text)

        def write_tagged(self, text, tag):
            self._append(text)

        def clear(self):
            self.txt.config(state='normal')
            self.txt.delete('1.0', 'end')
            self.txt.config(state='disabled')

    class InputBar(tk.Frame):
        def __init__(self, master, on_submit):
            super().__init__(master, bg=THEME['output_bg'])
            self._on_submit = on_submit
            tk.Label(self, text='输入:', bg=THEME['output_bg'],
                     fg=THEME['fg']).pack(side='left', padx=(6, 4))
            self.entry = tk.Entry(self, bg=THEME['output_bg'],
                                  fg=THEME['fg'],
                                  insertbackground=THEME['cursor'],
                                  relief='flat', highlightthickness=1,
                                  highlightbackground=THEME['border'],
                                  disabledforeground=THEME['fg_disabled'])
            self.entry.pack(side='left', fill='x', expand=True,
                            padx=4, pady=6, ipady=4)
            self.entry.bind('<Return>', self._fire)
            tk.Button(self, text='发送', command=self._fire, relief='flat',
                      bd=0, highlightthickness=0, bg=THEME['output_bg'],
                      fg=THEME['fg'], activebackground=THEME['hover'],
                      activeforeground=THEME['fg'],
                      padx=8, pady=4).pack(side='left', padx=(0, 6), pady=6)

        def _fire(self, event=None):
            line = self.entry.get()
            self.entry.delete(0, 'end')
            self._on_submit(line)

        def set_enabled(self, enabled):
            self.entry.config(state='normal' if enabled else 'disabled')

    class IdeStream:
        """最小流占位：只缓存提交行、转发输出，运行控制器到位后替换。"""

        def __init__(self, output=None, input_bar=None):
            self.output = output
            self.input_bar = input_bar
            self.input_requested = threading.Event()
            self.finished = threading.Event()
            self._lines = []

        def write(self, text):
            if self.output:
                self.output.write(text)

        def write_ansi(self, text):
            if self.output:
                self.output.write_ansi(text)

        def write_tagged(self, text, tag):
            if self.output:
                self.output.write_tagged(text, tag)

        def readline(self):
            self.input_requested.set()
            if self.input_bar:
                self.input_bar.set_enabled(True)
            line = self._lines.pop(0) if self._lines else ''
            self.input_requested.clear()
            if self.input_bar:
                self.input_bar.set_enabled(False)
            return line

        def submit(self, line):
            self._lines.append(line)

        def reset(self):
            self._lines.clear()
            self.input_requested.clear()
            self.finished.clear()

        def stop(self):
            self.finished.set()


if __name__ == '__main__':
    root = tk.Tk()
    app = PybookIDE(root)
    root.mainloop()
