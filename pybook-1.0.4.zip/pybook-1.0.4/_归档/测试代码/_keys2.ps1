Add-Type @'
using System;
using System.Runtime.InteropServices;
public static class K3 {
  [DllImport("user32.dll")]
  private static extern void keybd_event(byte bVk, byte bScan, uint dwFlags, UIntPtr dwExtraInfo);
  public static void Down(byte vk) { keybd_event(vk, 0, 0, UIntPtr.Zero); }
  public static void Up(byte vk)   { keybd_event(vk, 0, 2, UIntPtr.Zero); }
}
'@
Start-Sleep -Milliseconds 1000
[K3]::Down(0x27); Start-Sleep -Milliseconds 1000; [K3]::Up(0x27)   # 右
Start-Sleep -Milliseconds 300
[K3]::Down(0x28); Start-Sleep -Milliseconds 700; [K3]::Up(0x28)   # 下
Start-Sleep -Milliseconds 300
for ($i = 0; $i -lt 12; $i++) { [K3]::Down(0x1B); Start-Sleep -Milliseconds 70; [K3]::Up(0x1B); Start-Sleep -Milliseconds 130 }
