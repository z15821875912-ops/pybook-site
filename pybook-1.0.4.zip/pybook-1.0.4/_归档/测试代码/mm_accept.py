# -*- coding: utf-8 -*-
"""Memoryment 一致性验收驱动：8 用例 × 双后端（原生 C / VM 字节码）。"""
import os
import subprocess
import sys

GCC = r'C:\Users\zhuli\mingw64\bin\gcc.exe'
CASES = sorted(f for f in os.listdir('mm_tests') if f.endswith('.pybk'))


def run_native(path):
    p = subprocess.run([sys.executable, 'pybk_main.py', path],
                       capture_output=True)
    err = p.stderr.decode('utf-8', 'replace').strip().splitlines()
    return p.returncode, (err[-1] if err else '')


def run_vm(path, bc='mm_t.pybc'):
    code = ("import sys; sys.path.insert(0,'.'); from pybk_bc import "
            "compile_source; open('%s','wb').write(compile_source("
            "open(%r, encoding='utf-8-sig').read()))" % (bc, path))
    p = subprocess.run([sys.executable, '-c', code], capture_output=True)
    if p.returncode != 0:
        err = p.stderr.decode('utf-8', 'replace').strip().splitlines()
        # PybkError 异常栈最后一行是 "pybk_front.PybkError: 第 N 行：..."
        msg = next((l for l in reversed(err) if '暂未实现' in l or '行' in l),
                   err[-1] if err else '')
        return p.returncode, msg
    q = subprocess.run(['pyvm.exe', bc], capture_output=True)
    err = q.stderr.decode('utf-8', 'replace').strip().splitlines()
    return q.returncode, (err[-1] if err else '')


def main():
    rows = []
    for c in CASES:
        path = os.path.join('mm_tests', c)
        rc_a, msg_a = run_native(path)
        rc_b, msg_b = run_vm(path)
        same = rc_a == rc_b
        rows.append((c, rc_a, msg_a, rc_b, msg_b, same))
        print(f"{'一致' if same else '不一致':4} {c}  rc {rc_a}/{rc_b}")
        print(f"     A: {msg_a}")
        print(f"     B: {msg_b}")
    bad = [r for r in rows if not r[5]]
    print(f"\n共 {len(rows)} 例，一致 {len(rows)-len(bad)}，不一致 {len(bad)}")
    return 1 if bad else 0


if __name__ == '__main__':
    sys.exit(main())
