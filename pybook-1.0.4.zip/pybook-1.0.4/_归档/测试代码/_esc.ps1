Add-Type @'
using System;
using System.Runtime.InteropServices;
public static class K2 {
  [DllImport("user32.dll")]
  private static extern void keybd_event(byte bVk, byte bScan, uint dwFlags, UIntPtr dwExtraInfo);
  public static void Tap(byte vk) { keybd_event(vk, 0, 0, UIntPtr.Zero); System.Threading.Thread.Sleep(80); keybd_event(vk, 0, 2, UIntPtr.Zero); }
}
'@
for ($i = 0; $i -lt 15; $i++) { [K2]::Tap(0x1B); Start-Sleep -Milliseconds 150 }
