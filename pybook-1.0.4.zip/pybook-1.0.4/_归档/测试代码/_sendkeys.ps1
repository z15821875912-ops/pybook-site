Add-Type @'
using System;
using System.Runtime.InteropServices;
public static class K {
  [DllImport("user32.dll")]
  private static extern void keybd_event(byte bVk, byte bScan, uint dwFlags, UIntPtr dwExtraInfo);
  public static void Down(byte vk) { keybd_event(vk, 0, 0, UIntPtr.Zero); }
  public static void Up(byte vk)   { keybd_event(vk, 0, 2, UIntPtr.Zero); }
}
'@
Start-Sleep -Milliseconds 1500
[K]::Down(0x27); Start-Sleep -Milliseconds 900; [K]::Up(0x27)   # 按住 右 方向键 0.9s
[K]::Down(0x28); Start-Sleep -Milliseconds 900; [K]::Up(0x28)   # 按住 下 方向键 0.9s
for ($i = 0; $i -lt 10; $i++) {                                  # 连点 ESC 退出
  [K]::Down(0x1B); Start-Sleep -Milliseconds 80; [K]::Up(0x1B)
  Start-Sleep -Milliseconds 120
}
