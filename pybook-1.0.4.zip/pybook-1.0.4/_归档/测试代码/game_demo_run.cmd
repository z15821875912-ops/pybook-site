@echo off
cd /d C:\Users\zhuli\Desktop\pybook
game_demo.exe
echo EXIT=%ERRORLEVEL%> game_exit.txt
