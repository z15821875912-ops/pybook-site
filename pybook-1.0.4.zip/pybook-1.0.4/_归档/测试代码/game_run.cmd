@echo off
cd /d C:\Users\zhuli\Desktop\pybook
app.exe
echo EXIT=%ERRORLEVEL%> game_exit.txt
