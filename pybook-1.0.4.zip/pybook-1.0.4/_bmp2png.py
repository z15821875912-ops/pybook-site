# -*- coding: utf-8 -*-
"""24bit BMP -> PNG（零依赖，只用 stdlib 的 zlib/struct）。
BMP 是底向上存、每行 4 字节对齐；PNG 是顶向下、每行前面带一个 filter 字节。"""
import struct, zlib, sys, os, glob


def bmp_read(path):
    d = open(path, 'rb').read()
    assert d[:2] == b'BM', 'not bmp'
    off, = struct.unpack('<I', d[10:14])
    w, = struct.unpack('<i', d[18:22])
    h, = struct.unpack('<i', d[22:26])
    bpp, = struct.unpack('<H', d[28:30])
    assert bpp == 24, 'bpp=%d' % bpp
    stride = ((w * 3 + 3) // 4) * 4
    rows = []
    for y in range(h):
        # BMP 底向上：第一行数据其实是图像最下面一行
        start = off + (h - 1 - y) * stride
        src = d[start:start + w * 3]
        # ⚠ BMP 每像素是 B,G,R，PNG 要 R,G,B —— 必须逐像素交换，
        #   否则整张图红蓝互换（深蓝灰地面会渲染成棕色）。
        row = bytearray(w * 3)
        for x in range(w):
            row[x * 3 + 0] = src[x * 3 + 2]
            row[x * 3 + 1] = src[x * 3 + 1]
            row[x * 3 + 2] = src[x * 3 + 0]
        rows.append(bytes(row))
    return w, h, rows


def png_write(path, w, h, rows):
    raw = bytearray()
    for r in rows:
        raw.append(0)          # filter type 0 (None)
        raw += r
    comp = zlib.compress(bytes(raw), 6)

    def chunk(tag, data):
        c = struct.pack('>I', len(data)) + tag + data
        return c + struct.pack('>I', zlib.crc32(tag + data) & 0xffffffff)

    out = b'\x89PNG\r\n\x1a\n'
    out += chunk(b'IHDR', struct.pack('>IIBBBBB', w, h, 8, 2, 0, 0, 0))
    out += chunk(b'IDAT', comp)
    out += chunk(b'IEND', b'')
    open(path, 'wb').write(out)


if __name__ == '__main__':
    src_dir = sys.argv[1]
    dst_dir = sys.argv[2]
    os.makedirs(dst_dir, exist_ok=True)
    for p in sorted(glob.glob(os.path.join(src_dir, '*.bmp'))):
        w, h, rows = bmp_read(p)
        name = os.path.basename(p)[:-4] + '.png'
        png_write(os.path.join(dst_dir, name), w, h, rows)
        print('  %s  %dx%d' % (name, w, h))
