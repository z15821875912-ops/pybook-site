/* PYbook 标准库：te（文本）/ mt（数学）/ rd（随机）。
 *
 * 只依赖 pybook_rt 的 Value 盒子体系与 C99 标准库（math.h/stdlib.h/string.h/time.h），
 * 不引入新依赖。前端把 te.split(...) 翻译成 rt_lib_te_split(...) 等 C 调用。
 *
 * 约定：
 *  - 字符串参数一律要求 T_STR，类型不对按运行时错误退出（格式与 pybook_rt 一致）；
 *  - te 的"字符"按 UTF-8 首字节计数（(byte & 0xC0) != 0x80），切/长度均按字符；
 *  - rd 系列首次调用时 srand(time(NULL))，之后不重置；
 *  - 列表参数只要求 T_LIST，元素逐个经 rt_index/rt_setindex 访问（不碰内部结构）。
 *
 * 自测：gcc -O2 -DLIB_SELF_TEST pybook_lib.c pybook_rt.c -o lib_test.exe -I.
 */

#ifndef PYBOOK_LIB_H
#define PYBOOK_LIB_H

#include "pybook_rt.h"

/* ---------- te 文本模块 ---------- */

Value rt_lib_te_split(Value text, Value sep);     /* split(文本, 分隔符) → 列表 */
Value rt_lib_te_replace(Value text, Value old, Value nw); /* 替换所有旧→新 */
Value rt_lib_te_trim(Value text);                 /* 去首尾空白 */
Value rt_lib_te_upper(Value text);                /* 转大写（ASCII） */
Value rt_lib_te_lower(Value text);                /* 转小写（ASCII） */
Value rt_lib_te_has(Value text, Value sub);       /* 包含子串？→ 真/假 */
Value rt_lib_te_len(Value text);                  /* 字符个数（UTF-8 按字符） */
Value rt_lib_te_cut(Value text, Value start, Value stop); /* [起,止) 子串 */
Value rt_lib_te_join(Value list, Value sep);      /* 元素转文本后拼接 */

/* ---------- mt 数学模块 ---------- */

Value rt_lib_mt_sqrt(Value n);                    /* 平方根（浮点） */
Value rt_lib_mt_pow(Value base, Value exp);       /* 乘方（浮点） */
Value rt_lib_mt_abs(Value n);                     /* 绝对值（int 保 int） */
Value rt_lib_mt_ceil(Value n);                    /* 向上取整（整数） */
Value rt_lib_mt_floor(Value n);                   /* 向下取整（整数） */
Value rt_lib_mt_mod(Value a, Value b);            /* 取余（Python 语义） */
Value rt_lib_mt_max(Value list);                  /* 列表最大值 */
Value rt_lib_mt_min(Value list);                  /* 列表最小值 */
Value rt_lib_mt_prod(Value list);                 /* 连乘 */
Value rt_lib_mt_sum(Value list);                  /* 求和（空列表=0） */

Value rt_lib_mt_sin(Value angle);                 /* sin（浮点） */
Value rt_lib_mt_cos(Value angle);                 /* cos（浮点） */
Value rt_lib_mt_tan(Value angle);                 /* tan（浮点） */
Value rt_lib_mt_pi(void);                         /* 圆周率常量 */
Value rt_lib_mt_lerp(Value a, Value b, Value t);  /* 线性插值 a+(b-a)*t */
Value rt_lib_mt_dist(Value x1, Value y1, Value x2, Value y2); /* 两点距离 */
Value rt_lib_mt_clamp(Value v, Value lo, Value hi); /* 夹取 [lo,hi]（全整数字面量保 int） */

/* ---------- rd 随机模块 ---------- */

Value rt_lib_rd_int(Value lo, Value hi);          /* [起,止] 随机整数（含两端） */
Value rt_lib_rd_float(void);                      /* [0,1) 随机浮点 */
Value rt_lib_rd_pick(Value list);                 /* 随机取一个元素 */
Value rt_lib_rd_shuffle(Value list);              /* 原地打乱（返回空盒） */

Value rt_lib_mt_atan2(Value y, Value x);          /* atan2(y, x)，弧度 */

Value rt_lib_te_str(Value v);                    /* 任意值 → 字符串（数字转文本） */

/* ---------- tm 时间模块 ---------- */

Value rt_lib_tm_stop(Value dur, Value unit);      /* tm.stop(秒) 或 tm.stop(毫秒, "ms")：暂停 */
Value rt_lib_tm_now(void);                        /* tm.now()：程序启动至今的毫秒数 */

/* ---------- 音 音乐模块（实现在 pybook_music.c） ---------- */

Value rt_mu_sine(Value freq, Value ms);           /* 音.正弦(频率, 毫秒)：正弦波（播完才返回） */
Value rt_mu_tri(Value freq, Value ms);            /* 音.三角(频率, 毫秒)：三角波 */
Value rt_mu_play(Value path);                     /* 音.放("文件.mp3/.wav")：后台播放（MCI） */
Value rt_mu_stop(void);
Value rt_mu_quick(Value f, Value ms, Value wave);   /* 音.快(频率,毫秒,波形0正弦/1三角/2噪声)：非阻塞音效 */                           /* 音.停()：停止后台播放 */

/* ---------- 音 模块·列表方式做音乐（类比 mm.draw_away） ---------- */
Value rt_mu_note(Value name, Value freq, Value wave);   /* 音.音(名, 频率, 波形)：注册/覆盖自定义音符（波形0正弦/1三角/2噪声） */
Value rt_mu_away(Value rows, Value file, Value bpm);   /* 音.奏(表, "名.wav", 速度)：把乐谱列表渲染成 WAV 落盘 */
Value rt_mu_play_list(Value rows, Value bpm);          /* 音.谱(表, 速度)：把乐谱列表即时播放（阻塞） */

/* ---------- net 网络模块（TCP 行协议，实现在 pybook_net.c） ---------- */

Value rt_net_listen(Value port);              /* net.listen(端口)：TCP 监听 → 句柄(INT) */
Value rt_net_accept(Value handle);            /* net.accept(句)：阻塞等一个连接 → 新句柄 */
Value rt_net_connect(Value addr, Value port); /* net.connect("地址", 端口)：客户端连接 → 句柄 */
Value rt_net_read(Value handle);              /* net.recv(句)：非阻塞读一行；无完整行 ""；断开 "断" */
Value rt_net_read_block(Value handle);        /* net.readline(句)：阻塞读一行 */
Value rt_net_write(Value handle, Value text); /* net.send(句, 文本)：原样发送字节（语言层 net.send 自动补 
） */
Value rt_net_close(Value handle);             /* net.close(句)：关闭 */

/* ---------- 调色板（内置常量色表） ---------- */

/* 调色板.颜色名 → 新建的 [r,g,b] 列表；配合 color(列表) 重载使用。
 * 列表按内存约定分配后不回收。 */

Value rt_lib_pal_hong(void);                      /* 红 [255,68,68] */
Value rt_lib_pal_cheng(void);                     /* 橙 [255,150,40] */
Value rt_lib_pal_huang(void);                     /* 黄 [255,220,60] */
Value rt_lib_pal_lv(void);                        /* 绿 [60,200,90] */
Value rt_lib_pal_qing(void);                      /* 青 [60,200,200] */
Value rt_lib_pal_lan(void);                       /* 蓝 [70,130,255] */
Value rt_lib_pal_zi(void);                        /* 紫 [170,90,220] */
Value rt_lib_pal_bai(void);                       /* 白 [240,240,240] */
Value rt_lib_pal_hei(void);                       /* 黑 [20,20,24] */
Value rt_lib_pal_hui(void);                       /* 灰 [140,140,150] */
Value rt_lib_pal_fen(void);                       /* 粉 [255,140,180] */
Value rt_lib_pal_jin(void);                       /* 金 [255,200,60] */

/* ---------- np 数组库（numpybk，实现在 pybook_np.c） ---------- */

Value rt_np_zeros(Value n);                       /* np.zeros(n)：n 个 0 */
Value rt_np_range(Value lo, Value hi, Value step);/* np.range(起,止,步) */
Value rt_np_add(Value a, Value b);                /* 元素级加 */
Value rt_np_sub(Value a, Value b);                /* 元素级减 */
Value rt_np_mul(Value a, Value b);                /* 元素级乘 */
Value rt_np_scale(Value a, Value k);              /* 数乘 */
Value rt_np_dot(Value a, Value b);                /* 点积 */
Value rt_np_norm(Value a);                        /* 模长 */
Value rt_np_normalize(Value a);                   /* 归一化 */
Value rt_np_max(Value a);                         /* 最大 */
Value rt_np_min(Value a);                         /* 最小 */
Value rt_np_sum(Value a);                         /* 总和 */
Value rt_np_mean(Value a);                        /* 平均 */
Value rt_np_sin(Value a);                         /* 元素级 sin */
Value rt_np_cos(Value a);                         /* 元素级 cos */
Value rt_np_sqrt(Value a);                        /* 元素级 sqrt */

/* ---------- tb 神经网络库（torchbk，实现在 pybook_tb.c） ----------
 * 张量 = 列表的列表（2D 浮点矩阵）。前向 + 手写梯度对 + SGD。 */

Value rt_tb_mat(Value r, Value c);                 /* 零矩阵 */
Value rt_tb_rand(Value r, Value c);                /* [-1,1] 随机矩阵（初始化权重） */
Value rt_tb_rows(Value m);                         /* 行数 */
Value rt_tb_cols(Value m);                         /* 列数 */
Value rt_tb_dot(Value a, Value b);                 /* 矩阵乘 */
Value rt_tb_tr(Value m);                           /* 转置 */
Value rt_tb_add(Value a, Value b);                 /* 逐元素加 */
Value rt_tb_mul(Value a, Value b);                 /* 逐元素乘 */
Value rt_tb_addrow(Value m, Value row);            /* 行广播加（偏置） */
Value rt_tb_relu(Value m);                         /* ReLU */
Value rt_tb_sigmoid(Value m);                      /* Sigmoid */
Value rt_tb_lin(Value x, Value w, Value b);        /* 线性层 x@w+b */
Value rt_tb_mse(Value y, Value t);                 /* 均方误差 */
Value rt_tb_relu_grad(Value pre);                  /* d ReLU（传激活前的值） */
Value rt_tb_sigmoid_grad(Value y);                 /* d Sigmoid（传激活后的值） */
Value rt_tb_mse_grad(Value y, Value t);            /* d MSE */
Value rt_tb_lin_dx(Value x, Value w, Value g);     /* 线性层对 x 的梯度 */
Value rt_tb_lin_dw(Value x, Value g);              /* 线性层对 w 的梯度 */
Value rt_tb_lin_db(Value g);                       /* 线性层对 b 的梯度 */
Value rt_tb_step(Value m, Value dm, Value lr);     /* SGD 一步：m - lr*dm */
Value rt_tb_softmax(Value m);
Value rt_js_parse(Value text);               /* js.parse：JSON 文本 -> 值 */
Value rt_js_dump(Value v);                   /* js.dump：值 -> JSON 文本 */
Value rt_csv_parse(Value text);              /* csv.parse：表格文本 -> 二维表 */
Value rt_csv_dump(Value table);              /* csv.dump：二维表 -> 表格文本 */
int  rt_mm_lookup(Value tok, int *r, int *g, int *b);
                                    /* mm 调色板查询：1=不透明 0=透明 -1=未知 */
Value rt_mm_color(Value tok, Value r, Value g, Value b);
                                    /* mm.色：注册/覆盖颜色 token */
Value rt_mm_draw_away(Value rows, Value file, Value scale);
unsigned char *rt_mm_raster(Value rows, long long scale, size_t *W, size_t *H);
                                    /* mm 光栅化：token 列表 -> RGBA 缓冲（分配不回收） */
Value rt_mm_blt(Value rows, Value x, Value y, Value scale);
                                    /* mm.贴：窗口模式把列表画到 (x,y)，1 格 = N×N 像素 */
                                    /* mm.draw_away：列表渲染落成 PNG，返回文件名 */                      /* 每行 softmax */
Value rt_tb_crossent(Value y, Value t);            /* 交叉熵（target=类别下标列） */
Value rt_tb_crossent_grad(Value y, Value t);       /* dL/dy */
Value rt_tb_argmax(Value m);                       /* 每行最大值下标 */
Value rt_tb_sgd(Value w, Value dw, Value lr);      /* SGD 就地更新 */
Value rt_tb_adam(Value w, Value dw, Value m, Value v, Value lr, Value b1, Value b2, Value step);
Value rt_tb_shuffle(Value list, Value seed);       /* 洗牌（新表） */
Value rt_tb_onehot(Value n, Value k);              /* 单热行向量 */
Value rt_tb_batch(Value list, Value i, Value sz);  /* 第 i 批切片 */

/* ---------- mp 数学扩展（mathplus，实现在 mathplus.c） ---------- */
#include "mathplus.h"

/* ---------- bs 位运算扩展（实现在 pybook_bits.c） ---------- */
/* 放在这里 = 让 pybook_bits.h 先看到 pybook_rt.h，绑定层随之生效 */
#include "pybook_bits.h"

#endif /* PYBOOK_LIB_H */
