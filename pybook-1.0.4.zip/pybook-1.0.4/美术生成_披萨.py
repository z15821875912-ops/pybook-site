# -*- coding: utf-8 -*-
"""披萨塔 教学关 美术生成器：字符串像素画 → games/披萨塔/*.png + 对照图。
主角是原创的白衣大厨（披萨主题高速平台动作），风格手绘感像素。"""
import os
from PIL import Image, ImageDraw

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "games", "披萨塔")
os.makedirs(OUT, exist_ok=True)

PAL = {
    'k': (26, 22, 28),      # 描边
    'w': (248, 244, 238),   # 厨师白衣
    'W': (206, 198, 190),   # 白衣暗
    's': (240, 198, 156),   # 皮肤
    'S': (212, 166, 122),   # 皮肤暗
    'h': (70, 46, 36),      # 头发棕
    'r': (214, 60, 50),     # 红围巾/番茄
    'R': (160, 40, 40),     # 红暗
    'y': (250, 200, 60),    # 芝士黄
    'Y': (210, 150, 34),    # 黄暗
    'b': (60, 60, 70),      # 裤深灰
    'B': (40, 40, 50),      # 裤暗
    'e': (30, 28, 34),      # 眼
    'm': (232, 170, 120),   # 砖亮
    'M': (198, 134, 88),    # 砖基
    'n': (150, 96, 62),     # 砖暗
    'N': (120, 74, 48),     # 砖深
    'g': (128, 130, 140),   # 裂块灰基
    'G': (96, 98, 108),     # 灰暗
    'f': (255, 230, 140),   # 高光
    'u': (238, 220, 190),   # 木台亮
    'U': (196, 168, 126),   # 木台暗
    'o': (150, 60, 160),    # 蘑菇紫
    'O': (110, 40, 120),    # 蘑菇紫暗
    't': (250, 230, 220),   # 蘑菇柄
    'p': (90, 70, 50),      # 香肠棕
    'P': (60, 44, 32),      # 香肠暗
    'c': (255, 255, 255),   # 白(眼)
    'q': (240, 240, 245),   # 眼白
}

def png(name, rows):
    w = len(rows[0]); h = len(rows)
    for r in rows:
        assert len(r) == w, f"{name} 行宽不齐: {len(r)} != {w}"
    im = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    px = im.load()
    for y, row in enumerate(rows):
        for x, ch in enumerate(row):
            if ch != '.':
                c = PAL[ch]
                px[x, y] = (c[0], c[1], c[2], 255)
    im.save(os.path.join(OUT, name + ".png"))

# ---------------- 大厨 16×16 ----------------
# 站立
厨_站 = [
    "................",
    ".....kkkkkk.....",
    "....khhhhhhk....",
    "...khsssssshk...",
    "...kseqqeqqsk...".replace('q', 's'),
    "...ksseesss sk..".replace(' ', 'e'),
    "....kssssssk....",
    "...krrrrrrrrk...",
    "..kwrrrrrrrrwk..",
    "..kwkwkkkkwkwk..",
    "..kwkwwwwwwkwk..",
    "...kwwwwwwwwk...",
    "....kbbkkbbk....",
    "....kBbk.kBbk...",
    "....kkkk.kkkk...",
    "................",
]
# 走 A/B（腿交替）
厨_走A = [
    "................",
    ".....kkkkkk.....",
    "....khhhhhhk....",
    "...khsssssshk...",
    "...kssesseesk...",
    "...kssssssssk...",
    "....kssssssk....",
    "...krrrrrrrrk...",
    "..kwrrrrrrrrwk..",
    "..kwkwkkkkwkwk..",
    "..kwkwwwwwwkwk..",
    "...kwwwwwwwwk...",
    "...kbbk.kbbbk...",
    "..kBbk...kbbk...",
    "..kkk.....kkk...",
    "................",
]
厨_走B = [
    "................",
    ".....kkkkkk.....",
    "....khhhhhhk....",
    "...khsssssshk...",
    "...kssesseesk...",
    "...kssssssssk...",
    "....kssssssk....",
    "...krrrrrrrrk...",
    "..kwrrrrrrrrwk..",
    "..kwkwkkkkwkwk..",
    "..kwkwwwwwwkwk..",
    "...kwwwwwwwwk...",
    "...kbbbbbk.kk...",
    "...kbb.kbbk.....",
    "...kk..kkkk.....",
    "................",
]
# 跑 A/B（前倾、腿大步）
厨_跑A = [
    "................",
    "................",
    "......kkkkkk....",
    ".....khhhhhhk...",
    "....khsssssshk..",
    "....kssesseesk..",
    "....ksssssssk...",
    "...krrrrrrrrk...",
    "..kwrrrrrrrrwk..",
    "..kwkwkkkkwkwk..",
    "..kwkwwwwwwwwk..",
    "...kwwwwwwbbbk..",
    "...kbbkkbbbbk...",
    "..kbbbk.kkkk....",
    "..kkkk..........",
    "................",
]
厨_跑B = [
    "................",
    "................",
    "......kkkkkk....",
    ".....khhhhhhk...",
    "....khsssssshk..",
    "....kssesseesk..",
    "....ksssssssk...",
    "...krrrrrrrrk...",
    "..kwrrrrrrrrwk..",
    "..kwkwkkkkwkwk..",
    "..kwkwwwwwwwwk..",
    "...kwwwwwwwbbk..",
    "....kbbbbbbbk...",
    "....kkb.bbk.....",
    "......kkkk......",
    "................",
]
# 音速 A/B（极度前倾+护目镜感，加'速度线'由游戏画）
厨_音A = [
    "................",
    "................",
    "................",
    ".......kkkkkkk..",
    "..kk.khhhhhhhk..",
    ".khhkhsssssshk..",
    ".kssseeeqeqqk...".replace('q', 's'),
    "..kssssssssk....",
    "...krrrrrrrk....",
    "..kwrrrrrrrwwk..",
    ".kwkwwwwwwwwwk..",
    ".kwkwwwbbbbbbk..",
    "..kbbbbbbbkk....",
    "..kbbk.kbkk.....",
    "...kk...kk......",
    "................",
]
厨_音B = [
    "................",
    "................",
    "................",
    ".......kkkkkkk..",
    "..kk.khhhhhhhk..",
    ".khhkhsssssshk..",
    ".ksssseesssk....",
    "..ksssssssk.....",
    "...krrrrrrk.....",
    "..kwrrrrrrwwk...",
    ".kwkwwwwwwwwwk..",
    ".kwkwwwbbbbbbk..",
    "...kbbbbbbbbk...",
    "....kbb..bbk....",
    "....kk....kk....",
    "................",
]
# 跳（上伸手）/落（手下压）
厨_跳 = [
    "................",
    ".....kkkkkk.....",
    "....khhhhhhk....",
    "...khsssssshk...",
    "...kssesseesk...",
    "...kssssssssk...",
    "....kssssssk....",
    ".k.krrrrrrrrk.k.",
    "kwkwrrrrrrrwkwk.",
    ".kwkwkkkkwkwkk..",
    "...kwwwwwwkwk...",
    "...kwwwwwwwk....",
    "....kbbkkbbk....",
    "....kBbk.kBbk...",
    "....kkkk.kkkk...",
    "................",
]
厨_落 = [
    "................",
    ".....kkkkkk.....",
    "....khhhhhhk....",
    "...khsssssshk...",
    "...kssesseesk...",
    "...kssssssssk...",
    "....kssssssk....",
    "kwwkrrrrrrrrkwwk",
    "kwkwrrrrrrrrwkwk",
    ".kkwkwkkkwwkk.k.",
    "....kwwwwwwk....",
    "...kwwwwwwwwk...",
    "....kbbkkbbk....",
    "....kbbk.kbbk...",
    "....kkk...kkk...",
    "................",
]
# 翻滚 A/B（抱球）
厨_滚A = [
    "................",
    "................",
    "................",
    "................",
    "......kkkkk.....",
    "....kkwwwwwkk...",
    "...kwwwhhwwwk...",
    "..kwsssesswswk..".replace(' ', 'w'),
    "..kwsssssswwWk..",
    "..kWwwwwwwWwwk..",
    "...kWWwwWWwwk...",
    "....kkWWWWkk....",
    "......kkkk......",
    "................",
    "................",
    "................",
]
厨_滚B = [
    "................",
    "................",
    "................",
    "................",
    "......kkkkk.....",
    "....kkwwwwwkk...",
    "...kwwwwhhwwk...",
    "..kwwssesswwsk..",
    "..kWwsssssswwk..",
    "..kwwWwwwwwWwk..",
    "...kwWWwwWWwk...",
    "....kkWWWWkk....",
    "......kkkk......",
    "................",
    "................",
    "................",
]
# 压碎（空中下压，腿朝下伸直）
厨_压 = [
    "................",
    "................",
    ".....kkkkkk.....",
    "....khhhhhhk....",
    "...khsssssshk...",
    "...kssesseesk...",
    "...kssssssssk...",
    "kwwkssssssskwwk.",
    "kwkwrrrrrrrkwkk.",
    ".kwkrrrrrrrkwk..",
    "..kkkkkkkkkkk...",
    "....kbbbbbk.....",
    "....kbbbbbk.....",
    "....kBbbbk......",
    "....kkkkk.......",
    "................",
]
# 贴墙爬 A/B（身体贴墙竖展）
厨_爬A = [
    "................",
    ".....kkkkkk.....",
    "....khhhhhhk....",
    "...khsssssshk...",
    "...kssesseesk...",
    "...kssssssssk...",
    "..k.kssssssk.k..",
    ".kwkwrrrrrrkwkk.",
    ".kwkwrrrrrrkwk..",
    "..kwkwkkkkwkk...",
    "...kwwwwwwk.....",
    "...kwwwwwwwk....",
    "....kbbkbbk.....",
    "....kbb.kbk.....",
    "....kk...kk.....",
    "................",
]
厨_爬B = [
    "................",
    ".....kkkkkk.....",
    "....khhhhhhk....",
    "...khsssssshk...",
    "...kssesseesk...",
    "...kssssssssk...",
    "..kk.ksssssk....",
    ".kwkwrrrrrkwkk..",
    ".kwkwrrrrrkwk...",
    "..kkwkkkkwkk....",
    "....kwwwwwk.....",
    "....kwwwwwwk....",
    "....kbkbbk......",
    "....kbk.kbk.....",
    "....kk...kk.....",
    "................",
]

# ---------------- 地块 16×16 ----------------
块_地 = [
    "ffffffffffffffff",
    "fMMMMMMMMMMMMMMm",
    "fMmmMMmmMMmmMMmf",
    "fMMMMMMMMMMMMMMf",
    "fMMMMMMMMnMMMMMf",
    "fnMMMMMMMMMMMmmf",
    "fMmmMMmmMMMMMMMf",
    "fMMMMMMMMMMMMMMf",
    "fMMMMMnMMMMMMMMf",
    "fMMMMMMMMMMMmMMf",
    "fMmmMMmmMMMMMMnf",
    "fMMMMMMMMnMMMMDf".replace('D', 'M'),
    "fMMMMMMMMMMMDDDf".replace('D', 'M'),
    "fnMMMMMMMMMMMMMf",
    "fMmmMMmmMMMMMmMf",
    "nnnnnnnnnnnnnnnn",
]
块_台 = [
    "................",
    "................",
    "................",
    "................",
    "................",
    "................",
    "................",
    "................",
    "ffffffffffffffff",
    "kuuuuuuuuuuuuuUm",
    "kUnUUnUUnUUnUUnm",
    "kkkkkkkkkkkkkkkk",
    "................",
    "................",
    "................",
    "................",
]
块_裂 = [
    "fggggggggggggggf",
    "fgGggGfgGggGgggf",
    "fggggGgGgggggggf",
    "fgGgg.kGk.gGgggf".replace('.', 'g'),
    "fggGg.kGk.Gggggf".replace('.', 'g'),
    "fgggg.kGk.gggggf".replace('.', 'g'),
    "fgGgg.kGk.gGgggf".replace('.', 'g'),
    "fggggg.kG.ggggff".replace('.', 'g'),
    "fgGgg.kGk.gGgggf".replace('.', 'g'),
    "fgggg.kGk.gggggf".replace('.', 'g'),
    "fggGg.kGk.Gggggf".replace('.', 'g'),
    "fggggGkGkggggggf",
    "fgGggGgGggGggggf",
    "fggggggggggggggf",
    "fGGGGGGGGGGGGGGf",
    "ffffffffffffffff",
]
牌 = [
    "................",
    "................",
    "................",
    "................",
    ".kkkkkkkkkkkkkk.",
    ".kuuuuuuuuuuuuk.",
    ".kuuuuuuuuuuuUk.",
    ".kuuUuuuuuUuuuk.",
    ".kuuuuuuuuuuuUk.",
    ".kuUuuuuuuuuuuk.",
    ".kuuuuuuUuuuuUk.",
    ".kuuuuuuuuuuuuk.",
    ".kuUuuuuuuUuuUk.",
    ".kkkkkkkkkkkkkk.",
    "......kpk.......",
    "......kpk.......",
]
# 出口门 16×24
门 = [
    "....kkkkkkkk....",
    "...kuuuuuuuuk...",
    "..kuUUUUUUUUuk..",
    "..kuuyyyyyyuUk..",
    "..kuyyryyryyuUk.",
    "..kuyyryyryyyuk.",
    "..kuyyyyyyyyyuk.",
    "..kuyyyrryyyyuk.",
    "..kuyyrrrrryyuk.",
    "..kuyyrrrrryyuk.",
    "..kuyyyrryyyyuk.",
    "..kuyyyyyyyyyuk.",
    "..kuyyryyryyyuk.",
    "..kuyyryyryyyuk.",
    "..kuyyyyyyyyyuk.",
    "..kuuuuuuuuuuuk.",
    "..kuukkkkkkuuUk.",
    "..kuukwwwwkuuUk.",
    "..kuukwsswkuuUk.",
    "..kuukwsswkuuUk.",
    "..kuukkkkkkuuUk.",
    "..kuuuuuuuuuuUk.",
    "..kUUUUUUUUUUUk.",
    "...kkkkkkkkkkk..",
]
# ---------------- 顶料 16×16 ----------------
芝士 = [
    "................",
    "................",
    "................",
    "......kk........",
    ".....kyyk.......",
    "....kyyyykk.....",
    "...kyyyyyYyk....",
    "..kyyYyyyyyYk...",
    ".kyyyyyYyyyyyk..",
    ".kyYyyyyyyyyYk..",
    ".kyyyyYyyyyyyk..",
    ".kYyyyyyyYyyYk..",
    "..kkkkkkkkkkk...",
    "................",
    "................",
    "................",
]
番茄 = [
    "................",
    "................",
    ".....kkkkk......",
    "...kkrrrrrkk....",
    "..krrfrrrrrrk...",
    ".krrrrrrrrrrrk..",
    ".krfrYrrYrrrrk..",
    ".krrrYYrrYYrrk..",
    ".krfrYYrrrrrrk..",
    ".krrrrrrYrrrrk..",
    "..krrrrrrrrrk...",
    "...kkrrrrrkk....",
    ".....kkkkk......",
    "................",
    "................",
    "................",
]
蘑菇 = [
    "................",
    "................",
    "....kkkkkkk.....",
    "..kkooooooookk..",
    ".kooooffffoooo×k".replace('×', 'o'),
    ".kooffooooofook.",
    "koooffoooooofook",
    "kooooooooffooo×k".replace('×', 'o'),
    "kkkkkkkkkkkkkkk.",
    "..kttttttttttk..",
    "..kttqkttqkttk..".replace('q', 't'),
    "..kttttttttttk..",
    "..ktUtttttUtuk..".replace('u', 't'),
    "...kkkkkkkkkk...",
    "................",
    "................",
]
香肠 = [
    "................",
    "................",
    "................",
    "....kkkkkkkkk...",
    "..kkpppppppppkk.",
    ".kpppPPpppPPppk.",
    ".kpPpppppppppPk.",
    ".kppppPPppppppk.",
    ".kpPppppppPPppk.",
    ".kpppppPPppppPk.",
    ".kpPppppppppppk.",
    ".kppppPPpppPppk.",
    "..kkpppppppppkk.",
    "....kkkkkkkkk...",
    "................",
    "................",
]
# ---------------- 敌人：奶酪怪 2 帧 ----------------
酪怪A = [
    "................",
    "................",
    "................",
    "................",
    "....kkkkkkkk....",
    "...kyyyyyyyyk...",
    "..kyyyyyyyyyyk..",
    "..kyeqyyyyeqyk..",
    "..kyeeyyyyeeyk..",
    ".kyyyyyyyyyyyyk.",
    ".kyyyyYyyYyyyyk.",
    ".kyyyyyyyyyyyYk.",
    "..kYyyyyyYyyyk..",
    "...kkkkkkkkkk...",
    "....kk....kk....",
    "................",
]
酪怪B = [
    "................",
    "................",
    "................",
    "................",
    "....kkkkkkkk....",
    "...kyyyyyyyyk...",
    "..kyyyyyyyyyyk..",
    "..kyeqyyyyeqyk..",
    "..kyeeyyyyeeyk..",
    ".kyyyyyyyyyyyyk.",
    ".kyyyyYyyYyyyyk.",
    ".kyyyyyyyyyyyYk.",
    "..kYyyyyyYyyyk..",
    "...kkkkkkkkkk...",
    ".....kk..kk.....",
    "................",
]

# 扑击（超人式俯冲，身体水平双臂前伸）
厨_扑 = [
    "................",
    "................",
    "................",
    "................",
    "................",
    "....kkkkk.......",
    "...khhhhhsksk...".replace('s', 's'),
    "..khssssssssk...",
    ".krrssseessskkkk",
    "kwrrrrsssssswwwk",
    "kwkwrrrrsssswwsk",
    ".kkwkkrrrrrrwwwk",
    "...kwwwwwwwkkk..",
    "....kbbbbbkk....",
    "....kkkkkk......",
    "................",
]
# 趴下（贴地匍匐）
厨_趴 = [
    "................",
    "................",
    "................",
    "................",
    "................",
    "................",
    "................",
    "................",
    "....kkkkkk......",
    "...khhhhhhk.....",
    "..khsssssshk.kk.",
    ".krrseesseeskwwk",
    "kwkrrsssssswwwwk",
    "kkkkkkkkkkkkkkkk",
    "................",
    "................",
]


# 约翰柱子（16×24，惊恐脸柱）
约翰 = [
    "....kkkkkkkk....",
    "...kwwwwwwwwk...",
    "...kwWWWWWWwk...",
    "...kwqqqqqqwk...",
    "..kwqeeqqeeqwk..",
    "..kwqeeqqeeqwk..",
    "..kwqqqqqqqqwk..",
    "..kwqqnqqnqqwk..",
    "..kwqknnnnkqwk..",
    "..kwqknnnnkqwk..",
    "..kwqqnnnnqqwk..",
    "...kwqqqqqqqwk..",
    "...kwWWqqWWwwk..".replace('w', 'w'),
    "...kwWwwwwWwwk..",
    "...kwWwwwwWwwk..",
    "...kwWWwwWWwwk..",
    "...kwwwwwwwwwk..",
    "...kwWwwwwWwwk..",
    "..kkkkkkkkkkkkk.",
    ".kUUUUUUUUUUUUk.",
    ".kUUUUUUUUUUUUk.",
    ".kkkkkkkkkkkkkk.",
    "................",
]


# 马赫4：扭曲残影形态（24×16，水平拉长+颤抖五官+拖尾速度线）
厨_马4A = [
    "........................",
    "........................",
    "..............kkkk......",
    "..k..........khhhhsk....",
    ".kfk.kkkkkkkhhsssssk....",
    "..kfkkhhhhhhsseeesk.....",
    ".kkhhsssssssseeeqsk.....",
    "khhssssssssssssskkk.....",
    "kssrrrrrrrrrrssssk......",
    ".krrrrrrrrrrrrwwkk......",
    "..kwwwwwwwwwwwwwwwkkk...",
    "..kwkkwwkkwwkkwwwwwwkkk.",
    "...kwkwwkkwwkkwwkkwwkkk.",
    "....kkbbkkbbkkbbkkbbkk..",
    "......kBbkkBbkkBbkk.....",
    "........................",
]
厨_马4B = [
    "........................",
    "........................",
    "..............kkkk......",
    "...k........khhhhsk.....",
    "..kfk.kkkkkkkhssssk.....",
    ".kkfkkhhhhhhseeesk......",
    "kkhhssssssssseeeqk......",
    ".khhsssssssssssskk......",
    "..kssrrrrrrrrrsssk......",
    "..krrrrrrrrrrrwwkk......",
    "...kwwwwwwwwwwwwwwkkk...",
    "...kwkkwwkkwwkkwwwwkkk..",
    "....kwkwwkkwwkkwwkwwkk..",
    ".....kkbbkkbbkkbbkkbbk..",
    ".......kBbkkBbkkBbkk....",
    "........................",
]

ALL = {
    "厨_站": 厨_站, "厨_走A": 厨_走A, "厨_走B": 厨_走B,
    "厨_跑A": 厨_跑A, "厨_跑B": 厨_跑B,
    "厨_音A": 厨_音A, "厨_音B": 厨_音B,
    "厨_跳": 厨_跳, "厨_落": 厨_落,
    "厨_滚A": 厨_滚A, "厨_滚B": 厨_滚B,
    "厨_压": 厨_压, "厨_爬A": 厨_爬A, "厨_爬B": 厨_爬B, "厨_扑": 厨_扑, "厨_趴": 厨_趴,
    "块_地": 块_地, "块_台": 块_台, "块_裂": 块_裂, "牌": 牌, "门": 门,
    "芝士": 芝士, "番茄": 番茄, "蘑菇": 蘑菇, "香肠": 香肠,
    "酪怪A": 酪怪A, "酪怪B": 酪怪B, "约翰": 约翰, "厨_马4A": 厨_马4A, "厨_马4B": 厨_马4B,
}
for name, rows in ALL.items():
    png(name, rows)

names = list(ALL.keys())
cols = 8
cell_w, cell_h = 4 * 32 + 12, 4 * 32 + 26
rows_n = (len(names) + cols - 1) // cols
sheet = Image.new("RGB", (cols * cell_w, rows_n * cell_h), (40, 36, 52))
draw = ImageDraw.Draw(sheet)
for i, name in enumerate(names):
    im = Image.open(os.path.join(OUT, name + ".png")).convert("RGBA")
    sc = 4 if max(im.size) <= 16 else 3
    im2 = im.resize((im.width * sc, im.height * sc), Image.NEAREST)
    cx = (i % cols) * cell_w + 6
    cy = (i // cols) * cell_h + 18
    sheet.paste(im2, (cx, cy), im2)
    draw.text((cx, cy - 14), name, fill=(235, 235, 235))
sheet.save("_披萨美术对照.png")
print(f"已生成 {len(ALL)} 个精灵 → {OUT}")
