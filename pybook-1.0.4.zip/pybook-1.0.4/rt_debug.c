/* PYbook v2 运行时库——NaN-boxing 万能盒 Value 的实现（与 pybook_rt.h 配套）。
 *
 * Value 是一个 64 位盒子：浮点直接存原始位样（最快路径），其余类型装进
 * IEEE754 NaN 的未用载荷位（位样布局见 pybook_rt.h 头注释）。
 * 旧 struct Value 的 flags 字段去向：
 *   F_LOCKED → 槽地址侧表（锁定是"槽"的状态；rt_gold 写）；
 *   F_DELETED → 槽内盒子整体改写成 DELETED 位样（随值旅行，rt_chk 拦截）；
 *   F_RC → 载荷位 47（本版预留，永不置位）。
 * 整数快路径 48 位；更大的整数自动转 BIGINT 堆盒，64 位全范围保真。
 *
 * 内存约定：所有 malloc 之后一律不 free，脚本结束由进程统一归还；
 * 字符串不可变，Value 的赋值/传参只拷 8 字节盒子不拷内容。
 * 例外：@self（完全手动）模式下 rt_destroy 会真正 free——已释放指针登记在案
 * （最多 1024 个），共享别名二次 delete 不会 double-free；悬空访问后果自负。
 * 错误约定：所有运行时错误向 stderr 输出 "运行时错误: 原因" 后 exit(1)。
 *
 * 模块分工：te/mt/rd 在 pybook_lib.c（rt_lib_*，本文件不得重复定义），
 * file 在 pybook_file.c（rt_file_*，同上），其余全部在本文件。
 *
 * 游戏零件（rt_game_*）：SDL2 头文件在包含路径里即自动启用真实现；否则
 * 编译"未启用"桩——调用时给出明确报错，库自测等无 SDL 构建照样能链接。
 *
 * 自测（覆盖本库全部函数的正常 + 边界：溢出/除零/空列表/类型错误/锁删，
 * 报错分支没法在本进程里"接住"（rt_* 直接 exit(1)），所以拉起自身作为
 * 子进程跑指定用例，验证退出码为 1 且 stderr 带对应消息；同时冒烟链接
 * 进来的 pybook_lib.c（te/mt/rd）与 pybook_file.c（file））：
 *   gcc -O2 -DRT_SELF_TEST pybook_rt.c pybook_lib.c pybook_file.c
 *       -o rt_test.exe -I. -Iucrt64/include -Lucrt64/lib -lSDL2
 * 附加玩法：rt_test.exe game —— 开一个 SDL 窗口跑 120 帧图形演示。
 */

#if defined(__MINGW32__) && !defined(__USE_MINGW_ANSI_STDIO)
#define __USE_MINGW_ANSI_STDIO 1   /* 保证 %lld / %g 按 C99 语义工作 */
#endif

#include <errno.h>
#include <limits.h>
#include <math.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "pybook_rt.h"

/* ================= 内部工具 ================= */

/* 内存模式全局开关：0=@normal 1=@self（3=引用计数预留，暂未实现）。
 * 单线程语言：只在主执行流里被读写，无并发访问点，因此不加锁。 */
static int g_memmode = 0;

/* 统一的运行时错误出口 */
static void rt_die(const char *fmt, ...)
{
    va_list ap;
    fprintf(stderr, "运行时错误: ");
    va_start(ap, fmt);
    vfprintf(stderr, fmt, ap);
    va_end(ap);
    fputc('\n', stderr);
    exit(1);
}

/* ── 锁定侧表：F_LOCKED 的家 ──
 * 8 字节盒子里没有 flags 的位置，而"锁定"是槽的状态，所以按槽地址登记
 * （教学规模：每个程序锁定的变量屈指可数，固定 256 格线性查找足够；
 * 记录只增不删——语言里没有"解锁"）。 */
static struct { uint64_t box; } g_locks[256];
static int g_nlocks = 0;

static int slot_is_locked(Value *slot)
{
    uint64_t key = (uint64_t)(uintptr_t)slot;
    for (int i = 0; i < g_nlocks; i++)
        if (g_locks[i].box == key)
            return 1;
    return 0;
}

static void slot_lock(Value *slot)
{
    if (slot_is_locked(slot))
        return;
    if (g_nlocks >= (int)(sizeof g_locks / sizeof g_locks[0]))
        rt_die("锁定的变量太多（上限 %d 个）", (int)(sizeof g_locks / sizeof g_locks[0]));
    g_locks[g_nlocks++].box = (uint64_t)(uintptr_t)slot;
}

/* @self 模式的已释放指针登记表：free 过的地址都记下来，共享别名（两个名字
 * 拷贝了同一个盒子）二次 delete 时查表命中就跳过 free，只打删除标志——
 * "悬空访问后果自负"不等于"进程因 double-free 崩溃"。表满后不再登记
 * （方向保守：宁可泄漏到进程退出，也不二次 free）。 */
#define RT_FREED_CAP 1024
static const void *g_freed[RT_FREED_CAP];
static size_t g_freed_n = 0;

static int ptr_registered(const void *p)
{
    if (p == NULL)
        return 1;   /* NULL 无需释放 */
    for (size_t i = 0; i < g_freed_n; i++)
        if (g_freed[i] == p)
            return 1;
    return 0;
}

static void register_freed(const void *p)
{
    if (p != NULL && g_freed_n < RT_FREED_CAP)
        g_freed[g_freed_n++] = p;
}

/* ================= Memoryment 地基：统一堆单元（@3@4@5@6 共用） =================
 * 布局："头在载荷前"——每次分配 = sizeof(RtCell) + nbytes，返回的是载荷指针，
 * 于是 AS_STR / AS_LIST / AS_OBJ 这些宏一个都不用改，只在分配与释放处接管：
 *      [ RtCell 头 ][ 载荷：char 数组 / RtList / RtObject / long long ]
 * 所有"装得进 Value"的堆对象（字符串、列表、对象、BIGINT）都走这里并登记进
 * 全局双向链 g_all，供 @5 清除、@6 分代与统计遍历。
 * 不进链的辅助 malloc：显示文本（rt_str_of）、对象属性名——它们由宿主单元
 * 托管，随宿主一起释放。
 * 回收语义按模式分派（见 rt_set_memmode）：
 *   0 @normal 不回收（进程退出统一归还）  1 @self 手动 del 真释放
 *   3 @3 引用计数   4 @4 竞技场整块归还   5 @5 标记清除   6 @6 分代+增量
 */
typedef struct RtCell RtCell;
typedef struct RtArena RtArena;

struct RtCell {
    uint32_t rc;             /* 引用计数（@3 起用） */
    uint8_t  kind;           /* RTK_STR / LIST / OBJ / BIGINT */
    uint8_t  mark;           /* GC 标记位（@5/@6） */
    uint8_t  gen;            /* 分代：0=新生代 1=老年代（@6） */
    uint8_t  gray;           /* 已在增量标记的 gray 栈里（@6） */
    RtArena *owner;          /* 非 NULL：块内分配（@4 竞技场），随块回收 */
    RtCell  *next, *prev;    /* g_all 双向链 */
};

#define RTK_STR    0
#define RTK_LIST   1
#define RTK_OBJ    2
#define RTK_BIGINT 3

/* @4 竞技场：按块 bump 分配，整块归还（块内单元不单独 free） */
struct RtArena {
    RtArena *next;
    size_t   used, cap;
    char    *mem;
};
#define RT_ARENA_CHUNK (64u * 1024u)

static RtCell  *g_all   = NULL;   /* 全部存活单元 */
static size_t   g_live  = 0;      /* 存活单元数 */
static size_t   g_bytes = 0;      /* 近似占用（头+载荷），GC 阈值判断用 */
static RtArena *g_arena = NULL;   /* @4 当前块链 */

/* 单元入链/摘链 */
static void cell_link(RtCell *c)
{
    c->prev = NULL;
    c->next = g_all;
    if (g_all)
        g_all->prev = c;
    g_all = c;
    g_live++;
}

static void cell_unlink(RtCell *c)
{
    if (c->prev)
        c->prev->next = c->next;
    else
        g_all = c->next;
    if (c->next)
        c->next->prev = c->prev;
    c->next = c->prev = NULL;
    if (g_live)
        g_live--;
}

/* @4：从竞技场当前块 bump 一段；不够就新开一块 */
static void *arena_bump(size_t n)
{
    n = (n + 15u) & ~(size_t)15u;                 /* 16 字节对齐 */
    if (n > RT_ARENA_CHUNK) {
        /* 大于块尺寸：单独开一块专属大块 */
        RtArena *a = (RtArena *)malloc(sizeof(RtArena));
        if (!a)
            rt_die("内存不足");
        a->cap = n;
        a->used = n;
        a->mem = (char *)malloc(n);
        if (!a->mem)
            rt_die("内存不足");
        a->next = g_arena;
        g_arena = a;
        return a->mem;
    }
    if (!g_arena || g_arena->used + n > g_arena->cap) {
        RtArena *a = (RtArena *)malloc(sizeof(RtArena));
        if (!a)
            rt_die("内存不足");
        a->cap = RT_ARENA_CHUNK;
        a->used = 0;
        a->mem = (char *)malloc(RT_ARENA_CHUNK);
        if (!a->mem)
            rt_die("内存不足");
        a->next = g_arena;
        g_arena = a;
    }
    void *p = g_arena->mem + g_arena->used;
    g_arena->used += n;
    return p;
}

/* 取"当前块"（给单元记 owner 用） */
static RtArena *arena_current(void) { return g_arena; }

static void remember(RtCell *container, Value val);   /* @6 写屏障，定义见 Memoryment 段 */

/* 统一的 Value 级分配：带 RtCell 头，返回载荷指针。
 * 注意：这里**不**触发回收——表达式求值途中的临时值没有登记为根，
 * 若在分配时收集，会把正在使用的临时对象收走。回收只在语句边界
 * （生成代码调 rt_gc_poll）发生，见 Memoryment 段说明。 */
static void *heap_alloc(int kind, size_t nbytes)
{
    RtCell *c;
    if (g_memmode == 4) {                          /* @4：竞技场 */
        c = (RtCell *)arena_bump(sizeof(RtCell) + nbytes);
        c->owner = arena_current();
    } else {
        c = (RtCell *)malloc(sizeof(RtCell) + nbytes);
        if (!c)
            rt_die("内存不足");
        c->owner = NULL;
    }
    c->rc   = 1;
    c->kind = (uint8_t)kind;
    c->mark = 0;
    c->gen  = 0;
    c->gray = 0;
    cell_link(c);
    g_bytes += sizeof(RtCell) + nbytes;
    return (void *)(c + 1);
}

/* 辅助裸内存（列表 items 等）：跟随当前模式，块内分配则随块回收 */
static void *heap_raw(size_t nbytes)
{
    if (g_memmode == 4)
        return arena_bump(nbytes);
    void *p = malloc(nbytes);
    if (!p)
        rt_die("内存不足");
    return p;
}

static void heap_raw_free(void *p, RtCell *owner_hint)
{
    /* 块内分配的内存不单独 free；只有 malloc 来的才 free */
    if (p && (!owner_hint || !owner_hint->owner))
        free(p);
}

/* 辅助裸内存扩容：块内分配不能 realloc（bump 区没有伸缩余地），
 * 改为"新开一段 + 拷贝旧内容"，旧段留在块里随整块回收。 */
static void *heap_raw_grow(void *p, RtCell *owner_hint, size_t oldn, size_t newn)
{
    if (owner_hint && owner_hint->owner) {
        void *np = arena_bump(newn);
        if (p && oldn)
            memcpy(np, p, oldn);
        return np;
    }
    void *np = realloc(p, newn);
    if (!np)
        rt_die("内存不足");
    return np;
}

/* 由 Value 找到它的单元头（未装箱的 INT/FLOAT/BOOL/NONE 没有单元） */
static RtCell *cell_of(Value v)
{
    if (IS_STR(v) || IS_BIGINT(v))
        return ((RtCell *)AS_STR(v)) - 1;
    if (IS_LIST(v))
        return ((RtCell *)AS_LIST(v)) - 1;
    if (IS_OBJ(v))
        return ((RtCell *)AS_OBJ(v)) - 1;
    return NULL;
}

static void rt_retain(Value v);
static void rt_release(Value v);
static void cell_drop(RtCell *c);

/* 递归释放子对象：列表元素、对象属性值（BIGINT/字符串无子对象） */
static void cell_drop_children(RtCell *c)
{
    if (c->kind == RTK_LIST) {
        RtList *L = (RtList *)((void *)(c + 1));
        if (L->items)
            for (size_t i = 0; i < L->len; i++)
                rt_release(L->items[i]);
    } else if (c->kind == RTK_OBJ) {
        RtObject *o = (RtObject *)((void *)(c + 1));
        for (size_t i = 0; i < o->nprops; i++)
            rt_release(o->vals[i]);
    }
}

/* 真正释放一个单元：先放子对象，再摘链、释放载荷自带内存、最后释放自己 */
static void cell_drop(RtCell *c)
{
    if (!c)
        return;
    cell_drop_children(c);
    if (c->kind == RTK_LIST) {
        RtList *L = (RtList *)((void *)(c + 1));
        heap_raw_free(L->items, c);
        L->items = NULL;
    } else if (c->kind == RTK_OBJ) {
        RtObject *o = (RtObject *)((void *)(c + 1));
        for (size_t i = 0; i < o->nprops; i++)
            free(o->names[i]);          /* 属性名是普通 malloc，随宿主回收 */
        free(o->names);
        free(o->vals);
        o->names = NULL;
        o->vals = NULL;
    }
    cell_unlink(c);
    if (!c->owner)
        free(c);                        /* 块内单元随块回收，不单独 free */
}

static void rt_retain(Value v)
{
    RtCell *c = cell_of(v);
    if (c)
        c->rc++;
}

/* 引用计数减一；只有 @3 会在归零时立即释放（其余模式由 GC/竞技场/进程接管） */
static void rt_release(Value v)
{
    RtCell *c = cell_of(v);
    if (!c)
        return;
    if (c->rc > 0)
        c->rc--;
    if (c->rc == 0 && g_memmode == 3)
        cell_drop(c);
}

/* malloc 一份字符串拷贝（@normal 永不 free；@3 计数归零、@5/@6 GC 时回收） */
static char *dup_str(const char *s)
{
    size_t n = strlen(s) + 1;
    char *p = (char *)heap_alloc(RTK_STR, n);
    memcpy(p, s, n);
    return p;
}

/* 普通字符串拷贝：给"不是 Value"的辅助文本用（对象属性名等）。
 * 它不进堆链、不参与引用计数与 GC，由宿主单元持有，随宿主 free 掉。 */
static char *dup_str_plain(const char *s)
{
    size_t n = strlen(s) + 1;
    char *p = (char *)malloc(n);
    if (!p)
        rt_die("内存不足");
    memcpy(p, s, n);
    return p;
}

/* 数字包括 bool 与 BIGINT 堆盒（按数值参与） */
static int is_num(Value v)
{
    return IS_INT(v) || IS_BIGINT(v) || IS_FLT(v) || IS_BOOL(v);
}

/* 按整数值取出：INT 快路径 / BIGINT 堆盒解引用 / BOOL 0/1。
 * 调用点都先经过 is_num 检查，末尾的 rt_die 只是兜底。 */
static long long as_int(Value v)
{
    if (IS_INT(v))
        return AS_INT(v);
    if (IS_BIGINT(v))
        return *(long long *)AS_STR(v);
    if (IS_BOOL(v))
        return (long long)AS_BOOL(v);
    rt_die("需要整数");
    return 0;
}

/* 按浮点值取出 */
static double as_flt(Value v)
{
    if (IS_FLT(v))
        return AS_FLT(v);
    return (double)as_int(v);
}

/* UTF-8 按字符计数（续字节 10xxxxxx 不算新字符） */
static long long utf8_count(const char *s)
{
    long long n = 0;
    for (; *s; s++)
        if (((unsigned char)*s & 0xC0) != 0x80)
            n++;
    return n;
}

/* 从 s 起跳过 want 个字符，返回落点指针（越界停在串尾） */
static const char *utf8_at(const char *s, long long want)
{
    long long n = 0;
    while (*s) {
        if (((unsigned char)*s & 0xC0) != 0x80) {
            if (n == want)
                break;
            n++;
        }
        s++;
    }
    return s;
}

/* ================= 构造 ================= */

Value rt_int(long long x)
{
    if (x >= RT_INT_FAST_MIN && x <= RT_INT_FAST_MAX)
        return 0x7FF9000000000000ULL | ((uint64_t)x & 0xFFFFFFFFFFFFULL);
    /* 快路径装不下：malloc 一个 long long 堆盒，载荷位放数据指针，
     * 64 位全范围保真（LLONG_MAX/LLONG_MIN 字面量依赖这一点）。 */
    long long *block = (long long *)heap_alloc(RTK_BIGINT, sizeof(long long));
    *block = x;
    return 0x7FFB000000000000ULL | (uint64_t)(uintptr_t)block;
}

Value rt_float(double x)
{
    if (x != x) {   /* NaN：规范化到盒子区间之外（头 16 位 0x7FF0/0xFFF0），
                     * 否则原始位样会被 IS_FLT 误判成装箱值。保符号，丢载荷位。 */
        return signbit(x) ? 0xFFF0000000000001ULL : 0x7FF0000000000001ULL;
    }
    uint64_t bits;
    __builtin_memcpy(&bits, &x, sizeof bits);
    return bits;
}

Value rt_bool(int x)
{
    return MAKE_BOOL(x);
}

Value rt_str(const char *s)
{
    return MAKE_STR(dup_str(s ? s : ""));   /* 拷贝一份，永不回收 */
}

Value rt_none(void)
{
    return RT_NIL_BOX;
}

/* INT/BIGINT/BOOL 盒 → long long 的统一解码出口 */
long long rt_to_ll(Value v)
{
    if (IS_INT(v) || IS_BIGINT(v) || IS_BOOL(v))
        return as_int(v);
    rt_die("需要整数");
    return 0;
}

/* ================= 变量：赋值 / 检查 / 锁定 ================= */

void rt_assign(Value *dst, Value nv)
{
    if (slot_is_locked(dst))
        rt_die("变量已锁定");
    if (IS_DEL(*dst))
        rt_die("用已删除变量");
    if (g_memmode == 3) {
        rt_retain(nv);      /* 先保新的再放旧的：x = x 这种自赋值不会归零 */
        rt_release(*dst);
    }
    *dst = nv;   /* 8 字节盒子赋值；字符串只拷指针不拷内容 */
}

Value rt_chk(Value v)
{
    if (IS_DEL(v))
        rt_die("用已删除变量");
    return v;
}

void rt_gold(Value *dst)
{
    if (IS_DEL(*dst))
        rt_die("用已删除变量");
    slot_lock(dst);
}

/* ================= 内存管理模式（Memoryment） =================
 * 六档语义（数字由前端映射后传进来：@1→0 @2→1 @3→3 @4→4 @5→5 @6→6）：
 *   0 @normal  不回收：内存由进程退出统一归还（最快，适合短小程序）
 *   1 @self    完全手动：del 立即真释放，别名二次 del 不崩（后果自负）
 *   3 @3       引用计数：槽位/容器持有即 +1，覆盖与 del 即 -1，归零即回收。
 *              收不了循环引用（那是 @5 的活）
 *   4 @4       竞技场：bump 分配，单对象不释放，rt_arena_reset() 整块归还
 *   5 @5       标记清除：从根集（登记的变量槽）追踪可达对象，回收其余。
 *              能收循环引用；暂停时间随堆大小增长
 *   6 @6       分代 + 增量：新对象在新生代，存活下来的晋升老年代；
 *              minor GC 只扫新生代（老→新引用靠写屏障记入 Remember Set）；
 *              完整标记切成小片（rt_gc_step），把长暂停摊到每一帧
 */

void rt_set_memmode(int mode)
{
    if (mode != 0 && mode != 1 && mode != 3 && mode != 4 && mode != 5 && mode != 6)
        rt_die("内存管理模式不支持（%d）", mode);
    g_memmode = mode;
}

/* ── GC 根集 ──────────────────────────────────────────────────────────────
 * PYbook 的变量是生成代码里的 C 局部量（Value v_N），GC 没法自己枚举它们，
 * 所以由代码生成器在每个变量声明后调 rt_root_add(&v_N) 把槽地址登记进来；
 * 函数/GOING 块进出用 rt_scope_enter / rt_scope_leave 划分作用域（支持递归）。 */
static Value **g_roots = NULL;
static size_t  g_roots_n = 0, g_roots_cap = 0;
static size_t *g_scope = NULL;
static size_t  g_scope_n = 0, g_scope_cap = 0;

void rt_scope_enter(void)
{
    if (g_scope_n == g_scope_cap) {
        g_scope_cap = g_scope_cap ? g_scope_cap * 2 : 32;
        g_scope = (size_t *)realloc(g_scope, g_scope_cap * sizeof(size_t));
        if (!g_scope)
            rt_die("内存不足");
    }
    g_scope[g_scope_n++] = g_roots_n;
}

void rt_root_add(Value *slot)
{
    if (g_roots_n == g_roots_cap) {
        g_roots_cap = g_roots_cap ? g_roots_cap * 2 : 64;
        g_roots = (Value **)realloc(g_roots, g_roots_cap * sizeof(Value *));
        if (!g_roots)
            rt_die("内存不足");
    }
    g_roots[g_roots_n++] = slot;
}

void rt_scope_leave(void)
{
    if (g_scope_n)
        g_roots_n = g_scope[--g_scope_n];
}

/* ── 标记：用显式 gray 栈代替递归，既避免深结构爆栈，也天然支持分片 ── */
static RtCell **g_gray = NULL;
static size_t   g_gray_n = 0, g_gray_cap = 0;

static void gray_push(RtCell *c)
{
    if (!c || c->mark)
        return;
    c->mark = 1;
    if (g_gray_n == g_gray_cap) {
        g_gray_cap = g_gray_cap ? g_gray_cap * 2 : 128;
        g_gray = (RtCell **)realloc(g_gray, g_gray_cap * sizeof(RtCell *));
        if (!g_gray)
            rt_die("内存不足");
    }
    g_gray[g_gray_n++] = c;
}

/* 从 gray 栈里处理最多 budget 个单元；返回是否还有剩余 */
static int gray_step(size_t budget)
{
    while (g_gray_n && budget--) {
        RtCell *c = g_gray[--g_gray_n];
        if (c->kind == RTK_LIST) {
            RtList *L = (RtList *)((void *)(c + 1));
            for (size_t i = 0; i < L->len; i++)
                gray_push(cell_of(L->items[i]));
        } else if (c->kind == RTK_OBJ) {
            RtObject *o = (RtObject *)((void *)(c + 1));
            for (size_t i = 0; i < o->nprops; i++)
                gray_push(cell_of(o->vals[i]));
        }
    }
    return g_gray_n > 0;
}

static void mark_roots(void)
{
    for (size_t i = 0; i < g_roots_n; i++)
        if (g_roots[i])
            gray_push(cell_of(*g_roots[i]));
}

/* ── @6 写屏障：老年代容器写入新生代值时，把容器记入 Remember Set ── */
static RtCell **g_remset = NULL;
static size_t   g_remset_n = 0, g_remset_cap = 0;

static void remember(RtCell *container, Value val)
{
    if (g_memmode != 6 || !container || container->gen != 1)
        return;
    RtCell *vc = cell_of(val);
    if (!vc || vc->gen != 0)
        return;                       /* 只有 old→young 才需要记 */
    for (size_t i = 0; i < g_remset_n; i++)
        if (g_remset[i] == container)
            return;                   /* 已记录 */
    if (g_remset_n == g_remset_cap) {
        g_remset_cap = g_remset_cap ? g_remset_cap * 2 : 64;
        g_remset = (RtCell **)realloc(g_remset, g_remset_cap * sizeof(RtCell *));
        if (!g_remset)
            rt_die("内存不足");
    }
    g_remset[g_remset_n++] = container;
}

/* ── 清除：摘链并回收未标记单元（only_young=1 时只清新生代） ── */
static size_t sweep(int only_young)
{
    size_t freed = 0;
    RtCell *c = g_all;
    while (c) {
        RtCell *nx = c->next;
        if (!c->mark && (!only_young || c->gen == 0)) {
            if (c->owner) {           /* 块内单元：只摘链，内存随块回收 */
                cell_unlink(c);
            } else {
                cell_drop(c);         /* cell_drop 内部会摘链 */
            }
            freed++;
        } else {
            c->mark = 0;
            if (only_young && c->gen == 0)
                c->gen = 1;           /* 新生代存活者晋升老年代 */
        }
        c = nx;
    }
    return freed;
}

/* @6 的增量完整标记：分阶段推进，标记做完后一次性清除 */
static int  g_major_phase = 0;        /* 0=空闲 1=标记中 2=待清除 */
static size_t g_gc_threshold = 1024 * 1024;      /* @5 触发阈值 */
static size_t g_nursery_threshold = 256 * 1024;  /* @6 minor 触发阈值 */

/* 推进一小片 GC 工作（@6 增量）；返回本片是否做了事 */
int rt_gc_step(void)
{
    if (g_memmode != 6)
        return 0;
    if (g_major_phase == 1) {
        if (gray_step(256))
            return 1;
        g_major_phase = 2;
        return 1;
    }
    if (g_major_phase == 2) {
        sweep(0);
        for (size_t i = 0; i < g_remset_n; i++)
            g_remset[i] = NULL;
        g_remset_n = 0;
        g_major_phase = 0;
        g_nursery_threshold = (g_bytes > 256 * 1024 ? g_bytes : 256 * 1024) * 2;
        return 1;
    }
    return 0;
}

/* minor GC（@6）：只清新生代，根集 + Remember Set 作为根 */
static void gc_minor(void)
{
    mark_roots();
    for (size_t i = 0; i < g_remset_n; i++)
        if (g_remset[i])
            gray_push(g_remset[i]);
    while (gray_step(1000))
        ;
    sweep(1);
    /* 清掉已失效的 Remember Set 项（对应容器已被回收） */
    size_t k = 0;
    for (size_t i = 0; i < g_remset_n; i++)
        if (g_remset[i] && g_remset[i]->gen == 1)
            g_remset[k++] = g_remset[i];
    g_remset_n = k;
}

/* 手动触发一次完整回收（@5/@6 有效；其余模式是空操作） */
void rt_gc(void)
{
    if (g_memmode == 5) {
        mark_roots();
        while (gray_step(1000))
            ;
        sweep(0);
        g_gc_threshold = (g_bytes > 1024 * 1024 ? g_bytes : 1024 * 1024) * 2;
    } else if (g_memmode == 6) {
        if (g_major_phase == 0) {
            mark_roots();
            g_major_phase = 1;
        }
        while (rt_gc_step())
            ;
    }
}

/* @4：整块归还竞技场（块内所有单元一起死） */
void rt_arena_reset(void)
{
    for (RtArena *a = g_arena; a; ) {
        RtArena *nx = a->next;
        /* 先摘掉属于这块的所有单元，再放块内存 */
        RtCell *c = g_all;
        while (c) {
            RtCell *nx2 = c->next;
            if (c->owner == a)
                cell_unlink(c);
            c = nx2;
        }
        free(a->mem);
        free(a);
        a = nx;
    }
    g_arena = NULL;
    g_bytes = 0;
    for (RtCell *c = g_all; c; c = c->next)
        g_bytes += 64;   /* 非块内单元的粗略估算（重置后通常只剩它们） */
}

/* 内存统计：返回存活单元数；bytes/live 供调试输出 */
size_t rt_mem_stats(size_t *bytes)
{
    if (bytes)
        *bytes = g_bytes;
    return g_live;
}

/* 语句边界的 GC 轮询：由生成代码在每条语句之后调用。
 * 之所以不放在 heap_alloc 里：求值 a+b 时会先分配出临时对象，而临时值
 * 没有登记为 GC 根，若在分配途中就回收，等于把正在用的对象收走（悬挂指针）。
 * 只在语句边界回收，就能保证"一次求值期间绝不回收"。 */
void rt_gc_poll(void)
{
    if (g_memmode == 5) {
        if (g_bytes > g_gc_threshold)
            rt_gc();
    } else if (g_memmode == 6) {
        if (g_major_phase != 0) {
            rt_gc_step();
            return;
        }
        if (g_bytes > g_nursery_threshold)
            gc_minor();
    }
}

/* delete 的实际执行体：
 * @self：先登记再真正释放（共享同一内存的其他别名会悬空，访问后果自负；
 *        但同一指针的二次 free 由登记表拦下，别名 delete 不崩溃）
 * @3：   引用计数减一（归零即回收）
 * @4：   随竞技场整体回收（这里只打删除标志）
 * @5/@6：交给 GC（这里只打删除标志）
 * @normal：只打删除标志，内存由进程退出统一回收
 * 幂等性：对同一变量第二次 delete 在开头的 IS_DEL 检查处报 "用已删除变量"。 */
void rt_destroy(Value *v)
{
    if (IS_DEL(*v))
        rt_die("用已删除变量");
    RtCell *c = cell_of(*v);
    if (c) {
        void *payload = (void *)(c + 1);
        if (g_memmode == 1 && !ptr_registered(payload)) {
            register_freed(payload);
            cell_drop(c);           /* 真释放：含列表 items 与对象属性名 */
        } else if (g_memmode == 3) {
            rt_release(*v);         /* 计数减一，归零即回收 */
        }
    }
    *v = RT_DELETED_BOX;
}

/* ================= 算术 ================= */

/* rt_add / rt_sub / rt_mul 的公共实现 */
static Value arith(Value a, Value b, char op)
{
    if (IS_STR(a) && IS_STR(b)) {
        if (op != '+')
            rt_die(op == '-' ? "类型不可相减" : "类型不可相乘");
        size_t la = strlen(AS_STR(a)), lb = strlen(AS_STR(b));
        char *r = (char *)heap_alloc(RTK_STR, la + lb + 1);
        memcpy(r, AS_STR(a), la);
        memcpy(r + la, AS_STR(b), lb);
        r[la + lb] = '\0';
        return MAKE_STR(r);
    }
    if (is_num(a) && is_num(b)) {
        if (IS_FLT(a) || IS_FLT(b)) {
            double x = as_flt(a), y = as_flt(b);
            return rt_float(op == '+' ? x + y : op == '-' ? x - y : x * y);
        }
        long long x = as_int(a), y = as_int(b), r = 0;
        int ov = op == '+' ? __builtin_add_overflow(x, y, &r)
               : op == '-' ? __builtin_sub_overflow(x, y, &r)
               :             __builtin_mul_overflow(x, y, &r);
        if (ov)
            rt_die("溢出");
        return rt_int(r);   /* 结果落在快路径外自动转 BIGINT */
    }
    rt_die(op == '+' ? "类型不可相加" : op == '-' ? "类型不可相减" : "类型不可相乘");
    return rt_none();   /* 不可达 */
}

Value rt_add(Value a, Value b) { return arith(a, b, '+'); }
Value rt_sub(Value a, Value b) { return arith(a, b, '-'); }
Value rt_mul(Value a, Value b) { return arith(a, b, '*'); }

Value rt_div(Value a, Value b)
{
    if (!is_num(a) || !is_num(b))
        rt_die("类型不可相除");
    if (IS_FLT(b) ? AS_FLT(b) == 0.0 : as_int(b) == 0)
        rt_die("除以零");
    return rt_float(as_flt(a) / as_flt(b));   /* 真除法，结果一律 float */
}

Value rt_fdiv(Value a, Value b)
{
    if (!is_num(a) || !is_num(b))
        rt_die("类型不可整除");
    if (!IS_FLT(a) && !IS_FLT(b)) {
        long long x = as_int(a), y = as_int(b);
        if (y == 0)
            rt_die("除以零");
        if (x == LLONG_MIN && y == -1)
            rt_die("溢出");   /* 商 2^63 超出 long long */
        long long q = x / y;  /* C 的 / 向零取整，下面修成向下取整 */
        if (x % y != 0 && ((x < 0) != (y < 0)))
            q--;
        return rt_int(q);
    }
    double y = as_flt(b);
    if (y == 0.0)
        rt_die("除以零");
    return rt_float(floor(as_flt(a) / y));
}

Value rt_mod(Value a, Value b)
{
    if (!is_num(a) || !is_num(b))
        rt_die("类型不可取模");
    if (!IS_FLT(a) && !IS_FLT(b)) {
        long long x = as_int(a), y = as_int(b);
        if (y == 0)
            rt_die("除以零");
        if (y == -1)
            return rt_int(0);   /* LLONG_MIN % -1 在 C 里未定义；数学上余数恒为 0 */
        long long r = x % y;    /* C 的 % 符号跟被除数，下面修成跟除数 */
        if (r != 0 && ((r < 0) != (y < 0)))
            r += y;
        return rt_int(r);
    }
    double x = as_flt(a), y = as_flt(b);
    if (y == 0.0)
        rt_die("除以零");
    double r = fmod(x, y);
    if (r != 0.0 && ((r < 0.0) != (y < 0.0)))
        r += y;
    return rt_float(r);
}

Value rt_neg(Value a)
{
    if (IS_FLT(a))
        return rt_float(-AS_FLT(a));
    if (IS_INT(a) || IS_BIGINT(a) || IS_BOOL(a)) {
        long long r;
        if (__builtin_sub_overflow((long long)0, as_int(a), &r))
            rt_die("溢出");   /* -LLONG_MIN 溢出 */
        return rt_int(r);
    }
    rt_die("负号只能用于数字");
    return rt_none();   /* 不可达 */
}

/* ================= 真值与逻辑 ================= */

int rt_cond(Value v)
{
    if (IS_DEL(v))  return 0;   /* 删除占位按假（正常流在 rt_chk 就被拦下了） */
    if (IS_NONE(v)) return 0;
    if (IS_INT(v) || IS_BIGINT(v)) return as_int(v) != 0;
    if (IS_FLT(v))  return AS_FLT(v) != 0.0;
    if (IS_BOOL(v)) return AS_BOOL(v) != 0;
    if (IS_STR(v)) {
        const char *s = AS_STR(v);
        return s != NULL && s[0] != '\0';
    }
    if (IS_LIST(v)) return AS_LIST(v) != NULL && AS_LIST(v)->len > 0;
    if (IS_OBJ(v))  return 1;   /* 对象存在即为真（恒真） */
    return 0;
}

Value rt_not(Value a) { return rt_bool(!rt_cond(a)); }

/* ================= 比较 ================= */

/* 深度相等比较（== / != / list.unique / list.find 共用）。
 * Python 语义永不报错：不同类型就是不相等；列表递归；对象比指针身份。 */
static int values_equal(Value a, Value b)
{
    if (IS_OBJ(a) || IS_OBJ(b)) {
        if (!IS_OBJ(a) || !IS_OBJ(b))
            return 0;   /* 对象与其他类型：判不等 */
        return AS_OBJ(a) == AS_OBJ(b);   /* 指针身份：同一对象才相等 */
    }
    if (IS_LIST(a) || IS_LIST(b)) {
        if (!IS_LIST(a) || !IS_LIST(b))
            return 0;
        RtList *A = AS_LIST(a), *B = AS_LIST(b);
        if (A == B)
            return 1;
        if (!A || !B)
            return A == B;
        if (A->len != B->len)
            return 0;
        for (size_t i = 0; i < A->len; i++)
            if (!values_equal(A->items[i], B->items[i]))
                return 0;
        return 1;
    }
    if (IS_NONE(a) && IS_NONE(b))
        return 1;
    if (is_num(a) && is_num(b)) {
        if (IS_FLT(a) || IS_FLT(b))
            return as_flt(a) == as_flt(b);
        return as_int(a) == as_int(b);
    }
    if (IS_STR(a) && IS_STR(b))
        return strcmp(AS_STR(a) ? AS_STR(a) : "", AS_STR(b) ? AS_STR(b) : "") == 0;
    return 0;
}

/* 三态比较（< > <= >= 与 list 排序/max/min 共用）：-1 / 0 / 1；
 * 不可比较（混类型）直接报错退出——== 宽容、< 严格，两者刻意不同。 */
static int compare_values(Value a, Value b)
{
    if (IS_OBJ(a) || IS_OBJ(b)) {
        if (!IS_OBJ(a) || !IS_OBJ(b))
            rt_die("类型不可比较");   /* 对象与数字/字符串之间无排序 */
        return (AS_OBJ(a) > AS_OBJ(b)) - (AS_OBJ(a) < AS_OBJ(b));   /* 指针身份 */
    }
    if (is_num(a) && is_num(b)) {
        if (IS_FLT(a) || IS_FLT(b)) {
            double x = as_flt(a), y = as_flt(b);
            return (x > y) - (x < y);
        }
        long long x = as_int(a), y = as_int(b);
        return (x > y) - (x < y);
    }
    if (IS_STR(a) && IS_STR(b)) {
        int c = strcmp(AS_STR(a) ? AS_STR(a) : "", AS_STR(b) ? AS_STR(b) : "");
        return (c > 0) - (c < 0);
    }
    if (IS_NONE(a) && IS_NONE(b))
        return 0;
    rt_die("类型不可比较");
    return 0;   /* 不可达 */
}

Value rt_eq(Value a, Value b) { return rt_bool(values_equal(a, b)); }
Value rt_ne(Value a, Value b) { return rt_bool(!values_equal(a, b)); }
Value rt_lt(Value a, Value b) { return rt_bool(compare_values(a, b) <  0); }
Value rt_gt(Value a, Value b) { return rt_bool(compare_values(a, b) >  0); }
Value rt_le(Value a, Value b) { return rt_bool(compare_values(a, b) <= 0); }
Value rt_ge(Value a, Value b) { return rt_bool(compare_values(a, b) >= 0); }

/* ================= 显示（rt_str_of） ================= */

char *rt_str_of(Value v)
{
    char buf[64];
    if (IS_INT(v) || IS_BIGINT(v)) {
        snprintf(buf, sizeof buf, "%lld", as_int(v));
        return dup_str(buf);
    }
    if (IS_FLT(v)) {
        snprintf(buf, sizeof buf, "%.15g", AS_FLT(v));   /* %g 自动去掉多余尾零 */
        return dup_str(buf);
    }
    if (IS_BOOL(v))
        return dup_str(AS_BOOL(v) ? "true" : "false");
    if (IS_OBJ(v)) {
        RtObject *o = AS_OBJ(v);
        const char *cn = (o && o->cls) ? o->cls : "";
        size_t n = strlen(cn) + 16;
        char *out = (char *)malloc(n);
        if (!out)
            rt_die("内存不足");
        snprintf(out, n, "[%s 对象]", cn);
        return out;   /* 如 "[狗 对象]" */
    }
    if (IS_STR(v))
        return AS_STR(v) ? AS_STR(v) : (char *)"";   /* 原样：直接返回内部指针 */
    if (IS_LIST(v)) {
        RtList *L = AS_LIST(v);
        size_t cap = 64 + (L ? L->len * 24 : 0);
        size_t used = 0;
        char *out = (char *)malloc(cap);
        if (!out)
            rt_die("内存不足");
        out[used++] = '[';
        if (L) {
            for (size_t i = 0; i < L->len; i++) {
                const char *piece = rt_str_of(L->items[i]);
                size_t need = strlen(piece) + 3;
                if (used + need >= cap) {
                    cap = cap * 2 + need;
                    out = (char *)realloc(out, cap);
                    if (!out)
                        rt_die("内存不足");
                }
                if (i) {
                    out[used++] = ',';
                    out[used++] = ' ';
                }
                size_t pl = strlen(piece);
                memcpy(out + used, piece, pl);
                used += pl;
            }
        }
        if (used + 2 >= cap) {
            cap = used + 2;
            out = (char *)realloc(out, cap);
            if (!out)
                rt_die("内存不足");
        }
        out[used++] = ']';
        out[used] = '\0';
        return out;
    }
    return dup_str("空");   /* 空盒 / 删除占位等 */
}

/* ================= 容器（列表核心） ================= */

/* 取列表结构；删除状态/类型不符直接报错 */
static RtList *as_list(Value v, const char *ctx)
{
    if (IS_DEL(v))
        rt_die("用已删除变量");
    if (!IS_LIST(v) || AS_LIST(v) == NULL)
        rt_die("%s：目标不是列表", ctx);
    return AS_LIST(v);
}

/* 下标归一化：只收 INT/BOOL；负数从尾数；越界报错 */
static size_t norm_index(size_t len, Value idx, const char *ctx)
{
    if (!IS_INT(idx) && !IS_BOOL(idx))
        rt_die("%s：下标必须是整数", ctx);
    long long i = as_int(idx);
    if (i < 0)
        i += (long long)len;
    if (i < 0 || (size_t)i >= len)
        rt_die("%s：下标越界", ctx);
    return (size_t)i;
}

Value rt_list_new(void)
{
    RtList *L = (RtList *)heap_alloc(RTK_LIST, sizeof(RtList));
    L->len = 0;
    L->cap = 4;
    L->items = (Value *)heap_raw(L->cap * sizeof(Value));
    return MAKE_LIST(L);
}

Value rt_push(Value *dst, Value v)
{
    if (slot_is_locked(dst))
        rt_die("变量已锁定");
    if (IS_DEL(*dst))
        rt_die("用已删除变量");
    if (!IS_LIST(*dst) || AS_LIST(*dst) == NULL)
        rt_die("添加：目标不是列表");
    RtList *L = AS_LIST(*dst);
    if (L->len == L->cap) {
        size_t oldn = L->cap * sizeof(Value);
        L->cap *= 2;
        L->items = (Value *)heap_raw_grow(L->items, cell_of(*dst), oldn,
                                          L->cap * sizeof(Value));
    }
    L->items[L->len++] = v;
    if (g_memmode == 3)
        rt_retain(v);          /* 列表持有元素引用 */
    if (g_memmode == 6)
        remember(cell_of(*dst), v);   /* old→young 写屏障 */
    return rt_none();
}

long long rt_list_len_ll(Value lst)
{
    if (!IS_LIST(lst) || AS_LIST(lst) == NULL)
        rt_die("这里需要一个列表");
    return (long long)AS_LIST(lst)->len;
}

Value rt_list_remove(Value lst, Value item)
{
    if (IS_DEL(lst))
        rt_die("用已删除变量");
    if (!IS_LIST(lst) || AS_LIST(lst) == NULL)
        rt_die("删掉：目标不是列表");
    RtList *L = AS_LIST(lst);
    for (size_t i = 0; i < L->len; i++) {
        if (rt_cond(rt_eq(L->items[i], item))) {
            if (g_memmode == 3)
                rt_release(L->items[i]);   /* 与 rt_push 的 retain 对称 */
            if (i < L->len - 1)
                memmove(L->items + i, L->items + i + 1,
                        (L->len - i - 1) * sizeof(Value));
            L->len--;
            return rt_int(1);
        }
    }
    return rt_int(0);
}

Value rt_index(Value lst, Value idx)
{
    if (IS_DEL(lst))
        rt_die("用已删除变量");
    if (IS_STR(lst)) {                        /* 字符串下标：按 UTF-8 字符取 */
        const char *s = AS_STR(lst) ? AS_STR(lst) : "";
        long long n = utf8_count(s);
        long long i = norm_index((size_t)n, idx, "下标");
        s = utf8_at(s, i);
        size_t len = 1;
        while (s[len] && ((unsigned char)s[len] & 0xC0) == 0x80)
            len++;
        char one[8];
        memcpy(one, s, len);
        one[len] = '\0';
        return rt_str(one);
    }
    RtList *L = as_list(lst, "下标");
    size_t k = norm_index(L->len, idx, "下标");
    return L->items[k];
}

void rt_setindex(Value *lst, Value idx, Value v)
{
    if (IS_DEL(*lst))
        rt_die("用已删除变量");
    if (slot_is_locked(lst))
        rt_die("变量已锁定");
    if (!IS_LIST(*lst) || AS_LIST(*lst) == NULL)
        rt_die("下标赋值：目标不是列表");
    RtList *L = AS_LIST(*lst);
    size_t k = norm_index(L->len, idx, "下标赋值");
    if (g_memmode == 3) {
        rt_retain(v);            /* 先保新后放旧 */
        rt_release(L->items[k]);
    }
    L->items[k] = v;
    if (g_memmode == 6)
        remember(cell_of(*lst), v);
}

Value rt_len(Value v)
{
    if (IS_LIST(v))
        return rt_int((long long)(AS_LIST(v) ? AS_LIST(v)->len : 0));
    if (IS_STR(v))
        return rt_int(utf8_count(AS_STR(v) ? AS_STR(v) : ""));
    rt_die("长度 只能用于列表或字符串");
    return rt_none();   /* 不可达 */
}

/* ================= 列表扩展（sort/reverse/unique/merge/find/max/min） ================= */

/* qsort 比较器：数字按值、字符串按字典序、对象按指针；混类型在 compare_values 里报错退出 */
static int list_cmp_qsort(const void *pa, const void *pb)
{
    return compare_values(*(const Value *)pa, *(const Value *)pb);
}

Value rt_list_sort(Value lst)
{
    RtList *L = as_list(lst, "排序");
    qsort(L->items, L->len, sizeof(Value), list_cmp_qsort);
    return lst;   /* 原地排序，返回原列表 */
}

Value rt_list_reverse(Value lst)
{
    RtList *L = as_list(lst, "倒序");
    if (L->len > 1) {
        size_t i = 0, j = L->len - 1;
        while (i < j) {
            Value t = L->items[i];
            L->items[i] = L->items[j];
            L->items[j] = t;
            i++;
            j--;
        }
    }
    return lst;   /* 原地倒序，返回原列表 */
}

Value rt_list_unique(Value lst)
{
    RtList *L = as_list(lst, "去重");
    Value out = rt_list_new();
    for (size_t i = 0; i < L->len; i++) {
        int seen = 0;
        for (size_t j = 0; j < AS_LIST(out)->len; j++) {
            if (values_equal(L->items[i], AS_LIST(out)->items[j])) {
                seen = 1;   /* 重复：保留首次出现的，跳过 */
                break;
            }
        }
        if (!seen)
            rt_push(&out, L->items[i]);
    }
    return out;
}

Value rt_list_merge(Value a, Value b)
{
    RtList *A = as_list(a, "合并");
    RtList *B = as_list(b, "合并");
    Value out = rt_list_new();
    for (size_t i = 0; i < A->len; i++)
        rt_push(&out, A->items[i]);
    for (size_t i = 0; i < B->len; i++)
        rt_push(&out, B->items[i]);
    return out;
}

Value rt_list_find(Value lst, Value val)
{
    RtList *L = as_list(lst, "查找");
    for (size_t i = 0; i < L->len; i++)
        if (values_equal(L->items[i], val))
            return rt_int((long long)i);
    return rt_int(-1);   /* 找不到 */
}

Value rt_list_max(Value lst)
{
    RtList *L = as_list(lst, "max");
    if (L->len == 0)
        rt_die("列表为空");
    Value best = L->items[0];
    for (size_t i = 1; i < L->len; i++)
        if (compare_values(L->items[i], best) > 0)
            best = L->items[i];
    return best;
}

Value rt_list_min(Value lst)
{
    RtList *L = as_list(lst, "min");
    if (L->len == 0)
        rt_die("列表为空");
    Value best = L->items[0];
    for (size_t i = 1; i < L->len; i++)
        if (compare_values(L->items[i], best) < 0)
            best = L->items[i];
    return best;
}

/* ================= 对象（属性袋） ================= */

/* 取属性袋；删除状态/类型不符直接报错 */
static RtObject *as_object(Value v, const char *ctx)
{
    if (IS_DEL(v))
        rt_die("用已删除变量");
    if (!IS_OBJ(v) || AS_OBJ(v) == NULL) {
        fprintf(stderr, "[X] %s value=0x%016llx\n", ctx, (unsigned long long)v);
        rt_die("%s：目标不是对象", ctx);
    }
    return AS_OBJ(v);
}

Value rt_obj_new(const char *cls)
{
    RtObject *o = (RtObject *)heap_alloc(RTK_OBJ, sizeof(RtObject));
    o->cls = (char *)(cls ? cls : "");   /* 指向常量，永不回收 */
    o->nprops = 0;
    o->names = NULL;
    o->vals = NULL;
    return MAKE_OBJ(o);
}

void rt_obj_set_prop(Value obj, const char *name, Value v)
{
    RtObject *o = as_object(obj, "属性赋值");
    const char *key = name ? name : "";
    RtCell *oc = cell_of(obj);          /* 写屏障用：整个函数都要使 */
    for (size_t i = 0; i < o->nprops; i++) {
        if (strcmp(o->names[i], key) == 0) {
            if (g_memmode == 3) {
                rt_retain(v);            /* 先保新的，再放旧的（自赋值也安全） */
                rt_release(o->vals[i]);
            }
            o->vals[i] = v;              /* 已有则覆盖 */
            if (g_memmode == 6)
                remember(oc ? oc : cell_of(obj), v);
            return;
        }
    }
    /* 没有则追加（教学规模 +1 扩容足够） */
    o->names = (char **)heap_raw_grow(o->names, oc,
                                      o->nprops * sizeof(char *),
                                      (o->nprops + 1) * sizeof(char *));
    o->vals = (Value *)heap_raw_grow(o->vals, oc,
                                     o->nprops * sizeof(Value),
                                     (o->nprops + 1) * sizeof(Value));
    o->names[o->nprops] = dup_str_plain(key);   /* 属性名是辅助文本，非 Value */
    o->vals[o->nprops] = v;
    if (g_memmode == 3)
        rt_retain(v);
    o->nprops++;
}

Value rt_obj_get_prop(Value obj, const char *name)
{
    RtObject *o = as_object(obj, "属性读取");
    const char *key = name ? name : "";
    for (size_t i = 0; i < o->nprops; i++)
        if (strcmp(o->names[i], key) == 0)
            return o->vals[i];
    rt_die("属性 '%s' 不存在", key);
    return rt_none();   /* 不可达 */
}

/* 碰到(a, b)：两个对象的 AABB 碰撞。x/y 是中心，需要 x/y/宽/高 属性。 */
static double touch_num(Value v, const char *who)
{
    if (IS_INT(v) || IS_BIGINT(v))
        return (double)as_int(v);
    if (IS_BOOL(v))
        return (double)AS_BOOL(v);
    if (IS_FLT(v))
        return AS_FLT(v);
    rt_die("碰到：%s 需要是数字", who);
    return 0;
}

Value rt_touch(Value a, Value b)
{
    double ax = touch_num(rt_obj_get_prop(a, "x"), "x");
    double ay = touch_num(rt_obj_get_prop(a, "y"), "y");
    double aw = touch_num(rt_obj_get_prop(a, "宽"), "宽");
    double ah = touch_num(rt_obj_get_prop(a, "高"), "高");
    double bx = touch_num(rt_obj_get_prop(b, "x"), "x");
    double by = touch_num(rt_obj_get_prop(b, "y"), "y");
    double bw = touch_num(rt_obj_get_prop(b, "宽"), "宽");
    double bh = touch_num(rt_obj_get_prop(b, "高"), "高");
    double dx = ax - bx;
    double dy = ay - by;
    if (dx < 0)
        dx = -dx;
    if (dy < 0)
        dy = -dy;
    return rt_bool(dx * 2 < aw + bw && dy * 2 < ah + bh);
}

const char *rt_obj_class_name(Value obj)
{
    RtObject *o = as_object(obj, "类名");
    return o->cls ? o->cls : "";
}

/* ================= 样式 token（rt_magic 与网页段落样式共用） ================= */

/* 取下一个逗号分隔的样式项：返回起点，*len 为长度，*p 停在分隔符/串尾
 * （c=R,G/B=bk=R,G,B 的后两个分量由 read_channel 继续吃，所以不能提前跳逗号） */
static const char *style_token(const char **p, size_t *len)
{
    const char *start = *p;
    const char *q = start;
    while (*q && *q != ',')
        q++;
    *len = (size_t)(q - start);
    *p = q;
    return start;
}

/* 解析一个 0..255 的颜色分量，失败按"不支持的样式"报错 */
static int parse_channel(const char *start, const char *end)
{
    char tmp[16];
    size_t len = (size_t)(end - start);
    if (len == 0 || len >= sizeof tmp)
        rt_die("不支持的样式（颜色分量缺失或过长）");
    memcpy(tmp, start, len);
    tmp[len] = '\0';
    char *stop;
    long v = strtol(tmp, &stop, 10);
    if (stop != tmp + len || v < 0 || v > 255)
        rt_die("不支持的样式 %s", tmp);
    return (int)v;
}

/* 紧跟着读取 ",G" / ",B" 颜色项中的一个 */
static int read_channel(const char **pp, const char *ctx)
{
    const char *p = *pp;
    if (*p != ',')
        rt_die("不支持的样式 %s", ctx);   /* 缺少后续颜色分量 */
    p++;
    const char *start = p;
    while (*p && *p != ',')
        p++;
    *pp = p;
    return parse_channel(start, p);
}

/* 把当前项拷进报错用的小缓冲（过长截断） */
static void token_text(char *tok, size_t cap, const char *start, size_t len)
{
    size_t n = len < cap - 1 ? len : cap - 1;
    memcpy(tok, start, n);
    tok[n] = '\0';
}

/* 解析 "fs.数字" 的字号：纯数字 1..999，否则报错（网页端要用，不能放坏值进去） */
static int parse_font_size(const char *start, size_t len, const char *ctx)
{
    if (len == 0 || len > 3)
        rt_die("不支持的样式 %s", ctx);
    int v = 0;
    for (size_t i = 0; i < len; i++) {
        if (start[i] < '0' || start[i] > '9')
            rt_die("不支持的样式 %s", ctx);
        v = v * 10 + (start[i] - '0');
    }
    if (v == 0)
        rt_die("不支持的样式 %s", ctx);
    return v;
}

/* ================= 终端显示（show 的运行时） ================= */

/* 显示行缓冲（支持 l/fl、m/fm、r/fr 对齐）：show 系列先把片段拼进来，show_end 一次输出 */
static char g_line[65536];
static size_t g_len = 0;
static int g_align = 0;        /* 0=左(l/fl) 1=居中(m/fm) 2=右(r/fr) */
static int g_magic_used = 0;   /* 本行是否用过 magic（show_end 决定要不要发 \033[0m） */

static void line_append(const char *s)
{
    size_t n = strlen(s ? s : "");
    if (g_len + n >= sizeof g_line)
        rt_die("一行太长");
    memcpy(g_line + g_len, s, n + 1);
    g_len += n;
}

void rt_magic(const char *csv)
{
    const char *p = csv ? csv : "";
    g_magic_used = 1;   /* 空样式串也算用过 magic：show_end 照发重置序列 */
    for (;;) {
        size_t len;
        const char *start = style_token(&p, &len);

        char tok[64];
        token_text(tok, sizeof tok, start, len);

        if (len == 0) {
            /* 连续逗号/结尾逗号产生的空项：跳过 */
        }
        else if (len == 1 && start[0] == 'b')      line_append("\033[1m");  /* 加粗 */
        else if (len == 1 && start[0] == 'i')      line_append("\033[3m");  /* 斜体 */
        else if (len == 1 && start[0] == 'u')      line_append("\033[4m");  /* 下划线 */
        else if (len == 1 && start[0] == 'd')      line_append("\033[9m");  /* 删除线 */
        else if (len >= 2 && start[0] == 'c' && start[1] == '=') {
            int r = parse_channel(start + 2, p);
            int g = read_channel(&p, tok);
            int b = read_channel(&p, tok);
            char esc[32];
            snprintf(esc, sizeof esc, "\033[38;2;%d;%d;%dm", r, g, b);
            line_append(esc);                                          /* 前景色 */
        }
        else if (len >= 3 && start[0] == 'b' && start[1] == 'k' && start[2] == '=') {
            int r = parse_channel(start + 3, p);
            int g = read_channel(&p, tok);
            int b = read_channel(&p, tok);
            char esc[32];
            snprintf(esc, sizeof esc, "\033[48;2;%d;%d;%dm", r, g, b);
            line_append(esc);                                          /* 背景色 */
        }
        else if (len >= 2 && start[0] == 'f' && start[1] == '.') {
            if (len == 2)
                rt_die("不支持的样式 %s", tok);   /* f. 后面必须有字体名 */
            /* 字体名：终端改不了字体，接受并忽略（网页端生效） */
        }
        else if (len >= 3 && start[0] == 'f' && start[1] == 's' && start[2] == '.') {
            parse_font_size(start + 3, len - 3, tok);   /* 字号：同上，只校验 */
        }
        else if (len == 1 && start[0] == 'l') g_align = 0;             /* 左对齐 */
        else if (len == 2 && start[0] == 'f' && start[1] == 'l') g_align = 0;
        else if (len == 1 && start[0] == 'm') g_align = 1;             /* 居中 */
        else if (len == 2 && start[0] == 'f' && start[1] == 'm') g_align = 1;
        else if (len == 1 && start[0] == 'r') g_align = 2;             /* 右对齐 */
        else if (len == 2 && start[0] == 'f' && start[1] == 'r') g_align = 2;
        else
            rt_die("不支持的样式 %s", tok);

        if (*p == '\0')
            break;
        p++;   /* 跳过逗号，读下一项 */
    }
}

void rt_show_text(const char *s) { line_append(s ? s : ""); }

Value rt_show_value(Value v)
{
    line_append(rt_str_of(v));
    return v;
}

void rt_show_end(void)
{
    /* 可见长度：跳过 ANSI 转义序列 \033[...m（中文按字节近似） */
    size_t vis = 0;
    for (size_t i = 0; i < g_len;) {
        if (g_line[i] == '\033') {
            i++;
            if (i < g_len && g_line[i] == '[') {
                i++;
                while (i < g_len && g_line[i] != 'm')
                    i++;
                if (i < g_len)
                    i++;
            }
        } else {
            vis++;
            i++;
        }
    }
    const char *cols = getenv("COLUMNS");
    int width = cols ? atoi(cols) : 80;
    if (width < 10)
        width = 10;
    if (width > 200)
        width = 200;
    int pad = 0;
    if (g_align == 1)
        pad = (width - (int)vis) / 2;
    else if (g_align == 2)
        pad = width - (int)vis;
    if (pad < 0)
        pad = 0;
    for (int i = 0; i < pad; i++)
        fputc(' ', stdout);
    fwrite(g_line, 1, g_len, stdout);
    if (g_magic_used)
        fputs("\033[0m", stdout);   /* 只在本行用过 magic 时发重置序列 */
    fputc('\n', stdout);
    g_magic_used = 0;
    g_len = 0;
    g_align = 0;
}

Value rt_input(const char *prompt)
{
    if (prompt && *prompt) {
        fputs(prompt, stdout);
        fflush(stdout);
    }
    /* 读一整行（按块拼接；缓冲同样不回收，脚本结束由进程回收） */
    size_t cap = 128, len = 0;
    char *line = (char *)malloc(cap);
    if (!line)
        rt_die("内存不足");
    for (;;) {
        int c = getchar();
        if (c == EOF || c == '\n')
            break;
        if (len + 2 > cap) {
            cap *= 2;
            line = (char *)realloc(line, cap);
            if (!line)
                rt_die("内存不足");
        }
        line[len++] = (char)c;
    }
    line[len] = '\0';
    if (len > 0 && line[len - 1] == '\r')
        line[--len] = '\0';   /* 兼容 CRLF */

    /* 先按整数、再按浮点解析（忽略首尾空白，必须整行都是数字） */
    const char *b = line, *e = line + len;
    while (b < e && (*b == ' ' || *b == '\t'))
        b++;
    while (e > b && (e[-1] == ' ' || e[-1] == '\t'))
        e--;
    if (b < e) {
        char *stop;
        errno = 0;
        long long iv = strtoll(b, &stop, 10);
        if (stop == e && errno != ERANGE)
            return rt_int(iv);
        errno = 0;
        double fv = strtod(b, &stop);
        /* 必须吃满整行、至少含一个数字、且是有限值——挡掉 "inf"/"nan"/"0x1p3" */
        int has_digit = 0;
        for (const char *q = b; q < e; q++)
            if (*q >= '0' && *q <= '9') { has_digit = 1; break; }
        if (stop == e && has_digit && isfinite(fv))
            return rt_float(fv);
    }
    return rt_str(line);   /* 不是数字就整行按字符串（保留用户输入原样） */
}

/* ================= 网页输出（hm 的运行时） ================= */

/* 网页缓冲（malloc 增长，分配不回收；save 后清长度复用内存） */
static char  *g_page = NULL;
static size_t g_page_len = 0, g_page_cap = 0;
static int    g_page_begun = 0;

static void page_append_n(const char *s, size_t n)
{
    if (g_page_len + n + 1 > g_page_cap) {
        g_page_cap = g_page_cap ? g_page_cap : 1024;
        while (g_page_len + n + 1 > g_page_cap)
            g_page_cap *= 2;
        g_page = (char *)realloc(g_page, g_page_cap);
        if (!g_page)
            rt_die("内存不足");
    }
    memcpy(g_page + g_page_len, s, n);
    g_page_len += n;
    g_page[g_page_len] = '\0';
}

static void page_append(const char *s) { page_append_n(s ? s : "", strlen(s ? s : "")); }

/* 用户文本进页面的唯一通道：& < > " 全部转义，永远变不成可执行标签 */
static void page_append_esc(const char *s)
{
    for (const char *p = s ? s : ""; *p; p++) {
        switch (*p) {
        case '&': page_append_n("&amp;", 5); break;
        case '<': page_append_n("&lt;", 4); break;
        case '>': page_append_n("&gt;", 4); break;
        case '"': page_append_n("&quot;", 6); break;
        default:  page_append_n(p, 1); break;
        }
    }
}

/* 段落样式组装用的临时缓冲（同页缓冲策略） */
static char  *g_scratch = NULL;
static size_t g_scratch_len = 0, g_scratch_cap = 0;

static void scratch_reset(void)
{
    g_scratch_len = 0;
    if (g_scratch)
        g_scratch[0] = '\0';
}

static void scratch_append_n(const char *s, size_t n)
{
    if (g_scratch_len + n + 1 > g_scratch_cap) {
        g_scratch_cap = g_scratch_cap ? g_scratch_cap : 256;
        while (g_scratch_len + n + 1 > g_scratch_cap)
            g_scratch_cap *= 2;
        g_scratch = (char *)realloc(g_scratch, g_scratch_cap);
        if (!g_scratch)
            rt_die("内存不足");
    }
    memcpy(g_scratch + g_scratch_len, s, n);
    g_scratch_len += n;
    g_scratch[g_scratch_len] = '\0';
}

static void scratch_append(const char *s) { scratch_append_n(s, strlen(s)); }

/* hm 段落样式（与 rt_magic 同一套 token）→ CSS，"; " 连接：
 * b/i/u/d → font-weight / font-style / text-decoration(underline|line-through)
 * c=R,G,B → color:rgb(...)      bk=R,G,B → background-color:rgb(...)
 * f.字体 → font-family:'字体'   fs.数字 → font-size:数字px
 * l/fl、m/fm、r/fr → text-align:left/center/right
 * 未知 token → "不支持的样式" 退出。样式串由编译器生成，不做 HTML 转义。 */
static void page_style_css(const char *style)
{
    scratch_reset();
    const char *p = style ? style : "";
    if (*p == '\0')
        return;
    int first = 1;
    for (;;) {
        size_t len;
        const char *start = style_token(&p, &len);

        char tok[64];
        token_text(tok, sizeof tok, start, len);

        const char *css = NULL;
        char rgb[96];
        if (len == 0) {
            /* 空项跳过 */
        }
        else if (len == 1 && start[0] == 'b')                    css = "font-weight:bold";
        else if (len == 1 && start[0] == 'i')                    css = "font-style:italic";
        else if (len == 1 && start[0] == 'u')                    css = "text-decoration:underline";
        else if (len == 1 && start[0] == 'd')                    css = "text-decoration:line-through";
        else if (len == 1 && start[0] == 'm')                    css = "text-align:center";
        else if (len == 2 && start[0] == 'f' && start[1] == 'm') css = "text-align:center";
        else if (len == 1 && start[0] == 'r')                    css = "text-align:right";
        else if (len == 2 && start[0] == 'f' && start[1] == 'r') css = "text-align:right";
        else if (len == 1 && start[0] == 'l')                    css = "text-align:left";
        else if (len == 2 && start[0] == 'f' && start[1] == 'l') css = "text-align:left";
        else if (len >= 2 && start[0] == 'c' && start[1] == '=') {
            int r = parse_channel(start + 2, p);
            int g = read_channel(&p, tok);
            int b = read_channel(&p, tok);
            snprintf(rgb, sizeof rgb, "color:rgb(%d,%d,%d)", r, g, b);
            css = rgb;
        }
        else if (len >= 3 && start[0] == 'b' && start[1] == 'k' && start[2] == '=') {
            int r = parse_channel(start + 3, p);
            int g = read_channel(&p, tok);
            int b = read_channel(&p, tok);
            snprintf(rgb, sizeof rgb, "background-color:rgb(%d,%d,%d)", r, g, b);
            css = rgb;
        }
        else if (len >= 2 && start[0] == 'f' && start[1] == '.') {
            if (len == 2)
                rt_die("不支持的样式 %s", tok);
            snprintf(rgb, sizeof rgb, "font-family:'%.*s'", (int)(len - 2), start + 2);
            css = rgb;
        }
        else if (len >= 3 && start[0] == 'f' && start[1] == 's' && start[2] == '.') {
            int px = parse_font_size(start + 3, len - 3, tok);
            snprintf(rgb, sizeof rgb, "font-size:%dpx", px);
            css = rgb;
        }
        else
            rt_die("不支持的样式 %s", tok);

        if (css != NULL) {
            if (!first)
                scratch_append("; ");
            scratch_append(css);
            first = 0;
        }

        if (*p == '\0')
            break;
        p++;   /* 跳过逗号，读下一项 */
    }
}

void rt_page_begin(const char *title)
{
    g_page_len = 0;          /* 重新开始：清掉上一页内容（缓冲内存保留复用） */
    g_page_begun = 1;
    page_append("<!DOCTYPE html>\n<html lang=\"zh\">\n<head>\n"
                "<meta charset=\"utf-8\">\n<title>");
    page_append_esc(title ? title : "");
    page_append("</title>\n<style>\n"
                "body{background:#1e1e2e;color:#cdd6f4;"
                "font-family:\"Microsoft YaHei UI\",sans-serif;"
                "padding:40px;line-height:1.6}\n"
                "a{color:#89dceb}\n"
                "</style>\n</head>\n<body>\n");
}

void rt_page_para_open(const char *style)
{
    if (!g_page_begun)
        rt_die("网页输出：请先调用 hm.begin");
    if (style && *style) {
        page_style_css(style);
        page_append("<p style=\"");
        page_append(g_scratch);
        page_append("\">\n");
    } else {
        page_append("<p>\n");
    }
}

void rt_page_text(const char *raw)
{
    page_append_esc(raw);
}

void rt_page_raw(const char *raw)
{
    page_append(raw ? raw : "");   /* 不转义：<canvas>/<script> 等页面结构用 */
}

void rt_page_value(Value v)
{
    rt_page_text(rt_str_of(v));
}

void rt_page_para_close(void)
{
    page_append("</p>\n");
}

void rt_page_h(const char *raw, int level)
{
    int lv = (level >= 2) ? 2 : 1;   /* v2 只有 h1/h2，更大的级别按 h2 处理 */
    page_append(lv == 1 ? "<h1>" : "<h2>");
    page_append_esc(raw ? raw : "");
    page_append(lv == 1 ? "</h1>\n" : "</h2>\n");
}

void rt_page_img(const char *file)
{
    page_append("<img src=\"");
    page_append_esc(file ? file : "");
    page_append("\">\n");
}

void rt_page_hr(void)
{
    page_append("<hr>\n");
}

void rt_page_link(const char *text, const char *url)
{
    page_append("<a href=\"");
    page_append_esc(url ? url : "");
    page_append("\">");
    page_append_esc(text ? text : "");
    page_append("</a>\n");
}

void rt_page_save(void)
{
    if (!g_page_begun)
        rt_die("网页输出：请先调用 hm.begin");
    page_append("</body>\n</html>\n");
    FILE *fp = fopen("pybook_page.html", "wb");   /* 二进制写：UTF-8 字节原样落盘 */
    if (!fp)
        rt_die("网页输出：无法写 pybook_page.html");
    if (fwrite(g_page, 1, g_page_len, fp) != g_page_len) {
        fclose(fp);
        rt_die("网页输出：写 pybook_page.html 失败");
    }
    fclose(fp);
    g_page_len = 0;          /* 清空缓冲供下一页复用 */
    g_page_begun = 0;
}

/* ================= 游戏零件：SDL2 像素窗口版 =================
 * SDL2 头文件在包含路径里（-Iucrt64/include）→ 编译真实现；
 * 否则编译"未启用"桩：调用时给出明确报错，其他构建不受 SDL 依赖拖累。
 * 注意：SDL.h 会经 SDL_main.h 把 main 重定义成 SDL_main → 必须在包含之前
 * #define SDL_MAIN_HANDLED，并在初始化时调用 SDL_SetMainReady()。 */

#if defined(RT_GAME_SDL)
#  define RT_HAVE_SDL 1        /* 显式要求游戏引擎：强制启用 */
#elif defined(__has_include)
#  if __has_include(<SDL2/SDL.h>)
#    define RT_HAVE_SDL 1
#  else
#    define RT_HAVE_SDL 0
#  endif
#else
#  define RT_HAVE_SDL 0
#endif

#if RT_HAVE_SDL

#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#define SDL_MAIN_HANDLED
#include <SDL2/SDL.h>

/* 内部状态 */
static SDL_Window   *g_sdl_win = NULL;    /* 游戏窗口 */
static SDL_Renderer *g_sdl_ren = NULL;    /* 渲染器 */
static Uint8 g_kprev[256], g_kcur[256];   /* 键盘状态：上一帧 / 当前（rt_game_hit 用） */
static int   g_quit = 0;                  /* 用户是否点了 X */

/* 当前画图颜色（rt_game_color 记，clear/box/dot/line 共用），默认黑 */
static int g_pen_r = 0, g_pen_g = 0, g_pen_b = 0;

static int sdl_u8(int x)              /* 颜色分量截到 0..255 */
{
    return x < 0 ? 0 : x > 255 ? 255 : x;
}

/* 游戏零件的数字参数：INT/BIGINT/BOOL 直取，FLOAT 截断，其余报错 */
static long long game_num(Value v, const char *who)
{
    if (IS_INT(v) || IS_BIGINT(v))
        return as_int(v);
    if (IS_BOOL(v))
        return (long long)AS_BOOL(v);
    if (IS_FLT(v))
        return (long long)AS_FLT(v);
    rt_die("%s 需要数字参数", who);
    return 0;
}

/* 键名 → 虚拟键码；支持方向键/空格/回车/ESC/Shift、单字母 a-z 和中文键名。
 * 字母键 VK_A..VK_Z 恰好是大写 ASCII。未知键名返回 0（按"没按"处理）。 */
static int game_key_code(const char *name)
{
    static const struct { const char *n; int vk; } TAB[] = {
        {"right", VK_RIGHT}, {"left", VK_LEFT},
        {"up", VK_UP},       {"down", VK_DOWN},
        {"space", VK_SPACE}, {"enter", VK_RETURN},
        {"esc", VK_ESCAPE},  {"shift", VK_SHIFT},
        {"右", VK_RIGHT},    {"左", VK_LEFT},
        {"上", VK_UP},       {"下", VK_DOWN},
        {"空格", VK_SPACE},  {"回车", VK_RETURN},
    };
    if (name == NULL)
        return 0;
    for (size_t i = 0; i < sizeof(TAB) / sizeof(TAB[0]); i++)
        if (strcmp(TAB[i].n, name) == 0)
            return TAB[i].vk;
    if (name[1] == '\0' && name[0] >= 'a' && name[0] <= 'z')
        return name[0] - 'a' + 'A';
    return 0;
}

/* 泵一遍事件队列：SDL_QUIT（点 X）置 g_quit。
 * rt_game_end / rt_game_key / rt_game_hit / rt_game_frame 每次被调用都跑一次，
 * 窗口不会"无响应"。 */
static void game_pump(void)
{
    SDL_Event ev;
    while (SDL_PollEvent(&ev))
        if (ev.type == SDL_QUIT)
            g_quit = 1;
}

Value rt_game_win(Value wv, Value hv, const char *title)
{
    int w = (int)game_num(wv, "game.win 的宽");
    int h = (int)game_num(hv, "game.win 的高");
    SDL_SetMainReady();               /* 配合 SDL_MAIN_HANDLED：main 归用户 */
    if (SDL_Init(SDL_INIT_VIDEO) != 0)
        rt_die("SDL 初始化失败: %s", SDL_GetError());
    if (g_sdl_win != NULL) {          /* 重复开窗：先收掉旧的 */
        SDL_DestroyRenderer(g_sdl_ren);
        SDL_DestroyWindow(g_sdl_win);
        g_sdl_ren = NULL;
        g_sdl_win = NULL;
    }
    g_sdl_win = SDL_CreateWindow(title && *title ? title : "PYbook",
                                 SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
                                 w, h, SDL_WINDOW_SHOWN | SDL_WINDOW_RESIZABLE);
    if (g_sdl_win == NULL)
        rt_die("创建窗口失败: %s", SDL_GetError());
    g_sdl_ren = SDL_CreateRenderer(g_sdl_win, -1, SDL_RENDERER_ACCELERATED);
    if (g_sdl_ren == NULL)            /* 没有加速后端就退回软渲染 */
        g_sdl_ren = SDL_CreateRenderer(g_sdl_win, -1, 0);
    if (g_sdl_ren == NULL)
        rt_die("创建渲染器失败: %s", SDL_GetError());
    SDL_RenderSetLogicalSize(g_sdl_ren, w, h);   /* 逻辑尺寸 = 窗口尺寸，缩放不变形 */
    memset(g_kprev, 0, sizeof g_kprev);
    memset(g_kcur, 0, sizeof g_kcur);
    g_quit = 0;
    return rt_none();
}

Value rt_game_clear(Value rv, Value gv, Value bv)
{
    if (g_sdl_ren == NULL)
        rt_die("game.clear：还没开窗口（先调用 game.win）");
    SDL_SetRenderDrawColor(g_sdl_ren, sdl_u8((int)game_num(rv, "game.clear 的 R")),
                           sdl_u8((int)game_num(gv, "game.clear 的 G")),
                           sdl_u8((int)game_num(bv, "game.clear 的 B")), 255);
    SDL_RenderClear(g_sdl_ren);
    return rt_none();
}

Value rt_game_color(Value rv, Value gv, Value bv)
{
    g_pen_r = sdl_u8((int)game_num(rv, "game.color 的 R"));
    g_pen_g = sdl_u8((int)game_num(gv, "game.color 的 G"));
    g_pen_b = sdl_u8((int)game_num(bv, "game.color 的 B"));
    return rt_none();
}

Value rt_game_box(Value xv, Value yv, Value wv, Value hv)
{
    if (g_sdl_ren == NULL)
        rt_die("game.box：还没开窗口（先调用 game.win）");
    SDL_Rect rc;
    rc.x = (int)game_num(xv, "game.box 的 x");
    rc.y = (int)game_num(yv, "game.box 的 y");
    rc.w = (int)game_num(wv, "game.box 的宽");
    rc.h = (int)game_num(hv, "game.box 的高");
    SDL_SetRenderDrawColor(g_sdl_ren, g_pen_r, g_pen_g, g_pen_b, 255);
    SDL_RenderFillRect(g_sdl_ren, &rc);
    return rt_none();
}

Value rt_game_dot(Value xv, Value yv)
{
    return rt_game_box(xv, yv, rt_int(4), rt_int(4));   /* 点 = 4×4 像素的小方块 */
}

Value rt_game_line(Value x1v, Value y1v, Value x2v, Value y2v)
{
    if (g_sdl_ren == NULL)
        rt_die("game.line：还没开窗口（先调用 game.win）");
    SDL_SetRenderDrawColor(g_sdl_ren, g_pen_r, g_pen_g, g_pen_b, 255);
    SDL_RenderDrawLine(g_sdl_ren,
                       (int)game_num(x1v, "game.line 的 x1"), (int)game_num(y1v, "game.line 的 y1"),
                       (int)game_num(x2v, "game.line 的 x2"), (int)game_num(y2v, "game.line 的 y2"));
    return rt_none();
}

/* ---- 字 / 图 / 图缩：中文文字与 PNG 贴图（stb 单头文件，零新增依赖） ---- */

#define STB_TRUETYPE_IMPLEMENTATION
#include "stb_truetype.h"
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

static stbtt_fontinfo g_ttf;      /* 系统中文字体（惰性加载，字体数据常驻） */
static int g_ttf_ok = 0;

static void game_font_init(void)
{
    static const char *CAND[] = {
        "C:\\Windows\\Fonts\\msyh.ttc",    /* 微软雅黑 */
        "C:\\Windows\\Fonts\\msyh.ttf",
        "C:\\Windows\\Fonts\\simhei.ttf",  /* 黑体 */
        "C:\\Windows\\Fonts\\simsun.ttc",  /* 宋体 */
    };
    if (g_ttf_ok)
        return;
    for (int i = 0; i < (int)(sizeof CAND / sizeof CAND[0]); i++) {
        FILE *fp = fopen(CAND[i], "rb");
        if (fp == NULL)
            continue;
        fseek(fp, 0, SEEK_END);
        long n = ftell(fp);
        fseek(fp, 0, SEEK_SET);
        unsigned char *data = (unsigned char *)malloc((size_t)n);
        if (data != NULL && fread(data, 1, (size_t)n, fp) == (size_t)n) {
            int off = stbtt_GetFontOffsetForIndex(data, 0);
            if (off >= 0 && stbtt_InitFont(&g_ttf, data, off)) {
                g_ttf_ok = 1;          /* data 故意不释放：光栅化还要读 */
                fclose(fp);
                return;
            }
        }
        free(data);
        fclose(fp);
    }
    rt_die("game.字：在系统字体目录找不到中文字体（msyh/simhei/simsun）");
}

/* UTF-8 解一个码点，*adv 返回字节数 */
static unsigned game_utf8(const char *s, int i, int *adv)
{
    unsigned char c = (unsigned char)s[i];
    unsigned cp = c;
    *adv = 1;
    if (c >= 0xF0) {
        cp = ((c & 7u) << 18) | ((s[i + 1] & 63u) << 12) | ((s[i + 2] & 63u) << 6) | (s[i + 3] & 63u);
        *adv = 4;
    } else if (c >= 0xE0) {
        cp = ((c & 15u) << 12) | ((s[i + 1] & 63u) << 6) | (s[i + 2] & 63u);
        *adv = 3;
    } else if (c >= 0xC0) {
        cp = ((c & 31u) << 6) | (s[i + 1] & 63u);
        *adv = 2;
    }
    return cp;
}

/* 文本纹理缓存：键 = 字号|颜色|内容（换分数字会换内容，上限逐出最旧） */
#define TXT_CACHE_MAX 160
typedef struct { char *key; SDL_Texture *tex; int w, h; } TxtEnt;
static TxtEnt g_txt[TXT_CACHE_MAX];
static int g_txt_n = 0;

static SDL_Texture *game_text_tex(const char *s, int px, int *ow, int *oh)
{
    game_font_init();
    if (px < 6)
        px = 6;
    if (px > 220)
        px = 220;
    float scale = stbtt_ScaleForPixelHeight(&g_ttf, (float)px);
    int ascent = 0, descent = 0, gap = 0;
    stbtt_GetFontVMetrics(&g_ttf, &ascent, &descent, &gap);
    int base = (int)(ascent * scale) + 1;

    int W = 4;
    for (int i = 0; s[i];) {
        int adv = 1;
        unsigned cp = game_utf8(s, i, &adv);
        int a = 0, l = 0;
        stbtt_GetCodepointHMetrics(&g_ttf, (int)cp, &a, &l);
        W += (int)(a * scale) + 2;
        i += adv;
    }
    int H = px + 4;
    unsigned char *pix = (unsigned char *)calloc((size_t)W * H * 4, 1);
    if (pix == NULL)
        rt_die("game.字：内存不足");
    int penx = 1;
    for (int i = 0; s[i];) {
        int adv = 1;
        unsigned cp = game_utf8(s, i, &adv);
        int bw = 0, bh = 0, ox = 0, oy = 0;
        unsigned char *bmp = stbtt_GetCodepointBitmap(&g_ttf, scale, scale, (int)cp, &bw, &bh, &ox, &oy);
        if (bmp != NULL) {
            for (int j = 0; j < bh; j++) {
                int ty = base + oy + j;    /* oy 常为负：字形向上伸展 */
                if (ty < 0 || ty >= H)
                    continue;
                for (int k = 0; k < bw; k++) {
                    int tx = penx + ox + k;
                    if (tx < 0 || tx >= W)
                        continue;
                    size_t o = ((size_t)ty * W + tx) * 4;
                    pix[o] = (unsigned char)g_pen_r;
                    pix[o + 1] = (unsigned char)g_pen_g;
                    pix[o + 2] = (unsigned char)g_pen_b;
                    pix[o + 3] = bmp[j * bw + k];
                }
            }
            stbtt_FreeBitmap(bmp, NULL);
        }
        int a2 = 0, l2 = 0;
        stbtt_GetCodepointHMetrics(&g_ttf, (int)cp, &a2, &l2);
        penx += (int)(a2 * scale);
        i += adv;
    }
    SDL_Surface *sur = SDL_CreateRGBSurfaceWithFormatFrom(pix, W, H, 32, W * 4,
                                                          SDL_PIXELFORMAT_RGBA32);
    SDL_Texture *tex = SDL_CreateTextureFromSurface(g_sdl_ren, sur);
    SDL_FreeSurface(sur);
    free(pix);
    if (tex == NULL)
        rt_die("game.字：建纹理失败: %s", SDL_GetError());
    SDL_SetTextureBlendMode(tex, SDL_BLENDMODE_BLEND);
    *ow = W;
    *oh = H;
    return tex;
}

Value rt_game_text(Value xv, Value yv, Value tv, Value sv)
{
    if (g_sdl_ren == NULL)
        rt_die("game.字：还没开窗口（先调用 win）");
    int x = (int)game_num(xv, "game.字 的 x");
    int y = (int)game_num(yv, "game.字 的 y");
    int px = (int)game_num(sv, "game.字 的字号");
    char *s = rt_str_of(tv);
    char head[48];
    snprintf(head, sizeof head, "%d|%02x%02x%02x|", px, g_pen_r, g_pen_g, g_pen_b);
    size_t klen = strlen(head) + strlen(s) + 1;
    char *key = (char *)malloc(klen);
    if (key == NULL)
        rt_die("game.字：内存不足");
    snprintf(key, klen, "%s%s", head, s);

    SDL_Texture *tex = NULL;
    int tw = 0, th = 0;
    for (int i = 0; i < g_txt_n; i++) {
        if (strcmp(g_txt[i].key, key) == 0) {
            tex = g_txt[i].tex;
            tw = g_txt[i].w;
            th = g_txt[i].h;
            break;
        }
    }
    if (tex == NULL) {
        tex = game_text_tex(s, px, &tw, &th);
        if (g_txt_n == TXT_CACHE_MAX) {          /* 满了：逐出最旧的一条 */
            SDL_DestroyTexture(g_txt[0].tex);
            free(g_txt[0].key);
            memmove(g_txt, g_txt + 1, sizeof(TxtEnt) * (TXT_CACHE_MAX - 1));
            g_txt_n--;
        }
        g_txt[g_txt_n].key = key;
        g_txt[g_txt_n].tex = tex;
        g_txt[g_txt_n].w = tw;
        g_txt[g_txt_n].h = th;
        g_txt_n++;
    } else {
        free(key);
    }
    SDL_Rect dst;
    dst.x = x;
    dst.y = y;
    dst.w = tw;
    dst.h = th;
    SDL_RenderCopy(g_sdl_ren, tex, NULL, &dst);
    /* s 是 rt_str_of 的结果（可能是 Value 内部指针）：按运行时约定不回收 */
    return rt_none();
}

/* 图片缓存：路径 -> 纹理（加载一次常驻） */
#define IMG_CACHE_MAX 48
typedef struct { char *path; SDL_Texture *tex; int w, h; } ImgEnt;
static ImgEnt g_img[IMG_CACHE_MAX];
static int g_img_n = 0;

static SDL_Texture *game_img_tex(const char *path, int *ow, int *oh)
{
    for (int i = 0; i < g_img_n; i++) {
        if (strcmp(g_img[i].path, path) == 0) {
            *ow = g_img[i].w;
            *oh = g_img[i].h;
            return g_img[i].tex;
        }
    }
    /* UTF-8 路径 → UTF-16 → _wfopen（fopen 会按 ANSI 代码页误读中文路径） */
    wchar_t wpath[1024];
    if (MultiByteToWideChar(CP_UTF8, 0, path ? path : "", -1, wpath, 1024) <= 0)
        rt_die("game.图：路径转码失败 %s", path);
    FILE *fp = _wfopen(wpath, L"rb");
    if (fp == NULL)
        rt_die("game.图：无法加载图片 %s", path);
    int w = 0, h = 0, n = 0;
    unsigned char *data = stbi_load_from_file(fp, &w, &h, &n, 4);
    fclose(fp);
    if (data == NULL)
        rt_die("game.图：图片解码失败 %s", path);
    SDL_Surface *sur = SDL_CreateRGBSurfaceWithFormatFrom(data, w, h, 32, w * 4,
                                                          SDL_PIXELFORMAT_RGBA32);
    SDL_Texture *tex = SDL_CreateTextureFromSurface(g_sdl_ren, sur);
    SDL_FreeSurface(sur);
    stbi_image_free(data);
    if (tex == NULL)
        rt_die("game.图：建纹理失败: %s", SDL_GetError());
    SDL_SetTextureBlendMode(tex, SDL_BLENDMODE_BLEND);
    if (g_img_n == IMG_CACHE_MAX)
        rt_die("game.图：图片缓存已满（最多 %d 张）", IMG_CACHE_MAX);
    g_img[g_img_n].path = strdup(path);
    g_img[g_img_n].tex = tex;
    g_img[g_img_n].w = w;
    g_img[g_img_n].h = h;
    g_img_n++;
    *ow = w;
    *oh = h;
    return tex;
}

Value rt_game_img(Value xv, Value yv, Value pv)
{
    if (g_sdl_ren == NULL)
        rt_die("game.图：还没开窗口（先调用 win）");
    int x = (int)game_num(xv, "game.图 的 x");
    int y = (int)game_num(yv, "game.图 的 y");
    char *p = rt_str_of(pv);
    int w = 0, h = 0;
    SDL_Texture *tex = game_img_tex(p, &w, &h);
    SDL_Rect dst;
    dst.x = x;
    dst.y = y;
    dst.w = w;
    dst.h = h;
    SDL_RenderCopy(g_sdl_ren, tex, NULL, &dst);
    return rt_none();
}

Value rt_game_img_scaled(Value xv, Value yv, Value wv, Value hv, Value pv)
{
    if (g_sdl_ren == NULL)
        rt_die("game.图缩：还没开窗口（先调用 win）");
    int x = (int)game_num(xv, "game.图缩 的 x");
    int y = (int)game_num(yv, "game.图缩 的 y");
    int w = (int)game_num(wv, "game.图缩 的宽");
    int h = (int)game_num(hv, "game.图缩 的高");
    char *p = rt_str_of(pv);
    int tw = 0, th = 0;
    SDL_Texture *tex = game_img_tex(p, &tw, &th);
    SDL_Rect dst;
    dst.x = x;
    dst.y = y;
    dst.w = w;
    dst.h = h;
    SDL_RenderCopy(g_sdl_ren, tex, NULL, &dst);
    return rt_none();
}

Value rt_game_show(void)
{
    if (g_sdl_ren == NULL)
        rt_die("game.show：还没开窗口（先调用 game.win）");
    SDL_RenderPresent(g_sdl_ren);
    return rt_none();
}

Value rt_game_key(const char *name)
{
    int vk = game_key_code(name);
    if (vk == 0)
        return rt_int(0);   /* 未知键名按"没按"处理 */
    game_pump();
    return rt_int((GetAsyncKeyState(vk) & 0x8000) ? 1 : 0);
}

Value rt_game_hit(const char *name)
{
    int vk = game_key_code(name);
    if (vk == 0)
        return rt_int(0);
    return rt_int((g_kcur[vk & 255] && !g_kprev[vk & 255]) ? 1 : 0);
}

Value rt_game_frame(void)
{
    game_pump();
    memcpy(g_kprev, g_kcur, sizeof g_kcur);   /* cur → prev（给 rt_game_hit 用） */
    for (int i = 0; i < 256; i++)             /* 刷新当前键盘状态 */
        g_kcur[i] = (GetAsyncKeyState(i) & 0x8000) ? 1 : 0;
    SDL_Delay(16);                            /* 约 60 FPS */
    return rt_none();
}

Value rt_game_end(void)
{
    game_pump();
    if (g_quit)
        return rt_bool(1);
    /* 点 X 之外，按住 ESC 也算想结束（退出约定） */
    return rt_bool((GetAsyncKeyState(VK_ESCAPE) & 0x8000) ? 1 : 0);
}

Value rt_game_bye(void)
{
    if (g_sdl_ren != NULL) {
        SDL_DestroyRenderer(g_sdl_ren);
        g_sdl_ren = NULL;
    }
    if (g_sdl_win != NULL) {
        SDL_Delay(500);   /* 留半秒让最后一帧被看见 */
        SDL_DestroyWindow(g_sdl_win);
        g_sdl_win = NULL;
    }
    SDL_Quit();
    return rt_none();
}

#else /* 未启用 SDL2：游戏零件编译"未启用"桩 */

#define RT_GAME_OFF_MSG "游戏引擎需要 SDL2（构建时加 -Iucrt64/include -Lucrt64/lib -lSDL2）"

static void game_off(void) { rt_die("%s", RT_GAME_OFF_MSG); }

Value rt_game_win(Value w, Value h, const char *title) { (void)w; (void)h; (void)title; game_off(); return rt_none(); }
Value rt_game_clear(Value r, Value g, Value b) { (void)r; (void)g; (void)b; game_off(); return rt_none(); }
Value rt_game_color(Value r, Value g, Value b) { (void)r; (void)g; (void)b; game_off(); return rt_none(); }
Value rt_game_box(Value x, Value y, Value w, Value h) { (void)x; (void)y; (void)w; (void)h; game_off(); return rt_none(); }
Value rt_game_dot(Value x, Value y) { (void)x; (void)y; game_off(); return rt_none(); }
Value rt_game_line(Value x1, Value y1, Value x2, Value y2) { (void)x1; (void)y1; (void)x2; (void)y2; game_off(); return rt_none(); }
Value rt_game_show(void) { game_off(); return rt_none(); }
Value rt_game_key(const char *name) { (void)name; game_off(); return rt_none(); }
Value rt_game_hit(const char *name) { (void)name; game_off(); return rt_none(); }
Value rt_game_frame(void) { game_off(); return rt_none(); }
Value rt_game_end(void) { game_off(); return rt_none(); }
Value rt_game_bye(void) { game_off(); return rt_none(); }
Value rt_game_text(Value x, Value y, Value t, Value s) { (void)x; (void)y; (void)t; (void)s; game_off(); return rt_none(); }
Value rt_game_img(Value x, Value y, Value p) { (void)x; (void)y; (void)p; game_off(); return rt_none(); }
Value rt_game_img_scaled(Value x, Value y, Value w, Value h, Value p) { (void)x; (void)y; (void)w; (void)h; (void)p; game_off(); return rt_none(); }

#endif /* RT_HAVE_SDL */

/* ================= 自测（-DRT_SELF_TEST） ================= */

#ifdef RT_SELF_TEST

#include "pybook_lib.h"   /* rt_lib_te_* / rt_lib_mt_* / rt_lib_rd_* 冒烟 */
#include <unistd.h>       /* dup / dup2 / close：捕获 stdout 核对字节输出 */

static int g_pass = 0, g_fails = 0;

static void check(int cond, const char *name)
{
    if (cond) {
        g_pass++;
        printf("[通过] %s\n", name);
    } else {
        g_fails++;
        printf("[失败] %s\n", name);
    }
}

/* ---- 取值小助手 ---- */

static int is_i(Value v, long long x) { return IS_INT(v) && AS_INT(v) == x; }
static int is_f(Value v, double x)    { return IS_FLT(v) && AS_FLT(v) == x; }
static int is_s(Value v, const char *s) { return IS_STR(v) && strcmp(AS_STR(v), s) == 0; }
static int is_b(Value v, int b)       { return IS_BOOL(v) && AS_BOOL(v) == (b ? 1 : 0); }

/* ---- stdout 捕获（Windows 文本模式会把 \n 写成 \r\n，比对前去掉 \r） ---- */

static FILE *s_tmp;
static int s_saved_fd;

static void capture_start(void)
{
    fflush(stdout);
    s_saved_fd = dup(1);
    s_tmp = tmpfile();
    dup2(fileno(s_tmp), 1);
}

static void capture_finish(char *buf, size_t cap)
{
    fflush(stdout);
    dup2(s_saved_fd, 1);
    close(s_saved_fd);
    rewind(s_tmp);
    size_t n = fread(buf, 1, cap - 1, s_tmp);
    buf[n] = '\0';
    fclose(s_tmp);
    char *w = buf, *r = buf;
    while (*r) {
        if (*r != '\r')
            *w++ = *r;
        r++;
    }
    *w = '\0';
}

/* ---- 报错分支用例表：子进程模式跑指定用例，验证 exit(1) + stderr 消息 ---- */

static void e_add_ovf(void)      { (void)rt_add(rt_int(LLONG_MAX), rt_int(1)); }
static void e_sub_ovf(void)      { (void)rt_sub(rt_int(LLONG_MIN), rt_int(1)); }
static void e_mul_ovf(void)      { (void)rt_mul(rt_int(LLONG_MAX), rt_int(2)); }
static void e_div_zero(void)     { (void)rt_div(rt_int(1), rt_int(0)); }
static void e_div_fzero(void)    { (void)rt_div(rt_int(1), rt_float(0.0)); }
static void e_fdiv_zero(void)    { (void)rt_fdiv(rt_int(7), rt_int(0)); }
static void e_fdiv_ovf(void)     { (void)rt_fdiv(rt_int(LLONG_MIN), rt_int(-1)); }
static void e_mod_zero(void)     { (void)rt_mod(rt_int(7), rt_int(0)); }
static void e_neg_ovf(void)      { (void)rt_neg(rt_int(LLONG_MIN)); }
static void e_add_type(void)     { (void)rt_add(rt_str("a"), rt_int(1)); }
static void e_neg_type(void)     { (void)rt_neg(rt_str("x")); }
static void e_cmp_type(void)     { (void)rt_lt(rt_int(1), rt_str("a")); }
static void e_locked_assign(void)
{
    Value x = rt_int(1);
    rt_gold(&x);
    rt_assign(&x, rt_int(2));
}
static void e_locked_push(void)
{
    Value lst = rt_list_new();
    rt_gold(&lst);
    rt_push(&lst, rt_int(1));
}
static void e_del_read(void)
{
    Value x = rt_int(1);
    rt_destroy(&x);
    (void)rt_chk(x);
}
static void e_del_assign(void)
{
    Value x = rt_int(1);
    rt_destroy(&x);
    rt_assign(&x, rt_int(2));
}
static void e_index_oob(void)
{
    Value lst = rt_list_new();
    rt_push(&lst, rt_int(1));
    (void)rt_index(lst, rt_int(5));
}
static void e_prop_missing(void)
{
    Value o = rt_obj_new("猫");
    (void)rt_obj_get_prop(o, "身高");
}
static void e_memmode(void)      { rt_set_memmode(9); }   /* 0/1/3/4/5/6 之外 */
static void e_magic_bad(void)    { rt_magic("b,x1"); }
static void e_len_type(void)     { (void)rt_len(rt_int(5)); }
static void e_sqrt_neg(void)     { (void)rt_lib_mt_sqrt(rt_int(-9)); }
static void e_page_nobegin(void) { rt_page_para_open("b"); }
#if RT_HAVE_SDL
static void e_game_nowin(void)   { (void)rt_game_box(rt_int(0), rt_int(0), rt_int(1), rt_int(1)); }
#define E_GAME_MSG "还没开窗口"
#else
static void e_game_nowin(void)   { (void)rt_game_box(rt_int(0), rt_int(0), rt_int(1), rt_int(1)); }
#define E_GAME_MSG "游戏引擎需要 SDL2"
#endif

typedef struct {
    const char *name;
    void (*fn)(void);
    const char *msg;   /* 期望出现在 stderr 里的片段 */
} ErrCase;

static const ErrCase g_errtab[] = {
    { "add 溢出",            e_add_ovf,       "溢出" },
    { "sub 溢出",            e_sub_ovf,       "溢出" },
    { "mul 溢出",            e_mul_ovf,       "溢出" },
    { "div 除以零",          e_div_zero,      "除以零" },
    { "div 浮点除以零",      e_div_fzero,     "除以零" },
    { "fdiv 除以零",         e_fdiv_zero,     "除以零" },
    { "fdiv LLONG_MIN//-1",  e_fdiv_ovf,      "溢出" },
    { "mod 除以零",          e_mod_zero,      "除以零" },
    { "neg -LLONG_MIN 溢出", e_neg_ovf,       "溢出" },
    { "add 类型不匹配",      e_add_type,      "类型不可相加" },
    { "neg 类型不匹配",      e_neg_type,      "负号只能用于数字" },
    { "< 类型不匹配",        e_cmp_type,      "类型不可比较" },
    { "锁定后赋值",          e_locked_assign, "变量已锁定" },
    { "锁定后 push",         e_locked_push,   "变量已锁定" },
    { "删除后读取",          e_del_read,      "用已删除变量" },
    { "删除后赋值",          e_del_assign,    "用已删除变量" },
    { "下标越界",            e_index_oob,     "下标越界" },
    { "属性不存在",          e_prop_missing,  "属性 '身高' 不存在" },
    { "内存模式未实现",      e_memmode,       "内存管理模式不支持" },
    { "未知样式",            e_magic_bad,     "不支持的样式 x1" },
    { "长度类型不匹配",      e_len_type,      "长度 只能用于列表或字符串" },
    { "sqrt 负数",           e_sqrt_neg,      "负数" },
    { "网页未 begin",        e_page_nobegin,  "请先调用" },
    { "游戏未开窗",          e_game_nowin,    E_GAME_MSG },
};

/* 报错分支验证：拉起自身 "err N"，确认退出码 1 且 stderr 带对应消息 */
static void expect_die(const char *argv0, int idx)
{
    char exe[512], cmd[1200], err[1024];
    snprintf(exe, sizeof exe, "%s", (argv0 && *argv0) ? argv0 : "rt_test.exe");
    for (char *p = exe; *p; p++)
        if (*p == '/')
            *p = '\\';   /* system() 走 cmd.exe，需要 Windows 路径分隔符 */
    snprintf(cmd, sizeof cmd, "\"%s\" err %d 2>._rt_err.tmp", exe, idx);
    fflush(stdout);
    fflush(stderr);
    int rc = system(cmd);
    size_t n = 0;
    FILE *fp = fopen("._rt_err.tmp", "rb");
    if (fp) {
        n = fread(err, 1, sizeof err - 1, fp);
        fclose(fp);
    }
    err[n] = '\0';
    remove("._rt_err.tmp");
    const ErrCase *c = &g_errtab[idx];
    if (rc == 1 && strstr(err, "运行时错误: ") != NULL && strstr(err, c->msg) != NULL) {
        g_pass++;
        printf("[通过] 报错：%s\n", c->name);
    } else {
        g_fails++;
        printf("[失败] 报错：%s（退出码 %d，stderr=%.120s）\n", c->name, rc, err);
    }
}

/* ---- SDL 图形演示（rt_test.exe game 时进入；默认自测不开窗口） ---- */

#if RT_HAVE_SDL
static int game_demo(void)
{
    rt_game_win(rt_int(320), rt_int(240), "PYbook 游戏自测");
    int frame;
    for (frame = 0; frame < 120; frame++) {
        if (rt_cond(rt_game_end()))
            break;
        rt_game_clear(rt_int(30), rt_int(30), rt_int(60));
        rt_game_color(rt_int(0), rt_int(255), rt_int(0));
        rt_game_box(rt_int(frame * 2), rt_int(100), rt_int(40), rt_int(40));
        rt_game_color(rt_int(255), rt_int(200), rt_int(0));
        rt_game_dot(rt_int(160), rt_int(120));
        rt_game_line(rt_int(0), rt_int(0), rt_int(319), rt_int(239));
        rt_game_show();
        if (rt_cond(rt_game_key("esc")))
            break;
        rt_game_frame();
    }
    printf("游戏演示：跑了 %d 帧，end=%d hit(space)=%d key(z)=%d\n",
           frame, (int)rt_to_ll(rt_game_end()),
           (int)rt_to_ll(rt_game_hit("space")), (int)rt_to_ll(rt_game_key("z")));
    rt_game_bye();
    return 0;
}
#else
static int game_demo(void)
{
    printf("本构建未启用 SDL2（缺 -Iucrt64/include），无法跑图形演示\n");
    return 0;
}
#endif

int main(int argc, char **argv)
{
    /* ---- 子进程模式：跑指定报错用例，必然 exit(1) ---- */
    if (argc >= 3 && strcmp(argv[1], "err") == 0) {
        int k = atoi(argv[2]);
        if (k < 0 || k >= (int)(sizeof g_errtab / sizeof g_errtab[0]))
            return 9;
        g_errtab[k].fn();
        printf("子进程没有触发错误：%s\n", g_errtab[k].name);
        return 9;
    }
    /* ---- SDL 图形演示模式 ---- */
    if (argc >= 2 && strcmp(argv[1], "game") == 0)
        return game_demo();

    /* ================= 构造 / 取值往返 ================= */
    {
        Value v = rt_int(42);
        check(is_i(v, 42) && RT_TYPE(v) == 1, "构造：int 42 往返");
        v = rt_int(-42);
        check(is_i(v, -42), "构造：负 int 往返");
        v = rt_int(RT_INT_FAST_MAX);
        check(IS_INT(v) && rt_to_ll(v) == RT_INT_FAST_MAX, "构造：快路径上界 2^47-1 仍是 INT");
        v = rt_int(RT_INT_FAST_MAX + 1);
        check(IS_BIGINT(v) && RT_TYPE(v) == 3 && rt_to_ll(v) == RT_INT_FAST_MAX + 1,
              "构造：2^47 自动转 BIGINT 且值保真");
        v = rt_int(LLONG_MAX);
        check(IS_BIGINT(v) && rt_to_ll(v) == LLONG_MAX, "构造：LLONG_MAX 走 BIGINT 保真");
        v = rt_int(LLONG_MIN);
        check(IS_BIGINT(v) && rt_to_ll(v) == LLONG_MIN, "构造：LLONG_MIN 走 BIGINT 保真");
        v = rt_float(3.14);
        check(IS_FLT(v) && !RT_IS_BOX(v) && AS_FLT(v) == 3.14, "构造：float 原始位样直接存（不装箱）");
        check(v != RT_DELETED_BOX && !IS_DEL(v), "构造：float 不与 DELETED 位样混淆");
        check(is_f(rt_float(0.0), 0.0) && IS_FLT(rt_float(0.0)), "构造：0.0 是浮点");
        check(IS_FLT(rt_float(1.0 / 0.0)) && AS_FLT(rt_float(1.0 / 0.0)) > 0, "构造：+Inf 仍是浮点");
        Value nan = rt_float(0.0 / 0.0);
        check(IS_FLT(nan) && isnan(AS_FLT(nan)) && rt_cond(nan) == 1,
              "构造：NaN 规范化（不被误判成装箱值，真值同 Python 的真）");
        check(is_b(rt_bool(1), 1) && is_b(rt_bool(0), 0) && is_b(rt_bool(7), 1), "构造：bool 非 0 即真");
        v = rt_str("你好");
        check(is_s(v, "你好") && RT_TYPE(v) == 4, "构造：str malloc 拷贝");
        check(AS_STR(rt_str("x")) != AS_STR(rt_str("x")), "构造：str 各自独立拷贝");
        check(IS_NONE(rt_none()) && RT_TYPE(rt_none()) == 0 && rt_none() == RT_NIL_BOX,
              "构造：none 是 canonical 空盒");
        check(rt_to_ll(rt_bool(1)) == 1 && rt_to_ll(rt_int(9)) == 9,
              "构造：rt_to_ll 统一出口（INT/BOOL）");
    }

    /* ================= 算术 ================= */
    {
        check(is_i(rt_add(rt_int(2), rt_int(3)), 5), "算术：2+3=5");
        check(is_i(rt_add(rt_bool(1), rt_bool(1)), 2), "算术：true+true=2（bool 按数值）");
        check(is_f(rt_add(rt_int(1), rt_float(2.5)), 3.5), "算术：int+float=float");
        check(is_s(rt_add(rt_str("你好"), rt_str("！")), "你好！"), "算术：str+str 拼接");
        check(is_f(rt_div(rt_int(7), rt_int(2)), 3.5), "算术：7/2=3.5（真除法一律 float）");
        check(is_i(rt_fdiv(rt_int(7), rt_int(2)), 3), "算术：7//2=3");
        check(is_i(rt_fdiv(rt_int(-7), rt_int(2)), -4), "算术：-7//2=-4（Python 向下取整）");
        check(is_i(rt_fdiv(rt_int(7), rt_int(-2)), -4), "算术：7//-2=-4（Python 向下取整）");
        check(is_f(rt_fdiv(rt_float(-7.0), rt_float(2.0)), -4.0), "算术：浮点 // 向下取整");
        check(is_i(rt_mod(rt_int(7), rt_int(3)), 1), "算术：7%3=1");
        check(is_i(rt_mod(rt_int(-7), rt_int(3)), 2), "算术：-7%3=2（符号跟除数）");
        check(is_i(rt_mod(rt_int(7), rt_int(-3)), -2), "算术：7%-3=-2（符号跟除数）");
        check(is_i(rt_mod(rt_int(LLONG_MIN), rt_int(-1)), 0), "算术：LLONG_MIN%-1=0（避开 C 未定义）");
        check(is_f(rt_mod(rt_float(-7.5), rt_float(2.0)), 0.5), "算术：浮点取模符号跟除数");
        check(is_i(rt_neg(rt_int(-5)), 5), "算术：负号");
        check(is_f(rt_neg(rt_float(2.5)), -2.5), "算术：浮点负号");
        check(is_b(rt_not(rt_int(0)), 1) && is_b(rt_not(rt_str("a")), 0), "算术：逻辑非");
        /* 超快路径的加法自动升级 BIGINT：2^46 + 2^46 = 2^47 */
        Value big = rt_add(rt_int(RT_INT_FAST_MAX - 1), rt_int(3));
        check(IS_BIGINT(big) && rt_to_ll(big) == RT_INT_FAST_MAX + 2,
              "算术：快路径溢出结果自动转 BIGINT 保真");
    }

    /* ================= 比较 ================= */
    {
        check(is_b(rt_eq(rt_int(1), rt_int(1)), 1), "比较：1==1");
        check(is_b(rt_eq(rt_int(1), rt_float(1.0)), 1), "比较：1==1.0（跨类型数值）");
        check(is_b(rt_eq(rt_bool(1), rt_int(1)), 1), "比较：true==1");
        check(is_b(rt_eq(rt_str("a"), rt_str("a")), 1), "比较：\"a\"==\"a\"");
        check(is_b(rt_eq(rt_int(1), rt_str("1")), 0), "比较：1==\"1\" 为假且不报错");
        check(is_b(rt_ne(rt_int(1), rt_int(2)), 1), "比较：1!=2");
        check(is_b(rt_eq(rt_none(), rt_none()), 1), "比较：空盒==空盒");
        Value l1 = rt_list_new(), l2 = rt_list_new();
        rt_push(&l1, rt_int(1));
        rt_push(&l1, rt_str("x"));
        rt_push(&l2, rt_int(1));
        rt_push(&l2, rt_str("x"));
        check(is_b(rt_eq(l1, l2), 1), "比较：列表深度相等");
        rt_push(&l2, rt_int(2));
        check(is_b(rt_eq(l1, l2), 0), "比较：长度不同判不等");
        Value o1 = rt_obj_new("猫"), o2 = rt_obj_new("猫");
        check(is_b(rt_eq(o1, o1), 1) && is_b(rt_eq(o1, o2), 0), "比较：对象按指针身份");
        check(is_b(rt_lt(rt_int(1), rt_int(2)), 1) && is_b(rt_lt(rt_int(2), rt_int(1)), 0),
              "比较：1<2");
        check(is_b(rt_lt(rt_str("a"), rt_str("b")), 1), "比较：\"a\"<\"b\" 字典序");
        check(is_b(rt_le(rt_int(1), rt_float(1.0)), 1) && is_b(rt_ge(rt_int(2), rt_float(1.5)), 1),
              "比较：<= >= 跨类型数值");
    }

    /* ================= 真值（五个假值） ================= */
    {
        check(rt_cond(rt_none()) == 0, "真值：空盒为假");
        check(rt_cond(rt_int(0)) == 0, "真值：0 为假");
        check(rt_cond(rt_float(0.0)) == 0, "真值：0.0 为假");
        check(rt_cond(rt_str("")) == 0, "真值：\"\" 为假");
        check(rt_cond(rt_bool(0)) == 0, "真值：false 为假");
        check(rt_cond(rt_int(-1)) && rt_cond(rt_float(0.5)) && rt_cond(rt_str("0")) &&
              rt_cond(rt_bool(1)), "真值：非零数字/非空串为真");
        Value lst = rt_list_new();
        check(rt_cond(lst) == 0, "真值：空列表为假");
        rt_push(&lst, rt_int(1));
        check(rt_cond(lst) == 1, "真值：非空列表为真");
        check(rt_cond(rt_obj_new("X")) == 1, "真值：对象恒真");
    }

    /* ================= 显示（rt_str_of / show / input） ================= */
    {
        char *t = rt_str_of(rt_int(-42));
        check(strcmp(t, "-42") == 0, "显示：int 十进制");
        t = rt_str_of(rt_float(3.5));
        check(strcmp(t, "3.5") == 0, "显示：float %.15g 去尾零");
        t = rt_str_of(rt_float(0.1 + 0.2));
        check(strcmp(t, "0.3") == 0, "显示：0.1+0.2 显示 0.3");
        t = rt_str_of(rt_bool(1));
        check(strcmp(t, "true") == 0, "显示：true");
        t = rt_str_of(rt_none());
        check(strcmp(t, "空") == 0, "显示：none 显示\"空\"");
        t = rt_str_of(rt_str("abc"));
        check(strcmp(t, "abc") == 0, "显示：str 原样");
        Value lst = rt_list_new();
        rt_push(&lst, rt_int(1));
        rt_push(&lst, rt_str("a"));
        rt_push(&lst, rt_bool(1));
        t = rt_str_of(lst);
        check(strcmp(t, "[1, a, true]") == 0, "显示：列表深度展开");
        Value nest = rt_list_new();
        rt_push(&nest, rt_int(2));
        rt_push(&nest, rt_int(3));
        Value outer = rt_list_new();
        rt_push(&outer, rt_int(1));
        rt_push(&outer, nest);
        t = rt_str_of(outer);
        check(strcmp(t, "[1, [2, 3]]") == 0, "显示：嵌套列表");
        t = rt_str_of(rt_obj_new("狗"));
        check(strcmp(t, "[狗 对象]") == 0, "显示：对象");
        /* show_value 原样返回该值（行缓冲随后由 show_end 收尾，不留残段） */
        char got1[64];
        capture_start();
        int shown = rt_cond(rt_show_value(rt_int(1)));
        rt_show_end();
        capture_finish(got1, sizeof got1);
        check(shown == 1 && strcmp(got1, "1\n") == 0, "显示：show_value 原样返回该值");

        /* show 行缓冲 + magic：普通行不带重置序列，magic 行带 */
        char got[512];
        capture_start();
        rt_show_value(rt_int(42));
        rt_show_end();
        capture_finish(got, sizeof got);
        check(strcmp(got, "42\n") == 0, "显示：普通行不加 \\033[0m（按规范只输出换行）");

        capture_start();
        rt_magic("b,c=255,0,0");
        rt_show_text("hi");
        rt_show_end();
        capture_finish(got, sizeof got);
        check(strcmp(got, "\033[1m\033[38;2;255;0;0mhi\033[0m\n") == 0,
              "显示：magic(b,c=) 输出转义序列并在行尾重置");

        capture_start();
        rt_magic("");
        rt_show_end();
        capture_finish(got, sizeof got);
        check(strcmp(got, "\033[0m\n") == 0, "显示：空 magic 也算用过（行尾重置）");

        capture_start();
        rt_magic("f.宋体,fs.16,bk=0,0,0");
        rt_show_text("字");
        rt_show_end();
        capture_finish(got, sizeof got);
        check(strcmp(got, "\033[48;2;0;0;0m字\033[0m\n") == 0,
              "显示：f./fs. 在终端接受并忽略，bk= 生效");

        /* 右对齐：COLUMNS=20，可见宽度 2 → 补 18 空格 */
        _putenv("COLUMNS=20");
        capture_start();
        rt_magic("fr");
        rt_show_text("ab");
        rt_show_end();
        capture_finish(got, sizeof got);
        check(strcmp(got, "                  ab\033[0m\n") == 0, "显示：fr 右对齐按 COLUMNS 补空格");

        /* 居中对齐（沿用 COLUMNS=20：可见宽度 2 → 左补 9 空格） */
        capture_start();
        rt_magic("fm");
        rt_show_text("ab");
        rt_show_end();
        capture_finish(got, sizeof got);
        check(strcmp(got, "         ab\033[0m\n") == 0, "显示：fm 居中");
        _putenv("COLUMNS=80");
    }

    /* ================= 输入 ================= */
    {
        FILE *in = fopen("_rt_in.tmp", "wb");
        if (in) {
            fputs("42\n  -7 \n3.5\nabc 12\n", in);
            fclose(in);
        }
        char got[256];
        capture_start();
        freopen("_rt_in.tmp", "r", stdin);
        Value a = rt_input("n?");
        Value b = rt_input("");
        Value c = rt_input("f?");
        Value d = rt_input("s?");
        capture_finish(got, sizeof got);
        check(is_i(a, 42) && is_i(b, -7), "输入：整行数字按 int（含首尾空白）");
        check(is_f(c, 3.5), "输入：小数按 float");
        check(is_s(d, "abc 12"), "输入：非数字整行按字符串（保留原样）");
        check(strcmp(got, "n?f?s?") == 0, "输入：提示符输出、空提示符不输出");
        freopen("CONIN$", "r", stdin);   /* 还原控制台 stdin，释放临时文件 */
        remove("_rt_in.tmp");
    }

    /* ================= 容器（列表） ================= */
    {
        Value lst = rt_list_new();
        check(IS_LIST(lst) && is_i(rt_len(lst), 0), "列表：新建为空");
        for (int i = 1; i <= 10; i++)
            rt_push(&lst, rt_int(i));
        check(is_i(rt_len(lst), 10), "列表：push 自动扩容到 10 个");
        check(is_i(rt_index(lst, rt_int(0)), 1) && is_i(rt_index(lst, rt_int(9)), 10),
              "列表：下标读");
        check(is_i(rt_index(lst, rt_int(-1)), 10), "列表：负下标从尾数");
        rt_setindex(&lst, rt_int(4), rt_int(99));
        check(is_i(rt_index(lst, rt_int(4)), 99), "列表：下标写");
        check(is_s(rt_index(rt_str("你好a"), rt_int(1)), "好"), "列表：字符串按 UTF-8 字符取");
        check(is_i(rt_len(rt_str("中文ab")), 4), "列表：字符串长度按 UTF-8 字符");

        Value nums = rt_list_new();
        rt_push(&nums, rt_int(3));
        rt_push(&nums, rt_int(1));
        rt_push(&nums, rt_float(2.5));
        rt_push(&nums, rt_int(2));
        rt_list_sort(nums);
        check(is_i(rt_index(nums, rt_int(0)), 1) && is_i(rt_index(nums, rt_int(1)), 2) &&
              is_f(rt_index(nums, rt_int(2)), 2.5) && is_i(rt_index(nums, rt_int(3)), 3),
              "列表：sort 数字混型按值（原地，元素类型保留）");
        Value strs = rt_list_new();
        rt_push(&strs, rt_str("梨"));
        rt_push(&strs, rt_str("苹果"));
        rt_push(&strs, rt_str("白"));
        rt_list_sort(strs);
        /* 字典序 = UTF-8 字节序：梨(E6..) < 白(E7..) < 苹果(E8..) */
        check(is_s(rt_index(strs, rt_int(0)), "梨") && is_s(rt_index(strs, rt_int(2)), "苹果"),
              "列表：sort 字符串按字典序（UTF-8 字节序）");
        rt_list_reverse(nums);
        check(is_i(rt_index(nums, rt_int(0)), 3) && is_i(rt_index(nums, rt_int(3)), 1),
              "列表：reverse 原地倒序");

        Value dup = rt_list_new();
        rt_push(&dup, rt_int(1));
        rt_push(&dup, rt_int(1));
        rt_push(&dup, rt_str("a"));
        rt_push(&dup, rt_int(1));
        rt_push(&dup, rt_str("a"));
        Value uniq = rt_list_unique(dup);
        check(is_i(rt_len(uniq), 2) && is_i(rt_index(uniq, rt_int(0)), 1) &&
              is_s(rt_index(uniq, rt_int(1)), "a"),
              "列表：unique 深度判重保留首现");
        Value inner1 = rt_list_new(), inner2 = rt_list_new();
        rt_push(&inner1, rt_int(9));
        rt_push(&inner2, rt_int(9));
        Value dl = rt_list_new();
        rt_push(&dl, inner1);
        rt_push(&dl, inner2);
        rt_push(&dl, rt_int(7));
        check(is_i(rt_len(rt_list_unique(dl)), 2), "列表：unique 嵌套列表深度相等");

        Value m1 = rt_list_new(), m2 = rt_list_new();
        rt_push(&m1, rt_int(1));
        rt_push(&m1, rt_int(2));
        rt_push(&m2, rt_int(3));
        Value merged = rt_list_merge(m1, m2);
        check(is_i(rt_len(merged), 3) && is_i(rt_index(merged, rt_int(2)), 3),
              "列表：merge 先 a 后 b");

        check(is_i(rt_list_find(merged, rt_int(3)), 2) &&
              is_i(rt_list_find(merged, rt_int(9)), -1),
              "列表：find 命中/找不到 -1");
        check(is_i(rt_list_find(dl, inner2), 0), "列表：find 按深度相等匹配嵌套列表");

        check(is_i(rt_list_max(nums), 3) && is_i(rt_list_min(nums), 1),
              "列表：max/min 数字混型（返回原元素）");
        Value ss = rt_list_new();
        rt_push(&ss, rt_str("梨"));
        rt_push(&ss, rt_str("苹果"));
        check(is_s(rt_list_max(ss), "苹果"), "列表：max 字符串按字典序");
    }

    /* ================= 对象 ================= */
    {
        Value o = rt_obj_new("猫");
        rt_obj_set_prop(o, "名", rt_str("旺财"));
        rt_obj_set_prop(o, "岁", rt_int(2));
        check(is_s(rt_obj_get_prop(o, "名"), "旺财"), "对象：属性读写");
        rt_obj_set_prop(o, "名", rt_str("咪咪"));
        check(is_s(rt_obj_get_prop(o, "名"), "咪咪"), "对象：已有属性覆盖");
        check(strcmp(rt_obj_class_name(o), "猫") == 0, "对象：类名");
        check(is_i(rt_obj_get_prop(o, "岁"), 2), "对象：第二个属性完好");
        /* 引用语义：同一对象两个名字 */
        Value alias = o;
        rt_obj_set_prop(alias, "岁", rt_int(3));
        check(is_i(rt_obj_get_prop(o, "岁"), 3), "对象：引用语义（别名共享）");
    }

    /* ================= 锁定 / 删除（正常路径） ================= */
    {
        Value x = rt_int(1);
        rt_gold(&x);
        check(is_i(rt_chk(x), 1), "锁定：锁定后读取不受影响");
        check(slot_is_locked(&x), "锁定：槽已登记侧表");
        rt_gold(&x);   /* 重复锁定应幂等 */
        check(g_nlocks >= 1, "锁定：重复 gold 幂等");

        Value y = rt_int(7);
        Value copy = y;
        rt_destroy(&y);
        check(IS_DEL(y) && RT_TYPE(y) == 7, "删除：槽改写为 DELETED 位样");
        check(is_i(copy, 7), "删除：删除前拷走的旧拷贝不受影响");
        check(is_i(rt_chk(copy), 7), "删除：旧拷贝仍可正常使用");

        /* @self 模式真释放 + 别名登记表不 double-free */
        rt_set_memmode(1);
        Value s = rt_str("手动管理的字符串");
        Value alias = s;
        rt_destroy(&s);
        rt_destroy(&alias);   /* 同一块内存的第二次 delete：登记表命中，只标记 */
        check(IS_DEL(s) && IS_DEL(alias), "删除：@self 别名二次 delete 不崩溃");
        Value lst = rt_list_new();
        rt_push(&lst, rt_str("元素"));
        rt_destroy(&lst);     /* 释放列表结构 + items 数组 */
        check(IS_DEL(lst), "删除：@self 列表释放");
        rt_set_memmode(0);

        /* ---- @3 引用计数：归零即回收；容器持有元素不被回收 ---- */
        rt_set_memmode(3);
        {
            size_t b = rt_mem_stats(NULL);
            Value a = rt_str("引用计数");
            check(rt_mem_stats(NULL) == b + 1, "@3：新串登记为 1 个单元");
            rt_release(a);                    /* 交出构造时的那份引用 */
            check(rt_mem_stats(NULL) == b, "@3：引用归零立即回收");

            Value lst2 = rt_list_new();
            Value e = rt_str("元素");
            rt_push(&lst2, e);                /* 列表持有 → 元素 +1 */
            rt_release(e);                    /* 交出构造那份，列表仍持有 */
            check(rt_mem_stats(NULL) == b + 2, "@3：列表持有元素，元素不被回收");
            rt_release(lst2);                 /* 列表回收 → 连带释放元素 */
            check(rt_mem_stats(NULL) == b, "@3：列表回收时连带释放其元素");
        }
        rt_set_memmode(0);

        /* ---- @4 竞技场：整块分配、整块归还 ---- */
        rt_set_memmode(4);
        {
            size_t b = rt_mem_stats(NULL);
            for (int i = 0; i < 100; i++) {
                Value t = rt_str("竞技场");
                (void)t;
            }
            check(rt_mem_stats(NULL) == b + 100, "@4：竞技场分配 100 个单元");
            rt_arena_reset();
            check(rt_mem_stats(NULL) == b, "@4：整块归还后块内单元全部消失");
        }
        rt_set_memmode(0);

        /* ---- @5 标记清除：回收不可达、保留可达 ---- */
        rt_set_memmode(5);
        {
            Value root = rt_none();
            rt_scope_enter();
            rt_root_add(&root);
            rt_gc();                          /* 先归一化：清掉此前遗留的不可达单元 */
            size_t b = rt_mem_stats(NULL);
            for (int i = 0; i < 50; i++) {
                Value g = rt_str("不可达");
                (void)g;                      /* 没登记为根 → 垃圾 */
            }
            check(rt_mem_stats(NULL) == b + 50, "@5：50 个不可达对象已分配");
            rt_gc();
            check(rt_mem_stats(NULL) == b, "@5：GC 回收全部不可达对象");
            rt_assign(&root, rt_str("可达"));
            rt_gc();
            check(rt_mem_stats(NULL) == b + 1, "@5：可达对象应被保留");
            rt_scope_leave();
        }
        rt_set_memmode(0);

        /* ---- @6 分代 + 增量：minor GC、晋升、写屏障 ---- */
        rt_set_memmode(6);
        {
            Value root = rt_none();
            Value lst3 = rt_none();
            rt_scope_enter();
            rt_root_add(&root);
            rt_root_add(&lst3);
            gc_minor();                       /* 先归一化：清掉此前遗留的年轻单元 */
            size_t b = rt_mem_stats(NULL);
            for (int i = 0; i < 20; i++) {
                Value g = rt_str("新生代垃圾");
                (void)g;
            }
            rt_assign(&root, rt_str("存活对象"));
            rt_assign(&lst3, rt_list_new());
            gc_minor();                       /* 只清新生代 */
            check(rt_mem_stats(NULL) == b + 2, "@6：minor GC 清掉新生代垃圾、保留根可达对象");
            check(cell_of(root)->gen == 1, "@6：存活对象晋升老年代");
            check(cell_of(lst3)->gen == 1, "@6：存活列表晋升老年代");

            /* 写屏障：老年代列表放进新生代对象，minor GC 不该把它收走 */
            Value y = rt_str("新生代元素");
            rt_push(&lst3, y);                /* old→young：触发写屏障 */
            gc_minor();
            check(rt_mem_stats(NULL) == b + 3, "@6：写屏障保住 old→young 引用");
            check(cell_of(rt_index(lst3, rt_int(0)))->kind == RTK_STR, "@6：该元素仍可读");

            check(rt_gc_step() == 0, "@6：空闲时增量步进无事可做");
            rt_scope_leave();
        }
        rt_set_memmode(0);
    }

    /* ================= 网页缓冲 ================= */
    {
        rt_page_begin("我的<页面>");
        rt_page_para_open("b,c=200,100,0");
        rt_page_text("分数：");
        rt_page_value(rt_int(42));
        rt_page_para_close();
        rt_page_para_open("");
        rt_page_text("5<6 & \"引号\"");
        rt_page_para_close();
        rt_page_h("标题", 1);
        rt_page_img("<猫>.png");
        rt_page_hr();
        rt_page_link("点>我", "a&b");
        check(g_page != NULL && strcmp(g_page,
              "<!DOCTYPE html>\n<html lang=\"zh\">\n<head>\n"
              "<meta charset=\"utf-8\">\n<title>我的&lt;页面&gt;</title>\n"
              "<style>\n"
              "body{background:#1e1e2e;color:#cdd6f4;"
              "font-family:\"Microsoft YaHei UI\",sans-serif;"
              "padding:40px;line-height:1.6}\n"
              "a{color:#89dceb}\n"
              "</style>\n</head>\n<body>\n"
              "<p style=\"font-weight:bold; color:rgb(200,100,0)\">\n"
              "分数：42</p>\n"
              "<p>\n"
              "5&lt;6 &amp; &quot;引号&quot;</p>\n"
              "<h1>标题</h1>\n"
              "<img src=\"&lt;猫&gt;.png\">\n"
              "<hr>\n"
              "<a href=\"a&amp;b\">点&gt;我</a>\n") == 0,
              "网页：骨架 + 样式翻译 + 全量 HTML 转义");
        rt_page_para_open("i,bk=0,0,0,fs.14,fm,f.楷体");
        check(strstr(g_page, "<p style=\"font-style:italic; background-color:rgb(0,0,0); "
                              "font-size:14px; text-align:center; font-family:'楷体'\">") != NULL,
              "网页：i/bk/fs/fm/f. 全套 token 翻译成 CSS");
        rt_page_para_close();
        rt_page_save();
        check(g_page_len == 0 && !g_page_begun, "网页：save 后缓冲清空可复用");
        /* 落盘内容 = 缓冲 + 骨架尾 */
        FILE *fp = fopen("pybook_page.html", "rb");
        int file_ok = 0;
        if (fp) {
            char buf[4096];
            size_t n = fread(buf, 1, sizeof buf - 1, fp);
            buf[n] = '\0';
            fclose(fp);
            file_ok = strcmp(buf,
                     "<!DOCTYPE html>\n<html lang=\"zh\">\n<head>\n"
                     "<meta charset=\"utf-8\">\n<title>我的&lt;页面&gt;</title>\n"
                     "<style>\n"
                     "body{background:#1e1e2e;color:#cdd6f4;"
                     "font-family:\"Microsoft YaHei UI\",sans-serif;"
                     "padding:40px;line-height:1.6}\n"
                     "a{color:#89dceb}\n"
                     "</style>\n</head>\n<body>\n"
                     "<p style=\"font-weight:bold; color:rgb(200,100,0)\">\n"
                     "分数：42</p>\n"
                     "<p>\n"
                     "5&lt;6 &amp; &quot;引号&quot;</p>\n"
                     "<h1>标题</h1>\n"
                     "<img src=\"&lt;猫&gt;.png\">\n"
                     "<hr>\n"
                     "<a href=\"a&amp;b\">点&gt;我</a>\n"
                     "<p style=\"font-style:italic; background-color:rgb(0,0,0); "
                     "font-size:14px; text-align:center; font-family:'楷体'\">\n"
                     "</p>\n"
                     "</body>\n</html>\n") == 0;
        }
        check(file_ok, "网页：save 落盘内容完整（UTF-8 二进制写）");
        remove("pybook_page.html");   /* 测试产物不留在工作区 */
    }

    /* ================= 随机（链接进来的 rd 模块） ================= */
    {
        int in_range = 1, saw_lo = 0, saw_hi = 0;
        for (int i = 0; i < 2000; i++) {
            Value r = rt_lib_rd_int(rt_int(3), rt_int(7));
            long long x = rt_to_ll(r);
            if (x < 3 || x > 7)
                in_range = 0;
            if (x == 3) saw_lo = 1;
            if (x == 7) saw_hi = 1;
        }
        check(in_range, "随机：2000 次 rd.int 都在 [3,7]");
        check(saw_lo && saw_hi, "随机：rd.int 含两端");
        Value rf = rt_lib_rd_float();
        check(IS_FLT(rf) && AS_FLT(rf) >= 0.0 && AS_FLT(rf) < 1.0, "随机：rd.float 在 [0,1)");
        Value pool = rt_list_new();
        rt_push(&pool, rt_int(10));
        rt_push(&pool, rt_int(20));
        int pick_ok = 1;
        for (int i = 0; i < 100; i++) {
            Value p = rt_lib_rd_pick(pool);
            if (!is_i(p, 10) && !is_i(p, 20))
                pick_ok = 0;
        }
        check(pick_ok, "随机：rd.pick 取自原列表");
        Value deck = rt_list_new();
        for (int i = 1; i <= 6; i++)
            rt_push(&deck, rt_int(i));
        rt_lib_rd_shuffle(deck);
        long long sum = 0;
        for (long long i = 0; i < 6; i++)
            sum += rt_to_ll(rt_index(deck, rt_int(i)));
        check(sum == 21, "随机：rd.shuffle 元素集合不变");
    }

    /* ================= 标准库冒烟（te/mt） ================= */
    {
        Value parts = rt_lib_te_split(rt_str("a,b,c"), rt_str(","));
        check(is_i(rt_len(parts), 3) && is_s(rt_index(parts, rt_int(2)), "c"), "te：split");
        check(is_f(rt_lib_mt_sqrt(rt_int(144)), 12.0), "mt：sqrt(144)=12");
        check(is_f(rt_lib_mt_pi(), 3.14159265358979), "mt：pi");
    }

    /* ================= 文件模块冒烟（file） ================= */
    {
        Value path = rt_str("_rt_file.tmp");
        rt_file_write(path, rt_str("第一行\n第二行"));
        check(rt_cond(rt_file_exists(path)) != 0, "file：写后存在");
        check(is_s(rt_file_read(path), "第一行\n第二行"), "file：读回原文");
        Value lines = rt_file_lines(path);
        check(is_i(rt_len(lines), 2) && is_s(rt_index(lines, rt_int(1)), "第二行"),
              "file：按行切分");
        rt_file_del(path);
        check(rt_cond(rt_file_exists(path)) == 0, "file：删除后不存在");
    }

    /* ================= 报错分支（子进程验证） ================= */
    {
        for (int i = 0; i < (int)(sizeof g_errtab / sizeof g_errtab[0]); i++)
            expect_die(argv[0], i);
    }

    printf("\n自测：通过 %d 项，失败 %d 项\n", g_pass, g_fails);
    if (g_fails == 0)
        printf("自测全部通过。\n");
    else
        printf("自测失败 %d 项！\n", g_fails);
    return g_fails ? 1 : 0;
}
#endif /* RT_SELF_TEST */

/* rm.around 循环辅助 */
long long rt_loop_count(Value v)
{
    if (IS_INT(v))
        return AS_INT(v);
    if (IS_BOOL(v))
        return AS_BOOL(v);
    if (IS_FLT(v)) {
        double f = AS_FLT(v);
        if (f == (long long)f)
            return (long long)f;
    }
    rt_die("rm.around 次数不是整数");
    return 0;
}

Value rt_at(long long i)
{
    return rt_int(i);
}

