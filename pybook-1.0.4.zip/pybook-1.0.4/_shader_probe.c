/* 可编程管线验证探针：不看"编译是否通过"，看"画面是否真的变了"。
 *
 * 做法：
 *   1. 真开 GL 上下文，摆一个盒子+球+柱+线 的场景；
 *   2. 固定管线渲一帧 → glReadPixels 读回像素 → 算指纹；
 *   3. 逐个内置着色器各渲一帧 → 读回 → 算指纹；
 *   4. 指纹不同 = 着色器真的在起作用（不是"编译通过了但根本没绑上"）。
 *   5. 额外测 hw.shader 的内联源码路径：故意用"两字符 \n"写多行 GLSL，
 *      把 hw_unfold 也一起验了 —— 如果折叠没生效，#version 120 后面会
 *      跟一坨同行垃圾，编译必然失败、返回 0。
 *
 * 链接要求（和最终 exe 对齐）：
 *   gcc -DRT_GAME_SDL -DMP_RT_BINDING ... probe.c rt_cache/ (所有 .sdl.o)
 *       -lSDL2 -lwinmm -lws2_32 -lopengl32
 */
#include "pybook_rt.h"
#include <stdio.h>
#include <string.h>
#include <GL/gl.h>

Value rt_hw_open(Value, Value, Value);
Value rt_hw_clearcolor(Value, Value, Value);
Value rt_hw_camera(Value, Value, Value, Value, Value);
Value rt_hw_box(Value, Value, Value, Value, Value, Value, Value, Value, Value);
Value rt_hw_sphere(Value, Value, Value, Value, Value, Value, Value);
Value rt_hw_cylv(int, Value *);
Value rt_hw_line(Value, Value, Value, Value, Value, Value, Value, Value, Value);
Value rt_hw_light(Value, Value, Value, Value);
Value rt_hw_preset(Value, Value);
Value rt_hw_shader(Value, Value, Value);
Value rt_hw_shaderuse(Value);
Value rt_hw_univ(int, Value *);
Value rt_hw_frame(void);

#define W 240
#define H 180

static unsigned char g_buf[W * H * 4];

static void 布景(void);   /* 定义在后面 */

/* 读回一帧的像素并算指纹。
   注意 SwapBuffers 的语义：交换后"新的后缓冲"里其实是上一帧的画面，
   所以直接读 GL_BACK 拿到的是**上一帧**。这里先清空累积的 GL 错误，
   再由调用方连渲两帧同样的内容，读到的就是当前配置的画面。 */
static unsigned long long 取指纹(const char *标签)
{
    GLenum e = GL_NO_ERROR, e0 = GL_NO_ERROR;
    while ((e = glGetError()) != GL_NO_ERROR)   /* 排干渲染期攒下的错误 */
        if (e0 == GL_NO_ERROR) e0 = e;

    memset(g_buf, 0, sizeof g_buf);
    glReadBuffer(GL_BACK);
    glPixelStorei(GL_PACK_ALIGNMENT, 1);
    glReadPixels(0, 0, W, H, GL_RGBA, GL_UNSIGNED_BYTE, g_buf);

    unsigned long long h = 1469598103934665603ULL;   /* FNV-1a */
    long r = 0, g = 0, b = 0;
    for (int i = 0; i < W * H * 4; i += 4) {
        r += g_buf[i];
        g += g_buf[i + 1];
        b += g_buf[i + 2];
        h ^= g_buf[i];      h *= 1099511628211UL;
        h ^= g_buf[i + 1];  h *= 1099511628211UL;
        h ^= g_buf[i + 2];  h *= 1099511628211UL;
    }
    int n = W * H;
    printf("  %-22s 指纹=%016llx  均色=(%3ld,%3ld,%3ld)  glErr=%s\n",
           标签, h, r / n, g / n, b / n,
           e0 == GL_NO_ERROR ? "无" : (e0 == GL_INVALID_OPERATION ? "GL_INVALID_OPERATION" :
                                       e0 == GL_INVALID_ENUM ? "GL_INVALID_ENUM" :
                                       e0 == GL_INVALID_VALUE ? "GL_INVALID_VALUE" : "有!"));
    return h;
}

/* 连渲两帧同样的内容再读回 —— 抵消 SwapBuffers 的"后缓冲滞后一帧"。 */
static unsigned long long 一帧取指纹(const char *标签)
{
    布景();
    rt_hw_frame();
    布景();
    rt_hw_frame();
    return 取指纹(标签);
}

/* 每帧都要重新提交场景（帧末会清图元表） */
static void 布景(void)
{
    rt_hw_clearcolor(rt_int(18), rt_int(22), rt_int(34));
    rt_hw_camera(rt_int(12), rt_int(7), rt_int(12), rt_float(3.9), rt_float(-0.5));
    rt_hw_light(rt_float(0.5), rt_float(1.0), rt_float(0.4), rt_float(1.0));

    rt_hw_box(rt_int(-2), rt_int(-1), rt_int(-2), rt_int(4), rt_int(4), rt_int(4),
              rt_int(220), rt_int(90), rt_int(70));
    rt_hw_sphere(rt_int(4), rt_int(1), rt_int(0), rt_int(2),
                 rt_int(120), rt_int(180), rt_int(255));
    Value cyl[9] = { rt_int(0), rt_int(-1), rt_int(4), rt_float(1.5), rt_int(3), rt_float(1.5),
                     rt_int(80), rt_int(220), rt_int(140) };
    rt_hw_cylv(9, cyl);
    rt_hw_line(rt_int(-6), rt_int(0), rt_int(0), rt_int(6), rt_int(0), rt_int(0),
               rt_int(255), rt_int(60), rt_int(60));
}

/* 内联着色器：故意用两字符 \n 写多行，验 hw_unfold。
   还顺手用了 hw.uni 设的 uBoost。 */
static const char *内联VS =
    "#version 120\\n"
    "varying vec3 vN;\\n"
    "varying vec3 vC;\\n"
    "varying vec2 vUV;\\n"
    "void main(){\\n"
    "  vN = gl_NormalMatrix * gl_Normal;\\n"
    "  vC = gl_Color.rgb;\\n"
    "  vUV = gl_MultiTexCoord0.xy;\\n"
    "  gl_Position = gl_ModelViewProjectionMatrix * gl_Vertex;\\n"
    "}\\n";
static const char *内联FS =
    "#version 120\\n"
    "varying vec3 vN;\\n"
    "varying vec3 vC;\\n"
    "varying vec2 vUV;\\n"
    "uniform vec3 uLight;\\n"
    "uniform float uBoost;\\n"
    "void main(){\\n"
    "  float d = max(dot(normalize(vN), normalize(uLight)), 0.0);\\n"
    "  vec3 alb = mix(vec3(0.1, 0.2, 0.6), vC, d);\\n"
    "  gl_FragColor = vec4(alb * uBoost, 1.0);\\n"
    "}\\n";

int main(void)
{
    rt_hw_open(rt_int(W), rt_int(H), rt_str("GLSL probe"));
    printf("GL_VERSION %s\n", (const char *)glGetString(GL_VERSION));

    /* ---------- ① 固定管线打底 ---------- */
    printf("\n=== ① 固定管线（不指定着色器，老路径）===\n");
    unsigned long long 基准 = 一帧取指纹("固定管线");

    /* ---------- ② 六个内置着色器 ---------- */
    printf("\n=== ② 内置着色器（hw.preset）===\n");
    const char *名字[] = { "lambert", "toon", "fresnel", "checker", "normal", "unlit" };
    unsigned long long 指纹[6];
    for (int i = 0; i < 6; i++) {
        Value r = rt_hw_preset(rt_int(1), rt_str(名字[i]));
        if (rt_to_ll(r) != 1) {
            printf("  %-22s ** 装载失败 **\n", 名字[i]);
            指纹[i] = 0;
            continue;
        }
        rt_hw_shaderuse(rt_int(1));
        指纹[i] = 一帧取指纹(名字[i]);
    }
    /* 不存在的名字必须返回 0 且不崩 */
    Value bad = rt_hw_preset(rt_int(2), rt_str("__不存在的预设__"));
    printf("  %-22s 返回 %lld（期望 0）\n", "不存在的预设", rt_to_ll(bad));

    /* ---------- ③ 内联源码 + hw.uni ---------- */
    printf("\n=== ③ hw.shader 内联源码（验 \\n 折叠）+ hw.uni ===\n");
    Value ok = rt_hw_shader(rt_int(3), rt_str(内联VS), rt_str(内联FS));
    printf("  hw.shader 返回 %lld（期望 1 —— 折叠没生效就会编译失败）\n", rt_to_ll(ok));
    unsigned long long 内联指纹1 = 0, 内联指纹2 = 0;
    if (rt_to_ll(ok) == 1) {
        rt_hw_shaderuse(rt_int(3));
        Value u1[2] = { rt_str("uBoost"), rt_float(1.0) };
        rt_hw_univ(2, u1);
        内联指纹1 = 一帧取指纹("内联 uBoost=1.0");

        rt_hw_shaderuse(rt_int(3));
        Value u2[2] = { rt_str("uBoost"), rt_float(4.0) };
        rt_hw_univ(2, u2);
        内联指纹2 = 一帧取指纹("内联 uBoost=4.0");
    }

    /* ---------- ④ 中途切回固定管线 ---------- */
    printf("\n=== ④ hw.shaderuse(0) 中场回固定管线 ===\n");
    rt_hw_shaderuse(rt_int(0));
    unsigned long long 回退 = 一帧取指纹("切回固定管线");

    /* ---------- 结论 ---------- */
    printf("\n================ 结论 ================\n");
    int 变了几张 = 0;
    for (int i = 0; i < 6; i++)
        if (指纹[i] != 0 && 指纹[i] != 基准)
            变了几张++;
    printf("  六个内置着色器：%d/6 与固定管线画面不同\n", 变了几张);
    printf("  内联着色器 uBoost 1.0 vs 4.0 %s\n",
           内联指纹1 != 内联指纹2 ? "不同 → hw.uni 生效 ✓" :
           (内联指纹1 == 0 ? "没测成" : "相同 → **hw.uni 没生效**"));
    printf("  shaderuse(0) 切回后 %s固定管线画面\n",
           回退 == 基准 ? "复现原样 ✓" : "**和原样不同**");
    printf("  判定：%s\n",
           (变了几张 >= 1 && 内联指纹1 != 内联指纹2 && 回退 == 基准)
               ? "可编程管线链路完整 ✓" : "**有问题，看上面**");
    return 0;
}
