/* PYbook 标准库实现：te（文本）/ mt（数学）/ rd（随机）。
 * 接口见 pybook_lib.h；只依赖 pybook_rt 与 C99 标准库。 */

#include "pybook_lib.h"

#include <limits.h>
#include <math.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <windows.h>

/* ================= 内部工具 ================= */

/* 运行时错误出口：格式与 pybook_rt 的 rt_die 一致 */
static void lib_die(const char *fmt, ...)
{
    va_list ap;
    fprintf(stderr, "运行时错误: ");
    va_start(ap, fmt);
    vfprintf(stderr, fmt, ap);
    va_end(ap);
    fputc('\n', stderr);
    exit(1);
}

/* 参数类型检查：文本 / 整数 / 数字 */
static const char *lib_str(Value v, const char *who)
{
    if (!IS_STR(v))
        lib_die("%s 需要文本参数", who);
    return AS_STR(v);
}

static long long lib_ll(Value v, const char *who)
{
    if (IS_INT(v) || IS_BIGINT(v))
        return rt_to_ll(v);
    if (IS_BOOL(v))
        return (long long)AS_BOOL(v);
    lib_die("%s 需要整数参数", who);
    return 0;
}

static double lib_num(Value v, const char *who)
{
    if (IS_FLT(v))
        return AS_FLT(v);
    if (IS_INT(v) || IS_BIGINT(v))
        return (double)rt_to_ll(v);
    if (IS_BOOL(v))
        return (double)AS_BOOL(v);
    lib_die("%s 需要数字参数", who);
    return 0;
}

/* [a, b) 字节区间 → 字符串盒（临时缓冲拷给 rt_str 后即释放） */
static Value lib_val_range(const char *a, const char *b)
{
    size_t n = (size_t)(b - a);
    char *tmp = (char *)malloc(n + 1);
    if (tmp == NULL)
        lib_die("内存不足");
    memcpy(tmp, a, n);
    tmp[n] = '\0';
    Value v = rt_str(tmp);
    free(tmp);
    return v;
}

/* 可增长字节缓冲（scratch 用完即释放） */
typedef struct {
    char  *p;
    size_t len, cap;
} Buf;

static void buf_put(Buf *b, const char *s, size_t n)
{
    if (b->len + n + 1 > b->cap) {
        while (b->len + n + 1 > b->cap)
            b->cap = b->cap * 2 + 64;
        b->p = (char *)realloc(b->p, b->cap);
        if (b->p == NULL)
            lib_die("内存不足");
    }
    memcpy(b->p + b->len, s, n);
    b->len += n;
    b->p[b->len] = '\0';
}

static void buf_puts(Buf *b, const char *s)
{
    buf_put(b, s, strlen(s));
}

/* ---------- UTF-8 按字符计数与定位（首字节计数法） ---------- */

static long long utf8_count(const char *s)
{
    long long n = 0;
    while (*s) {
        if (((unsigned char)*s & 0xC0) != 0x80)
            n++;
        s++;
    }
    return n;
}

/* 从 s 向后跳过 chars 个字符，返回落点指针 */
static const char *utf8_at(const char *s, long long chars)
{
    long long n = 0;
    while (*s) {
        if (((unsigned char)*s & 0xC0) != 0x80) {
            if (n == chars)
                break;          /* 已落在第 chars 个字符的首字节 */
            n++;
        }
        s++;                    /* 后续字节（含上一字符的 continuation）一律跳过 */
    }
    return s;
}

/* ---------- 列表公共辅助 ---------- */

static long long lib_list_len(Value list, const char *who)
{
    if (!IS_LIST(list))
        lib_die("%s 需要列表参数", who);
    return AS_INT(rt_len(list));
}

static int lib_is_num(Value v)
{
    return IS_INT(v) || IS_BIGINT(v) || IS_FLT(v) || IS_BOOL(v);
}

/* ================= te 文本模块 ================= */

Value rt_lib_te_split(Value textv, Value sepv)
{
    const char *s   = lib_str(textv, "te.split 第 1 个参数");
    const char *sep = lib_str(sepv,  "te.split 第 2 个参数");
    size_t seplen = strlen(sep);
    if (seplen == 0)
        lib_die("te.split 的分隔符不能为空");
    Value out = rt_list_new();
    const char *p = s;
    for (;;) {
        const char *hit = strstr(p, sep);
        if (hit == NULL) {
            rt_push(&out, rt_str(p));
            break;
        }
        rt_push(&out, lib_val_range(p, hit));
        p = hit + seplen;
    }
    return out;
}

Value rt_lib_te_replace(Value textv, Value oldv, Value newv)
{
    const char *s   = lib_str(textv, "te.replace 第 1 个参数");
    const char *old = lib_str(oldv,  "te.replace 第 2 个参数");
    const char *nw  = lib_str(newv,  "te.replace 第 3 个参数");
    size_t oldlen = strlen(old);
    if (oldlen == 0)
        lib_die("te.replace 的旧串不能为空");
    Buf b = {NULL, 0, 0};
    const char *p = s;
    for (;;) {
        const char *hit = strstr(p, old);
        if (hit == NULL)
            break;
        buf_put(&b, p, (size_t)(hit - p));
        buf_puts(&b, nw);
        p = hit + oldlen;
    }
    buf_puts(&b, p);
    Value v = rt_str(b.p ? b.p : "");
    free(b.p);
    return v;
}

Value rt_lib_te_trim(Value textv)
{
    const char *s = lib_str(textv, "te.trim");
    const char *WS_SET = " \t\r\n\v\f";
    size_t lead = strspn(s, WS_SET);
    size_t len = strlen(s);
    while (len > lead && strchr(WS_SET, s[len - 1]) != NULL)
        len--;
    return lib_val_range(s + lead, s + len);
}

Value rt_lib_te_upper(Value textv)
{
    const char *s = lib_str(textv, "te.upper");
    char *tmp = (char *)malloc(strlen(s) + 1);
    if (tmp == NULL)
        lib_die("内存不足");
    for (size_t i = 0; s[i]; i++) {
        unsigned char c = (unsigned char)s[i];
        tmp[i] = (char)((c >= 'a' && c <= 'z') ? c - 'a' + 'A' : c);
    }
    tmp[strlen(s)] = '\0';
    Value v = rt_str(tmp);
    free(tmp);
    return v;
}

Value rt_lib_te_lower(Value textv)
{
    const char *s = lib_str(textv, "te.lower");
    char *tmp = (char *)malloc(strlen(s) + 1);
    if (tmp == NULL)
        lib_die("内存不足");
    for (size_t i = 0; s[i]; i++) {
        unsigned char c = (unsigned char)s[i];
        tmp[i] = (char)((c >= 'A' && c <= 'Z') ? c - 'A' + 'a' : c);
    }
    tmp[strlen(s)] = '\0';
    Value v = rt_str(tmp);
    free(tmp);
    return v;
}

Value rt_lib_te_has(Value textv, Value subv)
{
    const char *s   = lib_str(textv, "te.has 第 1 个参数");
    const char *sub = lib_str(subv,  "te.has 第 2 个参数");
    return rt_bool(strstr(s, sub) != NULL);
}

Value rt_lib_te_len(Value textv)
{
    const char *s = lib_str(textv, "te.len");
    return rt_int(utf8_count(s));
}

Value rt_lib_te_cut(Value textv, Value startv, Value stopv)
{
    const char *s   = lib_str(textv, "te.cut 第 1 个参数");
    long long start = lib_ll(startv, "te.cut 第 2 个参数");
    long long stop  = lib_ll(stopv,  "te.cut 第 3 个参数");
    long long total = utf8_count(s);
    if (start < 0 || stop < start || stop > total)
        lib_die("te.cut 范围越界：文本共 %lld 字，要求 [%lld, %lld)",
                total, start, stop);
    const char *a = utf8_at(s, start);
    const char *b = utf8_at(a, stop - start);
    return lib_val_range(a, b);
}

Value rt_lib_te_join(Value listv, Value sepv)
{
    long long n     = lib_list_len(listv, "te.join 第 1 个参数");
    const char *sep = lib_str(sepv, "te.join 第 2 个参数");
    Buf b = {NULL, 0, 0};
    for (long long i = 0; i < n; i++) {
        if (i > 0)
            buf_puts(&b, sep);
        buf_puts(&b, rt_str_of(rt_index(listv, rt_int(i))));
    }
    Value v = rt_str(b.p ? b.p : "");
    free(b.p);
    return v;
}

/* ================= mt 数学模块 ================= */

Value rt_lib_mt_sqrt(Value n)
{
    double x = lib_num(n, "mt.sqrt");
    if (x < 0)
        lib_die("mt.sqrt：负数没有平方根");
    return rt_float(sqrt(x));
}

Value rt_lib_mt_pow(Value basev, Value expv)
{
    double b = lib_num(basev, "mt.pow 第 1 个参数");
    double e = lib_num(expv,  "mt.pow 第 2 个参数");
    return rt_float(pow(b, e));
}

Value rt_lib_mt_abs(Value n)
{
    if (IS_INT(n)) {
        if (AS_INT(n) < 0) {
            if (AS_INT(n) == LLONG_MIN)
                lib_die("溢出");
            return rt_int(-AS_INT(n));
        }
        return rt_int(AS_INT(n));
    }
    if (IS_FLT(n))
        return rt_float(fabs(AS_FLT(n)));
    if (IS_BOOL(n))
        return rt_int(AS_BOOL(n));
    lib_die("mt.abs 需要数字参数");
    return rt_none();
}

static long long lib_round_to_ll(double x, const char *who)
{
    if (!(x > -9.3e18 && x < 9.3e18))
        lib_die("%s：结果超出整数范围", who);
    return (long long)x;
}

Value rt_lib_mt_ceil(Value n)
{
    return rt_int(lib_round_to_ll(ceil(lib_num(n, "mt.ceil")), "mt.ceil"));
}

Value rt_lib_mt_floor(Value n)
{
    return rt_int(lib_round_to_ll(floor(lib_num(n, "mt.floor")), "mt.floor"));
}

Value rt_lib_mt_mod(Value a, Value b)
{
    return rt_mod(a, b);              /* 复用运行时：Python 语义 + 除零检查 */
}

/* 数字列表的三种折叠：kind 0=max 1=min 2=prod，max/min 返回原元素 */
static Value lib_list_fold(Value listv, const char *who, int kind)
{
    long long n = lib_list_len(listv, who);
    if (n == 0) {
        if (kind == 3)
            return rt_int(0);            /* 空列表求和 = 0 */
        lib_die("%s：空列表", who);
    }
    Value acc = (kind == 3) ? rt_int(0) : rt_index(listv, rt_int(0));
    if (!lib_is_num(acc))
        lib_die("%s：列表元素必须全是数字", who);
    for (long long i = (kind == 3) ? 0 : 1; i < n; i++) {
        Value cur = rt_index(listv, rt_int(i));
        if (!lib_is_num(cur))
            lib_die("%s：列表元素必须全是数字", who);
        if (kind == 2) {
            acc = rt_mul(acc, cur);
        } else if (kind == 3) {
            acc = rt_add(acc, cur);
        } else {
            int cur_bigger = (AS_BOOL(rt_gt(cur, acc)) != 0);
            if (kind == 0 ? cur_bigger : !cur_bigger)
                acc = cur;
        }
    }
    return acc;
}

Value rt_lib_mt_max(Value list)  { return lib_list_fold(list, "mt.max", 0); }
Value rt_lib_mt_min(Value list)  { return lib_list_fold(list, "mt.min", 1); }
Value rt_lib_mt_prod(Value list) { return lib_list_fold(list, "mt.prod", 2); }

Value rt_lib_mt_sum(Value list)  { return lib_list_fold(list, "mt.sum", 3); }

Value rt_lib_mt_sin(Value a) { return rt_float(sin(lib_num(a, "mt.sin"))); }
Value rt_lib_mt_cos(Value a) { return rt_float(cos(lib_num(a, "mt.cos"))); }
Value rt_lib_mt_tan(Value a) { return rt_float(tan(lib_num(a, "mt.tan"))); }

Value rt_lib_mt_lerp(Value av, Value bv, Value tv)
{
    double a = lib_num(av, "mt.lerp 第 1 个参数");
    double b = lib_num(bv, "mt.lerp 第 2 个参数");
    double t = lib_num(tv, "mt.lerp 第 3 个参数");
    return rt_float(a + (b - a) * t);
}

Value rt_lib_mt_dist(Value x1v, Value y1v, Value x2v, Value y2v)
{
    double dx = lib_num(x2v, "mt.dist 的 x2") - lib_num(x1v, "mt.dist 的 x1");
    double dy = lib_num(y2v, "mt.dist 的 y2") - lib_num(y1v, "mt.dist 的 y1");
    return rt_float(sqrt(dx * dx + dy * dy));
}

Value rt_lib_mt_clamp(Value vv, Value lov, Value hiv)
{
    if (IS_INT(vv) && IS_INT(lov) && IS_INT(hiv)) {
        long long v = AS_INT(vv), lo = AS_INT(lov), hi = AS_INT(hiv);
        if (lo > hi)
            lib_die("mt.clamp：下限大于上限");
        return rt_int(v < lo ? lo : (v > hi ? hi : v));
    }
    {
        double v = lib_num(vv, "mt.clamp 的值");
        double lo = lib_num(lov, "mt.clamp 的下限");
        double hi = lib_num(hiv, "mt.clamp 的上限");
        if (lo > hi)
            lib_die("mt.clamp：下限大于上限");
        return rt_float(v < lo ? lo : (v > hi ? hi : v));
    }
}

Value rt_lib_mt_pi(void) { return rt_float(3.14159265358979); }

/* ================= rd 随机模块 ================= */

static int g_rd_seeded = 0;

static void rd_seed(void)
{
    if (!g_rd_seeded) {
        srand((unsigned)time(NULL));
        g_rd_seeded = 1;
    }
}

/* [0, range) 的随机整数（range >= 1）；两次 rand 拼 62 位，降低低位偏差 */
static long long rd_below(long long range)
{
    long long r = ((long long)rand() << 31) | (long long)rand();
    return r % range;
}

Value rt_lib_rd_int(Value lov, Value hiv)
{
    long long lo = lib_ll(lov, "rd.int 第 1 个参数");
    long long hi = lib_ll(hiv, "rd.int 第 2 个参数");
    if (lo > hi)
        lib_die("rd.int 的起（%lld）不能大于止（%lld）", lo, hi);
    rd_seed();
    long long span = hi - lo;                            /* 负区间（如 -100..100）合法 */
    if (span > 100000000LL)
        lib_die("rd.int：范围过大");
    return rt_int(lo + rd_below(span + 1));   /* 含两端 */
}

Value rt_lib_rd_float(void)
{
    rd_seed();
    return rt_float((double)rand() / ((double)RAND_MAX + 1.0));
}

Value rt_lib_rd_pick(Value list)
{
    long long n = lib_list_len(list, "rd.pick");
    if (n == 0)
        lib_die("rd.pick：空列表");
    rd_seed();
    return rt_index(list, rt_int(rd_below(n)));
}

Value rt_lib_rd_shuffle(Value list)
{
    long long n = lib_list_len(list, "rd.shuffle");
    rd_seed();
    for (long long i = n - 1; i > 0; i--) {   /* Fisher-Yates 原地打乱 */
        long long j = rd_below(i + 1);
        if (i == j)
            continue;
        Value vi = rt_index(list, rt_int(i));
        Value vj = rt_index(list, rt_int(j));
        rt_setindex(&list, rt_int(i), vj);
        rt_setindex(&list, rt_int(j), vi);
    }
    return rt_none();
}

Value rt_lib_mt_atan2(Value y, Value x)
{
    return rt_float(atan2(lib_num(y, "mt.atan2 的 y"), lib_num(x, "mt.atan2 的 x")));
}

Value rt_lib_te_str(Value v)
{
    return rt_str(rt_str_of(v));   /* 数字/布尔/字符串统一转文本盒 */
}

/* ================= tm 时间模块 ================= */

Value rt_lib_tm_stop(Value dur, Value unit)
{
    double ms = lib_num(dur, "tm.stop 的时长") * 1000.0;
    if (IS_STR(unit)) {
        const char *u = AS_STR(unit) ? AS_STR(unit) : "";
        if (strcmp(u, "ms") == 0 || strcmp(u, "毫秒") == 0)
            ms = lib_num(dur, "tm.stop 的时长");
        else if (strcmp(u, "s") != 0 && strcmp(u, "秒") != 0)
            lib_die("tm.stop 的单位只能是 \"s\" 或 \"ms\"");
    } else if (!IS_NONE(unit)) {
        lib_die("tm.stop 的单位只能是 \"s\" 或 \"ms\"");
    }
    if (ms < 0)
        ms = 0;
    Sleep((DWORD)ms);
    return rt_none();
}

Value rt_lib_tm_now(void)
{
    static ULONGLONG t0 = 0;
    static int started = 0;
    if (!started) {
        t0 = GetTickCount64();
        started = 1;
    }
    return rt_int((long long)(GetTickCount64() - t0));
}

/* ================= 调色板（内置常量色表） ================= */

/* 调色板.颜色名 → 新建的 [r,g,b] 列表（每色一个）。配合 color(列表)
 * 重载使用；列表按内存约定分配后不回收。 */

static Value pal_rgb(int r, int g, int b)
{
    Value lst = rt_list_new();
    rt_push(&lst, rt_int(r));
    rt_push(&lst, rt_int(g));
    rt_push(&lst, rt_int(b));
    return lst;
}

Value rt_lib_pal_hong(void)  { return pal_rgb(255, 68, 68);   }   /* 红 */
Value rt_lib_pal_cheng(void) { return pal_rgb(255, 150, 40);  }   /* 橙 */
Value rt_lib_pal_huang(void) { return pal_rgb(255, 220, 60);  }   /* 黄 */
Value rt_lib_pal_lv(void)    { return pal_rgb(60, 200, 90);   }   /* 绿 */
Value rt_lib_pal_qing(void)  { return pal_rgb(60, 200, 200);  }   /* 青 */
Value rt_lib_pal_lan(void)   { return pal_rgb(70, 130, 255);  }   /* 蓝 */
Value rt_lib_pal_zi(void)    { return pal_rgb(170, 90, 220);  }   /* 紫 */
Value rt_lib_pal_bai(void)   { return pal_rgb(240, 240, 240); }   /* 白 */
Value rt_lib_pal_hei(void)   { return pal_rgb(20, 20, 24);    }   /* 黑 */
Value rt_lib_pal_hui(void)   { return pal_rgb(140, 140, 150); }   /* 灰 */
Value rt_lib_pal_fen(void)   { return pal_rgb(255, 140, 180); }   /* 粉 */
Value rt_lib_pal_jin(void)   { return pal_rgb(255, 200, 60);  }   /* 金 */

/* ================= 自测（-DLIB_SELF_TEST） =================
 * gcc -O2 -DLIB_SELF_TEST pybook_lib.c pybook_rt.c -o lib_test.exe -I. */

#ifdef LIB_SELF_TEST

#include <float.h>

static int g_pass = 0, g_fail = 0;

#define CHECK(cond, name)                              \
    do {                                               \
        if (cond) {                                    \
            g_pass++;                                  \
        } else {                                       \
            g_fail++;                                  \
            printf("[失败] %s\n", name);               \
        }                                              \
    } while (0)

static Value mklist(int n, ...)
{
    Value lst = rt_list_new();
    va_list ap;
    va_start(ap, n);
    for (int i = 0; i < n; i++)
        rt_push(&lst, va_arg(ap, Value));
    va_end(ap);
    return lst;
}

static int str_eq(Value v, const char *want)
{
    return IS_STR(v) && strcmp(AS_STR(v), want) == 0;
}

static double as_f(Value v) { return AS_FLT(v); }
static long long as_i(Value v) { return IS_INT(v) || IS_BIGINT(v) ? rt_to_ll(v) : (long long)AS_BOOL(v); }

int main(void)
{
    /* ---- te.split ---- */
    Value parts = rt_lib_te_split(rt_str("a,b,,c"), rt_str(","));
    CHECK(as_i(rt_len(parts)) == 4, "te.split: 4 段");
    CHECK(str_eq(rt_index(parts, rt_int(2)), ""), "te.split: 空段保留");
    Value one = rt_lib_te_split(rt_str("abc"), rt_str(","));
    CHECK(as_i(rt_len(one)) == 1 && str_eq(rt_index(one, rt_int(0)), "abc"),
          "te.split: 无分隔符 → 整串 1 段");

    /* ---- te.replace ---- */
    CHECK(str_eq(rt_lib_te_replace(rt_str("番茄炒番茄"), rt_str("番茄"),
                                   rt_str("土豆")), "土豆炒土豆"),
          "te.replace: 多处替换");
    CHECK(str_eq(rt_lib_te_replace(rt_str("abc"), rt_str("x"), rt_str("y")),
                 "abc"), "te.replace: 无命中原样");
    CHECK(str_eq(rt_lib_te_replace(rt_str("aaa"), rt_str("aa"), rt_str("b")),
                 "ba"), "te.replace: 顺序扫描不重叠");

    /* ---- te.trim ---- */
    CHECK(str_eq(rt_lib_te_trim(rt_str("  hi\r\n")), "hi"), "te.trim: 去两侧空白");
    CHECK(str_eq(rt_lib_te_trim(rt_str(" \t\v\f")), ""), "te.trim: 全空白 → 空");
    CHECK(str_eq(rt_lib_te_trim(rt_str(" a b ")), "a b"), "te.trim: 中间空白保留");

    /* ---- te.upper / te.lower ---- */
    CHECK(str_eq(rt_lib_te_upper(rt_str("aBc1中")), "ABC1中"), "te.upper: 混合文本");
    CHECK(str_eq(rt_lib_te_lower(rt_str("AbC1中")), "abc1中"), "te.lower: 混合文本");

    /* ---- te.has ---- */
    CHECK(rt_cond(rt_lib_te_has(rt_str("hello 世界"), rt_str("lo 世"))) != 0,
          "te.has: 命中");
    CHECK(rt_cond(rt_lib_te_has(rt_str("abc"), rt_str("z"))) == 0,
          "te.has: 未命中");
    CHECK(rt_cond(rt_lib_te_has(rt_str("abc"), rt_str(""))) != 0,
          "te.has: 空子串恒真");

    /* ---- te.len：UTF-8 按字符 ---- */
    CHECK(as_i(rt_lib_te_len(rt_str("hello"))) == 5, "te.len: ASCII");
    CHECK(as_i(rt_lib_te_len(rt_str("中文ab"))) == 4, "te.len: UTF-8 按字符");

    /* ---- te.cut ---- */
    CHECK(str_eq(rt_lib_te_cut(rt_str("你好世界"), rt_int(1), rt_int(3)), "好世"),
          "te.cut: 中段（UTF-8 按字符）");
    CHECK(str_eq(rt_lib_te_cut(rt_str("abc"), rt_int(0), rt_int(0)), ""),
          "te.cut: 空区间");
    CHECK(str_eq(rt_lib_te_cut(rt_str("abc"), rt_int(0), rt_int(3)), "abc"),
          "te.cut: 全范围");

    /* ---- te.join ---- */
    CHECK(str_eq(rt_lib_te_join(mklist(3, rt_str("x"), rt_str("y"), rt_str("z")),
                                rt_str("-")), "x-y-z"), "te.join: 字符串列表");
    CHECK(str_eq(rt_lib_te_join(mklist(3, rt_int(1), rt_float(2.5), rt_str("真")),
                                rt_str(",")), "1,2.5,真"), "te.join: 混合类型转文本");
    CHECK(str_eq(rt_lib_te_join(rt_list_new(), rt_str("+")), ""),
          "te.join: 空列表 → 空串");

    /* ---- mt.sqrt / mt.pow ---- */
    CHECK(as_f(rt_lib_mt_sqrt(rt_int(144))) == 12.0, "mt.sqrt: 完全平方数");
    CHECK(as_f(rt_lib_mt_sqrt(rt_float(2.0))) > 1.4142135, "mt.sqrt: 浮点");
    CHECK(as_f(rt_lib_mt_pow(rt_int(2), rt_int(10))) == 1024.0, "mt.pow: 2^10");
    CHECK(as_f(rt_lib_mt_pow(rt_int(4), rt_float(0.5))) == 2.0, "mt.pow: 4^0.5=2");

    /* ---- mt.abs ---- */
    CHECK(as_i(rt_lib_mt_abs(rt_int(-7))) == 7 &&
          as_i(rt_lib_mt_abs(rt_int(7))) == 7, "mt.abs: 整数");
    CHECK(as_f(rt_lib_mt_abs(rt_float(-2.5))) == 2.5, "mt.abs: 浮点");
    CHECK(as_i(rt_lib_mt_abs(rt_int(0))) == 0, "mt.abs: 0→0");
    CHECK(as_i(rt_lib_mt_abs(rt_bool(1))) == 1, "mt.abs: 布尔按 0/1");

    /* ---- mt.ceil / mt.floor ---- */
    CHECK(as_i(rt_lib_mt_ceil(rt_float(1.2))) == 2, "mt.ceil: 1.2→2");
    CHECK(as_i(rt_lib_mt_ceil(rt_float(-1.2))) == -1, "mt.ceil: -1.2→-1");
    CHECK(as_i(rt_lib_mt_floor(rt_float(1.8))) == 1, "mt.floor: 1.8→1");
    CHECK(as_i(rt_lib_mt_floor(rt_float(-1.8))) == -2, "mt.floor: -1.8→-2");
    CHECK(as_i(rt_lib_mt_ceil(rt_int(5))) == 5, "mt.ceil: 整数原值");

    /* ---- mt.mod ---- */
    CHECK(as_i(rt_lib_mt_mod(rt_int(7), rt_int(3))) == 1, "mt.mod: 7%3=1");
    CHECK(as_i(rt_lib_mt_mod(rt_int(-7), rt_int(3))) == 2,
          "mt.mod: 负数符号跟除数");

    /* ---- mt.max / mt.min / mt.prod ---- */
    Value nums = mklist(4, rt_int(3), rt_int(-5), rt_float(9.5), rt_int(2));
    CHECK(as_f(rt_lib_mt_max(nums)) == 9.5, "mt.max: 混合数字");
    CHECK(as_i(rt_lib_mt_min(nums)) == -5, "mt.min: 负数");
    CHECK(as_i(rt_lib_mt_min(mklist(2, rt_int(100), rt_int(-100)))) == -100,
          "mt.min: 两元素");
    CHECK(as_i(rt_lib_mt_prod(mklist(3, rt_int(2), rt_int(3), rt_int(4)))) == 24,
          "mt.prod: 2*3*4");
    CHECK(as_f(rt_lib_mt_prod(mklist(2, rt_float(1.5), rt_int(4)))) == 6.0,
          "mt.prod: 浮点");

    /* ---- mt.sin / mt.cos / mt.tan / mt.pi ---- */
    CHECK(as_f(rt_lib_mt_sin(rt_int(0))) == 0.0, "mt.sin: 0→0");
    CHECK(as_f(rt_lib_mt_cos(rt_int(0))) == 1.0, "mt.cos: 0→1");
    CHECK(as_f(rt_lib_mt_tan(rt_int(0))) == 0.0, "mt.tan: 0→0");
    double pival = as_f(rt_lib_mt_pi());
    CHECK(pival > 3.14159265358 && pival < 3.14159265360, "mt.pi: 值正确");
    CHECK(IS_FLT(rt_lib_mt_pi()), "mt.pi: 浮点盒");

    /* ---- rd.int：范围、含两端、起=止 ---- */
    int in_range = 1, saw_lo = 0, saw_hi = 0;
    for (int i = 0; i < 2000; i++) {
        Value r = rt_lib_rd_int(rt_int(3), rt_int(7));
        if (as_i(r) < 3 || as_i(r) > 7)
            in_range = 0;
        if (as_i(r) == 3) saw_lo = 1;
        if (as_i(r) == 7) saw_hi = 1;
    }
    CHECK(in_range, "rd.int: 2000 次都在 [3,7]");
    CHECK(saw_lo && saw_hi, "rd.int: 两端都取到过（含两端）");
    CHECK(as_i(rt_lib_rd_int(rt_int(5), rt_int(5))) == 5, "rd.int: 起=止");

    /* ---- rd.float：范围 + 多样性 ---- */
    Value rf = rt_lib_rd_float();
    CHECK(IS_FLT(rf) && as_f(rf) >= 0.0 && as_f(rf) < 1.0,
          "rd.float: 在 [0,1)");
    int varied = 0;
    double first = as_f(rt_lib_rd_float());
    for (int i = 0; i < 50; i++)
        if (as_f(rt_lib_rd_float()) != first)
            varied = 1;
    CHECK(varied, "rd.float: 连续抽样有变化");

    /* ---- rd.pick ---- */
    Value pool = mklist(3, rt_int(10), rt_int(20), rt_int(30));
    int pick_ok = 1;
    for (int i = 0; i < 200; i++) {
        Value p = rt_lib_rd_pick(pool);
        if (as_i(p) != 10 && as_i(p) != 20 && as_i(p) != 30)
            pick_ok = 0;
    }
    CHECK(pick_ok, "rd.pick: 200 次都取自原列表");

    /* ---- rd.shuffle：集合不变 + 顺序变化 ---- */
    Value deck = mklist(6, rt_int(1), rt_int(2), rt_int(3),
                        rt_int(4), rt_int(5), rt_int(6));
    long long sum0 = 0;
    for (long long i = 0; i < 6; i++)
        sum0 += as_i(rt_index(deck, rt_int(i)));
    rt_lib_rd_shuffle(deck);
    long long sum1 = 0;
    int sorted_still = 1;
    for (long long i = 0; i < 6; i++) {
        Value e = rt_index(deck, rt_int(i));
        if (as_i(e) != i + 1)
            sorted_still = 0;
        sum1 += as_i(e);
    }
    CHECK(sum0 == 21 && sum1 == 21, "rd.shuffle: 元素集合不变（和=21）");
    CHECK(!sorted_still, "rd.shuffle: 顺序确实变了");

    /* ---- mt.lerp / mt.dist / mt.clamp ---- */
    CHECK(as_f(rt_lib_mt_lerp(rt_int(0), rt_int(10), rt_float(0.5))) == 5.0,
          "mt.lerp: 0→10 的一半是 5");
    CHECK(as_f(rt_lib_mt_dist(rt_int(0), rt_int(0), rt_int(3), rt_int(4))) == 5.0,
          "mt.dist: 3-4-5");
    CHECK(as_i(rt_lib_mt_clamp(rt_int(15), rt_int(0), rt_int(10))) == 10,
          "mt.clamp: 15 夹到上限 10");

    printf("库自测：通过 %d 项，失败 %d 项\n", g_pass, g_fail);
    if (g_fail == 0)
        printf("库自测全部通过\n");
    return g_fail == 0 ? 0 : 1;
}

#endif /* LIB_SELF_TEST */
