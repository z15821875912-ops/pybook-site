/* PYbookIDE.exe —— 双击启动 PYbook IDE（ide.py）。
 * 纯 C 原生启动器：找 pythonw → 以 exe 所在目录为工作目录运行 ide.py，无黑窗。
 * 编译: gcc -O2 -mwindows ide启动器.c -o PYbookIDE.exe -static-libgcc -lshell32 */
#include <windows.h>
#include <stdio.h>

int WINAPI WinMain(HINSTANCE hI, HINSTANCE hP, LPSTR cmd, int show)
{
    (void)hI; (void)hP; (void)cmd; (void)show;
    char 目录[MAX_PATH];
    GetModuleFileNameA(NULL, 目录, sizeof 目录);
    char *s = strrchr(目录, 92);
    if (s) *s = 0;

    char pyw[MAX_PATH] = "";
    char py[MAX_PATH] = "";
    if (SearchPathA(NULL, "pythonw.exe", NULL, sizeof pyw, pyw, NULL) == 0)
        SearchPathA(NULL, "python.exe", NULL, sizeof pyw, pyw, NULL);
    if (!pyw[0])
        strcpy(pyw, "C:/Users/zhuli/AppData/Local/Programs/Python/Python311/pythonw.exe");

    char ide[MAX_PATH * 2];
    snprintf(ide, sizeof ide, "%s/ide.py", 目录);
    if (GetFileAttributesA(ide) == INVALID_FILE_ATTRIBUTES) {
        MessageBoxA(NULL, ide, "找不到 ide.py", MB_ICONERROR);
        return 1;
    }

    char 参数[MAX_PATH * 4];
    snprintf(参数, sizeof 参数, "\"%s\" \"%s\"", pyw, ide);
    char 工作目录[MAX_PATH * 2];
    strcpy(工作目录, 目录);

    STARTUPINFOA si; memset(&si, 0, sizeof si);
    si.cb = sizeof si;
    PROCESS_INFORMATION pi;
    if (CreateProcessA(NULL, 参数, NULL, NULL, FALSE,
                       DETACHED_PROCESS | CREATE_NO_WINDOW, NULL, 工作目录, &si, &pi)) {
        CloseHandle(pi.hThread);
        CloseHandle(pi.hProcess);
        return 0;
    }
    char 错[256];
    snprintf(错, sizeof 错, "启动失败（错误 %lu）\n%s", (unsigned long)GetLastError(), 参数);
    MessageBoxA(NULL, 错, "PYbook IDE", MB_ICONERROR);
    return 1;
}
