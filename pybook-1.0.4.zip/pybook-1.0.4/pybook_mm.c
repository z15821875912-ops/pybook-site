/* PYbook MyMove（twoM）库：列表即像素画。
 * 一行字符串 = 一排像素；一个词 = 一个像素的颜色；`.` 或 `_` = 透明。
 * mm.色(token, r, g, b)            注册/覆盖颜色 token
 * mm.draw_away(表, "名.png", 倍数)  把列表渲染落成 PNG（倍数：1 格 = N×N 真像素）
 * mm.贴(表, x, y, 倍数)             窗口模式即时贴（实现见 pybook_rt.c 的 rt_mm_blt）
 * PNG 落盘：手写编码器（zlib store 块 + CRC32/Adler32），零依赖离线。 */

#include "pybook_lib.h"

#ifdef _WIN32
#  define WIN32_LEAN_AND_MEAN
#  include <windows.h>       /* 中文路径：UTF-8 -> 宽字符 _wfopen */
#endif
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static void mm_die(const char *fmt, ...)
{
    va_list ap;
    fprintf(stderr, "运行时错误: mm.");
    va_start(ap, fmt);
    vfprintf(stderr, fmt, ap);
    va_end(ap);
    fputc('\n', stderr);
    exit(1);
}

/* ---- 调色板 ---- */

typedef struct { const char *tok; unsigned char r, g, b; } MmBuiltin;

static const MmBuiltin mm_builtin[] = {
    {"b1", 137, 207, 240}, {"b2", 66, 133, 244}, {"b3", 26, 61, 158},
    {"r1", 255, 154, 154}, {"r2", 229, 57, 53},  {"r3", 155, 22, 22},
    {"g1", 129, 199, 132}, {"g2", 67, 160, 71},  {"g3", 27, 94, 32},
    {"y1", 255, 235, 59},  {"y2", 198, 148, 0},
    {"o1", 255, 167, 38},  {"o2", 230, 81, 0},
    {"p1", 206, 147, 216}, {"p2", 123, 31, 162},
    {"w1", 250, 250, 250}, {"w2", 158, 158, 158},
    {"k1", 20, 20, 20},
    {"f1", 255, 204, 170},
    /* 单字符简谱（连写模式用）：中调 */
    {"b", 66, 133, 244}, {"r", 229, 57, 53},  {"g", 67, 160, 71},
    {"y", 255, 235, 59},  {"o", 255, 167, 38}, {"p", 123, 31, 162},
    {"w", 250, 250, 250}, {"k", 20, 20, 20},   {"f", 255, 204, 170},
};

typedef struct { char tok[16]; unsigned char r, g, b; } MmCustom;

static MmCustom mm_custom[256];
static int mm_ncustom = 0;

/* 返回 1=不透明（rgb 出参），0=透明，-1=未知 token */
int rt_mm_lookup(Value tokv, int *r, int *g, int *b)
{
    const char *t = rt_str_of(tokv);
    if (!strcmp(t, ".") || !strcmp(t, "_"))
        return 0;
    for (int i = 0; i < mm_ncustom; i++)
        if (strcmp(mm_custom[i].tok, t) == 0) {
            *r = mm_custom[i].r; *g = mm_custom[i].g; *b = mm_custom[i].b;
            return 1;
        }
    for (size_t i = 0; i < sizeof mm_builtin / sizeof mm_builtin[0]; i++)
        if (strcmp(mm_builtin[i].tok, t) == 0) {
            *r = mm_builtin[i].r; *g = mm_builtin[i].g; *b = mm_builtin[i].b;
            return 1;
        }
    return -1;
}

Value rt_mm_color(Value tok, Value rv, Value gv, Value bv)
{
    const char *t = rt_str_of(tok);
    if (!*t || strlen(t) >= 16)
        mm_die("色：token 长度须为 1..15");
    if (!strcmp(t, ".") || !strcmp(t, "_"))
        mm_die("色：. 和 _ 是保留的透明标记");
    long long r = rt_to_ll(rv), g = rt_to_ll(gv), b = rt_to_ll(bv);
    if (r < 0 || r > 255 || g < 0 || g > 255 || b < 0 || b > 255)
        mm_die("色：RGB 须在 0..255");
    MmCustom *slot = NULL;
    for (int i = 0; i < mm_ncustom; i++)
        if (strcmp(mm_custom[i].tok, t) == 0) { slot = &mm_custom[i]; break; }
    if (!slot) {
        if (mm_ncustom >= 256)
            mm_die("色：自定义颜色已满（256 个）");
        slot = &mm_custom[mm_ncustom++];
        memset(slot->tok, 0, sizeof slot->tok);
        strncpy(slot->tok, t, 15);
    }
    slot->r = (unsigned char)r;
    slot->g = (unsigned char)g;
    slot->b = (unsigned char)b;
    return rt_none();
}

/* ---- 列表 → 像素缓冲 ----
 * 返回 malloc 的 RGBA 缓冲（项目约定分配不回收）；*W/*H 出尺寸。 */

unsigned char *rt_mm_raster(Value rows, long long scale, size_t *W, size_t *H)
{
    if (!IS_LIST(rows) || AS_LIST(rows) == NULL)
        mm_die("draw_away/贴 需要列表（一行字符串一排像素）");
    RtList *L = AS_LIST(rows);
    if (L->len == 0 || L->len > 4096)
        mm_die("列表行数须为 1..4096");
    if (scale < 1 || scale > 64)
        mm_die("倍数须为 1..64");

    int token_mode = 0;
    for (size_t i = 0; i < L->len && !token_mode; i++)
        if (strchr(rt_str_of(L->items[i]), ' '))
            token_mode = 1;               /* 行内有空格 = 多字符 token 模式 */
    size_t w = 0;
    for (size_t i = 0; i < L->len; i++) {
        const char *row = rt_str_of(L->items[i]);
        size_t cnt;
        if (token_mode) {
            cnt = 0;
            size_t j2 = 0;
            while (row[j2]) {
                while (row[j2] == ' ') j2++;
                if (!row[j2]) break;
                cnt++;
                while (row[j2] && row[j2] != ' ') j2++;
            }
        } else {
            cnt = strlen(row);            /* 连写模式：每字符一像素 */
        }
        if (cnt > w) w = cnt;
    }
    if (w == 0)
        mm_die("列表里没有任何像素（一行至少要一个 token，如 \"b1\"）");

    size_t Wp = w * (size_t)scale, Hp = L->len * (size_t)scale;
    unsigned char *px = (unsigned char *)calloc(Wp * Hp, 4);   /* 默认全透明 */
    if (!px)
        mm_die("draw_away 内存不足");

    for (size_t i = 0; i < L->len; i++) {
        const char *row = rt_str_of(L->items[i]);
        if (!token_mode) {
            for (size_t j2 = 0; j2 < strlen(row); j2++) {
                char tok[2] = { row[j2], 0 };
                Value tv = rt_str(tok);
                int r, g, b2;
                int kind = rt_mm_lookup(tv, &r, &g, &b2);
                if (kind < 0)
                    mm_die("draw_away：第 %zu 行第 %zu 格的字符 %c 不认识"
                           "（. 或 _ 是透明；mm.色 可自定义）", i + 1, j2 + 1, row[j2]);
                if (kind == 1) {
                    for (long long dy = 0; dy < scale; dy++)
                        for (long long dx = 0; dx < scale; dx++) {
                            unsigned char *pxl = px + ((i * (size_t)scale + (size_t)dy) * Wp
                                                       + (j2 * (size_t)scale + (size_t)dx)) * 4;
                            pxl[0] = (unsigned char)r;
                            pxl[1] = (unsigned char)g;
                            pxl[2] = (unsigned char)b2;
                            pxl[3] = 255;
                        }
                }
            }
            continue;
        }
        size_t col = 0, j = 0;
        while (row[j]) {
            while (row[j] == ' ') j++;
            if (!row[j]) break;
            char tok[16];
            size_t t = 0;
            while (row[j] && row[j] != ' ' && t < 15)
                tok[t++] = row[j++];
            while (row[j] && row[j] != ' ') j++;      /* 超长部分截断 */
            tok[t] = '\0';
            Value tv = rt_str(tok);
            int r, g, b2;
            int kind = rt_mm_lookup(tv, &r, &g, &b2);
            if (kind < 0)
                mm_die("draw_away：第 %zu 行第 %zu 格的 token '%s' 不认识"
                       "（mm.色 可自定义；. 或 _ 是透明）",
                       i + 1, col + 1, tok);
            if (kind == 1) {
                for (long long dy = 0; dy < scale; dy++)
                    for (long long dx = 0; dx < scale; dx++) {
                        size_t x = col * (size_t)scale + (size_t)dx;
                        size_t y = i * (size_t)scale + (size_t)dy;
                        unsigned char *pxl = px + (y * Wp + x) * 4;
                        pxl[0] = (unsigned char)r;
                        pxl[1] = (unsigned char)g;
                        pxl[2] = (unsigned char)b2;
                        pxl[3] = 255;
                    }
            }
            col++;
        }
    }
    *W = Wp;
    *H = Hp;
    return px;
}

/* ---- PNG 编码器（store 模式，零依赖） ---- */

static unsigned long mm_crc_table[256];
static int mm_crc_made = 0;

static void mm_crc_init(void)
{
    for (unsigned long n = 0; n < 256; n++) {
        unsigned long c = n;
        for (int k = 0; k < 8; k++)
            c = (c & 1) ? 0xEDB88320UL ^ (c >> 1) : c >> 1;
        mm_crc_table[n] = c;
    }
    mm_crc_made = 1;
}

static unsigned long mm_crc(unsigned long crc, const unsigned char *buf, size_t n)
{
    if (!mm_crc_made)
        mm_crc_init();
    for (size_t i = 0; i < n; i++)
        crc = mm_crc_table[(crc ^ buf[i]) & 0xFF] ^ (crc >> 8);
    return crc;
}

static void mm_w32(FILE *fp, unsigned long v)     /* 大端 4 字节 */
{
    fputc((int)((v >> 24) & 0xFF), fp);
    fputc((int)((v >> 16) & 0xFF), fp);
    fputc((int)((v >> 8) & 0xFF), fp);
    fputc((int)(v & 0xFF), fp);
}

static void mm_chunk(FILE *fp, const char *type, const unsigned char *data, size_t n)
{
    mm_w32(fp, (unsigned long)n);
    fwrite(type, 1, 4, fp);
    if (n)
        fwrite(data, 1, n, fp);
    unsigned long c = mm_crc(0xFFFFFFFFUL, type, 4);
    c = mm_crc(c ^ 0xFFFFFFFFUL, data, n);
    mm_w32(fp, (c ^ 0xFFFFFFFFUL) & 0xFFFFFFFFUL);
}

Value rt_mm_draw_away(Value rows, Value file, Value scale)
{
    long long sc = rt_to_ll(scale);
    size_t W = 0, H = 0;
    unsigned char *px = rt_mm_raster(rows, sc, &W, &H);

    /* 原始数据：每行前置过滤字节 0 */
    size_t raw_len = H * (W * 4 + 1);
    unsigned char *raw = (unsigned char *)malloc(raw_len);
    if (!raw)
        mm_die("draw_away 内存不足");
    for (size_t y = 0; y < H; y++) {
        raw[y * (W * 4 + 1)] = 0;
        memcpy(raw + y * (W * 4 + 1) + 1, px + y * W * 4, W * 4);
    }

    const char *name = rt_str_of(file);
    FILE *fp = NULL;
#ifdef _WIN32
    {
        wchar_t wname[1024];
        if (MultiByteToWideChar(CP_UTF8, 0, name, -1, wname, 1024) > 0)
            fp = _wfopen(wname, L"wb");
    }
#endif
    if (!fp)
        fp = fopen(name, "wb");
    if (!fp)
        mm_die("draw_away：无法写 %s", name);
    static const unsigned char sig[8] = {137, 80, 78, 71, 13, 10, 26, 10};
    fwrite(sig, 1, 8, fp);

    unsigned char ihdr[13];
    ihdr[0] = (unsigned char)((W >> 24) & 0xFF); ihdr[1] = (unsigned char)((W >> 16) & 0xFF);
    ihdr[2] = (unsigned char)((W >> 8) & 0xFF);  ihdr[3] = (unsigned char)(W & 0xFF);
    ihdr[4] = (unsigned char)((H >> 24) & 0xFF); ihdr[5] = (unsigned char)((H >> 16) & 0xFF);
    ihdr[6] = (unsigned char)((H >> 8) & 0xFF);  ihdr[7] = (unsigned char)(H & 0xFF);
    ihdr[8] = 8;   /* 位深 */
    ihdr[9] = 6;   /* RGBA */
    ihdr[10] = ihdr[11] = ihdr[12] = 0;
    mm_chunk(fp, "IHDR", ihdr, 13);

    /* zlib store 包装 */
    size_t zlen = raw_len + raw_len / 65535 * 5 + 12;
    unsigned char *z = (unsigned char *)malloc(zlen);
    if (!z)
        mm_die("draw_away 内存不足");
    size_t zp = 0;
    z[zp++] = 0x78; z[zp++] = 0x01;
    size_t off = 0;
    while (off < raw_len) {
        size_t blk = raw_len - off;
        if (blk > 65535) blk = 65535;
        z[zp++] = (off + blk >= raw_len) ? 1 : 0;
        z[zp++] = (unsigned char)(blk & 0xFF);
        z[zp++] = (unsigned char)(blk >> 8);
        z[zp++] = (unsigned char)(~blk & 0xFF);
        z[zp++] = (unsigned char)((~blk >> 8) & 0xFF);
        memcpy(z + zp, raw + off, blk);
        zp += blk;
        off += blk;
    }
    unsigned long a = 1, b2 = 0;
    for (size_t i = 0; i < raw_len; i++) {
        a = (a + raw[i]) % 65521;
        b2 = (b2 + a) % 65521;
    }
    unsigned long adler = (b2 << 16) | a;
    z[zp++] = (unsigned char)((adler >> 24) & 0xFF);
    z[zp++] = (unsigned char)((adler >> 16) & 0xFF);
    z[zp++] = (unsigned char)((adler >> 8) & 0xFF);
    z[zp++] = (unsigned char)(adler & 0xFF);
    mm_chunk(fp, "IDAT", z, zp);

    mm_chunk(fp, "IEND", (const unsigned char *)"", 0);
    fclose(fp);
    return rt_str(name);
}
