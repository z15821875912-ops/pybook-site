# -*- coding: utf-8 -*-
"""魔域勇者 美术生成器：字符串像素画 → games/魔域/*.png
并输出 放大对照图 _魔域美术对照.png 供肉眼检查。"""
import os
from PIL import Image

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "games", "魔域")
os.makedirs(OUT, exist_ok=True)

# ---------------- 全局调色板（字符 → RGB） ----------------
PAL = {
    'k': (20, 20, 30),      # 描边黑
    's': (240, 200, 160),   # 皮肤
    'S': (214, 166, 120),   # 皮肤暗
    'h': (188, 200, 220),   # 钢亮
    'H': (132, 148, 176),   # 钢暗
    'g': (96, 176, 100),    # 绿衣
    'G': (56, 122, 66),     # 绿衣暗
    'b': (150, 100, 56),    # 靴棕
    'B': (104, 66, 38),     # 靴棕暗
    'y': (244, 200, 74),    # 金
    'Y': (200, 144, 32),    # 金暗
    'r': (216, 76, 80),     # 红
    'R': (156, 48, 56),     # 红暗
    'w': (244, 244, 248),   # 白
    'p': (138, 92, 200),    # 紫
    'P': (92, 58, 144),     # 紫暗
    'o': (232, 138, 60),    # 橙
    'c': (88, 184, 200),    # 青
    'l': (106, 160, 232),   # 亮蓝
    'e': (32, 36, 46),      # 眼
    'm': (150, 156, 168),   # 骨灰亮
    'M': (104, 110, 122),   # 骨灰暗
    'a': (70, 200, 130),    # 史莱姆亮
    'A': (40, 140, 90),     # 史莱姆暗
    'n': (60, 56, 80),      # 夜紫暗（蝙蝠/巫）
    'N': (40, 36, 56),      # 夜紫更深
    'v': (180, 120, 220),   # 魔法亮紫
    'f': (255, 216, 74),    # 火黄
    'F': (255, 136, 48),    # 火橙
    'd': (70, 62, 88),      # 洞墙基
    'D': (48, 42, 64),      # 洞墙暗
    'u': (84, 74, 104),     # 洞墙亮
    'x': (208, 170, 120),   # 沙土亮
    'X': (168, 130, 88),    # 沙土暗
    'q': (60, 90, 60),      # 草暗
    'Q': (86, 140, 74),     # 草基
    'W': (110, 170, 88),    # 草亮
    't': (46, 96, 56),      # 树冠暗
    'T': (64, 126, 66),     # 树冠基
    'Y2': (94, 176, 92),    # 树冠亮
    'E': (255, 240, 180),   # 高光白黄
    'L': (60, 110, 170),    # 水基
    'C': (100, 160, 220),   # 水亮
    'K': (40, 70, 130),     # 水暗
    'z': (200, 200, 210),   # 银亮
}
PAL['j'] = (94, 176, 92)    # 树冠亮（同 Y2）

def png(name, rows):
    w = len(rows[0]); h = len(rows)
    for r in rows:
        assert len(r) == w, f"{name} 行宽不齐: {len(r)} != {w}"
    im = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    px = im.load()
    for y, row in enumerate(rows):
        for x, ch in enumerate(row):
            if ch != '.':
                c = PAL[ch]
                px[x, y] = (c[0], c[1], c[2], 255)
    im.save(os.path.join(OUT, name + ".png"))
    return im

# ---------------- 勇者（16×16，四方向 × 双帧） ----------------
# 下 A（站立/迈步1）
HERO_D_A = [
    "................",
    ".....kkkkkk.....",
    "....khhhhhhk....",
    "...khhhhhhhhk...",
    "...khssssssHk...",
    "...khsesksesh...".replace('k', 's'),
    "...khssssssHk...",
    "....kssSSssk....",
    "...kggggggggk...",
    "..ksgGGGGGGgsk..",
    "..kygGGyyGGgyk..",
    "...kyyyyyyyyk...",
    "...kbbk..kbbk...",
    "...kBbk..kbBk...",
    "....kk....kk....",
    "................",
]
# 下 B（迈步2：脚交错）
HERO_D_B = [
    "................",
    ".....kkkkkk.....",
    "....khhhhhhk....",
    "...khhhhhhhhk...",
    "...khssssssHk...",
    "...khsssse sh...".replace(' ', 's'),
    "...khssssssHk...",
    "....kssSSssk....",
    "...kggggggggk...",
    "..ksgGGGGGGgsk..",
    "..kygGGyyGGgyk..",
    "...kyyyyyyyyk...",
    "....kbbbbbbk....",
    "....kbBkkBbk....",
    ".....kk..kk.....",
    "................",
]
# 上（背面：全盔甲后脑）
HERO_U_A = [
    "................",
    ".....kkkkkk.....",
    "....khhhhhhk....",
    "...khhhhhhhhk...",
    "...khhhhhhhhk...",
    "...khHHHHHHHk...",
    "...khhhhhhhhk...",
    "....khhhhhhk....",
    "...kggggggggk...",
    "..ksgGGGGGGgsk..",
    "..ksgGGGGGGgsk..",
    "...kyyyyyyyyk...",
    "...kbbk..kbbk...",
    "...kBbk..kbBk...",
    "....kk....kk....",
    "................",
]
HERO_U_B = [
    "................",
    ".....kkkkkk.....",
    "....khhhhhhk....",
    "...khhhhhhhhk...",
    "...khhhhhhhhk...",
    "...khHHHHHHHk...",
    "...khhhhhhhhk...",
    "....khhhhhhk....",
    "...kggggggggk...",
    "..ksgGGGGGGgsk..",
    "..ksgGGGGGGgsk..",
    "...kyyyyyyyyk...",
    "....kbbbbbbk....",
    "....kbBkkBbk....",
    ".....kk..kk.....",
    "................",
]
# 右 A
HERO_R_A = [
    "................",
    ".....kkkkkk.....",
    "....khhhhhhk....",
    "...khhhhhhhhk...",
    "...khhsssssk....",
    "...khsse ss k...".replace(' ', 's'),
    "...khhsssssk....",
    "....kssShhk.....",
    "...kggggggk.....",
    "...kgGGggggk....",
    "...kyGGyyggk....",
    "...kyyyyyyk.....",
    "....kbbbk.......",
    "....kBbbk.......",
    ".....kkk........",
    "................",
]
# 右 B（迈步）
HERO_R_B = [
    "................",
    ".....kkkkkk.....",
    "....khhhhhhk....",
    "...khhhhhhhhk...",
    "...khhsssssk....",
    "...khsse ssk....".replace(' ', 's'),
    "...khhsssssk....",
    "....kssShhk.....",
    "...kggggggk.....",
    "...kgGGggggk....",
    "...kyGGyyggk....",
    "...kyyyyyyk.....",
    "...kbbbbbbk.....",
    "....kbbBbk......",
    ".....kkkk.......",
    "................",
]
def mirror(rows):
    return [r[::-1] for r in rows]

HERO_L_A = mirror(HERO_R_A)
HERO_L_B = mirror(HERO_R_B)

# ---------------- 敌人 ----------------
SLIME_A = [
    "................",
    "................",
    "................",
    "................",
    "......kkkk......",
    "....kkaaaakk....",
    "...kaaaaaaaak...",
    "..kaEaaaaaaaak..",
    "..kaaesaaesaak..",
    ".kaaaaaaaaaaaak.",
    ".kaaaaaaaaaaaak.",
    ".kaAAAAAAAAAAak.",
    ".kAAAAAAAAAAAAk.",
    "..kkkkkkkkkkkk..",
    "................",
    "................",
]
SLIME_B = [
    "................",
    "................",
    "................",
    "................",
    "................",
    ".....kkkkkk.....",
    "...kkaaaaaakk...",
    "..kaEaaaaaaaak..",
    "..kaaesaaesaak..",
    ".kaaaaaaaaaaaak.",
    ".kaaaaaaaaaaaak.",
    ".kaAAAAAAAAAAak.",
    "kAAAAAAAAAAAAAAk",
    "kkkkkkkkkkkkkkkk",
    "................",
    "................",
]
BAT_A = [
    "................",
    "................",
    "..k..........k..",
    ".knk........knk.",
    ".knnk..kk..knnk.",
    ".knnnkknnkknnnk.",
    "..knnnnnnnnnnk..",
    "...knnennennek..",
    "...knnnnnnnnk...",
    "....knnwwnnk....",
    ".....knnnnk.....",
    "......kkkk......",
    "................",
    "................",
    "................",
    "................",
]
BAT_B = [
    "................",
    "................",
    "................",
    "................",
    ".kk..........kk.",
    ".knnk.kkkk.knnk.",
    ".knnnkknnkknnnk.",
    "..knnnnnnnnnnk..",
    "...knnennennek..",
    "...knnnnnnnnk...",
    "....knnwwnnk....",
    ".....knnnnk.....",
    "......kkkk......",
    "................",
    "................",
    "................",
]
SKELETON_A = [
    "................",
    ".....kkkkkk.....",
    "....kmmmmmmk....",
    "...kmmmmmmmmk...",
    "...kmemmmmemk...",
    "...kmmmmmmmmk...",
    "....kmkkkkmk....",
    ".....kmmmmk.....",
    "...kmmkmmkmmk...",
    "..kMkm kkkk mk..".replace(' ', 'm'),
    "..kM.kmmmmk.Mk..",
    ".....kmmmmk.....",
    "....kmk..kmk....",
    "....kMk..kMk....",
    ".....kk....kk...",
    "................",
]
SKELETON_B = [
    "................",
    ".....kkkkkk.....",
    "....kmmmmmmk....",
    "...kmmmmmmmmk...",
    "...kmemmmmemk...",
    "...kmmmmmmmmk...",
    "....kmkkkkmk....",
    ".....kmmmmk.....",
    "...kmmkmmkmmk...",
    "..kMkmmmmmmkMk..",
    "..kM.kmmmmk.Mk..",
    ".....kmmmmk.....",
    ".....kmmmmk.....",
    "....kMmkkMk.....",
    "....kkk..kkk....",
    "................",
]
MAGE_A = [
    "................",
    "......kkk.......",
    ".....kpppk......",
    "....kpppppk.....",
    "...kpppppppk....",
    "..kkkkkkkkkkk...",
    "...knnnnnnnk....",
    "..knnvenvennk...",
    "..knnnnnnnnnk...",
    "..knpnnnnnpnk...",
    "...knnnnnnnk....",
    "....knnnnnk.....",
    "....knkknk......",
    ".....k..k.......",
    ".....knnk.......",
    "................",
]
MAGE_B = [
    "................",
    "......kkk.......",
    ".....kpppk......",
    "....kpppppk.....",
    "...kpppvpppk....",
    "..kkkkkkkkkkk...",
    "...knnnnnnnk....",
    "..knnvenvennk...",
    "..knnnnnnnnnk...",
    "..knpnnnnnpnk...",
    "...knnnnnnnk....",
    "....knnnnnk.....",
    "....knk.knk.....",
    "....k....k......",
    "....knnnnk......",
    "................",
]
# 魔王 32×32 ×2 帧（粗壮双足大恶魔）
BOSS_A = [
    "................................",
    "..kk........................kk..",
    ".kRRk......................kRRk.",
    ".kRRRk....kk......kk......kRRRk.",
    "..kRRk...kRRk....kRRk....kRRk...",
    "..kRRRk..kRRk....kRRk...kRRRk...",
    "...kRRRkkRRRkkkkkRRRkkkRRRk.....",
    "....kRRRRRRRRRRRRRRRRRRRk.......",
    "...kRRRRRRRRRRRRRRRRRRRRRk......",
    "..kRRRRRRRRRRRRRRRRRRRRRRRk.....",
    "..kRRRkkkkkkkkkkkkkkkkkRRRk.....",
    "..kRRkfffffffffffffffff kRRk....".replace(' ', 'f'),
    "..kRRkfRRRkkkkkkkkkkRRRfkRRk....",
    "..kRRkfRefkfkkkkkfkefRfkRRk.....",
    "..kRRkkkkkkkkkkkkkkkkkkkRRk.....",
    "..kRRRRRRRRRRRRRRRRRRRRRRRk.....",
    "...kRRRRRRRRRRRRRRRRRRRRRk......",
    "...kRRRPPPPPPPPPPPPPPPRRRk......",
    "..kRRRPPPvvvvvvvvvvvPPPRRRk.....",
    "..kRRPPPvvvvvvvvvvvvvPPPRRk.....",
    "..kRRPPPvvvvvvvvvvvvvPPPRRk.....",
    "..kRRRPPPvvvvvvvvvvvPPPRRRk.....",
    "...kRRRPPPPPPPPPPPPPPPRRRk......",
    "...kRRRRRRRRRRRRRRRRRRRRRk......",
    "..kRRRRRRRRRRRRRRRRRRRRRRRk.....",
    "..kRRRRkRRRRkkkkkRRRRkRRRRk.....",
    "..kRRRk.kRRRk...kRRRk.kRRRk.....",
    "..kRRk..kRRRk...kRRRk..kRRk.....",
    "..kbbk..kRRk.....kRRk..kbbk.....",
    "..kbbk..kkkk.....kkkk..kbbk.....",
    "..kkkk..................kkkk....",
    "................................",
]
BOSS_B = [
    "................................",
    "..kk........................kk..",
    ".kRRk......................kRRk.",
    ".kRRRk....kk......kk......kRRRk.",
    "..kRRk...kRRk....kRRk....kRRk...",
    "..kRRRk..kRRk....kRRk...kRRRk...",
    "...kRRRkkRRRkkkkkRRRkkkRRRk.....",
    "....kRRRRRRRRRRRRRRRRRRRk.......",
    "...kRRRRRRRRRRRRRRRRRRRRRk......",
    "..kRRRRRRRRRRRRRRRRRRRRRRRk.....",
    "..kRRRkkkkkkkkkkkkkkkkkRRRk.....",
    "..kRRkfffffffffffffffff kRRk....".replace(' ', 'f'),
    "..kRRkfRRRkkkkkkkkkkRRRfkRRk....",
    "..kRRkfRefkfkkkkkfkefRfkRRk.....",
    "..kRRkkkkkkkkkkkkkkkkkkkRRk.....",
    "..kRRRRRRRRRRRRRRRRRRRRRRRk.....",
    "...kRRRRRRRRRRRRRRRRRRRRRk......",
    "...kRRRPPPPPPPPPPPPPPPRRRk......",
    "..kRRRPPPvvvvvvvvvvvPPPRRRk.....",
    "..kRRPPPvvvvEvvvvvvvvPPPRRk.....",
    "..kRRPPPvvvvvvvvvEvvvPPPRRk.....",
    "..kRRRPPPvvvvvvvvvvvPPPRRRk.....",
    "...kRRRPPPPPPPPPPPPPPPRRRk......",
    "...kRRRRRRRRRRRRRRRRRRRRRk......",
    "..kRRRRRRRRRRRRRRRRRRRRRRRk.....",
    "..kRRRRkRRRRkkkkkRRRRkRRRRk.....",
    "..kRRRk.kRRRk...kRRRk.kRRRk.....",
    "...kRRk.kRRRk...kRRRk.kRRk......",
    "...kbbkkRRRk...kRRRkkbbk........",
    "...kbbkkkkkk...kkkkkkbbk........",
    "....kkkk..........kkkkk.........",
    "................................",
]

# ---------------- 地块（16×16） ----------------
def tile_grass(var=0):
    import random
    rnd = random.Random(7 + var)
    rows = []
    for y in range(16):
        row = ""
        for x in range(16):
            r = rnd.random()
            row += 'Q' if r < 0.62 else ('q' if r < 0.85 else 'W')
        rows.append(row)
    g = [list(r) for r in rows]
    if var == 1:      # 小花
        for cx, cy, ch in ((4, 4, 'y'), (10, 9, 'r'), (12, 3, 'w')):
            g[cy][cx] = ch
            g[cy - 1][cx] = 'W'
    return ["".join(r) for r in g]

TILE_GRASS_A = tile_grass(0)
TILE_GRASS_B = tile_grass(1)

TILE_TREE = [
    "....kkkkkk......",
    "..kkttttttkk....",
    ".kttTTTTTTttk...",
    ".ktTjjjjjTTttk..",
    "kttTjjjjjjTTttk.",
    "ktTjjjjjjjjTttk.",
    "ktTjjjjjjjjTtk..",
    "ktTjjjjjjjTTttk.",
    ".ktTjjjjjTTttk..",
    ".kttTTTTTTttk...",
    "..kkttttttkkk...",
    "....kkttkk......",
    "......kbbk......",
    "......kbbk......",
    ".....kBbbk......",
    "......kkkk......",
]
TILE_WATER_A = [
    "LLLLLLLLLLLLLLLL",
    "LCLLLLLLLKLLLLLL",
    "LLLLLCCLLLLLLLLL",
    "LLLLLLLLLLLCCCLL",
    "LKLLLLLLLLLLLLLL",
    "LLLCCLLLKLLLLLLL",
    "LLLLLLLLLLLCCLLL",
    "LLLLLLLLLLLLLLLL",
    "LLLLLKLLLLLLLLKL",
    "LCCCLLLLCCLLLLLL",
    "LLLLLLLLLLLKLLLL",
    "LLLLKLLLLLLLLCCL",
    "LLLLLLLLCCLLLLLL",
    "LLKLLLLLLLLLLKLL",
    "LLLLCCLLLLLLCCCL",
    "LLLLLLLLLLLLLLLL",
]
TILE_WATER_B = [
    "LLLLLLLLLLLLLLLL",
    "LLLLLKLLLLLLKLLL",
    "LLCCLLLLLCCLLLLL",
    "LLLLLLLCCLLLLLLL",
    "LLLLLLLLLLLCCCLL",
    "LCLLLLKLLLLLLLLL",
    "LLLLCCLLLLLLLLLL",
    "LLLLLLLLLLKLLLLL",
    "LLLLLLLLCCLLLLKL",
    "LKLLLLLLLLLLCCCL",
    "LLLLCCLLLLLLLLLL",
    "LLLLLLLLKLLLLLLL",
    "LLKLLLLLLLCCLLLL",
    "LLLLLCCCLLLLLLLL",
    "LLLLLLLLLLKLLLLL",
    "LLLLLLLLLLLLLLLL",
]
TILE_CAVE_FLOOR = [
    "dddddddddddddddd",
    "dDddddddddDddddd",
    "dddddudddddddddd",
    "dddddddddDdddudd",
    "dDdddddddddddddd",
    "ddddDdddddddddDd",
    "ddddddddDddddddd",
    "dddudddddddddddd",
    "dddddddddddDdddd",
    "dDdddudddddddddd",
    "ddddddddddduddDd",
    "ddddDddddddddddd",
    "ddddddddDddddddd",
    "ddduddddddddddud",
    "ddddddddDddddddd",
    "dddddddddddddddd",
]
TILE_CAVE_WALL = [
    "uuuuuuuuuuuuuuuu",
    "udDDDDudDDDDDudu",
    "udDDDDudDDDDDudu",
    "uuuuuuuuuuuuuuuu",
    "uDDDDuddDDDuddDu",
    "uDDDDuddDDDuddDu",
    "uuuuuuuuuuuuuuuu",
    "udDDDDDudDDDDDuu",
    "udDDDDDudDDDDDuu",
    "uuuuuuuuuuuuuuuu",
    "uDDDDuDuuDDDDDuu",
    "uDDDDuDuuDDDDDuu",
    "uuuuuuuuuuuuuuuu",
    "uDuddDDDDDuddDDu",
    "uDuddDDDDDuddDDu",
    "uuuuuuuuuuuuuuuu",
]
TILE_CASTLE_FLOOR = [
    "MMMMMMMMMMMMMMMM",
    "MmmmmmmmMMmmmmmm",
    "MmmmmmmmMMmmmmmm",
    "MmmmmmmmMMmmmmmm",
    "MMMMMMMMMMMMMMMM",
    "mmmmmMMmmmmmmmmm",
    "mmmmmMMmmmmmmmmm",
    "mmmmmMMmmmmmmmmm",
    "MMMMMMMMMMMMMMMM",
    "MmmmmmmmMMmmmmmm",
    "MmmmmmmmMMmmmmmm",
    "MmmmmmmmMMmmmmmm",
    "MMMMMMMMMMMMMMMM",
    "mmmmmMMmmmmmmmmm",
    "mmmmmMMmmmmmmmmm",
    "mmmmmMMmmmmmmmmm",
]
TILE_CASTLE_WALL = [
    "MMMMMMMMMMMMMMMM",
    "MHHHHHHHMmmmmmmM",
    "MHhhhhhHMmmmmmmM",
    "MHhhhhhHMmmmmmmM",
    "MHHHHHHHMmmmmmmM",
    "MmmmmmmMHHHHHHHM",
    "MmmmmmmMHhhhhhhM",
    "MmmmmmmMHhhhhhhM",
    "MMMMMMMMMMMMMMMM",
    "MHHHHHHHMmmmmmmM",
    "MHhhhhhHMmmmmmmM",
    "MHhhhhhHMmmmmmmM",
    "MHHHHHHHMmmmmmmM",
    "MmmmmmmMHHHHHHHM",
    "MmmmmmmMHhhhhhhM",
    "MMMMMMMMMMMMMMMM",
]
TILE_TORCH_A = [
    "................",
    "......kk........",
    ".....kffk.......",
    "....kfEffk......",
    "...kfEffffk.....",
    "...kffFfffk.....",
    "....kffFfk......",
    ".....kffk.......",
    "......kk........",
    "......kMk.......",
    "......kMk.......",
    ".....kMMMk......",
    "....kMMMMMk.....",
    "................",
    "................",
    "................",
]
TILE_TORCH_B = [
    "................",
    ".....kk.........",
    "....kffk........",
    "....kfEffk......",
    "...kfffEfk......",
    "...kffFfffk.....",
    "....kfFfk.......",
    ".....kffk.......",
    "......kk........",
    "......kMk.......",
    "......kMk.......",
    ".....kMMMk......",
    "....kMMMMMk.....",
    "................",
    "................",
    "................",
]
# 传送门 3 帧（16×16）
def portal(phase):
    rows = []
    for y in range(16):
        row = ""
        for x in range(16):
            dx = x - 7.5; dy = y - 7.5
            import math
            d = math.sqrt(dx * dx + dy * dy)
            ang = math.atan2(dy, dx) + phase * 2.09
            if d > 7.6:
                row += '.'
            elif d > 5.9:
                row += 'k'
            elif d > 2.2:
                row += 'v' if (math.sin(ang * 3 + d) > 0) else 'p'
            else:
                row += 'w' if phase == 1 else 'E'
        rows.append(row)
    return rows
PORTAL_A = portal(0)
PORTAL_B = portal(1)
PORTAL_C = portal(2)

# ---------------- 物品 ----------------
HEART_FULL = [
    "................",
    "...kk....kk.....",
    "..krrk..krrk....",
    ".krErrkkrrrrk...",
    ".krwrrrrrrrrk...",
    ".krrrrrrrrrrk...",
    ".krrrrrrrrrrk...",
    "..krrrrrrrrk....",
    "...krrrrrrk.....",
    "....krrrrk......",
    ".....krrk.......",
    "......kk........",
    "................",
    "................",
    "................",
    "................",
]
HEART_HALF = [
    "................",
    "...kk....kk.....",
    "..krrk..kMMk....",
    ".krErrkkMMMMk...",
    ".krwrrrrMMMMMk..",
    ".krrrrrrMMMMMk..",
    ".krrrrrrMMMMMk..",
    "..krrrrrMMMMk...",
    "...krrrrMMk.....",
    "....krrrk.......",
    ".....krk........",
    "......kk........",
    "................",
    "................",
    "................",
    "................",
]
HEART_EMPTY = [
    "................",
    "...kk....kk.....",
    "..kMMk..kMMk....",
    ".kMHMMkkMMMMk...",
    ".kMMMMMMMMMMk...",
    ".kMMMMMMMMMMk...",
    ".kMMMMMMMMMMk...",
    "..kMMMMMMMMk....",
    "...kMMMMMMk.....",
    "....kMMMMk......",
    ".....kMMk.......",
    "......kk........",
    "................",
    "................",
    "................",
    "................",
]
COIN = [
    "................",
    "................",
    "................",
    "................",
    ".....kkkkk......",
    "....kyyyyyk.....",
    "...kyEyyyyyk....",
    "...kyYyyYyyk....",
    "...kyyyYyyyyk...",
    "...kyyyyYyyyk...",
    "...kyyyyyYyyk...",
    "....kyyyyyk.....",
    ".....kkkkk......",
    "................",
    "................",
    "................",
]
POTION = [
    "................",
    "................",
    "......kkk.......",
    "......kMk.......",
    ".....kkMkk......",
    "....kMMMMk......",
    "...kMMrrMMk.....",
    "...kMrrrrMk.....",
    "...kMrRrrMk.....",
    "...kMrrrrMk.....",
    "....kMrrMk......",
    ".....kkkk.......",
    "................",
    "................",
    "................",
    "................",
]
CHEST_CLOSED = [
    "................",
    "................",
    "...kkkkkkkkkk...",
    "..kbbbbbbbbbbk..",
    ".kbyybbbbbbbybk.",
    ".kbbbbbbbbbbbbk.",
    ".kBBBBBBBBBBBBk.",
    ".kbbbbkkkkbbbbk.",
    ".kbbbkyykkbbbbk.",
    ".kbbbkyykkbbbbk.",
    ".kBBBBkkkkBBBBk.",
    ".kbbbbbbbbbbbbk.",
    "..kkkkkkkkkkkk..",
    "................",
    "................",
    "................",
]
CHEST_OPEN = [
    "................",
    "...kkkkkkkkkk...",
    "..kBBBBBBBBBBk..",
    ".kbBfffffffffBk.",
    ".kbBfEEEEEEEfBk.",
    ".kkkkkkkkkkkkkk.",
    ".kbbbbbbbbbbbbk.",
    ".kbbbkyyyykbbbk.",
    ".kbbbkyyyykbbbk.",
    ".kBBBkkkkkkBBBk.",
    ".kbbbbbbbbbbbbk.",
    ".kBBBBBBBBBBBBk.",
    "..kkkkkkkkkkkk..",
    "................",
    "................",
    "................",
]
FIREBALL = [
    "............",
    "....kkkk....",
    "...kffFkk...",
    "..kfEEffFk..",
    "..kfEwffFk..",
    ".kffEwfffFk.",
    ".kfffFfffok.",
    ".kfffFffFok.",
    "..kffffook..",
    "..kffFooik..".replace('i', 'k'),
    "...kokkkk...",
    "....kk......",
]
SHADOWBOLT = [
    "............",
    "....kkkk....",
    "...knnNkk...",
    "..knvvnnNk..",
    "..knvwnnNk..",
    ".knnvwnnnNk.",
    ".knnnnnnnNk.",
    ".knnnnnnnNk.",
    "..knnnnNk...",
    "..knnNNik...".replace('i', 'k'),
    "...kNkkk....",
    "....kk......",
]
# 剑图标（HUD 用）
SWORD_ICON = [
    "................",
    "..........kk....",
    ".........kzk....",
    "........kzzk....",
    ".......kzzk.....",
    "......kzzk......",
    ".....kzzk.......",
    "..k.kzzk........",
    "..kykzzk........",
    "...kyzk.........",
    "...kyyk.........",
    "..kyyyyk........",
    ".kyyyyyyk.......",
    ".kkkkkkkk.......",
    "................",
    "................",
]

# ---------------- 输出全部 ----------------
ALL = {
    "勇者_下A": HERO_D_A, "勇者_下B": HERO_D_B,
    "勇者_上A": HERO_U_A, "勇者_上B": HERO_U_B,
    "勇者_右A": HERO_R_A, "勇者_右B": HERO_R_B,
    "勇者_左A": HERO_L_A, "勇者_左B": HERO_L_B,
    "史莱姆A": SLIME_A, "史莱姆B": SLIME_B,
    "蝙蝠A": BAT_A, "蝙蝠B": BAT_B,
    "骷髅A": SKELETON_A, "骷髅B": SKELETON_B,
    "尸巫A": MAGE_A, "尸巫B": MAGE_B,
    "魔王A": BOSS_A, "魔王B": BOSS_B,
    "地块_草A": TILE_GRASS_A, "地块_草B": TILE_GRASS_B,
    "地块_树": TILE_TREE,
    "地块_水1": TILE_WATER_A, "地块_水2": TILE_WATER_B,
    "地块_洞地": TILE_CAVE_FLOOR, "地块_洞墙": TILE_CAVE_WALL,
    "地块_城地": TILE_CASTLE_FLOOR, "地块_城墙": TILE_CASTLE_WALL,
    "地块_火把A": TILE_TORCH_A, "地块_火把B": TILE_TORCH_B,
    "门A": PORTAL_A, "门B": PORTAL_B, "门C": PORTAL_C,
    "心_满": HEART_FULL, "心_半": HEART_HALF, "心_空": HEART_EMPTY,
    "金币": COIN, "药水": POTION,
    "宝箱_关": CHEST_CLOSED, "宝箱_开": CHEST_OPEN,
    "火球": FIREBALL, "暗弹": SHADOWBOLT,
    "剑图标": SWORD_ICON,
}
for name, rows in ALL.items():
    png(name, rows)

# ---------------- 对照图（全部精灵 4× 放大拼贴） ----------------
names = list(ALL.keys())
cols = 8
cell_w, cell_h = 4 * 32 + 12, 4 * 32 + 26
rows_n = (len(names) + cols - 1) // cols
sheet = Image.new("RGB", (cols * cell_w, rows_n * cell_h), (34, 36, 48))
from PIL import ImageDraw
draw = ImageDraw.Draw(sheet)
for i, name in enumerate(names):
    im = Image.open(os.path.join(OUT, name + ".png")).convert("RGBA")
    sc = 4 if max(im.size) <= 16 else 3
    im2 = im.resize((im.width * sc, im.height * sc), Image.NEAREST)
    cx = (i % cols) * cell_w + 6
    cy = (i // cols) * cell_h + 18
    sheet.paste(im2, (cx, cy), im2)
    draw.text((cx, cy - 14), name, fill=(230, 230, 230))
sheet.save("_魔域美术对照.png")
print(f"已生成 {len(ALL)} 个精灵 → {OUT}")
print("对照图 → _魔域美术对照.png")
