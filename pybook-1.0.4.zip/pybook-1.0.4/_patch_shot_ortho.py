# -*- coding: utf-8 -*-
"""给 _shot.c 加正交投影对比出图：
   shot_8_ortho34     3/4 视角 + 正交（半高 10）
   shot_9_ortho_top   正俯视 + 正交（半高 20）  ← 编辑器俯视图
   shot_10_persp_top  正俯视 + 透视（对照组）
每处断言 count==1。"""
import io, sys

def patch(path, patches):
    s = io.open(path, encoding='utf-8').read()
    for label, old, new in patches:
        n = s.count(old)
        if n != 1:
            sys.stderr.write('FAIL [%s] count=%d\n' % (label, n))
            sys.exit(1)
        s = s.replace(old, new, 1)
        print('ok  %s' % label)
    io.open(path, 'w', encoding='utf-8', newline='').write(s)

SHOTS = """    /* ④ 正交投影（hw.ortho）：同一份场景，换投影看差别。
       正俯视 + 正交 = 编辑器顶部俯视图；正俯视 + 透视 = 对照组（近大远小）。 */
    rt_hw_shaderuse(rt_int(0));

    g_模式 = 0; g_正交 = 10.0;
    printf("\\n[8] 正交 · 3/4 视角（半高 10）\\n");
    两帧出图("shot_8_ortho34");

    g_模式 = 1; g_正交 = 20.0;
    printf("\\n[9] 正交 · 正俯视（半高 20）—— 编辑器俯视图\\n");
    两帧出图("shot_9_ortho_top");

    g_模式 = 1; g_正交 = 0.0;
    printf("\\n[10] 透视 · 正俯视（对照组）\\n");
    两帧出图("shot_10_persp_top");

    g_模式 = 0; g_正交 = 0.0;          /* 复位，别影响后续 */

"""

patch('_shot.c', [
    # 1. 声明 + 两个开关（放在文件前部，布景() 与 main 都能用）
    ('shot:decl',
     "Value rt_hw_far(Value);",
     "Value rt_hw_far(Value);\n"
     "Value rt_hw_ortho(Value);\n"
     "/* 出图模式：0 = 3/4 斜视，1 = 正俯视；g_正交 0 = 透视，>0 = 正交半高 */\n"
     "static int   g_模式 = 0;\n"
     "static double g_正交 = 0.0;"),

    # 2. 相机：按模式切，并把正交开关喂进去
    ('shot:camera',
     "    rt_hw_camera(rt_float(9.5), rt_float(6.0), rt_float(9.5),\n"
     "                 rt_float(3.93), rt_float(-0.40));",
     "    rt_hw_ortho(rt_float(g_正交));\n"
     "    if (g_模式 == 1) {\n"
     "        /* 正俯视：架在原点正上方 40 格，俯仰 -90 度看下去。\n"
     "           z 给 0.1 而不是 0，避开创根号时的退化。 */\n"
     "        rt_hw_camera(rt_float(0), rt_float(40), rt_float(0.1),\n"
     "                     rt_float(0), rt_float(-1.5708));\n"
     "    } else {\n"
     "        rt_hw_camera(rt_float(9.5), rt_float(6.0), rt_float(9.5),\n"
     "                     rt_float(3.93), rt_float(-0.40));\n"
     "    }"),

    # 3. 三张对比图（插在 free(vs) 之后、"完成"之前）
    ('shot:main',
     "    free(vs); free(fs);",
     "    free(vs); free(fs);\n\n" + SHOTS.rstrip('\n') + "\n"),
])
