/* 关键探针：GLSL 120 能不能用？
 *
 * 为什么这个问题值钱：
 *   如果 #version 120 的着色器可编译，那 gl_Vertex / gl_Normal / gl_Color /
 *   gl_MultiTexCoord0 / gl_ModelViewProjectionMatrix / gl_NormalMatrix 这些
 *   "内建变量"全都能用 —— 它们由固定管线的立即模式（glBegin/glVertex3f）
 *   自动喂进来。也就是说：现有 1400 行的几何生成代码（draw_box /
 *   draw_sphere / draw_cyl 全是 glBegin）一行都不用改成 VBO，
 *   直接把可编程管线"贴"上去就能出画面。
 *
 *   反之如果只有 330 能用，就必须写 VBO/VAO 那 160 行。
 *
 * 顺带验证：自定义 uniform 能不能取到位置、glUniform* 系列指针存不存在
 * —— 它们决定了 hw.uni() 这条 API 能不能落地。 */

#define SDL_MAIN_HANDLED
#include <SDL2/SDL.h>
#include <GL/gl.h>
#include <GL/glext.h>
#include <stdio.h>

static PFNGLCREATESHADERPROC      pCreateShader;
static PFNGLSHADERSOURCEPROC      pShaderSource;
static PFNGLCOMPILESHADERPROC     pCompileShader;
static PFNGLGETSHADERIVPROC       pGetShaderiv;
static PFNGLGETSHADERINFOLOGPROC  pGetShaderInfoLog;
static PFNGLCREATEPROGRAMPROC     pCreateProgram;
static PFNGLATTACHSHADERPROC      pAttachShader;
static PFNGLLINKPROGRAMPROC       pLinkProgram;
static PFNGLGETPROGRAMIVPROC      pGetProgramiv;
static PFNGLGETPROGRAMINFOLOGPROC pGetProgramInfoLog;
static PFNGLGETUNIFORMLOCATIONPROC pGetUniformLocation;

/* 编译一个 vs+fs 对，成功返回 1。tag 只用于打印。 */
static int 试编译(const char *tag, const char *vs, const char *fs)
{
    printf("\n--- %s ---\n", tag);
    GLuint v = pCreateShader(GL_VERTEX_SHADER);
    GLuint f = pCreateShader(GL_FRAGMENT_SHADER);
    pShaderSource(v, 1, &vs, NULL);
    pShaderSource(f, 1, &fs, NULL);
    pCompileShader(v);
    pCompileShader(f);

    GLint ok = 0;
    pGetShaderiv(v, GL_COMPILE_STATUS, &ok);
    if (!ok) {
        char log[2048] = {0};
        pGetShaderInfoLog(v, sizeof log, NULL, log);
        printf("  顶点着色器 **编译失败**:\n%s\n", log);
        return 0;
    }
    pGetShaderiv(f, GL_COMPILE_STATUS, &ok);
    if (!ok) {
        char log[2048] = {0};
        pGetShaderInfoLog(f, sizeof log, NULL, log);
        printf("  片段着色器 **编译失败**:\n%s\n", log);
        return 0;
    }
    GLuint p = pCreateProgram();
    pAttachShader(p, v);
    pAttachShader(p, f);
    pLinkProgram(p);
    pGetProgramiv(p, GL_LINK_STATUS, &ok);
    if (!ok) {
        char log[2048] = {0};
        pGetProgramInfoLog(p, sizeof log, NULL, log);
        printf("  **链接失败**:\n%s\n", log);
        return 0;
    }
    printf("  编译+链接成功\n");
    return 1;
}

static void 查uniform(GLuint prog_unused, const char *name, const char *kind)
{
    (void)prog_unused;
    printf("    %-16s %s\n", name, kind);
}

int main(void)
{
    SDL_SetMainReady();
    if (SDL_Init(SDL_INIT_VIDEO) != 0) { printf("SDL init 失败\n"); return 1; }
    SDL_GL_SetAttribute(SDL_GL_DOUBLEBUFFER, 1);
    SDL_GL_SetAttribute(SDL_GL_DEPTH_SIZE, 24);
    SDL_Window *w = SDL_CreateWindow("gl120 probe", 0, 0, 320, 240,
                                     SDL_WINDOW_HIDDEN | SDL_WINDOW_OPENGL);
    if (!w) { printf("建窗失败: %s\n", SDL_GetError()); return 1; }
    SDL_GLContext c = SDL_GL_CreateContext(w);
    if (!c) { printf("建上下文失败: %s\n", SDL_GetError()); return 1; }

    printf("GL_VERSION  %s\n", (const char *)glGetString(GL_VERSION));
    printf("GLSL        %s\n", (const char *)glGetString(GL_SHADING_LANGUAGE_VERSION));

#define LOAD(n, t) p##n = (t)SDL_GL_GetProcAddress("gl" #n)
    LOAD(CreateShader, PFNGLCREATESHADERPROC);
    LOAD(ShaderSource, PFNGLSHADERSOURCEPROC);
    LOAD(CompileShader, PFNGLCOMPILESHADERPROC);
    LOAD(GetShaderiv, PFNGLGETSHADERIVPROC);
    LOAD(GetShaderInfoLog, PFNGLGETSHADERINFOLOGPROC);
    LOAD(CreateProgram, PFNGLCREATEPROGRAMPROC);
    LOAD(AttachShader, PFNGLATTACHSHADERPROC);
    LOAD(LinkProgram, PFNGLLINKPROGRAMPROC);
    LOAD(GetProgramiv, PFNGLGETPROGRAMIVPROC);
    LOAD(GetProgramInfoLog, PFNGLGETPROGRAMINFOLOGPROC);
    LOAD(GetUniformLocation, PFNGLGETUNIFORMLOCATIONPROC);
#undef LOAD
    if (!pCreateShader || !pCreateProgram || !pLinkProgram) {
        printf("函数指针取不到，后续无意义\n");
        return 1;
    }

    /* ① GLSL 120 —— 吃固定管线内建量的写法（最省事的路） */
    const char *vs120 =
        "#version 120\n"
        "varying vec3 vN;\n"
        "varying vec2 vUV;\n"
        "void main(){\n"
        "  vN = gl_NormalMatrix * gl_Normal;\n"
        "  vUV = gl_MultiTexCoord0.xy;\n"
        "  gl_Position = gl_ModelViewProjectionMatrix * gl_Vertex;\n"
        "}\n";
    const char *fs120 =
        "#version 120\n"
        "varying vec3 vN;\n"
        "varying vec2 vUV;\n"
        "uniform vec3 uLight;\n"
        "uniform vec3 uTint;\n"
        "uniform float uShine;\n"
        "uniform sampler2D uTex;\n"
        "void main(){\n"
        "  float d = max(dot(normalize(vN), normalize(uLight)), 0.0);\n"
        "  vec3 base = texture2D(uTex, vUV).rgb * uTint;\n"
        "  vec3 col = base * (0.35 + 0.65*d) + vec3(pow(d, 32.0) * uShine);\n"
        "  gl_FragColor = vec4(col, 1.0);\n"
        "}\n";
    int ok120 = 试编译("GLSL 120（固定管线内建量）", vs120, fs120);

    /* ② 同一份逻辑写成 330 core —— 对照，看是不是 120 特有问题 */
    const char *vs330 =
        "#version 330 core\n"
        "layout(location=0) in vec3 P;\n"
        "layout(location=1) in vec3 N;\n"
        "layout(location=2) in vec2 T;\n"
        "uniform mat4 MVP;\n"
        "out vec3 vN; out vec2 vUV;\n"
        "void main(){ vN=N; vUV=T; gl_Position = MVP*vec4(P,1.0); }\n";
    const char *fs330 =
        "#version 330 core\n"
        "in vec3 vN; in vec2 vUV;\n"
        "uniform sampler2D uTex; uniform vec3 uLight;\n"
        "out vec4 Frag;\n"
        "void main(){\n"
        "  float d = max(dot(normalize(vN), normalize(uLight)), 0.0);\n"
        "  Frag = vec4(texture(uTex, vUV).rgb * (0.35 + 0.65*d), 1.0);\n"
        "}\n";
    int ok330 = 试编译("GLSL 330 core（要 VBO）", vs330, fs330);

    printf("\n================ 结论 ================\n");
    printf("  GLSL 120 : %s\n", ok120 ? "可用 → 不必重写 VBO，现成 glBegin 几何直接吃"
                                     : "不可用 → 必须上 VBO/VAO");
    printf("  GLSL 330 : %s\n", ok330 ? "可用（备选）" : "不可用");

    SDL_GL_DeleteContext(c);
    SDL_DestroyWindow(w);
    SDL_Quit();
    return 0;
}
