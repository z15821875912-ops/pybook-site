/* PYbook 多线程内核（内部零件，语言层面零改动）：
 * 给 tb.* / np.* 的热点函数提供"偷偷用多核"的能力。
 *
 * 设计：
 *   - 固定 64 块切分：块边界只依赖 n，与线程数无关——
 *     归约类（sum/mse/crossent）按块号顺序相加，任何机器上位级一致。
 *   - 工人体只做"读 boxed 值 → 算 → 直写输出槽"，一律不分配 GC 内存，
 *     不触发 Memoryment，因此不需要锁运行时。
 *   - 主线程也领块干活，干完等其他工人交工（无忙等）。
 *   - PYBOOK_THREADS=1 环境变量可强制单线程（回归对照用）。
 */

#ifndef PYBOOK_MT_H
#define PYBOOK_MT_H

#include <stddef.h>

#define MT_CHUNKS 64   /* 固定切块数：归约按块号求和，结果与线程数无关 */

/* 有效工人数（含主线程）。PYBOOK_THREADS 环境变量优先。 */
int mt_workers(void);

/* 把 n 个元素切成 64 块并行处理。fn(cid, a, b, ud) 处理 [a, b) 区间。
 * 返回实际块数（串行路径为 1）。fn 内严禁分配 GC 内存、严禁再调 mt_parallel。
 * 约定：块边界恒为 a = n*cid/64, b = n*(cid+1)/64，n<=0 时只调 fn(0,0,0)。 */
int mt_parallel(long long n,
                void (*fn)(int cid, long long a, long long b, void *ud),
                void *ud);

#endif /* PYBOOK_MT_H */
