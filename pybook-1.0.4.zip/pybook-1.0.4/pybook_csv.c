/* PYbook csv. 库：表格文本 <-> 二维表（列表的列表，全字符串）。
 * csv.parse(文本) -> 二维表（支持引号包裹、"" 转义、引号内换行逗号）
 * csv.dump(二维表) -> 文本（含逗号/引号/换行的格子自动加引号）
 * 行尾 \r\n 与 \n 都认；末尾无换行也收。 */

#include "pybook_lib.h"

#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static void csv_die(const char *fmt, ...)
{
    va_list ap;
    fprintf(stderr, "运行时错误: csv.");
    va_start(ap, fmt);
    vfprintf(stderr, fmt, ap);
    va_end(ap);
    fputc('\n', stderr);
    exit(1);
}

/* ---- dump 缓冲 ---- */
typedef struct { char *s; size_t len, cap; } CsvBuf;

static void csv_buf_put_n(CsvBuf *b, const char *s, size_t n)
{
    if (b->len + n + 1 > b->cap) {
        b->cap = b->cap ? b->cap : 256;
        while (b->len + n + 1 > b->cap)
            b->cap *= 2;
        b->s = (char *)realloc(b->s, b->cap);
        if (!b->s)
            csv_die("dump 内存不足");
    }
    memcpy(b->s + b->len, s, n);
    b->len += n;
    b->s[b->len] = '\0';
}

static int csv_cell_needs_quotes(const char *s)
{
    return strpbrk(s, ",\"\n\r") != NULL;
}

Value rt_csv_parse(Value text)
{
    const char *p = rt_str_of(text);
    Value table = rt_list_new();
    Value row = rt_list_new();
    const char *cell = NULL;
    size_t cell_len = 0;
    int in_quotes = 0, cell_touched = 0;

    /* 用 RtList 存字符串时需要 rt_str 临时盒；为支持引号内任意内容，
     * 采用逐字符状态机，格子内容先攒在动态缓冲里。 */
    size_t cap = 64;
    char *buf = (char *)malloc(cap);
    size_t blen = 0;
    if (!buf)
        csv_die("parse 内存不足");

#define CSV_FLUSH() do { \
        char *tmp = (char *)malloc(blen + 1); \
        if (!tmp) csv_die("parse 内存不足"); \
        memcpy(tmp, buf, blen); tmp[blen] = '\0'; \
        rt_push(&row, rt_str(tmp)); \
        free(tmp); blen = 0; cell_touched = 0; \
    } while (0)

    while (*p) {
        if (in_quotes) {
            if (*p == '"') {
                if (p[1] == '"') {                   /* "" -> " */
                    if (blen + 2 > cap) { cap *= 2; buf = (char *)realloc(buf, cap); if (!buf) csv_die("parse 内存不足"); }
                    buf[blen++] = '"';
                    p += 2;
                    continue;
                }
                in_quotes = 0;
                p++;
                continue;
            }
            if (blen + 1 > cap) { cap *= 2; buf = (char *)realloc(buf, cap); if (!buf) csv_die("parse 内存不足"); }
            buf[blen++] = *p++;
            cell_touched = 1;
            continue;
        }
        if (*p == '"' && blen == 0) {
            in_quotes = 1;
            cell_touched = 1;
            p++;
            continue;
        }
        if (*p == ',') {
            CSV_FLUSH();
            p++;
            continue;
        }
        if (*p == '\n' || (*p == '\r' && p[1] == '\n')) {
            CSV_FLUSH();
            rt_push(&table, row);
            row = rt_list_new();
            cell_touched = 0;
            p += (*p == '\r') ? 2 : 1;
            continue;
        }
        if (*p == '\r') {                            /* 孤立 \r 当换行 */
            CSV_FLUSH();
            rt_push(&table, row);
            row = rt_list_new();
            p++;
            continue;
        }
        if (blen + 1 > cap) { cap *= 2; buf = (char *)realloc(buf, cap); if (!buf) csv_die("parse 内存不足"); }
        buf[blen++] = *p++;
        cell_touched = 1;
    }
    if (blen > 0 || cell_touched) {
        CSV_FLUSH();
        rt_push(&table, row);
    } else if (AS_LIST(row)->len > 0) {
        rt_push(&table, row);
    }
    free(buf);
    (void)cell;
    (void)cell_len;
    return table;
}

Value rt_csv_dump(Value table)
{
    if (!IS_LIST(table) || AS_LIST(table) == NULL)
        csv_die("dump 需要二维表（列表的列表）");
    CsvBuf b = { NULL, 0, 0 };
    RtList *R = AS_LIST(table);
    for (size_t i = 0; i < R->len; i++) {
        if (!IS_LIST(R->items[i]) || AS_LIST(R->items[i]) == NULL)
            csv_die("dump：第 %zu 行不是列表", i + 1);
        RtList *row = AS_LIST(R->items[i]);
        for (size_t j = 0; j < row->len; j++) {
            if (j) csv_buf_put_n(&b, ",", 1);
            const char *cell = rt_str_of(row->items[j]);
            if (csv_cell_needs_quotes(cell)) {
                csv_buf_put_n(&b, "\"", 1);
                for (const char *q = cell; *q; q++) {
                    if (*q == '"')
                        csv_buf_put_n(&b, "\"\"", 2);
                    else
                        csv_buf_put_n(&b, q, 1);
                }
                csv_buf_put_n(&b, "\"", 1);
            } else {
                csv_buf_put_n(&b, cell, strlen(cell));
            }
        }
        csv_buf_put_n(&b, "\n", 1);
    }
    if (!b.s) {
        b.s = (char *)malloc(1);
        if (!b.s)
            csv_die("dump 内存不足");
        b.s[0] = '\0';
    }
    return rt_str(b.s);                       /* 缓冲按项目约定分配不回收 */
}
