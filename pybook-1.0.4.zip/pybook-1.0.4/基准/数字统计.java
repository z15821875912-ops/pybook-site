import java.util.*;

public class 数字统计 {
    public static void main(String[] a) {
        int[] 数据 = {8, 3, 7, 2, 9, 4, 6, 5, 1, 0, 7, 3};
        long 偶数 = Arrays.stream(数据).filter(x -> x % 2 == 0).count();
        long 平方和 = Arrays.stream(数据).map(x -> x * x).sum();
        int[] 升序 = 数据.clone();
        Arrays.sort(升序);
        System.out.println("偶数个数: " + 偶数);
        System.out.println("平方和: " + 平方和);
        System.out.println("最大: " + Arrays.stream(数据).max().getAsInt()
            + " 最小: " + Arrays.stream(数据).min().getAsInt());
        System.out.println("含9: " + Arrays.stream(数据).filter(x -> x == 9).count());
        System.out.println("前三个: " + 升序[0] + " " + 升序[1] + " " + 升序[2]);
        System.out.println("后三个: " + 升序[9] + " " + 升序[10] + " " + 升序[11]);
    }
}
