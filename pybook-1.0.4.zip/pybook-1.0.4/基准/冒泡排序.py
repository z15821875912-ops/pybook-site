def 冒泡(表):
    n = len(表)
    for i in range(n - 1):
        for j in range(n - 1 - i):
            if 表[j] > 表[j + 1]:
                表[j], 表[j + 1] = 表[j + 1], 表[j]
    return 表

数据 = [5, 2, 9, 1, 7, 3, 8, 0]
结果 = 冒泡(数据.copy())
print(结果)
print("含0:", 0 in 结果)
