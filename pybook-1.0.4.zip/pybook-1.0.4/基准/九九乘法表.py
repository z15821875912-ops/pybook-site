for i in range(1, 10):
    行 = ""
    for j in range(1, i + 1):
        行 += f"{j}x{i}={i*j} "
    print(行)
