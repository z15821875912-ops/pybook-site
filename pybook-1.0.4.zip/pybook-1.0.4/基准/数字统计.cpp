#include <bits/stdc++.h>
using namespace std;
int main() {
    vector<int> 数据 = {8, 3, 7, 2, 9, 4, 6, 5, 1, 0, 7, 3};
    vector<int> 偶数, 平方;
    for (int x : 数据) {
        if (x % 2 == 0) 偶数.push_back(x);
        平方.push_back(x * x);
    }
    vector<int> 升序 = 数据;
    sort(升序.begin(), 升序.end());
    long long 平方和 = accumulate(平方.begin(), 平方.end(), 0LL);
    auto it9 = find(数据.begin(), 数据.end(), 9);
    cout << "偶数个数: " << 偶数.size() << "\n";
    cout << "平方和: " << 平方和 << "\n";
    cout << "最大: " << *max_element(数据.begin(), 数据.end())
         << " 最小: " << *min_element(数据.begin(), 数据.end()) << "\n";
    cout << "含9: " << (it9 != 数据.end()) << "\n";
    cout << "前三个: " << 升序[0] << " " << 升序[1] << " " << 升序[2] << "\n";
    cout << "后三个: " << 升序[9] << " " << 升序[10] << " " << 升序[11] << "\n";
}
