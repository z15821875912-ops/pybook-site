import javax.swing.*;
import java.awt.*;

public class 弹球 {
    static int x = 100, y = 100, vx = 4, vy = 3;
    public static void main(String[] a) {
        JFrame 窗 = new JFrame("弹球");
        JPanel 板 = new JPanel() {
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.setColor(new Color(16, 26, 38));
                g.fillRect(0, 0, 800, 500);
                g.setColor(new Color(255, 200, 80));
                g.fillOval(x - 10, y - 10, 20, 20);
            }
        };
        窗.add(板);
        窗.setSize(800, 500);
        窗.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        窗.setVisible(true);
        new Timer(16, e -> {
            x += vx;
            y += vy;
            if (x < 10 || x > 790) vx = -vx;
            if (y < 10 || y > 490) vy = -vy;
            板.repaint();
        }).start();
    }
}
