import tkinter as tk

root = tk.Tk()
root.title("弹球")
画布 = tk.Canvas(root, width=800, height=500, bg="#101a26", highlightthickness=0)
画布.pack()
x, y, vx, vy = 100.0, 100.0, 4, 3

def 每帧():
    global x, y, vx, vy
    x += vx
    y += vy
    if x < 10 or x > 790:
        vx = -vx
    if y < 10 or y > 490:
        vy = -vy
    画布.delete("all")
    画布.create_oval(x - 10, y - 10, x + 10, y + 10, fill="#ffc850")
    root.after(16, 每帧)

每帧()
root.mainloop()
