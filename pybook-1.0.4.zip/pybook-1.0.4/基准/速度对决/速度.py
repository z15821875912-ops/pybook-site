def fib(n):
    if n < 2:
        return n
    return fib(n - 1) + fib(n - 2)

s = 0
for i in range(5000000):
    s = s + i % 7
print("算术", s)
表 = []
for i in range(300000):
    表.append(i % 100)
t = 0
for k in range(len(表)):
    t = t + 表[k]
print("列表", t)
d = {}
for i in range(200000):
    d[i % 50000] = i
u = 0
for i in range(200000):
    u = u + d[i % 50000]
print("字典", u)
print("递归", fib(22))
