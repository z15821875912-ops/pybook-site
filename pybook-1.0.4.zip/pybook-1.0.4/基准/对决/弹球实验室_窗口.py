import tkinter as tk

root = tk.Tk()
root.title("弹球实验室")
画布 = tk.Canvas(root, width=800, height=560, bg="#f5f7ff", highlightthickness=0)
画布.pack()
球, 重力 = [], 400

def 加球(x, y):
    球.append([x, y, 5, 0])

def 点击(event):
    加球(event.x, event.y)

def 按键(event):
    global 重力
    if event.char == " ":
        加球(400, 60)
    if event.char == "c":
        球.clear()
    if event.keysym == "Up":
        重力 += 50
    if event.keysym == "Down":
        重力 -= 50

画布.bind("<Button-1>", 点击)
root.bind("<Key>", 按键)

def 每帧():
    for b in 球:
        b[3] += 重力 / 60
        b[0] += b[2] / 60
        b[1] += b[3] / 60
        if b[1] > 530:
            b[1] = 530
            b[3] *= -0.7
        if b[0] < 10 or b[0] > 790:
            b[2] *= -0.9
    画布.delete("all")
    for b in 球:
        画布.create_oval(b[0] - 10, b[1] - 10, b[0] + 10, b[1] + 10, fill="#503cdc")
    画布.create_text(16, 12, text=f"{len(球)} 球 · 重力 {重力} · 空格加球 C清空 上下调重力 鼠标点击生成", anchor="nw")
    root.after(16, 每帧)

每帧()
root.mainloop()
