import tkinter as tk

root = tk.Tk()
root.title("火箭动画")
cv = tk.Canvas(root, width=800, height=560, bg="#080818", highlightthickness=0)
cv.pack()

色 = {"R": "#ff8282", "k": "#141414", "r": "#e53935", "b": "#4285f4",
      "o": "#ffa726", "y": "#ffeb3b", ".": ""}
箭体 = [".......kk.......", "......krrk......", ".....krRRrk.....",
        "....krRRRRrk....", "...krRRRRRRrk...", "..krRRRRRRRRrk..",
        ".krRRRRRRRRRRrk.", "krRRkkbbbbkkRRrk", "krRkkbbbbkkRRrk.",
        "krRRkkbbbbkkRRrk", "krRRRRRRRRRRRRrk", "krRRRRRRRRRRRRrk",
        ".krRRRRRRRRRRrk.", "..krRRRRRRRRrk..", ".kkrRRRRRRRRrkk."]
火 = [["oyyo", "yyyy", ".yy."], ["yyyo", "yyyy", "y..y"], ["oyyo", ".yyy", "yy.y"]]
星 = [(60, 80), (150, 50), (240, 90), (330, 40), (420, 70), (510, 110), (600, 60),
      (690, 100), (100, 200), (300, 180), (500, 220), (700, 190), (200, 300),
      (600, 320), (90, 420), (700, 440)]

def 贴(img, 行表, 倍):
    for j, 行 in enumerate(行表):
        for i, c in enumerate(行):
            c2 = 色.get(c, "")
            if c2:
                img.put(c2, (i * 倍, j * 倍, i * 倍 + 倍, j * 倍 + 倍))

体图 = tk.PhotoImage(width=64, height=64)
贴(体图, 箭体, 4)
火图 = []
for f in 火:
    im = tk.PhotoImage(width=16, height=16)
    贴(im, f, 4)
    火图.append(im)

星id = []
for x, y in 星:
    星id.append(cv.create_oval(x - 2, y - 2, x + 2, y + 2, fill="#f0f0ff", outline=""))
体id = cv.create_image(368, 0, image=体图, anchor="nw")
火id = cv.create_image(384, 0, image=火图[0], anchor="nw")

计 = 0
def 每帧():
    global 计
    计 += 1
    y = 560 - (计 * 2 % 660)
    cv.coords(体id, 368, y)
    cv.coords(火id, 384, y + 62)
    cv.itemconfig(火id, image=火图[(计 // 5) % 3])
    if 计 % 30 == 0:
        for k2, sid in enumerate(星id):
            cv.itemconfig(sid, fill="#f0f0ff" if (k2 + 计) % 2 else "#555577")
    root.after(16, 每帧)

每帧()
root.mainloop()
