文本 = "苹果 香蕉 苹果 樱桃 香蕉 苹果 樱桃 梨 苹果"
词频 = {}
for 词 in 文本.split():
    词频[词] = 词频.get(词, 0) + 1
for 词, 次 in sorted(词频.items(), key=lambda x: -x[1]):
    print(词, 次)
