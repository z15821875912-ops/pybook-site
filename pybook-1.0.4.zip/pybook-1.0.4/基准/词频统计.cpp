#include <bits/stdc++.h>
using namespace std;
int main() {
    string 文本 = "苹果 香蕉 苹果 樱桃 香蕉 苹果 樱桃 梨 苹果";
    map<string, int> 词频;
    istringstream in(文本);
    string 词;
    while (in >> 词) 词频[词]++;
    vector<pair<string, int>> 项(词频.begin(), 词频.end());
    sort(项.begin(), 项.end(), [](auto& a, auto& b) { return a.second > b.second; });
    for (auto& [词, 次] : 项)
        cout << 词 << " x " << 次 << "\n";
}
