import java.util.*;

public class 词频统计 {
    public static void main(String[] a) {
        String 文本 = "苹果 香蕉 苹果 樱桃 香蕉 苹果 樱桃 梨 苹果";
        Map<String, Integer> 词频 = new HashMap<>();
        for (String 词 : 文本.split(" "))
            词频.merge(词, 1, Integer::sum);
        词频.entrySet().stream()
            .sorted(Map.Entry.<String, Integer>comparingByValue().reversed())
            .forEach(e -> System.out.println(e.getKey() + " x " + e.getValue()));
    }
}
