#define SDL_MAIN_HANDLED
#include <SDL2/SDL.h>
#include <cmath>
int main() {
    SDL_Init(SDL_INIT_VIDEO);
    SDL_Window* w = SDL_CreateWindow("弹球", SDL_WINDOWPOS_CENTERED,
                                     SDL_WINDOWPOS_CENTERED, 800, 500, 0);
    SDL_Renderer* r = SDL_CreateRenderer(w, -1, 0);
    float x = 100, y = 100, vx = 4, vy = 3;
    bool 跑 = true;
    while (跑) {
        SDL_Event e;
        while (SDL_PollEvent(&e))
            if (e.type == SDL_QUIT) 跑 = false;
        x += vx;
        y += vy;
        if (x < 10 || x > 790) vx = -vx;
        if (y < 10 || y > 490) vy = -vy;
        SDL_SetRenderDrawColor(r, 16, 26, 38, 255);
        SDL_RenderClear(r);
        SDL_SetRenderDrawColor(r, 255, 200, 80, 255);
        for (int d = -10; d <= 10; d++) {
            int span = (int)std::sqrt(100.0 - d * d);
            SDL_RenderDrawLine(r, (int)x - span, (int)y + d, (int)x + span, (int)y + d);
        }
        SDL_RenderPresent(r);
        SDL_Delay(16);
    }
}
