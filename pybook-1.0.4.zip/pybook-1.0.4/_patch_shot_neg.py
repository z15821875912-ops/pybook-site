# -*- coding: utf-8 -*-
"""给 _shot.c 加一张负数半高边界图：-5 应钳成 0，出图须与 shot_10 逐字节相同。"""
import io, sys

def patch(path, patches):
    s = io.open(path, encoding='utf-8').read()
    for label, old, new in patches:
        n = s.count(old)
        if n != 1:
            sys.stderr.write('FAIL [%s] count=%d\n' % (label, n))
            sys.exit(1)
        s = s.replace(old, new, 1)
        print('ok  %s' % label)
    io.open(path, 'w', encoding='utf-8', newline='').write(s)

patch('_shot.c', [
    ('shot:negclamp',
     '"shot_10_persp_top");',
     '"shot_10_persp_top");\n'
     '\n'
     '    /* 负数半高应被钳成 0（= 透视）：出图须与 shot_10 逐字节相同，\n'
     '       用来验 hw.ortho 的边界处理。 */\n'
     '    g_模式 = 1; g_正交 = -5.0;\n'
     '    printf("\\n[11] 负半高 -5（应钳成 0 = 透视，须与 shot_10 相同）\\n");\n'
     '    两帧出图("shot_11_negclamp");'),
])
