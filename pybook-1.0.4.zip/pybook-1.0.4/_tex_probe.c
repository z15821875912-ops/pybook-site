/* 贴图加载探针：真开一个 GL 上下文，调 rt_hw_tex 加载几个图，打印返回值。
   目的是证明 hw.tex 的"加载 + 上传 GL 纹理"这条链路真的通了，
   而不是静默失败退化成纯色。 */
#include "pybook_rt.h"
#include <stdio.h>

Value rt_hw_open(Value, Value, Value);
Value rt_hw_tex(Value, Value);
Value rt_hw_texuse(Value);
Value rt_hw_uv(Value);

int main(void)
{
    rt_hw_open(rt_int(320), rt_int(240), rt_str("tex probe"));

    struct { int slot; const char *p; } T[] = {
        { 1, "pybook_icon.jpg" },
        { 2, "_town.png" },
        { 3, "mymove_blue.png" },
        { 4, "__definitely_missing__.png" },
        { 5, "3D演示.pybk" },            /* 不是图片：解码必须失败且不崩 */
    };
    for (unsigned i = 0; i < sizeof T / sizeof T[0]; i++) {
        Value r = rt_hw_tex(rt_int(T[i].slot), rt_str(T[i].p));
        printf("slot %d  %-30s -> %lld\n", T[i].slot, T[i].p, rt_to_ll(r));
    }

    /* 顺带确认这三个 setter 不炸 */
    rt_hw_texuse(rt_int(2));
    rt_hw_uv(rt_int(4));
    printf("texuse/uv OK\n");
    return 0;
}
