@echo off
chcp 65001 >nul
cd /d C:/Users/zhuli/Desktop/pybook
"C:/Users/zhuli/AppData/Local/Programs/Python/Python311/python.exe" pybk_main.py games/披萨塔.pybk
