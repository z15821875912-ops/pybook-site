# PYbook v2 自动比对结果

- 用例总数：96　通过：96　失败：0　耗时 53.7s
- 运行方式：`C:\Users\zhuli\AppData\Local\Programs\Python\Python311\python.exe pybk_main.py tests/<用例>.pybk`（cwd=仓库根，剔除 COLUMNS）

## 汇总

| 用例 | 类型 | 结果 | 预期说明 |
|---|---|---|---|
| T01_comment_ok | normal | ✅ | 各位置注释均被忽略，只输出一行 注释OK |
| E01_no_at | error | ✅ | 缺 @ 行 → 第 1 行报错（实际会带 Python traceback，见 bug B1） |
| E02_empty_file | error | ✅ | 空程序 → 在 EOF 行报错（行号会算上文件尾注释，见 bug B1/B5；实际带 Python traceback） |
| E03_no_going | error | ✅ | 只有 @ 行缺 GOING → 在 EOF 行报错（见 bug B1/B5；实际带 Python traceback） |
| E04_after_stop | error | ✅ | GOING 之后再写语句 → 第 5 行报错（实际会带 Python traceback，见 bug B1） |
| E05_stop_line | error | ✅ | STOP 不与 } 同行 → 报错，但行号指向 EOF 行而非 STOP 所在第 5 行（bug B1/B5） |
| E06_missing_brace | error | ✅ | 缺收尾 } → 在 EOF 行报错（见 bug B1/B5；实际带 Python traceback） |
| T02_vars_ok | normal | ✅ | 整数/浮点/字符串/布尔字面量(true/false)/显示 true/false；重复赋值可改变类型（写 true/false 会报未声明，见 bug B8） |
| T02_uninit_none | normal | ✅ | 先赋值后声明语义：读到尚未赋值的变量得 空，之后读到 9 |
| T02_dynamic_ro | explore | ✅ | 观察：vg 也能装列表、vg_ro 也能装标量并可重新赋值（ro 前缀只是约定） |
| T03_list_ok | normal | ✅ | 列表字面量/下标读写/负下标/空列表/长度/添加/混合嵌套显示（布尔显示 true） |
| T03_index_oob | error | ✅ | 下标越界 → 运行时错误: 下标：下标越界，退出码 1 |
| T03_index_neg_oob | error | ✅ | 负下标越过头部 → 运行时错误: 下标：下标越界 |
| T03_index_float_read | error | ✅ | 浮点下标读 → 运行时错误: 下标：下标必须是整数 |
| T03_index_float_write | error | ✅ | 浮点下标写 → 运行时错误: 下标赋值：下标必须是整数 |
| T03_setindex_oob | error | ✅ | 下标写越界 → 运行时错误: 下标赋值：下标越界 |
| T03_list_plus_err | error | ✅ | 列表不支持 + 拼接 → 明确报错（设计如此） |
| T03_list_cmp_err | error | ✅ | 列表 == 深度相等（内容不同判假）；列表 < 直接报错（新语义） |
| T04_len_err | error | ✅ | 长度 用于整数 → 运行时错误 |
| T04_len_args | error | ✅ | 长度 无参 → 编译期 第 3 行: 长度 需要 1 个参数 |
| T05_add_ret_none | normal | ✅ | list.添加 返回空盒，且确实修改了原列表 |
| T05_add_form_err | error | ✅ | 添加 第一个参数不是变量名 → 编译期报错 |
| T05_add_undeclared | error | ✅ | 添加 未声明的列表 → 编译期报 未声明 |
| T06_show_ok | normal | ✅ | 文本/变量/表达式插值、空 show 输出空行、循环内 $at+1、$s+$s 拼接 |
| T06_dollar_empty | error | ✅ | $ 后无名字 → 第 3 行报错（实际会带 Python traceback，见 bug B1） |
| T06_show_unclosed | error | ✅ | ns.show 缺右括号 → 第 3 行报错（实际会带 Python traceback，见 bug B1） |
| T06_interp_paren_text | explore | ✅ | 观察：$f(1) 中括号按普通文本输出（$ 只取到标识符 f） |
| T06_interp_call | explore | ✅ | 观察：插值里 $list.函数(实参) 实际能调用函数（与“插值不能用小括号”的说明不符） |
| T07_magic_ok | normal | ✅ | b/i/u/d/c/bk 依次输出对应 ANSI 转义序列，行尾重置 |
| T07_align_ok | normal | ✅ | fl/fm/fr 与 l/m/r 对齐一致：左 0、居中 (80-字节数)//2、右 80-字节数 个空格 |
| T07_magic_font_err | error | ✅ | 字体类样式 f → 运行时错误: 不支持的样式 f（终端做不到，设计如此） |
| T07_magic_alias_err | error | ✅ | / 后不是 magic → 第 3 行报错（实际会带 Python traceback，见 bug B1） |
| T07_magic_color_partial | error | ✅ | 颜色缺分量 → 第 3 行报错（实际会带 Python traceback，见 bug B1） |
| T08_around_ok | normal | ✅ | 计数循环累加 0+1+2+3=6；嵌套循环内层 at 从 0 起、遮蔽外层；$at $at 之间的空格保留为文本 |
| T08_around_edge | normal | ✅ | 0 次不执行；值为整数的浮点次数 2.0 按 2 次执行 |
| T08_around_float_err | error | ✅ | 2.5 次应报错；注意实际前缀是英文 runtime error: 而非“运行时错误:”（bug B4） |
| T08_at_outside | error | ✅ | 循环外用 at → 编译期 第 3 行: 变量 'at' 未声明 |
| T09_aging_ok | normal | ✅ | 条件不满足就一直跑：输出 0/1/2 后条件满足停止 |
| T09_aging_zero | normal | ✅ | 条件一开始就满足 → 循环体一次都不执行 |
| T10_vc_ok | normal | ✅ | if/elif/else 命中正确分支；else  与 else 等价；空列表为假（条件用 true 字面量） |
| T10_vc_minus_solo | error | ✅ | else 单独开头 → 第 3 行报错（实际会带 Python traceback，见 bug B1） |
| T10_vc_plus_mid | error | ✅ | 链中间再写 if → 两个独立 if 块都执行，输出 一/二（新语法下不再报错） |
| T11_when_ok | normal | ✅ | when 块按数字升序稳定提到本层最前，同级保持书写顺序，其余语句顺序不变 |
| T11_when_float | error | ✅ | when 优先级写成 1.5 → 第 5 行报错（实际会带 Python traceback，见 bug B1） |
| T12_fn_ok | normal | ✅ | 两参函数、递归阶乘、裸 ret 返回空盒（多参调用放在普通赋值里；插值里写多参调用见 E13） |
| T12_fn_dup | error | ✅ | 重复定义函数 → 第 5 行（第二个 fv 所在行）报错（干净输出，无 traceback） |
| T12_fn_undef | error | ✅ | 调用未定义函数 → 第 3 行报错 |
| T12_fn_args | error | ✅ | 实参个数不符 → 第 6 行（调用所在行）报错 |
| T12_fn_forward | explore | ✅ | 观察：先定义的函数调用后定义的函数 → 编译期判 未定义（不支持前向引用） |
| T12_ret_in_going | error | ✅ | ret 写进 GOING → 第 3 行报错 |
| T12_fn_scope | explore | ✅ | 观察：函数内看不到 GOING 的变量（每个函数独立作用域） |
| T13_lock_read_ok | normal | ✅ | lock 锁定后仍可读取（不报错，正常输出 5） |
| T13_lock_assign_err | error | ✅ | 锁后再赋值 → 运行时错误: 变量已锁定 |
| T13_del_read_err | error | ✅ | 删后再读 → 运行时错误: 用已删除变量 |
| T13_del_assign_err | error | ✅ | 删后再赋值 → 运行时错误: 用已删除变量 |
| T13_lock_undeclared | error | ✅ | lock 未声明变量 → 编译期报 未声明 |
| T13_lock_setindex | normal | ✅ | 锁后下标写 → 运行时错误: 变量已锁定（路径已统一拦截） |
| T13_lock_push | explore | ✅ | 观察：锁后 list.添加 现在也被拦截（与下标写一致），报 变量已锁定 |
| T14_arith_ok | normal | ✅ | 四则/取模/整除（Python 语义负数向下）、优先级、/ 得浮点、%.15g 去尾零 |
| T14_cmp_ok | normal | ✅ | 六种比较、字符串按字节比较、浮点与整数比较 |
| T14_logic_ok | normal | ✅ | and/or 返回操作数本身（短路取值）；not 返回真/false |
| T14_shortcircuit | normal | ✅ | 短路：false and / true or 不执行右侧（右侧若执行会除零崩溃） |
| T14_strcat_ok | normal | ✅ | 字符串 + 拼接 |
| T14_strnum_err | error | ✅ | 字符串 + 数字 → 运行时错误: 类型不可相加 |
| T14_divzero_int | error | ✅ | 整除零 → 运行时错误: 除以零 |
| T14_divzero_fdiv | error | ✅ | // 除零 → 运行时错误: 除以零 |
| T14_divzero_mod | error | ✅ | % 除零 → 运行时错误: 除以零 |
| T14_divzero_float | error | ✅ | 浮点除零 → 运行时错误: 除以零 |
| T14_neg_err | error | ✅ | 一元负号对整数/浮点正常；对字符串 → 运行时错误 |
| T14_chain_cmp | explore | ✅ | 观察：链式比较按 (1<x)<3 解释、布尔当 0/1 参与 → 0 时整体为真（与 Python 不同） |
| T15_lit_max_ok | normal | ✅ | 64 位最大整数字面量正常显示 |
| T15_lit_over | error | ✅ | 超大整数字面量 → 编译期 第 3 行报错 |
| T15_runtime_overflow | error | ✅ | 运行期加法溢出 → 运行时错误: 溢出 |
| T15_neg_min_literal | explore | ✅ | 观察：负号是独立运算符，-9223372036854775808 的字面量部分越界 → 无法书写 LLONG_MIN |
| T16_input_ok | normal | ✅ | 字符串输入、整数输入参与运算；提示符原样输出不换行 |
| T16_input_float | normal | ✅ | 小数输入解析为浮点，3.5*2=7 显示为 7 |
| T16_input_empty | normal | ✅ | 空行输入 → 空字符串，长度 0 |
| E07_paren_unbalanced | error | ✅ | 括号不配对 → 第 4 行（} 所在行）报错（实际会带 Python traceback，见 bug B1） |
| E08_deep_nest | error | ✅ | 300 层嵌套括号 → 前端 Python 递归爆栈，报 maximum recursion depth exceeded（无行号，见 bug B2） |
| E10_illegal_char | error | ✅ | 非法字符 ？ → 第 3 行报错（实际会带 Python traceback，见 bug B1） |
| E11_unterminated_str | error | ✅ | 字符串未闭合 → 第 3 行报错（实际会带 Python traceback，见 bug B1） |
| E09_long_line | error | ✅ | 70000 字符的超长一行显示 → 运行时错误: 一行太长（运行时 64KB 行缓冲上限） |
| E12_dollar_adjacent | explore | ✅ | 观察：$at$at 的内部 $ 被去掉后拼成 atat 一个名字 → 报“变量 'atat' 未声明”，名字是拼接出来的（bug B6） |
| E13_interp_comma | explore | ✅ | 观察：插值遇逗号被截断，$list.加(3 被当成变量 out → 报“变量 'out' 未声明”，有误导性（bug B7） |
| E14_trailing_comment | explore | ✅ | 观察：EOF 锚定的报错行号把文件尾注释全部计入（bug B5 的直接演示） |
| E15_bool_cjk_literal | explore | ✅ | 观察：布尔字面量只能写 true/false；写 true 被当成未声明变量，报错误导（bug B8） |
| T17_mem_normal_ok | normal | ✅ | 文件级 @normal：del 只打逻辑删除标志，不再使用则正常结束（输出 1 与 结束） |
| T17_mem_self_del_ok | normal | ✅ | 文件级 @self：del 真正释放列表/字符串，删后不再使用则正常结束（输出 结束） |
| T17_mem_self_use_err | error | ✅ | @self 删除后再读取 → 运行时错误: 用已删除变量 |
| T17_mem_1_use_err | error | ✅ | @1（=自动托管/normal）删除后再读取 → 运行时错误: 用已删除变量 |
| T17_mem_normal_use_err | error | ✅ | @normal 删除后再读取 → 与 @1 用例逐字节相同的错误输出（两者等价） |
| T17_mem_2_eq_self | error | ✅ | @2（=完全手动/self）删除后再读取 → 与 @self 完全相同的运行时错误 |
| T17_mem_3_unimpl | normal | ✅ | @3（引用计数）现已实现：空 GOING 块正常结束，退出码 0 |
| T17_mem_switch_self_normal | normal | ✅ | 语句级声明+切换：先 @self 真删列表，再 @normal 切回自动托管，后续 del 只打标志，正常结束（输出 结束） |
| T17_lock_del_together | error | ✅ | lock 与 del 同用互不干扰：双标志后先触发 用已删除变量 |
| T17_mem_in_fn | normal | ✅ | 函数内声明 Memoryment：全局开关从声明处生效，函数内删除、函数外切回 @normal 均正常（输出 1 与 结束） |
