# -*- coding: utf-8 -*-
"""PYbook v2 编译器测试 Runner。

用法（在工作目录 C:\\Users\\zhuli\\Desktop\\pybook 下，或任意目录均可，脚本自己定位根目录）：
    python tests\\run_tests.py            # 生成全部 .pybk 并逐个运行、比对
    python tests\\run_tests.py --only T03_list_ok,T10_vc_ok   # 只跑指定用例
    python tests\\run_tests.py --list      # 只列出用例不运行

流程：把 cases.py 里的每个用例物化成 tests\\<id>.pybk（尾部追加 "# 预期" 注释块），
然后逐个执行
    <python> pybk_main.py tests\\<id>.pybk   （cwd = 仓库根，剔除 COLUMNS 环境变量）
并与预期 stdout / stderr / 退出码严格比对，结果写入 tests\\results.md。
"""
import argparse
import os
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
from cases import CASES  # noqa: E402

PY = sys.executable


def _sanitize(comment: str) -> str:
    """注解注释里的 ASCII 括号转全角：注释虽不产生 Token，但未闭合的
    ns.show( 会用 scan_raw 在【原始源码】里找下一个 )，ASCII 括号会提前截住它。"""
    for a, b in (("(", "（"), (")", "）"), ("{", "｛"), ("}", "｝"),
                 ("[", "［"), ("]", "］")):
        comment = comment.replace(a, b)
    return comment


def materialize(case):
    """把用例写成 tests/<id>.pybk，尾部追加纯注释的预期块（注释不产生 Token）。

    err / err_contains 里的 {EOF} 会被替换成生成文件的 EOF 行号——
    因为前端按物理行计数，文件尾注释会把“到文件尾才发现的错误”的行号推大
    （这正是 bug B5 的行为，测试直接把它固定下来）。"""
    path = os.path.join(HERE, case["id"] + ".pybk")
    src = case["src"]
    body = src if src.endswith("\n") else src + "\n"
    lines = [
        "",
        "# " + "=" * 64,
        "# 用例 " + case["id"] + " 预期：" + _sanitize(case.get("expect", "")),
        "# 退出码: " + str(case.get("exit", 0)),
    ]
    if "out" in case:
        lines.append("# stdout（转义显示）: " + _sanitize(ascii(case["out"])))
    if "err" in case:
        lines.append("# stderr（转义显示）: " + _sanitize(ascii(case["err"])))
    for s in case.get("err_contains", []):
        lines.append("# stderr 须包含: " + _sanitize(ascii(s)))
    eof_line = body.count("\n") + len(lines) + 1   # 最后一行之后即 EOF 所在行
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        f.write(body)
        f.write("\n".join(_sanitize(x).replace("{EOF}", str(eof_line)) for x in lines) + "\n")

    adjusted = dict(case)
    if "err" in case:
        adjusted["err"] = case["err"].replace("{EOF}", str(eof_line))
    if "err_contains" in case:
        adjusted["err_contains"] = [s.replace("{EOF}", str(eof_line))
                                    for s in case["err_contains"]]
    return adjusted


def run_case(case):
    env = {k: v for k, v in os.environ.items() if k != "COLUMNS"}
    return subprocess.run(
        [PY, "pybk_main.py", "tests/" + case["id"] + ".pybk"],
        cwd=ROOT, env=env,
        input=case.get("stdin"),
        stdin=None if case.get("stdin") else subprocess.DEVNULL,
        capture_output=True, text=True, encoding="utf-8", errors="replace",
        timeout=120,
    )


def check(case, p):
    """返回 (通过?, 问题列表)。stdout/stderr 统一按 \n 比对。"""
    problems = []
    out = p.stdout.replace("\r\n", "\n")
    err = p.stderr.replace("\r\n", "\n")
    if "out" in case and out != case["out"]:
        problems.append("stdout 不一致\n  期望: " + ascii(case["out"])
                        + "\n  实际: " + ascii(out))
    if "err" in case and err != case["err"]:
        problems.append("stderr 不一致\n  期望: " + ascii(case["err"])
                        + "\n  实际: " + ascii(err))
    for s in case.get("err_contains", []):
        if s.lower() not in err.lower():
            problems.append("stderr 缺少子串: " + ascii(s) + "\n  实际: " + ascii(err))
    want_exit = case.get("exit", 0)
    if p.returncode != want_exit:
        problems.append(f"退出码不一致 期望 {want_exit} 实际 {p.returncode}")
    return (not problems), problems


def fmt_expected(case) -> str:
    bits = [f"退出码={case.get('exit', 0)}"]
    if "out" in case:
        bits.append("stdout=" + ascii(case["out"]))
    if "err" in case:
        bits.append("stderr=" + ascii(case["err"]))
    if case.get("err_contains"):
        bits.append("stderr包含=" + " && ".join(ascii(s) for s in case["err_contains"]))
    return "  ".join(bits)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--only", default="", help="逗号分隔的用例 id")
    ap.add_argument("--list", action="store_true")
    args = ap.parse_args()

    only = {s.strip() for s in args.only.split(",") if s.strip()}
    todo = [c for c in CASES if not only or c["id"] in only]
    if args.list:
        for c in todo:
            print(f"{c['id']:26s} [{c['kind']:7s}] {c.get('expect','')}")
        print(f"共 {len(todo)} 例")
        return 0

    results_tmp = []
    for c in todo:
        results_tmp.append(materialize(c))

    results = []
    t0 = time.time()
    for i, c in enumerate(results_tmp, 1):
        try:
            p = run_case(c)
            ok, problems = check(c, p)
        except subprocess.TimeoutExpired:
            ok, problems = False, ["运行超时（>120s）"]
        results.append((c, ok, problems))
        print(f"[{i:>2}/{len(todo)}] {'通过' if ok else '失败'}  {c['id']}", flush=True)

    elapsed = time.time() - t0
    passed = sum(1 for _c, ok, _p in results if ok)
    failed = [r for r in results if not r[1]]

    with open(os.path.join(HERE, "results.md"), "w", encoding="utf-8", newline="\n") as f:
        f.write("# PYbook v2 自动比对结果\n\n")
        f.write(f"- 用例总数：{len(results)}　通过：{passed}　失败：{len(failed)}　耗时 {elapsed:.1f}s\n")
        f.write(f"- 运行方式：`{PY} pybk_main.py tests/<用例>.pybk`（cwd=仓库根，剔除 COLUMNS）\n\n")
        f.write("## 汇总\n\n| 用例 | 类型 | 结果 | 预期说明 |\n|---|---|---|---|\n")
        for c, ok, _p in results:
            f.write(f"| {c['id']} | {c['kind']} | {'✅' if ok else '❌'} | {c.get('expect','')} |\n")
        if failed:
            f.write("\n## 失败详情\n\n")
            for c, _ok, problems in failed:
                f.write(f"### {c['id']}\n\n- 预期：{fmt_expected(c)}\n")
                for p in problems:
                    f.write(f"- {p}\n")
                f.write("\n")

    print(f"\n合计 {len(results)} 例：通过 {passed}，失败 {len(failed)}，耗时 {elapsed:.1f}s")
    if failed:
        print("失败用例：", ", ".join(c["id"] for c, _o, _p in failed))
        print("详情见 tests\\results.md")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
