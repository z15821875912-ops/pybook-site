# 飞船大战 v3 · Python(pygame) 对照版
# 对照 PYbook games/飞船大战.pybk（741 行）——同功能，看行数差多少。
# 运行：pip install pygame 后  python games/飞船大战_py.py
import pygame, random, math, sys

pygame.init()
屏宽, 屏高, FPS = 800, 600, 60
屏 = pygame.display.set_mode((屏宽, 屏高))
pygame.display.set_caption("飞船大战 v3 (Python)")
钟 = pygame.time.Clock()

def 字体(大小):
    return pygame.font.SysFont("microsoftyahei", 大小)

# ---------- 实体基类（对应 lb.类，支持 x=1,y=2 关键字构造） ----------
class 实体:
    def __init__(self, **kw):
        self.x = 0; self.y = 0; self.宽 = 0; self.高 = 0
        for k, v in kw.items():
            setattr(self, k, v)

class 星(实体):
    def __init__(self, **kw): super().__init__(x=0, y=0, 速=1, **kw)
class 飞船(实体):
    def __init__(self, **kw): super().__init__(x=400, y=520, 血=3, 宽=44, 高=40, **kw)
class 弹(实体):
    def __init__(self, **kw): super().__init__(x=0, y=0, 宽=8, 高=20, **kw)
class 敌机(实体):
    def __init__(self, **kw): super().__init__(x=0, y=0, 型=1, 血=1, 相=0, 计=80, 宽=36, 高=36, **kw)
class 敌弹(实体):
    def __init__(self, **kw): super().__init__(x=0, y=0, vx=0, vy=0, 宽=14, 高=14, **kw)
class 爆(实体):
    def __init__(self, **kw): super().__init__(x=0, y=0, 帧=0, **kw)
class 母舰(实体):
    def __init__(self, **kw): super().__init__(x=400, y=-90, 血=60, 活=0, 入场=1, 向=1, 式=0, 计=0, 帧=0, 闪=0, 宽=184, 高=64, **kw)

# ---------- 框架糖（对应 PYbook 的 添加/删掉/碰到/字/图/color/clear/box） ----------
def 添加(表, 物): 表.append(物)
def 删掉(表, 物):
    if 物 in 表: 表.remove(物)
def 碰到(a, b):
    return abs(a.x - b.x) * 2 < (a.宽 + b.宽) and abs(a.y - b.y) * 2 < (a.高 + b.高)
def 字(x, y, 文, 大小, 色=None):
    色2 = 色 if 色 else 当前色
    图字 = 字体(大小).render(文 if isinstance(文, str) else str(文), True, 色2)
    屏.blit(图字, (int(x), int(y)))
_图存 = {}
def 图(x, y, 路径):
    if 路径 not in _图存:
        try: _图存[路径] = pygame.image.load(路径)
        except Exception: _图存[路径] = None
    s = _图存[路径]
    if s: 屏.blit(s, (int(x), int(y)))
    else: pygame.draw.rect(屏, 当前色, (int(x), int(y), 20, 20))
def 图缩(x, y, w, h, 路径):
    if 路径 not in _图存:
        try: _图存[路径] = pygame.image.load(路径)
        except Exception: _图存[路径] = None
    s = _图存[路径]
    if s: 屏.blit(pygame.transform.scale(s, (int(w), int(h))), (int(x), int(y)))
    else: pygame.draw.rect(屏, 当前色, (int(x), int(y), int(w), int(h)))

当前色 = (255, 255, 255)
def color(r, g, b):
    global 当前色; 当前色 = (r, g, b)
def clear():
    屏.fill(当前色)
def box(x, y, w, h):
    pygame.draw.rect(屏, 当前色, (int(x), int(y), int(w), int(h)))

def rd_int(a, b): return random.randint(a, b)
def mt_sin(x): return math.sin(x)
def mt_mod(a, b): return a % b

# ---------- 键状态（对应 key 按住 / hit 本帧按下） ----------
键名 = {"left": pygame.K_LEFT, "right": pygame.K_RIGHT, "up": pygame.K_UP, "down": pygame.K_DOWN,
        "a": pygame.K_a, "d": pygame.K_d, "w": pygame.K_w, "s": pygame.K_s,
        "space": pygame.K_SPACE, "p": pygame.K_p, "r": pygame.K_r, "m": pygame.K_m}
按住集, 本帧按下 = set(), set()
def key(名): return 键名.get(名) in 按住集
def hit(名): return 键名.get(名) in 本帧按下

# ---------- 提示横幅（对应 ns.show） ----------
提示, 提示计 = "", 0
def ns_show(文):
    global 提示, 提示计; 提示 = 文; 提示计 = 120

# ================= 一次性初始化（对应 window(normal,open) 到 win(...) 之前） =================
星空 = []
for _ in range(14):
    添加(星空, 星(x=rd_int(0, 799), y=rd_int(0, 599), 速=rd_int(1, 3)))
我弹, 敌群, 敌弹, 烟花 = [], [], [], []
船 = 飞船()
无敌, 射冷, 帧, 状态, 最高分 = 0, 0, 0, 0, 0
重置旗, 待爆旗, 待爆x, 待爆y = 0, 0, 0, 0
分, 游戏帧, 波, 波内帧, 生成计时, 重舰计时, 横幅, 受击旗 = 0, 0, 1, 0, 50, 220, 0, 0
boss = 母舰()

# ================= 主循环（对应 GOING 每帧体） =================
退出 = False
while not 退出:
    帧 += 1
    本帧按下 = set()
    for 事件 in pygame.event.get():
        if 事件.type == pygame.QUIT: 退出 = True
        elif 事件.type == pygame.KEYDOWN: 本帧按下.add(事件.key); 按住集.add(事件.key)
        elif 事件.type == pygame.KEYUP: 按住集.discard(事件.key)
    if 提示计 > 0: 提示计 -= 1

    # ---- 键盘状态机 ----
    if 状态 == 0 and hit("space"):
        重置旗 = 1; 状态 = 1; ns_show("★ 出击！第 1 波敌军来袭 ★")
    if 状态 == 1 or 状态 == 2:
        if hit("p"):
            if 状态 == 1: 状态 = 2; ns_show("已暂停：P 继续 · R 重开 · M 主菜单")
            else: 状态 = 1
        if hit("r"): 重置旗 = 1; 状态 = 1; ns_show("★ 重新开始 ★")
        if hit("m"): 状态 = 0; ns_show("回到主菜单：按 空格 开始")
    if 状态 == 3 or 状态 == 4:
        if hit("r"): 重置旗 = 1; 状态 = 1; ns_show("★ 重新开始 ★")
        if hit("m"): 状态 = 0; ns_show("回到主菜单：按 空格 开始")

    # ---- 开新局 ----
    if 重置旗 == 1:
        重置旗 = 0; 船 = 飞船(); 无敌 = 110; 射冷 = 0; 分 = 0; 游戏帧 = 0
        波 = 1; 波内帧 = 0; 生成计时 = 50; 重舰计时 = 220; 横幅 = 100; 受击旗 = 0
        我弹, 敌群, 敌弹, 烟花 = [], [], [], []; boss = 母舰()

    # ---- 星空滚动 ----
    if 状态 == 0 or 状态 == 1:
        for s in 星空:
            s.y = mt_mod(s.y + s.速, 600)

    # ---- 爆炸推进 ----
    if 状态 == 1 or 状态 == 4:
        for p in list(烟花):
            p.帧 += 1
            if p.帧 > 18: 删掉(烟花, p)

    # ================= 主菜单 =================
    if 状态 == 0:
        color(6, 6, 24); clear()
        for s in 星空:
            color(90, 100, 140) if s.速 == 1 else color(150, 165, 210) if s.速 == 2 else color(220, 230, 255)
            box(s.x, s.y, 2, 2)
        color(12, 30, 60); box(140, 70, 520, 110)
        color(0, 220, 200); box(140, 70, 520, 5); box(140, 175, 520, 5)
        字(295, 88, "飞 船 大 战", 52)
        color(160, 240, 255); 字(252, 148, "动态生灭 · 碰到检测 · 文本插值 · 框架循环", 18)
        图缩(352, 196, 96, 96, "games/飞船.png")
        color(255, 130, 50); box(380, 292, 10, 12 + 帧 % 10); box(410, 292, 10, 12 + 帧 % 10)
        if 帧 % 60 < 40:
            color(0, 200, 120); box(320, 336, 160, 44); color(30, 34, 50); 字(344, 350, "空格 出击", 20)
        else:
            color(0, 120, 80); box(320, 336, 160, 44); color(200, 255, 225); 字(344, 350, "空格 出击", 20)
        if 最高分 > 0:
            color(255, 210, 90); 字(320, 400, f"最高纪录 {最高分}", 18)
        color(20, 26, 48); box(0, 560, 800, 40); color(0, 180, 200); box(0, 560, 800, 3)
        color(150, 170, 210); 字(120, 572, "方向键/WASD 移动 · 空格 射击 · P 暂停 · R 重开 · M 菜单", 14)

    # ================= 游戏 / 暂停 =================
    if 状态 == 1 or 状态 == 2:
        if 状态 == 1:  # 逻辑更新（暂停跳过）
            游戏帧 += 1
            if 横幅 > 0: 横幅 -= 1
            if 无敌 > 0: 无敌 -= 1
            if 射冷 > 0: 射冷 -= 1
            if key("left") or key("a"):
                if 船.x > 24: 船.x -= 6
            if key("right") or key("d"):
                if 船.x < 776: 船.x += 6
            if key("up") or key("w"):
                if 船.y > 70: 船.y -= 6
            if key("down") or key("s"):
                if 船.y < 556: 船.y += 6
            if key("space") and 射冷 <= 0:
                射冷 = 10; 添加(我弹, 弹(x=船.x - 10, y=船.y - 22)); 添加(我弹, 弹(x=船.x + 10, y=船.y - 22))
            # 波次推进与刷怪
            if boss.活 != 1:
                波内帧 += 1
                if 波内帧 >= 900:
                    波内帧 = 0; 波 += 1; 横幅 = 100
                    if 波 >= 4:
                        boss = 母舰(); boss.活 = 1; ns_show("警告：母舰 BOSS 来袭！")
                    else: ns_show(f"★ 第 {波} 波敌军来袭 ★")
                if 波 < 4:
                    生成计时 -= 1
                    if 生成计时 <= 0:
                        生成计时 = 52 - 波 * 8; 型号 = 1
                        if 波 >= 2 and rd_int(0, 99) >= 55: 型号 = 2
                        血量, 敌y, 敌宽, 敌高 = 1, -30, 36, 36
                        if 型号 == 2: 血量, 敌y, 敌宽, 敌高 = 4, -40, 64, 44
                        添加(敌群, 敌机(x=rd_int(60, 740), y=敌y, 型=型号, 血=血量, 相=rd_int(0, 6), 计=rd_int(70, 130), 宽=敌宽, 高=敌高))
                    if 波 >= 2:
                        重舰计时 -= 1
                        if 重舰计时 <= 0:
                            重舰计时 = 240
                            添加(敌群, 敌机(x=rd_int(120, 680), y=-40, 型=2, 血=4, 相=0, 计=rd_int(70, 110), 宽=64, 高=44))
            # 玩家弹推进 + 出界消亡
            for b in list(我弹):
                b.y -= 11
                if b.y < -20: 删掉(我弹, b)
            # 玩家弹 打 敌机
            for b in list(我弹):
                for e in list(敌群):
                    if 碰到(b, e):
                        删掉(我弹, b); e.血 -= 1
                        if e.血 <= 0:
                            删掉(敌群, e); 分 += 40 if e.型 == 2 else 10
                            if 分 > 最高分: 最高分 = 分
                            添加(烟花, 爆(x=e.x, y=e.y))
                        break
            # 玩家弹 打 BOSS
            if boss.活 == 1 and boss.入场 == 0:
                for b in list(我弹):
                    if 碰到(b, boss):
                        删掉(我弹, b); boss.血 -= 1; boss.闪 = 4
                        if boss.血 <= 0:
                            boss.活 = 0; 分 += 500; 最高分 = max(最高分, 分)
                            状态 = 4; 添加(烟花, 爆(x=boss.x, y=boss.y))
                            ns_show(f"★ 任务完成！母舰已被击破 · 得分 {分} ★")
                            ns_show("按 R 重新开始 · 按 M 回主菜单")
            # 敌机推进 + 开火 + 撞玩家
            for e in list(敌群):
                if e.型 == 1:
                    e.y += 2 + (波 - 1) // 2; e.x += mt_sin(e.相 + 游戏帧 * 0.06) * 2.5
                    if e.y > 630: 删掉(敌群, e)
                else:
                    if e.y < 130: e.y += 1
                    e.计 -= 1
                    if e.计 <= 0 and e.y > 50:
                        e.计 = 78 if 波 >= 3 else 100
                        源x, 源y, 向y, 弹vy, 弹vx = e.x, e.y + 20, 船.y - (e.y + 20), 4.5, 0
                        if 向y > 60: 弹vx = (船.x - 源x) * (4.5 / 向y)
                        添加(敌弹, 敌弹(x=源x, y=源y, vx=弹vx, vy=弹vy))
                if 碰到(e, 船) and 无敌 <= 0:
                    删掉(敌群, e); 受击旗 = 1
            # BOSS 逻辑
            if boss.活 == 1:
                boss.帧 += 1
                if boss.闪 > 0: boss.闪 -= 1
                if boss.入场 == 1:
                    boss.y += 2
                    if boss.y >= 110: boss.y = 110; boss.入场 = 0
                else:
                    boss.x += boss.向 * 2
                    if boss.x < 170: boss.x = 170; boss.向 = 1
                    if boss.x > 630: boss.x = 630; boss.向 = -1
                    boss.y = 110 + mt_sin(boss.帧 * 0.02) * 8
                    boss.计 += 1
                    if boss.计 > 320: boss.计 = 0; boss.式 = (boss.式 + 1) % 3
                    if boss.式 == 0 and boss.计 % 60 == 0:
                        for 序 in range(5):
                            添加(敌弹, 敌弹(x=boss.x + (序 - 2) * 22, y=boss.y + 36, vx=(序 - 2) * 0.9, vy=4.2))
                    if boss.式 == 1 and boss.计 % 44 == 0:
                        for 序 in range(3):
                            源x, 源y, 向y, 弹vy, 弹vx = boss.x + (序 - 1) * 40, boss.y + 34, 船.y - (boss.y + 34), 4.8, 0
                            if 向y > 60: 弹vx = (船.x - 源x) * (4.8 / 向y)
                            添加(敌弹, 敌弹(x=源x, y=源y, vx=弹vx, vy=弹vy))
                    if boss.式 == 2 and boss.计 % 34 == 0:
                        添加(敌弹, 敌弹(x=boss.x + rd_int(-130, 130), y=boss.y + 30, vx=0, vy=5))
                    if boss.式 == 2 and boss.计 % 170 == 0:
                        for 序 in range(2):
                            添加(敌群, 敌机(x=boss.x + (序 - 1) * 90, y=boss.y + 20, 型=1, 血=1, 相=rd_int(0, 6), 计=80, 宽=36, 高=36))
                    if 碰到(boss, 船) and 无敌 <= 0: 受击旗 = 1
            # 敌弹推进 + 出界 + 打玩家
            for m in list(敌弹):
                m.x += m.vx; m.y += m.vy
                if m.y > 630 or m.y < -30 or m.x < -30 or m.x > 830: 删掉(敌弹, m)
                if 碰到(m, 船) and 无敌 <= 0: 删掉(敌弹, m); 受击旗 = 1
            # 玩家受击结算
            if 受击旗 == 1:
                受击旗 = 0
                if 无敌 <= 0:
                    船.血 -= 1; 无敌 = 100; 添加(烟花, 爆(x=船.x, y=船.y))
                    if 船.血 <= 0:
                        状态 = 3; ns_show(f"飞船损毁 · 最终得分 {分}"); ns_show("按 R 重新开始 · 按 M 回主菜单")
        # 待爆 -> 烟花
        if 待爆旗 == 1:
            待爆旗 = 0; 添加(烟花, 爆(x=待爆x, y=待爆y))
        # 绘制
        color(6, 6, 24); clear()
        for s in 星空:
            color(90, 100, 140) if s.速 == 1 else color(150, 165, 210) if s.速 == 2 else color(220, 230, 255)
            box(s.x, s.y, 2, 2)
        for m in 敌弹: 图(m.x - 7, m.y - 7, "games/敌弹.png")
        for e in 敌群:
            if e.型 == 1: 图缩(e.x - 18, e.y - 18, 36, 36, "games/敌机.png")
            else:
                图缩(e.x - 32, e.y - 22, 64, 44, "games/重舰.png"); color(255, 210, 80)
                for i in range(max(0, e.血)): box(e.x - 16 + i * 7, e.y + 26, 5, 5)
        if boss.活 == 1:
            图缩(boss.x - 96, boss.y - 40, 192, 80, "games/母舰.png")
            color(255, 95, 120); 核 = 10 + mt_sin(帧 * 0.2) * 4; box(boss.x - 核, boss.y - 核, 核 * 2, 核 * 2)
            color(255, 240, 240); box(boss.x - 4, boss.y - 4, 8, 8)
            if boss.闪 > 0 and 帧 % 2 == 0: color(240, 240, 255); box(boss.x - 96, boss.y - 40, 192, 80)
            color(60, 20, 30); box(250, 12, 300, 16)
            color(255, 70, 90); box(250, 12, boss.血 * 5, 16)
            color(255, 200, 210); box(249, 11, 302, 1); box(249, 28, 302, 1)
            字(210, 12, "母舰", 14); 字(562, 12, boss.血, 12)
        for b in 我弹: 图(b.x - 4, b.y - 10, "games/我弹.png")
        for p in 烟花:
            爆大 = p.帧 * 2 + 4; color(255, 150 - p.帧 * 6, 40); box(p.x - 爆大, p.y - 爆大, 爆大 * 2, 爆大 * 2)
            color(255, 220 - p.帧 * 8, 120); 爆大 //= 2; box(p.x - 爆大, p.y - 爆大, 爆大 * 2, 爆大 * 2)
        if 无敌 <= 0 or 帧 % 8 < 4:
            图缩(船.x - 24, 船.y - 24, 48, 48, "games/飞船.png")
            color(255, 130, 50)
            for dx in (-14, 6): box(船.x + dx, 船.y + 20, 8, 8 + 帧 % 8)
            color(255, 230, 140)
            for dx in (-12, 8): box(船.x + dx, 船.y + 20, 4, 6 + 帧 % 5)
        color(0, 255, 150); 字(16, 12, f"得分 {分}", 18)
        color(140, 160, 220)
        if boss.活 != 1: 字(386, 12, f"第 {波} 波", 14)
        color(255, 90, 120); 字(688, 12, f"生命 {船.血}", 16)

    # ================= 失败画面 =================
    if 状态 == 3:
        color(30, 6, 10); clear()
        for s in 星空: color(80, 40, 50); box(s.x, s.y, 2, 2)
        脉 = 26 + mt_sin(帧 * 0.1) * 8; color(140, 25, 30); box(400 - 脉 * 2, 300 - 脉 * 2, 脉 * 4, 脉 * 4)
        color(230, 70, 40); 脉2 = 脉 * 1.2; box(400 - 脉2, 300 - 脉2, 脉2 * 2, 脉2 * 2)
        color(255, 200, 120); box(385, 285, 30, 30)
        color(110, 100, 110)
        for dx, dy, w, h in ((300, 360, 10, 8), (430, 348, 8, 10), (370, 380, 12, 6), (490, 372, 7, 7), (280, 330, 6, 9)): box(dx, dy, w, h)
        color(255, 90, 90); 字(280, 120, "飞 船 损 毁", 52)
        color(255, 210, 150); 字(288, 210, f"最终得分 {分}", 26)
        color(200, 150, 150); 字(292, 252, f"最高纪录 {最高分}", 18)
        if 帧 % 50 < 30: color(255, 210, 80); 字(240, 420, "按 R 重新开始 · 按 M 回主菜单", 20)

    # ================= 胜利画面 =================
    if 状态 == 4:
        if 帧 % 12 == 0 and rd_int(0, 9) < 3:
            添加(烟花, 爆(x=rd_int(80, 720), y=rd_int(80, 420)))
        color(4, 10, 26); clear()
        for s in 星空:
            color(90, 100, 140) if s.速 == 1 else color(150, 165, 210) if s.速 == 2 else color(220, 230, 255)
            box(s.x, s.y, 2, 2)
        for p in 烟花:
            爆大 = p.帧 * 2 + 4; color(255, 150 - p.帧 * 6, 40); box(p.x - 爆大, p.y - 爆大, 爆大 * 2, 爆大 * 2)
            color(255, 220 - p.帧 * 8, 120); 爆大 //= 2; box(p.x - 爆大, p.y - 爆大, 爆大 * 2, 爆大 * 2)
        图缩(352, 296, 96, 96, "games/飞船.png")
        color(255, 130, 50); box(380, 392, 10, 12 + 帧 % 8); box(410, 392, 10, 12 + 帧 % 8)
        color(255, 210, 90); 字(264, 120, "任 务 完 成", 52)
        color(255, 240, 180); 字(300, 210, "母舰已被击破", 24)
        color(255, 210, 90); 字(288, 252, f"最终得分 {分}", 26)
        color(200, 170, 120); 字(292, 292, f"最高纪录 {最高分}", 18)
        if 帧 % 50 < 30: color(255, 210, 80); 字(240, 450, "按 R 重新开始 · 按 M 回主菜单", 20)

    # 顶部提示横幅
    if 提示计 > 0 and 提示:
        color(0, 0, 0); box(0, 0, 800, 36)
        color(255, 230, 120); 字(400 - len(提示) * 7, 8, 提示, 18)

    pygame.display.flip()
    钟.tick(FPS)
