# -*- coding: utf-8 -*-
ps1 = ('Start-Process -FilePath "C:/Users/zhuli/AppData/Local/Programs'
       '/Python/Python311/python.exe" '
       '-ArgumentList "pybk_main.py","games/\u62ab\u8428\u5854.pybk" '
       '-WorkingDirectory "C:/Users/zhuli/Desktop/pybook" '
       '-RedirectStandardOutput "_\u62ab\u8428_live.log" '
       '-RedirectStandardError "_\u62ab\u8428_err.log"\n')
open('_launch_pizza.ps1', 'w', encoding='utf-8-sig').write(ps1)
print('ps1 OK')
