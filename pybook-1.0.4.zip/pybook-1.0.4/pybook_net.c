/* PYbook 标准库：net 网络模块（TCP，行协议）。
 *
 * 实现：Winsock2。句柄是 INT（进程内句柄表的下标）；每个句柄在 C 侧持有
 * 接收缓冲区（char buf[] + 长度）——recv 先进缓冲、按 \n 切行、半行留在
 * 缓冲，绝不上交半行（防半包 bug 的硬要求）。
 *
 * 阻塞策略：句柄全部设非阻塞（ioctlsocket FIONBIO）；
 *   - net.accept / net.readline 在 C 里循环 非阻塞调用 + Sleep(1)，
 *     不需要线程；
 *   - net.recv 单次非阻塞尝试，没有完整新行返回 ""。
 *
 * 生命周期：WSAStartup 惰性初始化（第一次调 net.* 时），atexit 里 WSACleanup。
 * 编码：收发的字节按 UTF-8 原样进出字符串盒（与文件模块同约定）；
 *       连接地址是 UTF-8，经 MultiByteToWideChar 转 UTF-16 后 GetAddrInfoW。
 *
 * 语言层约定：net.send(句, 文本) 发一行——pybk_code 生成
 *   rt_net_write(句, rt_add(文本, rt_str("\n")))
 * 即 rt_net_write 本身只发原样字节（自测用它构造半包场景）。
 *
 * 自测：gcc -O2 -DNET_SELF_TEST pybook_net.c pybook_rt.c -o net_test.exe -lws2_32
 *       （单进程内完成 服务端+客户端、半包、非阻塞计时 三组断言）
 */

#include <winsock2.h>
#include <ws2tcpip.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <windows.h>

#include "pybook_rt.h"
#include "pybook_lib.h"

/* ---------- 运行时错误出口（与 pybook_rt 的 rt_die 格式一致） ---------- */

static void net_die(const char *fmt, ...)
{
    va_list ap;
    fprintf(stderr, "运行时错误: ");
    va_start(ap, fmt);
    vfprintf(stderr, fmt, ap);
    va_end(ap);
    fputc((int)'\n', stderr);
    exit(1);
}

/* ---------- 句柄表：SOCKET + 接收缓冲 ---------- */

#define NET_BUF_CAP     65536
#define NET_MAX_HANDLES 64

typedef struct {
    SOCKET sock;              /* INVALID_SOCKET = 空槽 */
    char   buf[NET_BUF_CAP];  /* 接收缓冲：半行留这里 */
    size_t len;               /* 缓冲内有效字节数 */
} NetHandle;

static NetHandle g_handles[NET_MAX_HANDLES];
static int g_wsa_ok = 0;
static int g_handles_init = 0;

/* 静态区零初始化的 0 不是 INVALID_SOCKET，首次使用前把空槽补成 INVALID_SOCKET */
static void net_handles_init(void)
{
    int i;
    if (g_handles_init)
        return;
    for (i = 0; i < NET_MAX_HANDLES; i++)
        g_handles[i].sock = INVALID_SOCKET;
    g_handles_init = 1;
}

static void net_cleanup(void)
{
    WSACleanup();
}

static void net_ensure_init(void)
{
    WSADATA d;
    if (g_wsa_ok)
        return;
    if (WSAStartup(MAKEWORD(2, 2), &d) != 0)
        net_die("net：WSAStartup 失败");
    atexit(net_cleanup);      /* 进程退出时 WSACleanup */
    g_wsa_ok = 1;
}

static NetHandle *net_handle(Value hv)
{
    long long h;
    net_handles_init();
    if (!IS_INT(hv))
        net_die("net：句柄需要整数");
    h = AS_INT(hv);
    if (h < 0 || h >= NET_MAX_HANDLES || g_handles[h].sock == INVALID_SOCKET)
        net_die("net：句柄 %lld 不存在或已关闭", h);
    return &g_handles[h];
}

static long long net_new_handle(SOCKET s)
{
    int i;
    net_handles_init();
    for (i = 0; i < NET_MAX_HANDLES; i++) {
        if (g_handles[i].sock == INVALID_SOCKET) {
            g_handles[i].sock = s;
            g_handles[i].len = 0;
            return i;
        }
    }
    net_die("net：句柄表已满（最多 %d 个连接）", NET_MAX_HANDLES);
    return -1;   /* 不可达 */
}

static void net_set_nonblock(SOCKET s)
{
    u_long mode = 1;
    ioctlsocket(s, FIONBIO, &mode);
}

static const char *net_str(Value v, const char *who)
{
    if (!IS_STR(v))
        net_die("%s 需要字符串", who);
    return IS_STR(v) ? (AS_STR(v) ? AS_STR(v) : "") : "";
}

static long long net_port(Value pv, const char *who)
{
    if (!IS_INT(pv))
        net_die("%s 需要整数端口", who);
    return AS_INT(pv);
}

/* ---------- 行缓冲：从句柄缓冲取一行 ---------- */

/* 从 h->buf 里取一行（到 \n 为止，不含 \n；行尾 \r 去掉）。
 * 取到返回该行字符串盒并把剩余字节前移；否则返回 NULL（缓冲不动）。 */
static Value net_take_line(NetHandle *h)
{
    size_t i;
    for (i = 0; i < h->len; i++) {
        if (h->buf[i] == '\n') {
            size_t linelen = i;
            size_t rest = h->len - i - 1;
            char *one;
            Value v;
            if (linelen > 0 && h->buf[linelen - 1] == '\r')
                linelen--;                 /* 兼容 \r\n */
            one = (char *)malloc(linelen + 1);
            if (!one)
                net_die("内存不足");
            memcpy(one, h->buf, linelen);
            one[linelen] = '\0';
            memmove(h->buf, h->buf + i + 1, rest);
            h->len = rest;
            v = rt_str(one);
            free(one);
            return v;
        }
    }
    return (Value)0;
}

/* ---------- 内部：非阻塞收进缓冲 ---------- */

/* 返回 1=收到新字节，0=暂无数据（WSAEWOULDBLOCK），-1=连接已断开 */
static int net_fill(NetHandle *h)
{
    char tmp[4096];
    int r = recv(h->sock, tmp, (int)sizeof tmp, 0);
    if (r > 0) {
        if (r > (int)(NET_BUF_CAP - h->len))     /* 缓冲满：保最新，丢最旧 */
            net_die("net：接收缓冲溢出（单行超过 %d 字节？）", NET_BUF_CAP);
        memcpy(h->buf + h->len, tmp, (size_t)r);
        h->len += (size_t)r;
        return 1;
    }
    if (r == 0)
        return -1;                               /* 对端正常关闭 */
    if (WSAGetLastError() == WSAEWOULDBLOCK)
        return 0;
    return -1;                                   /* 其他错误视为断开 */
}

/* ---------- 对外 API ---------- */

Value rt_net_listen(Value portv)
{
    net_ensure_init();
    {
        long long port = net_port(portv, "net.listen 的端口");
        SOCKET s = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
        struct sockaddr_in addr;
        BOOL reuse = TRUE;
        if (s == INVALID_SOCKET)
            net_die("net.listen：创建套接字失败（错误 %d）", WSAGetLastError());
        setsockopt(s, SOL_SOCKET, SO_REUSEADDR, (const char *)&reuse, sizeof reuse);
        ZeroMemory(&addr, sizeof addr);
        addr.sin_family = AF_INET;
        addr.sin_port = htons((u_short)port);
        addr.sin_addr.s_addr = htonl(INADDR_ANY);
        if (bind(s, (struct sockaddr *)&addr, sizeof addr) != 0) {
            int e = WSAGetLastError();
            closesocket(s);
            net_die("net.listen：绑定端口 %lld 失败（错误 %d，端口被占用？）", port, e);
        }
        if (listen(s, 8) != 0) {
            int e = WSAGetLastError();
            closesocket(s);
            net_die("net.listen：监听失败（错误 %d）", e);
        }
        net_set_nonblock(s);
        return rt_int(net_new_handle(s));
    }
}

Value rt_net_accept(Value lv)
{
    NetHandle *l;
    net_ensure_init();
    l = net_handle(lv);
    for (;;) {
        SOCKET c = accept(l->sock, NULL, NULL);
        if (c != INVALID_SOCKET) {
            net_set_nonblock(c);
            return rt_int(net_new_handle(c));
        }
        if (WSAGetLastError() == WSAEWOULDBLOCK) {
            Sleep(1);              /* 阻塞等连接：非阻塞轮询 + 睡 1ms */
            continue;
        }
        net_die("net.accept：%d", WSAGetLastError());
    }
}

Value rt_net_connect(Value addrv, Value portv)
{
    net_ensure_init();
    {
        const char *host = net_str(addrv, "net.connect 的地址");
        long long port = net_port(portv, "net.connect 的端口");
        wchar_t whost[256], wport[16];
        struct addrinfoW hints, *res = NULL;
        SOCKET s;
        if (!MultiByteToWideChar(CP_UTF8, 0, host, -1,
                                 whost, (int)(sizeof whost / sizeof whost[0])))
            net_die("net.connect：地址编码失败");
        swprintf(wport, (sizeof wport / sizeof wport[0]), L"%lld", port);
        ZeroMemory(&hints, sizeof hints);
        hints.ai_family = AF_INET;
        hints.ai_socktype = SOCK_STREAM;
        hints.ai_protocol = IPPROTO_TCP;
        if (GetAddrInfoW(whost, wport, &hints, &res) != 0 || res == NULL)
            net_die("net.connect：无法解析地址 %s", host);
        s = socket(res->ai_family, res->ai_socktype, res->ai_protocol);
        if (s == INVALID_SOCKET) {
            FreeAddrInfoW(res);
            net_die("net.connect：创建套接字失败（错误 %d）", WSAGetLastError());
        }
        if (connect(s, res->ai_addr, (int)res->ai_addrlen) != 0) {
            int e = WSAGetLastError();
            FreeAddrInfoW(res);
            closesocket(s);
            net_die("net.connect：连接 %s:%lld 失败（错误 %d）", host, port, e);
        }
        FreeAddrInfoW(res);
        net_set_nonblock(s);
        return rt_int(net_new_handle(s));
    }
}

Value rt_net_read(Value hv)
{
    NetHandle *h;
    net_ensure_init();
    h = net_handle(hv);
    for (;;) {
        Value line = net_take_line(h);
        if (line != 0)
            return line;                       /* 缓冲里有完整行 */
        {
            int r = net_fill(h);               /* 非阻塞收一次 */
            if (r == 1)
                continue;                      /* 有新字节，再找 \n */
            if (r == -1) {                     /* 连接断开 */
                if (h->len > 0) {              /* 剩半行：作为最后一行吐出 */
                    char *one = (char *)malloc(h->len + 1);
                    Value v;
                    if (!one)
                        net_die("内存不足");
                    memcpy(one, h->buf, h->len);
                    one[h->len] = '\0';
                    h->len = 0;
                    v = rt_str(one);
                    free(one);
                    return v;
                }
                return rt_str("断");
            }
            return rt_str("");                 /* 暂无完整新行 */
        }
    }
}

Value rt_net_read_block(Value hv)
{
    NetHandle *h;
    net_ensure_init();
    h = net_handle(hv);
    for (;;) {
        Value line = net_take_line(h);
        if (line != 0)
            return line;
        {
            int r = net_fill(h);
            if (r == 1)
                continue;
            if (r == -1) {                     /* 断开：吐残余或报"断" */
                if (h->len > 0) {
                    char *one = (char *)malloc(h->len + 1);
                    Value v;
                    if (!one)
                        net_die("内存不足");
                    memcpy(one, h->buf, h->len);
                    one[h->len] = '\0';
                    h->len = 0;
                    v = rt_str(one);
                    free(one);
                    return v;
                }
                return rt_str("断");
            }
            Sleep(1);                          /* 阻塞模式：轮询 + 睡 1ms */
        }
    }
}

Value rt_net_write(Value hv, Value textv)
{
    NetHandle *h;
    const char *data;
    size_t len, sent;
    net_ensure_init();
    h = net_handle(hv);
    data = net_str(textv, "net.send 的内容");
    len = strlen(data);
    sent = 0;
    while (sent < len) {
        int r = send(h->sock, data + sent, (int)(len - sent), 0);
        if (r == SOCKET_ERROR)
            net_die("net.send：发送失败（错误 %d）", WSAGetLastError());
        sent += (size_t)r;
    }
    return rt_none();
}

Value rt_net_close(Value hv)
{
    NetHandle *h;
    net_ensure_init();
    h = net_handle(hv);
    closesocket(h->sock);
    h->sock = INVALID_SOCKET;
    h->len = 0;
    return rt_none();
}

/* ================= 自测（-DNET_SELF_TEST） =================
 * gcc -O2 -DNET_SELF_TEST pybook_net.c pybook_rt.c -o net_test.exe -lws2_32 -I.
 * 单进程内：自听自连，覆盖 整行协议 / 半包 / 非阻塞计时 三组断言。 */

#ifdef NET_SELF_TEST

static int g_pass = 0, g_fail = 0;

#define CHECK(cond, name)                              \
    do {                                               \
        if (cond) {                                    \
            g_pass++;                                  \
        } else {                                       \
            g_fail++;                                  \
            printf("[失败] %s\n", name);               \
        }                                              \
    } while (0)

static int str_eq(Value v, const char *want)
{
    return IS_STR(v) && AS_STR(v) && strcmp(AS_STR(v), want) == 0;
}

int main(void)
{
    /* ---- 半包 / 非阻塞 / 整行：C 层直接驱动（rt_net_write 发原样字节） ---- */
    Value srv = rt_net_listen(rt_int(17777));
    Value cli = rt_net_connect(rt_str("127.0.0.1"), rt_int(17777));
    Value con = rt_net_accept(srv);
    DWORD t0;
    int i;
    Value line;

    /* 非阻塞：对端不发数据，recv 100 次全部 "" 且几乎不耗时 */
    t0 = GetTickCount();
    for (i = 0; i < 100; i++) {
        Value v = rt_net_read(con);
        CHECK(str_eq(v, ""), "net.recv 非阻塞：无数据返回空串");
    }
    CHECK(GetTickCount() - t0 < 200, "net.recv 100 次耗时 < 200ms（证明非阻塞）");

    /* 半包：先发 "abc"（无 \n），再发 "def\n" —— 两段拼成一行 */
    CHECK(rt_net_write(cli, rt_str("abc")) == rt_none(), "net.write: abc");
    line = rt_net_read(con);
    CHECK(str_eq(line, ""), "net.recv 半包：无 \\n 时不上交");
    (void)line;
    Sleep(30);
    rt_net_write(cli, rt_str("def\n"));
    line = rt_net_read(con);
    CHECK(str_eq(line, "abcdef"), "net.recv 半包：两段拼成完整一行 abcdef");

    /* 整行协议 + 阻塞读：服务端回一行，客户端阻塞收到 */
    rt_net_write(con, rt_str("hello client\n"));
    line = rt_net_read_block(cli);
    CHECK(str_eq(line, "hello client"), "net.readline 阻塞读一行");

    /* 关闭语义：对端 close 后，缓冲耗尽 → "断" */
    rt_net_close(cli);
    line = rt_net_read(con);
    CHECK(str_eq(line, "断"), "net.recv 对端关闭 → 断");
    rt_net_close(con);
    rt_net_close(srv);

    printf("net 自测：通过 %d 项，失败 %d 项\n", g_pass, g_fail);
    return g_fail ? 1 : 0;
}

#endif /* NET_SELF_TEST */
