﻿Start-Process -FilePath "C:/Users/zhuli/AppData/Local/Programs/Python/Python311/python.exe" -ArgumentList "pybk_main.py","games/魔域勇者.pybk" -WorkingDirectory "C:/Users/zhuli/Desktop/pybook"
