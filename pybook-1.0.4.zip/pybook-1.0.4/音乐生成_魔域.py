# -*- coding: utf-8 -*-
"""魔域勇者 BGM 生成器：芯片音乐三首（森林/洞窟/魔王）→ games/魔域/*.wav
纯标准库合成：方波主旋律 + 三角波贝斯（+魔王曲噪声踩镲）。22050Hz 16bit 单声道。"""
import wave, math, os, struct, random

SR = 22050
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "games", "魔域")
os.makedirs(OUT, exist_ok=True)

def midi(n):
    return 440.0 * (2 ** ((n - 69) / 12.0))

def sq(f, t):
    return 1.0 if math.sin(2 * math.pi * f * t) >= 0 else -1.0

def sq25(f, t):
    ph = (f * t) % 1.0
    return 1.0 if ph < 0.25 else -0.6

def tri(f, t):
    return (2.0 / math.pi) * math.asin(math.sin(2 * math.pi * f * t))

def render(bpm, bars, lead, bass, hats=False, lead_wave=sq, gain=0.42):
    """lead/bass: [(起始拍, 时值拍, midi号)]；返回 16bit 帧列表。"""
    beat = 60.0 / bpm
    total = int(bars * 4 * beat * SR)
    pcm = [0.0] * total
    for (s, d, n) in lead:
        f = midi(n)
        n0 = int(s * beat * SR); n1 = int((s + d) * beat * SR)
        n1 = min(n1, total)
        nn = n1 - n0
        for i in range(nn):
            t = i / SR
            env = 1.0
            rel = i / max(1, nn)
            if rel < 0.04: env = rel / 0.04
            elif rel > 0.75: env = (1 - rel) / 0.25
            v = lead_wave(f, t) * env * 0.55
            # 回声
            j = n0 + i + int(beat / 2 * SR)
            if j < total:
                pcm[j] += v * 0.28
            pcm[n0 + i] += v
    for (s, d, n) in bass:
        f = midi(n)
        n0 = int(s * beat * SR); n1 = min(int((s + d) * beat * SR), total)
        for i in range(n1 - n0):
            t = i / SR
            rel = i / max(1, n1 - n0)
            env = 1.0 if rel < 0.8 else (1 - rel) / 0.2
            pcm[n0 + i] += tri(f, t) * env * 0.5
    if hats:
        rnd = random.Random(99)
        eighth = beat / 2
        n_hat = int(0.03 * SR)
        for k in range(int(bars * 4 / 0.5) + 1):
            s = int((k * eighth + eighth / 2) * SR)
            for i in range(n_hat):
                if s + i < total:
                    env = 1 - i / n_hat
                    pcm[s + i] += (rnd.random() * 2 - 1) * env * 0.10
    out = []
    for v in pcm:
        v = math.tanh(v * gain) * 0.92
        out.append(int(v * 32000))
    return out

def save(name, pcm):
    path = os.path.join(OUT, name)
    with wave.open(path, "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR)
        w.writeframes(struct.pack("<%dh" % len(pcm), *pcm))
    print(f"{name}: {len(pcm)/SR:.1f}s")

# ---------------- 森林（C 大调五声 · 120BPM · 16 小节 = 32 秒） ----------------
E = 0.5   # 八分音符
def ph(seq, start):     # seq: [midi 或 None]，每项一个八分音符
    out = []
    for i, n in enumerate(seq):
        if n: out.append((start + i * E, E * 0.92, n))
    return out
# C 大调五声：C=60 D=62 E=64 G=67 A=69 C6=72 D6=74 E6=76 G6=79
lead1 = []
lead1 += ph([64, 67, 69, 67, 64, 62, 60, 62], 0)
lead1 += ph([64, 67, 69, 72, 69, 67, 64, 67], 4)
lead1 += ph([69, 72, 69, 67, 64, 67, 64, 62], 8)
lead1 += ph([60, 62, 64, 67, 69, 67, 64, 62], 12)
lead1 += ph([65, 69, 72, 69, 65, 64, 62, 60], 16)
lead1 += ph([62, 65, 67, 71, 74, 71, 67, 65], 20)
lead1 += ph([64, 67, 69, 67, 64, 62, 60, 57], 24)
lead1 += ph([60, 64, 67, 64, 60, None, 55, None], 28)
lead1 += ph([64, 67, 69, 67, 64, 62, 60, 62], 32)
lead1 += ph([64, 67, 69, 72, 69, 67, 64, 67], 36)
lead1 += ph([76, 74, 72, 69, 72, 69, 67, 64], 40)
lead1 += ph([65, 67, 69, 72, 74, 72, 69, 67], 44)
lead1 += ph([65, 69, 72, 76, 72, 69, 65, 64], 48)
lead1 += ph([62, 65, 71, 74, 71, 67, 62, 60], 52)
lead1 += ph([64, 67, 69, 72, 76, 72, 69, 67], 56)
lead1 += ph([64, 62, 60, None, 60, None, None, None], 60)
bass1 = []
for bar in range(16):
    root = [36, 36, 33, 33, 29, 29, 31, 31][bar % 8]
    for q in range(4):
        n = root if q % 2 == 0 else root + 7
        bass1.append((bar * 4 + q, 1.0 * 0.9, n))
save("魔域_森林.wav", render(120, 16, lead1, bass1))

# ---------------- 洞窟（A 小调 · 90BPM · 16 小节 ≈ 42.7 秒，疏落幽暗） ----------------
L = 1.0
lead2 = []
mel2 = [
    (0, 2, 69), (2, 1, 72), (3, 1, 71), (4, 3, 69), (8, 2, 64), (10, 2, 67), (12, 4, 64),
    (16, 2, 65), (18, 1, 69), (19, 1, 72), (20, 3, 69), (24, 2, 67), (26, 2, 64), (28, 4, 62),
    (32, 2, 69), (34, 1, 72), (35, 1, 76), (36, 3, 74), (40, 2, 72), (42, 2, 69), (44, 4, 67),
    (48, 2, 65), (50, 2, 64), (52, 2, 65), (54, 2, 69), (56, 4, 64), (60, 4, None),
]
lead2 = [(s, d * L * 0.95, n) for (s, d, n) in mel2 if n]
bass2 = []
for bar in range(16):
    root = [33, 33, 29, 29, 28, 28, 31, 31][bar % 8]
    bass2.append((bar * 4, 3.6, root))
    bass2.append((bar * 4 + 2, 1.6, root + 12))
save("魔域_洞窟.wav", render(90, 16, lead2, bass2, lead_wave=tri, gain=0.5))

# ---------------- 魔王（E 和声小调 · 150BPM · 16 小节 ≈ 25.6 秒，压迫推进） ----------------
riff = [40, 40, 43, 40, 44, 43, 40, 39,   # E E G E D# E D# C
        40, 40, 43, 45, 47, 45, 43, 40,   # E E G A B A G E
        40, 40, 43, 40, 44, 47, 44, 43,
        45, 43, 40, 39, 40, None, 38, 39]
lead3 = []
for rep in range(4):
    lead3 += ph(riff, rep * 16)
bass3 = []
for k in range(128):
    n = 28 if (k % 16) < 8 else 26
    bass3.append((k * 0.5, 0.45, n))
save("魔域_魔王.wav", render(150, 16, lead3, bass3, hats=True, gain=0.46))
print("BGM 生成完毕")
