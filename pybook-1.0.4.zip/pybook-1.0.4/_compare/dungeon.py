def blood_bar(name, hp, full):
    blocks = "█" * (hp * 20 // full)
    return name + " " + blocks

print("====== 地牢屠龙记 ======")
print("黑龙掳走了村长的女儿")
print("你将深入地牢，斩杀五只怪物，屠龙救人！")
my_name = input("冒险者，报上名号：")
hp = 30
hp_max = 30
atk = 6
dfn = 2
gold = 10
potion = 2
level = 1
exp = 0
m_name = ["史莱姆", "哥布林", "骷髅兵", "兽人", "黑龙"]
m_hp = [8, 14, 22, 30, 60]
m_atk = [3, 5, 7, 9, 14]
m_dfn = [0, 1, 2, 3, 5]
m_exp = [5, 8, 12, 18, 50]
m_gold = [6, 10, 15, 25, 100]
print(f"{my_name}，你的属性：❤血 30  攻 6  防 2  药水 2")

for i in range(len(m_name)):
    cur_name = m_name[i]
    cur_hp = m_hp[i]
    cur_atk = m_atk[i]
    cur_dfn = m_dfn[i]
    escaped = False
    print("================================")
    print(f"⚔ 第 {i+1} 关：{cur_name} 来了！")
    while not (cur_hp <= 0 or hp <= 0 or escaped):
        print(f"{blood_bar(cur_name, cur_hp, m_hp[i])} ❤{cur_hp}")
        print(f"{blood_bar(my_name, hp, hp_max)} ❤{hp}")
        print("1 攻击  2 重击伤翻倍但自损2  3 喝药+12  4 逃跑")
        act = int(input("你的行动"))
        if act == 1:
            dmg = atk - cur_dfn
            if dmg < 1:
                dmg = 1
            cur_hp -= dmg
            print(f"你挥出一击，造成 {dmg} 点伤害！")
        elif act == 2:
            dmg = (atk - cur_dfn) * 2
            if dmg < 2:
                dmg = 2
            cur_hp -= dmg
            hp -= 2
            print(f"重击！造成 {dmg} 点伤害，你反震自损 2")
        elif act == 3:
            if potion > 0:
                potion -= 1
                hp += 12
                if hp > hp_max:
                    hp = hp_max
                print("咕嘟咕嘟...喝下药水，感觉充满力量！")
            else:
                print("药水瓶已经空了！")
        elif act == 4:
            gold //= 2
            escaped = True
            cur_hp = 0
            print("你落荒而逃，金币掉了一半...")
        else:
            print("你发呆了一回合...")
        if cur_hp > 0 and not escaped:
            taken = cur_atk - dfn
            if taken < 1:
                taken = 1
            hp -= taken
            print(f"{cur_name} 反击！你损失 {taken} 点血")
    if not escaped and hp > 0:
        exp += m_exp[i]
        gold += m_gold[i]
        print(f"★ 击败 {cur_name}！经验 +{m_exp[i]}  金币 +{m_gold[i]}")
        while exp >= level * 10:
            exp -= level * 10
            level += 1
            atk += 2
            hp_max += 6
            hp = hp_max
            print(f"✨ 升级！{level} 级：攻 +2  血上限 +6，已回满！")
        print("路边有个小商店...")
        leave = False
        while not leave:
            print(f"金币：{gold}   1 买药水+12(8金)  2 武器强化+2攻(15金)  3 离开")
            choice = int(input("买什么"))
            if choice == 1:
                if gold >= 8:
                    gold -= 8
                    potion += 1
                    print(f"买下药水！剩余 {gold} 金币")
                else:
                    print("金币不够...")
            elif choice == 2:
                if gold >= 15:
                    gold -= 15
                    atk += 2
                    print(f"武器强化！攻击 now {atk}")
                else:
                    print("金币不够...")
            else:
                leave = True
                print("你离开了商店")
    if hp <= 0:
        print("你倒下了...")
        break

if hp > 0:
    print("====== 🐉 黑龙就在眼前 ======")
    print(f"{my_name} 深吸一口气，举起了武器！")
else:
    print("你的冒险到此为止...")
