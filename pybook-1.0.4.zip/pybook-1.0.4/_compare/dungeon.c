#include <stdio.h>
#include <string.h>

void blood_bar(const char *name, int hp, int full, char *out) {
    int blocks = hp * 20 / full;
    char *p = out;
    p += sprintf(p, "%s ", name);
    for (int i = 0; i < blocks; i++) {
        p += sprintf(p, "█");
    }
    *p = '\0';
}

int main(void) {
    char my_name[64];
    char bar[256];
    int hp = 30, hp_max = 30, atk = 6, dfn = 2;
    int gold = 10, potion = 2, level = 1, exp = 0;
    const char *m_name[] = {"史莱姆", "哥布林", "骷髅兵", "兽人", "黑龙"};
    int m_hp[]   = {8, 14, 22, 30, 60};
    int m_atk[]  = {3, 5, 7, 9, 14};
    int m_dfn[]  = {0, 1, 2, 3, 5};
    int m_exp[]  = {5, 8, 12, 18, 50};
    int m_gold[] = {6, 10, 15, 25, 100};

    printf("====== 地牢屠龙记 ======\n");
    printf("黑龙掳走了村长的女儿\n");
    printf("你将深入地牢，斩杀五只怪物，屠龙救人！\n");
    printf("冒险者，报上名号：\n");
    scanf("%63s", my_name);
    printf("%s，你的属性：❤血 30  攻 6  防 2  药水 2\n", my_name);

    for (int i = 0; i < 5; i++) {
        const char *cur_name = m_name[i];
        int cur_hp = m_hp[i], cur_atk = m_atk[i], cur_dfn = m_dfn[i];
        int escaped = 0;
        printf("================================\n");
        printf("⚔ 第 %d 关：%s 来了！\n", i + 1, cur_name);
        while (!(cur_hp <= 0 || hp <= 0 || escaped)) {
            int act;
            blood_bar(cur_name, cur_hp, m_hp[i], bar);
            printf("%s ❤%d\n", bar, cur_hp);
            blood_bar(my_name, hp, hp_max, bar);
            printf("%s ❤%d\n", bar, hp);
            printf("1 攻击  2 重击伤翻倍但自损2  3 喝药+12  4 逃跑\n");
            printf("你的行动\n");
            scanf("%d", &act);
            if (act == 1) {
                int dmg = atk - cur_dfn;
                if (dmg < 1) dmg = 1;
                cur_hp -= dmg;
                printf("你挥出一击，造成 %d 点伤害！\n", dmg);
            } else if (act == 2) {
                int dmg = (atk - cur_dfn) * 2;
                if (dmg < 2) dmg = 2;
                cur_hp -= dmg;
                hp -= 2;
                printf("重击！造成 %d 点伤害，你反震自损 2\n", dmg);
            } else if (act == 3) {
                if (potion > 0) {
                    potion -= 1;
                    hp += 12;
                    if (hp > hp_max) hp = hp_max;
                    printf("咕嘟咕嘟...喝下药水，感觉充满力量！\n");
                } else {
                    printf("药水瓶已经空了！\n");
                }
            } else if (act == 4) {
                gold /= 2;
                escaped = 1;
                cur_hp = 0;
                printf("你落荒而逃，金币掉了一半...\n");
            } else {
                printf("你发呆了一回合...\n");
            }
            if (cur_hp > 0 && !escaped) {
                int taken = cur_atk - dfn;
                if (taken < 1) taken = 1;
                hp -= taken;
                printf("%s 反击！你损失 %d 点血\n", cur_name, taken);
            }
        }
        if (!escaped && hp > 0) {
            exp += m_exp[i];
            gold += m_gold[i];
            printf("★ 击败 %s！经验 +%d  金币 +%d\n", cur_name, m_exp[i], m_gold[i]);
            while (exp >= level * 10) {
                exp -= level * 10;
                level += 1;
                atk += 2;
                hp_max += 6;
                hp = hp_max;
                printf("✨ 升级！%d 级：攻 +2  血上限 +6，已回满！\n", level);
            }
            printf("路边有个小商店...\n");
            int leave = 0;
            while (!leave) {
                int choice;
                printf("金币：%d   1 买药水+12(8金)  2 武器强化+2攻(15金)  3 离开\n", gold);
                printf("买什么\n");
                scanf("%d", &choice);
                if (choice == 1) {
                    if (gold >= 8) {
                        gold -= 8;
                        potion += 1;
                        printf("买下药水！剩余 %d 金币\n", gold);
                    } else {
                        printf("金币不够...\n");
                    }
                } else if (choice == 2) {
                    if (gold >= 15) {
                        gold -= 15;
                        atk += 2;
                        printf("武器强化！攻击 now %d\n", atk);
                    } else {
                        printf("金币不够...\n");
                    }
                } else {
                    leave = 1;
                    printf("你离开了商店\n");
                }
            }
        }
        if (hp <= 0) {
            printf("你倒下了...\n");
            break;
        }
    }

    if (hp > 0) {
        printf("====== 🐉 黑龙就在眼前 ======\n");
        printf("%s 深吸一口气，举起了武器！\n", my_name);
    } else {
        printf("你的冒险到此为止...\n");
    }
    return 0;
}
