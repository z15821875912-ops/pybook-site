const readline = require("readline");

const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
const input = (prompt) => new Promise((resolve) => rl.question(prompt + "\n", resolve));

function bloodBar(name, hp, full) {
    return name + " " + "█".repeat(Math.floor(hp * 20 / full));
}

(async () => {
    console.log("====== 地牢屠龙记 ======");
    console.log("黑龙掳走了村长的女儿");
    console.log("你将深入地牢，斩杀五只怪物，屠龙救人！");
    const myName = await input("冒险者，报上名号：");
    let hp = 30;
    let hpMax = 30;
    let atk = 6;
    let dfn = 2;
    let gold = 10;
    let potion = 2;
    let level = 1;
    let exp = 0;
    const mName = ["史莱姆", "哥布林", "骷髅兵", "兽人", "黑龙"];
    const mHp = [8, 14, 22, 30, 60];
    const mAtk = [3, 5, 7, 9, 14];
    const mDfn = [0, 1, 2, 3, 5];
    const mExp = [5, 8, 12, 18, 50];
    const mGold = [6, 10, 15, 25, 100];
    console.log(`${myName}，你的属性：❤血 30  攻 6  防 2  药水 2`);

    for (let i = 0; i < mName.length; i++) {
        const curName = mName[i];
        let curHp = mHp[i];
        const curAtk = mAtk[i];
        const curDfn = mDfn[i];
        let escaped = false;
        console.log("================================");
        console.log(`⚔ 第 ${i + 1} 关：${curName} 来了！`);
        while (!(curHp <= 0 || hp <= 0 || escaped)) {
            console.log(`${bloodBar(curName, curHp, mHp[i])} ❤${curHp}`);
            console.log(`${bloodBar(myName, hp, hpMax)} ❤${hp}`);
            console.log("1 攻击  2 重击伤翻倍但自损2  3 喝药+12  4 逃跑");
            const act = parseInt(await input("你的行动"), 10);
            if (act === 1) {
                let dmg = atk - curDfn;
                if (dmg < 1) dmg = 1;
                curHp -= dmg;
                console.log(`你挥出一击，造成 ${dmg} 点伤害！`);
            } else if (act === 2) {
                let dmg = (atk - curDfn) * 2;
                if (dmg < 2) dmg = 2;
                curHp -= dmg;
                hp -= 2;
                console.log(`重击！造成 ${dmg} 点伤害，你反震自损 2`);
            } else if (act === 3) {
                if (potion > 0) {
                    potion -= 1;
                    hp += 12;
                    if (hp > hpMax) hp = hpMax;
                    console.log("咕嘟咕嘟...喝下药水，感觉充满力量！");
                } else {
                    console.log("药水瓶已经空了！");
                }
            } else if (act === 4) {
                gold = Math.floor(gold / 2);
                escaped = true;
                curHp = 0;
                console.log("你落荒而逃，金币掉了一半...");
            } else {
                console.log("你发呆了一回合...");
            }
            if (curHp > 0 && !escaped) {
                let taken = curAtk - dfn;
                if (taken < 1) taken = 1;
                hp -= taken;
                console.log(`${curName} 反击！你损失 ${taken} 点血`);
            }
        }
        if (!escaped && hp > 0) {
            exp += mExp[i];
            gold += mGold[i];
            console.log(`★ 击败 ${curName}！经验 +${mExp[i]}  金币 +${mGold[i]}`);
            while (exp >= level * 10) {
                exp -= level * 10;
                level += 1;
                atk += 2;
                hpMax += 6;
                hp = hpMax;
                console.log(`✨ 升级！${level} 级：攻 +2  血上限 +6，已回满！`);
            }
            console.log("路边有个小商店...");
            let leave = false;
            while (!leave) {
                console.log(`金币：${gold}   1 买药水+12(8金)  2 武器强化+2攻(15金)  3 离开`);
                const choice = parseInt(await input("买什么"), 10);
                if (choice === 1) {
                    if (gold >= 8) {
                        gold -= 8;
                        potion += 1;
                        console.log(`买下药水！剩余 ${gold} 金币`);
                    } else {
                        console.log("金币不够...");
                    }
                } else if (choice === 2) {
                    if (gold >= 15) {
                        gold -= 15;
                        atk += 2;
                        console.log(`武器强化！攻击 now ${atk}`);
                    } else {
                        console.log("金币不够...");
                    }
                } else {
                    leave = true;
                    console.log("你离开了商店");
                }
            }
        }
        if (hp <= 0) {
            console.log("你倒下了...");
            break;
        }
    }

    if (hp > 0) {
        console.log("====== 🐉 黑龙就在眼前 ======");
        console.log(`${myName} 深吸一口气，举起了武器！`);
    } else {
        console.log("你的冒险到此为止...");
    }
    rl.close();
})();
