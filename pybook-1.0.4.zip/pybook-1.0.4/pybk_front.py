"""PYbook 语言前端：词法分析 + 语法分析。

一行一个语句，块用花括号，标识符允许中文。
只做认字和建 AST：不查变量声明、不查类型、不生成任何 C。
仅用 Python 标准库。

实现说明：ns.show(...) 的内容是不加引号的裸文本（可含 ！、$ 等非 Token 字符），
所以词法器遇到非法字符先产出 ERR 占位符而不是立刻抛错；语法器在正常解析路径上
遇到 ERR 才报错（带行号），而在裸文本区域里按源码位置整段跳过。
"""

import dataclasses
import re
from dataclasses import dataclass, field


# ---------------------------------------------------------------- Token

@dataclass
class Token:
    kind: str    # 'NUM' 'STR' 'NAME' 'KW' 'OP' 'AT' 'EOF'
    value: str
    line: int


KEYWORDS = {
    'net',
    'GOING', 'STOP', 'vg', 'vg_ro', 'ns', 'rm', 'when', 'func', 'ip', 'vc',
    'lock', 'del', 'list', 'show', 'input', 'ret', 'at', 'try', 'catch', 'onerror',
    'and', 'or', 'not', 'true', 'false', '真', '假', '空', 'none', 'Memoryment', 'web', 'js', 'csv', '查', 'mm',
    'lb', 'self', 'te', 'mt', 'rd', 'file', 'if', 'elif', 'else', 'while',
    '引用', 'break', '断', 'for', 'in', 'window', 'tm', '音', '调色板',
    'import', 'mu', 'palette',
    'ON', 'hw', 'np', 'tb', 'mp', 'ui', 'bs',
}

# 两字符运算符必须先于单字符判断
TWO_OPS = ('==', '!=', '<=', '>=', '//')
SINGLE_OPS = set('.(){}=+-*/%<>,:[]?')


class PybkError(Exception):
    """PYbook 词法/语法错误，信息带行号。"""


def _is_digit(c: str) -> bool:
    return '0' <= c <= '9'


def _is_id_start(c: str) -> bool:
    return (c == '_' or 'a' <= c <= 'z' or 'A' <= c <= 'Z'
            or '\u4e00' <= c <= '\u9fff')


def _is_id_char(c: str) -> bool:
    return _is_id_start(c) or _is_digit(c)


def _lex(src: str) -> list:
    """返回 (kind, value, line, pos) 四元组列表，pos 是 Token 起始偏移。"""
    toks = []
    i, n, line = 0, len(src), 1
    while i < n:
        c = src[i]
        if c == '\n':
            line += 1
            i += 1
            continue
        if c in ' \t\r':
            i += 1
            continue
        if c == '#':                      # 注释到行末
            while i < n and src[i] != '\n':
                i += 1
            continue
        if src[i:i + 2] == '/*':          # C 风格块注释（AI 从 C/JS 抄代码常写）：到 */ 为止
            end = src.find('*/', i + 2)
            if end < 0:
                toks.append(('ERR', '/*', line, i))
                i += 2
                continue
            line += src.count('\n', i, end)
            i = end + 2
            continue
        if c == '@':
            toks.append(('AT', '@', line, i))
            i += 1
            continue
        if c == '"':
            j = i + 1
            while j < n and src[j] != '"' and src[j] != '\n':
                j += 1
            if j >= n or src[j] == '\n':
                raise PybkError(f"第 {line} 行：字符串未闭合")
            toks.append(('STR', src[i + 1:j], line, i))
            i = j + 1
            continue
        if _is_digit(c):                  # 整数或小数
            j = i
            while j < n and _is_digit(src[j]):
                j += 1
            if j + 1 < n and src[j] == '.' and _is_digit(src[j + 1]):
                j += 1
                while j < n and _is_digit(src[j]):
                    j += 1
            toks.append(('NUM', src[i:j], line, i))
            i = j
            continue
        if _is_id_start(c):               # 标识符 / 关键字（允许中文）
            j = i
            while j < n and _is_id_char(src[j]):
                j += 1
            w = src[i:j]
            toks.append(('KW' if w in KEYWORDS else 'NAME', w, line, i))
            i = j
            continue
        if src[i:i + 2] in TWO_OPS:
            toks.append(('OP', src[i:i + 2], line, i))
            i += 2
            continue
        if c in SINGLE_OPS:
            toks.append(('OP', c, line, i))
            i += 1
            continue
        # 非法字符：占位，交给上层在正确位置报错（见文件头说明）
        toks.append(('ERR', c, line, i))
        i += 1
    last_line = toks[-1][2] if toks else 1   # EOF 行号锚定在最后一条真实代码行
    toks.append(('EOF', '', last_line, i))
    return toks


def tokenize(src: str) -> list[Token]:
    """返回 Token 流。ns.show(...) 的裸文本里可能含任意字符（$、！等），
    它们在词法层是 ERR 占位符；tokenize 无上下文、无法判断是否在裸文本区，
    因此这里跳过 ERR，非法字符的完整校验由 parse() 带行号抛出。"""
    toks = _lex(src)
    return [Token(k, v, ln) for k, v, ln, _ in toks if k != 'ERR']


# ---------------------------------------------------------------- AST

@dataclass
class NumLit:  value: int | float; line: int
@dataclass
class StrLit:  value: str; line: int
@dataclass
class StrParts: parts: list; line: int                 # "得分 $分" 插值：[(TEXT/VAR, ...)]
@dataclass
class BoolLit: value: bool; line: int
@dataclass
class VarRef:  name: str; line: int
@dataclass
class BinOp:   op: str; left: object; right: object; line: int   # + - * / % // == != < > <= >= and or
@dataclass
class Unary:   op: str; operand: object; line: int               # - not
@dataclass
class Call:    name: str; args: list; line: int                  # list.名字(实参)
@dataclass
class InputExpr: prompt: str; line: int                          # input("提示")
@dataclass
class Ret:     expr: object; line: int                           # ret 表达式 或裸 ret
@dataclass
class VgAssign: name: str; expr: object; line: int               # vg.名=表达式
@dataclass
class IpAssign: name: str; prompt: str; line: int                # vg(ip).名=input("提示")
@dataclass
class GoldDel: kind: str; name: str; line: int                   # lock(名) / del(名)
@dataclass
class MemoryMode: mode: int; line: int                           # Memoryment@模式  0=自动 1=手动
@dataclass
class NsShow:  parts: list; magic: list; line: int; vc_cond: object = None; vc_alt: list = field(default_factory=list)   # 短vc：vc:条件?(替代内容)
@dataclass
class HmStmt:  kind: str; parts: list; arg: str; magic: list; line: int   # 网页输出分支：kind='big'/'mid'/'show'/'img'/'line'/'link'
@dataclass
class HmDraw: cmd: str; params: list; line: int
# cmd: 'begin' 'end' 'color' 'circle' 'rect' 'line' 'clear' 'text' 'img_draw' 'img_scaled'
# params: 各命令的参数表达式列表
@dataclass
class HmFrame: body: list; line: int            # web.帧 {...}：一帧动画（块内是 web.draw.* 语句）
@dataclass
class HmPlay:  speed: object; line: int         # web.播放(速度)：以 速度(帧/秒) 循环播放之前的所有帧
@dataclass
class HmLive:  body: list; fps: object; line: int  # web.实时 {...}：浏览器里逐帧实时跑的块（fps=None 默认 60）
@dataclass
class HmBlockDef: name: str; params: list; body: list; line: int  # web.块 名字(参数) {...}：页面组件定义
@dataclass
class HmUse:    name: str; args: list; line: int   # web.名字(实参)：展开已定义的组件
@dataclass
class TestCheck: cond: object; name: str; line: int  # 查(条件, "名字")：测试断言
@dataclass
class HmPageStmt: name: str; body: list; line: int  # web.页("名") {...}：子页面（烤成独立 HTML）
@dataclass
class GoStmt:  direction: str; distance: object; speed: object; line: int
# direction: '右'/'左'/'上'/'下'（或 right/left/up/down）；distance/speed 是表达式
@dataclass
class ClassDef: name: str; props: list; methods: list; line: int          # props: [(属性名, 默认表达式或 None)]
@dataclass
class Member:   base: object; attr: str; line: int                        # 表达式位置：实例.属性（可链式）
@dataclass
class MethodCall: base: object; name: str; args: list; line: int          # 实例.方法(实参)
@dataclass
class AssignMember: base: object; attr: str; expr: object; line: int      # self.属性/vg.实例.属性 = 表达式
@dataclass
class CtorExpr: class_name: str; kwargs: list; line: int                  # lb.类名(属性=值, ...)
@dataclass
class Around:  times: object; body: list; line: int; var: str = 'at'   # rm.around(X)[-> 名]{...}
@dataclass
class ForIn:   var: str; iter: object; body: list; line: int; var2: str = None
@dataclass
class TryCatch: body: list; var: str; handler: list; line: int   # try {...} catch e {...}
@dataclass
class OnError:  body: list; var: str; handler: list; line: int   # onerror err {...}：整个程序兜底
     # for x in 列表 / for 键, 值 in 字典 {...}：逐个取元素（列表可装对象）
@dataclass
class Aging:   cond: object; body: list; line: int               # rm.aging.while(条件){...}
@dataclass
class BreakStmt: line: int                                       # break/断：跳出当前层循环
@dataclass
class CdBlock: priority: int; body: list; line: int              # when {...}if(数字)
@dataclass
class VcChain: arms: list; line: int                             # [(条件或None, body), ...]
@dataclass
class FnDef:   name: str; params: list; body: list; line: int; defaults: dict = None
     # defaults: {参数名: 默认值节点}——调用可省略尾参
@dataclass
class ListLit: items: list; line: int                           # [表达式, ...]
@dataclass
class Index:   base: object; index: object; line: int           # 名字[表达式]
@dataclass
class Slice:   base: object; start: object; stop: object; step: object; line: int   # 名字[a:b:step]，任一段可缺省
@dataclass
class DictLit: pairs: list; line: int                    # {"键": 值, ...}（键为任意表达式）
@dataclass
class DictComp: key: object; val: object; vars: list; iter: object; cond: object; line: int
                                                              # {键: 值 for k[, v] in 源 if 条件}
@dataclass
class Ternary: cond: object; then: object; els: object; line: int   # 条件 ? 成立 : 不成立
@dataclass
class Comp:    expr: object; var: str; iter: object; cond: object; line: int    # [表达式 for x in 列表 if 条件]
@dataclass
class MultiAssign: targets: list; values: list; line: int       # vg.a, vg.b = 值1, 值2（右边先算完，支持交换）
@dataclass
class AssignIndex: name: str; index: object; expr: object; line: int   # vg_ro.名[i]=表达式
@dataclass
class Program: meta: str; fns: list; go_body: list; classes: list = None; imports: list = None   # 引用("名") → [(名, 行号)]


# ---------------------------------------------------------------- 语法分析

CMP_OPS = ('==', '!=', '<', '>', '<=', '>=')

GO_DIRECTIONS = ('右', '左', '上', '下', 'right', 'left', 'up', 'down')

# 游戏零件内置调用：名字 -> 参数个数（key/win/clear/color/box/show/wait/end）
GAME_CALLS = {'key': 1, 'hit': 1, 'win': 3, 'clear': 0, 'color': 3,
              'box': 4, 'show': 0, 'wait': 1, 'end': 0,
              '字': 4, '图': 3, '图缩': 5, '图翻': 6, '绘': 1,
              '线': 4, '点': 2,
              'text': 4, 'img': 3, 'imgs': 5, 'line': 4, 'dot': 2,
              '圆': 3, 'circle': 3, 'mx': 0, 'my': 0, 'mdown': 0, 'mhit': 0,
              'dirkeys': 0, 'frame': 0, 'sec': 0}

# 标准库模块调用：全名（前缀.函数）-> 参数个数。
# te/mt/rd 实现在 pybook_lib.c（rt_lib_te_* 等），list 扩展见 pybook_rt.h，
# file 见 pybook_file.c。前端解析成 Call('te.split', ...) 普通节点。
LIB_PREFIXES = ('te', 'mt', 'rd', 'list', 'file', 'tm', '音', '调色板', 'mu', 'palette', 'net', 'hw', 'np', 'tb', 'mp', 'ui', 'dict', 'js', 'csv', 'mm', 'bs')
LIB_CALLS = {
    'te.split': 2, 'te.replace': 3, 'te.trim': 1, 'te.upper': 1, 'te.lower': 1,
    'te.has': 2, 'te.len': 1, 'te.cut': 3, 'te.join': 2,
    'mt.sqrt': 1, 'mt.pow': 2, 'mt.abs': 1, 'mt.ceil': 1, 'mt.floor': 1,
    'mt.mod': 2, 'mt.max': 1, 'mt.min': 1, 'mt.prod': 1, 'mt.sum': 1, 'mt.sin': 1,
    'mt.cos': 1, 'mt.tan': 1, 'mt.pi': 0,
    'mt.lerp': 3, 'mt.dist': 4, 'mt.clamp': 3,
    'rd.int': 2, 'rd.float': 0, 'rd.pick': 1, 'rd.shuffle': 1,
    'list.sort': 1, 'list.sorted': 1, 'list.rsorted': 1, 'list.reverse': 1, 'list.unique': 1, 'list.merge': 2, 'list.byfield': 3,
    'list.find': 2, 'list.max': 1, 'list.min': 1,
    'file.read': 1, 'file.write': 2, 'file.add': 2, 'file.exists': 1,
    'file.lines': 1, 'file.del': 1,
    'tm.stop': 2, 'tm.now': 0,
    'net.listen': 1, 'net.accept': 1, 'net.connect': 2,
    'net.recv': 1, 'net.readline': 1, 'net.send': 2, 'net.close': 1,
    'mu.sine': 2, 'mu.tri': 2, 'mu.play': 1, 'mu.stop': 0,
    'hw.open': 3, 'hw.clearcolor': 3, 'hw.camera': 5, 'hw.box': 9,
    'hw.fog': 2, 'hw.far': 1, 'hw.wire': 1,
    'hw.line': 9, 'hw.light': 4,
    'hw.sphere': 7, 'hw.cyl': 9, 'hw.fov': 1, 'hw.near': 1,
    'hw.tex': 2, 'hw.texuse': 1, 'hw.uv': 1,
    'hw.push': 6, 'hw.pop': 0,
    'hw.shader': 3, 'hw.preset': 2, 'hw.shaderuse': 1, 'hw.uni': 2,
    'hw.frame': 0, 'hw.end': 0, 'hw.key': 1, 'hw.hit': 1,
    'hw.mx': 0, 'hw.my': 0, 'hw.mdown': 0, 'hw.mhit': 0, 'hw.text': 4,
    'hw.grab': 0, 'hw.free': 0, 'hw.mdx': 0, 'hw.mdy': 0,
    'np.zeros': 1, 'np.range': 3, 'np.add': 2, 'np.sub': 2, 'np.mul': 2,
    'np.scale': 2, 'np.dot': 2, 'np.norm': 1, 'np.normalize': 1,
    'np.max': 1, 'np.min': 1, 'np.sum': 1, 'np.mean': 1,
    'np.sin': 1, 'np.cos': 1, 'np.sqrt': 1,
    'te.str': 1, 'dict.keys': 1, 'dict.values': 1, 'dict.byvalue': 2,
    # bs.* 位运算（实现在 pybook_bits.c）
    'bs.and': 2, 'bs.or': 2, 'bs.xor': 2, 'bs.not': 1,
    'bs.shl': 2, 'bs.shr': 2, 'bs.get': 2, 'bs.set': 3,
    'bs.popcount': 1, 'bs.band': 1, 'bs.mask': 1,
    'bs.hex': 1, 'bs.bin': 1, 'bs.frombin': 1, 'bs.fromhex': 1,
    'safe.get': 3, 'js.parse': 1, 'js.dump': 1, 'csv.parse': 1, 'csv.dump': 1, 'mm.色': 4, 'mm.color': 4, 'mm.draw_away': 3, 'mm.贴': 4, 'mm.blt': 4, 'mm.动': 5, 'mm.anim': 5, 'list.flat': 1, 'list.zip': 2, 'list.count': 2, 'safe.at': 3,
    'ui.按钮': 5, 'ui.输入框': 5, 'ui.滑条': 6,
    'tb.mat': 2, 'tb.rand': 2, 'tb.rows': 1, 'tb.cols': 1,
    'tb.dot': 2, 'tb.tr': 1, 'tb.add': 2, 'tb.mul': 2, 'tb.addrow': 2,
    'tb.relu': 1, 'tb.relu_grad': 1, 'tb.sigmoid': 1, 'tb.sigmoid_grad': 1,
    'tb.mse': 2, 'tb.mse_grad': 2,
    'tb.lin': 3, 'tb.lin_dx': 3, 'tb.lin_dw': 2, 'tb.lin_db': 1,
    'tb.step': 3,
    'tb.softmax': 1, 'tb.crossent': 2, 'tb.crossent_grad': 2, 'tb.argmax': 1,
    'tb.sgd': 3, 'tb.adam': 8,
    'tb.shuffle': 2, 'tb.onehot': 2, 'tb.batch': 3,
    'mp.vec_add': 2, 'mp.vec_sub': 2, 'mp.vec_scale': 2, 'mp.vec_dot': 2,
    'mp.vec_norm': 1, 'mp.vec_dist': 2, 'mp.vec_cross': 2, 'mp.vec_lerp': 3,
    'mp.mat_add': 4, 'mp.mat_scale': 4, 'mp.mat_mul': 5, 'mp.mat_transpose': 3,
    'mp.mat_identity': 1, 'mp.mat_det': 2, 'mp.mat_inverse': 2, 'mp.mat_vec_mul': 4,
    'mp.mean': 1, 'mp.var': 2, 'mp.std': 2, 'mp.sum': 1, 'mp.minmax': 1,
    'mp.linspace': 3,
    'mp.clamp': 3, 'mp.smoothstep': 3, 'mp.lerp': 3, 'mp.radians': 1, 'mp.degrees': 1,
    'mp.rand_seed': 1, 'mp.rand_u01': 0, 'mp.rand_normal': 2,
    'mt.atan2': 2,
    '音.正弦': 2, '音.三角': 2, '音.放': 1, '音.停': 0, '音.快': 3,
    '音.音': 3, '音.奏': 3, '音.谱': 2,
    # 调色板.颜色名：零参调用，返回新建的 [r,g,b] 列表（内置常量色表）
    '调色板.红': 0, '调色板.橙': 0, '调色板.黄': 0, '调色板.绿': 0,
    '调色板.青': 0, '调色板.蓝': 0, '调色板.紫': 0, '调色板.白': 0,
    '调色板.黑': 0, '调色板.灰': 0, '调色板.粉': 0, '调色板.金': 0,
}

# key(...) 合法键名：英文键名 + 中文键名 + 单字母 a-z
KEY_NAMES = ({'right', 'left', 'up', 'down', 'space', 'enter', 'esc', 'shift',
              '右', '左', '上', '下', '空格', '回车'}
             | {chr(c) for c in range(ord('a'), ord('z') + 1)})


class _Parser:
    def __init__(self, src: str):
        self.src = src
        self._class_props = {}     # 类名 -> 属性名集合（语义检查用）
        self._pending_ctors = []   # CtorExpr 节点，parse_program 末尾统一校验
        self._hoisted_classes = [] # 语句位置的单行类定义（提升到程序类表）
        self._frame_count = 0      # 已解析的 web.帧 数（web.播放 语义检查用）
        self.hm_blocks = {}        # 组件名 -> HmBlockDef（web.块 定义，先定义后使用）
        self._mem_self = False     # 当前是否处于 @self 内存模式（控制 vg. 声明可省）
        self._hw_on = False        # 3D_highway 模块：ON 3D_highway 之后才可用 hw.*
        self._window_open = False  # window(normal, open) 框架模式
        self.loop_depth = 0        # 循环嵌套深度（break 只能在循环内使用的检查用）
        self.toks = _lex(src)
        self.i = 0

    # ---- 基础工具 ----

    def cur(self):
        return self.toks[self.i]

    def kind(self):
        return self.toks[self.i][0]

    def val(self):
        return self.toks[self.i][1]

    def line(self):
        return self.toks[self.i][2]

    def err(self, msg: str):
        raise PybkError(f"第 {self.line()} 行：{msg}")

    def advance(self):
        k, v, ln, _p = self.toks[self.i]
        if k == 'ERR':
            raise PybkError(f"第 {ln} 行：非法字符 {v!r}")
        self.i += 1
        return self.toks[self.i - 1]

    def expect(self, kind: str, value=None):
        k, v, ln, _p = self.cur()
        if k == 'ERR':
            raise PybkError(f"第 {ln} 行：非法字符 {v!r}")
        if k != kind or (value is not None and v != value):
            want = value if value is not None else kind
            self.err(f"期望 {want!r}，实际是 {v if v else k!r}")
        return self.advance()

    def at(self, kind: str, value=None) -> bool:
        k, v, _ln, _p = self.cur()
        return k == kind and (value is None or v == value)

    def sync_to(self, pos: int):
        """跳过起始位置在 pos 之前的所有 Token（越过裸文本区域用）。"""
        while self.toks[self.i][0] != 'EOF' and self.toks[self.i][3] < pos:
            self.i += 1

    def scan_raw(self, start: int, what: str):
        """从源码 start 位置扫到配对的 ')'（支持括号嵌套），返回 (文本, 右括号偏移)。"""
        depth = 0
        i = start
        n = len(self.src)
        while i < n:
            ch = self.src[i]
            if ch == '(':
                depth += 1
            elif ch == ')':
                if depth == 0:
                    return self.src[start:i], i
                depth -= 1
            i += 1
        raise PybkError(f"第 {self.line()} 行：{what} 缺少右括号 )")

    # ---- 文件 ----

    def parse_program(self, require_going: bool = True) -> Program:
        """require_going=True 主文件（GOING 必须有）；False 模块单元
        （被引用的 .pybk：GOING 可有可无、有也被忽略；允许顶层 vg）。"""
        self.require_going = require_going
        meta = '未命名'
        if self.at('AT'):               # @ 元信息行可选：不写按未命名处理
            at = self.expect('AT')
            nl = self.src.find('\n', at[3])
            meta_end = len(self.src) if nl < 0 else nl
            meta = self.src[at[3] + 1:meta_end].strip()
            self.sync_to(meta_end)      # 跳过 @ 行上被切出的杂散 Token
        fns = []
        mems = []
        classes = []
        imports = []
        init_stmts = []   # 模块模式的顶层 vg：编译器把它们合并进主文件当初始化
        require_going = getattr(self, 'require_going', True)
        while True:
            if self.at('EOF'):
                if require_going:
                    self.err("文件必须包含恰好一个 GOING 块")
                break                   # 模块单元到文件尾正常结束
            if self.at('KW', 'lb'):
                classes.append(self.parse_class())
            elif self.at('KW', 'func'):
                fns.append(self.parse_func())
            elif self.at('KW', 'Memoryment'):
                mems.append(self.parse_memoryment())
            elif self.at('KW', 'window'):
                self.parse_window()
            elif self.at('KW', 'ON'):
                self.parse_on()
            elif self.at('KW', '引用'):
                imports.append(self.parse_import())
            elif self.at('KW', 'web'):
                self.parse_hm_blockdef()
            elif not require_going and (self.at('KW', 'vg') or self.at('KW', 'vg_ro')):
                is_ro = self.at('KW', 'vg_ro')
                init_stmts.append(self.parse_vg('vg_ro' if is_ro else 'vg'))
            elif self.at('KW', 'GOING'):
                if require_going:
                    break          # 主文件：跳出循环，GOING 由循环后统一解析
                go_body = self.parse_going()
                if not self.at('EOF'):
                    self.err("模块文件里 GOING 之后不应再有内容")
                break
            else:
                if require_going:
                    self.err("文件必须包含恰好一个 GOING 块")
                self.err("模块文件顶层只能是 引用/func/vg/lb/Memoryment")
        if require_going:
            go_body = self._重排onerror(self.parse_going())
            go_body = mems + go_body
            if not self.at('EOF'):
                self.err("GOING 块之后不应再有内容")
        else:
            go_body = mems + init_stmts   # 模块初始化语句（vg 顶层赋值）
        for node in self._pending_ctors:      # 语义检查：类须存在、属性名须一致
            if node.class_name not in self._class_props:
                raise PybkError(f"第 {node.line} 行：未定义的类 {node.class_name!r}")
            for kwn, _e in node.kwargs:
                if kwn not in self._class_props[node.class_name]:
                    raise PybkError(
                        f"第 {node.line} 行：类 {node.class_name!r} 没有属性 {kwn!r}")
        classes.extend(self._hoisted_classes)  # 语句位置定义的单行类并入类表
        prog = Program(meta, fns, go_body, classes)
        prog.imports = imports
        prog.hm_blocks = self.hm_blocks
        prog.window_open = 1 if self._window_open else 0
        return prog

    def parse_on(self):
        """ON 3D_highway：模块开关。ON 之后到行尾整段扫过（模仿 @ 元信息行，
        避免词法器把 3D_highway 切成数字），去空白后必须等于 3D_highway。"""
        ln = self.expect('KW', 'ON')[2]
        nl = self.src.find('\n', self.toks[self.i - 1][3])
        end = len(self.src) if nl < 0 else nl
        rest = self.src[self.toks[self.i - 1][3] + 2:end].strip()
        self.sync_to(end)           # 行尾的杂散 Token（如被切碎的标识符）整段跳过
        if rest != '3D_highway':
            self.err(f"目前只有 3D_highway 模块")
        self._hw_on = True

    def parse_import(self):
        """引用("名字")：加载同目录下 名字.pybk；必须在 GOING 之前。"""
        ln = self.cur()[2]
        if not (self.at('KW', '引用') or self.at('KW', 'import')):
            self.err('这里是 引用("名") / import("名")')
        self.advance()
        self.expect('OP', '(')
        name = self.expect('STR')[1]
        self.expect('OP', ')')
        self._preload_module_classes(name, ln, set())
        return (name, ln)

    def _preload_module_classes(self, name, ln, seen):
        """把模块（及其引用链）的类属性表并进本文件的语义检查，
        主文件里才能通过 类名(属性=...) 构造器的存在性检查。
        路径/解析问题在这里静默放过——正式报错由代码生成期的合并逻辑给出。"""
        if name in seen:
            return
        seen.add(name)
        import os, sys
        base = '.'
        try:
            if len(sys.argv) > 1 and os.path.exists(sys.argv[1]):
                base = os.path.dirname(os.path.abspath(sys.argv[1])) or '.'
        except Exception:
            pass
        path = os.path.join(base, name + '.pybk')
        if not os.path.isfile(path):
            return
        try:
            with open(path, encoding='utf-8-sig') as fh:
                sub = parse_module(fh.read())
        except Exception:
            return
        # 注意：sub.imports 的元素是 (名字, 行号) 元组，递归时要取 [0]
        for sub_name in getattr(sub, 'imports', None) or []:
            self._preload_module_classes(
                sub_name[0] if isinstance(sub_name, tuple) else sub_name, ln, seen)
        for cd in (sub.classes or []):
            if cd.name not in self._class_props:
                self._class_props[cd.name] = [p for p, _d in cd.props]

    def parse_func(self) -> FnDef:
        ln = self.expect('KW', 'func')[2]
        name = self.expect('NAME')[1]
        self.expect('OP', '(')
        params = []
        defaults = {}
        if not self.at('OP', ')'):
            params.append(self.expect('NAME')[1])
            if self.at('OP', '='):             # 默认值
                self.advance()
                defaults[params[-1]] = self.parse_expr()
            while self.at('OP', ','):
                self.advance()
                params.append(self.expect('NAME')[1])
                if self.at('OP', '='):
                    self.advance()
                    defaults[params[-1]] = self.parse_expr()
        self.expect('OP', ')')
        if self.at('OP', '='):                 # 单行函数：func f(x) = 表达式
            self.advance()
            外层参数 = getattr(self, '_fn参数', None)
            self._fn参数 = set(params)
            body = [Ret(self.parse_expr(), ln)]
            self._fn参数 = 外层参数
            return FnDef(name, params, body, ln, defaults)
        外层参数 = getattr(self, '_fn参数', None)
        self._fn参数 = set(params)          # 参数名允许直接下标赋值（冒泡等场景）
        body, _ = self._block()
        self._fn参数 = 外层参数
        return FnDef(name, params, body, ln, defaults)

    def parse_class(self):
        """lb.类名 { vg.属性[=默认值]...  func 方法(...){...} }"""
        ln = self.expect('KW', 'lb')[2]
        self.expect('OP', '.')
        name = self.expect('NAME')[1]
        if name in self._class_props:
            self.err(f"类 {name!r} 重复定义")
        self.expect('OP', '{')
        props = []
        methods = []
        while not self.at('OP', '}'):
            if self.at('EOF'):
                self.err("类体缺少收尾的 }")
            if self.at('KW', 'vg') or self.at('KW', 'vg_ro'):
                self.advance()
                self.expect('OP', '.')
                pname = self.expect('NAME')[1]
                default = None
                if self.at('OP', '='):
                    self.advance()
                    default = self.parse_expr()
                props.append((pname, default))
            elif self.at('KW', 'func'):
                methods.append(self.parse_func())
            else:
                self.err("类体里只能是属性声明(vg.名)或方法(func 名)")
        self.expect('OP', '}')
        self._class_props[name] = {p for p, _d in props}
        return ClassDef(name, props, methods, ln)

    def parse_class_oneline(self, ln):
        """语句位置的单行类定义：lb.名(属性=默认值, ...)。

        生成与多行 lb.名{ vg.属性=默认值 ... } 完全相同的 ClassDef
        （props 带默认值、methods 为空）；expression 位置的 lb.名(...)
        仍是构造实例，由 parse_primary 负责，互不影响。"""
        self.expect('KW', 'lb')
        self.expect('OP', '.')
        name = self.expect('NAME')[1]
        if name in self._class_props:
            self.err(f"类 {name!r} 重复定义")
        self.expect('OP', '(')
        props = []
        while not self.at('OP', ')'):
            pname = self.expect('NAME')[1]
            self.expect('OP', '=')
            props.append((pname, self.parse_expr()))
            if not self.at('OP', ','):
                break
            self.advance()
        self.expect('OP', ')')
        self._class_props[name] = {p for p, _d in props}
        return ClassDef(name, props, [], ln)

    def parse_self_assign(self):
        """self.属性 = 表达式（支持 self.a.b = ... 链式）"""
        ln = self.expect('KW', 'self')[2]
        base = VarRef('self', ln)
        while self.at('OP', '.'):
            self.advance()
            _k2, v2, l2, _p2 = self.expect('NAME')
            prev, base = base, Member(base, v2, l2)
        self.expect('OP', '=')
        return AssignMember(prev, base.attr, self.parse_expr(), ln)

    def _重排onerror(self, stmts):
        """onerror 包裹 GOING 中它之后的全部语句（嵌套进 body）。"""
        out = []
        i = 0
        while i < len(stmts):
            st = stmts[i]
            if isinstance(st, OnError):
                内层 = self._重排onerror(stmts[i + 1:])
                if 内层:
                    st.body = 内层
                out.append(st)
                return out        # onerror 之后不再有兄弟
            out.append(st)
            i += 1
        return out

    def parse_going(self) -> list:
        self.expect('KW', 'GOING')
        if self.at('OP', ':'):
            self.advance()
        body, rb_line = self._block()
        stop = self.expect('KW', 'STOP')
        if stop[2] != rb_line:
            self.err("STOP 必须紧跟在 } 之后（同一行）")
        return body

    # ---- 语句 ----

    def _block(self):
        self.expect('OP', '{')
        body = []
        while not self.at('OP', '}'):
            if self.at('EOF'):
                self.err("块缺少收尾的 }")
            node = self.parse_stmt()
            if isinstance(node, ClassDef):
                # 语句位置的单行类定义是声明：提升到程序类表，不留在语句流里
                self._hoisted_classes.append(node)
            else:
                body.append(node)
        rb = self.expect('OP', '}')
        return body, rb[2]

    def parse_stmt(self):
        k, v, _ln, _p = self.cur()
        if k == 'KW':
            if v == 'Memoryment':
                return self.parse_memoryment()
            if v == 'vg':
                return self.parse_vg('vg')
            if v == 'vg_ro':
                return self.parse_vg('vg_ro')
            if v == 'ns':
                return self.parse_ns()
            if v == '查':
                ln2 = self.cur()[2]
                self.advance()
                self.expect('OP', '(')
                cond = self.parse_expr()
                self.expect('OP', ',')
                name = self.expect('STR')[1]
                self.expect('OP', ')')
                return TestCheck(cond, name, ln2)
            if v == 'web':
                return self.parse_hm()
            if v == 'rm':
                return self.parse_rm()
            if v == 'when':
                return self.parse_when()
            if v == 'try':
                return self.parse_trycatch()
            if v == 'onerror':
                return self.parse_onerror()
            if v == 'if':
                return self.parse_branch()
            if v == 'for':
                return self.parse_forin()
            if v in ('break', '断'):
                return self.parse_break(_ln)
            if v == 'ret':
                return self.parse_ret()
            if v in ('lock', 'del'):
                return self.parse_goldel()
            if v == 'list' and self.toks[self.i + 1][:2] == ('OP', '.') \
                    and self.toks[self.i + 2][0] == 'NAME' \
                    and self.toks[self.i + 3][:2] == ('OP', '('):
                return self.parse_list_call(_ln)
            if v == 'lb' and self.toks[self.i + 1][:2] == ('OP', '.') \
                    and self.toks[self.i + 2][0] == 'NAME' \
                    and self.toks[self.i + 3][:2] == ('OP', '('):
                return self.parse_class_oneline(_ln)   # 单行类定义（带默认值）
            if v == 'self':                    # self.属性 = 表达式
                return self.parse_self_assign()
            if v in GAME_CALLS and self.toks[self.i + 1][:2] == ('OP', '('):
                self.advance()                 # show(...)：内置调用名撞关键字的只有它
                return self._game_call(v, _ln)
            if v in LIB_PREFIXES and v != 'list' and self.toks[self.i + 1][:2] == ('OP', '.'):
                e = self.parse_expr()          # te/file 等语句（list 已由上面单独处理）
                if isinstance(e, Call) and e.name in LIB_CALLS:
                    return e
                self.err(f"不是合法的语句开头：{v!r}")
        if k == 'NAME':                        # 实例.方法(实参) 语句
            if v == 'go' and self.toks[self.i + 1][:2] == ('OP', '('):
                return self.parse_go()         # go(方向, 距离, 速度)：画布整体移动
            nxt = self.toks[self.i + 1][:2]
            if nxt[0] == 'OP' and nxt[1] in ('+', '-', '*', '/', '%')                     and self.toks[self.i + 2][:2] == ('OP', '='):
                self.advance()                 # 名字
                self.advance()                 # 复合运算符的第一半
                self.advance()                 # =
                return VgAssign(v, BinOp(nxt[1], VarRef(v, _ln), self.parse_expr(), _ln), _ln)
            if self._mem_self:                 # @self 模式：允许裸声明（vg. 可省）
                if nxt == ('OP', '='):
                    nm = self.expect('NAME')[1]
                    self.advance()
                    return VgAssign(nm, self.parse_expr(), _ln)
                if nxt == ('OP', '['):
                    nm = self.expect('NAME')[1]
                    self.advance()
                    idx = self.parse_expr()
                    self.expect('OP', ']')
                    self.expect('OP', '=')
                    return AssignIndex(nm, idx, self.parse_expr(), _ln)
            elif nxt == ('OP', '='):
                self.advance()                 # 名字
                self.advance()                 # =
                return VgAssign(v, self.parse_expr(), _ln)   # 裸赋值：自动声明
            elif nxt == ('OP', '['):
                if self._mem_self:
                    nm = self.expect('NAME')[1]
                    self.advance()
                    idx = self.parse_expr()
                    self.expect('OP', ']')
                    self.expect('OP', '=')
                    return AssignIndex(nm, idx, self.parse_expr(), _ln)
                # 严格模式：t[i] 开头——当前函数的参数可直接下标赋值；
                # 多重赋值（t[0], t[1] = ...）也放行；否则维持老报错
                存 = self.i
                nm = self.expect('NAME')[1]
                self.advance()
                idx = self.parse_expr()
                self.expect('OP', ']')
                if nm in getattr(self, '_fn参数', ()) and not self.at('OP', ','):
                    self.expect('OP', '=')
                    return AssignIndex(nm, idx, self.parse_expr(), _ln)
                if self.at('OP', ','):
                    targets = [Index(VarRef(nm, _ln), idx, _ln)]
                    while self.at('OP', ','):
                        self.advance()
                        k3, v3, _l3, _p3 = self.expect('NAME')
                        targets.append(self._多目标(v3, _ln))
                    self.expect('OP', '=')
                    values = [self.parse_expr()]
                    while self.at('OP', ','):
                        self.advance()
                        values.append(self.parse_expr())
                    if len(values) != len(targets):
                        self.err(f'第 {_ln} 行：多重赋值左右个数不匹配：'
                                 f'{len(targets)} 个目标，{len(values)} 个值')
                    return MultiAssign(targets, values, _ln)
                self.i = 存
                self.err(f"第 {_ln} 行：变量声明必须以 vg. 开头"
                         f"（规则：新变量写 vg.名 = 值；已声明的变量在其后可裸名赋值；"
                         f"函数参数的元素可直接 表[i] = 值；"
                         f"当前非 self 模式，文件头写 Memoryment@self 可放开限制）")
            elif nxt == ('OP', ','):          # a, b = b, a：裸多重赋值/交换
                self.advance()                # 吃掉首个变量名
                targets = [v]
                while self.at('OP', ','):
                    self.advance()
                    targets.append(self.expect('NAME')[1])
                self.expect('OP', '=')
                values = [self.parse_expr()]
                while self.at('OP', ','):
                    self.advance()
                    values.append(self.parse_expr())
                if len(values) != len(targets) and len(values) != 1:
                    self.err(f'第 {_ln} 行：多重赋值左右个数不匹配：'
                             f'{len(targets)} 个目标，{len(values)} 个值')
                return MultiAssign(targets, values, _ln)
            e = self.parse_expr()
            if isinstance(e, MethodCall):
                return e
            if isinstance(e, Call) and (e.name in GAME_CALLS or e.name in LIB_CALLS
                    or e.name in ('添加', '删掉', '长度', '碰到',
                        'add', 'remove', 'len', 'touch')):
                return e                       # 游戏零件/内置语句：win(...) / clear() / 添加(...) 等
            if isinstance(e, Member) and self.at('OP', '='):
                self.advance()                 # 实例.属性 = 表达式（含 for-in 循环变量）
                return AssignMember(e.base, e.attr, self.parse_expr(), _ln)
            self.err(f"不是合法的语句开头：{v!r}")
        self.err(f"不是合法的语句开头：{v if v else k!r}")

    def parse_goldel(self):
        _k, v, ln, _p = self.advance()
        kind = 'gold' if v == 'lock' else 'del'
        self.expect('OP', '(')
        name = self.expect('NAME')[1]
        self.expect('OP', ')')
        return GoldDel(kind, name, ln)

    def parse_memoryment(self):
        ln = self.expect('KW', 'Memoryment')[2]
        self.expect('AT')
        k, v, _l, _p = self.cur()
        if k in ('NAME', 'KW') and v in ('normal', 'self'):
            mode = 0 if v == 'normal' else 1
            self.advance()
        elif k == 'NUM':
            n = int(v)
            # @1→0 普通  @2→1 手动  @3 引用计数  @4 竞技场  @5 标记清除  @6 分代+增量
            mode = {1: 0, 2: 1, 3: 3, 4: 4, 5: 5, 6: 6}.get(n)
            if mode is None:
                raise PybkError(f"第 {ln} 行：Memoryment 模式 {n} 不支持"
                                f"（支持 1/2/3/4/5/6/normal/self）")
            self.advance()
        else:
            self.err("Memoryment 后要 @normal、@self 或 @数字")

        self._mem_self = (mode == 1)
        return MemoryMode(mode, ln)


    def parse_window(self):
        """window(normal, open)：窗口框架模式。

        normal=桌面窗口（web 模式以后另加）；open=框架接管循环：
        GOING 里 win(宽, 高, "标题") 之前的语句只跑一次（初始化），
        之后的语句每帧跑一遍（框架自动 end 退出 / show / 60FPS）；
        全文件允许省略 vg. 前缀。"""
        ln = self.expect('KW', 'window')[2]
        self.expect('OP', '(')
        _k, a1, _l, _p = self.expect('NAME')
        if a1 != 'normal':
            self.err("window 的第一个参数目前只支持 normal（桌面窗口）")
        self.expect('OP', ',')
        _k, a2, _l2, _p2 = self.expect('NAME')
        if a2 != 'open':
            self.err("window 的第二个参数目前只支持 open（框架接管循环）")
        self.expect('OP', ')')
        self._window_open = True
        self._mem_self = True   # 框架模式：赋值可省 vg. 前缀
    def parse_vg(self, kw='vg'):
        ln = self.expect('KW', kw)[2]
        if self.at('OP', '(') and self.toks[self.i + 1][:2] == ('KW', 'ip'):
            self.advance()                      # (
            self.advance()                      # ip
            self.expect('OP', ')')
            self.expect('OP', '.')
            name = self.expect('NAME')[1]
            self.expect('OP', '=')
            self.expect('KW', 'input')
            self.expect('OP', '(')
            prompt = self.expect('STR')[1]
            self.expect('OP', ')')
            return IpAssign(name, prompt, ln)
        self.expect('OP', '.')
        name = self.expect('NAME')[1]
        if self.kind() == 'OP' and self.val() in ('+', '-', '*', '/', '%', '//')                 and self.toks[self.i + 1][:2] == ('OP', '='):
            运 = self.val()
            self.advance()                    # 运算符
            self.advance()                    # =
            return VgAssign(name, BinOp(运, VarRef(name, ln), self.parse_expr(), ln), ln)
        if self.at('OP', ','):                # vg.a, vg.b = 值1, 值2：一行多定义
            targets = [name]
            while self.at('OP', ','):
                self.advance()
                self.expect('KW', kw)         # 逗号后每个目标都带 vg.
                self.expect('OP', '.')
                targets.append(self.expect('NAME')[1])
            self.expect('OP', '=')
            values = [self.parse_expr()]
            while self.at('OP', ','):
                self.advance()
                values.append(self.parse_expr())
            if len(values) != len(targets) and len(values) != 1:
                self.err(f'多重赋值左右个数不匹配：{len(targets)} 个目标，{len(values)} 个值')
            return MultiAssign(targets, values, ln)
        if self.at('OP', '['):                # 名字[下标] = 表达式
            self.advance()
            idx = self.parse_expr()
            self.expect('OP', ']')
            self.expect('OP', '=')
            return AssignIndex(name, idx, self.parse_expr(), ln)
        if self.at('OP', '.'):                # vg.实例.属性 = 表达式（支持链式）
            base = VarRef(name, ln)
            while self.at('OP', '.'):
                self.advance()
                _k2, v2, l2, _p2 = self.expect('NAME')
                prev, base = base, Member(base, v2, l2)
            self.expect('OP', '=')
            return AssignMember(prev, base.attr, self.parse_expr(), ln)
        self.expect('OP', '=')
        return VgAssign(name, self.parse_expr(), ln)

    def parse_ns(self):
        ln = self.expect('KW', 'ns')[2]
        self.expect('OP', '.')
        self.expect('KW', 'show')
        lp = self.expect('OP', '(')
        raw, end = self.scan_raw(lp[3] + 1, 'ns.show')
        # 多参数：顶层逗号（引号外、括号外）切分 → 各段独立插值，输出以空格相连
        段s = self._切顶层逗号(raw, ln)
        if len(段s) > 1:
            parts = []
            for i, 段 in enumerate(段s):
                if i:
                    parts.append(('TEXT', ' '))
                if 段.startswith('"') and 段.endswith('"') and len(段) >= 2:
                    parts += self._split_content(段[1:-1], ln)
                else:
                    子 = _Parser(段)
                    parts.append(('EXPR', 子.parse_expr()))
        elif not raw.startswith('"') and '$' not in raw and re.search(r'[()\[]', raw):
            # 含括号/方括号才按表达式处理（如 te.join(表, " ")、list.max(数据)）；
            # 其余一律按文字显示（兼容旧式 ns.show(据点失守...) 写法）
            # 单段且像表达式（含括号/运算符/in）→ 按表达式显示；
            # 解析失败自动退回裸文本（兼容旧式 ns.show(据点失守！) 写法）
            try:
                子 = _Parser(raw)
                parts = [('EXPR', 子.parse_expr())]
            except PybkError:
                parts = self._split_content(raw, ln)
        else:
            # 注：raw 里的 / 是插值表达式的除号（/magic 在右括号之后，互不冲突）
            parts = self._split_content(raw, ln)
        self.sync_to(end)
        self.expect('OP', ')')
        magic = []
        j = end + 1
        while j < len(self.src) and self.src[j] in ' \t':
            j += 1
        if self.src[j:j + 1] == '/':            # 可选的 /magic(...)
            self.expect('OP', '/')
            m = self.expect('NAME')
            if m[1] != 'magic':
                self.err(f"ns.show 后只能接 /magic，实际是 {m[1]!r}")
            mlp = self.expect('OP', '(')
            mraw, mend = self.scan_raw(mlp[3] + 1, 'magic')
            magic = self._split_magic(mraw, ln)
            self.sync_to(mend)
            self.expect('OP', ')')
        vc_cond, vc_alt = None, []
        if self.at('KW', 'vc') and self.toks[self.i + 1][:2] == ('OP', ':'):
            self.advance()                      # vc
            self.expect('OP', ':')
            vc_cond = self._or()                # 条件在 ? 之前；不能用 parse_expr——它会把 ? 当三元吃掉
            self.expect('OP', '?')
            lp = self.expect('OP', '(')
            raw, end = self.scan_raw(lp[3] + 1, 'vc: 替代内容')
            vc_alt = self._split_content(raw, ln)   # 规则与主内容一致
            self.sync_to(end)
            self.expect('OP', ')')
        return NsShow(parts, magic, ln, vc_cond, vc_alt)

    def parse_hm_blockdef(self):
        """web.块 名字(参数, ...) { web.* 语句 ... }：页面组件定义（顶层）。
        体里允许段落/标题/图片/控件等页面语句与嵌套 web.组件调用；
        不允许 帧/播放/实时/再定义块（那些依赖 GOING 语境）。"""
        ln = self.expect('KW', 'web')[2]
        self.expect('OP', '.')
        _k, v, _l, _p = self.advance()
        if v != '块':
            self.err(f"顶层 web. 后只能是 块（组件定义），实际是 web.{v!r}")
        name = self.expect('NAME')[1]
        if name in self.hm_blocks:
            self.err(f"第 {ln} 行：web.块 {name!r} 重复定义")
        self.expect('OP', '(')
        params = []
        if not self.at('OP', ')'):
            params.append(self.expect('NAME')[1])
            while self.at('OP', ','):
                self.advance()
                params.append(self.expect('NAME')[1])
        self.expect('OP', ')')
        body, _ = self._block()
        for st in body:
            if isinstance(st, (HmFrame, HmPlay, HmLive, HmDraw, HmPageStmt)):
                raise PybkError(f"第 {st.line} 行：web.块 里不能用 帧/播放/实时/draw/页"
                                "（组件只烤当前页内容，动画写在 GOING，子页用 web.页）")
        self.hm_blocks[name] = HmBlockDef(name, params, body, ln)

    def parse_hm(self):
        """网页输出分支：web.big/mid/show/img/line/link/draw/帧/播放。

        big/mid/show 的内容走 ns.show 同一套裸文本规则（scan_raw 括号嵌套
        计数、$插值/表达式、$吸收）；/magic 只有 show 支持。$名字 的"须已
        声明"检查沿用下游既有路径（VAR 部件原样上交）。帧/播放 组成帧动画。"""
        ln = self.expect('KW', 'web')[2]
        self.expect('OP', '.')
        _k, v, _l, _p = self.advance()
        if v == 'draw':                         # web.draw.始/色/圆/方/线/终：画布绘图
            self.expect('OP', '.')
            _dk, dv, _dl, _dp = self.advance()
            draw_map = {'始': ('begin', 0), '终': ('end', 0),
                        '色': ('color', 3), '圆': ('circle', 3),
                        '方': ('rect', 4), '线': ('line', 4),
                        '清': ('clear', 3),
                        '字': ('text', 4),
                        '图': ('img_draw', 3), '图缩': ('img_scaled', 5),
                        'begin': ('begin', 0), 'end': ('end', 0),
                        'color': ('color', 3), 'circle': ('circle', 3),
                        'rect': ('rect', 4), 'line': ('line', 4),
                        'clear': ('clear', 3), 'text': ('text', 4),
                        'img': ('img_draw', 3), 'imgs': ('img_scaled', 5)}
            if dv not in draw_map:
                self.err(f"web.draw. 后只能是 始/色/圆/方/线/清/字/图/图缩/终，实际是 {dv!r}")
            cmd, arity = draw_map[dv]
            if dv in ('始', 'begin') and self.at('OP', '('):
                # web.draw.始(宽, 高)：画布尺寸可选，缺省 400×300
                self.advance()
                w = self.expect('NUM')[1]
                self.expect('OP', ',')
                h = self.expect('NUM')[1]
                self.expect('OP', ')')
                if not (w.isdigit() and h.isdigit()):
                    self.err(f"第 {ln} 行：web.draw.始(宽, 高) 必须是正整数")
                iw, ih = int(w), int(h)
                if not (16 <= iw <= 4096 and 16 <= ih <= 4096):
                    self.err(f"第 {ln} 行：画布尺寸超范围（16..4096），得到 {iw}×{ih}")
                return HmDraw('begin', [NumLit(iw, ln), NumLit(ih, ln)], ln)
            if arity == 0 and self.at('OP', '('):
                self.err(f"web.draw.{dv} 不带括号和参数")
            params = []
            if arity:
                self.expect('OP', '(')
                params.append(self.parse_expr())
                while self.at('OP', ','):
                    self.advance()
                    params.append(self.parse_expr())
                self.expect('OP', ')')
                if len(params) != arity:
                    self.err(f"web.draw.{dv} 需要 {arity} 个参数，实际 {len(params)} 个")
            if cmd == 'text' and len(params) == 4 and isinstance(params[2], StrLit)                     and '$' in params[2].value:
                params = list(params)
                params[2] = StrParts(self._split_interp(params[2].value, ln), ln)
            return HmDraw(cmd, params, ln)
        if v in ('帧', 'frame'):                # web.帧 { web.draw.* ... }：一帧动画
            if self.at('OP', '('):              # 可选 (速度数字)：定稿语法，AST 不保存
                self.advance()
                self.expect('NUM')
                self.expect('OP', ')')
            body, _ = self._block()
            self._frame_count += 1
            return HmFrame(body, ln)
        if v == '实时':                         # web.实时 { ... }：浏览器实时循环（可选 (帧率)）
            fps = None
            if self.at('OP', '('):
                self.advance()
                fps = self.expect('NUM')[1]
                if not fps.isdigit():
                    self.err('web.实时(帧率) 里必须是正整数')
                fps = int(fps)
                if fps <= 0:
                    self.err('web.实时(帧率) 必须是正整数')
                self.expect('OP', ')')
            body, _ = self._block()
            return HmLive(body, fps, ln)
        if v in ('播放', 'play'):               # web.播放(速度)：循环播放之前的所有帧
            if self._frame_count == 0:
                self.err('web.播放 前必须至少有一个 web.帧')
            self.expect('OP', '(')
            speed = self.parse_expr()
            self.expect('OP', ')')
            return HmPlay(speed, ln)
        if v == 'line':                         # 独立语句：无参数无括号
            return HmStmt('line', [], '', [], ln)
        if v in ('img', 'link'):
            self.expect('OP', '(')
            if v == 'img':
                arg = self.expect('STR')[1]     # web.img("文件名")
                parts = []
            else:                               # web.link("显示文字", "网址")
                text = self.expect('STR')[1]
                self.expect('OP', ',')
                arg = self.expect('STR')[1]
                parts = [('TEXT', text)]
            self.expect('OP', ')')
            return HmStmt(v, parts, arg, [], ln)
        if v in ('big', 'mid', 'show'):
            lp = self.expect('OP', '(')
            raw, end = self.scan_raw(lp[3] + 1, f'web.{v}')
            parts = self._split_content(raw, ln)
            self.sync_to(end)
            self.expect('OP', ')')
            magic = []
            j = end + 1
            while j < len(self.src) and self.src[j] in ' \t':
                j += 1
            if self.src[j:j + 1] == '/':
                if v != 'show':
                    self.err(f"web.{v} 不支持 /magic（只有 web.show 支持）")
                self.expect('OP', '/')
                m = self.expect('NAME')
                if m[1] != 'magic':
                    self.err(f"web.show 的 / 后只能接 magic，实际是 {m[1]!r}")
                mlp = self.expect('OP', '(')
                mraw, mend = self.scan_raw(mlp[3] + 1, 'magic')
                magic = self._split_magic(mraw, ln)
                self.sync_to(mend)
                self.expect('OP', ')')
            return HmStmt(v, parts, '', magic, ln)
        if v == 'click':                        # web.click：画布被点击（表达式）
            return Call('web.click', [], ln)
        if v == 'mx':
            return Call('web.mx', [], ln)
        if v == 'my':
            return Call('web.my', [], ln)
            self.expect('OP', '(')
        if v == 'textbox':                      # web.textbox(占位, id)
            self.expect('OP', '(')
            tip = self.expect('STR')[1]
            self.expect('OP', ',')
            name = self.expect('STR')[1]
            bind = None
            if self.at('OP', ','):               # 第三参：回车触发的按钮 id
                self.advance()
                bind = self.expect('STR')[1]
            self.expect('OP', ')')
            return HmStmt('textbox', [('TEXT', tip)], name, [bind] if bind else [], ln)
        if v == 'button':                       # web.button(文字, id) → <button>
            self.expect('OP', '(')
            text = self.expect('STR')[1]
            self.expect('OP', ',')
            name = self.expect('STR')[1]
            self.expect('OP', ')')
            return HmStmt('button', [('TEXT', text)], name, [], ln)
        if v == 'audio':                        # web.audio("文件") 或 web.audio.stop()
            if self.at('OP', '.') and self.toks[self.i + 1][1] == 'stop':
                self.advance(); self.advance()
                self.expect('OP', '(')
                self.expect('OP', ')')
                return HmStmt('audio_stop', [], '', [], ln)
            self.expect('OP', '(')
            src = self.expect('STR')[1]
            self.expect('OP', ')')
            return HmStmt('audio', [('TEXT', src)], '', [], ln)
        if v == 'align':                        # web.align("center")
            self.expect('OP', '(')
            mode = self.expect('STR')[1]
            self.expect('OP', ')')
            return HmStmt('align', [('TEXT', mode)], '', [], ln)
        if v == 'gap':                          # web.gap(像素)
            self.expect('OP', '(')
            arg = self.expect('NUM')[1]
            self.expect('OP', ')')
            return HmStmt('gap', [('TEXT', arg)], '', [], ln)
        if v == 'open':                         # web.open("网址")
            self.expect('OP', '(')
            arg = self.expect('STR')[1]
            self.expect('OP', ')')
            return HmStmt('open', [], arg, [], ln)
        if v == 'style':                        # web.style("css")
            self.expect('OP', '(')
            arg = self.expect('STR')[1]
            self.expect('OP', ')')
            return HmStmt('style', [], arg, [], ln)
        if v == 'storage':                      # web.storage("键", "值")
            self.expect('OP', '(')
            k = self.parse_expr()
            self.expect('OP', ',')
            v2 = self.parse_expr()
            self.expect('OP', ')')
            return HmStmt('storage', [k, v2], '', [], ln)
        if v == 'waitsec':                      # web.waitsec(秒)：暂停 N 秒（生成 setInterval 显示）
            self.expect('OP', '(')
            arg = self.expect('NUM')[1]
            self.expect('OP', ')')
            return HmStmt('waitsec', [('TEXT', arg)], '', [], ln)
        if v == 'title':                        # web.title("标题")
            self.expect('OP', '(')
            arg = self.expect('STR')[1]
            self.expect('OP', ')')
            return HmStmt('title', [], arg, [], ln)
        if v == '置':                           # web.置("id", 值)：回写输入框（实时块用）
            self.expect('OP', '(')
            a = self.parse_expr()
            self.expect('OP', ',')
            b = self.parse_expr()
            self.expect('OP', ')')
            return HmStmt('set', [a, b], '', [], ln)
        if v == '页':                           # web.页("名") { 页面语句 }：烤成独立网页
            self.expect('OP', '(')
            name = self.expect('STR')[1]
            self.expect('OP', ')')
            if any(ch in name for ch in '/\\:*?"<>|') or not name:
                self.err(f"web.页 名字不能为空且不能含 /\\:*?\"<>|，实际是 {name!r}")
            body, _ = self._block()
            for st in body:
                if isinstance(st, (HmFrame, HmPlay, HmLive, HmDraw, HmPageStmt)):
                    raise PybkError(
                        f"第 {st.line} 行：web.页 里不能用 帧/播放/实时/draw/嵌套页"
                        "（子页只烤页面内容，动画写在主页的画布段里）")
            return HmPageStmt(name, body, ln)
        if v in self.hm_blocks:                 # web.组件名(实参)：展开已定义的块
            d = self.hm_blocks[v]
            args = []
            if self.at('OP', '('):
                self.advance()
                if not self.at('OP', ')'):
                    args.append(self.parse_expr())
                    while self.at('OP', ','):
                        self.advance()
                        args.append(self.parse_expr())
                self.expect('OP', ')')
            if len(args) != len(d.params):
                self.err(f"第 {ln} 行：web.{v} 需要 {len(d.params)} 个参数，实际 {len(args)} 个")
            return HmUse(v, args, ln)
        if v == '块':
            self.err(f"第 {ln} 行：web.块 只能定义在文件顶层（func 旁边），不能写在 GOING 或块里")
        self.err(f"web. 后只能是 big/mid/show/img/line/link/draw/帧/播放/实时"
                 f"/click/mx/my/textbox/button/audio/align/gap/open/style/title"
                 f"或已定义的组件名，实际是 {v!r}")

    def parse_go(self):
        """go(方向, 距离, 速度)：把画布整体平移。

        方向是 中文 右/左/上/下 或英文 right/left/up/down；距离与速度是表达式。"""
        ln = self.expect('NAME', 'go')[2]
        self.expect('OP', '(')
        _k, d, _l, _p = self.expect('NAME')
        if d not in GO_DIRECTIONS:
            self.err("go 的方向只能是 右/左/上/下（或 right/left/up/down）")
        self.expect('OP', ',')
        dist = self.parse_expr()
        self.expect('OP', ',')
        speed = self.parse_expr()
        self.expect('OP', ')')
        return GoStmt(d, dist, speed, ln)

    def _game_call(self, name: str, ln: int) -> Call:
        """游戏零件内置调用：key("right")、win(800,600,"名")、clear() 等。

        参数个数按 GAME_CALLS 校验；key 的实参必须是字符串字面量
        且键名合法（right/left/up/down/space/a-z/enter/esc/shift 或中文）。"""
        self.expect('OP', '(')
        args = []
        if not self.at('OP', ')'):
            args.append(self.parse_expr())
            while self.at('OP', ','):
                self.advance()
                args.append(self.parse_expr())
        self.expect('OP', ')')
        # 圆 → circle：走后端默认英文名分支 rt_game_circle（对整文件保存回滚免疫）
        name = {'text': '字', 'img': '图', 'imgs': '图缩', 'line': '线',
                'dot': '点', '圆': 'circle'}.get(name, name)
        want = GAME_CALLS[name]
        if name == 'color' and len(args) in (1, 3):
            want = len(args)   # color 重载：color(r,g,b) 与 color(列表) 并存
        if len(args) != want:
            raise PybkError(f"第 {ln} 行：{name} 需要 {want} 个参数，实际 {len(args)} 个")
        if name == 'key':
            a = args[0]
            if not isinstance(a, StrLit):
                raise PybkError(f'第 {ln} 行：key 的键名必须是字符串字面量，如 key("right")')
            if a.value not in KEY_NAMES:
                raise PybkError(f'第 {ln} 行：不支持的键名 {a.value!r}'
                                '（可用 right/left/up/down/space/字母 a-z/enter/esc/shift'
                                ' 或 右/左/上/下/空格/回车）')
        return self._maybe_interp(name, args, ln)

    def _maybe_interp(self, name, args, ln):
        """字 的文本参数支持 $插值："得分 $分" → StrParts。"""
        if name in ('字', '图') and isinstance(args[2], StrLit)                 and '$' in args[2].value:
            args = list(args)
            args[2] = StrParts(self._split_interp(args[2].value, ln), ln)
        return Call(name, args, ln)

    def _split_interp(self, s: str, ln: int) -> list:
        """$名字（可含中文/下划线/点）切成 [(TEXT/VAR, ...)]。"""
        parts = []
        buf = []
        i = 0
        while i < len(s):
            ch = s[i]
            if ch == '$' and i + 1 < len(s) and s[i + 1] == '$':
                buf.append('$')               # $$ → 字面 $
                i += 2
                continue
            if ch == '$' and i + 1 < len(s) and s[i + 1] == '(':
                if buf:
                    parts.append(('TEXT', ''.join(buf)))
                    buf = []
                深度 = 0
                j = i + 1
                while j < len(s):
                    if s[j] == '(':
                        深度 += 1
                    elif s[j] == ')':
                        深度 -= 1
                        if 深度 == 0:
                            break
                    j += 1
                子 = _Parser(s[i + 2:j])
                parts.append(('EXPR', 子.parse_expr()))
                i = j + 1
                continue
            if ch == '$' and i + 1 < len(s) and (s[i + 1].isalnum() or s[i + 1] in '_.'):
                if buf:
                    parts.append(('TEXT', ''.join(buf)))
                    buf = []
                j = i + 1
                while j < len(s) and (s[j].isalnum() or s[j] in '_.'):
                    j += 1
                name = s[i + 1:j]
                # $名.尾缀：尾缀是纯英文短段且到字符串末尾 → 是文件扩展名不是属性
                #（"兵$帧图.png" 读帧图；"生命 $侠.血" 的 .血 是中文仍是属性）
                if '.' in name:
                    base, _, tail = name.rpartition('.')
                    if tail.isascii() and tail.isalpha() and len(tail) <= 4 and j == len(s):
                        name = base
                        j = i + 1 + len(base)
                parts.append(('VAR', name))
                i = j
            else:
                buf.append(ch)
                i += 1
        if buf:
            parts.append(('TEXT', ''.join(buf)))
        return parts

    def _切顶层逗号(self, raw: str, ln: int) -> list:
        """按引号外、括号外的顶层逗号切分 ns.show 的内容。"""
        段s = []
        buf = []
        引号 = False
        深度 = 0
        i = 0
        while i < len(raw):
            c = raw[i]
            if 引号:
                if c == 92 and i + 1 < len(raw):
                    buf.append(c)
                    buf.append(raw[i + 1])
                    i += 2
                    continue
                if c == '"':
                    引号 = False
                buf.append(c)
            elif c == '"':
                引号 = True
                buf.append(c)
            elif c in '([{':
                深度 += 1
                buf.append(c)
            elif c in ')]}':
                深度 -= 1
                buf.append(c)
            elif c == ',' and 深度 == 0:
                段s.append(''.join(buf).strip())
                buf = []
            else:
                buf.append(c)
            i += 1
        段s.append(''.join(buf).strip())
        if any(not 段 for 段 in 段s):
            self.err(f'第 {ln} 行：ns.show 参数里有空项')
        return 段s

    def _split_content(self, raw: str, ln: int) -> list:
        """裸文本切成 ('TEXT', 串) / ('VAR', 名) / ('EXPR', 节点) 交错列表。

        $ 后先尝试完整的表达式（如 $at+1、$n / 2），失败退回单标识符。"""
        parts = []
        buf = []
        i = 0
        while i < len(raw):
            c = raw[i]
            if c == '$':
                span, part = self._interp_expr(raw[i + 1:], ln)
                if buf:
                    parts.append(('TEXT', ''.join(buf)))
                    buf = []
                parts.append(part)
                i += 1 + span
            else:
                buf.append(c)
                i += 1
        if buf:
            parts.append(('TEXT', ''.join(buf)))
        return parts

    # $ 插值表达式允许出现的字符（遇白名单外字符即截断；) 永远结束整行）
    # 双引号放进白名单：$d["a"] 这类字符串下标才能在插值里求值（单引号 PYbook 不支持）
    _INTERP_CHARS = set('+-*/%<>=!. 	[]()"')

    def _interp_expr(self, text: str, ln: int):
        """把 $ 后面的文本尽量解析成表达式，返回 (消费字符数, part)。

        表达式里的后续 $ 会自动吸收：$s+$s 等价于 s + s。
        策略：截出白名单前缀 → 去掉内部 $ → 分词 → 从 1 个 token 开始
        逐个加长试解析，取"完整消化所有 token"的最长成功。"""
        cut = 0
        while cut < len(text) and (_is_id_char(text[cut])
                                   or text[cut] in self._INTERP_CHARS
                                   or text[cut] == '$'):
            cut += 1
        # 内部 $ 替换成空格（1:1 等宽替换，坐标不变；相邻 $变量 不会粘连）
        stripped_s = text[:cut].replace('$', ' ')
        body = []
        try:
            toks = list(_lex(stripped_s))
        except PybkError:
            toks = []      # 引号未闭合等：退回单标识符保底，不炸整行
        for t in toks:
            if t[0] in ('EOF', 'ERR'):
                break
            body.append(t)
        # at 是 rm.around 的内置圈数：插值表达式里当作普通变量名
        body = [('NAME', v, l, c)
                if (k2 == 'KW' and v in ('at', 'self')) else (k2, v, l, c)
                for (k2, v, l, c) in body]
        # 保底：按旧规则取最大标识符（表达式全部失败时退回它）
        j = 0
        while j < len(text) and _is_id_char(text[j]):
            j += 1
        ident = text[:j]
        if cut < len(text) and text[cut] == ',':
            raise PybkError(f"第 {ln} 行：插值表达式里不能用逗号——请先把结果存入变量，再显示变量")
        if not body:
            if ident == 'at':
                return j, ('VAR', 'at')
            if ident and ident not in KEYWORDS:
                return j, ('VAR', ident)
            raise PybkError(f"第 {ln} 行：插值里不能直接使用 {ident!r}"
                            f"（规则：先 vg.名 = {ident}，再 \"$名\"；"
                            f"或直接写 $(表达式)，如 \"$(长度(表))\"）")
        best_k, best_node = 0, None
        for k in range(1, len(body) + 1):
            p = _Parser.__new__(_Parser)
            p.src = ''
            p.toks = body[:k] + [('EOF', '', ln, 10 ** 6)]
            p.i = 0
            try:
                node = p.parse_expr()
            except PybkError:
                continue
            if p.i >= k:
                best_k, best_node = k, node
        if best_k == 0:
            if ident and ident not in KEYWORDS:
                return j, ('VAR', ident)
            raise PybkError(f"第 {ln} 行：$ 后的表达式无法解析：{stripped_s!r}")
        last = body[best_k - 1]
        span = last[3] + len(str(last[1]))   # 等宽替换，坐标即原坐标
        node = self._reline(best_node, ln)
        had_inner_dollar = '$' in text[:span]
        if best_k == 1 and body[0][0] == 'NAME' and not had_inner_dollar:
            return span, ('VAR', body[0][1])
        return span, ('EXPR', node)

    @staticmethod
    def _reline(node, ln):
        """把解析出的表达式节点（含嵌套）的行号统一改成正确的行号。"""
        import dataclasses as _dc
        def fix(n):
            if n is None or isinstance(n, (str, int, float, bool)):
                return n
            if _dc.is_dataclass(n) and hasattr(n, 'line'):
                n.line = ln
                for f in n.__dataclass_fields__:
                    v = getattr(n, f)
                    if isinstance(v, list):
                        for x in v:
                            fix(x)
                    else:
                        fix(v)
        fix(node)
        return node

    def _split_magic(self, raw: str, ln: int) -> list:
        """magic 项按逗号切分，但 c=255,0,0 这类颜色值自带逗号：
        含 = 的段后面必须紧跟两段数字，三段合并回一个项。"""
        pieces = [s.strip() for s in raw.split(',')]
        items = []
        i = 0
        while i < len(pieces):
            p = pieces[i]
            if '=' in p:
                if i + 2 >= len(pieces):
                    raise PybkError(f"第 {ln} 行：magic 项 {p!r} 缺少完整的 r,g,b 三段")
                p = f"{p},{pieces[i + 1].strip()},{pieces[i + 2].strip()}"
                i += 3
            else:
                i += 1
            if not p:
                raise PybkError(f"第 {ln} 行：magic 项不能为空")
            items.append(p)
        return items

    def parse_rm(self):
        ln = self.expect('KW', 'rm')[2]
        self.expect('OP', '.')
        _k, v2, _l2, _p2 = self.advance()
        if v2 == 'around':
            self.expect('OP', '(')
            times = self.parse_expr()
            self.expect('OP', ')')
            var = 'at'
            if self.at('OP', '-') and self.toks[self.i + 1][:2] == ('OP', '>'):
                self.advance()                 # -
                self.advance()                 # >
                var = self.expect('NAME')[1]   # 自定义计数器名
            self.loop_depth += 1
            body, _ = self._block()
            self.loop_depth -= 1
            return Around(times, body, ln, var)
        if v2 == 'aging':
            self.expect('OP', '.')
            self.expect('KW', 'while')
            self.expect('OP', '(')
            cond = self.parse_expr()
            self.expect('OP', ')')
            self.loop_depth += 1
            body, _ = self._block()
            self.loop_depth -= 1
            return Aging(cond, body, ln)
        self.err(f"rm. 后只能是 around 或 aging，实际是 {v2!r}")

    def parse_break(self, ln):
        """break/断：跳出当前层循环。后面不跟任何内容；
        不在任何循环里 → 立即报错（err 自带当前行号）。"""
        if self.loop_depth == 0:
            self.err("break 只能在循环内使用")
        self.advance()
        return BreakStmt(ln)

    def parse_when(self):
        ln = self.expect('KW', 'when')[2]
        body, _ = self._block()
        self.expect('KW', 'if')
        self.expect('OP', '(')
        k, v, _l, _p = self.cur()
        if k != 'NUM' or not v.isdigit():
            self.err("when 的 if(...) 里必须是整数")
        self.advance()
        self.expect('OP', ')')
        return CdBlock(int(v), body, ln)

    def parse_branch(self):
        ln = self.expect('KW', 'if')[2]
        self.expect('OP', '(')
        cond = self.parse_expr()
        self.expect('OP', ')')
        body, _ = self._block()
        arms = [(cond, body)]
        while self.at('KW', 'elif'):
            self.advance()
            self.expect('OP', '(')
            c = self.parse_expr()
            self.expect('OP', ')')
            b, _ = self._block()
            arms.append((c, b))
        if self.at('KW', 'else'):
            self.advance()
            b, _ = self._block()
            arms.append((None, b))
        return VcChain(arms, ln)

    def parse_trycatch(self):
        """try {...} catch e {...} / try {...} catch {...}"""
        ln = self.expect('KW', 'try')[2]
        body, _ = self._block()
        self.expect('KW', 'catch')
        var = None
        if self.at('NAME'):
            var = self.expect('NAME')[1]
        handler, _ = self._block()
        return TryCatch(body, var, handler, ln)

    def parse_onerror(self):
        """onerror err {...}：本文件的兜底 catch（放 GOING 顶层，包裹其后全部语句）"""
        ln = self.expect('KW', 'onerror')[2]
        var = None
        if self.at('NAME'):
            var = self.expect('NAME')[1]
        handler, _ = self._block()
        return OnError([], var, handler, ln)

    def parse_forin(self):
        """for x in 列表 { ... }：逐个取元素，元素叫 x（列表可装对象）。"""
        ln = self.expect('KW', 'for')[2]
        _k, name, _l, _p = self.expect('NAME')
        vg2 = None
        if self.at('OP', ','):                # for 键, 值 in 字典 {...}
            self.advance()
            vg2 = self.expect('NAME')[1]
        self.expect('KW', 'in')
        it = self.parse_expr()
        self.loop_depth += 1                 # break 允许在 for-in 里用
        body, _ = self._block()
        self.loop_depth -= 1
        return ForIn(name, it, body, ln, vg2)

    def parse_ret(self):
        ln = self.expect('KW', 'ret')[2]
        k, v, nl, _p = self.cur()
        bare = (k == 'EOF' or nl != ln
                or (k == 'OP' and v == '}')
                or (k == 'KW' and v == 'STOP'))
        if bare:
            return Ret(None, ln)
        return Ret(self.parse_expr(), ln)

    # ---- 表达式（优先级低到高：or → and → 比较 → + - → * / % // → 一元）----

    def parse_expr(self):
        return self._ternary()

    def _ternary(self):
        c = self._or()
        if self.at('OP', '?'):
            ln = self.advance()[2]
            a = self.parse_expr()
            self.expect('OP', ':')
            b = self._ternary()
            return Ternary(c, a, b, ln)
        return c

    def _or(self):
        l = self._and()
        while self.at('KW', 'or'):
            ln = self.advance()[2]
            l = BinOp('or', l, self._and(), ln)
        return l

    def _and(self):
        l = self._cmp()
        while self.at('KW', 'and'):
            ln = self.advance()[2]
            l = BinOp('and', l, self._cmp(), ln)
        return l

    def _cmp(self):
        l = self._add()
        while True:
            if self.kind() == 'OP' and self.val() in CMP_OPS:
                ln = self.advance()[2]
                l = BinOp(self.toks[self.i - 1][1], l, self._add(), ln)
            elif self.at('KW', 'in'):
                ln = self.advance()[2]
                l = BinOp('in', l, self._add(), ln)
            elif self.at('KW', 'not') and self.toks[self.i + 1][:2] == ('KW', 'in'):
                ln = self.advance()[2]
                self.advance()
                l = BinOp('not_in', l, self._add(), ln)
            else:
                return l

    def _add(self):
        l = self._mul()
        while self.kind() == 'OP' and self.val() in ('+', '-'):
            ln = self.advance()[2]
            l = BinOp(self.toks[self.i - 1][1], l, self._mul(), ln)
        return l

    def _mul(self):
        l = self._unary()
        while self.kind() == 'OP' and self.val() in ('*', '/', '%', '//'):
            ln = self.advance()[2]
            l = BinOp(self.toks[self.i - 1][1], l, self._unary(), ln)
        return l

    def _unary(self):
        if self.at('OP', '-'):
            ln = self.advance()[2]
            return Unary('-', self._unary(), ln)
        if self.at('KW', 'not'):
            ln = self.advance()[2]
            return Unary('not', self._unary(), ln)
        return self._primary()

    def _多目标(self, name, ln):
        """多重赋值的单个目标：名字 或 名字[下标]。"""
        if self.at('OP', '['):
            self.advance()
            idx = self.parse_expr()
            self.expect('OP', ']')
            return Index(VarRef(name, ln), idx, ln)
        return name

    def _suffixes(self, e, ln):
        """表达式后缀循环：[下标]、.属性、.方法(实参) 可任意叠加（天然支持链式）。"""
        while True:
            if self.at('OP', '['):
                self.advance()
                start = None
                if not self.at('OP', ':'):
                    start = self.parse_expr()
                if not self.at('OP', ':'):        # 普通下标
                    self.expect('OP', ']')
                    e = Index(e, start, ln)
                    continue
                self.advance()                     # 第一个冒号 → 切片 [a:b:c]
                stop = None
                if not self.at('OP', ':') and not self.at('OP', ']'):
                    stop = self.parse_expr()
                step = None
                if self.at('OP', ':'):
                    self.advance()
                    if not self.at('OP', ']'):
                        step = self.parse_expr()
                self.expect('OP', ']')
                e = Slice(e, start, stop, step, ln)
            elif self.at('OP', '.'):
                self.advance()
                _k2, v2, l2, _p2 = self.cur()
                if _k2 == 'KW' and v2 == 'at':
                    self.advance()             # .at 是方法名，虽然 at 是关键字
                else:
                    _k2, v2, l2, _p2 = self.expect('NAME')
                e = Member(e, v2, l2)
                if self.at('OP', '('):        # 方法调用后缀
                    self.advance()
                    args = []
                    if not self.at('OP', ')'):
                        args.append(self.parse_expr())
                        while self.at('OP', ','):
                            self.advance()
                            args.append(self.parse_expr())
                    self.expect('OP', ')')
                    if isinstance(e.base, VarRef) and e.base.name == 'dict':
                        e = Call('dict.' + e.attr, args, l2)   # dict.keys/values → 库调用
                    elif e.attr in ('get', 'at') and len(args) in (1, 2)                             and (isinstance(e.base, VarRef)
                                 or isinstance(e.base, (ListLit, DictLit, Slice, Index))):
                        # 安全访问器：x.at(i, 缺省) / x.get(键, 缺省) → 库调用
                        # 对象变量/字面量/切片/下标结果都可用（MethodCall 走类方法路径）
                        e = Call('safe.' + e.attr, [e.base] + args, l2)
                    else:
                        e = MethodCall(e.base, e.attr, args, l2)
            else:
                return e

    def _primary(self):
        k, v, ln, _p = self.cur()
        if k in ('NAME', 'KW') and v in GAME_CALLS \
                and self.toks[self.i + 1][:2] == ('OP', '('):
            self.advance()                     # key/win/clear/color/box/show/wait/end(...)
            return self._game_call(v, ln)
        if k == 'KW' and v == 'web':
            # 表达式位置：web.click() / web.mx() / web.my() / web.text("id") / web.down("id")
            self.advance()
            self.expect('OP', '.')
            _wk, wv, _wl, _wp = self.advance()
            if wv in ('click', 'mx', 'my'):
                self.expect('OP', '(')
                self.expect('OP', ')')
                return Call('web.' + wv, [], ln)
            if wv in ('text', 'down'):
                self.expect('OP', '(')
                argw = self.parse_expr()
                self.expect('OP', ')')
                return Call('web.' + wv, [argw], ln)
            if wv == '存':
                self.expect('OP', '(')
                kw = self.parse_expr()
                self.expect('OP', ',')
                dv = self.parse_expr()
                self.expect('OP', ')')
                return Call('web.存', [kw, dv], ln)
            self.err(f'web.{wv} 不能用在表达式里')
        if k == 'KW' and v in ('调色板', 'palette') \
                and self.toks[self.i + 1][:2] == ('OP', '.') \
                and self.toks[self.i + 2][0] == 'NAME':
            # 调色板.颜色名：零参 LIB 调用，返回新建的 [r,g,b] 列表
            # （不带括号也能用——色表是常量，直接当列表值）
            self.advance()
            self.expect('OP', '.')
            cname = self.expect('NAME')[1]
            if v == 'palette':
                cname = {'red': '红', 'orange': '橙', 'yellow': '黄', 'green': '绿',
                         'cyan': '青', 'blue': '蓝', 'purple': '紫', 'white': '白',
                         'black': '黑', 'gray': '灰', 'pink': '粉', 'gold': '金'
                         }.get(cname, cname)
            full = '调色板.' + cname
            if full not in LIB_CALLS:
                self.err(f"调色板 里没有颜色 {cname!r}")
            return Call(full, [], ln)
        if k == 'KW' and v == 'list' \
                and self.toks[self.i + 1][:2] == ('OP', '.') \
                and self.toks[self.i + 2][0] == 'NAME' \
                and self.toks[self.i + 3][:2] == ('OP', '('):
            return self.parse_list_call(ln)
        if k == 'KW' and v in LIB_PREFIXES and v != 'list' \
                and self.toks[self.i + 1][:2] == ('OP', '.') \
                and self.toks[self.i + 2][0] in ('NAME', 'KW') \
                and self.toks[self.i + 3][:2] == ('OP', '('):
            if v == 'mu':                      # mu.sine → 音.正弦（前端翻译）
                v = '音'
            return self._lib_call(v, ln)       # te.split(...) / file.read(...) 等
        if k == 'NUM':
            self.advance()
            return NumLit(float(v) if '.' in v else int(v), ln)
        if k == 'STR':
            self.advance()
            if '$' in v:                       # 含 $ 的字符串 = 插值串（赋值时求值）
                return StrParts(self._split_interp(v, ln), ln)
            return StrLit(v, ln)
        if k == 'NAME' and v in ('frame', 'sec')                 and self.toks[self.i + 1][:2] not in (('OP', '.'), ('OP', '='), ('OP', '(')):
            return Call(v, [], ln)             # frame / sec：内置帧数/秒数
        if k == 'KW' and v == 'at':            # rm.around 的循环计数器
            self.advance()
            return VarRef('at', ln)
        if k == 'KW' and v == 'self':          # self：方法内的当前实例
            self.advance()
            return self._suffixes(VarRef('self', ln), ln)
        if k == 'KW' and v == 'lb':            # lb.类名(属性=值, ...) 构造实例
            ln2 = self.advance()[2]
            self.expect('OP', '.')
            cname = self.expect('NAME')[1]
            self.expect('OP', '(')
            kwargs = []
            if not self.at('OP', ')'):
                while True:
                    kwn = self.expect('NAME')[1]
                    self.expect('OP', '=')
                    kwargs.append((kwn, self.parse_expr()))
                    if not self.at('OP', ','):
                        break
                    self.advance()
            self.expect('OP', ')')
            node = CtorExpr(cname, kwargs, ln2)
            pend = getattr(self, '_pending_ctors', None)   # 插值子解析器没有该属性
            if pend is not None:
                pend.append(node)
            return node
        if k == 'KW' and v in ('true', '真'):
            self.advance()
            return BoolLit(True, ln)
        if k == 'KW' and v in ('空', 'none'):
            self.advance()
            return Call('空', [], ln)
        if k == 'KW' and v == '假':
            self.advance()
            return BoolLit(False, ln)
        if k == 'KW' and v == 'false':
            self.advance()
            return BoolLit(False, ln)
        if k == 'KW' and v == 'input':
            self.advance()
            self.expect('OP', '(')
            prompt = self.expect('STR')[1]
            self.expect('OP', ')')
            return InputExpr(prompt, ln)
        if k == 'OP' and v == '{':            # 字典字面量 {"键": 值, ...}（允许尾逗号）
            self.advance()
            pairs = []
            while not self.at('OP', '}'):
                kk = self.parse_expr()
                self.expect('OP', ':')
                vv = self.parse_expr()
                pairs.append((kk, vv))
                if self.at('KW', 'for'):      # 字典推导 {k: v for k, v in 源 if 条件}
                    self.advance()
                    变 = [self.expect('NAME')[1]]
                    if self.at('OP', ','):
                        self.advance()
                        变.append(self.expect('NAME')[1])
                    self.expect('KW', 'in')
                    it = self.parse_expr()
                    cond = None
                    if self.at('KW', 'if'):
                        self.advance()
                        cond = self.parse_expr()
                    self.expect('OP', '}')
                    return DictComp(kk, vv, 变, it, cond, ln)
                if not self.at('OP', ','):
                    break
                self.advance()
            self.expect('OP', '}')
            return self._suffixes(DictLit(pairs, ln), ln)
        if k == 'OP' and v == '[':            # 列表字面量 / 推导式（允许尾逗号 [1, 2,]）
            self.advance()
            if self.at('OP', ']'):
                self.advance()
                return ListLit([], ln)
            first = self.parse_expr()
            if self.at('KW', 'for'):          # [表达式 for x in 列表 if 条件]
                self.advance()
                var = self.expect('NAME')[1]
                self.expect('KW', 'in')
                it = self.parse_expr()
                cond = None
                if self.at('KW', 'if'):
                    self.advance()
                    cond = self.parse_expr()
                self.expect('OP', ']')
                return Comp(first, var, it, cond, ln)
            items = [first]
            while self.at('OP', ','):
                self.advance()
                if self.at('OP', ']'):
                    break
                items.append(self.parse_expr())
            self.expect('OP', ']')
            return self._suffixes(ListLit(items, ln), ln)
        if k == 'NAME':
            self.advance()
            e = self._suffixes(VarRef(v, ln), ln)
            if self.at('OP', '('):      # 裸函数调用：名(实参)——模块函数/普通函数
                self.advance()
                args = []
                if not self.at('OP', ')'):
                    args.append(self.parse_expr())
                    while self.at('OP', ','):
                        self.advance()
                        args.append(self.parse_expr())
                self.expect('OP', ')')
                e = Call(v, args, ln)
            return e
        if k == 'OP' and v == '(':
            self.advance()
            e = self.parse_expr()
            self.expect('OP', ')')
            return e
        if k == 'ERR':
            raise PybkError(f"第 {ln} 行：非法字符 {v!r}")
        self.err(f"不是合法的表达式：{v if v else k!r}")

    def _lib_call(self, prefix: str, ln: int) -> Call:
        """标准库模块调用：te.split(文本, 分隔符) → Call('te.split', [...])。

        名字 = 前缀.函数（见 LIB_CALLS），参数个数在解析期校验；
        后端按全名映射到 rt_lib_* / rt_list_* / rt_file_*。"""
        if prefix == 'hw' and not getattr(self, '_hw_on', False):
            raise PybkError(f"第 {ln} 行：hw 模块需要先在文件顶部写 ON 3D_highway")
        self.advance()                      # 前缀关键字
        self.expect('OP', '.')
        nt = self.cur()
        if nt[0] not in ('NAME', 'KW'):   # 允许关键字做函数名（file.del 等）
            self.err(f'标准库 {prefix} 的函数名不合法')
        name = nt[1]
        self.advance()
        if prefix == '音' and name in ('sine', 'tri', 'play', 'stop'):
            name = {'sine': '正弦', 'tri': '三角', 'play': '放', 'stop': '停'}[name]
        full = prefix + '.' + name
        if full not in LIB_CALLS:
            raise PybkError(f"第 {ln} 行：标准库 {prefix} 没有函数 {name!r}")
        self.expect('OP', '(')
        args = []
        if not self.at('OP', ')'):
            args.append(self.parse_expr())
            while self.at('OP', ','):
                self.advance()
                args.append(self.parse_expr())
        self.expect('OP', ')')
        if full == 'hw.text' and len(args) == 4 and isinstance(args[3], StrLit) and '$' in args[3].value:
            args = list(args)
            args[3] = StrParts(self._split_interp(args[3].value, ln), ln)
        want = LIB_CALLS[full]
        if full == 'tm.stop':
            if len(args) not in (1, 2):
                raise PybkError(f"第 {ln} 行：tm.stop 的写法：tm.stop(秒) 或 tm.stop(数值, \"s\"/\"ms\")")
        elif full == 'hw.camera' and len(args) == 4:
            args.append(NumLit(0, ln))   # 旧写法 camera(x,y,z,朝) → 俯仰 0
        elif full == 'hw.box' and len(args) == 12:
            pass                          # box(x,y,z,w,h,d,r,g,b, 绕x,绕y,绕z)：带旋转
        elif full == 'hw.cyl' and len(args) == 10:
            pass                          # cyl(x,y,z,下半径,高,上半径, 边数, r,g,b)：自定义边数
        elif full == 'hw.uni' and 2 <= len(args) <= 5:
            pass                          # uni("名字", a[, b[, c[, d]]])：1~4 个分量
        elif len(args) != want:
            raise PybkError(f"第 {ln} 行：{full} 需要 {want} 个参数，实际 {len(args)} 个")
        if full == 'hw.text' and isinstance(args[3], StrParts):
            pass   # $ 插值已在参数解析时转为 StrParts
        return Call(full, args, ln)

    def parse_list_call(self, ln: int) -> Call:
        """list. 前缀调用：内置列表操作(添加/长度) / 标准库(list.sort 等) / 用户函数。

        list.添加(列表, 值) / list.长度(x) → Call('添加'/'长度')（后端特判）；
        list.sort(...) 等 → Call('list.sort')（走标准库）；
        其余 list.名字(...) → Call('名字')（用户函数调用）。"""
        self.advance()                      # list 关键字
        self.expect('OP', '.')
        name = self.expect('NAME')[1]
        full = 'list.' + name
        if full in LIB_CALLS:
            self.expect('OP', '(')
            args = []
            if not self.at('OP', ')'):
                args.append(self.parse_expr())
                while self.at('OP', ','):
                    self.advance()
                    args.append(self.parse_expr())
            self.expect('OP', ')')
            if len(args) != LIB_CALLS[full]:
                raise PybkError(f"第 {ln} 行：{full} 需要 {LIB_CALLS[full]} 个参数，实际 {len(args)} 个")
            return Call(full, args, ln)
        self.expect('OP', '(')
        args = []
        if not self.at('OP', ')'):
            args.append(self.parse_expr())
            while self.at('OP', ','):
                self.advance()
                args.append(self.parse_expr())
        self.expect('OP', ')')
        return Call(name, args, ln)


def parse(src: str) -> Program:
    return _Parser(src).parse_program()


# ---------------------------------------------------------------- 自测


def parse_module(src: str) -> Program:
    """解析被引用的模块单元：GOING 可有可无（有也被编译器忽略），
    顶层允许 vg 变量声明。Program.imports 记录它自己的 引用(...)。"""
    return _Parser(src).parse_program(require_going=False)


def _show(n, ind=0):
    pad = '  ' * ind
    if n is None or isinstance(n, (int, float, str, bool)):
        print(pad + repr(n))
        return
    if isinstance(n, list):
        for x in n:
            _show(x, ind)
        return
    if isinstance(n, tuple):
        if len(n) == 2 and n[0] in ('TEXT', 'VAR'):
            print(pad + repr(n))
            return
        cond, body = n
        print(pad + ('分支 else:' if cond is None else '分支:'))
        if cond is not None:
            _show(cond, ind + 1)
        _show(body, ind + 1)
        return
    if dataclasses.is_dataclass(n):
        head = [type(n).__name__]
        subs = []
        for f in dataclasses.fields(n):
            v = getattr(n, f.name)
            if isinstance(v, (list, tuple)) or dataclasses.is_dataclass(v):
                subs.append((f.name, v))
            else:
                head.append(f"{f.name}={v!r}")
        print(pad + ' '.join(head))
        for name, v in subs:
            print(pad + '  ' + name + ':')
            _show(v, ind + 2)


if __name__ == '__main__':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass

    SAMPLE = '''@ 我的>第一个>程序
# 注释一行
func 加倍(n) {
    ret n * 2
}
GOING:{
vg.名字 = "世界"
vg.次数 = 3
ns.show(你好 $名字！)/magic(b, c=0,200,255)
rm.around(次数) {
    ns.show(第 $at 圈)
}
if (次数 >= 3) {
    ns.show(次数不少)
}
else {
    ns.show(次数太少)
}
vg.结果 = list.加倍(21)
ns.show(结果=$结果)
}STOP
'''

    toks = tokenize(SAMPLE)
    print(f"样例共切成 {len(toks)} 个 Token（含 EOF），行号范围 1..{toks[-1].line}")
    prog = parse(SAMPLE)
    _show(prog)

    # ---- 结构断言 ----
    assert prog.meta == '我的>第一个>程序'
    assert len(prog.fns) == 1
    fv = prog.fns[0]
    assert (fv.name, fv.params) == ('加倍', ['n'])
    assert fv.body[0].expr == BinOp('*', VarRef('n', 4), NumLit(2, 4), 4)

    g = prog.go_body
    assert isinstance(g[0], VgAssign) and g[0].name == '名字'
    ns1 = g[2]
    assert ns1.parts == [('TEXT', '你好 '), ('VAR', '名字'), ('TEXT', '！')]
    assert ns1.magic == ['b', 'c=0,200,255']
    around = g[3]
    assert around.body[0].parts == [('TEXT', '第 '), ('VAR', 'at'), ('TEXT', ' 圈')]
    vc = g[4]
    assert isinstance(vc, VcChain) and len(vc.arms) == 2
    assert vc.arms[0][0] == BinOp('>=', VarRef('次数', 13), NumLit(3, 13), 13)
    assert vc.arms[1][0] is None
    call = g[5].expr
    assert call == Call('加倍', [NumLit(21, 19)], 19)
    assert g[6].parts == [('TEXT', '结果='), ('VAR', '结果')]
    assert toks[-1].kind == 'EOF'

    # ---- 附加用例：when 块、ip 输入赋值、if/elif/else 三段链、裸 ret、// 运算 ----
    EXTRA = '''@ 附加>测试>用例
func 啥也不干() {
    ret
}
GOING: {
vg(ip).名字 = input("你叫什么名字？")
when {
    ns.show(走这条路)
} if (2)
if (1 == 1) {
    ns.show(一)
}
elif (2 <= 1) {
    ns.show(二)
}
else {
    ns.show(其他)
}
vg.商 = list.整除(7, 2)
}STOP
'''
    ex = parse(EXTRA)
    assert ex.go_body[0] == IpAssign('名字', '你叫什么名字？', 6)
    cd = ex.go_body[1]
    assert isinstance(cd, CdBlock) and cd.priority == 2 and cd.body[0].parts == [('TEXT', '走这条路')]
    vc2 = ex.go_body[2]
    assert [c is None for c, _b in vc2.arms] == [False, False, True]
    assert isinstance(ex.fns[0].body[0], Ret) and ex.fns[0].body[0].expr is None
    assert ex.go_body[3].expr.args == [NumLit(7, 19), NumLit(2, 19)]

    # ---- 错误处理：非法字符和语法错误都要带行号 ----
    for bad in ('@ a>b>c\nGOING:{\nvg.x = ？\n}STOP\n',
                '@ a>b>c\nGOING:{\nfv\n',
                '@ a>b>c\nGOING:{ } STOPX\n'):
        try:
            parse(bad)
        except PybkError as e:
            assert '第 ' in str(e)
        else:
            raise AssertionError(f"应当报错却没有：{bad!r}")

    # ---- hm 网页输出分支 ----
    HM = '''@ 测>网页>分支
GOING:{
web.big(欢迎来到 $名字 的主页)
web.mid(第二章)
web.show(你好 $名字！得分 $分数 / 2)/magic(b, c=0,200,255)
web.show(普通段落没有 magic)
web.img("风景.png")
web.line
web.link("访问教程", "https://pybook.example.com")
}STOP
'''
    hm_prog = parse(HM)
    g = hm_prog.go_body
    assert [s.kind for s in g] == ['big', 'mid', 'show', 'show', 'img', 'line', 'link']
    assert g[0].parts == [('TEXT', '欢迎来到 '), ('VAR', '名字'), ('TEXT', ' 的主页')]
    assert g[0].arg == '' and g[0].magic == []
    assert g[2].parts == [('TEXT', '你好 '), ('VAR', '名字'), ('TEXT', '！得分 '),
                          ('EXPR', BinOp('/', VarRef('分数', 5), NumLit(2, 5), 5))]
    assert g[2].magic == ['b', 'c=0,200,255']
    assert g[3].magic == []                          # /magic 可省
    assert g[4].parts == [] and g[4].arg == '风景.png' and g[4].magic == []
    assert g[5].kind == 'line' and g[5].parts == [] and g[5].arg == '' and g[5].magic == []
    assert g[6].parts == [('TEXT', '访问教程')] and g[6].arg == 'https://pybook.example.com'
    assert g[6].magic == []

    # hm 错误路径：缺右括号 / / 后接非 magic / link 只给一个参数，均带行号
    for bad in ('@ a>b>c\nGOING:{\nweb.big(没有右括号\n',
                '@ a>b>c\nGOING:{\nweb.show(段落)/bold\n',
                '@ a>b>c\nGOING:{\nweb.link("只有文字")\n',
                '@ a>b>c\nGOING:{\nweb.mid(标题)/magic(b)\n'):
        try:
            parse(bad)
        except PybkError as e:
            assert '第 ' in str(e), str(e)
        else:
            raise AssertionError(f"应当报错却没有：{bad!r}")

    # ---- web.块（页面组件）：定义/使用/嵌套调用/错误路径 ----
    BLK = '''@ 测>组件>解析
web.块 卡片(标题, 内容) {
    web.mid($标题)
    web.show($标题：$内容)
    web.line
}
web.块 货架(名称) {
    web.卡片(名称, "欢迎选购")
}
GOING:{
    vg.x = 1
    web.卡片("水果", "苹果")
    web.货架("西瓜")
}STOP
'''
    bp = parse(BLK)
    assert list(bp.hm_blocks) == ['卡片', '货架']
    assert bp.hm_blocks['卡片'].params == ['标题', '内容']
    assert len(bp.hm_blocks['卡片'].body) == 3
    u0 = bp.go_body[1]
    assert isinstance(u0, HmUse) and u0.name == '卡片' and len(u0.args) == 2
    assert isinstance(bp.go_body[2], HmUse) and bp.go_body[2].name == '货架'
    inner = bp.hm_blocks['货架'].body[0]
    assert isinstance(inner, HmUse) and inner.name == '卡片' and len(inner.args) == 2

    for bad, frag in (
            ('@ a>b>c\nGOING:{\nvg.x = 1\nweb.卡片("x")\n}STOP\n', '或已定义的组件名'),
            ('@ a>b>c\nweb.块 卡(标题) {\n    web.mid(标题)\n}\nGOING:{\nvg.x = 1\nweb.卡("x", "y")\n}STOP\n',
             '需要 1 个参数'),
            ('@ a>b>c\nweb.块 卡(标题) {\n    web.mid(标题)\n    web.块 内(a) {\n        web.mid(a)\n    }\n}\n'
             'GOING:{\nvg.x = 1\n}STOP\n', '只能定义在文件顶层'),
            ('@ a>b>c\nweb.块 卡(标题) {\n    web.帧 { web.draw.色(1,2,3) }\n}\nGOING:{\nvg.x = 1\n}STOP\n',
             '帧/播放/实时'),
            ('@ a>b>c\nweb.块 卡(标题) {\n    web.draw.色(1,2,3)\n}\nGOING:{\nvg.x = 1\n}STOP\n',
             'draw/页')):
        try:
            parse(bad)
        except PybkError as e:
            assert '第 ' in str(e) and frag in str(e), (bad, str(e))
        else:
            raise AssertionError(f'应当报错却没有：{bad!r}')

    # ---- web.页（子页面）与 web.draw.始(宽,高) ----
    PG = '''@ 测>多页>解析
GOING:{
    web.big(主页内容)
    web.页("特惠") {
        web.big(今日特惠)
        web.link("回主页", "pybook_page.html")
    }
    web.draw.始(800, 200)
    web.帧 { web.draw.色(1,2,3) }
    web.播放(5)
    web.draw.终
}STOP
'''
    pg = parse(PG)
    page_i = [k for k, s in enumerate(pg.go_body) if isinstance(s, HmPageStmt)]
    assert len(page_i) == 1
    pgs = pg.go_body[page_i[0]]
    assert pgs.name == '特惠' and len(pgs.body) == 2
    dn = [s for s in pg.go_body if isinstance(s, HmDraw) and s.cmd == 'begin']
    assert len(dn) == 1 and [q.value for q in dn[0].params] == [800, 200]

    for bad, frag in (
            ('@ a>b>c\nGOING:{\nvg.x = 1\nweb.页("a") {\nweb.页("b") {\nweb.mid(嵌套)\n}\n}\n}STOP\n',
             '嵌套页'),
            ('@ a>b>c\nweb.块 卡(a) {\n    web.页("b") {\n        web.mid(a)\n    }\n}\n'
             'GOING:{\nvg.x = 1\n}STOP\n', '页'),
            ('@ a>b>c\nGOING:{\nvg.x = 1\nweb.页("a/b") {\nweb.mid(x)\n}\n}STOP\n', '不能含'),
            ('@ a>b>c\nGOING:{\nvg.x = 1\nweb.draw.始(800)\nweb.draw.终\n}STOP\n', "期望 ','"),
            ('@ a>b>c\nGOING:{\nvg.x = 1\nweb.draw.始(10000, 200)\nweb.draw.终\n}STOP\n', '超范围'),
            ('@ a>b>c\nGOING:{\nvg.x = 1\nweb.draw.始(80.5, 200)\nweb.draw.终\n}STOP\n', '正整数')):
        try:
            parse(bad)
        except PybkError as e:
            assert '第 ' in str(e) and frag in str(e), (bad, str(e))
        else:
            raise AssertionError(f'应当报错却没有：{bad!r}')

    # ---- lb 类（OOP）分支 ----
    CLS = '''@ 游戏>类>试炼
lb.狗 {
    vg.名字
    vg.血量 = 100
    func 叫() {
        ns.show($self.名字：汪汪汪！)/magic(b)
    }
    func 受伤(点数) {
        self.血量 = self.血量 - 点数
    }
}
GOING:{
vg.旺财 = lb.狗(名字="旺财", 血量=100)
旺财.叫()
旺财.受伤(30)
vg_ro.队伍 = [旺财]
ns.show($队伍[0].名字 报到)
}STOP
'''
    cp = parse(CLS)
    assert len(cp.classes) == 1
    dog = cp.classes[0]
    assert dog.name == '狗' and dog.line == 2
    assert [(n, d) for n, d in dog.props] == [('名字', None), ('血量', NumLit(100, 4))]
    assert [m.name for m in dog.methods] == ['叫', '受伤']
    jiao = dog.methods[0]
    assert jiao.params == [] and jiao.body[0].magic == ['b']
    assert jiao.body[0].parts == [('EXPR', Member(VarRef('self', 6), '名字', 6)),
                                  ('TEXT', '：汪汪汪！')]
    shang = dog.methods[1]
    assert shang.params == ['点数']
    assert shang.body[0] == AssignMember(VarRef('self', 9), '血量',
                                         BinOp('-',
                                               Member(VarRef('self', 9), '血量', 9),
                                               VarRef('点数', 9), 9), 9)
    gg = cp.go_body
    assert gg[0] == VgAssign('旺财', CtorExpr('狗', [('名字', StrLit('旺财', 13)),
                                                     ('血量', NumLit(100, 13))], 13), 13)
    assert gg[1] == MethodCall(VarRef('旺财', 14), '叫', [], 14)
    assert gg[2] == MethodCall(VarRef('旺财', 15), '受伤', [NumLit(30, 15)], 15)
    assert gg[3] == VgAssign('队伍', ListLit([VarRef('旺财', 16)], 16), 16)
    assert gg[4].parts == [('EXPR', Member(Index(VarRef('队伍', 17), NumLit(0, 17), 17),
                                           '名字', 17)),
                           ('TEXT', ' 报到')]

    # ---- 短vc：ns.show(主)vc:条件?(替代) ----
    SV = '''@ 测>短vc>解析
GOING:{
vg.分数 = 75
ns.show(及格)/magic(b, c=0,200,0)vc:分数 >= 60?(不及格 $分数 分)
ns.show(无后缀)
}STOP
'''
    sv = parse(SV).go_body
    assert sv[1].vc_cond == BinOp('>=', VarRef('分数', 4), NumLit(60, 4), 4)
    assert sv[1].vc_alt == [('TEXT', '不及格 '), ('VAR', '分数'), ('TEXT', ' 分')]
    assert sv[1].magic == ['b', 'c=0,200,0']
    assert sv[2].vc_cond is None and sv[2].vc_alt == []

    # ---- 模块系统：引用("名") 与 parse_module ----
    MAIN_M = '''@ 主>模块>测试
引用("工具箱")
引用("数学库")
func 广播() {
    ns.show(广播)
}
GOING:{
ns.show($版本)
}STOP
'''
    mp = parse(MAIN_M)
    assert mp.imports == [("工具箱", 2), ("数学库", 3)], mp.imports
    MOD_M = '''@ 工具箱>数学>v1
vg.版本 = 1
func 加(a, b) { ret a + b }
func double(n) { ret n * 2 }
GOING:{
ns.show(模块自己的GOING会被忽略)
}STOP
'''
    mod = parse_module(MOD_M)
    assert mod.imports == []
    assert [(f.name, f.params) for f in mod.fns] == [('加', ['a', 'b']), ('double', ['n'])]
    assert len(mod.go_body) == 1 and isinstance(mod.go_body[0], VgAssign)
    try:
        parse('@ a>b>c\nGOING:{\n}\n引用("晚了")\nSTOP\n')
    except PybkError as e:
        assert '第 ' in str(e)
    else:
        raise AssertionError("GOING 之后的引用应当报错")


    # 类错误路径：未知属性名 / 未定义的类 / 重复定义，均带行号
    for bad, frag in (
            ('@ a>b>c\nlb.狗 { vg.名字 }\nGOING:{\nvg.d = lb.狗(毛色=1)\n}STOP\n', '毛色'),
            ('@ a>b>c\nGOING:{\nvg.d = lb.猫()\n}STOP\n', '猫'),
            ('@ a>b>c\nlb.狗 { vg.名字 }\nlb.狗 { vg.年龄 }\nGOING:{\n}STOP\n', '重复')):
        try:
            parse(bad)
        except PybkError as e:
            assert '第 ' in str(e) and frag in str(e), (bad, str(e))
        else:
            raise AssertionError(f"应当报错却没有：{bad!r}")

    # ---- 帧动画 / go 移动 ----
    AN = '''@ 动画>解析>测试
GOING:{
web.draw.始
web.帧 {
    web.draw.色(255, 0, 0)
    web.draw.圆(200, 150, 80)
}
web.帧(5) {
    web.draw.色(0, 0, 255)
    web.draw.方(100, 100, 160, 160)
}
web.播放(2)
go(右, 100, 2)
web.draw.终
}STOP
'''
    an = parse(AN).go_body
    assert isinstance(an[0], HmDraw) and an[0].cmd == 'begin'
    assert isinstance(an[1], HmFrame) and len(an[1].body) == 2
    assert an[1].body[0] == HmDraw('color', [NumLit(255, 5), NumLit(0, 5), NumLit(0, 5)], 5)
    assert isinstance(an[2], HmFrame) and an[2].body[1].cmd == 'rect'
    assert an[3] == HmPlay(NumLit(2, 12), 12)
    assert an[4] == GoStmt('右', NumLit(100, 13), NumLit(2, 13), 13)
    assert isinstance(an[5], HmDraw) and an[5].cmd == 'end'
    g2 = parse('@ a>b>c\nGOING:{\ngo(down, 2 + 3, 0.5)\n}STOP\n').go_body
    assert g2[0] == GoStmt('down', BinOp('+', NumLit(2, 3), NumLit(3, 3), 3),
                           NumLit(0.5, 3), 3)
    # web.播放 前没有帧 → 语义错误带行号
    try:
        parse('@ a>b>c\nGOING:{\nweb.播放(2)\n}STOP\n')
    except PybkError as e:
        assert '第 3 行' in str(e) and 'web.帧' in str(e), str(e)
    else:
        raise AssertionError('web.播放 缺帧应当报错')
    # go 方向非法 → 报错带行号
    try:
        parse('@ a>b>c\nGOING:{\ngo(斜, 1, 1)\n}STOP\n')
    except PybkError as e:
        assert '第 3 行' in str(e) and '方向' in str(e), str(e)
    else:
        raise AssertionError('go 方向校验应当报错')

    # ---- 键盘监听与游戏零件 ----
    GM = '''@ game>move>fun
GOING:{
win(800, 600, "My Game")
vg.x = 100
vg.spd = 5
rm.aging.while(end()) {
    clear()
    color(30, 30, 60)
    box(0, 0, 800, 600)
    color(0, 255, 0)
    box(x, y, 50, 50)
    if (key("right")) {
        vg.x = x + spd
    }
    if (key("space") and key("up")) {
        vg.y = y - spd
    }
    show()
    wait(16)
}
}STOP
'''
    gm = parse(GM).go_body
    assert gm[0] == Call('win', [NumLit(800, 3), NumLit(600, 3), StrLit('My Game', 3)], 3)
    aging = gm[3]
    assert isinstance(aging, Aging)
    assert aging.cond == Call('end', [], 6)
    vc0 = aging.body[5]
    assert vc0.arms[0][0] == Call('key', [StrLit('right', 12)], 12)
    vc1 = aging.body[6]
    assert vc1.arms[0][0] == BinOp('and', Call('key', [StrLit('space', 15)], 15),
                                   Call('key', [StrLit('up', 15)], 15), 15)
    assert aging.body[7] == Call('show', [], 18)
    assert aging.body[8] == Call('wait', [NumLit(16, 19)], 19)
    # 全部字母键都合法；中文键名合法
    for kname in 'abcdefghijklmnopqrstuvwxyz':
        c = parse('@ a>b>c\nGOING:{\nvg.b = key("' + kname + '")\n}STOP\n').go_body[0].expr
        assert c == Call('key', [StrLit(kname, 3)], 3)
    c = parse('@ a>b>c\nGOING:{\nvg.b = key("右")\n}STOP\n').go_body[0].expr
    assert c.args[0].value == '右'
    # 错误路径：键名不是字符串 / 键名不合法 / 参数个数不对，均带行号
    for bad, frag in (
            ('@ a>b>c\nGOING:{\nvg.b = key(右)\n}STOP\n', '字符串字面量'),
            ('@ a>b>c\nGOING:{\nvg.b = key("空格2")\n}STOP\n', '不支持的键名'),
            ('@ a>b>c\nGOING:{\nvg.b = key("right", 1)\n}STOP\n', '1 个参数'),
            ('@ a>b>c\nGOING:{\nclear(1)\n}STOP\n', '0 个参数'),
            ('@ a>b>c\nGOING:{\nwin(800, 600)\n}STOP\n', '3 个参数')):
        try:
            parse(bad)
        except PybkError as e:
            assert '第 3 行' in str(e) and frag in str(e), (bad, str(e))
        else:
            raise AssertionError(f'应当报错却没有：{bad!r}')

    print()
    print("自测通过：分支链(if/elif/else)、when 块、$插值切分、裸 ret、web 网页分支、web.块 组件、lb 类(OOP)、"
          "帧动画/go、key 与游戏零件、模块引用/parse_module 均正确，错误均带行号。")
