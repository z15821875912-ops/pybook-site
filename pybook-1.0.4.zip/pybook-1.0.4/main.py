import sys
from pybk_code import compile_and_run, PybkCodegenError

try:
    compile_and_run(open(sys.argv[1], encoding="utf-8").read())
except PybkCodegenError as e:
    print(e, file=sys.stderr)
    sys.exit(1)
except RuntimeError as e:
    print(e, file=sys.stderr)
    sys.exit(1)
