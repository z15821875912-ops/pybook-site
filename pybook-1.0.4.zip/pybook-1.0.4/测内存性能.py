# Memoryment 六模式性能基准：同一负载，逐模式编译，exe 计时（3 取中位）
import statistics
import subprocess
import sys
import time

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

BENCH = """@ 内存模式基准

Memoryment@{n}

lb.怪 {{
    vg.血 = 0
    vg.力 = 1
}}

GOING:{{
vg_ro.窝 = []
rm.around(20000) {{
    list.添加(窝, lb.怪(血=rd.int(1, 99), 力=rd.int(1, 9)))
    vg.首 = 窝[0]
    首.力 = 首.力 + 1
    if(长度(窝) > 100) {{
        删掉(窝, 窝[0])
    }}
}}
ns.show(完成 $长度(窝))
}}STOP"""

from pybk_code import Codegen, parse
from pybk_front import parse as front_parse

GCC = r"C:\Users\zhuli\mingw64\bin\gcc.exe"
FLAGS = ["-O2", "-DRT_GAME_SDL", "-Iucrt64/include", "-Lucrt64/lib"]

results = []
for n in (1, 2, 3, 4, 5, 6):
    src = BENCH.format(n=n)
    try:
        gen = Codegen()
        c_code = gen.generate(front_parse(src))
    except Exception as e:
        results.append((n, None, f"编译失败: {e}"))
        continue
    with open("out_bench.c", "w", encoding="utf-8") as f:
        f.write(c_code)
    exe = f"bench_{n}.exe"
    build = subprocess.run(
        [GCC] + FLAGS + ["-o", exe, "out_bench.c",
                         "pybook_rt.c", "pybook_lib.c", "pybook_file.c", "-lSDL2"],
        capture_output=True, text=True, errors="replace")
    if build.returncode != 0:
        results.append((n, None, "gcc 失败: " + (build.stderr or "").splitlines()[-1][:60]))
        continue
    times = []
    ok = True
    for _ in range(3):
        t0 = time.perf_counter()
        run = subprocess.run([exe], capture_output=True, text=True,
                             encoding="utf-8", errors="replace")
        dt = (time.perf_counter() - t0) * 1000
        if run.returncode != 0:
            ok = False
            times.append(f"崩溃({run.returncode})")
            break
        times.append(dt)
    results.append((n, times, None))

print("模式 | 三次运行 (ms) | 中位")
print("-----|--------------|------")
for n, times, err in results:
    if err:
        print(f"  @{n} | {err}")
    elif not ok:
        print(f"  @{n} | {times}")
    else:
        print(f"  @{n} | {', '.join(f'{t:.0f}' for t in times)} | {statistics.median(times):.0f}")
