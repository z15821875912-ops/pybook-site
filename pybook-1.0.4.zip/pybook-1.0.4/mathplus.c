/* =============================================================================
 * mathplus.c — math+ 模块实现
 *   核心层 (mp_*)       : 无条件编译，纯 C / double*，无运行时依赖。
 *   绑定层 (rt_lib_mp_*) : 仅当 PYBOOK_RT_H 已定义（即 pybook_rt.h 已包含）时编译。
 * ========================================================================== */

#if defined(MP_RT_BINDING) || defined(PYBOOK_RT_H)
#include "pybook_rt.h"   /* 绑定层需要 Value / rt_*：必须在 mathplus.h 之前 */
#endif

#include "mathplus.h"

#include <math.h>
#include <stdlib.h>
#include <string.h>

/* =============================================================================
 * [1] 核心层：向量
 * ========================================================================== */

void mp_vec_add(const double *a, const double *b, double *out, int n)
{
    for (int i = 0; i < n; i++) out[i] = a[i] + b[i];
}

void mp_vec_sub(const double *a, const double *b, double *out, int n)
{
    for (int i = 0; i < n; i++) out[i] = a[i] - b[i];
}

void mp_vec_scale(const double *a, double s, double *out, int n)
{
    for (int i = 0; i < n; i++) out[i] = a[i] * s;
}

double mp_vec_dot(const double *a, const double *b, int n)
{
    double s = 0.0;
    for (int i = 0; i < n; i++) s += a[i] * b[i];
    return s;
}

double mp_vec_norm(const double *a, int n)
{
    return sqrt(mp_vec_dot(a, a, n));
}

double mp_vec_dist(const double *a, const double *b, int n)
{
    double s = 0.0;
    for (int i = 0; i < n; i++) {
        double d = a[i] - b[i];
        s += d * d;
    }
    return sqrt(s);
}

void mp_vec_cross(const double *a, const double *b, double out[3])
{
    out[0] = a[1] * b[2] - a[2] * b[1];
    out[1] = a[2] * b[0] - a[0] * b[2];
    out[2] = a[0] * b[1] - a[1] * b[0];
}

void mp_vec_lerp(const double *a, const double *b, double *out, int n, double t)
{
    for (int i = 0; i < n; i++) out[i] = a[i] + (b[i] - a[i]) * t;
}

/* =============================================================================
 * [1] 核心层：矩阵
 * ========================================================================== */

void mp_mat_add(const double *a, const double *b, double *out, int r, int c)
{
    int n = r * c;
    for (int i = 0; i < n; i++) out[i] = a[i] + b[i];
}

void mp_mat_scale(const double *a, double s, double *out, int r, int c)
{
    int n = r * c;
    for (int i = 0; i < n; i++) out[i] = a[i] * s;
}

void mp_mat_mul(const double *a, const double *b, double *out, int r, int m, int c)
{
    for (int i = 0; i < r; i++) {
        for (int j = 0; j < c; j++) {
            double s = 0.0;
            for (int k = 0; k < m; k++)
                s += a[(size_t)i * m + k] * b[(size_t)k * c + j];
            out[(size_t)i * c + j] = s;
        }
    }
}

void mp_mat_transpose(const double *a, double *out, int r, int c)
{
    for (int i = 0; i < r; i++)
        for (int j = 0; j < c; j++)
            out[(size_t)j * r + i] = a[(size_t)i * c + j];
}

void mp_mat_identity(double *out, int n)
{
    memset(out, 0, (size_t)n * n * sizeof(double));
    for (int i = 0; i < n; i++) out[(size_t)i * n + i] = 1.0;
}

void mp_mat_vec_mul(const double *a, const double *x, double *out, int r, int c)
{
    for (int i = 0; i < r; i++) {
        double s = 0.0;
        for (int j = 0; j < c; j++) s += a[(size_t)i * c + j] * x[j];
        out[i] = s;
    }
}

double mp_mat_det(const double *a, int n)
{
    if (n <= 0) return 1.0;
    double *m = (double *)malloc((size_t)n * n * sizeof(double));
    if (!m) return 0.0;
    memcpy(m, a, (size_t)n * n * sizeof(double));

    double det = 1.0;
    int sgn = 1;
    for (int k = 0; k < n; k++) {
        /* 部分主元 */
        int piv = k;
        double best = fabs(m[(size_t)k * n + k]);
        for (int i = k + 1; i < n; i++) {
            double v = fabs(m[(size_t)i * n + k]);
            if (v > best) { best = v; piv = i; }
        }
        if (best < 1e-12) { free(m); return 0.0; }
        if (piv != k) {
            for (int j = 0; j < n; j++) {
                double t = m[(size_t)k * n + j];
                m[(size_t)k * n + j] = m[(size_t)piv * n + j];
                m[(size_t)piv * n + j] = t;
            }
            sgn = -sgn;
        }
        double pk = m[(size_t)k * n + k];
        det *= pk;
        for (int i = k + 1; i < n; i++) {
            double f = m[(size_t)i * n + k] / pk;
            for (int j = k; j < n; j++)
                m[(size_t)i * n + j] -= f * m[(size_t)k * n + j];
        }
    }
    free(m);
    return sgn * det;
}

int mp_mat_inverse(const double *a, double *out, int n)
{
    if (n <= 0) return -1;
    double *aug = (double *)malloc((size_t)n * 2 * n * sizeof(double));
    if (!aug) return -1;
    /* 左 = A，右 = I */
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            aug[(size_t)i * 2 * n + j] = a[(size_t)i * n + j];
            aug[(size_t)i * 2 * n + (n + j)] = (j == i) ? 1.0 : 0.0;
        }
    }
    for (int col = 0; col < n; col++) {
        int piv = col;
        double best = fabs(aug[(size_t)col * 2 * n + col]);
        for (int i = col + 1; i < n; i++) {
            double v = fabs(aug[(size_t)i * 2 * n + col]);
            if (v > best) { best = v; piv = i; }
        }
        if (best < 1e-12) { free(aug); return -1; }
        if (piv != col) {
            for (int j = 0; j < 2 * n; j++) {
                double t = aug[(size_t)col * 2 * n + j];
                aug[(size_t)col * 2 * n + j] = aug[(size_t)piv * 2 * n + j];
                aug[(size_t)piv * 2 * n + j] = t;
            }
        }
        double pv = aug[(size_t)col * 2 * n + col];
        for (int j = 0; j < 2 * n; j++) aug[(size_t)col * 2 * n + j] /= pv;
        for (int i = 0; i < n; i++) {
            if (i == col) continue;
            double f = aug[(size_t)i * 2 * n + col];
            if (f == 0.0) continue;
            for (int j = 0; j < 2 * n; j++)
                aug[(size_t)i * 2 * n + j] -= f * aug[(size_t)col * 2 * n + j];
        }
    }
    for (int i = 0; i < n; i++)
        for (int j = 0; j < n; j++)
            out[(size_t)i * n + j] = aug[(size_t)i * 2 * n + (n + j)];
    free(aug);
    return 0;
}

void mp_mat_rot_x(double *out, double ang)
{
    double s = sin(ang), c = cos(ang);
    mp_mat_identity(out, 3);
    out[4] = c; out[5] = -s;   /* 标准右手系：+ang 为绕 X 逆时针 */
    out[7] = s; out[8] = c;
}

void mp_mat_rot_y(double *out, double ang)
{
    double s = sin(ang), c = cos(ang);
    mp_mat_identity(out, 3);
    out[0] = c; out[2] = s;
    out[6] = -s; out[8] = c;
}

void mp_mat_rot_z(double *out, double ang)
{
    double s = sin(ang), c = cos(ang);
    mp_mat_identity(out, 3);
    out[0] = c; out[1] = -s;
    out[3] = s; out[4] = c;
}

void mp_mat_perspective(double *out, double fovy, double aspect, double zn, double zf)
{
    memset(out, 0, 16 * sizeof(double));
    double f = 1.0 / tan(fovy / 2.0);
    out[0] = f / aspect;
    out[5] = f;
    out[10] = (zf + zn) / (zn - zf);
    out[11] = -1.0;
    out[14] = (2.0 * zf * zn) / (zn - zf);
}

void mp_mat_translate(double *out, double x, double y, double z)
{
    mp_mat_identity(out, 4);
    out[3] = x; out[7] = y; out[11] = z;
}

/* =============================================================================
 * [1] 核心层：统计 / 变换 / 标量
 * ========================================================================== */

double mp_sum(const double *a, int n)
{
    double s = 0.0;
    for (int i = 0; i < n; i++) s += a[i];
    return s;
}

double mp_mean(const double *a, int n)
{
    if (n <= 0) return 0.0;
    return mp_sum(a, n) / n;
}

double mp_var(const double *a, int n, int ddof)
{
    if (n <= 0) return 0.0;
    double mu = mp_mean(a, n);
    double s = 0.0;
    for (int i = 0; i < n; i++) { double d = a[i] - mu; s += d * d; }
    int denom = n - ddof;
    if (denom <= 0) denom = 1;
    return s / denom;
}

double mp_std(const double *a, int n, int ddof)
{
    return sqrt(mp_var(a, n, ddof));
}

void mp_minmax(const double *a, int n, double *mn, double *mx)
{
    if (n <= 0) { *mn = 0.0; *mx = 0.0; return; }
    double lo = a[0], hi = a[0];
    for (int i = 1; i < n; i++) {
        if (a[i] < lo) lo = a[i];
        if (a[i] > hi) hi = a[i];
    }
    *mn = lo; *mx = hi;
}

void mp_linspace(double *out, int n, double lo, double hi)
{
    if (n <= 1) { if (n == 1) out[0] = lo; return; }
    double step = (hi - lo) / (n - 1);
    for (int i = 0; i < n; i++) out[i] = lo + step * i;
}

double mp_clamp(double v, double lo, double hi)
{
    if (v < lo) return lo;
    if (v > hi) return hi;
    return v;
}

double mp_mix(double a, double b, double t) { return a + (b - a) * t; }

double mp_smoothstep(double e0, double e1, double x)
{
    if (e1 == e0) return (x < e0) ? 0.0 : 1.0;
    double t = mp_clamp((x - e0) / (e1 - e0), 0.0, 1.0);
    return t * t * (3.0 - 2.0 * t);
}

double mp_sign(double x) { return (x > 0) ? 1.0 : (x < 0) ? -1.0 : 0.0; }
double mp_radians(double deg) { return deg * M_PI / 180.0; }
double mp_degrees(double rad) { return rad * 180.0 / M_PI; }

/* =============================================================================
 * [1] 核心层：随机数（xorshift128，自带状态，独立于标准库 rd）
 * ========================================================================== */

static uint64_t g_mp_seed = 0x9E3779B97F4A7C15ULL;

void mp_rand_seed(uint64_t s)
{
    g_mp_seed = s ? s : 0x9E3779B97F4A7C15ULL;
}

double mp_rand_u01(void)
{
    uint64_t x = g_mp_seed;
    x ^= x << 13;
    x ^= x >> 7;
    x ^= x << 17;
    g_mp_seed = x;
    /* 53 位精度映射到 [0,1) */
    return (double)(x >> 11) / (double)(1ULL << 53);
}

double mp_rand_normal(double mean, double sd)
{
    double u1 = mp_rand_u01();
    if (u1 < 1e-12) u1 = 1e-12;
    double u2 = mp_rand_u01();
    double z = sqrt(-2.0 * log(u1)) * cos(2.0 * M_PI * u2);
    return mean + sd * z;
}

/* =============================================================================
 * [2] 绑定层：PYbook Value <-> double*（仅 PYBOOK_RT_H 已定义时编译）
 * ========================================================================== */
#if defined(PYBOOK_RT_H) || defined(MP_RT_BINDING)

#include <stdio.h>
#include <stdarg.h>

static void mp_die(const char *fmt, ...)
{
    va_list ap;
    fprintf(stderr, "math+ 运行时错误: ");
    va_start(ap, fmt);
    vfprintf(stderr, fmt, ap);
    va_end(ap);
    fputc('\n', stderr);
    exit(1);
}

static double mp_num(Value v, const char *who)
{
    if (IS_FLT(v)) return AS_FLT(v);
    if (IS_INT(v) || IS_BIGINT(v)) return (double)rt_to_ll(v);
    if (IS_BOOL(v)) return (double)AS_BOOL(v);
    mp_die("%s 需要数字参数", who);
    return 0.0;
}

static long long mp_ll(Value v, const char *who)
{
    if (IS_INT(v) || IS_BIGINT(v)) return rt_to_ll(v);
    if (IS_BOOL(v)) return (long long)AS_BOOL(v);
    mp_die("%s 需要整数参数", who);
    return 0;
}

/* 把 PYbook 列表展开成 double*（调用方负责 free） */
static double *mp_unpack(Value v, long long *out_n, const char *who)
{
    if (!IS_LIST(v)) mp_die("%s 需要列表参数", who);
    long long n = rt_list_len_ll(v);
    double *buf = (double *)malloc((size_t)(n > 0 ? n : 1) * sizeof(double));
    if (!buf) mp_die("math+ 内存不足");
    for (long long i = 0; i < n; i++)
        buf[i] = mp_num(rt_index(v, rt_int(i)), who);
    *out_n = n;
    return buf;
}

/* 把 double* 打包成 PYbook 列表（浮点） */
static Value mp_pack(const double *a, long long n)
{
    Value out = rt_list_new();
    for (long long i = 0; i < n; i++) rt_push(&out, rt_float(a[i]));
    return out;
}

/* 维度检查：扁平长度必须等于 r*c（或对应维度） */
static void mp_dim_check(long long got, long long need, const char *who)
{
    if (got != need)
        mp_die("%s 维度不符：列表长度 %lld，期望 %lld", who, got, need);
}

/* ---------- 向量 ---------- */

Value rt_lib_mp_vec_add(Value a, Value b)
{
    long long n1, n2;
    double *A = mp_unpack(a, &n1, "mp.vec_add");
    double *B = mp_unpack(b, &n2, "mp.vec_add");
    if (n1 != n2) mp_die("mp.vec_add 两向量长度不等：%lld vs %lld", n1, n2);
    double *o = (double *)malloc((size_t)n1 * sizeof(double));
    mp_vec_add(A, B, o, (int)n1);
    Value r = mp_pack(o, n1);
    free(A); free(B); free(o);
    return r;
}

Value rt_lib_mp_vec_sub(Value a, Value b)
{
    long long n1, n2;
    double *A = mp_unpack(a, &n1, "mp.vec_sub");
    double *B = mp_unpack(b, &n2, "mp.vec_sub");
    if (n1 != n2) mp_die("mp.vec_sub 两向量长度不等");
    double *o = (double *)malloc((size_t)n1 * sizeof(double));
    mp_vec_sub(A, B, o, (int)n1);
    Value r = mp_pack(o, n1);
    free(A); free(B); free(o);
    return r;
}

Value rt_lib_mp_vec_scale(Value a, Value s)
{
    long long n;
    double *A = mp_unpack(a, &n, "mp.vec_scale");
    double *o = (double *)malloc((size_t)n * sizeof(double));
    mp_vec_scale(A, mp_num(s, "mp.vec_scale 第 2 个参数"), o, (int)n);
    Value r = mp_pack(o, n);
    free(A); free(o);
    return r;
}

Value rt_lib_mp_vec_dot(Value a, Value b)
{
    long long n1, n2;
    double *A = mp_unpack(a, &n1, "mp.vec_dot");
    double *B = mp_unpack(b, &n2, "mp.vec_dot");
    if (n1 != n2) mp_die("mp.vec_dot 两向量长度不等");
    double d = mp_vec_dot(A, B, (int)n1);
    free(A); free(B);
    return rt_float(d);
}

Value rt_lib_mp_vec_norm(Value a)
{
    long long n;
    double *A = mp_unpack(a, &n, "mp.vec_norm");
    double d = mp_vec_norm(A, (int)n);
    free(A);
    return rt_float(d);
}

Value rt_lib_mp_vec_dist(Value a, Value b)
{
    long long n1, n2;
    double *A = mp_unpack(a, &n1, "mp.vec_dist");
    double *B = mp_unpack(b, &n2, "mp.vec_dist");
    if (n1 != n2) mp_die("mp.vec_dist 两向量长度不等");
    double d = mp_vec_dist(A, B, (int)n1);
    free(A); free(B);
    return rt_float(d);
}

Value rt_lib_mp_vec_cross(Value a, Value b)
{
    long long n1, n2;
    double *A = mp_unpack(a, &n1, "mp.vec_cross");
    double *B = mp_unpack(b, &n2, "mp.vec_cross");
    if (n1 != 3 || n2 != 3) mp_die("mp.vec_cross 仅支持 3 维向量");
    double o[3];
    mp_vec_cross(A, B, o);
    free(A); free(B);
    return mp_pack(o, 3);
}

Value rt_lib_mp_vec_lerp(Value a, Value b, Value t)
{
    long long n1, n2;
    double *A = mp_unpack(a, &n1, "mp.vec_lerp");
    double *B = mp_unpack(b, &n2, "mp.vec_lerp");
    if (n1 != n2) mp_die("mp.vec_lerp 两向量长度不等");
    double *o = (double *)malloc((size_t)n1 * sizeof(double));
    mp_vec_lerp(A, B, o, (int)n1, mp_num(t, "mp.vec_lerp 第 3 个参数"));
    Value r = mp_pack(o, n1);
    free(A); free(B); free(o);
    return r;
}

/* ---------- 矩阵 ---------- */

Value rt_lib_mp_mat_add(Value a, Value b, Value rv, Value cv)
{
    int r = (int)mp_ll(rv, "mp.mat_add 第 3 个参数");
    int c = (int)mp_ll(cv, "mp.mat_add 第 4 个参数");
    long long n1, n2;
    double *A = mp_unpack(a, &n1, "mp.mat_add");
    double *B = mp_unpack(b, &n2, "mp.mat_add");
    mp_dim_check(n1, (long long)r * c, "mp.mat_add(矩阵A)");
    mp_dim_check(n2, (long long)r * c, "mp.mat_add(矩阵B)");
    double *o = (double *)malloc((size_t)(r * c) * sizeof(double));
    mp_mat_add(A, B, o, r, c);
    Value res = mp_pack(o, (long long)r * c);
    free(A); free(B); free(o);
    return res;
}

Value rt_lib_mp_mat_scale(Value a, Value s, Value rv, Value cv)
{
    int r = (int)mp_ll(rv, "mp.mat_scale 第 3 个参数");
    int c = (int)mp_ll(cv, "mp.mat_scale 第 4 个参数");
    long long n;
    double *A = mp_unpack(a, &n, "mp.mat_scale");
    mp_dim_check(n, (long long)r * c, "mp.mat_scale");
    double *o = (double *)malloc((size_t)(r * c) * sizeof(double));
    mp_mat_scale(A, mp_num(s, "mp.mat_scale 第 2 个参数"), o, r, c);
    Value res = mp_pack(o, (long long)r * c);
    free(A); free(o);
    return res;
}

Value rt_lib_mp_mat_mul(Value a, Value b, Value rv, Value mv, Value cv)
{
    int r = (int)mp_ll(rv, "mp.mat_mul 第 3 个参数");
    int m = (int)mp_ll(mv, "mp.mat_mul 第 4 个参数");
    int c = (int)mp_ll(cv, "mp.mat_mul 第 5 个参数");
    long long n1, n2;
    double *A = mp_unpack(a, &n1, "mp.mat_mul");
    double *B = mp_unpack(b, &n2, "mp.mat_mul");
    mp_dim_check(n1, (long long)r * m, "mp.mat_mul(矩阵A)");
    mp_dim_check(n2, (long long)m * c, "mp.mat_mul(矩阵B)");
    double *o = (double *)malloc((size_t)(r * c) * sizeof(double));
    mp_mat_mul(A, B, o, r, m, c);
    Value res = mp_pack(o, (long long)r * c);
    free(A); free(B); free(o);
    return res;
}

Value rt_lib_mp_mat_transpose(Value a, Value rv, Value cv)
{
    int r = (int)mp_ll(rv, "mp.mat_transpose 第 2 个参数");
    int c = (int)mp_ll(cv, "mp.mat_transpose 第 3 个参数");
    long long n;
    double *A = mp_unpack(a, &n, "mp.mat_transpose");
    mp_dim_check(n, (long long)r * c, "mp.mat_transpose");
    double *o = (double *)malloc((size_t)(r * c) * sizeof(double));
    mp_mat_transpose(A, o, r, c);
    Value res = mp_pack(o, (long long)r * c);
    free(A); free(o);
    return res;
}

Value rt_lib_mp_mat_identity(Value nv)
{
    int n = (int)mp_ll(nv, "mp.mat_identity");
    if (n <= 0) mp_die("mp.mat_identity 维度必须为正整数");
    double *o = (double *)malloc((size_t)(n * n) * sizeof(double));
    mp_mat_identity(o, n);
    Value res = mp_pack(o, (long long)n * n);
    free(o);
    return res;
}

Value rt_lib_mp_mat_det(Value a, Value nv)
{
    int n = (int)mp_ll(nv, "mp.mat_det 第 2 个参数");
    long long len;
    double *A = mp_unpack(a, &len, "mp.mat_det");
    mp_dim_check(len, (long long)n * n, "mp.mat_det");
    double d = mp_mat_det(A, n);
    free(A);
    return rt_float(d);
}

Value rt_lib_mp_mat_inverse(Value a, Value nv)
{
    int n = (int)mp_ll(nv, "mp.mat_inverse 第 2 个参数");
    long long len;
    double *A = mp_unpack(a, &len, "mp.mat_inverse");
    mp_dim_check(len, (long long)n * n, "mp.mat_inverse");
    double *o = (double *)malloc((size_t)(n * n) * sizeof(double));
    if (mp_mat_inverse(A, o, n) != 0) mp_die("mp.mat_inverse 矩阵奇异，不可逆");
    Value res = mp_pack(o, (long long)n * n);
    free(A); free(o);
    return res;
}

Value rt_lib_mp_mat_vec_mul(Value a, Value x, Value rv, Value cv)
{
    int r = (int)mp_ll(rv, "mp.mat_vec_mul 第 3 个参数");
    int c = (int)mp_ll(cv, "mp.mat_vec_mul 第 4 个参数");
    long long n1, n2;
    double *A = mp_unpack(a, &n1, "mp.mat_vec_mul");
    double *X = mp_unpack(x, &n2, "mp.mat_vec_mul");
    mp_dim_check(n1, (long long)r * c, "mp.mat_vec_mul(矩阵)");
    mp_dim_check(n2, (long long)c, "mp.mat_vec_mul(向量)");
    double *o = (double *)malloc((size_t)r * sizeof(double));
    mp_mat_vec_mul(A, X, o, r, c);
    Value res = mp_pack(o, (long long)r);
    free(A); free(X); free(o);
    return res;
}

/* ---------- 统计 ---------- */

Value rt_lib_mp_mean(Value list)
{
    long long n;
    double *A = mp_unpack(list, &n, "mp.mean");
    double d = mp_mean(A, (int)n);
    free(A);
    return rt_float(d);
}

Value rt_lib_mp_var(Value list, Value ddof)
{
    long long n;
    double *A = mp_unpack(list, &n, "mp.var");
    double d = mp_var(A, (int)n, (int)mp_ll(ddof, "mp.var 第 2 个参数"));
    free(A);
    return rt_float(d);
}

Value rt_lib_mp_std(Value list, Value ddof)
{
    long long n;
    double *A = mp_unpack(list, &n, "mp.std");
    double d = mp_std(A, (int)n, (int)mp_ll(ddof, "mp.std 第 2 个参数"));
    free(A);
    return rt_float(d);
}

Value rt_lib_mp_sum(Value list)
{
    long long n;
    double *A = mp_unpack(list, &n, "mp.sum");
    double d = mp_sum(A, (int)n);
    free(A);
    return rt_float(d);
}

Value rt_lib_mp_minmax(Value list)
{
    long long n;
    double *A = mp_unpack(list, &n, "mp.minmax");
    double mn, mx;
    mp_minmax(A, (int)n, &mn, &mx);
    free(A);
    double out[2] = { mn, mx };
    return mp_pack(out, 2);
}

Value rt_lib_mp_linspace(Value lo, Value hi, Value nv)
{
    int n = (int)mp_ll(nv, "mp.linspace 第 3 个参数");
    if (n <= 0) mp_die("mp.linspace 元素数必须为正整数");
    double *o = (double *)malloc((size_t)n * sizeof(double));
    mp_linspace(o, n, mp_num(lo, "mp.linspace 第 1 个参数"),
                mp_num(hi, "mp.linspace 第 2 个参数"));
    Value res = mp_pack(o, (long long)n);
    free(o);
    return res;
}

/* ---------- 标量/变换 ---------- */

Value rt_lib_mp_clamp(Value v, Value lo, Value hi)
{
    return rt_float(mp_clamp(mp_num(v, "mp.clamp 第 1 个参数"),
                             mp_num(lo, "mp.clamp 第 2 个参数"),
                             mp_num(hi, "mp.clamp 第 3 个参数")));
}

Value rt_lib_mp_smoothstep(Value e0, Value e1, Value x)
{
    return rt_float(mp_smoothstep(mp_num(e0, "mp.smoothstep 第 1 个参数"),
                                 mp_num(e1, "mp.smoothstep 第 2 个参数"),
                                 mp_num(x, "mp.smoothstep 第 3 个参数")));
}

Value rt_lib_mp_lerp(Value a, Value b, Value t)
{
    return rt_float(mp_mix(mp_num(a, "mp.lerp 第 1 个参数"),
                           mp_num(b, "mp.lerp 第 2 个参数"),
                           mp_num(t, "mp.lerp 第 3 个参数")));
}

Value rt_lib_mp_radians(Value deg)
{
    return rt_float(mp_radians(mp_num(deg, "mp.radians")));
}

Value rt_lib_mp_degrees(Value rad)
{
    return rt_float(mp_degrees(mp_num(rad, "mp.degrees")));
}

/* ---------- 随机 ---------- */

Value rt_lib_mp_rand_seed(Value s)
{
    mp_rand_seed((uint64_t)mp_ll(s, "mp.rand_seed"));
    return rt_none();
}

Value rt_lib_mp_rand_u01(void)
{
    return rt_float(mp_rand_u01());
}

Value rt_lib_mp_rand_normal(Value m, Value sd)
{
    return rt_float(mp_rand_normal(mp_num(m, "mp.rand_normal 第 1 个参数"),
                                   mp_num(sd, "mp.rand_normal 第 2 个参数")));
}

#endif /* PYBOOK_RT_H */
