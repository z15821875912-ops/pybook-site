# -*- coding: utf-8 -*-
"""把 4 条新 API（hw.shader / hw.preset / hw.shaderuse / hw.uni）接到
   pybk_front.py 与 pybk_code.py 的 5 个注册点。
   每处断言 count == 1，任一失败整体不写回。"""
import io
import sys

# (文件, [(label, old, new), ...])
JOBS = []

JOBS.append(('pybk_front.py', [
    ('front-LIB_CALLS',
     "    'hw.push': 6, 'hw.pop': 0,\n",
     "    'hw.push': 6, 'hw.pop': 0,\n"
     "    'hw.shader': 3, 'hw.preset': 2, 'hw.shaderuse': 1, 'hw.uni': 2,\n"),
    ('front-arity',
     "        elif full == 'hw.cyl' and len(args) == 10:\n"
     "            pass                          # cyl(x,y,z,下半径,高,上半径, 边数, r,g,b)：自定义边数\n",
     "        elif full == 'hw.cyl' and len(args) == 10:\n"
     "            pass                          # cyl(x,y,z,下半径,高,上半径, 边数, r,g,b)：自定义边数\n"
     "        elif full == 'hw.uni' and 2 <= len(args) <= 5:\n"
     "            pass                          # uni(\"名字\", a[, b[, c[, d]]])：1~4 个分量\n"),
]))

JOBS.append(('pybk_code.py', [
    ('code-LIB_C_NAMES',
     "        'hw.push': 'rt_hw_push', 'hw.pop': 'rt_hw_pop',\n",
     "        'hw.push': 'rt_hw_push', 'hw.pop': 'rt_hw_pop',\n"
     "        'hw.shader': 'rt_hw_shader', 'hw.preset': 'rt_hw_preset',\n"
     "        'hw.shaderuse': 'rt_hw_shaderuse', 'hw.uni': 'rt_hw_univ',\n"),
    ('code-arity',
     "        elif e.name == 'hw.cyl' and len(e.args) == 10:\n"
     "            pass                        # cyl 带自定义边数的写法：走 rt_hw_cylv\n",
     "        elif e.name == 'hw.cyl' and len(e.args) == 10:\n"
     "            pass                        # cyl 带自定义边数的写法：走 rt_hw_cylv\n"
     "        elif e.name == 'hw.uni' and 2 <= len(e.args) <= 5:\n"
     "            pass                        # uni(\"名字\", a[, b[, c[, d]]])：1~4 个分量\n"),
    ('code-emit',
     "        if e.name == 'hw.cyl':\n"
     "            # rt_hw_cylv(nargs, (Value[]){ ... }) —— 9 参或 10 参都走这里\n"
     "            return stmts, (f'rt_hw_cylv({len(args)}, (Value[]){{ {\", \".join(args)} }})')\n",
     "        if e.name == 'hw.cyl':\n"
     "            # rt_hw_cylv(nargs, (Value[]){ ... }) —— 9 参或 10 参都走这里\n"
     "            return stmts, (f'rt_hw_cylv({len(args)}, (Value[]){{ {\", \".join(args)} }})')\n"
     "        if e.name == 'hw.uni':\n"
     "            # rt_hw_univ(nargs, (Value[]){ ... }) —— 2~5 个实参都走这里\n"
     "            return stmts, (f'rt_hw_univ({len(args)}, (Value[]){{ {\", \".join(args)} }})')\n"),
    ('code-protos',
     "    # 父子层级\n"
     "    lines.append('Value rt_hw_push(Value, Value, Value, Value, Value, Value);')\n"
     "    lines.append('Value rt_hw_pop(void);')\n",
     "    # 父子层级\n"
     "    lines.append('Value rt_hw_push(Value, Value, Value, Value, Value, Value);')\n"
     "    lines.append('Value rt_hw_pop(void);')\n"
     "    # 可编程管线（GLSL）：编译着色器 / 内置着色器 / 启用 / 设 uniform\n"
     "    lines.append('Value rt_hw_shader(Value, Value, Value);')\n"
     "    lines.append('Value rt_hw_preset(Value, Value);')\n"
     "    lines.append('Value rt_hw_shaderuse(Value);')\n"
     "    lines.append('Value rt_hw_univ(int nargs, Value *av);')\n"),
]))

for path, patches in JOBS:
    s = io.open(path, encoding='utf-8').read()
    out = s
    for label, old, new in patches:
        n = out.count(old)
        if n != 1:
            sys.stderr.write('FAIL [%s] count=%d in %s\n' % (label, n, path))
            sys.exit(1)
        out = out.replace(old, new, 1)
        print('ok   %-22s (%s)' % (label, path))
    io.open(path, 'w', encoding='utf-8', newline='').write(out)

print('\n注册点接线完成。')
