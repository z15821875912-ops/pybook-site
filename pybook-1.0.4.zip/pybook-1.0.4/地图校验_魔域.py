# -*- coding: utf-8 -*-
"""三张地图的草稿校验：40 列 × 26 行、边界封闭、必带标记。"""

森林图 = [
"########################################",
"#TT................T..........TT..TTTT#",
"#T....,,,,....T..........,,,,......TTT#",
"#T...........TTT....T..........T.....T#",
"#...................T....T............#",
"#....TT.....~~~...........TT..........#",
"#...........~~~~..~~~......T..........#",
"#..T........~~~...~~~~...........T....#",
"#....T......~~....~~~....T.......TT...#",
"#........T........~~.........T........#",
"#.....T.........T.....................#",
"#..C..................................#",
"#....................1........T.......#",
"#..T..........2.................T.....#",
"#.............................2.......#",
"#.....1..........TT.........1.........#",
"#.P.....................T...........X.#",
"#...............2.....................#",
"#..1..........T............1..........#",
"#........T.....................T......#",
"#....2............1...........T.....T.#",
"#..T..........T........T..............#",
"#.....................................#",
"#TT.......T........T........TT....TT..#",
"#TTT....TT....T......TT......T....TTT.#",
"########################################",
]

洞窟图 = [
"########################################",
"#......................................#",
"#..DDDDDDD......DDDDDDDDDDD...........#",
"#..DddddddddD..DddddddddddddD...DDDD..#",
"#..DddddddddDDDddddddddddddddD..DttD..#",
"#..Dddddd2ddddddddddd3dddddD....DttD..#",
"#..DdddddddddddddddddddddD......DDDD..#",
"#..DDDDDddddddddddddDDDDD............#",
"#......Dddddddd4ddddD................#",
"#......DDDDddddddddDD....DDDDDDDD....#",
"#.........DdddddddD......DtttttttD....#",
"#..DDDD...DddddddddDD....DddddddD....#",
"#..DttD...DdddddddddD....DddddddD....#",
"#..DttD...DDDddddDDDD....DDDddddD....#",
"#..DDDD......DdddD..........DdddD....#",
"#............DddddD..C......DdddD....#",
"#..1.........DdddD..........Ddddd....#",
"#............DdddDDD..........DDD....#",
"#..DDDDDD....DdddddD.................#",
"#..DtttD....DDdddddDD....3...........#",
"#..DtttD....DddddddddD...............#",
"#..DDDDD....DDDDddddDDDDD..DDDDDD....#",
"#..........................DttttD....#",
"#..3.....2...........2......DttttD....#",
"#.P.......................C...DDDD..X#",
"########################################",
]

魔王城图 = [
"########################################",
"#......................................#",
"#..MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM..#",
"#..MmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmM..#",
"#..MmmmmmMmmmmmmMmmmmmmmmMmmmmmmmmmM..#",
"#..MmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmM..#",
"#..MmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmM..#",
"#......................................#",
"#..MmmmmMtMmmmmmmMmmmmmmmMmmmMtMmmmM..#",
"#..MmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmM..#",
"#..MmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmM..#",
"#..MmmmmmMmmmmmmMmmBmmmmmMmmmmmmmmmM..#",
"#..MmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmM..#",
"#..MmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmM..#",
"#..MmmmmmMmmmmmmMmmmmmmmMmmmmmmmmmM..#",
"#..MmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmM..#",
"#..MmmmmmPmmmmmmmmmmmmmmmmmmmmmmmmmM..#",
"#..MmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmM..#",
"#..MmmmmMmmmmmmMmmmmmmmmMmmmmmmmmmM..#",
"#..MmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmM..#",
"#..MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM..#",
"#......................................#",
"#..MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM..#",
"#......................................#",
"#..MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM..#",
"########################################",
]

def normalize(m):
    """行宽机械整修：内宽补'.'或裁尾到 38，保证两侧 '#' 边界。"""
    out = []
    for r in m:
        if set(r) == {'#'}:
            out.append('#' * 40)
            continue
        core = r.strip('#')
        if len(core) > 38:
            # 从右往左裁掉多余的非实体格，优先裁 '.'
            n = len(core) - 38
            for ch in ['.']:
                while n > 0 and ch in core:
                    k = core.rfind(ch)
                    core = core[:k] + core[k + 1:]
                    n -= 1
            while n > 0 and len(core) > 38:   # 兜底：裁掉最右一个字符
                core = core[:-1]
                n -= 1
        elif len(core) < 38:
            core = core + '.' * (38 - len(core))
        out.append('#' + core + '#')
    return out

森林图 = normalize(森林图)
洞窟图 = normalize(洞窟图)
魔王城图 = normalize(魔王城图)

def check(name, m, need):
    assert len(m) == 26, f"{name}: 行数 {len(m)} != 26"
    for i, r in enumerate(m):
        assert len(r) == 40, f"{name} 第{i}行: 宽 {len(r)} != 40"
    assert m[0] == '#' * 40 and m[25] == '#' * 40, f"{name}: 上下边界不封闭"
    for i, r in enumerate(m):
        assert r[0] == '#' and r[39] == '#', f"{name} 第{i}行: 左右边界不封闭"
    for n in need:
        cnt = sum(r.count(n) for r in m)
        assert cnt >= 1, f"{name}: 缺少标记 {n}"
    print(f"{name}: 通过")

check("森林图", 森林图, "PX12C")
check("洞窟图", 洞窟图, "PX1234C")
check("魔王城图", 魔王城图, "PB")
print("全部通过")
for m in (森林图, 洞窟图, 魔王城图):
    for r in m:
        print(r)
    print()
