/* ============================================================
 * PYbook 场景编辑器（C + SDL2 原生版）
 *
 *   Godot 的本体是 C++，PYbook 引擎的本体是 C（pybook_rt.c + SDL2），
 *   所以编辑器也用 C 写：编译成一个 exe，双击即开，不再依赖 Tk。
 *   .pybk 之于 PYbook = GDScript 之于 Godot。
 *
 *   功能与 编辑器.py 完全对齐：
 *     - 左：对象层级   中：可拖拽视口(滚轮缩放/右键平移)   右：属性面板
 *     - 对象 = 节点：矩形/圆/文本/图片/相机 + 碰撞箱(0无 1实体 2角色 3动态 4触发)
 *     - 相机节点带「跟随」目标；播放时物理+相机+绘制全走真引擎
 *     - 场景存 .scene(JSON)；▶ 播放 = 生成 <名>_场景.pybk + <名>_预览.pybk
 *       再调 pybk_main.py 开 SDL 真机窗口（画面与真游戏一致）
 *   编译: gcc -O2 -finput-charset=UTF-8 -fexec-charset=UTF-8
 *         -Iucrt64/include -Lucrt64/lib 编辑器.c -o 编辑器.exe
 *         -lSDL2 -lcomdlg32 -lwinmm -static-libgcc
 * ============================================================ */
#define SDL_MAIN_HANDLED
#include <SDL2/SDL.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <math.h>
#include <windows.h>
#include <shellapi.h>
#include <commdlg.h>

#define STB_TRUETYPE_IMPLEMENTATION
#include "stb_truetype.h"
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

/* ============================ 场景数据 ============================ */

#define MAXOBJ 512

typedef struct {
    char 名[64];
    int 形;               /* 0矩形 1圆 2文本 3图片 4相机 */
    int x, y, w, h;
    int 红, 绿, 蓝;
    char 文本[256];
    int 号;
    char 图[260];
    int 可见;
    int 实;               /* 0无 1实体 2角色 3动态 4触发 */
    int 跟;               /* 相机跟随下标，-1 不跟 */
} 物;

static struct {
    char 名[64];
    int 宽, 高;
    int bgR, bgG, bgB;
    物 o[MAXOBJ];
    int n;
} S;

static char 场景路径[MAX_PATH * 3] = {0};   /* UTF-8 */
static int  选中 = -1;

static const char *SHAPE名[] = { "矩形", "圆", "文本", "图片", "相机" };
static const char *SOLID名[] = { "无", "实体", "角色", "动态", "触发" };
static const SDL_Color SOLID色[] = { {0,0,0,0}, {74,222,128,255}, {56,189,248,255},
                                     {251,146,60,255}, {250,204,21,255} };

static void 物默认(物 *o, int 形)
{
    memset(o, 0, sizeof *o);
    snprintf(o->名, sizeof o->名, "%s对象", SHAPE名[形]);
    o->形 = 形; o->x = 100; o->y = 100; o->w = 120; o->h = 80;
    o->红 = 120; o->绿 = 180; o->蓝 = 255;
    snprintf(o->文本, sizeof o->文本, "你好 PYbook");
    o->号 = 18; o->可见 = 1; o->实 = 0; o->跟 = -1;
    if (形 == 4) {
        snprintf(o->名, sizeof o->名, "相机");
        o->x = 0; o->y = 0; o->w = S.宽; o->h = S.高;
        o->红 = 250; o->绿 = 210; o->蓝 = 90;
    }
}

/* ============================ 小工具 ============================ */

static void utf8_to_wide(const char *s, wchar_t *w, int cap)
{
    MultiByteToWideChar(CP_UTF8, 0, s, -1, w, cap);
}
static void wide_to_utf8(const wchar_t *w, char *s, int cap)
{
    WideCharToMultiByte(CP_UTF8, 0, w, -1, s, cap, NULL, NULL);
}

static FILE *fopen_utf8(const char *path, const char *mode)
{
    wchar_t w[4096], wm[16];
    utf8_to_wide(path, w, 4096);
    MultiByteToWideChar(CP_UTF8, 0, mode, -1, wm, 16);
    return _wfopen(w, wm);
}


/* 动态字符串缓冲 */
typedef struct { char *p; int n, cap; } SB;
static void sbPut(SB *sb, const char *fmt, ...)
{
    va_list ap;
    if (sb->p == NULL) { sb->cap = 1 << 16; sb->p = malloc(sb->cap); sb->n = 0; sb->p[0] = 0; }
    for (;;) {
        int left = sb->cap - sb->n;
        va_start(ap, fmt);
        int need = vsnprintf(sb->p + sb->n, left, fmt, ap);
        va_end(ap);
        if (need >= 0 && need < left) { sb->n += need; return; }
        sb->cap *= 2;
        sb->p = realloc(sb->p, sb->cap);
    }
}

/* UTF-8 解一个码点，*adv=字节数 */
static unsigned utf8cp(const char *s, int i, int *adv)
{
    unsigned char c = (unsigned char)s[i];
    unsigned cp = c; *adv = 1;
    if (c >= 0xF0) { cp = ((c&7)<<18)|((s[i+1]&63)<<12)|((s[i+2]&63)<<6)|(s[i+3]&63); *adv = 4; }
    else if (c >= 0xE0) { cp = ((c&15)<<12)|((s[i+1]&63)<<6)|(s[i+2]&63); *adv = 3; }
    else if (c >= 0xC0) { cp = ((c&31)<<6)|(s[i+1]&63); *adv = 2; }
    return cp;
}
static void utf8put(char *s, int *n, unsigned cp)
{
    if (cp < 0x80) s[(*n)++] = (char)cp;
    else if (cp < 0x800) { s[(*n)++] = (char)(0xC0|(cp>>6)); s[(*n)++] = (char)(0x80|(cp&63)); }
    else if (cp < 0x10000) { s[(*n)++] = (char)(0xE0|(cp>>12)); s[(*n)++] = (char)(0x80|((cp>>6)&63)); s[(*n)++] = (char)(0x80|(cp&63)); }
    else { s[(*n)++] = (char)(0xF0|(cp>>18)); s[(*n)++] = (char)(0x80|((cp>>12)&63)); s[(*n)++] = (char)(0x80|((cp>>6)&63)); s[(*n)++] = (char)(0x80|(cp&63)); }
}
static void utf8backspace(char *s)   /* 删最后一个码点 */
{
    int n = (int)strlen(s);
    while (n > 0 && ((unsigned char)s[n-1] & 0xC0) == 0x80) n--;
    if (n > 0) n--;
    s[n] = 0;
}
/* PYbook 字符串字面量转义 */
static void sbPyStr(SB *sb, const char *s)
{
    sbPut(sb, "\"");
    for (; *s; s++) {
        if (*s == '\\') sbPut(sb, "\\\\");
        else if (*s == '"') sbPut(sb, "\\\"");
        else sbPut(sb, "%c", *s);
    }
    sbPut(sb, "\"");
}
/* 场景名 → 文件名/函数名安全串 */
static void sanitize(const char *in, char *out, int cap)
{
    int j = 0;
    for (int i = 0; in[i] && j < cap - 3; ) {
        unsigned char c = (unsigned char)in[i];
        int adv;
        if (c < 0x80) {
            if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == '_')
                out[j++] = (char)c;
            else out[j++] = '_';
            adv = 1;
        } else {
            out[j++] = in[i]; adv = 1;
            while (adv < 4 && in[i+adv] && ((unsigned char)in[i+adv] & 0xC0) == 0x80)
                out[j++] = in[i + adv++];
        }
        i += adv;
    }
    while (j > 0 && out[j-1] == '_') j--;
    if (j == 0) { const char *fb = "场景"; while (*fb) out[j++] = *fb++; }
    out[j] = 0;
}

/* ============================ JSON 读 ============================ */

static char *J; static int Ji;
static void jSkip(void) { while (J[Ji]==' '||J[Ji]=='\t'||J[Ji]=='\n'||J[Ji]=='\r') Ji++; }
static int jEat(char c) { jSkip(); if (J[Ji]==c) { Ji++; return 1; } return 0; }
static int jStr(char *out, int cap)
{
    jSkip();
    if (J[Ji] != '"') return 0;
    Ji++;
    int n = 0;
    while (J[Ji] && J[Ji] != '"') {
        char c = J[Ji];
        if (c == '\\') {
            Ji++;
            char e = J[Ji];
            if (e == 'n') { if (n<cap-1) out[n++]='\n'; Ji++; }
            else if (e == 'u') {
                unsigned cp = 0;
                for (int k = 1; k <= 4; k++) { char h = J[Ji+k]; cp <<= 4;
                    cp |= (h<='9')?(h-'0'):((h|32)-'a'+10); }
                Ji += 5;
                if (cp >= 0xD800 && cp < 0xDC00 && J[Ji+1]=='\\') {  /* 代理对 */
                    unsigned lo = 0;
                    for (int k = 3; k <= 6; k++) { char h = J[Ji+k]; lo <<= 4;
                        lo |= (h<='9')?(h-'0'):((h|32)-'a'+10); }
                    cp = 0x10000 + ((cp-0xD800)<<10) + (lo-0xDC00);
                    Ji += 7;
                }
                if (n < cap-4) utf8put(out, &n, cp);
            }
            else { if (n<cap-1) out[n++]=e; Ji++; }
        } else { if (n<cap-1) out[n++]=c; Ji++; }
    }
    out[n] = 0;
    if (J[Ji]=='"') Ji++;
    return 1;
}
static int jInt(int *v)
{
    jSkip();
    if (J[Ji]=='t') { *v=1; Ji+=4; return 1; }
    if (J[Ji]=='f') { *v=0; Ji+=5; return 1; }
    char *end; long x = strtol(J+Ji, &end, 10);
    if (end == J+Ji) return 0;
    *v = (int)x; Ji = (int)(end - J);
    return 1;
}
static int jArrInt(int *a, int cap, int *cnt)
{
    *cnt = 0;
    if (!jEat('[')) return 0;
    jSkip();
    if (jEat(']')) return 1;
    for (;;) {
        int v; jInt(&v);
        if (*cnt < cap) a[(*cnt)++] = v;
        if (jEat(',')) continue;
        jEat(']');
        return 1;
    }
}

static void 场景读物(物 *o)
{
    物默认(o, 0);
    if (!jEat('{')) return;
    char key[64];
    for (;;) {
        jSkip();
        if (jEat('}')) return;
        jStr(key, sizeof key);
        jEat(':');
        if      (!strcmp(key, "名"))   jStr(o->名, sizeof o->名);
        else if (!strcmp(key, "形"))   jInt(&o->形);
        else if (!strcmp(key, "x"))    jInt(&o->x);
        else if (!strcmp(key, "y"))    jInt(&o->y);
        else if (!strcmp(key, "w"))    jInt(&o->w);
        else if (!strcmp(key, "h"))    jInt(&o->h);
        else if (!strcmp(key, "红"))   jInt(&o->红);
        else if (!strcmp(key, "绿"))   jInt(&o->绿);
        else if (!strcmp(key, "蓝"))   jInt(&o->蓝);
        else if (!strcmp(key, "文本")) jStr(o->文本, sizeof o->文本);
        else if (!strcmp(key, "字号")) jInt(&o->号);
        else if (!strcmp(key, "图片")) jStr(o->图, sizeof o->图);
        else if (!strcmp(key, "可见")) jInt(&o->可见);
        else if (!strcmp(key, "实"))   jInt(&o->实);
        else if (!strcmp(key, "跟"))   jInt(&o->跟);
        else { /* 跳过未知值 */ jSkip();
               if (J[Ji]=='"') { char d[512]; jStr(d, sizeof d); }
               else if (J[Ji]=='[') { int a[8], c; jArrInt(a, 8, &c); }
               else if (J[Ji]=='{') { int d = 0, depth = 1; Ji++;
                   while (J[Ji] && depth) { if (J[Ji]=='{') depth++; if (J[Ji]=='}') depth--; Ji++; } }
               else { int v; jInt(&v); }
        }
        jEat(',');
    }
}

static int 场景读(const char *path)
{
    FILE *fp = fopen_utf8(path, "rb");
    if (!fp) return 0;
    fseek(fp, 0, SEEK_END); long n = ftell(fp); fseek(fp, 0, SEEK_SET);
    char *buf = malloc(n + 1);
    fread(buf, 1, n, fp); buf[n] = 0;
    fclose(fp);
    /* 去 BOM */
    if ((unsigned char)buf[0]==0xEF && (unsigned char)buf[1]==0xBB && (unsigned char)buf[2]==0xBF)
        memmove(buf, buf+3, n-2);
    J = buf; Ji = 0;
    memset(&S.o, 0, sizeof S.o); S.n = 0;
    char key[64];
    for (;;) {
        jSkip();
        if (!J[Ji]) break;
        if (jEat('{')) {
            for (;;) {
                jSkip();
                if (jEat('}') || !J[Ji]) break;
                jStr(key, sizeof key);
                jEat(':');
                if      (!strcmp(key, "名")) jStr(S.名, sizeof S.名);
                else if (!strcmp(key, "宽")) jInt(&S.宽);
                else if (!strcmp(key, "高")) jInt(&S.高);
                else if (!strcmp(key, "背景")) { int a[4], c; jArrInt(a, 4, &c);
                    if (c >= 3) { S.bgR=a[0]; S.bgG=a[1]; S.bgB=a[2]; } }
                else if (!strcmp(key, "对象")) {
                    jSkip();
                    if (jEat('[')) {
                        jSkip();
                        if (!jEat(']')) {
                            for (;;) {
                                if (S.n < MAXOBJ) 场景读物(&S.o[S.n++]);
                                else 场景读物(&(物){0});
                                if (jEat(',')) continue;
                                jEat(']');
                                break;
                            }
                        }
                    }
                }
                else { jSkip();
                       if (J[Ji]=='"') { char d[512]; jStr(d, sizeof d); }
                       else { int v; if (!jInt(&v)) Ji++; } }
                jEat(',');
            }
        } else Ji++;
    }
    free(buf);
    for (int i = 0; i < S.n; i++) {
        if (S.o[i].形 == 4) { S.o[i].w = S.宽; S.o[i].h = S.高; }
        if (S.o[i].跟 >= S.n) S.o[i].跟 = -1;
    }
    snprintf(场景路径, sizeof 场景路径, "%s", path);
    return 1;
}

static void 场景写(const char *path)
{
    FILE *fp = fopen_utf8(path, "wb");
    if (!fp) return;
    fprintf(fp, "{\n \"名\": \"");
    for (char *c = S.名; *c; c++) { if (*c=='"'||*c=='\\') fputc('\\', fp); fputc(*c, fp); }
    fprintf(fp, "\",\n \"宽\": %d,\n \"高\": %d,\n \"背景\": [%d, %d, %d],\n \"对象\": [\n",
            S.宽, S.高, S.bgR, S.bgG, S.bgB);
    for (int i = 0; i < S.n; i++) {
        物 *o = &S.o[i];
        fprintf(fp, "  {\"名\": \"");
        for (char *c = o->名; *c; c++) { if (*c=='"'||*c=='\\') fputc('\\', fp); fputc(*c, fp); }
        fprintf(fp, "\", \"形\": %d, \"x\": %d, \"y\": %d, \"w\": %d, \"h\": %d, "
                    "\"红\": %d, \"绿\": %d, \"蓝\": %d, \"文本\": \"", 
                o->形, o->x, o->y, o->w, o->h, o->红, o->绿, o->蓝);
        for (char *c = o->文本; *c; c++) { if (*c=='"'||*c=='\\') fputc('\\', fp); fputc(*c, fp); }
        fprintf(fp, "\", \"字号\": %d, \"图片\": \"", o->号);
        for (char *c = o->图; *c; c++) { if (*c=='"'||*c=='\\') fputc('\\', fp); fputc(*c, fp); }
        fprintf(fp, "\", \"可见\": %s, \"实\": %d, \"跟\": %d}%s\n",
                o->可见 ? "true" : "false", o->实, o->跟, i+1 < S.n ? "," : "");
    }
    fprintf(fp, " ]\n}\n");
    fclose(fp);
    snprintf(场景路径, sizeof 场景路径, "%s", path);
}

/* ============================ 代码生成 ============================ */

static const char *列表名 = "形s, Xs, Ys, Ws, Hs, 红s, 绿s, 蓝s, 文s, 号s, 图s, 见s, 实s, 跟s";
static const char *位列表 = "形s, Xs, Ys, Ws, Hs";

static void 生成模块(SB *sb)
{
    char 基[128]; sanitize(S.名, 基, sizeof 基);
    sbPut(sb, "@ %s>场景模块>1\nMemoryment@self\n", 基);
    sbPut(sb, "# 本文件由 PYbook 场景编辑器(C 版)生成：数据列表 + 绘制 + 物理。\n");
    sbPut(sb, "# 场景 %dx%d；碰撞箱=包围盒；实s: 0无 1实体 2角色 3动态 4触发；跟s: 相机跟随下标。\n\n", S.宽, S.高);
    /* 十四个平行列表 */
    sbPut(sb, "vg.形s = [");
    for (int i = 0; i < S.n; i++) sbPut(sb, "%s%d", i?", ":"", S.o[i].形);
    sbPut(sb, "]\nvg.Xs = [");
    for (int i = 0; i < S.n; i++) sbPut(sb, "%s%d", i?", ":"", S.o[i].x);
    sbPut(sb, "]\nvg.Ys = [");
    for (int i = 0; i < S.n; i++) sbPut(sb, "%s%d", i?", ":"", S.o[i].y);
    sbPut(sb, "]\nvg.Ws = [");
    for (int i = 0; i < S.n; i++) sbPut(sb, "%s%d", i?", ":"", S.o[i].w);
    sbPut(sb, "]\nvg.Hs = [");
    for (int i = 0; i < S.n; i++) sbPut(sb, "%s%d", i?", ":"", S.o[i].h);
    sbPut(sb, "]\nvg.红s = [");
    for (int i = 0; i < S.n; i++) sbPut(sb, "%s%d", i?", ":"", S.o[i].红);
    sbPut(sb, "]\nvg.绿s = [");
    for (int i = 0; i < S.n; i++) sbPut(sb, "%s%d", i?", ":"", S.o[i].绿);
    sbPut(sb, "]\nvg.蓝s = [");
    for (int i = 0; i < S.n; i++) sbPut(sb, "%s%d", i?", ":"", S.o[i].蓝);
    sbPut(sb, "]\nvg.文s = [");
    for (int i = 0; i < S.n; i++) { if (i) sbPut(sb, ", "); sbPyStr(sb, S.o[i].文本); }
    sbPut(sb, "]\nvg.号s = [");
    for (int i = 0; i < S.n; i++) sbPut(sb, "%s%d", i?", ":"", S.o[i].号);
    sbPut(sb, "]\nvg.图s = [");
    for (int i = 0; i < S.n; i++) { if (i) sbPut(sb, ", "); sbPyStr(sb, S.o[i].图); }
    sbPut(sb, "]\nvg.见s = [");
    for (int i = 0; i < S.n; i++) sbPut(sb, "%s%d", i?", ":"", S.o[i].可见 ? 1 : 0);
    sbPut(sb, "]\nvg.实s = [");
    for (int i = 0; i < S.n; i++) sbPut(sb, "%s%d", i?", ":"", S.o[i].实);
    sbPut(sb, "]\nvg.跟s = [");
    for (int i = 0; i < S.n; i++) sbPut(sb, "%s%d", i?", ":"", S.o[i].跟);
    sbPut(sb, "]\n\n");
    /* 绘制 */
    sbPut(sb, "func %s_绘制(%s, 相机X, 相机Y) {\n", 基, 列表名);
    for (int i = 0; i < S.n; i++) {
        if (S.o[i].形 == 4) continue;
        sbPut(sb, "    if(见s[%d] == 1) {\n", i);
        sbPut(sb, "        if(形s[%d] == 0) {\n            color(红s[%d], 绿s[%d], 蓝s[%d])\n"
                  "            box(Xs[%d] - 相机X, Ys[%d] - 相机Y, Ws[%d], Hs[%d])\n        }\n",
              i, i, i, i, i, i, i, i);
        sbPut(sb, "        if(形s[%d] == 1) {\n            color(红s[%d], 绿s[%d], 蓝s[%d])\n"
                  "            圆(Xs[%d] - 相机X + Ws[%d] / 2, Ys[%d] - 相机Y + Hs[%d] / 2, Ws[%d] / 2)\n        }\n",
              i, i, i, i, i, i, i, i, i);
        sbPut(sb, "        if(形s[%d] == 2) {\n            color(红s[%d], 绿s[%d], 蓝s[%d])\n"
                  "            字(Xs[%d] - 相机X, Ys[%d] - 相机Y, 文s[%d], 号s[%d])\n        }\n",
              i, i, i, i, i, i, i);
        sbPut(sb, "        if(形s[%d] == 3) {\n            图缩(Xs[%d] - 相机X, Ys[%d] - 相机Y, Ws[%d], Hs[%d], 图s[%d])\n        }\n",
              i, i, i, i, i, i);
        sbPut(sb, "    }\n");
    }
    sbPut(sb, "}\n");
    /* 物理 */
    sbPut(sb, "func %s_物理(%s, 实s, 跟s, 左, 右, 上, 下) {\n", 基, 位列表);
    sbPut(sb, "    # 1) 角色键控移动 / 动态体重力\n    rm.around(%d) -> i {\n", S.n);
    sbPut(sb, "        if(实s[i] == 2) {\n"
              "            if(左 > 0) { Xs[i] = Xs[i] - 4 }\n"
              "            if(右 > 0) { Xs[i] = Xs[i] + 4 }\n"
              "            if(上 > 0) { Ys[i] = Ys[i] - 4 }\n"
              "            if(下 > 0) { Ys[i] = Ys[i] + 4 }\n        }\n");
    sbPut(sb, "        if(实s[i] == 3) {\n            Ys[i] = Ys[i] + 6\n        }\n    }\n");
    sbPut(sb, "    # 2) AABB 碰撞解算：角色/动态 推出 实体（沿穿透更小的轴）\n    rm.around(%d) -> i {\n", S.n);
    sbPut(sb, "        if(实s[i] == 2 or 实s[i] == 3) {\n            rm.around(%d) -> j {\n", S.n);
    sbPut(sb, "                if(实s[j] == 1) {\n"
              "                    vg.ax = Xs[i]\n                    if(Xs[j] > ax) { ax = Xs[j] }\n"
              "                    vg.bx = Xs[i] + Ws[i]\n                    if(Xs[j] + Ws[j] < bx) { bx = Xs[j] + Ws[j] }\n"
              "                    vg.叠x = bx - ax\n"
              "                    vg.ay = Ys[i]\n                    if(Ys[j] > ay) { ay = Ys[j] }\n"
              "                    vg.by = Ys[i] + Hs[i]\n                    if(Ys[j] + Hs[j] < by) { by = Ys[j] + Hs[j] }\n"
              "                    vg.叠y = by - ay\n"
              "                    if(叠x > 0 and 叠y > 0) {\n"
              "                        if(叠x < 叠y) {\n"
              "                            if(Xs[i] + Ws[i] / 2 < Xs[j] + Ws[j] / 2) {\n"
              "                                Xs[i] = Xs[i] - 叠x\n                            } else {\n"
              "                                Xs[i] = Xs[i] + 叠x\n                            }\n"
              "                        } else {\n"
              "                            if(Ys[i] + Hs[i] / 2 < Ys[j] + Hs[j] / 2) {\n"
              "                                Ys[i] = Ys[i] - 叠y\n                            } else {\n"
              "                                Ys[i] = Ys[i] + 叠y\n                            }\n"
              "                        }\n                    }\n                }\n            }\n        }\n    }\n");
    sbPut(sb, "    # 3) 相机：跟随第一个设置了 跟 的相机节点，否则 (0,0)\n    vg.cx = 0\n    vg.cy = 0\n");
    sbPut(sb, "    rm.around(%d) -> i {\n        if(跟s[i] >= 0 and 跟s[i] < %d) {\n", S.n, S.n);
    sbPut(sb, "            vg.t = 跟s[i]\n            cx = Xs[t] + Ws[t] / 2 - %d / 2\n", S.宽);
    sbPut(sb, "            cy = Ys[t] + Hs[t] / 2 - %d / 2\n        }\n    }\n", S.高);
    sbPut(sb, "    ret [cx, cy]\n}\n");
}

static void 生成预览(SB *sb)
{
    char 基[128]; sanitize(S.名, 基, sizeof 基);
    sbPut(sb, "@ %s>预览>1\n\n引用(\"%s_场景\")\n\nwindow(normal, open)\n\nGOING:{\n", 基, 基);
    sbPut(sb, "    win(%d, %d, \"PYbook 预览 · %s\")\n", S.宽, S.高, S.名);
    sbPut(sb, "    vg.左 = 0\n    vg.右 = 0\n    vg.上 = 0\n    vg.下 = 0\n");
    sbPut(sb, "    if(key(\"a\") or key(\"left\")) { 左 = 1 }\n");
    sbPut(sb, "    if(key(\"d\") or key(\"right\")) { 右 = 1 }\n");
    sbPut(sb, "    if(key(\"w\") or key(\"up\")) { 上 = 1 }\n");
    sbPut(sb, "    if(key(\"s\") or key(\"down\")) { 下 = 1 }\n");
    sbPut(sb, "    vg.相机 = %s_物理(形s, Xs, Ys, Ws, Hs, 实s, 跟s, 左, 右, 上, 下)\n", 基);
    sbPut(sb, "    color(%d, %d, %d)\n    clear()\n", S.bgR, S.bgG, S.bgB);
    sbPut(sb, "    vg.画 = %s_绘制(%s, 相机[0], 相机[1])\n}STOP\n", 基, 列表名);
}

/* ============================ 字体 ============================ */

static void 启动记(const char *fmt, ...);
static FILE *启动日志 = NULL;
static void 启动记(const char *fmt, ...)
{
    if (!启动日志) {
        启动日志 = fopen_utf8("编辑器启动.log", "wb");
        if (!启动日志) return;
    }
    va_list ap;
    va_start(ap, fmt);
    vfprintf(启动日志, fmt, ap);
    va_end(ap);
    fflush(启动日志);
}
static void 致命(const char *what, const char *err)
{
    启动记("致命: %s: %s\n", what, err ? err : "");
    MessageBoxA(NULL, err ? err : what, what, MB_ICONERROR);
    exit(1);
}

static stbtt_fontinfo g_ttf;
static int g_ttf_ok = 0;
static int g_ascent = 0;

static void font_init(void)
{
    if (g_ttf_ok) return;   /* 只加载一次（漏了这行 = 每次画字泄漏 19MB 字体数据） */
    static const char *CAND[] = {
        "C:\\Windows\\Fonts\\msyh.ttc", "C:\\Windows\\Fonts\\msyh.ttf",
        "C:\\Windows\\Fonts\\simhei.ttf", "C:\\Windows\\Fonts\\simsun.ttc",
    };
    for (int i = 0; i < 4; i++) {
        FILE *fp = fopen_utf8(CAND[i], "rb");
        if (!fp) continue;
        fseek(fp, 0, SEEK_END); long n = ftell(fp); fseek(fp, 0, SEEK_SET);
        unsigned char *data = malloc(n);
        if (data && fread(data, 1, n, fp) == (size_t)n) {
            int off = stbtt_GetFontOffsetForIndex(data, 0);
            if (off >= 0 && stbtt_InitFont(&g_ttf, data, off)) {
                g_ttf_ok = 1; fclose(fp);
                int a, d, g;
                stbtt_GetFontVMetrics(&g_ttf, &a, &d, &g);
                g_ascent = a;
                return;
            }
        }
        free(data); fclose(fp);
    }
    致命("找不到中文字体", "系统字体目录缺 msyh/simhei/simsun");
}

/* ============================ 渲染 ============================ */

static SDL_Window *win;
static SDL_Renderer *ren;

#define GLYPH_MAX 4096
typedef struct { unsigned cp; int px; SDL_Texture *tex; int bw, bh, ox, oy, adv; } Glyph;
static Glyph GL[GLYPH_MAX];
static int GLn = 0;

static Glyph *glyph_get(unsigned cp, int px)
{
    for (int i = 0; i < GLn; i++)
        if (GL[i].cp == cp && GL[i].px == px) return &GL[i];
    if (GLn >= GLYPH_MAX) { GLn = GLYPH_MAX / 2; }   /* 粗暴重置 */
    Glyph *G = &GL[GLn];
    float scale = stbtt_ScaleForPixelHeight(&g_ttf, (float)px);
    int bw, bh, ox, oy;
    unsigned char *bmp = stbtt_GetCodepointBitmap(&g_ttf, scale, scale, (int)cp, &bw, &bh, &ox, &oy);
    int a, d, gap;
    stbtt_GetFontVMetrics(&g_ttf, &a, &d, &gap);
    G->cp = cp; G->px = px; G->bw = bw; G->bh = bh; G->ox = ox; G->oy = oy;
    int adv, lsb;
    stbtt_GetCodepointHMetrics(&g_ttf, (int)cp, &adv, &lsb);
    G->adv = (int)(adv * scale + 0.5f);
    G->tex = SDL_CreateTexture(ren, SDL_PIXELFORMAT_ARGB8888, SDL_TEXTUREACCESS_STATIC,
                               bw > 0 ? bw : 1, bh > 0 ? bh : 1);
    SDL_SetTextureBlendMode(G->tex, SDL_BLENDMODE_BLEND);
    if (bmp) {
        unsigned *pxs = malloc(sizeof(unsigned) * (size_t)(bw > 0 ? bw : 1) * (bh > 0 ? bh : 1));
        for (int y = 0; y < bh; y++)
            for (int x = 0; x < bw; x++)
                pxs[y * bw + x] = ((unsigned)bmp[y * bw + x] << 24) | 0x00FFFFFFu;
        SDL_UpdateTexture(G->tex, NULL, pxs, (bw > 0 ? bw : 1) * 4);
        free(pxs);
        stbtt_FreeBitmap(bmp, NULL);
    }
    GLn++;
    return G;
}

static int text_宽(const char *s, int px)
{
    float scale = stbtt_ScaleForPixelHeight(&g_ttf, (float)px);
    int w = 0;
    for (int i = 0; s[i]; ) {
        int adv; unsigned cp = utf8cp(s, i, &adv);
        int a, l; stbtt_GetCodepointHMetrics(&g_ttf, (int)cp, &a, &l);
        w += (int)(a * scale + 0.5f);
        i += adv;
    }
    return w;
}

static void text(int x, int y, const char *s, int px, int r, int g, int b)
{
    if (!g_ttf_ok) return;
    font_init();
    float scale = stbtt_ScaleForPixelHeight(&g_ttf, (float)px);
    int asc, d, gap;
    stbtt_GetFontVMetrics(&g_ttf, &asc, &d, &gap);
    int base = y + (int)(asc * scale + 0.5f);
    for (int i = 0; s[i]; ) {
        int adv; unsigned cp = utf8cp(s, i, &adv);
        Glyph *G = glyph_get(cp, px);
        if (G->bw > 0 && G->bh > 0) {
            SDL_Rect dst = { x + G->ox, base + G->oy, G->bw, G->bh };
            SDL_SetTextureColorMod(G->tex, r, g, b);
            SDL_RenderCopy(ren, G->tex, NULL, &dst);
        }
        x += G->adv;
        i += adv;
    }
}

static void fill_rect(int x, int y, int w, int h, int r, int g, int b)
{
    SDL_SetRenderDrawColor(ren, r, g, b, 255);
    SDL_Rect rc = { x, y, w, h };
    SDL_RenderFillRect(ren, &rc);
}
static void stroke_rect(int x, int y, int w, int h, int r, int g, int b)
{
    SDL_SetRenderDrawColor(ren, r, g, b, 255);
    SDL_Rect rc = { x, y, w, h };
    SDL_RenderDrawRect(ren, &rc);
}
static void fill_circle(int cx, int cy, int r, int R, int G, int B)
{
    SDL_SetRenderDrawColor(ren, R, G, B, 255);
    for (int dy = -r; dy <= r; dy++) {
        int dx = (int)sqrt((double)r * r - (double)dy * dy);
        SDL_RenderDrawLine(ren, cx - dx, cy + dy, cx + dx, cy + dy);
    }
}
static void dash_rect(int x, int y, int w, int h, int R, int G, int B)
{
    SDL_SetRenderDrawColor(ren, R, G, B, 255);
    for (int i = 0; i < w; i += 10) { SDL_RenderDrawLine(ren, x+i, y, x+i+5 < x+w ? x+i+5 : x+w, y);
                                     SDL_RenderDrawLine(ren, x+i, y+h, x+i+5 < x+w ? x+i+5 : x+w, y+h); }
    for (int i = 0; i < h; i += 10) { SDL_RenderDrawLine(ren, x, y+i, x, y+i+5 < y+h ? y+i+5 : y+h);
                                     SDL_RenderDrawLine(ren, x+w, y+i, x+w, y+i+5 < y+h ? y+i+5 : y+h); }
}

/* ---- 图片纹理缓存 ---- */
#define IMGMAX 64
typedef struct { char path[260]; SDL_Texture *tex; int w, h; } ImgTex;
static ImgTex IMG[IMGMAX];
static SDL_Texture *img_get(const char *path, int *w, int *h)
{
    for (int i = 0; i < IMGMAX; i++)
        if (IMG[i].tex && !strcmp(IMG[i].path, path)) { *w = IMG[i].w; *h = IMG[i].h; return IMG[i].tex; }
    for (int i = 0; i < IMGMAX; i++) {
        if (!IMG[i].tex) {
            int cw, ch, cn;
            unsigned char *data = stbi_load(path, &cw, &ch, &cn, 4);
            if (!data) { *w = *h = 0; return NULL; }
            SDL_Texture *t = SDL_CreateTexture(ren, SDL_PIXELFORMAT_ABGR8888,
                                               SDL_TEXTUREACCESS_STATIC, cw, ch);
            SDL_UpdateTexture(t, NULL, data, cw * 4);
            SDL_SetTextureBlendMode(t, SDL_BLENDMODE_BLEND);
            stbi_image_free(data);
            snprintf(IMG[i].path, sizeof IMG[i].path, "%s", path);
            IMG[i].tex = t; IMG[i].w = cw; IMG[i].h = ch;
            *w = cw; *h = ch;
            return t;
        }
    }
    *w = *h = 0; return NULL;
}

/* ============================ UI 状态 ============================ */

#define WINW 1280
#define WINH 760
#define 工具栏H 34
#define 状态栏H 24
#define 面板L 200
#define 面板R 230

static double 缩放 = 1.0;
static int 视ox = 0, 视oy = 0;
static int 视X, 视Y, 视W, 视H;             /* 视口区域 */
static int 鼠x, 鼠y, 鼠按, 鼠右按;
static int 拖下标 = -1, 拖dx, 拖dy;
static int 拖平移x, 拖平移y, 平移基准x, 平移基准y;
static int 焦点域 = 0;                      /* 0 无 / 属性域 100+ */
static int 跟随下拉开 = 0;
static int 弹窗 = 0;                        /* 0 无 / 1 场景设置 */
static char 状态栏[256] = "就绪";
static int 需适配 = 1;

static void 状态(const char *fmt, ...)
{
    va_list ap; va_start(ap, fmt);
    vsnprintf(状态栏, sizeof 状态栏, fmt, ap);
    va_end(ap);
}

/* 属性编辑缓冲（编辑即生效） */
typedef struct {
    char 名[64], 文本[256], 图[260];
    char x[16], y[16], w[16], h[16], 红[8], 绿[8], 蓝[8], 号[8];
} 属性缓冲;
static 属性缓冲 PB;
static int PB选中 = -2;    /* 上次同步的选中下标 */

static void PB同步(void)
{
    if (选中 < 0 || 选中 >= S.n) { PB选中 = 选中; return; }
    if (PB选中 == 选中) return;
    PB选中 = 选中;
    物 *o = &S.o[选中];
    snprintf(PB.名, sizeof PB.名, "%s", o->名);
    snprintf(PB.文本, sizeof PB.文本, "%s", o->文本);
    snprintf(PB.图, sizeof PB.图, "%s", o->图);
    snprintf(PB.x, sizeof PB.x, "%d", o->x);
    snprintf(PB.y, sizeof PB.y, "%d", o->y);
    snprintf(PB.w, sizeof PB.w, "%d", o->w);
    snprintf(PB.h, sizeof PB.h, "%d", o->h);
    snprintf(PB.红, sizeof PB.红, "%d", o->红);
    snprintf(PB.绿, sizeof PB.绿, "%d", o->绿);
    snprintf(PB.蓝, sizeof PB.蓝, "%d", o->蓝);
    snprintf(PB.号, sizeof PB.号, "%d", o->号);
}

static int 属性数(const char *s, int 旧, int 最小, int 最大)
{
    int v = 0, ok = 0;
    if (sscanf(s, "%d", &v) == 1) ok = 1;
    if (!ok) return 旧;
    if (v < 最小) v = 最小;
    if (v > 最大) v = 最大;
    return v;
}

/* ============================ 播放 ============================ */

static HANDLE 播放进程 = NULL;

static void 目录拼接(const char *基, char *out, int cap)
{
    char 目录[MAX_PATH * 3];
    if (场景路径[0]) {
        snprintf(目录, sizeof 目录, "%s", 场景路径);
        char *q = strrchr(目录, '/');
        char *q2 = strrchr(目录, '\\');
        if (q2 > q) q = q2;
        if (q) *q = 0; else snprintf(目录, sizeof 目录, ".");
        snprintf(out, cap, "%s\\%s", 目录, 基);
    } else {
        snprintf(out, cap, "%s", 基);
    }
}

static void 写文件UTF8(const char *path, const char *data)
{
    FILE *fp = fopen_utf8(path, "wb");
    if (!fp) return;
    fputs(data, fp);
    fclose(fp);
}

static void 播放(void)
{
    if (!场景路径[0]) {
        MessageBoxA(NULL, "先保存场景再播放（工具栏 · 保存）", "播放", MB_ICONINFORMATION);
        return;
    }
    场景写(场景路径);
    char 基[128]; sanitize(S.名, 基, sizeof 基);
    char 目录[MAX_PATH * 3];
    snprintf(目录, sizeof 目录, "%s", 场景路径);
    {
        char *q = strrchr(目录, '/');
        char *q2 = strrchr(目录, '\\');
        if (q2 > q) q = q2;
        if (q) *q = 0; else strcpy(目录, ".");
    }
    char 模块p[MAX_PATH * 3], 预览p[MAX_PATH * 3], 日志p[MAX_PATH * 3];
    snprintf(模块p, sizeof 模块p, "%s\\%s_场景.pybk", 目录, 基);
    snprintf(预览p, sizeof 预览p, "%s\\%s_预览.pybk", 目录, 基);
    snprintf(日志p, sizeof 日志p, "%s\\%s_预览_运行.log", 目录, 基);
    SB m = {0}, p = {0};
    生成模块(&m); 生成预览(&p);
    写文件UTF8(模块p, m.p);
    写文件UTF8(预览p, p.p);
    free(m.p); free(p.p);

    /* 找 python（PATH 优先，退回常见安装路径） */
    wchar_t wpy[MAX_PATH];
    char py[MAX_PATH * 3];
    if (SearchPathW(NULL, L"python.exe", NULL, MAX_PATH, wpy, NULL) == 0)
        wide_to_utf8(L"C:\\Users\\zhuli\\AppData\\Local\\Programs\\Python\\Python311\\python.exe",
                     py, sizeof py);
    else wide_to_utf8(wpy, py, sizeof py);

    char cwd[MAX_PATH * 3];
    GetModuleFileNameA(NULL, cwd, sizeof cwd);
    { char *slash = strrchr(cwd, '\\'); if (slash) *slash = 0; }

    char cmd[MAX_PATH * 6];
    snprintf(cmd, sizeof cmd, "\"%s\" \"%s\\pybk_main.py\" \"%s\"", py, cwd, 预览p);
    wchar_t wcmd[MAX_PATH * 6], wcwd[MAX_PATH * 3], wlog[MAX_PATH * 3];
    utf8_to_wide(cmd, wcmd, MAX_PATH * 6);
    utf8_to_wide(cwd, wcwd, MAX_PATH * 3);
    utf8_to_wide(日志p, wlog, MAX_PATH * 3);

    SECURITY_ATTRIBUTES sa = { sizeof sa, NULL, TRUE };
    HANDLE logh = CreateFileW(wlog, FILE_APPEND_DATA, FILE_SHARE_READ,
                              &sa, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    STARTUPINFOW si; memset(&si, 0, sizeof si);
    si.cb = sizeof si;
    si.dwFlags = STARTF_USESTDHANDLES;
    si.hStdOutput = logh; si.hStdError = logh;
    PROCESS_INFORMATION pi;
    if (CreateProcessW(NULL, wcmd, NULL, NULL, TRUE,
                       CREATE_NEW_PROCESS_GROUP | CREATE_NO_WINDOW,
                       NULL, wcwd, &si, &pi)) {
        if (播放进程) { TerminateProcess(播放进程, 0); CloseHandle(播放进程); }
        播放进程 = pi.hProcess;
        CloseHandle(pi.hThread);
        状态("真机播放中：%s_预览.pybk（引擎窗口稍后弹出）", 基);
    } else {
        状态("启动失败：找不到 python（错误 %lu）", (unsigned long)GetLastError());
    }
    if (logh) CloseHandle(logh);
}

static void 停止(void)
{
    if (播放进程) {
        TerminateProcess(播放进程, 0);
        CloseHandle(播放进程);
        播放进程 = NULL;
        状态("已停止");
    }
}

/* ============================ 文件对话框 ============================ */

static int 对话框打开(char *out, int cap)
{
    wchar_t f[MAX_PATH] = L"";
    OPENFILENAMEW ofn; memset(&ofn, 0, sizeof ofn);
    ofn.lStructSize = sizeof ofn;
    ofn.hwndOwner = GetActiveWindow();
    ofn.lpstrFilter = L"PYbook \x573A\x666F\0*.scene\0\0";
    ofn.lpstrFile = f; ofn.nMaxFile = MAX_PATH;
    ofn.Flags = OFN_FILEMUSTEXIST;
    if (!GetOpenFileNameW(&ofn)) return 0;
    wide_to_utf8(f, out, cap);
    return 1;
}
static int 对话框保存(char *out, int cap, const char *默认名)
{
    wchar_t f[MAX_PATH] = L"";
    wchar_t wdef[128];
    utf8_to_wide(默认名, wdef, 128);
    wcscpy(f, wdef);
    OPENFILENAMEW ofn; memset(&ofn, 0, sizeof ofn);
    ofn.lStructSize = sizeof ofn;
    ofn.hwndOwner = GetActiveWindow();
    ofn.lpstrFilter = L"PYbook \x573A\x666F\0*.scene\0\0";
    ofn.lpstrFile = f; ofn.nMaxFile = MAX_PATH;
    ofn.lpstrDefExt = L".scene";
    ofn.Flags = OFN_OVERWRITEPROMPT;
    if (!GetSaveFileNameW(&ofn)) return 0;
    wide_to_utf8(f, out, cap);
    return 1;
}

/* ============================ 操作 ============================ */

static void 适配(void) { 需适配 = 1; }

static void 保存场景(void)
{
    if (!场景路径[0]) {
        char out[MAX_PATH * 3];
        char 默认[128]; sanitize(S.名, 默认, sizeof 默认);
        strcat(默认, ".scene");
        if (!对话框保存(out, sizeof out, 默认)) return;
        场景写(out);
        状态("已保存 %s", out);
    } else {
        场景写(场景路径);
        状态("已保存 %s", 场景路径);
    }
}

static void 打开场景(const char *path)
{
    if (场景读(path)) {
        选中 = -1; PB选中 = -2; 适配();
        状态("已打开 %s", path);
    } else 状态("打开失败：%s", path);
}

static void 加对象(int 形)
{
    if (S.n >= MAXOBJ) return;
    物 o; 物默认(&o, 形);
    if (形 != 4) {
        o.x = (int)((视X + 视W / 2.0 - 视ox) / 缩放 - o.w / 2.0);
        o.y = (int)((视Y + 视H / 2.0 - 视oy) / 缩放 - o.h / 2.0);
    }
    S.o[S.n++] = o;
    选中 = S.n - 1; PB选中 = -2;
}

static void 删除选中(void)
{
    if (选中 < 0) return;
    memmove(&S.o[选中], &S.o[选中 + 1], sizeof(物) * (S.n - 选中 - 1));
    S.n--;
    for (int i = 0; i < S.n; i++) {
        if (S.o[i].跟 == 选中) S.o[i].跟 = -1;
        else if (S.o[i].跟 > 选中) S.o[i].跟--;
    }
    选中 = -1; PB选中 = -2;
}

static void 复制选中(void)
{
    if (选中 < 0 || S.n >= MAXOBJ) return;
    物 o = S.o[选中];
    o.x += 20; o.y += 20;
    memmove(&S.o[选中 + 2], &S.o[选中 + 1], sizeof(物) * (S.n - 选中 - 1));
    S.o[选中 + 1] = o;
    S.n++;
    选中++; PB选中 = -2;
}

static void 移层级(int dir)
{
    if (选中 < 0) return;
    int j = 选中 + dir;
    if (j < 0 || j >= S.n) return;
    物 t = S.o[选中]; S.o[选中] = S.o[j]; S.o[j] = t;
    for (int k = 0; k < S.n; k++) {   /* 跟随下标同步换位 */
        if (S.o[k].跟 == 选中) S.o[k].跟 = j;
        else if (S.o[k].跟 == j) S.o[k].跟 = 选中;
    }
    选中 = j; PB选中 = -2;
}

static void 微调(int dx, int dy, int 步)
{
    if (选中 < 0) return;
    S.o[选中].x += dx * 步;
    S.o[选中].y += dy * 步;
    PB选中 = -2;
}

/* ============================ 面板渲染 ============================ */

static int ui按钮(int x, int y, int w, int h, const char *label, int 加粗)
{
    int hot = 鼠x >= x && 鼠x < x+w && 鼠y >= y && 鼠y < y+h;
    fill_rect(x, y, w, h, hot ? 64 : 45, hot ? 64 : 45, hot ? 90 : 58);
    stroke_rect(x, y, w, h, 90, 92, 110);
    int tw = text_宽(label, 14);
    text(x + (w - tw) / 2, y + (h - 16) / 2, label, 14, 232, 232, 240);
    int 点击 = hot && 鼠按;
    if (hot && 鼠按) 鼠按 = 0;    /* 吃掉点击 */
    return 点击;
}

/* 当前焦点文本域的缓冲（SDL_TEXTINPUT 写入目标） */
static char *编辑buf = NULL;
static int 编辑cap = 0;

static int ui文本域(int id, int x, int y, int w, int h, char *buf, int cap)
{
    int hot = 鼠x >= x && 鼠x < x+w && 鼠y >= y && 鼠y < y+h;
    int 有焦点 = (焦点域 == id);
    fill_rect(x, y, w, h, 20, 20, 28);
    stroke_rect(x, y, w, h, 有焦点 ? 126 : 51, 有焦点 ? 200 : 51, 有焦点 ? 255 : 74);
    text(x + 4, y + (h - 15) / 2, buf[0] ? buf : " ", 12, 240, 240, 248);
    if (有焦点) {   /* 光标闪烁 */
        if ((SDL_GetTicks() / 500) % 2 == 0) {
            int tw = text_宽(buf, 12);
            fill_rect(x + 5 + tw, y + 4, 1, h - 8, 240, 240, 248);
        }
    }
    if (hot && 鼠按) {
        焦点域 = id; 编辑buf = buf; 编辑cap = cap;
        鼠按 = 0;
    }
    if (!hot && 鼠按 && 有焦点) { 焦点域 = 0; 编辑buf = NULL; }
    return 有焦点;
}

static void ui标签(int x, int y, const char *s) { text(x, y, s, 12, 184, 189, 208); }

/* ============================ 主循环 ============================ */

static void 画场景视口(void);
static void 画面板(void);

static void 场景设置弹窗(void);

static LONG WINAPI 崩溃记(EXCEPTION_POINTERS *ep)
{
    (void)ep;
    启动记("崩溃：异常代码 %lx\n", ep ? (unsigned long)ep->ExceptionRecord->ExceptionCode : 0);
    return EXCEPTION_CONTINUE_SEARCH;
}

int main(int argc, char **argv)
{
    /* 命令行中文：从宽字符命令行重取（ANSI argv 在中文 Windows 上是 GBK 字节） */
    {
        static char argb[8][4096];
        int wargc = 0;
        wchar_t **wargv = CommandLineToArgvW(GetCommandLineW(), &wargc);
        if (wargv) {
            for (int i = 0; i < wargc && i < 8; i++) {
                wide_to_utf8(wargv[i], argb[i], 4096);
                argv[i] = argb[i];
            }
            LocalFree(wargv);
        }
    }
    SetUnhandledExceptionFilter(崩溃记);
    启动记("编辑器启动…\n");
    SDL_SetMainReady();
    if (SDL_Init(SDL_INIT_VIDEO) != 0)
        致命("SDL 初始化失败", SDL_GetError());
    启动记("SDL ok\n");
    win = SDL_CreateWindow("PYbook 场景编辑器",
                           SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
                           WINW, WINH, SDL_WINDOW_SHOWN | SDL_WINDOW_RESIZABLE);
    if (!win) 致命("创建窗口失败", SDL_GetError());
    启动记("窗口 ok\n");
    ren = SDL_CreateRenderer(win, -1, SDL_RENDERER_SOFTWARE);   /* 纯软件渲染：稳定、可截取 */
    if (!ren) 致命("创建渲染器失败", SDL_GetError());
    SDL_SetRenderDrawBlendMode(ren, SDL_BLENDMODE_NONE);
    SDL_StartTextInput();
    启动记("渲染器 ok\n");
    font_init();

    strcpy(S.名, "我的场景");
    S.宽 = 800; S.高 = 500; S.bgR = 16; S.bgG = 18; S.bgB = 26;
    if (argc > 2 && (!strcmp(argv[1], "-p") || !strcmp(argv[1], "/p"))) {
        /* 命令行直接播放: editor.exe -p 场景.scene（保存+生成+真机一条龙） */
        if (!场景读(argv[2])) {
            MessageBoxA(NULL, argv[2], "找不到场景", MB_ICONERROR);
            return 1;
        }
        场景写(argv[2]);
        {
            char 基[128]; sanitize(S.名, 基, sizeof 基);
            char 目录[MAX_PATH * 3];
            snprintf(目录, sizeof 目录, "%s", argv[2]);
            { char *q = strrchr(目录, '/'); char *q2 = strrchr(目录, 92);
              if (q2 > q) q = q2; if (q) *q = 0; else strcpy(目录, "."); }
            char 模块p[MAX_PATH * 3], 预览p[MAX_PATH * 3];
            snprintf(模块p, sizeof 模块p, "%s%c%s_场景.pybk", 目录, 92, 基);
            snprintf(预览p, sizeof 预览p, "%s%c%s_预览.pybk", 目录, 92, 基);
            SB m = {0}, p = {0};
            生成模块(&m); 生成预览(&p);
            写文件UTF8(模块p, m.p); 写文件UTF8(预览p, p.p);
            free(m.p); free(p.p);
        }
        播放进程 = NULL;
        播放();
        Sleep(1500);
        return 0;
    }
    if (argc > 1) { 打开场景(argv[1]); 启动记("场景已加载 %s\n", argv[1]); }
    启动记("进入主循环\n");

    int run = 1;
    while (run) {
        /* ---- 事件 ---- */
        鼠按 = 0;
        int wheel = 0;
        SDL_Event e;
        while (SDL_PollEvent(&e)) {
            switch (e.type) {
            case SDL_QUIT: run = 0; break;
            case SDL_MOUSEBUTTONDOWN:
                if (e.button.button == SDL_BUTTON_LEFT) 鼠按 = 1;
                if (e.button.button == SDL_BUTTON_RIGHT) 鼠右按 = 1;
                break;
            case SDL_MOUSEBUTTONUP:
                if (e.button.button == SDL_BUTTON_LEFT) { 拖下标 = -1; }
                if (e.button.button == SDL_BUTTON_RIGHT) 鼠右按 = 0;
                break;
            case SDL_MOUSEMOTION:
                鼠x = e.motion.x; 鼠y = e.motion.y;
                if (鼠右按) { 视ox = 拖平移x + (鼠x - 平移基准x); 视oy = 拖平移y + (鼠y - 平移基准y); }
                if (拖下标 >= 0) {
                    S.o[拖下标].x = (int)((鼠x - 视ox) / 缩放) - 拖dx;
                    S.o[拖下标].y = (int)((鼠y - 视oy) / 缩放) - 拖dy;
                    PB选中 = -2;
                }
                break;
            case SDL_MOUSEWHEEL:
                wheel = e.wheel.y;
                break;
            case SDL_KEYDOWN: {
                int 编辑中 = 焦点域 != 0;
                if (编辑中 && e.key.keysym.sym == SDLK_BACKSPACE && 编辑buf) {
                    utf8backspace(编辑buf);
                    break;
                }
                if (编辑中 && e.key.keysym.sym == SDLK_RETURN) {
                    焦点域 = 0; 编辑buf = NULL;
                    break;
                }
                if (e.key.keysym.sym == SDLK_ESCAPE) {
                    焦点域 = 0; 编辑buf = NULL; 跟随下拉开 = 0;
                    break;
                }
                if (!编辑中 && 选中 >= 0) {
                    switch (e.key.keysym.sym) {
                    case SDLK_DELETE: 删除选中(); break;
                    case SDLK_LEFT:  微调(-1, 0, e.key.keysym.mod & KMOD_SHIFT ? 10 : 1); break;
                    case SDLK_RIGHT: 微调( 1, 0, e.key.keysym.mod & KMOD_SHIFT ? 10 : 1); break;
                    case SDLK_UP:    微调(0, -1, e.key.keysym.mod & KMOD_SHIFT ? 10 : 1); break;
                    case SDLK_DOWN:  微调(0,  1, e.key.keysym.mod & KMOD_SHIFT ? 10 : 1); break;
                    }
                    if ((e.key.keysym.mod & KMOD_LCTRL) && e.key.keysym.sym == SDLK_d)
                        复制选中();
                }
                break;
            }
            case SDL_TEXTINPUT:
                if (编辑buf) {
                    int len = (int)strlen(编辑buf);
                    int add = (int)strlen(e.text.text);
                    if (len + add < 编辑cap) {
                        memcpy(编辑buf + len, e.text.text, add + 1);
                    }
                }
                break;
            }
        }

        int winw, winh;
        SDL_GetRendererOutputSize(ren, &winw, &winh);
        if (winw != WINW || winh != WINH) { /* 窗口被拉大：用缩放渲染 */ }
        视X = 面板L; 视Y = 工具栏H;
        视W = winw - 面板L - 面板R; 视H = winh - 工具栏H - 状态栏H;

        if (wheel) {
            double 系数 = wheel > 0 ? 1.15 : 1 / 1.15;
            double 新z = 缩放 * 系数;
            if (新z < 0.1) 新z = 0.1;
            if (新z > 4) 新z = 4;
            double 实际 = 新z / 缩放;
            视ox = (int)(鼠x - (鼠x - 视ox) * 实际);
            视oy = (int)(鼠y - (鼠y - 视oy) * 实际);
            缩放 = 新z;
        }
        if (需适配) {
            需适配 = 0;
            double z1 = (视W - 80.0) / S.宽, z2 = (视H - 80.0) / S.高;
            缩放 = z1 < z2 ? z1 : z2;
            if (缩放 > 2) 缩放 = 2;
            if (缩放 < 0.1) 缩放 = 0.1;
            视ox = (int)(视X + (视W - S.宽 * 缩放) / 2);
            视oy = (int)(视Y + (视H - S.高 * 缩放) / 2);
        }

        /* ---- 视口按下拾取（在绘制前处理，简单可靠） ---- */
        if (鼠按 && 鼠x >= 视X && 鼠x < 视X+视W && 鼠y >= 视Y && 鼠y < 视Y+视H && 焦点域 == 0) {
            double wx = (鼠x - 视ox) / 缩放, wy = (鼠y - 视oy) / 缩放;
            选中 = -1;
            for (int i = S.n - 1; i >= 0; i--) {
                物 *o = &S.o[i];
                if (wx >= o->x && wx <= o->x + o->w && wy >= o->y && wy <= o->y + o->h) {
                    选中 = i; PB选中 = -2; 跟随下拉开 = 0;
                    拖下标 = i;
                    拖dx = (int)wx - o->x; 拖dy = (int)wy - o->y;
                    break;
                }
            }
            鼠按 = 0;
        }
        if (鼠右按 && 拖平移x == 0 && 拖平移y == 0) { 平移基准x = 鼠x; 平移基准y = 鼠y; 拖平移x = 视ox; 拖平移y = 视oy; }
        if (!鼠右按) { 拖平移x = 0; 拖平移y = 0; }

        /* ---- 窗口被遮挡/cloak（不被人看到）时跳帧：不渲染不提交 ---- */
        {
            static HWND 主窗 = NULL;
            if (!主窗)
                主窗 = FindWindowW(NULL, L"PYbook 场景编辑器");
            int 被遮挡 = (SDL_GetWindowFlags(win) & 0x00008000) != 0;   /* SDL_WINDOW_OCCLUDED */
            DWORD cloak = 0;
            typedef LONG (WINAPI *PFWA)(HWND, DWORD, void *, DWORD);
            static PFWA fwa = NULL;
            if (!fwa) fwa = (PFWA)(void *)GetProcAddress(GetModuleHandleA("dwmapi.dll"),
                                                         "DwmGetWindowAttribute");
            if (fwa && fwa(主窗, 14, &cloak, sizeof cloak) == 0 && cloak != 0)
                被遮挡 = 1;
            if (被遮挡) {
                SDL_Delay(50);
                continue;
            }
        }

        /* ---- 绘制 ---- */
        fill_rect(0, 0, winw, winh, 16, 16, 24);
        画场景视口();
        画面板();
        fill_rect(0, winh - 状态栏H, winw, 状态栏H, 35, 35, 46);
        {
            char 行[256];
            double mwx = (鼠x - 视ox) / 缩放, mwy = (鼠y - 视oy) / 缩放;
            snprintf(行, sizeof 行, "%s   ·   鼠标 (%d, %d)   缩放 %d%%   |   实体=墙 角色=键控 动态=重力 触发=区域   |   拖拽移动 方向键微调 Del删除 Ctrl+D复制",
                     状态栏, (int)mwx, (int)mwy, (int)(缩放 * 100));
            text(8, winh - 状态栏H + 5, 行, 12, 154, 160, 181);
        }
        SDL_RenderPresent(ren);
        SDL_Delay(8);
    }
    停止();
    return 0;
}

/* ============================ 视口绘制 ============================ */

static void 画场景视口(void)
{
    /* 场景底 + 边框 */
    int x0 = 视ox, y0 = 视oy;
    int x1 = (int)(视ox + S.宽 * 缩放), y1 = (int)(视oy + S.高 * 缩放);
    fill_rect(x0, y0, x1 - x0, y1 - y0, S.bgR, S.bgG, S.bgB);
    if (缩放 > 0.25) {
        SDL_SetRenderDrawColor(ren, 62, 68, 88, 255);
        for (int gx = 50; gx < S.宽; gx += 50) {
            int px = (int)(视ox + gx * 缩放);
            for (int yy = y0; yy < y1; yy += 2)
                SDL_RenderDrawPoint(ren, px, yy);
        }
        for (int gy = 50; gy < S.高; gy += 50) {
            int py = (int)(视oy + gy * 缩放);
            for (int xx = x0; xx < x1; xx += 2)
                SDL_RenderDrawPoint(ren, xx, py);
        }
    }
    stroke_rect(x0, y0, x1 - x0, y1 - y0, 74, 90, 138);

    /* 对象（列表序=绘制序，越靠下越上层；相机最后） */
    for (int i = 0; i < S.n; i++) {
        物 *o = &S.o[i];
        if (o->形 == 4) continue;
        if (!o->可见 && i != 选中) continue;
        int px = (int)(视ox + o->x * 缩放), py = (int)(视oy + o->y * 缩放);
        int pw = (int)(o->w * 缩放), ph = (int)(o->h * 缩放);
        if (o->形 == 1) fill_circle(px + pw/2, py + ph/2, pw/2 > 0 ? pw/2 : 1, o->红, o->绿, o->蓝);
        else if (o->形 == 2) {
            int 号 = (int)(o->号 * 缩放); if (号 < 8) 号 = 8;
            text(px, py, o->文本, 号, o->红, o->绿, o->蓝);
        } else if (o->形 == 3) {
            int iw, ih;
            SDL_Texture *t = img_get(o->图, &iw, &ih);
            stroke_rect(px, py, pw, ph, o->红, o->绿, o->蓝);
            if (t) { SDL_Rect d = { px, py, pw, ph }; SDL_RenderCopy(ren, t, NULL, &d); }
            else text(px + 4, py + 4, o->图, 12, 255, 128, 128);
        } else fill_rect(px, py, pw, ph, o->红, o->绿, o->蓝);
        if (o->实 > 0 && o->实 <= 4) {
            SDL_Color c = SOLID色[o->实];
            stroke_rect(px, py, pw, ph, c.r, c.g, c.b);
            stroke_rect(px+1, py+1, pw-2, ph-2, c.r, c.g, c.b);
        }
        if (i == 选中) {
            stroke_rect(px-3, py-3, pw+6, ph+6, 255, 210, 74);
            stroke_rect(px-2, py-2, pw+4, ph+4, 255, 210, 74);
            fill_rect(px, py, 8, 8, 255, 210, 74);
        }
    }
    /* 相机 */
    for (int i = 0; i < S.n; i++) {
        物 *o = &S.o[i];
        if (o->形 != 4) continue;
        int px = (int)(视ox + o->x * 缩放), py = (int)(视oy + o->y * 缩放);
        int pw = (int)(o->w * 缩放), ph = (int)(o->h * 缩放);
        dash_rect(px, py, pw, ph, 255, 210, 74);
        text(px + 6, py + 4, "相机", 13, 255, 210, 74);
        if (o->跟 >= 0 && o->跟 < S.n) {
            物 *t = &S.o[o->跟];
            int tx = (int)(视ox + (t->x + t->w/2.0) * 缩放), ty = (int)(视oy + (t->y + t->h/2.0) * 缩放);
            SDL_SetRenderDrawColor(ren, 255, 210, 74, 255);
            for (int d = 0; d < abs(tx - (px+pw/2)); d += 8) {
                int xx = px + pw/2 + (tx > px+pw/2 ? d : -d);
                SDL_RenderDrawPoint(ren, xx, py + ph/2 + (int)((ty - py - ph/2) * (double)d / (abs(tx - px - pw/2) > 0 ? abs(tx - px - pw/2) : 1)));
            }
        }
        if (i == 选中) stroke_rect(px-3, py-3, pw+6, ph+6, 255, 233, 160);
    }
}

/* ============================ 面板 ============================ */

/* 属性域 id 分配：10..15 数值/文本域，21 碰撞，22 跟随 */
static void 画面板(void)
{
    int winw, winh;
    SDL_GetRendererOutputSize(ren, &winw, &winh);
    fill_rect(0, 0, 面板L, winh, 26, 26, 36);
    fill_rect(winw - 面板R, 工具栏H, 面板R, winh - 工具栏H, 30, 30, 40);
    fill_rect(0, 0, winw, 工具栏H, 34, 34, 44);

    /* ---- 工具栏 ---- */
    int bx = 6;
    #define 按钮2(lab, 宽, act) do { if (ui按钮(bx, 5, 宽, 24, lab, 0)) { act; } bx += 宽 + 4; } while (0)
    按钮2("新建", 46, { S.n = 0; strcpy(S.名, "我的场景"); S.宽 = 800; S.高 = 500;
                       S.bgR = 16; S.bgG = 18; S.bgB = 26; 场景路径[0] = 0; 选中 = -1; PB选中 = -2; 适配(); });
    按钮2("打开…", 56, {
        char out[MAX_PATH*3];
        if (对话框打开(out, sizeof out)) 打开场景(out);
    });
    按钮2("保存", 46, 保存场景());
    bx += 8;
    按钮2("＋矩形", 58, 加对象(0));
    按钮2("＋圆", 46, 加对象(1));
    按钮2("＋文本", 58, 加对象(2));
    按钮2("＋图片", 58, 加对象(3));
    按钮2("＋相机", 58, 加对象(4));
    bx += 8;
    按钮2("▶ 播放(真机)", 96, 播放());
    if (播放进程) { if (ui按钮(bx, 5, 52, 24, "■ 停止", 0)) 停止(); bx += 56; }
    bx += 8;
    按钮2("导出模块", 70, {
        if (!场景路径[0]) { 保存场景(); }
        if (场景路径[0]) {
            char 基[128]; sanitize(S.名, 基, sizeof 基);
            char p[MAX_PATH*3]; 目录拼接("x", p, sizeof p);
            char *q = strrchr(p, 'x'); *q = 0;
            char out[MAX_PATH*3];
            snprintf(out, sizeof out, "%s%s_场景.pybk", p, 基);
            SB m = {0}; 生成模块(&m); 写文件UTF8(out, m.p); free(m.p);
            状态("已导出 %s（引用(\"%s_场景\") 后调 %s_物理/%s_绘制）", out, 基, 基, 基);
        }
    });
    按钮2("场景设置…", 78, 弹窗 = 1);
    #undef 按钮2

    /* ---- 左：对象列表 ---- */
    ui标签(8, 工具栏H + 6, "对象（越靠下越上层）");
    int ly = 工具栏H + 24;
    for (int i = 0; i < S.n; i++) {
        物 *o = &S.o[i];
        int ry = ly + i * 22;
        int hot = 鼠x >= 0 && 鼠x < 面板L && 鼠y >= ry && 鼠y < ry + 22;
        if (i == 选中) fill_rect(0, ry, 面板L, 22, 58, 74, 122);
        else if (hot) fill_rect(0, ry, 面板L, 22, 40, 40, 54);
        char 行[320];
        if (o->形 == 4)
            snprintf(行, sizeof 行, "%s [相机] → %s", o->名,
                     (o->跟 >= 0 && o->跟 < S.n) ? S.o[o->跟].名 : "不跟随");
        else if (o->实)
            snprintf(行, sizeof 行, "%s [%s]{%s}%s", o->名, SHAPE名[o->形], SOLID名[o->实],
                     o->可见 ? "" : " (隐)");
        else
            snprintf(行, sizeof 行, "%s [%s]%s", o->名, SHAPE名[o->形], o->可见 ? "" : " (隐)");
        text(8, ry + 4, 行, 12, i == 选中 ? 255 : 224, i == 选中 ? 230 : 224, i == 选中 ? 120 : 236);
        if (hot && 鼠按) { 选中 = i; PB选中 = -2; 跟随下拉开 = 0; 鼠按 = 0; }
    }
    {
        int by = winh - 状态栏H - 30;
        if (ui按钮(6, by, 44, 24, "上移", 0)) 移层级(-1);
        if (ui按钮(54, by, 44, 24, "下移", 0)) 移层级(1);
        if (ui按钮(102, by, 44, 24, "复制", 0)) 复制选中();
        if (ui按钮(150, by, 44, 24, "删除", 0)) 删除选中();
    }

    /* ---- 右：属性 ---- */
    int rx = winw - 面板R;
    ui标签(rx + 8, 工具栏H + 6, "属性");
    PB同步();
    if (选中 < 0) {
        text(rx + 8, 工具栏H + 30, "（未选中对象）", 12, 120, 124, 140);
        跟随下拉开 = 0;
        return;
    }
    物 *o = &S.o[选中];
    int py = 工具栏H + 28;
    #define 行(标签, 域, 容量, idv) do { \
        ui标签(rx + 8, py + 4, 标签); \
        if (ui文本域(idv, rx + 62, py, 面板R - 70, 20, 域, 容量)) { } \
        py += 24; } while (0)

    行("名称", PB.名, sizeof PB.名, 10);
    if (strcmp(PB.名, o->名) != 0) snprintf(o->名, sizeof o->名, "%s", PB.名);
    /* 类型只读 */
    ui标签(rx + 8, py + 4, "类型");
    text(rx + 62, py + 4, SHAPE名[o->形], 12, 126, 200, 255);
    py += 24;
    行("X", PB.x, sizeof PB.x, 11);
    o->x = 属性数(PB.x, o->x, -99999, 99999);
    行("Y", PB.y, sizeof PB.y, 12);
    o->y = 属性数(PB.y, o->y, -99999, 99999);
    行("宽", PB.w, sizeof PB.w, 13);
    o->w = 属性数(PB.w, o->w, 1, 99999);
    行("高", PB.h, sizeof PB.h, 14);
    o->h = 属性数(PB.h, o->h, 1, 99999);
    行("红", PB.红, sizeof PB.红, 15);
    o->红 = 属性数(PB.红, o->红, 0, 255);
    行("绿", PB.绿, sizeof PB.绿, 16);
    o->绿 = 属性数(PB.绿, o->绿, 0, 255);
    行("蓝", PB.蓝, sizeof PB.蓝, 17);
    o->蓝 = 属性数(PB.蓝, o->蓝, 0, 255);
    行("文本", PB.文本, sizeof PB.文本, 18);
    if (strcmp(PB.文本, o->文本) != 0) snprintf(o->文本, sizeof o->文本, "%s", PB.文本);
    行("字号", PB.号, sizeof PB.号, 19);
    o->号 = 属性数(PB.号, o->号, 6, 200);
    行("图片路径", PB.图, sizeof PB.图, 20);
    if (strcmp(PB.图, o->图) != 0) snprintf(o->图, sizeof o->图, "%s", PB.图);
    #undef 行

    /* 可见 */
    {
        int cx = rx + 62, cy = py + 2;
        stroke_rect(cx, cy, 14, 14, 120, 120, 140);
        if (o->可见) fill_rect(cx + 3, cy + 3, 8, 8, 120, 220, 120);
        text(cx + 20, cy + 1, "可见", 12, 184, 189, 208);
        if (鼠x >= cx && 鼠x < cx + 60 && 鼠y >= cy && 鼠y < cy + 16 && 鼠按) {
            o->可见 = !o->可见; 鼠按 = 0;
        }
        py += 24;
    }
    /* 碰撞箱 */
    {
        ui标签(rx + 8, py + 4, "碰撞箱");
        SDL_Color c = SOLID色[o->实];
        int hot = 鼠x >= rx+62 && 鼠x < rx+62+80 && 鼠y >= py && 鼠y < py+20;
        fill_rect(rx + 62, py, 80, 20, hot ? 70 : 45, hot ? 70 : 45, hot ? 100 : 58);
        stroke_rect(rx + 62, py, 80, 20, c.r, c.g, c.b);
        text(rx + 62 + 24, py + 3, SOLID名[o->实], 13, c.r, c.g, c.b);
        if (hot && 鼠按) { o->实 = (o->实 + 1) % 5; 鼠按 = 0; }
        py += 22;
        text(rx + 62, py, "实体=墙 角色=键控 动态=重力 触发=区域", 9, 102, 108, 128);
        py += 20;
    }
    /* 相机跟随 */
    if (o->形 == 4) {
        ui标签(rx + 8, py + 4, "跟随");
        int hot = 鼠x >= rx+62 && 鼠x < rx+62+120 && 鼠y >= py && 鼠y < py+20;
        fill_rect(rx + 62, py, 面板R - 72, 20, 20, 20, 28);
        stroke_rect(rx + 62, py, 面板R - 72, 20, 跟随下拉开 || hot ? 126 : 51, 跟随下拉开 || hot ? 200 : 51, 跟随下拉开 || hot ? 255 : 74);
        char 当前[96];
        if (o->跟 >= 0 && o->跟 < S.n) snprintf(当前, sizeof 当前, "%d. %s", o->跟, S.o[o->跟].名);
        else snprintf(当前, sizeof 当前, "不跟随");
        text(rx + 66, py + 3, 当前, 12, 240, 240, 248);
        text(rx + 面板R - 24, py + 3, "v", 12, 160, 160, 180);
        if (hot && 鼠按) { 跟随下拉开 = !跟随下拉开; 鼠按 = 0; }
        py += 24;
        if (跟随下拉开) {
            int 选项数 = 1;
            for (int i = 0; i < S.n; i++) if (S.o[i].形 != 4) 选项数++;
            int 行高 = 18;
            int 总高 = 选项数 * 行高;
            int ly2 = py;
            if (ly2 + 总高 > winh - 状态栏H) ly2 = winh - 状态栏H - 总高;
            fill_rect(rx + 62, ly2, 面板R - 72, 总高, 18, 18, 26);
            stroke_rect(rx + 62, ly2, 面板R - 72, 总高, 80, 80, 100);
            int oy2 = ly2;
            int 点了 = 0;
            text(rx + 66, oy2 + 2, "不跟随", 12, 224, 224, 236);
            if (鼠x >= rx+62 && 鼠x < winw-10 && 鼠y >= oy2 && 鼠y < oy2+行高 && 鼠按) {
                o->跟 = -1; 跟随下拉开 = 0; 鼠按 = 0; 点了 = 1;
            }
            oy2 += 行高;
            for (int i = 0; i < S.n; i++) {
                if (S.o[i].形 == 4) continue;
                char 行文[128];
                snprintf(行文, sizeof 行文, "%d. %s", i, S.o[i].名);
                int hov = 鼠x >= rx+62 && 鼠x < winw-10 && 鼠y >= oy2 && 鼠y < oy2+行高;
                if (hov) fill_rect(rx + 64, oy2, 面板R - 76, 行高, 50, 60, 100);
                text(rx + 66, oy2 + 2, 行文, 12, 224, 224, 236);
                if (hov && 鼠按) { o->跟 = i; 跟随下拉开 = 0; 鼠按 = 0; 点了 = 1; }
                oy2 += 行高;
            }
            (void)点了;
        }
    } else 跟随下拉开 = 0;

    /* ---- 场景设置弹窗 ---- */
    if (弹窗) 场景设置弹窗();
}

/* 场景设置：居中面板（名/宽/高/背景RGB），域 40..45 */
static char 设名[64] = "", 设宽[8] = "", 设高[8] = "", 设R[8] = "", 设G[8] = "", 设B[8] = "";
static int 设初始化 = 0;
static void 场景设置弹窗(void)
{
    if (!设初始化) {
        设初始化 = 1;
        snprintf(设名, sizeof 设名, "%s", S.名);
        snprintf(设宽, sizeof 设宽, "%d", S.宽);
        snprintf(设高, sizeof 设高, "%d", S.高);
        snprintf(设R, sizeof 设R, "%d", S.bgR);
        snprintf(设G, sizeof 设G, "%d", S.bgG);
        snprintf(设B, sizeof 设B, "%d", S.bgB);
    }
    int winw, winh;
    SDL_GetRendererOutputSize(ren, &winw, &winh);
    int w = 300, h = 260, x = (winw - w) / 2, y = (winh - h) / 2;
    fill_rect(0, 0, winw, winh, 0, 0, 0);                 /* 遮罩（不透明简化） */
    fill_rect(x, y, w, h, 40, 40, 52);
    stroke_rect(x, y, w, h, 110, 110, 140);
    text(x + 12, y + 10, "场景设置", 16, 240, 240, 248);
    int py = y + 40;
    #define 设行(标签, 域, idv) do { \
        ui标签(x + 12, py + 4, 标签); \
        ui文本域(idv, x + 70, py, w - 84, 20, 域, sizeof 域); \
        py += 26; } while (0)
    设行("名称", 设名, 40);
    设行("宽", 设宽, 41);
    设行("高", 设高, 42);
    设行("背景R", 设R, 43);
    设行("背景G", 设G, 44);
    设行("背景B", 设B, 45);
    #undef 设行
    if (ui按钮(x + w / 2 - 40, y + h - 34, 80, 24, "确定", 0)) {
        int 宽 = 属性数(设宽, S.宽, 200, 20000);
        int 高 = 属性数(设高, S.高, 150, 20000);
        snprintf(S.名, sizeof S.名, "%s", 设名[0] ? 设名 : S.名);
        S.宽 = 宽; S.高 = 高;
        S.bgR = 属性数(设R, S.bgR, 0, 255);
        S.bgG = 属性数(设G, S.bgG, 0, 255);
        S.bgB = 属性数(设B, S.bgB, 0, 255);
        for (int i = 0; i < S.n; i++)
            if (S.o[i].形 == 4) { S.o[i].w = S.宽; S.o[i].h = S.高; }
        弹窗 = 0; 设初始化 = 0; 焦点域 = 0;
        适配();
    }
    if (鼠按 && (鼠x < x || 鼠x > x + w || 鼠y < y || 鼠y > y + h)) { 弹窗 = 0; 设初始化 = 0; 鼠按 = 0; }
}
