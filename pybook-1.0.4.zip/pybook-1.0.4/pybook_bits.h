/* PYbook bits 库（bs.*）——位运算工具。
 *
 * 两层结构，与 mathplus 同一套路：
 *   核心层 pb_*  : 纯 C，零依赖，不碰 PYbook 运行时；别的库可只 include 本头文件
 *                  直接调核心层（互不影响内存分配策略）。
 *   绑定层 rt_*  : 把 PYbook 的 Value <-> long long / char* 互转，挂进前端 bs. 名字。
 *                  只在「已看到 pybook_rt.h」时才声明/编译（或用 -DPB_BITS_BINDING 强开）。
 *
 * 位宽约定：全部按 64 位无符号做（输入 long long 按位重解释），
 *   - bs.not / bs.hex / bs.bin 按无符号解释，负数会被解释成很大的无符号数（符合直觉）
 *   - bs.get / bs.set 的位序号从 0 起（最低位）
 */

#ifndef PYBOOK_BITS_H
#define PYBOOK_BITS_H

#include <stddef.h>

/* ==================== 核心层（纯 C，零依赖） ==================== */

unsigned long long pb_and(unsigned long long a, unsigned long long b);
unsigned long long pb_or(unsigned long long a, unsigned long long b);
unsigned long long pb_xor(unsigned long long a, unsigned long long b);
unsigned long long pb_not(unsigned long long a);
unsigned long long pb_shl(unsigned long long a, int n);
unsigned long long pb_shr(unsigned long long a, int n);   /* 逻辑右移（补 0） */
int                pb_get(unsigned long long a, int i);  /* 第 i 位 → 0/1 */
unsigned long long pb_set(unsigned long long a, int i, int v);
int                pb_popcount(unsigned long long a);
unsigned long long pb_mask(int w);                       /* 低 w 位全 1；w<=0 得 0，w>=64 得全 1 */

void pb_bin_str(unsigned long long a, char *out, size_t cap);   /* 二进制串，去前导零；0 → "0" */
void pb_hex_str(unsigned long long a, char *out);               /* "0x" + 大写十六进制；out 需 >= 19 字节 */
int  pb_bin_parse(const char *s, unsigned long long *out);      /* 解析 0b/纯 01 串；0=成功 -1=非法 */
int  pb_hex_parse(const char *s, unsigned long long *out);      /* 解析 0x/纯 hex 串；0=成功 -1=非法 */

/* ==================== 绑定层（PYbook 命名空间 bs.） ==================== */
/* 绑定层的三种打开方式（满足任一即生效）：
 *   1) 已经 include 过 pybook_rt.h（例如经 pybook_lib.h 间接引入）
 *   2) 显式 -DPB_BITS_BINDING
 *   3) 编译清单统一给运行时 .c 传的 -DMP_RT_BINDING
 * 只要是被 2/3 触发的，得自己把运行时头拉进来，否则 Value 未定义。 */
#if (defined(PB_BITS_BINDING) || defined(MP_RT_BINDING)) && !defined(PYBOOK_RT_H)
#include "pybook_rt.h"
#endif

#if defined(PYBOOK_RT_H) || defined(PB_BITS_BINDING) || defined(MP_RT_BINDING)

Value rt_bs_and(Value a, Value b);
Value rt_bs_or(Value a, Value b);
Value rt_bs_xor(Value a, Value b);
Value rt_bs_not(Value a);
Value rt_bs_shl(Value a, Value n);
Value rt_bs_shr(Value a, Value n);
Value rt_bs_get(Value a, Value i);
Value rt_bs_set(Value a, Value i, Value v);
Value rt_bs_popcount(Value a);
Value rt_bs_mask(Value w);
Value rt_bs_hex(Value a);
Value rt_bs_bin(Value a);
Value rt_bs_frombin(Value s);
Value rt_bs_fromhex(Value s);
Value rt_bs_band(Value a);          /* 一元别名：bs.band(a) == bs.popcount(a) */

#endif /* 绑定层 */

#endif /* PYBOOK_BITS_H */
