@echo off
REM 重编译 PYbook 字节码虚拟机 pyvm.exe（含全部标准库）
REM
REM 关键坑：mathplus.c 的绑定层（rt_lib_mp_*）只在 PYBOOK_RT_H 或 MP_RT_BINDING
REM         被定义时才编译。单独编译它时必须显式加 -DMP_RT_BINDING，
REM         否则 mp.* 全部 undefined reference。
REM
REM hw3d（SDL2）不在 g_lib_calls 表里，无需链接。

setlocal
set GCC=C:\Users\zhuli\mingw64\bin\x86_64-w64-mingw32-gcc.exe
if not exist "%GCC%" set GCC=gcc

cd /d "%~dp0"
"%GCC%" -O2 -I. ^
    pyvm.c pybook_rt.c pybook_lib.c pybook_csv.c pybook_json.c pybook_file.c ^
    pybook_mt.c pybook_mm.c pybook_np.c pybook_tb.c pybook_bits.c ^
    -DMP_RT_BINDING mathplus.c ^
    -o pyvm.exe -lm

if %errorlevel%==0 (
    echo [OK] pyvm.exe 重新编译成功
) else (
    echo [FAIL] 编译失败，错误码 %errorlevel%
)
endlocal
