# -*- coding: utf-8 -*-
"""披萨塔教学关 BGM：160BPM 放克风芯片乐（切分方波主旋律 + 走步三角贝斯 + 噪声踩镲）。
复用魔域的渲染思路，独立成文件。输出 games/披萨塔/披萨_狂奔.wav"""
import wave, math, os, struct, random

SR = 22050
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "games", "披萨塔")
os.makedirs(OUT, exist_ok=True)

def midi(n):
    return 440.0 * (2 ** ((n - 69) / 12.0))

def sq(f, t):
    return 1.0 if math.sin(2 * math.pi * f * t) >= 0 else -1.0

def tri(f, t):
    return (2.0 / math.pi) * math.asin(math.sin(2 * math.pi * f * t))

def render(bpm, bars, lead, bass, gain=0.44):
    beat = 60.0 / bpm
    total = int(bars * 4 * beat * SR)
    pcm = [0.0] * total
    for (s, d, n) in lead:
        f = midi(n)
        n0 = int(s * beat * SR); n1 = min(int((s + d) * beat * SR), total)
        nn = n1 - n0
        for i in range(nn):
            rel = i / max(1, nn)
            env = 1.0
            if rel < 0.03:
                env = rel / 0.03
            elif rel > 0.7:
                env = (1 - rel) / 0.3
            pcm[n0 + i] += sq(f, i / SR) * env * 0.5
    for (s, d, n) in bass:
        f = midi(n)
        n0 = int(s * beat * SR); n1 = min(int((s + d) * beat * SR), total)
        for i in range(n1 - n0):
            rel = i / max(1, n1 - n0)
            env = 1.0 if rel < 0.75 else (1 - rel) / 0.25
            pcm[n0 + i] += tri(f, i / SR) * env * 0.55
    rnd = random.Random(7)
    eighth = beat / 2
    n_hat = int(0.025 * SR)
    for k in range(int(bars * 8) + 1):
        s = int(k * eighth * SR)
        for i in range(n_hat):
            if s + i < total:
                pcm[s + i] += (rnd.random() * 2 - 1) * (1 - i / n_hat) * 0.12
    out = []
    for v in pcm:
        out.append(int(math.tanh(v * gain) * 0.92 * 32000))
    return out

def save(name, pcm):
    with wave.open(os.path.join(OUT, name), "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR)
        w.writeframes(struct.pack("<%dh" % len(pcm), *pcm))
    print(f"{name}: {len(pcm)/SR:.1f}s")

E = 0.5
def ph(seq, start):
    out = []
    for i, n in enumerate(seq):
        if n:
            out.append((start + i * E, E * 0.9, n))
    return out

# E 小调放克 riff（40=E3 → 用高八度 64=E4 区）
riff = [64, None, 64, 67, None, 64, 70, 67,
        64, None, 62, 64, 67, 69, 67, 64,
        64, None, 64, 67, None, 64, 70, 72,
        71, 69, 67, 64, 62, None, 59, 62]
lead = []
for rep in range(6):
    lead += ph(riff, rep * 16)
# 贝斯：E 走步 + 回转
bass = []
walk = [28, 30, 31, 33, 28, 30, 26, 28]
for rep in range(6):
    base = rep * 16
    for k in range(16):
        bar = k // 4
        n = walk[(rep * 2 + bar) % 8] if k % 4 == 0 else walk[(rep * 2 + bar) % 8] + 7
        bass.append((base + k * E, E * 0.95, n))

# 逃亡曲：半音下行的紧迫感
riff2 = [76, 76, 79, 76, 75, 76, 79, 82,
         76, 76, 79, 81, 80, 79, 75, 71,
         76, 76, 79, 76, 75, 76, 82, 81,
         80, 79, 75, 71, 68, None, 64, None]
lead2 = []
for rep in range(4):
    lead2 += ph(riff2, rep * 16)
bass2 = []
pump = [28, 28, 28, 28, 26, 26, 26, 26]
for rep in range(4):
    for k in range(16):
        n = pump[(rep * 2 + k // 8) % 8]
        bass2.append((rep * 16 + k * E, E * 0.9, n))
save("披萨_逃亡.wav", render(180, 16, lead2, bass2))
print("BGM 生成完毕")
