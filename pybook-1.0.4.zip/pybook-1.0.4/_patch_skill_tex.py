# -*- coding: utf-8 -*-
"""同步 pybook-debug 技能：hw API 27→31（贴图 + 父子层级）、op 命令流、纠正"贴图要 GLSL"的错误判断。"""
import io, sys

JOBS = []
def add(f, l, o, n): JOBS.append((f, l, o, n))

S = 'C:/Users/zhuli/.workbuddy/skills/pybook-debug/SKILL.md'
B = 'C:/Users/zhuli/.workbuddy/skills/pybook-debug/references/backend-apis.md'

# ---------------- SKILL.md ----------------
add(S, 'S-count', '## hw.* API 全表（3D_highway，共 27 条）',
                 '## hw.* API 全表（3D_highway，共 31 条）')

add(S, 'S-table', """fog(起,止):2   far(距离):1   wire(0/1):1       ← 雾/视距/线框
fov(角度):1    near(距离):1                    ← 竖直视场角 / 近裁剪面
line(x1,y1,z1,x2,y2,z2, r,g,b):9               ← 单帧线段（gizmo/坐标轴/弹道）
light(方向x,方向y,方向z, 强度0~1):4            ← 方向光（改全局，一次调用影响所有图元）
frame():0             end():0""",
"""fog(起,止):2   far(距离):1   wire(0/1):1       ← 雾/视距/线框
fov(角度):1    near(距离):1                    ← 竖直视场角 / 近裁剪面
line(x1,y1,z1,x2,y2,z2, r,g,b):9               ← 单帧线段（gizmo/坐标轴/弹道）
light(方向x,方向y,方向z, 强度0~1):4            ← 方向光（改全局，一次调用影响所有图元）
tex(槽,路径):2      texuse(槽):1      uv(重复):1   ← 贴图：加载 / 选用 / 平铺
push(x,y,z, 绕x,绕y,绕z):6    pop():0          ← 父子层级（变换栈）
frame():0             end():0""")

add(S, 'S-boundary', """- **还不能做的**（固定管线装不下）：贴图、父子层级、正交投影、PBR 材质、
  阴影贴图、Bloom/SSAO 等后处理 —— 这些要上 GLSL 着色器 + FBO，等于换渲染架构。
  （球/圆柱**已填上**，见上表 —— 用 `GL_TRIANGLE_STRIP`/`FAN` 硬写细分即可。）""",
"""- **贴图已支持**，而且**不需要 GLSL**（我最初判断"贴图必须上着色器"是错的）：
  固定管线的 `glEnable(GL_TEXTURE_2D)` + `glTexCoord2f` + `GL_MODULATE` 就够。
  `GL_MODULATE` 让顶点色（已含方向光）直接乘在贴图上 → "光照 x 贴图"自动成立。
  透明 PNG 用 `glEnable(GL_ALPHA_TEST)` + `glAlphaFunc(GREATER, 0.01)` 做裁剪，
  **不做排序**，绕开半透明排序难题。`GL_REPEAT` 是 `hw.uv` 能平铺的前提。
- **父子层级已支持**（`hw.push`/`hw.pop`）：见下面的「op 命令流」一节。
- **还不能做的**（固定管线装不下）：正交投影、PBR 材质、阴影贴图、
  Bloom/SSAO 等后处理 —— 这些要上 GLSL 着色器 + FBO，等于换渲染架构。
  （球/圆柱/贴图/层级**都已填上**。固定管线比想象中能干，别轻易下"必须换架构"的结论。）""")

add(S, 'S-opstream', """## 构建命令""",
"""## op 命令流（3D_highway 的核心架构，改这里之前必读）

图元**不是**按类型分批画（以前是"先画所有盒、再所有球、再所有柱、最后所有线"），
而是**按脚本提交的顺序画**。原因：`hw.push`/`hw.pop` 只有在顺序执行时才有语义。

```c
enum { OP_BOX, OP_SPHERE, OP_CYL, OP_LINE, OP_PUSH, OP_POP };
typedef struct { int type, idx; float px,py,pz, rx,ry,rz; } HwOp;
static HwOp g_ops[HW_OP_MAX];   /* 65536 */
static int  g_nops, g_depth;
```

- **数据与顺序分离**：图元本体仍在 `g_boxes`/`g_spheres`/`g_cyls`/`g_lines` 里，
  op 只存「类型 + 下标」。这样上限检查和报错文案都不用改。
- `hw_op(type, idx)` 追加无变换参数的 op；`hw.push` 手写追加（要带 6 个变换参数）。
- `draw_ops()`（在 `rt_hw_frame` 之前）按顺序执行：
  `OP_PUSH` → `glPushMatrix/glTranslatef/glRotatef(x,y,z)/`（旋转顺序 X→Y→Z）；
  `OP_POP` → `glPopMatrix`；图元 → `hw_bind_tex(tex)` 后画。
- **两种兜底**：`g_depth >= HW_MAX_DEPTH(20)` 时忽略 push（防 GL 矩阵栈溢出）；
  帧末 `while (g_depth > 0) glPopMatrix()`（脚本忘配对 pop 也不崩）。
- **线段做连续批处理**：相邻的 `OP_LINE` 合进一个 `glBegin(GL_LINES)`（`i = j - 1` 跳过已吃掉的）。
- **每帧清空**：`g_nops = 0; g_depth = 0;` 在 `rt_hw_frame` 末尾和 `rt_hw_open` 里都要清。
- 贴图槽/UV 是**提交时刻**的状态，记进图元本体（`HwBox.tex/.uv`）——
  所以之后改 `hw.texuse` 不会影响已经提交的图元。

## 构建命令""")

add(S, 'S-ref', """- `hw.sphere` / `hw.cyl` / `hw.fov` / `hw.near` 最小自测：`C:\\Users\\zhuli\\Desktop\\pybook\\_proto_spherecyl.pybk`
  （球/圆柱/圆锥/倒锥/六棱柱一字排开，F/N 键切视口参数）""",
"""- `hw.sphere` / `hw.cyl` / `hw.fov` / `hw.near` 最小自测：`C:\\Users\\zhuli\\Desktop\\pybook\\_proto_spherecyl.pybk`
  （球/圆柱/圆锥/倒锥/六棱柱一字排开，F/N 键切视口参数）
- `hw.tex` / `hw.push` 最小自测：`C:\\Users\\zhuli\\Desktop\\pybook\\_proto_texparen.pybk`
  （贴图柱/球/立方体 + 三层嵌套"桌子>托盘>杯子"，1~5 键切贴图与 UV）
- **贴图加载探针**：`C:\\Users\\zhuli\\Desktop\\pybook\\_tex_probe.c`
  （不开 pybk，直接链接 rt_cache 的 .o 调 `rt_hw_tex` 并 printf 返回值 ——
 这是**唯一能真正看到"贴图加载成功/失败"的办法**，因为 3D 模式没有控制台输出。
  编译命令见 backend-apis.md 末尾。）""")

# ---------------- backend-apis.md ----------------
add(B, 'B-count', '依赖 SDL2 + OpenGL 固定管线。导出 `rt_hw_*` 共 **27 个**（见 SKILL.md 的 API 表）。',
                 '依赖 SDL2 + OpenGL 固定管线。导出 `rt_hw_*` 共 **31 个**（见 SKILL.md 的 API 表）。\n\n**op 命令流是这套引擎的核心架构**，详见 SKILL.md「op 命令流」一节。')

add(B, 'B-state', """| 状态区 约 74-146 行 | `g_camx/y/z, g_yaw, g_pitch`；`g_sky_r/g/b`；`g_fog_start/g_fog_end/g_far`；`g_wire`；`g_fovy`(默认 70) / `g_near`(默认 1.0)；`HwLine g_lines[16384]`+`g_nlines`；`HwSphere g_spheres[4096]`+`g_nspheres`；`HwCyl g_cyls[4096]`+`g_ncyls`；光照 `g_lx/g_ly/g_lz`(0.45/0.80/0.40) + `g_lamb` + `g_ldiff` |""",
"""| 状态区 约 74-160 行 | `g_camx/y/z, g_yaw, g_pitch`；`g_sky_r/g/b`；`g_fog_start/g_fog_end/g_far`；`g_wire`；`g_fovy`(70) / `g_near`(1.0)；`HwLine g_lines[16384]`+`g_nlines`；`HwSphere g_spheres[4096]`+`g_nspheres`；`HwCyl g_cyls[4096]`+`g_ncyls`；光照 `g_lx/g_ly/g_lz` + `g_lamb` + `g_ldiff`；**贴图** `g_texs[8]`/`g_texw`/`g_texh`/`g_curtex`/`g_curuv`；**op 流** `g_ops[65536]`/`g_nops`/`g_depth` |
| `HwOp` 约 150 行 | `{ type, idx, px,py,pz, rx,ry,rz }` —— op 命令流的一条 |
| `hw_op(type, idx)` 约 183 行 | 追加无变换参数的 op（带上限检查） |
| `hw_bind_tex(slot)` 约 653 行 | 绑定槽贴图；槽 0/未加载则 `glDisable(GL_TEXTURE_2D)` |
| `draw_ops()` 约 876 行 | 按提交顺序执行；push/pop → GL 矩阵栈；线段的连续批处理；末尾兜底清栈 |""")

fails = 0
bufs = {}
for fn, label, old, new in JOBS:
    if fn not in bufs:
        bufs[fn] = io.open(fn, encoding='utf-8').read()
    n = bufs[fn].count(old)
    if n != 1:
        sys.stderr.write('FAIL [%s] count=%d\n' % (label, n))
        fails += 1
        continue
    bufs[fn] = bufs[fn].replace(old, new, 1)
    print('ok   ' + label)

if fails:
    sys.stderr.write('\n%d 处失败，未写回\n' % fails)
    sys.exit(1)
for fn, txt in bufs.items():
    io.open(fn, 'w', encoding='utf-8', newline='').write(txt)
    print('写回 ' + fn)
