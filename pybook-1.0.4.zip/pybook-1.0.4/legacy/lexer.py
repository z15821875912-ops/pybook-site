"""词法分析器：把"新语言"源码切成 Token 列表。

只做认字（词法分析），不做语法检查，不生成 AST。
仅用 Python 标准库。
"""

from dataclasses import dataclass


@dataclass
class Token:
    kind: str    # 'INT' 'IDENT' 'KEYWORD' 'OP' 'EOF'
    value: str
    line: int
    col: int


KEYWORDS = {
    'fn', 'return', 'if', 'else', 'while', 'let', 'true', 'false',
    'int', 'bool',
}

# 两字符运算符必须先于单字符匹配，否则 -> 会被切成 - 和 >
TWO_CHAR_OPS = {'==', '!=', '<=', '>=', '->'}
SINGLE_CHAR_OPS = set('+-*/%(){},;:=<>')


class LexError(Exception):
    """词法错误：带行号和列号。"""


def _is_digit(ch: str) -> bool:
    return '0' <= ch <= '9'


def _is_ident_start(ch: str) -> bool:
    return ch == '_' or 'a' <= ch <= 'z' or 'A' <= ch <= 'Z'


def _is_ident_char(ch: str) -> bool:
    return _is_ident_start(ch) or _is_digit(ch)


def tokenize(src: str) -> list[Token]:
    tokens: list[Token] = []
    i = 0
    n = len(src)
    line = 1
    col = 1

    while i < n:
        ch = src[i]

        # 换行：行号 +1，列号归 1
        if ch == '\n':
            i += 1
            line += 1
            col = 1
            continue

        # 空白跳过
        if ch in ' \t\r':
            i += 1
            col += 1
            continue

        # 注释：// 到行末
        if ch == '/' and i + 1 < n and src[i + 1] == '/':
            while i < n and src[i] != '\n':
                i += 1
            continue  # 换行符留给下一轮处理（重置列号）

        start_line, start_col = line, col

        # 整数字面量
        if _is_digit(ch):
            j = i
            while j < n and _is_digit(src[j]):
                j += 1
            tokens.append(Token('INT', src[i:j], start_line, start_col))
            col += j - i
            i = j
            continue

        # 标识符 / 关键字
        if _is_ident_start(ch):
            j = i
            while j < n and _is_ident_char(src[j]):
                j += 1
            word = src[i:j]
            kind = 'KEYWORD' if word in KEYWORDS else 'IDENT'
            tokens.append(Token(kind, word, start_line, start_col))
            col += j - i
            i = j
            continue

        # 两字符运算符
        if src[i:i + 2] in TWO_CHAR_OPS:
            op = src[i:i + 2]
            tokens.append(Token('OP', op, start_line, start_col))
            i += 2
            col += 2
            continue

        # 单字符符号
        if ch in SINGLE_CHAR_OPS:
            tokens.append(Token('OP', ch, start_line, start_col))
            i += 1
            col += 1
            continue

        raise LexError(
            f"词法错误：第 {line} 行第 {col} 列出现非法字符 {ch!r}"
        )

    tokens.append(Token('EOF', '', line, col))
    return tokens


if __name__ == '__main__':
    SAMPLE = '''fn add(a: int, b: int) -> int {
    return a + b;
}
fn main() -> int {
    let i: int = 0;
    let s: int = 0;
    while i < 5 {
        s = add(s, i);
        i = i + 1;
    }
    print(s);
    return 0;
}
'''

    toks = tokenize(SAMPLE)
    for t in toks:
        print(f"{t.line:>3}:{t.col:<3} {t.kind:<8} {t.value!r}")

    # 确认两字符符号被整体切开，没有被拆成单字符
    ops = tokenize("a == b != c <= d >= e -> f")
    two_char = [t.value for t in ops if t.kind == 'OP' and len(t.value) == 2]
    assert two_char == ['==', '!=', '<=', '>=', '->'], two_char
    assert [t.kind for t in toks if t.value == '->'] == ['OP', 'OP']
    assert toks[-1].kind == 'EOF'

    # 非法字符：报错信息要带行号列号
    try:
        tokenize("let x = 1;\nlet y = @;")
    except LexError as e:
        print("非法字符测试:", e)
        assert '2' in str(e) and '9' in str(e)
    else:
        raise AssertionError("非法字符未报错")

    print("自测通过：-> 和 == 等两字符符号均正确切分，EOF 已附加。")
