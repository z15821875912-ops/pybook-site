"""编译后端：把 parser.py 产出的 AST 编译成 C，调 gcc 生成 app.exe 并运行。

全流程：compile_and_run(src)
    tokenize → parse → 遍历 AST 做类型检查并生成 C
    → 写 out.c → gcc -O2 -o app.exe out.c → 运行 app.exe

类型映射与运行时规则（与规格一致）：
    int  → C 的 long long（64 位有符号）
    bool → C 的 int（true=1, false=0）
    加减乘用 __builtin_{add,sub,mul}_overflow 检查溢出，溢出报错退出；
    除法/取余用固定辅助函数 floordiv/floormod（Python 向下取整语义），
    除数为 0 以及 LLONG_MIN / -1 报错退出。

类型/语义错误抛 CompileError，消息带行号列号。parser.py 的 AST 节点不携带
行号，这里按同一文法把 token 流和 AST 同步走一遍，把每个节点的起始位置
找回来（_build_line_map）。仅用 Python 标准库。
"""

import os
import subprocess
import sys

from lexer import tokenize
from parser import parse
from parser import (
    Program, FnDef, IntLit, BoolLit, Var, BinOp, Unary, Call,
    Let, Assign, If, While, Return, ExprStmt,
)

INT, BOOL = 'int', 'bool'
C_TYPE = {INT: 'long long', BOOL: 'int'}

ARITH_OPS = {'+', '-', '*', '/', '%'}
REL_OPS = {'<', '>', '<=', '>='}
EQ_OPS = {'==', '!='}
# 加减乘走溢出检查；除/余走 Python 向下取整语义
ARITH_C = {'+': 'add_ovf', '-': 'sub_ovf', '*': 'mul_ovf',
           '/': 'floordiv', '%': 'floormod'}

INT_MIN, INT_MAX = -(2 ** 63), 2 ** 63 - 1
# print 是内置函数；lang_main 是 main 在生成 C 里的名字，都不能被用户占用
RESERVED = {'print', 'lang_main'}

C_PRELUDE = r'''#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

static long long add_ovf(long long a, long long b) {
    long long r;
    if (__builtin_add_overflow(a, b, &r)) {
        fprintf(stderr, "runtime error: overflow\n");
        exit(1);
    }
    return r;
}
static long long sub_ovf(long long a, long long b) {
    long long r;
    if (__builtin_sub_overflow(a, b, &r)) {
        fprintf(stderr, "runtime error: overflow\n");
        exit(1);
    }
    return r;
}
static long long mul_ovf(long long a, long long b) {
    long long r;
    if (__builtin_mul_overflow(a, b, &r)) {
        fprintf(stderr, "runtime error: overflow\n");
        exit(1);
    }
    return r;
}
static long long floordiv(long long a, long long b) {
    if (b == 0 || (a == LLONG_MIN && b == -1)) { fprintf(stderr, "runtime error: div\n"); exit(1); }
    long long q = a / b;
    if ((a % b != 0) && ((a < 0) != (b < 0))) q--;
    return q;
}
static long long floormod(long long a, long long b) {
    if (b == 0 || (a == LLONG_MIN && b == -1)) { fprintf(stderr, "runtime error: mod\n"); exit(1); }
    long long r = a % b;
    if (r != 0 && ((a < 0) != (b < 0))) r += b;
    return r;
}
'''


class CompileError(Exception):
    """类型/语义错误，消息带行号列号。"""


def c_name(name: str) -> str:
    """用户函数名 → C 函数名：main 必须改名 lang_main，给生成的 C 入口让位。"""
    return 'lang_main' if name == 'main' else name


# ---------- 行号回填 ----------
#
# parser.py 出来的 AST 节点是纯数据类，没有行号。生成 C 前把 token 流和
# AST 按 parser 的同一文法同步走一遍：每个节点 consume 它对应的 token，
# 起始 token 的 (line, col) 就是节点的位置。括号在 AST 里不体现，遇到
# '(' 就先吃掉、递归走内层节点、再吃掉 ')'。

class _Desync(Exception):
    """AST 与 token 流对不上（只会在 parser 文法改动后出现）。"""


def _build_line_map(program: Program, tokens: list) -> dict:
    linemap = {}
    pos = 0

    def peek():
        return tokens[min(pos, len(tokens) - 1)]

    def take(kind=None, value=None):
        nonlocal pos
        t = peek()
        if t.kind == 'EOF' \
                or (kind is not None and t.kind != kind) \
                or (value is not None and t.value != value):
            raise _Desync()
        pos += 1
        return t

    def p_type():
        take()  # 类型名占一个 token（parser 接受 IDENT/KEYWORD，合法性由后端查）

    def expr(e):
        if peek().kind == 'OP' and peek().value == '(':
            take('OP', '(')
            expr(e)
            take('OP', ')')
            return
        linemap[id(e)] = (peek().line, peek().col)
        if isinstance(e, IntLit):
            take('INT')
        elif isinstance(e, BoolLit):
            if take().value not in ('true', 'false'):
                raise _Desync()
        elif isinstance(e, Var):
            take('IDENT', e.name)
        elif isinstance(e, Unary):
            take('OP', e.op)
            expr(e.operand)
        elif isinstance(e, BinOp):
            expr(e.left)
            take('OP', e.op)
            expr(e.right)
        elif isinstance(e, Call):
            take('IDENT', e.name)
            take('OP', '(')
            for i, arg in enumerate(e.args):
                expr(arg)
                if i + 1 < len(e.args):
                    take('OP', ',')
            take('OP', ')')
        else:
            raise _Desync()

    def stmt(s):
        if isinstance(s, Let):
            linemap[id(s)] = (peek().line, peek().col)
            take('KEYWORD', 'let')
            take('IDENT', s.name)
            take('OP', ':')
            p_type()
            take('OP', '=')
            expr(s.expr)
            take('OP', ';')
        elif isinstance(s, Assign):
            linemap[id(s)] = (peek().line, peek().col)
            take('IDENT', s.name)
            take('OP', '=')
            expr(s.expr)
            take('OP', ';')
        elif isinstance(s, If):
            linemap[id(s)] = (peek().line, peek().col)
            take('KEYWORD', 'if')
            expr(s.cond)
            block(s.then)
            if s.els:
                take('KEYWORD', 'else')
                block(s.els)
        elif isinstance(s, While):
            linemap[id(s)] = (peek().line, peek().col)
            take('KEYWORD', 'while')
            expr(s.cond)
            block(s.body)
        elif isinstance(s, Return):
            linemap[id(s)] = (peek().line, peek().col)
            take('KEYWORD', 'return')
            expr(s.expr)
            take('OP', ';')
        elif isinstance(s, ExprStmt):
            linemap[id(s)] = (peek().line, peek().col)
            expr(s.expr)
            take('OP', ';')
        else:
            raise _Desync()

    def block(stmts):
        take('OP', '{')
        for s in stmts:
            stmt(s)
        take('OP', '}')

    def fn(f):
        linemap[id(f)] = (peek().line, peek().col)
        take('KEYWORD', 'fn')
        take('IDENT', f.name)
        take('OP', '(')
        for i, (pname, _ptype) in enumerate(f.params):
            take('IDENT', pname)
            take('OP', ':')
            p_type()
            if i + 1 < len(f.params):
                take('OP', ',')
        take('OP', ')')
        take('OP', '->')
        p_type()
        block(f.body)

    try:
        linemap[id(program)] = (peek().line, peek().col)
        for f in program.fns:
            fn(f)
        if peek().kind != 'EOF':
            raise _Desync()
    except _Desync:
        # 失配就整体放弃行号：报错退化成不带位置，不影响编译正确性
        return {}
    return linemap


# ---------- 类型检查 + C 代码生成 ----------

class Codegen:
    def __init__(self, program: Program, line_map: dict):
        self.program = program
        self.line_map = line_map
        self.sigs = {}        # 函数名 -> (参数类型列表, 返回类型)
        self.scopes = []      # 作用域栈，每层是 name -> type
        self.ret_type = None
        self.out = []
        self.depth = 0

    # ---- 错误与符号表 ----

    def err(self, node, msg):
        pos = self.line_map.get(id(node))
        where = f'第 {pos[0]} 行第 {pos[1]} 列: ' if pos else ''
        raise CompileError(where + msg)

    def lookup(self, name, node):
        for scope in reversed(self.scopes):
            if name in scope:
                return scope[name]
        self.err(node, f"变量 '{name}' 未声明")

    def define(self, name, ty, node):
        if name in self.scopes[-1]:
            self.err(node, f"变量 '{name}' 在同一作用域重复声明")
        self.scopes[-1][name] = ty

    def collect_sigs(self):
        """先收集全部函数签名再查函数体，天然支持先调用后定义/互相递归。"""
        for f in self.program.fns:
            if f.name in RESERVED:
                self.err(f, f"函数名 '{f.name}' 是保留名，不能定义")
            if f.name in self.sigs:
                self.err(f, f"函数 '{f.name}' 重复定义")
            seen = set()
            for pname, ptype in f.params:
                if ptype not in C_TYPE:
                    self.err(f, f"参数 '{pname}' 用了未知类型 '{ptype}'（只支持 int/bool）")
                if pname in seen:
                    self.err(f, f"参数 '{pname}' 重复")
                seen.add(pname)
            if f.ret not in C_TYPE:
                self.err(f, f"返回类型 '{f.ret}' 未知（只支持 int/bool）")
            self.sigs[f.name] = ([t for _, t in f.params], f.ret)
        main_sig = self.sigs.get('main')
        if main_sig is None:
            self.err(self.program, "程序必须定义 main 函数")
        if main_sig[0]:
            self.err(self.program, 'main 函数不能带参数')

    # ---- C 代码 ----

    def emit(self, line):
        self.out.append('    ' * self.depth + line if line else '')

    def fn_signature(self, f) -> str:
        params = ', '.join(f'{C_TYPE[t]} {n}' for n, t in f.params) or 'void'
        return f'{C_TYPE[f.ret]} {c_name(f.name)}({params})'

    def generate(self) -> str:
        self.collect_sigs()
        self.out = [C_PRELUDE]
        for f in self.program.fns:            # 原型声明，允许前向调用
            self.emit(self.fn_signature(f) + ';')
        for f in self.program.fns:
            self.gen_fn(f)
        self.emit('int main(void) {')
        self.depth += 1
        self.emit('return (int)lang_main();')
        self.depth -= 1
        self.emit('}')
        return '\n'.join(self.out) + '\n'

    def gen_fn(self, f):
        self.ret_type = f.ret
        self.scopes = [{n: t for n, t in f.params}]
        self.emit(self.fn_signature(f) + ' {')
        self.depth += 1
        for s in f.body:
            self.stmt(s)
        self.depth -= 1
        self.emit('}')
        self.emit('')

    def block(self, stmts):
        self.scopes.append({})
        self.depth += 1
        for s in stmts:
            self.stmt(s)
        self.depth -= 1
        self.scopes.pop()

    # ---- 语句 ----

    def stmt(self, s):
        if isinstance(s, Let):
            if s.type not in C_TYPE:
                self.err(s, f"未知类型 '{s.type}'（只支持 int/bool）")
            code, t = self.expr(s.expr)   # 先查初始化式：新名字在自己的初值里不可见
            if t != s.type:
                self.err(s, f"let '{s.name}' 声明为 {s.type}，初始化式却是 {t}")
            self.define(s.name, s.type, s)
            self.emit(f'{C_TYPE[s.type]} {s.name} = {code};')
        elif isinstance(s, Assign):
            ty = self.lookup(s.name, s)
            code, t = self.expr(s.expr)
            if t != ty:
                self.err(s, f"给 '{s.name}'（{ty}）赋了 {t} 值")
            self.emit(f'{s.name} = {code};')
        elif isinstance(s, Return):
            code, t = self.expr(s.expr)
            if t != self.ret_type:
                self.err(s, f'返回类型不符：函数声明返回 {self.ret_type}，实际返回 {t}')
            self.emit(f'return {code};')
        elif isinstance(s, If):
            code, t = self.expr(s.cond)
            if t not in C_TYPE:           # int 和 bool 都能当条件
                self.err(s, f'if 条件需要 int 或 bool，得到 {t}')
            self.emit(f'if ({code}) {{')
            self.block(s.then)
            if s.els:
                self.emit('} else {')
                self.block(s.els)
            self.emit('}')
        elif isinstance(s, While):
            code, t = self.expr(s.cond)
            if t not in C_TYPE:
                self.err(s, f'while 条件需要 int 或 bool，得到 {t}')
            self.emit(f'while ({code}) {{')
            self.block(s.body)
            self.emit('}')
        elif isinstance(s, ExprStmt):
            code, _ = self.expr(s.expr)
            self.emit(f'{code};')
        else:
            self.err(s, f'不支持的语句节点 {type(s).__name__}')

    # ---- 表达式：返回 (C 表达式文本, 语言类型) ----

    def expr(self, e):
        if isinstance(e, IntLit):
            if not (INT_MIN <= e.value <= INT_MAX):
                self.err(e, f'整数字面量 {e.value} 超出 64 位有符号范围')
            return str(e.value), INT
        if isinstance(e, BoolLit):
            return ('1' if e.value else '0'), BOOL
        if isinstance(e, Var):
            return e.name, self.lookup(e.name, e)
        if isinstance(e, Unary):
            s, t = self.expr(e.operand)
            if e.op == '-':
                if t != INT:
                    self.err(e, f"一元 '-' 需要 int，得到 {t}")
                return f'sub_ovf(0, {s})', INT
            if e.op == '!':
                if t != BOOL:
                    self.err(e, f"一元 '!' 需要 bool，得到 {t}")
                return f'(!{s})', BOOL
            self.err(e, f"不支持的一元运算符 '{e.op}'")
        if isinstance(e, BinOp):
            ls, lt = self.expr(e.left)
            rs, rt = self.expr(e.right)
            if e.op in ARITH_OPS:
                if lt != INT or rt != INT:
                    self.err(e, f"运算符 '{e.op}' 需要 int 操作数，得到 {lt} 和 {rt}")
                return f'{ARITH_C[e.op]}({ls}, {rs})', INT
            if e.op in REL_OPS:
                if lt != INT or rt != INT:
                    self.err(e, f"比较符 '{e.op}' 需要 int 操作数，得到 {lt} 和 {rt}")
                return f'({ls} {e.op} {rs})', BOOL
            if e.op in EQ_OPS:
                if lt != rt:
                    self.err(e, f"运算符 '{e.op}' 两边类型不一致：{lt} 和 {rt}")
                return f'({ls} {e.op} {rs})', BOOL
            self.err(e, f"不支持的运算符 '{e.op}'")
        if isinstance(e, Call):
            return self.call(e)
        self.err(e, f'不支持的表达式节点 {type(e).__name__}')

    def call(self, e):
        if e.name == 'print':
            if len(e.args) != 1:
                self.err(e, f'print 需要恰好 1 个参数，得到 {len(e.args)} 个')
            s, t = self.expr(e.args[0])
            if t != INT:
                self.err(e, f'print 需要 int 参数，得到 {t}')
            return f'printf("%lld\\n", {s})', INT
        if e.name not in self.sigs:
            self.err(e, f"函数 '{e.name}' 未定义")
        ptypes, ret = self.sigs[e.name]
        if len(e.args) != len(ptypes):
            self.err(e, f"函数 '{e.name}' 需要 {len(ptypes)} 个参数，得到 {len(e.args)} 个")
        parts = []
        for i, (arg, pt) in enumerate(zip(e.args, ptypes), 1):
            s, t = self.expr(arg)
            if t != pt:
                self.err(arg, f"函数 '{e.name}' 的第 {i} 个参数需要 {pt}，得到 {t}")
            parts.append(s)
        return f"{c_name(e.name)}({', '.join(parts)})", ret


# ---------- 全流程 ----------

def compile_and_run(src: str) -> str:
    """源码 → AST → C → gcc → 运行 app.exe。

    类型/语义错误抛 CompileError（带行号列号）；gcc 编译失败抛 CompileError
    （附 gcc 输出）；程序运行时非零退出抛 RuntimeError。正常运行时回显程序
    输出并把它作为返回值。
    """
    tokens = tokenize(src)
    program = parse(tokens)
    line_map = _build_line_map(program, tokens)
    c_code = Codegen(program, line_map).generate()
    with open('out.c', 'w', encoding='utf-8') as f:
        f.write(c_code)

    build = subprocess.run(['gcc', '-O2', '-o', 'app.exe', 'out.c'],
                           capture_output=True, text=True, errors='replace')
    if build.returncode != 0:
        raise CompileError('gcc 编译失败：\n' + (build.stderr or build.stdout))

    run = subprocess.run(['app.exe' if os.name == 'nt' else './app.exe'],
                         capture_output=True, text=True, errors='replace')
    if run.stdout:
        print(run.stdout, end='')
    if run.returncode != 0:
        if run.stderr:
            sys.stderr.write(run.stderr)
        raise RuntimeError(f'程序异常退出，退出码 {run.returncode}')
    return run.stdout


# ---------- 自测 ----------

SELF_TEST_SRC = '''fn add(a: int, b: int) -> int {
    return a + b;
}
fn main() -> int {
    let i: int = 0;
    let s: int = 0;
    while i < 5 {
        s = add(s, i);
        i = i + 1;
    }
    print(s);
    return 0;
}
'''

if __name__ == '__main__':
    output = compile_and_run(SELF_TEST_SRC)
    assert output == '10\n', f'自测失败：期望打印 10，实际输出 {output!r}'
    print('自测通过：样例程序输出 10')
