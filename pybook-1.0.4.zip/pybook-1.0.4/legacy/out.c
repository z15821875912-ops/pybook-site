#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

static long long add_ovf(long long a, long long b) {
    long long r;
    if (__builtin_add_overflow(a, b, &r)) {
        fprintf(stderr, "runtime error: overflow\n");
        exit(1);
    }
    return r;
}
static long long sub_ovf(long long a, long long b) {
    long long r;
    if (__builtin_sub_overflow(a, b, &r)) {
        fprintf(stderr, "runtime error: overflow\n");
        exit(1);
    }
    return r;
}
static long long mul_ovf(long long a, long long b) {
    long long r;
    if (__builtin_mul_overflow(a, b, &r)) {
        fprintf(stderr, "runtime error: overflow\n");
        exit(1);
    }
    return r;
}
static long long floordiv(long long a, long long b) {
    if (b == 0 || (a == LLONG_MIN && b == -1)) { fprintf(stderr, "runtime error: div\n"); exit(1); }
    long long q = a / b;
    if ((a % b != 0) && ((a < 0) != (b < 0))) q--;
    return q;
}
static long long floormod(long long a, long long b) {
    if (b == 0 || (a == LLONG_MIN && b == -1)) { fprintf(stderr, "runtime error: mod\n"); exit(1); }
    long long r = a % b;
    if (r != 0 && ((a < 0) != (b < 0))) r += b;
    return r;
}

long long add(long long a, long long b);
long long lang_main(void);
long long add(long long a, long long b) {
    return add_ovf(a, b);
}

long long lang_main(void) {
    long long i = 0;
    long long s = 0;
    while ((i < 5)) {
        s = add(s, i);
        i = add_ovf(i, 1);
    }
    printf("%lld\n", s);
    return 0;
}

int main(void) {
    return (int)lang_main();
}
