import sys
from codegen import compile_and_run

compile_and_run(open(sys.argv[1], encoding="utf-8").read())
