"""v1 递归下降语法分析器。

输入：lexer.tokenize 产出的 Token 列表（Token 定义 import 自 lexer.py）。
输出：Program AST。

文法（v1）：
    程序   = 函数定义*（至少要有 main）
    函数   = fn 名字(参数: 类型, ...) -> 类型 { 语句* }
    语句   = let 名字: 类型 = 表达式 ;  |  名字 = 表达式 ;
           | if 表达式 { 语句* } (可选 else { 语句* })
           | while 表达式 { 语句* }  |  return 表达式 ;  |  表达式 ;
    表达式优先级从低到高：== !=  →  < > <= >=  →  + -  →  * / %  →  一元负号
                           →  调用/括号/字面量/变量（二元运算均为左结合）
    调用：名字(参数, ...)，包括内置函数 print。

AST 说明：FnDef.params 是 (参数名, 类型) 二元组的列表。
红线：不检查类型、不检查变量声明、不生成 C——那些是下一关的事。
"""

from dataclasses import dataclass

from lexer import Token


# ---------- AST（节点与字段名和规格逐字一致） ----------

@dataclass
class IntLit:  value: int
@dataclass
class BoolLit: value: bool
@dataclass
class Var:     name: str
@dataclass
class BinOp:   op: str; left: object; right: object
@dataclass
class Unary:   op: str; operand: object
@dataclass
class Call:    name: str; args: list
@dataclass
class Let:     name: str; type: str; expr: object
@dataclass
class Assign:  name: str; expr: object
@dataclass
class If:      cond: object; then: list; els: list
@dataclass
class While:   cond: object; body: list
@dataclass
class Return:  expr: object
@dataclass
class ExprStmt: expr: object
@dataclass
class FnDef:   name: str; params: list; ret: str; body: list
@dataclass
class Program: fns: list


# ---------- 错误 ----------

class ParseError(Exception):
    """语法错误。携带 line / col 属性，message 里也带有行列号。"""

    def __init__(self, message: str, line: int, col: int):
        super().__init__(f'第 {line} 行第 {col} 列: {message}')
        self.line = line
        self.col = col


# ---------- 递归下降分析器 ----------

class Parser:
    def __init__(self, tokens: list[Token]):
        # 容错：调用方忘给 EOF 时补一个，位置取最后一个 token（或 1:1）。
        self.toks = list(tokens)
        if not self.toks or self.toks[-1].kind != 'EOF':
            line = self.toks[-1].line if self.toks else 1
            col = self.toks[-1].col if self.toks else 1
            self.toks.append(Token('EOF', '', line, col))
        self.pos = 0

    # ---- 基础工具 ----

    def peek(self, off: int = 0) -> Token:
        return self.toks[min(self.pos + off, len(self.toks) - 1)]

    def advance(self) -> Token:
        tok = self.toks[self.pos]
        if tok.kind != 'EOF':
            self.pos += 1
        return tok

    def error(self, msg: str, tok: Token | None = None):
        tok = tok or self.peek()
        raise ParseError(msg, tok.line, tok.col)

    def check(self, kind: str, value: str | None = None, off: int = 0) -> bool:
        tok = self.peek(off)
        return tok.kind == kind and (value is None or tok.value == value)

    def accept(self, kind: str, value: str | None = None) -> Token | None:
        if self.check(kind, value):
            return self.advance()
        return None

    def expect(self, kind: str, value: str | None = None, what: str | None = None) -> Token:
        if self.check(kind, value):
            return self.advance()
        tok = self.peek()
        want = what or (f"'{value}'" if value is not None else kind)
        if tok.kind == 'EOF':
            self.error(f'需要 {want}，但输入在这里提前结束')
        self.error(f'需要 {want}，实际是 {tok.value!r}')

    # ---- 程序 = 函数定义*（至少要有 main） ----

    def parse_program(self) -> Program:
        fns = []
        while not self.check('EOF'):
            fns.append(self.parse_fn())
        if not any(fn.name == 'main' for fn in fns):
            eof = self.peek()
            raise ParseError("程序必须定义 main 函数", eof.line, eof.col)
        return Program(fns)

    # ---- 函数 = fn 名字(参数: 类型, ...) -> 类型 { 语句* } ----

    def parse_fn(self) -> FnDef:
        self.expect('KEYWORD', 'fn')
        name = self.expect('IDENT', what='函数名').value
        self.expect('OP', '(')
        params = []
        if not self.check('OP', ')'):
            while True:
                pname = self.expect('IDENT', what='参数名').value
                self.expect('OP', ':')
                params.append((pname, self.parse_type()))
                if not self.accept('OP', ','):
                    break
        self.expect('OP', ')')
        self.expect('OP', '->')
        ret = self.parse_type()
        body = self.parse_block()
        return FnDef(name, params, ret, body)

    # 类型名：接受 IDENT 或 KEYWORD（int/bool 两种词法方案都兼容）。
    def parse_type(self) -> str:
        tok = self.peek()
        if tok.kind in ('IDENT', 'KEYWORD'):
            self.advance()
            return tok.value
        if tok.kind == 'EOF':
            self.error('需要类型名，但输入在这里提前结束')
        self.error(f'需要类型名，实际是 {tok.value!r}')

    # ---- 语句 ----

    def parse_block(self) -> list:
        self.expect('OP', '{')
        stmts = []
        while not self.check('OP', '}'):
            if self.check('EOF'):
                self.error("需要 '}'，但输入在这里提前结束")
            stmts.append(self.parse_stmt())
        self.advance()  # '}'
        return stmts

    def parse_stmt(self):
        tok = self.peek()
        if tok.kind == 'KEYWORD':
            if tok.value == 'let':
                return self.parse_let()
            if tok.value == 'if':
                return self.parse_if()
            if tok.value == 'while':
                return self.parse_while()
            if tok.value == 'return':
                return self.parse_return()
            self.error(f'意外的关键字 {tok.value!r}')
        # 名字 = 表达式 ;  形式：IDENT 后面紧跟单个 '='（'==' 不会误伤）。
        if tok.kind == 'IDENT' and self.check('OP', '=', off=1):
            name = self.advance().value
            self.advance()  # '='
            expr = self.parse_expr()
            self.expect('OP', ';')
            return Assign(name, expr)
        expr = self.parse_expr()
        self.expect('OP', ';')
        return ExprStmt(expr)

    def parse_let(self) -> Let:
        self.expect('KEYWORD', 'let')
        name = self.expect('IDENT', what='变量名').value
        self.expect('OP', ':')
        ty = self.parse_type()
        self.expect('OP', '=')
        expr = self.parse_expr()
        self.expect('OP', ';')
        return Let(name, ty, expr)

    def parse_if(self) -> If:
        self.expect('KEYWORD', 'if')
        cond = self.parse_expr()
        then = self.parse_block()
        els = []
        if self.accept('KEYWORD', 'else'):
            els = self.parse_block()
        return If(cond, then, els)

    def parse_while(self) -> While:
        self.expect('KEYWORD', 'while')
        cond = self.parse_expr()
        body = self.parse_block()
        return While(cond, body)

    def parse_return(self) -> Return:
        self.expect('KEYWORD', 'return')
        expr = self.parse_expr()
        self.expect('OP', ';')
        return Return(expr)

    # ---- 表达式（优先级从低到高，二元运算左结合） ----

    def parse_expr(self):
        return self.parse_equality()

    def _binary(self, ops: tuple[str, ...], next_level):
        node = next_level()
        while self.peek().kind == 'OP' and self.peek().value in ops:
            op = self.advance().value
            node = BinOp(op, node, next_level())
        return node

    def parse_equality(self):
        return self._binary(('==', '!='), self.parse_relational)

    def parse_relational(self):
        return self._binary(('<', '>', '<=', '>='), self.parse_additive)

    def parse_additive(self):
        return self._binary(('+', '-'), self.parse_multiplicative)

    def parse_multiplicative(self):
        return self._binary(('*', '/', '%'), self.parse_unary)

    def parse_unary(self):
        if self.check('OP', '-'):
            self.advance()
            return Unary('-', self.parse_unary())
        return self.parse_primary()

    def parse_primary(self):
        tok = self.peek()
        if tok.kind == 'INT':
            self.advance()
            return IntLit(int(tok.value))
        if tok.value in ('true', 'false') and tok.kind in ('KEYWORD', 'IDENT'):
            self.advance()
            return BoolLit(tok.value == 'true')
        if tok.kind == 'IDENT':
            self.advance()
            if self.accept('OP', '('):
                args = []
                if not self.check('OP', ')'):
                    args.append(self.parse_expr())
                    while self.accept('OP', ','):
                        args.append(self.parse_expr())
                self.expect('OP', ')')
                return Call(tok.value, args)
            return Var(tok.value)
        if self.accept('OP', '('):
            expr = self.parse_expr()
            self.expect('OP', ')')
            return expr
        if tok.kind == 'EOF':
            self.error('需要表达式，但输入在这里提前结束')
        self.error(f'需要表达式，实际是 {tok.value!r}')


# ---------- 对外接口 ----------

def parse(tokens: list[Token]) -> Program:
    """把 Token 列表解析成 Program AST；语法错误抛 ParseError（带行号）。"""
    return Parser(tokens).parse_program()


# ---------- 自测 ----------

if __name__ == '__main__':
    import lexer
    from dataclasses import asdict
    from pprint import pprint

    SAMPLE = """\
fn add(a: int, b: int) -> int {
    return a + b;
}

fn main() -> int {
    let n: int = 1 + 2 * 3 - 8 / 4 % 3;
    let ok: bool = n < 10 == true;
    let m: int = -n + (2 - 1) % 3;
    if ok != false {
        m = m * 2;
    } else {
        print(0);
    }
    while m > 0 {
        m = m - 1;
    }
    print(add(m, n) >= 0);
    print(-m);
    return 0;
}
"""

    ast = parse(lexer.tokenize(SAMPLE))
    print('语法分析通过，AST 如下：')
    pprint(asdict(ast), width=100, sort_dicts=False)
