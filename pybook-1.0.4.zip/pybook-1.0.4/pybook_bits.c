/* PYbook bits 库（bs.*）：位运算。实现见 pybook_bits.h 的两层说明。
 *
 * 只依赖 pybook_rt 的 Value 盒子与 C99 标准库，不引入新依赖。
 * 自测（核心层，不接运行时）：
 *     gcc -O2 -DPB_SELF_TEST pybook_bits.c -o bits_test.exe -I.
 * 只编核心层：直接 gcc -c pybook_bits.c（不定义 PB_BITS_BINDING、也不 include 运行时头）
 */

#include "pybook_bits.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* ---------------- 核心层：纯 C，零依赖 ---------------- */

unsigned long long pb_and(unsigned long long a, unsigned long long b) { return a & b; }
unsigned long long pb_or (unsigned long long a, unsigned long long b) { return a | b; }
unsigned long long pb_xor(unsigned long long a, unsigned long long b) { return a ^ b; }
unsigned long long pb_not(unsigned long long a) { return ~a; }

unsigned long long pb_shl(unsigned long long a, int n)
{
    if (n < 0 || n >= 64) return 0;          /* 越界按 0（不踩 UB） */
    return a << n;
}

unsigned long long pb_shr(unsigned long long a, int n)
{
    if (n < 0 || n >= 64) return 0;
    return a >> n;
}

int pb_get(unsigned long long a, int i)
{
    if (i < 0 || i >= 64) return 0;
    return (int)((a >> i) & 1ULL);
}

unsigned long long pb_set(unsigned long long a, int i, int v)
{
    if (i < 0 || i >= 64) return a;
    if (v) return a | (1ULL << i);
    return a & ~(1ULL << i);
}

int pb_popcount(unsigned long long a)
{
    int c = 0;
    while (a) { c += (int)(a & 1ULL); a >>= 1; }
    return c;
}

unsigned long long pb_mask(int w)
{
    if (w <= 0) return 0;
    if (w >= 64) return ~0ULL;
    return (1ULL << w) - 1ULL;
}

void pb_bin_str(unsigned long long a, char *out, size_t cap)
{
    if (!out || cap == 0) return;
    if (a == 0) { if (cap >= 2) { out[0] = '0'; out[1] = '\0'; } else out[0] = '\0'; return; }
    char tmp[64];
    int n = 0;
    while (a) { tmp[n++] = (char)('0' + (int)(a & 1ULL)); a >>= 1; }
    if ((size_t)n + 1 > cap) n = (int)cap - 1;      /* 缓冲不够就截断，绝不越界写 */
    for (int i = 0; i < n; i++) out[i] = tmp[n - 1 - i];
    out[n] = '\0';
}

void pb_hex_str(unsigned long long a, char *out)
{
    static const char *D = "0123456789ABCDEF";
    if (!out) return;
    out[0] = '0'; out[1] = 'x';
    int started = 0, p = 2;
    for (int sh = 60; sh >= 0; sh -= 4) {
        int d = (int)((a >> sh) & 0xFULL);
        if (d == 0 && !started && sh != 0) continue;
        started = 1;
        out[p++] = D[d];
    }
    out[p] = '\0';
}

int pb_bin_parse(const char *s, unsigned long long *out)
{
    if (!s || !out) return -1;
    if (s[0] == '0' && (s[1] == 'b' || s[1] == 'B')) s += 2;
    if (*s == '\0') return -1;
    unsigned long long v = 0;
    for (const char *p = s; *p; p++) {
        if (*p != '0' && *p != '1') return -1;
        if (v > (~0ULL >> 1)) return -1;          /* 溢出保护 */
        v = (v << 1) | (unsigned long long)(*p - '0');
    }
    *out = v;
    return 0;
}

static int hex_digit(char c)
{
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    if (c >= 'A' && c <= 'F') return c - 'A' + 10;
    return -1;
}

int pb_hex_parse(const char *s, unsigned long long *out)
{
    if (!s || !out) return -1;
    if (s[0] == '0' && (s[1] == 'x' || s[1] == 'X')) s += 2;
    if (*s == '\0') return -1;
    unsigned long long v = 0;
    for (const char *p = s; *p; p++) {
        int d = hex_digit(*p);
        if (d < 0) return -1;
        if (v > (~0ULL >> 4)) return -1;
        v = (v << 4) | (unsigned long long)d;
    }
    *out = v;
    return 0;
}

/* ---------------- 绑定层：PYbook Value <-> C ---------------- */

#if defined(PYBOOK_RT_H) || defined(PB_BITS_BINDING) || defined(MP_RT_BINDING)

static void bs_die(const char *who, const char *msg)
{
    fprintf(stderr, "运行时错误: bs.%s：%s\n", who, msg);
    exit(1);
}

/* 取一个整数参数：浮点按截断取整（与语言其余部分一致） */
static unsigned long long bs_arg_u64(Value v, const char *who)
{
    double d;
    if (IS_FLT(v))            d = AS_FLT(v);
    else if (IS_INT(v) || IS_BIGINT(v)) d = (double)rt_to_ll(v);
    else if (IS_BOOL(v))      d = (double)AS_BOOL(v);
    else { bs_die(who, "需要数字参数"); return 0; }
    if (d < 0) d = -d;                       /* 负数按无符号重解释的绝对值处理 */
    return (unsigned long long)d;
}

static int bs_arg_int(Value v, const char *who)
{
    double d;
    if (IS_FLT(v))            d = AS_FLT(v);
    else if (IS_INT(v) || IS_BIGINT(v)) d = (double)rt_to_ll(v);
    else if (IS_BOOL(v))      d = (double)AS_BOOL(v);
    else { bs_die(who, "需要数字参数"); return 0; }
    return (int)d;
}

/* 无符号结果回落成 Value：超过 long long 正范围就退成浮点，
   避免 rt_int 把大数装坏 */
static Value bs_ret_u64(unsigned long long x)
{
    if (x <= (unsigned long long)9223372036854775807LL)
        return rt_int((long long)x);
    return rt_float((double)x);
}

Value rt_bs_and(Value a, Value b) { return bs_ret_u64(pb_and(bs_arg_u64(a, "and"), bs_arg_u64(b, "and"))); }
Value rt_bs_or (Value a, Value b) { return bs_ret_u64(pb_or (bs_arg_u64(a, "or"),  bs_arg_u64(b, "or"))); }
Value rt_bs_xor(Value a, Value b) { return bs_ret_u64(pb_xor(bs_arg_u64(a, "xor"), bs_arg_u64(b, "xor"))); }
Value rt_bs_not(Value a)          { return bs_ret_u64(pb_not(bs_arg_u64(a, "not"))); }

Value rt_bs_shl(Value a, Value n) { return bs_ret_u64(pb_shl(bs_arg_u64(a, "shl"), bs_arg_int(n, "shl"))); }
Value rt_bs_shr(Value a, Value n) { return bs_ret_u64(pb_shr(bs_arg_u64(a, "shr"), bs_arg_int(n, "shr"))); }

Value rt_bs_get(Value a, Value i)
{
    int bit = bs_arg_int(i, "get");
    if (bit < 0 || bit >= 64) bs_die("get", "位序号要在 0~63");
    return rt_int(pb_get(bs_arg_u64(a, "get"), bit));
}

Value rt_bs_set(Value a, Value i, Value v)
{
    int bit = bs_arg_int(i, "set");
    if (bit < 0 || bit >= 64) bs_die("set", "位序号要在 0~63");
    int on = (bs_arg_int(v, "set") != 0) ? 1 : 0;
    return bs_ret_u64(pb_set(bs_arg_u64(a, "set"), bit, on));
}

Value rt_bs_popcount(Value a) { return rt_int(pb_popcount(bs_arg_u64(a, "popcount"))); }
Value rt_bs_band(Value a)     { return rt_int(pb_popcount(bs_arg_u64(a, "band"))); }

Value rt_bs_mask(Value w)
{
    int n = bs_arg_int(w, "mask");
    if (n < 0) bs_die("mask", "位数不能为负");
    return bs_ret_u64(pb_mask(n));
}

Value rt_bs_hex(Value a)
{
    char buf[24];
    pb_hex_str(bs_arg_u64(a, "hex"), buf);
    return rt_str(buf);
}

Value rt_bs_bin(Value a)
{
    char buf[72];
    pb_bin_str(bs_arg_u64(a, "bin"), buf, sizeof(buf));
    return rt_str(buf);
}

Value rt_bs_frombin(Value s)
{
    if (!IS_STR(s)) bs_die("frombin", "需要字符串参数");
    unsigned long long v = 0;
    if (pb_bin_parse(rt_str_of(s), &v) != 0)
        bs_die("frombin", "不是合法的二进制串（只认 0/1，可带 0b 前缀）");
    return bs_ret_u64(v);
}

Value rt_bs_fromhex(Value s)
{
    if (!IS_STR(s)) bs_die("fromhex", "需要字符串参数");
    unsigned long long v = 0;
    if (pb_hex_parse(rt_str_of(s), &v) != 0)
        bs_die("fromhex", "不是合法的十六进制串（可带 0x 前缀）");
    return bs_ret_u64(v);
}

#endif /* 绑定层 */

/* ---------------- 核心层自检（不接运行时也能跑） ---------------- */
#ifdef PB_SELF_TEST

static int g_fail = 0;
#define CHK(cond, name) do { \
    if (!(cond)) { printf("失败: %s\n", name); g_fail++; } \
    else printf("通过: %s\n", name); \
} while (0)

int main(void)
{
    CHK(pb_and(0xF0, 0x3C) == 0x30, "and");
    CHK(pb_or(0xF0, 0x0C) == 0xFC, "or");
    CHK(pb_xor(0xFF, 0x0F) == 0xF0, "xor");
    CHK(pb_shl(1, 10) == 1024, "shl");
    CHK(pb_shl(1, 64) == 0, "shl 越界归零");
    CHK(pb_shr(256, 4) == 16, "shr");
    CHK(pb_get(0b1010, 1) == 1 && pb_get(0b1010, 2) == 0, "get");
    CHK(pb_set(0, 3, 1) == 8 && pb_set(8, 3, 0) == 0, "set");
    CHK(pb_popcount(0xFF) == 8 && pb_popcount(0) == 0, "popcount");
    CHK(pb_mask(0) == 0 && pb_mask(4) == 0xF, "mask");

    char b[80], h[24];
    pb_bin_str(0, b, sizeof(b));   CHK(strcmp(b, "0") == 0, "bin 0");
    pb_bin_str(5, b, sizeof(b));   CHK(strcmp(b, "101") == 0, "bin 5");
    pb_hex_str(255, h);            CHK(strcmp(h, "0xFF") == 0, "hex 255");
    pb_hex_str(0, h);              CHK(strcmp(h, "0x0") == 0, "hex 0");

    unsigned long long v = 0;
    CHK(pb_bin_parse("1010", &v) == 0 && v == 10, "bin_parse 1010");
    CHK(pb_bin_parse("0b11", &v) == 0 && v == 3, "bin_parse 0b11");
    CHK(pb_bin_parse("102", &v) == -1, "bin_parse 非法");
    CHK(pb_hex_parse("FF", &v) == 0 && v == 255, "hex_parse FF");
    CHK(pb_hex_parse("0x10", &v) == 0 && v == 16, "hex_parse 0x10");
    CHK(pb_hex_parse("zz", &v) == -1, "hex_parse 非法");

    printf(g_fail ? "\n%d 项失败\n" : "\n全部通过\n", g_fail);
    return g_fail ? 1 : 0;
}

#endif /* PB_SELF_TEST */
