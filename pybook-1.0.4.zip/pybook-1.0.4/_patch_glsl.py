# -*- coding: utf-8 -*-
"""给 pybook_hw3d.c 加"可编程管线（GLSL）骨架"。
   所有锚点都断言 count == 1，任一失败即整体不写回（原子性）。
   补丁脚本可重复运行（幂等：第二次跑会因 count==0 报错退出，不会双改）。"""
import io
import sys

PATH = 'pybook_hw3d.c'
s = io.open(PATH, encoding='utf-8').read()

PATCHES = []

# ---------------------------------------------------------------- P1 头文件
PATCHES.append((
    'include-glext',
    '#include <windows.h>            /* MultiByteToWideChar：中文路径转 UTF-16 */\n',
    '#include <windows.h>            /* MultiByteToWideChar：中文路径转 UTF-16 */\n'
    '\n'
    '/* GL 2.0+ 的入口类型（PFNGL*PROC）。\n'
    '   windows.h 必须先到位：glext.h 里的 APIENTRYP 依赖 APIENTRY 展开成 __stdcall。\n'
    '   这里只要类型声明，不要原型 —— 入口全靠 SDL_GL_GetProcAddress 运行时取。 */\n'
    '#include <GL/glext.h>\n',
))

# ---------------------------------------------------------------- P2 文件头接口表
PATCHES.append((
    'header-api',
    ' *   hw.fog(起,止)  hw.far(距离)  hw.fov(角度)  hw.near(距离)  hw.wire(0/1)\n',
    ' *   hw.fog(起,止)  hw.far(距离)  hw.fov(角度)  hw.near(距离)  hw.wire(0/1)\n'
    ' *   --- 可编程管线（GLSL）：不指定就照旧走固定管线，老程序零改动 ---\n'
    ' *   hw.preset(槽,名字)  hw.shader(槽,顶点源码,片段源码)  hw.shaderuse(槽)  hw.uni(名,值...)\n',
))

# ---------------------------------------------------------------- P3 函数指针表
PATCHES.append((
    'gl-funcptrs',
    'static int hw_u8(int x)\n'
    '{\n'
    '    return x < 0 ? 0 : x > 255 ? 255 : x;\n'
    '}\n'
    '\n'
    '/* ================= 状态 ================= */\n',
    'static int hw_u8(int x)\n'
    '{\n'
    '    return x < 0 ? 0 : x > 255 ? 255 : x;\n'
    '}\n'
    '\n'
    '/* ================= GL 2.0+ 入口加载（可编程管线的地基） =================\n'
    '   血泪教训：Windows 的 opengl32.dll 只导出 GL 1.1 —— glCreateShader 这些\n'
    '   GL 2.0+ 的入口在链接期根本找不到原型符号，必须用 SDL_GL_GetProcAddress\n'
    '   在运行时取函数指针（_gl120_probe.c 实测：驱动真实版本是 OpenGL 4.6\n'
    '   兼容 profile，GLSL 120 和 330 都能编译）。\n'
    '   所以"用不了着色器"从来不是能力问题，只是缺这一张表。\n'
    '   类型来自 <GL/glext.h>，活动工具链自带，不需要 GLEW / glad。 */\n'
    'typedef struct {\n'
    '    /* 着色器编译 / 链接 */\n'
    '    PFNGLCREATESHADERPROC       CreateShader;\n'
    '    PFNGLSHADERSOURCEPROC       ShaderSource;\n'
    '    PFNGLCOMPILESHADERPROC      CompileShader;\n'
    '    PFNGLGETSHADERIVPROC        GetShaderiv;\n'
    '    PFNGLGETSHADERINFOLOGPROC   GetShaderInfoLog;\n'
    '    PFNGLDELETESHADERPROC       DeleteShader;\n'
    '    PFNGLCREATEPROGRAMPROC      CreateProgram;\n'
    '    PFNGLATTACHSHADERPROC       AttachShader;\n'
    '    PFNGLLINKPROGRAMPROC        LinkProgram;\n'
    '    PFNGLGETPROGRAMIVPROC       GetProgramiv;\n'
    '    PFNGLGETPROGRAMINFOLOGPROC  GetProgramInfoLog;\n'
    '    PFNGLUSEPROGRAMPROC         UseProgram;\n'
    '    PFNGLDELETEPROGRAMPROC      DeleteProgram;\n'
    '    /* uniform */\n'
    '    PFNGLGETUNIFORMLOCATIONPROC GetUniformLocation;\n'
    '    PFNGLUNIFORM1FPROC          Uniform1f;\n'
    '    PFNGLUNIFORM2FPROC          Uniform2f;\n'
    '    PFNGLUNIFORM3FPROC          Uniform3f;\n'
    '    PFNGLUNIFORM4FPROC          Uniform4f;\n'
    '    PFNGLUNIFORM1IPROC          Uniform1i;\n'
    '    PFNGLACTIVETEXTUREPROC      ActiveTexture;\n'
    '    /* 预先取好，留给下一步（阴影贴图 / 后处理）—— 本版暂不使用 */\n'
    '    PFNGLGENFRAMEBUFFERSPROC        GenFramebuffers;\n'
    '    PFNGLBINDFRAMEBUFFERPROC        BindFramebuffer;\n'
    '    PFNGLFRAMEBUFFERTEXTURE2DPROC   FramebufferTexture2D;\n'
    '    PFNGLCHECKFRAMEBUFFERSTATUSPROC CheckFramebufferStatus;\n'
    '    PFNGLGENRENDERBUFFERSPROC       GenRenderbuffers;\n'
    '    PFNGLBINDRENDERBUFFERPROC       BindRenderbuffer;\n'
    '    PFNGLRENDERBUFFERSTORAGEPROC    RenderbufferStorage;\n'
    '} HwGL;\n'
    '\n'
    'static HwGL glapi;\n'
    'static int  g_gl_ok    = 0;   /* 着色器那条路必需的入口是否齐了 */\n'
    'static int  g_gl_tried = 0;   /* 只在建好上下文后加载一次 */\n'
    '\n'
    'static void hw_gl_load(void)\n'
    '{\n'
    '    if (g_gl_tried)\n'
    '        return;\n'
    '    g_gl_tried = 1;\n'
    '#define HW_GET(field, pfn, name) glapi.field = (pfn)SDL_GL_GetProcAddress(name)\n'
    '    HW_GET(CreateShader,          PFNGLCREATESHADERPROC,       "glCreateShader");\n'
    '    HW_GET(ShaderSource,          PFNGLSHADERSOURCEPROC,       "glShaderSource");\n'
    '    HW_GET(CompileShader,         PFNGLCOMPILESHADERPROC,      "glCompileShader");\n'
    '    HW_GET(GetShaderiv,           PFNGLGETSHADERIVPROC,        "glGetShaderiv");\n'
    '    HW_GET(GetShaderInfoLog,      PFNGLGETSHADERINFOLOGPROC,   "glGetShaderInfoLog");\n'
    '    HW_GET(DeleteShader,          PFNGLDELETESHADERPROC,       "glDeleteShader");\n'
    '    HW_GET(CreateProgram,         PFNGLCREATEPROGRAMPROC,      "glCreateProgram");\n'
    '    HW_GET(AttachShader,          PFNGLATTACHSHADERPROC,       "glAttachShader");\n'
    '    HW_GET(LinkProgram,           PFNGLLINKPROGRAMPROC,        "glLinkProgram");\n'
    '    HW_GET(GetProgramiv,          PFNGLGETPROGRAMIVPROC,       "glGetProgramiv");\n'
    '    HW_GET(GetProgramInfoLog,     PFNGLGETPROGRAMINFOLOGPROC,  "glGetProgramInfoLog");\n'
    '    HW_GET(UseProgram,            PFNGLUSEPROGRAMPROC,         "glUseProgram");\n'
    '    HW_GET(DeleteProgram,         PFNGLDELETEPROGRAMPROC,      "glDeleteProgram");\n'
    '    HW_GET(GetUniformLocation,    PFNGLGETUNIFORMLOCATIONPROC, "glGetUniformLocation");\n'
    '    HW_GET(Uniform1f,             PFNGLUNIFORM1FPROC,          "glUniform1f");\n'
    '    HW_GET(Uniform2f,             PFNGLUNIFORM2FPROC,          "glUniform2f");\n'
    '    HW_GET(Uniform3f,             PFNGLUNIFORM3FPROC,          "glUniform3f");\n'
    '    HW_GET(Uniform4f,             PFNGLUNIFORM4FPROC,          "glUniform4f");\n'
    '    HW_GET(Uniform1i,             PFNGLUNIFORM1IPROC,          "glUniform1i");\n'
    '    HW_GET(ActiveTexture,         PFNGLACTIVETEXTUREPROC,      "glActiveTexture");\n'
    '    HW_GET(GenFramebuffers,       PFNGLGENFRAMEBUFFERSPROC,    "glGenFramebuffers");\n'
    '    HW_GET(BindFramebuffer,       PFNGLBINDFRAMEBUFFERPROC,    "glBindFramebuffer");\n'
    '    HW_GET(FramebufferTexture2D,  PFNGLFRAMEBUFFERTEXTURE2DPROC, "glFramebufferTexture2D");\n'
    '    HW_GET(CheckFramebufferStatus, PFNGLCHECKFRAMEBUFFERSTATUSPROC, "glCheckFramebufferStatus");\n'
    '    HW_GET(GenRenderbuffers,      PFNGLGENRENDERBUFFERSPROC,   "glGenRenderbuffers");\n'
    '    HW_GET(BindRenderbuffer,      PFNGLBINDRENDERBUFFERPROC,   "glBindRenderbuffer");\n'
    '    HW_GET(RenderbufferStorage,   PFNGLRENDERBUFFERSTORAGEPROC, "glRenderbufferStorage");\n'
    '#undef HW_GET\n'
    '    g_gl_ok = (glapi.CreateShader && glapi.ShaderSource && glapi.CompileShader &&\n'
    '               glapi.GetShaderiv && glapi.DeleteShader && glapi.CreateProgram &&\n'
    '               glapi.AttachShader && glapi.LinkProgram && glapi.GetProgramiv &&\n'
    '               glapi.UseProgram && glapi.DeleteProgram &&\n'
    '               glapi.GetUniformLocation && glapi.Uniform1f && glapi.Uniform3f) ? 1 : 0;\n'
    '}\n'
    '\n'
    '/* ================= 状态 ================= */\n',
))

# ---------------------------------------------------------------- P4 op 枚举
PATCHES.append((
    'op-enum',
    'enum { OP_BOX = 0, OP_SPHERE, OP_CYL, OP_LINE, OP_PUSH, OP_POP };\n',
    'enum { OP_BOX = 0, OP_SPHERE, OP_CYL, OP_LINE, OP_PUSH, OP_POP,\n'
    '       OP_UNI,     /* 设一个 uniform */\n'
    '       OP_PROG };  /* 切换着色器程序（槽 0 = 回固定管线） */\n',
))

# ---------------------------------------------------------------- P5 着色器状态
PATCHES.append((
    'shader-state',
    'static int    g_curtex = 0;      /* 当前贴图槽（提交图元时记进图元里） */\n'
    'static float  g_curuv  = 1.0f;   /* 当前 UV 重复次数 */\n',
    'static int    g_curtex = 0;      /* 当前贴图槽（提交图元时记进图元里） */\n'
    'static float  g_curuv  = 1.0f;   /* 当前 UV 重复次数 */\n'
    '\n'
    '/* ---- 可编程管线（GLSL）----\n'
    '   槽 0 = "不用着色器" → 走原来的固定管线（老程序零改动）。槽 1~7 放程序。\n'
    '   着色器约定用 GLSL #version 120：兼容 profile 下 gl_Vertex / gl_Normal /\n'
    '   gl_Color / gl_MultiTexCoord0 / gl_ModelViewProjectionMatrix / gl_NormalMatrix\n'
    '   都由立即模式自动喂进来 —— 现有 glBegin 几何一行都不用改成 VBO。 */\n'
    '#define HW_SHADER_SLOTS 8\n'
    'static GLuint g_progs[HW_SHADER_SLOTS];\n'
    'static GLint  g_ulight[HW_SHADER_SLOTS];  /* 每个程序里 uLight 的位置缓存 */\n'
    'static int    g_curprog    = 0;   /* 帧开始时绑哪个程序（shaderuse 最后一次） */\n'
    'static GLuint g_bound_prog = 0;   /* 当前真正 UseProgram 着的（0 = 固定管线） */\n'
    'static GLuint g_white_tex  = 0;   /* 1x1 白纹理：着色器模式没贴图时顶上去 */\n'
    '\n'
    '/* uniform 也走命令流：hw.uni 追加一条 OP_UNI，按脚本顺序生效。\n'
    '   kind = 分量个数（1 → float，2/3/4 → vec2/vec3/vec4）。 */\n'
    '#define HW_UNI_MAX 4096\n'
    'typedef struct {\n'
    '    char  name[64];\n'
    '    int   kind;\n'
    '    float v[4];\n'
    '    GLint  loc;        /* 位置缓存：同一个程序只查一次 */\n'
    '    GLuint loc_prog;\n'
    '} HwUni;\n'
    'static HwUni g_unis[HW_UNI_MAX];\n'
    'static int   g_nunis = 0;\n',
))

# ---------------------------------------------------------------- P6 rt_hw_open
PATCHES.append((
    'open-reset',
    '    memset(g_kprev, 0, sizeof g_kprev);\n'
    '    memset(g_kcur, 0, sizeof g_kcur);\n'
    '    g_mprev = g_mcur = 0;\n'
    '    glEnable(GL_DEPTH_TEST);\n',
    '    memset(g_kprev, 0, sizeof g_kprev);\n'
    '    memset(g_kcur, 0, sizeof g_kcur);\n'
    '    g_mprev = g_mcur = 0;\n'
    '    /* 着色器状态：旧上下文的程序对象随上下文一起没了，只清名字 */\n'
    '    memset(g_progs, 0, sizeof g_progs);\n'
    '    for (int i = 0; i < HW_SHADER_SLOTS; i++)\n'
    '        g_ulight[i] = -1;\n'
    '    g_curprog = 0;\n'
    '    g_bound_prog = 0;\n'
    '    g_nunis = 0;\n'
    '    g_white_tex = 0;\n'
    '    hw_gl_load();                 /* 取 GL 2.0+ 入口（带上下文才取得到） */\n'
    '    glEnable(GL_DEPTH_TEST);\n',
))

# ---------------------------------------------------------------- P7 lit() 反照率
PATCHES.append((
    'lit-albedo',
    'static float lit(float nx, float ny, float nz)\n'
    '{\n'
    '    float d = nx * g_lx + ny * g_ly + nz * g_lz;\n',
    'static float lit(float nx, float ny, float nz)\n'
    '{\n'
    '    /* 着色器模式：顶点色要让位给"纯反照率"。\n'
    '       固定管线把光照烤进 gl_Color；可编程管线要用真法线在片元里算光照，\n'
    '       所以这里返回 1.0 —— 送进 gl_Color 的就是图元本色，不会被重复乘一遍光。 */\n'
    '    if (g_curprog != 0)\n'
    '        return 1.0f;\n'
    '    float d = nx * g_lx + ny * g_ly + nz * g_lz;\n',
))

# ---------------------------------------------------------------- P8 盒子六面法线
for _k, _n in (('顶', '(0.0f, 1.0f, 0.0f)'),
               ('底', '(0.0f, -1.0f, 0.0f)'),
               ('前', '(0.0f, 0.0f, -1.0f)'),
               ('后', '(0.0f, 0.0f, 1.0f)'),
               ('左', '(-1.0f, 0.0f, 0.0f)'),
               ('右', '(1.0f, 0.0f, 0.0f)')):
    PATCHES.append((
        'box-normal-' + _k,
        '    k = lit%s;\n' % _n,
        '    k = lit%s;\n'
        '    glNormal3f%s;              /* 着色器要用真法线（固定管线无视） */\n' % (_n, _n),
    ))

# ---------------------------------------------------------------- P9 盒子线框法线
PATCHES.append((
    'box-wire-normal',
    '        glColor3f(r * 0.35f + 0.6f, g * 0.35f + 0.6f, bl * 0.35f + 0.6f);\n'
    '        glBegin(GL_LINES);\n',
    '        glColor3f(r * 0.35f + 0.6f, g * 0.35f + 0.6f, bl * 0.35f + 0.6f);\n'
    '        glNormal3f(0.0f, 1.0f, 0.0f);\n'
    '        glBegin(GL_LINES);\n',
))

# ---------------------------------------------------------------- P10 绑贴图
PATCHES.append((
    'bind-tex',
    'static void hw_bind_tex(int slot)\n'
    '{\n'
    '    if (slot > 0 && slot < HW_TEX_SLOTS && g_texs[slot] != 0) {\n'
    '        glEnable(GL_TEXTURE_2D);\n'
    '        glBindTexture(GL_TEXTURE_2D, g_texs[slot]);\n'
    '    } else {\n'
    '        glDisable(GL_TEXTURE_2D);\n'
    '    }\n'
    '}\n',
    'static void hw_bind_tex(int slot)\n'
    '{\n'
    '    /* 着色器模式：采样器读的是纹理单元 0，所以要显式 ActiveTexture。\n'
    '       没贴图时绑 1x1 白纹理 —— 采样得到 (1,1,1)，对乘法是单位元，\n'
    '       于是"有贴图/没贴图"可以共用同一段 GLSL，不会出现黑块。 */\n'
    '    if (g_gl_ok && glapi.ActiveTexture)\n'
    '        glapi.ActiveTexture(GL_TEXTURE0);\n'
    '    if (slot > 0 && slot < HW_TEX_SLOTS && g_texs[slot] != 0) {\n'
    '        glEnable(GL_TEXTURE_2D);\n'
    '        glBindTexture(GL_TEXTURE_2D, g_texs[slot]);\n'
    '    } else if (g_bound_prog != 0 && g_white_tex != 0) {\n'
    '        glEnable(GL_TEXTURE_2D);\n'
    '        glBindTexture(GL_TEXTURE_2D, g_white_tex);\n'
    '    } else {\n'
    '        glDisable(GL_TEXTURE_2D);\n'
    '    }\n'
    '}\n',
))

# ---------------------------------------------------------------- P11 球法线
PATCHES.append((
    'sphere-normal-a',
    '            nx = sy0 * sr->c[j]; ny = cy0; nz = sy0 * sr->s[j];\n'
    '            set_lit_color(lr, lg, lb, nx, ny, nz);\n'
    '            glTexCoord2f(uu, tv0);\n',
    '            nx = sy0 * sr->c[j]; ny = cy0; nz = sy0 * sr->s[j];\n'
    '            set_lit_color(lr, lg, lb, nx, ny, nz);\n'
    '            glNormal3f(nx, ny, nz);        /* 球面法线 = 归一化的相对中心向量 */\n'
    '            glTexCoord2f(uu, tv0);\n',
))
PATCHES.append((
    'sphere-normal-b',
    '            nx = sy1 * sr->c[j]; ny = cy1; nz = sy1 * sr->s[j];\n'
    '            set_lit_color(lr, lg, lb, nx, ny, nz);\n'
    '            glTexCoord2f(uu, tv1);\n',
    '            nx = sy1 * sr->c[j]; ny = cy1; nz = sy1 * sr->s[j];\n'
    '            set_lit_color(lr, lg, lb, nx, ny, nz);\n'
    '            glNormal3f(nx, ny, nz);\n'
    '            glTexCoord2f(uu, tv1);\n',
))

# ---------------------------------------------------------------- P12 柱法线
PATCHES.append((
    'cyl-normal-side-a',
    '            set_lit_color(lr, lg, lb, nx, nyy, nz);\n'
    '            glTexCoord2f(uu, 0.0f);\n',
    '            set_lit_color(lr, lg, lb, nx, nyy, nz);\n'
    '            glNormal3f(nx, nyy, nz);\n'
    '            glTexCoord2f(uu, 0.0f);\n',
))
PATCHES.append((
    'cyl-normal-side-b',
    '            set_lit_color(lr, lg, lb, nx, nyy, nz);\n'
    '            glTexCoord2f(uu, U);\n',
    '            set_lit_color(lr, lg, lb, nx, nyy, nz);\n'
    '            glNormal3f(nx, nyy, nz);\n'
    '            glTexCoord2f(uu, U);\n',
))
PATCHES.append((
    'cyl-normal-cap-top',
    '        set_lit_color(lr, lg, lb, 0.0f, 1.0f, 0.0f);\n'
    '        glBegin(GL_TRIANGLE_FAN);\n',
    '        set_lit_color(lr, lg, lb, 0.0f, 1.0f, 0.0f);\n'
    '        glNormal3f(0.0f, 1.0f, 0.0f);\n'
    '        glBegin(GL_TRIANGLE_FAN);\n',
))
PATCHES.append((
    'cyl-normal-cap-bot',
    '        set_lit_color(lr, lg, lb, 0.0f, -1.0f, 0.0f);\n'
    '        glBegin(GL_TRIANGLE_FAN);\n',
    '        set_lit_color(lr, lg, lb, 0.0f, -1.0f, 0.0f);\n'
    '        glNormal3f(0.0f, -1.0f, 0.0f);\n'
    '        glBegin(GL_TRIANGLE_FAN);\n',
))

# ---------------------------------------------------------------- P13 线框球/柱法线
PATCHES.append((
    'sphere-wire-normal',
    '    glColor3f(s->r / 255.0f * k + 0.6f, s->g / 255.0f * k + 0.6f, s->b / 255.0f * k + 0.6f);\n'
    '    glBegin(GL_LINES);\n',
    '    glColor3f(s->r / 255.0f * k + 0.6f, s->g / 255.0f * k + 0.6f, s->b / 255.0f * k + 0.6f);\n'
    '    glNormal3f(0.0f, 1.0f, 0.0f);\n'
    '    glBegin(GL_LINES);\n',
))
PATCHES.append((
    'cyl-wire-normal',
    '    glColor3f(c->r / 255.0f * k + 0.6f, c->g / 255.0f * k + 0.6f, c->b / 255.0f * k + 0.6f);\n'
    '    glBegin(GL_LINES);\n',
    '    glColor3f(c->r / 255.0f * k + 0.6f, c->g / 255.0f * k + 0.6f, c->b / 255.0f * k + 0.6f);\n'
    '    glNormal3f(0.0f, 1.0f, 0.0f);\n'
    '    glBegin(GL_LINES);\n',
))

# ---------------------------------------------------------------- P14 着色器 helper + 内置着色器
PATCHES.append((
    'shader-helper-block',
    '/* 按提交顺序执行命令流。push/pop 直接映射到 GL 的矩阵栈。\n',
    '''/* ============ 着色器 helper（编译 / 链接 / uniform / 内置着色器） ============
   注意 GLSL 版本选择：这里一律用 #version 120，不用 330 core。
   原因（_gl120_probe.c 实测）：兼容 profile 下 120 的着色器能直接读
   gl_Vertex / gl_Normal / gl_Color / gl_MultiTexCoord0 / gl_ModelViewProjectionMatrix，
   这些量由立即模式（glVertex3f / glNormal3f / glColor3f / glTexCoord2f）自动喂进来。
   → 现有 1400 行几何生成代码一行都不用改成 VBO/VAO，可编程管线直接"贴"上去。
   换 330 core 就得把 draw_box / draw_sphere / draw_cyl 全部重写成喂 buffer。 */

/* PYbook 的字符串字面量不支持转义、也不能跨行（词法层遇到换行就报未闭合）。
   所以着色器源码统一约定：字符串里写两字符的 \\n 当换行、\\t 当制表符。
   稍长的着色器建议写成 .vert/.frag 文件用 file.read 读进来 —— 编辑器里有
   语法高亮、也不受字符串规则捆住。这里做一次"折叠还原"，返回堆内存（调用方 free）。 */
static char *hw_unfold(const char *src)
{
    size_t n = strlen(src);
    char *out = (char *)malloc(n + 2);
    if (out == NULL)
        hw_die("hw.shader：内存不足");
    size_t k = 0;
    for (size_t i = 0; i < n; i++) {
        if (src[i] == '\\\\' && i + 1 < n) {
            char c = src[i + 1];
            if (c == 'n')  { out[k++] = '\\n'; i++; continue; }
            if (c == 't')  { out[k++] = '\\t'; i++; continue; }
            if (c == '\\\\') { out[k++] = '\\\\'; i++; continue; }
        }
        out[k++] = src[i];
    }
    out[k] = '\\0';
    return out;
}

/* 设一个 uniform 的默认值（建好程序后调一次）。k = 分量个数。 */
static void hw_setu(GLuint prog, const char *name, int k,
                    float a, float b, float c, float d)
{
    if (!g_gl_ok || prog == 0)
        return;
    GLint l = glapi.GetUniformLocation(prog, name);
    if (l < 0)
        return;                          /* 着色器里没这个 uniform：跳过 */
    glapi.UseProgram(prog);
    switch (k) {
    case 1:  glapi.Uniform1f(l, a); break;
    case 2:  glapi.Uniform2f(l, a, b); break;
    case 3:  glapi.Uniform3f(l, a, b, c); break;
    default: glapi.Uniform4f(l, a, b, c, d); break;
    }
}

/* 编译一个阶段。失败返回 0，并把日志写进 out（可为 NULL）。 */
static GLuint hw_compile_stage(GLenum type, const char *src, char *out, int outn)
{
    GLuint s = glapi.CreateShader(type);
    if (s == 0)
        return 0;
    glapi.ShaderSource(s, 1, &src, NULL);
    glapi.CompileShader(s);
    GLint ok = 0;
    glapi.GetShaderiv(s, GL_COMPILE_STATUS, &ok);
    if (!ok) {
        if (out != NULL && outn > 0) {
            out[0] = '\\0';
            if (glapi.GetShaderInfoLog)
                glapi.GetShaderInfoLog(s, outn, NULL, out);
        }
        glapi.DeleteShader(s);
        return 0;
    }
    return s;
}

/* 编译 + 链接一个程序。失败返回 0（日志进 out）。
   成功后自动设两个约定 uniform：uTex → 纹理单元 0，uTexMix → 1.0
   （这样"贴图 x 本色"开箱即用，没贴图的图元靠 1x1 白纹理兜底）。 */
static GLuint hw_build_program(const char *vs, const char *fs, char *out, int outn)
{
    GLuint v = hw_compile_stage(GL_VERTEX_SHADER, vs, out, outn);
    if (v == 0)
        return 0;
    GLuint f = hw_compile_stage(GL_FRAGMENT_SHADER, fs, out, outn);
    if (f == 0) {
        glapi.DeleteShader(v);
        return 0;
    }
    GLuint p = glapi.CreateProgram();
    glapi.AttachShader(p, v);
    glapi.AttachShader(p, f);
    glapi.LinkProgram(p);
    glapi.DeleteShader(v);               /* 删除是延迟的：链上了就无所谓 */
    glapi.DeleteShader(f);
    GLint ok = 0;
    glapi.GetProgramiv(p, GL_LINK_STATUS, &ok);
    if (!ok) {
        if (out != NULL && outn > 0) {
            out[0] = '\\0';
            if (glapi.GetProgramInfoLog)
                glapi.GetProgramInfoLog(p, outn, NULL, out);
        }
        glapi.DeleteProgram(p);
        return 0;
    }
    hw_setu(p, "uTex", 1, 0.0f, 0.0f, 0.0f, 0.0f);
    hw_setu(p, "uTexMix", 1, 1.0f, 0.0f, 0.0f, 0.0f);
    glapi.UseProgram(0);
    return p;
}

/* 应用一条 uniform（位置按程序缓存，同一个程序只查一次）。
   着色器里没声明的名字静默跳过 —— 脚本里多设几个不存在的 uniform 不该崩。 */
static void hw_apply_uni(HwUni *u)
{
    if (!g_gl_ok || g_bound_prog == 0 || u->name[0] == '\\0')
        return;
    if (u->loc_prog != g_bound_prog) {
        u->loc = glapi.GetUniformLocation(g_bound_prog, u->name);
        u->loc_prog = g_bound_prog;
    }
    if (u->loc < 0)
        return;
    switch (u->kind) {
    case 1:  glapi.Uniform1f(u->loc, u->v[0]); break;
    case 2:  glapi.Uniform2f(u->loc, u->v[0], u->v[1]); break;
    case 3:  glapi.Uniform3f(u->loc, u->v[0], u->v[1], u->v[2]); break;
    default: glapi.Uniform4f(u->loc, u->v[0], u->v[1], u->v[2], u->v[3]); break;
    }
}

/* 1x1 白纹理：着色器模式下"这个图元没有贴图"时顶上去。
   采样得到 (1,1,1)，对乘法是单位元，所以一段 GLSL 能同时应付两种情况。 */
static void hw_white_tex(void)
{
    static const unsigned char px[4] = { 255, 255, 255, 255 };
    if (g_white_tex != 0)
        return;
    glGenTextures(1, &g_white_tex);
    glBindTexture(GL_TEXTURE_2D, g_white_tex);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, 1, 1, 0, GL_RGBA, GL_UNSIGNED_BYTE, px);
    glBindTexture(GL_TEXTURE_2D, 0);
}

/* ---- 内置着色器（hw.preset）----
   共同顶点阶段：把法线/本色/UV/视空间位置转成 varying 传给片段阶段。
   gl_NormalMatrix 会把模型view 的旋转正确作用到法线上 ——
   这一点比固定管线那套"轴对齐法线 + 烤光"还准（物体自转时光照跟着转）。 */
static const char *HW_PRESET_VS =
    "#version 120\\n"
    "varying vec3 vN;\\n"
    "varying vec3 vC;\\n"
    "varying vec2 vUV;\\n"
    "varying vec3 vEye;\\n"
    "void main(){\\n"
    "  vN = gl_NormalMatrix * gl_Normal;\\n"
    "  vC = gl_Color.rgb;\\n"
    "  vUV = gl_MultiTexCoord0.xy;\\n"
    "  vEye = (gl_ModelViewMatrix * gl_Vertex).xyz;\\n"
    "  gl_Position = gl_ModelViewProjectionMatrix * gl_Vertex;\\n"
    "}\\n";

/* 朗伯：环境光 + 漫反射，可选贴图。和固定管线观感最接近，做基准对照用。 */
static const char *HW_FS_LAMBERT =
    "#version 120\\n"
    "varying vec3 vN; varying vec3 vC; varying vec2 vUV;\\n"
    "uniform vec3 uLight; uniform sampler2D uTex; uniform float uTexMix;\\n"
    "void main(){\\n"
    "  float d = max(dot(normalize(vN), normalize(uLight)), 0.0);\\n"
    "  vec3 alb = vC * mix(vec3(1.0), texture2D(uTex, vUV).rgb, uTexMix);\\n"
    "  gl_FragColor = vec4(alb * (0.35 + 0.75 * d), 1.0);\\n"
    "}\\n";

/* 卡通：把连续光照量化成 N 档色阶（uSteps 可调），马上有"动漫感"。 */
static const char *HW_FS_TOON =
    "#version 120\\n"
    "varying vec3 vN; varying vec3 vC; varying vec2 vUV;\\n"
    "uniform vec3 uLight; uniform sampler2D uTex; uniform float uTexMix;\\n"
    "uniform float uSteps;\\n"
    "void main(){\\n"
    "  float d = max(dot(normalize(vN), normalize(uLight)), 0.0);\\n"
    "  float s = floor(d * uSteps + 0.5) / max(uSteps, 1.0);\\n"
    "  vec3 alb = vC * mix(vec3(1.0), texture2D(uTex, vUV).rgb, uTexMix);\\n"
    "  gl_FragColor = vec4(alb * (0.30 + 0.85 * s), 1.0);\\n"
    "}\\n";

/* 边缘光：视线越"擦过"表面越亮，科幻/全息感。uRim 是边缘色。 */
static const char *HW_FS_FRESNEL =
    "#version 120\\n"
    "varying vec3 vN; varying vec3 vC; varying vec2 vUV; varying vec3 vEye;\\n"
    "uniform vec3 uLight; uniform sampler2D uTex; uniform float uTexMix;\\n"
    "uniform vec3 uRim; uniform float uRimPow;\\n"
    "void main(){\\n"
    "  vec3 N = normalize(vN);\\n"
    "  vec3 V = normalize(-vEye);\\n"
    "  float d = max(dot(N, normalize(uLight)), 0.0);\\n"
    "  vec3 alb = vC * mix(vec3(1.0), texture2D(uTex, vUV).rgb, uTexMix);\\n"
    "  float f = pow(1.0 - max(dot(N, V), 0.0), uRimPow);\\n"
    "  gl_FragColor = vec4(alb * (0.25 + 0.70 * d) + uRim * f, 1.0);\\n"
    "}\\n";

/* 棋盘：完全不采样贴图，用 UV 现场算格子 —— 演示"程序化纹理"，也方便看 UV 对不对。 */
static const char *HW_FS_CHECKER =
    "#version 120\\n"
    "varying vec3 vN; varying vec3 vC; varying vec2 vUV;\\n"
    "uniform vec3 uLight; uniform float uScale; uniform vec3 uDark;\\n"
    "void main(){\\n"
    "  vec2 g = floor(vUV * uScale);\\n"
    "  float k = mod(g.x + g.y, 2.0);\\n"
    "  vec3 alb = mix(uDark, vC, k);\\n"
    "  float d = max(dot(normalize(vN), normalize(uLight)), 0.0);\\n"
    "  gl_FragColor = vec4(alb * (0.35 + 0.75 * d), 1.0);\\n"
    "}\\n";

/* 法线可视化：调 UV / 法线 / 细分问题时最有用的一张图。 */
static const char *HW_FS_NORMAL =
    "#version 120\\n"
    "varying vec3 vN;\\n"
    "void main(){ gl_FragColor = vec4(normalize(vN) * 0.5 + 0.5, 1.0); }\\n";

/* 自发光：只出本色 x 贴图，不算光照。做 UI / 发光体 / 天空盒用。 */
static const char *HW_FS_UNLIT =
    "#version 120\\n"
    "varying vec3 vC; varying vec2 vUV;\\n"
    "uniform sampler2D uTex; uniform float uTexMix;\\n"
    "void main(){\\n"
    "  vec3 alb = vC * mix(vec3(1.0), texture2D(uTex, vUV).rgb, uTexMix);\\n"
    "  gl_FragColor = vec4(alb, 1.0);\\n"
    "}\\n";

/* 名字 → 片段着色器源码。中英文别名都收。找不到返回 NULL。 */
static const char *hw_preset_fs_src(const char *n)
{
    static const struct { const char *n; const char *s; } TAB[] = {
        { "lambert", HW_FS_LAMBERT }, { "朗伯",   HW_FS_LAMBERT },
        { "toon",    HW_FS_TOON },    { "卡通",   HW_FS_TOON },
        { "fresnel", HW_FS_FRESNEL }, { "边缘",   HW_FS_FRESNEL },
        { "checker", HW_FS_CHECKER }, { "棋盘",   HW_FS_CHECKER },
        { "normal",  HW_FS_NORMAL },  { "法线",   HW_FS_NORMAL },
        { "unlit",   HW_FS_UNLIT },   { "自发光", HW_FS_UNLIT },
    };
    if (n == NULL)
        return NULL;
    for (size_t i = 0; i < sizeof TAB / sizeof TAB[0]; i++)
        if (TAB[i].n != NULL && strcmp(TAB[i].n, n) == 0)
            return TAB[i].s;
    return NULL;
}

/* 内置着色器的默认 uniform（可被 hw.uni 覆盖）。 */
static void hw_preset_defaults(GLuint p, const char *n)
{
    if (strcmp(n, "toon") == 0 || strcmp(n, "卡通") == 0) {
        hw_setu(p, "uSteps", 1, 4.0f, 0.0f, 0.0f, 0.0f);
    } else if (strcmp(n, "fresnel") == 0 || strcmp(n, "边缘") == 0) {
        hw_setu(p, "uRim", 3, 0.25f, 0.55f, 1.00f, 0.0f);
        hw_setu(p, "uRimPow", 1, 3.0f, 0.0f, 0.0f, 0.0f);
    } else if (strcmp(n, "checker") == 0 || strcmp(n, "棋盘") == 0) {
        hw_setu(p, "uScale", 1, 4.0f, 0.0f, 0.0f, 0.0f);
        hw_setu(p, "uDark", 3, 0.06f, 0.07f, 0.10f, 0.0f);
    }
    if (g_gl_ok)
        glapi.UseProgram(0);
}

/* 按提交顺序执行命令流。push/pop 直接映射到 GL 的矩阵栈。
''',
))

# ---------------------------------------------------------------- P15 draw_ops 新 case
PATCHES.append((
    'draw-ops-cases',
    '            if (g_wire) draw_cyl_wire(&g_cyls[o->idx]);\n'
    '            else        draw_cyl(&g_cyls[o->idx]);\n'
    '            break;\n',
    '            if (g_wire) draw_cyl_wire(&g_cyls[o->idx]);\n'
    '            else        draw_cyl(&g_cyls[o->idx]);\n'
    '            break;\n'
    '        case OP_UNI:\n'
    '            hw_apply_uni(&g_unis[o->idx]);\n'
    '            break;\n'
    '        case OP_PROG: {\n'
    '            /* 帧中间切着色器：槽 0 = 回固定管线。\n'
    '               切完把流里"已经出现过"的 uniform 补设一遍 —— 用户很可能把\n'
    '               hw.uni 写在 hw.shaderuse 前面，顺序不该成为坑。 */\n'
    '            GLuint np = (o->idx > 0 && o->idx < HW_SHADER_SLOTS) ? g_progs[o->idx] : 0;\n'
    '            g_bound_prog = np;\n'
    '            if (g_gl_ok) {\n'
    '                glapi.UseProgram(np);\n'
    '                if (np != 0) {\n'
    '                    if (g_ulight[o->idx] >= 0)\n'
    '                        glapi.Uniform3f(g_ulight[o->idx], g_lx, g_ly, g_lz);\n'
    '                    for (int k2 = 0; k2 < i; k2++)\n'
    '                        if (g_ops[k2].type == OP_UNI)\n'
    '                            hw_apply_uni(&g_unis[g_ops[k2].idx]);\n'
    '                }\n'
    '            }\n'
    '            break;\n'
    '        }\n',
))

# ---------------------------------------------------------------- P16 线段批加法线
PATCHES.append((
    'line-normal',
    '            glDisable(GL_TEXTURE_2D);         /* 线段不贴图 */\n'
    '            glBegin(GL_LINES);\n',
    '            glDisable(GL_TEXTURE_2D);         /* 线段不贴图 */\n'
    '            glNormal3f(0.0f, 1.0f, 0.0f);\n'
    '            glBegin(GL_LINES);\n',
))

# ---------------------------------------------------------------- P17 rt_hw_frame 绑程序
PATCHES.append((
    'frame-bind-prog',
    '    draw_ops();\n',
    '''    /* 着色器模式：绑上"当前程序"（draw_ops 里还能靠 hw.shaderuse 中途切）。
       没指定过着色器就走原样的固定管线 —— 老程序一行不用改。
       uLight 由引擎每帧从 hw.light 灌进去，所以 hw.light 对着色器同样有效。
       注意固定管线的雾 / alpha 裁剪在兼容 profile 下是"片段着色器之后"的
       固定功能级，所以开着色器时 hw.fog 和透明 PNG 裁剪照样工作。 */
    g_bound_prog = 0;
    if (g_gl_ok && g_curprog > 0 && g_progs[g_curprog] != 0) {
        glapi.UseProgram(g_progs[g_curprog]);
        g_bound_prog = g_progs[g_curprog];
        if (g_white_tex == 0)
            hw_white_tex();
        if (g_ulight[g_curprog] >= 0)
            glapi.Uniform3f(g_ulight[g_curprog], g_lx, g_ly, g_lz);
    }
    draw_ops();
    if (g_bound_prog != 0) {
        glapi.UseProgram(0);
        g_bound_prog = 0;
    }
''',
))

# ---------------------------------------------------------------- P18 帧末清 uniform
PATCHES.append((
    'frame-clear-unis',
    '    g_nops = 0;\n'
    '    g_depth = 0;\n'
    '\n'
    '    glDisable(GL_BLEND);\n',
    '    g_nops = 0;\n'
    '    g_depth = 0;\n'
    '    /* uniform 表每帧清空（保持有界）；uniform 的值本身存在程序对象里，\n'
    '       所以"开局设一次"的写法在后续帧照样生效，不必每帧重设。 */\n'
    '    g_nunis = 0;\n'
    '\n'
    '    glDisable(GL_BLEND);\n',
))

# ---------------------------------------------------------------- P19 新 API 实现
NEW_APIS = '''/* ===================== 可编程管线 API ===================== */

/* hw.shader(槽, 顶点源码, 片段源码)：把一段 GLSL 编译进着色器槽（1~7）。
   成功返回 1，编译/链接失败返回 0（不中断程序，脚本可以自己容错）。
   之后用 hw.shaderuse(槽) 启用；槽 0 表示"回到固定管线"。

   **源码请用 #version 120**（这是引擎的约定，见 hw_build_program 上方注释）：
   兼容 profile 下它可以直接读 gl_Vertex / gl_Normal / gl_Color /
   gl_MultiTexCoord0 / gl_ModelViewProjectionMatrix / gl_NormalMatrix，
   这些量由现成的 glBegin 几何自动喂进来，不用改成 VBO。

   PYbook 字符串不能跨行、也不支持转义，所以字符串里写两字符的 \\n 会被
   还原成真换行。稍长一点的着色器请写成 .vert / .frag 文件，用 file.read 读：
       顶点 = file.read("光源.vert")
       片段 = file.read("光源.frag")
       好了 = hw.shader(1, 顶点, 片段)

   引擎自动喂这几个约定 uniform，不用自己设：
     uLight   vec3       —— hw.light 的方向（引擎每帧灌）
     uTex     sampler2D  —— 纹理单元 0，即 hw.texuse 选中的那张
     uTexMix  float      —— 0 = 不采样贴图，1 = 贴图 x 本色（默认 1） */
Value rt_hw_shader(Value sv, Value vsv, Value fsv)
{
    int slot = (int)hw_num(sv, "hw.shader 的槽位");
    if (slot < 1 || slot >= HW_SHADER_SLOTS) {
        hw_die("hw.shader：槽位要在 1~%d 之间（0 是固定管线）", HW_SHADER_SLOTS - 1);
        return rt_int(0);
    }
    if (g_win == NULL)
        hw_die("hw.shader：还没开窗口（先调用 hw.open）");
    hw_gl_load();
    if (!g_gl_ok) {
        fprintf(stderr, "hw.shader：取不到 GL 2.0+ 入口，着色器不可用\\n");
        return rt_int(0);
    }
    char *vs = hw_unfold(hw_str(vsv, "hw.shader 的顶点源码"));
    char *fs = hw_unfold(hw_str(fsv, "hw.shader 的片段源码"));
    char log[2048] = {0};
    GLuint p = hw_build_program(vs, fs, log, sizeof log);
    free(vs);
    free(fs);
    if (p == 0) {
        fprintf(stderr, "hw.shader 槽 %d 编译失败:\\n%s\\n", slot, log);
        return rt_int(0);
    }
    if (g_progs[slot] != 0)
        glapi.DeleteProgram(g_progs[slot]);
    g_progs[slot] = p;
    g_ulight[slot] = glapi.GetUniformLocation(p, "uLight");
    return rt_int(1);
}

/* hw.preset(槽, 名字)：装一个内置着色器，省得自己写 GLSL。
   名字（中英都行）：
     lambert/朗伯  环境光 + 漫反射 + 可选贴图（和固定管线最接近，做基准用）
     toon/卡通     光照量化成 4 档色阶（改 uSteps）
     fresnel/边缘  视线擦过表面时发亮（uRim 边缘色 / uRimPow 锐度）
     checker/棋盘  按 UV 现场算格子，不采样贴图（uScale / uDark）
     normal/法线   把法线画成颜色，调 UV 和法线问题的利器
     unlit/自发光  只出本色 x 贴图，不算光照（UI / 发光体 / 天空盒）
   返回 1 成功、0 失败。装完用 hw.shaderuse(槽) 启用。 */
Value rt_hw_preset(Value sv, Value nv)
{
    int slot = (int)hw_num(sv, "hw.preset 的槽位");
    if (slot < 1 || slot >= HW_SHADER_SLOTS) {
        hw_die("hw.preset：槽位要在 1~%d 之间（0 是固定管线）", HW_SHADER_SLOTS - 1);
        return rt_int(0);
    }
    if (g_win == NULL)
        hw_die("hw.preset：还没开窗口（先调用 hw.open）");
    hw_gl_load();
    if (!g_gl_ok)
        return rt_int(0);
    const char *name = hw_str(nv, "hw.preset 的名字");
    const char *fs = hw_preset_fs_src(name);
    if (fs == NULL) {
        fprintf(stderr, "hw.preset：没有内置着色器 %s。"
                        "可用：lambert/朗伯 toon/卡通 fresnel/边缘 "
                        "checker/棋盘 normal/法线 unlit/自发光\\n",
                name != NULL ? name : "(空)");
        return rt_int(0);
    }
    char log[2048] = {0};
    GLuint p = hw_build_program(HW_PRESET_VS, fs, log, sizeof log);
    if (p == 0) {
        fprintf(stderr, "hw.preset 槽 %d 编译失败:\\n%s\\n", slot, log);
        return rt_int(0);
    }
    hw_preset_defaults(p, name);
    if (g_progs[slot] != 0)
        glapi.DeleteProgram(g_progs[slot]);
    g_progs[slot] = p;
    g_ulight[slot] = glapi.GetUniformLocation(p, "uLight");
    return rt_int(1);
}

/* hw.shaderuse(槽)：之后的图元用这个着色器画；0 = 回固定管线。
   写进命令流，所以可以在一帧里穿插切换：
       a = hw.shaderuse(1)      # 世界用卡通着色器
       ... 画场景 ...
       a = hw.shaderuse(0)      # 辅助线 / gizmo 回固定管线（线没有法线）
       ... 画 gizmo ...
   （PYbook 里库调用不能当独立语句，所以要写成 变量 = hw.shaderuse(...)） */
Value rt_hw_shaderuse(Value sv)
{
    int slot = (int)hw_num(sv, "hw.shaderuse 的槽位");
    if (slot < 0 || slot >= HW_SHADER_SLOTS) {
        hw_die("hw.shaderuse：槽位要在 0~%d 之间（0 是固定管线）", HW_SHADER_SLOTS - 1);
        return rt_none();
    }
    g_curprog = slot;
    hw_op(OP_PROG, slot);
    return rt_none();
}

/* hw.uni(名字, a[, b[, c[, d]]])：设一个 uniform。
   1 个值 → float，2 个 → vec2，3 个 → vec3，4 个 → vec4。
   按命令流顺序生效；着色器里没声明的名字会被静默忽略（方便共用脚本）。
   注意：着色器请用 hw.uni 之外的名字，别覆盖 uLight / uTex / uTexMix。 */
Value rt_hw_univ(int nargs, Value *av)
{
    if (nargs < 2 || nargs > 5) {
        hw_die("hw.uni：写法是 hw.uni(\\"名字\\", a[, b[, c[, d]]])");
        return rt_none();
    }
    if (g_nunis >= HW_UNI_MAX)
        hw_die("hw.uni：单帧 uniform 数超过上限 %d", HW_UNI_MAX);
    HwUni *u = &g_unis[g_nunis++];
    const char *nm = hw_str(av[0], "hw.uni 的名字");
    snprintf(u->name, sizeof u->name, "%s", nm != NULL ? nm : "");
    u->kind = nargs - 1;
    for (int i = 0; i < 4; i++)
        u->v[i] = (i < u->kind) ? (float)hw_num(av[1 + i], "hw.uni 的值") : 0.0f;
    u->loc = -1;
    u->loc_prog = 0;
    hw_op(OP_UNI, g_nunis - 1);
    return rt_none();
}

Value rt_hw_end(void)
'''

PATCHES.append(('new-apis', 'Value rt_hw_end(void)\n', NEW_APIS))


# ================= 执行：先全部校验，再一次性写回 =================
for label, old, new in PATCHES:
    n = s.count(old)
    if n != 1:
        sys.stderr.write('FAIL [%s] count=%d\n' % (label, n))
        sys.stderr.write('--- 锚点开头 ---\n%s\n--- 锚点结尾 ---\n' % old[:400])
        sys.exit(1)
    s = s.replace(old, new, 1)
    print('ok   %-22s' % label)

io.open(PATH, 'w', encoding='utf-8', newline='').write(s)
print('\n写入完成，共 %d 处。' % len(PATCHES))
