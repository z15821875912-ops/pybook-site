# 一次性补丁：pybk_code.py 鼠标监听 + UI 控件运行时 + ui.* 绑定
import ast

p = 'pybk_code.py'
lines = open(p, encoding='utf-8').read().split('\n')

# ---- 1. keyup 块后插鼠标监听 + UI 运行时引用 ----
idx = next(i for i, l in enumerate(lines) if "PYBK_KEYS{sfx}[e.key] = false" in l)
j = idx + 1
assert lines[j].strip().endswith("')"), lines[j]
UI_INJECT = [
    "        # 鼠标：位置/按下/抬起（逻辑坐标按 400x300 换算）",
    "        self.raw(('(function(){ var cv = document.getElementById(\"pybook-canvas-' + str(self.in_draw) + '\");'",
    "                 ' function hw_mm(e){ var r = cv.getBoundingClientRect();'",
    "                 ' window.__pybkMX = (e.clientX - r.left) * 400 / r.width;'",
    "                 ' window.__pybkMY = (e.clientY - r.top) * 300 / r.height; }'",
    "                 ' cv.addEventListener(\"mousemove\", hw_mm);'",
    "                 ' cv.addEventListener(\"mousedown\", function(e){ hw_mm(e);'",
    "                 ' window.__pybkMD = true; window.__pybkMH = true; });'",
    "                 ' document.addEventListener(\"mouseup\", function(){ window.__pybkMD = false; });'",
    "                 '})();\\n'))",
    "        # UI 控件运行时（按钮/输入框/滑条），CTXNAME 替换为本块 ctx 名",
    "        self.raw(_UI_RUNTIME.replace('CTXNAME', 'ctx' + str(self.in_draw)))",
]
lines[j+1:j+1] = UI_INJECT

# ---- 2. 帧末 MH 清零 ----
for i, l in enumerate(lines):
    if "lines.append(f'PYBK_PRESSED{sfx}.clear();')" in l:
        lines.insert(i + 1, "        lines.append('window.__pybkMH = false;')")
        break
else:
    raise AssertionError('MH clear anchor')

src = '\n'.join(lines)

# ---- 3. _UI_RUNTIME 模块常量（插在 FALLBACK_GCC/_find_gcc 前）----
UI_RUNTIME = r'''
# ---- 网页 UI 控件运行时（按钮/输入框/滑条）；CTXNAME 替换为画布 ctx 变量名 ----
_UI_RUNTIME = r"""window.__pybkUI = { focus: null, drag: null, text: {}, val: {} };
window.__pybkUI_KEY = function(e) {
  if (!window.__pybkUI.focus) return;
  var t = window.__pybkUI.text[window.__pybkUI.focus] || '';
  if (e.key === 'Backspace') { window.__pybkUI.text[window.__pybkUI.focus] = t.slice(0, -1); }
  else if (e.key.length === 1 && !e.ctrlKey && !e.metaKey) { window.__pybkUI.text[window.__pybkUI.focus] = t + e.key; }
};
window.__pybkUI_BTN = function(ctx, x, y, w, h, label) {
  var mx = window.__pybkMX || 0, my = window.__pybkMY || 0;
  var over = mx >= x && mx <= x + w && my >= y && my <= y + h;
  ctx.fillStyle = over ? 'rgb(90,170,255)' : 'rgb(60,120,220)';
  ctx.fillRect(x, y, w, h);
  ctx.fillStyle = '#ffffff';
  ctx.font = '16px sans-serif';
  var tw = ctx.measureText(label).width;
  ctx.fillText(label, x + w / 2 - tw / 2, y + h / 2 + 6);
  return (over && window.__pybkMH) ? 1 : 0;
};
window.__pybkUI_INP = function(ctx, id, x, y, w, h) {
  var mx = window.__pybkMX || 0, my = window.__pybkMY || 0;
  var over = mx >= x && mx <= x + w && my >= y && my <= y + h;
  if (window.__pybkMH && over) window.__pybkUI.focus = id;
  var focused = window.__pybkUI.focus === id;
  var txt = window.__pybkUI.text[id] || '';
  ctx.fillStyle = '#ffffff'; ctx.fillRect(x, y, w, h);
  ctx.strokeStyle = focused ? '#50fa7b' : '#8899bb'; ctx.lineWidth = 2;
  ctx.strokeRect(x, y, w, h);
  ctx.fillStyle = '#222222'; ctx.font = '15px sans-serif';
  var caret = (focused && (Math.floor(Date.now() / 400) % 2 === 0)) ? '|' : '';
  ctx.fillText(txt + caret, x + 8, y + h / 2 + 5);
  return txt;
};
window.__pybkUI_SLD = function(ctx, id, x, y, w, lo, hi, val) {
  var mx = window.__pybkMX || 0, my = window.__pybkMY || 0;
  var over = mx >= x - 10 && mx <= x + w + 10 && my >= y - 12 && my <= y + 12;
  if (window.__pybkUI.val[id] === undefined) window.__pybkUI.val[id] = val;
  if (window.__pybkMH && over) window.__pybkUI.drag = id;
  if (window.__pybkUI.drag === id) {
    if (!window.__pybkMD) window.__pybkUI.drag = null;
    else { var t = (mx - x) / w; t = Math.max(0, Math.min(1, t)); window.__pybkUI.val[id] = lo + t * (hi - lo); }
  }
  var v = window.__pybkUI.val[id];
  var kn = x + w * (v - lo) / (hi - lo);
  ctx.strokeStyle = '#8899bb'; ctx.lineWidth = 4;
  ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + w, y); ctx.stroke();
  ctx.fillStyle = '#50fa7b';
  ctx.beginPath(); ctx.arc(kn, y, 8, 0, Math.PI * 2); ctx.fill();
  ctx.fillStyle = '#ffffff'; ctx.font = '13px sans-serif';
  ctx.fillText(String(Math.round(v * 100) / 100), x + w + 14, y + 5);
  return v;
};"""


def _find_gcc():'''
a2 = "def _find_gcc():"
assert src.count(a2) == 1, src.count(a2)
src = src.replace(a2, UI_RUNTIME, 1)
ast.parse(src)
open(p, 'w', encoding='utf-8', newline='').write(src)
print('runtime OK')
