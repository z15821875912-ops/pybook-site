/* PYbook 音 模块：正弦/三角波合成（waveOut）+ 外部音频播放（MCI，支持 MP3/WAV）。
 * 接口见 pybook_lib.h；依赖 windows.h（winmm），无第三方库。
 * 约定：正弦/三角是阻塞式（播完才返回，适合写旋律）；音.放 是后台异步播放。 */

#include "pybook_lib.h"

#include <windows.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>

#define MU_SR        44100          /* 采样率 */
#define MU_AMplitude 0.28           /* 音量系数（防爆音） */
#define MU_TAU       6.28318530717958647692

/* 运行时错误出口（lib_die 是 lib.c 的静态函数，这里自备一份） */
static void mu_die(const char *fmt, ...)
{
    va_list ap;
    fprintf(stderr, "运行时错误: ");
    va_start(ap, fmt);
    vfprintf(stderr, fmt, ap);
    va_end(ap);
    fputc('\n', stderr);
    exit(1);
}

/* 参数取数字 */
static double mu_num(Value v, const char *who)
{
    if (IS_FLT(v))
        return AS_FLT(v);
    if (IS_INT(v) || IS_BIGINT(v))
        return (double)rt_to_ll(v);
    if (IS_BOOL(v))
        return (double)AS_BOOL(v);
    mu_die("%s 需要数字参数", who);
    return 0;
}

/* UTF-8 → UTF-16（路径含中文也稳） */
static int mu_wide(const char *s, wchar_t *out, int cap)
{
    return MultiByteToWideChar(CP_UTF8, 0, s ? s : "", -1, out, cap);
}

/* 合成一段波形并阻塞播放：fade 5ms 消除起止爆音 */
static Value mu_tone(Value fv, Value mv, int triangle)
{
    double f = mu_num(fv, triangle ? "音.三角 的频率" : "音.正弦 的频率");
    double ms = mu_num(mv, "时长");
    if (f < 1.0)
        f = 1.0;
    if (f > 20000.0)
        f = 20000.0;
    if (ms < 0.0)
        ms = 0.0;
    if (ms > 60000.0)
        ms = 60000.0;

    size_t n = (size_t)(MU_SR * ms / 1000.0);
    if (n == 0)
        return rt_none();
    short *pcm = (short *)malloc(n * sizeof(short));
    if (pcm == NULL)
        mu_die("音：内存不足");

    double w = MU_TAU * f / MU_SR;
    size_t fade = n / 4;
    if (fade > (size_t)(MU_SR * 0.005))
        fade = (size_t)(MU_SR * 0.005);
    if (fade == 0)
        fade = 1;
    for (size_t i = 0; i < n; i++) {
        double ph = w * (double)i;
        double v = triangle ? (2.0 / MU_TAU) * asin(sin(ph)) : sin(ph);
        double g = 1.0;
        if (i < fade)
            g = (double)i / (double)fade;
        if (n - i < fade)
            g = (double)(n - i) / (double)fade;
        pcm[i] = (short)(v * MU_AMplitude * 32767.0 * g);
    }

    HWAVEOUT h = NULL;
    WAVEFORMATEX fmt;
    memset(&fmt, 0, sizeof fmt);
    fmt.wFormatTag = WAVE_FORMAT_PCM;
    fmt.nChannels = 1;
    fmt.nSamplesPerSec = MU_SR;
    fmt.wBitsPerSample = 16;
    fmt.nBlockAlign = fmt.nChannels * fmt.wBitsPerSample / 8;
    fmt.nAvgBytesPerSec = MU_SR * fmt.nBlockAlign;
    if (waveOutOpen(&h, WAVE_MAPPER, &fmt, 0, 0, CALLBACK_NULL) != MMSYSERR_NOERROR) {
        free(pcm);
        return rt_none();   /* 无可用音频输出（设备被占/静音拔线）：静默跳过不崩游戏 */
    }
    WAVEHDR hdr;
    memset(&hdr, 0, sizeof hdr);
    hdr.lpData = (LPSTR)pcm;
    hdr.dwBufferLength = (DWORD)(n * sizeof(short));
    waveOutPrepareHeader(h, &hdr, sizeof hdr);
    waveOutWrite(h, &hdr, sizeof hdr);
    while (!(hdr.dwFlags & WHDR_DONE))
        Sleep(1);
    waveOutUnprepareHeader(h, &hdr, sizeof hdr);
    waveOutClose(h);
    free(pcm);
    return rt_none();
}

Value rt_mu_sine(Value freq, Value ms)
{
    return mu_tone(freq, ms, 0);
}

Value rt_mu_tri(Value freq, Value ms)
{
    return mu_tone(freq, ms, 1);
}

/* ---- 外部音频（MCI：MP3/WAV/WMA 都行）----
 * 用别名 pybkmusic 管理一个后台播放器；音.放 会先收掉上一个。 */

static void mu_mci_close(void)
{
    mciSendStringW(L"close pybkmusic", NULL, 0, NULL);
}

/* ---- 非阻塞音效：fire-and-forget，绝不卡游戏帧 ---- */

#define SFX_RING 12

static HWAVEOUT g_sfx_hwo = NULL;     /* 音效专用设备句柄（复用，免打开延迟） */
static WAVEHDR  g_sfx_hdr[SFX_RING];
static short   *g_sfx_pcm[SFX_RING];
static int      g_sfx_next = 0;

static void sfx_reclaim(void)
{
    for (int i = 0; i < SFX_RING; i++) {
        if (g_sfx_pcm[i] != NULL && (g_sfx_hdr[i].dwFlags & WHDR_DONE)) {
            waveOutUnprepareHeader(g_sfx_hwo, &g_sfx_hdr[i], sizeof(WAVEHDR));
            free(g_sfx_pcm[i]);
            g_sfx_pcm[i] = NULL;
        }
    }
}

Value rt_mu_quick(Value fv, Value mv, Value wv)
{
    double f = mu_num(fv, "音.快 的频率");
    double ms = mu_num(mv, "音.快 的时长");
    long long wave = 0;
    if (IS_INT(wv) || IS_BIGINT(wv))
        wave = rt_to_ll(wv);
    if (f < 20.0)
        f = 20.0;
    if (f > 8000.0)
        f = 8000.0;
    if (ms < 5.0)
        ms = 5.0;
    if (ms > 400.0)
        ms = 400.0;

    if (g_sfx_hwo == NULL) {
        WAVEFORMATEX fmt;
        memset(&fmt, 0, sizeof fmt);
        fmt.wFormatTag = WAVE_FORMAT_PCM;
        fmt.nChannels = 1;
        fmt.nSamplesPerSec = MU_SR;
        fmt.wBitsPerSample = 16;
        fmt.nBlockAlign = 2;
        fmt.nAvgBytesPerSec = MU_SR * 2;
        if (waveOutOpen(&g_sfx_hwo, WAVE_MAPPER, &fmt, 0, 0, CALLBACK_NULL) != MMSYSERR_NOERROR)
            return rt_none();   /* 无音频设备：静默跳过 */
    }
    sfx_reclaim();

    size_t n = (size_t)(MU_SR * ms / 1000.0);
    if (n == 0)
        return rt_none();
    short *pcm = (short *)malloc(n * sizeof(short));
    if (pcm == NULL)
        return rt_none();
    int slot = -1;
    for (int i = 0; i < SFX_RING; i++)
        if (g_sfx_pcm[i] == NULL) {
            slot = i;
            break;
        }
    if (slot < 0) {                 /* 环满：挤掉最旧的一个 */
        slot = g_sfx_next % SFX_RING;
        waveOutUnprepareHeader(g_sfx_hwo, &g_sfx_hdr[slot], sizeof(WAVEHDR));
        free(g_sfx_pcm[slot]);
    }
    double w = MU_TAU * f / MU_SR;
    size_t fade = n / 5;
    if (fade < 16)
        fade = 16;
    if (fade > n)
        fade = n;
    unsigned seed = (unsigned)(f * 977 + ms * 31 + wave * 7 + n);
    for (size_t i = 0; i < n; i++) {
        double ph = w * (double)i;
        double v;
        if (wave == 1)
            v = (2.0 / MU_TAU) * asin(sin(ph)) * 0.9;
        else if (wave == 2) {
            seed = seed * 1664525u + 1013904223u;
            v = ((double)((seed >> 8) & 0xFFFF) / 32768.0) - 1.0;
        } else
            v = sin(ph);
        double g = 1.0;
        if (i < fade)
            g = (double)i / (double)fade;
        if (n - i < fade)
            g = (double)(n - i) / (double)fade;
        pcm[i] = (short)(v * 0.30 * 32767.0 * g);
    }

    WAVEHDR *h = &g_sfx_hdr[slot];
    memset(h, 0, sizeof *h);
    h->lpData = (LPSTR)pcm;
    h->dwBufferLength = (DWORD)(n * sizeof(short));
    waveOutPrepareHeader(g_sfx_hwo, h, sizeof(WAVEHDR));
    if (waveOutWrite(g_sfx_hwo, h, sizeof(WAVEHDR)) != MMSYSERR_NOERROR) {
        free(pcm);
        g_sfx_pcm[slot] = NULL;
        return rt_none();
    }
    g_sfx_pcm[slot] = pcm;
    g_sfx_next++;
    return rt_none();
}

Value rt_mu_play(Value path)
{
    const char *p = rt_str_of(path);
    wchar_t wpath[1024];
    if (mu_wide(p, wpath, 1024) <= 0)
        mu_die("音.放：路径转码失败 %s", p);
    wchar_t dos[1024];
    for (int i = 0; wpath[i] != L'\0' && i < 1023; i++)
        dos[i] = (wpath[i] == L'/') ? L'\\' : wpath[i];
    dos[1023] = L'\0';
    wchar_t cmd[1200];
    _snwprintf(cmd, 1199, L"open \"%s\" alias pybkmusic", dos);
    mu_mci_close();
    /* 背景音乐是锦上添花：设备被占用/没有音频输出时静默跳过，不许崩游戏 */
    if (mciSendStringW(cmd, NULL, 0, NULL) != 0)
        return rt_none();
    if (mciSendStringW(L"play pybkmusic", NULL, 0, NULL) != 0)
        return rt_none();
    return rt_none();
}

Value rt_mu_stop(void)
{
    mu_mci_close();
    return rt_none();
}

/* ============ 列表方式做音乐（类比 mm 的 draw_away：列表即乐谱） ============
 * 一行字符串 = 一条音轨；一个词 = 一拍（一个音符）。
 * 休止符：. _ r 都算静音（类比 mymove 的透明标记）。
 * 音符写法：科学音名 C4 D#4 Eb5 A3 …（默认正弦波）；音.音 可注册自定义音符。
 * 时长：默认 1 拍；token 后接 :N 表示 N 拍，如 C4:2 表示两拍。
 * 音.音(名, 频率, 波形)            注册/覆盖自定义音符（波形 0正弦/1三角/2噪声）
 * 音.奏(表, "名.wav", 速度)        列表 → 渲染成 WAV 落盘（速度 = 拍/分 BPM）
 * 音.谱(表, 速度)                 列表 → 即时播放（阻塞，播完才返回） */

typedef struct { char name[16]; double freq; int wave; } MuNote;
static MuNote mu_notes[256];
static int    mu_nnotes = 0;

/* 音名 → 半音（A B C D E F G） */
static int mu_letter_semitone(char c)
{
    switch (c) {
        case 'C': return 0;  case 'D': return 2;  case 'E': return 4;
        case 'F': return 5;  case 'G': return 7;  case 'A': return 9;
        case 'B': return 11; default: return -1;
    }
}

/* 解析音符：自定义优先；否则科学音名。命中返回 1 并写出 freq/wave；-1 不认识 */
static int mu_parse_note(const char *tok, double *freq, int *wave)
{
    for (int i = 0; i < mu_nnotes; i++)
        if (strcmp(mu_notes[i].name, tok) == 0) {
            *freq = mu_notes[i].freq; *wave = mu_notes[i].wave; return 1;
        }
    const char *p = tok;
    int semi = mu_letter_semitone(*p);
    if (semi < 0)
        return -1;
    p++;
    if (*p == '#') { semi++; p++; }
    else if (*p == 'b') { semi--; p++; }
    if (*p < '0' || *p > '9')
        return -1;
    int oct = 0;
    while (*p >= '0' && *p <= '9') { oct = oct * 10 + (*p - '0'); p++; }
    if (*p) return -1;                       /* 尾部多余字符 */
    int midi = (oct + 1) * 12 + semi;        /* C4 = 60 */
    *freq = 440.0 * pow(2.0, (midi - 69) / 12.0);
    *wave = 0;
    return 1;
}

Value rt_mu_note(Value namev, Value freqv, Value wavev)
{
    const char *t = rt_str_of(namev);
    if (!*t || strlen(t) >= 16)
        mu_die("音.音：名字长度须为 1..15");
    if (!strcmp(t, ".") || !strcmp(t, "_") || !strcmp(t, "r"))
        mu_die("音.音：. _ r 是保留的休止符，不能当音符名");
    double f = mu_num(freqv, "音.音 的频率");
    long long w = 0;
    if (IS_INT(wavev) || IS_BIGINT(wavev) || IS_FLT(wavev))
        w = rt_to_ll(wavev);
    if (f <= 0.0 || f > 30000.0)
        mu_die("音.音：频率须在 1..30000");
    MuNote *slot = NULL;
    for (int i = 0; i < mu_nnotes; i++)
        if (!strcmp(mu_notes[i].name, t)) { slot = &mu_notes[i]; break; }
    if (!slot) {
        if (mu_nnotes >= 256)
            mu_die("音.音：自定义音符已满（256 个）");
        slot = &mu_notes[mu_nnotes++];
        memset(slot->name, 0, sizeof slot->name);
        strncpy(slot->name, t, 15);
    }
    slot->freq = f;
    slot->wave = (int)w;
    return rt_none();
}

/* 把乐谱列表渲染成混合 PCM float 缓冲（调用方 free）；写样本数到 *nsamp */
static float *mu_raster(Value rows, double beat_ms, size_t *nsamp, int *ntracks_out)
{
    if (!IS_LIST(rows) || AS_LIST(rows) == NULL)
        mu_die("音.奏/谱 需要列表（一行字符串一条音轨）");
    RtList *L = AS_LIST(rows);
    if (L->len == 0 || L->len > 256)
        mu_die("音轨数须为 1..256");
    if (beat_ms <= 0)
        beat_ms = 1;
    double spb = beat_ms / 1000.0 * MU_SR;          /* 每拍样本数 */

    /* 第一遍：算总拍数（取最长音轨） */
    double max_beats = 0;
    for (size_t i = 0; i < L->len; i++) {
        const char *row = rt_str_of(L->items[i]);
        double beats = 0;
        size_t j = 0;
        while (row[j]) {
            while (row[j] == ' ') j++;
            if (!row[j]) break;
            char tok[32]; size_t t = 0;
            while (row[j] && row[j] != ' ' && t < 31) tok[t++] = row[j++];
            while (row[j] && row[j] != ' ') j++;
            tok[t] = '\0';
            double dur = 1;
            char *colon = strchr(tok, ':');
            if (colon) { *colon = '\0'; dur = atof(colon + 1); if (dur <= 0) dur = 1; }
            beats += dur;
        }
        if (beats > max_beats) max_beats = beats;
    }
    if (max_beats <= 0)
        mu_die("乐谱里没有任何音符（每行至少一个 token，如 C4；. _ r 是休止）");
    size_t total = (size_t)(max_beats * spb) + 1;
    float *mix = (float *)calloc(total, sizeof(float));
    if (!mix)
        mu_die("音：内存不足");

    int ntracks = 0;
    for (size_t i = 0; i < L->len; i++) {
        const char *row = rt_str_of(L->items[i]);
        size_t j = 0;
        double cursor = 0;          /* 样本游标 */
        int had = 0;
        while (row[j]) {
            while (row[j] == ' ') j++;
            if (!row[j]) break;
            char tok[32]; size_t t = 0;
            while (row[j] && row[j] != ' ' && t < 31) tok[t++] = row[j++];
            while (row[j] && row[j] != ' ') j++;
            tok[t] = '\0';
            double dur = 1;
            char *colon = strchr(tok, ':');
            if (colon) { *colon = '\0'; dur = atof(colon + 1); if (dur <= 0) dur = 1; }

            if (!strcmp(tok, ".") || !strcmp(tok, "_") || !strcmp(tok, "r")
                || !strcmp(tok, "R")) {
                cursor += dur * spb;
                continue;
            }
            double fr = 0; int wv = 0;
            if (mu_parse_note(tok, &fr, &wv) < 0)
                mu_die("音.奏：不认识的音符 '%s'（音.音 可自定义；. _ r 是休止）", tok);
            had = 1;
            size_t ns = (size_t)(dur * spb);
            for (size_t k = 0; k < ns && (size_t)(cursor + (double)k) < total; k++) {
                double ph = MU_TAU * fr * ((cursor + (double)k)) / MU_SR;
                double v;
                if (wv == 1)
                    v = (2.0 / MU_TAU) * asin(sin(ph));
                else if (wv == 2) {
                    unsigned seed = (unsigned)(fr * 977 + k * 31 + wv * 7);
                    seed = seed * 1664525u + 1013904223u;
                    v = ((double)((seed >> 8) & 0xFFFF) / 32768.0) - 1.0;
                } else
                    v = sin(ph);
                size_t idx = (size_t)(cursor + (double)k);
                if (idx < total) mix[idx] += (float)v;
            }
            cursor += dur * spb;
        }
        if (had) ntracks++;
    }
    *nsamp = total;
    if (ntracks_out) *ntracks_out = ntracks;
    return mix;
}

/* 写 16-bit PCM 单声道 WAV（含中文路径：UTF-8 → 宽字符） */
static void mu_write_wav(const char *name, const short *pcm, size_t n)
{
    FILE *fp = NULL;
#ifdef _WIN32
    wchar_t wn[1024];
    if (MultiByteToWideChar(CP_UTF8, 0, name, -1, wn, 1024) > 0)
        fp = _wfopen(wn, L"wb");
#endif
    if (!fp)
        fp = fopen(name, "wb");
    if (!fp)
        mu_die("音.奏：无法写 %s", name);
    unsigned char h[44];
    memset(h, 0, 44);
    unsigned int dataBytes = (unsigned int)(n * 2);
    unsigned int riff = dataBytes + 36;
    memcpy(h, "RIFF", 4);
    h[4] = riff & 0xFF; h[5] = (riff >> 8) & 0xFF; h[6] = (riff >> 16) & 0xFF; h[7] = (riff >> 24) & 0xFF;
    memcpy(h + 8, "WAVE", 4);
    memcpy(h + 12, "fmt ", 4);
    h[16] = 16;
    h[20] = 1;                         /* PCM */
    h[22] = 1;                         /* 单声道 */
    unsigned int sr = MU_SR;
    h[24] = sr & 0xFF; h[25] = (sr >> 8) & 0xFF; h[26] = (sr >> 16) & 0xFF; h[27] = (sr >> 24) & 0xFF;
    unsigned int bps = sr * 2;
    h[28] = bps & 0xFF; h[29] = (bps >> 8) & 0xFF; h[30] = (bps >> 16) & 0xFF; h[31] = (bps >> 24) & 0xFF;
    h[32] = 2;                         /* block align */
    h[34] = 16;                        /* bits */
    memcpy(h + 36, "data", 4);
    h[40] = dataBytes & 0xFF; h[41] = (dataBytes >> 8) & 0xFF; h[42] = (dataBytes >> 16) & 0xFF; h[43] = (dataBytes >> 24) & 0xFF;
    fwrite(h, 1, 44, fp);
    fwrite(pcm, 2, n, fp);
    fclose(fp);
}

/* 列表 → 落盘 WAV（类比 mm.draw_away 落盘 PNG） */
Value rt_mu_away(Value rows, Value filev, Value bpmv)
{
    double bpm = mu_num(bpmv, "速度");
    if (bpm < 20.0) bpm = 20.0;
    if (bpm > 400.0) bpm = 400.0;
    double beat_ms = 60000.0 / bpm;

    size_t n; int nt;
    float *mix = mu_raster(rows, beat_ms, &n, &nt);
    if (n == 0) { free(mix); return rt_none(); }
    short *pcm = (short *)malloc(n * sizeof(short));
    if (!pcm) { free(mix); mu_die("音：内存不足"); }

    float peak = 0;
    for (size_t i = 0; i < n; i++) {
        float v = (mix[i] < 0) ? -mix[i] : mix[i];
        if (v > peak) peak = v;
    }
    float g = (peak > 0) ? (0.7f / peak) : 0.0f;   /* 峰值归一，防削波 */
    for (size_t i = 0; i < n; i++) {
        float v = mix[i] * g;
        if (v > 1) v = 1; if (v < -1) v = -1;
        pcm[i] = (short)(v * 32767.0f);
    }
    free(mix);

    const char *name = rt_str_of(filev);
    mu_write_wav(name, pcm, n);
    free(pcm);
    return rt_str(name);
}

/* 列表 → 即时播放（阻塞；类比不想落盘、直接听） */
Value rt_mu_play_list(Value rows, Value bpmv)
{
    double bpm = mu_num(bpmv, "速度");
    if (bpm < 20.0) bpm = 20.0;
    if (bpm > 400.0) bpm = 400.0;
    double beat_ms = 60000.0 / bpm;

    size_t n; int nt;
    float *mix = mu_raster(rows, beat_ms, &n, &nt);
    if (n == 0) { free(mix); return rt_none(); }
    short *pcm = (short *)malloc(n * sizeof(short));
    if (!pcm) { free(mix); mu_die("音：内存不足"); }
    float peak = 0;
    for (size_t i = 0; i < n; i++) {
        float v = (mix[i] < 0) ? -mix[i] : mix[i];
        if (v > peak) peak = v;
    }
    float g = (peak > 0) ? (0.7f / peak) : 0.0f;
    for (size_t i = 0; i < n; i++) {
        float v = mix[i] * g;
        if (v > 1) v = 1; if (v < -1) v = -1;
        pcm[i] = (short)(v * 32767.0f);
    }
    free(mix);

    HWAVEOUT h = NULL;
    WAVEFORMATEX fmt;
    memset(&fmt, 0, sizeof fmt);
    fmt.wFormatTag = WAVE_FORMAT_PCM;
    fmt.nChannels = 1;
    fmt.nSamplesPerSec = MU_SR;
    fmt.wBitsPerSample = 16;
    fmt.nBlockAlign = 2;
    fmt.nAvgBytesPerSec = MU_SR * 2;
    if (waveOutOpen(&h, WAVE_MAPPER, &fmt, 0, 0, CALLBACK_NULL) != MMSYSERR_NOERROR) {
        free(pcm);
        return rt_none();   /* 无音频设备：静默跳过 */
    }
    WAVEHDR hdr;
    memset(&hdr, 0, sizeof hdr);
    hdr.lpData = (LPSTR)pcm;
    hdr.dwBufferLength = (DWORD)(n * sizeof(short));
    waveOutPrepareHeader(h, &hdr, sizeof hdr);
    waveOutWrite(h, &hdr, sizeof hdr);
    while (!(hdr.dwFlags & WHDR_DONE))
        Sleep(1);
    waveOutUnprepareHeader(h, &hdr, sizeof hdr);
    waveOutClose(h);
    free(pcm);
    return rt_none();
}
