/* PYbook v2 运行时库（pybook_rt）——NaN-boxing 万能盒 Value。
 *
 * PYbook 是动态类型语言：每个变量就是一个 8 字节的 Value 盒子。盒子的 64 个
 * 位既编码"装的是什么类型"又编码"值本身"（NaN-boxing）：双精度浮点直接存原始
 * 位样（最快路径，零转换），其余类型装进 IEEE754 NaN 的未用载荷位。代码生成
 * 器（pybk_code.py）按本头文件的接口发射 C 调用；pybook_lib.c（te/mt/rd）与
 * pybook_file.c（file）也建立在本头文件的 Value 体系之上。
 *
 * ── 位样布局（64 位）────────────────────────────────────────────────────
 *   位 63..48          位 47..0
 *  ┌──────────────┬──────────────────────────────────┐
 *  │ 0x7FF8|type  │  payload（48 位载荷）             │  ← 除 FLOAT 外的一切
 *  └──────────────┴──────────────────────────────────┘
 *   浮点：不装箱——原始 double 位样直接就是盒子。IEEE754 里指数全 1 且尾数
 *         非 0 才是 NaN；规范化后的浮点永远不会长出 0x7FF8..0x7FFF 的头
 *         （见 rt_float 的 NaN 规范化），所以"头 16 位落在 [0x7FF8,0x7FFF]"
 *         与"是浮点"互斥，判型只需一次比较。
 *   type（头 16 位低 3 位）：0=NONE 1=INT 2=BOOL 3=BIGINT 4=STR 5=LIST
 *         6=OBJ 7=DELETED（删除占位）。
 *   INT 快路径：48 位有符号整数直接放载荷（约 ±1.4e17，覆盖教学程序的全部
 *         日常整数）；更大的整数走 BIGINT——malloc 一个 long long 块，载荷
 *         位放数据指针，64 位全范围保真（LLONG_MAX/LLONG_MIN 字面量依赖）。
 *   指针（STR/LIST/OBJ/BIGINT）：48 位载荷位放数据指针。
 *   位 47（载荷最高位）= F_RC 引用计数标志，本版预留（永不置位）；指针按
 *         约定只取低 47 位，未来启用时无需改判型代码。
 *
 * ── 旧 struct Value 的 flags 字段去向（8 字节盒子里装不下）──────────────
 *   F_LOCKED（锁定）是"槽"的状态而不是"值"的状态——登记在槽地址侧表
 *         （rt_gold 写，rt_assign / rt_push / rt_setindex 查）。
 *   F_DELETED（删除）必须随值旅行（生成代码用 rt_chk(值的拷贝) 拦截已删除
 *         变量的每次读取）——删除即把槽内盒子整体改写成 DELETED 位样
 *         （type 7 + 载荷全 1）。改写只发生在被删的那一个槽上，删除前已
 *         拷走的旧拷贝不受影响。
 *   F_RC 见上（载荷位 47，预留）。
 *
 * 内存约定（全局）：所有 malloc 之后一律不 free，脚本结束由进程统一归还；
 * 字符串不可变，Value 的赋值/传参只拷 8 字节盒子不拷内容。
 *   例外：@self（完全手动）模式下 rt_destroy 会真正 free（见该函数注释）。
 * 错误约定（全局）：所有运行时错误向 stderr 输出 "运行时错误: 原因" 后 exit(1)。
 *
 * 模块分工（链接期一体的三份实现）：
 *   pybook_rt.c   本头文件除 file 外的全部实现；
 *   pybook_lib.c  te/mt/rd 标准库（rt_lib_te_* / rt_lib_mt_* / rt_lib_rd_*，
 *                 声明见 pybook_lib.h）；
 *   pybook_file.c file 文件模块（rt_file_*，声明见本头文件末段）。
 * 因此 pybook_rt.c 不定义 rt_lib_* / rt_file_* 符号，避免重复定义。
 *
 * 游戏零件（rt_game_*）：SDL2 像素窗口版。SDL2 头文件在构建的包含路径里
 * （-Iucrt64/include）即自动启用；否则编译进"未启用"桩——调用时报
 * "游戏引擎需要 SDL2"退出，其余构建（如库自测）不依赖 SDL 也能链接。
 * 链接：gcc -O2 pybook_rt.c pybook_lib.c pybook_file.c 主程序.c
 *           -o app.exe -I. -Iucrt64/include -Lucrt64/lib -lSDL2
 * 键名表（rt_game_key / rt_game_hit 共用）：right/右 left/左 up/上 down/下
 * space/空格 enter/回车 esc shift a-z（单字母）；未知键名按"没按"处理。
 *
 * 自测（覆盖本库全部函数的正常 + 边界分支，报错分支用子进程验证退出码，
 * 输出 [通过]/[失败]，全部通过则退出码 0）：
 *   gcc -O2 -DRT_SELF_TEST pybook_rt.c pybook_lib.c pybook_file.c
 *       -o rt_test.exe -I. -Iucrt64/include -Lucrt64/lib -lSDL2
 */

#ifndef PYBOOK_RT_H
#define PYBOOK_RT_H

#include <stdint.h>   /* uint64_t（Value 就是一个 64 位盒子） */
#include <stddef.h>   /* size_t（RtList / RtObject 用） */

/* 万能盒：一个 64 位 NaN-boxing 值。判型/取值/构造一律走下面的宏，
 * 不许直接对盒子做位运算——位样布局只属于本头文件。 */
typedef uint64_t Value;

/* ── 位样常量与判型/取值/构造宏 ────────────────────────────────────────
 * 盒子头 16 位落在 [0x7FF8, 0x7FFF] ⟹ 装箱值（低 3 位是 type）；
 * 否则整个盒子就是一个原始 double（含 ±Inf 与规范化后的 NaN）。 */

#define RT_NIL_BOX     0x7FF8000000000000ULL   /* NONE：type 0，载荷 0 */
#define RT_DELETED_BOX 0x7FFFFFFFFFFFFFFFULL   /* DELETED：type 7，载荷全 1 */
#define RT_RC_BIT      0x0000800000000000ULL   /* 载荷位 47：F_RC（预留，本版永不置位） */
#define RT_PTR_MASK    0x0000FFFFFFFFFFFFULL   /* 48 位载荷：数据指针 */

#define RT_TYPE(v)     ((uint32_t)((v) >> 48) & 7u)               /* 取 type */
#define RT_IS_BOX(v)   ((((uint32_t)((v) >> 48)) & 0xFFF8u) == 0x7FF8u)

#define IS_NONE(v)     ((v) == RT_NIL_BOX)
#define IS_INT(v)      ((((v) >> 48) & 0xFFFFu) == 0x7FF9u)       /* type 1 */
#define IS_BOOL(v)     ((((v) >> 48) & 0xFFFFu) == 0x7FFAu)       /* type 2 */
#define IS_BIGINT(v)   ((((v) >> 48) & 0xFFFFu) == 0x7FFBu)       /* type 3 */
#define IS_STR(v)      ((((v) >> 48) & 0xFFFFu) == 0x7FFCu)       /* type 4 */
#define IS_LIST(v)     ((((v) >> 48) & 0xFFFFu) == 0x7FFDu)       /* type 5 */
#define IS_DICT(v)     ((((v) >> 48) & 0xFFFFu) == 0x7FFFu)       /* type 7：字典 */
#define IS_OBJ(v)      ((((v) >> 48) & 0xFFFFu) == 0x7FFEu)       /* type 6 */
#define IS_DEL(v)      ((v) == RT_DELETED_BOX)                    /* 已删除占位 */
#define IS_FLT(v)      (!RT_IS_BOX(v))                            /* 其余全是浮点 */

/* 取值：AS_INT 做 48 位符号扩展；AS_FLT 把原始位样当 double 读；
 * AS_STR/AS_LIST/AS_OBJ 还原 48 位指针（前提：类型对）。 */
#define AS_INT(v)      ((long long)((int64_t)((v) << 16) >> 16))
#define AS_FLT(v)      rt_f64_of_bits(v)
#define AS_BOOL(v)     ((int)((v) & 1u))
#define AS_STR(v)      ((char *)((v) & RT_PTR_MASK))
#define AS_LIST(v)     ((RtList *)((v) & RT_PTR_MASK))
#define AS_DICT(v)     ((RtDictPub *)((v) & RT_PTR_MASK))         /* 载荷见 rt.c 的 RtDict */
typedef struct { void *pairs; } RtDictPub;                /* pairs 是一个列表 Value */
#define MAKE_DICT(p)   (0x7FFF000000000000ULL | (uint64_t)(uintptr_t)(p))
#define AS_OBJ(v)      ((RtObject *)((v) & RT_PTR_MASK))

/* 构造：MAKE_* 只装盒不分配（p 必须是 malloc 好的指针）；
 * 需要拷贝/分配时用函数版 rt_str / rt_list_new / rt_obj_new。 */
#define MAKE_NONE()    RT_NIL_BOX
#define MAKE_BOOL(b)   (0x7FFA000000000000ULL | (uint64_t)((b) ? 1u : 0u))
#define MAKE_STR(p)    (0x7FFC000000000000ULL | (uint64_t)(uintptr_t)(p))
#define MAKE_LIST(p)   (0x7FFD000000000000ULL | (uint64_t)(uintptr_t)(p))
#define MAKE_OBJ(p)    (0x7FFE000000000000ULL | (uint64_t)(uintptr_t)(p))
/* 整数构造必须走函数：快路径装不下的要转 BIGINT 堆盒（见 rt_int）。 */
#define MAKE_INT(x)    rt_int(x)
#define MAKE_FLT(x)    rt_float(x)

/* double 位样 ↔ 64 位整数的无 aliasing 读取（编译成一个 movq） */
static inline double rt_f64_of_bits(uint64_t b)
{
    double d;
    __builtin_memcpy(&d, &b, sizeof d);
    return d;
}

/* INT 快路径的范围（48 位有符号）；之外的整数自动走 BIGINT 堆盒 */
#define RT_INT_FAST_MIN (-140737488355328LL)   /* -(2^47)    */
#define RT_INT_FAST_MAX ( 140737488355327LL)   /*   2^47 - 1 */

/* 编译期断言：Value 必须是 8 字节（NaN-boxing 的全部意义所在） */
_Static_assert(sizeof(Value) == 8, "Value 必须是 8 字节 NaN-boxing 盒子");

/* 列表：可增长数组；元素是 Value 盒本身（拷 8 字节盒子） */
typedef struct { size_t len, cap; Value *items; } RtList;

/* 对象 = 属性袋：属性名 → 值 的登记表（线性查找），创建时记录类名。
 * cls 指向常量（调用方保证生命周期，通常是字面量，永不回收）；
 * names 里每个名字是 malloc 拷贝（永不回收）。 */
typedef struct {
    char   *cls;      /* 类名（指向常量） */
    size_t  nprops;
    char  **names;    /* 属性名数组（每个名字 malloc 拷贝） */
    Value  *vals;     /* 属性值数组 */
} RtObject;

/* ---------- 构造 ---------- */

Value rt_int(long long x);      /* 整数盒：快路径 48 位，更大走 BIGINT 堆盒 */
Value rt_float(double x);       /* 浮点盒：原始位样（NaN 规范化，见实现） */
Value rt_bool(int x);           /* 布尔盒（非 0 即真，内部只存 0/1） */
Value rt_str(const char *s);    /* 字符串盒：malloc 拷贝一份（永不回收） */
Value rt_none(void);            /* 空盒 */

/* 把 INT/BIGINT/BOOL 盒解码成 long long（48 位快路径与 BIGINT 堆盒统一出口） */
long long rt_to_ll(Value v);

/* ---------- 变量：赋值 / 检查 / 锁定 ---------- */

/* 赋值：目标已锁定 → "变量已锁定" 退出；已删除 → "用已删除变量" 退出；
 * 否则整体 8 字节盒子赋值（字符串只拷指针不拷内容）。 */
void  rt_assign(Value *dst, Value nv);

/* 使用前检查：已删除 → "用已删除变量" 退出；否则原样返回 */
Value rt_chk(Value v);

/* 锁定（gold 语句的运行时形态；把槽记入锁定侧表） */
void  rt_gold(Value *dst);

/* ---------- 内存管理模式（Memoryment） ---------- */

/* 六档（数字由前端映射：@1→0 @2→1 @3→3 @4→4 @5→5 @6→6）：
 *   0 @normal 不回收（进程退出统一归还）     1 @self 完全手动（del 立即真释放）
 *   3 引用计数：槽位/容器持有 +1、覆盖与 del -1，归零回收（收不了循环引用）
 *   4 竞技场：bump 分配 + rt_arena_reset() 整块归还
 *   5 标记清除：从根集追踪可达对象回收其余（能收循环引用）
 *   6 分代 + 增量：新生代/老年代 + 写屏障 + rt_gc_step() 分片标记
 * 其他值 → "内存管理模式不支持" 退出。 */
void  rt_set_memmode(int mode);

/* ── 根集：变量槽登记（@5/@6 需要，其余模式下是廉价的空登记）──
 * 生成代码在每个变量声明后调 rt_root_add(&v_N)；函数/GOING 进出用
 * rt_scope_enter / rt_scope_leave 划分作用域（支持递归嵌套）。 */
void  rt_scope_enter(void);
void  rt_root_add(Value *slot);
void  rt_scope_leave(void);

/* @5/@6：完整回收一次。@6 走增量流程（标记分片 + 清除）。 */
void  rt_gc(void);
/* 语句边界的 GC 轮询：生成代码在每条语句后调用。回收只在这里发生，
 * 以保证表达式求值期间绝不回收（临时值没有登记为根，收了就悬挂）。 */
void  rt_gc_poll(void);
/* @6：推进一小片 GC 工作（把长暂停摊到每帧）；返回本片是否做了事 */
int   rt_gc_step(void);

/* @4：整块归还竞技场（块内所有单元一起死） */
void  rt_arena_reset(void);

/* 内存统计：返回存活单元数；bytes 输出近似占用字节 */
size_t rt_mem_stats(size_t *bytes);

/* delete 的执行体：先把槽内盒子改写成 DELETED 位样，再按模式回收内存。
 * @normal：只改写位样（内存由进程退出统一回收）；
 * @self：  真正释放 STR/LIST/OBJ/BIGINT 的堆内存——已释放指针登记在案
 *          （最多 1024 个），共享别名二次 delete 不会 double-free，只是
 *          再次标记删除；悬空访问属"后果自负"。对已删除变量再 delete
 *          → "用已删除变量" 退出（幂等保护）。 */
void  rt_destroy(Value *v);

/* ---------- 算术（数字含 bool/BIGINT，按数值参与） ---------- */

/* +：int+int 用 __builtin_add_overflow，溢出 → "溢出" 退出；
 * 任一是 float 结果为 float；str+str 拼接；str 与数字相加 → "类型不可相加" 退出。 */
Value rt_add(Value a, Value b);

/* -：规则同 rt_add（用 __builtin_sub_overflow；str 参与 → "类型不可相减"） */
Value rt_sub(Value a, Value b);

/* ×：规则同 rt_add（用 __builtin_mul_overflow；str 参与 → "类型不可相乘"） */
Value rt_mul(Value a, Value b);

/* /：真除法，结果一律 float；非数字 → "类型不可相除"、
 * 除数为 0/0.0 → "除以零" 退出 */
Value rt_div(Value a, Value b);

/* //：向下取整整除。int/int 按 Python floordiv 规则（负数向下取整；
 * 除数为 0 → "除以零"、LLONG_MIN // -1 → "溢出"）；
 * 含 float 时结果为 floor(a/b) 的 float（除数为 ±0.0 → "除以零"）。 */
Value rt_fdiv(Value a, Value b);

/* %：Python 语义，结果符号跟除数；除数为 0/0.0 → "除以零" 退出 */
Value rt_mod(Value a, Value b);

/* 一元负号：仅数字（INT/BOOL/BIGINT 结果 INT，FLOAT 结果 FLOAT）；
 * -LLONG_MIN 溢出报 "溢出"；其他类型 → "负号只能用于数字" 退出 */
Value rt_neg(Value a);

/* 逻辑非：按 rt_cond 真值取反，返回 Bool */
Value rt_not(Value a);

/* 真值判断：空盒 / 0 / 0.0 / "" / 假 / 空列表 → 0；其余 → 1 */
int   rt_cond(Value v);

/* ---------- 比较 ---------- */

/* == 与 != 永不报错（Python 语义）：不同类型就是不相等；
 * 数字跨 int/float/bool/BIGINT 按数值，字符串按 strcmp，两个空盒相等；
 * 列表做深度递归相等比较；对象比指针身份（同一对象才相等）。 */
Value rt_eq(Value a, Value b);  /* == */
Value rt_ne(Value a, Value b);  /* != */

/* < > <= >= ：不可比较（类型不匹配）直接报 "类型不可比较" 退出。
 * 可比较：数字之间按值；字符串之间按 strcmp；对象之间按指针身份。 */
Value rt_lt(Value a, Value b);
Value rt_gt(Value a, Value b);
Value rt_le(Value a, Value b);
Value rt_ge(Value a, Value b);

/* ---------- 容器（列表） ---------- */

Value rt_list_new(void);                        /* 空列表 */
Value rt_push(Value *dst, Value v);
long long rt_list_len_ll(Value lst);      /* 列表长度（C 整数；for-in 边遍历边删用） */
Value rt_list_remove(Value lst, Value item);   /* 删掉(列表, 元素)：移除第一个相等元素 */             /* 追加元素（改原列表），返回空盒；
                                                 * 目标已锁定/已删除/不是列表 → 报错 */
Value rt_list_slice(Value lst, Value av, Value bv, Value cv);
                                /* 切片 lst[a:b:step]：段为 INT_MIN 哨兵表示缺省 */
Value rt_in(Value item, Value lst);             /* in：列表线性查找 / 字符串子串 */
Value rt_not_in(Value item, Value lst);         /* not in */
Value rt_index(Value lst, Value idx);           /* 下标读：负数从尾数；字符串按
                                                 * UTF-8 字符取；浮点/越界 → 报错 */
Value rt_dict_new(void);                        /* 空字典（插入序保留） */
Value rt_dict_set(Value *d, Value k, Value v);  /* 键存在则覆盖，否则追加；k 可为任意值 */
long long rt_dict_len_ll(Value d);              /* 字典键值对个数 */
Value rt_dict_key_at(Value d, long long i);     /* 第 i 个插入的键（for-in 用） */
Value rt_dict_get(Value d, Value k);            /* 取值：键不存在 → 报错 */
long long rt_dict_has(Value d, Value k);        /* 键存在 = 1 */
Value rt_dict_del(Value d, Value k);            /* 删键：不存在 → 报错 */
long long rt_iter_len_ll(Value v);              /* 列表或字典的长度（for-in 多态用） */
Value rt_dict_keys(Value d);                    /* dict.keys：键列表（插入序） */
Value rt_dict_values(Value d);                  /* dict.values：值列表（插入序） */
Value rt_safe_get(Value d, Value k, Value 缺省);   /* 字典.get(键, 缺省)：不炸 */
Value rt_safe_at(Value lst, Value idx, Value 缺省);   /* 表.at(i, 缺省)：越界不炸 */
Value rt_mm_blt(Value rows, Value x, Value y, Value scale);
Value rt_mm_anim(Value frames, Value x, Value y, Value scale, Value fps);
                                   /* mm.动：按帧率轮播帧列表（帧率取整除节拍） */
                                   /* mm.贴：窗口模式把 token 列表画到 (x,y) */

long long pk_mod(long long a, long long b);     /* 热循环取模（除数符号） */
long long pk_fdiv(long long a, long long b);    /* 热循环 floor 除 */
Value rt_list_flat(Value lst);                 /* list.flat：一层展平 */
Value rt_list_zip(Value a, Value b);           /* list.zip：按位配对取短 */
Value rt_list_count(Value lst, Value v);       /* list.count：出现次数 */
Value rt_list_sorted(Value lst);                /* list.sorted：排序出新表（升序） */
Value rt_list_rsorted(Value lst);               /* list.rsorted：降序出新表 */
Value rt_list_byfield(Value lst, Value 名, Value dir);  /* list.byfield：对象按字段排序 */
Value rt_dict_byvalue(Value d, Value dir);      /* dict.byvalue：按键值排序取键列表 */
extern long long g_cur_line;                    /* 当前执行行（rt_die 报错用） */
struct ErrPoint;                                /* 不透明（实现在 rt.c） */
struct ErrPoint *rt_err_push(void);
void  rt_err_pop(struct ErrPoint *p);
const char *rt_err_msg(void);
Value rt_game_img_flip(Value x, Value y, Value w, Value h, Value p, Value flip); /* 图翻：水平镜像 */
Value rt_dirkeys(void);                         /* dirkeys()：[dx, dy]，WASD+方向键 */
Value rt_frames(void);                          /* frame：框架模式累计帧数 */
Value rt_secs(void);                            /* sec：frame / 60.0 */
void  rt_setindex(Value *lst, Value idx, Value v);  /* 下标写；越界/类型错 → 报错 */
Value rt_len(Value v);                          /* 长度：列表元素个数 / 字符串字符数
                                                 * （按 UTF-8 字符）；其他 → 报错 */

/* ---------- 列表扩展 ---------- */

Value rt_list_sort(Value lst);     /* 原地排序（数字按值、字符串按字典序、
                                    * 对象按指针；混类型 → "类型不可比较"），返回原列表 */
Value rt_list_reverse(Value lst);  /* 原地倒序，返回原列表 */
Value rt_list_unique(Value lst);   /* 去重（深度相等判重，保留首现），返回新列表 */
Value rt_list_merge(Value a, Value b);  /* 拼接两个列表（先 a 后 b），返回新列表 */
Value rt_list_find(Value lst, Value val);  /* 深度相等查找，INT 索引；找不到 -1 */
Value rt_list_max(Value lst);      /* 最大值；空列表 → "列表为空"、非列表 → 报错 */
Value rt_list_min(Value lst);      /* 最小值；同上 */

/* ---------- 对象（属性袋；赋值是引用语义，两个名字共享同一对象） ---------- */

Value rt_obj_new(const char *cls);   /* 空属性袋（cls 指向常量） */
void  rt_obj_set_prop(Value obj, const char *name, Value v);
                          /* 已有则覆盖，没有则追加；obj 不是对象 → 报错 */
Value rt_obj_get_prop(Value obj, const char *name);
Value rt_touch(Value a, Value b);               /* 碰到(a,b)：AABB 碰撞（x/y 中心 + 宽/高） */                          /* 存在 → 值；不存在 → "属性 'x' 不存在" 退出 */
const char *rt_obj_class_name(Value obj);       /* 类名字符串 */

/* ---------- 终端显示与输入 ---------- */

/* 转显示文本：int 十进制、float %.15g（自动去尾零）、bool "true/false"、str 原样、
 * none "空"、list "[a, b, c]"（深度展开）、obj "[类名 对象]"。
 * str 直接返回内部指针，其余返回 malloc 文本（均不回收）。 */
char *rt_str_of(Value v);

/* 解析样式描述 "b,i,c=R,G,B,bk=R,G,B,f.字体,fs.数字,fm,fl,fr" 并暂存对应
 * ANSI 转义序列，随本次 show 输出：
 *   b=加粗 \033[1m   i=斜体 \033[3m   u=下划线 \033[4m   d=删除线 \033[9m
 *   c=R,G,B=前景色 \033[38;2;R;G;Bm  bk=R,G,B=背景色 \033[48;2;R;G;Bm
 *   f.字体/fs.字号=终端不能真正改字体字号，接受并忽略（网页端生效）
 *   l/fl=左对齐  m/fm=居中  r/fr=右对齐（按 COLUMNS，缺省 80）
 * 遇到不认识的项 → "不支持的样式 xxx" 退出。 */
void  rt_magic(const char *csv);

/* 原样输出文本（不加样式、不换行；进入当前 show 行缓冲） */
void  rt_show_text(const char *s);

/* 输出 rt_str_of(v) 的文本，并原样返回该值 */
Value rt_show_value(Value v);

/* 结束本次 show：按对齐补空格、输出行缓冲；本行用过 magic 再输出
 * \033[0m（重置样式），最后换行。 */
void  rt_show_end(void);

/* 输出提示符后读一行：先按整数解析（整行必须是数字，忽略首尾空白），
 * 再按浮点解析，都不行就整行按字符串（保留原样）。 */
Value rt_input(const char *prompt);

/* ---------- 网页输出（hm.* 语句的运行时） ---------- */

/* hm 语句把内容追加进内部网页缓冲；rt_page_save 按完整 HTML 骨架把缓冲落盘为
 * pybook_page.html（UTF-8，二进制写，不做换行翻译），随后清空缓冲供下一页
 * 复用。缓冲内存按项目约定"分配不回收"。防注入：所有进入页面的用户文本经
 * HTML 转义（& < > "），永远变不成可执行标签；段落样式串由编译器生成，
 * 不做转义。 */
void rt_page_begin(const char *title);     /* 写骨架头（DOCTYPE/head/meta/title 转义/
                                              内置深色样式表/<body>） */
void rt_page_para_open(const char *style); /* <p style="...">；样式 token
                                              （b/i/u/d/c=R,G,B/bk=R,G/B/f.字体/
                                              fs.字号/l/m/r 等）翻译成 CSS；
                                              空串 → 裸 <p> */
void rt_page_text(const char *raw);        /* 文本：& < > " 转义后追加 */
void rt_page_raw(const char *raw);         /* 不转义原样追加（画布 <script> 用） */
void rt_page_value(Value v);               /* rt_str_of(v) 转文本后同上追加 */
void rt_page_para_close(void);             /* </p> */
void rt_page_h(const char *raw, int level);  /* level 1=<h1>，其余=<h2>，转义 */
void rt_page_img(const char *file);        /* <img src="file">（转义） */
void rt_page_hr(void);                     /* <hr> */
void rt_page_link(const char *text, const char *url);
                          /* <a href="url(转义含 ")">转义text</a> */
void rt_page_table(Value v);              /* web.表格(二维列表)：第一行做表头 */
void rt_page_table(Value v);              /* web.表格(二维列表)：第一行做表头 */
void rt_page_save(void);                   /* 拼骨架尾 </body></html> 写盘并清缓冲 */

/* 多页支持（web.页 语句）：页表暂存各子页缓冲，rt_page_save 时逐个落盘为
 * pybook_page_<名>.html（主页仍叫 pybook_page.html）。页名经前端校验，
 * 不含路径字符。 */
void rt_test_check(int cond, const char *name);   /* 查(条件, "名字")：记录一次断言 */
long long rt_test_summary(void);                  /* 打印汇总，返回失败数 */
void rt_page_open(const char *file, const char *title);
                           /* 切到子页（首次写骨架，重开则续写）；当前页暂存入表 */
void rt_page_back(void);   /* 切回打开前的页（栈） */

/* ---------- 游戏零件：SDL2 像素窗口版 ----------
 * 全部函数收发 Value；颜色/坐标/宽高参数收 INT/BIGINT/BOOL（按数值）与
 * FLOAT（截断取整），其他类型报错。还没开窗口就画图 → 报错退出。 */

Value rt_game_win(Value w, Value h, const char *title);  /* 开窗口+渲染器（居中、
                                                          可缩放、逻辑尺寸=窗口尺寸） */
Value rt_game_clear(Value r, Value g, Value b);  /* 用 (r,g,b) 清屏 */
Value rt_game_color(Value r, Value g, Value b);  /* 设画图颜色（box/dot/line 共用） */
Value rt_game_box(Value x, Value y, Value w, Value h);   /* 实心方块 */
Value rt_game_dot(Value x, Value y);             /* 画一个点（4×4 像素小方块） */
Value rt_game_line(Value x1, Value y1, Value x2, Value y2);  /* 画线 */
Value rt_game_show(void);                        /* 呈现这一帧 */
Value rt_game_key(const char *name);             /* 某键此刻正被按住 → INT 1/0 */
Value rt_game_hit(const char *name);             /* 某键刚被按下（本帧一次性）→ INT 1/0 */
Value rt_game_frame(void);                       /* 帧末尾：泵事件 + 键状态翻页 + 约 60FPS */
Value rt_game_end(void);                         /* 想关窗口？点 X 或按住 ESC → 真/假 */
Value rt_game_bye(void);                         /* 游戏结束善后：停半秒 + 销毁 + SDL_Quit */

/* 字/图/图缩：中文文字渲染（stb_truetype + 系统字体）与 PNG 贴图（stb_image）。
 * 文本纹理按 (字号|颜色|内容) 缓存；图片按路径缓存。用当前画笔色画字。 */
Value rt_game_circle(Value x, Value y, Value r);   /* 圆(x,y,r)：实心圆（当前画笔色） */
Value rt_game_mx(void);                            /* 鼠标 X（逻辑坐标） */
Value rt_game_my(void);                            /* 鼠标 Y（逻辑坐标） */
Value rt_game_mdown(void);                         /* 鼠标左键按住 → 1/0 */
Value rt_game_mhit(void);                          /* 鼠标左键刚按下 → 1/0 */
Value rt_game_text(Value x, Value y, Value text, Value size);   /* 字(x,y,"文本",字号) */
Value rt_game_img(Value x, Value y, Value path);                /* 图(x,y,"文件.png") */
Value rt_game_img_scaled(Value x, Value y, Value w, Value h, Value path);  /* 图缩(x,y,宽,高,"文件") */

/* ---------- file 文件模块（实现见 pybook_file.c，UTF-8 读写） ---------- */

Value rt_file_read(Value path);                 /* 读全部文本 → 字符串 */
Value rt_file_write(Value path, Value content); /* 覆盖写 → 空盒 */
Value rt_file_add(Value path, Value content);   /* 追加写 → 空盒 */
Value rt_file_exists(Value path);               /* 文件存在？→ 真/假 */
Value rt_file_lines(Value path);                /* 按 \n 切成列表（去行尾 \r，
                                                  尾部空行不单算） */
Value rt_file_del(Value path);                  /* 删除文件 → 空盒 */

/* rm.around 循环辅助 */
long long rt_loop_count(Value v);   /* 次数解码：INT 直取/整值浮点截断/其余报错 */
Value rt_at(long long i);           /* 圈数包装成 INT 盒 */

#endif /* PYBOOK_RT_H */
