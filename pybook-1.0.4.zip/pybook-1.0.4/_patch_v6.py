# -*- coding: utf-8 -*-
"""给 _proto_3deditor.pybk 打补丁：加 图元类型(盒/球/柱) + FOV/近裁剪 快捷键。
每处断言 count==1，一次写回。"""
import io, sys

P = 'C:/Users/zhuli/Desktop/pybook/_proto_3deditor.pybk'
s = io.open(P, encoding='utf-8').read()

PATCHES = []

# ---- 1) 文档头：补 v6 说明 ----
PATCHES.append((
    'doc',
    """#  PYbook 原生 3D 场景摆放器 · v4
# ============================================================
#  v4 新增：""",
    """#  PYbook 原生 3D 场景摆放器 · v6
# ============================================================
#  v6 新增：
#    · 图元类型：1=盒  2=球  3=圆柱  4=圆锥（按数字键切当前放置类型）
#    · FOV / 近裁剪面可调（hw.fov / hw.near）：[ ] 调 FOV，- = 调 near
#    · 选中物体的 gizmo 仍是三色坐标轴；球用包围球框，柱用上下圈
#
#  v4 新增："""))

# ---- 2) 物体列表：加"类型"和"柱边数"两个平行列表 ----
PATCHES.append((
    'lists-head',
    """orr = []
org = []
orb = []

添加(ox, 0)""",
    """orr = []
org = []
orb = []
okind = []      # 1=盒 2=球 3=圆柱 4=圆锥
oseg = []       # 圆柱/圆锥的边数

添加(ox, 0)"""))

# ---- 3) 四个初始物体的 kind/seg ----
PATCHES.append((
    'init1',
    """添加(orr, 220)
添加(org, 90)
添加(orb, 90)

添加(ox, 6)""",
    """添加(orr, 220)
添加(org, 90)
添加(orb, 90)
添加(okind, 1)
添加(oseg, 24)

添加(ox, 6)"""))

PATCHES.append((
    'init2',
    """添加(orr, 90)
添加(org, 210)
添加(orb, 130)
""",
    """添加(orr, 90)
添加(org, 210)
添加(orb, 130)
添加(okind, 2)
添加(oseg, 24)
"""))

PATCHES.append((
    'init3',
    """添加(orr, 100)
添加(org, 150)
添加(orb, 230)
""",
    """添加(orr, 100)
添加(org, 150)
添加(orb, 230)
添加(okind, 3)
添加(oseg, 24)
"""))

PATCHES.append((
    'init4',
    """添加(orr, 240)
添加(org, 220)
添加(orb, 90)
""",
    """添加(orr, 240)
添加(org, 220)
添加(orb, 90)
添加(okind, 4)
添加(oseg, 12)
"""))

# ---- 4) 编辑器状态：加当前类型 / FOV / near ----
PATCHES.append((
    'state',
    """转步 = 0.06
日角 = 0.9
""",
    """转步 = 0.06
日角 = 0.9
当前类型 = 1
类型名 = "盒"
视场角 = 70.0
近视距 = 1.0
"""))

# ---- 5) 放置时写入 kind/seg ----
PATCHES.append((
    'place',
    """                添加(orr, 205)
                添加(org, 205)
                添加(orb, 215)
                选中 = 长度(ox) - 1
                信息 = "新建第 $选中 号\"""",
    """                添加(orr, 205)
                添加(org, 205)
                添加(orb, 215)
                添加(okind, 当前类型)
                添加(oseg, 24)
                选中 = 长度(ox) - 1
                信息 = "新建第 $选中 号（$类型名）\""""))

# ---- 6) 复制时一并复制 kind/seg ----
PATCHES.append((
    'clone',
    """            添加(orr, 取值(orr, 选中))
            添加(org, 取值(org, 选中))
            添加(orb, 取值(orb, 选中))
            选中 = 长度(ox) - 1""",
    """            添加(orr, 取值(orr, 选中))
            添加(org, 取值(org, 选中))
            添加(orb, 取值(orb, 选中))
            添加(okind, 取值(okind, 选中))
            添加(oseg, 取值(oseg, 选中))
            选中 = 长度(ox) - 1"""))

# ---- 7) 删除时一并删 kind/seg ----
PATCHES.append((
    'del',
    """            丢 = 删位(orr, 选中)
            丢 = 删位(org, 选中)
            丢 = 删位(orb, 选中)
            信息 = "已删除（剩 $(长度(ox)) 个）\"""",
    """            丢 = 删位(orr, 选中)
            丢 = 删位(org, 选中)
            丢 = 删位(orb, 选中)
            丢 = 删位(okind, 选中)
            丢 = 删位(oseg, 选中)
            信息 = "已删除（剩 $(长度(ox)) 个）\""""))

# ---- 8) 新增：图元类型切换 + FOV/near 快捷键（插在"转动太阳"之前）----
PATCHES.append((
    'keys',
    """    # ===================== 转动太阳（hw.light）=====================""",
    """    # ===================== 切图元类型（1盒 2球 3柱 4锥）=====================
    if(hw.hit("1")) {
        当前类型 = 1
        类型名 = "盒"
        信息 = "放置类型：盒"
    }
    if(hw.hit("2")) {
        当前类型 = 2
        类型名 = "球"
        信息 = "放置类型：球（半径=尺寸）"
    }
    if(hw.hit("3")) {
        当前类型 = 3
        类型名 = "圆柱"
        信息 = "放置类型：圆柱"
    }
    if(hw.hit("4")) {
        当前类型 = 4
        类型名 = "圆锥"
        信息 = "放置类型：圆锥"
    }

    # ===================== FOV / 近裁剪面（hw.fov / hw.near）=====================
    if(hw.key("[")) {
        视场角 = 视场角 - 0.6
        if(视场角 < 15) {
            视场角 = 15
        }
        丢 = hw.fov(视场角)
        信息 = "FOV $视场角 度"
    }
    if(hw.key("]")) {
        视场角 = 视场角 + 0.6
        if(视场角 > 140) {
            视场角 = 140
        }
        丢 = hw.fov(视场角)
        信息 = "FOV $视场角 度"
    }
    if(hw.hit("-")) {
        if(近视距 < 0.2) {
            近视距 = 1.0
        } else {
            近视距 = 0.05
        }
        丢 = hw.near(近视距)
        信息 = "近裁剪面 $近视距"
    }
    if(hw.hit("=")) {
        if(近视距 > 2) {
            近视距 = 1.0
        } else {
            近视距 = 3.0
        }
        丢 = hw.near(近视距)
        信息 = "近裁剪面 $近视距"
    }

    # ===================== 转动太阳（hw.light）====================="""))

# ---- 9) 绘制：按类型分发（盒/球/柱/锥）----
PATCHES.append((
    'draw-dispatch',
    """        序 = 序 + 1
    }

    # ---- 选中物体的 gizmo 坐标轴""",
    """        序 = 序 + 1
    }

    # 图元按类型分派重画（把盒子的位置当中心/底面）
    序 = 0
    rm.around(长度(ox)) {
        k = 取值(okind, 序)
        if(k == 2) {
            # 球：位置是球心，抬到"盒底面 + 半径"处
            hw.sphere(ox[序], oy[序] + os[序] * 0.5, oz[序],
                      os[序] * 0.5, orr[序], org[序], orb[序])
        } else {
            if(k == 3) {
                hw.cyl(ox[序], oy[序], oz[序],
                       os[序] * 0.5, os[序], os[序] * 0.5, 取值(oseg, 序),
                       orr[序], org[序], orb[序])
            } else {
                if(k == 4) {
                    hw.cyl(ox[序], oy[序], oz[序],
                           os[序] * 0.5, os[序], 0.0, 取值(oseg, 序),
                           orr[序], org[序], orb[序])
                }
            }
        }
        序 = 序 + 1
    }

    # ---- 选中物体的 gizmo 坐标轴"""))

# ---- 10) HUD 补新键位 + 状态 ----
PATCHES.append((
    'hud',
    """    hw.text(20, 172, 14, "V=线框（当前 $线框）  T=转太阳")
    hw.text(20, 196, 14, "相机 $cx / $cy / $cz")""",
    """    hw.text(20, 172, 14, "1盒 2球 3柱 4锥（当前 $类型名）  V=线框($线框)  T=太阳")
    hw.text(20, 196, 14, "[ ]=FOV($视场角度)  - ==近裁剪面($近视距)  相机 $cx/$cy/$cz")"""))

fails = 0
for label, old, new in PATCHES:
    n = s.count(old)
    if n != 1:
        sys.stderr.write('FAIL [%s] count=%d\n' % (label, n))
        fails += 1
        continue
    s = s.replace(old, new, 1)
    print('ok   ' + label)

if fails:
    sys.stderr.write('\n%d 处锚点失败，未写回\n' % fails)
    sys.exit(1)

io.open(P, 'w', encoding='utf-8', newline='').write(s)
print('\n全部 %d 处已写回' % len(PATCHES))
