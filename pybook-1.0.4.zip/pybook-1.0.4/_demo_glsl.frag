// 自定义着色器 · 片段阶段：全息投影风
// 这一段在固定管线里做不到：菲涅尔边缘 + 滚动扫描线 + 双色渐变 + 贴图混合。
#version 120

varying vec3 vN;
varying vec3 vC;
varying vec2 vUV;
varying vec3 vEye;

uniform vec3  uLight;    // 引擎每帧从 hw.light 灌进来
uniform sampler2D uTex;  // 引擎固定指纹理单元 0（hw.texuse 选的那张）
uniform float uTexMix;   // 引擎默认 1.0；没贴图时是 1x1 白纹理，乘了没影响

uniform float uBoost;    // 亮度总开关（hw.uni 可调）
uniform float uTime;     // 动画相位（每帧 hw.uni 灌）
uniform vec3  uColorA;   // 正面色
uniform vec3  uColorB;   // 边缘色
uniform float uScan;     // 扫描线密度

void main(){
  vec3 N = normalize(vN);
  vec3 V = normalize(-vEye);
  vec3 L = normalize(uLight);

  float d = max(dot(N, L), 0.0);
  float h = d * 0.5 + 0.5;                            // 半兰伯特：背面也亮一点
  float rim = pow(1.0 - max(dot(N, V), 0.0), 2.5);    // 菲涅尔边缘
  float scan = 0.5 + 0.5 * sin(vEye.y * uScan - uTime * 4.0);

  vec3 tex = texture2D(uTex, vUV).rgb;
  vec3 base = mix(uColorA, uColorB, rim);
  vec3 alb = mix(base, base * tex, uTexMix * 0.6);

  float glow = (0.35 + 0.65 * h) * (0.75 + 0.35 * scan) + rim * 0.8;
  gl_FragColor = vec4(alb * glow * uBoost, 1.0);
}
