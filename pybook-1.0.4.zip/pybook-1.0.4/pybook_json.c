/* PYbook js. 库：JSON 解析与序列化（配置/网络/数据交换的地基）。
 * js.parse(文本) -> 值：对象→字典、数组→列表、字符串/数字/true/false/null
 * js.dump(值)   -> 文本：字典/列表/数字/字符串/真假/空，字符串自动转义
 * 纯 C 单遍递归下降；错误带位置提示。 */

#include "pybook_lib.h"

#include <math.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static void js_die(const char *fmt, ...)
{
    va_list ap;
    fprintf(stderr, "运行时错误: js.");
    va_start(ap, fmt);
    vfprintf(stderr, fmt, ap);
    va_end(ap);
    fputc('\n', stderr);
    exit(1);
}

static const char *g_p;                       /* 解析游标 */

static void js_skip(void)
{
    while (*g_p == ' ' || *g_p == '\t' || *g_p == '\n' || *g_p == '\r')
        g_p++;
}

static Value js_value(void);

/* 字符串字面量 → 值（处理 \n \t \r \" \\ \/ 等转义；\uXXXX 暂按原样保留） */
static Value js_parse_string(void)
{
    Value out = rt_str("");
    char *tmp;
    size_t cap = 32, w = 0;
    g_p++;                                    /* 跳过开引号 */
    tmp = (char *)malloc(cap);
    if (!tmp)
        js_die("parse 内存不足");
    while (*g_p && *g_p != '"') {
        char c = *g_p;
        if (c == '\\' && g_p[1]) {
            g_p++;
            switch (*g_p) {
            case 'n': c = '\n'; break;
            case 't': c = '\t'; break;
            case 'r': c = '\r'; break;
            case '"': c = '"'; break;
            case '\\': c = '\\'; break;
            case '/': c = '/'; break;
            default: c = *g_p; break;
            }
        }
        if (w + 5 >= cap) {
            cap *= 2;
            tmp = (char *)realloc(tmp, cap);
            if (!tmp)
                js_die("parse 内存不足");
        }
        tmp[w++] = c;
        g_p++;
    }
    if (*g_p != '"')
        js_die("parse：字符串没闭合");
    g_p++;
    tmp[w] = '\0';
    out = rt_str(tmp);
    free(tmp);
    return out;
}

static Value js_parse_number(void)
{
    char *end = NULL;
    double d = strtod(g_p, &end);
    if (end == g_p)
        js_die("parse：数字格式不对（附近 %.6s）", g_p);
    g_p = end;
    if (d == (double)(long long)d)
        return rt_int((long long)d);
    return rt_float(d);
}

static Value js_parse_array(void)
{
    Value out = rt_list_new();
    g_p++;                                    /* [ */
    js_skip();
    if (*g_p == ']') { g_p++; return out; }
    for (;;) {
        js_skip();
        rt_push(&out, js_value());
        js_skip();
        if (*g_p == ',') { g_p++; continue; }
        if (*g_p == ']') { g_p++; return out; }
        js_die("parse：数组缺逗号或收括号（附近 %.6s）", g_p);
    }
}

static Value js_parse_object(void)
{
    Value out = rt_dict_new();
    g_p++;                                    /* { */
    js_skip();
    if (*g_p == '}') { g_p++; return out; }
    for (;;) {
        Value k, v;
        js_skip();
        if (*g_p != '"')
            js_die("parse：对象的键必须是字符串（附近 %.6s）", g_p);
        k = js_parse_string();
        js_skip();
        if (*g_p != ':')
            js_die("parse：对象键后缺冒号");
        g_p++;
        js_skip();
        v = js_value();
        rt_dict_set(&out, k, v);
        js_skip();
        if (*g_p == ',') { g_p++; continue; }
        if (*g_p == '}') { g_p++; return out; }
        js_die("parse：对象缺逗号或收括号（附近 %.6s）", g_p);
    }
}

static Value js_value(void)
{
    js_skip();
    if (*g_p == '{') return js_parse_object();
    if (*g_p == '[') return js_parse_array();
    if (*g_p == '"') return js_parse_string();
    if (*g_p == 't' && strncmp(g_p, "true", 4) == 0) { g_p += 4; return rt_bool(1); }
    if (*g_p == 'f' && strncmp(g_p, "false", 5) == 0) { g_p += 5; return rt_bool(0); }
    if (*g_p == 'n' && strncmp(g_p, "null", 4) == 0) { g_p += 4; return rt_none(); }
    if (*g_p == '-' || (*g_p >= '0' && *g_p <= '9')) return js_parse_number();
    js_die("parse：不认识的开头（附近 %.6s）", g_p);
    return rt_none();
}

Value rt_js_parse(Value text)
{
    Value out;
    g_p = rt_str_of(text);
    out = js_value();
    js_skip();
    if (*g_p)
        js_die("parse：正文结束后还有剩余字符（附近 %.6s）", g_p);
    return out;
}

/* ---- dump ---- */

typedef struct { char *s; size_t len, cap; } JsBuf;

static void js_buf_put_n(JsBuf *b, const char *s, size_t n)
{
    if (b->len + n + 1 > b->cap) {
        b->cap = b->cap ? b->cap : 256;
        while (b->len + n + 1 > b->cap)
            b->cap *= 2;
        b->s = (char *)realloc(b->s, b->cap);
        if (!b->s)
            js_die("dump 内存不足");
    }
    memcpy(b->s + b->len, s, n);
    b->len += n;
    b->s[b->len] = '\0';
}

static void js_buf_put(JsBuf *b, const char *s) { js_buf_put_n(b, s, strlen(s)); }

static void js_buf_put_escaped(JsBuf *b, const char *s)
{
    char tmp[8];
    for (; *s; s++) {
        switch (*s) {
        case '"': js_buf_put(b, "\\\""); break;
        case '\\': js_buf_put(b, "\\\\"); break;
        case '\n': js_buf_put(b, "\\n"); break;
        case '\t': js_buf_put(b, "\\t"); break;
        case '\r': js_buf_put(b, "\\r"); break;
        default:
            if ((unsigned char)*s < 0x20) {
                snprintf(tmp, sizeof tmp, "\\u%04x", (unsigned char)*s);
                js_buf_put(b, tmp);
            } else {
                js_buf_put_n(b, s, 1);
            }
        }
    }
}

static void js_dump_value(JsBuf *b, Value v)
{
    char num[40];
    if (IS_DICT(v)) {
        Value keys = rt_dict_keys(v);
        RtList *K = AS_LIST(keys);
        js_buf_put(b, "{");
        for (size_t i = 0; i < K->len; i++) {
            if (i) js_buf_put(b, ",");
            js_buf_put(b, "\"");
            js_buf_put_escaped(b, rt_str_of(K->items[i]));
            js_buf_put(b, "\":");
            js_dump_value(b, rt_dict_get(v, K->items[i]));
        }
        js_buf_put(b, "}");
        return;
    }
    if (IS_LIST(v)) {
        RtList *L = AS_LIST(v);
        js_buf_put(b, "[");
        for (size_t i = 0; i < L->len; i++) {
            if (i) js_buf_put(b, ",");
            js_dump_value(b, L->items[i]);
        }
        js_buf_put(b, "]");
        return;
    }
    if (IS_STR(v)) {
        js_buf_put(b, "\"");
        js_buf_put_escaped(b, rt_str_of(v));
        js_buf_put(b, "\"");
        return;
    }
    if (IS_BOOL(v)) { js_buf_put(b, AS_BOOL(v) ? "true" : "false"); return; }
    if (IS_NONE(v)) { js_buf_put(b, "null"); return; }
    if (IS_FLT(v)) {
        snprintf(num, sizeof num, "%.17g", AS_FLT(v));
        js_buf_put(b, num);
        return;
    }
    snprintf(num, sizeof num, "%lld", rt_to_ll(v));   /* INT / BIGINT */
    js_buf_put(b, num);
}

Value rt_js_dump(Value v)
{
    JsBuf b = { NULL, 0, 0 };
    js_dump_value(&b, v);
    if (!b.s) {
        b.s = (char *)malloc(1);
        if (!b.s)
            js_die("dump 内存不足");
        b.s[0] = '\0';
    }
    return rt_str(b.s);                       /* 缓冲按项目约定分配不回收 */
}
