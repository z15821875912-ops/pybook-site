# -*- coding: utf-8 -*-
"""给 3D_highway 加 hw.ortho(半高)：正交投影。
一次改 3 个文件共 6 处，每处断言 count==1，最后分别写回。"""
import io, sys

def patch(path, patches):
    s = io.open(path, encoding='utf-8').read()
    for label, old, new in patches:
        n = s.count(old)
        if n != 1:
            sys.stderr.write('FAIL [%s] count=%d\n' % (label, n))
            sys.exit(1)
        s = s.replace(old, new, 1)
        print('ok  %s' % label)
    io.open(path, 'w', encoding='utf-8', newline='').write(s)

# ---------------- pybook_hw3d.c ----------------
HW = 'pybook_hw3d.c'

ORTHO_FN = """/* hw.ortho(半高)：切正交投影。0（默认）= 透视，> 0 = 正交。
   半高 = 视野竖直方向的一半，单位是"世界单位" —— 写 30 就是上下各看 30 格。
   正交下物体不再近大远小，等距对齐、CAD 式三视图、编辑器俯视图都靠它：

       hw.ortho(30)     # 切正交，上下各看 30 格
       hw.ortho(0)      # 切回透视

   注意：正交下 hw.fov 不参与计算（视场由半高决定），
   但 hw.near / hw.far 照样裁剪 —— 俯视相机架太高时记得把 hw.far 调大。 */
Value rt_hw_ortho(Value vv)
{
    double d = hw_num(vv, "hw.ortho 的半高");
    if (d < 0.0) d = 0.0;
    g_ortho = d;
    return rt_none();
}
"""

patch(HW, [
    # 1. 新状态量
    ('hw3d:state',
     "static double g_near = 1.0;",
     "static double g_near = 1.0;\n"
     "/* 正交投影：0 = 透视（默认），> 0 = 正交，值是视野竖直半高（世界单位）。 */\n"
     "static double g_ortho = 0.0;"),

    # 2. 投影矩阵分支
    ('hw3d:projection',
     "        double fh = n * tan(fovy * 3.14159265358979 / 360.0);\n"
     "        double fw = fh * (double)winW / (double)winH;\n"
     "        glFrustum(-fw, fw, -fh, fh, n, f);",
     "        if (g_ortho > 0.0) {\n"
     "            /* 正交：半高直接是世界单位，不再乘 near —— 近大远小消失。\n"
     "               等距对齐 / 三视图 / 编辑器俯视图靠的就是这个。 */\n"
     "            double oh = g_ortho;\n"
     "            double ow = oh * (double)winW / (double)winH;\n"
     "            glOrtho(-ow, ow, -oh, oh, n, f);\n"
     "        } else {\n"
     "            double fh = n * tan(fovy * 3.14159265358979 / 360.0);\n"
     "            double fw = fh * (double)winW / (double)winH;\n"
     "            glFrustum(-fw, fw, -fh, fh, n, f);\n"
     "        }"),

    # 3. 新函数（紧跟 hw.near 之后）
    ('hw3d:fn',
     "    if (d < 0.01) d = 0.01;\n"
     "    g_near = d;\n"
     "    return rt_none();\n"
     "}",
     "    if (d < 0.01) d = 0.01;\n"
     "    g_near = d;\n"
     "    return rt_none();\n"
     "}\n\n" + ORTHO_FN.rstrip('\n')),
])

# ---------------- pybk_code.py ----------------
patch('pybk_code.py', [
    ('code:names',
     "        'hw.fov': 'rt_hw_fov', 'hw.near': 'rt_hw_near',",
     "        'hw.fov': 'rt_hw_fov', 'hw.near': 'rt_hw_near', 'hw.ortho': 'rt_hw_ortho',"),

    ('code:decl',
     "    lines.append('Value rt_hw_fov(Value);')\n"
     "    lines.append('Value rt_hw_near(Value);')",
     "    lines.append('Value rt_hw_fov(Value);')\n"
     "    lines.append('Value rt_hw_near(Value);')\n"
     "    lines.append('Value rt_hw_ortho(Value);')"),
])

# ---------------- pybk_front.py ----------------
patch('pybk_front.py', [
    ('front:arity',
     "    'hw.sphere': 7, 'hw.cyl': 9, 'hw.fov': 1, 'hw.near': 1,",
     "    'hw.sphere': 7, 'hw.cyl': 9, 'hw.fov': 1, 'hw.near': 1, 'hw.ortho': 1,"),
])
