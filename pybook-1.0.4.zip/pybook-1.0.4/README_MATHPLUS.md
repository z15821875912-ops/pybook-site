# math+ — PYbook 原生数学扩展模块（C）

一份**拿来即合**的 C 模块。设计成两层，专门方便和你的 `numpybk` / `torchbk` / `3D_highway` 撮合：

- **核心层 `mp_*`（纯 C，double\* 缓冲，零运行时依赖）**：numpybk/torchbk/3D_highway 直接 `#include "mathplus.h"` 调，不需要链接 PYbook 运行时，也不碰任何内存分配策略（输出缓冲一律调用方提供）。
- **绑定层 `rt_lib_mp_*`（PYbook 命名空间 `mp.`）**：把 PYbook 的 `Value` 列表 ↔ `double*` 互转，挂进前端 `mp.`。只在「已看到 `pybook_rt.h`」时编译。

> 状态：核心层 **43 项自检全过**；绑定层已**连真实 `pybook_rt.c` + SDL2 编译运行验证**（vec_dot / mat_det / mat_inverse / 统计 / 随机全部数值正确）。

---

## 1. 文件清单

| 文件 | 作用 |
|------|------|
| `mathplus.h` | 公共头。核心 API 无条件声明；绑定 API 用 `__PYBOOK_RT_H__ \|\| MP_RT_BINDING` 守卫 |
| `mathplus.c` | 实现：核心层 + 绑定层（绑定层需 `-DMP_RT_BINDING` 或先 include `pybook_rt.h`） |
| `mathplus_test.c` | 核心层自检（无运行时）。`gcc -O2 mathplus_test.c mathplus.c -o t -I. && t` |
| `mathplus_reg.py` | 接进 `pybk_code.py` 的注册片段（LIB_C_NAMES / LIB_CALLS / 编译清单） |
| `mathplus.pybk` | 语言侧调用示例 |
| `e2e/` | 端到端验证残留（连运行时编出 `mp_e2e.exe` 跑通的证明，可不发） |

---

## 2. 编译

### 2.1 核心层自测（无运行时，最快验证）
```bash
gcc -O2 mathplus_test.c mathplus.c -o mp_test -I.
./mp_test          # 期望：43 通过 / 0 失败
```

### 2.2 接入 PYbook（你的另一台机器）
三步，和 numpybk/torchbk 的接法一致（详见 `mathplus_reg.py`）：

1. `pybook_lib.h` 末尾加一行：`#include "mathplus.h"`
2. `pybk_code.py` 的 `LIB_C_NAMES` / `LIB_CALLS` 各追加一段（reg 文件里已列好）
3. `pybk_code.py` 的编译清单元组加 `'mathplus.c'`，并给它的编译加 `-DMP_RT_BINDING`

> 关键点：`mathplus.c` 必须“看到 `pybook_rt.h`”才会编译绑定层。第 1 步的
> `#include` 已保证这点；`-DMP_RT_BINDING` 是双保险。只发核心层（不接 PYbook）时
> 完全不需要这两个宏，直接当普通 C 数学库用。

---

## 3. 与 numpybk / torchbk / 3D_highway 撮合

**重库不要重写基础数值运算，直接调核心层**：

```c
#include "mathplus.h"          /* 不需要 pybook_rt.h */

/* torchbk：矩阵乘（你的张量按行主序铺平后调用） */
double A[6], B[6], C[6];
mp_mat_mul(A, B, C, 2, 3, 2);            /* 2x3 × 3x2 -> 2x2 */

/* torchbk：参数初始化用独立高斯（不污染标准库 rd 的随机流） */
mp_rand_seed(1234);
double w = mp_rand_normal(0.0, 0.01);

/* numpybk：协方差/统计 */
double mu = mp_mean(buf, n);
double sd = mp_std(buf, n, 1);            /* ddof=1 样本标准差 */

/* 3D_highway：变换矩阵 */
double R[9], P[16], T[16];
mp_mat_rot_z(R, mp_radians(45));         /* 绕 Z 转 45°（右手系 +θ） */
mp_mat_perspective(P, mp_radians(60), 16.0/9.0, 0.1, 1000.0);
mp_mat_translate(T, cam_x, cam_y, cam_z);
```

核心层全部是 **`double*` 行主序 + 调用方提供输出缓冲`**，所以你的重库用自己的存储
（堆/栈/池）即可，互不干涉分配策略——这是“撮合”时最干净的分界。

---

## 4. API 总表

### 4.1 向量（长度 n，double\*）
| 核心 C | PYbook 绑定 | 说明 |
|--------|------------|------|
| `mp_vec_add(a,b,o,n)` | `mp.vec_add(a,b)` → 列表 | 逐元素加 |
| `mp_vec_sub(a,b,o,n)` | `mp.vec_sub(a,b)` → 列表 | 逐元素减 |
| `mp_vec_scale(a,s,o,n)` | `mp.vec_scale(a,s)` → 列表 | 数乘 |
| `mp_vec_dot(a,b,n)` | `mp.vec_dot(a,b)` → 浮点 | 内积 |
| `mp_vec_norm(a,n)` | `mp.vec_norm(a)` → 浮点 | L2 范数 |
| `mp_vec_dist(a,b,n)` | `mp.vec_dist(a,b)` → 浮点 | 欧氏距离 |
| `mp_vec_cross(a,b,o[3])` | `mp.vec_cross(a,b)` → [3] | 叉积（仅 3D） |
| `mp_vec_lerp(a,b,o,n,t)` | `mp.vec_lerp(a,b,t)` → 列表 | 线性插值 |

### 4.2 矩阵（行主序，r 行 c 列）
| 核心 C | PYbook 绑定 | 说明 |
|--------|------------|------|
| `mp_mat_add(a,b,o,r,c)` | `mp.mat_add(a,b,r,c)` → 列表 | 加 |
| `mp_mat_scale(a,s,o,r,c)` | `mp.mat_scale(a,s,r,c)` → 列表 | 数乘 |
| `mp_mat_mul(a,b,o,r,m,c)` | `mp.mat_mul(a,b,r,m,c)` → 列表 | 乘（a:r×m, b:m×c） |
| `mp_mat_transpose(a,o,r,c)` | `mp.mat_transpose(a,r,c)` → 列表 | 转置 |
| `mp_mat_identity(o,n)` | `mp.mat_identity(n)` → 列表 | 单位阵（n×n） |
| `mp_mat_vec_mul(a,x,o,r,c)` | `mp.mat_vec_mul(a,x,r,c)` → 列表 | 矩阵×向量 |
| `mp_mat_det(a,n)` | `mp.mat_det(a,n)` → 浮点 | 行列式（部分主元 LU，n≤16） |
| `mp_mat_inverse(a,o,n)` | `mp.mat_inverse(a,n)` → 列表 | 逆（0=成功 / -1=奇异报错） |

### 4.3 3D 辅助
| 核心 C | 说明 |
|--------|------|
| `mp_mat_rot_x/rot_y/rot_z(o,ang)` | 3×3 旋转（右手系 +ang，弧度） |
| `mp_mat_perspective(o,fovy,aspect,zn,zf)` | 4×4 透视（右手，z∈[-1,1]） |
| `mp_mat_translate(o,x,y,z)` | 4×4 平移 |

### 4.4 统计 / 变换 / 标量
| 核心 C | PYbook 绑定 | 说明 |
|--------|------------|------|
| `mp_sum(a,n)` | `mp.sum(list)` | 求和 |
| `mp_mean(a,n)` | `mp.mean(list)` | 均值 |
| `mp_var(a,n,ddof)` | `mp.var(list,ddof)` | 方差（0 总体 / 1 样本） |
| `mp_std(a,n,ddof)` | `mp.std(list,ddof)` | 标准差 |
| `mp_minmax(a,n,&mn,&mx)` | `mp.minmax(list)` → [min,max] | 最值 |
| `mp_linspace(o,n,lo,hi)` | `mp.linspace(lo,hi,n)` → 列表 | 等距采样 |
| `mp_clamp(v,lo,hi)` | `mp.clamp(v,lo,hi)` | 夹取 |
| `mp_mix(a,b,t)` | `mp.lerp(a,b,t)` | 标量插值 |
| `mp_smoothstep(e0,e1,x)` | `mp.smoothstep(e0,e1,x)` | 平滑阶跃 |
| `mp_radians/mp_degrees` | `mp.radians/mp.degrees` | 角度换算 |

### 4.5 随机（自带 xorshift128 PRNG，独立于标准库 `rd`）
| 核心 C | PYbook 绑定 | 说明 |
|--------|------------|------|
| `mp_rand_seed(u64)` | `mp.rand_seed(s)` | 设种子（确定性可复现） |
| `mp_rand_u01()` | `mp.rand_u01()` | [0,1) |
| `mp_rand_normal(mean,sd)` | `mp.rand_normal(m,sd)` | 正态分布（Box-Muller） |

> 独立 PRNG 的意义：torchbk/numpybk 初始化权重时可以自己控随机流，不会和游戏/脚本里
> 的 `rd.int` 互相串扰——这正是“撮合”时要避免的隐式耦合。

---

## 5. 约定与坑
- **矩阵在 PYbook 侧用「扁平列表 + 维度」传**（和 `numpy.flatten` 一致）：`mp.mat_mul([1,2,3,4], [5,6,7,8], 2, 2, 2)`。
- **旋转是右手系 +θ**（标准数学方向），不是屏幕坐标方向——3D_highway 若用左手系自行取负或换轴。
- **绑定层列表元素是浮点**；整型字面量（如维度 `2`）自动转，无需 `vg.` 前缀（普通模式变量照常 `vg.` 声明）。
- **核心层所有输出缓冲由调用方分配**：`mp_mat_inverse` 失败时返回 `-1`，不会写 `out`。
- 数值核对：`mat_det([[1,2],[3,4]])=-2`、`mp.vec_cross([1,2,3],[4,5,6])=[-3,6,-3]`、`std([1..4],ddof1)=1.291`。
