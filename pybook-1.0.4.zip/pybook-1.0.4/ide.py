# -*- coding: utf-8 -*-
"""PYbook IDE —— 单文件深色编辑器 + 进程管理器。

从零实现，不 import 任何 ide_*.py / pybk_*.py / pybook_rt：
IDE 只负责写代码和管进程，编译逻辑全部通过 subprocess 调外部命令——
    F5        python pybk_main.py  <临时.pybk>   （前端 → C → gcc → 原生 exe）
    Ctrl+F5   python pybk_build.py <临时.pybk> <out.pybc> 后再跑 pyvm.exe
运行前先用一条 python -c 小脚本调 pybk_code 做纯编译检查（不运行程序），
语法/语义错误以红字写入输出区，不弹窗。

线程约定：所有耗时操作在 daemon 工作线程里，线程只往 queue.Queue 放消息；
主线程用 root.after 轮询队列并刷新 UI，绝不从工作线程直接碰 Tk。

仅用 Python 标准库。
"""

import os
import queue
import re
import subprocess
import sys
import tempfile
import threading
import tkinter as tk
import tkinter.font as tkfont
from tkinter import filedialog, messagebox

# ---- 外部命令与路径 ----
# 打包成 exe（PyInstaller onefile）后 __file__ 在临时解包目录，
# 工程文件都在 exe 旁边——所以 BASE_DIR 取 exe 所在目录。
BASE_DIR = os.path.dirname(os.path.abspath(sys.executable))     if getattr(sys, 'frozen', False) else os.path.dirname(os.path.abspath(__file__))
import shutil as _sh
def _find_gcc():
    """按序探测可用的 gcc：PATH → mingw64 全名 → mingw64 短名 → 桌面。
    gcc 挪窝/改名不再需要改代码。"""
    cands = [
        _sh.which('gcc'),
        r'C:' + chr(92) + 'Users' + chr(92) + 'zhuli' + chr(92) + 'mingw64' + chr(92) + 'bin' + chr(92) + 'x86_64-w64-mingw32-gcc.exe',
        r'C:' + chr(92) + 'Users' + chr(92) + 'zhuli' + chr(92) + 'mingw64' + chr(92) + 'bin' + chr(92) + 'gcc.exe',
        r'C:' + chr(92) + 'Users' + chr(92) + 'zhuli' + chr(92) + 'Desktop' + chr(92) + 'gcc.exe',
    ]
    import os as _os
    for c in cands:
        if c and _os.path.isfile(c):
            return c
    return 'gcc'
GCC_PATH = _find_gcc()
PYBK_MAIN = os.path.join(BASE_DIR, 'pybk_main.py')
PYBK_BUILD = os.path.join(BASE_DIR, 'pybk_build.py')
PYVM = os.path.join(BASE_DIR, 'pyvm.exe')
NEW_CONSOLE = getattr(subprocess, 'CREATE_NEW_CONSOLE', 0)

# ---- 深色主题（Catppuccin Mocha）----
C = {
    'editor_bg': '#1e1e2e',   # 编辑区背景
    'editor_fg': '#cdd6f4',   # 编辑区文字
    'linenum_bg': '#181825',  # 行号区背景
    'linenum_fg': '#6c7086',  # 行号文字
    'linenum_cur': '#cba6f7', # 当前行号
    'cursor': '#f5c2e7',      # 光标
    'select': '#45475a',      # 选中文本
    'out_bg': '#11111b',      # 输出区背景
    'out_fg': '#cdd6f4',      # 输出区文字
    'err': '#f38ba8',         # 错误文字
    'ok': '#a6e3a1',          # 成功文字
    'hl_prefix': '#fab387',   # 语法-前缀码
    'hl_kw': '#cba6f7',       # 语法-关键字
    'hl_str': '#a6e3a1',      # 语法-字符串
    'hl_num': '#fab387',      # 语法-数字
    'hl_comment': '#6c7086',  # 语法-注释
    'bar_bg': '#181825',      # 菜单/工具栏底
    'status_bg': '#11111b',   # 状态栏底
    'status_fg': '#a6adc8',   # 状态栏文字
    'hover': '#313244',       # 悬停/分隔
}

# 语法高亮：一次正则扫描，组号 -> tag。
# 顺序有讲究：字符串最先，注释里的引号才不会拆开字符串；
# 前缀码/关键字用 \b 圈边界，不会误染中文变量名里的英文片段。
HL_RE = re.compile(
    r'("[^"\n]*")'                                                 # 1 字符串
    r'|(#[^\n]*)'                                                  # 2 注释
    r'|(\b\d+(?:\.\d+)?\b)'                                        # 3 数字
    r'|\b(when|func|lock|del|if|elif|else|while|ret|self)\b'       # 4 关键字
    r'|\b(vg_ro|vg|ns|rm|vc|fv|hm|lb|out|ip)\b'                    # 5 前缀码
)
HL_TAG_OF_GROUP = {
    1: 'hl_str', 2: 'hl_comment', 3: 'hl_num', 4: 'hl_kw', 5: 'hl_prefix',
}
HL_TAGS = ('hl_str', 'hl_comment', 'hl_num', 'hl_kw', 'hl_prefix')
HL_COLORS = {
    'hl_str': C['hl_str'], 'hl_comment': C['hl_comment'],
    'hl_num': C['hl_num'], 'hl_kw': C['hl_kw'], 'hl_prefix': C['hl_prefix'],
}

# 运行前的编译检查：子进程里跑 pybk_front.parse + pybk_code 代码生成，
# 只编译不运行。语法/语义错误写 stderr，退出码 1。
_CHECK_SCRIPT = """import sys
sys.path.insert(0, sys.argv[1])
if sys.stderr:                       # pythonw 下 stderr 为 None
    sys.stderr.reconfigure(encoding='utf-8', errors='replace')
if sys.stdout:
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
from pybk_front import parse, PybkError
from pybk_code import Codegen, PybkCodegenError
try:
    src = open(sys.argv[2], encoding='utf-8-sig').read()
    Codegen().generate(parse(src))
except (PybkError, PybkCodegenError) as e:
    sys.stderr.write(str(e) + '\\n')
    sys.exit(1)
except RecursionError:
    sys.stderr.write('表达式或嵌套太深，请拆分后再试\\n')
    sys.exit(1)
"""


class AnsiOutput:
    """只读 tk.Text 输出区：解析 ANSI 转义码并映射成 Tk tag。

    支持 \x1b[38;2;R;G;Bm 前景色、\x1b[1m 加粗、\x1b[0m 重置，
    以及常见 30-37/90-97 基本色；其余 CSI 序列一律吞掉。
    转义序列可能被管道读到一半切断，挂半个序列的尾巴先缓存，
    等下一个数据块到齐再渲染。
    """

    CSI = re.compile(r'\x1b\[([0-9;]*)([A-Za-z])')

    BASIC_FG = {
        30: '#45475a', 31: '#f38ba8', 32: '#a6e3a1', 33: '#f9e2af',
        34: '#89b4fa', 35: '#f5c2e7', 36: '#94e2d5', 37: '#cdd6f4',
        90: '#6c7086', 91: '#f38ba8', 92: '#a6e3a1', 93: '#f9e2af',
        94: '#89b4fa', 95: '#f5c2e7', 96: '#94e2d5', 97: '#ffffff',
    }

    def __init__(self, text, normal_font, bold_font, default_fg):
        self.text = text
        self.default_fg = default_fg
        self._fg = None        # 当前 ANSI 前景色对应的 tag 名
        self._bold = False
        self._buf = ''         # 半截转义序列的缓冲
        self._made = set()     # 已配置过的颜色 tag
        text.tag_configure('ansi_def', foreground=default_fg)
        text.tag_configure('ansi_bold', font=bold_font)

    # ---- 对外 ----

    def write(self, chunk):
        """程序输出入口：可能混着 ANSI 码，也可能一块被截成两半。"""
        chunk = chunk.replace('\r\n', '\n').replace('\r', '\n')
        text = self._buf + chunk
        stick = self._at_bottom()
        # 末尾若挂着半截转义序列，留下次再渲染，避免闪出一个孤零零的 ESC
        cut = len(text)
        last = text.rfind('\x1b')
        if last != -1 and self.CSI.match(text, last) is None:
            if len(text) == last + 1 or text[last + 1] == '[':
                cut = last
        self._buf = text[cut:]
        text = text[:cut]

        pos = 0
        for m in self.CSI.finditer(text):
            if m.start() > pos:
                self._emit(text[pos:m.start()])
            if m.group(2) == 'm':
                self._sgr(m.group(1))
            pos = m.end()
        if pos < len(text):
            self._emit(text[pos:])
        if stick:
            self.text.see('end')

    def write_line(self, s, tag='ansi_def'):
        """IDE 自己的消息：直接按给定 tag 写，不走 ANSI 状态机。"""
        stick = self._at_bottom()
        self._insert(s, (tag,))
        if stick:
            self.text.see('end')

    def clear(self):
        self.text.config(state='normal')
        self.text.delete('1.0', 'end')
        self.text.config(state='disabled')

    # ---- 内部 ----

    def _at_bottom(self):
        return self.text.yview()[1] > 0.99

    def _insert(self, s, tags):
        self.text.config(state='normal')
        self.text.insert('end', s, tags)
        self.text.config(state='disabled')

    def _emit(self, s):
        if not s:
            return
        tags = []
        if self._fg:
            tags.append(self._fg)
        if self._bold:
            tags.append('ansi_bold')
        self._insert(s, tuple(tags) or ('ansi_def',))

    def _sgr(self, params):
        parts = (params or '0').split(';')
        i = 0
        while i < len(parts):
            p = parts[i]
            n = int(p) if p.isdigit() else 0
            if n == 0:
                self._fg = None
                self._bold = False
            elif n == 1:
                self._bold = True
            elif n == 22:
                self._bold = False
            elif n == 39:
                self._fg = None
            elif n == 38 and i + 4 < len(parts) and parts[i + 1] == '2':
                try:
                    hexv = '#%02x%02x%02x' % (
                        int(parts[i + 2]), int(parts[i + 3]), int(parts[i + 4]))
                    self._fg = self._color_tag(hexv)
                except ValueError:
                    pass
                i += 4
            elif 30 <= n <= 37 or 90 <= n <= 97:
                self._fg = self._color_tag(self.BASIC_FG.get(n, self.default_fg))
            i += 1

    def _color_tag(self, hexcolor):
        tag = 'ansi_' + hexcolor[1:]
        if tag not in self._made:
            self.text.tag_configure(tag, foreground=hexcolor)
            self._made.add(tag)
        return tag


class LineNumberBar(tk.Canvas):
    """编辑区左侧行号：Canvas 上画数字，跟随 Text 滚动。"""

    def __init__(self, master, text, font, fg, cur_fg, bg):
        super().__init__(master, width=44, bg=bg, highlightthickness=0)
        self.text = text
        self.font = font
        self.fg = fg
        self.cur_fg = cur_fg

    def redraw(self):
        t = self.text
        nlines = max(1, int(t.index('end-1c').split('.')[0]))
        digits = max(2, len(str(nlines)))
        w = self.font.measure('0') * digits + 16
        if int(self['width']) != w:
            self.config(width=w)
        self.delete('all')
        cur = t.index('insert').split('.')[0]
        i = t.index('@0,0')            # 视口里第一行
        linespace = self.font.metrics('linespace')
        while True:
            dline = t.dlineinfo(i)
            if dline is None:
                break
            y, h = dline[1], dline[3]
            ln = i.split('.')[0]
            self.create_text(
                w - 8, y + (h - linespace) // 2 + linespace // 2,
                text=ln, anchor='e', font=self.font,
                fill=self.cur_fg if ln == cur else self.fg)
            i = t.index(i + '+1line')


class PybookIDE:
    def __init__(self, root):
        self.root = root
        self.filepath = None
        self.dirty = False
        self.running = False
        self.proc = None               # 当前子进程（工作线程里赋值，仅读写属性）
        self._stop_requested = False
        self.ui_queue = queue.Queue()  # 工作线程 -> 主线程 的唯一通道
        self._hl_job = None            # 高亮防抖的 after 句柄
        self._loading = False          # 程序化装载文件时不标记 dirty
        self._last_pos = None
        if getattr(sys, 'frozen', False):
            打包py = _sh.which('python') or _sh.which('python3') or _sh.which('py')
            self.python_exe = 打包py or sys.executable
        else:
            self.python_exe = sys.executable

        self._setup_fonts()
        self._build_menu()
        self._build_toolbar()
        self._build_editor()
        self._build_output()
        self._build_statusbar()
        self._bind_keys()

        root.title('PYbook IDE')
        root.iconbitmap("ide_icon.ico")
        root.geometry('1080x720')
        root.configure(bg=C['bar_bg'])
        root.minsize(760, 480)
        root.protocol('WM_DELETE_WINDOW', self._on_close)

        self._welcome()
        self._update_title()
        self._update_status_file()
        root.after(60, self._poll_queue)
        root.after(150, self._tick)
        root.after(200, self._cursor_moved)   # 首次映射后画一次行号

    # ================================================== UI 搭建

    def _setup_fonts(self):
        families = set(tkfont.families())
        self.editor_font = None
        for name in ('Cascadia Code', 'Consolas', 'Courier New'):
            if name in families:
                self.editor_font = tkfont.Font(family=name, size=12)
                break
        if self.editor_font is None:
            self.editor_font = tkfont.nametofont('TkFixedFont')
            self.editor_font.configure(size=12)
        self.editor_bold = self.editor_font.copy()
        self.editor_bold.configure(weight='bold')

        if 'Microsoft YaHei UI' in families:
            self.ui_font = tkfont.Font(family='Microsoft YaHei UI', size=10)
        else:
            self.ui_font = tkfont.nametofont('TkDefaultFont')

    def _menu_kw(self):
        return dict(tearoff=False, bg=C['bar_bg'], fg=C['editor_fg'],
                    activebackground=C['hover'], activeforeground=C['editor_fg'],
                    bd=0, font=self.ui_font)

    def _build_menu(self):
        kw = self._menu_kw()
        menubar = tk.Menu(self.root, **kw)
        m_file = tk.Menu(menubar, **kw)
        m_file.add_command(label='新建', accelerator='Ctrl+N', command=self.new_file)
        m_file.add_command(label='打开...', accelerator='Ctrl+O', command=self.open_file)
        m_file.add_separator()
        m_file.add_command(label='保存', accelerator='Ctrl+S', command=self.save_file)
        m_file.add_command(label='另存为...', accelerator='Ctrl+Shift+S',
                           command=self.save_file_as)
        m_file.add_separator()
        m_file.add_command(label='退出', command=self._on_close)

        m_run = tk.Menu(menubar, **kw)
        m_run.add_command(label='▶ 运行', accelerator='F5',
                          command=lambda: self.run_program('native'))
        m_run.add_command(label='▶ 用虚拟机运行', accelerator='Ctrl+F5',
                          command=lambda: self.run_program('vm'))
        m_run.add_command(label='■ 停止', accelerator='Shift+F5', command=self.stop_run)
        m_run.add_separator()
        m_run.add_command(label='清空输出', command=lambda: self.out.clear())

        m_help = tk.Menu(menubar, **kw)
        m_help.add_command(label='语法速查', command=self.show_cheatsheet)
        m_help.add_command(label='关于', command=self.show_about)

        menubar.add_cascade(label='文件', menu=m_file)
        menubar.add_cascade(label='运行', menu=m_run)
        menubar.add_cascade(label='帮助', menu=m_help)
        self.root.config(menu=menubar)

    def _tool_button(self, parent, text, command, fg, state='normal'):
        return tk.Button(
            parent, text=text, command=command, state=state,
            font=self.ui_font, relief='flat', bd=0, cursor='hand2',
            bg=C['bar_bg'], fg=fg, padx=12, pady=4,
            activebackground=C['hover'], activeforeground=C['editor_fg'],
            disabledforeground='#45475a')

    def _build_toolbar(self):
        bar = tk.Frame(self.root, bg=C['bar_bg'], height=38)
        bar.pack(side='top', fill='x')
        bar.pack_propagate(False)

        self._tool_button(bar, '📄 新建', self.new_file, C['editor_fg']).pack(side='left', padx=(8, 0), pady=3)
        self._tool_button(bar, '📂 打开', self.open_file, C['editor_fg']).pack(side='left', padx=4, pady=3)
        self._tool_button(bar, '💾 保存', self.save_file, C['editor_fg']).pack(side='left', padx=4, pady=3)
        tk.Frame(bar, width=1, bg=C['hover']).pack(side='left', fill='y', padx=6, pady=6)
        self.run_btn = self._tool_button(bar, '▶ 运行', lambda: self.run_program('native'), C['ok'])
        self.run_btn.pack(side='left', padx=4, pady=3)
        self.stop_btn = self._tool_button(bar, '■ 停止', self.stop_run, C['err'], state='disabled')
        self.stop_btn.pack(side='left', padx=4, pady=3)

    def _build_editor(self):
        pw = tk.PanedWindow(self.root, orient='vertical', sashwidth=3,
                            bg=C['hover'], bd=0)
        pw.pack(side='top', fill='both', expand=True)

        editor_frame = tk.Frame(pw, bg=C['editor_bg'])
        output_frame = tk.Frame(pw, bg=C['out_bg'])
        pw.add(editor_frame, minsize=120, height=430, stretch='always')
        pw.add(output_frame, minsize=90, height=240, stretch='always')
        self.paned = pw

        self.text = tk.Text(
            editor_frame, wrap='word', undo=True,
            bg=C['editor_bg'], fg=C['editor_fg'],
            insertbackground=C['cursor'], insertwidth=2, insertontime=500,
            selectbackground=C['select'], selectforeground=C['editor_fg'],
            font=self.editor_font, relief='flat', bd=0, padx=10, pady=8)
        self.vbar = tk.Scrollbar(editor_frame, command=self.text.yview)
        self.text.config(yscrollcommand=self._on_yscroll)

        self.linenumbers = LineNumberBar(
            editor_frame, self.text, self.editor_font,
            fg=C['linenum_fg'], cur_fg=C['linenum_cur'], bg=C['linenum_bg'])

        self.linenumbers.pack(side='left', fill='y')
        self.vbar.pack(side='right', fill='y')
        self.text.pack(side='left', fill='both', expand=True)

        for tag, color in HL_COLORS.items():
            self.text.tag_configure(tag, foreground=color)
        self.text.tag_raise('sel')   # 选中高亮永远盖在语法色之上

    def _build_output(self):
        # PanedWindow 的第二个面板就是输出区
        kids = self.paned.panes()
        pane = kids[1].decode() if isinstance(kids[1], bytes) else kids[1]
        frame = self.root.nametowidget(pane)

        self.out_text = tk.Text(
            frame, wrap='word', state='disabled',
            bg=C['out_bg'], fg=C['out_fg'],
            insertbackground=C['cursor'],
            selectbackground=C['select'], selectforeground=C['out_fg'],
            font=self.editor_font, relief='flat', bd=0, padx=10, pady=8)
        self.out_vbar = tk.Scrollbar(frame, command=self.out_text.yview)
        self.out_text.config(yscrollcommand=self.out_vbar.set)
        self.out_vbar.pack(side='right', fill='y')
        self.out_text.pack(side='left', fill='both', expand=True)

        self.out_text.tag_configure('out_err', foreground=C['err'])
        self.out_text.tag_configure('out_ok', foreground=C['ok'])
        self.out_text.tag_configure('out_dim', foreground=C['linenum_fg'])
        self.out_text.tag_configure('out_note', foreground=C['status_fg'])
        self.out = AnsiOutput(self.out_text, self.editor_font,
                              self.editor_bold, C['out_fg'])

    def _build_statusbar(self):
        status = tk.Frame(self.root, bg=C['status_bg'], height=26)
        status.pack(side='bottom', fill='x')
        status.pack_propagate(False)
        lbl = dict(bg=C['status_bg'], fg=C['status_fg'], font=self.ui_font, bd=0)
        self.pos_label = tk.Label(status, text='行 1, 列 1', **lbl)
        self.pos_label.pack(side='right', padx=(0, 10))
        self.status_label = tk.Label(status, text='就绪', anchor='center', **lbl)
        self.status_label.pack(side='left', expand=True, fill='both')
        self.file_label = tk.Label(status, text='未命名', **lbl)
        self.file_label.pack(side='left', padx=(10, 0))

    def _welcome(self):
        self.out.write_line('PYbook IDE 就绪。\n', 'out_note')
        self.out.write_line('F5 运行（编译成 exe）｜ Ctrl+F5 用虚拟机运行 ｜ Shift+F5 停止\n', 'out_dim')

    # ================================================== 快捷键与编辑行为

    def _bind_keys(self):
        r = self.root
        r.bind('<F5>', lambda e: self.run_program('native'))
        r.bind('<Control-F5>', lambda e: self.run_program('vm'))
        r.bind('<Shift-F5>', lambda e: self.stop_run())
        for seq, fn in (('<Control-n>', self.new_file),
                        ('<Control-N>', self.new_file),
                        ('<Control-o>', self.open_file),
                        ('<Control-O>', self.open_file),
                        ('<Control-s>', self.save_file),
                        ('<Control-S>', self.save_file),
                        ('<Control-Shift-S>', self.save_file_as)):
            r.bind(seq, lambda e, f=fn: (f(), 'break')[1])

        t = self.text
        t.bind('<Return>', self._on_return)
        t.bind('<KP_Enter>', self._on_return)
        t.bind('<Tab>', self._on_tab)
        t.bind('<<Modified>>', self._on_modified)
        t.bind('<KeyRelease>', lambda e: self._cursor_moved())
        t.bind('<ButtonRelease-1>', lambda e: self._cursor_moved())

    def _on_return(self, event):
        """回车保持上一行缩进；上一行以 { 结尾就再多缩一层。"""
        line = self.text.get('insert linestart', 'insert')
        indent = re.match(r'[ \t]*', line).group(0)
        if line.rstrip().endswith('{'):
            indent += '    '
        self.text.insert('insert', '\n' + indent)
        self.text.see('insert')
        return 'break'

    def _on_tab(self, event):
        self.text.insert('insert', '    ')
        return 'break'

    def _on_modified(self, event=None):
        if self._loading or not self.text.edit_modified():
            return
        self.text.edit_modified(False)
        if not self.dirty:
            self._set_dirty(True)
        if self._hl_job:
            self.root.after_cancel(self._hl_job)
        self._hl_job = self.root.after(300, self.highlight)  # 输入防抖 300ms
        self.linenumbers.redraw()

    def _on_yscroll(self, first, last):
        self.vbar.set(first, last)
        self.linenumbers.redraw()

    def _cursor_moved(self):
        line, col = self.text.index('insert').split('.')
        self.pos_label.config(text=f'行 {line}, 列 {int(col) + 1}')
        self.linenumbers.redraw()

    def _tick(self):
        """低频巡查：光标位置变化时更新状态栏与当前行号。"""
        self.root.after(150, self._tick)
        pos = self.text.index('insert')
        if pos != self._last_pos:
            self._last_pos = pos
            self._cursor_moved()

    def highlight(self):
        self._hl_job = None
        t = self.text
        for tag in HL_TAGS:
            t.tag_remove(tag, '1.0', 'end')
        nlines = max(1, int(t.index('end-1c').split('.')[0]))
        for i in range(1, nlines + 1):
            s = t.get(f'{i}.0', f'{i}.end')
            if not s:
                continue
            for m in HL_RE.finditer(s):
                tag = HL_TAG_OF_GROUP[m.lastindex]
                t.tag_add(tag, f'{i}.{m.start()}', f'{i}.{m.end()}')

    # ================================================== 文件操作

    def _display_name(self):
        return os.path.basename(self.filepath) if self.filepath else '未命名'

    def _update_title(self):
        self.root.title(f'{self._display_name()}{"*" if self.dirty else ""} - PYbook IDE')

    def _update_status_file(self):
        self.file_label.config(text=f'{self._display_name()}{"*" if self.dirty else ""}')

    def _set_dirty(self, dirty):
        self.dirty = dirty
        self._update_title()
        self._update_status_file()

    def set_status(self, s):
        self.status_label.config(text=s)

    def _confirm_discard(self):
        """dirty 时切换文件前确认。返回 False 表示用户想留下。"""
        if not self.dirty:
            return True
        r = messagebox.askyesnocancel('PYbook IDE', '当前代码还没保存，要先保存吗？')
        if r is None:
            return False
        if r:
            return self.save_file()
        return True

    def new_file(self):
        if not self._confirm_discard():
            return
        self._loading = True
        self.text.delete('1.0', 'end')
        self._loading = False
        self.text.edit_modified(False)
        self.text.mark_set('insert', '1.0')
        self.filepath = None
        self._set_dirty(False)
        self.highlight()
        self._cursor_moved()
        self.text.see('insert')
        self.set_status('新建：未命名')

    def open_file(self):
        if not self._confirm_discard():
            return
        path = filedialog.askopenfilename(
            title='打开 PYbook 源码',
            initialdir=os.path.dirname(self.filepath) if self.filepath else BASE_DIR,
            filetypes=[('PYbook 源码', '*.pybk'), ('所有文件', '*.*')])
        if not path:
            return
        try:
            raw = open(path, 'rb').read()
            try:
                src = raw.decode('utf-8-sig')
            except UnicodeDecodeError:
                src = raw.decode('gbk', 'replace')   # 老文件可能是 GBK
        except OSError as e:
            messagebox.showerror('PYbook IDE', f'打不开文件：\n{e}')
            return
        self._loading = True
        self.text.delete('1.0', 'end')
        self.text.insert('1.0', src)
        self._loading = False
        self.text.edit_modified(False)
        self.filepath = path
        self._set_dirty(False)
        self.text.mark_set('insert', '1.0')
        self.text.see('insert')
        self.highlight()
        self._cursor_moved()
        self.set_status('已打开 ' + path)

    def save_file(self):
        return self._save(self.filepath)

    def save_file_as(self):
        return self._save(None)

    def _save(self, path):
        if not path:
            path = filedialog.asksaveasfilename(
                title='保存 PYbook 源码', defaultextension='.pybk',
                initialdir=os.path.dirname(self.filepath) if self.filepath else BASE_DIR,
                initialfile=os.path.basename(self.filepath) if self.filepath else '未命名.pybk',
                filetypes=[('PYbook 源码', '*.pybk'), ('所有文件', '*.*')])
            if not path:
                return False
        src = self.text.get('1.0', 'end-1c')
        try:
            with open(path, 'w', encoding='utf-8', newline='\n') as f:
                f.write(src)
        except OSError as e:
            messagebox.showerror('PYbook IDE', f'保存失败：\n{e}')
            return False
        self.filepath = path
        self._set_dirty(False)
        self.set_status('已保存 ' + path)
        return True

    # ================================================== 运行（核心）

    def run_program(self, mode='native'):
        if self.proc is not None and self.proc.poll() is None:
            self.set_status('已有程序在运行（Shift+F5 可停止）')
            return
        src = self.text.get('1.0', 'end-1c')
        if not src.strip():
            self.set_status('编辑区是空的，先写点代码吧')
            return

        # 源码落盘到临时文件（.pybk 后缀），编译和运行都用它
        try:
            fd, tmp_path = tempfile.mkstemp(suffix='.pybk', prefix='pybk_ide_')
            with os.fdopen(fd, 'w', encoding='utf-8', newline='\n') as f:
                f.write(src)
        except OSError as e:
            self.out.write_line(f'写临时文件失败：{e}\n', 'out_err')
            return

        interactive = ('input(' in src) or ('vg(ip)' in src)
        self._stop_requested = False
        self.out.write_line('── 虚拟机运行 ──\n' if mode == 'vm' else '── 运行 ──\n', 'out_dim')
        self._set_running(True)
        self.set_status('编译中...')
        threading.Thread(target=self._run_worker,
                         args=(tmp_path, interactive, mode), daemon=True).start()

    def _set_running(self, running):
        self.running = running
        self.run_btn.config(state='disabled' if running else 'normal')
        self.stop_btn.config(state='normal' if running else 'disabled')

    @staticmethod
    def _child_env():
        env = os.environ.copy()
        env['PYTHONIOENCODING'] = 'utf-8'
        env['PYTHONUTF8'] = '1'
        gdir = os.path.dirname(GCC_PATH)
        if os.path.isfile(GCC_PATH) and gdir not in env.get('PATH', ''):
            env['PATH'] = gdir + os.pathsep + env.get('PATH', '')
        return env

    # ---- 工作线程里跑的部分（只许碰 queue，不许碰 Tk）----

    def _run_worker(self, tmp_path, interactive, mode):
        q = self.ui_queue
        try:
            # 1) 先纯编译检查：语法/语义错误在这里就红字报告，不启动程序
            rc, err = self._compile_check(tmp_path)
            if rc != 0:
                q.put(('err', err.strip() + '\n' if err.strip() else '编译失败\n'))
                q.put(('status', '编译错误'))
                q.put(('done', 1, True))
                return
            q.put(('ok', '编译通过\n'))
            q.put(('status', '运行中...'))

            # 2) 真正运行
            if mode == 'vm':
                self._run_vm(tmp_path, interactive, q)
            else:
                self._run_native(tmp_path, interactive, q)
        except Exception as e:   # 兜底：任何意外都报告，不让线程静默死掉
            q.put(('err', f'IDE 内部错误：{e!r}\n'))
            q.put(('done', 1, True))
        finally:
            for p in (tmp_path, tmp_path + '.pybc'):
                try:
                    os.remove(p)
                except OSError:
                    pass

    def _compile_check(self, tmp_path):
        p = subprocess.run(
            [self.python_exe, '-c', _CHECK_SCRIPT, BASE_DIR, tmp_path],
            cwd=BASE_DIR, env=self._child_env(),
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=120)
        return p.returncode, p.stderr.decode('utf-8', 'replace')

    def _run_native(self, tmp_path, interactive, q):
        cmd = [self.python_exe, PYBK_MAIN, tmp_path]
        if interactive:
            # 交互程序（含 input 或 vg(ip)：弹独立控制台，用户直接在里面
            # 看输出、敲输入，最可靠，不需要管道转发；用完自己关。
            q.put(('note', '交互程序：已弹出黑色控制台窗口，请在那边输入；'
                           '程序结束后可自行关闭窗口。\n'))
            proc = subprocess.Popen(cmd, cwd=BASE_DIR, env=self._child_env(),
                                    creationflags=NEW_CONSOLE)
            self.proc = proc
            rc = proc.wait()
        else:
            proc = subprocess.Popen(cmd, cwd=BASE_DIR, env=self._child_env(),
                                    stdin=subprocess.DEVNULL,
                                    stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            self.proc = proc
            rc = self._wait_piped(proc, q)
        if rc and not self._stop_requested:
            q.put(('status', f'运行出错（退出码 {rc}）'))
        q.put(('done', rc, rc != 0))

    def _run_vm(self, tmp_path, interactive, q):
        pybc = tmp_path + '.pybc'
        p = subprocess.run([self.python_exe, PYBK_BUILD, tmp_path, pybc],
                           cwd=BASE_DIR, env=self._child_env(),
                           stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                           timeout=120)
        if p.returncode != 0:
            err = p.stderr.decode('utf-8', 'replace').strip()
            q.put(('err', (err + '\n') if err else '字节码编译失败\n'))
            q.put(('status', '编译错误'))
            q.put(('done', 1, True))
            return
        if not os.path.exists(PYVM):
            q.put(('err', f'找不到虚拟机：{PYVM}\n'))
            q.put(('done', 1, True))
            return
        cmd = [PYVM, pybc]
        if interactive:
            q.put(('note', '交互程序（VM）：已弹出控制台窗口，请在那边输入。\n'))
            proc = subprocess.Popen(cmd, cwd=BASE_DIR, env=self._child_env(),
                                    creationflags=NEW_CONSOLE)
            self.proc = proc
            rc = proc.wait()
        else:
            proc = subprocess.Popen(cmd, cwd=BASE_DIR, env=self._child_env(),
                                    stdin=subprocess.DEVNULL,
                                    stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            self.proc = proc
            rc = self._wait_piped(proc, q)
        if rc and not self._stop_requested:
            q.put(('status', f'运行出错（退出码 {rc}）'))
        q.put(('done', rc, rc != 0))

    def _wait_piped(self, proc, q):
        """两个读线程分别泵 stdout/stderr 进队列，主 worker 等退出码。"""
        readers = [
            threading.Thread(target=self._pump,
                             args=(proc.stdout, lambda s: q.put(('out', s))),
                             daemon=True),
            threading.Thread(target=self._pump,
                             args=(proc.stderr, lambda s: q.put(('err', s))),
                             daemon=True),
        ]
        for t in readers:
            t.start()
        rc = proc.wait()
        for t in readers:
            t.join(timeout=5)
        return rc

    @staticmethod
    def _pump(stream, emit):
        try:
            while True:
                chunk = stream.read(4096)
                if not chunk:
                    break
                emit(chunk.decode('utf-8', 'replace'))
        except (OSError, ValueError):
            pass
        finally:
            try:
                stream.close()
            except OSError:
                pass

    # ---- 主线程消费队列 ----

    def _poll_queue(self):
        self.root.after(60, self._poll_queue)
        while True:
            try:
                msg = self.ui_queue.get_nowait()
            except queue.Empty:
                break
            kind = msg[0]
            if kind == 'out':
                self.out.write(msg[1])
            elif kind == 'err':
                self.out.write_line(msg[1], 'out_err')
            elif kind == 'ok':
                self.out.write_line(msg[1], 'out_ok')
            elif kind == 'note':
                self.out.write_line(msg[1], 'out_note')
            elif kind == 'status':
                self.set_status(msg[1])
            elif kind == 'done':
                self._finish_run(msg[1], msg[2])

    def _finish_run(self, rc, failed):
        self._set_running(False)
        self.proc = None
        if self._stop_requested:
            self._stop_requested = False
            self.out.write_line('-- 已停止 --\n', 'out_note')
            self.set_status('已停止')
            return
        if failed:
            self.out.write_line(f'-- 退出码 {rc} --\n', 'out_err')
        else:
            self.out.write_line(f'-- 程序结束，退出码 {rc} --\n', 'out_dim')
            self.set_status('就绪')

    def stop_run(self):
        proc = self.proc
        if proc is None or proc.poll() is not None:
            self.set_status('没有正在运行的程序')
            return
        self._stop_requested = True
        try:   # 连同它派生的 exe / 控制台一起结束
            subprocess.run(['taskkill', '/F', '/T', '/PID', str(proc.pid)],
                           capture_output=True, timeout=5)
        except (OSError, subprocess.TimeoutExpired):
            pass
        try:
            proc.kill()
        except OSError:
            pass
        self.set_status('正在停止...')

    # ================================================== 帮助 / 退出

    def show_cheatsheet(self):
        messagebox.showinfo('PYbook 语法速查', '''@ 名字>作者>版本          ← 可选元信息行
GOING:{
  vg.分数 = 0             ← 定义变量
  ns.show(得分：$分数)     ← 输出，$变量 嵌进文本
  vg(ip).名 = input(?)    ← 从键盘输入
  rm.aging.while(分数 <= 9) { ... }   ← 循环
  rm.around(3) { ... }    ← 重复 3 圈，圈内用 $at
  when(条件) { ... } elif { ... } else { ... }   ← 分支
  func 加(甲, 乙) { ret 甲 + 乙 }     ← 函数
  ns.show(红字)/magic(b, c=255,0,0)   ← 加粗、改颜色
}STOP

快捷键：F5 运行 ｜ Ctrl+F5 虚拟机 ｜ Shift+F5 停止
Ctrl+N 新建 ｜ Ctrl+O 打开 ｜ Ctrl+S 保存''')

    def show_about(self):
        messagebox.showinfo('关于 PYbook IDE',
                            'PYbook IDE —— 中文友好的教学编程语言 IDE\n'
                            'PYbook 源码 → Python 前端 → C 代码 → gcc → 原生 exe\n'
                            '或 PYbook 源码 → 字节码(.pybc) → pyvm.exe\n\n'
                            '仅用 Python 标准库实现。')

    def _on_close(self):
        if not self._confirm_discard():
            return
        proc = self.proc
        if proc is not None and proc.poll() is None:
            try:
                proc.kill()
            except OSError:
                pass
        self.root.destroy()


def main():
    root = tk.Tk()
    PybookIDE(root)
    root.mainloop()


if __name__ == '__main__':
    main()
