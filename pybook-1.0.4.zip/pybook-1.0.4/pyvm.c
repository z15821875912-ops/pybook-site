/* PYbook 字节码虚拟机（.pybc 栈式虚拟机）。
 *
 * 文件格式（与编译器同事的合同，多字节整数一律小端）：
 *   [0..3]='PYBC'；[4..7] u32 版本=1；[8..11] u32 常量数 N；[12..15] u32 函数数 F；
 *   常量池 N 项：u8 类型(1=int64, 2=float64, 3=字符串) + 内容；
 *   函数表 F 项（函数 0 = 主程序）：u32 名字常量索引 + u16 参数个数 + u16 槽位总数
 *   + u32 代码偏移 + u32 代码字节数；代码区紧随，代码偏移相对代码区起点（不是相对文件头）。
 *
 * 结构：全局 Value 操作数栈（初始 4096，满则翻倍 realloc）+ 帧栈
 *（帧 = 返回 ip + 函数索引 + 槽位数组；槽 = 参数按序 + 其余 rt_none() 填充）。
 * 值语义全部委托 pybook_rt.h：rt_add/rt_cond/rt_show_value/rt_input/rt_index/...
 * 本文件只做取指、译码、栈与帧管理、越界与格式校验。
 *
 * 编译：gcc -O2 pyvm.c pybook_rt.c -o pyvm.exe
 * 运行：pyvm.exe 文件.pybc
 * 自测：gcc -O2 -DPYVM_SELF_TEST pyvm.c pybook_rt.c -o pyvm_test.exe && ./pyvm_test
 *   自测 main 会手工拼 4 个字节码模块：42 演示、循环+调用+列表综合、
 *   锁定/删除报错（子进程验证退出码）；参数 "dump" 把样例写成 .pybc 文件，
 *   参数 "child N" 供父进程拉起验证报错分支。
 */

#include <math.h>
#include <stdarg.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "pybook_rt.h"
#include "pybook_lib.h"

/* 标准库调用表（由 LIB_CALLS + LIB_C_NAMES 生成）：name/arity/fn 三元组。
 * CALL_LIB 指令按名字在此查表，按 arity 弹参调用。*/
Value rt_csv_dump(Value); Value rt_csv_parse(Value);
Value rt_js_dump(Value); Value rt_js_parse(Value);
Value rt_safe_get(Value, Value, Value); Value rt_safe_at(Value, Value, Value);
#include "_vm_lib_calls.inc"

_Static_assert(sizeof(double) == 8 && sizeof(long long) == 8, "需要 64 位 double/int64");

/* ================= 错误出口 ================= */

/* 虚拟机自身 / 字节码的问题 */
static void vm_die(const char *fmt, ...)
{
    va_list ap;
    fprintf(stderr, "虚拟机错误: ");
    va_start(ap, fmt);
    vfprintf(stderr, fmt, ap);
    va_end(ap);
    fputc('\n', stderr);
    exit(1);
}

/* 用户程序层面的问题（VM 代替 rt 报的少数几处），保持同一消息风格 */
static void prog_die(const char *fmt, ...)
{
    va_list ap;
    fprintf(stderr, "运行时错误: ");
    va_start(ap, fmt);
    vfprintf(stderr, fmt, ap);
    va_end(ap);
    fputc('\n', stderr);
    exit(1);
}

/* ================= 文件读取与小端解码 ================= */

static uint8_t *read_file(const char *path, size_t *out_len)
{
    FILE *fp = fopen(path, "rb");
    if (!fp)
        return NULL;
    if (fseek(fp, 0, SEEK_END) != 0) {
        fclose(fp);
        return NULL;
    }
    long size = ftell(fp);
    if (size < 0 || fseek(fp, 0, SEEK_SET) != 0) {
        fclose(fp);
        return NULL;
    }
    uint8_t *buf = (uint8_t *)malloc(size ? (size_t)size : 1);
    if (!buf) {
        fclose(fp);
        vm_die("内存不足");
    }
    if (size > 0 && fread(buf, 1, (size_t)size, fp) != (size_t)size) {
        fclose(fp);
        free(buf);
        return NULL;
    }
    fclose(fp);
    *out_len = (size_t)size;
    return buf;
}

/* 带边界检查的顺序解码器 */
typedef struct {
    const uint8_t *p;
    const uint8_t *end;
} Reader;

static const uint8_t *take(Reader *r, size_t n)
{
    if ((size_t)(r->end - r->p) < n)
        vm_die("文件格式错误：数据截断");
    const uint8_t *q = r->p;
    r->p += n;
    return q;
}

static uint8_t rd_u8(Reader *r) { return take(r, 1)[0]; }

static uint16_t rd_u16(Reader *r)
{
    const uint8_t *q = take(r, 2);
    return (uint16_t)(q[0] | (uint16_t)q[1] << 8);
}

static uint32_t rd_u32(Reader *r)
{
    const uint8_t *q = take(r, 4);
    return (uint32_t)q[0] | (uint32_t)q[1] << 8 | (uint32_t)q[2] << 16 | (uint32_t)q[3] << 24;
}

static uint64_t rd_u64(Reader *r)
{
    const uint8_t *q = take(r, 8);
    uint64_t v = 0;
    for (int i = 7; i >= 0; i--)
        v = v << 8 | q[i];
    return v;
}

/* ================= 模块加载 ================= */

typedef struct {
    uint32_t name_idx;
    uint16_t nparams;
    uint16_t nslots;
    uint32_t code_off;
    uint32_t code_len;
} Fn;

typedef struct {
    Value *consts;
    uint32_t nconsts;
    Fn *fns;
    uint32_t nfns;
    uint32_t code_base;   /* 代码区起点（绝对偏移） */
} Module;

static Module load_module(const uint8_t *img, size_t len)
{
    Module m;
    memset(&m, 0, sizeof m);
    if (len < 16)
        vm_die("文件格式错误：文件太短");
    if (memcmp(img, "PYBC", 4) != 0)
        vm_die("文件格式错误：魔数不是 'PYBC'");
    Reader r = { img + 4, img + len };
    if (rd_u32(&r) != 1)
        vm_die("文件格式错误：只支持版本 1");
    uint32_t n = rd_u32(&r);
    uint32_t f = rd_u32(&r);

    m.nconsts = n;
    m.consts = (Value *)calloc(n ? n : 1, sizeof(Value));
    if (!m.consts)
        vm_die("内存不足");
    for (uint32_t i = 0; i < n; i++) {
        uint8_t tag = rd_u8(&r);
        switch (tag) {
        case 1: {   /* int64 */
            int64_t v = (int64_t)rd_u64(&r);
            m.consts[i] = rt_int(v);
            break;
        }
        case 2: {   /* float64 */
            uint64_t bits = rd_u64(&r);
            double d;
            memcpy(&d, &bits, sizeof d);
            m.consts[i] = rt_float(d);
            break;
        }
        case 3: {   /* 字符串：u32 字节数 + UTF-8 */
            uint32_t blen = rd_u32(&r);
            const uint8_t *bytes = take(&r, blen);
            char *s = (char *)malloc((size_t)blen + 1);
            if (!s)
                vm_die("内存不足");
            memcpy(s, bytes, blen);
            s[blen] = '\0';
            m.consts[i] = rt_str(s);   /* rt_str 自会拷贝进运行时内存 */
            free(s);
            break;
        }
        default:
            vm_die("文件格式错误：未知常量类型 %u", (unsigned)tag);
        }
    }

    if (f == 0)
        vm_die("文件格式错误：函数表为空（缺少主程序）");
    m.nfns = f;
    m.fns = (Fn *)calloc(f, sizeof(Fn));
    if (!m.fns)
        vm_die("内存不足");
    for (uint32_t i = 0; i < f; i++) {
        Fn *fn = &m.fns[i];
        fn->name_idx = rd_u32(&r);
        fn->nparams = rd_u16(&r);
        fn->nslots = rd_u16(&r);
        fn->code_off = rd_u32(&r);
        fn->code_len = rd_u32(&r);
        if (fn->name_idx >= n)
            vm_die("文件格式错误：函数 %u 名字常量索引越界", (unsigned)i);
        if (fn->nparams > fn->nslots)
            vm_die("文件格式错误：函数 %u 槽位数少于参数个数", (unsigned)i);
        if ((uint64_t)fn->code_off + fn->code_len > len)
            vm_die("文件格式错误：函数 %u 代码区间越界", (unsigned)i);
    }
    m.code_base = (uint32_t)(r.p - img);   /* 函数表结束处即代码区起点 */
    return m;
}

/* ================= 虚拟机状态 ================= */

static const uint8_t *g_img;   /* 整个 .pybc 映像（操作数直接从这里读） */
static size_t g_img_len;

/* 操作数栈：初始 4096，满了翻倍 realloc */
static Value *g_stack;
static size_t g_sp, g_cap;

/* 帧栈 */
typedef struct {
    uint32_t ip;       /* 当前指令指针（相对整个映像） */
    uint32_t ret_ip;   /* 返回到的 ip */
    uint32_t fn;       /* 当前函数索引 */
    Value *slots;      /* 槽位数组：参数按序 + 其余 rt_none() 填满 */
} Frame;

static Frame *g_frames;
static size_t g_fp, g_fcap;

/* rt 的显示是行缓冲：SHOW_TEXT/SHOW_VALUE/MAGIC 只追加到当前行，SHOW_END 才输出。
 * VM 记录"有未结束的行"，正常停机时补一次 rt_show_end 把挂起内容刷出来。 */
static int g_line_pending;

static void vm_finish(void)
{
    if (g_line_pending) {
        g_line_pending = 0;
        rt_show_end();
    }
}

static void push(Value v)
{
    if (g_sp == g_cap) {
        g_cap = g_cap ? g_cap * 2 : 4096;
        g_stack = (Value *)realloc(g_stack, g_cap * sizeof(Value));
        if (!g_stack)
            vm_die("内存不足");
    }
    g_stack[g_sp++] = v;
}

static Value pop(void)
{
    if (g_sp == 0)
        vm_die("操作数栈下溢（字节码不平衡）");
    return g_stack[--g_sp];
}

/* ---- 操作数读取（相对整个映像做边界检查） ---- */

static uint8_t rd_ip_u8(uint32_t *ip)
{
    if ((uint64_t)*ip + 1 > g_img_len)
        vm_die("指令流截断");
    return g_img[(*ip)++];
}

static uint16_t rd_ip_u16(uint32_t *ip)
{
    if ((uint64_t)*ip + 2 > g_img_len)
        vm_die("指令流截断");
    uint16_t v = (uint16_t)(g_img[*ip] | (uint16_t)g_img[*ip + 1] << 8);
    *ip += 2;
    return v;
}

static uint32_t rd_ip_u32(uint32_t *ip)
{
    if ((uint64_t)*ip + 4 > g_img_len)
        vm_die("指令流截断");
    uint32_t v = (uint32_t)g_img[*ip] | (uint32_t)g_img[*ip + 1] << 8
               | (uint32_t)g_img[*ip + 2] << 16 | (uint32_t)g_img[*ip + 3] << 24;
    *ip += 4;
    return v;
}

/* ---- 常量/槽位取用（带校验） ---- */

static Value const_at(const Module *m, uint16_t idx)
{
    if (idx >= m->nconsts)
        vm_die("常量索引 %u 越界", (unsigned)idx);
    return m->consts[idx];
}

static const char *str_const(const Module *m, uint16_t idx)
{
    Value v = const_at(m, idx);
    if (!IS_STR(v))
        vm_die("常量 %u 不是字符串", (unsigned)idx);
    return AS_STR(v);
}

static Value *slot_ref(Frame *f, const Fn *fn, uint16_t s)
{
    if (s >= fn->nslots)
        vm_die("槽位索引 %u 越界（函数只有 %u 个槽）", (unsigned)s, (unsigned)fn->nslots);
    return &f->slots[s];
}

/* AROUND_INIT 的次数校验：INT/BOOL 可，FLOAT 须整数值 */
static long long loop_count_of(Value v)
{
    if (IS_INT(v) || IS_BIGINT(v))
        return rt_to_ll(v);
    if (IS_BOOL(v))
        return (long long)AS_BOOL(v);
    if (IS_FLT(v)) {
        double fv = AS_FLT(v);
        if (fv >= -(double)LLONG_MAX && fv <= (double)LLONG_MAX && fv == floor(fv))
            return (long long)fv;
    }
    prog_die("循环次数必须是整数");
    return 0;   /* 不可达 */
}

/* 跳转偏移相对下一条指令处（from = 已读完操作数的 ip）；越界直接报错。
 * 注意：偏移必须先读进局部变量再算目标，禁止 "f->ip + rd_ip_u32(&f->ip)"
 * 这种同一表达式读又改 f->ip 的写法——那是未定义行为。 */
static uint32_t jump_target(const Module *m, const Fn *fn, uint32_t fn_idx, uint32_t from, int32_t off)
{
    uint32_t t = from + (uint32_t)off;   /* 利用无符号回绕实现负偏移 */
    if (t < m->code_base + fn->code_off || t >= (uint64_t)m->code_base + fn->code_off + fn->code_len)
        vm_die("跳转目标越界（函数 %u）", (unsigned)fn_idx);
    return t;
}

/* 二元算术/比较的公共小助手：弹 b 弹 a，压 op(a,b) */
static Value pop2_apply(Value (*op)(Value, Value))
{
    Value b = pop();
    Value a = pop();
    return op(a, b);
}

/* ================= 执行主循环 ================= */

/* ================= 标准库调用（CALL_LIB） ================= */

typedef Value (*LibFn0)(void);
typedef Value (*LibFn1)(Value);
typedef Value (*LibFn2)(Value, Value);
typedef Value (*LibFn3)(Value, Value, Value);
typedef Value (*LibFn4)(Value, Value, Value, Value);
typedef Value (*LibFn5)(Value, Value, Value, Value, Value);
typedef Value (*LibFn6)(Value, Value, Value, Value, Value, Value);
typedef Value (*LibFn7)(Value, Value, Value, Value, Value, Value, Value);
typedef Value (*LibFn8)(Value, Value, Value, Value, Value, Value, Value, Value);

/* 按名字查库调用；找不到返回 NULL */
static void *lib_lookup(const char *name, int *arity_out)
{
    size_t n = sizeof(g_lib_calls) / sizeof(g_lib_calls[0]);
    for (size_t i = 0; i < n; i++) {
        if (strcmp(g_lib_calls[i].name, name) == 0) {
            *arity_out = g_lib_calls[i].arity;
            return g_lib_calls[i].fn;
        }
    }
    return NULL;
}

/* 按 arity 弹实参并调用；返回值压栈。栈上实参按书写序（末参在顶）。 */
static void lib_invoke(const char *name, void *fn, int arity)
{
    Value a0=rt_none(),a1=rt_none(),a2=rt_none(),a3=rt_none();
    Value a4=rt_none(),a5=rt_none(),a6=rt_none(),a7=rt_none();
    if (arity > 8 || arity < 0)
        vm_die("库 %s 的参数个数 %d 不受支持", name, arity);
    if (g_sp < (size_t)arity)
        vm_die("操作数栈下溢（调用库 %s）", name);
    switch (arity) {
    case 8: a7 = pop(); /* fallthrough */
    case 7: a6 = pop(); /* fallthrough */
    case 6: a5 = pop(); /* fallthrough */
    case 5: a4 = pop(); /* fallthrough */
    case 4: a3 = pop(); /* fallthrough */
    case 3: a2 = pop(); /* fallthrough */
    case 2: a1 = pop(); /* fallthrough */
    case 1: a0 = pop(); /* fallthrough */
    case 0: break;
    }
    Value r;
    switch (arity) {
    case 0: r = ((LibFn0)fn)(); break;
    case 1: r = ((LibFn1)fn)(a0); break;
    case 2: r = ((LibFn2)fn)(a0, a1); break;
    case 3: r = ((LibFn3)fn)(a0, a1, a2); break;
    case 4: r = ((LibFn4)fn)(a0, a1, a2, a3); break;
    case 5: r = ((LibFn5)fn)(a0, a1, a2, a3, a4); break;
    case 6: r = ((LibFn6)fn)(a0, a1, a2, a3, a4, a5); break;
    case 7: r = ((LibFn7)fn)(a0, a1, a2, a3, a4, a5, a6); break;
    default: r = ((LibFn8)fn)(a0, a1, a2, a3, a4, a5, a6, a7); break;
    }
    push(r);
}

static void run_module(const uint8_t *img, size_t len)
{
    /* 每次运行都重置虚拟机状态（自测会连续跑多个模块） */
    g_img = img;
    g_img_len = len;
    g_sp = 0;
    g_fp = 0;
    g_line_pending = 0;

    Module m = load_module(img, len);
    if (m.fns[0].nparams != 0)
        vm_die("主程序（函数 0）不能有参数");

    /* 槽位数组：参数按序 + 其余 rt_none() 填充到槽位总数 */
    Frame f0;
    f0.ip = m.code_base + m.fns[0].code_off;
    f0.ret_ip = 0;
    f0.fn = 0;
    f0.slots = (Value *)malloc((m.fns[0].nslots ? m.fns[0].nslots : 1) * sizeof(Value));
    if (!f0.slots)
        vm_die("内存不足");
    for (uint16_t i = 0; i < m.fns[0].nslots; i++)
        f0.slots[i] = rt_none();

    g_fcap = 256;
    g_frames = (Frame *)malloc(g_fcap * sizeof(Frame));
    if (!g_frames)
        vm_die("内存不足");
    g_frames[g_fp++] = f0;

    for (;;) {
        if (g_fp == 0) {
            vm_finish();   /* 主程序 RET/RET_NONE：正常结束 */
            return;
        }

        Frame *f = &g_frames[g_fp - 1];
        const Fn *fn = &m.fns[f->fn];
        if (f->ip < m.code_base + fn->code_off || f->ip >= (uint64_t)m.code_base + fn->code_off + fn->code_len)
            vm_die("程序计数器越界（函数 %u）", (unsigned)f->fn);
        uint8_t op = g_img[f->ip++];
        if (getenv("PYVM_TRACE"))
            fprintf(stderr, "[trace] fn=%u ip=%u op=%02X sp=%zu fp=%zu\n",
                    (unsigned)f->fn, (unsigned)(f->ip - 1), (unsigned)op, g_sp, g_fp);

        switch (op) {
        case 0x00:   /* NOP */
            break;
        case 0x01:   /* HALT：正常退出 */
            vm_finish();
            return;

        case 0x02:   /* CONST u16 */
            push(const_at(&m, rd_ip_u16(&f->ip)));
            break;
        case 0x03:   /* LOAD u16：槽读（已删除报错走 rt_chk） */
            push(rt_chk(*slot_ref(f, fn, rd_ip_u16(&f->ip))));
            break;
        case 0x04: { /* STORE u16：弹出写槽（锁定/删除检查走 rt_assign） */
            uint16_t s = rd_ip_u16(&f->ip);
            Value v = pop();
            rt_assign(slot_ref(f, fn, s), v);
            break;
        }
        case 0x05:   /* DUP */
            if (g_sp == 0)
                vm_die("操作数栈下溢（DUP）");
            push(g_stack[g_sp - 1]);
            break;
        case 0x06:   /* POP */
            (void)pop();
            break;

        case 0x10: push(pop2_apply(rt_add));  break;   /* ADD  */
        case 0x11: push(pop2_apply(rt_sub));  break;   /* SUB  */
        case 0x12: push(pop2_apply(rt_mul));  break;   /* MUL  */
        case 0x13: push(pop2_apply(rt_div));  break;   /* DIV  */
        case 0x14: push(pop2_apply(rt_fdiv)); break;   /* FDIV */
        case 0x15: push(pop2_apply(rt_mod));  break;   /* MOD  */
        case 0x16:   /* NEG */
            push(rt_neg(pop()));
            break;
        case 0x17:   /* NOT */
            push(rt_not(pop()));
            break;

        case 0x18: push(pop2_apply(rt_eq)); break;   /* EQ */
        case 0x19: push(pop2_apply(rt_ne)); break;   /* NE */
        case 0x1A: push(pop2_apply(rt_lt)); break;   /* LT */
        case 0x1B: push(pop2_apply(rt_gt)); break;   /* GT */
        case 0x1C: push(pop2_apply(rt_le)); break;   /* LE */
        case 0x1D: push(pop2_apply(rt_ge)); break;   /* GE */

        case 0x1E: { /* JUMP i32 */
            int32_t off = (int32_t)rd_ip_u32(&f->ip);
            f->ip = jump_target(&m, fn, f->fn, f->ip, off);
            break;
        }
        case 0x1F: { /* JUMP_IF_FALSE i32：弹条件，假跳 */
            int32_t off = (int32_t)rd_ip_u32(&f->ip);
            if (!rt_cond(pop()))
                f->ip = jump_target(&m, fn, f->fn, f->ip, off);
            break;
        }
        case 0x20: { /* JUMP_IF_TRUE i32：弹条件，真跳 */
            int32_t off = (int32_t)rd_ip_u32(&f->ip);
            if (rt_cond(pop()))
                f->ip = jump_target(&m, fn, f->fn, f->ip, off);
            break;
        }

        case 0x21:   /* SHOW_TEXT u16 */
            rt_show_text(str_const(&m, rd_ip_u16(&f->ip)));
            g_line_pending = 1;
            break;
        case 0x22:   /* SHOW_VALUE：弹一显示 */
            (void)rt_show_value(pop());
            g_line_pending = 1;
            break;
        case 0x23:   /* MAGIC u16 */
            rt_magic(str_const(&m, rd_ip_u16(&f->ip)));
            g_line_pending = 1;
            break;
        case 0x24:   /* SHOW_END */
            rt_show_end();
            g_line_pending = 0;
            break;

        case 0x25:   /* LIST_NEW */
            push(rt_list_new());
            break;
        case 0x26: { /* LIST_APPEND：栈 [...,表,值] → [...,表] */
            Value v = pop();
            if (g_sp == 0)
                vm_die("操作数栈下溢（LIST_APPEND）");
            (void)rt_push(&g_stack[g_sp - 1], v);
            break;
        }
        case 0x27:   /* LEN */
            push(rt_len(pop()));
            break;
        case 0x28: { /* INDEX：弹 idx 弹 base，压 rt_index(base, idx) */
            Value idx = pop();
            Value base = pop();
            push(rt_index(base, idx));
            break;
        }
        case 0x29: { /* SETIDX：弹 v 弹 idx 弹 base */
            Value v = pop();
            Value idx = pop();
            Value base = pop();
            rt_setindex(&base, idx, v);
            break;
        }

        case 0x2A:   /* INPUT u16 */
            push(rt_input(str_const(&m, rd_ip_u16(&f->ip))));
            break;

        case 0x2D:   /* DICT_NEW：压空字典 */
            push(rt_dict_new());
            break;
        case 0x2E: { /* DICT_SET：栈 [...,字典,键,值] → [...,字典] */
            Value v = pop();
            Value k = pop();
            if (g_sp == 0)
                vm_die("操作数栈下溢（DICT_SET）");
            (void)rt_dict_set(&g_stack[g_sp - 1], k, v);
            break;
        }

        case 0x2B: { /* AROUND_INIT u16 u16（at槽,次数槽）：弹次数校验整数 */
            uint16_t at = rd_ip_u16(&f->ip);
            uint16_t cnt = rd_ip_u16(&f->ip);
            long long count = loop_count_of(pop());
            (void)slot_ref(f, fn, at);   /* 越界校验 */
            (void)slot_ref(f, fn, cnt);
            f->slots[at] = rt_int(0);
            f->slots[cnt] = rt_int(count);
            break;
        }
        case 0x2C: { /* AROUND_STEP u16 u16 i32（at槽,次数槽,回跳） */
            uint16_t at = rd_ip_u16(&f->ip);
            uint16_t cnt = rd_ip_u16(&f->ip);
            int32_t off = (int32_t)rd_ip_u32(&f->ip);
            Value *at_s = slot_ref(f, fn, at);
            Value *cnt_s = slot_ref(f, fn, cnt);
            if (!(IS_INT(*at_s) || IS_BIGINT(*at_s)) || !(IS_INT(*cnt_s) || IS_BIGINT(*cnt_s)))
                vm_die("AROUND 槽被非整数破坏");
            long long next = rt_to_ll(*at_s) + 1;
            *at_s = rt_int(next);
            if (next < rt_to_ll(*cnt_s))
                f->ip = jump_target(&m, fn, f->fn, f->ip, off);
            break;
        }

        case 0x30: { /* CALL u16 u8（函数索引, 参数个数）：实参按书写序压栈 */
            uint16_t fni = rd_ip_u16(&f->ip);
            uint8_t nargs = rd_ip_u8(&f->ip);
            if (fni >= m.nfns)
                vm_die("函数索引 %u 越界", (unsigned)fni);
            const Fn *callee = &m.fns[fni];
            if (nargs != callee->nparams)
                vm_die("函数 %u 需要 %u 个参数，实际 %u 个",
                       (unsigned)fni, (unsigned)callee->nparams, (unsigned)nargs);
            uint32_t ret_ip = f->ip;
            Value *slots = (Value *)malloc((callee->nslots ? callee->nslots : 1) * sizeof(Value));
            if (!slots)
                vm_die("内存不足");
            for (uint16_t i = nargs; i > 0; i--)
                slots[i - 1] = pop();          /* 栈顶是最后一个参数 */
            for (uint16_t i = nargs; i < callee->nslots; i++)
                slots[i] = rt_none();
            if (g_fp == g_fcap) {
                g_fcap *= 2;
                g_frames = (Frame *)realloc(g_frames, g_fcap * sizeof(Frame));
                if (!g_frames)
                    vm_die("内存不足");
            }
            Frame nf;
            nf.ip = m.code_base + callee->code_off;
            nf.ret_ip = ret_ip;
            nf.fn = fni;
            nf.slots = slots;
            g_frames[g_fp++] = nf;
            break;
        }
        case 0x31: { /* RET：弹返回值回调用方 */
            Value rv = pop();
            free(f->slots);
            g_fp--;
            if (g_fp == 0) {
                vm_finish();   /* 主程序返回：正常结束 */
                return;
            }
            push(rv);
            break;
        }
        case 0x32: { /* RET_NONE */
            free(f->slots);
            g_fp--;
            if (g_fp == 0) {
                vm_finish();
                return;
            }
            push(rt_none());
            break;
        }

        case 0x33:   /* GOLD u16：锁定槽（锁记在槽地址侧表，rt_gold 写） */
            rt_gold(slot_ref(f, fn, rd_ip_u16(&f->ip)));
            break;
        case 0x34:   /* DEL u16：删除变量（@self 模式真释放内存） */
            rt_destroy(slot_ref(f, fn, rd_ip_u16(&f->ip)));
            break;

        case 0x35:   /* SETMEM u8：内存管理模式（0=自动 1=手动） */
            rt_set_memmode((int)g_img[f->ip++]);
            break;

        case 0x36: { /* CALL_LIB u16 u8（库名常量索引, 参数个数） */
            uint16_t namei = rd_ip_u16(&f->ip);
            uint8_t nargs = rd_ip_u8(&f->ip);
            const char *name = str_const(&m, namei);
            int arity = 0;
            void *fn = lib_lookup(name, &arity);
            if (!fn)
                vm_die("标准库 %s 在 VM 模式下不可用", name);
            if ((int)nargs != arity)
                vm_die("标准库 %s 需要 %d 个参数，实际 %u 个", name, arity, (unsigned)nargs);
            lib_invoke(name, fn, arity);
            break;
        }

        default:
            vm_die("未知指令 0x%02X（ip=%u，函数 %u）",
                   (unsigned)op, (unsigned)f->ip, (unsigned)f->fn);
        }
    }
}

/* ================= 命令行 / 自测 ================= */

#ifndef PYVM_SELF_TEST

int main(int argc, char **argv)
{
    if (argc != 2) {
        fprintf(stderr, "用法: pyvm.exe 文件.pybc\n");
        return 2;
    }
    size_t len = 0;
    uint8_t *img = read_file(argv[1], &len);
    if (!img) {
        fprintf(stderr, "虚拟机错误: 无法读取文件 %s\n", argv[1]);
        return 1;
    }
    run_module(img, len);
    return 0;
}

#else /* PYVM_SELF_TEST */

#include <unistd.h>   /* dup / dup2 / close：捕获 stdout 做字节级核对 */

/* ---- 字节码拼装小工具 ---- */

typedef struct {
    uint8_t *b;
    size_t len, cap;
} Buf;

static void emit(Buf *b, const void *data, size_t n)
{
    if (b->len + n > b->cap) {
        b->cap = b->cap ? b->cap : 256;
        while (b->len + n > b->cap)
            b->cap *= 2;
        b->b = (uint8_t *)realloc(b->b, b->cap);
    }
    memcpy(b->b + b->len, data, n);
    b->len += n;
}

static void eu8(Buf *b, unsigned v)  { emit(b, &(uint8_t){(uint8_t)v}, 1); }
static void eu16(Buf *b, unsigned v) { uint8_t q[2] = { (uint8_t)v, (uint8_t)(v >> 8) }; emit(b, q, 2); }
static void eu32(Buf *b, uint32_t v) { uint8_t q[4] = { (uint8_t)v, (uint8_t)(v >> 8), (uint8_t)(v >> 16), (uint8_t)(v >> 24) }; emit(b, q, 4); }
static void ei64(Buf *b, long long v)
{
    uint64_t u = (uint64_t)v;
    for (int i = 0; i < 8; i++)
        eu8(b, (unsigned)(u >> (8 * i) & 0xFF));
}
static void estr(Buf *b, const char *s)
{
    size_t n = strlen(s);
    eu32(b, (uint32_t)n);
    emit(b, s, n);
}

/* 指令速记 */
static void op0(Buf *b, unsigned code)                       { eu8(b, code); }
static void op_u16(Buf *b, unsigned code, unsigned a)        { eu8(b, code); eu16(b, a); }
static void op2_u16(Buf *b, unsigned code, unsigned a, unsigned c) { eu8(b, code); eu16(b, a); eu16(b, c); }

/* 常量池项 */
static void c_int(Buf *b, long long v)   { eu8(b, 1); ei64(b, v); }
static void c_str(Buf *b, const char *s) { eu8(b, 3); estr(b, s); }

/* 函数表项 */
static void fnent(Buf *b, uint32_t name, unsigned params, unsigned slots, uint32_t off, uint32_t clen)
{
    eu32(b, name);
    eu16(b, params);
    eu16(b, slots);
    eu32(b, off);
    eu32(b, clen);
}

/* ---- 模块 1（合同要求的自测）：常量 40 和 2；CONST 0, CONST 1, ADD, SHOW_VALUE, HALT ---- */

static Buf build_module1(void)
{
    Buf b = { 0 };
    Buf code = { 0 };
    op_u16(&code, 0x02, 0);   /* CONST 常量池[0] (40) */
    op_u16(&code, 0x02, 1);   /* CONST 常量池[1] (2)  */
    op0(&code, 0x10);         /* ADD（0x10） */
    op0(&code, 0x22);         /* SHOW_VALUE */
    op0(&code, 0x01);         /* HALT */

    emit(&b, "PYBC", 4);
    eu32(&b, 1);              /* 版本 */
    eu32(&b, 2);              /* 常量数 */
    eu32(&b, 1);              /* 函数数 */
    c_int(&b, 40);
    c_int(&b, 2);
    fnent(&b, 0, 0, 0, 0, (uint32_t)code.len);   /* 代码偏移相对代码区起点；名字索引指向整数常量，执行不使用 */
    emit(&b, code.b, code.len);
    free(code.b);
    return b;
}

/* ---- 模块 2：列表 + 循环 + 函数调用 综合 ----
 * main（槽 0=at, 1=次数, 2=表）：
 *   list=[7,8,9]; show(len(list))        → 3
 *   show(list[0])                        → 7
 *   list[2]=99; show(list[2])            → 99
 *   循环 3 圈 show(at)                    → 0 1 2
 *   show(double(21))                     → 42
 *   show_text("end")                     → end
 * double(n): return n + n
 */
static Buf build_module2(void)
{
    Buf b = { 0 };
    Buf main_c = { 0 }, dbl_c = { 0 };

    /* double：LOAD 0; LOAD 0; ADD; RET */
    op_u16(&dbl_c, 0x03, 0);
    op_u16(&dbl_c, 0x03, 0);
    op0(&dbl_c, 0x10);
    op0(&dbl_c, 0x31);

    /* main */
    op0(&main_c, 0x25);                        /* LIST_NEW */
    op_u16(&main_c, 0x02, 3); op0(&main_c, 0x26);   /* 7 入表 */
    op_u16(&main_c, 0x02, 4); op0(&main_c, 0x26);   /* 8 入表 */
    op_u16(&main_c, 0x02, 5); op0(&main_c, 0x26);   /* 9 入表 */
    op_u16(&main_c, 0x04, 2);                  /* STORE 2（表） */
    op_u16(&main_c, 0x03, 2); op0(&main_c, 0x27);   /* LEN */
    op0(&main_c, 0x22); op0(&main_c, 0x24);    /* SHOW_VALUE, SHOW_END → 3 */
    op_u16(&main_c, 0x03, 2);                  /* LOAD 2 */
    op_u16(&main_c, 0x02, 0);                  /* CONST 0（int 0） */
    op0(&main_c, 0x28);                        /* INDEX */
    op0(&main_c, 0x22); op0(&main_c, 0x24);    /* → 7 */
    op_u16(&main_c, 0x03, 2);                  /* LOAD 2 */
    op_u16(&main_c, 0x02, 6);                  /* CONST 6（int 2） */
    op_u16(&main_c, 0x02, 7);                  /* CONST 7（int 99） */
    op0(&main_c, 0x29);                        /* SETIDX：list[2]=99 */
    op_u16(&main_c, 0x03, 2);                  /* LOAD 2 */
    op_u16(&main_c, 0x02, 6);                  /* CONST 6 */
    op0(&main_c, 0x28);                        /* INDEX */
    op0(&main_c, 0x22); op0(&main_c, 0x24);    /* → 99 */

    op_u16(&main_c, 0x02, 1);                  /* CONST 1（int 3，循环次数） */
    op2_u16(&main_c, 0x2B, 0, 1);              /* AROUND_INIT at=0 次数=1 */
    uint32_t loop_start = (uint32_t)main_c.len;
    op_u16(&main_c, 0x03, 0);                  /* LOAD 0（at） */
    op0(&main_c, 0x22); op0(&main_c, 0x24);    /* show 0/1/2 */
    eu8(&main_c, 0x2C); eu16(&main_c, 0); eu16(&main_c, 1);
    eu32(&main_c, loop_start - (main_c.len + 4));   /* AROUND_STEP 回跳循环头 */

    op_u16(&main_c, 0x02, 2);                  /* CONST 2（int 21） */
    eu8(&main_c, 0x30); eu16(&main_c, 1); eu8(&main_c, 1);   /* CALL double 1参 */
    op0(&main_c, 0x22); op0(&main_c, 0x24);    /* → 42 */
    op_u16(&main_c, 0x02, 8);                  /* CONST 8（"end"） */
    op_u16(&main_c, 0x21, 8);                  /* SHOW_TEXT */
    op0(&main_c, 0x24);                        /* SHOW_END */
    op0(&main_c, 0x32);                        /* RET_NONE */

    emit(&b, "PYBC", 4);
    eu32(&b, 1);
    eu32(&b, 9);                 /* 常量数：0,3,21,7,8,9,2,99,"end" */
    eu32(&b, 2);                 /* 函数数 */
    c_int(&b, 0);
    c_int(&b, 3);
    c_int(&b, 21);
    c_int(&b, 7);
    c_int(&b, 8);
    c_int(&b, 9);
    c_int(&b, 2);
    c_int(&b, 99);
    c_str(&b, "end");
    /* 代码偏移相对代码区起点：fn0 从 0 开始，fn1 紧随 fn0 */
    fnent(&b, 0, 0, 4, 0, (uint32_t)main_c.len);
    fnent(&b, 0, 1, 1, (uint32_t)main_c.len, (uint32_t)dbl_c.len);
    emit(&b, main_c.b, main_c.len);
    emit(&b, dbl_c.b, dbl_c.len);
    free(main_c.b);
    free(dbl_c.b);
    return b;
}

/* ---- 模块 3：GOLD 后再赋值 → 运行时错误: 变量已锁定 ---- */
static Buf build_module3(void)
{
    Buf b = { 0 };
    Buf code = { 0 };
    op_u16(&code, 0x02, 0);   /* CONST 0（int 1） */
    op_u16(&code, 0x04, 0);   /* STORE 0 */
    op_u16(&code, 0x33, 0);   /* GOLD 0 */
    op_u16(&code, 0x02, 0);   /* CONST 0 */
    op_u16(&code, 0x04, 0);   /* STORE 0 → 报错退出 */
    emit(&b, "PYBC", 4);
    eu32(&b, 1); eu32(&b, 1); eu32(&b, 1);
    c_int(&b, 1);
    fnent(&b, 0, 0, 1, 0, (uint32_t)code.len);   /* 代码偏移相对代码区起点 */
    emit(&b, code.b, code.len);
    free(code.b);
    return b;
}

/* ---- 模块 4：DEL 后再读 → 运行时错误: 用已删除变量 ---- */
static Buf build_module4(void)
{
    Buf b = { 0 };
    Buf code = { 0 };
    op_u16(&code, 0x02, 0);   /* CONST 0 */
    op_u16(&code, 0x04, 0);   /* STORE 0 */
    op_u16(&code, 0x34, 0);   /* DEL 0 */
    op_u16(&code, 0x03, 0);   /* LOAD 0 → 报错退出 */
    emit(&b, "PYBC", 4);
    eu32(&b, 1); eu32(&b, 1); eu32(&b, 1);
    c_int(&b, 1);
    fnent(&b, 0, 0, 1, 0, (uint32_t)code.len);   /* 代码偏移相对代码区起点 */
    emit(&b, code.b, code.len);
    free(code.b);
    return b;
}

/* ---- stdout 捕获 ---- */

static FILE *s_tmp;
static int s_saved_fd;

static void capture_start(void)
{
    fflush(stdout);
    s_saved_fd = dup(1);
    s_tmp = tmpfile();
    dup2(fileno(s_tmp), 1);
}

static void capture_finish(char *buf, size_t cap)
{
    fflush(stdout);
    dup2(s_saved_fd, 1);
    close(s_saved_fd);
    rewind(s_tmp);
    size_t n = fread(buf, 1, cap - 1, s_tmp);
    buf[n] = '\0';
    fclose(s_tmp);
}

static int g_fails = 0;

static void check(int cond, const char *name)
{
    if (cond)
        printf("[通过] %s\n", name);
    else {
        printf("[失败] %s\n", name);
        g_fails++;
    }
}

/* Windows 文本模式 stdout 会把 \n 写成 \r\n；比对前把 \r 去掉，期望串里只写 \n */
static void strip_cr(char *s)
{
    char *w = s, *r = s;
    while (*r) {
        if (*r != '\r')
            *w++ = *r;
        r++;
    }
    *w = '\0';
}

/* 报错分支验证：拉起自身 "child N"，确认退出码 1 */
static void expect_die(const char *argv0, const char *kase, const char *name)
{
    char exe[512], cmd[1100];
    snprintf(exe, sizeof exe, "%s", (argv0 && *argv0) ? argv0 : "pyvm_test");
    for (char *p = exe; *p; p++)
        if (*p == '/')
            *p = '\\';   /* system() 走 cmd.exe，需要 Windows 路径分隔符 */
    snprintf(cmd, sizeof cmd, "\"%s\" %s", exe, kase);
    fflush(stdout);
    fflush(stderr);
    int rc = system(cmd);
    if (rc == 1)
        printf("[通过] %s\n", name);
    else {
        printf("[失败] %s（退出码 %d，预期 1）\n", name, rc);
        g_fails++;
    }
}

static void run_buf(const Buf *b) { run_module(b->b, b->len); }

int main(int argc, char **argv)
{
    Buf m1 = build_module1();
    Buf m2 = build_module2();
    Buf m3 = build_module3();
    Buf m4 = build_module4();

    /* 子进程模式：跑指定模块，必然报错 exit(1) */
    if (argc > 1 && strcmp(argv[1], "child") == 0 && argc > 2) {
        if (strcmp(argv[2], "3") == 0)
            run_buf(&m3);
        else if (strcmp(argv[2], "4") == 0)
            run_buf(&m4);
        printf("子进程没有触发错误！\n");
        return 3;
    }
    /* dump 模式：把样例模块写成 .pybc，供命令行版 pyvm.exe 实测 */
    if (argc > 1 && strcmp(argv[1], "dump") == 0) {
        struct { const char *name; const Buf *b; } out[] = {
            { "test42.pybc", &m1 }, { "test_full.pybc", &m2 },
            { "test_locked.pybc", &m3 }, { "test_del.pybc", &m4 },
        };
        for (size_t i = 0; i < sizeof out / sizeof out[0]; i++) {
            FILE *fp = fopen(out[i].name, "wb");
            if (!fp) {
                fprintf(stderr, "写 %s 失败\n", out[i].name);
                return 1;
            }
            fwrite(out[i].b->b, 1, out[i].b->len, fp);
            fclose(fp);
            printf("写出 %s（%zu 字节）\n", out[i].name, out[i].b->len);
        }
        return 0;
    }
    /* 文件模式：自测构建同样可以直接跑 .pybc 文件 */
    if (argc > 1) {
        size_t len = 0;
        uint8_t *img = read_file(argv[1], &len);
        if (!img) {
            fprintf(stderr, "虚拟机错误: 无法读取文件 %s\n", argv[1]);
            return 1;
        }
        run_module(img, len);
        return 0;
    }

    /* ---- 合同要求的最小自测：应打印 42 ---- */
    {
        char got[64];
        capture_start();
        run_buf(&m1);
        capture_finish(got, sizeof got);
        strip_cr(got);
        /* 本行未用过 magic，rt_show_end 不发 \033[0m 重置序列 */
        check(strcmp(got, "42\n") == 0,
              "模块1：CONST/CONST/ADD/SHOW_VALUE/HALT 打印 42（VM 停机时刷出挂起行）");
    }

    /* ---- 综合：列表 + 循环 + 调用 ---- */
    {
        char got[512];
        capture_start();
        run_buf(&m2);
        capture_finish(got, sizeof got);
        strip_cr(got);
        const char *want = "3\n"
                           "7\n"
                           "99\n"
                           "0\n"
                           "1\n"
                           "2\n"
                           "42\n"
                           "end\n";
        check(strcmp(got, want) == 0, "模块2：列表/LEN/INDEX/SETIDX/循环/调用/文本");
    }

    /* ---- 报错分支（子进程，stderr 出现对应"运行时错误: ..."） ---- */
    expect_die(argv[0], "child 3", "模块3：GOLD 后赋值 → 变量已锁定");
    expect_die(argv[0], "child 4", "模块4：DEL 后读取 → 用已删除变量");

    if (g_fails == 0)
        printf("自测全部通过。\n");
    else
        printf("自测失败 %d 项。\n", g_fails);
    return g_fails ? 1 : 0;
}

#endif /* PYVM_SELF_TEST */
