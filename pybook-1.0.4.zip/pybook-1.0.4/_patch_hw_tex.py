# -*- coding: utf-8 -*-
"""pybook_hw3d.c：加 贴图(hw.tex/texuse/uv) + 父子层级(hw.push/pop) + op 命令流。
每处断言 count==1，全部在内存里顺序替换，最后一次写回。"""
import io, sys

P = 'C:/Users/zhuli/Desktop/pybook/pybook_hw3d.c'
s = io.open(P, encoding='utf-8').read()
PATCHES = []

def add(label, old, new):
    PATCHES.append((label, old, new))

# ============ 1) 头文件 ============
add('include', """/* 只取声明：stbtt_* 的实现由 pybook_rt.c 提供（全局符号，直接链接） */
#include "stb_truetype.h"
""", """/* 只取声明：stbtt_* 的实现由 pybook_rt.c 提供（全局符号，直接链接） */
#include "stb_truetype.h"
/* 同理：stbi_* 的实现也在 pybook_rt.c（"游戏.图"那套），这里只要声明。
   所以 hw.tex 能加载 png/jpg/bmp/tga，且零新增依赖。 */
#include "stb_image.h"

#include <windows.h>            /* MultiByteToWideChar：中文路径转 UTF-16 */
""")

# ============ 2) 文件头接口说明 ============
add('head-comment',
""" *   hw.fog(起,止)  hw.far(距离)  hw.fov(角度)  hw.near(距离)  hw.wire(0/1)""",
""" *   hw.tex(槽,路径)  hw.texuse(槽)  hw.uv(重复)        贴图
 *   hw.push(x,y,z, 绕x,绕y,绕z)  hw.pop()              父子层级
 *   hw.fog(起,止)  hw.far(距离)  hw.fov(角度)  hw.near(距离)  hw.wire(0/1)""")

# ============ 3) 贴图槽 + HwBox 加 tex/uv ============
add('structs-box', """/* 场景表 */
#define HW_BOX_MAX 16384
typedef struct {
    float x, y, z, w, h, d;
    unsigned char r, g, b;
    float rx, ry, rz;      /* 绕自身中心的旋转（弧度，度序 XYZ）—— 0 即不转 */
} HwBox;""",
"""/* 贴图槽：hw.tex(槽,路径) 加载，hw.texuse(槽) 选择。槽 0 表示不用贴图。
   每张图上传成 GL 纹理；hw.uv(重复) 靠 GL_REPEAT 平铺。
   光照不用额外处理：GL_MODULATE 让顶点色（已含方向光）直接乘在贴图上。 */
#define HW_TEX_SLOTS 8
static GLuint g_texs[HW_TEX_SLOTS];
static int    g_texw[HW_TEX_SLOTS], g_texh[HW_TEX_SLOTS];
static int    g_curtex = 0;      /* 当前贴图槽（提交图元时记进图元里） */
static float  g_curuv  = 1.0f;   /* 当前 UV 重复次数 */

/* 场景表 */
#define HW_BOX_MAX 16384
typedef struct {
    float x, y, z, w, h, d;
    unsigned char r, g, b;
    float rx, ry, rz;      /* 绕自身中心的旋转（弧度，度序 XYZ）—— 0 即不转 */
    int   tex;             /* 贴图槽（0 = 纯色） */
    float uv;              /* UV 重复次数 */
} HwBox;""")

add('structs-sphere', """typedef struct {
    float x, y, z, rad;
    unsigned char r, g, b;
} HwSphere;""",
"""typedef struct {
    float x, y, z, rad;
    unsigned char r, g, b;
    int   tex;
    float uv;
} HwSphere;""")

add('structs-cyl', """typedef struct {
    float x, y, z, rb, h, rt;
    int   seg;
    unsigned char r, g, b;
} HwCyl;""",
"""typedef struct {
    float x, y, z, rb, h, rt;
    int   seg;
    unsigned char r, g, b;
    int   tex;
    float uv;
} HwCyl;""")

# ============ 4) op 命令流 ============
add('opstream', """static HwCyl  g_cyls[HW_CYL_MAX];
static int    g_ncyls = 0;
""",
"""static HwCyl  g_cyls[HW_CYL_MAX];
static int    g_ncyls = 0;

/* ---- 命令流（op stream）----
   图元不再"按类型分批画"，而是按脚本提交的顺序画。
   这是父子层级的前提：push/pop 只有在顺序执行时才有语义。
   每个 op 只记「类型 + 数据下标」，数据本体仍在上面那些数组里。 */
enum { OP_BOX = 0, OP_SPHERE, OP_CYL, OP_LINE, OP_PUSH, OP_POP };
#define HW_OP_MAX 65536
typedef struct {
    int   type;
    int   idx;                  /* 数据数组下标（PUSH/POP 不用） */
    float px, py, pz;           /* PUSH：平移 */
    float rx, ry, rz;           /* PUSH：旋转（弧度） */
} HwOp;

static HwOp  g_ops[HW_OP_MAX];
static int   g_nops = 0;
static int   g_depth = 0;       /* push 深度（防 glPopMatrix 打空栈） */
#define HW_MAX_DEPTH 20

/* 追加一个"无变换参数"的 op */
static void hw_op(int type, int idx)
{
    if (g_nops >= HW_OP_MAX)
        hw_die("hw：单帧图元/变换数超过上限 %d", HW_OP_MAX);
    HwOp *o = &g_ops[g_nops++];
    o->type = type;
    o->idx  = idx;
    o->px = o->py = o->pz = 0.0f;
    o->rx = o->ry = o->rz = 0.0f;
}
""")

# ============ 5) boxn 记贴图 + op ============
add('boxn', """    b->rx = (nargs >= 12) ? (float)hw_num(av[9],  "hw.box 的绕X") : 0.0f;
    b->ry = (nargs >= 12) ? (float)hw_num(av[10], "hw.box 的绕Y") : 0.0f;
    b->rz = (nargs >= 12) ? (float)hw_num(av[11], "hw.box 的绕Z") : 0.0f;
    return rt_none();
}""",
"""    b->rx = (nargs >= 12) ? (float)hw_num(av[9],  "hw.box 的绕X") : 0.0f;
    b->ry = (nargs >= 12) ? (float)hw_num(av[10], "hw.box 的绕Y") : 0.0f;
    b->rz = (nargs >= 12) ? (float)hw_num(av[11], "hw.box 的绕Z") : 0.0f;
    /* 贴图取"提交时刻"的状态：之后改 hw.texuse 不影响已提交的图元 */
    b->tex = g_curtex;
    b->uv  = g_curuv;
    hw_op(OP_BOX, g_nboxes - 1);
    return rt_none();
}""")

# ============ 6) draw_box 六面补 UV ============
add('drawbox-faces', """    /* 六个面各算一次光照（法线固定为 ±X/±Y/±Z）。
       颜色用 clamp 防爆白。 */
    float k;
    glBegin(GL_QUADS);
    /* 顶 (+Y) */
    k = lit(0.0f, 1.0f, 0.0f);
    glColor3f(r * k > 1 ? 1 : r * k, g * k > 1 ? 1 : g * k, bl * k > 1 ? 1 : bl * k);
    glVertex3f(x0, y1, z0); glVertex3f(x0, y1, z1);
    glVertex3f(x1, y1, z1); glVertex3f(x1, y1, z0);
    /* 底 (-Y) */
    k = lit(0.0f, -1.0f, 0.0f);
    glColor3f(r * k > 1 ? 1 : r * k, g * k > 1 ? 1 : g * k, bl * k > 1 ? 1 : bl * k);
    glVertex3f(x0, y0, z0); glVertex3f(x1, y0, z0);
    glVertex3f(x1, y0, z1); glVertex3f(x0, y0, z1);
    /* 前 (-Z) */
    k = lit(0.0f, 0.0f, -1.0f);
    glColor3f(r * k > 1 ? 1 : r * k, g * k > 1 ? 1 : g * k, bl * k > 1 ? 1 : bl * k);
    glVertex3f(x0, y0, z0); glVertex3f(x0, y1, z0);
    glVertex3f(x1, y1, z0); glVertex3f(x1, y0, z0);
    /* 后 (+Z) */
    k = lit(0.0f, 0.0f, 1.0f);
    glColor3f(r * k > 1 ? 1 : r * k, g * k > 1 ? 1 : g * k, bl * k > 1 ? 1 : bl * k);
    glVertex3f(x0, y0, z1); glVertex3f(x1, y0, z1);
    glVertex3f(x1, y1, z1); glVertex3f(x0, y1, z1);
    /* 左 (-X) */
    k = lit(-1.0f, 0.0f, 0.0f);
    glColor3f(r * k > 1 ? 1 : r * k, g * k > 1 ? 1 : g * k, bl * k > 1 ? 1 : bl * k);
    glVertex3f(x0, y0, z0); glVertex3f(x0, y0, z1);
    glVertex3f(x0, y1, z1); glVertex3f(x0, y1, z0);
    /* 右 (+X) */
    k = lit(1.0f, 0.0f, 0.0f);
    glColor3f(r * k > 1 ? 1 : r * k, g * k > 1 ? 1 : g * k, bl * k > 1 ? 1 : bl * k);
    glVertex3f(x1, y0, z0); glVertex3f(x1, y1, z0);
    glVertex3f(x1, y1, z1); glVertex3f(x1, y0, z1);
    glEnd();""",
"""    /* 六个面各算一次光照（法线固定为 ±X/±Y/±Z）。颜色用 clamp 防爆白。
       每个面发 (0,0)->(U,U) 的 UV：hw.uv(1) 是整张铺满一面，
       hw.uv(3) 就是 3x3 平铺（靠 GL_REPEAT）。
       GL_MODULATE 下顶点色会乘上贴图，所以"方向光 x 贴图"自动成立。 */
    float U = b->uv > 0.0f ? b->uv : 1.0f;
    float k;
    glBegin(GL_QUADS);
    /* 顶 (+Y) */
    k = lit(0.0f, 1.0f, 0.0f);
    glColor3f(r * k > 1 ? 1 : r * k, g * k > 1 ? 1 : g * k, bl * k > 1 ? 1 : bl * k);
    glTexCoord2f(0, 0); glVertex3f(x0, y1, z0);
    glTexCoord2f(0, U); glVertex3f(x0, y1, z1);
    glTexCoord2f(U, U); glVertex3f(x1, y1, z1);
    glTexCoord2f(U, 0); glVertex3f(x1, y1, z0);
    /* 底 (-Y) */
    k = lit(0.0f, -1.0f, 0.0f);
    glColor3f(r * k > 1 ? 1 : r * k, g * k > 1 ? 1 : g * k, bl * k > 1 ? 1 : bl * k);
    glTexCoord2f(0, 0); glVertex3f(x0, y0, z0);
    glTexCoord2f(U, 0); glVertex3f(x1, y0, z0);
    glTexCoord2f(U, U); glVertex3f(x1, y0, z1);
    glTexCoord2f(0, U); glVertex3f(x0, y0, z1);
    /* 前 (-Z) */
    k = lit(0.0f, 0.0f, -1.0f);
    glColor3f(r * k > 1 ? 1 : r * k, g * k > 1 ? 1 : g * k, bl * k > 1 ? 1 : bl * k);
    glTexCoord2f(0, 0); glVertex3f(x0, y0, z0);
    glTexCoord2f(0, U); glVertex3f(x0, y1, z0);
    glTexCoord2f(U, U); glVertex3f(x1, y1, z0);
    glTexCoord2f(U, 0); glVertex3f(x1, y0, z0);
    /* 后 (+Z) */
    k = lit(0.0f, 0.0f, 1.0f);
    glColor3f(r * k > 1 ? 1 : r * k, g * k > 1 ? 1 : g * k, bl * k > 1 ? 1 : bl * k);
    glTexCoord2f(0, 0); glVertex3f(x0, y0, z1);
    glTexCoord2f(U, 0); glVertex3f(x1, y0, z1);
    glTexCoord2f(U, U); glVertex3f(x1, y1, z1);
    glTexCoord2f(0, U); glVertex3f(x0, y1, z1);
    /* 左 (-X) */
    k = lit(-1.0f, 0.0f, 0.0f);
    glColor3f(r * k > 1 ? 1 : r * k, g * k > 1 ? 1 : g * k, bl * k > 1 ? 1 : bl * k);
    glTexCoord2f(0, 0); glVertex3f(x0, y0, z0);
    glTexCoord2f(U, 0); glVertex3f(x0, y0, z1);
    glTexCoord2f(U, U); glVertex3f(x0, y1, z1);
    glTexCoord2f(0, U); glVertex3f(x0, y1, z0);
    /* 右 (+X) */
    k = lit(1.0f, 0.0f, 0.0f);
    glColor3f(r * k > 1 ? 1 : r * k, g * k > 1 ? 1 : g * k, bl * k > 1 ? 1 : bl * k);
    glTexCoord2f(0, 0); glVertex3f(x1, y0, z0);
    glTexCoord2f(0, U); glVertex3f(x1, y1, z0);
    glTexCoord2f(U, U); glVertex3f(x1, y1, z1);
    glTexCoord2f(U, 0); glVertex3f(x1, y0, z1);
    glEnd();""")

# ============ 7) draw_lines 换成 hw_bind_tex ============
add('bindtex', """/* 画场景里所有线段（hw.line 攒的） */
static void draw_lines(void)
{
    if (g_nlines == 0)
        return;
    glBegin(GL_LINES);
    for (int i = 0; i < g_nlines; i++) {
        const HwLine *l = &g_lines[i];
        glColor3f(l->r / 255.0f, l->g / 255.0f, l->b / 255.0f);
        glVertex3f(l->x1, l->y1, l->z1);
        glVertex3f(l->x2, l->y2, l->z2);
    }
    glEnd();
}""",
"""/* 绑定当前图元的贴图槽；槽 0 或未加载则关掉贴图（回到纯色）。
   顶点色仍由 lit() 给出，GL_MODULATE 负责把两者乘起来。 */
static void hw_bind_tex(int slot)
{
    if (slot > 0 && slot < HW_TEX_SLOTS && g_texs[slot] != 0) {
        glEnable(GL_TEXTURE_2D);
        glBindTexture(GL_TEXTURE_2D, g_texs[slot]);
    } else {
        glDisable(GL_TEXTURE_2D);
    }
}""")

# ============ 8) 球：UV ============
add('sphere-uv', """    float lr = s->r / 255.0f, lg = s->g / 255.0f, lb = s->b / 255.0f;

    for (int i = 0; i < RING; i++) {
        double p0 = 3.14159265358979 * (double)i / (double)RING;
        double p1 = 3.14159265358979 * (double)(i + 1) / (double)RING;
        float sy0 = (float)sin(p0), cy0 = (float)cos(p0);
        float sy1 = (float)sin(p1), cy1 = (float)cos(p1);
        glBegin(GL_TRIANGLE_STRIP);
        for (int j = 0; j <= SEG; j++) {
            float nx, ny, nz;
            /* 上环：纬线 RING 段的第 i 片 */
            nx = sy0 * sr->c[j]; ny = cy0; nz = sy0 * sr->s[j];
            set_lit_color(lr, lg, lb, nx, ny, nz);
            glVertex3f(s->x + s->rad * nx, s->y + s->rad * ny, s->z + s->rad * nz);
            /* 下环 */
            nx = sy1 * sr->c[j]; ny = cy1; nz = sy1 * sr->s[j];
            set_lit_color(lr, lg, lb, nx, ny, nz);
            glVertex3f(s->x + s->rad * nx, s->y + s->rad * ny, s->z + s->rad * nz);
        }
        glEnd();
    }
}""",
"""    float lr = s->r / 255.0f, lg = s->g / 255.0f, lb = s->b / 255.0f;
    float U = s->uv > 0.0f ? s->uv : 1.0f;

    for (int i = 0; i < RING; i++) {
        double p0 = 3.14159265358979 * (double)i / (double)RING;
        double p1 = 3.14159265358979 * (double)(i + 1) / (double)RING;
        float sy0 = (float)sin(p0), cy0 = (float)cos(p0);
        float sy1 = (float)sin(p1), cy1 = (float)cos(p1);
        /* 纬度 → V：上极点是 0，下极点是 U（经度 → U 在循环里按 j 算） */
        float tv0 = (float)i / (float)RING * U;
        float tv1 = (float)(i + 1) / (float)RING * U;
        glBegin(GL_TRIANGLE_STRIP);
        for (int j = 0; j <= SEG; j++) {
            float nx, ny, nz;
            float uu = (float)j / (float)SEG * U;
            /* 上环：纬线 RING 段的第 i 片 */
            nx = sy0 * sr->c[j]; ny = cy0; nz = sy0 * sr->s[j];
            set_lit_color(lr, lg, lb, nx, ny, nz);
            glTexCoord2f(uu, tv0);
            glVertex3f(s->x + s->rad * nx, s->y + s->rad * ny, s->z + s->rad * nz);
            /* 下环 */
            nx = sy1 * sr->c[j]; ny = cy1; nz = sy1 * sr->s[j];
            set_lit_color(lr, lg, lb, nx, ny, nz);
            glTexCoord2f(uu, tv1);
            glVertex3f(s->x + s->rad * nx, s->y + s->rad * ny, s->z + s->rad * nz);
        }
        glEnd();
    }
}""")

# ============ 9) 柱：UV（侧面 + 两个盖） ============
add('cyl-uv', """    float lr = c->r / 255.0f, lg = c->g / 255.0f, lb = c->b / 255.0f;
    float y0 = c->y, y1 = c->y + c->h;
    float rb = c->rb, rt = c->rt;
    /* 侧面法线的竖直分量：底面到顶面半径差越大越斜。
       用 (rb - rt) / h 作为斜率，避免 h=0 时除零。 */
    float slope = c->h != 0.0f ? (rb - rt) / c->h : 0.0f;
    float ny = -slope;                 /* 外法线朝上为负斜率 */

    /* ---- 侧面 ---- */
    if (rb > 0.0001f || rt > 0.0001f) {
        glBegin(GL_TRIANGLE_STRIP);
        for (int j = 0; j <= SEG; j++) {
            float cc = sr->c[j], ss = sr->s[j];
            float nl = (float)sqrt((double)(1.0f + ny * ny));
            float nx = cc / nl, nyy = ny / nl, nz = ss / nl;
            set_lit_color(lr, lg, lb, nx, nyy, nz);
            glVertex3f(c->x + rb * cc, y0, c->z + rb * ss);
            set_lit_color(lr, lg, lb, nx, nyy, nz);
            glVertex3f(c->x + rt * cc, y1, c->z + rt * ss);
        }
        glEnd();
    }

    /* ---- 顶盖（半径 > 0 才画），法线 +Y ---- */
    if (rt > 0.0001f) {
        set_lit_color(lr, lg, lb, 0.0f, 1.0f, 0.0f);
        glBegin(GL_TRIANGLE_FAN);
        glVertex3f(c->x, y1, c->z);
        for (int j = 0; j <= SEG; j++)
            glVertex3f(c->x + rt * sr->c[j], y1, c->z + rt * sr->s[j]);
        glEnd();
    }

    /* ---- 底盖，法线 -Y，绕序反过来 ---- */
    if (rb > 0.0001f) {
        set_lit_color(lr, lg, lb, 0.0f, -1.0f, 0.0f);
        glBegin(GL_TRIANGLE_FAN);
        glVertex3f(c->x, y0, c->z);
        for (int j = SEG; j >= 0; j--)
            glVertex3f(c->x + rb * sr->c[j], y0, c->z + rb * sr->s[j]);
        glEnd();
    }
}""",
"""    float lr = c->r / 255.0f, lg = c->g / 255.0f, lb = c->b / 255.0f;
    float U = c->uv > 0.0f ? c->uv : 1.0f;
    float y0 = c->y, y1 = c->y + c->h;
    float rb = c->rb, rt = c->rt;
    /* 侧面法线的竖直分量：底面到顶面半径差越大越斜。
       用 (rb - rt) / h 作为斜率，避免 h=0 时除零。 */
    float slope = c->h != 0.0f ? (rb - rt) / c->h : 0.0f;
    float ny = -slope;                 /* 外法线朝上为负斜率 */

    /* ---- 侧面：U 沿圆周绕一圈，V 沿高度 0->U ---- */
    if (rb > 0.0001f || rt > 0.0001f) {
        float nl = (float)sqrt((double)(1.0f + ny * ny));
        glBegin(GL_TRIANGLE_STRIP);
        for (int j = 0; j <= SEG; j++) {
            float cc = sr->c[j], ss = sr->s[j];
            float nx = cc / nl, nyy = ny / nl, nz = ss / nl;
            float uu = (float)j / (float)SEG * U;
            set_lit_color(lr, lg, lb, nx, nyy, nz);
            glTexCoord2f(uu, 0.0f);
            glVertex3f(c->x + rb * cc, y0, c->z + rb * ss);
            set_lit_color(lr, lg, lb, nx, nyy, nz);
            glTexCoord2f(uu, U);
            glVertex3f(c->x + rt * cc, y1, c->z + rt * ss);
        }
        glEnd();
    }

    /* ---- 顶盖（半径 > 0 才画），法线 +Y。
           UV 用平面映射：把 (x,z) 的圆盘直接映到 0..U 的方形上。 ---- */
    if (rt > 0.0001f) {
        set_lit_color(lr, lg, lb, 0.0f, 1.0f, 0.0f);
        glBegin(GL_TRIANGLE_FAN);
        glTexCoord2f(U * 0.5f, U * 0.5f);
        glVertex3f(c->x, y1, c->z);
        for (int j = 0; j <= SEG; j++) {
            glTexCoord2f((0.5f + 0.5f * sr->c[j]) * U, (0.5f + 0.5f * sr->s[j]) * U);
            glVertex3f(c->x + rt * sr->c[j], y1, c->z + rt * sr->s[j]);
        }
        glEnd();
    }

    /* ---- 底盖，法线 -Y，绕序反过来 ---- */
    if (rb > 0.0001f) {
        set_lit_color(lr, lg, lb, 0.0f, -1.0f, 0.0f);
        glBegin(GL_TRIANGLE_FAN);
        glTexCoord2f(U * 0.5f, U * 0.5f);
        glVertex3f(c->x, y0, c->z);
        for (int j = SEG; j >= 0; j--) {
            glTexCoord2f((0.5f + 0.5f * sr->c[j]) * U, (0.5f + 0.5f * sr->s[j]) * U);
            glVertex3f(c->x + rb * sr->c[j], y0, c->z + rb * sr->s[j]);
        }
        glEnd();
    }
}""")

# ============ 10) 图元记录：sphere / cyl / line 追加 op ============
add('sphere-op', """    s->b = (unsigned char)hw_u8((int)hw_num(cbv, "hw.sphere 的 B"));
    return rt_none();
}""",
"""    s->b = (unsigned char)hw_u8((int)hw_num(cbv, "hw.sphere 的 B"));
    s->tex = g_curtex;
    s->uv  = g_curuv;
    hw_op(OP_SPHERE, g_nspheres - 1);
    return rt_none();
}""")

add('cyl-op', """    c->b = (unsigned char)hw_u8((int)hw_num(bv, "hw.cyl 的 B"));
    return rt_none();
}""",
"""    c->b = (unsigned char)hw_u8((int)hw_num(bv, "hw.cyl 的 B"));
    c->tex = g_curtex;
    c->uv  = g_curuv;
    hw_op(OP_CYL, g_ncyls - 1);
    return rt_none();
}""")

add('line-op', """    l->b = (unsigned char)hw_u8((int)hw_num(bv, "hw.line 的 B"));
    return rt_none();
}""",
"""    l->b = (unsigned char)hw_u8((int)hw_num(bv, "hw.line 的 B"));
    hw_op(OP_LINE, g_nlines - 1);
    return rt_none();
}""")

# ============ 11) 新 API：push / pop / tex / texuse / uv ============
add('new-apis', """Value rt_hw_end(void)""",
"""/* hw.push(x, y, z, 绕x, 绕y, 绕z)：压入一个父变换（节点树的"进节点"）。
   push 之后提交的所有图元都活在这个坐标系里——父节点转动时它们跟着转。
   必须和 hw.pop() 配对；忘写 pop 帧末会自动清栈，不会崩。
   旋转顺序 X→Y→Z，绕 push 的那个原点。

   典型用法（转动桌子，桌上的东西跟着转）：
       hw.push(桌x, 桌y, 桌z, 0, 桌朝向, 0)
       hw.box(0, 0, 0, 4, 0.3, 4, 140, 100, 60)      # 桌面（局部坐标）
       hw.box(-1, 0.5, 1, 1, 1, 1, 220, 220, 230)    # 杯子（自动跟着转）
       hw.box(1.2, 0.4, -0.8, 0.8, 0.8, 0.8, 180, 120, 90)
       hw.pop()

   可以嵌套（最多 %d 层）：桌子上面放托盘，托盘上再放杯子。 */
Value rt_hw_push(Value xv, Value yv, Value zv,
                 Value axv, Value ayv, Value azv)
{
    if (g_nops >= HW_OP_MAX)
        hw_die("hw.push：单帧图元/变换数超过上限 %d", HW_OP_MAX);
    HwOp *o = &g_ops[g_nops++];
    o->type = OP_PUSH;
    o->idx  = 0;
    o->px = (float)hw_num(xv, "hw.push 的 x");
    o->py = (float)hw_num(yv, "hw.push 的 y");
    o->pz = (float)hw_num(zv, "hw.push 的 z");
    o->rx = (float)hw_num(axv, "hw.push 的绕X");
    o->ry = (float)hw_num(ayv, "hw.push 的绕Y");
    o->rz = (float)hw_num(azv, "hw.push 的绕Z");
    return rt_none();
}

/* hw.pop()：弹出最近的 hw.push（节点树的"出节点"）。 */
Value rt_hw_pop(void)
{
    hw_op(OP_POP, 0);
    return rt_none();
}

/* hw.tex(槽, 路径)：把图片加载到贴图槽（1 ~ 7）。
   支持 png / jpg / bmp / tga（走 stb_image，和"游戏.图"同一个解码器）。
   成功返回 1，文件不存在或解码失败返回 0（不中断程序，方便脚本容错）。
   槽 0 固定表示"无贴图"，不能写入。
   中文路径没问题（内部转 UTF-16 再 _wfopen）。 */
Value rt_hw_tex(Value sv, Value pv)
{
    int slot = (int)hw_num(sv, "hw.tex 的槽位");
    const char *path = hw_str(pv, "hw.tex 的路径");
    if (slot < 1 || slot >= HW_TEX_SLOTS) {
        hw_die("hw.tex：槽位要在 1~%d 之间（0 是无贴图）", HW_TEX_SLOTS - 1);
        return rt_int(0);
    }
    if (g_win == NULL)
        hw_die("hw.tex：还没开窗口（先调用 hw.open）");

    wchar_t wpath[1024];
    if (MultiByteToWideChar(CP_UTF8, 0, path ? path : "", -1, wpath, 1024) <= 0)
        return rt_int(0);
    FILE *fp = _wfopen(wpath, L"rb");
    if (fp == NULL)
        return rt_int(0);
    int w = 0, h = 0, n = 0;
    unsigned char *data = stbi_load_from_file(fp, &w, &h, &n, 4);
    fclose(fp);
    if (data == NULL || w <= 0 || h <= 0)
        return rt_int(0);

    if (g_texs[slot] != 0)                 /* 重载同一槽：先删旧的 */
        glDeleteTextures(1, &g_texs[slot]);
    GLuint id = 0;
    glGenTextures(1, &id);
    glBindTexture(GL_TEXTURE_2D, id);
    glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, data);
    /* GL_REPEAT 是 hw.uv 能平铺的前提；不做 mipmap，就用线性过滤 */
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glBindTexture(GL_TEXTURE_2D, 0);
    stbi_image_free(data);
    g_texs[slot] = id;
    g_texw[slot] = w;
    g_texh[slot] = h;
    return rt_int(1);
}

/* hw.texuse(槽)：设定"当前贴图"。之后提交的 box / sphere / cyl 都会用它。
   槽 0 = 回到纯色。想只给部分图元贴图，就在中间切一次。 */
Value rt_hw_texuse(Value sv)
{
    int slot = (int)hw_num(sv, "hw.texuse 的槽位");
    if (slot < 0 || slot >= HW_TEX_SLOTS) {
        hw_die("hw.texuse：槽位要在 0~%d 之间", HW_TEX_SLOTS - 1);
        return rt_none();
    }
    g_curtex = slot;
    return rt_none();
}

/* hw.uv(重复次数)：设定"当前 UV 重复次数"。
   1 = 整张贴图铺满一个面；3 = 3x3 平铺；0.5 = 只显示贴图中心那一块。
   （>1 才是平铺，靠 GL_REPEAT 实现） */
Value rt_hw_uv(Value vv)
{
    double d = hw_num(vv, "hw.uv 的重复次数");
    if (d <= 0.0) d = 1.0;
    if (d > 64.0) d = 64.0;
    g_curuv = (float)d;
    return rt_none();
}

Value rt_hw_end(void)""")

# ============ 12) frame：贴图环境 + 换成 draw_ops ============
add('frame-texenv', """    glEnable(GL_DEPTH_TEST);
    /* 雾：起步 >= 终止 视为关雾（编辑器看近景时不糊） */""",
"""    glEnable(GL_DEPTH_TEST);
    /* 贴图环境（每帧设一次即可）：
       GL_MODULATE = 顶点色 x 贴图色 —— 方向光的明暗会自动作用在贴图上。
       alpha 裁剪处理带透明通道的 PNG：不做排序，避免半透明排序难题。 */
    glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
    glEnable(GL_ALPHA_TEST);
    glAlphaFunc(GL_GREATER, 0.01f);
    /* 雾：起步 >= 终止 视为关雾（编辑器看近景时不糊） */""")

add('frame-drawops', """    for (int i = 0; i < g_nboxes; i++)
        draw_box(&g_boxes[i]);
    for (int i = 0; i < g_nspheres; i++) {
        if (g_wire) draw_sphere_wire(&g_spheres[i]);
        else        draw_sphere(&g_spheres[i]);
    }
    for (int i = 0; i < g_ncyls; i++) {
        if (g_wire) draw_cyl_wire(&g_cyls[i]);
        else        draw_cyl(&g_cyls[i]);
    }
    draw_lines();""",
"""    draw_ops();""")

add('frame-clear', """    g_nqtext = 0;
    g_nboxes = 0;
    g_nlines = 0;
    g_nspheres = 0;
    g_ncyls = 0;""",
"""    g_nqtext = 0;
    g_nboxes = 0;
    g_nlines = 0;
    g_nspheres = 0;
    g_ncyls = 0;
    g_nops = 0;
    g_depth = 0;""")

# ============ 13) draw_ops（插在 rt_hw_frame 之前） ============
add('draw-ops', """Value rt_hw_frame(void)""",
"""/* 按提交顺序执行命令流。push/pop 直接映射到 GL 的矩阵栈。
   这是"父子层级"的落地点：父变换套在外面，子图元自然跟着转。
   线段做连续批处理（相邻的 OP_LINE 合进一个 glBegin）。 */
static void draw_ops(void)
{
    g_depth = 0;
    for (int i = 0; i < g_nops; i++) {
        HwOp *o = &g_ops[i];
        switch (o->type) {
        case OP_PUSH:
            if (g_depth >= HW_MAX_DEPTH)      /* 超深度：忽略，防爆栈 */
                break;
            glPushMatrix();
            glTranslatef(o->px, o->py, o->pz);
            glRotatef(o->rz * 57.29578f, 0.0f, 0.0f, 1.0f);
            glRotatef(o->ry * 57.29578f, 0.0f, 1.0f, 0.0f);
            glRotatef(o->rx * 57.29578f, 1.0f, 0.0f, 0.0f);
            g_depth++;
            break;
        case OP_POP:
            if (g_depth > 0) {
                glPopMatrix();
                g_depth--;
            }
            break;
        case OP_BOX:
            hw_bind_tex(g_boxes[o->idx].tex);
            draw_box(&g_boxes[o->idx]);
            break;
        case OP_SPHERE:
            hw_bind_tex(g_spheres[o->idx].tex);
            if (g_wire) draw_sphere_wire(&g_spheres[o->idx]);
            else        draw_sphere(&g_spheres[o->idx]);
            break;
        case OP_CYL:
            hw_bind_tex(g_cyls[o->idx].tex);
            if (g_wire) draw_cyl_wire(&g_cyls[o->idx]);
            else        draw_cyl(&g_cyls[o->idx]);
            break;
        case OP_LINE: {
            glDisable(GL_TEXTURE_2D);         /* 线段不贴图 */
            glBegin(GL_LINES);
            int j = i;
            for (; j < g_nops && g_ops[j].type == OP_LINE; j++) {
                const HwLine *l = &g_lines[g_ops[j].idx];
                glColor3f(l->r / 255.0f, l->g / 255.0f, l->b / 255.0f);
                glVertex3f(l->x1, l->y1, l->z1);
                glVertex3f(l->x2, l->y2, l->z2);
            }
            glEnd();
            i = j - 1;                        /* 批处理已吃掉 [i, j) */
            break;
        }
        default:
            break;
        }
    }
    while (g_depth > 0) {                     /* 脚本忘配对 pop：兜底清栈 */
        glPopMatrix();
        g_depth--;
    }
    glDisable(GL_TEXTURE_2D);
}

Value rt_hw_frame(void)""")

# ============ 14) open：重置 op + 贴图槽 ============
add('open-reset', """    g_nboxes = 0;
    g_nlines = 0;
    g_nqtext = 0;
    g_nspheres = 0;
    g_ncyls = 0;
    memset(g_kprev, 0, sizeof g_kprev);""",
"""    g_nboxes = 0;
    g_nlines = 0;
    g_nqtext = 0;
    g_nspheres = 0;
    g_ncyls = 0;
    g_nops = 0;
    g_depth = 0;
    g_curtex = 0;
    g_curuv = 1.0f;
    /* 旧上下文的纹理随上下文一起销毁了，这里只清名字（不能 glDeleteTextures） */
    memset(g_texs, 0, sizeof g_texs);
    memset(g_texw, 0, sizeof g_texw);
    memset(g_texh, 0, sizeof g_texh);
    memset(g_kprev, 0, sizeof g_kprev);""")

# ---------- 执行 ----------
fails = 0
for label, old, new in PATCHES:
    n = s.count(old)
    if n != 1:
        sys.stderr.write('FAIL [%s] count=%d\n' % (label, n))
        fails += 1
        continue
    s = s.replace(old, new, 1)
    print('ok   ' + label)

if fails:
    sys.stderr.write('\n%d 处锚点失败，未写回\n' % fails)
    sys.exit(1)

io.open(P, 'w', encoding='utf-8', newline='').write(s)
print('\n全部 %d 处已写回' % len(PATCHES))
