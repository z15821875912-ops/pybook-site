/* PYbook numpybk（np. 前缀）：数组运算原生库。
 * v1 定位：一维数值列表的向量化运算（游戏数学够用）——
 * 全部直接操作 RtList，C 级速度；整数保整数，浮点自动提升。
 * 函数：zeros / range / add / sub / mul / scale / dot / norm /
 *       normalize / max / min / sum / mean / sin / cos / sqrt */

#include "pybook_lib.h"
#include "pybook_mt.h"

#include <math.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>

#define NP_PAR_MIN (1 << 16)   /* 6.5 万元素起并行 */

/* ================= 内部 ================= */

static void np_die(const char *fmt, ...)
{
    va_list ap;
    fprintf(stderr, "运行时错误: ");
    va_start(ap, fmt);
    vfprintf(stderr, fmt, ap);
    va_end(ap);
    fputc('\n', stderr);
    exit(1);
}

static RtList *as_arr(Value v, const char *who)
{
    if (!IS_LIST(v) || AS_LIST(v) == NULL)
        np_die("%s 需要列表（np 库操作数值数组）", who);
    return AS_LIST(v);
}

static RtList *as_arr2(Value a, Value b, const char *who)
{
    RtList *A = as_arr(a, who), *B = as_arr(b, who);
    if (A->len != B->len)
        np_die("%s 两个数组长度不一致（%zu vs %zu）", who, A->len, B->len);
    (void)A;
    return B;
}

static double el(Value v)
{
    if (IS_FLT(v))  return AS_FLT(v);
    if (IS_INT(v) || IS_BIGINT(v)) return (double)rt_to_ll(v);
    if (IS_BOOL(v)) return (double)AS_BOOL(v);
    np_die("np 数组元素必须是数字");
    return 0;
}

static double num_arg(Value v, const char *who)
{
    if (IS_FLT(v))  return AS_FLT(v);
    if (IS_INT(v) || IS_BIGINT(v)) return (double)rt_to_ll(v);
    if (IS_BOOL(v)) return (double)AS_BOOL(v);
    np_die("%s 需要数字参数", who);
    return 0;
}

static int is_int_el(Value v)
{
    return IS_INT(v) || IS_BIGINT(v) || IS_BOOL(v);
}

static Value new_arr(size_t n)
{
    Value lst = rt_list_new();
    RtList *L = AS_LIST(lst);
    for (size_t i = 0; i < n; i++)
        rt_push(&lst, rt_int(0));
    (void)L;
    return lst;
}

/* 元素级二元运算：双整保整，否则浮点 */
typedef struct { RtList *A, *B, *O; int all_int; } NpBinCtx;

#define BINOP(NAME, OP, WHO)                                        \
static void NAME##_chunk(int cid, long long a, long long b, void *ud) \
{                                                                   \
    NpBinCtx *x = ud;                                               \
    (void)cid;                                                      \
    if (x->all_int)                                                 \
        for (long long i = a; i < b; i++)                           \
            x->O->items[i] = rt_int(rt_to_ll(x->A->items[i])        \
                                    OP rt_to_ll(x->B->items[i]));   \
    else                                                            \
        for (long long i = a; i < b; i++)                           \
            x->O->items[i] = rt_float(el(x->A->items[i])            \
                                      OP el(x->B->items[i]));       \
}                                                                   \
static Value NAME(Value a, Value b)                                 \
{                                                                   \
    RtList *A = as_arr(a, WHO), *B = as_arr2(a, b, WHO);            \
    Value out = new_arr(A->len);                                    \
    RtList *O = AS_LIST(out);                                       \
    int all_int = 1;                                                \
    for (size_t i = 0; i < A->len; i++)                             \
        if (!is_int_el(A->items[i]) || !is_int_el(B->items[i])) {   \
            all_int = 0;                                            \
            break;                                                  \
        }                                                           \
    if (A->len >= NP_PAR_MIN) {                                     \
        NpBinCtx x = { A, B, O, all_int };                          \
        mt_parallel((long long)A->len, NAME##_chunk, &x);           \
        return out;                                                 \
    }                                                               \
    for (size_t i = 0; i < A->len; i++) {                           \
        if (all_int) {                                              \
            long long x = rt_to_ll(A->items[i]) OP rt_to_ll(B->items[i]); \
            O->items[i] = rt_int(x);                                \
        } else {                                                    \
            O->items[i] = rt_float(el(A->items[i]) OP el(B->items[i])); \
        }                                                           \
    }                                                               \
    return out;                                                     \
}

BINOP(np_add_impl, +, "np.add")
BINOP(np_sub_impl, -, "np.sub")
BINOP(np_mul_impl, *, "np.mul")

/* ================= 对外接口 ================= */

Value rt_np_zeros(Value n)
{
    long long len = (long long)num_arg(n, "np.zeros 的长度");
    if (len < 0 || len > 10000000)
        np_die("np.zeros 长度超范围（0..1000万）");
    return new_arr((size_t)len);
}

Value rt_np_range(Value lov, Value hiv, Value stepv)
{
    double lo = num_arg(lov, "np.range 的起点");
    double hi = num_arg(hiv, "np.range 的终点");
    double st = num_arg(stepv, "np.range 的步长");
    if (st == 0.0)
        np_die("np.range 步长不能为 0");
    int ints = is_int_el(lov) && is_int_el(hiv) && is_int_el(stepv);
    Value out = rt_list_new();
    long long guard = 0;
    if (st > 0)
        for (double x = lo; x < hi && guard++ < 10000000; x += st) {
            if (ints && st == (double)(long long)st && lo == (double)(long long)lo)
                rt_push(&out, rt_int((long long)x));
            else
                rt_push(&out, rt_float(x));
        }
    else
        for (double x = lo; x > hi && guard++ < 10000000; x += st) {
            if (ints && st == (double)(long long)st && lo == (double)(long long)lo)
                rt_push(&out, rt_int((long long)x));
            else
                rt_push(&out, rt_float(x));
        }
    return out;
}

Value rt_np_add(Value a, Value b) { return np_add_impl(a, b); }
Value rt_np_sub(Value a, Value b) { return np_sub_impl(a, b); }
Value rt_np_mul(Value a, Value b) { return np_mul_impl(a, b); }

typedef struct { RtList *A, *O; int ints; double k; long long ki; } NpScCtx;

static void np_scale_chunk(int cid, long long a, long long b, void *ud)
{
    NpScCtx *x = ud;
    (void)cid;
    if (x->ints)
        for (long long i = a; i < b; i++)
            x->O->items[i] = rt_int(rt_to_ll(x->A->items[i]) * x->ki);
    else
        for (long long i = a; i < b; i++)
            x->O->items[i] = rt_float(el(x->A->items[i]) * x->k);
}

Value rt_np_scale(Value a, Value k)
{
    RtList *A = as_arr(a, "np.scale");
    Value out = new_arr(A->len);
    RtList *O = AS_LIST(out);
    int ints = is_int_el(k);
    for (size_t i = 0; i < A->len; i++)
        ints = ints && is_int_el(A->items[i]);
    if (A->len >= NP_PAR_MIN) {
        NpScCtx x = { A, O, ints, el(k), rt_to_ll(k) };
        mt_parallel((long long)A->len, np_scale_chunk, &x);
        return out;
    }
    for (size_t i = 0; i < A->len; i++) {
        if (ints)
            O->items[i] = rt_int(rt_to_ll(A->items[i]) * rt_to_ll(k));
        else
            O->items[i] = rt_float(el(A->items[i]) * el(k));
    }
    return out;
}

Value rt_np_dot(Value a, Value b)
{
    RtList *A = as_arr(a, "np.dot"), *B = as_arr2(a, b, "np.dot");
    int ints = 1;
    double acc_f = 0;
    long long acc_i = 0;
    for (size_t i = 0; i < A->len; i++)
        if (!is_int_el(A->items[i]) || !is_int_el(B->items[i])) {
            ints = 0;
            break;
        }
    if (ints) {
        for (size_t i = 0; i < A->len; i++)
            acc_i += rt_to_ll(A->items[i]) * rt_to_ll(B->items[i]);
        return rt_int(acc_i);
    }
    for (size_t i = 0; i < A->len; i++)
        acc_f += el(A->items[i]) * el(B->items[i]);
    return rt_float(acc_f);
}

Value rt_np_norm(Value a)
{
    RtList *A = as_arr(a, "np.norm");
    double s = 0;
    for (size_t i = 0; i < A->len; i++) {
        double x = el(A->items[i]);
        s += x * x;
    }
    return rt_float(sqrt(s));
}

Value rt_np_normalize(Value a)
{
    RtList *A = as_arr(a, "np.normalize");
    double s = 0;
    for (size_t i = 0; i < A->len; i++) {
        double x = el(A->items[i]);
        s += x * x;
    }
    double n = sqrt(s);
    if (n < 1e-12)
        np_die("np.normalize 零向量没有方向");
    Value out = new_arr(A->len);
    RtList *O = AS_LIST(out);
    for (size_t i = 0; i < A->len; i++)
        O->items[i] = rt_float(el(A->items[i]) / n);
    return out;
}

Value rt_np_max(Value a)
{
    RtList *A = as_arr(a, "np.max");
    if (A->len == 0)
        np_die("np.max 空数组没有最大值");
    Value m = A->items[0];
    for (size_t i = 1; i < A->len; i++)
        if (rt_cond(rt_gt(A->items[i], m)))
            m = A->items[i];
    return m;
}

Value rt_np_min(Value a)
{
    RtList *A = as_arr(a, "np.min");
    if (A->len == 0)
        np_die("np.min 空数组没有最小值");
    Value m = A->items[0];
    for (size_t i = 1; i < A->len; i++)
        if (rt_cond(rt_lt(A->items[i], m)))
            m = A->items[i];
    return m;
}

typedef struct { RtList *A; RtList *O; long long *iparts; double *dparts; } NpSumCtx;

static void np_sum_chunk(int cid, long long a, long long b, void *ud)
{
    NpSumCtx *x = ud;
    if (x->iparts) {
        long long s = 0;
        for (long long i = a; i < b; i++)
            s += rt_to_ll(x->A->items[i]);
        x->iparts[cid] = s;
    } else {
        double s = 0;
        for (long long i = a; i < b; i++)
            s += el(x->A->items[i]);
        x->dparts[cid] = s;
    }
}

Value rt_np_sum(Value a)
{
    RtList *A = as_arr(a, "np.sum");
    int ints = 1;
    for (size_t i = 0; i < A->len; i++)
        if (!is_int_el(A->items[i])) {
            ints = 0;
            break;
        }
    if (ints) {
        if (A->len >= NP_PAR_MIN) {
            long long parts[MT_CHUNKS] = {0};
            NpSumCtx x = { A, NULL, parts, NULL };
            int chunks = mt_parallel((long long)A->len, np_sum_chunk, &x);
            long long s = 0;
            for (int i = 0; i < chunks; i++)
                s += parts[i];
            return rt_int(s);
        }
        long long s = 0;
        for (size_t i = 0; i < A->len; i++)
            s += rt_to_ll(A->items[i]);
        return rt_int(s);
    }
    if (A->len >= NP_PAR_MIN) {
        double parts[MT_CHUNKS] = {0};
        NpSumCtx x = { A, NULL, NULL, parts };
        int chunks = mt_parallel((long long)A->len, np_sum_chunk, &x);
        double s = 0;
        for (int i = 0; i < chunks; i++)
            s += parts[i];
        return rt_float(s);
    }
    double s = 0;
    for (size_t i = 0; i < A->len; i++)
        s += el(A->items[i]);
    return rt_float(s);
}

Value rt_np_mean(Value a)
{
    RtList *A = as_arr(a, "np.mean");
    if (A->len == 0)
        np_die("np.mean 空数组没有平均值");
    double s = 0;
    if (A->len >= NP_PAR_MIN) {
        double parts[MT_CHUNKS] = {0};
        NpSumCtx x = { A, NULL, NULL, parts };
        int chunks = mt_parallel((long long)A->len, np_sum_chunk, &x);
        for (int i = 0; i < chunks; i++)
            s += parts[i];
        return rt_float(s / (double)A->len);
    }
    for (size_t i = 0; i < A->len; i++)
        s += el(A->items[i]);
    return rt_float(s / (double)A->len);
}

/* 元素级数学：sin / cos / sqrt（全浮点输出） */
typedef struct { RtList *A, *O; } NpM1Ctx;

#define MATH1(NAME, EXPR, WHO)                                     \
static void NAME##_chunk(int cid, long long a, long long b, void *ud) \
{                                                                   \
    NpM1Ctx *x = ud;                                                \
    (void)cid;                                                      \
    for (long long i = a; i < b; i++) {                             \
        double v = el(x->A->items[i]);                              \
        x->O->items[i] = rt_float(EXPR);                            \
    }                                                               \
}                                                                   \
static Value NAME(Value a)                                          \
{                                                                   \
    RtList *A = as_arr(a, WHO);                                     \
    Value out = new_arr(A->len);                                    \
    RtList *O = AS_LIST(out);                                       \
    if (A->len >= NP_PAR_MIN) {                                     \
        NpM1Ctx x = { A, O };                                       \
        mt_parallel((long long)A->len, NAME##_chunk, &x);           \
        return out;                                                 \
    }                                                               \
    for (size_t i = 0; i < A->len; i++) {                           \
        double v = el(A->items[i]);                                 \
        O->items[i] = rt_float(EXPR);                               \
    }                                                               \
    return out;                                                     \
}

MATH1(m_sin, sin(v),   "np.sin")
MATH1(m_cos, cos(v),   "np.cos")
MATH1(m_sqrt, sqrt(v), "np.sqrt")

Value rt_np_sin(Value a)   { return m_sin(a); }
Value rt_np_cos(Value a)   { return m_cos(a); }
Value rt_np_sqrt(Value a)  { return m_sqrt(a); }
