# -*- coding: utf-8 -*-
"""跑 _proto_ortho.pybk：编译成 C → gcc → 运行，然后把程序写出的报告读回来。
   3D 程序没有 stdout，所以这里读报告文件来验证。"""
import io, os, sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.argv = [sys.argv[0], '_proto_ortho.pybk']
import pybk_code

src = io.open('_proto_ortho.pybk', encoding='utf-8-sig').read()
out = pybk_code.compile_and_run_once(src)
print('--- 程序回显 ---')
print(out)

rep = '_ortho_smoke_report.txt'
if os.path.exists(rep):
    print('--- 报告 %s ---' % rep)
    print(io.open(rep, encoding='utf-8').read())
    # 收尾：报告里应出现 帧数=300
    txt = io.open(rep, encoding='utf-8').read()
    assert '帧数=300' in txt, '帧数不是 300，程序可能中途异常'
    print('>>> 断言通过：跑满 300 帧、投影两侧都走到')
else:
    print('** 报告文件没生成 —— 程序可能崩在 hw.ortho 上')
    sys.exit(1)
