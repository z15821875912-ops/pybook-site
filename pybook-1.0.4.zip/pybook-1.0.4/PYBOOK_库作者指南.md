# PYbook 库作者指南

> 给「想给 PYbook 写个库」的人。全部结论均在本机实测（`_库实验室/` 有可跑的样板）。
> 实测环境：Python 3.13、gcc `C:\Users\zhuli\mingw64\bin\x86_64-w64-mingw32-gcc.exe`。

## 一句话结论

写库有两条路。**纯 PYbook 库（`.pybk` + `引用`）现在能用，但它是「把整个库文本拼进你的程序」，没有命名空间、不能有模块级状态、不能用对象做接口** —— 所以库的正确写法是「**自由函数 + 列表状态盒 + 统一命名前缀**」。想要 `mt.` / `js.` 那种带前缀的成员式调用（`库.函数(...)`），必须走 C 扩展路线。

| 路线 | 产物 | 调用形式 | 适合 |
|---|---|---|---|
| A. PYbook 原生库 | `名字.pybk` | `st_均值(表)`（扁平名） | 纯逻辑、算法包、让自己用的工具库 |
| B. C 扩展库 | `pybook_xxx.c/h` + **四处**注册 | `xxx.函数(...)`（命名空间式） | 要性能、要接 C 生态、要对外发布成"标准库" |

**结论：用 C 做行，而且这是唯一能做出 `库.函数(...)` 前缀调用的路子。** 本次已用 C 做出
`bs.*` 位运算库并跑通（核心层 20 项自检 + 14 个函数全部数值正确），照抄即可。

---

## 路线 A：PYbook 原生库

### 最小模板

库文件 `statlib.pybk`（顶层不能有 GOING）：

```python
@ st 统计库>内部>1

vg_ro.st_版本 = "1.0"          # 只读常量（主文件 GOING 可读，函数里读不到）

func st_均值(表) {
    vg.和 = 0
    for v in 表 { 和 += v }
    ret 和 / 长度(表)
}
```

主文件：

```python
@ 演示>主程序>1
引用("statlib")                # 必须在 GOING 之前；找同目录 statlib.pybk
GOING:{
vg.m = st_均值([1,2,3])
ns.show(均值 $m)
}STOP
```

验证：`python pybk_main.py --check 主文件.pybk`（含 `引用` 的程序以前会崩，已修）。

### 硬规则（全部实测确认）

| # | 规则 | 违反后果 |
|---|---|---|
| 1 | 库顶层只能有 `引用` / `func` / `vg` / `vg_ro` / `lb` / `Memoryment` | 报错「模块文件顶层只能是 引用/func/vg/lb/Memoryment」 |
| 2 | **库的 GOING 被完全忽略**，一行都不跑 | 不报错，静默失效 —— 自检/示例别写在这 |
| 3 | **库内函数不支持前向引用**，被调用者必须先定义 | 报错「函数 xxx 未定义」（行号在被调的那行） |
| 4 | **没有命名空间**：所有 func / 类 / 顶层 vg 并进一张全局扁平表 | 与主程序或另一个库同名 → 「重复定义」 |
| 5 | **传递可见**：A 引用 B → 主程序无需引用 B 就能直接用 B 的函数 | 便利，但命名空间污染更深 |
| 6 | **函数体内读不到全局**（含库自己的顶层 `vg`） | 报错「变量 xxx 未声明」 |
| 7 | 方法调用只支持 `self` 或**直接由 `lb.类(...)` 赋值的变量** | 对象当参数传进函数后调不了它的方法 |
| 8 | 嵌套引用最深 8 层，循环引用报错 | 「引用嵌套超过 8 层」/「循环引用」 |
| 9 | `引用` 必须写在 GOING 之前 | 「GOING 之后的引用应当报错」 |

### 唯一可靠的库写法（推荐范式）

规则 6 + 7 决定了：**库不能持有模块级可变状态，也不能把对象当接口传**。
所以状态只能用**列表**（引用传递，函数内可自由读写）显式在调用方手里流转：

```python
# 库侧：工厂 + 纯函数
func st_新盒() { ret [0] }                 # [0] = 调用次数
func st_记一笔(盒) { 盒[0] = 盒[0] + 1  ret 盒[0] }
func st_报告(表, 盒) { ret [st_均值(表), 盒[0]] }

# 调用方：持有状态，传进去
vg.盒 = st_新盒()
vg.r = st_报告(数据, 盒)
```

- **不要用字典做状态盒**：实测会让参数字典触发堆损坏（见下方「已知 bug」）。
- **不要用 `lb` 对象做状态盒**：传进函数后调不了方法。

### 命名约定（因为规则 4，这是强制的，不是风格问题）

| 用途 | 写法 | 例 |
|---|---|---|
| 公开函数 | `库前缀_动词` | `st_均值` |
| 内部函数 | `库前缀_内部名` + 注释说明 | `st_归一化内部`（`__` 前缀也行，但同样全局可见，**没有真正的私有**） |
| 库常量 | `库前缀_名`，用 `vg_ro.` | `vg_ro.st_版本` |
| 状态盒字段 | 列表下标 + 注释 | `[0] 次数 / [1] 耗时` |

### 验证清单（每次发库前）

```bash
python pybk_main.py --check demo.pybk     # 静态：语法 + 语义 + 引用合并
python pybk_main.py demo.pybk             # 真实：gcc 编译 + 链接 + 跑
```
`--check` 通过 ≠ 能跑。本次就遇到「`--check` 过、一跑就段错误」的情况，务必真跑 3~5 次。

---

## 路线 B：C 扩展库（做成 `mt.` 这样的带前缀标准库）

**已实测跑通**：本次新增的 `bs.*` 位运算库（`pybook_bits.c/h` + `_库实验室/bits_demo.pybk`），
核心层 20 项自检全过，接进 PYbook 后 14 个函数全部数值正确。照抄即可。

### 接入要改 5 处（**四处注册一点都不能漏**）

| # | 文件 | 位置 | 改什么 |
|---|---|---|---|
| 1 | `pybk_front.py` | `KEYWORDS` (~L25) | **加前缀名**，如 `'bs'` —— 不加的话 `bs.xxx` 会被切成 NAME + `.`，报「不是合法的表达式」 |
| 2 | `pybk_front.py` | `LIB_PREFIXES` (L267) | **再加一次前缀** —— 不加的话报「不是合法的表达式：'bs'」 |
| 3 | `pybk_front.py` | `LIB_CALLS` (L268) | `'前缀.函数名': 参数个数`（**元数写错在调用点报错**） |
| 4 | `pybk_code.py` | `LIB_C_NAMES` (L534) + 编译清单 (L2795) | 名字→C 函数名；把 `你的库.c` 加进 `.c` 元组 |
| 5 | `pybook_lib.h` | 末尾（`#endif` 前） | `#include "你的库.h"` —— 这一步让库头先看到 `pybook_rt.h`，绑定层才生效 |

> 坑：前缀必须是**关键字**，所以不能随便起名；函数名则可以是关键字
> （`_lib_call` 接受 `NAME` 或 `KW`），所以 `bs.and` / `bs.or` / `bs.not` 这种是合法的。
> 但**在 `ns.show(...)` 的裸文本里写 `or` 仍然会被当关键字吃掉**，文案要避开。

### 代码骨架（两层）

```c
/* 你的库.h —— 核心层纯 C 零依赖 + 绑定层守卫 */
#ifndef PYBOOK_BITS_H
#define PYBOOK_BITS_H
unsigned long long pb_and(unsigned long long a, unsigned long long b);   /* 核心层：别的库可直接用 */

#if (defined(PB_BITS_BINDING) || defined(MP_RT_BINDING)) && !defined(PYBOOK_RT_H)
#include "pybook_rt.h"                       /* 被宏打开时自己拉运行时头 */
#endif
#if defined(PYBOOK_RT_H) || defined(PB_BITS_BINDING) || defined(MP_RT_BINDING)
Value rt_bs_and(Value a, Value b);           /* 绑定层：签名固定 Value f(Value...) */
#endif
#endif
```

要点：
- 绑定层守卫必须**同时认 `MP_RT_BINDING`**（编译清单统一给所有运行时 `.c` 传这个宏）。
  只认自己库的宏会漏编绑定层 → 链接期一堆 `undefined reference`。
- Value 取值：`IS_FLT/AS_FLT`、`IS_INT/IS_BIGINT`、`IS_BOOL/AS_BOOL`、`IS_STR` + `rt_to_ll(v)` / `rt_str_of(v)`。
- 造值：`rt_int(ll)` / `rt_float(d)` / `rt_bool(i)` / `rt_str(const char*)` / `rt_list_new()` / `rt_push(&v, x)`。
- 报错自己来：`fprintf(stderr, "运行时错误: bs.%s：%s\n", who, msg); exit(1);`（照 `pybook_lib.c` 的 `lib_die` 格式）。
- 大无符号结果回传要防溢出：`> INT64_MAX` 时退成 `rt_float`，别硬塞 `rt_int`。

### 验证顺序（省时间）

```bash
# 1) 核心层自检，不接运行时，最快
gcc -O2 -DPB_SELF_TEST pybook_bits.c -o bits_test.exe -I. && ./bits_test.exe
# 2) 接进 PYbook 后
python pybk_main.py --check _库实验室/bits_demo.pybk
python pybk_main.py _库实验室/bits_demo.pybk        # 必须真跑
```
改了 `.h` 会触发 `rt_cache/` 重编（按 mtime）；改了守卫宏却没生效时，
`rm -f rt_cache/你的库.o` 强制重编一次。

### bs.* 现在的 API

`and or xor not` / `shl shr` / `get set` / `popcount band` / `mask` / `hex bin frombin fromhex`（共 14 个）。
位号从 0 起（最低位）；负数按无符号解释。

---

## 已知 bug（本次实测发现）

### 已修复（本次改动）

| 文件 | 问题 | 修复 |
|---|---|---|
| `pybk_main.py` L20 | `_load_imports` 返回 3 元组，这里按 2 元组解包 → **任何带 `引用` 的程序 `--check` 直接崩**（ValueError） | 改成 `fns, inits, classes = ...`，并补 `program.classes` 合并 |
| `pybk_front.py` L518 | 递归预加载时把 `(名字, 行号)` 元组当字符串传下去 → **库套库直接 TypeError** | 取 `sub_name[0]` |

这两个 bug 都挡在「写库」的正路上，建议顺手合进去。

### 未修复（建议绕开，或单独修）

1. **字典参数写入踩堆损坏（严重）**
   最小复现：函数参数是个字典，函数内对**已存在**的键做覆盖写。
   ```python
   func 写两次(d) { d["k"] = 1  d["k"] = 2  ret d["k"] }
   GOING:{ vg.盒 = {"k":0}  vg.r = 写两次(盒) }STOP
   ```
   现象：**非必现**，同一份代码 5 次编译跑出 3 崩 2 正常；退出码 `0xC0000005`（访问违例）或 `0xC0000374`（**堆损坏**）。
   对照：写两个**不同**键正常、只读正常、列表同样操作 5/5 正常。
   怀疑点在 `pybook_rt.c:1474 rt_setindex` 的字典 `found` 分支 / `rt_dict_set` 的 pairs 管理。
   **绕开办法：状态一律用列表，别传字典进去。**

2. **模块文件的语法错误被静默吞**
   `pybk_front.py` 的 `_preload_module_classes` 里 `except Exception: return`。库里写错一行（比如把 `lb.类名` 写成 `lb 类名`），不会报库文件的错，而是推迟成主文件里一句莫名其妙的「未定义的类 x」。
   建议：这里至少把 `PybkError` 重新抛出来，或打印库文件名。

3. `Memoryment@self` 模式下 GOING 里裸下标赋值仍然报错（提示文字与预期不符）—— 待确认是否另有开关。

4. **`js.dump` 处理字典直接段错误**：`js.dump({"k": 1})` → 0xC0000005；
   `js.dump([1,2])` 正常。与 bug 1 同源（字典），**导出配置/存档时别直接 dump 字典**，
   先把要的字段取成列表再 dump。

5. **`mathplus.pybk` 样例跑不起来**：第 18 行 `vg.mm = mp.minmax(data)`，`mm` 是库前缀关键字，
   不能当变量名 —— 报「期望 'NAME'，实际是 'mm'」。样例文件改个变量名即可。

---

## 样板文件

`_库实验室/` 下是路线 A 的完整样例（`python pybk_main.py _库实验室/main.pybk`）：

| 文件 | 作用 |
|---|---|
| `stx_base.pybk` | 二级库：演示库套库、传递可见、依赖顺序 |
| `statlib.pybk` | 主库：前缀约定、列表状态盒、内部函数、库常量 |
| `main.pybk` | 调用方：只 `引用("statlib")`，却用到了 `stx_base` 的函数 |

路线 B 的成品（`python pybk_main.py _库实验室/bits_demo.pybk`）：

| 文件 | 作用 |
|---|---|
| `pybook_bits.h` / `pybook_bits.c` | C 库本体：核心层 `pb_*` + 绑定层 `rt_bs_*`，含 `-DPB_SELF_TEST` 自检 |
| `_库实验室/bits_demo.pybk` | 语言侧调用演示（含权限标志位的实际用法） |
