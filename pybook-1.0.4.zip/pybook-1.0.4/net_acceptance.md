# net 网络模块（TCP 行协议）交付与验收说明

## 交付物
- `pybook_net.c`（新建）：rt_net_listen / rt_net_accept / rt_net_connect /
  rt_net_read（非阻塞 recv）/ rt_net_read_block（阻塞 readline）/
  rt_net_write（send，原样字节）/ rt_net_close
- `pybook_lib.h`（追加）：net 七函数声明（与音模块同款风格）
- `pybk_front.py`（三处注册）：KEYWORDS += 'net'；LIB_PREFIXES += 'net'；
  LIB_CALLS += listen/accept/connect/recv/readline/send/close 七条
- `pybk_code.py`：LIB_C_NAMES 七条映射（net.recv→rt_net_read、
  net.readline→rt_net_read_block、net.send→rt_net_write）；运行时源列表
  加 pybook_net.c；链接加 -lws2_32
- 备份：`pybk_front.py.bak`（动手前快照，红线要求的 .bak）

## 实现要点（对照任务要求）
1. 独立文件 pybook_net.c，未触碰 pybook_rt.c；gcc 源列表加 pybook_net.c、
   链接加 -lws2_32。
2. **每句柄接收缓冲**：句柄表是 `{SOCKET sock; char buf[65536]; size_t len}`
   数组（上限 64 句柄），recv 进缓冲、按 \n 切行、半行留在缓冲；
   非阻塞模式（ioctlsocket FIONBIO）。
3. WSAStartup 惰性初始化（首次调 net.* 时），`atexit(WSACleanup)`。
4. UTF-8：收发字节原样进出字符串盒；连接地址经 MultiByteToWideChar 转
   UTF-16 后 GetAddrInfoW 解析（支持域名）。
5. 阻塞函数（accept/readline）= 非阻塞调用 + Sleep(1) 循环，无线程。
6. 语言层 `net.send` 的"自动补 \n"在 codegen 层完成：
   `rt_net_write(句, rt_add(文本, rt_str("\n")))`——rt_net_write 本身发原样
   字节，这让 C 层自测可以构造真正的半包场景。

## 验收输出（全部实测）

### 1. 双进程探针（整行协议）
服务端 `__net_srv.pybk`（listen 7777 → accept → readline → 回发 → close）：
```
收到 hello server
```
客户端 `__net_cli.pybk`（connect → send → readline → close）：
```
回 hello client
```
两进程各自独立编译、独立运行，退出码均 0。

### 2. 非阻塞验证（服务端实测输出）
```
100次recv耗时毫秒=0
非阻塞验证通过
对端关闭后=断
```
连接后客户端不发数据，服务端 net.recv 循环 100 次全部返回空串、
tm.now() 差值 0ms（< 200ms，证明未阻塞）；客户端关闭后服务端
net.recv 返回 "断"。

### 3. 半包验证（C 层自测，-DNET_SELF_TEST）
```
net 自测：通过 106 项，失败 0 项
```
覆盖：非阻塞 100 次 recv 全空且耗时 <200ms；客户端先发 "abc"（无 \n，
经 rt_net_write 原样字节）服务端不上交半行；隔 30ms 再发 "def\n" 后
net.recv 收到完整一行 "abcdef"；阻塞 readline 整行；对端 close 后返回 "断"。

说明：语言层 net.send 按规格"自动补 \n"（codegen 层实现），PYbook 源码
无法表达不带换行的裸发送，因此半包场景在 C 层自测中驱动（语义与语言层
完全一致：同一条 rt_net_write 路径 + 同一个每句柄接收缓冲）。

### 4. 回归
- `python pybk_front.py`：自测全过（分支链/when/$插值/裸 ret/web/lb 类/
  帧动画/go/key/模块引用 均正确，错误带行号）。
- `python pybk_main.py games/飞船大战.pybk`：正常启动运行，ESC 退出码 0。
- `python tests/run_tests.py`：**96/96 全过**（gcc 链接新增 pybook_net.c +
  -lws2_32 后无任何回归；pybook_net.o 走既有 rt_cache 缓存机制）。

## Windows 防火墙
首次 net.listen 时 Windows 防火墙可能弹"是否允许访问网络"提示，点允许即可；
仅监听 127.0.0.1 回环时实际不经防火墙，弹窗属系统正常行为。

## 已知边界
- 句柄上限 64 个（句柄表容量）；单行上限 64KB（接收缓冲容量，溢出报错退出）。
- net.recv 对端关闭但缓冲里还有无换行的残余字节时，会把残余作为最后一行
  返回，之后才返回 "断"（半行数据不丢）。
- net.listen 端口需 INT；地址/内容需字符串（类型错误带原因退出）。
