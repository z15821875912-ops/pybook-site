# -*- coding: utf-8 -*-
"""披萨塔 v2 音乐：狂奔 BGM（152BPM 放克）+ 逃亡 BGM（168BPM 紧迫）+ 全套音效。
输出 games/披萨塔2/*.wav。纯正弦/方波/三角/噪声合成，无依赖。"""
import wave
import math
import os
import struct
import random

SR = 22050
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "games", "披萨塔2")
os.makedirs(OUT, exist_ok=True)


def midi(n):
    return 440.0 * (2 ** ((n - 69) / 12.0))


def sq(f, t):
    return 1.0 if math.sin(2 * math.pi * f * t) >= 0 else -1.0


def tri(f, t):
    return (2.0 / math.pi) * math.asin(math.sin(2 * math.pi * f * t))


def 渲染(bpm, 小节, 主旋律, 贝斯, 主音色=sq, 贝音色=tri, 主量=0.30, 贝量=0.26):
    """主旋律/贝斯：[(十六分位置, 音高或None, 十分音符长)]。"""
    拍 = 60.0 / bpm
    十六 = 拍 / 4
    总长 = 小节 * 4 * 拍
    n = int(总长 * SR)
    out = [0.0] * n
    for 序列, 音色, 量 in ((主旋律, 主音色, 主量), (贝斯, 贝音色, 贝量)):
        for (pos, pitch, dur) in 序列:
            t0 = pos * 十六
            i0 = int(t0 * SR)
            i1 = int((t0 + dur * 十六 * 0.92) * SR)
            if pitch is None or i1 <= i0:
                continue
            f = midi(pitch)
            for i in range(i0, min(i1, n)):
                t = i / SR - t0
                包 = min(1.0, t * 90) * min(1.0, (i1 - i) / SR * 60)
                out[i] += 音色(f, t) * 量 * 包
    # 鼓：底鼓每拍，军鼓 2/4 拍，踩镲八分
    for bar in range(小节):
        for beat in range(4):
            t0 = (bar * 4 + beat) * 拍
            i0 = int(t0 * SR)
            for i in range(i0, min(i0 + int(0.10 * SR), n)):
                t = (i - i0) / SR
                out[i] += math.sin(2 * math.pi * 58 * t) * math.exp(-t * 26) * 0.5
            if beat in (1, 3):
                for i in range(i0, min(i0 + int(0.09 * SR), n)):
                    t = (i - i0) / SR
                    out[i] += (random.random() * 2 - 1) * math.exp(-t * 34) * 0.28
            for 半 in range(2):
                t0h = t0 + 半 * 拍 / 2
                ih = int(t0h * SR)
                for i in range(ih, min(ih + int(0.03 * SR), n)):
                    t = (i - ih) / SR
                    out[i] += (random.random() * 2 - 1) * math.exp(-t * 120) * 0.12
    return out


def 写wav(名, data):
    峰 = max(1e-9, max(abs(v) for v in data))
    k = 0.92 / 峰
    with wave.open(os.path.join(OUT, 名), "w") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes(b"".join(struct.pack("<h", int(v * k * 32767)) for v in data))


# ---- 狂奔 BGM：A 段动机 x2 + B 段回应（16 小节循环）----
A主 = [(0, 69, 2), (2, 69, 1), (3, 72, 1), (4, 74, 2), (6, 72, 1), (7, 69, 1),
       (8, 67, 2), (10, 69, 1), (11, 72, 1), (12, 74, 3), (15, 76, 1)]
A贝 = [(0, 45, 3), (4, 45, 2), (6, 52, 1), (8, 43, 3), (12, 47, 3)]
B主 = [(0, 76, 2), (2, 74, 1), (3, 72, 1), (4, 69, 4), (8, 72, 2), (10, 74, 1),
       (11, 76, 1), (12, 79, 3)]
B贝 = [(0, 41, 3), (4, 48, 2), (8, 43, 3), (12, 45, 3)]
主旋律 = A主 + [(pos + 16, p, d) for (pos, p, d) in A主] \
    + [(pos + 32, p, d) for (pos, p, d) in B主] + [(pos + 48, p, d) for (pos, p, d) in B主]
贝斯全 = A贝 + [(pos + 16, p, d) for (pos, p, d) in A贝] \
    + [(pos + 32, p, d) for (pos, p, d) in B贝] + [(pos + 48, p, d) for (pos, p, d) in B贝]
写wav("乐_狂奔.wav", 渲染(152, 16, 主旋律, 贝斯全))

# ---- 逃亡 BGM：更急的小调（16 小节）----
逃主 = [(0, 76, 1), (1, 76, 1), (2, 79, 2), (4, 76, 1), (5, 74, 1), (6, 72, 2),
        (8, 74, 1), (9, 74, 1), (10, 77, 2), (12, 74, 1), (13, 72, 1), (14, 69, 2)]
逃贝 = [(0, 40, 2), (2, 40, 1), (4, 47, 2), (8, 38, 2), (10, 38, 1), (12, 45, 2)]
逃全 = 逃主 + [(pos + 16, p, d) for (pos, p, d) in 逃主] \
    + [(pos + 32, p, d) for (pos, p, d) in 逃主] + [(pos + 48, p, d) for (pos, p, d) in 逃主]
逃贝全 = 逃贝 + [(pos + 16, p, d) for (pos, p, d) in 逃贝] \
    + [(pos + 32, p, d) for (pos, p, d) in 逃贝] + [(pos + 48, p, d) for (pos, p, d) in 逃贝]
写wav("乐_逃亡.wav", 渲染(168, 16, 逃全, 逃贝全, 主量=0.32, 贝量=0.30))

# ---- 音效 ----
def 音效(名, 时长, 函数):
    n = int(时长 * SR)
    data = [函数(i / SR, 时长) for i in range(n)]
    写wav(名, data)


音效("效_跳.wav", 0.14, lambda t, T: math.sin(2 * math.pi * (300 + 500 * (t / T)) * t) * (1 - t / T) * 0.6)
音效("效_抓.wav", 0.10, lambda t, T: (random.random() * 2 - 1) * (1 - t / T) * 0.4)
音效("效_砸.wav", 0.22, lambda t, T: math.sin(2 * math.pi * (110 - 70 * t / T) * t) * (1 - t / T) * 0.7)
音效("效_碎.wav", 0.16, lambda t, T: (random.random() * 2 - 1) * (1 - t / T) ** 2 * 0.55)
音效("效_料.wav", 0.12, lambda t, T: math.sin(2 * math.pi * (660 + 400 * t / T) * t) * (1 - t / T) * 0.5)
音效("效_连击.wav", 0.14, lambda t, T: math.sin(2 * math.pi * (500 + 600 * (t / T)) * t) * (1 - t / T) * 0.55)
音效("效_挑.wav", 0.18, lambda t, T: sq(620, t) * (1 - t / T) * 0.4)
音效("效_超挑.wav", 0.5, lambda t, T: sq(220 + 440 * min(1, t * 3), t) * (1 - t / T) * 0.5)
音效("效_伤.wav", 0.3, lambda t, T: math.sin(2 * math.pi * (200 - 120 * t / T) * t) * (1 - t / T) * 0.65)
音效("效_门.wav", 0.6, lambda t, T: tri(330 + 260 * t, t) * (1 - t / T) * 0.5)
音效("效_警.wav", 0.4, lambda t, T: sq(880 if (int(t * 10) % 2) else 660, t) * (1 - t / T) * 0.4)

print("音乐完成：", len([f for f in os.listdir(OUT) if f.endswith('.wav')]), "个 wav")
