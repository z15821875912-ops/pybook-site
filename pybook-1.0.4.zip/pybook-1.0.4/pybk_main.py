import json
import sys

from pybk_front import PybkError, parse
from pybk_code import compile_and_run, PybkCodegenError


def die(msg):
    print(msg, file=sys.stderr)
    sys.exit(1)


def _完整编译(源码):
    """解析 + 代码生成（不产出 .c 文件、不 gcc、不运行）。
    被 --check 用：静态错误在这一步全部暴露。"""
    program = parse(源码)
    if program.imports:
        import os
        base = os.path.dirname(os.path.abspath(sys.argv[-1])) or '.'
        fns, inits, classes = __import__('pybk_code')._load_imports(program, base, ['<主文件>'])
        program.fns = fns + (program.fns or [])
        program.go_body = inits + (program.go_body or [])
        program.classes = classes + (program.classes or [])
    return __import__('pybk_code').Codegen().generate(program)


def main():
    argv = sys.argv[1:]
    check = False
    paths = []
    for a in argv:
        if a == '--check':
            check = True
        elif a == '--check-json':
            check = 'json'
        elif a.startswith('-'):
            die(f"未知选项: {a}")
        else:
            paths.append(a)
    if not paths:
        die("用法: python pybk_main.py [--check|--check-json] 程序.pybk")
    try:
        src = open(paths[0], encoding="utf-8-sig").read()
    except FileNotFoundError:
        die(f"找不到文件: {paths[0]}")

    if check:
        try:
            _完整编译(src)
        except (PybkError, PybkCodegenError) as e:
            msg = str(e)
            if check == 'json':
                import re
                m = re.search(r'第 (\d+) 行', msg)
                print(json.dumps({"ok": False,
                                  "line": int(m.group(1)) if m else None,
                                  "message": msg}, ensure_ascii=False))
            else:
                print("编译失败: " + msg)
            sys.exit(1)
        except RecursionError:
            msg = "表达式或嵌套太深，请拆分后再试"
            if check == 'json':
                print(json.dumps({"ok": False, "line": None, "message": msg},
                                 ensure_ascii=False))
            else:
                print("编译失败: " + msg)
            sys.exit(1)
        if check == 'json':
            print(json.dumps({"ok": True, "message": "编译通过（语法+语义；未 gcc 未运行）"},
                             ensure_ascii=False))
        else:
            print("编译通过（语法 + 语义检查；未 gcc 未运行）")
        return

    try:
        compile_and_run(src)
    except PybkError as e:          # 前端语法/词法错误
        die(str(e))
    except PybkCodegenError as e:   # 语义/编译错误
        die(str(e))
    except RuntimeError as e:       # 程序运行时错误
        die(str(e))
    except RecursionError:
        die("表达式或嵌套太深，请拆分后再试")


main()
