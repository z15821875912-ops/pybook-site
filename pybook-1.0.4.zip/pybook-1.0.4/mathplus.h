/* =============================================================================
 * mathplus — PYbook 原生扩展「math+」模块（C 实现）
 * -----------------------------------------------------------------------------
 * 两层结构：
 *
 *   [1] 核心层 (mp_*)：纯 C，double* 行主序缓冲，零 PYbook 运行时依赖。
 *       numpybk / torchbk / 3D_highway 这类重库直接 #include 本头文件后调用，
 *       无需链接 pybook_rt，也不需要任何分配策略假设（输出缓冲一律由调用方提供）。
 *
 *   [2] 绑定层 (rt_lib_mp_*)：把 PYbook 的 Value 列表 <-> double* 互转，
 *       挂进前端 `mp.` 命名空间。仅在「已包含 pybook_rt.h」时可见/编译。
 *
 * 编译：
 *   核心自测（无运行时）: gcc -O2 mathplus_test.c mathplus.c -o mp_test
 *   PYbook 接驳          : 在 pybk_code.py 的源清单里加 mathplus.c，
 *                          并 #include "mathplus.h"（在 pybook_lib.h 之后）。
 *   绑定层符号仅在 PYBOOK_RT_H 已定义时参与编译。
 * ========================================================================== */

#ifndef MATHPLUS_H
#define MATHPLUS_H

#include <stdint.h>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

#ifdef __cplusplus
extern "C" {
#endif

/* =============================================================================
 * [1] 核心层：向量 (double*, 长度 n)
 * ========================================================================== */

void   mp_vec_add(const double *a, const double *b, double *out, int n);
void   mp_vec_sub(const double *a, const double *b, double *out, int n);
void   mp_vec_scale(const double *a, double s, double *out, int n);
double mp_vec_dot(const double *a, const double *b, int n);
double mp_vec_norm(const double *a, int n);                 /* L2 范数 */
double mp_vec_dist(const double *a, const double *b, int n);
void   mp_vec_cross(const double *a, const double *b, double out[3]); /* 仅 3D */
void   mp_vec_lerp(const double *a, const double *b, double *out, int n, double t);

/* =============================================================================
 * [1] 核心层：矩阵 (double* 行主序, r 行 c 列)
 * ========================================================================== */

void   mp_mat_add(const double *a, const double *b, double *out, int r, int c);
void   mp_mat_scale(const double *a, double s, double *out, int r, int c);
void   mp_mat_mul(const double *a, const double *b, double *out,
                  int r, int m, int c);                      /* a:r×m  b:m×c -> out:r×c */
void   mp_mat_transpose(const double *a, double *out, int r, int c);
void   mp_mat_identity(double *out, int n);
void   mp_mat_vec_mul(const double *a, const double *x, double *out, int r, int c);
double mp_mat_det(const double *a, int n);                  /* 部分主元 LU，n<=16 */
int    mp_mat_inverse(const double *a, double *out, int n); /* 0=成功 -1=奇异 */

/* 3D 辅助（行主序 3×3 / 4×4，函数内按列填充方便与 OpenGL 风格矩阵对接） */
void   mp_mat_rot_x(double *out, double ang);   /* 3×3 */
void   mp_mat_rot_y(double *out, double ang);   /* 3×3 */
void   mp_mat_rot_z(double *out, double ang);   /* 3×3 */
void   mp_mat_perspective(double *out, double fovy, double aspect,
                          double zn, double zf); /* 4×4 透视（右手，z∈[-1,1]） */
void   mp_mat_translate(double *out, double x, double y, double z); /* 4×4 */

/* =============================================================================
 * [1] 核心层：统计 / 变换 / 标量
 * ========================================================================== */

double mp_sum(const double *a, int n);
double mp_mean(const double *a, int n);
double mp_var(const double *a, int n, int ddof);  /* ddof=0 总体, 1 样本 */
double mp_std(const double *a, int n, int ddof);
void   mp_minmax(const double *a, int n, double *mn, double *mx);
void   mp_linspace(double *out, int n, double lo, double hi);

double mp_clamp(double v, double lo, double hi);
double mp_mix(double a, double b, double t);                 /* = 标量 lerp */
double mp_smoothstep(double e0, double e1, double x);
double mp_sign(double x);
double mp_radians(double deg);
double mp_degrees(double rad);

/* =============================================================================
 * [1] 核心层：随机数（自带 xorshift128 PRNG，独立于标准库 rd，便于撮合不冲突）
 * ========================================================================== */

void   mp_rand_seed(uint64_t s);
double mp_rand_u01(void);                 /* [0,1) */
double mp_rand_normal(double mean, double sd); /* Box-Muller */

/* =============================================================================
 * [2] 绑定层：仅当已包含 pybook_rt.h（即 PYBOOK_RT_H 已定义）或定义了
 *     MP_RT_BINDING 时声明/编译。在 PYbook 里以 `mp.xxx(...)` 调用，对应
 *     rt_lib_mp_xxx。矩阵在 PYbook 侧以「扁平列表 + 维度」传递（与 numpy 的
 *     flatten 一致）。
 * ========================================================================== */
#if defined(PYBOOK_RT_H) || defined(MP_RT_BINDING)

/* 向量 */
Value rt_lib_mp_vec_add(Value a, Value b);     /* mp.vec_add(a,b)   -> 列表 */
Value rt_lib_mp_vec_sub(Value a, Value b);     /* mp.vec_sub(a,b)   -> 列表 */
Value rt_lib_mp_vec_scale(Value a, Value s);   /* mp.vec_scale(a,s) -> 列表 */
Value rt_lib_mp_vec_dot(Value a, Value b);     /* mp.vec_dot(a,b)   -> 浮点 */
Value rt_lib_mp_vec_norm(Value a);             /* mp.vec_norm(a)    -> 浮点 */
Value rt_lib_mp_vec_dist(Value a, Value b);    /* mp.vec_dist(a,b)  -> 浮点 */
Value rt_lib_mp_vec_cross(Value a, Value b);   /* mp.vec_cross(a,b) -> 列表[3] */
Value rt_lib_mp_vec_lerp(Value a, Value b, Value t); /* mp.vec_lerp(a,b,t) -> 列表 */

/* 矩阵 */
Value rt_lib_mp_mat_add(Value a, Value b, Value r, Value c);          /* mp.mat_add(a,b,r,c) */
Value rt_lib_mp_mat_scale(Value a, Value s, Value r, Value c);        /* mp.mat_scale(a,s,r,c) */
Value rt_lib_mp_mat_mul(Value a, Value b, Value r, Value m, Value c); /* mp.mat_mul(a,b,r,m,c) */
Value rt_lib_mp_mat_transpose(Value a, Value r, Value c);            /* mp.mat_transpose(a,r,c) */
Value rt_lib_mp_mat_identity(Value n);                               /* mp.mat_identity(n) -> 列表 */
Value rt_lib_mp_mat_det(Value a, Value n);                           /* mp.mat_det(a,n) -> 浮点 */
Value rt_lib_mp_mat_inverse(Value a, Value n);                       /* mp.mat_inverse(a,n) -> 列表 */
Value rt_lib_mp_mat_vec_mul(Value a, Value x, Value r, Value c);     /* mp.mat_vec_mul(a,x,r,c) */

/* 统计 */
Value rt_lib_mp_mean(Value list);                       /* mp.mean(list) */
Value rt_lib_mp_var(Value list, Value ddof);            /* mp.var(list,ddof) */
Value rt_lib_mp_std(Value list, Value ddof);            /* mp.std(list,ddof) */
Value rt_lib_mp_sum(Value list);                        /* mp.sum(list) */
Value rt_lib_mp_minmax(Value list);                     /* mp.minmax(list) -> [min,max] */
Value rt_lib_mp_linspace(Value lo, Value hi, Value n);  /* mp.linspace(lo,hi,n) -> 列表 */

/* 标量/变换 */
Value rt_lib_mp_clamp(Value v, Value lo, Value hi);     /* mp.clamp(v,lo,hi) */
Value rt_lib_mp_smoothstep(Value e0, Value e1, Value x);/* mp.smoothstep(e0,e1,x) */
Value rt_lib_mp_lerp(Value a, Value b, Value t);        /* mp.lerp(a,b,t) */
Value rt_lib_mp_radians(Value deg);                     /* mp.radians(deg) */
Value rt_lib_mp_degrees(Value rad);                     /* mp.degrees(rad) */

/* 随机 */
Value rt_lib_mp_rand_seed(Value s);        /* mp.rand_seed(s) */
Value rt_lib_mp_rand_u01(void);            /* mp.rand_u01() */
Value rt_lib_mp_rand_normal(Value m, Value sd); /* mp.rand_normal(m,sd) */

#endif /* PYBOOK_RT_H */

#ifdef __cplusplus
}
#endif

#endif /* MATHPLUS_H */
