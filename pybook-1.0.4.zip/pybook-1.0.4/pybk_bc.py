"""PYbook 字节码编译后端：pybk_front.parse() 的 AST -> .pybc 字节码。

只编译，不运行：虚拟机是同事的 C 代码。不修改 pybk_front.py。
仅用 Python 标准库。

对合同中未定死语义的两处约定（VM 同事请对齐）：
- MAGIC u16：操作数是 magic 参数串（逗号连接，如 'b,c=0,200,255'）的常量池索引。
- 函数表里的代码偏移：相对代码区起点（不是相对文件头）。

已知边界：前端文法没有列表字面量和 lock/del 语句，所以 LIST_NEW 一族
（规则9）与 GOLD/DEL 指令经 parse() 不可达；这里仍完整支持指令编码与反汇编。
样例中的 vg_ro / [1,2,3] 前端无法解析，自测用了等价的合法写法（见文件尾）。
"""

import struct
import dataclasses

from pybk_front import (
    parse, PybkError,
    Program, FnDef, NumLit, StrLit, BoolLit, VarRef, BinOp, Unary, Call,
    InputExpr, Ret, VgAssign, IpAssign, NsShow, Around, Aging, CdBlock,
    VcChain, ListLit, DictLit, Index, AssignIndex, GoldDel, MemoryMode, HmStmt,
    ForIn, HmDraw, HmLive, HmFrame, HmPlay, GoStmt,
    LIB_PREFIXES,
    LIB_CALLS,
)

MAGIC = b'PYBC'
VERSION = 1

T_INT, T_FLOAT, T_STR = 1, 2, 3

# ---- 指令表：opcode -> (助记符, 操作数规格串) ----
# 规格：'' 无操作数；'U' u16；'B' u8；'I' i32
OPS = {
    0x00: ('NOP', ''),
    0x01: ('HALT', ''),
    0x02: ('CONST', 'U'),
    0x03: ('LOAD', 'U'),
    0x04: ('STORE', 'U'),
    0x05: ('DUP', ''),
    0x06: ('POP', ''),
    0x10: ('ADD', ''), 0x11: ('SUB', ''), 0x12: ('MUL', ''),
    0x13: ('DIV', ''), 0x14: ('FDIV', ''), 0x15: ('MOD', ''),
    0x16: ('NEG', ''), 0x17: ('NOT', ''),
    0x18: ('EQ', ''), 0x19: ('NE', ''), 0x1A: ('LT', ''),
    0x1B: ('GT', ''), 0x1C: ('LE', ''), 0x1D: ('GE', ''),
    0x1E: ('JUMP', 'I'),
    0x1F: ('JUMP_IF_FALSE', 'I'),
    0x20: ('JUMP_IF_TRUE', 'I'),
    0x21: ('SHOW_TEXT', 'U'),
    0x22: ('SHOW_VALUE', ''),
    0x23: ('MAGIC', 'U'),
    0x24: ('SHOW_END', ''),
    0x25: ('LIST_NEW', ''),
    0x26: ('LIST_APPEND', ''),
    0x27: ('LEN', ''),
    0x28: ('INDEX', ''),
    0x29: ('SETIDX', ''),
    0x2A: ('INPUT', 'U'),
    0x2B: ('AROUND_INIT', 'UU'),
    0x2C: ('AROUND_STEP', 'UUI'),
    0x2D: ('DICT_NEW', ''),
    0x2E: ('DICT_SET', ''),
    0x30: ('CALL', 'UB'),
    0x31: ('RET', ''),
    0x32: ('RET_NONE', ''),
    0x33: ('GOLD', 'U'),
    0x34: ('DEL', 'U'),
    0x35: ('SETMEM', 'B'),
    0x36: ('CALL_LIB', 'UB'),   # 库名常量索引 u16 + 实参个数 u8
}

_BINOP = {'+': 0x10, '-': 0x11, '*': 0x12, '/': 0x13,
          '//': 0x14, '%': 0x15,
          '==': 0x18, '!=': 0x19, '<': 0x1A, '>': 0x1B,
          '<=': 0x1C, '>=': 0x1D}

INT64_MIN, INT64_MAX = -2 ** 63, 2 ** 63 - 1


class CompileError(Exception):
    """编译期语义错误，信息带行号。"""


def _chk_u16(v, what, line):
    if not 0 <= v <= 0xFFFF:
        raise CompileError(f"第 {line} 行：{what} 超出 u16 范围：{v}")
    return v


def _chk_u8(v, what, line):
    if not 0 <= v <= 0xFF:
        raise CompileError(f"第 {line} 行：{what} 超出 u8 范围：{v}")
    return v


# ---------------------------------------------------------------- 函数代码生成

class _FnGen:
    def __init__(self, comp, name, params):
        self.comp = comp                  # 取常量池用
        self.name = name
        self.params = list(params)
        self.slots = {}                   # 变量名 -> 槽号
        for p in self.params:
            self.slots[p] = len(self.slots)
        self.loops = []                   # 内层在尾：每层 around 的 at 槽号
        self.buf = bytearray()
        self.fixups = []                  # (操作数在 buf 中的偏移, 目标 label)

    # ---- 槽位 ----

    def new_slot(self, name):
        if len(self.slots) >= 0x10000:
            raise CompileError(f"函数 {self.name!r}：槽位数超过 u16 上限")
        s = len(self.slots)
        self.slots[name] = s
        return s

    def resolve(self, name, line):
        fv = getattr(self, 'forvars', [])
        for vname, slot in reversed(fv):  # 最内层 for-in 变量遮蔽外层同名
            if vname == name:
                return slot
        if name == 'at' and self.loops:   # 最内层 around 的 at 遮蔽同名变量
            return self.loops[-1]
        if name in self.slots:
            return self.slots[name]
        raise CompileError(f"第 {line} 行：未声明的变量 {name!r}")

    # ---- 发射 ----

    def here(self):
        return len(self.buf)

    def emit(self, op, spec=''):
        self.buf.append(op)
        for ch in spec:
            if ch == 'U':
                self.buf += b'\x00\x00'
            elif ch == 'I':
                self.buf += b'\x00\x00\x00\x00'
            elif ch == 'B':
                self.buf.append(0)

    def set_u16(self, op_pos, operand_pos, v, line):
        _chk_u16(v, '操作数', line)
        struct.pack_into('<H', self.buf, op_pos + operand_pos, v)

    def jump(self, op):
        """发射跳转（偏移占位），返回 fixup 句柄。"""
        pos = len(self.buf)
        self.emit(op, 'I')
        self.fixups.append([pos + 1, None])
        return len(self.fixups) - 1

    def place(self):
        """当前地址作为 label，返回句柄给 patch 用。"""
        return len(self.buf)

    def patch(self, handle, label):
        self.fixups[handle][1] = label

    def resolve_fixups(self):
        for op_pos, label in self.fixups:
            struct.pack_into('<i', self.buf, op_pos,
                             label - (op_pos + 4))   # 偏移相对下一条指令


# ---------------------------------------------------------------- 编译器

class _Compiler:
    def __init__(self, prog: Program):
        self.prog = prog
        self.consts = []                  # (类型, 值)
        self.cidx = {}                    # (类型, 值) -> 索引（去重）
        # 函数 0 = GOING 主程序，之后每个 fv 按出现顺序
        self.fns = [_FnGen(self, 'main', [])]
        self.fn_index = {}
        for f in prog.fns:
            if f.name in self.fn_index or f.name == 'main':
                raise CompileError(f"第 {f.line} 行：重复的函数定义 {f.name!r}")
            if f.name in ('长度', '添加'):
                raise CompileError(f"第 {f.line} 行：函数名 {f.name!r} 是内置函数，不能定义")
            self.fn_index[f.name] = len(self.fns)
            self.fns.append(_FnGen(self, f.name, f.params))

    # ---- 常量池 ----

    def const(self, typ, val):
        key = (typ, val)
        if key in self.cidx:
            return self.cidx[key]
        if len(self.consts) >= 0x10000:
            raise CompileError("常量池超过 65536 项")
        idx = len(self.consts)
        self.consts.append(key)
        self.cidx[key] = idx
        return idx

    # ---- 语句 ----

    def compile_stmts(self, fg, stmts):
        # 规则7：本层的 when 块全部摘出，按 priority 升序稳定排序提到最前
        cds = sorted((s for s in stmts if isinstance(s, CdBlock)),
                     key=lambda c: c.priority)
        rest = [s for s in stmts if not isinstance(s, CdBlock)]
        for cd in cds:
            self.compile_stmt(fg, cd)
        for s in rest:
            self.compile_stmt(fg, s)

    def compile_stmt(self, fg, s):
        if isinstance(s, VgAssign):
            self.compile_expr(fg, s.expr)
            fg.emit(0x04, 'U')
            fg.set_u16(len(fg.buf) - 3, 1, fg.slots[s.name], s.line)
        elif isinstance(s, IpAssign):
            fg.emit(0x2A, 'U')
            fg.set_u16(len(fg.buf) - 3, 1, self.const(T_STR, s.prompt), s.line)
            fg.emit(0x04, 'U')
            fg.set_u16(len(fg.buf) - 3, 1, fg.slots[s.name], s.line)
        elif isinstance(s, NsShow):
            self.compile_ns(fg, s)
        elif isinstance(s, Around):
            self.compile_around(fg, s)
        elif isinstance(s, ForIn):
            self.compile_forin(fg, s)
        elif isinstance(s, (HmDraw, HmFrame, HmPlay, HmLive, GoStmt)):
            raise CompileError(f"第 {s.line} 行：web 网页语句只在原生模式里支持（VM 是终端模式）")
        elif isinstance(s, Aging):
            self.compile_aging(fg, s)
        elif isinstance(s, CdBlock):
            self.compile_stmts(fg, s.body)
        elif isinstance(s, VcChain):
            self.compile_vc(fg, s)
        elif isinstance(s, AssignIndex):
            slot = fg.resolve(s.name, s.line)
            self.compile_expr(fg, s.index)
            self.compile_expr(fg, s.expr)
            fg.emit(0x29)
        elif isinstance(s, GoldDel):
            slot = fg.resolve(s.name, s.line)
            fg.emit(0x33 if s.kind == 'gold' else 0x34, 'U')
            fg.set_u16(len(fg.buf) - 3, 1, slot, s.line)
        elif isinstance(s, MemoryMode):
            fg.emit(0x35, 'B')
            fg.buf[-1] = s.mode
        elif isinstance(s, HmStmt):
            raise CompileError(f"第 {s.line} 行：hm 网页语句暂不支持 VM 模式，请用原生模式（F5）")
        elif isinstance(s, Ret):
            if fg.name == 'main':
                raise CompileError(f"第 {s.line} 行：ret 不能出现在 GOING 主程序里")
            if s.expr is not None:
                self.compile_expr(fg, s.expr)
                fg.emit(0x31)
            else:
                fg.emit(0x32)
        elif isinstance(s, Call):
            self.compile_expr(fg, s)
            fg.emit(0x06)                              # 语句级调用，丢弃返回值
        else:
            raise CompileError(f"第 {getattr(s, 'line', 0)} 行：不可编译的语句 {type(s).__name__}")

    def compile_ns(self, fg, s: NsShow):
        if s.magic:
            fg.emit(0x23, 'U')
            fg.set_u16(len(fg.buf) - 3, 1,
                       self.const(T_STR, ','.join(s.magic)), s.line)
        for kind, val in s.parts:
            if kind == 'TEXT':
                fg.emit(0x21, 'U')
                fg.set_u16(len(fg.buf) - 3, 1, self.const(T_STR, val), s.line)
            elif kind == 'EXPR':                       # 完整表达式插值
                self.compile_expr(fg, val)
                fg.emit(0x22)
            else:                                      # VAR 单变量插值
                slot = fg.resolve(val, s.line)
                fg.emit(0x03, 'U')
                fg.set_u16(len(fg.buf) - 3, 1, slot, s.line)
                fg.emit(0x22)
        fg.emit(0x24)

    def compile_around(self, fg, s: Around):
        self.compile_expr(fg, s.times)
        self._hid = getattr(self, '_hid', 0)
        at = fg.new_slot(f'@at{self._hid}')
        cnt = fg.new_slot(f'@cnt{self._hid}')
        self._hid += 1
        fg.loops.append(at)
        fg.emit(0x2B, 'UU')
        base = len(fg.buf) - 5
        fg.set_u16(base, 1, at, s.line)
        fg.set_u16(base, 3, cnt, s.line)
        body = fg.place()
        self.compile_stmts(fg, s.body)
        fg.emit(0x2C, 'UUI')
        base = len(fg.buf) - 9
        fg.set_u16(base, 1, at, s.line)
        fg.set_u16(base, 3, cnt, s.line)
        # 偏移域在 base+5，相对下一条指令回跳到循环体首
        fg.fixups.append([base + 5, body])
        fg.loops.pop()

    def compile_forin(self, fg, s: ForIn):
        """for x in 列表 { ... }：列表存进隐藏槽，次数走 LEN，
        每轮 at 当下标用 INDEX 取元素存进本轮专属槽（遮蔽外层同名）。"""
        hid = getattr(self, '_hid', 0)
        self._hid = hid + 1
        lst = fg.new_slot(f'@lst{hid}')
        at = fg.new_slot(f'@at{hid}')
        cnt = fg.new_slot(f'@cnt{hid}')
        varslot = fg.new_slot(f'@for{hid}:{s.var}')
        self.compile_expr(fg, s.iter)
        fg.emit(0x04, 'U')
        fg.set_u16(len(fg.buf) - 3, 1, lst, s.line)
        fg.emit(0x03, 'U')
        fg.set_u16(len(fg.buf) - 3, 1, lst, s.line)
        fg.emit(0x27)                              # LEN → 次数压栈
        fg.loops.append(at)
        fg.emit(0x2B, 'UU')
        base = len(fg.buf) - 5
        fg.set_u16(base, 1, at, s.line)
        fg.set_u16(base, 3, cnt, s.line)
        body = fg.place()
        if not hasattr(fg, 'forvars'):
            fg.forvars = []
        fg.forvars.append((s.var, varslot))
        fg.emit(0x03, 'U')
        fg.set_u16(len(fg.buf) - 3, 1, lst, s.line)
        fg.emit(0x03, 'U')
        fg.set_u16(len(fg.buf) - 3, 1, at, s.line)
        fg.emit(0x28)                              # INDEX：列表[at] → 元素
        fg.emit(0x04, 'U')
        fg.set_u16(len(fg.buf) - 3, 1, varslot, s.line)
        self.compile_stmts(fg, s.body)
        fg.forvars.pop()
        fg.emit(0x2C, 'UUI')
        base = len(fg.buf) - 9
        fg.set_u16(base, 1, at, s.line)
        fg.set_u16(base, 3, cnt, s.line)
        fg.fixups.append([base + 5, body])
        fg.loops.pop()

    def compile_aging(self, fg, s: Aging):
        top = fg.place()
        self.compile_expr(fg, s.cond)
        jf = fg.jump(0x20)
        self.compile_stmts(fg, s.body)
        back = fg.jump(0x1E)
        fg.patch(back, top)
        fg.patch(jf, fg.place())

    def compile_vc(self, fg, s: VcChain):
        ends = []
        for cond, body in s.arms:
            if cond is not None:
                self.compile_expr(fg, cond)
                jf = fg.jump(0x1F)
                self.compile_stmts(fg, body)
                ends.append(fg.jump(0x1E))
                fg.patch(jf, fg.place())
            else:                          # else 臂必为最后一臂
                self.compile_stmts(fg, body)
        for h in ends:
            fg.patch(h, fg.place())

    # ---- 表达式 ----

    def compile_expr(self, fg, e):
        if isinstance(e, NumLit):
            if isinstance(e.value, float):
                idx = self.const(T_FLOAT, e.value)
            else:
                if not INT64_MIN <= e.value <= INT64_MAX:
                    raise CompileError(f"第 {e.line} 行：整数 {e.value} 超出 int64 范围")
                idx = self.const(T_INT, e.value)
            fg.emit(0x02, 'U')
            fg.set_u16(len(fg.buf) - 3, 1, idx, e.line)
        elif isinstance(e, StrLit):
            fg.emit(0x02, 'U')
            fg.set_u16(len(fg.buf) - 3, 1, self.const(T_STR, e.value), e.line)
        elif isinstance(e, BoolLit):
            fg.emit(0x02, 'U')
            fg.set_u16(len(fg.buf) - 3, 1,
                       self.const(T_INT, 1 if e.value else 0), e.line)
        elif isinstance(e, VarRef):
            fg.emit(0x03, 'U')
            fg.set_u16(len(fg.buf) - 3, 1, fg.resolve(e.name, e.line), e.line)
        elif isinstance(e, Unary):
            self.compile_expr(fg, e.operand)
            fg.emit(0x16 if e.op == '-' else 0x17)
        elif isinstance(e, BinOp):
            if e.op == 'and':              # 规则3：短路且返回操作数本身
                self.compile_expr(fg, e.left)
                fg.emit(0x05)              # DUP
                j = fg.jump(0x1F)          # 假则留着左操作数直接出去
                fg.emit(0x06)              # POP 弹掉副本
                self.compile_expr(fg, e.right)
                fg.patch(j, fg.place())
            elif e.op == 'or':
                self.compile_expr(fg, e.left)
                fg.emit(0x05)
                j = fg.jump(0x20)
                fg.emit(0x06)
                self.compile_expr(fg, e.right)
                fg.patch(j, fg.place())
            else:
                self.compile_expr(fg, e.left)
                self.compile_expr(fg, e.right)
                fg.emit(_BINOP[e.op])
        elif isinstance(e, Call):
            self.compile_call(fg, e)
        elif isinstance(e, InputExpr):
            fg.emit(0x2A, 'U')
            fg.set_u16(len(fg.buf) - 3, 1, self.const(T_STR, e.prompt), e.line)
        elif isinstance(e, ListLit):
            fg.emit(0x25)
            for it in e.items:
                self.compile_expr(fg, it)
                fg.emit(0x26)
        elif isinstance(e, DictLit):
            fg.emit(0x2D)                     # DICT_NEW
            for k, v in e.pairs:
                self.compile_expr(fg, k)
                self.compile_expr(fg, v)
                fg.emit(0x2E)                 # DICT_SET：[...,键,值] → [...,字典]
        elif isinstance(e, Index):
            self.compile_expr(fg, e.base)
            self.compile_expr(fg, e.index)
            fg.emit(0x28)
        else:
            raise CompileError(f"第 {getattr(e, 'line', 0)} 行：不可编译的表达式 {type(e).__name__}")

    def compile_call(self, fg, c: Call):
        if c.name in LIB_CALLS:
            # 标准库调用 → CALL_LIB：库名进常量池，实参按书写序压栈
            if len(c.args) != LIB_CALLS[c.name]:
                raise CompileError(
                    f"第 {c.line} 行：{c.name} 需要 {LIB_CALLS[c.name]} 个实参，"
                    f"给了 {len(c.args)} 个")
            namei = self.const(T_STR, c.name)
            for a in c.args:
                self.compile_expr(fg, a)
            _chk_u16(namei, '库名常量索引', c.line)
            _chk_u8(len(c.args), '参数个数', c.line)
            fg.emit(0x36, 'UB')
            base = len(fg.buf) - 4
            fg.set_u16(base, 1, namei, c.line)
            struct.pack_into('<B', fg.buf, base + 3, len(c.args))
            return
        if '.' in c.name and c.name.split('.')[0] in LIB_PREFIXES:
            raise CompileError(f"第 {c.line} 行：{c.name.split('.')[0]} 标准库暂不支持 VM 模式，请用原生模式（F5）")
        if c.name == '长度':
            if len(c.args) != 1:
                raise CompileError(f"第 {c.line} 行：list.长度 恰好要 1 个实参")
            self.compile_expr(fg, c.args[0])
            fg.emit(0x27)
            return
        if c.name == '添加':
            if len(c.args) != 2 or not isinstance(c.args[0], VarRef):
                raise CompileError(f"第 {c.line} 行：list.添加 的写法是 list.添加(列表名, 值)")
            fg.emit(0x03, 'U')
            fg.set_u16(len(fg.buf) - 3, 1,
                       fg.resolve(c.args[0].name, c.line), c.line)
            self.compile_expr(fg, c.args[1])
            fg.emit(0x26)
            return
        if c.name not in self.fn_index:
            raise CompileError(f"第 {c.line} 行：未声明的函数 list.{c.name}")
        idx = self.fn_index[c.name]
        fdef = self.prog.fns[idx - 1]
        if len(c.args) != len(fdef.params):
            raise CompileError(
                f"第 {c.line} 行：函数 {c.name!r} 要 {len(fdef.params)} 个实参，给了 {len(c.args)} 个")
        for a in c.args:                   # 实参按书写顺序压栈
            self.compile_expr(fg, a)
        fg.emit(0x30, 'UB')
        base = len(fg.buf) - 4
        fg.set_u16(base, 1, idx, c.line)
        _chk_u8(len(c.args), '参数个数', c.line)
        struct.pack_into('<B', fg.buf, base + 3, len(c.args))

    # ---- 入口 ----

    def run(self) -> bytes:
        for fg in self.fns:                # 函数名先进池，索引才能进函数表
            self.const(T_STR, fg.name)
        for i, f in enumerate(self.fns):
            body = self.prog.go_body if i == 0 else self.prog.fns[i - 1].body
            self._declare_all(f, body)
            self.compile_stmts(f, body)
            if i == 0:
                f.emit(0x01)               # 主程序结尾 HALT
            else:
                f.emit(0x32)               # fv 兜底 RET_NONE
            f.resolve_fixups()

        out = bytearray(MAGIC)
        out += struct.pack('<III', VERSION, len(self.consts), len(self.fns))
        for typ, val in self.consts:
            if typ == T_INT:
                out.append(T_INT)
                out += struct.pack('<q', val)
            elif typ == T_FLOAT:
                out.append(T_FLOAT)
                out += struct.pack('<d', val)
            else:
                enc = val.encode('utf-8')
                out.append(T_STR)
                out += struct.pack('<I', len(enc)) + enc
        # 代码偏移相对代码区起点
        offs = []
        o = 0
        for fg in self.fns:
            offs.append(o)
            o += len(fg.buf)
        for i, fg in enumerate(self.fns):
            out += struct.pack('<I', self.cidx[(T_STR, fg.name)])
            out += struct.pack('<HHII', len(fg.params), len(fg.slots),
                               offs[i], len(fg.buf))
        out += b''.join(bytes(fg.buf) for fg in self.fns)
        return bytes(out)

    def _declare_all(self, fg, stmts):
        """预遍历：把函数内所有赋值过的名字按首现顺序分槽。"""
        def walk(stmts):
            for s in stmts:
                if isinstance(s, VgAssign) and s.name not in fg.slots:
                    fg.new_slot(s.name)
                elif isinstance(s, IpAssign) and s.name not in fg.slots:
                    fg.new_slot(s.name)
                elif isinstance(s, Around):
                    walk(s.body)
                elif isinstance(s, ForIn):
                    walk(s.body)
                elif isinstance(s, Aging):
                    walk(s.body)
                elif isinstance(s, CdBlock):
                    walk(s.body)
                elif isinstance(s, VcChain):
                    for _c, b in s.arms:
                        walk(b)
        walk(stmts)


def compile_source(src: str) -> bytes:
    return _Compiler(parse(src)).run()


# ---------------------------------------------------------------- 反汇编

def _parse_pybc(data: bytes):
    if data[:4] != MAGIC:
        raise CompileError("魔数不是 PYBC")
    version, n, f = struct.unpack_from('<III', data, 4)
    if version != VERSION:
        raise CompileError(f"不支持的版本 {version}")
    pos = 16
    consts = []
    for _ in range(n):
        typ = data[pos]
        pos += 1
        if typ == T_INT:
            consts.append((T_INT, struct.unpack_from('<q', data, pos)[0]))
            pos += 8
        elif typ == T_FLOAT:
            consts.append((T_FLOAT, struct.unpack_from('<d', data, pos)[0]))
            pos += 8
        elif typ == T_STR:
            ln = struct.unpack_from('<I', data, pos)[0]
            pos += 4
            consts.append((T_STR, data[pos:pos + ln].decode('utf-8')))
            pos += ln
        else:
            raise CompileError(f"常量池类型 {typ} 未知")
    funcs = []
    for _ in range(f):
        name_i, argc, nslot, off, size = struct.unpack_from('<IHHII', data, pos)
        pos += 16
        funcs.append((name_i, argc, nslot, off, size))
    code = data[pos:]
    return version, consts, funcs, code


def disasm(data: bytes) -> str:
    version, consts, funcs, code = _parse_pybc(data)
    lines = [f".pybc  版本={version}  常量={len(consts)}  函数={len(funcs)}",
             "常量池:"]
    for i, (typ, val) in enumerate(consts):
        tn = {T_INT: 'int', T_FLOAT: 'float', T_STR: 'str'}[typ]
        lines.append(f"  [{i}] {tn} {val!r}")
    lines.append("函数表:")
    for i, (name_i, argc, nslot, off, size) in enumerate(funcs):
        lines.append(f"  fn{i} {consts[name_i][1]!r} 参数={argc} 槽位={nslot} "
                     f"代码=[{off}..{off + size})")
    starts = set()
    pc = 0
    while pc < len(code):
        op = code[pc]
        if op not in OPS:
            raise CompileError(f"代码区偏移 {pc}：未知操作码 0x{op:02X}")
        spec = OPS[op][1]
        size = 1 + sum(2 if c == 'U' else (4 if c == 'I' else 2 if c == 'U' else 1 if c == 'B' else 0) for c in spec)
        starts.add(pc)
        pc += size
    for i, (name_i, argc, nslot, off, size) in enumerate(funcs):
        lines.append(f"--- fn{i} {consts[name_i][1]!r} ---")
        pc = off
        end = off + size
        while pc < end:
            op = code[pc]
            name, spec = OPS[op]
            args = []
            p = pc + 1
            for c in spec:
                if c == 'U':
                    args.append(str(struct.unpack_from('<H', code, p)[0]))
                    p += 2
                elif c == 'B':
                    args.append(str(code[p]))
                    p += 1
                else:
                    args.append(str(struct.unpack_from('<i', code, p)[0]))
                    p += 4
            note = ''
            if name == 'CONST':
                note = f"  ; {consts[int(args[0])][1]!r}"
            elif name in ('SHOW_TEXT', 'MAGIC', 'INPUT'):
                note = f"  ; {consts[int(args[0])][1]!r}"
            elif spec == 'I' or (spec == 'UUI'):
                target = p + struct.unpack_from('<i', code, p - 4)[0]
                args[-1] = f"-> {target}"
            lines.append(f"  {pc:4d}: {name}"
                         + (' ' + ' '.join(args) if args else '') + note)
            pc = p
    return '\n'.join(lines)


# ---------------------------------------------------------------- 自测

if __name__ == '__main__':
    import sys
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass

    # 说明：样例原文里的 vg_ro.单 = [1,2,3] 前端文法不支持（vg_ro 不是关键字、
    # AST 也没有列表节点），在不动 pybk_front.py 的前提下用 vg.单 = 3 等价替换，
    # 使 list.长度(单) == 3 依旧成立。
    SAMPLE = '''@ 测>样例>一
func 加倍(n) { ret n * 2 }
GOING:{
vg.单 = 3
rm.around(3) { ns.show(第 $at 圈) }
if(list.长度(单) == 3) { ns.show(长度对) }
vg.答案 = list.加倍(21)
ns.show(答案=$答案)
}STOP
'''
    data = compile_source(SAMPLE)
    assert data[:4] == b'PYBC'
    version, consts, funcs, code = _parse_pybc(data)
    assert version == 1 and len(funcs) == 2
    assert consts[funcs[0][0]][1] == 'main' and consts[funcs[1][0]][1] == '加倍'

    # 常量去重：整数 3 出现在 vg 赋值、around 次数、== 比较里，池里只应有 1 项
    assert sum(1 for t, v in consts if t == T_INT and v == 3) == 1

    # 指令流完整性：解码正好覆盖代码区，所有跳转目标都落在指令边界上
    starts = set()
    pc = 0
    jump_tgts = []
    while pc < len(code):
        op = code[pc]
        assert op in OPS, f"未知操作码 0x{op:02X} @ {pc}"
        spec = OPS[op][1]
        size = 1 + sum(2 if c == 'U' else (4 if c == 'I' else 2 if c == 'U' else 1 if c == 'B' else 0) for c in spec)
        starts.add(pc)
        if spec in ('I', 'UUI'):
            off = struct.unpack_from('<i', code, pc + 1 + 4 * (spec == 'UUI'))[0]
            jump_tgts.append(pc + size + off)
        pc += size
    assert pc == len(code)
    assert all(t in starts for t in jump_tgts), "跳转目标没有落在指令边界"

    # 主程序以 HALT 结尾；func 以 RET_NONE 兜底
    assert code[funcs[0][3] + funcs[0][4] - 1] == 0x01
    assert code[funcs[1][3] + funcs[1][4] - 1] == 0x32

    print(disasm(data))

    # ---- 语义错误必须带行号 ----
    def _err(src):
        try:
            compile_source(src)
        except (CompileError, PybkError) as e:
            assert '第 ' in str(e), str(e)
            return str(e)
        raise AssertionError('应当报错却没有：' + src)

    assert 'ret' in _err('@ a>b>c\nGOING:{\nret 1\n}STOP\n')
    assert '重复' in _err('@ a>b>c\nfunc f(x){}\nfunc f(y){}\nGOING:{}STOP\n')
    assert '未声明' in _err('@ a>b>c\nGOING:{\nvg.a = b\n}STOP\n')
    assert '内置' in _err('@ a>b>c\nfunc 长度(x){ ret x }\nGOING:{}STOP\n')
    print()
    print("自测通过：格式/去重/跳转边界/HALT 与 RET_NONE 兜底/语义错误均核对无误。")
