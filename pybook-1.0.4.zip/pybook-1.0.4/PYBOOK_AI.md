# PYBOOK_AI.md —— 给 AI 的 PYbook 编程规范

PYbook 是一门中文优先的编程语言：编译到 C、原生 SDL 窗口、以 Python 级语法写 2D/3D 游戏。
本文写给将要**生成 PYbook 代码**的 AI（你）。读完这一页即可精准输出，无需读编译器源码。

## 30 秒上手

```python
@ 游戏>我的程序>1          # 元信息行（必有）

window(normal, open)       # 框架模式：win() 之前的语句只跑一次，之后的每帧跑

GOING:{
    vg.x = 100             # 新变量必须 vg. 前缀（声明）
    win(800, 500, "标题")  # 开窗口（框架模式必调）
    color(255, 200, 80)
    圆(x, 100, 10)         # 画一个圆
}STOP
```

运行：`python pybk_main.py 程序.pybk`（窗口程序）。
**只验证语法**：`python pybk_main.py --check 程序.pybk`（不弹窗，AI 改-验循环用这个）；
`--check-json` 输出 `{"ok": bool, "line": 行号, "message": …}`。

## 硬规则（违反即编译失败，每条都带行号报错）

1. **新变量声明必须 `vg.`**：`vg.x = 1`。声明过之后的同函数内裸赋值 `x = 2` 也合法。
   函数参数的元素可直接 `表[i] = 值`（参数例外）。
2. **函数读不到全局**：函数体内只能读自己的参数和自己赋过的变量。需要场景数据？把列表
   当参数传进去（列表按引用传）。
3. **用户函数调用不是语句**：`我的函数(1)` 单独一行非法。写 `vg.结果 = 我的函数(1)`。
4. **ret 只在 func 里**；`window(normal, open)` 必须在 GOING 之前、文件级。
5. **类可跨模块**：`引用("模块")` 会把模块的 `lb.` 类、函数、顶层变量一并并入；
   类名/函数名跨文件不得重复。构造器仍是 `lb.类名(属性=值)`，属性名拼写错误会带行号报错。
6. **key() 返回布尔**：不能 `key("a") + key("left")`，要 `if(key("a") or key("left"))`。
   注意 key 读全局键盘——别的窗口打字也会被算进去。
7. **插值字符串里不能再嵌引号**：`"$(表["键"])"` 非法。先 `vg.键 = "键"` 再 `"$(表[键])"`。
8. **`$名` 插值要求变量已声明**；任意表达式用 `$(表达式)`；字面 `$` 写 `$$`。
9. **文件名含中文没问题**；Python 3.11；2D 窗口走 `win()`，3D 走 `hw.*`（`ON 3D_highway` 开启）。

## 语境差异（AI 最容易踩的三处）

| 语境 | 裸赋值 | 裸下标赋值 | 说明 |
|---|---|---|---|
| GOING 里（无 window 语句） | 要 `vg.` | 要 `vg.` | 严格模式 |
| GOING 里（有 window(normal,open)） | 可裸 | 参数可裸、其余要 `vg.` | 宽松模式 |
| 函数体内 | 可裸（自己声明的） | 参数可裸 | 函数读不到全局 |

拿不准就全写 `vg.`——永远正确，只是啰嗦。

## 语法速查（P1~P4 全集）

```
vg.a, vg.b = 1, 2              # 多定义
a, b = b, a                    # 交换（右边先算完）
vg.dx, vg.dy = dirkeys()       # 解包：一个列表拆给多目标
vg.偶 = [x for x in 表 if x % 2 == 0]    # 列表推导
vg.翻倍 = {k: v * 2 for k, v in 词频}    # 字典推导
x > 3 ? 1 : 0                  # 三元
"值 = $(x + 1) 百分号$$"        # 任何字符串可插值；$() 里写完整表达式
分 += 10                       # += -= *= /=
xs[-1]  xs[1:4]  xs[::-1]      # 负索引 / 切片 / 反转步长
if(x in 表)  if(x not in 表)   # 成员判断（字符串两边则是子串判断）
for 词, 次 in 词频 { ... }      # 字典双变量遍历（列表单变量）
func 击杀分(基数 = 10, 连击加 = 5) = 基数 + 连击加 * 2   # 默认参数+单行函数
```

## 内置与标准库

- 帧/输入：`frame`（帧数）`sec`（秒）`dirkeys()`（WASD+方向键 → [dx,dy]）
  `key("a")` `hit("space")` `mx() my() mdown()`
- 绘制：`win(宽,高,"标题")` `color(r,g,b)` `clear()` `box(x,y,w,h)` `圆(x,y,r)`
  `线(x1,y1,x2,y2)` `字(x,y,"文本",号)` `图(x,y,"路径")` `图缩(x,y,w,h,"路径")`
- 聚合：`mt.sum(表)` `mt.max` `mt.min` `list.sorted(表)`（升序新表）
  `list.rsorted(表)`（降序新表）`list.byfield(对象表, "字段", 1或-1)`
- 字典：`{"键": 值}` 字面量；`长度(d)` `删掉(d, 键)` `dict.keys(d)` `dict.values(d)`
  `dict.byvalue(d, 1或-1)`（按键值排序取键）
- 列表：`长度(表)` `添加(表, 值)` `删掉(表, 值)` `list.find(表, 值)`（无则 -1）
  `list.sort(表)`（原地）
- 数学：`mt.sqrt abs floor ceil sin cos atan2 依此类推`（mt. 前缀，中文报错）
- 数据交换：`js.parse(文本)` / `js.dump(值)` JSON 读写（字典/列表/数字/字符串/真假/空，
  往返保真）；`csv.parse(文本)` / `csv.dump(表)` 表格文本（逗号引号换行自动处理）
- 列表进阶：`list.flat(嵌套表)`（一层展平）`list.zip(a, b)`（按位配对取短）`list.count(表, 值)`
- 空值字面量：`空` 或 `none`（js.dump 出 null）
- 像素画 MyMove（twoM）：列表即画布，一行字符串一排像素。`mm.draw_away(表, "名.png", 倍数)`
  落成 PNG（透明自动抠）；`mm.贴(表, x, y, 倍数)` 窗口直画；`mm.动([帧1, 帧2], x, y, 倍数, 帧率)` 逐帧动画
  （按帧率轮播帧列表）；`mm.色(token, r, g, b)` 自定义色。中英双名：color=色、blt=贴、anim=动。
  两种写法自动识别：行内含空格 = 多字符 token（`"b1 b2 ."`，`.` 透明）；整图无空格 = 单字符连写
  （`"..gg.."`，每字符一像素）。内置色阶 b/r/g/y/o/p 各 1~3 阶 + w/k/f 与单字符简谱
- 字符串：`te.join(表, "分隔")`（表在前！）`te.split(文本, " ")` `te.str(x)`（转文本）
- 声音：`音.快(频率, 毫秒, 波形)` 非阻塞；`mu.play("文件.wav")`
- 循环：`rm.around(n) -> i { ... }`（n 圈，i 从 0）；`for x in 表`；`rm.aging.while(条件)`
- 文本输出：`ns.show("a", 1, x)`（多参数空格相连，列表/字典直显）

## 神经网络（tb.*：张量 = 二维列表，反向传播手写但算子齐全）

```python
vg.W1 = tb.rand(4, 8)          # 4行8列 随机权重
vg.隐 = tb.relu(tb.lin(X, W1, B1))     # 全连接 + ReLU
vg.概 = tb.softmax(tb.lin(隐, W2, B2)) # 分类输出：每行和为1
vg.损 = tb.crossent(概, Y)      # 交叉熵（Y 是类别号列向量 [[3],[1],...]）
vg.g = tb.lin_dw(隐, tb.crossent_grad(概, Y), W2)   # 梯度链
tb.sgd(W2, g, 0.1)              # 就地更新（lr=0.1）
```

- 形状：`tb.rows(M)` `tb.cols(M)` `tb.mat(行,列,值)` `tb.tr(M)`（转置）
- 运算：`tb.dot(A,B)` `tb.add(A,B)` `tb.mul(A,B)`（逐元素）
- 层：`tb.lin(X,W,B)` 全连接；`tb.relu` `tb.sigmoid` `tb.softmax`
- 损失：`tb.mse(预测,真值)`；`tb.crossent(概率,类别)`；对应 `*_grad` 同参数
- 优化器：`tb.sgd(W,梯度,lr)`；`tb.adam(W,梯度,M,V,lr,b1,b2,步数)`（M/V 各自
  `tb.mat` 同形零矩阵，传进去会被更新）
- 数据：`tb.rand(行,列)` `tb.shuffle(列表,种子)`（同种子同结果）
  `tb.onehot(n,类别数)` `tb.batch(列表,批号,大小)`（批号从0，批 i 取 [i*大小, i*大小+大小)，末尾不足截断，越界得空表）
- 完整可跑示例：`AI走迷宫.pybk`、`神经网络示例.pybk`（两层网络 + Adam 训练到 100% 准确率）

## 数学进阶（mp.*，math+：向量/矩阵/统计/随机，元素全是**一维列表**）

```python
vg.v = mp.vec_add([1,0,0], [0,1,0])      # 向量：add/sub/scale/dot/cross/norm/normalize/dist/lerp
vg.M = mp.mat_mul(A, B, 2, 3, 3)         # 矩阵乘：mat_mul(A,B,行,中,列)——矩阵存成一维列表，形状另传
vg.D = mp.mat_det(M, 3)                  # 方阵：det/inverse(M,n)；mat_identity(n)
vg.sd = mp.std(数据, 0)                  # 统计：mean(表) var/std(表,ddof) minmax(表)→[最小,最大]
vg.x = mp.lerp(0, 100, 0.5)              # 插值族：lerp/clamp/smoothstep(边0,边1,x)
vg.n = mp.rand_normal(0, 1)              # 正态随机数；rand_u01()均匀[0,1)；rand_seed(种子)
```

- 矩阵函数一律 **一维列表 + 行列参数**（和 tb.* 的二维列表是两套体系，别混用）
- 角度函数 `mp.radians(度)` `mp.degrees(弧度)`；`mt.*` 是基础数学（sqrt/sin/…），够用就别用 mp

## 数值数组（np.*，numpybk：一维数组 + 逐元素运算）

```python
vg.a = np.range(0, 10, 2)        # [0,2,4,6,8]；np.zeros(n) 全零
vg.b = np.add(a, [1,1,1,1,1])    # 逐元素 add/sub/mul；np.scale(数组, 系数)
vg.c = np.sin(a)                 # 逐元素 sin/cos/sqrt
vg.d = np.normalize(v)           # 单位化；np.norm(v)；np.dot(a,b)
vg.m = np.mean(a)                # 聚合：max/min/sum/mean
```

np 和 mp 的向量功能有重叠：纯数组逐元素运算用 np，需要矩阵/统计/随机用 mp。

## 网页输出（web.*：编译运行后生成 pybook_page.html 并自动弹浏览器）

```python
@ 博客>首页>1
GOING:{
web.title("我的主页")
web.big(你好 $名字)                       # 大标题；web.mid 中标题
web.show(得分 $分数 / 2)/magic(b, c=0,200,255)   # 段落；$() 任意表达式；/magic 修饰可省
web.img("风景.png")                       # 图片；web.line 分隔线
web.link("教程", "https://…")             # 超链接
web.draw.始                               # 开画布；帧动画和实时块都要包在 始/终 之间
web.帧 { web.draw.色(255,0,0)  web.draw.圆(100,100,30) }   # 预烤动画帧
web.帧 { web.draw.色(0,0,255)  web.draw.圆(200,100,30) }
web.播放(12)                              # 以 12 帧/秒循环之前的所有 帧
web.实时(60) { web.draw.清(0,0,0)  web.draw.圆(web.mx(), web.my(), 10)
    if(web.down("go")) { web.draw.色(0,255,0) } }        # 浏览器实时循环
web.draw.终
web.textbox("输入名字", "nm")             # 页面控件：输入框、按钮
web.button("点我", "go")
}STOP
```

- 画布绘图动词：`web.draw.始/色/圆/方/线/清/字/图/图缩/终`；**实时块里参数是表达式每帧重算**，
  预烤帧里参数烤成常量；画布缺省 400×300，`web.draw.始(800, 450)` 可调（鼠标坐标自动按尺寸换算）
- **多页 `web.页("名") { 页面语句 }`**：烤成独立文件 `pybook_page_名.html`，页间用
  `web.link("文字", "pybook_page_名.html")` 跳转；页里不能套 帧/播放/实时/draw/嵌套页
- **组件复用 `web.块`**：文件顶层定义、GOING 里按名调用，实参是表达式（字符串/数字/已声明变量），
  块体内用 `$参数名` 插值；块内可再调用别的块（先定义后用），但**不能**用 帧/播放/实时/draw
  ```python
  web.块 卡片(标题, 内容) {
      web.mid($标题)
      web.show($标题：$内容)
  }
  GOING:{ web.卡片("水果", "苹果 3 元")  web.卡片("蔬菜", "白菜 1 元") }STOP
  ```
- 交互：`web.textbox(占位, id)` `web.button(文字, id)` 是页面控件语句；读取用表达式
  `web.text("id")`（输入框内容）`web.down("id")`（按钮按下中）`web.click()`（画布被点）`web.mx() web.my()`
  ——**这些表达式只在网页程序（实时块/帧参数）里有效**，桌面窗口程序里没有
- 杂项：`web.audio("文件")` / `web.audio.stop()`；`web.align("center")` `web.gap(像素)`
  `web.style("css")` `web.storage("键","值")` `web.open("网址")` `web.waitsec(秒)`
- `ns.show(...)/magic(...)` 在网页程序里同样输出为段落，magic 是 HTML 标签/样式参数

## 3D（hw.*：文件头写 `ON 3D_highway`，软件光栅，自带窗口）

```python
@ 演示>3D>1
ON 3D_highway

GOING:{
hw.open(800, 500, "我的3D")      # 自管窗口和循环，不要再调 win()
hw.clearcolor(20, 24, 48)        # 天空色
hw.camera(0, 1.6, 0, 0)          # x,y,z,朝向(弧度)，俯仰可省 → 5 参
hw.box(0, 0, 5,  1, 1, 1,  200, 60, 60)   # x,y,z, 宽高深, 颜色 —— 9 参
hw.text(10, 10, "得分 $分", 2)    # 屏幕文字
hw.grab()                        # FPS 视角：锁鼠标（hw.free() 解锁）
hw.frame()                       # 每帧末必调（内部约 60FPS）
}STOP
```

- 输入：`hw.key("w")` `hw.hit("space")` `hw.mx() hw.my() hw.mdown()`；
  **鼠标增量** `hw.mdx() hw.mdy()`（配 hw.grab 做视角）
- 高频坑：忘写 `ON 3D_highway` → hw.* 全部报"需要先 ON"；调了 win() 会和 hw.open 打架；
  hw.frame() 漏调 → 黑屏不刷新

## 高频坑（本规范作者的 AI 同行实际翻车记录）

- `te.join(表, " ")` 参数顺序：**表在第一**。
- 函数做语句不行 → 赋值；模块类不可见 → 平行列表模式。
- 3D：`ON 3D_highway` 在文件头；`hw.box(x,y,z, w,h,d, r,g,b)` 9 参；
  `hw.frame()` 每帧末必调；`hw.open()` 自管窗口不要再用 `win()`。
- 窗口程序编译通过≠正确：先用 `--check` 验语法，再跑窗口看行为。
- `win()` 之后的代码每帧重复执行——把只会做一次的事（清空列表、读文件）放 `win()` 之前。

## 错误处理（P5：try/catch、onerror、安全访问器）

```
try {                       # 抓运行时错误（含"第 N 行"完整消息）
    vg.分 = 存档["最高"]
} catch e {                 # e 是错误文本字符串；也可省 e：catch { ... }
    分 = 0
    ns.show("读档失败", e)
}
```

```
onerror err {               # 放 GOING 任意位置，自动兜底其后全部语句
    ns.show("出错了但不白屏", err)     # 未捕获错误 → 跳这里，游戏不死
    vg.完 = 1
}
```

```
vg.分 = 存档.get("最高", 0)     # 字典：键没有 → 默认值（不炸）
vg.值 = 表.at(i, 0)             # 列表/字符串：越界 → 默认值（不炸）；.at 的缺省可省略
```

规则：catch/onerror 里可以再 try（嵌套安全）；catch 处理完新错误照常可捕获；
`$() 里不能写字符串字面量` 同样适用于 catch 的 e（先落变量再插值）。
防御性写法优先用 .get/.at——不炸的代码比抓异常的代码更好。

## AI 工作循环（推荐）

1. 写/改 `.pybk`
2. `python pybk_main.py --check 文件` —— 通过才进行下一步（失败信息含行号+规则+改法）
3. 需要看行为才真跑窗口；改完即停，别留僵尸进程
4. 运行时报错格式 `运行时错误(第 N 行): 信息` —— 按行号定位，一次修一处
