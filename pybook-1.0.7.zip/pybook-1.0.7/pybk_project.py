"""PYbook 大项目管理（项目分析层，纯静态、不碰代码生成）。

负责把「一堆 .pybk 文件」当成一个工程来管：
1. 读清单 `PYBOOK.toml`：声明入口文件、要扫描的模块目录、编译目标、开关。
2. 目录发现：递归扫根目录 + 包含目录下的 *.pybk，每个文件当成一个模块单元。
3. 依赖图：从每个模块的 `引用("名")` 抽出有向边；做拓扑排序 + DFS 循环检测
   （返回完整环路径，比 _load_imports 里只报 "chain 重复" 更直观）。
4. 跨目录解析：被 `引用("名")` 的模块，除入口所在目录外，还会去包含目录里找。

本模块不生成 C、不调 gcc，只产出结构化结果，供 pybktl CLI 与构建流程使用。
"""

import os
import sys

try:
    import tomllib  # Python 3.11+
except ModuleNotFoundError:  # 极老环境兜底（一般不会走到）
    tomllib = None

from pybk_front import parse_module, PybkError


class ProjectError(Exception):
    """工程配置/结构层面的错误（区别于单文件语法错误 PybkError）。"""


# TOML 键的中英文别名：中文优先，英文兜底，方便不同习惯的用户。
_ALIASES = {
    'entry': '入口', '包含': '包含', 'include': '包含',
    '目标': '目标', 'target': '目标',
    '缓存': '缓存', 'cache': '缓存',
    '拆解编译': '拆解编译', 'separate': '拆解编译',
}


def _norm_key(raw: str) -> str:
    return _ALIASES.get(raw, raw)


def load_manifest(path: str) -> dict:
    """读 PYBOOK.toml，返回规整后的 dict：
    { entry, includes: [dir,...], target, cache: bool, separate: bool, root }。
    找不到清单时抛 ProjectError。"""
    if not os.path.isfile(path):
        raise ProjectError(f"找不到工程清单：{path}")
    if tomllib is None:
        raise ProjectError("当前 Python 无 tomllib（需 3.11+），无法解析 PYBOOK.toml")
    with open(path, 'rb') as f:
        try:
            raw = tomllib.load(f)
        except Exception as e:
            raise ProjectError(f"PYBOOK.toml 解析失败：{e}")
    # TOML 裸键/表名只允许 ASCII，故清单用 [project] 段 + 英文键；
    # 这里同时兼容中文键（若将来换成自定义格式），两种都试一遍。
    sec = raw.get('project', raw.get('工程', raw))

    def get(*keys):
        for k in keys:
            if k in sec:
                return sec[k]
        return None

    entry = get('entry', '入口')
    includes = get('include', '包含') or []
    if isinstance(includes, str):
        includes = [includes]
    target = get('target', '目标') or 'app.exe'
    cache = bool(get('cache', '缓存'))
    separate = bool(get('separate', '拆解编译'))
    if not entry:
        raise ProjectError("PYBOOK.toml 必须声明 入口 = \"主文件.pybk\"")
    root = os.path.dirname(os.path.abspath(path))
    # 包含目录相对工程根解析；工程根本身（绝对路径，避免 '.' 落到 CWD 把整仓扫进来）
    inc_dirs = [root]
    for d in includes:
        ap = d if os.path.isabs(d) else os.path.join(root, d)
        if os.path.isdir(ap):
            inc_dirs.append(ap)
    return {
        'entry': entry,
        'includes': inc_dirs,
        'target': target,
        'cache': cache,
        'separate': separate,
        'root': root,
    }


def discover_modules(manifest: dict) -> dict:
    """扫描 manifest.includes 下所有 *.pybk，返回 { 模块名: ModuleInfo }。

    ModuleInfo: name, path, imports[(name,line),...], has_going(bool), mtime
    模块名 = 文件名去 .pybk（与 引用("名") 的「名」对齐，忽略所在子目录）。
    重复模块名（不同目录同名 .pybk）记到 conflicts，由调用方决定报错还是忽略。
    """
    from dataclasses import dataclass, field

    @dataclass
    class ModuleInfo:
        name: str
        path: str
        imports: list = field(default_factory=list)
        has_going: bool = False
        mtime: float = 0.0

    modules = {}
    conflicts = {}
    seen_paths = set()
    for base in manifest['includes']:
        for dirpath, _dirs, files in os.walk(base):
            for fn in files:
                if not fn.endswith('.pybk'):
                    continue
                full = os.path.abspath(os.path.join(dirpath, fn))
                if full in seen_paths:        # 同一文件被多个搜索目录重复走到
                    continue
                seen_paths.add(full)
                name = fn[:-5]  # 去 .pybk
                try:
                    src = open(full, encoding='utf-8-sig').read()
                    prog = parse_module(src)
                except (PybkError, OSError) as e:
                    # 发现阶段不致命：记下来，后续校验再报
                    conflicts.setdefault(name, []).append((full, f'解析失败: {e}'))
                    continue
                imports = list(prog.imports or [])
                has_going = bool(prog.go_body)
                info = ModuleInfo(name, full, imports, has_going,
                                  os.path.getmtime(full))
                if name in modules and modules[name].path != full:
                    # 只有「不同路径同名」才算真冲突；同文件重复扫到忽略
                    conflicts.setdefault(name, []).append(
                        (full, '与 ' + modules[name].path + ' 同名'))
                elif name not in modules:
                    modules[name] = info
    if conflicts:
        msgs = []
        for nm, locs in conflicts.items():
            if nm in modules:
                others = '、'.join(p for p, _ in locs if p != modules[nm].path)
                if others:
                    msgs.append(f"模块 {nm} 重名：{modules[nm].path}；另发现 {others}")
        if msgs:
            raise ProjectError('；'.join(msgs))
    return modules


def resolve_module(name: str, manifest: dict, modules: dict) -> str:
    """把 引用("名") 解析成文件路径：先看已发现模块表，再回退到目录里找 name.pybk。"""
    if name in modules:
        return modules[name].path
    for base in manifest['includes']:
        cand = os.path.join(base, name + '.pybk')
        if os.path.isfile(cand):
            return cand
    return None


def build_graph(modules: dict) -> dict:
    """返回 { node: [被它引用的模块名,...] } 的有向边表（只含图里存在的节点）。"""
    graph = {n: [] for n in modules}
    for name, info in modules.items():
        for imp_name, _ln in info.imports:
            if imp_name in modules and imp_name not in graph[name]:
                graph[name].append(imp_name)
    return graph


def detect_cycles(graph: dict) -> list:
    """DFS 三色标记找有向环。返回环列表，每个环是 [节点,...]（首尾相同）。"""
    WHITE, GRAY, BLACK = 0, 1, 2
    color = {n: WHITE for n in graph}
    cycles = []
    stack = []

    def dfs(u):
        color[u] = GRAY
        stack.append(u)
        for v in graph.get(u, []):
            if v not in color:
                continue
            if color[v] == GRAY:
                # 找到环：从 stack 里 v 的位置截到末尾再补 v
                if v in stack:
                    idx = stack.index(v)
                    cycles.append(stack[idx:] + [v])
            elif color[v] == WHITE:
                dfs(v)
        stack.pop()
        color[u] = BLACK

    for n in graph:
        if color[n] == WHITE:
            dfs(n)
    return cycles


def topo_order(graph: dict) -> list:
    """Kahn 拓扑排序；有环时返回 None（并顺便不保证完整）。"""
    indeg = {n: 0 for n in graph}
    for u in graph:
        for v in graph[u]:
            if v in indeg:
                indeg[v] += 1
    from collections import deque
    q = deque([n for n in graph if indeg[n] == 0])
    order = []
    while q:
        u = q.popleft()
        order.append(u)
        for v in graph[u]:
            if v in indeg:
                indeg[v] -= 1
                if indeg[v] == 0:
                    q.append(v)
    if len(order) != len(graph):
        return None
    return order


def analyze(manifest_path: str) -> dict:
    """一站式：读清单 → 发现 → 构图 → 环/拓扑。返回结构化结果供 CLI 打印。"""
    manifest = load_manifest(manifest_path)
    modules = discover_modules(manifest)
    graph = build_graph(modules)
    cycles = detect_cycles(graph)
    topo = topo_order(graph) if not cycles else None
    entry_name = os.path.splitext(os.path.basename(manifest['entry']))[0]
    entry_path = (manifest['entry'] if os.path.isabs(manifest['entry'])
                  else os.path.join(manifest['root'], manifest['entry']))
    if not os.path.isfile(entry_path):
        raise ProjectError(f"入口文件不存在：{entry_path}")
    # 入口若不在发现表里（比如不在包含目录），单独补一个节点
    if entry_name not in modules:
        try:
            prog = parse_module(open(entry_path, encoding='utf-8-sig').read())
            modules[entry_name] = type('M', (), {
                'name': entry_name, 'path': entry_path,
                'imports': list(prog.imports or []),
                'has_going': bool(prog.go_body),
                'mtime': os.path.getmtime(entry_path)})()
            graph[entry_name] = [i[0] for i in modules[entry_name].imports
                                 if i[0] in modules]
        except (PybkError, OSError) as e:
            raise ProjectError(f"入口文件解析失败：{e}")
    return {
        'manifest': manifest,
        'modules': modules,
        'graph': graph,
        'cycles': cycles,
        'topo': topo,
        'entry': entry_name,
        'entry_path': entry_path,
    }


if __name__ == '__main__':
    if len(sys.argv) < 2:
        print("用法: python pybk_project.py <PYBOOK.toml>")
        sys.exit(1)
    res = analyze(sys.argv[1])
    print(f"入口: {res['entry']}  ({res['entry_path']})")
    print(f"模块数: {len(res['modules'])}")
    for n, info in res['modules'].items():
        tag = ' [入口]' if n == res['entry'] else (' [库]' if not info.has_going else '')
        imps = ', '.join(i[0] for i in info.imports) or '（无引用）'
        print(f"  - {n}{tag}: 引用 {imps}")
    if res['cycles']:
        print("发现循环依赖：")
        for c in res['cycles']:
            print("  环: " + ' -> '.join(c))
    else:
        print("无循环依赖 ✓")
        if res['topo']:
            print("拓扑序（被依赖者在前）: " + ' -> '.join(res['topo']))
