# 开发速度基准：同一任务（10 万次循环累加）在各语言/后端上的"改-验-跑"循环耗时
# 每项跑 3 次取中位数，单位毫秒
import subprocess, time, statistics, sys

def t(cmd, n=3, **kw):
    ts = []
    for _ in range(n):
        a = time.perf_counter()
        r = subprocess.run(cmd, capture_output=True, cwd='.', **kw)
        ts.append((time.perf_counter() - a) * 1000)
        if r.returncode != 0:
            print('  失败:', cmd, r.stderr.decode('utf-8', 'replace')[:200])
            break
    return statistics.median(ts)

PY = sys.executable
rows = []
rows.append(('PYbook --check 小文件(8行)      [AI改-验循环]', t([PY, 'pybk_main.py', '--check', '_speed_test.pybk'])))
rows.append(('PYbook --check 射击场(1765行)  [AI改-验循环]', t([PY, 'pybk_main.py', '--check', '示例_射击场.pybk'])))
rows.append(('PYbook VM: pybc 编译(Python)', t([PY, '-c', "import pybk_bc; open('_speed_test.pybc','wb').write(pybk_bc.compile_source(open('_speed_test.pybk',encoding='utf-8-sig').read()))"])))
rows.append(('PYbook VM: pyvm.exe 跑 .pybc  [运行]', t(['./pyvm.exe', '_speed_test.pybc'])))
import os
import pybk_code
key = pybk_code._src_fingerprint(open('_speed_test.pybk', encoding='utf-8-sig').read())
cached = os.path.join('exe_cache', 'prog_%s.exe' % key)
if os.path.isfile(cached):
    os.remove(cached)            # 保证"首次构建"真实
rows.append(('PYbook C 后端: 首次构建+运行   [冷]', t([PY, 'pybk_main.py', '_speed_test.pybk'], n=1)))
rows.append(('PYbook C 后端: exe 缓存命中    [热]', t([PY, 'pybk_main.py', '_speed_test.pybk'])))
rows.append(('Python 3.13 直接跑同任务       [对照]', t([PY, '_speed_test.py'])))
rows.append(('Node v24 直接跑同任务          [对照]', t(['node', '_speed_test.js'])))
rows.append(('手写 C: gcc 编译               [对照冷]', t([r'C:\Users\zhuli\mingw64\bin\x86_64-w64-mingw32-gcc.exe', '-O2', '_speed_test.c', '-o', '_speed_test_c.exe'], n=1)))
rows.append(('手写 C: 运行 exe               [对照热]', t(['./_speed_test_c.exe'])))

print()
print('%-46s %10s' % ('项目', '中位毫秒'))
print('-' * 58)
for name, ms in rows:
    print('%-46s %10.0f' % (name, ms))
