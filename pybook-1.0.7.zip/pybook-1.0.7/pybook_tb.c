/* PYbook torchbk（tb. 前缀）：教学级神经网络原生库。
 * 张量 = 列表的列表（2D 浮点矩阵），与 np.* / 游戏代码完全互通。
 * 设计：手写梯度对（前向算子 + 配套 _grad/_dx/_dw/_db），
 *       不做自动微分——让学习者亲手拼出反向传播。
 *
 * 前向：mat/rand/dot/tr/add/mul/addrow/relu/sigmoid/lin/mse
 * 反向：relu_grad/sigmoid_grad/mse_grad/lin_dx/lin_dw/lin_db
 * 优化：step(w, dw, lr) = w - lr*dw
 * 维度：rows/cols
 *
 * 约定：矩阵 = 行列表，每行是等长浮点列表；维度不符带具体报错。 */

#include "pybook_lib.h"
#include "pybook_mt.h"

#include <math.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* ================= 内部 ================= */

static void tb_die(const char *fmt, ...)
{
    va_list ap;
    fprintf(stderr, "运行时错误: ");
    va_start(ap, fmt);
    vfprintf(stderr, fmt, ap);
    va_end(ap);
    fputc('\n', stderr);
    exit(1);
}

/* 张量底层：tb.* 现在统一操作 RtTensor（行主序浮点缓冲），不再用列表的列表。
 * 下面辅助函数把"矩阵"语义映射到 RtTensor 上。 */
static RtTensor *tens_of(Value m, const char *who)
{
    if (!rt_is_tensor(m) || rt_as_tensor(m) == NULL)
        tb_die("%s 需要张量（tb 矩阵）", who);
    return rt_as_tensor(m);
}

static double at(Value m, size_t r, size_t c, const char *who)
{
    RtTensor *t = tens_of(m, who);
    if (t->ndim != 2)
        tb_die("%s 需要 2D 张量（当前 %d 维）", who, t->ndim);
    if (r >= (size_t)t->dims[0] || c >= (size_t)t->dims[1])
        tb_die("%s 越界 (%zu,%zu)，形状 %dx%d", who, r, c, t->dims[0], t->dims[1]);
    return t->data[r * (size_t)t->dims[1] + c];
}

static double numv(Value v, const char *who)
{
    if (IS_FLT(v))  return AS_FLT(v);
    if (IS_INT(v) || IS_BIGINT(v)) return (double)rt_to_ll(v);
    if (IS_BOOL(v)) return (double)AS_BOOL(v);
    tb_die("%s 需要数字参数", who);
    return 0;
}

static size_t rows_of(Value m, const char *who)
{
    return (size_t)tens_of(m, who)->dims[0];
}

static size_t cols_of(Value m, const char *who)
{
    RtTensor *t = tens_of(m, who);
    if (t->ndim < 2)
        tb_die("%s 需要 2D 张量（当前 %d 维）", who, t->ndim);
    return (size_t)t->dims[1];
}

static Value new_mat(size_t r, size_t c)
{
    int d[2] = { (int)r, (int)c };
    return rt_tensor_new(2, d);
}

static void set_at(Value m, size_t r, size_t c, double x)
{
    RtTensor *t = rt_as_tensor(m);
    t->data[r * (size_t)t->dims[1] + c] = x;
}

/* ================= 并行分块（pybook_mt 内核，块内零分配） ================= */

#define TB_EW_MIN ((double)(1 << 15))   /* 逐元素：3.3 万元素起并行 */
#define TB_MM_MIN ((double)(1 << 19))   /* 矩阵乘：52 万次乘加起并行 */

static double sig(double x);   /* 定义在下方 sigmoid 区 */

typedef struct {
    Value m1, m2, m3, out;   /* 三个输入槽 + 输出 */
    size_t k1, k2;           /* 维度槽 */
    double *parts;           /* 归约分块偏经（MT_CHUNKS 长） */
} TbJob;

static void dot_chunk(int cid, long long ra, long long rb, void *ud)
{
    TbJob *x = ud;
    (void)cid;
    for (long long i = ra; i < rb; i++)
        for (size_t j = 0; j < x->k2; j++) {
            double s = 0;
            for (size_t k = 0; k < x->k1; k++)
                s += at(x->m1, (size_t)i, k, "tb.dot") * at(x->m2, k, j, "tb.dot");
            set_at(x->out, (size_t)i, j, s);
        }
}

static void lin_chunk(int cid, long long ra, long long rb, void *ud)
{
    TbJob *x = ud;
    (void)cid;
    for (long long i = ra; i < rb; i++)
        for (size_t j = 0; j < x->k2; j++) {
            double s = at(x->m3, 0, j, "tb.lin");
            for (size_t k = 0; k < x->k1; k++)
                s += at(x->m1, (size_t)i, k, "tb.lin") * at(x->m2, k, j, "tb.lin");
            set_at(x->out, (size_t)i, j, s);
        }
}

static void add_chunk(int cid, long long ra, long long rb, void *ud)
{
    TbJob *x = ud;
    (void)cid;
    for (long long i = ra; i < rb; i++)
        for (size_t j = 0; j < x->k2; j++)
            set_at(x->out, (size_t)i, j,
                   at(x->m1, (size_t)i, j, "tb.add") + at(x->m2, (size_t)i, j, "tb.add"));
}

static void mul_chunk(int cid, long long ra, long long rb, void *ud)
{
    TbJob *x = ud;
    (void)cid;
    for (long long i = ra; i < rb; i++)
        for (size_t j = 0; j < x->k2; j++)
            set_at(x->out, (size_t)i, j,
                   at(x->m1, (size_t)i, j, "tb.mul") * at(x->m2, (size_t)i, j, "tb.mul"));
}

static void addrow_chunk(int cid, long long ra, long long rb, void *ud)
{
    TbJob *x = ud;
    (void)cid;
    for (long long i = ra; i < rb; i++)
        for (size_t j = 0; j < x->k2; j++)
            set_at(x->out, (size_t)i, j,
                   at(x->m1, (size_t)i, j, "tb.addrow") + at(x->m2, 0, j, "tb.addrow"));
}

static void relu_chunk(int cid, long long ra, long long rb, void *ud)
{
    TbJob *x = ud;
    (void)cid;
    for (long long i = ra; i < rb; i++)
        for (size_t j = 0; j < x->k2; j++) {
            double v = at(x->m1, (size_t)i, j, "tb.relu");
            set_at(x->out, (size_t)i, j, v > 0 ? v : 0.0);
        }
}

static void sigmoid_chunk(int cid, long long ra, long long rb, void *ud)
{
    TbJob *x = ud;
    (void)cid;
    for (long long i = ra; i < rb; i++)
        for (size_t j = 0; j < x->k2; j++)
            set_at(x->out, (size_t)i, j, sig(at(x->m1, (size_t)i, j, "tb.sigmoid")));
}

static void softmax_chunk(int cid, long long ra, long long rb, void *ud)
{
    TbJob *x = ud;
    (void)cid;
    size_t c = x->k2;
    double *tmp = (double *)malloc(c * sizeof(double));   /* 原生内存，非 GC */
    if (!tmp)
        tb_die("tb.softmax 内存不足");
    for (long long i = ra; i < rb; i++) {
        double mx = at(x->m1, (size_t)i, 0, "tb.softmax");
        for (size_t j = 1; j < c; j++) {
            double v = at(x->m1, (size_t)i, j, "tb.softmax");
            if (v > mx) mx = v;
        }
        double s = 0;
        for (size_t j = 0; j < c; j++) {
            tmp[j] = exp(at(x->m1, (size_t)i, j, "tb.softmax") - mx);
            s += tmp[j];
        }
        for (size_t j = 0; j < c; j++)
            set_at(x->out, (size_t)i, j, tmp[j] / s);
    }
    free(tmp);
}

static void mse_chunk(int cid, long long ra, long long rb, void *ud)
{
    TbJob *x = ud;
    double s = 0;
    for (long long i = ra; i < rb; i++)
        for (size_t j = 0; j < x->k2; j++) {
            double d = at(x->m1, (size_t)i, j, "tb.mse") - at(x->m2, (size_t)i, j, "tb.mse");
            s += d * d;
        }
    x->parts[cid] = s;
}

static void crossent_chunk(int cid, long long ra, long long rb, void *ud)
{
    TbJob *x = ud;
    double s = 0;
    for (long long i = ra; i < rb; i++) {
        size_t r = (size_t)i;
        size_t kc = cols_of(x->m2, "tb.crossent");
        if (kc < 1) tb_die("tb.crossent：目标行必须含类别下标");
        long long cls = (long long)at(x->m2, r, 0, "tb.crossent");
        size_t yc = cols_of(x->m1, "tb.crossent");
        if (cls < 0 || (size_t)cls >= yc)
            tb_die("tb.crossent：类别下标 %lld 越界（0..%zu）", cls, yc - 1);
        double p = at(x->m1, r, (size_t)cls, "tb.crossent");
        if (p < 1e-12) p = 1e-12;
        s += -log(p);
    }
    x->parts[cid] = s;
}

/* ================= 创建 / 维度 ================= */

Value rt_tb_mat(Value rv, Value cv)
{
    long long r = (long long)numv(rv, "tb.mat 的行数");
    long long c = (long long)numv(cv, "tb.mat 的列数");
    if (r < 1 || r > 100000 || c < 1 || c > 100000)
        tb_die("tb.mat 行列数超范围（1..10万）");
    return new_mat((size_t)r, (size_t)c);
}

Value rt_tb_rand(Value rv, Value cv)
{
    long long r = (long long)numv(rv, "tb.rand 的行数");
    long long c = (long long)numv(cv, "tb.rand 的列数");
    if (r < 1 || r > 100000 || c < 1 || c > 100000)
        tb_die("tb.rand 行列数超范围");
    Value m = new_mat((size_t)r, (size_t)c);
    for (size_t i = 0; i < (size_t)r; i++)
        for (size_t j = 0; j < (size_t)c; j++)
            set_at(m, i, j, (double)rand() * 2.0 / RAND_MAX - 1.0);
    return m;
}

Value rt_tb_rows(Value m)
{
    return rt_int((long long)rows_of(m, "tb.rows"));
}

Value rt_tb_cols(Value m)
{
    return rt_int((long long)cols_of(m, "tb.cols"));
}

/* ================= 前向算子 ================= */

Value rt_tb_dot(Value a, Value b)
{
    size_t ar = rows_of(a, "tb.dot"), ac = cols_of(a, "tb.dot");
    size_t br = rows_of(b, "tb.dot"), bc = cols_of(b, "tb.dot");
    if (ac != br)
        tb_die("tb.dot 维度不符：%zux%zu 乘 %zux%zu（中间要对上）", ar, ac, br, bc);
    Value out = new_mat(ar, bc);
    if ((double)ar * (double)ac * (double)bc >= TB_MM_MIN) {
        TbJob x = {.m1 = a, .m2 = b, .out = out, .k1 = ac, .k2 = bc};
        mt_parallel((long long)ar, dot_chunk, &x);
        return out;
    }
    for (size_t i = 0; i < ar; i++)
        for (size_t j = 0; j < bc; j++) {
            double s = 0;
            for (size_t k = 0; k < ac; k++)
                s += at(a, i, k, "tb.dot") * at(b, k, j, "tb.dot");
            set_at(out, i, j, s);
        }
    return out;
}

Value rt_tb_tr(Value m)
{
    size_t r = rows_of(m, "tb.tr"), c = cols_of(m, "tb.tr");
    Value out = new_mat(c, r);
    for (size_t i = 0; i < r; i++)
        for (size_t j = 0; j < c; j++)
            set_at(out, j, i, at(m, i, j, "tb.tr"));
    return out;
}

Value rt_tb_add(Value a, Value b)
{
    size_t r = rows_of(a, "tb.add"), c = cols_of(a, "tb.add");
    if (rows_of(b, "tb.add") != r || cols_of(b, "tb.add") != c)
        tb_die("tb.add 形状不同（%zux%zu vs %zux%zu）",
               r, c, rows_of(b, "tb.add"), cols_of(b, "tb.add"));
    Value out = new_mat(r, c);
    if ((double)r * (double)c >= TB_EW_MIN) {
        TbJob x = {.m1 = a, .m2 = b, .out = out, .k2 = c};
        mt_parallel((long long)r, add_chunk, &x);
        return out;
    }
    for (size_t i = 0; i < r; i++)
        for (size_t j = 0; j < c; j++)
            set_at(out, i, j, at(a, i, j, "tb.add") + at(b, i, j, "tb.add"));
    return out;
}

Value rt_tb_mul(Value a, Value b)
{
    size_t r = rows_of(a, "tb.mul"), c = cols_of(a, "tb.mul");
    if (rows_of(b, "tb.mul") != r || cols_of(b, "tb.mul") != c)
        tb_die("tb.mul 形状不同");
    Value out = new_mat(r, c);
    if ((double)r * (double)c >= TB_EW_MIN) {
        TbJob x = {.m1 = a, .m2 = b, .out = out, .k2 = c};
        mt_parallel((long long)r, mul_chunk, &x);
        return out;
    }
    for (size_t i = 0; i < r; i++)
        for (size_t j = 0; j < c; j++)
            set_at(out, i, j, at(a, i, j, "tb.mul") * at(b, i, j, "tb.mul"));
    return out;
}

/* addrow(m, row)：把 1×c 的行加到每一行（线性层偏置用） */
Value rt_tb_addrow(Value m, Value row)
{
    size_t r = rows_of(m, "tb.addrow"), c = cols_of(m, "tb.addrow");
    if (rows_of(row, "tb.addrow") != 1 || cols_of(row, "tb.addrow") != c)
        tb_die("tb.addrow 第二参数要 1x%zu 的行，得到 %zux%zu",
               c, rows_of(row, "tb.addrow"), cols_of(row, "tb.addrow"));
    Value out = new_mat(r, c);
    if ((double)r * (double)c >= TB_EW_MIN) {
        TbJob x = {.m1 = m, .m2 = row, .out = out, .k2 = c};
        mt_parallel((long long)r, addrow_chunk, &x);
        return out;
    }
    for (size_t i = 0; i < r; i++)
        for (size_t j = 0; j < c; j++)
            set_at(out, i, j, at(m, i, j, "tb.addrow") + at(row, 0, j, "tb.addrow"));
    return out;
}

Value rt_tb_relu(Value m)
{
    size_t r = rows_of(m, "tb.relu"), c = cols_of(m, "tb.relu");
    Value out = new_mat(r, c);
    if ((double)r * (double)c >= TB_EW_MIN) {
        TbJob x = {.m1 = m, .out = out, .k2 = c};
        mt_parallel((long long)r, relu_chunk, &x);
        return out;
    }
    for (size_t i = 0; i < r; i++)
        for (size_t j = 0; j < c; j++) {
            double x = at(m, i, j, "tb.relu");
            set_at(out, i, j, x > 0 ? x : 0.0);
        }
    return out;
}

static double sig(double x) { return 1.0 / (1.0 + exp(-x)); }

Value rt_tb_sigmoid(Value m)
{
    size_t r = rows_of(m, "tb.sigmoid"), c = cols_of(m, "tb.sigmoid");
    Value out = new_mat(r, c);
    if ((double)r * (double)c >= TB_EW_MIN) {
        TbJob x = {.m1 = m, .out = out, .k2 = c};
        mt_parallel((long long)r, sigmoid_chunk, &x);
        return out;
    }
    for (size_t i = 0; i < r; i++)
        for (size_t j = 0; j < c; j++)
            set_at(out, i, j, sig(at(m, i, j, "tb.sigmoid")));
    return out;
}

/* linear(x, w, b) = x@w + b（b 是 1×out 的行，广播到每行） */
Value rt_tb_lin(Value x, Value w, Value b)
{
    size_t xr = rows_of(x, "tb.lin"), xc = cols_of(x, "tb.lin");
    size_t wr = rows_of(w, "tb.lin"), wc = cols_of(w, "tb.lin");
    if (xc != wr)
        tb_die("tb.lin 维度不符：x 是 %zux%zu，w 是 %zux%zu（x列数要=w行数）",
               xr, xc, wr, wc);
    if (rows_of(b, "tb.lin") != 1 || cols_of(b, "tb.lin") != wc)
        tb_die("tb.lin 偏置 b 要是 1x%zu，得到 %zux%zu",
               wc, rows_of(b, "tb.lin"), cols_of(b, "tb.lin"));
    Value out = new_mat(xr, wc);
    if ((double)xr * (double)xc * (double)wc >= TB_MM_MIN) {
        TbJob jb = {.m1 = x, .m2 = w, .m3 = b, .out = out, .k1 = xc, .k2 = wc};
        mt_parallel((long long)xr, lin_chunk, &jb);
        return out;
    }
    for (size_t i = 0; i < xr; i++)
        for (size_t j = 0; j < wc; j++) {
            double s = at(b, 0, j, "tb.lin");
            for (size_t k = 0; k < xc; k++)
                s += at(x, i, k, "tb.lin") * at(w, k, j, "tb.lin");
            set_at(out, i, j, s);
        }
    return out;
}

/* MSE：((y-t)^2)/个数 */
Value rt_tb_mse(Value y, Value t)
{
    size_t r = rows_of(y, "tb.mse"), c = cols_of(y, "tb.mse");
    if (rows_of(t, "tb.mse") != r || cols_of(t, "tb.mse") != c)
        tb_die("tb.mse 形状不同");
    double s = 0;
    if ((double)r * (double)c >= TB_EW_MIN) {
        double parts[MT_CHUNKS] = {0};
        TbJob x = {.m1 = y, .m2 = t, .k2 = c, .parts = parts};
        int chunks = mt_parallel((long long)r, mse_chunk, &x);
        for (int i = 0; i < chunks; i++)
            s += parts[i];
    } else {
        for (size_t i = 0; i < r; i++)
            for (size_t j = 0; j < c; j++) {
                double d = at(y, i, j, "tb.mse") - at(t, i, j, "tb.mse");
                s += d * d;
            }
    }
    return rt_float(s / ((double)r * (double)c));
}
/* ================= 反向算子（手写梯度） ================= */

Value rt_tb_relu_grad(Value pre)
{
    size_t r = rows_of(pre, "tb.relu_grad"), c = cols_of(pre, "tb.relu_grad");
    Value out = new_mat(r, c);
    for (size_t i = 0; i < r; i++)
        for (size_t j = 0; j < c; j++)
            set_at(out, i, j, at(pre, i, j, "tb.relu_grad") > 0 ? 1.0 : 0.0);
    return out;
}

/* sigmoid 导数 s'(x) = s(1-s)：直接传 sigmoid 的输出 y */
Value rt_tb_sigmoid_grad(Value y)
{
    size_t r = rows_of(y, "tb.sigmoid_grad"), c = cols_of(y, "tb.sigmoid_grad");
    Value out = new_mat(r, c);
    for (size_t i = 0; i < r; i++)
        for (size_t j = 0; j < c; j++) {
            double s = at(y, i, j, "tb.sigmoid_grad");
            set_at(out, i, j, s * (1.0 - s));
        }
    return out;
}

/* dL/dy = 2(y-t)/个数 */
Value rt_tb_mse_grad(Value y, Value t)
{
    size_t r = rows_of(y, "tb.mse_grad"), c = cols_of(y, "tb.mse_grad");
    if (rows_of(t, "tb.mse_grad") != r || cols_of(t, "tb.mse_grad") != c)
        tb_die("tb.mse_grad 形状不同");
    Value out = new_mat(r, c);
    double n = (double)r * (double)c;
    for (size_t i = 0; i < r; i++)
        for (size_t j = 0; j < c; j++)
            set_at(out, i, j, 2.0 * (at(y, i, j, "tb.mse_grad")
                                     - at(t, i, j, "tb.mse_grad")) / n);
    return out;
}

/* lin 的三路梯度：out = x@w+b，已知 dL/dout（记作 g，形状同 out）*/
Value rt_tb_lin_dx(Value x, Value w, Value g)
{
    /* dx = g @ w转置 */
    (void)w;
    return rt_tb_dot(g, rt_tb_tr(w));
}

Value rt_tb_lin_dw(Value x, Value g)
{
    /* dw = x转置 @ g */
    return rt_tb_dot(rt_tb_tr(x), g);
}

Value rt_tb_lin_db(Value g)
{
    /* db = g 各行求和（1×out） */
    size_t r = rows_of(g, "tb.lin_db"), c = cols_of(g, "tb.lin_db");
    Value out = new_mat(1, c);
    for (size_t j = 0; j < c; j++) {
        double s = 0;
        for (size_t i = 0; i < r; i++)
            s += at(g, i, j, "tb.lin_db");
        set_at(out, 0, j, s);
    }
    return out;
}

/* ================= 优化器 ================= */

/* step(m, dm, lr) = m - lr*dm */
Value rt_tb_step(Value m, Value dm, Value lrv)
{
    size_t r = rows_of(m, "tb.step"), c = cols_of(m, "tb.step");
    if (rows_of(dm, "tb.step") != r || cols_of(dm, "tb.step") != c)
        tb_die("tb.step 形状不同");
    double lr = numv(lrv, "tb.step 的学习率");
    Value out = new_mat(r, c);
    for (size_t i = 0; i < r; i++)
        for (size_t j = 0; j < c; j++)
            set_at(out, i, j, at(m, i, j, "tb.step") - lr * at(dm, i, j, "tb.step"));
    return out;
}

/* ================= 分类损失（P5 扩展） ================= */

/* softmax(m)：每行做数值稳定的 softmax，输出同形矩阵 */
Value rt_tb_softmax(Value m)
{
    size_t nrows = rows_of(m, "tb.softmax");
    size_t c = cols_of(m, "tb.softmax");
    Value out = new_mat(nrows, c);
    if ((double)nrows * (double)c * 2.0 >= TB_EW_MIN) {
        TbJob x = {.m1 = m, .out = out, .k2 = c};
        mt_parallel((long long)nrows, softmax_chunk, &x);
        return out;
    }
    for (size_t r = 0; r < nrows; r++) {
        double maxv = at(m, r, 0, "tb.softmax");
        for (size_t cc = 1; cc < c; cc++) {
            double v = at(m, r, cc, "tb.softmax");
            if (v > maxv) maxv = v;
        }
        double sum = 0;
        for (size_t cc = 0; cc < c; cc++) {
            double e = exp(at(m, r, cc, "tb.softmax") - maxv);
            set_at(out, r, cc, e);
            sum += e;
        }
        for (size_t cc = 0; cc < c; cc++)
            set_at(out, r, cc, at(out, r, cc, "tb.softmax") / sum);
    }
    return out;
}

/* crossent(y_prob, target)：target 是列向量（每行一个类别下标 0..K-1）。
 * 返回标量列向量 [[平均交叉熵]]。 */
Value rt_tb_crossent(Value y, Value t)
{
    size_t ny = rows_of(y, "tb.crossent");
    size_t nt = rows_of(t, "tb.crossent");
    if (ny != nt)
        tb_die("tb.crossent：样本数不一致 %zu vs %zu", ny, nt);
    double sum = 0;
    if ((double)ny >= (double)(1 << 14)) {
        double parts[MT_CHUNKS] = {0};
        TbJob x = {.m1 = y, .m2 = t, .parts = parts};
        int chunks = mt_parallel((long long)ny, crossent_chunk, &x);
        for (int i = 0; i < chunks; i++)
            sum += parts[i];
    } else {
        for (size_t r = 0; r < ny; r++) {
            size_t kc = cols_of(t, "tb.crossent");
            if (kc < 1) tb_die("tb.crossent：目标行必须含类别下标");
            long long cls = (long long)at(t, r, 0, "tb.crossent");
            size_t yc = cols_of(y, "tb.crossent");
            if (cls < 0 || (size_t)cls >= yc)
                tb_die("tb.crossent：类别下标 %lld 越界（0..%zu）", cls, yc - 1);
            double p = at(y, r, (size_t)cls, "tb.crossent");
            if (p < 1e-12) p = 1e-12;
            sum += -log(p);
        }
    }
    Value out = new_mat(1, 1);
    set_at(out, 0, 0, sum / (double)ny);
    return out;
}

/* crossent_grad(y_prob, target)：dL/dy = (y - onehot(t)) / N */
Value rt_tb_crossent_grad(Value y, Value t)
{
    size_t ny = rows_of(y, "tb.crossent");
    size_t nt = rows_of(t, "tb.crossent");
    if (ny != nt)
        tb_die("tb.crossent_grad：样本数不一致");
    size_t nc = cols_of(y, "tb.crossent_grad");
    Value out = new_mat(ny, nc);
    double n = (double)ny;
    for (size_t r = 0; r < ny; r++) {
        size_t kc = cols_of(t, "tb.crossent_grad");
        if (kc < 1) tb_die("tb.crossent_grad：目标行必须含类别下标");
        long long cls = (long long)at(t, r, 0, "tb.crossent_grad");
        for (size_t c = 0; c < nc; c++)
            set_at(out, r, c, (at(y, r, c, "tb.crossent_grad") - (c == (size_t)cls ? 1.0 : 0.0)) / n);
    }
    return out;
}

/* argmax(m)：每行最大值下标，输出列向量 */
Value rt_tb_argmax(Value m)
{
    size_t nrows = rows_of(m, "tb.argmax");
    size_t c = cols_of(m, "tb.argmax");
    Value out = new_mat(nrows, 1);
    for (size_t r = 0; r < nrows; r++) {
        size_t best = 0;
        double bv = at(m, r, 0, "tb.argmax");
        for (size_t cc = 1; cc < c; cc++) {
            double v = at(m, r, cc, "tb.argmax");
            if (v > bv) { bv = v; best = cc; }
        }
        set_at(out, r, 0, (double)best);
    }
    return out;
}

/* ================= 优化器（P5 扩展） ================= */

/* sgd(w, dw, lr)：w = w - lr*dw（就地修改并返回 w） */
Value rt_tb_sgd(Value w, Value dw, Value lrv)
{
    double lr = (IS_FLT(lrv)) ? AS_FLT(lrv) : (double)rt_to_ll(lrv);
    size_t nw = rows_of(w, "tb.sgd");
    size_t nd = rows_of(dw, "tb.sgd");
    if (nw != nd) tb_die("tb.sgd：行数不一致 %zu vs %zu", nw, nd);
    size_t cw = cols_of(w, "tb.sgd");
    size_t cd = cols_of(dw, "tb.sgd");
    if (cw != cd) tb_die("tb.sgd：列数不一致 %zu vs %zu", cw, cd);
    for (size_t r = 0; r < nw; r++)
        for (size_t c = 0; c < cw; c++)
            set_at(w, r, c, at(w, r, c, "tb.sgd") - lr * at(dw, r, c, "tb.sgd"));
    return w;
}

/* adam 系列：三态存在语言层（m/v 矩阵由用户持有），这里提供单步更新 */
Value rt_tb_adam(Value w, Value dw, Value m, Value v,
                 Value lrv, Value beta1v, Value beta2v, Value stepv)
{
    double lr = (IS_FLT(lrv)) ? AS_FLT(lrv) : (double)rt_to_ll(lrv);
    double b1 = (IS_FLT(beta1v)) ? AS_FLT(beta1v) : (double)rt_to_ll(beta1v);
    double b2 = (IS_FLT(beta2v)) ? AS_FLT(beta2v) : (double)rt_to_ll(beta2v);
    double step = (IS_FLT(stepv)) ? AS_FLT(stepv) : (double)rt_to_ll(stepv);
    size_t nw = rows_of(w, "tb.adam");
    size_t nd = rows_of(dw, "tb.adam");
    if (nw != nd) tb_die("tb.adam：行数不一致");
    size_t cw = cols_of(w, "tb.adam");
    size_t cd = cols_of(dw, "tb.adam");
    size_t cm = cols_of(m, "tb.adam");
    size_t cv = cols_of(v, "tb.adam");
    if (cw != cd || cw != cm || cw != cv)
        tb_die("tb.adam：形状不一致");
    for (size_t r = 0; r < nw; r++)
        for (size_t c = 0; c < cw; c++) {
            double g = at(dw, r, c, "tb.adam");
            double mm = b1 * at(m, r, c, "tb.adam") + (1 - b1) * g;
            double vv = b2 * at(v, r, c, "tb.adam") + (1 - b2) * g * g;
            set_at(m, r, c, mm);
            set_at(v, r, c, vv);
            double mh = mm / (1 - pow(b1, step));
            double vh = vv / (1 - pow(b2, step));
            set_at(w, r, c, at(w, r, c, "tb.adam") - lr * mh / (sqrt(vh) + 1e-8));
        }
    return w;
}

/* ================= 数据原语（P5 扩展） ================= */

/* shuffle(表, 种子)：Fisher-Yates，返回新表（元素引用不变） */
Value rt_tb_shuffle(Value list, Value seedv)
{
    if (!IS_LIST(list) || AS_LIST(list) == NULL)
        tb_die("tb.shuffle 需要列表");
    RtList *L = AS_LIST(list);
    unsigned seed = (unsigned)rt_to_ll(seedv);
    Value out = rt_list_new();
    for (size_t i = 0; i < L->len; i++)
        rt_push(&out, L->items[i]);
    srand(seed);
    for (size_t i = AS_LIST(out)->len; i > 1; i--) {
        size_t j = (size_t)(rand() % i);
        Value t = AS_LIST(out)->items[i - 1];
        AS_LIST(out)->items[i - 1] = AS_LIST(out)->items[j];
        AS_LIST(out)->items[j] = t;
    }
    return out;
}

/* onehot(n, 类数)：[[0..1..0]] 列向量（n 是单值） */
Value rt_tb_onehot(Value nv, Value kv)
{
    long long n = rt_to_ll(nv);
    long long k = rt_to_ll(kv);
    if (k <= 0) tb_die("tb.onehot：类数必须为正");
    if (n < 0 || n >= k) tb_die("tb.onehot：下标 %lld 越界（0..%lld）", n, k - 1);
    Value out = new_mat(1, (size_t)k);
    set_at(out, 0, (size_t)n, 1.0);
    return out;
}

/* batch(表, i, 大小)：取出 [i*大小, i*大小+大小) 的切片（不足则取到尾部） */
Value rt_tb_batch(Value list, Value iv, Value szv)
{
    if (!IS_LIST(list) || AS_LIST(list) == NULL)
        tb_die("tb.batch 需要列表");
    RtList *L = AS_LIST(list);
    long long i = rt_to_ll(iv);
    long long sz = rt_to_ll(szv);
    if (sz <= 0) tb_die("tb.batch：大小必须为正");
    long long start = i * sz;
    if (start < 0) start = 0;
    if (start >= (long long)L->len) {
        Value empty = rt_list_new();
        return empty;
    }
    long long end = start + sz;
    if (end > (long long)L->len) end = (long long)L->len;
    Value out = rt_list_new();
    for (long long k = start; k < end; k++)
        rt_push(&out, L->items[k]);
    return out;
}
