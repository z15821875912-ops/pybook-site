# PYbook AST 树形打印器：parse() 一段程序，缩进打印语法树（省略 line 字段降噪）
import sys, dataclasses
sys.path.insert(0, '.')
from pybk_front import parse

def is_node(v):
    return dataclasses.is_dataclass(v) and not isinstance(v, type)

def render(v):
    """标量/元组 → 单行简写；节点和混合列表 → 返回 None 表示要展开"""
    if is_node(v):
        return None
    if isinstance(v, list):
        if not v:
            return '[]'
        flat = all(isinstance(x, (str, int, float, bool, type(None), tuple)) for x in v)
        if flat:
            s = repr(v)
            return s if len(s) <= 56 else s[:53] + '...'
        return None
    if isinstance(v, str):
        s = repr(v)
        return s if len(s) <= 40 else s[:37] + '...'
    return repr(v)

def dump(node, out, indent=''):
    name = type(node).__name__
    heads, subs = [], []
    for f in dataclasses.fields(node):
        if f.name == 'line':
            continue
        v = getattr(node, f.name)
        r = render(v)
        if r is None:
            subs.append((f.name, v))
            heads.append('%s=[…]' % f.name)
        else:
            heads.append('%s=%s' % (f.name, r))
    out.append('%s%s(%s)' % (indent, name, ', '.join(heads)))
    for fname, v in subs:
        pad = indent + '    '
        if isinstance(v, list):
            out.append('%s%s ×%d:' % (indent + '  ', fname, len(v)))
            for it in v:
                if is_node(it):
                    dump(it, out, pad)
                else:
                    out.append(pad + repr(it)[:76])
        else:
            out.append('%s%s:' % (indent + '  ', fname))
            dump(v, out, pad)

src = open(sys.argv[1], encoding='utf-8-sig').read()
prog = parse(src)
out = []
dump(prog, out)
print('\n'.join(out))
