/* pybook_ui.c —— 桌面 GUI 引擎（立即模式 / SDL2 自绘）
 *
 * 三条设计决策：
 *   ① 立即模式（IMGUI）：每帧重新声明控件，函数直接返回交互结果。
 *      契合 PYbook 的 `rm.aging.while(end()) { ... show() }` 帧循环 ——
 *      不用注册回调、不用管控件生命周期，新手友好、代码量小。
 *   ② SDL2 自绘，不用系统原生控件：零新增依赖、Windows 与 Linux 表现一致、
 *      风格统一成 PYbook 的深色终端风。
 *   ③ API 全英文：关键字早已迁英文，中文只出现在变量名 / 字符串 / 注释。
 *
 * 复用的现成部件（这是本引擎能写得这么短的原因）：
 *   · 窗口 / 渲染器 —— rt_game_win 与 game_renderer（2D 游戏已有）
 *   · 中文字       —— rt_game_text（pybook_rt.c 的 stb_truetype + 纹理缓存）
 *   · 鼠标         —— rt_game_mx / my / mhit / mdown
 *   · 文本输入     —— game_take_text（SDL_TEXTINPUT；中文 IME 也走这条）
 *   · 文字测宽     —— game_text_width（布局要用）
 *
 * 状态怎么存：控件要跨帧记住文本 / 滑条值。默认按「容器内调用序号」生成 id；
 *   把控件放进 if 分支会让序号错位，那种情况先用 ui.tag("名字") 钉住稳定 id。
 */

#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "pybook_rt.h"
#include <SDL2/SDL.h>

/* ---- pybook_rt.c 跨文件提供 ---- */
extern int           game_text_width(const char *s, int px);
extern const char   *game_take_text(void);
extern int           game_take_backspace(void);
extern SDL_Renderer *game_renderer(void);
extern int           game_height(void);

/* ⚠ rt_die 是 pybook_rt.c 的 static，这里拿不到 —— 自带一份报错出口。
   退出码 1，跟 PYbook 其它运行时错误一致。 */
static void ui_die(const char *fmt, ...)
{
    va_list ap;
    va_start(ap, fmt);
    fflush(stdout);
    fputs("ui 错误：", stderr);
    vfprintf(stderr, fmt, ap);
    fputc('\n', stderr);
    va_end(ap);
    exit(1);
}

/* ---- PYbook 深色终端风配色 ----
   用结构体而不是多值宏：宏在 `a ? C_X : C_Y` 这种三元里没法正确展开。 */
typedef struct { int r, g, b; } UiCol;

static const UiCol COL_BG     = {  11,  14,  20 };   /* #0B0E14 底 */
static const UiCol COL_PANEL  = {  19,  24,  32 };   /* 控件底 */
static const UiCol COL_PANEL2 = {  26,  32,  42 };   /* 悬停 / 轨道 */
static const UiCol COL_BORDER = {  40,  48,  62 };   /* 边框 */
static const UiCol COL_TEXT   = { 232, 237, 244 };   /* #E8EDF4 正文 */
static const UiCol COL_DIM    = { 132, 142, 158 };   /* 次要文字 */
static const UiCol COL_ACCENT = {  53, 224, 122 };   /* #35E07A 主色 */
static const UiCol COL_PURPLE = { 154, 140, 245 };   /* #9A8CF5 辅色 */
static const UiCol COL_ZEBRA  = {  15,  19, 26 };    /* 表格斑马纹（PANEL 与 BG 之间） */

enum { UI_COL = 0, UI_ROW = 1 };

#define UI_DEPTH 16

typedef struct {
    int      dir;        /* UI_COL 竖排 / UI_ROW 横排 */
    int      x, y, w, h; /* 容器矩形 */
    int      cx, cy;     /* 光标：下一个控件的左上角 */
    unsigned hash;       /* 容器 id 哈希，给子控件生成稳定 id */
    int      seq;        /* 本容器内已放置的控件数 */
} UiBox;

static UiBox g_st[UI_DEPTH];
static int   g_depth = 0;

static int g_pad     = 8;    /* 控件间距 */
static int g_ctrl_h  = 32;   /* 控件默认高 */
static int g_font_px = 16;   /* 默认字号 */

/* ---- 每帧的输入快照（ui.begin 时采一次，控件共用） ---- */
static int g_mx = 0, g_my = 0;
static int g_click = 0;      /* 本帧左键刚按下（边沿） */
static int g_down  = 0;      /* 左键按住中 */

/* ---- 无头测试注入钩子 ----
   鼠标位置取自 SDL_GetMouseState（真实 OS 光标），按键状态也取自真实物理按键，
   所以「点一下按钮」这件事在 CI / 截图探针里没法合成事件（引擎不读事件队列）。
   这个钩子让探针在 rt_ui_begin 之前覆写本帧快照。
   ⚠ 故意不注册进 pybk_code 的 LIB_C_NAMES —— PYbook 代码调不到，
     只有直接链接 rt_cache/*.o 的 C 探针能用（和 game_renderer 同样的用法）。 */
static int g_tx = 0, g_ty = 0, g_tclick = 0, g_tdown = 0, g_tforce = 0;

void ui_test_input(int x, int y, int click, int down)
{
    g_tx = x; g_ty = y; g_tclick = click; g_tdown = down; g_tforce = 1;
}

void ui_test_input_reset(void)
{
    g_tforce = 0;
}

/* ---- 控件状态表（跨帧记忆） ---- */
#define UI_STATE_MAX 256
typedef struct {
    unsigned id;
    char    *text;      /* 输入框文本 */
    double   num;       /* 滑条值 / 勾选值 */
    int      init;      /* 已用外部值初始化过 */
} UiState;

static UiState  g_state[UI_STATE_MAX];
static int      g_state_n = 0;
static unsigned g_focus = 0;     /* 当前获得键盘输入的控件 id */
static unsigned g_tag   = 0;     /* ui.tag 设的下一个 id（用一次即清） */

/* ---------------- 小工具 ---------------- */

static char *ui_dup(const char *s)
{
    if (s == NULL)
        s = "";
    size_t n = strlen(s) + 1;
    char *p = (char *)malloc(n);
    if (p == NULL)
        ui_die("内存不足");
    memcpy(p, s, n);
    return p;
}

static double ui_num(Value v, const char *who)
{
    if (IS_FLT(v))
        return AS_FLT(v);
    if (IS_INT(v) || IS_BIGINT(v))
        return (double)rt_to_ll(v);
    if (IS_BOOL(v))
        return (double)AS_BOOL(v);
    ui_die("%s 需要数字参数", who);
    return 0;
}

static const char *ui_str(Value v)
{
    return rt_str_of(v);
}

/* 稳定 id：ui.tag 优先，否则按容器内序号 */
static unsigned ui_id(void)
{
    if (g_tag != 0) {
        unsigned t = g_tag;
        g_tag = 0;
        return t;
    }
    UiBox *c = &g_st[g_depth - 1];
    c->seq++;
    return c->hash * 131u + (unsigned)c->seq;
}

static unsigned ui_hash(const char *s)
{
    unsigned h = 2166136261u;
    for (const unsigned char *p = (const unsigned char *)s; *p; p++) {
        h ^= *p;
        h *= 16777619u;
    }
    return h ? h : 1u;      /* 0 留给「没设 tag」 */
}

static UiState *ui_state(unsigned id)
{
    for (int i = 0; i < g_state_n; i++)
        if (g_state[i].id == id)
            return &g_state[i];
    if (g_state_n >= UI_STATE_MAX)
        return &g_state[UI_STATE_MAX - 1];   /* 满了就复用最后一条：退化但不崩 */
    UiState *s = &g_state[g_state_n++];
    memset(s, 0, sizeof *s);
    s->id   = id;
    s->text = ui_dup("");
    return s;
}

/* ---- 绘制 ---- */

static void ui_fill(int x, int y, int w, int h, UiCol c)
{
    SDL_Renderer *ren = game_renderer();
    if (ren == NULL || w <= 0 || h <= 0)
        return;
    SDL_SetRenderDrawColor(ren, (Uint8)c.r, (Uint8)c.g, (Uint8)c.b, 255);
    SDL_Rect rc;
    rc.x = x; rc.y = y; rc.w = w; rc.h = h;
    SDL_RenderFillRect(ren, &rc);
}

/* 描边：四条 1px 实心线拼 —— SDL_RenderDrawRect 在部分后端有 1px 偏差 */
static void ui_stroke(int x, int y, int w, int h, UiCol c)
{
    ui_fill(x, y, w, 1, c);
    ui_fill(x, y + h - 1, w, 1, c);
    ui_fill(x, y, 1, h, c);
    ui_fill(x + w - 1, y, 1, h, c);
}

/* 任意方向粗线（Bresenham，逐点铺 t×t 方块）。
   勾选的对勾是两条斜笔画，纯横竖的 ui_fill 拼不出来，所以单独备一个。 */
static void ui_line(int x0, int y0, int x1, int y1, int t, UiCol c)
{
    int dx = abs(x1 - x0), sx = (x0 < x1) ? 1 : -1;
    int dy = -abs(y1 - y0), sy = (y0 < y1) ? 1 : -1;
    int e = dx + dy;
    for (;;) {
        ui_fill(x0 - t / 2, y0 - t / 2, t, t, c);
        if (x0 == x1 && y0 == y1)
            break;
        int e2 = e * 2;
        if (e2 >= dy) { e += dy; x0 += sx; }
        if (e2 <= dx) { e += dx; y0 += sy; }
    }
}

static void ui_text(int x, int y, const char *s, int px, UiCol c)
{
    if (s == NULL || s[0] == '\0')
        return;
    rt_game_color(rt_int(c.r), rt_int(c.g), rt_int(c.b));
    rt_game_text(rt_int(x), rt_int(y), rt_str(s), rt_int(px));
}

static int ui_in(int x, int y, int w, int h)
{
    return g_mx >= x && g_mx < x + w && g_my >= y && g_my < y + h;
}

/* ---------------- 布局 ---------------- */

/* 在光标处占一块地，返回实际矩形。竖排时宽度撑满容器。 */
static void ui_rect(int w, int h, int *ox, int *oy, int *ow, int *oh)
{
    UiBox *c = &g_st[g_depth - 1];
    *ox = c->cx;
    *oy = c->cy;
    *ow = (c->dir == UI_COL) ? c->w : w;
    *oh = h;
}

static void ui_advance(int w, int h)
{
    UiBox *c = &g_st[g_depth - 1];
    if (c->dir == UI_COL) {
        c->cy += h + g_pad;
    } else {
        c->cx += w + g_pad;
        if (h > c->h)
            c->h = h;                        /* 行内高度取最大 */
    }
}

/* ---------------- 对外 API ---------------- */

/* ui.begin(x, y, w)：每帧开一次，重置布局并把光标放到 (x, y)。
   之后所有 ui.* 都活在这个根容器里（竖排）。 */
Value rt_ui_begin(Value xv, Value yv, Value wv)
{
    int x = (int)ui_num(xv, "ui.begin 的 x");
    int y = (int)ui_num(yv, "ui.begin 的 y");
    int w = (int)ui_num(wv, "ui.begin 的宽");
    if (w < 8)
        w = 8;

    /* 每帧采一次输入快照：mhit 是「本帧边沿」，多次调用只会翻页一次 */
    if (g_tforce) {
        g_mx    = g_tx;
        g_my    = g_ty;
        g_click = g_tclick;
        g_down  = g_tdown;
    } else {
        g_mx    = (int)rt_to_ll(rt_game_mx());
        g_my    = (int)rt_to_ll(rt_game_my());
        g_click = rt_to_ll(rt_game_mhit()) ? 1 : 0;
        g_down  = rt_to_ll(rt_game_mdown()) ? 1 : 0;
    }

    g_depth     = 1;                 /* 根容器常驻，ui.end 收到 0 才结束这一帧 */
    g_tag       = 0;                 /* 每帧重置：上一帧没人消费的 tag 不许漏到这一帧 */
    g_st[0].dir = UI_COL;
    g_st[0].x   = x;
    g_st[0].y   = y;
    g_st[0].w   = w;
    g_st[0].h   = game_height() - y - 20;
    if (g_st[0].h < 8)
        g_st[0].h = 8;
    g_st[0].cx   = x;
    g_st[0].cy   = y;
    g_st[0].hash = 0;
    g_st[0].seq  = 0;
    return rt_none();
}

/* ui.row() / ui.col()：压入一个横排 / 竖排容器 */
static void ui_push(int dir)
{
    if (g_depth >= UI_DEPTH)
        ui_die("容器嵌套超过 %d 层", UI_DEPTH);
    if (g_depth <= 0)
        ui_die("ui.row / ui.col 必须在 ui.begin 之后调用");
    UiBox *p = &g_st[g_depth - 1];
    UiBox *c = &g_st[g_depth];
    c->dir  = dir;
    c->x    = p->cx;
    c->y    = p->cy;
    c->w    = p->x + p->w - p->cx;          /* 吃掉父容器剩余宽度 */
    if (c->w < 8)
        c->w = 8;
    c->h    = g_ctrl_h;
    c->cx   = c->x;
    c->cy   = c->y;
    c->hash = p->hash * 131u + (unsigned)(p->seq + 1);
    c->seq  = 0;
    g_depth++;
}

Value rt_ui_row(void) { ui_push(UI_ROW); return rt_none(); }
Value rt_ui_col(void) { ui_push(UI_COL); return rt_none(); }

Value rt_ui_end(void)
{
    if (g_depth <= 0)
        ui_die("ui.end：没有可结束的容器（ui.begin / ui.row / ui.col 要与 ui.end 配对）");
    UiBox *c = &g_st[g_depth - 1];
    int used_w = (c->dir == UI_ROW) ? (c->cx - c->x - g_pad) : c->w;
    int used_h = (c->dir == UI_COL) ? (c->cy - c->y - g_pad) : c->h;
    if (used_w < 0) used_w = 0;
    if (used_h < 0) used_h = 0;

    if (g_depth >= 2) {                      /* 根容器没有父级，不用回写 */
        UiBox *p = &g_st[g_depth - 2];
        if (p->dir == UI_COL)
            p->cy = c->y + used_h + g_pad;
        else
            p->cx = c->x + used_w + g_pad;
        p->seq++;
    }
    g_depth--;
    return rt_none();
}

/* ui.gap(px)：插一段空白 */
Value rt_ui_gap(Value pv)
{
    if (g_depth <= 0)
        ui_die("ui.gap 必须在 ui.begin 之后调用");
    int n = (int)ui_num(pv, "ui.gap 的像素");
    if (n < 0)
        n = 0;
    UiBox *c = &g_st[g_depth - 1];
    if (c->dir == UI_COL)
        c->cy += n;
    else
        c->cx += n;
    return rt_none();
}

/* ui.tag(name)：给下一个控件钉一个稳定 id。
   把控件写在 if 分支里时序号 id 会错位 —— 用这个就不会。 */
Value rt_ui_tag(Value nv)
{
    g_tag = ui_hash(ui_str(nv));
    return rt_none();
}

/* ui.label(text, px)：一行静态文字 */
Value rt_ui_label(Value tv, Value pv)
{
    if (g_depth <= 0)
        ui_die("ui.label 必须在 ui.begin 之后调用");
    const char *s  = ui_str(tv);
    int         px = (int)ui_num(pv, "ui.label 的字号");
    if (px < 6)
        px = 6;
    int w = game_text_width(s, px) + 4;
    int h = px + 8;
    int x, y, rw, rh;
    ui_rect(w, h, &x, &y, &rw, &rh);
    ui_text(x + 2, y + 2, s, px, COL_TEXT);
    ui_advance(w, h);
    return rt_none();
}

/* ui.button(text)：返回本帧是否被点（1/0） */
Value rt_ui_button(Value tv)
{
    if (g_depth <= 0)
        ui_die("ui.button 必须在 ui.begin 之后调用");
    const char *s = ui_str(tv);
    int tw = game_text_width(s, g_font_px);
    int w  = tw + 28;
    int h  = g_ctrl_h;
    int x, y, rw, rh;
    ui_rect(w, h, &x, &y, &rw, &rh);

    int hover = ui_in(x, y, rw, rh);
    ui_fill(x, y, rw, rh, hover ? COL_PANEL2 : COL_PANEL);
    ui_stroke(x, y, rw, rh, hover ? COL_ACCENT : COL_BORDER);
    ui_text(x + (rw - tw) / 2, y + (rh - g_font_px) / 2, s, g_font_px,
            hover ? COL_ACCENT : COL_TEXT);

    int hit = (hover && g_click) ? 1 : 0;
    ui_advance(w, h);
    return rt_bool(hit);
}

/* ui.input(value)：单行输入框。返回当前文本。
   典型写法 `名字 = ui.input(名字)` —— 传进去当初始值，拿回来是新值。
   点一下获得焦点；有焦点时键盘输入直接进来（中文 IME 也走 SDL_TEXTINPUT）。 */
Value rt_ui_input(Value vv)
{
    if (g_depth <= 0)
        ui_die("ui.input 必须在 ui.begin 之后调用");
    const char *val = ui_str(vv);
    int w = 220, h = g_ctrl_h;
    int x, y, rw, rh;
    ui_rect(w, h, &x, &y, &rw, &rh);

    unsigned id = ui_id();
    UiState *st = ui_state(id);
    if (!st->init || strcmp(st->text, val) != 0) {
        /* 首次、或外部把这个值改了（比如点了个「清空」按钮）→ 采纳外部值 */
        free(st->text);
        st->text = ui_dup(val);
        st->init = 1;
    }

    int hover = ui_in(x, y, rw, rh);
    if (hover && g_click)
        g_focus = id;
    else if (g_click && !hover && g_focus == id)
        g_focus = 0;                       /* 点到别处就失焦 */

    if (g_focus == id) {
        const char *t = game_take_text();
        if (t != NULL && t[0] != '\0') {
            size_t n1 = strlen(st->text), n2 = strlen(t);
            char *p = (char *)realloc(st->text, n1 + n2 + 1);
            if (p != NULL) {
                st->text = p;
                memcpy(st->text + n1, t, n2 + 1);
            }
        }
        int bs = game_take_backspace();
        while (bs-- > 0 && st->text[0] != '\0') {
            /* 退掉一个完整 UTF-8 字符（中文不能退半个） */
            size_t n = strlen(st->text);
            size_t k = 1;
            while (k < n && ((unsigned char)st->text[n - k - 1] & 0xC0) == 0x80)
                k++;
            if (k > 4)
                k = 4;
            st->text[n - k] = '\0';
        }
    }

    int focused = (g_focus == id);
    ui_fill(x, y, rw, rh, COL_PANEL);
    ui_stroke(x, y, rw, rh, focused ? COL_ACCENT : (hover ? COL_DIM : COL_BORDER));

    int tw = game_text_width(st->text, g_font_px);
    int tx = x + 8;
    if (tw > rw - 16)                       /* 太长就把尾部截出来显示 */
        tx = x + 8 - (tw - (rw - 16));
    ui_text(tx, y + (rh - g_font_px) / 2, st->text, g_font_px, COL_TEXT);

    if (focused && (int)((SDL_GetTicks() / 500) % 2)) {   /* 光标：1 秒一闪 */
        int cx = x + 8 + (tw < rw - 16 ? tw : rw - 16);
        ui_fill(cx, y + 6, 2, rh - 12, COL_ACCENT);
    }

    ui_advance(w, h);
    return rt_str(st->text);
}

/* ui.slider(value, min, max)：拖动条。返回当前值。
   按住左键在条上拖即可；也支持点一下跳过去。 */
Value rt_ui_slider(Value vv, Value mnv, Value mxv)
{
    if (g_depth <= 0)
        ui_die("ui.slider 必须在 ui.begin 之后调用");
    double val = ui_num(vv,  "ui.slider 的值");
    double mn  = ui_num(mnv, "ui.slider 的最小值");
    double mx  = ui_num(mxv, "ui.slider 的最大值");
    if (mx < mn) { double t = mn; mn = mx; mx = t; }
    if (mx - mn < 1e-9)
        mx = mn + 1.0;

    int w = 200, h = g_ctrl_h;
    int x, y, rw, rh;
    ui_rect(w, h, &x, &y, &rw, &rh);

    unsigned id = ui_id();
    UiState *st = ui_state(id);
    if (!st->init) {
        st->num  = val;
        st->init = 1;
    }

    /* 右端要标当前数值，先把它的宽度量出来并从轨道里扣掉 ——
       不扣的话数值会画到容器右外侧、被窗口边缘裁掉（实测 "50" 被切一半）。 */
    char buf[48];
    snprintf(buf, sizeof buf, "%.0f", st->num);
    int vw = game_text_width(buf, g_font_px);
    int tw = rw - (vw + 12);
    if (tw < 40)
        tw = rw;              /* 容器太窄就不留数值位，优先保住能拖的范围 */

    int hover = ui_in(x, y, rw, rh);
    /* 本帧点中 → 接管拖动；已经接管且左键还按着 → 继续跟手 */
    if (hover && g_click)
        g_focus = id;
    if (g_focus == id && g_down) {
        double t = (double)(g_mx - x) / (double)tw;
        if (t < 0.0) t = 0.0;
        if (t > 1.0) t = 1.0;
        st->num = mn + t * (mx - mn);
    }
    if (g_click && !hover)
        g_focus = 0;

    double t = (st->num - mn) / (mx - mn);
    if (t < 0.0) t = 0.0;
    if (t > 1.0) t = 1.0;

    int ky = y + rh / 2 - 2;
    ui_fill(x, ky, tw, 4, COL_PANEL2);
    ui_fill(x, ky, (int)(tw * t), 4, COL_ACCENT);
    int kx = x + (int)(tw * t) - 5;
    if (kx < x) kx = x;
    if (kx > x + tw - 10) kx = x + tw - 10;
    ui_fill(kx, y + rh / 2 - 8, 10, 16, (hover || g_focus == id) ? COL_ACCENT : COL_TEXT);

    /* 数值右对齐贴容器右缘，跟轨道保持 12px 呼吸 */
    ui_text(x + rw - vw, y + (rh - g_font_px) / 2, buf, g_font_px,
            (hover || g_focus == id) ? COL_TEXT : COL_DIM);

    ui_advance(w, h);
    return rt_float(st->num);
}

/* ui.check(text, value)：勾选框。返回当前是否勾上（1/0）。 */
Value rt_ui_check(Value tv, Value vv)
{
    if (g_depth <= 0)
        ui_die("ui.check 必须在 ui.begin 之后调用");
    const char *s  = ui_str(tv);
    int on = ui_num(vv, "ui.check 的值") != 0.0;
    int tw = game_text_width(s, g_font_px);
    int w  = 20 + 8 + tw + 8;
    int h  = g_ctrl_h;
    int x, y, rw, rh;
    ui_rect(w, h, &x, &y, &rw, &rh);

    unsigned id = ui_id();
    UiState *st = ui_state(id);
    if (!st->init) {
        st->num  = on ? 1.0 : 0.0;
        st->init = 1;
    }

    int hover = ui_in(x, y, rw, rh);
    if (hover && g_click)
        st->num = (st->num != 0.0) ? 0.0 : 1.0;

    int bx = x, by = y + (rh - 20) / 2;
    ui_fill(bx, by, 20, 20, COL_PANEL);
    ui_stroke(bx, by, 20, 20, hover ? COL_ACCENT : COL_BORDER);
    if (st->num != 0.0) {
        /* 对勾：短斜下 + 长斜上，比一条横线一眼能认出是"勾上了" */
        ui_line(bx + 5, by + 10, bx + 9, by + 14, 3, COL_ACCENT);
        ui_line(bx + 9, by + 14, bx + 15, by + 5, 3, COL_ACCENT);
    }
    ui_text(x + 28, y + (rh - g_font_px) / 2, s, g_font_px, COL_TEXT);

    ui_advance(w, h);
    return rt_bool(st->num != 0.0);
}

/* ---- ui.table：任意格子值 → malloc 文本（用完 free）。
   数字 / 真假 / 空都按 ns.show 的口径转，混型表格不用先 te.str。 ---- */
static char *ui_cell_text(Value v)
{
    char buf[48];
    if (IS_STR(v))
        return ui_dup(rt_str_of(v));
    if (IS_INT(v) || IS_BIGINT(v)) {
        snprintf(buf, sizeof buf, "%lld", rt_to_ll(v));
        return ui_dup(buf);
    }
    if (IS_FLT(v)) {
        snprintf(buf, sizeof buf, "%g", AS_FLT(v));
        return ui_dup(buf);
    }
    if (IS_BOOL(v))
        return ui_dup(AS_BOOL(v) ? "真" : "假");
    if (IS_NONE(v))
        return ui_dup("空");
    return ui_dup("?");
}

/* ui.table(selected, data, headers, view_h)：数据表 —— 应用级「看表 + 点行」。
 *
 *   selected  当前选中行号（0 起，-1 = 没选中）
 *   data      列表的列表：每行一个子列表，格子自动转文本
 *   headers   表头字符串列表；空表 [] = 不画表头
 *   view_h    >0 = 视口高（超出出右缘滚动条，可拖）；<=0 = 自然高（全展开）
 *
 * 列宽自动：每列取「表头 + 所有格子」的最大文本宽 + 12，总宽超出容器按比例压缩。
 * 交互：悬停行高亮；点行选中、再点同一行取消（回 -1）。
 * 返回：本帧的选中行号 —— 惯用法 `选中 = ui.表格(选中, 数据, 表头, 260)`。
 * 表格是通栏控件：总是撑满当前容器剩余宽（竖排流里用最自然）。
 * 限制：每帧 O(行×列) 次文本测量，千行级先分页；2D 运行时没有滚轮，v1 靠滚动条。 */
Value rt_ui_table(Value selv, Value datav, Value headv, Value vhv)
{
    if (g_depth <= 0)
        ui_die("ui.table 必须在 ui.begin 之后调用");
    if (!IS_LIST(datav))
        ui_die("ui.table 的数据需要是列表（每个元素是一行子列表）");
    if (!IS_LIST(headv))
        ui_die("ui.table 的表头需要是字符串列表（不要表头就传 []）");

    /* 首帧裸名进来是空盒 → 当作「没选中」；整数/真假照收 */
    long long sel = IS_NONE(selv) ? -1 : rt_to_ll(selv);
    RtList  *rl   = AS_LIST(datav);
    RtList  *hl   = AS_LIST(headv);
    long long nrows = rt_list_len_ll(datav);
    long long nh    = (long long)hl->len;
    int       vh_req = (int)ui_num(vhv, "ui.table 的视口高");

    if (sel >= nrows)
        sel = -1;                       /* 数据变短了，旧选中号作废 */

    unsigned id = ui_id();
    UiState *st = ui_state(id);

    /* ---- 一次取齐所有文本：量宽和绘制共用（用完就放） ---- */
    char **hdr = NULL;
    if (nh > 0) {
        hdr = (char **)calloc((size_t)nh, sizeof(char *));
        if (hdr == NULL)
            ui_die("内存不足");
        for (long long c = 0; c < nh; c++)
            hdr[c] = ui_cell_text(hl->items[c]);
    }
    long long ncols = nh;
    for (long long i = 0; i < nrows; i++) {
        Value rv = rl->items[i];
        if (IS_LIST(rv) && (long long)AS_LIST(rv)->len > ncols)
            ncols = (long long)AS_LIST(rv)->len;
    }
    char **grid = NULL;
    if (nrows > 0 && ncols > 0) {
        grid = (char **)calloc((size_t)(nrows * ncols), sizeof(char *));
        if (grid == NULL)
            ui_die("内存不足");
        for (long long i = 0; i < nrows; i++) {
            Value rv = rl->items[i];
            RtList *r = IS_LIST(rv) ? AS_LIST(rv) : NULL;
            for (long long c = 0; c < ncols; c++)
                grid[i * ncols + c] =
                    (r != NULL && c < (long long)r->len) ? ui_cell_text(r->items[c])
                                                          : ui_dup("");
        }
    }

    /* ---- 列宽：最大文本宽 + 12；总宽超出容器按比例压（单列保底 24） ---- */
    long long *colw = NULL;
    if (ncols > 0) {
        colw = (long long *)calloc((size_t)ncols, sizeof(long long));
        if (colw == NULL)
            ui_die("内存不足");
        for (long long cc = 0; cc < ncols; cc++) {
            long long wmax = 0;
            if (cc < nh && hdr[cc] != NULL)
                wmax = game_text_width(hdr[cc], g_font_px);
            if (grid != NULL) {
                for (long long i = 0; i < nrows; i++) {
                    int cw = game_text_width(grid[i * ncols + cc], g_font_px);
                    if (cw > wmax)
                        wmax = cw;
                }
            }
            colw[cc] = wmax + 12;
        }
    }
    UiBox *cur = &g_st[g_depth - 1];
    int avail = cur->x + cur->w - cur->cx;         /* 容器剩余宽 */
    if (avail < 60)
        avail = 60;
    long long total = 0;
    for (long long cc = 0; cc < ncols; cc++)
        total += colw[cc];
    if (total > avail && total > 0) {
        for (long long cc = 0; cc < ncols; cc++) {
            colw[cc] = colw[cc] * avail / total;
            if (colw[cc] < 24)
                colw[cc] = 24;
        }
    }

    /* ---- 占位：表格是通栏控件，撑满容器剩余宽 ---- */
    int rowh    = g_font_px + 8;
    int has_hdr = (nh > 0);
    int headerh = has_hdr ? rowh : 0;
    int contenth = (int)(nrows * rowh);
    int vh = (vh_req > 0) ? vh_req : headerh + contenth;
    if (vh < headerh + rowh)
        vh = headerh + rowh;

    int x, y, rw, rh;
    ui_rect(8, vh, &x, &y, &rw, &rh);
    (void)rw;
    (void)rh;
    int w = cur->x + cur->w - x;
    if (w < 60)
        w = 60;

    int bodyh = vh - headerh;
    int maxscroll = (contenth > bodyh) ? (contenth - bodyh) : 0;
    double scroll = st->num;
    if (scroll < 0)
        scroll = 0;
    if (scroll > maxscroll)
        scroll = maxscroll;

    int sb_w   = (maxscroll > 0) ? 8 : 0;
    int bodyx  = x;
    int bodyy  = y + headerh;
    int bodyw  = w - sb_w;
    SDL_Renderer *ren = game_renderer();

    /* ---- 交互：滚动条拖动（借 slider 的焦点-拖动手势） ---- */
    if (maxscroll > 0) {
        int trackx = x + w - 8;
        int thumbh = bodyh * bodyh / contenth;
        if (thumbh < 16)
            thumbh = 16;
        if (thumbh > bodyh)
            thumbh = bodyh;
        int thumby = bodyy + (int)((bodyh - thumbh) * (scroll / (double)maxscroll));
        int in_track = ui_in(trackx, bodyy, 8, bodyh);
        if (in_track && g_click)
            g_focus = id;
        if (g_focus == id && g_down) {
            double t = (double)(g_my - bodyy - thumbh / 2) / (double)(bodyh - thumbh);
            if (t < 0.0) t = 0.0;
            if (t > 1.0) t = 1.0;
            scroll = t * maxscroll;
        } else if (g_click && !ui_in(x, y, w, vh) && g_focus == id) {
            g_focus = 0;
        }
    }

    /* ---- 交互：点行选中 / 再点取消 ---- */
    long long hover_row = -1;
    if (g_mx >= bodyx && g_mx < bodyx + bodyw && g_my >= bodyy && g_my < bodyy + bodyh) {
        long long i = (long long)(g_my - bodyy + scroll) / rowh;
        if (i >= 0 && i < nrows)
            hover_row = i;
    }
    if (hover_row >= 0 && g_click)
        sel = (sel == hover_row) ? -1 : hover_row;

    /* ---- 画：表体底 → 裁剪画行 → 表头 → 滚动条 → 外框 ---- */
    ui_fill(x, y, w, vh, COL_BG);

    if (ren != NULL) {
        SDL_Rect clip;
        clip.x = bodyx; clip.y = bodyy; clip.w = bodyw; clip.h = bodyh;
        SDL_RenderSetClipRect(ren, &clip);
    }
    for (long long i = 0; i < nrows; i++) {
        int ry = bodyy + (int)(i * rowh) - (int)scroll;
        if (ry + rowh <= bodyy || ry >= bodyy + bodyh)
            continue;
        UiCol rc = (i == hover_row) ? COL_PANEL2 : ((i % 2 == 0) ? COL_PANEL : COL_ZEBRA);
        ui_fill(bodyx, ry, bodyw, rowh, rc);
        if (i == sel)
            ui_fill(bodyx, ry, 3, rowh, COL_ACCENT);
        int tx = bodyx + 6;
        for (long long cc = 0; cc < ncols; cc++) {
            ui_text(tx, ry + (rowh - g_font_px) / 2, grid ? grid[i * ncols + cc] : "",
                    g_font_px, (i == sel) ? COL_ACCENT : COL_TEXT);
            tx += (int)colw[cc];
        }
    }
    if (ren != NULL)
        SDL_RenderSetClipRect(ren, NULL);

    if (has_hdr) {
        ui_fill(x, y, w, headerh, COL_PANEL2);
        ui_fill(x, y + headerh - 1, w, 1, COL_BORDER);
        int tx = x + 6;
        for (long long cc = 0; cc < nh; cc++) {
            ui_text(tx, y + (headerh - g_font_px) / 2, hdr[cc], g_font_px, COL_DIM);
            tx += (int)colw[cc];
        }
    }
    if (maxscroll > 0) {
        int trackx = x + w - 8;
        int thumbh = bodyh * bodyh / contenth;
        if (thumbh < 16)
            thumbh = 16;
        if (thumbh > bodyh)
            thumbh = bodyh;
        int thumby = bodyy + (int)((bodyh - thumbh) * (scroll / (double)maxscroll));
        ui_fill(trackx, bodyy, 8, bodyh, COL_PANEL);
        ui_fill(trackx + 1, thumby, 6, thumbh,
                (g_focus == id) ? COL_ACCENT : COL_BORDER);
    }
    ui_stroke(x, y, w, vh, COL_BORDER);

    st->num = scroll;
    if (grid != NULL) {
        for (long long k = 0; k < nrows * ncols; k++)
            free(grid[k]);
        free(grid);
    }
    if (hdr != NULL) {
        for (long long c = 0; c < nh; c++)
            free(hdr[c]);
        free(hdr);
    }
    free(colw);

    ui_advance(w, vh);
    return rt_int(sel);
}
