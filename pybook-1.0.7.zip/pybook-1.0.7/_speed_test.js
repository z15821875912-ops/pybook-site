// 和 _speed_test.pybk 同一任务：10 万次循环累加取余
let h = 0;
for (let i = 0; i < 100000; i++) h += i % 7;
console.log("和 =", h);
