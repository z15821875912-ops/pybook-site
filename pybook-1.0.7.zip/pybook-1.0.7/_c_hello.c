#include <stdio.h>
int main(void){ printf("hello pybook\\n"); return 0; }
