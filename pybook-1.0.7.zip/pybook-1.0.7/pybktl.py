"""pybktl —— PYbook 大项目管理命令行工具（Phase 1）。

把「一堆散落的 .pybk 文件」当成一个工程来管。所有子命令都先读工程清单
PYBOOK.toml（[project] 段：entry / include / target / cache / separate），
再按工程视角操作。

子命令：
  deps  <PYBOOK.toml>     打印模块依赖图 + 拓扑序（被依赖者在前）
  check <PYBOOK.toml>     循环依赖检测（有环 exit 1）+ 全工程静态语法/语义检查
  build <PYBOOK.toml>     把工程拼成单文件编译单元并编译运行（复用 pybk_main）
  run   <PYBOOK.toml>     同 build（第一版 build 即「编译并运行」，run 等同）

设计说明（Phase 1）：
- 依赖分析（deps/check 的环检测）是纯静态层（pybk_project.py），不碰代码生成。
- build/run 目前通过「扁平镜像」复用现有 pybk_main 编译管线：
  把发现到的所有模块 + 入口复制到同一个 ASCII 构建目录，让 引用("名") 的
  扁平合并机制能找到它们（现有 _load_imports 只在同目录找被引文件）。
  这也是 Phase 2（#75 分模块增量编译）的缓存目录雏形。
- 跨目录 引用() 解析增强（#74）与分模块独立编译+真增量（#75）是后续任务，
  本文件已为它们预留 _flat_mirror 这个集中点。
"""

import os
import sys
import shutil
import subprocess

import pybk_project
from pybk_project import ProjectError


_BUILD_DIR = os.path.join('build_tmp', '_pybktl')


def _die(msg, code=1):
    print(msg, file=sys.stderr)
    sys.exit(code)


def _flat_mirror(manifest, modules):
    """把入口 + 所有被发现模块镜像到同一个 ASCII 构建目录。
    返回 (镜像目录, 镜像入口路径)。同名冲突（不同路径同名 .pybk）直接报错——
    这跟 discover_modules 的冲突检测互补：那里只查「发现表」内的重名，这里查
    镜像落盘时是否会互相覆盖。

    注意：现有 引用("名") 合并按文件名去 .pybk 匹配，所以镜像目录里每个
    模块必须独占一个不重名的 名字.pybk，扁平化正是为此。
    """
    if os.path.isdir(_BUILD_DIR):
        shutil.rmtree(_BUILD_DIR)
    os.makedirs(_BUILD_DIR, exist_ok=True)

    # 入口若不在发现表里，补进来
    entry_name = os.path.splitext(os.path.basename(manifest['entry']))[0]
    entry_path = (manifest['entry'] if os.path.isabs(manifest['entry'])
                  else os.path.join(manifest['root'], manifest['entry']))
    if not os.path.isfile(entry_path):
        _die(f"入口文件不存在：{entry_path}")
    sources = {}
    sources[entry_name] = entry_path
    for name, info in modules.items():
        if name in sources and sources[name] != info.path:
            _die(f"模块名冲突：{sources[name]} 与 {info.path} 都叫 {name}.pybk，"
                 f"扁平镜像无法共存（请用不同文件名或做命名空间）")
        sources[name] = info.path

    for name, src in sources.items():
        dst = os.path.join(_BUILD_DIR, name + '.pybk')
        shutil.copyfile(src, dst)
    return _BUILD_DIR, os.path.join(_BUILD_DIR, entry_name + '.pybk')


def cmd_deps(toml):
    res = pybk_project.analyze(toml)
    print(f"入口: {res['entry']}  ({res['entry_path']})")
    print(f"模块数: {len(res['modules'])}")
    for n, info in res['modules'].items():
        tag = ' [入口]' if n == res['entry'] else (' [库]' if not info.has_going else '')
        imps = ', '.join(i[0] for i in info.imports) or '（无引用）'
        print(f"  - {n}{tag}: 引用 {imps}")
    if res['cycles']:
        print("\n发现循环依赖：")
        for c in res['cycles']:
            print("  环: " + ' -> '.join(c))
        return 1
    print("\n无循环依赖 ✓")
    if res['topo']:
        print("拓扑序（被依赖者在前）: " + ' -> '.join(res['topo']))
    return 0


def cmd_check(toml):
    res = pybk_project.analyze(toml)
    rc = 0
    if res['cycles']:
        print("发现循环依赖（存在环则无法安全编译）：")
        for c in res['cycles']:
            print("  环: " + ' -> '.join(c))
        rc = 1
    else:
        print("循环依赖检测：无环 ✓")

    # 静态语法/语义检查：镜像后复用 pybk_main --check
    manifest = res['manifest']
    flat_dir, flat_entry = _flat_mirror(manifest, res['modules'])
    env = dict(os.environ)
    env['PYBK_IMPORT_DIR'] = flat_dir
    print(f"\n静态检查工程（入口镜像到 {flat_dir}）...")
    r = subprocess.run([sys.executable, 'pybk_main.py', '--check', flat_entry],
                       env=env)
    if r.returncode != 0:
        rc = 1
        print("静态检查未通过（见上）。")
    else:
        print("静态检查通过 ✓")
    return rc


def cmd_build(toml):
    res = pybk_project.analyze(toml)
    if res['cycles']:
        print("存在循环依赖，无法编译：")
        for c in res['cycles']:
            print("  环: " + ' -> '.join(c))
        return 1
    manifest = res['manifest']
    target = manifest.get('target') or 'app.exe'
    flat_dir, flat_entry = _flat_mirror(manifest, res['modules'])
    env = dict(os.environ)
    env['PYBK_IMPORT_DIR'] = flat_dir
    # 复用现有编译管线（编译 + 运行；输出名由管线缓存决定，target 仅作提示）
    print(f"编译并运行工程（入口 {res['entry']}，目标 {target}）...")
    r = subprocess.run([sys.executable, 'pybk_main.py', flat_entry], env=env)
    return r.returncode


def cmd_run(toml):
    # 第一版：run 等同于 build（编译并运行）
    return cmd_build(toml)


def main():
    if len(sys.argv) < 3:
        print(__doc__)
        sys.exit(2)
    sub = sys.argv[1]
    toml = sys.argv[2]
    try:
        if sub == 'deps':
            sys.exit(cmd_deps(toml))
        elif sub == 'check':
            sys.exit(cmd_check(toml))
        elif sub == 'build':
            sys.exit(cmd_build(toml))
        elif sub == 'run':
            sys.exit(cmd_run(toml))
        else:
            print(f"未知子命令: {sub}\n")
            print(__doc__)
            sys.exit(2)
    except ProjectError as e:
        _die(f"工程错误：{e}")


if __name__ == '__main__':
    main()
