# PYBOOK_AI.md —— 给 AI 的 PYbook 编程规范

PYbook 是一门中文优先的编程语言：编译到 C、原生 SDL 窗口、以 Python 级语法写 2D/3D 游戏。
本文写给将要**生成 PYbook 代码**的 AI（你）。读完这一页即可精准输出，无需读编译器源码。

## 30 秒上手

```python
@ 游戏>我的程序>1          # 元信息行（必有）

window(normal, open)       # 框架模式：win() 之前的语句只跑一次，之后的每帧跑

GOING:{
    vg.x = 100             # 新变量必须 vg. 前缀（声明）
    win(800, 500, "标题")  # 开窗口（框架模式必调）
    color(255, 200, 80)
    圆(x, 100, 10)         # 画一个圆
}STOP
```

运行：`python pybk_main.py 程序.pybk`（窗口程序）。
**只验证语法**：`python pybk_main.py --check 程序.pybk`（不弹窗，AI 改-验循环用这个）；
`--check-json` 输出 `{"ok": bool, "line": 行号, "message": …}`。

## 硬规则（违反即编译失败，每条都带行号报错）

1. **新变量声明必须 `vg.`**：`vg.x = 1`。声明过之后的同函数内裸赋值 `x = 2` 也合法。
   函数参数的元素可直接 `表[i] = 值`（参数例外）。
2. **函数读不到全局**：函数体内只能读自己的参数和自己赋过的变量。需要场景数据？把列表
   当参数传进去（列表按引用传）。
3. **用户函数调用不是语句**：`我的函数(1)` 单独一行非法。写 `vg.结果 = 我的函数(1)`。
4. **ret 只在 func 里**；`window(normal, open)` 必须在 GOING 之前、文件级。
5. **类可跨模块**：`引用("模块")` 会把模块的 `lb.` 类、函数、顶层变量一并并入；
   类名/函数名跨文件不得重复。PYbook 的 `lb.` 类系统支持：
   - **继承 + 多态**：`lb.狗 : 动物 { ... }`，子类同名方法覆盖父类，不写则继承；多态是
     运行时按对象真实类沿继承链分发，**参数/变量无需声明类型**。
   - **构造形参 + 构造体**：`lb.点(x, y) { vg.x=x; func 构造(){ self.半径=x+y } }`，
     构造时 `lb.点(3,4)` 按位置传参，构造体自动在属性初始化后执行。
   - **静态成员 / 类方法**：`静 vg.计数=0` 类级字段、`静 func 加(){ lb.圆.计数=lb.圆.计数+1 }`
     类方法，通过 `lb.类名.字段` / `lb.类名.方法(...)` 访问（实例上取不到）。
   构造器 `lb.类名(属性=值)` 的"属性名拼错"会带行号报错。
6. **key() 返回布尔**：不能 `key("a") + key("left")`，要 `if(key("a") or key("left"))`。
   注意 key 读全局键盘——别的窗口打字也会被算进去。
7. **插值字符串里不能再嵌引号**：`"$(表["键"])"` 非法。先 `vg.键 = "键"` 再 `"$(表[键])"`。
8. **`$名` 插值要求变量已声明**；任意表达式用 `$(表达式)`；字面 `$` 写 `$$`。
9. **文件名含中文没问题**；Python 3.11；2D 窗口走 `win()`，3D 走 `hw.*`（`ON 3D_highway` 开启）。

## 语境差异（AI 最容易踩的三处）

| 语境 | 裸赋值 | 裸下标赋值 | 说明 |
|---|---|---|---|
| GOING 里（无 window 语句） | 要 `vg.` | 要 `vg.` | 严格模式 |
| GOING 里（有 window(normal,open)） | 可裸 | 参数可裸、其余要 `vg.` | 宽松模式 |
| 函数体内 | 可裸（自己声明的） | 参数可裸 | 函数读不到全局 |

拿不准就全写 `vg.`——永远正确，只是啰嗦。

## 语法速查（P1~P4 全集）

```
vg.a, vg.b = 1, 2              # 多定义
a, b = b, a                    # 交换（右边先算完）
vg.dx, vg.dy = dirkeys()       # 解包：一个列表拆给多目标
vg.偶 = [x for x in 表 if x % 2 == 0]    # 列表推导
vg.翻倍 = {k: v * 2 for k, v in 词频}    # 字典推导
x > 3 ? 1 : 0                  # 三元
"值 = $(x + 1) 百分号$$"        # 任何字符串可插值；$() 里写完整表达式
分 += 10                       # += -= *= /=
xs[-1]  xs[1:4]  xs[::-1]      # 负索引 / 切片 / 反转步长
if(x in 表)  if(x not in 表)   # 成员判断（字符串两边则是子串判断）
for 词, 次 in 词频 { ... }      # 字典双变量遍历（列表单变量）
func 击杀分(基数 = 10, 连击加 = 5) = 基数 + 连击加 * 2   # 默认参数+单行函数
```

## 内置与标准库

- 帧/输入：`frame`（帧数）`sec`（秒）`dirkeys()`（WASD+方向键 → [dx,dy]）
  `key("a")` `hit("space")` `mx() my() mdown()`
- 绘制：`win(宽,高,"标题")` `color(r,g,b)` `clear()` `box(x,y,w,h)` `圆(x,y,r)`
  `线(x1,y1,x2,y2)` `字(x,y,"文本",号)` `图(x,y,"路径")` `图缩(x,y,w,h,"路径")`
- 聚合：`mt.sum(表)` `mt.max` `mt.min` `list.sorted(表)`（升序新表）
  `list.rsorted(表)`（降序新表）`list.byfield(对象表, "字段", 1或-1)`
- 字典：`{"键": 值}` 字面量；`长度(d)` `删掉(d, 键)` `dict.keys(d)` `dict.values(d)`
  `dict.byvalue(d, 1或-1)`（按键值排序取键）
- 列表：`长度(表)` `添加(表, 值)` `删掉(表, 值)` `list.find(表, 值)`（无则 -1）
  `list.sort(表)`（原地）
- 数学：`mt.sqrt abs floor ceil sin cos atan2 依此类推`（mt. 前缀，中文报错）
- 数据交换：`js.parse(文本)` / `js.dump(值)` JSON 读写（字典/列表/数字/字符串/真假/空，
  往返保真）；`csv.parse(文本)` / `csv.dump(表)` 表格文本（逗号引号换行自动处理）
- 列表进阶：`list.flat(嵌套表)`（一层展平）`list.zip(a, b)`（按位配对取短）`list.count(表, 值)`
- 空值字面量：`空` 或 `none`（js.dump 出 null）
- 像素画 MyMove（twoM）：列表即画布，一行字符串一排像素。`mm.draw_away(表, "名.png", 倍数)`
  落成 PNG（透明自动抠）；`mm.贴(表, x, y, 倍数)` 窗口直画；`mm.动([帧1, 帧2], x, y, 倍数, 帧率)` 逐帧动画
  （按帧率轮播帧列表）；`mm.色(token, r, g, b)` 自定义色。中英双名：color=色、blt=贴、anim=动。
  两种写法自动识别：行内含空格 = 多字符 token（`"b1 b2 ."`，`.` 透明）；整图无空格 = 单字符连写
  （`"..gg.."`，每字符一像素）。内置色阶 b/r/g/y/o/p 各 1~3 阶 + w/k/f 与单字符简谱
- 字符串：`te.join(表, "分隔")`（表在前！）`te.split(文本, " ")` `te.str(x)`（转文本）
- 声音：`音.快(频率, 毫秒, 波形)` 非阻塞；`mu.play("文件.wav")`
- 循环：`rm.around(n) -> i { ... }`（n 圈，i 从 0）；`for x in 表`；`rm.aging.while(条件)`
- 文本输出：`ns.show("a", 1, x)`（多参数空格相连，列表/字典直显）

## 标准库总览（全模块索引）

> 给 AI：下面这张表是 PYbook 全部标准库模块的"地图"。**写代码前先在这里定位模块，再查对应小节拿函数签名**。
> 后端列：`C` = 仅原生 exe（C 后端）可用；`双` = C 后端 + VM 后端（.pybc）都可用。带 `C` 的库在 VM 后端跑不了。

| 模块 | 用途 | 后端 | 实现 |
|---|---|---|---|
| `vg` / `ns` / `rm` | 变量声明 / 文本输出 / 循环 | 双 | 前端 |
| `te` | 文本（split/join/trim/chr/str…） | 双 | C 标准库 |
| `mt` | 基础数学（sqrt/sin/cos/sum/lerp…） | 双 | C 标准库 |
| `rd` | 随机（int/float/pick/shuffle） | 双 | C 标准库 |
| `safe` | 安全访问（at/get，越界/缺键不崩；也是 `.at`/`.get` 方法语法的底层） | 双 | 前端 |
| `list` | 列表（sort/sorted/find/flat/zip/count…） | 双 | C 标准库 |
| `dict` | 字典（keys/values/get/set/byvalue…） | 双 | 前端 |
| `file` | 文件读写（read/write/add/lines/split…） | 双 | C 标准库 |
| `tm` | 时间（now/stop） | 双 | C 标准库 |
| `mu` | 声音播放 play/stop/sine/tri | **C** | VM 编译能过但运行时报「在 VM 模式下不可用」（实测） |
| `音` | 声音中文全名（音/奏/谱/快/放/停/正弦/三角） | **C** | VM 编译能过但运行时报「在 VM 模式下不可用」（实测；音.* 已登记在 LIB_CALLS，故能编译） |
| `调色板` / `palette` | 内置常量色（红/橙/…/金 → [r,g,b]） | 双 | VM 实测返回 [r,g,b]（rt_lib_pal_* 已链入 pyvm.exe） |
| `js` / `csv` | JSON / CSV 互转 | 双 | C 标准库 |
| `bs` | 位运算（and/or/xor/shl/popcount/hex…） | 双 | C 标准库（pybook_bits.c） |
| `ui` | 即时模式 GUI（begin/row/label/button/slider/table…） | **C** | C 标准库（pyvm 未链 pybook_ui.c，实测仅原生 exe 可用） |
| `net` | TCP 网络（listen/accept/connect/send/recv） | **C** | C 标准库（仅 Windows） |
| `np` | 数值数组（逐元素运算，一维） | 双 | C 标准库（pybook_np.c） |
| `mp` | 数学进阶（向量/矩阵/统计/随机，一维列表） | 双 | C 标准库 |
| `tb` | 神经网络（算子库；底层张量见 `tensor`） | 双 | C 标准库 |
| `tensor` | **张量一等类型**（真·VM 对象：`T[i,j]` 多维索引、`T[a:b,c:d]` 切片、`A**B` 矩阵乘） | 双 | C 运行时（pybook_rt.c，RtTensor 扁平缓冲） |
| `mm` | 像素画 MyMove（列表即画布 → PNG/动画） | **C** | VM 运行时报「mm.draw_away 在 VM 模式下不可用」（实测） |
| `m3` | MyMove3D 体素建模（MC 风格） | **C** | 依赖 hw.box，随 hw 仅 C |
| `hw` | 3D（ON 3D_highway，软件光栅） | **C** | pyvm 未链 hw3d（build 注释自证） |
| `web` | 网页输出（生成 html + 浏览器） | **C** | pybk_bc 拒绝 web 语句进 .pybc（实测） |
| `smoke` | 安全检查（heap/type/expect/require） | 双 | C 标准库 |
| `ffi` | 底层窗口（编译期展开成 C 调用） | **C** | 编译期 |
| `mec` | 现代化语法（lambda/泛型/高阶函数/类型查询） | **C** | C 标准库 + mec.pybk |
| `宏` | 编译期内联宏（语句级，AST 展开） | 双 | 前端 |

## mec.* 现代化语法（lambda / 泛型 / 高阶函数）

> `mec` = Modernized_code。模块声明 `@ mec Modernized_code>mec>1`，写在 `games/mec.pybk`，用 `引用("mec")` 引入。
> **关键限制：lambda 和全部 `mec.*` 只在 C 后端（原生 exe）可用，VM 后端（.pybc）跑不了**——做跨端库别依赖它。

### lambda（语言级语法，可调用值）

```pybk
vg.双 = lambda(x) { ret x * 2 }          # lambda 表达式 → 可调用值
ns.show(mec.apply(双, [21]))             # 42：mec.apply 动态分发
ns.show(双(21))                          # 语法糖：变量直接当函数调，同上
vg.加5 = mec.部分(加, [5])               # 部分应用（闭包替代）：记住 a=5
ns.show(加5(3))                          # 8
```

- lambda **不捕获外部变量**，只看得见自己的参数；要"记住"一部分参数用 `mec.部分`。
- 调用方式二选一：`mec.apply(f, [参...])` 或 `变量名(参...)` 语法糖。

### 泛型算法（元素任意类型，靠动态类型通吃）

```pybk
活着的 = mec.filter(敌人, lambda(e){ ret e.血量 > 0 })
按伤害 = mec.sort_by(敌人, lambda(e){ ret e.伤害 })
vg.s = mec.reduce(表, lambda(a,b){ ret a+b }, 0)
```

| 函数 | 签名 | 用途 |
|---|---|---|
| `mec.map` | (表, f) | 每个元素跑 f，返回新表 |
| `mec.filter` | (表, f) | 留 f 为真者 |
| `mec.reduce` | (表, f, 初值) | 折叠 |
| `mec.each` | (表, f) | 遍历副作用 |
| `mec.find` | (表, f) | 首个 f 为真者，无则 空 |
| `mec.count_if` | (表, f) | 计数 |
| `mec.sort_by` | (表, f) | 按 f 提取的键升序（返回新表） |
| `mec.zip` | (甲, 乙) | 按位配对（取短） |
| `mec.flat` | (表) | 一层展平 |
| `mec.range` | (起, 止, 步) | 区间表 |
| `mec.部分` | (f, [预填参]) | 部分应用（闭包替代） |

### 类型查询 & 泛型容器（运行时类型锁定）

```pybk
ns.show(mec.kind(3))          # "整数"；还有 小数/文本/列表/字典/对象/真假/空
vg.整表 = mec.表("整数")      # 只收整数；"任意" 不锁，"数字" = 整数或小数
vg.ok = mec.追加(整表, 3)     # 1=成功 0=类型不符（不收，不报错）
vg.v = mec.取(整表, 0)  vg.n = mec.长(整表)
```

- `mec.kind(值)` → 中文类型名（用于运行时分支）。
- `mec.表(类型名)` 造类型锁定容器；`mec.收(类型名,值)` 返回 1/0（"任意"/"数字" 虚类型也认）；`mec.追加` 只在收下时入表。
- 这是**运行时泛型**，不是编译期 `<T>` 参数化——别向用户承诺编译期类型安全。

## 其余标准库速查（未在上文详述的模块）

### 随机 `rd.*`
`rd.int(范围, 缺省)` 随机整数（越界给缺省）；`rd.float()` 随机小数；`rd.pick(表)` 随机取一个；`rd.shuffle(表)` 原地洗牌。

### 时间 `tm.*`
`tm.now()` 当前毫秒时间戳；`tm.stop(标签, ...)` 打点计时（运行期零开销）。

### 文件 `file.*`（双后端）
`file.read(路径)` 整文件文本；`file.write(路径, 文本)` 覆盖；`file.add(路径, 文本)` 追加；`file.exists(路径)` 真假；`file.lines(路径)` 按行表；`file.del(路径)` 删；`file.size(路径)` 字节数；`file.list(路径)` 目录项表；`file.split(路径, 分隔)` / `file.join(分隔, 表)` 路径拼接。

### 字典 `dict.*`（双后端）
`dict.keys(d)` / `dict.values(d)` / `dict.get(d, 键, 缺省)` / `dict.set(d, 键, 值)` / `dict.byvalue(d, 1或-1)`（按值排序取键）/ `dict.max(d)` / `dict.min(d)`。

### 声音 `音.*` / `mu.*`（双后端）
`音.快(频率, 毫秒, 波形)` 非阻塞蜂鸣；`音.放("文件.wav")` 放音；`音.停()`；`音.正弦/三角(频率,毫秒)`；`音.音(频率,毫秒,波形)` / `音.奏(频率,时长,波形)` / `音.谱(频率表)` 奏乐。**`音.*` 与英文 `mu.*` 完全同义、可混用**：`mu.sine`/`mu.tri`(波形,毫秒)、`mu.play`(文件)/`mu.stop`/`mu.note`(名,频率,波形)/`mu.quick`(频率,毫秒,波形)/`mu.away`(表,文件名,速度)/`mu.play_list`(表,速度)。

### 调色板 `调色板.*`（双后端）
零参调用返回新建 `[r,g,b]`：`调色板.红/橙/黄/绿/青/蓝/紫/白/黑/灰/粉/金`。**英文别名 `palette.*` 完全同义、可混用**：`palette.red/orange/yellow/green/cyan/blue/purple/white/black/gray/pink/gold`（也可直接写中文色名 `palette.红`）。支持带括号 `palette.red()` 与无括号值 `palette.red` 两种写法。

### 位运算 `bs.*`（双后端）
`bs.and/or/xor/not(a,b)`；`bs.shl/bs.shr(a, n)`；`bs.get(数, 位)` / `bs.set(数, 位, 1或0)`；`bs.popcount(数)`；`bs.band(数)` 最低置位位；`bs.mask(n)` 低 n 位掩码；`bs.hex(数)` / `bs.bin(数)` / `bs.frombin(文本)` / `bs.fromhex(文本)`。

### 即时模式 GUI `ui.*`（仅 C 后端）
`ui.begin(宽,高,标题)` 开 UI 层；`ui.row()` / `ui.col()` / `ui.end()` 布局；`ui.gap(像素)`；`ui.tag(名)`；`ui.label(文本,?)` / `ui.button(文本)` / `ui.input(占位)` / `ui.slider(名,最小,最大)` / `ui.check(名,默认)` / `ui.table(选中,数据,表头,视口高)` 数据表（点行选中再点取消，返回行号；超视口出滚动条）。读控件状态用各自的返回值。

### TCP 网络 `net.*`（⚠ 仅 C 后端 / 仅 Windows）
`net.listen(端口)` 监听；`net.accept(句柄)` 等连接（返回新句柄）；`net.connect(地址, 端口)`；`net.recv(句柄)` / `net.readline(句柄)` 收；`net.send(句柄, 文本)` 发；`net.close(句柄)` 关。无 UDP/HTTP/TLS/WebSocket；VM 后端无映射——联网程序必须走原生 exe。

## 神经网络（tb.*：算子库，底层张量是语言一等类型 `tensor`）

> **张量现在是一等类型**（1.0.14 起）：独立的 VM 对象（不是二维列表语法糖），VM 后端与 C 后端都支持、行为一致。详见下一节「张量一等类型（tensor.*）」。下面 `tb.*` 仍是神经网络算子库，现在直接读写 `tensor` 张量对象。

```python
vg.W1 = tb.rand(4, 8)          # 4行8列 随机权重
vg.隐 = tb.relu(tb.lin(X, W1, B1))     # 全连接 + ReLU
vg.概 = tb.softmax(tb.lin(隐, W2, B2)) # 分类输出：每行和为1
vg.损 = tb.crossent(概, Y)      # 交叉熵（Y 是类别号列向量 [[3],[1],...]）
vg.g = tb.lin_dw(隐, tb.crossent_grad(概, Y), W2)   # 梯度链
tb.sgd(W2, g, 0.1)              # 就地更新（lr=0.1）
```

- 形状：`tb.rows(M)` `tb.cols(M)` `tb.mat(行,列,值)` `tb.tr(M)`（转置）
- 运算：`tb.dot(A,B)` `tb.add(A,B)` `tb.mul(A,B)`（逐元素）
- 层：`tb.lin(X,W,B)` 全连接；`tb.relu` `tb.sigmoid` `tb.softmax`
- 损失：`tb.mse(预测,真值)`；`tb.crossent(概率,类别)`；对应 `*_grad` 同参数
- 优化器：`tb.sgd(W,梯度,lr)`；`tb.adam(W,梯度,M,V,lr,b1,b2,步数)`（M/V 各自
  `tb.mat` 同形零矩阵，传进去会被更新）
- 数据：`tb.rand(行,列)` `tb.shuffle(列表,种子)`（同种子同结果）
  `tb.onehot(n,类别数)` `tb.batch(列表,批号,大小)`（批号从0，批 i 取 [i*大小, i*大小+大小)，末尾不足截断，越界得空表）
- 完整可跑示例：`AI走迷宫.pybk`、`神经网络示例.pybk`（两层网络 + Adam 训练到 100% 准确率）

### 张量一等类型（tensor.*：真·VM 对象，不是二维列表语法糖）

> `tensor` 是语言一等类型：底层 `RtTensor{ ndim, dims, data }` 扁平 double 缓冲，挂在 `OBJ` box-tag（`RTK_TENSOR=5`）。VM 后端（.pybc）和 C 后端（原生 exe）都支持，行为一致。**`tensor` 不在 `_VM_UNAVAILABLE`，VM 模式可用**。

```python
vg.M = tensor.from([[1,2,3],[4,5,6],[7,8,9]])   # 从嵌套列表造张量
vg.x = M[1, 2]              # 多维索引：第1行第2列 = 6
M[0, 0] = 99                # 多维赋值（原地改 data 缓冲）
vg.行 = M[0]                # 取单行（返回新张量）
vg.块 = M[0:2, 0:2]         # 二维切片：行[0,2)×列[0,2)
vg.块2 = M[0:2, 1:3]        # 每维上下界都要显式写
vg.P = A ** B               # 矩阵乘（脱糖成 tb.dot，多线程）
vg.值 = tensor.get(M, 1, 1) # 取元素（函数式写法，等价 M[1,1]）
vg.L = tensor.to_list(M)    # 转回嵌套列表（ns.show 打印值用这个）
```

- **语法**：
  - `M[i, j]` 多维索引 / `M[i, j] = v` 多维赋值 → `tensor.get` / `tensor.set`
  - `M[a:b, c:d]` 二维切片，每段上下界必须显式写出 → `tensor.slice`；**暂不支持步长**
  - `M[i]` 取单行（返回新张量，等价于取该行所有列）
  - `A ** B` 矩阵乘（脱糖为 `tb.dot(A, B)`，走多线程）
- **标准库 `tensor.*`**：`from(嵌套列表)` `to_list(张量)` `get(M,i,j)` `set(M,i,j,v)` `slice(M,r0,r1,c0,c1)`（缺省界用 `空`/`none` 省略）
- **与 `tb.*` 的关系**：`tb.*` 仍是神经网络算子库，现在底层统一读写 `RtTensor` 扁平缓冲（29 个函数全迁移完），`tb.dot` 等可直接吃 `tensor.from` 造出的张量。
- **限制（v1）**：v1 只做二维（矩阵）；`tb.tr` 转置等仍返回张量对象可继续参与运算；`ns.show(张量)` 只打印变量名（裸 VarRef 的既有约定），要打印数值用 `ns.show(tensor.to_list(M))`。

## 数学进阶（mp.*，math+：向量/矩阵/统计/随机，元素全是**一维列表**）

```python
vg.v = mp.vec_add([1,0,0], [0,1,0])      # 向量：add/sub/scale/dot/cross/norm/normalize/dist/lerp
vg.M = mp.mat_mul(A, B, 2, 3, 3)         # 矩阵乘：mat_mul(A,B,行,中,列)——矩阵存成一维列表，形状另传
vg.D = mp.mat_det(M, 3)                  # 方阵：det/inverse(M,n)；mat_identity(n)
vg.sd = mp.std(数据, 0)                  # 统计：mean(表) var/std(表,ddof) minmax(表)→[最小,最大]
vg.x = mp.lerp(0, 100, 0.5)              # 插值族：lerp/clamp/smoothstep(边0,边1,x)
vg.n = mp.rand_normal(0, 1)              # 正态随机数；rand_u01()均匀[0,1)；rand_seed(种子)
```

- 矩阵函数一律 **一维列表 + 行列参数**（和 tb.* 的二维列表是两套体系，别混用）
- 角度函数 `mp.radians(度)` `mp.degrees(弧度)`；`mt.*` 是基础数学（sqrt/sin/…），够用就别用 mp

## 数值数组（np.*，numpybk：一维数组 + 逐元素运算）

```python
vg.a = np.range(0, 10, 2)        # [0,2,4,6,8]；np.zeros(n) 全零
vg.b = np.add(a, [1,1,1,1,1])    # 逐元素 add/sub/mul；np.scale(数组, 系数)
vg.c = np.sin(a)                 # 逐元素 sin/cos/sqrt
vg.d = np.normalize(v)           # 单位化；np.norm(v)；np.dot(a,b)
vg.m = np.mean(a)                # 聚合：max/min/sum/mean
```

np 和 mp 的向量功能有重叠：纯数组逐元素运算用 np，需要矩阵/统计/随机用 mp。

## 网页输出（web.*：编译运行后生成 pybook_page.html 并自动弹浏览器）

```python
@ 博客>首页>1
GOING:{
web.title("我的主页")
web.big(你好 $名字)                       # 大标题；web.mid 中标题
web.show(得分 $分数 / 2)/magic(b, c=0,200,255)   # 段落；$() 任意表达式；/magic 修饰可省
web.img("风景.png")                       # 图片；web.line 分隔线
web.link("教程", "https://…")             # 超链接
web.draw.始                               # 开画布；帧动画和实时块都要包在 始/终 之间
web.帧 { web.draw.色(255,0,0)  web.draw.圆(100,100,30) }   # 预烤动画帧
web.帧 { web.draw.色(0,0,255)  web.draw.圆(200,100,30) }
web.播放(12)                              # 以 12 帧/秒循环之前的所有 帧
web.实时(60) { web.draw.清(0,0,0)  web.draw.圆(web.mx(), web.my(), 10)
    if(web.down("go")) { web.draw.色(0,255,0) } }        # 浏览器实时循环
web.draw.终
web.textbox("输入名字", "nm")             # 页面控件：输入框、按钮
web.button("点我", "go")
}STOP
```

- 画布绘图动词：`web.draw.始/色/圆/方/线/清/字/图/图缩/终`；**实时块里参数是表达式每帧重算**，
  预烤帧里参数烤成常量；画布缺省 400×300，`web.draw.始(800, 450)` 可调（鼠标坐标自动按尺寸换算）
- **多页 `web.页("名") { 页面语句 }`**：烤成独立文件 `pybook_page_名.html`，页间用
  `web.link("文字", "pybook_page_名.html")` 跳转；页里不能套 帧/播放/实时/draw/嵌套页
- **组件复用 `web.块`**：文件顶层定义、GOING 里按名调用，实参是表达式（字符串/数字/已声明变量），
  块体内用 `$参数名` 插值；块内可再调用别的块（先定义后用），但**不能**用 帧/播放/实时/draw
  ```python
  web.块 卡片(标题, 内容) {
      web.mid($标题)
      web.show($标题：$内容)
  }
  GOING:{ web.卡片("水果", "苹果 3 元")  web.卡片("蔬菜", "白菜 1 元") }STOP
  ```
- 交互：`web.textbox(占位, id)` `web.button(文字, id)` 是页面控件语句；读取用表达式
  `web.text("id")`（输入框内容）`web.down("id")`（按钮按下中）`web.click()`（画布被点）`web.mx() web.my()`
  ——**这些表达式只在网页程序（实时块/帧参数）里有效**，桌面窗口程序里没有
- 杂项：`web.audio("文件")` / `web.audio.stop()`；`web.align("center")` `web.gap(像素)`
  `web.style("css")` `web.storage("键","值")` `web.open("网址")` `web.waitsec(秒)`
- `ns.show(...)/magic(...)` 在网页程序里同样输出为段落，magic 是 HTML 标签/样式参数

## 3D（hw.*：文件头写 `ON 3D_highway`，软件光栅，自带窗口）

```python
@ 演示>3D>1
ON 3D_highway

GOING:{
hw.open(800, 500, "我的3D")      # 自管窗口和循环，不要再调 win()
hw.clearcolor(20, 24, 48)        # 天空色
hw.camera(0, 1.6, 0, 0)          # x,y,z,朝向(弧度)，俯仰可省 → 5 参
hw.box(0, 0, 5,  1, 1, 1,  200, 60, 60)   # x,y,z, 宽高深, 颜色 —— 9 参
hw.text(10, 10, 2, "得分 $分")    # 屏幕文字：x, y, 字号, 文字（字号在文字前面！）
hw.grab()                        # FPS 视角：锁鼠标（hw.free() 解锁）
hw.frame()                       # 每帧末必调（内部约 60FPS）
}STOP
```

- 输入：`hw.key("w")` `hw.hit("space")` `hw.mx() hw.my() hw.mdown()`；
  **鼠标增量** `hw.mdx() hw.mdy()`（配 hw.grab 做视角）；
  右键 `hw.rdown()`（按住=1）/ `hw.rhit()`（按下的那一帧=1）
- `hw.grab()` 锁鼠标、`hw.free()` 解锁。锁了之后光标不会跑出窗口：
  引擎每帧重申相对模式，窗口万一没焦点还会把光标按回客户区中心兜底
- **按 Esc 不会退出程序**（只把锁住的鼠标放开，因为锁了鼠标就点不到关闭按钮了）。
  退出要点窗口的 X / Alt+F4 —— 那才让 `hw.end()` 返回真，循环才结束。
  想让 Esc 干别的事，读 `hw.hit("esc")`（**键名是 `esc`**）
- **HUD 坐标 = `hw.open` 的宽高**（叫"设计尺寸"）。窗口被拉伸 / 最大化 / 高 DPI
  放大时，HUD 会整体缩放去贴窗口四边，**不用自己按比例算**。
  想拿真实尺寸用 `hw.wininfo()` → `[设计宽,设计高, 逻辑宽,逻辑高, 像素宽,像素高, 鼠标锁住了吗]`；
  程序自己改窗口用 `hw.resize(宽, 高)`；`hw.mx()/my()` 返回的也是设计坐标
- 高频坑：忘写 `ON 3D_highway` → hw.* 全部报"需要先 ON"；调了 win() 会和 hw.open 打架；
  hw.frame() 漏调 → 黑屏不刷新；
  **手持武器（第一人称视角模型）必须 `hw.near(0.06)`**，默认近裁剪面是 1.0，
  离眼睛 0.5 米的枪会被整个裁掉看不见

## 3D 模型文件（hw.obj*：把 Blender 导出的 .obj 搬进来）

```python
ON 3D_highway
GOING:{
hw.open(800, 500, "模型")            # 必须在 hw.open 之后才 hw.obj（要传贴图）
vg.船 = hw.obj("objtest/probe.obj")  # 加载 .obj（顺带读同名 .mtl）；失败返回 0
vg.信 = hw.objinfo(船)               # [顶点数, 三角数, minx,miny,minz, maxx,maxy,maxz]
vg.顶 = hw.objh(船, 3.0, 5.0)        # 竖直往下打射线 → 该点地面最高的 y（没中返回 -1e9）
vg.丢 = hw.objfix(船, 1)             # 0=不动 1=前脸转到+X 2=Z-up→Y-up 3=都做（只调一次）
hw.objdraw(船, 0, 0, 5, 1.0)         # 句柄, x,y,z, 缩放
hw.objdrawr(船, 2, 0, 5, 1.0, 0, 1.2, 0)  # 再加旋转（绕自身包围盒中心，弧度）
hw.objcolor(船, 120, 220, 160)       # 整体换色（盖掉材质色），不调就用 .mtl 的
hw.objfree(船)                       # 释放；释放后再画会报"句柄无效"
hw.frame()
}STOP
```

- 路径规则同 `hw.tex` / `m3.load`：相对**进程当前目录**（→ exe 目录），不是 .pybk 所在目录
- `hw.objh(句柄, x, z)`：竖直往下打一条射线，返回该点**地面最高的 y**，没打中返回 `-1e9`。
  在起伏地形上走路 / 站到模型顶上靠它。引擎按 XZ 切 64×64 格建了索引
  （存三角形下标，所以 `hw.objfree` 压缩顶点池也不会失效），
  4 万面的地图也能每帧问几十次。整个身子沉在地面以下是"忘了加地形高度"的典型症状
- **hw 世界里 yaw=0 的正前方是 +X**，obj 标准是 −Z 朝前 → 想让它面朝镜头写 `hw.objfix(句柄, 1)`
- 材质自带贴图优先；没贴图的材质吃 `hw.texuse` 的槽 + `hw.uv` 的平铺
- 模型是"加载一次长期驻留"，不像 `hw.box` 每帧清空；`hw.objdraw` 写在 `hw.frame()` 之前
- 上限：同驻留 64 个模型、全部合计 100 万顶点（约 33 万面）、单帧 4096 次绘制
- 解析范围：`v/vt/vn/f`（`f` 四种写法、n 边形、负索引都认）；没 `vn` 按面法线补，
  没 `vt` 按主轴投影现算 UV。`.fbx/.glb/.blend/.stl` 不是这个格式，得先导出成 .obj
- "加载完一片黑"多半是没打光 → `hw.preset(1,"lambert")` + `hw.shaderuse(1)`

## MyMove3D（m3.*：MC 风格体素建模，列表即模型）

```python
ON 3D_highway
GOING:{
m3.color("d", 160, 100, 40)          # 注册色 token（或复用 mm 调色板）
# m3.texture("g", "草.png")          # token 绑纹理（走 hw.tex 槽）
# m3.pack("材质/默认")                # 一键加载材质包（目录 pack.txt + png）
# m3.glass("n", 140, 200, 255, 0.35) # 真透明玻璃（alpha 0~1）
# m3.glow("l", 40, 230, 255)          # 夜光方块

# 模型 = 列表的列表：每个子列表 = 一个 Y 高度层（从下到上）
# 层内一行 = Z，一格 = X；. _ 空气
vg.屋 = [
  ["kkkk", "k..k", "k..k", "kkkk"],
  ["kkkk", "k.d k", "k..k", "kkkk"],   # 空格分隔 = token 模式
  ["kkkk", "kkkk", "kkkk", "kkkk"]
]
vg.n = m3.count(屋)                  # 体素数
vg.b = m3.bounds(屋)                 # [宽X, 高Y, 深Z]
vg.丢 = m3.draw(屋, 0, 0, 0, 1.0)    # 画进当前帧（一格 = scale）
vg.丢 = m3.drawr(屋, 0, 0, 0, 1.0, 0, 1.2, 0)   # 带旋转（弧度）
vg.丢 = m3.anim([帧1, 帧2], 8, 0, 0, 1.0, 6)    # 多帧轮播
vg.新 = m3.merge(屋, 附件, 2, 0, 0)  # 拼装
vg.新2 = m3.dig(新, 0, 0, 0)         # 挖方块（返回新模型）
vg.新3 = m3.put(新2, 0, 0, 0, "d")   # 放方块
vg.丢 = m3.save(屋, "名.m3d")        # 落盘
vg.读 = m3.load("名.m3d")
vg.丢 = m3.uv(2)                     # 贴图平铺
}STOP
```

- 一格 = 一个 `hw.box` 方块，MC 严丝合缝网格；尺寸上限 32³
- token 解析：`m3.texture` 槽 → `mm.色`/内置色 → `#rrggbb` / `@N`（序列化）
- **`m3.color` / `m3.texture` 必须在解析模型之前调用**
- `m3.draw` 在 `ON 3D_highway` 帧内调用；依赖 `hw.box`

## 高频坑（本规范作者的 AI 同行实际翻车记录）

- `te.join(表, " ")` 参数顺序：**表在第一**。
- **保留字别拿来做变量名**：模块前缀全是保留字 —— `mm te mt rd mu np tb mp ui hw bs js
  csv web file list tm net m3 smoke mec 音 查 调色板`。
  用 `mm = 1` 报的是 **"不是合法的语句开头：'mm'"**，完全看不出是重名。
  （`mm` = Memoryment，最容易撞。）
- 函数做语句不行 → 赋值；模块类不可见 → 平行列表模式。
- 3D：`ON 3D_highway` 在文件头；`hw.box(x,y,z, w,h,d, r,g,b)` 9 参；
  `hw.frame()` 每帧末必调；`hw.open()` 自管窗口不要再用 `win()`。
- 窗口程序编译通过≠正确：先用 `--check` 验语法，再跑窗口看行为。
- `win()` 之后的代码每帧重复执行——把只会做一次的事（清空列表、读文件）放 `win()` 之前。

## AI 踩坑速查（保留字 / 隐藏规则 / API 对照）

> 这一节是**实战翻车记录** —— 每条都是真踩过的。**先查这里再写代码**，能省好几轮试错。

### 🔴 保留字（不能做变量名 —— 报错会**指错方向**）

**全集 73 个**（来自 `pybk_front.py` 的 `KEYWORDS`；含后续版本加的 `宏`/`lambda`/`ffi`/`mec`），分类如下：

**① 控制流（14 个）**
```
if  elif  else  while  for  in  break  断  try  catch  onerror  and  or  not
```

**② 值 / 字面量（6 个）**
```
true  false  真  假  空  none
```

**③ 声明 / 定义（10 个）**
```
func  ret  del  lock  self  import  引用  when  宏  lambda
```

**④ 程序结构（2 个）**
```
GOING  STOP
```

**⑤ 库前缀（41 个）—— 也不能做变量名**
```
vg  vg_ro  ns  rm  list  show  input  at  net  web  js  csv  lb
te  mt  rd  file  tm  音  调色板  mm  mu  palette  macro  Memoryment
ip  vc  window  ON  hw  np  tb  mp  ui  bs  tw  data  m3  smoke  ffi  mec
```

**⚠ 一词多用的（既是关键字又是库前缀，最容易撞）**
```
list  show  input  at  net  window  file  mm
```

**踩坑实录**：写 `vg.查 = 查 + 1` → 报「变量声明必须以 vg. 开头」
**真相**：`查` 是保留字！报错**指错了方向**（说是声明规则问题）。
**做法**：变量名避开上面这些（`vg.查验数` 就行）。

**快速自查**：写变量名前，扫一眼这 73 个 —— 中文名（`真`/`假`/`空`/`查`/`断`/`音`/`调色板`/`引用`/`宏`）
和短英文名（`at`/`lb`/`ip`/`vc`/`mm`/`mp`/`np`/`tb`/`bs`/`tw`/`mu`/`rd`）最容易撞。

### 🔴 隐藏规则（违反报错，但报错**不会告诉你规则**）

| 规则 | 报错长什么样 | 正确写法 |
|---|---|---|
| **`表[i] = 值` 只在函数参数里合法** | 「变量声明必须以 vg. 开头」| GOING 块写 `vg.表[i] =`，或**包进 func** |
| **`if(...) {...}` 后不能直接跟语句** | 「不是合法的语句开头：'STOP'」| `if` 块后空一行，或写 `}STOP` 收尾 |
| **字符串转义** | 支持 \n \r \t \"\\ | 例 "a\nb" = a 换行 b；字符串**不能跨行**（裸换行报"未闭合"）；te.chr 老写法兼容 |
| **函数内看不到全局** | 「变量未声明」| 函数内只能读参数 + 自己赋过的；要用就传参 |
| **`Memoryment@X` 作用域** | 模式不对报错 | 函数内要重新声明 `Memoryment@self` |

### 🟡 API 对照（中文直觉 ≠ 实际名字）

| 你想写的 ❌ | 实际是 ✅ | 说明 |
|---|---|---|
| `时间.秒()` / `时间.now()` | **`tm.now()`** | 计时（毫秒）|
| `te.字符(10)` | **`te.chr(10)`** | 按码点造字符（英文 API）|
| `smoke.查(v)` | **`smoke.check(v)`** | 1.0.5.2 起全英文 |
| `list.添加(表, x)` | **`添加(表, x)`** | 全局函数，不是 list. 方法 |

**通用规律**：**库里是英文**（`tm.*`/`te.*`/`smoke.*`/`hw.*`），**语句是中文**（`vg.`/`ns.`/`rm.`/`func`/`del`）。

### 🟢 新特性速查（1.0.5.2+）

```bash
python pybk_main.py --check 文件     # 语法+语义检查（必跑）
python pybk_main.py --version       # 版本号
python smokeroor.py                 # 安全体检（红绿灯报告）
python smokeroor.py --learn         # 自动学习期望（生成 .expect）
```

```pybk
# 安全检查（smoke.*，全英文，零成本）
vg.s = smoke.check(a)          # ["OK"] / ["DELETED"] / ["DANGLING"]
vg.t = smoke.type(a)           # INT / FLT / STR / LIST / DICT / OBJ
vg.h = smoke.heap()            # [错误, 悬垂, 根数, 模式, 字节, 单元, minor, major]
vg.丢 = smoke.expect(条件, "文案")    # 软断言（不中断，跑完看汇总）
vg.丢 = smoke.require(条件, "文案")   # 硬断言（假则立即报错）

# 字符串换行/回车（现在支持转义：反斜杠n 即换行；te.chr 是老写法）
vg.文本 = te.join(行, te.chr(10))    # 拼多行
```

## ffi.* 底层窗口（FFI）—— 直接调 C 函数/系统 API

> **城外的门开着了**：PYbook 编译成 C，`ffi.*` 在编译期展开成真 C 调用（零包装）。
> 签名**照抄真实的 C 声明**（和 ctypes 一样）；签名写错会崩 —— 这是开窗的代价。

```pybk
# ① 调 C 标准库（签名要和真的完全一致，含 const）
ffi.声明("size_t strlen(const char*)")
GOING:{
vg.n = ffi.调用("strlen", "hello")        # → 5
}STOP

# ② 调系统 API（Win32）：ffi.包含 头文件、ffi.链接 库
ffi.包含("windows.h")
ffi.链接("user32")
ffi.声明("int GetSystemMetrics(int)")
GOING:{
vg.w = ffi.调用("GetSystemMetrics", 0)    # 屏幕宽，真调到了 Win32
}STOP

# ③ 逃生门：ffi.码 写原样 C（文件作用域，自己对自己负责）
ffi.码("int py_demo_add(int a, int b) { return a * 100 + b; }")
ffi.声明("int py_demo_add(int, int)")
GOING:{
vg.n = ffi.调用("py_demo_add", 3, 7)      # → 307
}STOP
```

**五个函数**：`ffi.包含("头文件")` / `ffi.链接("库名")` / `ffi.声明("签名")` / `ffi.码("原样C")` / `ffi.调用("名", 参数...)`

**类型转换**（PYbook 值 ↔ C）：
| C 类型 | PYbook 侧 |
|---|---|
| int/long/size_t... | 整数（文本能解析也收）|
| double/float | 整数或小数 |
| char*/const char* | 文本（空值 → NULL）|
| void*/指针 | 整数地址 / 文本 / 空 |
| 返回 char* | 文本（拷贝；NULL → 空）|
| 返回指针 | 整数地址 |

**规则**：
- `ffi.声明` / `ffi.调用` 的函数名**必须是字面量**（编译期要知道调谁）
- 签名格式：`返回类型 函数名(参数类型, ...)`，参数名可省
- 同一函数只准声明一次（两种签名会报错）
- **不支持**：函数指针参数、结构体传值、变参（用 `ffi.码` 手写包装）
- `ffi.*` 可以放文件头（顶层）或 GOING 里 —— 都是编译期生效，运行期零开销

## 宏（inline code macro，编译期内联展开）

> **批量生成重复代码用的**：`宏 名(参数){...}` 定义一段"代码模板"，调用 `名(实参)` 时。
> **关键字 `宏` 与英文 `macro` 完全等价、可混用**（如 `macro 名(参数){...}`）。
> 在**编译期**把实参替换进模板、原地展开成若干条语句。**不是函数调用**——没有调用开销、
> 不进调用栈、生成的代码和手写一模一样。C 后端和 VM 后端共用同一套前端展开。

```pybk
宏 血条(对象, 屏x, 屏y) {
    color(220, 40, 40)
    box(屏x, 屏y, 100 * 对象.血 / 对象.血上限, 8)   # 对象/屏x/屏y 编译期换成实参
}

GOING:{
    血条(玩家, 10, 10)
    血条(敌1, 220, 10)        # 展开后 = 把模板里的 对象/屏x/屏y 换成 敌1/220/10
}STOP
```

**规则**：
- **只能当语句调用**，不能当表达式取值。`vg.x = 血条(...)` 非法（宏展开成的是"语句"不是"值"）。
  要批量算返回值，老老实实写 `func`。
- **零参宏也要写 `()`**：`宏 初始化() {...}`，调用 `初始化()`。漏括号会报"不是合法的语句开头"。
- **支持宏套宏**（模板里调另一个宏），编译期一路展开到底。
- **不支持递归**：模板调自己会被栈深守卫拦下，报"宏 名 递归展开（编译期不允许）"。
- **参数按"变量引用"替换，不是文本替换**：模板里出现的 `参数名`（作为变量名 / 数组下标 /
  成员对象 / for 循环变量 / 被调函数名）会被替换成对应实参表达式的**深拷贝**——所以没有 C 宏
  那种"同一个参数被求值多次"的坑。`x = 对象.血` 里的 `对象` 会被换成实参，但字符串字面量
  `"对象"`（当文本出现的）不会动。
- **`引用("模块")` 里定义的宏会一起并入**：跨文件宏在 C 后端和 VM 后端都能用（走同一套前端展开）。

**报错**（都带三段式 为什么/怎么改）：
- 实参与形参个数不符 → "宏 名 需要 N 个参数，实际给了 M 个"
- 宏名和已有 `func` 重名 → "宏 名 与函数 名 重名"
- 同一文件定义两个同名宏 → "宏 名 重复定义"
- 递归展开 → 上面那条

**适合 / 不适合**：
- ✅ 给一组相似对象写重复 UI / 绘制 / 初始化（上面血条就是）
- ✅ 把"一组配套语句"打包成一个可读的名字，避免复制粘贴漂移
- ❌ 需要返回值 → 用 `func`
- ❌ 参数个数不定的变参 → 用 `func` + 表

## 做库的人注意的规范（Library Author Guide）

> 写给要写 PYbook 标准库 / 第三方库的人。遵守这些，你的库才能跨后端、被 AI 正确生成、被人类读懂。

### 1. 模块声明与导入
- 库文件头：`@ 名 路径>命名空间>版本`（如 `@ mec Modernized_code>mec>1`）。
- 用户用 `引用("名")` 把你的 `lb.` 类、函数、顶层变量一并并入；**跨文件类名/函数名不得重复**，否则冲突报错。
- 破坏性改动升版本号；保持旧版本可并行。

### 2. 命名
- 库函数用 `模块.函数` 前缀风格（`te.split` / `mec.map`）。
- **模块前缀全是保留字**（`te mt rd list file tm 音 调色板 mu net hw np tb mp ui dict js csv mm bs m3 smoke ffi mec`…）。别拿它们当变量名，也别起和已有前缀撞的新前缀。
- 中文名（`真/假/空/查/断/音/调色板/引用/宏`）和短英文（`at/lb/ip/vc/mm/mp/np/tb/bs/mu/rd`）最容易撞保留字。

### 3. 后端一致性（双管线，最致命）
PYbook 有两条执行路径：**C 后端（原生 exe）** 和 **VM 后端（.pybc 字节码）**。两者前端共享，但部分能力只在 C 后端：

| 只在 C 后端 | C + VM 双端 |
|---|---|
| `lambda` + 全部 `mec.*`；`mu.*` / `音.*`（声音，VM 运行时不可用）；`net.*`（TCP，且仅 Windows）；`ffi.*`（编译期展开成 C）；`hw.*` / `web.*` / `ui.*` / `mm.*` / `m3.*`（VM 均未链对应运行时，编译期即拒绝） | `宏`（前端 AST 展开）；`te/mt/rd/list/dict/file/tm/js/csv/bs/mp/np/tb/smoke` + `调色板`/`palette`（VM 实测可用）+ 内置语句 |

**规则**：你的库若用了 lambda / `mec.*` / `net.*` / `ffi.*`，**必须在文档和注释里写明"仅原生 exe（C 后端）可用，VM 后端不支持"**。想做跨端库，优先用 `宏` 做代码生成（双端通用），别用 lambda。

### 4. lambda 与函数作值
- lambda **不捕获外部变量**，只看得见自己的参数；"记住一部分参数"用 `mec.部分(f, [预填参])`。
- 把函数当值传来传去：定义 `func` 后，调用处写 `函数名(参)` 语法糖，或 `mec.apply(函数名, [参])` 动态分发。
- 递归 lambda 不支持（没有名字可递归）。

### 5. 宏（编译期内联）
- `宏 名(参数){...}` 定义，调用 `名(实参)` 在编译期就地展开成语句。
- **只能当语句用**（不产出值）；**不支持递归**（栈守卫拦）；**不能和 `func` 重名**；零参宏也要写 `()`。
- 参数按"变量引用"深拷贝替换（非文本替换）→ 没有 C 宏"参数多次求值"坑；字符串字面量里的同名文本不会动。
- 宏在 C / VM 双后端通用（前端展开）——跨端库优先用。

### 6. 运行时类型与守卫
- 运行时分支用 `mec.kind(值)` 拿中文类型名（整数/小数/文本/列表/字典/对象/真假/空）。
- 要锁类型的容器用 `mec.表("整数")`（"任意" 不锁，"数字" = 整数或小数）；`mec.追加` 类型不符返回 0 不收。
- 这是**运行时泛型**，不是编译期 `<T>` 参数化——别向用户承诺编译期类型安全。

### 7. 错误处理（给用户兜底）
- 优先用安全访问器 `表.at(i, 缺省)` / `字典.get(键, 缺省)`（越界/缺键不炸）。
- 必要时 `try { } catch e { }` 抓运行时错误，`onerror err { }` 全局兜底（游戏不白屏）。

### 8. 报错风格（配合 lookaround 中文翻译）
- 库自己做运行时校验时，报错信息写**中文**、带"为什么/怎么改"三段式，lookaround 会原样翻给人看。
- 别抛英文堆栈让用户自己猜。

### 9. 写 C 扩展
- 简单调 C / 系统 API 用 `ffi.声明("签名")` + `ffi.调用("名", ...)`（签名照抄真 C 声明，含 const）。
- 要进标准库、有固定语义的，写进 `pybook_lib.c` 等并在 `pybk_front.py` 的 `LIB_CALLS` 登记 `(前缀.函数: 元数)`。
- `ffi.码("原样C")` 是逃生门，自己对自己负责。

### 10. 文档与 AI 友好
- 库文件顶部用 `#` 写用法示例（像 `mec.pybk` 那样：lambda / 部分应用 / 泛型算法 / 泛型容器分段注释）。
- 把本规范的"标准库总览"和你的模块小节喂给 AI——AI 不认识 PYbook 就写不出对的代码。

## 报错怎么读（三段式：错了什么 + 为什么 + 怎么改）

**报错现在自带三段式**（1.0.5.3 起）—— 拿到报错**先读完三行**，多数当场知道怎么改：

```
第 3 行：期望 'NAME'，实际是 '查'
  为什么：`查` 是保留字（69 个之一），不能当变量名/函数名
  怎么改：换个名字，比如 vg.查数；完整保留字表见 PYBOOK_AI.md
```

**读法**：
1. **行号**：定位到那行（一次修一处）
2. **为什么**：告诉你踩了什么规则
3. **怎么改**：照做就行

**如果报错没有后两段**（还没收录的文案）→ 查上面「AI 踩坑速查」的隐藏规则表，
大概率是那几条；再没有就是真 bug，把报错原样贴出来。

**已内建提示的错误**：保留字撞名、未声明、方法调用定不了类、if 块后跟语句、
非法字符（转义）、找不到文件、没有这个 API、嵌套太深、参数个数不对、
del 后访问、下标越界、除零、溢出、字典缺键、变量锁定、类型不配、内存不足……

## 错误处理（P5：try/catch、onerror、安全访问器）

```
try {                       # 抓运行时错误（含"第 N 行"完整消息）
    vg.分 = 存档["最高"]
} catch e {                 # e 是错误文本字符串；也可省 e：catch { ... }
    分 = 0
    ns.show("读档失败", e)
}
```

```
onerror err {               # 放 GOING 任意位置，自动兜底其后全部语句
    ns.show("出错了但不白屏", err)     # 未捕获错误 → 跳这里，游戏不死
    vg.完 = 1
}
```

```
vg.分 = 存档.get("最高", 0)     # 字典：键没有 → 默认值（不炸）
vg.值 = 表.at(i, 0)             # 列表/字符串：越界 → 默认值（不炸）；.at 的缺省可省略
```

规则：catch/onerror 里可以再 try（嵌套安全）；catch 处理完新错误照常可捕获；
`$() 里不能写字符串字面量` 同样适用于 catch 的 e（先落变量再插值）。
防御性写法优先用 .get/.at——不炸的代码比抓异常的代码更好。

## AI 工作循环（推荐）

1. 写/改 `.pybk`（**先查「AI 踩坑速查」** —— 保留字/隐藏规则/API 对照）
2. `python pybk_main.py --check 文件` —— 通过才进行下一步（失败信息含行号+规则+改法）
3. 需要看行为才真跑窗口；改完即停，别留僵尸进程
4. 运行时报错格式 `运行时错误(第 N 行): 信息` —— **先查「AI 踩坑速查」再改代码**（大概率是隐藏规则）
5. 改了 `pybook_rt.c` / `pybk_code.py` 等运行时 → **跑 `python smokeroor.py`**（红绿灯报告，7 个冒烟用例）
6. 想自测就用 `smoke.expect(条件, "文案")` 写断言（软，不中断）或 `smoke.require`（硬，立即报错）

**验证顺序**：`--check` → 跑程序 → Smokeroor（改运行时才需要）→ 写断言（可选）

## 附录：标准库函数全清单（按前缀，函数数核对自 LIB_CALLS）

> 给 AI：下面这张总表是全部标准库 API 的"字典"。**写代码前先在这里确认函数名和模块前缀拼对**（PYbook 库里是英文，错一个字母就报"没有这个 API"）。后端列：`C` = 仅原生 exe（C 后端）；`双` = C + VM 双后端。

| 前缀 | 函数数 | 内容 | 后端 |
|---|---|---|---|
| `mt` | 18 | 基础数学 sqrt/sin/cos/tan/atan2/abs/ceil/floor/pow/mod/pi + 聚合 sum/prod/max/min + 插值 clamp/lerp/dist | 双 |
| `mp` | 30 | 数学进阶：vec_add/sub/scale/dot/cross/norm/normalize/dist/lerp、mat_mul/det/inverse/identity/transpose/vec_mul/scale/add、mean/var/std/minmax、lerp/clamp/smoothstep、radians/degrees、rand_normal/rand_u01/rand_seed | 双 |
| `np` | 16 | 一维数值数组逐元素 range/zeros/add/sub/mul/scale/sin/cos/sqrt/dot/norm/normalize/max/min/sum/mean | 双 |
| `tb` | 29 | 神经网络：mat/rows/cols/tr/add/mul/dot、rand/shuffle/onehot/batch、lin/lin_dw/lin_dx/lin_db、relu/sigmoid/softmax(+_grad)、mse/crossent(+_grad)、argmax、sgd/adam/step | 双 |
| `rd` | 4 | 随机 float/int/pick/shuffle | 双 |
| `te` | 11 | 字符串 chr/cut/has/join/len/lower/replace/split/str/trim/upper | 双 |
| `tm` | 2 | 时间 now（毫秒整数）/stop | 双 |
| `list` | 13 | sorted/rsorted/sort/reverse/byfield/unique/merge/zip/count/find/max/min/flat | 双 |
| `dict` | 7 | get/set/keys/values/byvalue/max/min | 双 |
| `safe` | 2 | 安全访问 at/get（越界/缺键不崩；也是 `.at`/`.get` 方法语法底层） | 双 |
| `调色板` | 12 | 颜色常量 红/绿/蓝/黄/橙/紫/青/粉/白/灰/金/黑 | 双 |
| `file` | 10 | read/write/lines/list/add/del/exists/size/split/join | 双 |
| `csv` | 2 | parse/dump | 双 |
| `js` | 2 | JSON parse/dump | 双 |
| `net` | 7 | TCP socket connect/listen/accept/close/send/recv/readline | **C** |
| `音` | 8 | 声音合成 音/奏/谱/快/放/停/正弦/三角 | **C**（mu 4 个英文名同样 VM 运行时不可用） |
| `mu` | 4 | 音频播放 play/stop/sine/tri | **C**（VM 编译能过但运行时报「在 VM 模式下不可用」） |
| `mm` | 7 | 像素画 MyMove draw_away/贴/色/anim/动/blt（中英双名） | **C** |
| `smoke` | 14 | 安全体检 check/deleted/locked/type/heap/mem/leak/dangling/roots/errors/mode/selftest/expect/require | 双 |
| `ui` | 15 | 桌面 GUI 立即模式 begin/end/row/col/gap/label/button/input/slider/check/table/tag + 中文别名 按钮/滑条/输入框 | **C** |
| `hw` | 58 | 3D 引擎 open/camera/box/sphere/cyl/line/tex/obj*/push/pop/shader/shadow/frame/grab/key/hit/objh/objfix/… | **C** |
| `m3` | 25 | 体素建模 MyMove3D draw/drawr/anim/merge/dig/put/save/load/color/texture/glass/glow/wall/roof/stair/pillar/fence/slab/style/bounds/count/pack/animr/metal | **C** |
| `ffi` | 5 | 底层 C 调用 包含/链接/声明/码/调用 | **C** |
| `bs` | 15 | 位运算 and/or/xor/not/shl/shr/get/set/popcount/band/mask/hex/bin/frombin/fromhex | 双 |
| `mec` | 18 | **Modernized_code 现代化语法**：原生 apply/kind + 标准库 map/filter/reduce/each/find/count_if/sort_by/zip/flat/range/部分/表/收/追加/取/长 | **C** |
| `web` | 多 | 网页输出（详见前文 web.* 节，函数众多，不计入 LIB_CALLS 简单计数） | **C** |
| `宏` | — | 编译期内联宏（关键字，非前缀） | 双 |

**统计**：LIB_CALLS 登记的标准库函数约 **315 个** + `mec` 标准库 16 个 ≈ **333 个 API**（不含 web/宏）。
**易错提醒**：`mec` 常被误记成"机械/物理类接口"——它是 **Modernized_code（现代化语法：lambda / 泛型 / 高阶函数 / 类型查询）**，源码 `games/mec.pybk:2` 自证；且 `mec` 与 `lambda`/`net`/`ffi` 一样**只在 C 后端可用，VM 后端跑不了**。
