# 优化版（与 _life_v2.pybk 同算法）：一维扁平数组 + 邻居偏移表（哨兵补齐）+ 展开求和
import time

W, H, TOTAL = 64, 64, 2000
N = W * H
SENT = N

g = [0] * (N + 1)

# 邻居偏移表：每格恒定 8 项，不足用哨兵补
nb = []
for y in range(H):
    for x in range(W):
        o = []
        for dy in (-1, 0, 1):
            for dx in (-1, 0, 1):
                if dx == 0 and dy == 0:
                    continue
                nx, ny = x + dx, y + dy
                if 0 <= nx < W and 0 <= ny < H:
                    o.append(ny * W + nx)
        while len(o) < 8:
            o.append(SENT)
        nb.append(o)

cx, cy = W // 2, H // 2
for (dx, dy) in [(1, 0), (2, 0), (0, 1), (1, 1), (1, 2)]:
    g[(cy + dy) * W + cx + dx] = 1

t0 = time.perf_counter()
for gen in range(1, TOTAL + 1):
    ng = []
    ap = ng.append
    for i in range(N):
        o = nb[i]
        n = g[o[0]] + g[o[1]] + g[o[2]] + g[o[3]] + g[o[4]] + g[o[5]] + g[o[6]] + g[o[7]]
        if g[i] == 1:
            ap(1 if (n == 2 or n == 3) else 0)
        else:
            ap(1 if n == 3 else 0)
    ap(0)
    g = ng
    if gen % 500 == 0:
        print(f"第 {gen} 代  人口 =", sum(g))
t1 = time.perf_counter()
print("最终人口 =", sum(g))
print(f"计算耗时: {(t1 - t0) * 1000:.0f} ms")
