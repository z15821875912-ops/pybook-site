# 康威生命游戏 · R-pentomino · 64x64 死边界 · 2000 代（与 _life_v1.pybk 同算法）
import time

W, H, TOTAL = 64, 64, 2000

def neighbors(g, x, y):
    n = 0
    for dy in (-1, 0, 1):
        for dx in (-1, 0, 1):
            if dx == 0 and dy == 0:
                continue
            nx, ny = x + dx, y + dy
            if 0 <= nx < W and 0 <= ny < H and g[ny][nx] == 1:
                n += 1
    return n

def next_gen(g):
    ng = []
    for y in range(H):
        row = []
        for x in range(W):
            n = neighbors(g, x, y)
            alive = g[y][x]
            nxt = 1 if (alive == 1 and n in (2, 3)) or (alive == 0 and n == 3) else 0
            row.append(nxt)
        ng.append(row)
    return ng

def population(g):
    return sum(sum(r) for r in g)

g = [[0] * W for _ in range(H)]
cx, cy = W // 2, H // 2
for (dx, dy) in [(1, 0), (2, 0), (0, 1), (1, 1), (1, 2)]:
    g[cy + dy][cx + dx] = 1

t0 = time.perf_counter()
for gen in range(1, TOTAL + 1):
    g = next_gen(g)
    if gen % 500 == 0:
        print(f"第 {gen} 代  人口 =", population(g))
t1 = time.perf_counter()
print("最终人口 =", population(g))
print(f"计算耗时: {(t1 - t0) * 1000:.0f} ms")
