# 和 _speed_test.pybk 同一任务：10 万次循环累加取余
h = 0
for i in range(100000):
    h = h + i % 7
print("和 =", h)
