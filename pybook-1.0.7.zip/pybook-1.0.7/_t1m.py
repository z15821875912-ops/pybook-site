﻿h=0
for i in range(1000000):
    h = h + i % 7
print('和 =', h)
