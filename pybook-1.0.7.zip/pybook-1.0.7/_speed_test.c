#include <stdio.h>
int main(void) {
    long long h = 0;
    for (int i = 0; i < 100000; i++) h += i % 7;
    printf("和 = %lld\n", h);
    return 0;
}
