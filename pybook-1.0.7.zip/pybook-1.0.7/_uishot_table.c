/* _uishot_table.c —— ui.table 无头验收探针（克隆 _uishot.c 的脚手架）。
 *
 * 不开 pybk，直接链 rt_cache 的 .o 调 rt_ui_table：
 *   ① 合成点击（ui_test_input 钩子）断言「点行选中 / 再点取消 / 滚动条拖到底」；
 *   ② 三个状态各存 BMP —— 肉眼验渲染。
 *
 * 布局常数（与 rt_ui_table 的实现口径一致）：
 *   ui.begin(24,20,512) → 表格 x=24,y=20,w=512；字号16 → 行高24；
 *   表头高24（表体从 y=44 起）；view_h=200 → 表体高176 → 30行(720px)出滚动条，
 *   滚动条占右缘 8px（x=528..536）。maxscroll = 720-176 = 544。
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "pybook_rt.h"
#define SDL_MAIN_HANDLED
#include <SDL2/SDL.h>

extern SDL_Renderer *game_renderer(void);
extern Value rt_list_new(void);
extern Value rt_push(Value *dst, Value v);
extern Value rt_ui_begin(Value, Value, Value);
extern Value rt_ui_end(void);
extern Value rt_ui_table(Value, Value, Value, Value);
extern void  ui_test_input(int x, int y, int click, int down);
extern void  ui_test_input_reset(void);

static const int W = 560, H = 400;
static const int TBL_X = 24, TBL_Y = 20, HDR_H = 24, ROW_H = 24;

static int g_sel = -1;
static int g_fail = 0;
static Value g_data, g_headers;

static void 检查(const char *what, int ok, const char *detail)
{
    printf("  %s %s%s%s\n", ok ? "[通过]" : "[失败]", what,
           detail ? "  —— " : "", detail ? detail : "");
    if (!ok)
        g_fail++;
}

/* ---- BMP 输出（B,G,R 逐像素换回 R,G,B） ---- */
static void put32(unsigned char *p, unsigned v)
{
    p[0] = (unsigned char)(v & 0xff);
    p[1] = (unsigned char)((v >> 8) & 0xff);
    p[2] = (unsigned char)((v >> 16) & 0xff);
    p[3] = (unsigned char)((v >> 24) & 0xff);
}
static void put16(unsigned char *p, unsigned v)
{
    p[0] = (unsigned char)(v & 0xff);
    p[1] = (unsigned char)((v >> 8) & 0xff);
}
static void save_bmp(const char *dir, const char *name, unsigned char *src)
{
    int row = W * 3, pad = (4 - (row % 4)) % 4, stride = row + pad;
    char path[512];
    snprintf(path, sizeof path, "%s/%s.bmp", dir, name);
    FILE *f = fopen(path, "wb");
    if (f == NULL) { printf("  ** 写不了 %s\n", path); g_fail++; return; }
    unsigned char hdr[54];
    memset(hdr, 0, sizeof hdr);
    hdr[0] = 'B'; hdr[1] = 'M';
    put32(hdr + 2, 54 + stride * H);
    put32(hdr + 10, 54);
    put32(hdr + 14, 40);
    put32(hdr + 18, W);
    put32(hdr + 22, H);
    put16(hdr + 26, 1);
    put16(hdr + 28, 24);
    put32(hdr + 34, stride * H);
    fwrite(hdr, 1, 54, f);
    unsigned char *line = (unsigned char *)malloc((size_t)row);
    unsigned char zero[4] = { 0, 0, 0, 0 };
    for (int y = 0; y < H; y++) {
        const unsigned char *s = src + (size_t)(H - 1 - y) * row;
        for (int x = 0; x < W; x++) {
            line[x * 3 + 0] = s[x * 3 + 2];
            line[x * 3 + 1] = s[x * 3 + 1];
            line[x * 3 + 2] = s[x * 3 + 0];
        }
        fwrite(line, 1, (size_t)row, f);
        if (pad) fwrite(zero, 1, (size_t)pad, f);
    }
    free(line);
    fclose(f);
    printf("  存图 %s/%s.bmp\n", dir, name);
}

/* 行 i（滚动 offset）的屏幕中心 y —— 和实现公式互为逆运算 */
static int 行y(int i, int scroll)
{
    return TBL_Y + HDR_H + i * ROW_H - scroll + ROW_H / 2;
}

static void 画一屏(void)
{
    rt_game_clear(rt_int(11), rt_int(14), rt_int(20));
    rt_ui_begin(rt_int(TBL_X), rt_int(TBL_Y), rt_int(512));
    g_sel = (int)rt_to_ll(rt_ui_table(rt_int(g_sel), g_data, g_headers, rt_int(200)));
    rt_ui_end();
}

static void 一步(const char *dir, const char *name)
{
    画一屏();
    if (name != NULL) {
        SDL_Renderer *ren = game_renderer();
        if (ren == NULL) { printf("  ** 拿不到渲染器\n"); g_fail++; return; }
        static unsigned char *buf = NULL;
        if (buf == NULL) {
            buf = (unsigned char *)malloc((size_t)W * H * 3);
            if (buf == NULL) { printf("  ** 内存不足\n"); g_fail++; return; }
        }
        memset(buf, 0, (size_t)W * H * 3);
        if (SDL_RenderReadPixels(ren, NULL, SDL_PIXELFORMAT_RGB24, buf, W * 3) != 0) {
            printf("  ** 读回像素失败：%s\n", SDL_GetError());
            g_fail++;
            return;
        }
        save_bmp(dir, name, buf);
    }
    rt_game_show();
}

int main(int argc, char **argv)
{
    const char *out = (argc > 1) ? argv[1] : ".";

    rt_game_win(rt_int(W), rt_int(H), "PYbook table shot");

    /* 30 行 × 3 列：姓名(文本) 语文 数学(整数) */
    g_data = rt_list_new();
    for (int i = 0; i < 30; i++) {
        char name[64];
        snprintf(name, sizeof name, "同学%d", i + 1);
        Value row = rt_list_new();
        rt_push(&row, rt_str(name));
        rt_push(&row, rt_int(60 + (i * 7) % 41));
        rt_push(&row, rt_int(55 + (i * 13) % 46));
        rt_push(&g_data, row);
    }
    g_headers = rt_list_new();
    rt_push(&g_headers, rt_str("姓名"));
    rt_push(&g_headers, rt_str("语文"));
    rt_push(&g_headers, rt_str("数学"));

    ui_test_input_reset();
    for (int i = 0; i < 2; i++)
        一步(NULL, NULL);          /* 预热字体缓存 */

    puts("=== ① 静止态：无输入 ===");
    一步(out, "table_idle");
    检查("初始无选中（返回 -1）", g_sel == -1, NULL);

    puts("=== ② 点第 3 行（下标 2）===");
    ui_test_input(54, 行y(2, 0), 1, 1);
    一步(NULL, NULL);
    检查("点行选中，返回 2", g_sel == 2, NULL);

    puts("=== ③ 换点第 6 行（下标 5）===");
    ui_test_input(54, 行y(5, 0), 1, 1);
    一步(NULL, NULL);
    检查("换行选中，返回 5", g_sel == 5, NULL);

    puts("=== ④ 再点同一行（下标 5）===");
    ui_test_input(54, 行y(5, 0), 1, 1);
    一步(NULL, NULL);
    检查("再点取消，回 -1", g_sel == -1, NULL);

    puts("=== ⑤ 点第 1 行（下标 0）+ 出图 ===");
    ui_test_input(54, 行y(0, 0), 1, 1);
    一步(out, "table_sel");
    检查("选中第 0 行", g_sel == 0, NULL);

    puts("=== ⑥ 滚动条点到底（x=532 在右缘 8px 内）===");
    ui_test_input(532, TBL_Y + 200 - 1, 1, 1);   /* 点轨道最底 → 拖到 max */
    一步(NULL, NULL);
    检查("滚动条接管（此处不触发换选）", g_sel == 0, NULL);

    puts("=== ⑦ 滚到底后点最后一行（下标 29）+ 出图 ===");
    ui_test_input(54, 行y(29, 544), 1, 1);        /* 按住左键=继续拖+点行 */
    一步(out, "table_scrolled");
    检查("滚动后选中第 29 行", g_sel == 29, NULL);

    puts("=== ⑧ 松开鼠标：选中跨帧保持 ===");
    ui_test_input(54, 行y(29, 544), 0, 0);
    一步(NULL, NULL);
    检查("选中保持 29", g_sel == 29, "跨帧状态保存住了");

    printf(g_fail == 0 ? "\n全部通过\n" : "\n%d 项失败\n", g_fail);
    return g_fail == 0 ? 0 : 1;
}
