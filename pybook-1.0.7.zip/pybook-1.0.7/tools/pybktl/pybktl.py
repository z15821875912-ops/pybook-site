#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
pybktl —— PYbook 外部工具链（零侵入版）
======================================
设计约束：不修改 pybk_main.py / pybk_code.py / pybk_front.py / pybk_build.py 任何字节。
本工具只是「包在编译器外面的壳」：通过子进程调用 PYbook 已有的 CLI，
把 kaula 那种 pkg / workspace / fmt / smoke 的体验补到 PYbook 上。

PYbook 真实 CLI 契约（已核实）：
  pybk_main.py             <文件.pybk>           → 前端→C→gcc→原生 exe 并运行（弹 SDL 窗）
  pybk_main.py --check-json <文件.pybk>           → 静态校验，输出 {"ok","line","message"}
  pybk_build.py            <文件.pybk> [out.pybc] → 编译为字节码 .pybc（不依赖 gcc）
  pybk_build.py            <文件.pybk> -r         → 编译后立即用 pyvm.exe 运行
  smokeroor.py                                → 跑 tests/smoke/ 全套，比对 .expect
  （无头）设环境变量 PYBOOK_SHOT_DIR          → hw 程序自动存 BMP 帧（仅 3D）

子命令：
  pybktl init                  在当前目录生成 pybook.md 清单（已存在则跳过）
  pybktl check <文件.pybk>     静态校验（友好化 --check-json + 错误指纹）
  pybktl build <文件.pybk>     编译为 .pybc 字节码产物（离线，不运行）
  pybktl run   <文件>         运行（默认原生管线；--vm 走字节码 pyvm；2D 会弹窗）
  pybktl fmt   <文件.pybk>     块级缩进整理（默认预览，--in-place 落盘，--check 落盘后复检）
  pybktl pkg add  <名> <路径>  往 pybook.md「依赖」段加一条
  pybktl pkg sync             把依赖 .pybk 同步到各成员目录旁（让 引用() 能解析）
  pybktl ws build / ws check   按 pybook.md「工作区」段批量 build / check
  pybktl smoke <文件.pybk>     无头冒烟：跑一遍看崩不崩；若旁有 .expect 则比对；
                                --shot-dir <dir> 设 PYBOOK_SHOT_DIR（3D 无头出图验收）
                                --all 则委托 smokeroor.py 跑整套 tests/smoke/
  pybktl lookaround            在当前文件夹开启日志循环（监控文件改动 + 自动记录运行/错误）
  pybktl lookaround log        查看/筛选日志（--file/--type/--since/--tail）
  pybktl lookaround report     生成团队协作报告（--out 写入文件）
  pybktl todo add/done/rm/list/show   文件夹级待办清单（配合 lookaround 使用）

编译器定位优先级（可移植，无硬编码绝对路径）：
  1. 环境变量 PYBOOK_HOME
  2. 当前目录 pybook.md 的「## 编译器」段 home: 路径
  3. 从本工具自身位置向上找 pybk_main.py（工具随包发布，在 <pybook>/tools/pybktl/ 下）
  4. 从当前工作目录向上找 pybk_main.py
"""

import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys

# 让同目录的 lookaround.py 可被 import（工具随包发布，lookaround.py 就在一旁）
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lookaround  # LookAround 日志循环：文件夹改动 / run·build·check·smoke 运行 / 错误翻中文

MANIFEST = "pybook.md"
INDENT = "    "  # 4 空格
SMOKEROOR_TIMEOUT = 120  # smokeroor 单用例超时（秒）


# ---------------------------------------------------------------------------
# 基础工具
# ---------------------------------------------------------------------------
def _winpath(p):
    """把 Git Bash / MSYS 传来的 POSIX 风格路径（/c/foo）转成 Windows 路径（C:/foo）。
    普通 Windows 终端下输入本就是 C:\\foo，这里无副作用。"""
    p = os.path.expanduser(p)
    m = re.match(r"^/([a-zA-Z])/(.*)$", p.replace("\\", "/"))
    if m:
        p = m.group(1) + ":/" + m.group(2)
    return os.path.abspath(p)


def out(msg=""):
    print(msg, flush=True)


def err(msg):
    print(msg, file=sys.stderr, flush=True)


def _manifest_home(md_path):
    try:
        for line in open(md_path, encoding="utf-8"):
            m = re.match(r"\s*home:\s*(.+)", line)
            if m:
                return m.group(1).strip()
    except Exception:
        pass
    return None


# ---------------------------------------------------------------------------
# 编译器 / 工具定位
# ---------------------------------------------------------------------------
def _self_dir():
    """本工具所在目录（工具随包发布：<pybook>/tools/pybktl/）。"""
    return os.path.dirname(os.path.abspath(__file__))


def _search_up_for(name, start):
    """从 start 目录向上逐级查找名为 name 的文件，返回其所在目录；找不到返回 None。
    这就是"自带定位"：pybk_main.py 一般就在包根，所以从 tools/pybktl/ 上跳两级即可。"""
    d = os.path.abspath(start)
    while True:
        if os.path.isfile(os.path.join(d, name)):
            return d
        nd = os.path.dirname(d)
        if nd == d:
            return None
        d = nd


def home_dir():
    """按优先级返回 PYbook 根目录（含 pybk_main.py 的目录）。
    全部走环境变量 / 清单 / 相对向上查找，不含任何硬编码的绝对路径。"""
    home = os.environ.get("PYBOOK_HOME")
    if not home:
        md = os.path.join(os.getcwd(), MANIFEST)
        if os.path.isfile(md):
            home = _manifest_home(md)
    if not home:
        home = _search_up_for("pybk_main.py", _self_dir())   # 工具就在包内
    if not home:
        home = _search_up_for("pybk_main.py", os.getcwd())   # 用户自己的项目目录
    if not home:
        err("找不到 PYbook 编译器（pybk_main.py）。请设置 PYBOOK_HOME，")
        err("或在当前目录的 " + MANIFEST + " 里写 `home: <pybook目录>`。")
        sys.exit(2)
    return _winpath(home)


def _find_script(name):
    """在 HOME 下找某个 PYbook 脚本（pybk_main.py / pybk_build.py / smokeroor.py / pyvm.exe）。"""
    home = home_dir()
    cand = os.path.join(home, name)
    if os.path.isfile(cand):
        return cand
    # 退化：向上递归找
    d = os.getcwd()
    while True:
        if os.path.isfile(os.path.join(d, name)):
            return os.path.join(d, name)
        nd = os.path.dirname(d)
        if nd == d:
            break
        d = nd
    err(f"找不到 {name}（HOME={home}）。请用 PYBOOK_HOME 指定，或在 pybook.md 写 home:。")
    sys.exit(2)


def locate_main():
    return _find_script("pybk_main.py")


def locate_build():
    return _find_script("pybk_build.py")


def locate_smokeroor():
    return _find_script("smokeroor.py")


def locate_vm():
    return _find_script("pyvm.exe")


def _find_gcc_dir():
    """探测 gcc 所在的 bin 目录，加到子进程 PATH 里（可移植，无硬编码路径）。
    优先级：PYBOOK_GCC 环境变量 → PATH 上的 gcc → 包目录旁常见的 mingw/ucrt64/bin。
    找不到返回 None（pybk_main 内部 _find_gcc 还有自己的兜底逻辑）。"""
    candidates = [os.environ.get("PYBOOK_GCC"), shutil.which("gcc")]
    try:
        root = home_dir()
    except SystemExit:
        root = None
    bases = [b for b in [root, os.path.dirname(root) if root else None] if b]
    for base in bases:
        for sub in ("mingw64/bin", "mingw32/bin", "ucrt64/bin", "bin"):
            candidates.append(os.path.join(base, sub, "gcc.exe"))
    for c in candidates:
        if c and os.path.isfile(c):
            return os.path.dirname(c)
    return None


_CHILD_ENV = None


def child_env(extra=None):
    """复刻 ide.py 的运行环境：UTF-8 编码 + 把 gcc bin 加进 PATH。
    额外 env（如 PYBOOK_SHOT_DIR）通过 extra 传入。"""
    global _CHILD_ENV
    if _CHILD_ENV is None:
        e = os.environ.copy()
        e["PYTHONIOENCODING"] = "utf-8"
        e["PYTHONUTF8"] = "1"
        gdir = _find_gcc_dir()
        if gdir and gdir not in e.get("PATH", ""):
            e["PATH"] = gdir + os.pathsep + e.get("PATH", "")
        _CHILD_ENV = e
    e = dict(_CHILD_ENV)
    if extra:
        e.update(extra)
    return e


def run_tool(script, *args, cwd=None, timeout=None, env=None):
    """子进程调用某个 PYbook 脚本。cwd 默认文件所在目录（方便 引用() 解析）。
    script 可以是 .py（用 python 跑）或 .exe（直接跑）。"""
    script = _winpath(script)
    if script.lower().endswith(".exe"):
        cmd = [script, *args]
    else:
        cmd = [sys.executable, script, *args]
    if cwd is None:
        # 关键：PYbook 的运行时 .c/.h 用裸名按 cwd 解析，IDE 也是用 cwd=HOME 跑的。
        # 所以统一把 cwd 设为 HOME（pybk_main/pybk_build 都依赖此约定）。
        cwd = home_dir()
    cwd = _winpath(cwd)
    if not os.path.isdir(cwd):
        cwd = None
    try:
        p = subprocess.run(
            cmd, capture_output=True, text=True,
            encoding="utf-8", errors="replace",
            cwd=cwd, env=env or child_env(), timeout=timeout,
        )
        return p.returncode, p.stdout, p.stderr
    except subprocess.TimeoutExpired as ex:
        return -1, (ex.stdout or ""), (ex.stderr or "") + "\n(超时)"


def fingerprint(message):
    """把报错归一化成稳定指纹（去行号、去数字、去标识符），对应 Smokeroor 思路。
    同类错误（只是行号/变量名不同）会落到同一指纹，方便 AI 改-验循环。"""
    norm = re.sub(r"第\s*\d+\s*行", "", message)
    norm = re.sub(r"\d+(\.\d+)?", "N", norm)
    norm = re.sub(r"[A-Za-z_][A-Za-z0-9_]*", "X", norm)
    norm = re.sub(r"[一-鿿]+", "C", norm)
    return hashlib.sha1(norm.strip().encode("utf-8")).hexdigest()[:8]


# ---------------------------------------------------------------------------
# 清单（pybook.md）解析
# ---------------------------------------------------------------------------
def parse_manifest(path):
    data = {"home": None, "deps": [], "members": []}
    if not os.path.isfile(path):
        return data
    section = None
    for line in open(path, encoding="utf-8"):
        s = line.strip()
        if s.startswith("## "):
            section = s[3:].strip()
            continue
        if section == "编译器":
            m = re.match(r"home:\s*(.+)", s)
            if m:
                data["home"] = m.group(1).strip()
        elif section == "依赖":
            if s.startswith("-"):
                body = s[1:].strip()
                if "=>" in body:
                    name, _, p = body.partition("=>")
                    data["deps"].append((name.strip(), p.strip()))
                else:
                    base = os.path.splitext(os.path.basename(body))[0]
                    data["deps"].append((base, body.strip()))
        elif section == "工作区":
            if s.startswith("-"):
                data["members"].append(s[1:].strip())
    return data


def _section_insert_index(lines, section):
    """确保 pybook.md 里有某个 ## 段，返回「该段内容末尾、下一段之前」的插入行号。
    lines 会被原地修改（必要时在文件尾新建该段）。"""
    idx = None
    for i, ln in enumerate(lines):
        if ln.strip() == f"## {section}":
            idx = i
            break
    if idx is None:
        if lines and lines[-1].strip():
            lines.append("")
        lines.append(f"## {section}")
        lines.append("")
        idx = len(lines) - 2  # 段头所在行
    # 找段尾：到下一个 ## 段或文件尾
    end = idx + 1
    while end < len(lines) and not lines[end].strip().startswith("## "):
        end += 1
    # 在段内最后一条非空内容之后插入
    insert = end
    for j in range(end - 1, idx, -1):
        if lines[j].strip():
            insert = j + 1
            break
    return insert


def _ensure_manifest_section(manifest, section):
    """兼容旧签名：返回 (行列表, 段起始索引或None)。"""
    lines = []
    if os.path.isfile(manifest):
        lines = open(manifest, encoding="utf-8").read().split("\n")
    idx = None
    for i, ln in enumerate(lines):
        if ln.strip() == f"## {section}":
            idx = i
            break
    if idx is None:
        if lines and lines[-1].strip():
            lines.append("")
        lines.append(f"## {section}")
        lines.append("")
        idx = len(lines) - 1
    return lines, idx


# ---------------------------------------------------------------------------
# 格式化（块级缩进，v1 启发式）
# ---------------------------------------------------------------------------
def fmt_text(text):
    """块级缩进整理。规则：以 { 开启一层缩进，以 } 收一层。
    简化假设：一行一条语句；括号不出现在字符串/注释内。
    v1.1 修正：# 注释起始到行尾不参与括号计数（此前文档注释里的示例
    lambda(x) { ... } 会把深度带偏，注释被缩进搞乱）。"""
    out_lines = []
    depth = 0
    for raw in text.split("\n"):
        line = raw.rstrip()
        if line.strip() == "":
            out_lines.append("")
            continue
        opens = closes = 0
        instr = False
        quote = ""
        for ch in line:
            if instr:
                if ch == quote:
                    instr = False
            else:
                if ch == "#":
                    break              # 注释开始：本行剩余内容不参与括号计数
                if ch in "\"'":
                    instr = True
                    quote = ch
                elif ch == "{":
                    opens += 1
                elif ch == "}":
                    closes += 1
        if closes > 0:
            depth = max(0, depth - closes)
        out_lines.append(INDENT * depth + line.strip())
        if opens > 0:
            depth += opens
    result = "\n".join(out_lines)
    if not result.endswith("\n"):
        result += "\n"
    return result


# ---------------------------------------------------------------------------
# .expect 解析与匹配（与 Smokeroor 同格式，保证一致）
# ---------------------------------------------------------------------------
def load_expect(pybk_path):
    """读 <file>.expect → (期望退出码|None, 正向关键字[], 反向关键字[])。
    格式：第1行=期望退出码（整数，可空）；其余行=正向关键字（任一命中即过），
    行首 '!' = 反向断言（不应出现）；'re:' 前缀 = 正则。"""
    p = pybk_path + ".expect"
    if not os.path.isfile(p):
        return None, [], []
    pos, neg = [], []
    rc = None
    with open(p, encoding="utf-8") as f:
        for line in f:
            line = line.rstrip("\n")
            if not line.strip():
                continue
            if rc is None:
                try:
                    rc = int(line.strip())
                    continue
                except ValueError:
                    pass
            if line.startswith("!"):
                neg.append(line[1:].strip())
            else:
                pos.append(line.strip())
    return rc, pos, neg


def match_expect(expected_rc, actual_rc, out_text, pos, neg, strict=False):
    """按 Smokeroor 的 .expect 格式比对：退出码匹配 + 任一正向关键字命中 + 无反向关键字。
    返回 (ok, 原因)。"""
    rc_ok = (expected_rc is None) or (expected_rc == actual_rc)
    hay = out_text if strict else (out_text or "").lower()

    def hit(key):
        if key.startswith("re:"):
            pat = key[3:]
            try:
                return re.search(pat, out_text, 0 if strict else re.IGNORECASE) is not None
            except re.error:
                return pat in out_text
        needle = key if strict else key.lower()
        return needle in hay

    pos_ok = (not pos) or any(hit(k) for k in pos)
    neg_ok = all(not hit(k) for k in neg)
    ok = rc_ok and pos_ok and neg_ok
    reason = ""
    if not rc_ok:
        reason = f"退出码期望 {expected_rc}，实际 {actual_rc}"
    elif not pos_ok:
        reason = "没看到期望关键字：" + " / ".join(pos) if pos else "（无正向关键字）"
    elif not neg_ok:
        reason = "出现了不该有的：" + " / ".join(neg)
    return ok, reason


# ---------------------------------------------------------------------------
# 子命令实现
# ---------------------------------------------------------------------------
def cmd_init(args):
    manifest = os.path.join(os.getcwd(), MANIFEST)
    if os.path.isfile(manifest):
        out(f"· 已存在 {MANIFEST}，跳过。")
        return 0
    home = (os.environ.get("PYBOOK_HOME")
            or _manifest_home(manifest)
            or _search_up_for("pybk_main.py", _self_dir())
            or "<PYbook 根目录>")
    tmpl = (
        "# PYbook 项目清单（pybktl 读取此文件）\n"
        "# 格式就是 markdown，人和 AI 都能直接读写。\n\n"
        "## 编译器\n"
        f"home: {home}\n\n"
        "## 依赖\n"
        "# - 物理引擎 => ../libs/physics.pybk\n\n"
        "## 工作区\n"
        "# - games/披萨塔/main.pybk\n"
        "# - learn/pybook-3d-highway/自学验证.pybk\n"
    )
    open(manifest, "w", encoding="utf-8").write(tmpl)
    out(f"✓ 已生成 {MANIFEST}（编译器 home 指向 {home}）")
    out("  编辑「依赖」「工作区」段后，用 pkg/ws 子命令批量管理。")
    return 0


def _parse_check_json(stdout):
    data = None
    for ln in reversed(stdout.strip().splitlines()):
        try:
            data = json.loads(ln)
            break
        except Exception:
            continue
    return data


def _log_lookaround(script, cmd, rc, stdout, stderr, todo_id=None):
    """若 script 所在（或上级）文件夹开启了 LookAround，把本次运行追加进 lookaround.md。"""
    root = lookaround.find_lookaround_root(os.path.dirname(os.path.abspath(script)))
    if root:
        lookaround.log_run(root, script, cmd, rc, stdout, stderr, todo_id=todo_id)


def cmd_check(args):
    main = locate_main()
    rc, stdout, stderr = run_tool(main, "--check-json", _winpath(args.file))
    data = _parse_check_json(stdout)
    sf = os.path.abspath(_winpath(args.file))
    cmd = "pybktl check " + os.path.basename(args.file)
    if data and data.get("ok"):
        out(f"✓ {args.file}  编译通过（静态：语法 + 语义，未 gcc 未运行）")
        _log_lookaround(sf, cmd, rc, stdout, stderr)
        return 0
    if data:
        line = data.get("line")
        msg = data.get("message", "")
        fp = fingerprint(msg)
        loc = ""
        if line and f"第 {line} 行" not in msg:
            loc = f"第 {line} 行"
        head = " ".join(filter(None, [f"✗ {args.file}", loc, f"[指纹 {fp}]"]))
        err(f"{head}  {msg}")
    else:
        err(stderr.strip() or stdout.strip() or "未知错误（编译器未输出 JSON）")
    _log_lookaround(sf, cmd, rc, stdout, stderr)
    return 1


def cmd_build(args):
    build = locate_build()
    src = _winpath(args.file)
    if not os.path.isfile(src):
        err(f"找不到文件: {src}")
        return 2
    out_path = args.out or (os.path.splitext(src)[0] + ".pybc")
    out_path = _winpath(out_path)
    rc, stdout, stderr = run_tool(build, src, out_path)
    sf = os.path.abspath(src)
    cmd = "pybktl build " + os.path.basename(src)
    if rc != 0:
        err(stderr.strip() or stdout.strip() or "编译失败")
        _log_lookaround(sf, cmd, rc, stdout, stderr)
        return rc
    out(f"✓ 已编译: {src}")
    out(f"  → 产物: {out_path}  ({os.path.getsize(out_path)} 字节)")
    if stdout.strip():
        out("  ---- 反汇编摘要 ----")
        out(stdout.strip())
    out("  （可用 `pybktl run --vm <同名.pybc>` 执行此字节码产物）")
    _log_lookaround(sf, cmd, rc, stdout, stderr)
    return 0


def cmd_run(args):
    f = _winpath(args.file)
    if not os.path.isfile(f):
        err(f"找不到文件: {f}")
        return 2
    extra = {}
    if args.shot_dir:
        sd = _winpath(args.shot_dir)
        os.makedirs(sd, exist_ok=True)
        extra["PYBOOK_SHOT_DIR"] = sd
    if args.vm or f.lower().endswith(".pybc"):
        if f.lower().endswith(".pybc"):
            if not os.path.isfile(locate_vm()):
                err("找不到 pyvm.exe（字节码运行时）。请用原生管线：pybktl run <文件.pybk>")
                return 2
            rc, stdout, stderr = run_tool(locate_vm(), f, env=child_env(extra))
        else:
            build = locate_build()
            rc, stdout, stderr = run_tool(build, f, "-r", env=child_env(extra))
    else:
        main = locate_main()
        rc, stdout, stderr = run_tool(main, f, env=child_env(extra))

    # LookAround：若本文件夹开启了日志循环，把这次运行（含运行时错误）追加进 lookaround.md
    _la_cmd = "pybktl run " + os.path.basename(f) + (" --vm" if (args.vm or f.lower().endswith('.pybc')) else "")
    _log_lookaround(f, _la_cmd, rc, stdout, stderr, todo_id=getattr(args, "todo", None))
    if stdout.strip():
        out(stdout.strip())
    if stderr.strip():
        err(stderr.strip())
    if rc != 0:
        return rc
    if args.shot_dir:
        sd = _winpath(args.shot_dir)
        shots = [x for x in os.listdir(sd)] if os.path.isdir(sd) else []
        out(f"  （无头出图：在 {sd} 产出 {len(shots)} 张帧）")
    return 0


def cmd_fmt(args):
    args.file = _winpath(args.file)
    if not os.path.isfile(args.file):
        err(f"找不到文件: {args.file}")
        return 2
    src = open(args.file, encoding="utf-8-sig").read()
    new = fmt_text(src)
    if args.in_place:
        if new != src:
            open(args.file, "w", encoding="utf-8").write(new)
            out(f"✓ 已格式化（落盘）: {args.file}")
        else:
            out(f"· 无需改动: {args.file}")
            return 0
        if args.check:
            # 落盘后复检：确保格式化没把语法搞坏
            rc, _, _ = run_tool(locate_main(), "--check-json", args.file)
            if rc != 0:
                err("⚠ 警告：格式化后静态校验未通过！已回滚。")
                open(args.file, "w", encoding="utf-8").write(src)
                return 1
            out("✓ 落盘后复检通过")
        return 0
    # 预览模式
    old_lines = src.split("\n")
    new_lines = new.split("\n")
    changed = sum(1 for a, b in zip(old_lines, new_lines) if a.rstrip() != b.rstrip())
    out(new)
    out(f"--- 预览：{changed} 行缩进有变化（加 --in-place 落盘；--check 可落盘后复检）---")
    return 0


def cmd_pkg(args):
    manifest = os.path.join(os.getcwd(), MANIFEST)
    if args.pkg_action == "add":
        lines = open(manifest, encoding="utf-8").read().split("\n") if os.path.isfile(manifest) else []
        ins = _section_insert_index(lines, "依赖")
        entry = f"- {args.name} => {args.path}"
        if any(entry.strip() == l.strip() for l in lines):
            out(f"· 已存在: {entry}")
        else:
            lines.insert(ins, entry)
            open(manifest, "w", encoding="utf-8").write("\n".join(lines))
            out(f"✓ 已加入依赖: {entry}")
        return 0
    if args.pkg_action == "sync":
        data = parse_manifest(manifest)
        if not data["deps"]:
            out("· 清单里没有依赖，跳过。")
            return 0
        targets = set()
        for m in data["members"]:
            targets.add(os.path.dirname(os.path.abspath(m)) or ".")
        targets.add(os.getcwd())
        copied = 0
        for name, p in data["deps"]:
            if not os.path.isfile(p):
                err(f"✗ 依赖源不存在: {p}")
                continue
            base = os.path.basename(p)
            for t in targets:
                os.makedirs(t, exist_ok=True)
                shutil.copy(p, os.path.join(t, base))
                copied += 1
        out(f"✓ 同步完成：{len(data['deps'])} 个依赖 × {len(targets)} 个目标目录 = {copied} 次复制")
        out("  （依赖已放到各成员目录旁，引用(\"模块\") 现在能解析）")
        return 0
    return 1


def cmd_ws(args):
    manifest = os.path.join(os.getcwd(), MANIFEST)
    data = parse_manifest(manifest)
    if not data["members"]:
        err("· 清单「工作区」段没有成员。先 pybktl pkg add 或直接编辑 pybook.md。")
        return 2
    ok = fail = 0
    for m in data["members"]:
        m = _winpath(m)
        if not os.path.isfile(m):
            err(f"✗ 成员不存在: {m}")
            fail += 1
            continue
        if args.ws_action == "build":
            rc, stdout, stderr = run_tool(locate_build(), m,
                                          os.path.splitext(m)[0] + ".pybc")
            if rc == 0:
                out(f"✓ {m}  → .pybc")
                ok += 1
            else:
                err(f"✗ {m}  {stderr.strip() or stdout.strip()}")
                fail += 1
        else:  # check
            rc, stdout, stderr = run_tool(locate_main(), "--check-json", m)
            d = _parse_check_json(stdout)
            if d and d.get("ok"):
                out(f"✓ {m}")
                ok += 1
            else:
                msg = (d or {}).get("message", stderr.strip() or "未知错误")
                err(f"✗ {m}  {msg}")
                fail += 1
    out(f"--- 工作区 {args.ws_action}: {ok} 通过 / {fail} 失败 ---")
    return 1 if fail else 0


# ---------------------------------------------------------------------------
# 3门神总闸：静态门 + 运行门 + 回归门
# ---------------------------------------------------------------------------
def _read_text(path):
    try:
        with open(path, encoding="utf-8-sig", errors="replace") as f:
            return f.read()
    except Exception:
        return ""


def _door_static(path):
    """静态门：--check 通过（含字面量类型/取值检查）。"""
    main = locate_main()
    rc, so, se = run_tool(main, "--check-json", _winpath(path))
    d = _parse_check_json(so)
    if d and d.get("ok"):
        return ("pass", "静态校验通过（语法+语义+字面量类型/取值）")
    msg = (d or {}).get("message") or (se or so).strip() or "未知错误"
    return ("fail", msg)


def _door_runtime(path, mode):
    """运行门：源码是否挂了 try-catch/onerror 网 + （full 模式）有界运行看崩不崩。"""
    src = _read_text(path)
    has_net = bool(re.search(r"\b(try|catch|onerror)\b", src))
    net = "已挂运行门(try/catch/onerror)" if has_net else "未挂运行门(try/catch/onerror)：运行期错误会直接崩"
    if mode != "full":
        return ("pass" if has_net else "warn", net)
    rc, so, se = run_tool(locate_main(), _winpath(path), timeout=15, env=child_env())
    combined = (so or "") + (se or "")
    if rc == -1:
        run = ("warn", "运行超时(>15s)，可能交互/死循环，需人工验")
    elif rc != 0:
        run = ("fail", "运行期崩溃: " + combined.strip()[-300:])
    else:
        run = ("pass", "运行无异常退出")
    level = "pass" if (has_net and run[0] == "pass") else ("fail" if run[0] == "fail" else "warn")
    return (level, net + "；" + run[1])


def _door_regress(path, mode, all_=False):
    """回归门：smokeroor 冒烟/回归。单文件若有 .expect 则比对；--all 跑全套。"""
    if all_:
        sr = locate_smokeroor()
        rc, so, se = run_tool(sr, timeout=SMOKEROOR_TIMEOUT * 5)
        if rc == 0:
            return ("pass", "smokeroor 全套通过")
        return ("fail", (so or se).strip()[-300:] or "smokeroor 有失败")
    exp_rc, pos, neg = load_expect(path)
    if exp_rc is not None or pos or neg:
        rc, so, se = run_tool(locate_main(), _winpath(path), timeout=30, env=child_env())
        ok, reason = match_expect(exp_rc, rc, (so or "") + (se or ""), pos, neg)
        return (("pass", "冒烟比对通过(.expect 命中)") if ok else ("fail", reason))
    return ("warn", "无对应冒烟用例（用 `pybktl guard --all` 跑全套回归）")


def guard_file(path, mode="full", all_=False):
    path = _winpath(path)
    if not os.path.isfile(path):
        return None, [("fail", "找不到文件: " + path)]
    doors = [
        ("静态门", _door_static(path)),
        ("运行门", _door_runtime(path, mode)),
        ("回归门", _door_regress(path, mode, all_)),
    ]
    return path, doors


def cmd_guard(args):
    all_ = args.all
    if all_ and not args.file:
        sr = locate_smokeroor()
        rc, so, se = run_tool(sr, timeout=SMOKEROOR_TIMEOUT * 5)
        if so.strip():
            out(so.strip())
        if se.strip():
            err(se.strip())
        return rc
    if not args.file:
        err("用法: pybktl guard <文件.pybk> [--all] [--auto]")
        return 2
    mode = "auto" if args.auto else "full"
    path, doors = guard_file(args.file, mode=mode, all_=all_)
    if path is None:
        return 2
    sym = {"pass": "\u2713", "warn": "\u26a0", "fail": "\u2717"}
    out("\U0001F531 3门神总闸：" + os.path.basename(path))
    worst = "pass"
    for name, (lvl, msg) in doors:
        out("  [%s] %s：%s" % (sym[lvl], name, msg))
        if lvl == "fail":
            worst = "fail"
        elif lvl == "warn" and worst != "fail":
            worst = "warn"
    if worst == "fail":
        out("结果：有门神未过，先修再发布。")
        return 1
    if worst == "warn":
        out("结果：通过，但运行门/回归门有提醒项，留意。")
        return 0
    out("结果：三道门神全过。")
    return 0


def cmd_smoke(args):
    # --all：委托给项目自带的 smokeroor.py 跑整套
    if args.all:
        sr = locate_smokeroor()
        rc, stdout, stderr = run_tool(sr, *(["--json"] if args.json else []),
                                      timeout=SMOKEROOR_TIMEOUT * 5)
        _log_lookaround(sr, "pybktl smoke --all", rc, stdout, stderr)
        if stdout.strip():
            out(stdout.strip())
        if stderr.strip():
            err(stderr.strip())
        return rc

    f = _winpath(args.file)
    if not os.path.isfile(f):
        err(f"找不到文件: {f}")
        return 2

    extra = {}
    if args.shot_dir:
        sd = _winpath(args.shot_dir)
        os.makedirs(sd, exist_ok=True)
        extra["PYBOOK_SHOT_DIR"] = sd

    # 冒烟 = 真正运行一遍（原生管线），超时兜底
    rc, stdout, stderr = run_tool(locate_main(), f, timeout=args.timeout, env=child_env(extra))
    combined = (stdout or "") + (stderr or "")
    _log_lookaround(f, "pybktl smoke " + os.path.basename(f), rc, stdout, stderr)

    # 若旁边有 .expect，按 Smokeroor 格式比对
    exp_rc, pos, neg = load_expect(f)
    if exp_rc is not None or pos or neg:
        ok, reason = match_expect(exp_rc, rc, combined, pos, neg)
        if ok:
            out(f"✓ {f}  冒烟通过（.expect 命中）")
        else:
            err(f"✗ {f}  冒烟失败：{reason}")
            err(combined.strip()[-500:] if combined.strip() else "(无输出)")
            _try_smokeroor(f)
            return 1
    else:
        if rc == -1:
            err(f"✗ {f}  无头冒烟超时（>{args.timeout}s），可能卡死/死循环")
            _try_smokeroor(f)
            return 2
        if rc != 0:
            err(f"✗ {f}  无头冒烟失败 (rc={rc})")
            if stderr.strip():
                err(stderr.strip())
            if "Traceback" in combined or "pybook_rt.c" in combined or "gcc" in combined.lower():
                err("  （提示：疑似 gcc/mingw 不可用或运行时 .c 未找到；"
                    "请在装好 mingw 的机器上运行，或确认 PYBOOK_HOME 指向完整 pybook 目录）")
            fp = fingerprint(combined)
            err(f"  [指纹 {fp}]")
            _try_smokeroor(f)
            return 1
        out(f"✓ {f}  无头冒烟通过（rc=0）")

    if args.shot_dir:
        sd = _winpath(args.shot_dir)
        shots = [x for x in os.listdir(sd)] if os.path.isdir(sd) else []
        if shots:
            out(f"  （无头出图：在 {sd} 产出 {len(shots)} 张帧，3D 渲染管线已跑通）")
        else:
            out(f"  （提示：未发现帧。PYBOOK_SHOT_DIR 仅对 3D(hw) 程序生效；2D 无头不存帧）")
    return 0


def _try_smokeroor(filepath):
    """若 Smokeroor 产出过错误指纹库，尝试读取并判已知/未知。"""
    cand = os.path.join(os.path.dirname(os.path.abspath(filepath)), "smokeroor_errors.json")
    if not os.path.isfile(cand):
        cand = os.path.join(home_dir(), "smokeroor_errors.json")
    if not os.path.isfile(cand):
        return
    try:
        db = json.load(open(cand, encoding="utf-8"))
        known = db.get("known", []) if isinstance(db, dict) else []
        out(f"  （Smokeroor 指纹库命中 {len(known)} 条已知错误）")
    except Exception:
        pass


# ---------------------------------------------------------------------------
# LookAround 日志循环（文件夹级开发日志：文件改动 / run·build·check·smoke 运行 / 错误翻中文）
# ---------------------------------------------------------------------------
def cmd_lookaround(args):
    """开启文件夹日志循环（前台监控，Ctrl+C 停止）。详见 lookaround.py。"""
    lookaround.start_watcher()


def cmd_lookaround_log(args):
    """查看/筛选 lookaround.md 日志。"""
    root, text = lookaround.view_log(file=args.file, since=args.since,
                                     until=args.until, etype=args.type, tail=args.tail)
    print(text)
    return 0 if root is not None else 1


def cmd_lookaround_report(args):
    """生成团队协作报告：改动/运行/错误汇总 + 待办完成情况。"""
    root = lookaround.find_lookaround_root(os.getcwd())
    if not root:
        print("该文件夹未开启 LookAround 日志循环：请先 `cd` 到目标文件夹执行 `pybktl lookaround`。")
        return 1
    text = lookaround.build_report(root, since=args.since, until=args.until, by=args.by)
    if args.out:
        out_path = os.path.join(root, args.out)
        with open(out_path, "w", encoding="utf-8") as f:
            f.write(text)
        out("✓ 报告已写入：%s" % out_path)
    else:
        print(text)
    return 0


def cmd_todo(args):
    """LookAround 待办清单：独立进程通过 .lookaround 标记定位根目录，可在 watcher 运行过程中途加入。"""
    root = lookaround.find_lookaround_root(os.getcwd())
    if not root:
        print("该文件夹未开启 LookAround 日志循环：请先 `cd` 到目标文件夹执行 `pybktl lookaround`。")
        return 1
    c = args.todo_cmd
    if c == "add":
        text = " ".join(args.text)
        nid = lookaround.add_todo(root, text)
        print("已加入待办 #%d：%s" % (nid, text))
    elif c == "done":
        ok = lookaround.done_todo(root, args.idx)
        print("已标记完成 #%d" % args.idx if ok else "未找到待办 #%d" % args.idx)
    elif c == "rm":
        ok = lookaround.rm_todo(root, args.idx)
        print("已删除 #%d" % args.idx if ok else "未找到待办 #%d" % args.idx)
    elif c == "list":
        print(lookaround.list_todo(root))
    elif c == "show":
        txt = lookaround.show_todo(root, args.idx)
        print(txt if txt else "未找到待办 #%d" % args.idx)
    return 0


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------
def build_parser():
    p = argparse.ArgumentParser(prog="pybktl", description="PYbook 外部工具链（零侵入）")
    sub = p.add_subparsers(dest="command", required=True)

    pi = sub.add_parser("init", help="在当前目录生成 pybook.md 清单")
    pi.set_defaults(func=cmd_init)

    pc = sub.add_parser("check", help="静态校验 .pybk（友好化报错 + 错误指纹）")
    pc.add_argument("file")
    pc.set_defaults(func=cmd_check)

    pb = sub.add_parser("build", help="编译为 .pybc 字节码产物（离线，不运行）")
    pb.add_argument("file")
    pb.add_argument("out", nargs="?", help="输出 .pybc 路径（默认 同名.pybc）")
    pb.set_defaults(func=cmd_build)

    pr = sub.add_parser("run", help="运行：默认原生管线，--vm 走字节码，2D 会弹窗")
    pr.add_argument("file")
    pr.add_argument("--vm", action="store_true", help="用 pyvm.exe 跑字节码（Ctrl+F5 管线）")
    pr.add_argument("--todo", type=int, help="把本次运行关联到某条待办（配合 `todo show <编号>` 跳转查看）")
    pr.add_argument("--shot-dir", help="设 PYBOOK_SHOT_DIR（3D 无头出图验收）")
    pr.set_defaults(func=cmd_run)

    pf = sub.add_parser("fmt", help="块级缩进整理（默认预览）")
    pf.add_argument("file")
    pf.add_argument("--in-place", action="store_true", help="直接落盘")
    pf.add_argument("--check", action="store_true",
                    help="落盘后自动复检静态校验，失败则回滚")
    pf.set_defaults(func=cmd_fmt)

    pp = sub.add_parser("pkg", help="依赖管理")
    pp.add_argument("pkg_action", choices=["add", "sync"])
    pp.add_argument("name", nargs="?", help="add 时的依赖名")
    pp.add_argument("path", nargs="?", help="add 时的依赖路径")
    pp.set_defaults(func=cmd_pkg)

    pw = sub.add_parser("ws", help="工作区批量")
    pw.add_argument("ws_action", choices=["build", "check"])
    pw.set_defaults(func=cmd_ws)

    ps = sub.add_parser("smoke", help="无头冒烟 / 跑 Smokeroor 套件")
    ps.add_argument("file", nargs="?", help="单个 .pybk（与 --all 互斥）")
    ps.add_argument("--all", action="store_true", help="委托 smokeroor.py 跑 tests/smoke/ 全套")
    ps.add_argument("--shot-dir", help="设 PYBOOK_SHOT_DIR（3D 无头出图验收）")
    ps.add_argument("--timeout", type=int, default=30, help="单文件超时秒数")
    ps.add_argument("--json", action="store_true", help="--all 时让 smokeroor 输出 JSON")
    ps.set_defaults(func=cmd_smoke)

    pg = sub.add_parser("guard", help="3门神总闸：静态(--check)+运行(try-catch网/有界运行)+回归(smokeroor)")
    pg.add_argument("file", nargs="?", help="单个 .pybk（与 --all 可并存）")
    pg.add_argument("--all", action="store_true", help="回归门跑 smokeroor 全套")
    pg.add_argument("--auto", action="store_true", help="轻量模式（lookaround 自动调用）：跳过实际运行，只做静态+存在性+单文件冒烟")
    pg.set_defaults(func=cmd_guard)

    pla = sub.add_parser("lookaround",
                         help="在当前文件夹开启日志循环：监控文件改动，并自动记录 run/build/check/smoke 运行与运行时错误到 lookaround.md")
    pla.set_defaults(func=cmd_lookaround)
    plos = pla.add_subparsers(dest="look_cmd")
    plog = plos.add_parser("log", help="查看/筛选 lookaround.md 日志")
    plog.add_argument("--file", help="只显示涉及该文件的事件")
    plog.add_argument("--since", help="起始时间，格式 YYYY-MM-DD[ HH:MM:SS]")
    plog.add_argument("--until", help="结束时间，格式 YYYY-MM-DD[ HH:MM:SS]")
    plog.add_argument("--type", choices=["change", "run", "todo", "error"],
                     help="按事件类型筛选：change=文件改动 / run=运行 / todo=待办 / error=运行时错误")
    plog.add_argument("--tail", type=int, default=0, help="只显示最后 N 条事件")
    plog.set_defaults(func=cmd_lookaround_log)
    prep = plos.add_parser("report", help="生成团队协作报告（改动/运行/错误汇总 + 待办完成情况）")
    prep.add_argument("--since", help="统计起始时间，格式 YYYY-MM-DD[ HH:MM:SS]")
    prep.add_argument("--until", help="统计结束时间，格式 YYYY-MM-DD[ HH:MM:SS]")
    prep.add_argument("--by", default="", help="报告人（团队协作署名）")
    prep.add_argument("--out", help="把报告写入该文件（默认打印到屏幕）")
    prep.set_defaults(func=cmd_lookaround_report)

    ptd = sub.add_parser("todo",
                         help="LookAround 待办清单：中途可随时 add/done/rm/list（需先在该文件夹开启 lookaround）")
    ptd_sub = ptd.add_subparsers(dest="todo_cmd", required=True)
    ptd_a = ptd_sub.add_parser("add", help="新增待办（支持多词，用空格分隔）")
    ptd_a.add_argument("text", nargs="+", help="待办内容")
    ptd_d = ptd_sub.add_parser("done", help="标记某条待办完成")
    ptd_d.add_argument("idx", type=int, help="待办编号 #id")
    ptd_r = ptd_sub.add_parser("rm", help="删除某条待办")
    ptd_r.add_argument("idx", type=int, help="待办编号 #id")
    ptd_l = ptd_sub.add_parser("list", help="列出全部待办（含完成状态）")
    ptd_s = ptd_sub.add_parser("show", help="查看某条待办详情 + 它的关联运行（待办↔运行跳转）")
    ptd_s.add_argument("idx", type=int, help="待办编号 #id")
    ptd.set_defaults(func=cmd_todo)
    return p


def main():
    parser = build_parser()
    args = parser.parse_args()
    # smoke --all 不需要 file
    if getattr(args, "command", None) == "smoke" and args.all and not args.file:
        pass
    sys.exit(args.func(args))


if __name__ == "__main__":
    main()
