/* 康威生命游戏 · R-pentomino · 64x64 死边界 · 2000 代
 * 与 _life_v2.pybk / _life_v2.py 同算法：一维数组 + 邻居偏移表（哨兵补齐8邻）
 */
#include <stdio.h>
#include <windows.h>

#define W 64
#define H 64
#define N (W * H)
#define SENT N
#define TOTAL 2000

static unsigned char cell_a[N + 1], cell_b[N + 1];
static int nb[N][8];

int main(void) {
    /* 邻居偏移表：每格恒定 8 项，越界用哨兵格补齐（永远为 0） */
    for (int y = 0; y < H; y++) {
        for (int x = 0; x < W; x++) {
            int k = 0, idx = y * W + x;
            for (int dy = -1; dy <= 1; dy++) {
                for (int dx = -1; dx <= 1; dx++) {
                    if (dx == 0 && dy == 0) continue;
                    int nx = x + dx, ny = y + dy;
                    if (nx >= 0 && nx < W && ny >= 0 && ny < H)
                        nb[idx][k++] = ny * W + nx;
                }
            }
            while (k < 8) nb[idx][k++] = SENT;
        }
    }

    /* R-pentomino: .XX / XX. / .X. */
    int cx = W / 2, cy = H / 2;
    cell_a[cy * W + cx + 1] = 1;
    cell_a[cy * W + cx + 2] = 1;
    cell_a[(cy + 1) * W + cx] = 1;
    cell_a[(cy + 1) * W + cx + 1] = 1;
    cell_a[(cy + 2) * W + cx + 1] = 1;

    LARGE_INTEGER freq, t0, t1;
    QueryPerformanceFrequency(&freq);
    QueryPerformanceCounter(&t0);

    unsigned char *g = cell_a, *ng = cell_b;
    for (int gen = 1; gen <= TOTAL; gen++) {
        for (int i = 0; i < N; i++) {
            const int *o = nb[i];
            int n = g[o[0]] + g[o[1]] + g[o[2]] + g[o[3]]
                  + g[o[4]] + g[o[5]] + g[o[6]] + g[o[7]];
            ng[i] = g[i] ? ((n == 2 || n == 3) ? 1 : 0) : (n == 3 ? 1 : 0);
        }
        ng[N] = 0;
        unsigned char *tmp = g; g = ng; ng = tmp;
        if (gen % 500 == 0) {
            int pop = 0;
            for (int i = 0; i < N; i++) pop += g[i];
            printf("第 %d 代  人口 = %d\n", gen, pop);
        }
    }

    QueryPerformanceCounter(&t1);
    int pop = 0;
    for (int i = 0; i < N; i++) pop += g[i];
    printf("最终人口 = %d\n", pop);
    printf("计算耗时: %.0f ms\n",
           (double)(t1.QuadPart - t0.QuadPart) * 1000.0 / freq.QuadPart);
    return 0;
}
