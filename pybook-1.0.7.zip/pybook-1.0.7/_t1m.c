#include <stdio.h>
int main(void){ long long h=0; for(int i=0;i<1000000;i++) h += i % 7; printf("? = %lld\\n", h); return 0; }
