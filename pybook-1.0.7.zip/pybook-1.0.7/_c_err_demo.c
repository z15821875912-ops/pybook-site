int main(void) {
    int 表 = 5
    int 个 = 表 + 1;
    return 个 - 6;
}
