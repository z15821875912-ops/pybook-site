"""LookAround —— PYbook 文件夹日志循环。

在任意文件夹里跑 `pybktl lookaround` 即开启「日志循环」：
- 持续监控该文件夹（递归，跳过隐藏/缓存目录）里所有文件的 创建/修改/删除，
  写进该文件夹的 `lookaround.md`；
- 之后在该文件夹（或其子目录）里跑 `pybktl run` / `smoke` / `build` / `check` 时，
  会自动把「运行了哪个文件、退出码、输出、运行时错误」也追加进同一份 `lookaround.md`。
- 文本文件的「修改」事件会额外记录内容 diff（unified diff，仅文本、<200KB、最多 300 行），
  回看可知具体改了什么，而非只有大小/时间。
- 查看历史用 `pybktl lookaround log`（支持按文件 / 时间 / 类型 / 条数筛选）。

特征：
- 零依赖（纯标准库，轮询式监控，不装 watchdog）。
- 通过 `.lookaround` 标记文件判断「日志循环是否开着」，与 watcher 进程解耦：
  run/smoke 是独立进程，启动时检查 cwd 或脚本目录里有没有 `.lookaround` 标记，
  有就追加日志，没有就完全不碰 md（零副作用）。
- watcher 自己只轮询，不会因写 md 而递归触发（md 与标记文件被排除）。
"""

import os
import re
import time
import difflib
from datetime import datetime

LOOK_MD = "lookaround.md"      # 日志文件名
LOOK_TODO = "lookaround.todo"  # 待办明细（由 todo 命令自己记语义事件，watcher 不重复记文件改动）
MARKER = ".lookaround"         # 开启标记（隐藏，watcher 启动时创建、退出时删除）

MAX_DIFF_BYTES = 200 * 1024   # 超过此大小的文本文件不记 diff
DIFF_MAX_LINES = 300          # diff 输出最多行数（超出截断）
MAX_MD_LINES = int(os.environ.get("LOOKAROUND_MAX_LINES", "2000"))  # md 超此行数自动轮转（<=0 关闭）


# ---------------------------------------------------------------------------
# 位置解析
# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
# 强杀防呆：标记里存 watcher PID，检测「标记在但进程已死」的残留并自动清理
# ---------------------------------------------------------------------------
def _pid_alive(pid):
    """检查进程是否存活（只查询，不发信号、不终止）。查询失败时保守当作存活。"""
    if pid <= 0:
        return False
    if os.name == "nt":
        try:
            import ctypes
            PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
            h = ctypes.windll.kernel32.OpenProcess(
                PROCESS_QUERY_LIMITED_INFORMATION, False, pid)
            if h:
                ctypes.windll.kernel32.CloseHandle(h)
                return True
            return False
        except Exception:
            return True  # 查询异常，保守当作活着，避免误删
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def _watcher_pid(root):
    """读取标记里的 watcher PID；无 PID（旧式空标记）返回 None。"""
    try:
        with open(os.path.join(root, MARKER), "r") as f:
            return int(f.read().strip() or "0") or None
    except (OSError, ValueError):
        return None


def find_lookaround_root(start=None, reap=True):
    """向上查找最近的含 `.lookaround` 标记的目录（= 日志所在文件夹）。

    先查 start（通常是被 run 的脚本所在目录），再查当前 cwd，逐级向上。
    reap=True 时：若标记存在但 watcher 进程已死（被强杀），自动删除残留标记
    并继续向上找——避免「残留标记」被误判成「循环还开着」。
    找不到返回 None（表示当前未开启日志循环）。"""
    candidates = []
    if start:
        candidates.append(os.path.abspath(start))
    candidates.append(os.path.abspath(os.getcwd()))
    for c in candidates:
        d = c
        while True:
            mp = os.path.join(d, MARKER)
            if os.path.exists(mp):
                alive = False
                if reap:
                    pid = _watcher_pid(d)
                    alive = (pid is not None) and _pid_alive(pid)
                if not reap or alive:
                    return d
                # 残留标记：watcher 已死，自动清理后继续向上找
                try:
                    os.remove(mp)
                except OSError:
                    pass
            parent = os.path.dirname(d)
            if parent == d:
                break
            d = parent
    return None


# ---------------------------------------------------------------------------
# 日志写入
# ---------------------------------------------------------------------------
def _ts():
    return time.strftime("%Y-%m-%d %H:%M:%S")


def _ensure_md(root):
    """确保日志 md 存在（首次写表头），返回路径。"""
    p = os.path.join(root, LOOK_MD)
    if not os.path.exists(p):
        with open(p, "w", encoding="utf-8") as f:
            f.write("# LookAround 日志\n\n")
            f.write(f"- 开启：{_ts()}\n")
            f.write(f"- 目录：`{root}`\n")
            f.write("\n> 由 `pybktl lookaround` 生成：记录文件改动、运行与运行时错误。\n")
    return p


def log_event(root, kind, detail):
    """追加一条带时间戳的事件到 md。"""
    _ensure_md(root)
    p = os.path.join(root, LOOK_MD)
    with open(p, "a", encoding="utf-8") as f:
        f.write(f"\n## {_ts()} — {kind}\n\n")
        f.write(detail.rstrip() + "\n")
    _rotate_if_needed(root)


def _rotate_if_needed(root):
    """md 超过 MAX_MD_LINES 行时轮转：当前 md -> lookaround.1.md，并重建新 md。"""
    try:
        if MAX_MD_LINES <= 0:
            return
        p = os.path.join(root, LOOK_MD)
        if not os.path.exists(p):
            return
        with open(p, "r", encoding="utf-8") as f:
            n = sum(1 for _ in f)
        if n <= MAX_MD_LINES:
            return
        bak = os.path.join(root, "lookaround.1.md")
        if os.path.exists(bak):
            os.remove(bak)
        os.replace(p, bak)
        _ensure_md(root)  # 重建带表头的新 md
        with open(p, "a", encoding="utf-8") as f:
            f.write(f"\n> 上一份日志过长，已轮转到 `{os.path.basename(bak)}`。\n")
    except OSError:
        pass


def log_change(root, path, event, old=None, new=None, diff=None):
    """记录一次文件改动。diff 为可选的 unified-diff 文本块。"""
    try:
        rel = os.path.relpath(path, root)
    except ValueError:
        rel = path
    lines = [f"- 事件：{event}", f"- 文件：`{rel}`"]
    if old is not None and new is not None:
        lines.append(f"- 大小：{old} → {new} 字节")
    try:
        mtime = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(os.path.getmtime(path)))
        lines.append(f"- mtime：{mtime}")
    except OSError:
        pass
    if diff:
        lines.append(diff)
    log_event(root, f"改动 {rel}", "\n".join(lines))


# ---------------------------------------------------------------------------
# 错误「人话」翻译：把编译器/运行时原始英文报错翻成通俗中文
# ---------------------------------------------------------------------------
def _translate_msg(msg):
    """把单条编译器/运行时报错翻成通俗中文；翻不动返回 None。"""
    m = re.search(r"too few arguments to function '([^']+)'; expected (\d+), have (\d+)", msg)
    if m:
        return "调用函数 %s 时参数少了：它需要 %s 个参数，实际只给了 %s 个。" % (
            m.group(1), m.group(2), m.group(3))
    m = re.search(r"too many arguments to function '([^']+)'; expected (\d+), have (\d+)", msg)
    if m:
        return "调用函数 %s 时参数多了：它只需要 %s 个参数，你却给了 %s 个。" % (
            m.group(1), m.group(2), m.group(3))
    m = re.search(r"undefined reference to [`']([^`']+)[`']", msg)
    if m:
        return "链接时找不到 %s 的定义：它可能没有编译进来，或你忘了链接对应的库。" % m.group(1)
    m = re.search(r"cannot find -l(\S+)", msg)
    if m:
        return "链接时找不到库 %s（链接参数 -l%s 对应的库文件不存在，请检查库是否已安装或路径是否正确）。" % (
            m.group(1), m.group(1))
    m = re.search(r"([\w./\\+-]+):\s*No such file or directory", msg)
    if m:
        return "找不到头文件 %s：请检查 include 路径，或确认该文件已放在正确位置。" % m.group(1)
    m = re.search(r"implicit declaration of function '([^']+)'", msg)
    if m:
        return "使用了未声明的函数 %s：它可能没有被桥接 / 包含进来，或函数名写错了。" % m.group(1)
    m = re.search(r"conflicting types for '([^']+)'", msg)
    if m:
        return "函数 %s 的类型前后不一致：它的定义和声明对不上。" % m.group(1)
    m = re.search(r"expected ['\"]([^'\"]+)['\"] but argument is of type ['\"]([^'\"]+)['\"]", msg)
    if m:
        return "参数类型不匹配：这里期望 %s，但实际传入的是 %s。" % (m.group(1), m.group(2))
    # Python 常见异常
    m = re.match(r"^(\w+(?:Error|Exception))\b:?\s*(.*)$", msg.strip())
    if m:
        etype, detail = m.group(1), m.group(2).strip()
        table = {
            "ZeroDivisionError": "试图除以 0 了",
            "IndexError": "下标越界，序列里没那么多元素",
            "KeyError": "字典里没这个键",
            "NameError": "用到了一个没定义的名字",
            "AttributeError": "对象没这个属性 / 方法",
            "TypeError": "类型用错了",
            "ValueError": "值不合法",
            "FileNotFoundError": "文件不存在",
            "ModuleNotFoundError": "导入的模块不存在，可能没安装或名字写错了",
            "ImportError": "导入失败",
            "RecursionError": "递归太深了",
        }
        if etype in table:
            base = table[etype]
            return "%s：%s" % (base, detail) if detail else base + "。"
    # PYbook 自身的中文错误（本就带「第 X 行」）已是人话，原样保留
    if "第" in msg and "行" in msg:
        return msg.strip()
    return None


def _humanize_error(raw):
    """把一段原始错误（gcc / clang / Python Traceback / PYbook 中文）翻成通俗中文行列表。

    返回 (human_lines, 是否成功翻译)。翻译不出时退回原文。"""
    if not raw or not raw.strip():
        return [], False
    errs = []  # (位置, 消息)
    for ln in raw.strip().splitlines():
        s = ln.strip()
        if not s or s.startswith("In file included from"):
            continue  # 跳过噪音（头文件嵌套链）
        m = re.match(r'^(?P<loc>[\w./:\\-]+:\d+(?::\d+)?):\s*(?:fatal\s+)?(?:error|note):\s*(?P<msg>.*)$', s)
        if m:
            errs.append((m.group("loc"), m.group("msg")))
            continue
        m2 = re.search(r'\berror:\s*(.*)$', s)
        if m2:
            errs.append((None, m2.group(1)))
            continue
        # Python Traceback 末行异常
        if ("Traceback" in raw or 'File "' in raw) and re.match(r'^\w+(?:Error|Exception)\b', s):
            errs.append((None, s))
    human = []
    seen = set()
    for loc, msg in errs:
        h = _translate_msg(msg)
        if not h or h in seen:   # 同一错误常在源文件 + 链接器各报一次，去重
            continue
        seen.add(h)
        human.append("> %s%s" % (h, ("（位置：%s）" % loc) if loc else ""))
    if not human and errs:
        # 翻译不出、但确实抓到了错误行：原样展示这些错误行，别退回噪音首行
        for loc, msg in errs:
            human.append("> %s%s" % (msg, ("（位置：%s）" % loc) if loc else ""))
    if not human:
        # 最后一招：取第一条有意义的内容
        for ln in raw.strip().splitlines():
            s = ln.strip()
            if s and "In file included from" not in s:
                human.append("> %s" % s)
                break
    return human, bool(human)


def log_run(root, script, cmd_line, rc, stdout, stderr, todo_id=None):
    """记录一次运行（含运行时错误，错误会以通俗中文呈现，原文附后供排查）。

    todo_id 非空时把本次运行关联到该待办，供 `todo show <编号>` 跳转查看。"""
    try:
        rel = os.path.relpath(script, root)
    except ValueError:
        rel = script
    ok = (rc == 0)
    title = f"运行 {rel}" + ("" if ok else "  ❌ 运行时错误")
    lines = [f"- 命令：`{cmd_line}`", f"- 退出码：{rc}"]
    if todo_id:
        lines.append(f"- 关联待办：#{todo_id}")   # 待办 → 运行的跳转锚点
    if stdout and stdout.strip():
        lines.append("- 输出：\n```\n" + stdout.strip() + "\n```")
    if not ok:
        raw_err = (stderr and stderr.strip()) or (stdout and stdout.strip()) or ""
        if raw_err:
            human, _ = _humanize_error(raw_err)
            if human:
                lines.append("- 错误（人话）：\n" + "\n".join(human))
                lines.append("- 错误（原文，供排查）：\n```\n" + raw_err + "\n```")
            else:
                lines.append("- 错误：\n```\n" + raw_err + "\n```")
    log_event(root, title, "\n".join(lines))


# ---------------------------------------------------------------------------
# 内容 diff（仅文本文件、受大小/行数限制）
# ---------------------------------------------------------------------------
def _read_text_lines(path):
    """读取文本文件内容为行列表；非文本 / 过大 / 读失败返回 None（不记 diff）。"""
    try:
        size = os.path.getsize(path)
    except OSError:
        return None
    if size > MAX_DIFF_BYTES:
        return None
    try:
        with open(path, "r", encoding="utf-8", errors="strict") as f:
            return f.read().splitlines()
    except (UnicodeDecodeError, OSError):
        return None


def _diff_block(old_lines, new_lines):
    """生成 unified diff 文本块（超行数截断）。无差异返回 None。"""
    if old_lines == new_lines:
        return None
    diff = list(difflib.unified_diff(old_lines or [], new_lines or [],
                                     fromfile="before", tofile="after", lineterm=""))
    if not diff:
        return None
    if len(diff) > DIFF_MAX_LINES:
        diff = diff[:DIFF_MAX_LINES] + ["... (diff 已截断，共 %d 行)" % len(diff)]
    return "- diff：\n```diff\n" + "\n".join(diff) + "\n```"


# ---------------------------------------------------------------------------
# 待办清单（中途可随时 add / done / rm / list，与 watcher 进程解耦）
# ---------------------------------------------------------------------------
TODO_FILE = "lookaround.todo"     # 待办明细（独立于事件流 md）


def _todo_path(root):
    return os.path.join(root, TODO_FILE)


def _load_todos(root):
    """读取待办明细，返回 [{id, ts, done, text}, ...]。"""
    p = _todo_path(root)
    todos = []
    if os.path.exists(p):
        with open(p, "r", encoding="utf-8") as f:
            for line in f:
                line = line.rstrip("\n")
                if not line:
                    continue
                parts = line.split("|", 3)
                if len(parts) >= 4:
                    try:
                        todos.append({"id": int(parts[0]), "ts": parts[1],
                                      "done": parts[2] == "1", "text": parts[3]})
                    except ValueError:
                        pass
    return todos


def _save_todos(root, todos):
    with open(_todo_path(root), "w", encoding="utf-8") as f:
        for t in todos:
            f.write("%d|%s|%s|%s\n" % (t["id"], t["ts"],
                                       "1" if t["done"] else "0", t["text"]))


def add_todo(root, text):
    """新增一条待办（中途可随时加），返回新 id；同时在 md 记一笔事件。"""
    todos = _load_todos(root)
    nid = (todos[-1]["id"] + 1) if todos else 1
    ts = _ts()
    todos.append({"id": nid, "ts": ts, "done": False, "text": text})
    _save_todos(root, todos)
    log_event(root, "待办 +1", "- 新增 #%d：`%s`" % (nid, text))
    return nid


def done_todo(root, idx):
    """标记某条待办完成，返回是否成功。"""
    todos = _load_todos(root)
    for t in todos:
        if t["id"] == idx:
            t["done"] = True
            _save_todos(root, todos)
            log_event(root, "待办完成", "- 完成 #%d：`%s`" % (idx, t["text"]))
            return True
    return False


def rm_todo(root, idx):
    """删除某条待办，返回是否成功。"""
    todos = _load_todos(root)
    new = [t for t in todos if t["id"] != idx]
    if len(new) == len(todos):
        return False
    _save_todos(root, new)
    log_event(root, "待办删除", "- 删除 #%d" % idx)
    return True


def list_todo(root):
    """返回待办清单字符串（含完成状态）。"""
    todos = _load_todos(root)
    if not todos:
        return "（暂无待办）"
    out = []
    done_n = sum(1 for t in todos if t["done"])
    out.append("待办清单（%d/%d 已完成）：" % (done_n, len(todos)))
    for t in todos:
        mark = "x" if t["done"] else " "
        out.append("  [%s] #%d %s  (%s)" % (mark, t["id"], t["text"], t["ts"]))
    return "\n".join(out)


def show_todo(root, idx):
    """返回单条待办详情 + 与它关联的运行记录（待办 → 运行跳转）。未找到返回 None。"""
    todos = _load_todos(root)
    t = next((x for x in todos if x["id"] == idx), None)
    if not t:
        return None
    lines = ["#%d %s" % (t["id"], t["text"]),
             "- 状态：%s（创建于 %s）" % ("已完成" if t["done"] else "未完成", t["ts"])]
    rel_runs = []
    md = os.path.join(root, LOOK_MD)
    if os.path.exists(md):
        with open(md, "r", encoding="utf-8") as f:
            for ts, title, body in _parse_sections(f.read()):
                if ("关联待办：#%d" % idx) in body:
                    rel_runs.append((ts, title))
    if rel_runs:
        lines.append("- 关联运行：%d 次" % len(rel_runs))
        for ts, title in rel_runs:
            ok = "❌" not in title
            name = title[len("运行"):].split("❌")[0].strip()
            lines.append("  - %s  `%s`  %s" % (
                ts.strftime("%m-%d %H:%M:%S"), name, "✅ 成功" if ok else "❌ 失败"))
    else:
        lines.append("- 关联运行：无（跑 `pybktl run xxx.pybk --todo %d` 可把某次运行关联到本条）" % idx)
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# 文件快照（轮询用）
# ---------------------------------------------------------------------------
_SKIP_DIRS = ('exe_cache', 'rt_cache', '__pycache__', '.git', 'node_modules')
IGNORE_FILE = ".lookaroundignore"   # 自定义忽略名单（每行一条 glob，# 开头为注释）


def _load_ignore(root):
    """读取 .lookaroundignore 忽略规则（glob 列表）；文件不存在返回空。"""
    pats = []
    try:
        with open(os.path.join(root, IGNORE_FILE), "r", encoding="utf-8") as f:
            for ln in f:
                s = ln.strip()
                if s and not s.startswith("#"):
                    pats.append(s)
    except OSError:
        pass
    return pats


def _is_ignored(rel, pats):
    """相对路径（/ 分隔）是否命中忽略规则：匹配文件名、相对路径，或目录前缀。"""
    if not pats:
        return False
    import fnmatch
    base = os.path.basename(rel)
    for pat in pats:
        if fnmatch.fnmatch(base, pat) or fnmatch.fnmatch(rel, pat):
            return True
        if pat.endswith("/") and rel.startswith(pat.rstrip("/")):
            return True
    return False


def _snapshot(root):
    """扫描 root 下所有普通文件的 (size, mtime)。排除隐藏文件、日志自身、标记、缓存目录、忽略名单命中项。"""
    ignore = _load_ignore(root)
    snap = {}
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames
                       if not d.startswith('.') and d not in _SKIP_DIRS]
        for fn in filenames:
            if fn.startswith('.'):          # 跳过 .lookaround 等隐藏文件
                continue
            if fn == LOOK_MD:               # 别监控日志自己
                continue
            if fn == "lookaround.1.md":     # 轮转出来的历史日志
                continue
            if fn == LOOK_TODO:             # 待办明细由 todo 命令记语义事件，避免重复
                continue
            fp = os.path.join(dirpath, fn)
            rel = os.path.relpath(fp, root).replace("\\", "/")
            if ignore and _is_ignored(rel, ignore):   # .lookaroundignore 忽略
                continue
            try:
                st = os.stat(fp)
                snap[fp] = (st.st_size, st.st_mtime)
            except OSError:
                pass
    return snap


def start_watcher():
    """前台日志循环：监控 cwd，Ctrl+C 停止。"""
    root = os.path.abspath(os.getcwd())
    marker = os.path.join(root, MARKER)
    with open(marker, "w") as f:
        f.write(str(os.getpid()))   # 存 PID，供 run/todo 检测「强杀残留标记」
    log_event(root, "LookAround 已开启",
              f"- 监控目录：`{root}`\n"
              f"- 该文件夹里运行 `pybktl run`/`smoke`/`build`/`check` 会自动记录\n"
              f"- 文本文件改动会记录内容 diff\n"
              f"- 本窗口按 Ctrl+C 停止；查看历史用 `pybktl lookaround log`")
    print(f"LookAround 已开启，监控：{root}")
    print(f"日志写入：{os.path.join(root, LOOK_MD)}  （Ctrl+C 停止）")

    snap = _snapshot(root)
    # 内容缓存：仅保存文本文件行内容，用于生成 consecutive diff
    content_cache = {}
    for path in snap:
        cl = _read_text_lines(path)
        if cl is not None:
            content_cache[path] = cl
    try:
        while True:
            time.sleep(1)
            new = _snapshot(root)
            for path, info in new.items():
                if path not in snap:
                    log_change(root, path, "created", new=info[0])
                    cl = _read_text_lines(path)
                    if cl is not None:
                        content_cache[path] = cl
                elif snap[path] != info:
                    old_size, new_size = snap[path][0], info[0]
                    diff = None
                    cl = _read_text_lines(path)
                    if cl is not None:
                        old_cl = content_cache.get(path)
                        if old_cl is not None:
                            diff = _diff_block(old_cl, cl)
                        content_cache[path] = cl
                    log_change(root, path, "modified", old=old_size, new=new_size, diff=diff)
            for path in snap:
                if path not in new:
                    content_cache.pop(path, None)
                    log_change(root, path, "deleted")
            snap = new
    except KeyboardInterrupt:
        try:
            os.remove(marker)
        except OSError:
            pass
        log_event(root, "LookAround 已停止", f"- 停止时间：{_ts()}")
        print(f"\nLookAround 已停止。日志见：{os.path.join(root, LOOK_MD)}")


# ---------------------------------------------------------------------------
# 日志查看 / 筛选
# ---------------------------------------------------------------------------
_SEC_RE = re.compile(r'^## (\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}) — (.+)$')


def _parse_sections(text):
    """把 md 拆成 [(datetime, title, body), ...]，按 `## 时间 — 标题` 分段。"""
    sections = []
    cur_ts = None
    cur_title = ""
    cur_lines = []
    for line in text.splitlines():
        m = _SEC_RE.match(line)
        if m:
            if cur_ts is not None:
                sections.append((cur_ts, cur_title, "\n".join(cur_lines)))
            try:
                cur_ts = datetime.strptime(m.group(1), "%Y-%m-%d %H:%M:%S")
            except ValueError:
                cur_ts = None
            cur_title = m.group(2)
            cur_lines = []
        else:
            if cur_ts is not None:
                cur_lines.append(line)
    if cur_ts is not None:
        sections.append((cur_ts, cur_title, "\n".join(cur_lines)))
    return sections


def _parse_dt(s):
    s = (s or "").strip()
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%Y-%m-%d"):
        try:
            return datetime.strptime(s, fmt)
        except ValueError:
            continue
    return None


def _match_type(title, etype):
    if etype == "change":
        return title.startswith("改动")
    if etype == "run":
        return title.startswith("运行")
    if etype == "todo":
        return title.startswith("待办")
    if etype == "error":
        return "❌" in title or "运行时错误" in title or "错误" in title
    return False


def view_log(file=None, since=None, until=None, etype=None, tail=0):
    """解析并筛选 lookaround.md，返回 (root_or_None, 要打印的文本)。

    root 为 None 时文本是提示/错误信息；否则文本为筛选结果。"""
    root = find_lookaround_root(os.getcwd())
    if not root:
        return None, "该文件夹未开启 LookAround 日志循环：请先 `cd` 到目标文件夹执行 `pybktl lookaround`。"
    md = os.path.join(root, LOOK_MD)
    if not os.path.exists(md):
        return None, "未找到 lookaround.md（该文件夹尚未记录任何事件）。"
    with open(md, "r", encoding="utf-8") as f:
        text = f.read()
    sections = _parse_sections(text)
    s_dt = _parse_dt(since) if since else None
    u_dt = _parse_dt(until) if until else None
    out = []
    for ts, title, body in sections:
        if s_dt and ts < s_dt:
            continue
        if u_dt and ts > u_dt:
            continue
        if etype and not _match_type(title, etype):
            continue
        if file and file not in (title + "\n" + body):
            continue
        out.append("## %s — %s\n%s" % (ts.strftime("%Y-%m-%d %H:%M:%S"), title, body.rstrip()))
    if tail and tail > 0 and len(out) > tail:
        out = out[-tail:]
    if not out:
        return root, "（无匹配事件）"
    return root, "# LookAround 日志筛选结果（%d 条）\n\n%s" % (len(out), "\n\n".join(out))


# ---------------------------------------------------------------------------
# 团队协作报告（改动 / 运行 / 错误汇总 + 待办完成情况）
# ---------------------------------------------------------------------------
def _extract_field(body, key):
    """从事件 body 里取 `- key：值` 形式的值。"""
    m = re.search(r'^- %s：(.+)$' % re.escape(key), body, re.M)
    return m.group(1).strip() if m else None


def build_report(root, since=None, until=None, by=None):
    """生成团队协作报告（Markdown 字符串）：改动/运行/错误汇总 + 待办完成情况。"""
    md = os.path.join(root, LOOK_MD)
    if not os.path.exists(md):
        return "# LookAround 团队协作报告\n\n（尚未记录任何事件）"
    with open(md, "r", encoding="utf-8") as f:
        sections = _parse_sections(f.read())
    s_dt = _parse_dt(since) if since else None
    u_dt = _parse_dt(until) if until else None

    file_stats = {}   # 文件 -> [改动次数, 最后动作]
    runs = []         # (时间, 程序名, 是否成功)
    errors = {}       # 人话错误 -> 次数
    for ts, title, body in sections:
        if s_dt and ts < s_dt:
            continue
        if u_dt and ts > u_dt:
            continue
        if title.startswith("改动"):
            fn = _extract_field(body, "文件") or "?"
            ev = _extract_field(body, "事件") or "?"
            st = file_stats.setdefault(fn, [0, ev])
            st[0] += 1
            st[1] = ev
        elif title.startswith("运行"):
            ok = "❌" not in title
            runs.append((ts, title[len("运行"):].split("❌")[0].strip(), ok))
            if not ok:
                mm = re.search(r'- 错误（人话）：\n((?:> .*\n?)+)', body)
                if mm:
                    for ln in mm.group(1).splitlines():
                        ln = ln.strip()
                        if ln.startswith("> "):
                            msg = ln[2:].strip()
                            # 剥离「（位置：out_xxxx.c:行:列）」：gcc 临时文件名每次不同，
                            # 不剥离会让同一逻辑错误聚合成多条，报告里的频次就失真了
                            msg = re.sub(r"（位置：[^）]*）", "", msg)
                            errors[msg] = errors.get(msg, 0) + 1
    todos = _load_todos(root)
    done_n = sum(1 for t in todos if t["done"])

    period = ("%s ~ %s" % (since or "最早", until or "现在")) if (since or until) else "全部时间"
    L = ["# LookAround 团队协作报告", "",
         "- 生成时间：%s" % _ts()]
    if by:
        L.append("- 报告人：%s" % by)
    L += ["- 统计周期：%s" % period, "- 目录：`%s`" % root, "",
          "## 总览", "",
          "- 改动文件：%d 个（累计 %d 次改动）" % (
              len(file_stats), sum(v[0] for v in file_stats.values())),
          "- 运行：%d 次（成功 %d / 失败 %d）" % (
              len(runs), sum(1 for r in runs if r[2]), sum(1 for r in runs if not r[2])),
          "- 错误（人话）：%d 类" % len(errors),
          "- 待办：%d/%d 已完成（%.0f%%）" % (
              done_n, len(todos), (done_n / len(todos) * 100) if todos else 0),
          ""]

    L += ["## 文件改动", ""]
    if file_stats:
        L += ["| 文件 | 改动次数 | 最后动作 |", "|---|---|---|"]
        for fn, (cnt, last) in sorted(file_stats.items(), key=lambda kv: -kv[1][0]):
            L.append("| `%s` | %d | %s |" % (fn, cnt, last))
    else:
        L.append("（无）")

    L += ["", "## 运行记录", ""]
    if runs:
        L += ["| 时间 | 程序 | 结果 |", "|---|---|---|"]
        for ts, name, ok in runs:
            L.append("| %s | `%s` | %s |" % (
                ts.strftime("%m-%d %H:%M:%S"), name, "✅ 成功" if ok else "❌ 失败"))
    else:
        L.append("（无）")

    L += ["", "## 错误汇总（人话）", ""]
    if errors:
        L += ["| 错误 | 次数 |", "|---|---|"]
        for msg, cnt in sorted(errors.items(), key=lambda kv: -kv[1]):
            L.append("| %s | %d |" % (msg, cnt))
    else:
        L.append("（无报错）")

    L += ["", "## 待办完成情况", ""]
    if todos:
        for t in todos:
            L.append("- [%s] #%d %s" % ("x" if t["done"] else " ", t["id"], t["text"]))
    else:
        L.append("（无待办）")
    L.append("")
    return "\n".join(L)


if __name__ == "__main__":
    start_watcher()
