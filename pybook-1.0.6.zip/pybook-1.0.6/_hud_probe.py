# -*- coding: utf-8 -*-
"""按"设计坐标"去 BMP 里采样，看 HUD 有没有跟着窗口缩放。

思路：HUD 板子的底色是 (16,18,24) 的近黑。把设计坐标按 (x/1100*W, y/620*H)
换算成像素去采样 —— 如果 HUD 贴着窗口缩放，板内一定是近黑、板外一定不是。
用法：python _hud_probe.py 图.bmp [设计宽] [设计高]
"""
import struct
import sys

SRC = sys.argv[1]
DW = int(sys.argv[2]) if len(sys.argv) > 2 else 1100
DH = int(sys.argv[3]) if len(sys.argv) > 3 else 620

d = open(SRC, 'rb').read()
off = struct.unpack_from('<I', d, 10)[0]
w, h = struct.unpack_from('<ii', d, 18)
bpp = struct.unpack_from('<H', d, 28)[0]
H = abs(h)
topdown = h < 0
step = bpp // 8
rowsz = (w * step + 3) & ~3


def px(x, y):
    x = max(0, min(w - 1, x))
    y = max(0, min(H - 1, y))
    sy = y if topdown else (H - 1 - y)
    p = off + sy * rowsz + x * step
    return d[p + 2], d[p + 1], d[p]


def dark(c):
    """HUD 板子 = 近黑且偏灰；3D 场景里的草地/树干都不满足（绿/棕，色彩差大）。"""
    return (c[0] + c[1] + c[2] < 260) and (max(c) - min(c) <= 40)


print('图 %s  %dx%d   设计 %dx%d   比例 %.3f x %.3f'
      % (SRC, w, H, DW, DH, w / DW, H / DH))

# 采样点特意避开文字/进度条，落在板子的纯底色上
SAMPLES = [
    ('得分板内',   (400, 124),  '板内'),
    ('得分板右外', (440, 60),   '板外'),
    ('得分板上外', (400, 6),    '板外'),
    ('武器栏内',   (114, 596),  '板内'),
    ('武器栏右外', (520, 560),  '板外'),
    ('弹药板内',   (1070, 600), '板内'),
    ('弹药板右外', (1092, 560), '板外'),
    ('弹药板下外', (940, 614),  '板外'),
]
bad = 0
for name, (dx, dy), want in SAMPLES:
    X = int(dx / DW * w)
    Y = int(dy / DH * h)
    c = px(X, Y)
    got = '板内' if dark(c) else '板外'
    ok = (got == want)
    if not ok:
        bad += 1
    print('  %-12s 设计(%4d,%4d) → 像素(%4d,%4d)  rgb%-16s %s  %s'
          % (name, dx, dy, X, Y, str(c), got, 'OK' if ok else '<<< 不符'))

print('不符 %d/%d' % (bad, len(SAMPLES)))

# 顺带报一下：整张图里近黑像素的最右 / 最下位置（HUD 板子应该贴着边）
right = -1
bottom = -1
for y in range(0, H, 2):
    for x in range(w - 1, right, -1):
        if dark(px(x, y)):
            if x > right:
                right = x
            break
for x in range(0, w, 2):
    for y in range(H - 1, bottom, -1):
        if dark(px(x, y)):
            if y > bottom:
                bottom = y
            break
print('近黑像素最右 x=%d (%.1f%% of %d)   最下 y=%d (%.1f%% of %d)'
      % (right, 100.0 * right / w, w, bottom, 100.0 * bottom / H, H))
