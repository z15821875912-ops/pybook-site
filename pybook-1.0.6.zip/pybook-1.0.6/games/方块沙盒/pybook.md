# PYbook 项目清单（pybktl 读取此文件）
# 格式就是 markdown，人和 AI 都能直接读写。

## 编译器
home: C:\Users\zhuli\Desktop\pybook-1.0.5.2

## 依赖
# - 物理引擎 => ../libs/physics.pybk
- mec => ./mec.pybk
- myui3d => ./myui3d.pybk
- fancy3d => ./fancy3d.pybk

## 工作区
- 方块沙盒.pybk
- 自测.pybk
