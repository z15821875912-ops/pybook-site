# -*- coding: utf-8 -*-
"""生成"能自己跑完退出"的测试副本，只为截图验证。
刻意不做的事：不自动开火（除非显式给 fire）、不锁鼠标。

用法：python _mkharness.py <out.pybk> <idle|walk|tp> [ads] [fire] [w0|w1|w2|w3]

  idle  站着不动      walk  按住 W 看走路动画      tp  第三人称
  ads   强制右键瞄准（瞄要 = 1）
  fire  强制扣扳机（每帧都开，冷却管着节奏）
  w0..w3 强制指定开局拿哪把枪（0 手枪 1 步枪 2 霰弹 3 狙击）
  skill 技能栏压住几个冷却不放 + 减速力场常开（看 HUD 两种状态）
  hot   狂热常开（看橙色那条边）
注意：skill / hot 和 resize 用的是同一个锚点，别在同一个副本里叠。
"""
import io
import sys

OUT = sys.argv[1]
MODE = sys.argv[2] if len(sys.argv) > 2 else 'idle'
FLAGS = sys.argv[3:]

src = io.open('示例_射击场.pybk', encoding='utf-8').read()

PATCHES = [
    # 只换开局那次 grab（Enter 里那次留着，锚点靠后面的主循环注释块区分）
    ('不锁鼠标', '丢 = hw.grab()\n\n# ====', '丢 = 0\n\n# ===='),
    ('加帧计数器', '清场 = 0.0\n锁定 = 0\n视角 = 0\n',
                 '清场 = 0.0\n锁定 = 0\n视角 = 0\n帧 = 0\n'),
    ('帧自增', '    dt = 0.016\n', '    dt = 0.016\n    帧 = 帧 + 1\n'),
    # rm.aging.while 是 repeat-until（条件为真才跳出），所以"限帧"要 or 上去。
    # 写成 and 的后果：过了 320 帧条件恒假 → 循环永不退出（本次实测卡死 3 分钟）。
    ('循环上限', 'rm.aging.while(hw.end()) {',
                'rm.aging.while(hw.end() or 帧 > 320) {'),
]

if MODE == 'walk':
    PATCHES.append(('按住W（只为看走路动画）',
                    '        if(hw.key("w")) {\n            前 = 1.0\n        }',
                    '        前 = 1.0'))
elif MODE == 'tp':
    PATCHES.append(('切第三人称', '视角 = 0\n帧 = 0', '视角 = 1\n帧 = 0'))

if 'ads' in FLAGS:
    PATCHES.append(('强制瞄准', '    瞄要 = 0.0\n', '    瞄要 = 1.0\n'))

if 'fire' in FLAGS:
    PATCHES.append(('强制开火', '    开扳机 = 0\n', '    开扳机 = 1\n'))

# 技能 HUD 验证：把冷却钉在几个不同的值上（每帧重置一次，
# 所以"计时"那段减掉的 dt 会被立刻补回来 —— 看起来就是三个冷却中 + 一个转好）
if 'skill' in FLAGS:
    PATCHES.append(('钉住技能冷却 + 减速常开',
                    '    帧 = 帧 + 1\n',
                    '    帧 = 帧 + 1\n'
                    '    技冷 = [3.2, 8.4, 20.0, 0.0]\n'
                    '    减速时 = 7.0\n'))

if 'hot' in FLAGS:
    PATCHES.append(('狂热常开',
                    '    帧 = 帧 + 1\n',
                    '    帧 = 帧 + 1\n'
                    '    狂热时 = 6.0\n'))

# 真·拉伸测试：设计尺寸还是 1100x620 不动，只把真窗口在第 30 帧拉大 ——
# 这才是用户"窗口拉大了 HUD 却缩在左上角"的场景。
if 'resize' in FLAGS:
    PATCHES.append(('第 30 帧把窗口拉到 1500x820',
                    '    帧 = 帧 + 1\n',
                    '    帧 = 帧 + 1\n'
                    '    if(帧 == 30) {\n'
                    '        hw.resize(1500, 820)\n'
                    '    }\n'))

# 窗口尺寸：big=1500x800（拉伸验证 HUD 贴边）、tall=900x700（非等比验证）
SIZES = {'big': (1500, 800), 'tall': (900, 700)}
for f in FLAGS:
    if f in SIZES:
        w, h = SIZES[f]
        PATCHES.append(('窗口 %dx%d' % (w, h),
                        'hw.open(1100, 620, "青山射击场 · 第一人称对射")',
                        'hw.open(%d, %d, "青山射击场 · 第一人称对射")' % (w, h)))

W = None
for f in FLAGS:
    if len(f) == 2 and f[0] == 'w' and f[1] in '0123':
        W = int(f[1])

for label, old, new in PATCHES:
    n = src.count(old)
    if n != 1:
        sys.stderr.write('FAIL [%s] count=%d\n' % (label, n))
        sys.exit(1)
    src = src.replace(old, new, 1)
    print('ok  ' + label)

if W is not None:
    # 枪选 / 上次枪 是两行独立的顶层赋值，整行替换最稳
    lines = src.split('\n')
    got = 0
    for idx, ln in enumerate(lines):
        if ln.startswith('枪选 = 1') and '开局拿步枪' in ln:
            lines[idx] = '枪选 = %d' % W
            got = got + 1
        elif ln.startswith('上次枪 = 1'):
            lines[idx] = '上次枪 = %d' % W
            got = got + 1
    if got != 2:
        sys.stderr.write('FAIL [强制枪%s] got=%d\n' % (W, got))
        sys.exit(1)
    src = '\n'.join(lines)
    print('ok  强制拿枪 w%d' % W)

io.open(OUT, 'w', encoding='utf-8', newline='\n').write(src)
print('wrote %s (%s %s)' % (OUT, MODE, ','.join(FLAGS) if FLAGS else '-'))
