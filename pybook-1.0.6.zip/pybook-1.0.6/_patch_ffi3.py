# -*- coding: utf-8 -*-
"""顶层支持 c.* 指令（底层窗口放文件头）。幂等补丁。"""
import io
import sys

PATH = 'pybk_front.py'
s = io.open(PATH, encoding='utf-8').read()

PATCHES = [
    ('top_c_branch',
     "            elif self.at('KW', 'web'):\n"
     "                self.parse_hm_blockdef()",
     "            elif self.at('KW', 'web'):\n"
     "                self.parse_hm_blockdef()\n"
     "            elif self.at('KW', 'c'):\n"
     "                # top-level c.* directives (low-level window): compile-time, file head\n"
     "                stmt = self.parse_expr()\n"
     "                if not (isinstance(stmt, Call) and stmt.name.startswith('c.')):\n"
     '                    self.err("\u9876\u5c42\u53ea\u63a5\u53d7 c. \u5f00\u5934\u7684\u5e95\u5c42\u6307\u4ee4\uff1ac.\u5305\u542b/c.\u94fe\u63a5/c.\u58f0\u660e/c.\u7801/c.\u8c03\u7528")\n'
     "                init_stmts.append(stmt)"),
    ('top_c_merge',
     "            go_body = mems + go_body",
     "            go_body = mems + init_stmts + go_body   # top-level c.* lands in front of GOING"),
]

for label, old, new in PATCHES:
    n = s.count(old)
    if n != 1:
        sys.stderr.write('FAIL [%s] count=%d\n' % (label, n))
        sys.exit(1)
    s = s.replace(old, new, 1)
    print('ok  ' + label)

io.open(PATH, 'w', encoding='utf-8', newline='').write(s)
print('written:', PATH)
