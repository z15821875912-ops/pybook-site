"""量一张 BMP 里"视野中央"有多少暗像素 —— 用来判断枪是不是把画面糊住了。

只sample 视野正中一块（避开四角的 HUD 面板），统计
  r+g+b < 150 的"很暗"像素占比，以及最暗的那一档。
用法: python _darkprobe.py 图1.bmp 图2.bmp ...
"""
import struct
import sys


def load_bmp(path):
    with open(path, 'rb') as f:
        b = f.read()
    off = struct.unpack_from('<I', b, 10)[0]
    w, h = struct.unpack_from('<ii', b, 18)
    bpp = struct.unpack_from('<H', b, 28)[0]
    if bpp not in (24, 32):
        raise SystemExit('只支持 24/32 位: %s (%d)' % (path, bpp))
    rows = []
    stride = ((w * bpp // 8) + 3) // 4 * 4
    for y in range(abs(h)):
        base = off + y * stride
        row = []
        for x in range(w):
            p = base + x * (bpp // 8)
            row.append((b[p + 2], b[p + 1], b[p]))       # BMP 是 BGR
        rows.append(row)
    if h > 0:
        rows.reverse()
    return w, abs(h), rows


def stats(path):
    w, h, rows = load_bmp(path)
    x0, x1 = int(w * 0.20), int(w * 0.80)
    y0, y1 = int(h * 0.30), int(h * 0.72)
    tot = 0
    dark = 0
    vdark = 0
    for y in range(y0, y1):
        for x in range(x0, x1):
            r, g, bl = rows[y][x]
            s = r + g + bl
            tot += 1
            if s < 150:
                dark += 1
            if s < 90:
                vdark += 1
    print('%-34s %4dx%-4d  中央暗像素 <150: %5.1f%%   <90: %5.1f%%'
          % (path.split('/')[-1], w, h, dark * 100.0 / tot, vdark * 100.0 / tot))


if __name__ == '__main__':
    for a in sys.argv[1:]:
        stats(a)
