import sys
from pybk_front import parse
from pybk_code import Codegen

src = open(sys.argv[1], encoding='utf-8-sig').read()
prog = parse(src)
c = Codegen().generate(prog)
out = 'out_' + sys.argv[1].replace('.', '_') + '.c'
open(out, 'w', encoding='utf-8').write(c)
print('wrote', out, len(c), 'bytes')
