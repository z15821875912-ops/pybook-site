# PYBOOK_AI.md —— 给 AI 的 PYbook 编程规范

PYbook 是一门中文优先的编程语言：编译到 C、原生 SDL 窗口、以 Python 级语法写 2D/3D 游戏。
本文写给将要**生成 PYbook 代码**的 AI（你）。读完这一页即可精准输出，无需读编译器源码。

## 30 秒上手

```python
@ 游戏>我的程序>1          # 元信息行（必有）

window(normal, open)       # 框架模式：win() 之前的语句只跑一次，之后的每帧跑

GOING:{
    vg.x = 100             # 新变量必须 vg. 前缀（声明）
    win(800, 500, "标题")  # 开窗口（框架模式必调）
    color(255, 200, 80)
    圆(x, 100, 10)         # 画一个圆
}STOP
```

运行：`python pybk_main.py 程序.pybk`（窗口程序）。
**只验证语法**：`python pybk_main.py --check 程序.pybk`（不弹窗，AI 改-验循环用这个）；
`--check-json` 输出 `{"ok": bool, "line": 行号, "message": …}`。

## 硬规则（违反即编译失败，每条都带行号报错）

1. **新变量声明必须 `vg.`**：`vg.x = 1`。声明过之后的同函数内裸赋值 `x = 2` 也合法。
   函数参数的元素可直接 `表[i] = 值`（参数例外）。
2. **函数读不到全局**：函数体内只能读自己的参数和自己赋过的变量。需要场景数据？把列表
   当参数传进去（列表按引用传）。
3. **用户函数调用不是语句**：`我的函数(1)` 单独一行非法。写 `vg.结果 = 我的函数(1)`。
4. **ret 只在 func 里**；`window(normal, open)` 必须在 GOING 之前、文件级。
5. **类可跨模块**：`引用("模块")` 会把模块的 `lb.` 类、函数、顶层变量一并并入；
   类名/函数名跨文件不得重复。构造器仍是 `lb.类名(属性=值)`，属性名拼写错误会带行号报错。
6. **key() 返回布尔**：不能 `key("a") + key("left")`，要 `if(key("a") or key("left"))`。
   注意 key 读全局键盘——别的窗口打字也会被算进去。
7. **插值字符串里不能再嵌引号**：`"$(表["键"])"` 非法。先 `vg.键 = "键"` 再 `"$(表[键])"`。
8. **`$名` 插值要求变量已声明**；任意表达式用 `$(表达式)`；字面 `$` 写 `$$`。
9. **文件名含中文没问题**；Python 3.11；2D 窗口走 `win()`，3D 走 `hw.*`（`ON 3D_highway` 开启）。

## 语境差异（AI 最容易踩的三处）

| 语境 | 裸赋值 | 裸下标赋值 | 说明 |
|---|---|---|---|
| GOING 里（无 window 语句） | 要 `vg.` | 要 `vg.` | 严格模式 |
| GOING 里（有 window(normal,open)） | 可裸 | 参数可裸、其余要 `vg.` | 宽松模式 |
| 函数体内 | 可裸（自己声明的） | 参数可裸 | 函数读不到全局 |

拿不准就全写 `vg.`——永远正确，只是啰嗦。

## 语法速查（P1~P4 全集）

```
vg.a, vg.b = 1, 2              # 多定义
a, b = b, a                    # 交换（右边先算完）
vg.dx, vg.dy = dirkeys()       # 解包：一个列表拆给多目标
vg.偶 = [x for x in 表 if x % 2 == 0]    # 列表推导
vg.翻倍 = {k: v * 2 for k, v in 词频}    # 字典推导
x > 3 ? 1 : 0                  # 三元
"值 = $(x + 1) 百分号$$"        # 任何字符串可插值；$() 里写完整表达式
分 += 10                       # += -= *= /=
xs[-1]  xs[1:4]  xs[::-1]      # 负索引 / 切片 / 反转步长
if(x in 表)  if(x not in 表)   # 成员判断（字符串两边则是子串判断）
for 词, 次 in 词频 { ... }      # 字典双变量遍历（列表单变量）
func 击杀分(基数 = 10, 连击加 = 5) = 基数 + 连击加 * 2   # 默认参数+单行函数
```

## 内置与标准库

- 帧/输入：`frame`（帧数）`sec`（秒）`dirkeys()`（WASD+方向键 → [dx,dy]）
  `key("a")` `hit("space")` `mx() my() mdown()`
- 绘制：`win(宽,高,"标题")` `color(r,g,b)` `clear()` `box(x,y,w,h)` `圆(x,y,r)`
  `线(x1,y1,x2,y2)` `字(x,y,"文本",号)` `图(x,y,"路径")` `图缩(x,y,w,h,"路径")`
- 聚合：`mt.sum(表)` `mt.max` `mt.min` `list.sorted(表)`（升序新表）
  `list.rsorted(表)`（降序新表）`list.byfield(对象表, "字段", 1或-1)`
- 字典：`{"键": 值}` 字面量；`长度(d)` `删掉(d, 键)` `dict.keys(d)` `dict.values(d)`
  `dict.byvalue(d, 1或-1)`（按键值排序取键）
- 列表：`长度(表)` `添加(表, 值)` `删掉(表, 值)` `list.find(表, 值)`（无则 -1）
  `list.sort(表)`（原地）
- 数学：`mt.sqrt abs floor ceil sin cos atan2 依此类推`（mt. 前缀，中文报错）
- 数据交换：`js.parse(文本)` / `js.dump(值)` JSON 读写（字典/列表/数字/字符串/真假/空，
  往返保真）；`csv.parse(文本)` / `csv.dump(表)` 表格文本（逗号引号换行自动处理）
- 列表进阶：`list.flat(嵌套表)`（一层展平）`list.zip(a, b)`（按位配对取短）`list.count(表, 值)`
- 空值字面量：`空` 或 `none`（js.dump 出 null）
- 像素画 MyMove（twoM）：列表即画布，一行字符串一排像素。`mm.draw_away(表, "名.png", 倍数)`
  落成 PNG（透明自动抠）；`mm.贴(表, x, y, 倍数)` 窗口直画；`mm.动([帧1, 帧2], x, y, 倍数, 帧率)` 逐帧动画
  （按帧率轮播帧列表）；`mm.色(token, r, g, b)` 自定义色。中英双名：color=色、blt=贴、anim=动。
  两种写法自动识别：行内含空格 = 多字符 token（`"b1 b2 ."`，`.` 透明）；整图无空格 = 单字符连写
  （`"..gg.."`，每字符一像素）。内置色阶 b/r/g/y/o/p 各 1~3 阶 + w/k/f 与单字符简谱
- 字符串：`te.join(表, "分隔")`（表在前！）`te.split(文本, " ")` `te.str(x)`（转文本）
- 声音：`音.快(频率, 毫秒, 波形)` 非阻塞；`mu.play("文件.wav")`
- 循环：`rm.around(n) -> i { ... }`（n 圈，i 从 0）；`for x in 表`；`rm.aging.while(条件)`
- 文本输出：`ns.show("a", 1, x)`（多参数空格相连，列表/字典直显）

## 神经网络（tb.*：张量 = 二维列表，反向传播手写但算子齐全）

```python
vg.W1 = tb.rand(4, 8)          # 4行8列 随机权重
vg.隐 = tb.relu(tb.lin(X, W1, B1))     # 全连接 + ReLU
vg.概 = tb.softmax(tb.lin(隐, W2, B2)) # 分类输出：每行和为1
vg.损 = tb.crossent(概, Y)      # 交叉熵（Y 是类别号列向量 [[3],[1],...]）
vg.g = tb.lin_dw(隐, tb.crossent_grad(概, Y), W2)   # 梯度链
tb.sgd(W2, g, 0.1)              # 就地更新（lr=0.1）
```

- 形状：`tb.rows(M)` `tb.cols(M)` `tb.mat(行,列,值)` `tb.tr(M)`（转置）
- 运算：`tb.dot(A,B)` `tb.add(A,B)` `tb.mul(A,B)`（逐元素）
- 层：`tb.lin(X,W,B)` 全连接；`tb.relu` `tb.sigmoid` `tb.softmax`
- 损失：`tb.mse(预测,真值)`；`tb.crossent(概率,类别)`；对应 `*_grad` 同参数
- 优化器：`tb.sgd(W,梯度,lr)`；`tb.adam(W,梯度,M,V,lr,b1,b2,步数)`（M/V 各自
  `tb.mat` 同形零矩阵，传进去会被更新）
- 数据：`tb.rand(行,列)` `tb.shuffle(列表,种子)`（同种子同结果）
  `tb.onehot(n,类别数)` `tb.batch(列表,批号,大小)`（批号从0，批 i 取 [i*大小, i*大小+大小)，末尾不足截断，越界得空表）
- 完整可跑示例：`AI走迷宫.pybk`、`神经网络示例.pybk`（两层网络 + Adam 训练到 100% 准确率）

## 数学进阶（mp.*，math+：向量/矩阵/统计/随机，元素全是**一维列表**）

```python
vg.v = mp.vec_add([1,0,0], [0,1,0])      # 向量：add/sub/scale/dot/cross/norm/normalize/dist/lerp
vg.M = mp.mat_mul(A, B, 2, 3, 3)         # 矩阵乘：mat_mul(A,B,行,中,列)——矩阵存成一维列表，形状另传
vg.D = mp.mat_det(M, 3)                  # 方阵：det/inverse(M,n)；mat_identity(n)
vg.sd = mp.std(数据, 0)                  # 统计：mean(表) var/std(表,ddof) minmax(表)→[最小,最大]
vg.x = mp.lerp(0, 100, 0.5)              # 插值族：lerp/clamp/smoothstep(边0,边1,x)
vg.n = mp.rand_normal(0, 1)              # 正态随机数；rand_u01()均匀[0,1)；rand_seed(种子)
```

- 矩阵函数一律 **一维列表 + 行列参数**（和 tb.* 的二维列表是两套体系，别混用）
- 角度函数 `mp.radians(度)` `mp.degrees(弧度)`；`mt.*` 是基础数学（sqrt/sin/…），够用就别用 mp

## 数值数组（np.*，numpybk：一维数组 + 逐元素运算）

```python
vg.a = np.range(0, 10, 2)        # [0,2,4,6,8]；np.zeros(n) 全零
vg.b = np.add(a, [1,1,1,1,1])    # 逐元素 add/sub/mul；np.scale(数组, 系数)
vg.c = np.sin(a)                 # 逐元素 sin/cos/sqrt
vg.d = np.normalize(v)           # 单位化；np.norm(v)；np.dot(a,b)
vg.m = np.mean(a)                # 聚合：max/min/sum/mean
```

np 和 mp 的向量功能有重叠：纯数组逐元素运算用 np，需要矩阵/统计/随机用 mp。

## 网页输出（web.*：编译运行后生成 pybook_page.html 并自动弹浏览器）

```python
@ 博客>首页>1
GOING:{
web.title("我的主页")
web.big(你好 $名字)                       # 大标题；web.mid 中标题
web.show(得分 $分数 / 2)/magic(b, c=0,200,255)   # 段落；$() 任意表达式；/magic 修饰可省
web.img("风景.png")                       # 图片；web.line 分隔线
web.link("教程", "https://…")             # 超链接
web.draw.始                               # 开画布；帧动画和实时块都要包在 始/终 之间
web.帧 { web.draw.色(255,0,0)  web.draw.圆(100,100,30) }   # 预烤动画帧
web.帧 { web.draw.色(0,0,255)  web.draw.圆(200,100,30) }
web.播放(12)                              # 以 12 帧/秒循环之前的所有 帧
web.实时(60) { web.draw.清(0,0,0)  web.draw.圆(web.mx(), web.my(), 10)
    if(web.down("go")) { web.draw.色(0,255,0) } }        # 浏览器实时循环
web.draw.终
web.textbox("输入名字", "nm")             # 页面控件：输入框、按钮
web.button("点我", "go")
}STOP
```

- 画布绘图动词：`web.draw.始/色/圆/方/线/清/字/图/图缩/终`；**实时块里参数是表达式每帧重算**，
  预烤帧里参数烤成常量；画布缺省 400×300，`web.draw.始(800, 450)` 可调（鼠标坐标自动按尺寸换算）
- **多页 `web.页("名") { 页面语句 }`**：烤成独立文件 `pybook_page_名.html`，页间用
  `web.link("文字", "pybook_page_名.html")` 跳转；页里不能套 帧/播放/实时/draw/嵌套页
- **组件复用 `web.块`**：文件顶层定义、GOING 里按名调用，实参是表达式（字符串/数字/已声明变量），
  块体内用 `$参数名` 插值；块内可再调用别的块（先定义后用），但**不能**用 帧/播放/实时/draw
  ```python
  web.块 卡片(标题, 内容) {
      web.mid($标题)
      web.show($标题：$内容)
  }
  GOING:{ web.卡片("水果", "苹果 3 元")  web.卡片("蔬菜", "白菜 1 元") }STOP
  ```
- 交互：`web.textbox(占位, id)` `web.button(文字, id)` 是页面控件语句；读取用表达式
  `web.text("id")`（输入框内容）`web.down("id")`（按钮按下中）`web.click()`（画布被点）`web.mx() web.my()`
  ——**这些表达式只在网页程序（实时块/帧参数）里有效**，桌面窗口程序里没有
- 杂项：`web.audio("文件")` / `web.audio.stop()`；`web.align("center")` `web.gap(像素)`
  `web.style("css")` `web.storage("键","值")` `web.open("网址")` `web.waitsec(秒)`
- `ns.show(...)/magic(...)` 在网页程序里同样输出为段落，magic 是 HTML 标签/样式参数

## 3D（hw.*：文件头写 `ON 3D_highway`，软件光栅，自带窗口）

```python
@ 演示>3D>1
ON 3D_highway

GOING:{
hw.open(800, 500, "我的3D")      # 自管窗口和循环，不要再调 win()
hw.clearcolor(20, 24, 48)        # 天空色
hw.camera(0, 1.6, 0, 0)          # x,y,z,朝向(弧度)，俯仰可省 → 5 参
hw.box(0, 0, 5,  1, 1, 1,  200, 60, 60)   # x,y,z, 宽高深, 颜色 —— 9 参
hw.text(10, 10, 2, "得分 $分")    # 屏幕文字：x, y, 字号, 文字（字号在文字前面！）
hw.grab()                        # FPS 视角：锁鼠标（hw.free() 解锁）
hw.frame()                       # 每帧末必调（内部约 60FPS）
}STOP
```

- 输入：`hw.key("w")` `hw.hit("space")` `hw.mx() hw.my() hw.mdown()`；
  **鼠标增量** `hw.mdx() hw.mdy()`（配 hw.grab 做视角）；
  右键 `hw.rdown()`（按住=1）/ `hw.rhit()`（按下的那一帧=1）
- `hw.grab()` 锁鼠标、`hw.free()` 解锁。锁了之后光标不会跑出窗口：
  引擎每帧重申相对模式，窗口万一没焦点还会把光标按回客户区中心兜底
- **按 Esc 不会退出程序**（只把锁住的鼠标放开，因为锁了鼠标就点不到关闭按钮了）。
  退出要点窗口的 X / Alt+F4 —— 那才让 `hw.end()` 返回真，循环才结束。
  想让 Esc 干别的事，读 `hw.hit("esc")`（**键名是 `esc`**）
- **HUD 坐标 = `hw.open` 的宽高**（叫"设计尺寸"）。窗口被拉伸 / 最大化 / 高 DPI
  放大时，HUD 会整体缩放去贴窗口四边，**不用自己按比例算**。
  想拿真实尺寸用 `hw.wininfo()` → `[设计宽,设计高, 逻辑宽,逻辑高, 像素宽,像素高, 鼠标锁住了吗]`；
  程序自己改窗口用 `hw.resize(宽, 高)`；`hw.mx()/my()` 返回的也是设计坐标
- 高频坑：忘写 `ON 3D_highway` → hw.* 全部报"需要先 ON"；调了 win() 会和 hw.open 打架；
  hw.frame() 漏调 → 黑屏不刷新；
  **手持武器（第一人称视角模型）必须 `hw.near(0.06)`**，默认近裁剪面是 1.0，
  离眼睛 0.5 米的枪会被整个裁掉看不见

## 3D 模型文件（hw.obj*：把 Blender 导出的 .obj 搬进来）

```python
ON 3D_highway
GOING:{
hw.open(800, 500, "模型")            # 必须在 hw.open 之后才 hw.obj（要传贴图）
vg.船 = hw.obj("objtest/probe.obj")  # 加载 .obj（顺带读同名 .mtl）；失败返回 0
vg.信 = hw.objinfo(船)               # [顶点数, 三角数, minx,miny,minz, maxx,maxy,maxz]
vg.顶 = hw.objh(船, 3.0, 5.0)        # 竖直往下打射线 → 该点地面最高的 y（没中返回 -1e9）
vg.丢 = hw.objfix(船, 1)             # 0=不动 1=前脸转到+X 2=Z-up→Y-up 3=都做（只调一次）
hw.objdraw(船, 0, 0, 5, 1.0)         # 句柄, x,y,z, 缩放
hw.objdrawr(船, 2, 0, 5, 1.0, 0, 1.2, 0)  # 再加旋转（绕自身包围盒中心，弧度）
hw.objcolor(船, 120, 220, 160)       # 整体换色（盖掉材质色），不调就用 .mtl 的
hw.objfree(船)                       # 释放；释放后再画会报"句柄无效"
hw.frame()
}STOP
```

- 路径规则同 `hw.tex` / `m3.load`：相对**进程当前目录**（→ exe 目录），不是 .pybk 所在目录
- `hw.objh(句柄, x, z)`：竖直往下打一条射线，返回该点**地面最高的 y**，没打中返回 `-1e9`。
  在起伏地形上走路 / 站到模型顶上靠它。引擎按 XZ 切 64×64 格建了索引
  （存三角形下标，所以 `hw.objfree` 压缩顶点池也不会失效），
  4 万面的地图也能每帧问几十次。整个身子沉在地面以下是"忘了加地形高度"的典型症状
- **hw 世界里 yaw=0 的正前方是 +X**，obj 标准是 −Z 朝前 → 想让它面朝镜头写 `hw.objfix(句柄, 1)`
- 材质自带贴图优先；没贴图的材质吃 `hw.texuse` 的槽 + `hw.uv` 的平铺
- 模型是"加载一次长期驻留"，不像 `hw.box` 每帧清空；`hw.objdraw` 写在 `hw.frame()` 之前
- 上限：同驻留 64 个模型、全部合计 100 万顶点（约 33 万面）、单帧 4096 次绘制
- 解析范围：`v/vt/vn/f`（`f` 四种写法、n 边形、负索引都认）；没 `vn` 按面法线补，
  没 `vt` 按主轴投影现算 UV。`.fbx/.glb/.blend/.stl` 不是这个格式，得先导出成 .obj
- "加载完一片黑"多半是没打光 → `hw.preset(1,"lambert")` + `hw.shaderuse(1)`

## MyMove3D（m3.*：MC 风格体素建模，列表即模型）

```python
ON 3D_highway
GOING:{
m3.color("d", 160, 100, 40)          # 注册色 token（或复用 mm 调色板）
# m3.texture("g", "草.png")          # token 绑纹理（走 hw.tex 槽）
# m3.pack("材质/默认")                # 一键加载材质包（目录 pack.txt + png）
# m3.glass("n", 140, 200, 255, 0.35) # 真透明玻璃（alpha 0~1）
# m3.glow("l", 40, 230, 255)          # 夜光方块

# 模型 = 列表的列表：每个子列表 = 一个 Y 高度层（从下到上）
# 层内一行 = Z，一格 = X；. _ 空气
vg.屋 = [
  ["kkkk", "k..k", "k..k", "kkkk"],
  ["kkkk", "k.d k", "k..k", "kkkk"],   # 空格分隔 = token 模式
  ["kkkk", "kkkk", "kkkk", "kkkk"]
]
vg.n = m3.count(屋)                  # 体素数
vg.b = m3.bounds(屋)                 # [宽X, 高Y, 深Z]
vg.丢 = m3.draw(屋, 0, 0, 0, 1.0)    # 画进当前帧（一格 = scale）
vg.丢 = m3.drawr(屋, 0, 0, 0, 1.0, 0, 1.2, 0)   # 带旋转（弧度）
vg.丢 = m3.anim([帧1, 帧2], 8, 0, 0, 1.0, 6)    # 多帧轮播
vg.新 = m3.merge(屋, 附件, 2, 0, 0)  # 拼装
vg.新2 = m3.dig(新, 0, 0, 0)         # 挖方块（返回新模型）
vg.新3 = m3.put(新2, 0, 0, 0, "d")   # 放方块
vg.丢 = m3.save(屋, "名.m3d")        # 落盘
vg.读 = m3.load("名.m3d")
vg.丢 = m3.uv(2)                     # 贴图平铺
}STOP
```

- 一格 = 一个 `hw.box` 方块，MC 严丝合缝网格；尺寸上限 32³
- token 解析：`m3.texture` 槽 → `mm.色`/内置色 → `#rrggbb` / `@N`（序列化）
- **`m3.color` / `m3.texture` 必须在解析模型之前调用**
- `m3.draw` 在 `ON 3D_highway` 帧内调用；依赖 `hw.box`

## 高频坑（本规范作者的 AI 同行实际翻车记录）

- `te.join(表, " ")` 参数顺序：**表在第一**。
- **保留字别拿来做变量名**：模块前缀全是保留字 —— `mm te mt rd mu np tb mp ui hw bs js
  csv web file list tm net m3 smoke mec 音 查 调色板`。
  用 `mm = 1` 报的是 **"不是合法的语句开头：'mm'"**，完全看不出是重名。
  （`mm` = Memoryment，最容易撞。）
- 函数做语句不行 → 赋值；模块类不可见 → 平行列表模式。
- 3D：`ON 3D_highway` 在文件头；`hw.box(x,y,z, w,h,d, r,g,b)` 9 参；
  `hw.frame()` 每帧末必调；`hw.open()` 自管窗口不要再用 `win()`。
- 窗口程序编译通过≠正确：先用 `--check` 验语法，再跑窗口看行为。
- `win()` 之后的代码每帧重复执行——把只会做一次的事（清空列表、读文件）放 `win()` 之前。

## AI 踩坑速查（保留字 / 隐藏规则 / API 对照）

> 这一节是**实战翻车记录** —— 每条都是真踩过的。**先查这里再写代码**，能省好几轮试错。

### 🔴 保留字（不能做变量名 —— 报错会**指错方向**）

**全集 69 个**（来自 `pybk_front.py` 的 `KEYWORDS`，逐个核对过），分类如下：

**① 控制流（14 个）**
```
if  elif  else  while  for  in  break  断  try  catch  onerror  and  or  not
```

**② 值 / 字面量（6 个）**
```
true  false  真  假  空  none
```

**③ 声明 / 定义（8 个）**
```
func  ret  del  lock  self  import  引用  when
```

**④ 程序结构（2 个）**
```
GOING  STOP
```

**⑤ 库前缀（39 个）—— 也不能做变量名**
```
vg  vg_ro  ns  rm  list  show  input  at  net  web  js  csv  lb
te  mt  rd  file  tm  音  调色板  mm  mu  palette  Memoryment
ip  vc  window  ON  hw  np  tb  mp  ui  bs  tw  data  m3  smoke
```

**⚠ 一词多用的（既是关键字又是库前缀，最容易撞）**
```
list  show  input  at  net  window  file  mm
```

**踩坑实录**：写 `vg.查 = 查 + 1` → 报「变量声明必须以 vg. 开头」
**真相**：`查` 是保留字！报错**指错了方向**（说是声明规则问题）。
**做法**：变量名避开上面这些（`vg.查验数` 就行）。

**快速自查**：写变量名前，扫一眼这 69 个 —— 中文名（`真`/`假`/`空`/`查`/`断`/`音`/`调色板`/`引用`）
和短英文名（`at`/`lb`/`ip`/`vc`/`mm`/`mp`/`np`/`tb`/`bs`/`tw`/`mu`/`rd`）最容易撞。

### 🔴 隐藏规则（违反报错，但报错**不会告诉你规则**）

| 规则 | 报错长什么样 | 正确写法 |
|---|---|---|
| **`表[i] = 值` 只在函数参数里合法** | 「变量声明必须以 vg. 开头」| GOING 块写 `vg.表[i] =`，或**包进 func** |
| **`if(...) {...}` 后不能直接跟语句** | 「不是合法的语句开头：'STOP'」| `if` 块后空一行，或写 `}STOP` 收尾 |
| **字符串不支持转义** | `\n` 不生效（当两字符）| 换行用 **`te.chr(10)`**，回车 `te.chr(13)` |
| **函数内看不到全局** | 「变量未声明」| 函数内只能读参数 + 自己赋过的；要用就传参 |
| **`Memoryment@X` 作用域** | 模式不对报错 | 函数内要重新声明 `Memoryment@self` |

### 🟡 API 对照（中文直觉 ≠ 实际名字）

| 你想写的 ❌ | 实际是 ✅ | 说明 |
|---|---|---|
| `时间.秒()` / `时间.now()` | **`tm.now()`** | 计时（毫秒）|
| `te.字符(10)` | **`te.chr(10)`** | 按码点造字符（英文 API）|
| `smoke.查(v)` | **`smoke.check(v)`** | 1.0.5.2 起全英文 |
| `list.添加(表, x)` | **`添加(表, x)`** | 全局函数，不是 list. 方法 |

**通用规律**：**库里是英文**（`tm.*`/`te.*`/`smoke.*`/`hw.*`），**语句是中文**（`vg.`/`ns.`/`rm.`/`func`/`del`）。

### 🟢 新特性速查（1.0.5.2+）

```bash
python pybk_main.py --check 文件     # 语法+语义检查（必跑）
python pybk_main.py --version       # 版本号
python smokeroor.py                 # 安全体检（红绿灯报告）
python smokeroor.py --learn         # 自动学习期望（生成 .expect）
```

```pybk
# 安全检查（smoke.*，全英文，零成本）
vg.s = smoke.check(a)          # ["OK"] / ["DELETED"] / ["DANGLING"]
vg.t = smoke.type(a)           # INT / FLT / STR / LIST / DICT / OBJ
vg.h = smoke.heap()            # [错误, 悬垂, 根数, 模式, 字节, 单元, minor, major]
vg.丢 = smoke.expect(条件, "文案")    # 软断言（不中断，跑完看汇总）
vg.丢 = smoke.require(条件, "文案")   # 硬断言（假则立即报错）

# 字符串换行/回车（PYbook 无转义，这是唯一出口）
vg.文本 = te.join(行, te.chr(10))    # 拼多行
```

## ffi.* 底层窗口（FFI）—— 直接调 C 函数/系统 API

> **城外的门开着了**：PYbook 编译成 C，`ffi.*` 在编译期展开成真 C 调用（零包装）。
> 签名**照抄真实的 C 声明**（和 ctypes 一样）；签名写错会崩 —— 这是开窗的代价。

```pybk
# ① 调 C 标准库（签名要和真的完全一致，含 const）
ffi.声明("size_t strlen(const char*)")
GOING:{
vg.n = ffi.调用("strlen", "hello")        # → 5
}STOP

# ② 调系统 API（Win32）：ffi.包含 头文件、ffi.链接 库
ffi.包含("windows.h")
ffi.链接("user32")
ffi.声明("int GetSystemMetrics(int)")
GOING:{
vg.w = ffi.调用("GetSystemMetrics", 0)    # 屏幕宽，真调到了 Win32
}STOP

# ③ 逃生门：ffi.码 写原样 C（文件作用域，自己对自己负责）
ffi.码("int py_demo_add(int a, int b) { return a * 100 + b; }")
ffi.声明("int py_demo_add(int, int)")
GOING:{
vg.n = ffi.调用("py_demo_add", 3, 7)      # → 307
}STOP
```

**五个函数**：`ffi.包含("头文件")` / `ffi.链接("库名")` / `ffi.声明("签名")` / `ffi.码("原样C")` / `ffi.调用("名", 参数...)`

**类型转换**（PYbook 值 ↔ C）：
| C 类型 | PYbook 侧 |
|---|---|
| int/long/size_t... | 整数（文本能解析也收）|
| double/float | 整数或小数 |
| char*/const char* | 文本（空值 → NULL）|
| void*/指针 | 整数地址 / 文本 / 空 |
| 返回 char* | 文本（拷贝；NULL → 空）|
| 返回指针 | 整数地址 |

**规则**：
- `ffi.声明` / `ffi.调用` 的函数名**必须是字面量**（编译期要知道调谁）
- 签名格式：`返回类型 函数名(参数类型, ...)`，参数名可省
- 同一函数只准声明一次（两种签名会报错）
- **不支持**：函数指针参数、结构体传值、变参（用 `ffi.码` 手写包装）
- `ffi.*` 可以放文件头（顶层）或 GOING 里 —— 都是编译期生效，运行期零开销

## 报错怎么读（三段式：错了什么 + 为什么 + 怎么改）

**报错现在自带三段式**（1.0.5.3 起）—— 拿到报错**先读完三行**，多数当场知道怎么改：

```
第 3 行：期望 'NAME'，实际是 '查'
  为什么：`查` 是保留字（69 个之一），不能当变量名/函数名
  怎么改：换个名字，比如 vg.查数；完整保留字表见 PYBOOK_AI.md
```

**读法**：
1. **行号**：定位到那行（一次修一处）
2. **为什么**：告诉你踩了什么规则
3. **怎么改**：照做就行

**如果报错没有后两段**（还没收录的文案）→ 查上面「AI 踩坑速查」的隐藏规则表，
大概率是那几条；再没有就是真 bug，把报错原样贴出来。

**已内建提示的错误**：保留字撞名、未声明、方法调用定不了类、if 块后跟语句、
非法字符（转义）、找不到文件、没有这个 API、嵌套太深、参数个数不对、
del 后访问、下标越界、除零、溢出、字典缺键、变量锁定、类型不配、内存不足……

## 错误处理（P5：try/catch、onerror、安全访问器）

```
try {                       # 抓运行时错误（含"第 N 行"完整消息）
    vg.分 = 存档["最高"]
} catch e {                 # e 是错误文本字符串；也可省 e：catch { ... }
    分 = 0
    ns.show("读档失败", e)
}
```

```
onerror err {               # 放 GOING 任意位置，自动兜底其后全部语句
    ns.show("出错了但不白屏", err)     # 未捕获错误 → 跳这里，游戏不死
    vg.完 = 1
}
```

```
vg.分 = 存档.get("最高", 0)     # 字典：键没有 → 默认值（不炸）
vg.值 = 表.at(i, 0)             # 列表/字符串：越界 → 默认值（不炸）；.at 的缺省可省略
```

规则：catch/onerror 里可以再 try（嵌套安全）；catch 处理完新错误照常可捕获；
`$() 里不能写字符串字面量` 同样适用于 catch 的 e（先落变量再插值）。
防御性写法优先用 .get/.at——不炸的代码比抓异常的代码更好。

## AI 工作循环（推荐）

1. 写/改 `.pybk`（**先查「AI 踩坑速查」** —— 保留字/隐藏规则/API 对照）
2. `python pybk_main.py --check 文件` —— 通过才进行下一步（失败信息含行号+规则+改法）
3. 需要看行为才真跑窗口；改完即停，别留僵尸进程
4. 运行时报错格式 `运行时错误(第 N 行): 信息` —— **先查「AI 踩坑速查」再改代码**（大概率是隐藏规则）
5. 改了 `pybook_rt.c` / `pybk_code.py` 等运行时 → **跑 `python smokeroor.py`**（红绿灯报告，7 个冒烟用例）
6. 想自测就用 `smoke.expect(条件, "文案")` 写断言（软，不中断）或 `smoke.require`（硬，立即报错）

**验证顺序**：`--check` → 跑程序 → Smokeroor（改运行时才需要）→ 写断言（可选）
