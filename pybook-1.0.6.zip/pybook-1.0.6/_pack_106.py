# -*- coding: utf-8 -*-
"""打 PYbook 1.0.6 发布包。

在 1.0.5.2 的基础上：随包内置工具链 LookAround（tools/pybktl/）。
排除项沿用 1.0.5.2（已剔除 app_*.exe / 发布打包_102 / _stdlib_v2 / 各种探针残留）。

包里**不含 gcc**（只自带 SDL2），gcc 需系统 PATH 上有。
"""
import os
import sys
import zipfile
import fnmatch

SRC = r'C:\Users\zhuli\Desktop\pybook'
DST = r'C:\Users\zhuli\Desktop\pybook官网\pybook-1.0.6.zip'
TOP = 'pybook-1.0.6'

SKIP_DIRS = {'.git', '__pycache__', 'rt_cache', 'exe_cache', 'node_modules',
             '.trae-html-share-packages', '发布打包_102',
             '_stdlib_v2'}
SKIP_FILES = [
    'app_*.exe',
    '_*.exe',               # 探针产物：_uishot.exe / _shot.exe
    '_run_ui_demo',
    '_run_ui_sm',
    'pybook-*.zip',
    'out_*.c',
    '*.o',
    '_glsl_smoke_report.txt',
    '_ortho_smoke_report.txt',
    'smokeroor_errors.json',   # 错误指纹库：本地状态，不随包分发
    'smokeroor_baseline.txt',  # 基线：同上
    'libgcc_*.dll',            # MinGW 运行时 DLL：1.0.5 包里没有（exe 用静态链接），别带
    'libwinpthread-*.dll',
    'libstdc++-*.dll',
    '.DS_Store',
    'Thumbs.db',
    'E3旋律.wav',
    'ItBoTime_旋律.wav',
    'ItBoTime_贝斯.wav',
]


def skip(name):
    return any(fnmatch.fnmatch(name, p) for p in SKIP_FILES)


kept = skipped_n = 0
skipped_bytes = 0

if os.path.exists(DST):
    os.remove(DST)

with zipfile.ZipFile(DST, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for root, dirs, files in os.walk(SRC):
        dirs[:] = [d for d in dirs if d not in SKIP_DIRS]
        for f in files:
            full = os.path.join(root, f)
            rel = os.path.relpath(full, SRC).replace('\\', '/')
            if skip(f):
                skipped_n += 1
                try:
                    skipped_bytes += os.path.getsize(full)
                except OSError:
                    pass
                continue
            z.write(full, TOP + '/' + rel)
            kept += 1

mb = os.path.getsize(DST) / 1024 / 1024
print('打进包的文件   : %d' % kept)
print('剔除的文件     : %d（%.1f MB）' % (skipped_n, skipped_bytes / 1024 / 1024))
print('pybook-1.0.6.zip: %.1f MB' % mb)

if mb > 95:
    sys.stderr.write('\n** 超过 95MB，GitHub push 会失败！需要再剔除东西。**\n')
    sys.exit(1)

# ---------- 验收：关键文件必须在，且本版新东西真在包里 ----------
MUST = [
    'pybk_front.py', 'pybk_code.py', 'pybk_bc.py', 'pybk_main.py', 'pybk_build.py',
    'pybook_rt.c', 'pybook_lib.h', 'pybook_json.c',
    'pybook_ui.c', 'pybook_hw3d.c',
    'pybook_smoke.c', 'pybook_smoke.h',      # 1.0.5.2 新增：Smokeroor 安全检查
    'smokeroor.py',                          # 1.0.5.2 新增：无头体检 runner
    'CHANGELOG.md', 'PYBOOK_AI.md', 'PYbookIDE.exe',
    'SDL2.dll', 'ucrt64/include/SDL2/SDL.h',
    '3D演示.pybk', '示例_GUI表单.pybk',
    'tests/smoke/smoke_01_overflow.pybk',    # 1.0.5.2 新增：冒烟用例
    'mm_tests/mm09_self_dangling.pybk',      # 1.0.5.2 新增：悬垂指针回归锁
    # 本版新增：工具链 LookAround（随包内置、可移植、零硬编码路径）
    'tools/pybktl/pybktl.py',
    'tools/pybktl/lookaround.py',
    'tools/pybktl/LOOKAROUND.md',
    'tools/pybktl/lookaround.cmd',
]
z = zipfile.ZipFile(DST)
names = set(z.namelist())
missing = [m for m in MUST if (TOP + '/' + m) not in names]
print('\n关键文件检查：', '全在 ✓' if not missing else '**缺 %s**' % missing)

checks = [
    # Memoryment @5/@6 三处修复
    ('pybook_rt.c', b'cell_drop(RtCell *c, int drop_children)', 'P0 cell_drop 分流'),
    ('pybook_rt.c', b'gc_insert_barrier', 'P2 增量写屏障'),
    ('pybook_rt.c', b'g_major_threshold', 'P1 major 触发阈值'),
    ('pybook_rt.c', b'g_err_count', '错误计数器'),
    # Smokeroor：安全体检
    ('pybook_smoke.c', b'rt_smoke_check', 'smoke.check 实现'),
    ('pybook_smoke.c', b'rt_smoke_expect', 'smoke.expect 软断言'),
    ('smokeroor.py', 'fingerprint', '错误指纹库'),
    ('smokeroor.py', '--learn', '期望自动学习'),
    ('pybk_front.py', "'smoke.check': 1", '前端注册 smoke.check'),
    ('pybk_code.py', "'smoke.check': 'rt_smoke_check'", 'C 后端映射 smoke.check'),
    # 编译缓存
    ('pybk_code.py', 'EXE_CACHE_DIR', 'exe 级编译缓存'),
    ('pybk_code.py', '_src_fingerprint', '缓存指纹'),
    # te.chr：字符串换行/回车出口
    ('pybook_lib.c', b'rt_lib_te_chr', 'te.chr 实现'),
    # 本版新增：工具链 LookAround
    ('tools/pybktl/pybktl.py', 'import lookaround', 'pybktl 嫁接 lookaround'),
    ('tools/pybktl/pybktl.py', 'def cmd_lookaround', 'lookaround 子命令'),
    ('tools/pybktl/pybktl.py', 'def cmd_todo', 'todo 子命令'),
    ('tools/pybktl/lookaround.py', 'def start_watcher', 'LookAround 监控器'),
    ('tools/pybktl/lookaround.py', 'def build_report', '团队协作报告'),
    ('tools/pybktl/lookaround.py', 'def _translate_msg', '报错翻中文'),
    # 版本与台账
    ('pybk_main.py', "PYBOOK_VERSION = '1.0.6'", '版本常量'),
    ('CHANGELOG.md', '1.0.6', 'CHANGELOG 1.0.6'),
]
bad = []
for path, needle, label in checks:
    data = z.read(TOP + '/' + path)
    nd = needle.encode('utf-8') if isinstance(needle, str) else needle
    if nd not in data:
        bad.append(label)
print('包内新特性检查：', '全部命中 ✓' if not bad else '**没命中: %s**' % bad)

# 确认没把 gcc/mingw 打进去（官网文案写"自带 gcc"是错的，包里确认没有）
gh = [n for n in names if 'gcc' in n.lower() or 'mingw' in n.lower()]
print('包内 gcc/mingw 命中数：%d %s' % (len(gh), '（符合预期：不含 gcc）' if not gh else gh[:5]))

print('\n结论：', '打包成功' if (not missing and not bad and mb <= 95 and not gh) else '**有问题**')
