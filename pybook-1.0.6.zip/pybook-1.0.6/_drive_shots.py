# -*- coding: utf-8 -*-
"""一次性驱动：生成测试副本 -> --check -> 带截图跑。
用法：python _drive_shots.py <阶段>
  gen    只生成 + check
  shot   跑所有副本并抓帧
"""
import os
import subprocess
import sys

PY = r'C:\Users\zhuli\.workbuddy\binaries\python\versions\3.13.12\python.exe'
CWD = os.path.dirname(os.path.abspath(__file__))

COPIES = [
    ('_t_idle.pybk',  ['idle']),
    ('_t_walk.pybk',  ['walk']),
    ('_t_ads.pybk',   ['idle', 'ads', 'w1']),
    ('_t_ads0.pybk',  ['idle', 'ads', 'w0']),
    ('_t_ads2.pybk',  ['idle', 'ads', 'w2']),
    ('_t_sk.pybk',    ['idle', 'skill']),
    ('_t_hot.pybk',   ['idle', 'fire', 'hot']),
    ('_t_gun0.pybk',  ['idle', 'w0']),
    ('_t_gun2.pybk',  ['idle', 'fire', 'w2']),
    ('_t_snipe.pybk', ['idle', 'ads', 'w3']),
    ('_t_tp.pybk',    ['tp']),
    ('_t_big.pybk',   ['idle', 'big']),
    ('_t_tall.pybk',  ['idle', 'tall']),
    ('_t_rz.pybk',    ['idle', 'resize']),
]


def pick(args):
    """命令行里给了标签就只做那几个（比如 gen big tall）。"""
    tags = [a for a in args if a not in ('gen', 'shot', 'all')]
    if not tags:
        return COPIES
    out = [c for c in COPIES if any(t in c[0] for t in tags)]
    if not out:
        sys.stderr.write('没有匹配的副本: %s\n' % tags)
        sys.exit(1)
    return out


def run(args, env=None, timeout=150):
    e = dict(os.environ)
    if env:
        e.update(env)
    p = subprocess.run([PY] + args, cwd=CWD, env=e,
                       stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=timeout)
    return p.returncode, p.stdout.decode('utf-8', 'replace')


def main():
    stage = sys.argv[1] if len(sys.argv) > 1 else 'gen'
    todo = pick(sys.argv[2:])

    if stage in ('gen', 'all'):
        for out, flags in todo:
            rc, o = run(['_mkharness.py', out] + flags)
            print('== mk %s rc=%d' % (out, rc))
            print(o.rstrip())
            if rc != 0:
                return 1
        for out, _ in todo:
            rc, o = run(['pybk_main.py', '--check', out])
            print('== check %s rc=%d  %s' % (out, rc, o.strip()[:120]))
            if rc != 0:
                return 1
        print('全绿')

    if stage in ('shot', 'all'):
        for out, flags in todo:
            tag = out.replace('_t_', '').replace('.pybk', '')
            d = os.path.join(CWD, '_shots_' + tag)
            rc, o = run(['pybk_main.py', out], env={
                'PYBOOK_SHOT_DIR': d,
                'PYBOOK_SHOT_EVERY': '40',
                'PYBOOK_SHOT_MAX': '8',
            })
            print('== run %s rc=%d  %s' % (out, rc, o.strip()[-200:]))
            if os.path.isdir(d):
                print('   frames: ' + ', '.join(sorted(os.listdir(d))))
            else:
                print('   (没生成 ' + d + ')')

    return 0


sys.exit(main())
