# -*- coding: utf-8 -*-
"""粒子级参数：把 重力/阻力/速度 从「函数参数」下沉成「粒子自己的字段」。
新增 fancyX_evolve(池) 按各粒子自己的参数演化；fancyX_update(...) 保留为池级参数版
（先把参数写进各粒子，再调 evolve），因此老调用行为逐位不变。
"""
import io, sys


def splice_tail(s, anchor, new_tail):
    """从 anchor 起，替换到「该函数结尾的顶格 }」为止。"""
    if s.count(anchor) != 1:
        sys.stderr.write('FAIL anchor count=%d: %s\n' % (s.count(anchor), anchor[:40]))
        sys.exit(1)
    i = s.index(anchor)
    j = s.index('\n}\n', i) + len('\n}\n')
    return s[:i] + new_tail + s[j:]


def run(path, head_old, head_new, field_old, field_new, anchor, new_tail):
    s = io.open(path, encoding='utf-8').read()
    for label, old, new in (('头部注释', head_old, head_new),
                            ('粒子字段', field_old, field_new)):
        if s.count(old) != 1:
            sys.stderr.write('FAIL [%s] %s count=%d\n' % (path, label, s.count(old)))
            sys.exit(1)
        s = s.replace(old, new, 1)
    s = splice_tail(s, anchor, new_tail)
    io.open(path, 'w', encoding='utf-8', newline='').write(s)
    print('ok  %s  %d lines' % (path, s.count('\n') + 1))


# ============================== fancy3d ==============================

H3D_OLD = '''#
# 想连演化都自己写？改完 p.x/p.vy/… 后只借它的绘制：'''

H3D_NEW = '''#
# 一池多种物理（粒子级参数）：重力/阻力/速度也是粒子自己的字段，可以逐个设：
#   vg.p = fancy3d_get(池)   p.重力 = 0.0   p.阻力 = 0.99   p.速度 = 2.0
#   vg.丢 = fancy3d_evolve(池)      一次演化全池，各粒子按各自的参数走
#
# 想连演化都自己写？改完 p.x/p.vy/… 后只借它的绘制：'''

F3D_OLD = '''    vg.r = 255
    vg.g = 255
    vg.b = 255
}'''

F3D_NEW = '''    vg.r = 255
    vg.g = 255
    vg.b = 255
    vg.重力 = 0.02
    vg.阻力 = 1.0
    vg.速度 = 1.0
}'''

A3D = '''# 演化 + 绘制。三个参数全部可选，默认值 = 1.0 之前写死的那套行为。
#   重力  每帧竖直下落加速度   0.0 = 无重力漂浮 / 0.02 = 默认 / 0.08 = 重落
#   阻力  每帧速度乘数         1.0 = 无阻力（直线匀速）/ 0.98 = 有空气阻力
#   速度  整体速度倍率         1.0 = 原速 / 2.0 = 双倍速
func fancy3d_update(池, 重力 = 0.02, 阻力 = 1.0, 速度 = 1.0) {'''

T3D = '''# 按「每个粒子自己的」重力/阻力/速度演化 —— 三个字段定义在 lb.粒子 里，逐个粒子设。
# 这就是「一个池里跑多种物理」的入口：不同粒子设不同重力，一次 evolve 全搞定。
func fancy3d_evolve(池) {
    for p in 池 {
        if(p.活) {
            p.x = p.x + p.vx * p.速度
            p.y = p.y + p.vy * p.速度
            p.z = p.z + p.vz * p.速度
            p.vy = p.vy - p.重力
            p.vx = p.vx * p.阻力
            p.vy = p.vy * p.阻力
            p.vz = p.vz * p.阻力
            p.生命 = p.生命 - 1
            if(p.生命 <= 0) {
                p.活 = 0
            } else {
                vg.比例 = p.生命 / p.最大
                hw.sphere(p.x, p.y, p.z, p.大小, p.r * 比例, p.g * 比例, p.b * 比例)
            }
        }
    }
    ret 0
}

# 池级参数版：先把这套参数写进每个活粒子，再统一演化。
# 整池只有一种物理时用它最省事；要一池多种物理就改用 fancy3d_evolve。
#   重力  每帧竖直下落加速度   0.0 = 无重力漂浮 / 0.02 = 默认 / 0.08 = 重落
#   阻力  每帧速度乘数         1.0 = 无阻力（直线匀速）/ 0.98 = 有空气阻力
#   速度  整体速度倍率         1.0 = 原速 / 2.0 = 双倍速
func fancy3d_update(池, 重力 = 0.02, 阻力 = 1.0, 速度 = 1.0) {
    for p in 池 {
        if(p.活) {
            p.重力 = 重力
            p.阻力 = 阻力
            p.速度 = 速度
        }
    }
    vg.丢 = fancy3d_evolve(池)
    ret 0
}
'''

for p in (r'C:\Users\zhuli\Desktop\pybook\_stdlib_v2\fancy3d.pybk',
          r'C:\Users\zhuli\Desktop\pybook\星核特效\fancy3d.pybk'):
    run(p, H3D_OLD, H3D_NEW, F3D_OLD, F3D_NEW, A3D, T3D)

# ============================== fancy2d ==============================

H2D_OLD = '''#
# 想连演化都自己写？改完 p.x/p.vy/… 后只借它的绘制：'''

H2D_NEW = '''#
# 一池多种物理（粒子级参数）：重力/阻力/速度也是粒子自己的字段，可以逐个设：
#   vg.p = fancy2d_get(池)   p.重力 = 0.0   p.阻力 = 0.99   p.速度 = 2.0
#   vg.丢 = fancy2d_evolve(池)      一次演化全池，各粒子按各自的参数走
#
# 想连演化都自己写？改完 p.x/p.vy/… 后只借它的绘制：'''

F2D_OLD = F3D_OLD
F2D_NEW = '''    vg.r = 255
    vg.g = 255
    vg.b = 255
    vg.重力 = 0.15
    vg.阻力 = 1.0
    vg.速度 = 1.0
}'''

A2D = '''# 演化 + 绘制。三个参数全部可选，默认值 = 1.0 之前写死的那套行为。
#   重力  每帧下落加速度   0.15 = 默认（屏幕 y 向下为正）/ 0.0 = 无重力 / 负值 = 上飘
#   阻力  每帧速度乘数     1.0 = 无阻力（直线匀速）/ 0.98 = 有空气阻力
#   速度  整体速度倍率     1.0 = 原速 / 2.0 = 双倍速
func fancy2d_update(池, 重力 = 0.15, 阻力 = 1.0, 速度 = 1.0) {'''

T2D = '''# 按「每个粒子自己的」重力/阻力/速度演化 —— 三个字段定义在 lb.粒子 里，逐个粒子设。
# 这就是「一个池里跑多种物理」的入口：不同粒子设不同重力，一次 evolve 全搞定。
# 注意 2D 是屏幕坐标、y 向下为正：下落用正重力，上飘用负重力。
func fancy2d_evolve(池) {
    for p in 池 {
        if(p.活) {
            p.x = p.x + p.vx * p.速度
            p.y = p.y + p.vy * p.速度
            p.vy = p.vy + p.重力
            p.vx = p.vx * p.阻力
            p.vy = p.vy * p.阻力
            p.生命 = p.生命 - 1
            if(p.生命 <= 0) {
                p.活 = 0
            } else {
                vg.比例 = p.生命 / p.最大
                vg.s = p.大小 * 比例
                color(p.r * 比例, p.g * 比例, p.b * 比例)
                圆(p.x, p.y, s)
            }
        }
    }
    ret 0
}

# 池级参数版：先把这套参数写进每个活粒子，再统一演化。
# 整池只有一种物理时用它最省事；要一池多种物理就改用 fancy2d_evolve。
#   重力  每帧下落加速度   0.15 = 默认（屏幕 y 向下为正）/ 0.0 = 无重力 / 负值 = 上飘
#   阻力  每帧速度乘数     1.0 = 无阻力（直线匀速）/ 0.98 = 有空气阻力
#   速度  整体速度倍率     1.0 = 原速 / 2.0 = 双倍速
func fancy2d_update(池, 重力 = 0.15, 阻力 = 1.0, 速度 = 1.0) {
    for p in 池 {
        if(p.活) {
            p.重力 = 重力
            p.阻力 = 阻力
            p.速度 = 速度
        }
    }
    vg.丢 = fancy2d_evolve(池)
    ret 0
}
'''

for p in (r'C:\Users\zhuli\Desktop\pybook\_stdlib_v2\fancy2d.pybk',
          r'C:\Users\zhuli\Desktop\pybook\星核特效\fancy2d.pybk'):
    run(p, H2D_OLD, H2D_NEW, F2D_OLD, F2D_NEW, A2D, T2D)
