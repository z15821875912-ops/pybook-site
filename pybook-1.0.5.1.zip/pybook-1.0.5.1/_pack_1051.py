# -*- coding: utf-8 -*-
"""打 PYbook 1.0.5.1（1.0.5 修正版）发布包。

策略沿用 _pack_105.py，按本版新增调整排除项与验收项：
  · 新增排除 `_glsl方案_已弃用/`（用户否决的自写 GLSL 方案，只留在仓库里归档）
  · 新增排除随库走的数值验收探针：`_探针_*.pybk` / `_probe_*.pybk` / `_星核_冒烟.pybk`
  · 本版新增的 `星核特效/` 目录（自包含示例）自然进包

必须继续剔除的老大头（不剔会 >200MB，GitHub push 直接拒）：
  · app_*.exe  350+ 个 —— pybk_code.py 每次编译残留
  · 发布打包_102 —— 1.0.2 留下的整套 mingw64（~400MB）
  · 旧发布包 zip / __pycache__ / out_*.c / rt_cache/*.o
包里**不含 gcc**（只自带 SDL2），gcc 需系统 PATH 上有。
"""
import os
import sys
import zipfile
import fnmatch

SRC = r'C:\Users\zhuli\Desktop\pybook'
DST = r'C:\Users\zhuli\Desktop\pybook官网\pybook-1.0.5.1.zip'
TOP = 'pybook-1.0.5.1'

SKIP_DIRS = {'.git', '__pycache__', 'rt_cache', 'node_modules',
             '.trae-html-share-packages', '发布打包_102',
             '_stdlib_v2',
             '_glsl方案_已弃用'}          # 本版新增
SKIP_FILES = [
    'app_*.exe',
    '_*.exe',               # 探针产物：_uishot.exe / _shot.exe
    '_run_ui_demo',
    '_run_ui_sm',
    'pybook-*.zip',
    'out_*.c',
    '*.o',
    '_glsl_smoke_report.txt',
    '_ortho_smoke_report.txt',
    '.DS_Store',
    'Thumbs.db',
    'E3旋律.wav',
    'ItBoTime_旋律.wav',
    'ItBoTime_贝斯.wav',
    '_探针_*.pybk',          # 本版新增：随库走的数值验收探针
    '_probe_*',
    '_星核_冒烟.pybk',
    '_星核_冒烟报告.txt',
    '星核特效_报告.txt',
]


def skip(name):
    return any(fnmatch.fnmatch(name, p) for p in SKIP_FILES)


kept = skipped_n = 0
skipped_bytes = 0

if os.path.exists(DST):
    os.remove(DST)

with zipfile.ZipFile(DST, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for root, dirs, files in os.walk(SRC):
        dirs[:] = [d for d in dirs if d not in SKIP_DIRS]
        for f in files:
            full = os.path.join(root, f)
            rel = os.path.relpath(full, SRC).replace('\\', '/')
            if skip(f):
                skipped_n += 1
                try:
                    skipped_bytes += os.path.getsize(full)
                except OSError:
                    pass
                continue
            z.write(full, TOP + '/' + rel)
            kept += 1

mb = os.path.getsize(DST) / 1024 / 1024
print('打进包的文件   : %d' % kept)
print('剔除的文件     : %d（%.1f MB）' % (skipped_n, skipped_bytes / 1024 / 1024))
print('pybook-1.0.5.1.zip: %.1f MB' % mb)

if mb > 95:
    sys.stderr.write('\n** 超过 95MB，GitHub push 会失败！需要再剔除东西。**\n')
    sys.exit(1)

# ---------- 验收：关键文件必须在，且本版新东西真在包里 ----------
MUST = [
    'pybk_front.py', 'pybk_code.py', 'pybk_bc.py', 'pybk_main.py', 'pybk_build.py',
    'pybook_rt.c', 'pybook_lib.h', 'pybook_json.c',
    'pybook_ui.c', 'pybook_hw3d.c',
    'CHANGELOG.md', 'PYBOOK_AI.md', 'PYbookIDE.exe',
    'SDL2.dll', 'ucrt64/include/SDL2/SDL.h',
    '3D演示.pybk', '示例_GUI表单.pybk',
    # 本版新增：自包含的星核特效示例
    '星核特效/星核特效.pybk', '星核特效/fancy3d.pybk', '星核特效/fancy2d.pybk',
    '星核特效.cmd',
]
z = zipfile.ZipFile(DST)
names = set(z.namelist())
missing = [m for m in MUST if (TOP + '/' + m) not in names]
print('\n关键文件检查：', '全在 ✓' if not missing else '**缺 %s**' % missing)

checks = [
    # 本版主菜：粒子库力学参数化
    ('星核特效/fancy3d.pybk', 'func fancy3d_evolve', '3D 粒子级 evolve'),
    ('星核特效/fancy3d.pybk', 'vg.重力 = 0.02', '3D 粒子自有重力字段'),
    ('星核特效/fancy3d.pybk', 'func fancy3d_draw', '只画不演化 draw'),
    ('星核特效/fancy2d.pybk', 'func fancy2d_evolve', '2D 粒子级 evolve'),
    ('星核特效/fancy2d.pybk', 'vg.重力 = 0.15', '2D 粒子自有重力字段'),
    # 引擎修复：LIB_C_NAMES 补表
    ('pybk_code.py', "'hw.near': 'rt_hw_near'", 'hw.near 补映射'),
    ('pybk_code.py', "'mt.lerp': 'rt_lib_mp_lerp'", 'mt.lerp 补映射'),
    ('pybk_code.py', "'mu.sine': 'rt_mu_sine'", 'mu.sine 补映射'),
    # 引擎新能力：无头出图
    ('pybook_hw3d.c', 'PYBOOK_SHOT_DIR', '无头出图开关'),
    # 新示例
    ('星核特效/星核特效.pybk', '画笼', '星核特效程序本体'),
    ('星核特效.cmd', 'pybk_main.py', '双击启动器'),
    # 台账
    ('CHANGELOG.md', '1.0.5.1', 'CHANGELOG 1.0.5.1'),
]
bad = []
for path, needle, label in checks:
    data = z.read(TOP + '/' + path)
    nd = needle.encode('utf-8') if isinstance(needle, str) else needle
    if nd not in data:
        bad.append(label)
print('包内新特性检查：', '全部命中 ✓' if not bad else '**没命中: %s**' % bad)

# 确认没把 gcc/mingw 打进去（官网文案写"自带 gcc"是错的，包里确认没有）
gh = [n for n in names if 'gcc' in n.lower() or 'mingw' in n.lower()]
print('包内 gcc/mingw 命中数：%d %s' % (len(gh), '（符合预期：不含 gcc）' if not gh else gh[:5]))

# 确认探针没混进去
probes = [n for n in names if '探针' in n or '_probe_' in n or '_冒烟' in n]
print('包内探针命中数：%d %s' % (len(probes), '（符合预期：不含探针）' if not probes else probes[:5]))

print('\n结论：', '打包成功' if (not missing and not bad and mb <= 95 and not gh and not probes) else '**有问题**')
