# -*- coding: utf-8 -*-
"""把源仓库 CHANGELOG 的「## 未发布」节整理成正式版本节 1.0.5.1。
补上本次修正版另外三样内容（LIB_C_NAMES 补表 / 无头出图开关 / 星核特效）。
"""
import io, sys

P = r'C:\Users\zhuli\Desktop\pybook\CHANGELOG.md'
s = io.open(P, encoding='utf-8').read()


def sub(old, new, label):
    global s
    n = s.count(old)
    if n != 1:
        sys.stderr.write('FAIL [%s] count=%d\n' % (label, n))
        sys.exit(1)
    s = s.replace(old, new, 1)
    print('ok  ' + label)


# ---- 1. 版本节标题 ----
sub('## 未发布\n',
    '## 1.0.5.1 —— 1.0.5 修正版：粒子库可调 + 星核特效（2026-09-27）\n',
    '版本节标题')

# ---- 2. 主菜标题去掉日期、标注主菜 ----
sub('### 粒子库力学参数化：`fancy3d` / `fancy2d` —— 参数可调，且能一池多种物理（2026-09-27）',
    '### 粒子库力学参数化：`fancy3d` / `fancy2d`（本版主菜）',
    '主菜标题')

# ---- 3. 节末尾补三个小节 ----
ANCHOR = '行数：`fancy3d.pybk` 118 → 140，`fancy2d.pybk` 116 → 139。\n'

EXTRA = '''
### 引擎修复：`hw.fov` / `hw.near` / `mt.clamp` / `mt.lerp` / `mu.*` 补上 C 名映射

1.0.5 里一个**极难定位的编译崩溃**：这些名字在参数个数表（`pybk_front.LIB_CALLS`）里有，
但 C 名映射表（`pybk_code.LIB_C_NAMES`）里漏了。于是写 `hw.near(0.1)` 不是报
「没这个 API」，而是 Python 层直接抛 `KeyError: 'hw.near'` —— **编译器自己崩了**，
报错信息跟 PYbook 代码毫无关系。

补了 12 条，共三组：

| 组 | 补的名字 | 映射到 |
|---|---|---|
| 相机 | `hw.fov` `hw.near` | `rt_hw_fov` `rt_hw_near` |
| 数学 | `mt.clamp` `mt.lerp` | `rt_lib_mp_clamp` `rt_lib_mp_lerp` |
| 音乐 | `mu.sine` `mu.tri` `mu.quick` `mu.play` `mu.stop` `mu.note` `mu.away` `mu.play_list` | `rt_mu_*` |

运行时函数（`rt_hw_fov` 等）一直都在，**纯粹是表漏**。另写了个探针脚本，能一键列出
「arity 表有 / C 名表没有」的全部名字，扣掉 `tm.stop`、`ui.按钮/输入框/滑条`
（这三个是 codegen 特判转写、本来就不需要映射）后应为空。

### 引擎新能力：无头出图开关（`hw` 程序终于能自动截图）

3D 程序以前只有真窗口能看画面，自动化验收只能靠「跑完没崩」猜，改画面全靠盲改。
现在加了个**环境变量驱动的出图开关**（不设就零开销）：

```bash
PYBOOK_SHOT_DIR=shots PYBOOK_SHOT_EVERY=17 PYBOOK_SHOT_MAX=7 python pybk_main.py 程序.pybk
```

| 变量 | 作用 | 默认 |
|---|---|---|
| `PYBOOK_SHOT_DIR` | **设了才开**，出图目录 | 不设 = 关闭 |
| `PYBOOK_SHOT_EVERY` | 每几帧出一张 | 20 |
| `PYBOOK_SHOT_MAX` | 最多出几张 | 8 |

实现在 `SDL_GL_SwapWindow` **之前** `glReadPixels(GL_BACK)` 读回，自写 24 位 BMP
（GL 给的是 R,G,B，BMP 要 B,G,R，逐像素交换）；视口尺寸用 `glGetIntegerv(GL_VIEWPORT)` 取，
不用 SDL 窗口尺寸 —— DPI 缩放时两者不一致。

### 新示例：星核特效（纯 `fancy3d` + pybk，零着色器）

`星核特效/星核特效.pybk`（382 行）—— 双击 `星核特效.cmd` 直接出窗口。

- **零 GLSL、零贴图、零第三方依赖**：粒子用标准库 `fancy3d`，几何用 `hw.box` 一块块拼，
  运动学是 pybk 自己积分出来的。
- 画面构成：24×24 砖块的**波动高度场地面**、三道各 72 段的**自转能量环**、
  三层互相垂直的**力场笼**、周期性**冲击波**与光柱，外加四组粒子池（火/涡/爆/尘）。
- 键位：空格暂停 · P 手动爆一发 · W 线框 · H 信息 · ESC 退出。
- 目录自包含：`fancy3d.pybk` / `fancy2d.pybk` 副本随程序一起放（`引用()` 只找**同目录**的模块）。
'''

sub(ANCHOR, ANCHOR + EXTRA, '追加三小节')

io.open(P, 'w', encoding='utf-8', newline='').write(s)
print('\n写入完成，共 %d 行' % (s.count('\n') + 1))
print('版本节顺序：', [l for l in s.split('\n') if l.startswith('## ')][:4])
