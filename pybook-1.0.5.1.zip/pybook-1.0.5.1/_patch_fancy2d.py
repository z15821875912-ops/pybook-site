# -*- coding: utf-8 -*-
"""给 fancy2d 做与 fancy3d 同样的力学参数化（幂等补丁）。
默认值 == 旧行为逐位一致，老调用零改动。
"""
import io, sys

FILES = [
    r'C:\Users\zhuli\Desktop\pybook\_stdlib_v2\fancy2d.pybk',
    r'C:\Users\zhuli\Desktop\pybook\星核特效\fancy2d.pybk',
]

OLD_HEAD = '''# fancy2d = 2D 粒子特效
#   引用("fancy2d")
#   vg.粒子 = []
#   fancy2d_init(粒子, 200)
#   fancy2d_burst(粒子, 100, 200, 20, 255,150,50)
#   fancy2d_update(粒子)
'''

NEW_HEAD = '''# fancy2d = 2D 粒子特效
#   引用("fancy2d")
#   vg.粒子 = []
#   fancy2d_init(粒子, 200)
#   fancy2d_burst(粒子, 100, 200, 20, 255,150,50)
#   fancy2d_update(粒子)
#
# 力学参数都可自己决定（都有默认值，老写法 fancy2d_update(粒子) 行为不变）：
#   fancy2d_update(池)                  重力 0.15 / 无阻力 / 原速（老行为）
#   fancy2d_update(池, 0.0)             零重力 —— 粒子直线匀速飘出去
#   fancy2d_update(池, -0.05)           反重力 —— 像烟一样往上飘
#   fancy2d_update(池, 0.15, 0.98)      下落 + 每帧 2% 空气阻力
#   fancy2d_update(池, 0.0, 0.99, 2.0)  双倍速 + 慢慢减速
#   fancy2d_burst(池, x,y, 数量, r,g,b, 2.0)     初速翻倍（炸得更开）
#
# 想连演化都自己写？改完 p.x/p.vy/… 后只借它的绘制：
#   vg.丢 = fancy2d_draw(池)
'''

OLD_BURST_SIG = 'func fancy2d_burst(池, x, y, 数量, r, g, b) {'
NEW_BURST_SIG = 'func fancy2d_burst(池, x, y, 数量, r, g, b, 初速 = 1.0) {'

OLD_SPD = '            vg.spd = mp.rand_u01() * 4.0 + 1.0'
NEW_SPD = '            vg.spd = (mp.rand_u01() * 4.0 + 1.0) * 初速'

OLD_UPDATE = '''func fancy2d_update(池) {
    for p in 池 {
        if(p.活) {
            p.x = p.x + p.vx
            p.y = p.y + p.vy
            p.vy = p.vy + 0.15
            p.生命 = p.生命 - 1
            if(p.生命 <= 0) {
                p.活 = 0
            } else {
                vg.比例 = p.生命 / p.最大
                vg.s = p.大小 * 比例
                color(p.r * 比例, p.g * 比例, p.b * 比例)
                圆(p.x, p.y, s)
            }
        }
    }
    ret 0
}
'''

NEW_UPDATE = '''# 只画不演化：给「物理完全自己写」的人留的口子。
# 按 生命/最大 的比例同时衰减大小与颜色（和 fancy2d_update 画法一致）。
func fancy2d_draw(池) {
    for p in 池 {
        if(p.活) {
            if(p.生命 > 0) {
                vg.比例 = p.生命 / p.最大
                vg.s = p.大小 * 比例
                color(p.r * 比例, p.g * 比例, p.b * 比例)
                圆(p.x, p.y, s)
            }
        }
    }
    ret 0
}

# 演化 + 绘制。三个参数全部可选，默认值 = 1.0 之前写死的那套行为。
#   重力  每帧下落加速度   0.15 = 默认（屏幕 y 向下为正）/ 0.0 = 无重力 / 负值 = 上飘
#   阻力  每帧速度乘数     1.0 = 无阻力（直线匀速）/ 0.98 = 有空气阻力
#   速度  整体速度倍率     1.0 = 原速 / 2.0 = 双倍速
func fancy2d_update(池, 重力 = 0.15, 阻力 = 1.0, 速度 = 1.0) {
    for p in 池 {
        if(p.活) {
            p.x = p.x + p.vx * 速度
            p.y = p.y + p.vy * 速度
            p.vy = p.vy + 重力
            p.vx = p.vx * 阻力
            p.vy = p.vy * 阻力
            p.生命 = p.生命 - 1
            if(p.生命 <= 0) {
                p.活 = 0
            } else {
                vg.比例 = p.生命 / p.最大
                vg.s = p.大小 * 比例
                color(p.r * 比例, p.g * 比例, p.b * 比例)
                圆(p.x, p.y, s)
            }
        }
    }
    ret 0
}
'''

PATCHES = [
    ('头部注释', OLD_HEAD, NEW_HEAD),
    ('burst 签名', OLD_BURST_SIG, NEW_BURST_SIG),
    ('burst 初速 spd', OLD_SPD, NEW_SPD),
    ('update 参数化 + draw', OLD_UPDATE, NEW_UPDATE),
]

for path in FILES:
    s = io.open(path, encoding='utf-8').read()
    orig = s
    for label, old, new in PATCHES:
        n = s.count(old)
        if n != 1:
            sys.stderr.write('FAIL [%s] %s  count=%d\n' % (path, label, n))
            sys.exit(1)
        s = s.replace(old, new, 1)
    io.open(path, 'w', encoding='utf-8', newline='').write(s)
    print('ok  %s   %d -> %d bytes, %d lines' % (
        path, len(orig.encode('utf-8')), len(s.encode('utf-8')), s.count('\n') + 1))
