# -*- coding: utf-8 -*-
"""把源仓库 CHANGELOG 整份同步到官网 —— 先验证「上一版及以下」逐字节相同。"""
import io, shutil, sys

SRC = r'C:\Users\zhuli\Desktop\pybook\CHANGELOG.md'
DST = r'C:\Users\zhuli\Desktop\pybook官网\CHANGELOG.md'

a = io.open(SRC, encoding='utf-8').read()
b = io.open(DST, encoding='utf-8').read()

for mark in ('## 1.0.5', '## 1.0.4'):
    ia, ib = a.find(mark), b.find(mark)
    if ia < 0 or ib < 0:
        print('  %s: 源=%d 官网=%d（跳过）' % (mark, ia, ib))
        continue
    same = a[ia:] == b[ib:]
    print('  %s 起逐字节比较: %s' % (mark, '相同 ✓' if same else '**不同**'))
    if same:
        shutil.copyfile(SRC, DST)
        print('\n已整份覆盖到官网。官网现在 %d 行。' % (len(b.split('\n'))))
        s2 = io.open(DST, encoding='utf-8').read()
        print('官网版本节：', [l for l in s2.split('\n') if l.startswith('## ')][:3])
        sys.exit(0)

sys.stderr.write('\n**两份 CHANGELOG 在旧版本段不一致，不能直接覆盖，需人工核对**\n')
sys.exit(1)
