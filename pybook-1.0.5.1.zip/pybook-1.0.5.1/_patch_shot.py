"""给 pybook_hw3d.c 加一个"可选的无头出图"开关（环境变量驱动，未设=零开销）。

为什么需要：hw 程序的画面只有真窗口里能看到，验收时没法"看一眼"。
加了这个之后任何 hw 程序都能这样出图：

    PYBOOK_SHOT_DIR=shots PYBOOK_SHOT_EVERY=15 PYBOOK_SHOT_MAX=5 app_xxx.exe

存 BMP（零依赖，Read / _bmp2png.py 都能直接看）。
"""
import io, sys

P = 'pybook_hw3d.c'
s = io.open(P, encoding='utf-8').read()

CODE = r'''
/* ================= 可选：无头出图（环境变量驱动）=================
   验收/截图时用；环境变量没设就一行都不跑，零开销零影响。
     PYBOOK_SHOT_DIR    出图目录（设了才开）
     PYBOOK_SHOT_EVERY  每多少帧存一张（默认 20）
     PYBOOK_SHOT_MAX    最多存几张（默认 8）
   为什么存 BMP：零依赖、最好写；GL 读回是 R,G,B，BMP 要 B,G,R，逐像素换。 */
static int  g_shot_on    = 0;
static int  g_shot_every = 20;
static int  g_shot_max   = 8;
static int  g_shot_taken = 0;
static int  g_shot_seen  = 0;
static char g_shot_dir[400] = {0};

static void hw_shot_p16(unsigned char *p, unsigned v)
{ p[0] = (unsigned char)(v & 0xFF); p[1] = (unsigned char)((v >> 8) & 0xFF); }

static void hw_shot_p32(unsigned char *p, unsigned long v)
{
    p[0] = (unsigned char)(v & 0xFF);
    p[1] = (unsigned char)((v >> 8) & 0xFF);
    p[2] = (unsigned char)((v >> 16) & 0xFF);
    p[3] = (unsigned char)((v >> 24) & 0xFF);
}

static void hw_shot_bmp(const char *path, int W, int H, const unsigned char *rgb)
{
    FILE *f = fopen(path, "wb");
    if (f == NULL) { fprintf(stderr, "[shot] 打不开 %s\n", path); return; }
    int row = W * 3;
    int pad = (4 - (row % 4)) % 4;
    unsigned long stride = (unsigned long)(row + pad);
    unsigned char hdr[54];
    memset(hdr, 0, sizeof hdr);
    hdr[0] = 'B'; hdr[1] = 'M';
    hw_shot_p32(hdr + 2,  (unsigned long)(54 + stride * (unsigned long)H));
    hw_shot_p32(hdr + 10, 54);
    hw_shot_p32(hdr + 14, 40);
    hw_shot_p32(hdr + 18, (unsigned long)W);
    hw_shot_p32(hdr + 22, (unsigned long)H);
    hw_shot_p16(hdr + 26, 1);
    hw_shot_p16(hdr + 28, 24);
    hw_shot_p32(hdr + 34, stride * (unsigned long)H);
    fwrite(hdr, 1, 54, f);
    unsigned char zero[3] = { 0, 0, 0 };
    unsigned char *line = (unsigned char *)malloc((size_t)row);
    if (line == NULL) { fclose(f); return; }
    for (int y = 0; y < H; y++) {
        const unsigned char *s2 = rgb + (size_t)y * row;
        for (int x = 0; x < W; x++) {          /* GL 给 R,G,B → BMP 要 B,G,R */
            line[x * 3 + 0] = s2[x * 3 + 2];
            line[x * 3 + 1] = s2[x * 3 + 1];
            line[x * 3 + 2] = s2[x * 3 + 0];
        }
        fwrite(line, 1, (size_t)row, f);
        if (pad) fwrite(zero, 1, (size_t)pad, f);
    }
    free(line);
    fclose(f);
}

static void hw_shot_init(void)
{
    const char *d = getenv("PYBOOK_SHOT_DIR");
    if (d == NULL || *d == '\0') return;
    snprintf(g_shot_dir, sizeof g_shot_dir, "%s", d);
    const char *e = getenv("PYBOOK_SHOT_EVERY");
    if (e != NULL && *e != '\0') g_shot_every = atoi(e);
    if (g_shot_every < 1) g_shot_every = 1;
    const char *m = getenv("PYBOOK_SHOT_MAX");
    if (m != NULL && *m != '\0') g_shot_max = atoi(m);
    if (g_shot_max < 1) g_shot_max = 1;
    g_shot_on = 1;
    printf("[shot] 出图目录 %s  每 %d 帧一张，最多 %d 张\n",
           g_shot_dir, g_shot_every, g_shot_max);
    fflush(stdout);
}

/* 在 SwapWindow 之前调：此时后缓冲里是刚渲完的这一帧 */
static void hw_shot_maybe(void)
{
    if (!g_shot_on || g_shot_taken >= g_shot_max) return;
    g_shot_seen++;
    if (g_shot_seen % g_shot_every != 0) return;

    GLint vp[4];
    glGetIntegerv(GL_VIEWPORT, vp);
    int W = (int)vp[2], H = (int)vp[3];
    if (W <= 0 || H <= 0) return;

    size_t n = (size_t)W * (size_t)H * 3;
    unsigned char *buf = (unsigned char *)malloc(n);
    if (buf == NULL) return;
    glReadBuffer(GL_BACK);
    glPixelStorei(GL_PACK_ALIGNMENT, 1);
    glReadPixels(0, 0, W, H, GL_RGB, GL_UNSIGNED_BYTE, buf);
    while (glGetError() != GL_NO_ERROR) { /* 排干 */ }

    char path[520];
    snprintf(path, sizeof path, "%s/fx_%03d.bmp", g_shot_dir, g_shot_taken);
    hw_shot_bmp(path, W, H, buf);
    free(buf);
    printf("[shot] %s  (%dx%d)\n", path, W, H);
    fflush(stdout);
    g_shot_taken++;
}

/* ================= 数值解码 ================= */
'''

PATCHES = [
    ('插入出图模块',
     '/* ================= 数值解码 ================= */',
     CODE.lstrip('\n')),
    ('open 末尾初始化',
     '    glEnable(GL_DEPTH_TEST);\n    glDepthFunc(GL_LEQUAL);\n    return rt_none();\n}',
     '    glEnable(GL_DEPTH_TEST);\n    glDepthFunc(GL_LEQUAL);\n    hw_shot_init();\n    return rt_none();\n}'),
    ('swap 前出图',
     '    glDisable(GL_BLEND);\n    SDL_GL_SwapWindow(g_win);',
     '    glDisable(GL_BLEND);\n    hw_shot_maybe();\n    SDL_GL_SwapWindow(g_win);'),
]

for label, old, new in PATCHES:
    n = s.count(old)
    if n != 1:
        sys.stderr.write('FAIL [%s] count=%d\n' % (label, n))
        sys.exit(1)
    s = s.replace(old, new, 1)
    print('ok  ' + label)

io.open(P, 'w', encoding='utf-8', newline='').write(s)
print('已写回 %s' % P)
