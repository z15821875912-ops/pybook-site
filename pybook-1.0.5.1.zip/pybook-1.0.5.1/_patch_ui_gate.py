# -*- coding: utf-8 -*-
"""原来「任何 ui.* 只能用在 web.实时 块里」这刀砍得太宽 —— 新增的桌面 GUI
   （ui.begin / ui.button / ui.input ...）也被挡了。改成只拦网页专用的那三个。"""
import io, sys

def patch(path, patches):
    s = io.open(path, encoding='utf-8').read()
    for label, old, new in patches:
        n = s.count(old)
        if n != 1:
            sys.stderr.write('FAIL [%s] count=%d\n' % (label, n))
            sys.exit(1)
        s = s.replace(old, new, 1)
        print('ok  %s' % label)
    io.open(path, 'w', encoding='utf-8', newline='').write(s)

patch('pybk_code.py', [
    ('code:gate',
     "        if e.name.startswith('ui.'):\n"
     "            self.err(e, f'{e.name} 只在网页模式支持（写在 web.实时 块里）')",
     "        # 网页专用控件：ui.按钮 / ui.输入框 / ui.滑条 —— 只能写在 web.实时 块里。\n"
     "        # 注意别写成 startswith('ui.')：桌面 GUI 的 ui.begin / ui.button / ui.input\n"
     "        # 是另一套（实现在 pybook_ui.c），要放它们走下面的通用分发。\n"
     "        if e.name in ('ui.按钮', 'ui.输入框', 'ui.滑条'):\n"
     "            self.err(e, f'{e.name} 只在网页模式支持（写在 web.实时 块里）')"),
])
