/* _uishot.c —— GUI 出图 + 交互探针（无头验收）。
 *
 * 不开 pybk，直接链接 rt_cache 的 .o 调 rt_ui_* 渲一帧：
 *   ① 存 BMP 出图 —— 肉眼验控件到底长什么样；
 *   ② 注入输入 —— 验「点按钮有没有反应 / 点击是不是边沿语义 / 状态跨帧保不保得住」。
 *      鼠标位置取自 SDL_GetMouseState（真实光标），合成事件没用，所以走
 *      pybook_ui.c 里的 ui_test_input 钩子（故意不注册进 PYbook）。
 *
 * ⚠ 两个坑：
 *   · SDL.h 经 SDL_main.h 把 main 重定义成 SDL_main → 必须先 SDL_MAIN_HANDLED。
 *   · SDL_RenderReadPixels 读的是后备缓冲，present 之后内容未定义（实测读回全黑）
 *     → 顺序必须是「画 → 读 → present」。
 *   · BMP 存 B,G,R，读回来的是 R,G,B → 逐像素交换，否则红蓝互换。
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "pybook_rt.h"
#define SDL_MAIN_HANDLED
#include <SDL2/SDL.h>

extern SDL_Renderer *game_renderer(void);
extern int game_text_width(const char *s, int px);
extern Value rt_ui_begin(Value, Value, Value);
extern Value rt_ui_row(void);
extern Value rt_ui_col(void);
extern Value rt_ui_end(void);
extern Value rt_ui_gap(Value);
extern Value rt_ui_label(Value, Value);
extern Value rt_ui_button(Value);
extern Value rt_ui_input(Value);
extern Value rt_ui_slider(Value, Value, Value);
extern Value rt_ui_check(Value, Value);
/* pybook_ui.c 提供的测试钩子（不注册进 PYbook） */
extern void ui_test_input(int x, int y, int click, int down);
extern void ui_test_input_reset(void);

static const int W = 460;
static const int H = 340;

/* 控件坐标来自第一张截图实测；布局一改这里就要跟着改，
   改漏了断言会以「命中=0」大声失败，不会静默通过。 */
static const int BTN_OK_X = 53,  BTN_OK_Y = 118;   /* "确定" 中心 */
static const int BTN_CL_X = 121, BTN_CL_Y = 118;   /* "清空" 中心 */
static const int CHK_X = 34, CHK_Y = 241;          /* 勾选框中心 */
static const int SLD_X = 300, SLD_Y = 191;         /* 滑条上偏右一点 */

static int    g_btn_ok = 0, g_btn_clr = 0;
static double g_slider = 50.0;
static int    g_check  = 1;

static int g_fail = 0;

/* Value → double。rt_to_ll 只吃整数，浮点得走 AS_FLT（NaN boxing，见 pybook_rt.h） */
static double 取数(Value v)
{
    if (!IS_FLT(v))
        return (double)rt_to_ll(v);
    return AS_FLT(v);
}

static void 检查(const char *what, int ok, const char *detail)
{
    printf("  %s %s%s%s\n", ok ? "[通过]" : "[失败]", what,
           detail ? "  —— " : "", detail ? detail : "");
    if (!ok)
        g_fail++;
}

/* ---------------- BMP 输出 ---------------- */

static void put32(unsigned char *p, unsigned v)
{
    p[0] = (unsigned char)(v & 0xff);
    p[1] = (unsigned char)((v >> 8) & 0xff);
    p[2] = (unsigned char)((v >> 16) & 0xff);
    p[3] = (unsigned char)((v >> 24) & 0xff);
}

static void put16(unsigned char *p, unsigned v)
{
    p[0] = (unsigned char)(v & 0xff);
    p[1] = (unsigned char)((v >> 8) & 0xff);
}

static void save_bmp(const char *dir, const char *name, unsigned char *src)
{
    int row = W * 3;
    int pad = (4 - (row % 4)) % 4;
    int stride = row + pad;
    char path[512];
    snprintf(path, sizeof path, "%s/%s.bmp", dir, name);
    FILE *f = fopen(path, "wb");
    if (f == NULL) { printf("  ** 写不了 %s\n", path); g_fail++; return; }

    unsigned char hdr[54];
    memset(hdr, 0, sizeof hdr);
    hdr[0] = 'B'; hdr[1] = 'M';
    put32(hdr + 2, 54 + stride * H);
    put32(hdr + 10, 54);
    put32(hdr + 14, 40);
    put32(hdr + 18, W);
    put32(hdr + 22, H);
    put16(hdr + 26, 1);
    put16(hdr + 28, 24);
    put32(hdr + 34, stride * H);
    fwrite(hdr, 1, 54, f);

    unsigned char *line = (unsigned char *)malloc((size_t)row);
    unsigned char zero[4] = { 0, 0, 0, 0 };
    for (int y = 0; y < H; y++) {
        /* BMP 自下而上存：图像最后一行写在文件最前面 */
        const unsigned char *s = src + (size_t)(H - 1 - y) * row;
        for (int x = 0; x < W; x++) {
            line[x * 3 + 0] = s[x * 3 + 2];   /* B <- R */
            line[x * 3 + 1] = s[x * 3 + 1];   /* G */
            line[x * 3 + 2] = s[x * 3 + 0];   /* R <- B */
        }
        fwrite(line, 1, (size_t)row, f);
        if (pad) fwrite(zero, 1, (size_t)pad, f);
    }
    free(line);
    fclose(f);
    printf("  存图 %s/%s.bmp\n", dir, name);
}

/* ---------------- 一屏表单 ---------------- */

/* 标题 / 输入框 / 两个按钮（一行）/ 结果文字 / 滑条 / 勾选
   返回值落到 g_* 全局，供断言用。 */
static void 画一屏(void)
{
    rt_game_clear(rt_int(11), rt_int(14), rt_int(20));

    rt_ui_begin(rt_int(24), rt_int(22), rt_int(412));

        rt_ui_label(rt_str("请输入名字"), rt_int(18));
        rt_ui_input(rt_str("世界"));

        rt_ui_row();
            g_btn_ok  = (int)rt_to_ll(rt_ui_button(rt_str("确定")));
            g_btn_clr = (int)rt_to_ll(rt_ui_button(rt_str("清空")));
        rt_ui_end();

        rt_ui_gap(rt_int(6));
        rt_ui_label(rt_str("你好，世界！点了 0 次"), rt_int(16));

        rt_ui_gap(rt_int(12));
        g_slider = 取数(rt_ui_slider(rt_float(50.0), rt_int(0), rt_int(100)));
        g_check  = (int)rt_to_ll(rt_ui_check(rt_str("显示网格"), rt_bool(1)));

    rt_ui_end();
}

/* 一步 = 画一帧 →（可选）读后备缓冲存图 → present。
   读必须在 present 之前，见文件头注释。 */
static void 一步(const char *dir, const char *name)
{
    画一屏();

    if (name != NULL) {
        SDL_Renderer *ren = game_renderer();
        if (ren == NULL) { printf("  ** 拿不到渲染器\n"); g_fail++; return; }
        static unsigned char *buf = NULL;
        if (buf == NULL) {
            buf = (unsigned char *)malloc((size_t)W * H * 3);
            if (buf == NULL) { printf("  ** 内存不足\n"); g_fail++; return; }
        }
        memset(buf, 0, (size_t)W * H * 3);
        if (SDL_RenderReadPixels(ren, NULL, SDL_PIXELFORMAT_RGB24, buf, W * 3) != 0) {
            printf("  ** 读回像素失败：%s\n", SDL_GetError());
            g_fail++;
            return;
        }
        save_bmp(dir, name, buf);
    }

    rt_game_show();
}

int main(int argc, char **argv)
{
    const char *out = (argc > 1) ? argv[1] : ".";

    rt_game_win(rt_int(W), rt_int(H), "PYbook GUI shot");

    /* 预热两帧：把字体纹理缓存喂热，之后才是稳定结果 */
    ui_test_input_reset();
    for (int i = 0; i < 2; i++)
        一步(NULL, NULL);

    puts("=== ① 静止态：无输入，出图 ===");
    ui_test_input_reset();
    一步(out, "ui_shot");
    检查("静止态两个按钮都返回 0", g_btn_ok == 0 && g_btn_clr == 0, NULL);

    puts("=== ② 悬停态：鼠标停在\"清空\"上但不按 ===");
    ui_test_input(BTN_CL_X, BTN_CL_Y, 0, 0);
    一步(out, "ui_hover");
    检查("悬停不触发点击", g_btn_ok == 0 && g_btn_clr == 0, "悬停只该改变描边颜色");

    puts("=== ③ 点\"清空\"：边沿语义 ===");
    ui_test_input(BTN_CL_X, BTN_CL_Y, 1, 1);
    一步(NULL, NULL);
    检查("\"清空\"返回 1", g_btn_clr == 1, NULL);
    检查("\"确定\"没被误触发", g_btn_ok == 0, NULL);
    ui_test_input(BTN_CL_X, BTN_CL_Y, 0, 1);   /* 左键仍按住，但已不是按下那一帧 */
    一步(NULL, NULL);
    检查("按住不放不会重复触发", g_btn_clr == 0, "点击必须是边沿而不是电平");

    puts("=== ④ 点\"确定\" ===");
    ui_test_input(BTN_OK_X, BTN_OK_Y, 1, 1);
    一步(NULL, NULL);
    检查("\"确定\"返回 1", g_btn_ok == 1, NULL);
    检查("\"清空\"没被误触发", g_btn_clr == 0, NULL);

    puts("=== ⑤ 点空白处 ===");
    ui_test_input(400, 300, 1, 1);
    一步(NULL, NULL);
    检查("空白处点击两个按钮都不响应", g_btn_ok == 0 && g_btn_clr == 0, NULL);

    puts("=== ⑥ 勾选框：点击翻转 + 状态跨帧保持 ===");
    检查("初始为勾上", g_check == 1, NULL);
    ui_test_input(CHK_X, CHK_Y, 1, 1);
    一步(NULL, NULL);
    检查("点一下变成不勾", g_check == 0, "外部每帧传的字面值 1 不该覆盖内部状态");
    ui_test_input(CHK_X, CHK_Y, 0, 0);
    一步(NULL, NULL);
    检查("松开后仍保持不勾", g_check == 0, "跨帧状态保存住了");
    ui_test_input(CHK_X, CHK_Y, 1, 1);
    一步(NULL, NULL);
    检查("再点一下变回勾上", g_check == 1, NULL);

    puts("=== ⑦ 滑条：点击位置 → 数值映射 ===");
    ui_test_input(SLD_X, SLD_Y, 1, 1);
    一步(NULL, NULL);
    {
        /* 理论值直接用引擎量出的真实数值文本宽度算，别手估 ——
           "50" 在 16px 下实测 22px 宽，手估 16px 会把误差算进断言里。
           轨道宽 tw = 容器宽 412 - (文本宽 + 12)，见 rt_ui_slider。 */
        int vw   = game_text_width("50", 16);
        int tw   = 412 - (vw + 12);
        double want = 100.0 * (double)(SLD_X - 24) / (double)tw;
        double diff = g_slider - want;
        if (diff < 0) diff = -diff;
        char d[160];
        snprintf(d, sizeof d, "点 x=%d 得 %.1f，按轨道宽 %d 算理论 %.1f",
                 SLD_X, g_slider, tw, want);
        检查("滑条跟手", diff < 0.5, d);
    }
    ui_test_input(SLD_X, SLD_Y, 0, 0);
    一步(NULL, NULL);
    检查("滑条值跨帧保持", g_slider > 60.0, NULL);

    puts("=== ⑧ 末态出图 ===");
    ui_test_input_reset();
    一步(out, "ui_final");

    if (g_fail == 0)
        puts("\n>>> 全部通过：出图 3 张，交互语义（边沿 / 状态 / 映射）都对");
    else
        printf("\n>>> 有 %d 项失败\n", g_fail);
    return g_fail == 0 ? 0 : 1;
}
