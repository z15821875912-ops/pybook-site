# -*- coding: utf-8 -*-
"""把 ui.* 注册进 PYbook：C 名表 / 前向声明 / 参数个数 / rt_cache 编译清单。"""
import io, sys

def patch(path, patches):
    s = io.open(path, encoding='utf-8').read()
    for label, old, new in patches:
        n = s.count(old)
        if n != 1:
            sys.stderr.write('FAIL [%s] count=%d\n' % (label, n))
            sys.exit(1)
        s = s.replace(old, new, 1)
        print('ok  %s' % label)
    io.open(path, 'w', encoding='utf-8', newline='').write(s)

UI_PROTOS = '''

def gen_ui_protos() -> str:
    """out.c 需要的 rt_ui_* 原型（实现在 pybook_ui.c）。

    与 gen_hw_protos 的区别：hw 那批只在用到 3D 时才发，ui 这批无条件发 ——
    未使用的函数原型在 C 里无害，省得再去维护一个 ui_used 标志。"""
    fns = ['begin:3', 'row:0', 'col:0', 'end:0', 'gap:1', 'tag:1',
           'label:2', 'button:1', 'input:1', 'slider:3', 'check:2']
    lines = ['/* 桌面 GUI（实现在 pybook_ui.c，立即模式 / SDL2 自绘） */']
    for f in fns:
        name, n = f.split(':')
        args = ', '.join(['Value'] * int(n)) or 'void'
        lines.append('Value rt_ui_' + name + '(' + args + ');')
    return '\\n'.join(lines) + '\\n'
'''

patch('pybk_code.py', [
    # 1. C 名表
    ('code:names',
     "        'hw.fov': 'rt_hw_fov', 'hw.near': 'rt_hw_near', 'hw.ortho': 'rt_hw_ortho',",
     "        'hw.ortho': 'rt_hw_ortho',\n"
     "        'ui.begin': 'rt_ui_begin', 'ui.row': 'rt_ui_row', 'ui.col': 'rt_ui_col',\n"
     "        'ui.end': 'rt_ui_end', 'ui.gap': 'rt_ui_gap', 'ui.tag': 'rt_ui_tag',\n"
     "        'ui.label': 'rt_ui_label', 'ui.button': 'rt_ui_button',\n"
     "        'ui.input': 'rt_ui_input', 'ui.slider': 'rt_ui_slider',\n"
     "        'ui.check': 'rt_ui_check',"),

    # 2. out.c 里带上 ui 原型
    ('code:emit',
     "+ (self.hw_used and gen_hw_protos() or '')",
     "+ (self.hw_used and gen_hw_protos() or '')\n                + gen_ui_protos()"),

    # 3. gen_ui_protos 本体（紧跟 gen_hw_protos 之后）
    ('code:protofn',
     "    lines.append('Value rt_hw_univ(int nargs, Value *av);')\n"
     "    return '\\n'.join(lines) + '\\n'",
     "    lines.append('Value rt_hw_univ(int nargs, Value *av);')\n"
     "    return '\\n'.join(lines) + '\\n'" + UI_PROTOS),

    # 4. rt_cache 编译清单：新引擎要一起编成 .o
    ('code:cache',
     "'mathplus.c', 'pybook_bits.c'):",
     "'mathplus.c', 'pybook_bits.c', 'pybook_ui.c'):"),
])

patch('pybk_front.py', [
    ('front:arity',
     "    'hw.mx': 0, 'hw.my': 0, 'hw.mdown': 0, 'hw.mhit': 0, 'hw.text': 4,",
     "    'hw.mx': 0, 'hw.my': 0, 'hw.mdown': 0, 'hw.mhit': 0, 'hw.text': 4,\n"
     "    'ui.begin': 3, 'ui.row': 0, 'ui.col': 0, 'ui.end': 0, 'ui.gap': 1,\n"
     "    'ui.tag': 1, 'ui.label': 2, 'ui.button': 1, 'ui.input': 1,\n"
     "    'ui.slider': 3, 'ui.check': 2,"),
])
