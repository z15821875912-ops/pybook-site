"""把 星核特效.pybk 复制成"跑满 N 帧自动退出"的无头冒烟版。

主文件本身不设帧上限（给人玩的）；冒烟版只在 hw.frame() 之后插一条 break，
并把报告文件换名，免得覆盖真报告。
"""
import io, sys

N = int(sys.argv[1]) if len(sys.argv) > 1 else 90

src = io.open('星核特效/星核特效.pybk', encoding='utf-8').read()

old = "    hw.frame()\n}\n"
new = "    hw.frame()\n    if(帧 > %d) { 断 }\n}\n" % (N - 1)
assert src.count(old) == 1, '锚点不唯一：%d' % src.count(old)
src = src.replace(old, new, 1)

old2 = 'file.write("星核特效_报告.txt", 尾报)'
new2 = 'file.write("_星核_冒烟报告.txt", 尾报)'
assert src.count(old2) == 1
src = src.replace(old2, new2, 1)

io.open('星核特效/_星核_冒烟.pybk', 'w', encoding='utf-8', newline='').write(src)
print('已生成 星核特效/_星核_冒烟.pybk（上限 %d 帧）' % N)
