# -*- coding: utf-8 -*-
"""给 2D 后端补 GUI 需要的两处基础设施：
   ① 文字宽度测量（布局要用）
   ② 文本输入收集（SDL_TEXTINPUT —— 中文 IME 走的也是这条路）
每处断言 count==1。"""
import io, sys

def patch(path, patches):
    s = io.open(path, encoding='utf-8').read()
    for label, old, new in patches:
        n = s.count(old)
        if n != 1:
            sys.stderr.write('FAIL [%s] count=%d\n' % (label, n))
            sys.exit(1)
        s = s.replace(old, new, 1)
        print('ok  %s' % label)
    io.open(path, 'w', encoding='utf-8', newline='').write(s)

patch('pybook_rt.c', [

    # ① 文字宽度测量（只要 advance 累加，不生成纹理）
    ('rt:width',
     "Value rt_game_text(Value xv, Value yv, Value tv, Value sv)",
     """/* GUI 布局要量文字宽度：只累加 advance，不生成纹理（比 game_text_tex 轻）。
   非 static —— pybook_ui.c 要用。 */
int game_text_width(const char *s, int px)
{
    game_font_init();
    if (s == NULL)
        return 0;
    if (px < 6)
        px = 6;
    if (px > 220)
        px = 220;
    float scale = stbtt_ScaleForPixelHeight(&g_ttf, (float)px);
    int W = 4;
    for (int i = 0; s[i];) {
        int adv = 1;
        unsigned cp = game_utf8(s, i, &adv);
        int a = 0, l = 0;
        stbtt_GetCodepointHMetrics(&g_ttf, (int)cp, &a, &l);
        W += (int)(a * scale) + 2;
        i += adv;
    }
    return W;
}

Value rt_game_text(Value xv, Value yv, Value tv, Value sv)"""),

    # ② 文本输入：SDL_TEXTINPUT 直接给 UTF-8 合成结果
    ('rt:pump',
     """static void game_pump(void)
{
    SDL_Event ev;
    while (SDL_PollEvent(&ev))
        if (ev.type == SDL_QUIT)
            g_quit = 1;
}""",
     """/* 文本输入缓冲。
   ⚠ 关键点：SDL_TEXTINPUT 给的是**输入法合成之后**的 UTF-8 结果，
   所以中文输入（IME）不需要我们自己做候选词合成 —— 只要开 SDL_StartTextInput，
   中文就能直接打进来。退格 / 回车单独记次数，按帧消费。 */
#define GAME_TYPED_MAX 256
static char g_typed[GAME_TYPED_MAX];
static int  g_typed_n = 0;
static int  g_backspace = 0;
static int  g_enter = 0;

static void game_pump(void)
{
    SDL_Event ev;
    while (SDL_PollEvent(&ev)) {
        if (ev.type == SDL_QUIT)
            g_quit = 1;
        else if (ev.type == SDL_TEXTINPUT) {
            const char *t = ev.text.text;
            for (int i = 0; t[i] && g_typed_n < GAME_TYPED_MAX - 1; i++)
                g_typed[g_typed_n++] = t[i];
            g_typed[g_typed_n] = '\\0';
        } else if (ev.type == SDL_KEYDOWN) {
            if (ev.key.keysym.sym == SDLK_BACKSPACE)
                g_backspace++;
            else if (ev.key.keysym.sym == SDLK_RETURN ||
                     ev.key.keysym.sym == SDLK_KP_ENTER)
                g_enter++;
        }
    }
}

/* 取走本帧输入的文本（取走即清空）。非 static —— pybook_ui.c 用。 */
const char *game_take_text(void)
{
    static char buf[GAME_TYPED_MAX];
    memcpy(buf, g_typed, (size_t)g_typed_n + 1);
    g_typed_n = 0;
    g_typed[0] = '\\0';
    return buf;
}

int game_take_backspace(void)
{
    int n = g_backspace;
    g_backspace = 0;
    return n;
}

int game_take_enter(void)
{
    int n = g_enter;
    g_enter = 0;
    return n;
}"""),

    # ③ 开窗时打开文本输入（否则收不到 SDL_TEXTINPUT）
    ('rt:starttext',
     "    SDL_RenderSetLogicalSize(g_sdl_ren, w, h);",
     "    SDL_RenderSetLogicalSize(g_sdl_ren, w, h);\n"
     "    SDL_StartTextInput();          /* 收 SDL_TEXTINPUT：中文 IME 也靠它 */"),
])
