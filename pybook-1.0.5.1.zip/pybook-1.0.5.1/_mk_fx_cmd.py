# -*- coding: utf-8 -*-
"""生成 星核特效.cmd（仓库根）+ 桌面转发器。GBK 编码 + CRLF，双击即用。"""
import io, os

ROOT = r'C:\Users\zhuli\Desktop\pybook'
DESK = r'C:\Users\zhuli\Desktop'

MAIN = r'''@echo off
chcp 936 >nul 2>&1
title PYbook 星核特效 1.0.5
setlocal

rem ---- 定位 PYbook 仓库根：放哪都能跑 ----
set "ROOT=%~dp0"
if not exist "%ROOT%pybk_main.py" set "ROOT=%~dp0..\"
if not exist "%ROOT%pybk_main.py" goto NO_ROOT
cd /d "%ROOT%"

if not exist "星核特效\星核特效.pybk" goto NO_SRC

rem ---- 找编译器 ----
if exist "C:\Users\zhuli\mingw64\bin\x86_64-w64-mingw32-gcc.exe" set "PATH=C:\Users\zhuli\mingw64\bin;%PATH%"
where gcc >nul 2>&1
if not errorlevel 1 goto GCC_OK
if exist "C:\Users\zhuli\mingw64\bin\x86_64-w64-mingw32-gcc.exe" goto GCC_OK
goto NO_GCC
:GCC_OK

rem ---- 找 Python ----
set "PY=python"
python --version >nul 2>&1
if not errorlevel 1 goto PY_OK
set "PY=%LocalAppData%\Programs\Python\Python311\python.exe"
if exist "%PY%" goto PY_OK
set "PY=C:\Users\zhuli\AppData\Local\Programs\Python\Python311\python.exe"
if exist "%PY%" goto PY_OK
set "PY=C:\Users\zhuli\.workbuddy\binaries\python\versions\3.13.12\python.exe"
if exist "%PY%" goto PY_OK
goto NO_PY

:PY_OK
echo.
echo   ====================================================
echo      PYbook 星核特效      纯 fancy3d + pybk 程序化特效
echo   ====================================================
echo.
echo      空格 = 暂停 / 继续        P = 手动爆一发
echo      W    = 线框开关           H = 显示 / 隐藏信息
echo      ESC  = 退出
echo.
echo   [1/3] 解析 .pybk 并生成 C 代码 ...
echo   [2/3] gcc 编译（首次 10~40 秒，之后走 rt_cache 缓存快很多）...
echo   [3/3] 弹出窗口 ...
echo.

"%PY%" pybk_main.py "星核特效\星核特效.pybk"
set "RC=%errorlevel%"
echo.
if "%RC%"=="0" (
  echo   窗口已正常关闭。
) else (
  echo   退出码 %RC%  ^(非 0 一般是编译或运行报错，往上翻看错误信息^)
)
echo.
pause
endlocal
exit /b 0

:NO_ROOT
echo.
echo   [x] 找不到 pybk_main.py
echo       本脚本要放到 PYbook 仓库根目录（pybk_main.py 旁边）再双击。
echo       当前查找位置：%ROOT%
echo.
pause
exit /b 1

:NO_SRC
echo.
echo   [x] 找不到 星核特效\星核特效.pybk
echo       当前目录：%CD%
echo.
pause
exit /b 1

:NO_GCC
echo.
echo   [x] 没找到 gcc 编译器。3D 特效需要它把 PYbook 编成 exe。
echo       请把 mingw64 解压到 C:\Users\zhuli\mingw64
echo       （要能看到 C:\Users\zhuli\mingw64\bin\x86_64-w64-mingw32-gcc.exe）
echo.
pause
exit /b 1

:NO_PY
echo.
echo   [x] 没找到可用的 Python。
echo       请安装 Python 3.x 并勾选 "Add python.exe to PATH"，
echo       或直接编辑本脚本里的 PY 路径。
echo.
pause
exit /b 1
'''

DESKTOP_LAUNCHER = r'''@echo off
chcp 936 >nul 2>&1
title PYbook 星核特效
call "C:\Users\zhuli\Desktop\pybook\星核特效.cmd"
'''


def w(path, text):
    with io.open(path, 'w', encoding='gbk', newline='\r\n') as f:
        f.write(text)
    print('ok  ' + path + '  (%d bytes)' % os.path.getsize(path))


w(os.path.join(ROOT, '星核特效.cmd'), MAIN)
w(os.path.join(DESK, '星核特效.cmd'), DESKTOP_LAUNCHER)
