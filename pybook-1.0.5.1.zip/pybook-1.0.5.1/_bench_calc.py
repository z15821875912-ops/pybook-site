# -*- coding: utf-8 -*-
"""跟 _bench_calc.pybk 同题的 CPython 对照基准。
   同题同量级，纯 Python 与 numpy 各测一遍（PYbook 的 np.dot 对标 numpy）。"""
import math, time


def bench(fn):
    t = time.perf_counter()
    r = fn()
    return (time.perf_counter() - t) * 1000.0, r


def A():
    s = 0
    for i in range(50_000_000):
        s = s + i
    return s


def B():
    s = 0.0
    for i in range(10_000_000):
        s = s + math.sqrt(i + 1)
    return s


def C1():
    a = []
    ap = a.append
    for i in range(2_000_000):
        ap(i)
    return a


def C2(a):
    s = 0
    for i in range(2_000_000):
        s = s + a[i]
    return s


def D():
    X = list(range(1600))
    Y = list(range(1600))
    d = 0.0
    for _ in range(20000):
        d = d + sum(x * y for x, y in zip(X, Y))
    return d


def D_np():
    try:
        import numpy as np
    except ImportError:
        return None
    X = np.arange(1600)
    Y = np.arange(1600)
    d = 0.0
    for _ in range(20000):
        d = d + float(np.dot(X, Y))
    return d


if __name__ == '__main__':
    ta, ra = bench(A)
    print('A整数5e7=%.0f ms  和=%d' % (ta, ra))

    tb, rb = bench(B)
    print('B浮点sqrt1e7=%.0f ms  和=%.3f' % (tb, rb))

    tc1, a = bench(C1)
    tc2, rc = bench(lambda: C2(a))
    print('C列表2e6 建=%.0f ms 读=%.0f ms  和=%d' % (tc1, tc2, rc))

    td, rd = bench(D)
    print('D点积1600x2万(纯python)=%.0f ms  和=%d' % (td, rd))

    r = D_np()
    if r is not None:
        tdn, rdn = bench(D_np)
        print('D点积1600x2万(numpy)=%.0f ms  和=%d' % (tdn, rdn))
    else:
        print('D点积1600x2万(numpy)= 无 numpy')
