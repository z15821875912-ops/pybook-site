# -*- coding: utf-8 -*-
"""把两张 PNG 横向拼成一张对照图（右侧带虚线分隔）。
读自己写的 PNG，所以可以假定 filter 全 0。"""
import struct, zlib, sys


def read_png(p):
    d = open(p, 'rb').read()
    i, w, h, idat = 8, None, None, b''
    while i < len(d):
        ln, = struct.unpack('>I', d[i:i + 4])
        tag = d[i + 4:i + 8]
        data = d[i + 8:i + 8 + ln]
        if tag == b'IHDR':
            w, h = struct.unpack('>II', data[:8])
        elif tag == b'IDAT':
            idat += data
        i += 12 + ln
    raw = zlib.decompress(idat)
    stride = w * 3
    return w, h, [raw[y * (stride + 1) + 1: y * (stride + 1) + 1 + stride] for y in range(h)]


def write_png(path, w, h, rows):
    raw = bytearray()
    for r in rows:
        raw.append(0)
        raw += r
    comp = zlib.compress(bytes(raw), 6)

    def chunk(tag, data):
        return (struct.pack('>I', len(data)) + tag + data
                + struct.pack('>I', zlib.crc32(tag + data) & 0xffffffff))

    out = b'\x89PNG\r\n\x1a\n'
    out += chunk(b'IHDR', struct.pack('>IIBBBBB', w, h, 8, 2, 0, 0, 0))
    out += chunk(b'IDAT', comp)
    out += chunk(b'IEND', b'')
    open(path, 'wb').write(out)


left, right, out = sys.argv[1], sys.argv[2], sys.argv[3]
w1, h1, r1 = read_png(left)
w2, h2, r2 = read_png(right)
GAP = 8
W = w1 + GAP + w2
H = max(h1, h2)
rows = []
for y in range(H):
    row = bytearray()
    row += r1[y] if y < h1 else bytes(w1 * 3)
    row += bytes([20, 24, 34]) * GAP          # 深色分隔条
    row += r2[y] if y < h2 else bytes(w2 * 3)
    rows.append(bytes(row))
write_png(out, W, H, rows)
print('%s  %dx%d' % (out, W, H))
