# -*- coding: utf-8 -*-
"""给 GUI 引擎开访问口：g_sdl_ren / g_log_w / g_log_h 都是 static，
   pybook_ui.c 拿不到，只能靠这几个函数。"""
import io, sys

def patch(path, patches):
    s = io.open(path, encoding='utf-8').read()
    for label, old, new in patches:
        n = s.count(old)
        if n != 1:
            sys.stderr.write('FAIL [%s] count=%d\n' % (label, n))
            sys.exit(1)
        s = s.replace(old, new, 1)
        print('ok  %s' % label)
    io.open(path, 'w', encoding='utf-8', newline='').write(s)

patch('pybook_rt.c', [
    ('rt:accessors',
     'Value rt_game_show(void)\n{\n    if (g_sdl_ren == NULL)\n        rt_die("game.show：还没开窗口（先调用 game.win）");',
     """/* GUI 引擎（pybook_ui.c）要直接画矩形边框 —— rt_game_box 只能填实心，
   描边得自己调 SDL。g_sdl_ren / g_log_w / g_log_h 都是本文件 static，
   所以给三个访问口。 */
SDL_Renderer *game_renderer(void) { return g_sdl_ren; }
int game_width(void)  { return g_log_w; }
int game_height(void) { return g_log_h; }

Value rt_game_show(void)"""),
])
