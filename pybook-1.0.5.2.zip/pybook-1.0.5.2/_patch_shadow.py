# -*- coding: utf-8 -*-
"""Task #24：阴影贴图（深度 FBO + 软件深度比较）。
两遍渲染：光源视角先渲一遍深度，主 pass 每个片元回查比较。
幂等：每处锚点断言 count == 1，改完一次性写回。"""
import io, sys, os

ROOT = r'C:\Users\zhuli\Desktop\pybook'

# ---------------------------------------------------------------- 阴影前半段
SHADOW_HEAD = r'''
/* ================= 阴影贴图（hw.shadow / shadowres / shadowarea / shadowbias /
   shadowcenter）=================
   两遍渲染：
     1) 阴影 pass —— 从光源方向把整个场景渲一遍，只留深度（正交投影，平行光）。
     2) 主 pass —— 每个片元把"到光源的深度"换算到阴影贴图坐标，回查比较：
        比阴影贴图里记的还浅 = 被别的东西挡住了 = 在阴影里。
   用的是软件比较（普通 sampler2D 采样深度值自己比），而不是
   sampler2DShadow + GL_TEXTURE_COMPARE_MODE 那套硬件比较 ——
   兼容 profile 下最省事，也少两个扩展依赖。 */
static int    g_shadow_on   = 0;       /* hw.shadow(1) 才启用 */
static int    g_shadow_res  = 1024;    /* hw.shadowres：阴影贴图边长 */
static double g_shadow_area = 20.0;    /* hw.shadowarea：正交半径（世界单位） */
static double g_shadow_bias = 0.0025;  /* hw.shadowbias：自遮挡偏移 */
static double g_shadow_cx = 0.0, g_shadow_cy = 0.0, g_shadow_cz = 0.0;
static GLuint g_fbo_shadow  = 0;       /* 只挂深度，不挂颜色 */
static GLuint g_shadow_tex  = 0;
static int    g_shadow_size = 0;
static GLuint g_shadow_prog = 0;       /* 阴影 pass 用的空片段着色器 */
static int    g_shadow_fail = 0;
static int    g_shadow_pass = 0;       /* 当前处在阴影 pass：命令流要忽略切程序 */
static GLfloat g_lightmat[16];         /* 光源正交投影 × 光源视图（视空间→光源裁剪） */

#ifndef GL_TEXTURE2
#define GL_TEXTURE2 0x84C2
#endif
#ifndef GL_DEPTH_COMPONENT
#define GL_DEPTH_COMPONENT 0x1902
#endif
#ifndef GL_NONE
#define GL_NONE 0
#endif
#ifndef GL_TEXTURE_COMPARE_MODE
#define GL_TEXTURE_COMPARE_MODE 0x884C
#endif

/* 阴影 pass 的着色器：顶点只做 MVP 变换，片段什么都不写 ——
   颜色通道本来就关着（glColorMask），深度照样会写进深度贴图。 */
static const char *HW_SHADOW_VS =
    "#version 120\n"
    "void main(){ gl_Position = gl_ModelViewProjectionMatrix * gl_Vertex; }\n";
static const char *HW_SHADOW_FS =
    "#version 120\n"
    "void main(){ gl_FragColor = vec4(1.0); }\n";

/* 摆一个"从 eye 看向 center"的相机矩阵（列主序，直接给 glMultMatrixd）。
   up 与视线共线时挑一个备用轴，免得叉乘退化成零向量。 */
static void hw_lookat(double ex, double ey, double ez,
                      double cx, double cy, double cz,
                      double ux, double uy, double uz)
{
    double fx = cx - ex, fy = cy - ey, fz = cz - ez;
    double l = sqrt(fx * fx + fy * fy + fz * fz);
    if (l < 1e-9) { fx = 0.0; fy = 0.0; fz = -1.0; }
    else          { fx /= l; fy /= l; fz /= l; }
    double sx = fy * uz - fz * uy, sy = fz * ux - fx * uz, sz = fx * uy - fy * ux;
    l = sqrt(sx * sx + sy * sy + sz * sz);
    if (l < 1e-9) { sx = 1.0; sy = 0.0; sz = 0.0; }   /* f 与 up 共线 */
    else          { sx /= l; sy /= l; sz /= l; }
    double nx = sy * fz - sz * fy, ny = sz * fx - sx * fz, nz = sx * fy - sy * fx;
    double m[16] = {
        sx, nx, -fx, 0.0,
        sy, ny, -fy, 0.0,
        sz, nz, -fz, 0.0,
        0.0, 0.0, 0.0, 1.0
    };
    glMultMatrixd(m);
    glTranslated(-ex, -ey, -ez);
}

static void hw_shadow_drop(void)
{
    if (g_fbo_shadow != 0 && glapi.DeleteFramebuffers)
        glapi.DeleteFramebuffers(1, &g_fbo_shadow);
    if (g_shadow_tex != 0)
        glDeleteTextures(1, &g_shadow_tex);
    g_fbo_shadow = 0;
    g_shadow_tex = 0;
    g_shadow_size = 0;
}

/* 保证阴影 FBO 与深度贴图都在、且边长是 res。返回 0 = 这套能力用不了。 */
static int hw_shadow_ensure(void)
{
    if (!g_gl_ok || glapi.GenFramebuffers == NULL || glapi.FramebufferTexture2D == NULL ||
        glapi.BindFramebuffer == NULL || glapi.CheckFramebufferStatus == NULL)
        return 0;
    int res = g_shadow_res;
    if (res < 64) res = 64;
    if (res > 4096) res = 4096;
    if (g_fbo_shadow != 0 && g_shadow_size == res)
        return 1;

    hw_shadow_drop();
    if (g_shadow_prog == 0) {
        if (g_shadow_fail)
            return 0;
        char log[512];
        g_shadow_prog = hw_build_program(HW_SHADOW_VS, HW_SHADOW_FS, log, sizeof log);
        if (g_shadow_prog == 0) {
            fprintf(stderr, "[shadow] 深度着色器编译失败：%s\n", log);
            fflush(stderr);
            g_shadow_fail = 1;
            return 0;
        }
    }

    glGenTextures(1, &g_shadow_tex);
    glBindTexture(GL_TEXTURE_2D, g_shadow_tex);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_DEPTH_COMPONENT24, res, res, 0,
                 GL_DEPTH_COMPONENT, GL_FLOAT, NULL);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_COMPARE_MODE, GL_NONE);
    glBindTexture(GL_TEXTURE_2D, 0);

    glapi.GenFramebuffers(1, &g_fbo_shadow);
    glapi.BindFramebuffer(GL_FRAMEBUFFER, g_fbo_shadow);
    glapi.FramebufferTexture2D(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT,
                               GL_TEXTURE_2D, g_shadow_tex, 0);
    glDrawBuffer(GL_NONE);
    glReadBuffer(GL_NONE);
    GLenum st = glapi.CheckFramebufferStatus(GL_FRAMEBUFFER);
    glapi.BindFramebuffer(GL_FRAMEBUFFER, 0);
    if (st != GL_FRAMEBUFFER_COMPLETE) {
        fprintf(stderr, "[shadow] 深度 FBO 不完整（0x%X）—— 关掉阴影\n", (unsigned)st);
        fflush(stderr);
        hw_shadow_drop();
        g_shadow_fail = 1;
        g_shadow_on = 0;
        return 0;
    }
    g_shadow_size = res;
    printf("[shadow] 深度贴图 %dx%d 就绪\n", res, res);
    fflush(stdout);
    return 1;
}

'''

# ---------------------------------------------------------------- 阴影后半段
SHADOW_TAIL = r'''
/* 阴影 pass：从光源方向渲一遍场景，深度存进 g_shadow_tex。
   顺带把"光源矩阵"算出来 —— 直接用 GL 自己的矩阵乘法（glLoadMatrixd +
   glMultMatrixd + glGetFloatv）拿，省得手写 4x4 乘还容易搞错列主序。 */
static void hw_shadow_pass(void)
{
    double area = g_shadow_area;
    if (area < 0.5) area = 0.5;
    if (area > 2000.0) area = 2000.0;
    double range = area * 3.0;

    glapi.BindFramebuffer(GL_FRAMEBUFFER, g_fbo_shadow);
    glViewport(0, 0, g_shadow_size, g_shadow_size);
    glClearDepth(1.0);
    glClear(GL_DEPTH_BUFFER_BIT);
    glColorMask(GL_FALSE, GL_FALSE, GL_FALSE, GL_FALSE);
    glDisable(GL_FOG);
    glDisable(GL_BLEND);
    glDisable(GL_ALPHA_TEST);
    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_LEQUAL);
    glDepthMask(GL_TRUE);
    /* 背面剔除：少一半图元写深度，顺带把"自阴影 acne"压下去一档 */
    glCullFace(GL_BACK);
    glEnable(GL_CULL_FACE);

    /* 光源相机：沿光方向退到 range 处，看向阴影中心 */
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(-area, area, -area, area, -range, range);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    {
        double ex = g_shadow_cx + (double)g_lx * range;
        double ey = g_shadow_cy + (double)g_ly * range;
        double ez = g_shadow_cz + (double)g_lz * range;
        double ux = 0.0, uy = 1.0, uz = 0.0;
        if (fabs((double)g_ly) > 0.985) { ux = 1.0; uy = 0.0; uz = 0.0; }
        hw_lookat(ex, ey, ez,
                  g_shadow_cx, g_shadow_cy, g_shadow_cz, ux, uy, uz);
    }

    /* g_lightmat = 正交投影 × 光源视图 = "世界 → 光源裁剪"。
       主 pass 里传进着色器的是视空间坐标，所以要用
       g_lightmat * (gl_ModelViewMatrix * gl_Vertex) —— 正好把
       gl_ModelViewMatrix 里的"视图 × 模型"补上，顶点着色器不用改。 */
    {
        double view[16], proj[16];
        glGetDoublev(GL_MODELVIEW_MATRIX, view);
        glGetDoublev(GL_PROJECTION_MATRIX, proj);
        glLoadMatrixd(proj);
        glMultMatrixd(view);
        glGetFloatv(GL_MODELVIEW_MATRIX, g_lightmat);
        glLoadMatrixd(view);      /* 把光源视图装回去，开始画场景 */
    }

    g_shadow_pass = 1;
    int saved_wire = g_wire;
    g_wire = 0;                    /* 阴影是实心的，线框不该投阴影 */
    if (glapi.UseProgram != NULL) {
        glapi.UseProgram(g_shadow_prog);
        g_bound_prog = g_shadow_prog;
    }
    draw_ops();
    g_wire = saved_wire;
    g_shadow_pass = 0;
    if (glapi.UseProgram != NULL) {
        glapi.UseProgram(0);
        g_bound_prog = 0;
    }

    glColorMask(GL_TRUE, GL_TRUE, GL_TRUE, GL_TRUE);
    glDisable(GL_CULL_FACE);
    glapi.BindFramebuffer(GL_FRAMEBUFFER, 0);
}

/* 把阴影相关的 uniform 灌进"当前正在用的程序"。
   着色器里没声明这些名字时 GetUniformLocation 返回 -1，静默跳过 ——
   所以老程序的自定义着色器照常工作，不会因为多了这几个名字就崩。 */
static void hw_shadow_unis(GLuint p)
{
    if (!g_shadow_on || g_shadow_tex == 0 || p == 0)
        return;
    if (glapi.UniformMatrix4fv != NULL) {
        GLint l = glapi.GetUniformLocation(p, "uLightMat");
        if (l >= 0) glapi.UniformMatrix4fv(l, 1, GL_FALSE, g_lightmat);
    }
    GLint l = glapi.GetUniformLocation(p, "uShadow");
    if (l >= 0) glapi.Uniform1i(l, 2);
    l = glapi.GetUniformLocation(p, "uShadowTexel");
    if (l >= 0) glapi.Uniform1f(l, 1.0f / (GLfloat)g_shadow_size);
    l = glapi.GetUniformLocation(p, "uShadowOn");
    if (l >= 0) glapi.Uniform1f(l, 1.0f);
    l = glapi.GetUniformLocation(p, "uShadowBias");
    if (l >= 0) glapi.Uniform1f(l, (GLfloat)g_shadow_bias);
}

'''

SHADOW_API = r'''/* ---- 阴影贴图开关与参数 ---- */
Value rt_hw_shadow(Value vv)
{
    g_shadow_on = hw_num(vv, "hw.shadow 的开关") > 0.5 ? 1 : 0;
    return rt_none();
}

Value rt_hw_shadowres(Value vv)
{
    int r = (int)hw_num(vv, "hw.shadowres 的尺寸");
    if (r < 64) r = 64;
    if (r > 4096) r = 4096;
    g_shadow_res = r;
    return rt_none();
}

Value rt_hw_shadowarea(Value vv)
{
    g_shadow_area = hw_num(vv, "hw.shadowarea 的半径");
    return rt_none();
}

Value rt_hw_shadowbias(Value vv)
{
    g_shadow_bias = hw_num(vv, "hw.shadowbias 的偏移");
    return rt_none();
}

Value rt_hw_shadowcenter(Value xv, Value yv, Value zv)
{
    g_shadow_cx = hw_num(xv, "hw.shadowcenter 的x");
    g_shadow_cy = hw_num(yv, "hw.shadowcenter 的y");
    g_shadow_cz = hw_num(zv, "hw.shadowcenter 的z");
    return rt_none();
}

'''

# ---------------------------------------------------------------- 内置着色器改造
# 影子辅助段（宏字符串字面量：编译期拼进各 FS，不用运行时 strcat）
FS_HELP = r'''
/* 阴影查询辅助段：所有吃光照的内置片段着色器都要拼上它。
   这是宏字符串字面量，不是 static const char* —— 后者没法在编译期拼接
   （静态初始化器不接受非常量表达式，报 "initializer element is not constant"）。 */
#define HW_FS_SHADOW_HELP \
    "uniform mat4 uLightMat;\n" \
    "uniform sampler2D uShadow;\n" \
    "uniform float uShadowOn;\n" \
    "uniform float uShadowTexel;\n" \
    "uniform float uShadowBias;\n" \
    "float shadowOf(vec3 eye){\n" \
    "  if (uShadowOn < 0.5) return 1.0;\n" \
    "  vec4 lp = uLightMat * vec4(eye, 1.0);\n" \
    "  vec3 p = lp.xyz / lp.w * 0.5 + 0.5;\n" \
    "  if (p.x <= 0.0 || p.x >= 1.0 || p.y <= 0.0 || p.y >= 1.0 || p.z >= 1.0) return 1.0;\n" \
    "  float s = 0.0;\n" \
    "  for (int i = -1; i <= 1; i++) for (int j = -1; j <= 1; j++) {\n" \
    "    float d = texture2D(uShadow, p.xy + vec2(float(i), float(j)) * uShadowTexel).r;\n" \
    "    s += (p.z - uShadowBias > d) ? 0.0 : 1.0;\n" \
    "  }\n" \
    "  return s / 9.0;\n" \
    "}\n"
'''

PATCHES_C = [
    # 1. 阴影前半段（全局 / VS / FS / lookat / drop / ensure）
    ('shadow-head',
     'static void hw_post_drop(void)\n{',
     SHADOW_HEAD.lstrip('\n') + 'static void hw_post_drop(void)\n{'),

    # 2. HW_FS_SHADOW_HELP 宏
    ('fs-help-macro',
     '/* 朗伯：环境光 + 漫反射，可选贴图。和固定管线观感最接近，做基准对照用。 */',
     FS_HELP.lstrip('\n') + '\n'
     '/* 朗伯：环境光 + 漫反射，可选贴图。和固定管线观感最接近，做基准对照用。 */'),

    # 3. HW_FS_LAMBERT 加阴影
    ('fs-lambert',
     'static const char *HW_FS_LAMBERT =\n'
     '    "#version 120\\n"\n'
     '    "varying vec3 vN; varying vec3 vC; varying vec2 vUV;\\n"\n'
     '    "uniform vec3 uLight; uniform sampler2D uTex; uniform float uTexMix;\\n"\n'
     '    "void main(){\\n"\n'
     '    "  float d = max(dot(normalize(vN), normalize(uLight)), 0.0);\\n"\n'
     '    "  vec3 alb = vC * mix(vec3(1.0), texture2D(uTex, vUV).rgb, uTexMix);\\n"\n'
     '    "  gl_FragColor = vec4(alb * (0.35 + 0.75 * d), 1.0);\\n"\n'
     '    "}\\n";',
     'static const char *HW_FS_LAMBERT =\n'
     '    "#version 120\\n"\n'
     '    "varying vec3 vN; varying vec3 vC; varying vec2 vUV; varying vec3 vEye;\\n"\n'
     '    HW_FS_SHADOW_HELP\n'
     '    "uniform vec3 uLight; uniform sampler2D uTex; uniform float uTexMix;\\n"\n'
     '    "void main(){\\n"\n'
     '    "  float d = max(dot(normalize(vN), normalize(uLight)), 0.0);\\n"\n'
     '    "  d *= shadowOf(vEye);\\n"\n'
     '    "  vec3 alb = vC * mix(vec3(1.0), texture2D(uTex, vUV).rgb, uTexMix);\\n"\n'
     '    "  gl_FragColor = vec4(alb * (0.35 + 0.75 * d), 1.0);\\n"\n'
     '    "}\\n";'),

    # 4. HW_FS_TOON 加阴影
    ('fs-toon',
     'static const char *HW_FS_TOON =\n'
     '    "#version 120\\n"\n'
     '    "varying vec3 vN; varying vec3 vC; varying vec2 vUV;\\n"\n'
     '    "uniform vec3 uLight; uniform sampler2D uTex; uniform float uTexMix;\\n"\n'
     '    "uniform float uSteps;\\n"\n'
     '    "void main(){\\n"\n'
     '    "  float d = max(dot(normalize(vN), normalize(uLight)), 0.0);\\n"\n'
     '    "  float s = floor(d * uSteps + 0.5) / max(uSteps, 1.0);\\n"\n'
     '    "  vec3 alb = vC * mix(vec3(1.0), texture2D(uTex, vUV).rgb, uTexMix);\\n"\n'
     '    "  gl_FragColor = vec4(alb * (0.30 + 0.85 * s), 1.0);\\n"\n'
     '    "}\\n";',
     'static const char *HW_FS_TOON =\n'
     '    "#version 120\\n"\n'
     '    "varying vec3 vN; varying vec3 vC; varying vec2 vUV; varying vec3 vEye;\\n"\n'
     '    HW_FS_SHADOW_HELP\n'
     '    "uniform vec3 uLight; uniform sampler2D uTex; uniform float uTexMix;\\n"\n'
     '    "uniform float uSteps;\\n"\n'
     '    "void main(){\\n"\n'
     '    "  float d = max(dot(normalize(vN), normalize(uLight)), 0.0);\\n"\n'
     '    "  d *= shadowOf(vEye);\\n"\n'
     '    "  float s = floor(d * uSteps + 0.5) / max(uSteps, 1.0);\\n"\n'
     '    "  vec3 alb = vC * mix(vec3(1.0), texture2D(uTex, vUV).rgb, uTexMix);\\n"\n'
     '    "  gl_FragColor = vec4(alb * (0.30 + 0.85 * s), 1.0);\\n"\n'
     '    "}\\n";'),

    # 5. HW_FS_FRESNEL 加阴影（本来就有 vEye）
    ('fs-fresnel',
     '    "varying vec3 vN; varying vec3 vC; varying vec2 vUV; varying vec3 vEye;\\n"\n'
     '    "uniform vec3 uLight; uniform sampler2D uTex; uniform float uTexMix;\\n"\n'
     '    "uniform vec3 uRim; uniform float uRimPow;\\n"\n'
     '    "void main(){\\n"\n'
     '    "  vec3 N = normalize(vN);\\n"\n'
     '    "  vec3 V = normalize(-vEye);\\n"\n'
     '    "  float d = max(dot(N, normalize(uLight)), 0.0);\\n"\n'
     '    "  vec3 alb = vC * mix(vec3(1.0), texture2D(uTex, vUV).rgb, uTexMix);\\n"\n'
     '    "  float f = pow(1.0 - max(dot(N, V), 0.0), uRimPow);\\n"\n'
     '    "  gl_FragColor = vec4(alb * (0.25 + 0.70 * d) + uRim * f, 1.0);\\n"\n'
     '    "}\\n";',
     '    "varying vec3 vN; varying vec3 vC; varying vec2 vUV; varying vec3 vEye;\\n"\n'
     '    HW_FS_SHADOW_HELP\n'
     '    "uniform vec3 uLight; uniform sampler2D uTex; uniform float uTexMix;\\n"\n'
     '    "uniform vec3 uRim; uniform float uRimPow;\\n"\n'
     '    "void main(){\\n"\n'
     '    "  vec3 N = normalize(vN);\\n"\n'
     '    "  vec3 V = normalize(-vEye);\\n"\n'
     '    "  float d = max(dot(N, normalize(uLight)), 0.0);\\n"\n'
     '    "  d *= shadowOf(vEye);\\n"\n'
     '    "  vec3 alb = vC * mix(vec3(1.0), texture2D(uTex, vUV).rgb, uTexMix);\\n"\n'
     '    "  float f = pow(1.0 - max(dot(N, V), 0.0), uRimPow);\\n"\n'
     '    "  gl_FragColor = vec4(alb * (0.25 + 0.70 * d) + uRim * f, 1.0);\\n"\n'
     '    "}\\n";'),

    # 6. HW_FS_CHECKER 加阴影
    ('fs-checker',
     'static const char *HW_FS_CHECKER =\n'
     '    "#version 120\\n"\n'
     '    "varying vec3 vN; varying vec3 vC; varying vec2 vUV;\\n"\n'
     '    "uniform vec3 uLight; uniform float uScale; uniform vec3 uDark;\\n"\n'
     '    "void main(){\\n"\n'
     '    "  vec2 g = floor(vUV * uScale);\\n"\n'
     '    "  float k = mod(g.x + g.y, 2.0);\\n"\n'
     '    "  vec3 alb = mix(uDark, vC, k);\\n"\n'
     '    "  float d = max(dot(normalize(vN), normalize(uLight)), 0.0);\\n"\n'
     '    "  gl_FragColor = vec4(alb * (0.35 + 0.75 * d), 1.0);\\n"\n'
     '    "}\\n";',
     'static const char *HW_FS_CHECKER =\n'
     '    "#version 120\\n"\n'
     '    "varying vec3 vN; varying vec3 vC; varying vec2 vUV; varying vec3 vEye;\\n"\n'
     '    HW_FS_SHADOW_HELP\n'
     '    "uniform vec3 uLight; uniform float uScale; uniform vec3 uDark;\\n"\n'
     '    "void main(){\\n"\n'
     '    "  vec2 g = floor(vUV * uScale);\\n"\n'
     '    "  float k = mod(g.x + g.y, 2.0);\\n"\n'
     '    "  vec3 alb = mix(uDark, vC, k);\\n"\n'
     '    "  float d = max(dot(normalize(vN), normalize(uLight)), 0.0);\\n"\n'
     '    "  d *= shadowOf(vEye);\\n"\n'
     '    "  gl_FragColor = vec4(alb * (0.35 + 0.75 * d), 1.0);\\n"\n'
     '    "}\\n";'),

    # 7. draw_ops：阴影 pass 忽略切程序 / uniform
    ('ops-skip-prog',
     '        case OP_UNI:\n'
     '            hw_apply_uni(&g_unis[o->idx]);\n'
     '            break;',
     '        case OP_UNI:\n'
     '            if (!g_shadow_pass)                       /* 阴影 pass 只看几何 */\n'
     '                hw_apply_uni(&g_unis[o->idx]);\n'
     '            break;'),
    ('ops-skip-prog2',
     '        case OP_PROG: {\n'
     '            /* 帧中间切着色器：槽 0 = 回固定管线。',
     '        case OP_PROG: {\n'
     '            if (g_shadow_pass)                        /* 阴影 pass 不理会切程序 */\n'
     '                break;\n'
     '            /* 帧中间切着色器：槽 0 = 回固定管线。'),
    ('ops-shadow-unis',
     '                    for (int k2 = 0; k2 < i; k2++)\n'
     '                        if (g_ops[k2].type == OP_UNI)\n'
     '                            hw_apply_uni(&g_unis[g_ops[k2].idx]);',
     '                    for (int k2 = 0; k2 < i; k2++)\n'
     '                        if (g_ops[k2].type == OP_UNI)\n'
     '                            hw_apply_uni(&g_unis[g_ops[k2].idx]);\n'
     '                    hw_shadow_unis(np);               /* 切了程序也要重灌阴影 */'),

    # 8. rt_hw_frame：阴影 pass + 阴影纹理绑定 + uniform 灌入
    ('frame-shadow-pass',
     '    int post = 0;\n'
     '    if (g_post_on && hw_post_begin(winW, winH)) {\n'
     '        post = 1;\n'
     '        glViewport(0, 0, winW, winH);\n'
     '    }\n',
     '    int post = 0;\n'
     '    if (g_post_on && hw_post_begin(winW, winH)) {\n'
     '        post = 1;\n'
     '        glViewport(0, 0, winW, winH);\n'
     '    }\n'
     '\n'
     '    /* 阴影 pass：先把"从光源看过去"的深度渲进阴影贴图。\n'
     '       必须在主 pass 画任何东西之前 —— 主 pass 要查这张纹理。 */\n'
     '    if (g_shadow_on && hw_shadow_ensure())\n'
     '        hw_shadow_pass();\n'
     '    glViewport(0, 0, winW, winH);\n'),
    ('frame-shadow-bind',
     '        if (g_ulight[g_curprog] >= 0)\n'
     '            glapi.Uniform3f(g_ulight[g_curprog], g_lx, g_ly, g_lz);\n'
     '    }\n'
     '    draw_ops();',
     '        if (g_ulight[g_curprog] >= 0)\n'
     '            glapi.Uniform3f(g_ulight[g_curprog], g_lx, g_ly, g_lz);\n'
     '        hw_shadow_unis(g_bound_prog);      /* 灌光源矩阵 / 阴影采样器 */\n'
     '    }\n'
     '    if (g_shadow_on && g_shadow_tex != 0 && glapi.ActiveTexture != NULL) {\n'
     '        glapi.ActiveTexture(GL_TEXTURE2);  /* 阴影贴图固定在纹理单元 2 */\n'
     '        glBindTexture(GL_TEXTURE_2D, g_shadow_tex);\n'
     '        glapi.ActiveTexture(GL_TEXTURE0);\n'
     '    }\n'
     '    draw_ops();'),

    # 9. 阴影 API
    ('shadow-api',
     'Value rt_hw_fog(Value sv, Value ev)',
     SHADOW_API + 'Value rt_hw_fog(Value sv, Value ev)'),
]

PATCHES_FRONT = [
    ('front-libcalls',
     "    'hw.post': 1, 'hw.postfx': 2,\n",
     "    'hw.post': 1, 'hw.postfx': 2,\n"
     "    'hw.shadow': 1, 'hw.shadowres': 1, 'hw.shadowarea': 1,\n"
     "    'hw.shadowbias': 1, 'hw.shadowcenter': 3,\n"),
]

PATCHES_CODE = [
    ('code-names',
     "        'hw.post': 'rt_hw_post', 'hw.postfx': 'rt_hw_postfx',\n",
     "        'hw.post': 'rt_hw_post', 'hw.postfx': 'rt_hw_postfx',\n"
     "        'hw.shadow': 'rt_hw_shadow', 'hw.shadowres': 'rt_hw_shadowres',\n"
     "        'hw.shadowarea': 'rt_hw_shadowarea', 'hw.shadowbias': 'rt_hw_shadowbias',\n"
     "        'hw.shadowcenter': 'rt_hw_shadowcenter',\n"),
    ('code-protos',
     "           'wheel:0', 'textc:7', 'rect:7', 'post:1', 'postfx:2']\n",
     "           'wheel:0', 'textc:7', 'rect:7', 'post:1', 'postfx:2',\n"
     "           'shadow:1', 'shadowres:1', 'shadowarea:1', 'shadowbias:1', 'shadowcenter:3']\n"),
]


def patch(path, patches):
    s = io.open(path, encoding='utf-8', newline='').read()
    had_crlf = '\r\n' in s
    if had_crlf:
        s = s.replace('\r\n', '\n')
    for label, old, new in patches:
        n = s.count(old)
        if n != 1:
            sys.stderr.write('FAIL [%s] %s count=%d\n' % (label, os.path.basename(path), n))
            sys.exit(1)
        s = s.replace(old, new, 1)
        print('  ok  %s' % label)
    if had_crlf:
        s = s.replace('\r\n', '\n').replace('\n', '\r\n')
    io.open(path, 'w', encoding='utf-8', newline='').write(s)


ONLY = sys.argv[1:]
def want(tag):
    return (not ONLY) or (tag in ONLY)

if want('c'):
    print('pybook_hw3d.c:')
    patch(os.path.join(ROOT, 'pybook_hw3d.c'), PATCHES_C)
if want('front'):
    print('pybk_front.py:')
    patch(os.path.join(ROOT, 'pybk_front.py'), PATCHES_FRONT)
if want('code'):
    print('pybk_code.py:')
    patch(os.path.join(ROOT, 'pybk_code.py'), PATCHES_CODE)
print('done')
