from pathlib import Path
p = Path(r'C:\Users\zhuli\Desktop\pybook\pybook_m3d.c')
t = p.read_text(encoding='utf-8')

old1 = '''                        if (kind > 0 && x < M3_MAX) {
                            out->kind[x][y][z] = (unsigned char)kind;
                            if (kind == 1) {
                                out->rgb[x][y][z][0] = (unsigned char)r;
                                out->rgb[x][y][z][1] = (unsigned char)g;
                                out->rgb[x][y][z][2] = (unsigned char)b;
                            } else {
                                out->tex[x][y][z] = (unsigned char)ts;
                            }
                        }'''
new1 = '''                        if (kind > 0 && x < M3_MAX) {
                            out->kind[x][y][z] = (unsigned char)kind;
                            out->alpha[x][y][z] = 255;
                            if (kind == 1 || kind == 3 || kind == 4) {
                                out->rgb[x][y][z][0] = (unsigned char)r;
                                out->rgb[x][y][z][1] = (unsigned char)g;
                                out->rgb[x][y][z][2] = (unsigned char)b;
                                if (kind >= 3) {
                                    M3Special *sp = m3_find_special(t3);
                                    if (sp) out->alpha[x][y][z] = (unsigned char)(sp->alpha * 255.0f + 0.5f);
                                }
                            } else {
                                out->tex[x][y][z] = (unsigned char)ts;
                            }
                        }'''

old2 = '''                    if (kind > 0 && x < M3_MAX) {
                        out->kind[x][y][z] = (unsigned char)kind;
                        if (kind == 1) {
                            out->rgb[x][y][z][0] = (unsigned char)r;
                            out->rgb[x][y][z][1] = (unsigned char)g;
                            out->rgb[x][y][z][2] = (unsigned char)b;
                        } else {
                            out->tex[x][y][z] = (unsigned char)ts;
                        }
                    }'''

new2 = '''                    if (kind > 0 && x < M3_MAX) {
                        out->kind[x][y][z] = (unsigned char)kind;
                        out->alpha[x][y][z] = 255;
                        if (kind == 1 || kind == 3 || kind == 4) {
                            out->rgb[x][y][z][0] = (unsigned char)r;
                            out->rgb[x][y][z][1] = (unsigned char)g;
                            out->rgb[x][y][z][2] = (unsigned char)b;
                            if (kind >= 3) {
                                M3Special *sp = m3_find_special(tok);
                                if (sp) out->alpha[x][y][z] = (unsigned char)(sp->alpha * 255.0f + 0.5f);
                            }
                        } else {
                            out->tex[x][y][z] = (unsigned char)ts;
                        }
                    }'''

# char-mode single-byte path uses t2, not tok — fix that site separately after
print('old1', t.count(old1), 'old2', t.count(old2))
t = t.replace(old1, new1)
print('old2 after', t.count(old2))

# remaining two old2: first is t2 path (single char), second is tok (token mode)
# Fix the t2 one: replace out->tex with same but t2 for special
idx = t.find(old2)
if idx >= 0:
    # This is the t2 site - use t2
    alt = new2.replace('m3_find_special(tok)', 'm3_find_special(t2)')
    t = t[:idx] + alt + t[idx+len(old2):]
    print('patched t2 site')

idx = t.find(old2)
if idx >= 0:
    t = t[:idx] + new2 + t[idx+len(old2):]
    print('patched tok site')

p.write_text(t, encoding='utf-8')
print('done', t.count('out->alpha[x][y][z]'))
