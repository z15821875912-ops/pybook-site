# -*- coding: utf-8 -*-
"""修出图开关的三个问题（幂等补丁）：
  1. 不创建目录 → fopen 静默失败
  2. 失败后仍打印「看起来成功」的 "[shot] xxx.bmp (WxH)"，把错误盖住
  3. 失败后每 N 帧重试一次，一路刷屏
"""
import io, sys

P = r'C:\Users\zhuli\Desktop\pybook\pybook_hw3d.c'
s = io.open(P, encoding='utf-8').read()

PATCHES = []

# ---- 1. 跨平台建目录 ----
PATCHES.append(('建目录宏',
'''static int  g_shot_on    = 0;''',
'''#ifdef _WIN32
#  include <direct.h>
#  define HW_SHOT_MKDIR(p) _mkdir(p)
#else
#  include <sys/stat.h>
#  include <sys/types.h>
#  define HW_SHOT_MKDIR(p) mkdir(p, 0755)
#endif

static int  g_shot_on    = 0;'''))

# ---- 2. hw_shot_bmp 改成返回成功与否 ----
PATCHES.append(('bmp 签名+失败返回',
'''static void hw_shot_bmp(const char *path, int W, int H, const unsigned char *rgb)
{
    FILE *f = fopen(path, "wb");
    if (f == NULL) { fprintf(stderr, "[shot] 打不开 %s\\n", path); return; }''',
'''static int hw_shot_bmp(const char *path, int W, int H, const unsigned char *rgb)
{
    FILE *f = fopen(path, "wb");
    if (f == NULL) {
        fprintf(stderr, "[shot] 打不开 %s（目录不存在或不可写？）\\n", path);
        return 0;
    }'''))

PATCHES.append(('bmp 内存失败返回',
'''    if (line == NULL) { fclose(f); return; }''',
'''    if (line == NULL) { fclose(f); return 0; }'''))

PATCHES.append(('bmp 末尾返回成功',
'''    free(line);
    fclose(f);
}''',
'''    free(line);
    fclose(f);
    return 1;
}'''))

# ---- 3. init 里把目录建出来 ----
PATCHES.append(('init 建目录',
'''    snprintf(g_shot_dir, sizeof g_shot_dir, "%s", d);
    const char *e = getenv("PYBOOK_SHOT_EVERY");''',
'''    snprintf(g_shot_dir, sizeof g_shot_dir, "%s", d);
    /* 自己把目录建出来：不建的话 fopen 直接失败，而这个失败很容易被
       后面那行「看起来成功」的 [shot] xxx.bmp (WxH) 盖住，白找半天。
       目录已存在时 _mkdir 返回非 0，忽略即可（多级路径 a/b/c 仍需自己先建好）。 */
    (void)HW_SHOT_MKDIR(g_shot_dir);
    const char *e = getenv("PYBOOK_SHOT_EVERY");'''))

# ---- 4. 失败要显眼 + 停止重试 ----
PATCHES.append(('失败处理',
'''    hw_shot_bmp(path, W, H, buf);
    free(buf);
    printf("[shot] %s  (%dx%d)\\n", path, W, H);
    fflush(stdout);
    g_shot_taken++;''',
'''    int ok = hw_shot_bmp(path, W, H, buf);
    free(buf);
    if (ok) {
        printf("[shot] %s  (%dx%d)\\n", path, W, H);
        fflush(stdout);
        g_shot_taken++;
    } else {
        fprintf(stderr, "[shot] 出图失败 —— 已关掉出图开关（先把目录修好再跑）\\n");
        fflush(stderr);
        g_shot_on = 0;          /* 别每 N 帧重试一次刷屏 */
    }'''))

for label, old, new in PATCHES:
    n = s.count(old)
    if n != 1:
        sys.stderr.write('FAIL [%s] count=%d\n' % (label, n))
        sys.exit(1)
    s = s.replace(old, new, 1)
    print('ok  ' + label)

io.open(P, 'w', encoding='utf-8', newline='').write(s)
print('\n写入完成 %d 行' % (s.count('\n') + 1))
