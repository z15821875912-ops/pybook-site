# -*- coding: utf-8 -*-
"""全量 --check 前后对比：证明这次移植对老用例零回归。

把仓库里所有 .pybk 用例，用**改动前的备份**和**当前版**各跑一遍 --check，
逐条比退出码。只打印"两边不一致"的行 —— 一致就说明没动到它。

⚠ try/finally 保证 front / code 一定还原，中途报错也不会留下改了一半的仓库。
   发布包快照目录（发布打包_102）故意不扫：那里的 .pybk 是旧版快照，
   本来就会大面积失败，混进来只会淹没真信号。
"""
import glob
import os
import shutil
import subprocess
import sys

PY = r'C:\Users\zhuli\.workbuddy\binaries\python\versions\3.13.12\python.exe'
ROOT = r'C:\Users\zhuli\Desktop\pybook'
PATS = ('tests/*.pybk', '_stdlib_v2/*.pybk', '星核特效/*.pybk', '*.pybk')


def discover():
    out = []
    for pat in PATS:
        out += glob.glob(os.path.join(ROOT, pat))
    return sorted(set(out))


def check(path):
    r = subprocess.run([PY, 'pybk_main.py', '--check', path],
                       cwd=ROOT, capture_output=True)
    return r.returncode


def main():
    files = discover()
    print('共发现 %d 个用例，跑两遍（改动前 / 改动后）...' % len(files))
    swapped = False
    try:
        shutil.copy(os.path.join(ROOT, 'pybk_front.py'), os.path.join(ROOT, '_cur_front.py'))
        shutil.copy(os.path.join(ROOT, 'pybk_code.py'), os.path.join(ROOT, '_cur_code.py'))
        shutil.copy(os.path.join(ROOT, 'pybk_front.py.bak_post'), os.path.join(ROOT, 'pybk_front.py'))
        shutil.copy(os.path.join(ROOT, 'pybk_code.py.bak_post'), os.path.join(ROOT, 'pybk_code.py'))
        swapped = True
        before = {f: check(f) for f in files}
        print('  改动前跑完')
    finally:
        if swapped:
            shutil.copy(os.path.join(ROOT, '_cur_front.py'), os.path.join(ROOT, 'pybk_front.py'))
            shutil.copy(os.path.join(ROOT, '_cur_code.py'), os.path.join(ROOT, 'pybk_code.py'))
            for junk in ('_cur_front.py', '_cur_code.py'):
                p = os.path.join(ROOT, junk)
                if os.path.exists(p):
                    os.remove(p)

    after = {f: check(f) for f in files}
    print('  改动后跑完')
    print()

    diff = []
    for f in files:
        b, a = before[f], after[f]
        if b != a:
            diff.append((f, b, a))
    for f, b, a in diff:
        print('差异  %-42s 前=%d 后=%d' % (os.path.relpath(f, ROOT), b, a))
    print()
    print('用例 %d 个：改动前通过 %d / 改动后通过 %d / 结果不一致 %d 个'
          % (len(files),
             sum(1 for v in before.values() if v == 0),
             sum(1 for v in after.values() if v == 0),
             len(diff)))
    return 1 if diff else 0


if __name__ == '__main__':
    sys.exit(main())
