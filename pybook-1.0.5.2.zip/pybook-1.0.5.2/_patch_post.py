# -*- coding: utf-8 -*-
"""Task #23：FBO 离屏渲染底座 + 全屏后处理通道。
幂等：每处锚点断言 count == 1，改完一次性写回（避免 Edit 并行互相覆盖）。"""
import io, sys, os

ROOT = r'C:\Users\zhuli\Desktop\pybook'

# ---------------------------------------------------------------- C 全局块
C_GLOBALS = r'''
/* ---- 离屏渲染 + 后处理（hw.post / hw.postfx）----
   把整帧 3D 画面先渲进一张离屏纹理，再用一个全屏 quad 采样它上屏。
   好处：凡是"对整帧统一处理"的效果（曝光 / 暗角 / bloom / 色调映射）
   都退化成"换一段片段着色器"，一行几何代码都不用动。
   默认关闭：关着时走的还是原来那条直通路径，老程序零回归、零开销。 */
static int    g_post_on   = 0;      /* hw.post(1) 之后才走离屏通道 */
static double g_exposure  = 1.0;    /* hw.postfx 第 1 参：曝光 */
static double g_vignette  = 0.0;    /* hw.postfx 第 2 参：暗角 */
static double g_bloom     = 0.0;    /* hw.bloom 强度（0 = 关，留给下一步） */
static GLuint g_bloom_tex = 0;      /* bloom 结果纹理（合成阶段在单元 1 采样） */
static GLuint g_fbo_scene = 0;      /* 场景 FBO */
static GLuint g_fbo_sctex = 0;      /* 颜色附着（用纹理：后面要采样它） */
static GLuint g_fbo_scdep = 0;      /* 深度附着（用 renderbuffer：从不采样） */
static int    g_fbo_w = 0, g_fbo_h = 0;
static GLuint g_post_prog = 0;      /* 全屏合成程序（首次真正用到才编译） */
static int    g_post_fail = 0;      /* 编译或建 FBO 失败过：别每帧重试刷屏 */

/* FBO 常量：老 gl.h 只到 GL 1.1，这里兜底；glext.h 已定义时 #ifndef 会跳过。 */
#ifndef GL_FRAMEBUFFER
#define GL_FRAMEBUFFER 0x8D40
#endif
#ifndef GL_COLOR_ATTACHMENT0
#define GL_COLOR_ATTACHMENT0 0x8CE0
#endif
#ifndef GL_DEPTH_ATTACHMENT
#define GL_DEPTH_ATTACHMENT 0x8D00
#endif
#ifndef GL_RENDERBUFFER
#define GL_RENDERBUFFER 0x8D41
#endif
#ifndef GL_DEPTH_COMPONENT24
#define GL_DEPTH_COMPONENT24 0x81A6
#endif
#ifndef GL_FRAMEBUFFER_COMPLETE
#define GL_FRAMEBUFFER_COMPLETE 0x8CD5
#endif
#ifndef GL_CLAMP_TO_EDGE
#define GL_CLAMP_TO_EDGE 0x812F
#endif
#ifndef GL_RGBA8
#define GL_RGBA8 0x8058
#endif
#ifndef GL_TEXTURE1
#define GL_TEXTURE1 0x84C1
#endif
'''

# ---------------------------------------------------------------- C 实现块
C_IMPL = r'''
/* ================= 离屏渲染 + 全屏后处理 =================
   这一段是"阴影贴图 / bloom / PBR"三件事的共同底座：只要能离屏渲染，
   就只需要再加"离屏那张纹理怎么算"。 */

static void hw_post_drop(void)
{
    if (g_fbo_scene != 0 && glapi.DeleteFramebuffers)
        glapi.DeleteFramebuffers(1, &g_fbo_scene);
    if (g_fbo_sctex != 0)
        glDeleteTextures(1, &g_fbo_sctex);
    if (g_fbo_scdep != 0 && glapi.DeleteRenderbuffers)
        glapi.DeleteRenderbuffers(1, &g_fbo_scdep);
    g_fbo_scene = 0; g_fbo_sctex = 0; g_fbo_scdep = 0;
    g_fbo_w = 0; g_fbo_h = 0;
}

/* 全屏 quad 的顶点阶段：直接拿 gl_Vertex 当裁剪坐标（不乘任何矩阵），
   UV 从 gl_MultiTexCoord0 来 —— 于是这个 quad 只要给 (-1,-1)~(1,1) 四点，
   连"正交矩阵"都不用设。 */
static const char *HW_POST_VS =
    "#version 120\n"
    "varying vec2 vUV;\n"
    "void main(){\n"
    "  vUV = gl_MultiTexCoord0.xy;\n"
    "  gl_Position = gl_Vertex;\n"
    "}\n";

/* 合成：场景色 + bloom（可选）→ 曝光 → 暗角。
   uBloom = 0 时那一项完全不起作用，所以本版不开 bloom 也不会串味。 */
static const char *HW_POST_FS =
    "#version 120\n"
    "varying vec2 vUV;\n"
    "uniform sampler2D uTex;\n"
    "uniform sampler2D uBloomTex;\n"
    "uniform float uExposure;\n"
    "uniform float uVignette;\n"
    "uniform float uBloom;\n"
    "void main(){\n"
    "  vec3 c = texture2D(uTex, vUV).rgb;\n"
    "  if (uBloom > 0.0) c += texture2D(uBloomTex, vUV).rgb * uBloom;\n"
    "  c *= uExposure;\n"
    "  vec2 d = vUV - vec2(0.5);\n"
    "  c *= clamp(1.0 - uVignette * dot(d, d) * 2.5, 0.0, 1.0);\n"
    "  gl_FragColor = vec4(c, 1.0);\n"
    "}\n";

/* 绑上场景 FBO 并保证尺寸对。返回 0 = 这条通道用不了（调用方走直通路径）。 */
static int hw_post_begin(int w, int h)
{
    if (!g_gl_ok || glapi.GenFramebuffers == NULL || glapi.BindFramebuffer == NULL ||
        glapi.FramebufferTexture2D == NULL || glapi.FramebufferRenderbuffer == NULL ||
        glapi.GenRenderbuffers == NULL || glapi.BindRenderbuffer == NULL ||
        glapi.RenderbufferStorage == NULL)
        return 0;
    if (w <= 0 || h <= 0)
        return 0;

    if (g_post_prog == 0) {
        if (g_post_fail)
            return 0;
        char log[512];
        g_post_prog = hw_build_program(HW_POST_VS, HW_POST_FS, log, sizeof log);
        if (g_post_prog == 0) {
            fprintf(stderr, "[post] 合成着色器编译失败：%s\n", log);
            fflush(stderr);
            g_post_fail = 1;
            return 0;
        }
        /* uTex 在 hw_build_program 里已约定为单元 0；这里把 bloom 纹理指到单元 1。 */
        hw_setu(g_post_prog, "uBloomTex", 1, 1.0f, 0.0f, 0.0f, 0.0f);
    }

    if (g_fbo_scene == 0 || w != g_fbo_w || h != g_fbo_h) {
        hw_post_drop();
        glGenTextures(1, &g_fbo_sctex);
        glBindTexture(GL_TEXTURE_2D, g_fbo_sctex);
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, NULL);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
        glBindTexture(GL_TEXTURE_2D, 0);

        glapi.GenRenderbuffers(1, &g_fbo_scdep);
        glapi.BindRenderbuffer(GL_RENDERBUFFER, g_fbo_scdep);
        glapi.RenderbufferStorage(GL_RENDERBUFFER, GL_DEPTH_COMPONENT24, w, h);
        glapi.BindRenderbuffer(GL_RENDERBUFFER, 0);

        glapi.GenFramebuffers(1, &g_fbo_scene);
        glapi.BindFramebuffer(GL_FRAMEBUFFER, g_fbo_scene);
        glapi.FramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0,
                                   GL_TEXTURE_2D, g_fbo_sctex, 0);
        glapi.FramebufferRenderbuffer(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT,
                                      GL_RENDERBUFFER, g_fbo_scdep);
        GLenum st = glapi.CheckFramebufferStatus(GL_FRAMEBUFFER);
        if (st != GL_FRAMEBUFFER_COMPLETE) {
            fprintf(stderr, "[post] FBO 不完整（0x%X）—— 关掉后处理通道\n",
                    (unsigned)st);
            fflush(stderr);
            glapi.BindFramebuffer(GL_FRAMEBUFFER, 0);
            hw_post_drop();
            g_post_fail = 1;
            return 0;
        }
        g_fbo_w = w; g_fbo_h = h;
        printf("[post] 离屏通道 %dx%d 就绪\n", w, h);
        fflush(stdout);
        return 1;
    }
    glapi.BindFramebuffer(GL_FRAMEBUFFER, g_fbo_scene);
    return 1;
}

/* 解绑 FBO，用一个全屏 quad 把离屏画面合成到后缓冲。 */
static void hw_post_end(int w, int h)
{
    glapi.BindFramebuffer(GL_FRAMEBUFFER, 0);
    glViewport(0, 0, w, h);

    /* 合成阶段必须干净：不带深度、不带雾、不带混合（HUD 在其后才压上去）。 */
    glDisable(GL_DEPTH_TEST);
    glDisable(GL_FOG);
    glDisable(GL_BLEND);
    glDisable(GL_ALPHA_TEST);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    glapi.UseProgram(g_post_prog);
    g_bound_prog = g_post_prog;
    {
        GLint l = glapi.GetUniformLocation(g_post_prog, "uExposure");
        if (l >= 0) glapi.Uniform1f(l, (GLfloat)g_exposure);
        l = glapi.GetUniformLocation(g_post_prog, "uVignette");
        if (l >= 0) glapi.Uniform1f(l, (GLfloat)g_vignette);
        l = glapi.GetUniformLocation(g_post_prog, "uBloom");
        if (l >= 0) glapi.Uniform1f(l, (GLfloat)g_bloom);
    }
    if (glapi.ActiveTexture != NULL) {
        glapi.ActiveTexture(GL_TEXTURE1);            /* bloom 结果（没有就是 0） */
        glBindTexture(GL_TEXTURE_2D, g_bloom_tex);
        glapi.ActiveTexture(GL_TEXTURE0);
    }
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, g_fbo_sctex);
    glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
    glBegin(GL_QUADS);
    glTexCoord2f(0.0f, 0.0f); glVertex2f(-1.0f, -1.0f);
    glTexCoord2f(1.0f, 0.0f); glVertex2f( 1.0f, -1.0f);
    glTexCoord2f(1.0f, 1.0f); glVertex2f( 1.0f,  1.0f);
    glTexCoord2f(0.0f, 1.0f); glVertex2f(-1.0f,  1.0f);
    glEnd();

    glapi.UseProgram(0);
    g_bound_prog = 0;
    glBindTexture(GL_TEXTURE_2D, 0);
    glDisable(GL_TEXTURE_2D);
}

'''

C_API = r'''/* ---- 后处理通道开关与参数 ----
   默认值是"什么都不做"：post 关着时这条路径整个不启用。 */
Value rt_hw_post(Value vv)
{
    g_post_on = hw_num(vv, "hw.post 的开关") > 0.5 ? 1 : 0;
    return rt_none();
}

Value rt_hw_postfx(Value ev, Value vv)
{
    g_exposure = hw_num(ev, "hw.postfx 的曝光");
    g_vignette = hw_num(vv, "hw.postfx 的暗角");
    return rt_none();
}

'''

PATCHES_C = [
    # 1. HwGL 结构体补入口
    ('struct-fbo-entries',
     '    PFNGLRENDERBUFFERSTORAGEPROC    RenderbufferStorage;\n} HwGL;',
     '    PFNGLRENDERBUFFERSTORAGEPROC    RenderbufferStorage;\n'
     '    /* 后处理 / 阴影贴图必需：RBO 挂深度、删对象、传矩阵 */\n'
     '    PFNGLFRAMEBUFFERRENDERBUFFERPROC FramebufferRenderbuffer;\n'
     '    PFNGLDELETEFRAMEBUFFERSPROC      DeleteFramebuffers;\n'
     '    PFNGLDELETERENDERBUFFERSPROC     DeleteRenderbuffers;\n'
     '    PFNGLUNIFORMMATRIX4FVPROC        UniformMatrix4fv;\n} HwGL;'),
    # 2. hw_gl_load 里取这些入口
    ('load-fbo-entries',
     '    HW_GET(RenderbufferStorage,   PFNGLRENDERBUFFERSTORAGEPROC, "glRenderbufferStorage");\n#undef HW_GET',
     '    HW_GET(RenderbufferStorage,   PFNGLRENDERBUFFERSTORAGEPROC, "glRenderbufferStorage");\n'
     '    HW_GET(FramebufferRenderbuffer, PFNGLFRAMEBUFFERRENDERBUFFERPROC, "glFramebufferRenderbuffer");\n'
     '    HW_GET(DeleteFramebuffers,    PFNGLDELETEFRAMEBUFFERSPROC,  "glDeleteFramebuffers");\n'
     '    HW_GET(DeleteRenderbuffers,   PFNGLDELETERENDERBUFFERSPROC, "glDeleteRenderbuffers");\n'
     '    HW_GET(UniformMatrix4fv,      PFNGLUNIFORMMATRIX4FVPROC,    "glUniformMatrix4fv");\n'
     '#undef HW_GET'),
    # 3. 全局状态
    ('post-globals',
     'static GLuint g_white_tex  = 0;   /* 1x1 白纹理：着色器模式没贴图时顶上去 */\n',
     'static GLuint g_white_tex  = 0;   /* 1x1 白纹理：着色器模式没贴图时顶上去 */\n'
     + C_GLOBALS),
    # 4. 实现块
    ('post-impl',
     '/* 按提交顺序执行命令流。push/pop 直接映射到 GL 的矩阵栈。',
     C_IMPL + '/* 按提交顺序执行命令流。push/pop 直接映射到 GL 的矩阵栈。'),
    # 5. rt_hw_frame：进去之前绑 FBO
    ('frame-enter',
     '    SDL_GetWindowSize(g_win, &winW, &winH);   /* 窗口可拉伸：视口跟随 */\n'
     '    glViewport(0, 0, winW, winH);\n',
     '    SDL_GetWindowSize(g_win, &winW, &winH);   /* 窗口可拉伸：视口跟随 */\n'
     '    glViewport(0, 0, winW, winH);\n'
     '\n'
     '    /* 后处理通道：整帧渲进离屏 FBO，末尾再全屏合成上屏。\n'
     '       默认关着 —— 老程序一行不改就是原来那条直通路径。 */\n'
     '    int post = 0;\n'
     '    if (g_post_on && hw_post_begin(winW, winH)) {\n'
     '        post = 1;\n'
     '        glViewport(0, 0, winW, winH);\n'
     '    }\n'),
    # 6. rt_hw_frame：3D 画完之后合成
    ('frame-leave',
     '    draw_ops();\n'
     '    if (g_bound_prog != 0) {\n'
     '        glapi.UseProgram(0);\n'
     '        g_bound_prog = 0;\n'
     '    }\n',
     '    draw_ops();\n'
     '    if (g_bound_prog != 0) {\n'
     '        glapi.UseProgram(0);\n'
     '        g_bound_prog = 0;\n'
     '    }\n'
     '\n'
     '    /* 后处理：解绑 FBO，全屏 quad 把离屏画面合成到后缓冲。\n'
     '       顺序很关键 —— 合成必须在 HUD 之前，HUD 才不会被一起曝光/暗角。 */\n'
     '    if (post)\n'
     '        hw_post_end(winW, winH);\n'),
    # 7. 两个新 API
    ('post-api',
     'Value rt_hw_fog(Value sv, Value ev)',
     C_API + 'Value rt_hw_fog(Value sv, Value ev)'),
]

PATCHES_FRONT = [
    ('front-libcalls',
     "    'hw.textc': 7, 'hw.rect': 7,\n",
     "    'hw.textc': 7, 'hw.rect': 7,\n"
     "    'hw.post': 1, 'hw.postfx': 2,\n"),
]

PATCHES_CODE = [
    ('code-names',
     "        'hw.textc': 'rt_hw_textc', 'hw.rect': 'rt_hw_rect',\n",
     "        'hw.textc': 'rt_hw_textc', 'hw.rect': 'rt_hw_rect',\n"
     "        'hw.post': 'rt_hw_post', 'hw.postfx': 'rt_hw_postfx',\n"),
    ('code-protos',
     "           'wheel:0', 'textc:7', 'rect:7']\n",
     "           'wheel:0', 'textc:7', 'rect:7', 'post:1', 'postfx:2']\n"),
]


def patch(path, patches):
    s = io.open(path, encoding='utf-8', newline='').read()
    had_crlf = '\r\n' in s
    if had_crlf:                       # 锚点统一按 LF 写，读完先归一
        s = s.replace('\r\n', '\n')
    for label, old, new in patches:
        n = s.count(old)
        if n != 1:
            sys.stderr.write('FAIL [%s] %s count=%d\n' % (label, os.path.basename(path), n))
            sys.exit(1)
        s = s.replace(old, new, 1)
        print('  ok  %s' % label)
    if had_crlf:
        s = s.replace('\r\n', '\n').replace('\n', '\r\n')
    io.open(path, 'w', encoding='utf-8', newline='').write(s)


ONLY = sys.argv[1:]
def want(tag):
    return (not ONLY) or (tag in ONLY)

if want('c'):
    print('pybook_hw3d.c:')
    patch(os.path.join(ROOT, 'pybook_hw3d.c'), PATCHES_C)
if want('front'):
    print('pybk_front.py:')
    patch(os.path.join(ROOT, 'pybk_front.py'), PATCHES_FRONT)
if want('code'):
    print('pybk_code.py:')
    patch(os.path.join(ROOT, 'pybk_code.py'), PATCHES_CODE)
print('done')
