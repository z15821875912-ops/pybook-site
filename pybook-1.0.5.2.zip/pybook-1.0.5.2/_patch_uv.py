from pathlib import Path
p = Path(r'C:\Users\zhuli\Desktop\pybook\pybook_hw3d.c')
t = p.read_text(encoding='utf-8')
# Only replace face UV calls that use 0/U pattern in draw_box (not HUD)
# Use u0,v0 offsets from box
old_pairs = [
    ('glTexCoord2f(0, 0);', 'glTexCoord2f(u0, v0);'),
    ('glTexCoord2f(0, U);', 'glTexCoord2f(u0, v0 + U);'),
    ('glTexCoord2f(U, U);', 'glTexCoord2f(u0 + U, v0 + U);'),
    ('glTexCoord2f(U, 0);', 'glTexCoord2f(u0 + U, v0);'),
]
# Careful: line 2306 is HUD - don't change those if they use 0,0 with i
# The HUD one is glTexCoord2f(0, 0); glVertex2i - same string.
# Split by context: only replace inside draw_box region
start = t.find('static void draw_box')
end = t.find('static void hw_bind_tex')
if start < 0 or end < 0:
    raise SystemExit(f'markers not found {start} {end}')
region = t[start:end]
n = 0
for a, b in old_pairs:
    n += region.count(a)
    region = region.replace(a, b)
t = t[:start] + region + t[end:]
# add u0/v0 locals after U is defined
t = t.replace(
    'float U = b->uv > 0.0f ? b->uv : 1.0f;',
    'float U = b->uv > 0.0f ? b->uv : 1.0f;\n    float u0 = b->uoff, v0 = b->voff;'
)
# boxn: store uoff/voff from globals
t = t.replace(
    'b->alpha = g_cur_alpha;\n    b->spec  = g_cur_spec;',
    'b->alpha = g_cur_alpha;\n    b->spec  = g_cur_spec;\n    b->uoff = g_cur_uoff;\n    b->voff = g_cur_voff;'
)
t = t.replace(
    'static float  g_cur_spec  = 0.0f; /* 当前镜面强度（金属） */',
    'static float  g_cur_spec  = 0.0f; /* 当前镜面强度（金属） */\nstatic float  g_cur_uoff = 0.0f, g_cur_voff = 0.0f; /* UV 偏移 */'
)
t = t.replace(
    '    g_cur_alpha = 1.0f;\n    g_cur_spec = 0.0f;',
    '    g_cur_alpha = 1.0f;\n    g_cur_spec = 0.0f;\n    g_cur_uoff = g_cur_voff = 0.0f;'
)
# reset uoff after each box submission so next doesn't inherit? sticky like uv - m3 sets each voxel
p.write_text(t, encoding='utf-8')
print('uv replacements', n)
