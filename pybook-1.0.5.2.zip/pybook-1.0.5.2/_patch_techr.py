# -*- coding: utf-8 -*-
"""加 te.chr(码点) → 一个字符的文本（UTF-8）。

为什么必须有它：PYbook 的字符串**不支持转义序列**（实测 长度("\\r") == 2），
所以脚本里发不出换行/回车字节 —— tw.board 的看板挤成一行、发不了合法 HTTP，
都是卡在这。te.chr(10) 是换行、te.chr(13) 是回车，唯一出口。
幂等：每处锚点断言 count == 1，改完一次性写回。"""
import io, sys, os

ROOT = r'C:\Users\zhuli\Desktop\pybook'

TE_CHR_IMPL = r'''
/* te.chr(码点) → 一个字符的文本（UTF-8 编码）。
   这是 PYbook 字符串**没有转义序列**的唯一出口：
   te.chr(10) 换行、te.chr(13) 回车 —— 源码里写 "\n" 只会得到两个字符。
   码点按标准 UTF-8 编码（1~4 字节），所以 te.chr(20013) 就是"中"。 */
Value rt_lib_te_chr(Value nv)
{
    long long cp = (long long)lib_num(nv, "te.chr 的码点");
    if (cp < 0 || cp > 0x10FFFF)
        lib_die("te.chr：码点要在 0~%lld 之间", (long long)0x10FFFF);
    if (cp >= 0xD800 && cp <= 0xDFFF)
        lib_die("te.chr：0xD800~0xDFFF 是 UTF-16 代理区，不是有效码点");
    char buf[5];
    int k;
    if (cp < 0x80) {
        buf[0] = (char)cp;
        k = 1;
    } else if (cp < 0x800) {
        buf[0] = (char)(0xC0 | (cp >> 6));
        buf[1] = (char)(0x80 | (cp & 0x3F));
        k = 2;
    } else if (cp < 0x10000) {
        buf[0] = (char)(0xE0 | (cp >> 12));
        buf[1] = (char)(0x80 | ((cp >> 6) & 0x3F));
        buf[2] = (char)(0x80 | (cp & 0x3F));
        k = 3;
    } else {
        buf[0] = (char)(0xF0 | (cp >> 18));
        buf[1] = (char)(0x80 | ((cp >> 12) & 0x3F));
        buf[2] = (char)(0x80 | ((cp >> 6) & 0x3F));
        buf[3] = (char)(0x80 | (cp & 0x3F));
        k = 4;
    }
    buf[k] = '\0';
    return rt_str(buf);
}

'''

TE_CHR_TEST = r'''    /* ---- te.chr ---- */
    CHECK(str_eq(rt_lib_te_chr(rt_int(10)), "\n"), "te.chr: 换行");
    CHECK(str_eq(rt_lib_te_chr(rt_int(13)), "\r"), "te.chr: 回车");
    CHECK(str_eq(rt_lib_te_chr(rt_int(65)), "A"), "te.chr: ASCII");
    CHECK(str_eq(rt_lib_te_chr(rt_int(0x4E2D)), "\xE4\xB8\xAD"), "te.chr: 中文码点→UTF-8");
    CHECK(str_eq(rt_lib_te_join(mklist(3, rt_str("a"), rt_str("b"), rt_str("c")),
                                rt_lib_te_chr(rt_int(10))), "a\nb\nc"),
          "te.chr: 当行分隔符用");

'''

PATCHES = {
    'pybook_lib.h': [
        ('hdr-decl',
         "Value rt_lib_te_join(Value list, Value sep);      /* 元素转文本后拼接 */\n",
         "Value rt_lib_te_join(Value list, Value sep);      /* 元素转文本后拼接 */\n"
         "Value rt_lib_te_chr(Value n);                    /* 码点 → 一个字符（UTF-8）*/\n"),
    ],
    'pybook_lib.c': [
        ('impl',
         "/* ================= mt 数学模块 ================= */",
         TE_CHR_IMPL.lstrip('\n') +
         "/* ================= mt 数学模块 ================= */"),
        ('selftest',
         "    /* ---- mt.sqrt / mt.pow ---- */",
         TE_CHR_TEST + "    /* ---- mt.sqrt / mt.pow ---- */"),
    ],
    'pybk_front.py': [
        ('libcalls',
         "    'te.len': 1, 'te.cut': 3, 'te.join': 2,\n",
         "    'te.len': 1, 'te.cut': 3, 'te.join': 2, 'te.chr': 1,\n"),
    ],
    'pybk_code.py': [
        ('cnames',
         "        'te.join': 'rt_lib_te_join',\n",
         "        'te.join': 'rt_lib_te_join', 'te.chr': 'rt_lib_te_chr',\n"),
    ],
}


def patch(path, patches):
    s = io.open(path, encoding='utf-8', newline='').read()
    had_crlf = '\r\n' in s
    if had_crlf:
        s = s.replace('\r\n', '\n')
    for label, old, new in patches:
        n = s.count(old)
        if n != 1:
            sys.stderr.write('FAIL [%s] %s count=%d\n' % (label, os.path.basename(path), n))
            sys.exit(1)
        s = s.replace(old, new, 1)
        print('  ok  %s' % label)
    if had_crlf:
        s = s.replace('\r\n', '\n').replace('\n', '\r\n')
    io.open(path, 'w', encoding='utf-8', newline='').write(s)


for fn, pats in PATCHES.items():
    print(fn + ':')
    patch(os.path.join(ROOT, fn), pats)
print('done')
