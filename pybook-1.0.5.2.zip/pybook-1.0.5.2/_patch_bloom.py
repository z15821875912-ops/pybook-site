# -*- coding: utf-8 -*-
"""Task #25：Bloom 后处理链（亮度提取 → 水平模糊 → 垂直模糊 → 合成）。
依赖 Task #23 的离屏通道：场景已经在 g_fbo_sctex 里，合成段已经留好 uBloom/uBloomTex。
幂等：每处锚点断言 count == 1，改完一次性写回。"""
import io, sys, os

ROOT = r'C:\Users\zhuli\Desktop\pybook'

# ---------------------------------------------------------------- Bloom 全局
BLOOM_GLOBALS = r'''
/* ---- bloom（hw.bloom）----
   流程：场景色 → 亮度提取（阈值以上才留）→ 水平模糊 → 垂直模糊 → 合成。
   模糊用的是可分离高斯（一次横一次竖，各 9 tap），所以两张半分辨率
   ping-pong 纹理就够，不用叠一堆 FBO。半分辨率是省一半带宽还更好看。 */
static double g_bloom_thr  = 0.6;    /* 亮度阈值：低于它的像素不参与辉光 */
static GLuint g_fbo_b1 = 0, g_b1_tex = 0;
static GLuint g_fbo_b2 = 0, g_b2_tex = 0;
static int    g_bw = 0, g_bh = 0;
static GLuint g_bright_prog = 0, g_blur_prog = 0;
static int    g_bloom_fail = 0;
'''

# ---------------------------------------------------------------- 着色器
BLOOM_SHADERS = r'''
/* 亮度提取：只留比阈值亮的部分（超过阈值的部分原样过，低于阈值直接归零）。
   用 smoothstep 做软过渡，免得阈值附近出现硬边。 */
static const char *HW_BLOOM_BRIGHT_FS =
    "#version 120\n"
    "varying vec2 vUV;\n"
    "uniform sampler2D uTex;\n"
    "uniform float uThresh;\n"
    "void main(){\n"
    "  vec3 c = texture2D(uTex, vUV).rgb;\n"
    "  float l = max(max(c.r, c.g), c.b);\n"
    "  float k = smoothstep(uThresh, uThresh + 0.25, l);\n"
    "  gl_FragColor = vec4(c * k, 1.0);\n"
    "}\n";

/* 可分离高斯模糊（9 tap）：uDir 给方向，(1/w, 0) 是横、(0, 1/h) 是竖。
   一次只糊一个方向，两次就把二维模糊做完了 —— 代价是 9+9 而不是 81。 */
static const char *HW_BLOOM_BLUR_FS =
    "#version 120\n"
    "varying vec2 vUV;\n"
    "uniform sampler2D uTex;\n"
    "uniform vec2 uDir;\n"
    "void main(){\n"
    "  float w[5];\n"
    "  w[0] = 0.227027; w[1] = 0.194594; w[2] = 0.121621;\n"
    "  w[3] = 0.054054; w[4] = 0.016216;\n"
    "  vec3 s = texture2D(uTex, vUV).rgb * w[0];\n"
    "  for (int i = 1; i < 5; i++) {\n"
    "    vec2 o = uDir * float(i);\n"
    "    s += texture2D(uTex, vUV + o).rgb * w[i];\n"
    "    s += texture2D(uTex, vUV - o).rgb * w[i];\n"
    "  }\n"
    "  gl_FragColor = vec4(s, 1.0);\n"
    "}\n";

'''

# ---------------------------------------------------------------- 实现
BLOOM_IMPL = r'''
/* 画一个覆盖整个视口的全屏 quad（顶点就是裁剪坐标 -1..1）。
   post 合成与 bloom 的三个 pass 都靠它，省三份重复代码。 */
static void hw_fullscreen_quad(void)
{
    glBegin(GL_QUADS);
    glTexCoord2f(0.0f, 0.0f); glVertex2f(-1.0f, -1.0f);
    glTexCoord2f(1.0f, 0.0f); glVertex2f( 1.0f, -1.0f);
    glTexCoord2f(1.0f, 1.0f); glVertex2f( 1.0f,  1.0f);
    glTexCoord2f(0.0f, 1.0f); glVertex2f(-1.0f,  1.0f);
    glEnd();
}

/* 建/重建一对半分辨率 ping-pong FBO。 */
static void hw_bloom_drop(void)
{
    if (g_fbo_b1 != 0 && glapi.DeleteFramebuffers)
        glapi.DeleteFramebuffers(1, &g_fbo_b1);
    if (g_fbo_b2 != 0 && glapi.DeleteFramebuffers)
        glapi.DeleteFramebuffers(1, &g_fbo_b2);
    if (g_b1_tex != 0) glDeleteTextures(1, &g_b1_tex);
    if (g_b2_tex != 0) glDeleteTextures(1, &g_b2_tex);
    g_fbo_b1 = g_fbo_b2 = g_b1_tex = g_b2_tex = 0;
    g_bw = g_bh = 0;
}

static GLuint hw_bloom_make_fbo(int w, int h, GLuint *tex_out)
{
    GLuint tex = 0, fbo = 0;
    glGenTextures(1, &tex);
    glBindTexture(GL_TEXTURE_2D, tex);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, NULL);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glBindTexture(GL_TEXTURE_2D, 0);

    glapi.GenFramebuffers(1, &fbo);
    glapi.BindFramebuffer(GL_FRAMEBUFFER, fbo);
    glapi.FramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, tex, 0);
    GLenum st = glapi.CheckFramebufferStatus(GL_FRAMEBUFFER);
    glapi.BindFramebuffer(GL_FRAMEBUFFER, 0);
    if (st != GL_FRAMEBUFFER_COMPLETE) {
        if (tex != 0) glDeleteTextures(1, &tex);
        return 0;
    }
    *tex_out = tex;
    return fbo;
}

/* 把 bloom 结果写进 g_bloom_tex（合成阶段在纹理单元 1 采样）。
   g_bloom <= 0 时直接返回，合成阶段 uBloom = 0，那一项乘掉。 */
static void hw_bloom_run(int w, int h)
{
    if (g_bloom <= 0.0 || g_fbo_sctex == 0 || !g_gl_ok)
        return;
    int bw = w / 2, bh = h / 2;
    if (bw < 4) bw = 4;
    if (bh < 4) bh = 4;

    if (g_fbo_b1 == 0 || bw != g_bw || bh != g_bh) {
        hw_bloom_drop();
        if (g_bright_prog == 0 && !g_bloom_fail) {
            char log[512];
            g_bright_prog = hw_build_program(HW_POST_VS, HW_BLOOM_BRIGHT_FS, log, sizeof log);
            g_blur_prog   = hw_build_program(HW_POST_VS, HW_BLOOM_BLUR_FS,   log, sizeof log);
            if (g_bright_prog == 0 || g_blur_prog == 0) {
                fprintf(stderr, "[bloom] 着色器编译失败：%s\n", log);
                fflush(stderr);
                g_bloom_fail = 1;
                return;
            }
        }
        if (g_bright_prog == 0 || g_blur_prog == 0)
            return;
        g_fbo_b1 = hw_bloom_make_fbo(bw, bh, &g_b1_tex);
        g_fbo_b2 = hw_bloom_make_fbo(bw, bh, &g_b2_tex);
        if (g_fbo_b1 == 0 || g_fbo_b2 == 0) {
            fprintf(stderr, "[bloom] 半分辨率 FBO 建不出来 —— 关掉 bloom\n");
            fflush(stderr);
            hw_bloom_drop();
            g_bloom_fail = 1;
            g_bloom = 0.0;
            return;
        }
        g_bw = bw; g_bh = bh;
        printf("[bloom] 半分辨率 %dx%d 就绪\n", bw, bh);
        fflush(stdout);
    }

    /* 全屏 quad 的矩阵必须是干净的：post 合成阶段也用这一套 */
    glDisable(GL_DEPTH_TEST);
    glDisable(GL_FOG);
    glDisable(GL_BLEND);
    glDisable(GL_ALPHA_TEST);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    if (glapi.ActiveTexture != NULL)
        glapi.ActiveTexture(GL_TEXTURE0);
    glEnable(GL_TEXTURE_2D);

    /* ① 亮度提取：场景色 → b1 */
    glapi.BindFramebuffer(GL_FRAMEBUFFER, g_fbo_b1);
    glViewport(0, 0, bw, bh);
    glapi.UseProgram(g_bright_prog);
    {
        GLint l = glapi.GetUniformLocation(g_bright_prog, "uThresh");
        if (l >= 0) glapi.Uniform1f(l, (GLfloat)g_bloom_thr);
    }
    glBindTexture(GL_TEXTURE_2D, g_fbo_sctex);
    hw_fullscreen_quad();

    /* ② 水平模糊：b1 → b2 */
    glapi.BindFramebuffer(GL_FRAMEBUFFER, g_fbo_b2);
    glapi.UseProgram(g_blur_prog);
    {
        GLint l = glapi.GetUniformLocation(g_blur_prog, "uDir");
        if (l >= 0) glapi.Uniform2f(l, 1.0f / (GLfloat)bw, 0.0f);
    }
    glBindTexture(GL_TEXTURE_2D, g_b1_tex);
    hw_fullscreen_quad();

    /* ③ 垂直模糊：b2 → b1（结果就放 b1，合成阶段采样它） */
    glapi.BindFramebuffer(GL_FRAMEBUFFER, g_fbo_b1);
    {
        GLint l = glapi.GetUniformLocation(g_blur_prog, "uDir");
        if (l >= 0) glapi.Uniform2f(l, 0.0f, 1.0f / (GLfloat)bh);
    }
    glBindTexture(GL_TEXTURE_2D, g_b2_tex);
    hw_fullscreen_quad();

    g_bloom_tex = g_b1_tex;
    glapi.UseProgram(0);
    g_bound_prog = 0;
    glBindTexture(GL_TEXTURE_2D, 0);
    glDisable(GL_TEXTURE_2D);
    glapi.BindFramebuffer(GL_FRAMEBUFFER, 0);
}

'''

BLOOM_API = r'''/* ---- bloom 开关与参数 ----
   强度 <= 0 关闭；阈值是"多亮才算发光体"（0~1，越低越容易晕开）。 */
Value rt_hw_bloom(Value iv, Value tv)
{
    g_bloom = hw_num(iv, "hw.bloom 的强度");
    g_bloom_thr = hw_num(tv, "hw.bloom 的阈值");
    return rt_none();
}

'''

PATCHES_C = [
    # 1. Bloom 全局
    ('bloom-globals',
     'static GLuint g_post_prog = 0;      /* 全屏合成程序（首次真正用到才编译） */\n'
     'static int    g_post_fail = 0;      /* 编译或建 FBO 失败过：别每帧重试刷屏 */\n',
     'static GLuint g_post_prog = 0;      /* 全屏合成程序（首次真正用到才编译） */\n'
     'static int    g_post_fail = 0;      /* 编译或建 FBO 失败过：别每帧重试刷屏 */\n'
     + BLOOM_GLOBALS),

    # 2. Bloom 着色器（放在 HW_POST_FS 之后）
    ('bloom-shaders',
     '/* 绑上场景 FBO 并保证尺寸对。返回 0 = 这条通道用不了（调用方走直通路径）。 */',
     BLOOM_SHADERS.lstrip('\n') +
     '/* 绑上场景 FBO 并保证尺寸对。返回 0 = 这条通道用不了（调用方走直通路径）。 */'),

    # 3. Bloom 实现（放在 hw_shadow_pass 之前，即 shadow 前半段之后）
    ('bloom-impl',
     '/* 阴影 pass：从光源方向渲一遍场景，深度存进 g_shadow_tex。',
     BLOOM_IMPL.lstrip('\n') +
     '/* 阴影 pass：从光源方向渲一遍场景，深度存进 g_shadow_tex。'),

    # 4. rt_hw_frame：合成之前跑 bloom
    ('frame-bloom',
     '    if (post)\n'
     '        hw_post_end(winW, winH);\n',
     '    if (post) {\n'
     '        hw_bloom_run(winW, winH);   /* 场景已渲完 → 提亮/模糊，结果进 g_bloom_tex */\n'
     '        hw_post_end(winW, winH);    /* 合成时 uBloom 那一项才拿得到它 */\n'
     '    }\n'),

    # 5. post 合成用 hw_fullscreen_quad（去重复）
    ('post-use-quad',
     '    glColor4f(1.0f, 1.0f, 1.0f, 1.0f);\n'
     '    glBegin(GL_QUADS);\n'
     '    glTexCoord2f(0.0f, 0.0f); glVertex2f(-1.0f, -1.0f);\n'
     '    glTexCoord2f(1.0f, 0.0f); glVertex2f( 1.0f, -1.0f);\n'
     '    glTexCoord2f(1.0f, 1.0f); glVertex2f( 1.0f,  1.0f);\n'
     '    glTexCoord2f(0.0f, 1.0f); glVertex2f(-1.0f,  1.0f);\n'
     '    glEnd();\n',
     '    glColor4f(1.0f, 1.0f, 1.0f, 1.0f);\n'
     '    hw_fullscreen_quad();\n'),

    # 6. API
    ('bloom-api',
     'Value rt_hw_fog(Value sv, Value ev)',
     BLOOM_API + 'Value rt_hw_fog(Value sv, Value ev)'),
]

PATCHES_FRONT = [
    ('front-libcalls',
     "    'hw.shadow': 1, 'hw.shadowres': 1, 'hw.shadowarea': 1,\n",
     "    'hw.bloom': 2,\n"
     "    'hw.shadow': 1, 'hw.shadowres': 1, 'hw.shadowarea': 1,\n"),
]

PATCHES_CODE = [
    ('code-names',
     "        'hw.shadow': 'rt_hw_shadow', 'hw.shadowres': 'rt_hw_shadowres',\n",
     "        'hw.bloom': 'rt_hw_bloom',\n"
     "        'hw.shadow': 'rt_hw_shadow', 'hw.shadowres': 'rt_hw_shadowres',\n"),
    ('code-protos',
     "           'shadow:1', 'shadowres:1', 'shadowarea:1', 'shadowbias:1', 'shadowcenter:3']\n",
     "           'shadow:1', 'shadowres:1', 'shadowarea:1', 'shadowbias:1', 'shadowcenter:3',\n"
     "           'bloom:2']\n"),
]


def patch(path, patches):
    s = io.open(path, encoding='utf-8', newline='').read()
    had_crlf = '\r\n' in s
    if had_crlf:
        s = s.replace('\r\n', '\n')
    for label, old, new in patches:
        n = s.count(old)
        if n != 1:
            sys.stderr.write('FAIL [%s] %s count=%d\n' % (label, os.path.basename(path), n))
            sys.exit(1)
        s = s.replace(old, new, 1)
        print('  ok  %s' % label)
    if had_crlf:
        s = s.replace('\r\n', '\n').replace('\n', '\r\n')
    io.open(path, 'w', encoding='utf-8', newline='').write(s)


ONLY = sys.argv[1:]
def want(tag):
    return (not ONLY) or (tag in ONLY)

if want('c'):
    print('pybook_hw3d.c:')
    patch(os.path.join(ROOT, 'pybook_hw3d.c'), PATCHES_C)
if want('front'):
    print('pybk_front.py:')
    patch(os.path.join(ROOT, 'pybk_front.py'), PATCHES_FRONT)
if want('code'):
    print('pybk_code.py:')
    patch(os.path.join(ROOT, 'pybk_code.py'), PATCHES_CODE)
print('done')
