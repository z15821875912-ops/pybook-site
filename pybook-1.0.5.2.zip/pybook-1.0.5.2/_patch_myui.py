# -*- coding: utf-8 -*-
"""把「作者版」的三份文件里值得要的东西，移植进仓库版（不是覆盖！）。

作者版 = 一个**更旧的基线** + 几项新东西。直接覆盖会丢掉仓库里已有的：
  · ui.* 桌面 GUI 全套（11 个 API + gen_ui_protos + pybook_ui.c 编译项）
  · PYBOOK_SHOT_DIR 无头出图开关（1.0.5.1 刚发的功能）
  · 三处循环/内存 bug 修复（嵌套循环 at 读错层、矩阵乘行变对角线、
    for-in 迭代对象没生根导致的随机段错误）
  · 语句形态调用放宽（自己的 func 当语句调用，标准库 pool_clear 靠它）
  · ns.show() 空参放宽、dict.get/set/max/min、mt.clamp/lerp、mu.* 映射

作者版**值得吸收**的只有四项：
  ① hw.rect / hw.textc     —— 屏幕空间 HUD 矩形 + 彩色文字（MyUI 3D 版要的）
  ② hw.wheel               —— 鼠标滚轮净增量
  ③ hw.key 支持 f1~f12     —— hw3d.c 的键名表（front 的 KEY_NAMES 不管 hw.key，只在表里加即可）
  ④ _fn参数 默认用 set()   —— 修一个真 bug（默认 None 时 GOING 里 表[i]=值 会崩）

另外**补一个作者漏掉的 bug**：codegen 里 hw.text 的「文本插值」特判写死了下标 3，
hw.textc 的文本在第 7 参，照抄作者的写法会导致
`hw.textc(...., "得分 $(分)")` 这种字面量插值走不通。改成按「末位参数」判。

行尾策略：仓库的 .py 是 CRLF、.c 是 LF。统一折成 LF 做替换、写回时按原样还原，
避免把 CRLF 文件洗成 LF（那会让整份 git diff 变成全文件差异）。
"""
import io
import sys

ROOT = 'C:/Users/zhuli/Desktop/pybook/'
PATCHES = []

# ============================================================ pybook_hw3d.c（LF）

PATCHES.append(('hw3d:键名表加 f1~f12', 'pybook_hw3d.c',
'''        {"y", SDL_SCANCODE_Y}, {"z", SDL_SCANCODE_Z},
    };''',
'''        {"y", SDL_SCANCODE_Y}, {"z", SDL_SCANCODE_Z},
        {"f1", SDL_SCANCODE_F1}, {"f2", SDL_SCANCODE_F2},
        {"f3", SDL_SCANCODE_F3}, {"f4", SDL_SCANCODE_F4},
        {"f5", SDL_SCANCODE_F5}, {"f6", SDL_SCANCODE_F6},
        {"f7", SDL_SCANCODE_F7}, {"f8", SDL_SCANCODE_F8},
        {"f9", SDL_SCANCODE_F9}, {"f10", SDL_SCANCODE_F10},
        {"f11", SDL_SCANCODE_F11}, {"f12", SDL_SCANCODE_F12},
    };'''))

PATCHES.append(('hw3d:QText 加颜色 + QRect 队列 + 滚轮量', 'pybook_hw3d.c',
'''typedef struct { char *s; int x, y, size; } QText;
static QText g_qtext[QTEXT_MAX];
static int g_nqtext = 0;''',
'''typedef struct { char *s; int x, y, size; int r, g, b; } QText;
static QText g_qtext[QTEXT_MAX];
static int g_nqtext = 0;

/* 矩形覆盖层队列（MyUI 的面板 / 按钮 / 进度条 / 格子底）。
   和文字队列走同一条通道：帧末正交像素坐标、y 向下、无深度无雾、永远置顶。
   hw.rect 只往这里塞一条、帧末统一画 —— 所以调用顺序天然就是叠放顺序
   （先面板底、再进度条，文字在下一段里压上去）。 */
#define QRECT_MAX 512
typedef struct { int x, y, w, h, r, g, b; } QRect;
static QRect g_qrect[QRECT_MAX];
static int g_nqrect = 0;

/* 滚轮累积量：pump() 里累加，hw.wheel() 读走后清零 */
static int g_wheel = 0;'''))

PATCHES.append(('hw3d:pump 里收滚轮事件', 'pybook_hw3d.c',
'''        if (ev.type == SDL_KEYDOWN && ev.key.keysym.scancode == SDL_SCANCODE_ESCAPE) {
            if (ev.key.windowID == 0 || ev.key.windowID == g_winid)
                g_quit = 1;
        }
    }
}''',
'''        if (ev.type == SDL_KEYDOWN && ev.key.keysym.scancode == SDL_SCANCODE_ESCAPE) {
            if (ev.key.windowID == 0 || ev.key.windowID == g_winid)
                g_quit = 1;
        }
        /* 滚轮：向上滚 ev.wheel.y > 0。累积成净增量，hw.wheel() 读走后清零，
           所以一帧读一次就能拿到这段时间滚了多少（正 = 向上 / 拉近）。 */
        if (ev.type == SDL_MOUSEWHEEL) {
            g_wheel += ev.wheel.y;
        }
    }
}'''))

PATCHES.append(('hw3d:rt_hw_text 默认白 + 新增 textc/rect', 'pybook_hw3d.c',
'''Value rt_hw_text(Value xv, Value yv, Value sv, Value tv)
{
    if (g_nqtext == QTEXT_MAX)
        hw_die("hw.text：单帧文字超过上限 %d", QTEXT_MAX);
    QText *t = &g_qtext[g_nqtext++];
    t->x = (int)hw_num(xv, "hw.text 的 x");
    t->y = (int)hw_num(yv, "hw.text 的 y");
    t->size = (int)hw_num(sv, "hw.text 的字号");
    const char *s = hw_str(tv, "hw.text 的文本");
    t->s = strdup(s);                  /* 帧末释放 */
    return rt_none();
}''',
'''Value rt_hw_text(Value xv, Value yv, Value sv, Value tv)
{
    if (g_nqtext == QTEXT_MAX)
        hw_die("hw.text：单帧文字超过上限 %d", QTEXT_MAX);
    QText *t = &g_qtext[g_nqtext++];
    t->x = (int)hw_num(xv, "hw.text 的 x");
    t->y = (int)hw_num(yv, "hw.text 的 y");
    t->size = (int)hw_num(sv, "hw.text 的字号");
    t->r = t->g = t->b = 255;          /* 老 hw.text 就是白色 */
    const char *s = hw_str(tv, "hw.text 的文本");
    t->s = strdup(s);                  /* 帧末释放 */
    return rt_none();
}

/* hw.textc(x, y, 字号, r, g, b, 文本)：彩色版 hw.text。
   坐标系完全一样（像素、原点左上、y 向下），只是多了个颜色 ——
   和 hw.rect 搭起来就是一套 HUD：面板底 + 彩色文字。 */
Value rt_hw_textc(Value xv, Value yv, Value sv, Value rv, Value gv, Value bv, Value tv)
{
    if (g_nqtext == QTEXT_MAX)
        hw_die("hw.textc：单帧文字超过上限 %d", QTEXT_MAX);
    QText *t = &g_qtext[g_nqtext++];
    t->x = (int)hw_num(xv, "hw.textc 的 x");
    t->y = (int)hw_num(yv, "hw.textc 的 y");
    t->size = (int)hw_num(sv, "hw.textc 的字号");
    t->r = (int)hw_num(rv, "hw.textc 的 r");
    t->g = (int)hw_num(gv, "hw.textc 的 g");
    t->b = (int)hw_num(bv, "hw.textc 的 b");
    const char *s = hw_str(tv, "hw.textc 的文本");
    t->s = strdup(s);                  /* 帧末释放 */
    return rt_none();
}

/* hw.rect(x, y, 宽, 高, r, g, b)：屏幕空间实心矩形（HUD 覆盖层）。
   像素坐标、原点左上、y 向下 —— 和 hw.text / hw.textc 同一套坐标系，
   帧末画在 3D 之上，不写深度、不吃雾，永远置顶。
   纯覆盖层：不参与物理、不参与 hw.hit 拾取（hw.hit 只管游戏世界里的东西），
   HUD 上的按钮得自己用 hw.mx / hw.my 判命中（见 MyUI 的 myui按钮）。

   宽或高非正也能安全提交（GL 不画退化四边形），所以进度条可以一路写
   hw.rect(x, y, w * 比, h, ...) 不用特判"比为 0"那一帧。 */
Value rt_hw_rect(Value xv, Value yv, Value wv, Value hv, Value rv, Value gv, Value bv)
{
    if (g_nqrect == QRECT_MAX)
        hw_die("hw.rect：单帧矩形超过上限 %d", QRECT_MAX);
    QRect *q = &g_qrect[g_nqrect++];
    q->x = (int)hw_num(xv, "hw.rect 的 x");
    q->y = (int)hw_num(yv, "hw.rect 的 y");
    q->w = (int)hw_num(wv, "hw.rect 的宽");
    q->h = (int)hw_num(hv, "hw.rect 的高");
    q->r = (int)hw_num(rv, "hw.rect 的 r");
    q->g = (int)hw_num(gv, "hw.rect 的 g");
    q->b = (int)hw_num(bv, "hw.rect 的 b");
    return rt_none();
}'''))

PATCHES.append(('hw3d:帧末先画矩形再画文字', 'pybook_hw3d.c',
'''    for (int i = 0; i < g_nqtext; i++) {
        QText *t = &g_qtext[i];
        int tw, th;
        GLuint tex = text_texture(t->s, t->size, &tw, &th);
        if (tex != 0) {
            glEnable(GL_TEXTURE_2D);
            glBindTexture(GL_TEXTURE_2D, tex);
            glColor4f(1, 1, 1, 1);''',
'''    /* ---- 矩形覆盖层：先画矩形（一批提交），文字在下面那段里压上去 ---- */
    glDisable(GL_TEXTURE_2D);
    glBegin(GL_QUADS);
    for (int i = 0; i < g_nqrect; i++) {
        QRect *q = &g_qrect[i];
        glColor4f(q->r / 255.0f, q->g / 255.0f, q->b / 255.0f, 1.0f);
        glVertex2i(q->x,        q->y);
        glVertex2i(q->x + q->w, q->y);
        glVertex2i(q->x + q->w, q->y + q->h);
        glVertex2i(q->x,        q->y + q->h);
    }
    glEnd();

    for (int i = 0; i < g_nqtext; i++) {
        QText *t = &g_qtext[i];
        int tw, th;
        GLuint tex = text_texture(t->s, t->size, &tw, &th);
        if (tex != 0) {
            glEnable(GL_TEXTURE_2D);
            glBindTexture(GL_TEXTURE_2D, tex);
            glColor4f(t->r / 255.0f, t->g / 255.0f, t->b / 255.0f, 1.0f);'''))

PATCHES.append(('hw3d:帧末清空矩形队列', 'pybook_hw3d.c',
'''    g_nqtext = 0;
    g_nboxes = 0;
    g_nlines = 0;
    g_nspheres = 0;
    g_ncyls = 0;
    g_nops = 0;''',
'''    g_nqtext = 0;
    g_nqrect = 0;
    g_nboxes = 0;
    g_nlines = 0;
    g_nspheres = 0;
    g_ncyls = 0;
    g_nops = 0;'''))

PATCHES.append(('hw3d:新增 rt_hw_wheel', 'pybook_hw3d.c',
'''Value rt_hw_mdy(void)
{
    if (g_win == NULL)
        return rt_int(0);
    int dx, dy;
    SDL_GetRelativeMouseState(&dx, &dy);
    return rt_int(dy);
}''',
'''Value rt_hw_mdy(void)
{
    if (g_win == NULL)
        return rt_int(0);
    int dx, dy;
    SDL_GetRelativeMouseState(&dx, &dy);
    return rt_int(dy);
}

/* hw.wheel()：上次读取以来的滚轮净增量（向上滚为正），读完清零。
   典型用法：vg.w = hw.wheel()  →  距 = 距 - w * 步长（拉近 / 推远镜头）。 */
Value rt_hw_wheel(void)
{
    if (g_win == NULL)
        return rt_int(0);
    pump();
    int d = g_wheel;
    g_wheel = 0;
    return rt_int(d);
}'''))

# ============================================================= pybk_front.py（CRLF）

PATCHES.append(('front:hw.textc / hw.rect 参数个数表', 'pybk_front.py',
"""    'hw.mx': 0, 'hw.my': 0, 'hw.mdown': 0, 'hw.mhit': 0, 'hw.text': 4,""",
"""    'hw.mx': 0, 'hw.my': 0, 'hw.mdown': 0, 'hw.mhit': 0, 'hw.text': 4,
    'hw.textc': 7, 'hw.rect': 7,"""))

PATCHES.append(('front:hw.wheel 参数个数表', 'pybk_front.py',
"""    'hw.grab': 0, 'hw.free': 0, 'hw.mdx': 0, 'hw.mdy': 0,""",
"""    'hw.grab': 0, 'hw.free': 0, 'hw.mdx': 0, 'hw.mdy': 0, 'hw.wheel': 0,"""))

PATCHES.append(('front:_fn参数 默认值改 set()（单行 func 分支）', 'pybk_front.py',
"""            外层参数 = getattr(self, '_fn参数', None)
            self._fn参数 = set(params)
            body = [Ret(self.parse_expr(), ln)]""",
"""            # 用 set() 而不是 None 当默认：顶层 func 解析完会把外层值写回来，
            # 若留成 None，之后 GOING 里任何 "表[i] = 值" 都会在 `nm in None` 上崩。
            外层参数 = getattr(self, '_fn参数', set())
            self._fn参数 = set(params)
            body = [Ret(self.parse_expr(), ln)]"""))

PATCHES.append(('front:_fn参数 默认值改 set()（多行 func 分支）', 'pybk_front.py',
"""        外层参数 = getattr(self, '_fn参数', None)
        self._fn参数 = set(params)          # 参数名允许直接下标赋值（冒泡等场景）""",
"""        外层参数 = getattr(self, '_fn参数', set())
        self._fn参数 = set(params)          # 参数名允许直接下标赋值（冒泡等场景）"""))

# ============================================================== pybk_code.py（CRLF）

PATCHES.append(('code:LIB_C_NAMES 注册 rect / textc / wheel', 'pybk_code.py',
"""        'hw.text': 'rt_hw_text',""",
"""        'hw.text': 'rt_hw_text',
        'hw.textc': 'rt_hw_textc', 'hw.rect': 'rt_hw_rect',
        'hw.wheel': 'rt_hw_wheel',"""))

PATCHES.append(('code:out.c 原型发射补三个', 'pybk_code.py',
"""    fns = ['open:3', 'clearcolor:3', 'camera:5', 'box:9', 'frame:0', 'end:0', 'key:1', 'hit:1', 'mx:0', 'my:0', 'mdown:0', 'mhit:0', 'text:4', 'grab:0', 'free:0', 'mdx:0', 'mdy:0']""",
"""    fns = ['open:3', 'clearcolor:3', 'camera:5', 'box:9', 'frame:0', 'end:0', 'key:1', 'hit:1', 'mx:0', 'my:0', 'mdown:0', 'mhit:0', 'text:4', 'grab:0', 'free:0', 'mdx:0', 'mdy:0',
           'wheel:0', 'textc:7', 'rect:7']"""))

PATCHES.append(('code:文本插值特判扩展到 hw.textc（按末位判）', 'pybk_code.py',
"""        if e.name == 'hw.text':
            stmts = []
            args = []
            for k4, a4 in enumerate(e.args):
                if k4 == 3 and isinstance(a4, StrParts):""",
"""        # hw.text / hw.textc：最后一个参数是文本，可能带 $( ) 插值，要先拼成
        # C 字符串再 materialize（其余参数都是数值表达式）。hw.text 是 4 参、
        # hw.textc 是 7 参，所以按"末位参数"判，别写死下标 3。
        if e.name in ('hw.text', 'hw.textc'):
            stmts = []
            args = []
            for k4, a4 in enumerate(e.args):
                if k4 == len(e.args) - 1 and isinstance(a4, StrParts):"""))

PATCHES.append(('code:hw.text 的返回改用映射表（textc 复用同一段）', 'pybk_code.py',
"""            return stmts, f'rt_hw_text({", ".join(args)})'""",
"""            return stmts, '%s(%s)' % (self.LIB_C_NAMES[e.name], ", ".join(args))"""))


def main():
    cache = {}
    crlf = {}
    for label, fname, old, new in PATCHES:
        if fname not in cache:
            raw = io.open(ROOT + fname, encoding='utf-8', newline='').read()
            crlf[fname] = raw.count('\r\n') > 0
            cache[fname] = raw.replace('\r\n', '\n')
        s = cache[fname]
        n = s.count(old)
        if n != 1:
            sys.stderr.write('FAIL [%s] %s count=%d\n' % (label, fname, n))
            return 1
        cache[fname] = s.replace(old, new, 1)
        print('ok   %-52s %s' % (label, fname))
    for fname, s in cache.items():
        out = s.replace('\n', '\r\n') if crlf[fname] else s
        io.open(ROOT + fname, 'w', encoding='utf-8', newline='').write(out)
        print('写回 %-20s 行尾保留 %s' % (fname, 'CRLF' if crlf[fname] else 'LF'))
    return 0


if __name__ == '__main__':
    sys.exit(main())
