from pathlib import Path
p = Path(r'C:\Users\zhuli\Desktop\pybook\pybook_m3d.c')
t = p.read_text(encoding='utf-8')
t = t.replace('if (kind == 1 || kind == 3 || kind == 4)', 'if (kind == 1 || kind == 3 || kind == 4 || kind == 5)')
p.write_text(t, encoding='utf-8')
print('kind5 patches', t.count('kind == 5'))
