/* PYbook torchbk（tb. 前缀）：教学级神经网络原生库。
 * 张量 = 列表的列表（2D 浮点矩阵），与 np.* / 游戏代码完全互通。
 * 设计：手写梯度对（前向算子 + 配套 _grad/_dx/_dw/_db），
 *       不做自动微分——让学习者亲手拼出反向传播。
 *
 * 前向：mat/rand/dot/tr/add/mul/addrow/relu/sigmoid/lin/mse
 * 反向：relu_grad/sigmoid_grad/mse_grad/lin_dx/lin_dw/lin_db
 * 优化：step(w, dw, lr) = w - lr*dw
 * 维度：rows/cols
 *
 * 约定：矩阵 = 行列表，每行是等长浮点列表；维度不符带具体报错。 */

#include "pybook_lib.h"
#include "pybook_mt.h"
#include "pybook_gpu.h"   /* tb.dot / tb.lin 的 GPU 路由（device gpu 或 device auto 探测到卡） */

#include <math.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <immintrin.h>

/* ================= 内部 ================= */

/* 3 级分块矩阵乘（MR×NR 寄存器分块 + KC/kc + NC/jc + MC/ic 三向分块 + A/B 双打包）。
 * 计算 O += A@B 的部分和（调用方须先把 O 清零/填偏置）。
 * 内层 k 循环对打包后的 A 面板(pA[ip*klen+p]) 与 B 面板(pB[p*jlen+jp]) 都做单位步长
 * 流式读取，彻底消除原内核 B[k*bc+jj] 的 ~8000B 跨距冲突未命中与 A 的重复读取。
 * 面板尺寸取 L2 友好：KC*NC*8 + MC*KC*8 ≈ 256KB。 */
/* 寄存器分块：MR 行 × NR 列（8 条独立 FMA 链打满 AVX2 吞吐）。 */
#define TB_MR 4
#define TB_NR 8
/* 三级缓存分块尺寸（单位：元素数）。
 * 经过扫描调优定为 48，不要改大：
 *   12 线程按【行】切（1000³ 每线程约 83 行），B 面板是每线程各自打包的；
 *   大面板(>128)打包 memcpy 开销主导，且溢出 per-core L2(256KB)。
 *   K=48 时 A/B 两面板合计约 2×48²×8≈36KB，全进 L1/L2，打包代价可忽略。
 *   改回 128 会让 1000³ 从约 20ms/rep 退到约 27ms/rep。 */
#define TB_KC 48
#define TB_NC 48
#define TB_MC 48

static void tb_die(const char *fmt, ...);  /* 前向声明（定义见下方） */

/* 微内核：O[(ioff+ip), jc+jp] += Σ_p A[(ioff+ip)*ac + kc + p] * pB[p*jlen+jp]。
 * A 的 k 维本就单位步长（行内连续），直接读、不做 A 打包（那是纯开销）；
 * 仅 B 打包成连续面板消除 ~8000B 跨距冲突未命中。
 * init=1 时 O 刚清零，直接覆盖写（省一次 load）；否则累加。 */
static void tb_micro_packed(const double *A, const double *pB, double *O,
                            size_t ac, size_t bc, size_t ioff, size_t ilen,
                            size_t kc, size_t jc, size_t jlen, size_t klen, int init)
{
    size_t jrem = jlen % TB_NR;
    size_t jmain = jlen - jrem;
    for (size_t ip = 0; ip + TB_MR <= ilen; ip += TB_MR) {
        for (size_t jp = 0; jp < jmain; jp += TB_NR) {
            __m256d c0l = _mm256_setzero_pd(), c0h = _mm256_setzero_pd();
            __m256d c1l = _mm256_setzero_pd(), c1h = _mm256_setzero_pd();
            __m256d c2l = _mm256_setzero_pd(), c2h = _mm256_setzero_pd();
            __m256d c3l = _mm256_setzero_pd(), c3h = _mm256_setzero_pd();
            for (size_t p = 0; p < klen; p++) {
                const double *Bp = pB + p * jlen + jp;
                __m256d b0 = _mm256_loadu_pd(Bp);
                __m256d b1 = _mm256_loadu_pd(Bp + 4);
                __m256d a0 = _mm256_broadcast_sd(&A[(ioff + ip + 0) * ac + kc + p]);
                c0l = _mm256_fmadd_pd(b0, a0, c0l);
                c0h = _mm256_fmadd_pd(b1, a0, c0h);
                __m256d a1 = _mm256_broadcast_sd(&A[(ioff + ip + 1) * ac + kc + p]);
                c1l = _mm256_fmadd_pd(b0, a1, c1l);
                c1h = _mm256_fmadd_pd(b1, a1, c1h);
                __m256d a2 = _mm256_broadcast_sd(&A[(ioff + ip + 2) * ac + kc + p]);
                c2l = _mm256_fmadd_pd(b0, a2, c2l);
                c2h = _mm256_fmadd_pd(b1, a2, c2h);
                __m256d a3 = _mm256_broadcast_sd(&A[(ioff + ip + 3) * ac + kc + p]);
                c3l = _mm256_fmadd_pd(b0, a3, c3l);
                c3h = _mm256_fmadd_pd(b1, a3, c3h);
            }
            size_t o0 = (ioff + ip + 0) * bc + jc + jp;
            __m256d s0l = init ? c0l : _mm256_add_pd(c0l, _mm256_loadu_pd(&O[o0]));
            _mm256_storeu_pd(&O[o0], s0l);
            __m256d s0h = init ? c0h : _mm256_add_pd(c0h, _mm256_loadu_pd(&O[o0 + 4]));
            _mm256_storeu_pd(&O[o0 + 4], s0h);
            size_t o1 = (ioff + ip + 1) * bc + jc + jp;
            __m256d s1l = init ? c1l : _mm256_add_pd(c1l, _mm256_loadu_pd(&O[o1]));
            _mm256_storeu_pd(&O[o1], s1l);
            __m256d s1h = init ? c1h : _mm256_add_pd(c1h, _mm256_loadu_pd(&O[o1 + 4]));
            _mm256_storeu_pd(&O[o1 + 4], s1h);
            size_t o2 = (ioff + ip + 2) * bc + jc + jp;
            __m256d s2l = init ? c2l : _mm256_add_pd(c2l, _mm256_loadu_pd(&O[o2]));
            _mm256_storeu_pd(&O[o2], s2l);
            __m256d s2h = init ? c2h : _mm256_add_pd(c2h, _mm256_loadu_pd(&O[o2 + 4]));
            _mm256_storeu_pd(&O[o2 + 4], s2h);
            size_t o3 = (ioff + ip + 3) * bc + jc + jp;
            __m256d s3l = init ? c3l : _mm256_add_pd(c3l, _mm256_loadu_pd(&O[o3]));
            _mm256_storeu_pd(&O[o3], s3l);
            __m256d s3h = init ? c3h : _mm256_add_pd(c3h, _mm256_loadu_pd(&O[o3 + 4]));
            _mm256_storeu_pd(&O[o3 + 4], s3h);
        }
        /* 列余量（jlen 非 8 倍数）：4 路 ymm 收尾 */
        for (size_t jp = jmain; jp + 4 <= jlen; jp += 4) {
            __m256d c0 = _mm256_setzero_pd(), c1 = _mm256_setzero_pd(),
                    c2 = _mm256_setzero_pd(), c3 = _mm256_setzero_pd();
            for (size_t p = 0; p < klen; p++) {
                const double *Bp = pB + p * jlen + jp;
                __m256d b0 = _mm256_loadu_pd(Bp);
                __m256d a0 = _mm256_broadcast_sd(&A[(ioff + ip + 0) * ac + kc + p]);
                c0 = _mm256_fmadd_pd(b0, a0, c0);
                __m256d a1 = _mm256_broadcast_sd(&A[(ioff + ip + 1) * ac + kc + p]);
                c1 = _mm256_fmadd_pd(b0, a1, c1);
                __m256d a2 = _mm256_broadcast_sd(&A[(ioff + ip + 2) * ac + kc + p]);
                c2 = _mm256_fmadd_pd(b0, a2, c2);
                __m256d a3 = _mm256_broadcast_sd(&A[(ioff + ip + 3) * ac + kc + p]);
                c3 = _mm256_fmadd_pd(b0, a3, c3);
            }
            size_t o0 = (ioff + ip + 0) * bc + jc + jp;
            __m256d s0 = init ? c0 : _mm256_add_pd(c0, _mm256_loadu_pd(&O[o0]));
            _mm256_storeu_pd(&O[o0], s0);
            size_t o1 = (ioff + ip + 1) * bc + jc + jp;
            __m256d s1 = init ? c1 : _mm256_add_pd(c1, _mm256_loadu_pd(&O[o1]));
            _mm256_storeu_pd(&O[o1], s1);
            size_t o2 = (ioff + ip + 2) * bc + jc + jp;
            __m256d s2 = init ? c2 : _mm256_add_pd(c2, _mm256_loadu_pd(&O[o2]));
            _mm256_storeu_pd(&O[o2], s2);
            size_t o3 = (ioff + ip + 3) * bc + jc + jp;
            __m256d s3 = init ? c3 : _mm256_add_pd(c3, _mm256_loadu_pd(&O[o3]));
            _mm256_storeu_pd(&O[o3], s3);
        }
        /* 末余量 <4 列：标量收尾
         *
         * 注意 base 必须**每轮 p 都重新读 O**，不能写成 `init ? 0 : O[...]`。
         * 这四行在 p 循环体内：init==1（第一个 kc 块）时若把 base 钉死成 0，
         * 每轮 p 都在覆盖写而不是累加，整个 kc 块只剩最后一个 p 的乘积，
         * 输出**静默错**——实测触发条件是 N%4 != 0 且 M >= 4，
         * 错的是最后 (N mod 4) 列里落在 4 行组中的那些行。
         * 调用方保证 init==1 时 O 刚清零，所以第一次读到的自然就是 0，
         * 直接读 O 既正确又不多花什么（反正同一个地址刚存过）。
         *
         * 对照：下面「余行 <4」那段的 base 写在 p 循环**外**（sum 在局部累完了
         * 才加 base），那里 `init ? 0 : O[...]` 是对的，别照着改。 */
        for (size_t jp = jlen - (jlen % 4); jp < jlen; jp++) {
            for (size_t p = 0; p < klen; p++) {
                double b = pB[p * jlen + jp];
                double base = O[(ioff + ip + 0) * bc + jc + jp];
                O[(ioff + ip + 0) * bc + jc + jp] = base + A[(ioff + ip + 0) * ac + kc + p] * b;
                double b1 = O[(ioff + ip + 1) * bc + jc + jp];
                O[(ioff + ip + 1) * bc + jc + jp] = b1 + A[(ioff + ip + 1) * ac + kc + p] * b;
                double b2 = O[(ioff + ip + 2) * bc + jc + jp];
                O[(ioff + ip + 2) * bc + jc + jp] = b2 + A[(ioff + ip + 2) * ac + kc + p] * b;
                double b3 = O[(ioff + ip + 3) * bc + jc + jp];
                O[(ioff + ip + 3) * bc + jc + jp] = b3 + A[(ioff + ip + 3) * ac + kc + p] * b;
            }
        }
    }
    /* 余行 <4：标量 */
    for (size_t ip = ilen - (ilen % TB_MR); ip < ilen; ip++) {
        for (size_t jp = 0; jp < jlen; jp++) {
            double sum = 0;
            for (size_t p = 0; p < klen; p++)
                sum += A[(ioff + ip) * ac + kc + p] * pB[p * jlen + jp];
            double base = init ? 0 : O[(ioff + ip) * bc + jc + jp];
            O[(ioff + ip) * bc + jc + jp] = base + sum;
        }
    }
}

static void tb_matmul_tile(const double *A, const double *B, double *O,
                           size_t ac, size_t bc, size_t i0, size_t i1)
{
    size_t KC = ac < TB_KC ? ac : TB_KC;
    size_t NC = bc < TB_NC ? bc : TB_NC;
    size_t MC = (i1 - i0) < TB_MC ? (i1 - i0) : TB_MC;
    double *pB = malloc(KC * NC * sizeof(double));
    if (!pB) tb_die("tb.matmul 分配 B 打包缓冲失败");
    for (size_t kc = 0; kc < ac; kc += KC) {
        size_t k1 = (kc + KC < ac) ? kc + KC : ac;
        size_t klen = k1 - kc;
        int init = (kc == 0) ? 1 : 0;
        for (size_t jc = 0; jc < bc; jc += NC) {
            size_t j1 = (jc + NC < bc) ? jc + NC : bc;
            size_t jlen = j1 - jc;
            for (size_t p = 0; p < klen; p++)
                memcpy(pB + p * jlen, B + (kc + p) * bc + jc, jlen * sizeof(double));
            for (size_t ic = i0; ic < i1; ic += MC) {
                size_t i1b = (ic + MC < i1) ? ic + MC : i1;
                size_t ilen = i1b - ic;
                tb_micro_packed(A, pB, O, ac, bc, ic, ilen, kc, jc, jlen, klen, init);
            }
        }
    }
    free(pB);
}


static void tb_die(const char *fmt, ...)
{
    va_list ap;
    char msg[896];
    va_start(ap, fmt);
    vsnprintf(msg, sizeof msg, fmt, ap);
    va_end(ap);
    /* 统一走 rt_die（曾经这里自己 fprintf+exit(1)）：① 可被 try/catch 接住，
     * 坏形状不再连窝端掉整个进程；② 计入 g_err_count（Smokeroor 不再漏计）；
     * ③ 带上行号与三段式建议，与 pybook_rt.c 里张量函数的错误出口一致。
     * 无 try 时 rt_die 的兜底同样是打印+exit(1)，可见行为不变。 */
    rt_die("%s", msg);
}

/* 张量底层：tb.* 现在统一操作 RtTensor（行主序浮点缓冲），不再用列表的列表。
 * 下面辅助函数把"矩阵"语义映射到 RtTensor 上。 */
static RtTensor *tens_of(Value m, const char *who)
{
    if (!rt_is_tensor(m) || rt_as_tensor(m) == NULL)
        tb_die("%s 需要张量（tb 矩阵）", who);
    return rt_as_tensor(m);
}

/* ── ≥2D 通用视图：元素-wise = 前积×末维；matmul/lin = 首维×后积 ──
 * 3D 批量张量 (N, R, C) 两种读法数据是同一份行主序，只是切法不同。 */
static size_t tb_front(const RtTensor *t)   /* dims[0..n-2] 的积 */
{
    size_t p = 1;
    for (int i = 0; i < t->ndim - 1; i++)
        p *= (size_t)t->dims[i];
    return p;
}
static size_t tb_last(const RtTensor *t)    /* dims[n-1] */
{
    return (size_t)t->dims[t->ndim - 1];
}
static size_t tb_total(const RtTensor *t)
{
    return tb_front(t) * tb_last(t);
}
static size_t tb_rest(const RtTensor *t)    /* dims[1..n-1] 的积（lin 视图列数） */
{
    size_t p = 1;
    for (int i = 1; i < t->ndim; i++)
        p *= (size_t)t->dims[i];
    return p;
}

static double at(Value m, size_t r, size_t c, const char *who)
{
    RtTensor *t = tens_of(m, who);
    if (t->ndim < 2)
        tb_die("%s 需要 2D 及以上张量（当前 %d 维）", who, t->ndim);
    if (r >= tb_front(t) || c >= tb_last(t))
        tb_die("%s 越界 (%zu,%zu)，元素视图形状 %dx%d",
               who, r, c, (int)tb_front(t), (int)tb_last(t));
    return t->data[r * tb_last(t) + c];
}

static double numv(Value v, const char *who)
{
    if (IS_FLT(v))  return AS_FLT(v);
    if (IS_INT(v) || IS_BIGINT(v)) return (double)rt_to_ll(v);
    if (IS_BOOL(v)) return (double)AS_BOOL(v);
    tb_die("%s 需要数字参数", who);
    return 0;
}

static size_t rows_of(Value m, const char *who)
{
    return tb_front(tens_of(m, who));   /* ≥2D：前积（2D 时就是 dims[0]） */
}

static size_t cols_of(Value m, const char *who)
{
    RtTensor *t = tens_of(m, who);
    if (t->ndim < 2)
        tb_die("%s 需要 2D 张量（当前 %d 维）", who, t->ndim);
    return tb_last(t);
}

static Value new_mat(size_t r, size_t c)
{
    int d[2] = { (int)r, (int)c };
    return rt_tensor_new(2, d);
}

static Value new_mat_p(size_t r, size_t c, int prec)
{
    int d[2] = { (int)r, (int)c };
    return rt_tensor_new_p(2, d, prec);
}

static void set_at(Value m, size_t r, size_t c, double x)
{
    RtTensor *t = rt_as_tensor(m);
    t->data[r * tb_last(t) + c] = rt_tensor_round(t->prec, x);
}

/* ================= GPU 路由（device gpu / device auto 探测到卡） =================
 * 上卡要四个条件全满足，少一条就留在 CPU —— 这是「不合适」，不是故障：
 *   1. 后端确实是 GPU
 *   2. 输入两个张量都是 float32。1060 的 FP64 只有 FP32 的 1/64 吞吐，
 *      double 张量上卡不是加速是倒退（真要上也是几十倍的亏），所以让它留在 CPU。
 *   3. N 和 K 都能被 4 整除 —— 当前 kernel 用 float4 向量化载入，要求 16 字节对齐。
 *      M 不限：行指针按行距算，尾巴靠 min() 钳位加载 + 谓词存储处理。
 *   4. 规模够大。GPU_DOT_MIN_MAC 以下，搬运 + kernel 启动的开销盖过并行收益。
 * 一旦真的上了卡却失败（显存不够、kernel 报错），那是故障，直接报错，不吞。
 * 两种情况必须分开：回退是设计，报错是真出事。 */
static int gpu_dot_try(Value a, Value b, Value *outp,
                       size_t M, size_t N, size_t K)
{
    RtTensor *ta = tens_of(a, "tb.dot"), *tb = tens_of(b, "tb.dot");
    RtTensor *to;
    int       d[2];

    if (rt_device_backend() != 2)
        return 0;
    if (ta->prec != TENSOR_F32 || tb->prec != TENSOR_F32)
        return 0;
    if ((double)M * (double)N * (double)K < (double)GPU_DOT_MIN_MAC)
        return 0;
    /* 对齐要求来自 float4 载入：地址 = 基址 + 下标*4 字节，要 16 字节对齐，
     * 于是行距 K*4（B 的行距 N*4）都得是 16 的倍数，也就是 K 和 N 要是 4 的倍数。
     * M 不受限制（行指针照样是行距算出来的，尾巴由 min() 钳到 M-1 + 谓词存储兜住）。 */
    if (M < 1 || N < 4 || K < 4 || (N & 3) || (K & 3))
        return 0;

    d[0] = (int)M;
    d[1] = (int)N;
    outp[0] = new_mat_p(M, N, TENSOR_F32);
    to = rt_as_tensor(outp[0]);
    if (getenv("PYBOOK_GPU_TRACE"))
        fprintf(stderr, "[gpu] dot %dx%dx%d 上卡\n", (int)M, (int)N, (int)K);
    if (!gpu_sgemm_f32(ta->data, tb->data, to->data, (int)M, (int)N, (int)K))
        tb_die("tb.dot 已经决定上 GPU，但 kernel 没跑成：%s"
               "\n  怎么改：这个形状/显存是硬件限制，不是程序的错；"
               "可以改小矩阵，或改用 device cpu。",
               gpu_last_error());
    return 1;
}

/* tb.lin 用：GPU 只算乘法，偏置在 CPU 上补（1xN 广播，逐行加一次，省无可省） */
static void add_bias_row(Value out, Value b)
{
    RtTensor *o = rt_as_tensor(out), *bv = rt_as_tensor(b);
    size_t r = (size_t)o->dims[0], c = (size_t)o->dims[1];
    size_t i, j;
    for (i = 0; i < r; i++)
        for (j = 0; j < c; j++)
            o->data[i * c + j] =
                rt_tensor_round(o->prec, o->data[i * c + j] + bv->data[j]);
}

/* ================= 并行分块（pybook_mt 内核，块内零分配） ================= */

#define TB_EW_MIN ((double)(1 << 15))   /* 逐元素：3.3 万元素起并行 */
/* 矩阵乘起并行的阈值 —— 从 1<<19 提到 1<<24，理由全在下面，别凭感觉再调回去。
 *
 * 为什么不是「总工作量够大就并行」：mt_parallel 固定把行切成 MT_CHUNKS=64 块，
 * 而 tb_matmul_tile 每块都要把整个 B 面板重新打包（还带一次 malloc）。
 * 于是并行版的打包总量 = 64 × K×N×8 字节，**与 M 无关**；计算量才跟 M 走。
 * 真正该看的是**每块工作量** = M×N×K / 64（每块约 2 次乘加算 1 次乘加）。
 *
 * 本机实测（i5-10400F 6核12线程，-O3 -march=native，多轮交替取中位数，
 * 工具 _cpubench.c；微内核从本文件原文抽取，测的就是线上跑的那份）：
 *
 *   固定 N·K=65536 只扫 M            每块工作量        谁赢
 *     1 行/块  (M=64)                   65 536        串行 +326%
 *     2 行/块  (M=128)                 131 072        串行 +214%
 *     3 行/块  (M=192)                 196 608        串行 +107%
 *     4 行/块  (M=256)                 262 144        MT 赢
 *   固定 M=1024（16 行/块）只扫 N·K
 *     N·K=4096                          65 536        串行 +90%
 *     N·K=6400                         102 400        串行 +35%
 *     N·K=9216                         147 456        串行  +7%
 *     N·K=12544                        200 704        MT 赢
 *
 * 两个独立扫描把分界夹在 2×10^5 ~ 2.6×10^5 flop/块。换算成总 MAC（M>=64 时）：
 *   2×10^5 × 64 ≈ 1.3×10^7 ，2.6×10^5 × 64 ≈ 1.7×10^7
 * 取上沿 1<<24 = 16777216，因为它在两个扫描里都稳稳落在「MT 赢」那一侧。
 *
 * 修正前（1<<19 = 524288）的实测损失，这条阈值改动的全部价值就在这张表：
 *   81³  MAC=531441   串行 0.068ms / MT 0.734ms   **+981%**
 *   88³  MAC=681472                              +970%
 *   96³  MAC=884736                              +757%
 *   128³ MAC=2097152                             +206%
 *   192³ MAC=7077888                             +183%
 *   224³ MAC=11239424                             +13%
 *   256³ MAC=16777216  → 新阈值分界，MT 确实赢，改后正确
 *   512×48×48  MAC=1179648                       +532%
 *   512×90×90  MAC=4147200                       +115%
 *   3072³ MAC=2.9e10   仍并行，MT 快 4.9 倍，不受影响
 *
 * 已知边界情况：M<64 时 mt_parallel 只会用到 M 个非空块（例如 2×512×512 只有 2 块），
 * 这类瘦长矩阵按本阈值一律走串行，实测 MT 只快 13%，损失可接受，先不特殊处理。
 * 真要吃满这块，得给 mt_parallel 加一个「按工作量定块数」的变体
 * （块数 = clamp(总工作量 / 2.6e5, 1, MT_CHUNKS)），让并行度跟着工作量走而不是钉死 64；
 * 那是改 pybook_mt 的公共接口，影响面比调阈值大得多，单独议。 */
#define TB_MM_MIN ((double)(1 << 24))   /* 矩阵乘：1670 万次乘加起并行 */

static double sig(double x);   /* 定义在下方 sigmoid 区 */

typedef struct {
    Value m1, m2, m3, out;   /* 三个输入槽 + 输出 */
    size_t k1, k2;           /* 维度槽 */
    double *parts;           /* 归约分块偏经（MT_CHUNKS 长） */
} TbJob;

static void dot_chunk(int cid, long long ra, long long rb, void *ud)
{
    TbJob *x = ud;
    (void)cid;
    /* AVX2 分块微内核（MR=4/NR=8）：8 条独立 FMA 链打满 FMA 吞吐 */
    RtTensor *A = rt_as_tensor(x->m1), *B = rt_as_tensor(x->m2), *O = rt_as_tensor(x->out);
    size_t ac = (size_t)x->k1, bc = (size_t)x->k2;
    double *Ad = A->data, *Bd = B->data, *Od = O->data;
    for (long long i = ra; i < rb; i++)
        for (size_t j = 0; j < bc; j++) Od[(size_t)i * bc + j] = 0;
    tb_matmul_tile(Ad, Bd, Od, ac, bc, (size_t)ra, (size_t)rb);
}

static void lin_chunk(int cid, long long ra, long long rb, void *ud)
{
    TbJob *x = ud;
    (void)cid;
    /* AVX2 分块微内核 + 偏置：O = b + X@W（先填偏置，再累加 matmul） */
    RtTensor *X = rt_as_tensor(x->m1), *W = rt_as_tensor(x->m2),
             *Bv = rt_as_tensor(x->m3), *O = rt_as_tensor(x->out);
    size_t ac = (size_t)x->k1, bc = (size_t)x->k2;
    double *Xd = X->data, *Wd = W->data, *Bd = Bv->data, *Od = O->data;
    for (long long i = ra; i < rb; i++)
        for (size_t j = 0; j < bc; j++) Od[(size_t)i * bc + j] = Bd[j];
    tb_matmul_tile(Xd, Wd, Od, ac, bc, (size_t)ra, (size_t)rb);
}

static void add_chunk(int cid, long long ra, long long rb, void *ud)
{
    TbJob *x = ud;
    (void)cid;
    for (long long i = ra; i < rb; i++)
        for (size_t j = 0; j < x->k2; j++)
            set_at(x->out, (size_t)i, j,
                   at(x->m1, (size_t)i, j, "tb.add") + at(x->m2, (size_t)i, j, "tb.add"));
}

static void mul_chunk(int cid, long long ra, long long rb, void *ud)
{
    TbJob *x = ud;
    (void)cid;
    for (long long i = ra; i < rb; i++)
        for (size_t j = 0; j < x->k2; j++)
            set_at(x->out, (size_t)i, j,
                   at(x->m1, (size_t)i, j, "tb.mul") * at(x->m2, (size_t)i, j, "tb.mul"));
}

static void addrow_chunk(int cid, long long ra, long long rb, void *ud)
{
    TbJob *x = ud;
    (void)cid;
    for (long long i = ra; i < rb; i++)
        for (size_t j = 0; j < x->k2; j++)
            set_at(x->out, (size_t)i, j,
                   at(x->m1, (size_t)i, j, "tb.addrow") + at(x->m2, 0, j, "tb.addrow"));
}

static void relu_chunk(int cid, long long ra, long long rb, void *ud)
{
    TbJob *x = ud;
    (void)cid;
    for (long long i = ra; i < rb; i++)
        for (size_t j = 0; j < x->k2; j++) {
            double v = at(x->m1, (size_t)i, j, "tb.relu");
            set_at(x->out, (size_t)i, j, v > 0 ? v : 0.0);
        }
}

static void sigmoid_chunk(int cid, long long ra, long long rb, void *ud)
{
    TbJob *x = ud;
    (void)cid;
    for (long long i = ra; i < rb; i++)
        for (size_t j = 0; j < x->k2; j++)
            set_at(x->out, (size_t)i, j, sig(at(x->m1, (size_t)i, j, "tb.sigmoid")));
}

static void softmax_chunk(int cid, long long ra, long long rb, void *ud)
{
    TbJob *x = ud;
    (void)cid;
    size_t c = x->k2;
    double *tmp = (double *)malloc(c * sizeof(double));   /* 原生内存，非 GC */
    if (!tmp)
        tb_die("tb.softmax 内存不足");
    for (long long i = ra; i < rb; i++) {
        double mx = at(x->m1, (size_t)i, 0, "tb.softmax");
        for (size_t j = 1; j < c; j++) {
            double v = at(x->m1, (size_t)i, j, "tb.softmax");
            if (v > mx) mx = v;
        }
        double s = 0;
        for (size_t j = 0; j < c; j++) {
            tmp[j] = exp(at(x->m1, (size_t)i, j, "tb.softmax") - mx);
            s += tmp[j];
        }
        for (size_t j = 0; j < c; j++)
            set_at(x->out, (size_t)i, j, tmp[j] / s);
    }
    free(tmp);
}

static void mse_chunk(int cid, long long ra, long long rb, void *ud)
{
    TbJob *x = ud;
    double s = 0;
    for (long long i = ra; i < rb; i++)
        for (size_t j = 0; j < x->k2; j++) {
            double d = at(x->m1, (size_t)i, j, "tb.mse") - at(x->m2, (size_t)i, j, "tb.mse");
            s += d * d;
        }
    x->parts[cid] = s;
}

static void crossent_chunk(int cid, long long ra, long long rb, void *ud)
{
    TbJob *x = ud;
    double s = 0;
    for (long long i = ra; i < rb; i++) {
        size_t r = (size_t)i;
        size_t kc = cols_of(x->m2, "tb.crossent");
        if (kc < 1) tb_die("tb.crossent：目标行必须含类别下标");
        long long cls = (long long)at(x->m2, r, 0, "tb.crossent");
        size_t yc = cols_of(x->m1, "tb.crossent");
        if (cls < 0 || (size_t)cls >= yc)
            tb_die("tb.crossent：类别下标 %lld 越界（0..%zu）", cls, yc - 1);
        double p = at(x->m1, r, (size_t)cls, "tb.crossent");
        if (p < 1e-12) p = 1e-12;
        s += -log(p);
    }
    x->parts[cid] = s;
}

/* ================= 创建 / 维度 ================= */

Value rt_tb_mat(Value rv, Value cv)
{
    long long r = (long long)numv(rv, "tb.mat 的行数");
    long long c = (long long)numv(cv, "tb.mat 的列数");
    if (r < 1 || r > 100000 || c < 1 || c > 100000)
        tb_die("tb.mat 行列数超范围（1..10万）");
    return new_mat((size_t)r, (size_t)c);
}

Value rt_tb_rand(Value rv, Value cv)
{
    long long r = (long long)numv(rv, "tb.rand 的行数");
    long long c = (long long)numv(cv, "tb.rand 的列数");
    if (r < 1 || r > 100000 || c < 1 || c > 100000)
        tb_die("tb.rand 行列数超范围");
    Value m = new_mat((size_t)r, (size_t)c);
    for (size_t i = 0; i < (size_t)r; i++)
        for (size_t j = 0; j < (size_t)c; j++)
            set_at(m, i, j, (double)rand() * 2.0 / RAND_MAX - 1.0);
    return m;
}

/* ---- float32 版本：GPU 通路只吃 f32，所以「造一批 f32 矩阵」是一等需求 ---- */
Value rt_tb_mat32(Value rv, Value cv)
{
    long long r = (long long)numv(rv, "tb.mat32 的行数");
    long long c = (long long)numv(cv, "tb.mat32 的列数");
    if (r < 1 || r > 100000 || c < 1 || c > 100000)
        tb_die("tb.mat32 行列数超范围（1..10万）");
    return new_mat_p((size_t)r, (size_t)c, TENSOR_F32);
}

Value rt_tb_rand32(Value rv, Value cv)
{
    long long r = (long long)numv(rv, "tb.rand32 的行数");
    long long c = (long long)numv(cv, "tb.rand32 的列数");
    if (r < 1 || r > 100000 || c < 1 || c > 100000)
        tb_die("tb.rand32 行列数超范围（1..10万）");
    Value m = new_mat_p((size_t)r, (size_t)c, TENSOR_F32);
    for (size_t i = 0; i < (size_t)r; i++)
        for (size_t j = 0; j < (size_t)c; j++)
            set_at(m, i, j, (double)rand() * 2.0 / RAND_MAX - 1.0);
    return m;
}

/* ---- 设备查询：让程序自己问「现在到底跑在哪」，
 *      而不是猜、更不是看 device 那行写了什么（auto 可能落到 CPU） ---- */
int rt_tb_on_gpu(void)
{
    return rt_device_backend() == 2 ? 1 : 0;
}

Value rt_tb_is_gpu(void)
{
    return rt_bool(rt_tb_on_gpu());
}

Value rt_tb_gpu_name(void)
{
    return rt_str(gpu_device_name());
}

Value rt_tb_rows(Value m)
{
    return rt_int((long long)rows_of(m, "tb.rows"));
}

Value rt_tb_cols(Value m)
{
    return rt_int((long long)cols_of(m, "tb.cols"));
}

/* ================= 前向算子 ================= */

/* 结果精度：任一输入是 f32 就是 f32（跟 arith() 的传播规则一致）。
 * 这条必须在 CPU 和 GPU 两条路上给出同一个答案 ——
 * 否则「换个 device 档位，返回类型就变了」，那是会咬人的暗坑。 */
static int dot_prec(Value a, Value b)
{
    RtTensor *ta = tens_of(a, "tb.dot"), *tb = tens_of(b, "tb.dot");
    return (ta->prec == TENSOR_F32 || tb->prec == TENSOR_F32)
           ? TENSOR_F32 : TENSOR_F64;
}

/* CPU 微内核全程用 double 累加，直写缓冲、不经过 set_at。
 * 输出要是 f32 就得在收尾时统一舍一遍，否则 f32 张量里会混进 double 值，
 * 「每个值都能被 float32 精确表示」这条不变量就破了。 */
static void round_out(Value m)
{
    RtTensor *t = rt_as_tensor(m);
    size_t n, i;
    if (t->prec != TENSOR_F32)
        return;
    n = 1;
    for (int k = 0; k < t->ndim; k++)
        n *= (size_t)t->dims[k];
    for (i = 0; i < n; i++)
        t->data[i] = rt_tensor_round(TENSOR_F32, t->data[i]);
}

Value rt_tb_dot(Value a, Value b)
{
    size_t ar = rows_of(a, "tb.dot"), ac = cols_of(a, "tb.dot");
    size_t br = rows_of(b, "tb.dot"), bc = cols_of(b, "tb.dot");
    Value out;
    if (ac != br)
        tb_die("tb.dot 维度不符：%zux%zu 乘 %zux%zu（中间要对上）", ar, ac, br, bc);
    if (gpu_dot_try(a, b, &out, ar, bc, ac))
        return out;
    out = new_mat_p(ar, bc, dot_prec(a, b));
    if ((double)ar * (double)ac * (double)bc >= TB_MM_MIN) {
        TbJob x = {.m1 = a, .m2 = b, .out = out, .k1 = ac, .k2 = bc};
        mt_parallel((long long)ar, dot_chunk, &x);
        round_out(out);
        return out;
    }
    /* 小矩阵：直接走 AVX2 分块微内核（与 dot_chunk 同一条代码路径） */
    double *Ad = rt_as_tensor(a)->data, *Bd = rt_as_tensor(b)->data, *Od = rt_as_tensor(out)->data;
    for (size_t i = 0; i < ar; i++)
        for (size_t j = 0; j < bc; j++) Od[i * bc + j] = 0;
    tb_matmul_tile(Ad, Bd, Od, ac, bc, 0, ar);
    round_out(out);
    return out;
}

Value rt_tb_tr(Value m)
{
    /* lin 视图转置：(N, R*C) 的 3D 也按 (R*C, N) 转（数据行主序，直接搬） */
    RtTensor *t = tens_of(m, "tb.tr");
    size_t r = t->dims[0], c = tb_rest(t);
    Value out = new_mat(c, r);
    RtTensor *to = rt_as_tensor(out);
    for (size_t i = 0; i < r; i++)
        for (size_t j = 0; j < c; j++)
            to->data[j * r + i] = t->data[i * c + j];
    return out;
}

Value rt_tb_add(Value a, Value b)
{
    size_t r = rows_of(a, "tb.add"), c = cols_of(a, "tb.add");
    if (rows_of(b, "tb.add") != r || cols_of(b, "tb.add") != c)
        tb_die("tb.add 形状不同（%zux%zu vs %zux%zu）",
               r, c, rows_of(b, "tb.add"), cols_of(b, "tb.add"));
    Value out = new_mat(r, c);
    if ((double)r * (double)c >= TB_EW_MIN) {
        TbJob x = {.m1 = a, .m2 = b, .out = out, .k2 = c};
        mt_parallel((long long)r, add_chunk, &x);
        return out;
    }
    for (size_t i = 0; i < r; i++)
        for (size_t j = 0; j < c; j++)
            set_at(out, i, j, at(a, i, j, "tb.add") + at(b, i, j, "tb.add"));
    return out;
}

Value rt_tb_mul(Value a, Value b)
{
    /* 逐元素乘只要求「总元素数相同」：3D 激活可以直接配 2D 扁平梯度
     * （行主序下同一份 flat 数据），形状不必一致 */
    RtTensor *ta = tens_of(a, "tb.mul"), *tbb = tens_of(b, "tb.mul");
    size_t na = tb_total(ta), nb = tb_total(tbb);
    if (na != nb)
        tb_die("tb.mul 总元素数不同（%zu vs %zu）", na, nb);
    Value out = rt_tensor_new(ta->ndim, ta->dims);
    RtTensor *to = rt_as_tensor(out);
    for (size_t i = 0; i < na; i++)
        to->data[i] = rt_tensor_round(to->prec, ta->data[i] * tbb->data[i]);
    return out;
}

/* addrow(m, row)：把 1×c 的行加到每一行（线性层偏置用） */
Value rt_tb_addrow(Value m, Value row)
{
    size_t r = rows_of(m, "tb.addrow"), c = cols_of(m, "tb.addrow");
    if (rows_of(row, "tb.addrow") != 1 || cols_of(row, "tb.addrow") != c)
        tb_die("tb.addrow 第二参数要 1x%zu 的行，得到 %zux%zu",
               c, rows_of(row, "tb.addrow"), cols_of(row, "tb.addrow"));
    Value out = new_mat(r, c);
    if ((double)r * (double)c >= TB_EW_MIN) {
        TbJob x = {.m1 = m, .m2 = row, .out = out, .k2 = c};
        mt_parallel((long long)r, addrow_chunk, &x);
        return out;
    }
    for (size_t i = 0; i < r; i++)
        for (size_t j = 0; j < c; j++)
            set_at(out, i, j, at(m, i, j, "tb.addrow") + at(row, 0, j, "tb.addrow"));
    return out;
}

Value rt_tb_relu(Value m)
{
    /* 保形：4D 批量激活不能被摊平（下一层 conv 还要 4D）。扁平迭代。 */
    RtTensor *tm = tens_of(m, "tb.relu");
    Value out = rt_tensor_new(tm->ndim, tm->dims);
    RtTensor *to = rt_as_tensor(out);
    size_t n = tb_total(tm);
    for (size_t i = 0; i < n; i++)
        to->data[i] = rt_tensor_round(to->prec, tm->data[i] > 0 ? tm->data[i] : 0.0);
    return out;
}

static double sig(double x) { return 1.0 / (1.0 + exp(-x)); }

Value rt_tb_sigmoid(Value m)
{
    size_t r = rows_of(m, "tb.sigmoid"), c = cols_of(m, "tb.sigmoid");
    Value out = new_mat(r, c);
    if ((double)r * (double)c >= TB_EW_MIN) {
        TbJob x = {.m1 = m, .out = out, .k2 = c};
        mt_parallel((long long)r, sigmoid_chunk, &x);
        return out;
    }
    for (size_t i = 0; i < r; i++)
        for (size_t j = 0; j < c; j++)
            set_at(out, i, j, sig(at(m, i, j, "tb.sigmoid")));
    return out;
}

/* linear(x, w, b) = x@w + b（b 是 1×out 的行，广播到每行）
 * x 允许 3D 批量 (N, R, C)：按 lin 视图 = (N, R*C) 参与矩阵乘，零拷贝 */
Value rt_tb_lin(Value x, Value w, Value b)
{
    RtTensor *txn = tens_of(x, "tb.lin");
    size_t xr = txn->dims[0], xc = tb_rest(txn);
    size_t wr = rows_of(w, "tb.lin"), wc = cols_of(w, "tb.lin");
    if (xc != wr)
        tb_die("tb.lin 维度不符：x 是 %zux%zu，w 是 %zux%zu（x列数要=w行数）",
               xr, xc, wr, wc);
    if (rows_of(b, "tb.lin") != 1 || cols_of(b, "tb.lin") != wc)
        tb_die("tb.lin 偏置 b 要是 1x%zu，得到 %zux%zu",
               wc, rows_of(b, "tb.lin"), cols_of(b, "tb.lin"));
    Value out;
    if (gpu_dot_try(x, w, &out, xr, wc, xc)) {
        add_bias_row(out, b);
        return out;
    }
    out = new_mat_p(xr, wc, dot_prec(x, w));
    if ((double)xr * (double)xc * (double)wc >= TB_MM_MIN) {
        TbJob jb = {.m1 = x, .m2 = w, .m3 = b, .out = out, .k1 = xc, .k2 = wc};
        mt_parallel((long long)xr, lin_chunk, &jb);
        round_out(out);
        return out;
    }
    double *Xd = rt_as_tensor(x)->data, *Wd = rt_as_tensor(w)->data,
           *Bd = rt_as_tensor(b)->data, *Od = rt_as_tensor(out)->data;
    for (size_t i = 0; i < xr; i++)
        for (size_t j = 0; j < wc; j++) Od[i * wc + j] = Bd[j];   /* O = 偏置 */
    tb_matmul_tile(Xd, Wd, Od, xc, wc, 0, xr);                    /* O += X @ W */
    round_out(out);
    return out;
}

/* MSE：((y-t)^2)/个数 */
Value rt_tb_mse(Value y, Value t)
{
    size_t r = rows_of(y, "tb.mse"), c = cols_of(y, "tb.mse");
    if (rows_of(t, "tb.mse") != r || cols_of(t, "tb.mse") != c)
        tb_die("tb.mse 形状不同");
    double s = 0;
    if ((double)r * (double)c >= TB_EW_MIN) {
        double parts[MT_CHUNKS] = {0};
        TbJob x = {.m1 = y, .m2 = t, .k2 = c, .parts = parts};
        int chunks = mt_parallel((long long)r, mse_chunk, &x);
        for (int i = 0; i < chunks; i++)
            s += parts[i];
    } else {
        for (size_t i = 0; i < r; i++)
            for (size_t j = 0; j < c; j++) {
                double d = at(y, i, j, "tb.mse") - at(t, i, j, "tb.mse");
                s += d * d;
            }
    }
    return rt_float(s / ((double)r * (double)c));
}
/* ================= 反向算子（手写梯度） ================= */

Value rt_tb_relu_grad(Value pre)
{
    /* 保形同 relu */
    RtTensor *tm = tens_of(pre, "tb.relu_grad");
    Value out = rt_tensor_new(tm->ndim, tm->dims);
    RtTensor *to = rt_as_tensor(out);
    size_t n = tb_total(tm);
    for (size_t i = 0; i < n; i++)
        to->data[i] = rt_tensor_round(to->prec, tm->data[i] > 0 ? 1.0 : 0.0);
    return out;
}

/* sigmoid 导数 s'(x) = s(1-s)：直接传 sigmoid 的输出 y */
Value rt_tb_sigmoid_grad(Value y)
{
    size_t r = rows_of(y, "tb.sigmoid_grad"), c = cols_of(y, "tb.sigmoid_grad");
    Value out = new_mat(r, c);
    for (size_t i = 0; i < r; i++)
        for (size_t j = 0; j < c; j++) {
            double s = at(y, i, j, "tb.sigmoid_grad");
            set_at(out, i, j, s * (1.0 - s));
        }
    return out;
}

/* dL/dy = 2(y-t)/个数 */
Value rt_tb_mse_grad(Value y, Value t)
{
    size_t r = rows_of(y, "tb.mse_grad"), c = cols_of(y, "tb.mse_grad");
    if (rows_of(t, "tb.mse_grad") != r || cols_of(t, "tb.mse_grad") != c)
        tb_die("tb.mse_grad 形状不同");
    Value out = new_mat(r, c);
    double n = (double)r * (double)c;
    for (size_t i = 0; i < r; i++)
        for (size_t j = 0; j < c; j++)
            set_at(out, i, j, 2.0 * (at(y, i, j, "tb.mse_grad")
                                     - at(t, i, j, "tb.mse_grad")) / n);
    return out;
}

/* lin 的三路梯度：out = x@w+b，已知 dL/dout（记作 g，形状同 out）*/
Value rt_tb_lin_dx(Value x, Value w, Value g)
{
    /* dx = g @ w转置；x 是 3D 批量时输出保持 x 的形状（扁平数据一致，拷贝回形） */
    Value d = rt_tb_dot(g, rt_tb_tr(w));
    RtTensor *tx = rt_as_tensor(x);
    Value out = rt_tensor_new(tx->ndim, tx->dims);
    RtTensor *to = rt_as_tensor(out), *td = rt_as_tensor(d);
    size_t n = tb_total(td);
    for (size_t i = 0; i < n; i++)
        to->data[i] = td->data[i];
    return out;
}

Value rt_tb_lin_dw(Value x, Value g)
{
    /* dw = x转置 @ g（x 3D 按 lin 视图 (N, R*C)） */
    return rt_tb_dot(rt_tb_tr(x), g);
}

Value rt_tb_lin_db(Value g)
{
    /* db = g 各行求和（1×out） */
    size_t r = rows_of(g, "tb.lin_db"), c = cols_of(g, "tb.lin_db");
    Value out = new_mat(1, c);
    for (size_t j = 0; j < c; j++) {
        double s = 0;
        for (size_t i = 0; i < r; i++)
            s += at(g, i, j, "tb.lin_db");
        set_at(out, 0, j, s);
    }
    return out;
}

/* ================= 优化器 ================= */

/* step(m, dm, lr) = m - lr*dm */
Value rt_tb_step(Value m, Value dm, Value lrv)
{
    size_t r = rows_of(m, "tb.step"), c = cols_of(m, "tb.step");
    if (rows_of(dm, "tb.step") != r || cols_of(dm, "tb.step") != c)
        tb_die("tb.step 形状不同");
    double lr = numv(lrv, "tb.step 的学习率");
    Value out = new_mat(r, c);
    for (size_t i = 0; i < r; i++)
        for (size_t j = 0; j < c; j++)
            set_at(out, i, j, at(m, i, j, "tb.step") - lr * at(dm, i, j, "tb.step"));
    return out;
}

/* ================= 分类损失（P5 扩展） ================= */

/* softmax(m)：每行做数值稳定的 softmax，输出同形矩阵 */
Value rt_tb_softmax(Value m)
{
    size_t nrows = rows_of(m, "tb.softmax");
    size_t c = cols_of(m, "tb.softmax");
    Value out = new_mat(nrows, c);
    if ((double)nrows * (double)c * 2.0 >= TB_EW_MIN) {
        TbJob x = {.m1 = m, .out = out, .k2 = c};
        mt_parallel((long long)nrows, softmax_chunk, &x);
        return out;
    }
    for (size_t r = 0; r < nrows; r++) {
        double maxv = at(m, r, 0, "tb.softmax");
        for (size_t cc = 1; cc < c; cc++) {
            double v = at(m, r, cc, "tb.softmax");
            if (v > maxv) maxv = v;
        }
        double sum = 0;
        for (size_t cc = 0; cc < c; cc++) {
            double e = exp(at(m, r, cc, "tb.softmax") - maxv);
            set_at(out, r, cc, e);
            sum += e;
        }
        for (size_t cc = 0; cc < c; cc++)
            set_at(out, r, cc, at(out, r, cc, "tb.softmax") / sum);
    }
    return out;
}

/* crossent(y_prob, target)：target 是列向量（每行一个类别下标 0..K-1）。
 * 返回标量列向量 [[平均交叉熵]]。 */
Value rt_tb_crossent(Value y, Value t)
{
    size_t ny = rows_of(y, "tb.crossent");
    size_t nt = rows_of(t, "tb.crossent");
    if (ny != nt)
        tb_die("tb.crossent：样本数不一致 %zu vs %zu", ny, nt);
    double sum = 0;
    if ((double)ny >= (double)(1 << 14)) {
        double parts[MT_CHUNKS] = {0};
        TbJob x = {.m1 = y, .m2 = t, .parts = parts};
        int chunks = mt_parallel((long long)ny, crossent_chunk, &x);
        for (int i = 0; i < chunks; i++)
            sum += parts[i];
    } else {
        for (size_t r = 0; r < ny; r++) {
            size_t kc = cols_of(t, "tb.crossent");
            if (kc < 1) tb_die("tb.crossent：目标行必须含类别下标");
            long long cls = (long long)at(t, r, 0, "tb.crossent");
            size_t yc = cols_of(y, "tb.crossent");
            if (cls < 0 || (size_t)cls >= yc)
                tb_die("tb.crossent：类别下标 %lld 越界（0..%zu）", cls, yc - 1);
            double p = at(y, r, (size_t)cls, "tb.crossent");
            if (p < 1e-12) p = 1e-12;
            sum += -log(p);
        }
    }
    Value out = new_mat(1, 1);
    set_at(out, 0, 0, sum / (double)ny);
    return out;
}

/* crossent_grad(y_prob, target)：dL/dy = (y - onehot(t)) / N */
Value rt_tb_crossent_grad(Value y, Value t)
{
    size_t ny = rows_of(y, "tb.crossent");
    size_t nt = rows_of(t, "tb.crossent");
    if (ny != nt)
        tb_die("tb.crossent_grad：样本数不一致");
    size_t nc = cols_of(y, "tb.crossent_grad");
    Value out = new_mat(ny, nc);
    double n = (double)ny;
    for (size_t r = 0; r < ny; r++) {
        size_t kc = cols_of(t, "tb.crossent_grad");
        if (kc < 1) tb_die("tb.crossent_grad：目标行必须含类别下标");
        long long cls = (long long)at(t, r, 0, "tb.crossent_grad");
        for (size_t c = 0; c < nc; c++)
            set_at(out, r, c, (at(y, r, c, "tb.crossent_grad") - (c == (size_t)cls ? 1.0 : 0.0)) / n);
    }
    return out;
}

/* argmax(m)：每行最大值下标，输出列向量 */
Value rt_tb_argmax(Value m)
{
    size_t nrows = rows_of(m, "tb.argmax");
    size_t c = cols_of(m, "tb.argmax");
    Value out = new_mat(nrows, 1);
    for (size_t r = 0; r < nrows; r++) {
        size_t best = 0;
        double bv = at(m, r, 0, "tb.argmax");
        for (size_t cc = 1; cc < c; cc++) {
            double v = at(m, r, cc, "tb.argmax");
            if (v > bv) { bv = v; best = cc; }
        }
        set_at(out, r, 0, (double)best);
    }
    return out;
}

/* ================= 优化器（P5 扩展） ================= */

/* sgd(w, dw, lr)：w = w - lr*dw（就地修改并返回 w） */
Value rt_tb_sgd(Value w, Value dw, Value lrv)
{
    double lr = (IS_FLT(lrv)) ? AS_FLT(lrv) : (double)rt_to_ll(lrv);
    size_t nw = rows_of(w, "tb.sgd");
    size_t nd = rows_of(dw, "tb.sgd");
    if (nw != nd) tb_die("tb.sgd：行数不一致 %zu vs %zu", nw, nd);
    size_t cw = cols_of(w, "tb.sgd");
    size_t cd = cols_of(dw, "tb.sgd");
    if (cw != cd) tb_die("tb.sgd：列数不一致 %zu vs %zu", cw, cd);
    for (size_t r = 0; r < nw; r++)
        for (size_t c = 0; c < cw; c++)
            set_at(w, r, c, at(w, r, c, "tb.sgd") - lr * at(dw, r, c, "tb.sgd"));
    return w;
}

/* adam 系列：三态存在语言层（m/v 矩阵由用户持有），这里提供单步更新 */
Value rt_tb_adam(Value w, Value dw, Value m, Value v,
                 Value lrv, Value beta1v, Value beta2v, Value stepv)
{
    double lr = (IS_FLT(lrv)) ? AS_FLT(lrv) : (double)rt_to_ll(lrv);
    double b1 = (IS_FLT(beta1v)) ? AS_FLT(beta1v) : (double)rt_to_ll(beta1v);
    double b2 = (IS_FLT(beta2v)) ? AS_FLT(beta2v) : (double)rt_to_ll(beta2v);
    double step = (IS_FLT(stepv)) ? AS_FLT(stepv) : (double)rt_to_ll(stepv);
    size_t nw = rows_of(w, "tb.adam");
    size_t nd = rows_of(dw, "tb.adam");
    if (nw != nd) tb_die("tb.adam：行数不一致");
    size_t cw = cols_of(w, "tb.adam");
    size_t cd = cols_of(dw, "tb.adam");
    size_t cm = cols_of(m, "tb.adam");
    size_t cv = cols_of(v, "tb.adam");
    if (cw != cd || cw != cm || cw != cv)
        tb_die("tb.adam：形状不一致");
    for (size_t r = 0; r < nw; r++)
        for (size_t c = 0; c < cw; c++) {
            double g = at(dw, r, c, "tb.adam");
            double mm = b1 * at(m, r, c, "tb.adam") + (1 - b1) * g;
            double vv = b2 * at(v, r, c, "tb.adam") + (1 - b2) * g * g;
            set_at(m, r, c, mm);
            set_at(v, r, c, vv);
            double mh = mm / (1 - pow(b1, step));
            double vh = vv / (1 - pow(b2, step));
            set_at(w, r, c, at(w, r, c, "tb.adam") - lr * mh / (sqrt(vh) + 1e-8));
        }
    return w;
}

/* ================= 数据原语（P5 扩展） ================= */

/* shuffle(表, 种子)：Fisher-Yates，返回新表（元素引用不变） */
Value rt_tb_shuffle(Value list, Value seedv)
{
    if (!IS_LIST(list) || AS_LIST(list) == NULL)
        tb_die("tb.shuffle 需要列表");
    RtList *L = AS_LIST(list);
    unsigned seed = (unsigned)rt_to_ll(seedv);
    Value out = rt_list_new();
    for (size_t i = 0; i < L->len; i++)
        rt_push(&out, L->items[i]);
    srand(seed);
    for (size_t i = AS_LIST(out)->len; i > 1; i--) {
        size_t j = (size_t)(rand() % i);
        Value t = AS_LIST(out)->items[i - 1];
        AS_LIST(out)->items[i - 1] = AS_LIST(out)->items[j];
        AS_LIST(out)->items[j] = t;
    }
    return out;
}

/* onehot(n, 类数)：[[0..1..0]] 列向量（n 是单值） */
Value rt_tb_onehot(Value nv, Value kv)
{
    long long n = rt_to_ll(nv);
    long long k = rt_to_ll(kv);
    if (k <= 0) tb_die("tb.onehot：类数必须为正");
    if (n < 0 || n >= k) tb_die("tb.onehot：下标 %lld 越界（0..%lld）", n, k - 1);
    Value out = new_mat(1, (size_t)k);
    set_at(out, 0, (size_t)n, 1.0);
    return out;
}

/* batch(表, i, 大小)：取出 [i*大小, i*大小+大小) 的切片（不足则取到尾部） */
Value rt_tb_batch(Value list, Value iv, Value szv)
{
    if (!IS_LIST(list) || AS_LIST(list) == NULL)
        tb_die("tb.batch 需要列表");
    RtList *L = AS_LIST(list);
    long long i = rt_to_ll(iv);
    long long sz = rt_to_ll(szv);
    if (sz <= 0) tb_die("tb.batch：大小必须为正");
    long long start = i * sz;
    if (start < 0) start = 0;
    if (start >= (long long)L->len) {
        Value empty = rt_list_new();
        return empty;
    }
    long long end = start + sz;
    if (end > (long long)L->len) end = (long long)L->len;
    Value out = rt_list_new();
    for (long long k = start; k < end; k++)
        rt_push(&out, L->items[k]);
    return out;
}

/* ================= 训练算子：卷积 / 池化 / 归一化 / dropout =================
 *
 * 形状约定（先读这段，否则参数看不懂）：
 * 语言层的 tensor 一等类型只能构造和读取**二维**（tensor.from / tensor.to_list /
 * T[i,j] 都按 dims[0]×dims[1] 走，见 pybook_rt.c），所以这里一律用二维张量，
 * 多通道靠「把 (C,H,W) 压成 (C*H, W)」这个视图表达：
 *
 *   特征图 x : (C*H, W)      行号 = 通道号*H + 行号，列号 = 列号
 *   卷积核 k : (O, I*kh*kw)  行号 = 输出通道，列号 = (输入通道*核高 + 行号)*核宽 + 列号
 *   输出   y : (O*OH, OW)    行号 = 输出通道*OH + 行号
 *
 * 输入通道数 I 由核的列数除以 核高*核宽 反推（不用额外传参），输出通道数 O 是核的行数。
 * C=1 时三者退化成最经典的 (H,W) / (kh,kw) / (OH,OW)，读法一模一样。
 *
 * 池化只按「一张图 (H,W)」处理（单通道）：conv2d 出来的多通道图请用 tensor.slice
 * 按通道切片后逐块池化（见 tb.maxpool 的注释）。
 *
 * 多返回值一律用列表，和 tb.qr / tb.cholesky / tb.svd 一个约定（la_pack / la_pack3）：
 *   tb.batchnorm     → [y, 本次用的均值, 本次用的方差, 新running均值, 新running方差]
 *   tb.batchnorm_dx  → [dx, dgamma, dbeta]
 *   tb.layernorm     → [y, 每行均值, 每行方差]
 *   tb.layernorm_dx  → [dx, dgamma, dbeta]
 * 「本次用的方差」已经**含 eps**（反向直接开方即可，不用再传 eps 进来）；
 * 「新 running 方差」是标准口径的 σ²（不含 eps），推理时配 eps 使用。
 *
 * 精度：输入张量的 prec 不影响输出 —— 本组算子一律出 f64（与 tb.lin 等既有算子一致）。
 * 梯度全部手写解析式，不做自动微分；反向约定和 tb.lin_dx 一致：
 * 「已知 dL/d输出（记作 gy）求 dL/d某个输入」。
 */

/* ---- 小工具：裸缓冲读写（循环内不做形状校验，省一次 tens_of 调用）---- */
static double tget(const RtTensor *t, size_t r, size_t c)
{
    return t->data[r * (size_t)t->dims[1] + c];
}

static void tset(RtTensor *t, size_t r, size_t c, double v)
{
    t->data[r * (size_t)t->dims[1] + c] = rt_tensor_round(t->prec, v);
}

/* 累加（不是覆盖）：反向里一个像素可能被好几个窗口同时选中，梯度要加起来。
   输出张量由 calloc 起步是全 0，所以直接 += 就对。 */
static void tadd(RtTensor *t, size_t r, size_t c, double v)
{
    t->data[r * (size_t)t->dims[1] + c] = rt_tensor_round(
        t->prec, t->data[r * (size_t)t->dims[1] + c] + v);
}

/* 整数标量参数：范围校验 + 三段式报错（形状算错是最常见的事，报清楚省得瞎猜） */
static int tb_iv(Value v, int lo, int hi, const char *who, const char *what)
{
    double d = numv(v, who);
    if (d != (double)(long long)d)
        tb_die("%s 的%s要是整数，收到 %g\n"
               "  为什么：核尺寸、步长、填充这些是整数，给小数说明算错了\n"
               "  怎么改：写成整数", who, what, d);
    if ((long long)d < lo || (long long)d > hi)
        tb_die("%s 的%s是 %lld，越界（要 %d~%d）\n"
               "  怎么改：改成 %d~%d 之间的整数", who, what, (long long)d, lo, hi, lo, hi);
    return (int)d;
}

/* 多返回值打包（列表），和 la_pack 一个味道 */
static Value tb_packn(int n, ...)
{
    va_list ap;
    Value l = rt_list_new();
    va_start(ap, n);
    for (int i = 0; i < n; i++) {
        Value v = va_arg(ap, Value);
        rt_push(&l, v);
    }
    va_end(ap);
    return l;
}

/* (1, n) 行向量 —— 参数/统计量统一这个形状（dgamma、dbeta、偏置、running 统计） */
static Value tb_row(size_t n)
{
    return new_mat(1, n ? n : 1);
}

/* 按列求均值/有偏方差（batchnorm 用；layernorm 是按行，循环顺序反过来） */
static void tb_col_mean_var(const RtTensor *x, size_t n, size_t c,
                            double *mean, double *var)
{
    for (size_t j = 0; j < c; j++) {
        double s = 0;
        for (size_t i = 0; i < n; i++) s += tget(x, i, j);
        double mu = s / (double)n;
        double v = 0;
        for (size_t i = 0; i < n; i++) {
            double d = tget(x, i, j) - mu;
            v += d * d;
        }
        mean[j] = mu;
        var[j] = v / (double)n;          /* 有偏方差（和 PyTorch 一致） */
    }
}

/* ================= A. 卷积与池化 ================= */

/* conv2d 的形状：推导 + 校验。三处除法都可能不整除，每处都给可操作的报错 */
typedef struct {
    int H, W;          /* 输入单通道 高 / 宽 */
    int I, O;          /* 输入通道 / 输出通道 */
    int kh, kw, st, pad;
    int OH, OW;
    int kc;            /* 核的行长（摊平布局是 I*kh*kw，小图布局是 kw） */
    int N;             /* 批量：3D (N,I*H,W) / 4D (N,I,H,W) 输入时 >1；2D 恒 1 */
} TbConv;

static void tb_conv_shape(Value xv, Value kv, int kh, int kw, int st, int pad,
                          const char *who, TbConv *c)
{
    RtTensor *tx = tens_of(xv, who), *tk = tens_of(kv, who);
    size_t xr, xc, kc, patch;
    if (tx->ndim < 2 || tx->ndim > 4 || tk->ndim != 2)
        tb_die("%s：输入要 2D(单图)/3D(批量)/4D(批量+分通道)，核要 2D"
               "（当前输入 %d 维、核 %d 维）", who, tx->ndim, tk->ndim);
    if (tx->ndim == 2) {
        xr = (size_t)tx->dims[0];
        xc = (size_t)tx->dims[1];
    } else if (tx->ndim == 3) {          /* 批量：(N, I*H, W) */
        xr = (size_t)tx->dims[1];
        xc = (size_t)tx->dims[2];
    } else {                              /* 批量 4 维：(N, I, H, W) */
        xr = (size_t)tx->dims[2];
        xc = (size_t)tx->dims[3];
    }
    kc = (size_t)tk->dims[1];
    patch = (size_t)kh * (size_t)kw;
    if (kc % patch == 0 && kc >= patch) {
        c->I = (int)(kc / patch);
        c->O = (int)tk->dims[0];
    } else if ((size_t)tk->dims[0] == (size_t)kh && kc == (size_t)kw) {
        c->I = 1;
        c->O = 1;
    } else {
        tb_die("%s：核的形状 %dx%d 两种布局都不匹配（核高=%d 核宽=%d）",
               who, (int)tk->dims[0], (int)tk->dims[1], kh, kw);
    }
    c->kc = (int)kc;
    if (tx->ndim == 4) {                     /* 批量 4 维：(N, I, H, W) */
        c->N = (int)tx->dims[0];
        if ((size_t)tx->dims[1] != (size_t)c->I)
            tb_die("%s：4 维输入的通道 %d 与核的输入通道 %d 不一致",
                   who, (int)tx->dims[1], c->I);
        c->H = (int)tx->dims[2];
    } else if (tx->ndim == 3) {              /* 批量：(N, I*H, W)，批次在最外 */
        c->N = (int)tx->dims[0];
        if ((size_t)tx->dims[1] % (size_t)c->I)
            tb_die("%s：批量输入的行维 %zu 不是 输入通道数 %d 的整数倍",
                   who, (size_t)tx->dims[1], c->I);
        c->H = (int)((size_t)tx->dims[1] / (size_t)c->I);
    } else {
        c->N = 1;
        if (xr % (size_t)c->I)
            tb_die("%s：输入行数 %zu 不是 输入通道数 %d 的整数倍",
                   who, xr, c->I);
        c->H = (int)(xr / (size_t)c->I);
    }
    c->W = (int)xc;
    c->kh = kh; c->kw = kw; c->st = st; c->pad = pad;
    if (c->H + 2 * pad < kh || c->W + 2 * pad < kw)
        tb_die("%s：输入 %dx%d 配 填充%d 之后还是装不下 %dx%d 的核",
               who, c->H, c->W, pad, kh, kw);
    c->OH = (c->H + 2 * pad - kh) / st + 1;
    c->OW = (c->W + 2 * pad - kw) / st + 1;
}

/* 取输入的一个元素；越界（填充区）返回 0 —— 本组算子只支持零填充 */
static double tb_conv_at(const RtTensor *tx, const TbConv *c, int b, int ic,
                         int ih, int iw)
{
    int hh = ih - c->pad, ww = iw - c->pad;
    if (hh < 0 || ww < 0 || hh >= c->H || ww >= c->W)
        return 0.0;
    return tx->data[((size_t)b * (size_t)c->I + (size_t)ic) * (size_t)c->H
                    * (size_t)c->W + (size_t)hh * (size_t)c->W + ww];
}

/* conv2d 的 GPU 路由：门槛与 gpu_dot_try 同哲学——
 *   ① 后端是 GPU；② 两个张量都是 float32；③ pad=0（kernel 只写了直卷）；
 *   ④ 工作量 O·OH·OW·I·kh·kw 达 GPU_CONV_MIN_MAC；
 *   ⑤ conv 内核编译成功（没编出来降级 CPU，不堵通路）。
 * 上卡后失败 = 故障，tb_die 不吞（与 gpu_dot_try 同款：回退是设计，报错是真出事）。
 * 放在 TbConv 定义之后：结构体 1178 行才声明，提前了 gcc 不认。 */
static int gpu_conv_try(Value x, Value k, Value *outp, const TbConv *c)
{
    RtTensor *tx = tens_of(x, "tb.conv2d"), *tk = tens_of(k, "tb.conv2d");
    RtTensor *to;
    int       d[2];

    if (rt_device_backend() != 2)
        return 0;
    if (tx->prec != TENSOR_F32 || tk->prec != TENSOR_F32)
        return 0;
    if (c->pad != 0)
        return 0;
    if (!gpu_conv_ready())
        return 0;
    if ((double)c->O * (double)c->OH * (double)c->OW
        * (double)c->I * (double)c->kh * (double)c->kw
        < (double)GPU_CONV_MIN_MAC)
        return 0;

    d[0] = c->O * c->OH;
    d[1] = c->OW;
    outp[0] = new_mat_p(d[0], d[1], TENSOR_F32);
    to = rt_as_tensor(outp[0]);
    if (getenv("PYBOOK_GPU_TRACE"))
        fprintf(stderr, "[gpu] conv2d %dx%d I%d O%d K%dx%d S%d 上卡\n",
                c->H, c->W, c->I, c->O, c->kh, c->kw, c->st);
    if (!gpu_conv2d_f32(tx->data, tk->data, to->data, c->H, c->W, c->I, c->O,
                        c->kh, c->kw, c->OH, c->OW, c->st, c->N))
        tb_die("tb.conv2d 已经决定上 GPU，但 kernel 没跑成：%s"
               "\n  怎么改：这个形状/显存是硬件限制，不是程序的错；"
               "可以改小图，或改用 device cpu。",
               gpu_last_error());
    return 1;
}

Value rt_tb_conv2d(Value x, Value k, Value khv, Value kwv, Value stv, Value padv)
{
    const char *who = "tb.conv2d";
    TbConv c;
    RtTensor *tx, *tk, *ty;
    Value y;
    int o, ic, i, j, oh, ow, d[2];
    tb_conv_shape(x, k,
                  tb_iv(khv, 1, 4096, who, "核高"), tb_iv(kwv, 1, 4096, who, "核宽"),
                  tb_iv(stv, 1, 4096, who, "步长"), tb_iv(padv, 0, 4096, who, "填充"), who, &c);
    tx = tens_of(x, who);
    tk = tens_of(k, who);
    if (gpu_conv_try(x, k, &y, &c))
        return y;
    if (tx->ndim == 4) {                 /* 批量 4 维：输出 (N, O, OH, OW) */
        int dd[4] = { c.N, c.O, c.OH, c.OW };
        y = rt_tensor_new(4, dd);
    } else if (tx->ndim == 3) {          /* 批量 3 维：输出 (N, O*OH, OW) */
        int dd[3] = { c.N, c.O * c.OH, c.OW };
        y = rt_tensor_new(3, dd);
    } else {
        d[0] = c.O * c.OH;
        d[1] = c.OW;
        y = rt_tensor_new(2, d);
    }
    ty = rt_as_tensor(y);
    for (int b = 0; b < c.N; b++)
        for (o = 0; o < c.O; o++)
            for (oh = 0; oh < c.OH; oh++)
                for (ow = 0; ow < c.OW; ow++) {
                    double s = 0;
                    for (ic = 0; ic < c.I; ic++)
                        for (i = 0; i < c.kh; i++)
                            for (j = 0; j < c.kw; j++)
                                s += tb_conv_at(tx, &c, b, ic, oh * c.st + i, ow * c.st + j)
                                   * tk->data[(size_t)o * (size_t)c.kc
                                              + ((size_t)(ic * c.kh + i)) * (size_t)c.kw + j];
                    /* 2D/3D/4D 输出的 flat 布局一致，直接按 flat 下标写 */
                    ty->data[((size_t)b * (size_t)c.O + (size_t)o) * (size_t)c.OH
                             * (size_t)c.OW + (size_t)oh * (size_t)c.OW + (size_t)ow] =
                        rt_tensor_round(ty->prec, s);
                }
    return y;
}

/* dL/dx：把上游梯度按核「撒」回输入（卷积在反向里是相关，不是卷积）。
 * dx[b,ic,ih,iw] = Σ_o Σ_(oh,ow) gy[b,o,oh,ow] · k[o, ic, ih-oh·st+pad, iw-ow·st+pad] */
Value rt_tb_conv2d_dx(Value x, Value k, Value gy, Value khv, Value kwv,
                      Value stv, Value padv)
{
    const char *who = "tb.conv2d_dx";
    TbConv c;
    RtTensor *tx, *tk, *tg, *tdx;
    Value dx;
    int o, ic, ih, iw, oh, ow;
    tb_conv_shape(x, k,
                  tb_iv(khv, 1, 4096, who, "核高"), tb_iv(kwv, 1, 4096, who, "核宽"),
                  tb_iv(stv, 1, 4096, who, "步长"), tb_iv(padv, 0, 4096, who, "填充"), who, &c);
    tx = tens_of(x, who);
    tk = tens_of(k, who);
    tg = tens_of(gy, who);
    if (tb_last(tg) != (size_t)c.OW
        || tb_total(tg) != (size_t)c.N * (size_t)c.O * (size_t)c.OH * (size_t)c.OW)
        tb_die("%s：上游梯度总量与输出对不上（要 %d 张 %dx%d）",
               who, c.N, c.O * c.OH, c.OW);
    dx = rt_tensor_new(tx->ndim, tx->dims);
    tdx = rt_as_tensor(dx);
    for (int b = 0; b < c.N; b++)
        for (ic = 0; ic < c.I; ic++)
            for (ih = 0; ih < c.H; ih++)
                for (iw = 0; iw < c.W; iw++) {
                    double s = 0;
                    for (o = 0; o < c.O; o++)
                        for (oh = 0; oh < c.OH; oh++)
                            for (ow = 0; ow < c.OW; ow++) {
                                int pi = ih - oh * c.st + c.pad;
                                int pj = iw - ow * c.st + c.pad;
                                if (pi < 0 || pj < 0 || pi >= c.kh || pj >= c.kw)
                                    continue;
                                s += tg->data[((size_t)b * (size_t)c.O + (size_t)o)
                                              * (size_t)c.OH * (size_t)c.OW
                                              + (size_t)oh * (size_t)c.OW + (size_t)ow]
                                   * tk->data[(size_t)o * (size_t)c.kc
                                              + ((size_t)(ic * c.kh + pi)) * (size_t)c.kw + pj];
                            }
                    tdx->data[((size_t)b * (size_t)c.I + (size_t)ic) * (size_t)c.H
                              * (size_t)c.W + (size_t)ih * (size_t)c.W + (size_t)iw] =
                        rt_tensor_round(tdx->prec, s);
                }
    return dx;
}

/* dL/dk：dk[o, ic*kh*kw + pi*kw + pj] = Σ_b Σ_(oh,ow) gy[b,o,oh,ow] · x[b,ic,oh·st+pi,ow·st+pj] */
Value rt_tb_conv2d_dk(Value x, Value k, Value gy, Value khv, Value kwv,
                      Value stv, Value padv)
{
    const char *who = "tb.conv2d_dk";
    TbConv c;
    RtTensor *tx, *tk, *tg, *tdk;
    Value dk;
    int o, ic, i, j, oh, ow, d[2];
    tb_conv_shape(x, k,
                  tb_iv(khv, 1, 4096, who, "核高"), tb_iv(kwv, 1, 4096, who, "核宽"),
                  tb_iv(stv, 1, 4096, who, "步长"), tb_iv(padv, 0, 4096, who, "填充"), who, &c);
    tx = tens_of(x, who);
    tk = tens_of(k, who);
    tg = tens_of(gy, who);
    if (tb_last(tg) != (size_t)c.OW
        || tb_total(tg) != (size_t)c.N * (size_t)c.O * (size_t)c.OH * (size_t)c.OW)
        tb_die("%s：上游梯度总量与输出对不上（要 %d 张 %dx%d）",
               who, c.N, c.O * c.OH, c.OW);
    d[0] = tk->dims[0];
    d[1] = tk->dims[1];
    dk = rt_tensor_new(2, d);
    tdk = rt_as_tensor(dk);
    for (o = 0; o < c.O; o++)
        for (ic = 0; ic < c.I; ic++)
            for (i = 0; i < c.kh; i++)
                for (j = 0; j < c.kw; j++) {
                    double s = 0;
                    for (int b = 0; b < c.N; b++)
                        for (oh = 0; oh < c.OH; oh++)
                            for (ow = 0; ow < c.OW; ow++)
                                s += tg->data[((size_t)b * (size_t)c.O + (size_t)o)
                                              * (size_t)c.OH * (size_t)c.OW
                                              + (size_t)oh * (size_t)c.OW + (size_t)ow]
                                   * tb_conv_at(tx, &c, b, ic, oh * c.st + i, ow * c.st + j);
                    tset(tdk, (size_t)o, (size_t)(ic * c.kh + i) * (size_t)c.kw + j, s);
                }
    return dk;
}

/* dL/db：偏置梯度 = 上游梯度按通道整块求和（批量 gy 也一样按通道求） */
Value rt_tb_conv2d_db(Value gy, Value ov)
{
    const char *who = "tb.conv2d_db";
    RtTensor *tg = tens_of(gy, who), *tdb;
    Value db;
    int O = tb_iv(ov, 1, 1 << 20, who, "输出通道数");
    size_t rows = tb_front(tg), cols = tb_last(tg), oh, j;
    if (rows % (size_t)O)
        tb_die("%s: gy rows %zu not divisible by O %d", who, rows, O);
    db = tb_row((size_t)O);
    tdb = rt_as_tensor(db);
    for (int o = 0; o < O; o++) {
        double s = 0;
        for (oh = 0; oh < rows / (size_t)O; oh++)
            for (j = 0; j < cols; j++)
                s += tg->data[(size_t)(o * (rows / (size_t)O) + oh) * cols + j];
        tset(tdb, 0, (size_t)o, s);
    }
    return db;
}
/* 池化形状：一张图 (H,W) 按 kh×kw 的窗切，步长 st */
typedef struct { int H, W, kh, kw, st, OH, OW; } TbPool;

static void tb_pool_shape(Value xv, int kh, int kw, int st, const char *who, TbPool *p)
{
    RtTensor *tx = tens_of(xv, who);
    if (tx->ndim != 2)
        tb_die("%s 需要二维张量（当前 %d 维）", who, tx->ndim);
    p->H = tx->dims[0];
    p->W = tx->dims[1];
    p->kh = kh; p->kw = kw; p->st = st;
    if (p->H < kh || p->W < kw)
        tb_die("%s：图 %dx%d 比池化窗 %dx%d 还小\n  怎么改：换小的池化窗，或者把图放大",
               who, p->H, p->W, kh, kw);
    p->OH = (p->H - kh) / st + 1;
    p->OW = (p->W - kw) / st + 1;
}

/* maxpool：单通道一张图 (H,W) → (OH,OW)。
 * 多通道的图（conv2d 出来的 O·OH 行）请用 tensor.slice 按通道切片后逐块池化。 */
/* 池化的 GPU 路由：后端 GPU + F32 + 工作量 OH·OW·kh·kw 达门槛 + 内核就绪；
 * 上卡失败 = 故障，tb_die（与 conv2d 同款：回退是设计，报错是真出事）。 */
static int gpu_pool_try(Value x, Value *outp, const TbPool *p, int is_avg)
{
    RtTensor *tx = tens_of(x, is_avg ? "tb.avgpool" : "tb.maxpool");
    RtTensor *to;
    int       d[2];

    if (rt_device_backend() != 2)
        return 0;
    if (tx->prec != TENSOR_F32)
        return 0;
    if (!gpu_pool_ready())
        return 0;
    if ((double)p->OH * (double)p->OW * (double)p->kh * (double)p->kw
        < (double)GPU_CONV_MIN_MAC)
        return 0;

    d[0] = p->OH;
    d[1] = p->OW;
    outp[0] = new_mat_p(d[0], d[1], TENSOR_F32);
    to = rt_as_tensor(outp[0]);
    if (getenv("PYBOOK_GPU_TRACE"))
        fprintf(stderr, "[gpu] %s %dx%d K%dx%d S%d 上卡\n",
                is_avg ? "avgpool" : "maxpool",
                p->OH, p->OW, p->kh, p->kw, p->st);
    if (!gpu_pool_f32(tx->data, to->data, (int)((size_t)tx->dims[0] * (size_t)tx->dims[1]),
                      p->OH * p->OW, (int)tx->dims[1], p->OH, p->OW,
                      p->kh, p->kw, p->st, is_avg))
        tb_die("tb.%s 已经决定上 GPU，但 kernel 没跑成：%s"
               "\n  怎么改：这个形状/显存是硬件限制，不是程序的错；"
               "可以改小图，或改用 device cpu。",
               is_avg ? "avgpool" : "maxpool", gpu_last_error());
    return 1;
}

Value rt_tb_maxpool(Value x, Value phv, Value pwv, Value stv)
{
    const char *who = "tb.maxpool";
    TbPool p;
    RtTensor *tx, *ty;
    Value y;
    int d[2];
    tb_pool_shape(x, tb_iv(phv, 1, 4096, who, "池高"), tb_iv(pwv, 1, 4096, who, "池宽"),
                  tb_iv(stv, 1, 4096, who, "步长"), who, &p);
    tx = tens_of(x, who);
    if (gpu_pool_try(x, &y, &p, 0))
        return y;
    d[0] = p.OH;
    d[1] = p.OW;
    y = rt_tensor_new(2, d);
    ty = rt_as_tensor(y);
    for (int oh = 0; oh < p.OH; oh++)
        for (int ow = 0; ow < p.OW; ow++) {
            double best = tget(tx, (size_t)(oh * p.st), (size_t)(ow * p.st));
            for (int i = 0; i < p.kh; i++)
                for (int j = 0; j < p.kw; j++) {
                    double v = tget(tx, (size_t)(oh * p.st + i), (size_t)(ow * p.st + j));
                    if (v > best) best = v;      /* 严格大于：并列取第一个，与反向一致 */
                }
            tset(ty, (size_t)oh, (size_t)ow, best);
        }
    return y;
}

/* maxpool 反向：只把梯度撒回前向选中的那个位置（并列取第一个，与前向同规则） */
Value rt_tb_maxpool_dx(Value x, Value gy, Value phv, Value pwv, Value stv)
{
    const char *who = "tb.maxpool_dx";
    TbPool p;
    RtTensor *tx, *tg, *tdx;
    Value dx;
    int d[2];
    tb_pool_shape(x, tb_iv(phv, 1, 4096, who, "池高"), tb_iv(pwv, 1, 4096, who, "池宽"),
                  tb_iv(stv, 1, 4096, who, "步长"), who, &p);
    tx = tens_of(x, who);
    tg = tens_of(gy, who);
    if ((size_t)tg->dims[0] != (size_t)p.OH || (size_t)tg->dims[1] != (size_t)p.OW)
        tb_die("%s：上游梯度形状 %dx%d 与池化输出对不上（要 %dx%d）", who,
               tg->dims[0], tg->dims[1], p.OH, p.OW);
    d[0] = p.H;
    d[1] = p.W;
    dx = rt_tensor_new(2, d);
    tdx = rt_as_tensor(dx);
    for (int oh = 0; oh < p.OH; oh++)
        for (int ow = 0; ow < p.OW; ow++) {
            int bi = 0, bj = 0;
            double best = tget(tx, (size_t)(oh * p.st), (size_t)(ow * p.st));
            for (int i = 0; i < p.kh; i++)
                for (int j = 0; j < p.kw; j++) {
                    double v = tget(tx, (size_t)(oh * p.st + i), (size_t)(ow * p.st + j));
                    if (v > best) { best = v; bi = i; bj = j; }
                }
            /* 必须累加：步长小于池化窗时，同一个像素可能是好几个窗口的 argmax，
               覆盖写会把前面窗口的梯度吃掉（3x3 图上 2x2/步长1 的 (0,1) 就同时
               被窗口 (0,0) 和 (0,1) 选中）。 */
            tadd(tdx, (size_t)(oh * p.st + bi), (size_t)(ow * p.st + bj),
                 tget(tg, (size_t)oh, (size_t)ow));
        }
    return dx;
}

/* avgpool：窗口内取平均 → (OH,OW) */
Value rt_tb_avgpool(Value x, Value phv, Value pwv, Value stv)
{
    const char *who = "tb.avgpool";
    TbPool p;
    RtTensor *tx, *ty;
    Value y;
    int d[2];
    tb_pool_shape(x, tb_iv(phv, 1, 4096, who, "池高"), tb_iv(pwv, 1, 4096, who, "池宽"),
                  tb_iv(stv, 1, 4096, who, "步长"), who, &p);
    tx = tens_of(x, who);
    if (gpu_pool_try(x, &y, &p, 1))
        return y;
    d[0] = p.OH;
    d[1] = p.OW;
    y = rt_tensor_new(2, d);
    ty = rt_as_tensor(y);
    for (int oh = 0; oh < p.OH; oh++)
        for (int ow = 0; ow < p.OW; ow++) {
            double s = 0;
            for (int i = 0; i < p.kh; i++)
                for (int j = 0; j < p.kw; j++)
                    s += tget(tx, (size_t)(oh * p.st + i), (size_t)(ow * p.st + j));
            tset(ty, (size_t)oh, (size_t)ow, s / ((double)p.kh * p.kw));
        }
    return y;
}

/* avgpool 反向：每个上游梯度平摊到窗口里所有位置。
 * x 要传进来，但只用它的**形状**：dx 的尺寸是输入图，而 gy 只有池化后的尺寸
 * （3x3 池成 2x2 之后 gy 是 2x2，拿它当 dx 的形状就做错了）。值用不到。 */
Value rt_tb_avgpool_dx(Value x, Value gy, Value phv, Value pwv, Value stv)
{
    const char *who = "tb.avgpool_dx";
    TbPool p;
    RtTensor *tg, *tdx;
    Value dx;
    int d[2];
    tb_pool_shape(x, tb_iv(phv, 1, 4096, who, "池高"), tb_iv(pwv, 1, 4096, who, "池宽"),
                  tb_iv(stv, 1, 4096, who, "步长"), who, &p);
    tg = tens_of(gy, who);
    if ((size_t)tg->dims[0] != (size_t)p.OH || (size_t)tg->dims[1] != (size_t)p.OW)
        tb_die("%s：上游梯度形状 %dx%d 与池化输出对不上（要 %dx%d）\n"
               "  怎么改：先算 tb.avgpool 拿到输出形状，再传同形的梯度",
               who, tg->dims[0], tg->dims[1], p.OH, p.OW);
    d[0] = p.H;
    d[1] = p.W;
    dx = rt_tensor_new(2, d);
    tdx = rt_as_tensor(dx);
    {
        double inv = 1.0 / ((double)p.kh * p.kw);
        for (int oh = 0; oh < p.OH; oh++)
            for (int ow = 0; ow < p.OW; ow++) {
                double g = tget(tg, (size_t)oh, (size_t)ow) * inv;
                for (int i = 0; i < p.kh; i++)
                    for (int j = 0; j < p.kw; j++)
                        tadd(tdx, (size_t)(oh * p.st + i), (size_t)(ow * p.st + j), g);
            }
    }
    return dx;
}

/* ================= B. dropout / batchnorm / layernorm ================= */

/* dropout 掩码：
 *   传同形的 0/1 张量 -> 就用它（复现实验、梯度检验必须走这条）
 *   传 0（任意非张量都行，空 也一样）-> 按丢弃率随机生成 Bernoulli(1-p)
 * 为什么用数字 0 当「没给掩码」而不是空：空 只有 C 后端认（pybk_code.py 里有
 * Call('空') -> rt_none()），**字节码后端编不出来**（pybk_bc.py 没有对应分支，
 * 会当成 list.空 的库调用报错）。数字 0 两个后端都成立。 */
static Value tb_dropout_mask(Value maskv, size_t rows, size_t cols, double p,
                             const char *who)
{
    Value m;
    RtTensor *tm;
    if (rt_is_tensor(maskv)) {
        m = maskv;
        tm = rt_as_tensor(m);
        if ((size_t)tm->dims[0] != rows || (size_t)tm->dims[1] != cols)
            tb_die("%s：掩码形状 %dx%d 与输入 %zux%zu 不一致\n"
                   "  怎么改：掩码用与输入同形状的 0/1 张量", who,
                   tm->dims[0], tm->dims[1], rows, cols);
        return m;
    }
    if (numv(maskv, who) != 0.0)
        tb_die("%s：掩码只认两种写法\n"
               "  为什么：要么给同形的 0/1 张量，要么给 0 表示按丢弃率随机生成\n"
               "  怎么改：随机就传 0，复现/梯度检验就传自己那张 0/1 掩码", who);
    {
        int d[2] = { (int)rows, (int)cols };
        m = rt_tensor_new(2, d);
    }
    tm = rt_as_tensor(m);
    for (size_t i = 0; i < rows * cols; i++)
        tm->data[i] = ((double)rand() / (double)RAND_MAX) < p ? 0.0 : 1.0;
    return m;
}

static double tb_drop_rate(Value pv, const char *who)
{
    double p = numv(pv, who);
    if (p < 0.0 || p >= 1.0)
        tb_die("%s：丢弃率是 %g，要落在 0~1（不含 1）\n"
               "  为什么：p=1 会除以 0，p<0 没有意义\n  怎么改：常用 0.2~0.5", who, p);
    return p;
}

Value rt_tb_dropout(Value x, Value pv, Value trainv, Value maskv)
{
    const char *who = "tb.dropout";
    RtTensor *tx, *ty, *tm;
    Value y, m;
    size_t rows, cols, i, n;
    double p = tb_drop_rate(pv, who);
    int train = numv(trainv, who) != 0.0;
    int d[2];
    tx = tens_of(x, who);
    rows = (size_t)tx->dims[0];
    cols = (size_t)tx->dims[1];
    n = rows * cols;
    d[0] = (int)rows;
    d[1] = (int)cols;
    y = rt_tensor_new(2, d);
    ty = rt_as_tensor(y);
    if (!train) {                                  /* 推理：恒等，不碰掩码、不缩放 */
        for (i = 0; i < n; i++) ty->data[i] = tx->data[i];
        return y;
    }
    m = tb_dropout_mask(maskv, rows, cols, p, who);
    tm = rt_as_tensor(m);
    {
        double keep = 1.0 / (1.0 - p);
        for (i = 0; i < n; i++)
            ty->data[i] = tm->data[i] > 0.5
                        ? rt_tensor_round(ty->prec, tx->data[i] * keep) : 0.0;
    }
    return y;
}

/* dropout 反向：dy · mask/(1-p)。掩码必须给 —— 没有掩码的梯度是错的，
 * 与其悄悄给个错的，不如当场报错。 */
Value rt_tb_dropout_dx(Value gy, Value pv, Value trainv, Value maskv)
{
    const char *who = "tb.dropout_dx";
    RtTensor *tg, *tdx, *tm;
    Value dx, m;
    size_t rows, cols, i, n;
    double p;
    int train = numv(trainv, who) != 0.0;
    int d[2];
    tg = tens_of(gy, who);
    rows = (size_t)tg->dims[0];
    cols = (size_t)tg->dims[1];
    n = rows * cols;
    d[0] = (int)rows;
    d[1] = (int)cols;
    dx = rt_tensor_new(2, d);
    tdx = rt_as_tensor(dx);
    if (!train) {
        for (i = 0; i < n; i++) tdx->data[i] = tg->data[i];
        return dx;
    }
    p = tb_drop_rate(pv, who);
    if (!rt_is_tensor(maskv))
        tb_die("%s 必须传掩码张量\n"
               "  为什么：dropout 的梯度要靠前向那同一张掩码，没有它算出来是错的\n"
               "  怎么改：前向 tb.dropout 用的是随机掩码时，先把它取出来；"
               "训练时请显式生成一张 0/1 掩码再传进来", who);
    m = maskv;
    tm = rt_as_tensor(m);
    if ((size_t)tm->dims[0] != rows || (size_t)tm->dims[1] != cols)
        tb_die("%s：掩码形状 %dx%d 与上游梯度 %zux%zu 不一致", who,
               tm->dims[0], tm->dims[1], rows, cols);
    {
        double keep = 1.0 / (1.0 - p);
        for (i = 0; i < n; i++)
            tdx->data[i] = rt_tensor_round(tdx->prec,
                        tm->data[i] > 0.5 ? tg->data[i] * keep : 0.0);
    }
    return dx;
}

/* batchnorm(x, gamma, beta, 均值, 方差, 训练, 动量, eps)
 *   x 是 (批, 特征)：行=批、列=特征。gamma/beta/均值/方差 都是 (1,特征)。
 *   训练：用本批统计量，并把 running 统计按 动量 往前推一格；
 *   推理：直接用 running 统计量，不更新。
 * 返回 [y, 本次用的均值, 本次用的方差(含eps), 新running均值, 新running方差]
 *   「本次用的」是反向真正需要的那个（训练=本批，推理=running），原样传给
 *   tb.batchnorm_dx 即可，不要自己判断。 */
Value rt_tb_batchnorm(Value x, Value gam, Value bet, Value mu, Value va,
                      Value trainv, Value momv, Value epsv)
{
    const char *who = "tb.batchnorm";
    RtTensor *tx, *tg, *tb, *tm, *tv;
    Value y, used_mu, used_va, new_mu, new_va;
    size_t n, c, j, i;
    int train = numv(trainv, who) != 0.0;
    double mom = numv(momv, who);
    double eps = numv(epsv, who);
    double *um = NULL, *uv = NULL;
    int d[2];
    if (eps <= 0.0)
        tb_die("%s：eps 是 %g，要为正\n  怎么改：常用 1e-5", who, eps);
    if (mom < 0.0 || mom > 1.0)
        tb_die("%s：动量是 %g，要落在 0~1（0=只信历史，1=只信本批）", who, mom);
    tx = tens_of(x, who);
    tg = tens_of(gam, who);
    tb = tens_of(bet, who);
    tm = tens_of(mu, who);
    tv = tens_of(va, who);
    if (tx->ndim != 2 || tg->ndim != 2 || tb->ndim != 2 || tm->ndim != 2 || tv->ndim != 2)
        tb_die("%s 需要二维张量", who);
    n = (size_t)tx->dims[0];
    c = (size_t)tx->dims[1];
    if (n < 1) tb_die("%s：批大小是 0", who);
    if ((size_t)tg->dims[1] != c || (size_t)tb->dims[1] != c)
        tb_die("%s：gamma/beta 的列数要和输入的 %zu 个特征对齐（取第 0 行）", who, c);
    if ((size_t)tm->dims[1] != c || (size_t)tv->dims[1] != c)
        tb_die("%s：均值/方差 的列数要和 gamma 一致（要 %zu）", who, c);
    um = (double *)malloc(c * sizeof(double));
    uv = (double *)malloc(c * sizeof(double));
    if (!um || !uv) { free(um); free(uv); tb_die("%s 内存不足", who); }
    used_mu = tb_row(c);
    used_va = tb_row(c);
    new_mu = tb_row(c);
    new_va = tb_row(c);
    d[0] = (int)n;
    d[1] = (int)c;
    y = rt_tensor_new(2, d);
    if (train)
        tb_col_mean_var(tx, n, c, um, uv);
    else
        for (j = 0; j < c; j++) { um[j] = tget(tm, 0, j); uv[j] = tget(tv, 0, j); }
    for (j = 0; j < c; j++) {
        double inv = 1.0 / sqrt(uv[j] + eps);
        for (i = 0; i < n; i++)
            tset(rt_as_tensor(y), i, j,
                 tget(tg, 0, j) * (tget(tx, i, j) - um[j]) * inv + tget(tb, 0, j));
        tset(rt_as_tensor(used_mu), 0, j, um[j]);
        tset(rt_as_tensor(used_va), 0, j, uv[j] + eps);   /* 含 eps：反向直接开方 */
        tset(rt_as_tensor(new_mu), 0, j,
             train ? (1.0 - mom) * tget(tm, 0, j) + mom * um[j] : tget(tm, 0, j));
        tset(rt_as_tensor(new_va), 0, j,
             train ? (1.0 - mom) * tget(tv, 0, j) + mom * uv[j] : tget(tv, 0, j));
    }
    free(um); free(uv);
    return tb_packn(5, y, used_mu, used_va, new_mu, new_va);
}

/* batchnorm 反向：传「前向实际用的那个统计量」即可，训练/推理公式一致。
 *   x̂ = (x-μ)/sqrt(σ²+eps)，std = sqrt(用的方差)
 *   dx = (γ/std)·(gy - mean(gy) - x̂·mean(gy·x̂))
 * 返回 [dx, dgamma, dbeta] */
Value rt_tb_batchnorm_dx(Value x, Value gy, Value mu, Value va, Value gam)
{
    const char *who = "tb.batchnorm_dx";
    RtTensor *tx, *tg, *tm, *tv, *tgam, *tdx, *tdg, *tdb;
    Value dx, dg, db;
    size_t n, c, j, i;
    int d[2];
    tx = tens_of(x, who);
    tg = tens_of(gy, who);
    tm = tens_of(mu, who);
    tv = tens_of(va, who);
    tgam = tens_of(gam, who);
    if (tx->ndim != 2 || tg->ndim != 2)
        tb_die("%s 需要二维张量", who);
    n = (size_t)tx->dims[0];
    c = (size_t)tx->dims[1];
    if ((size_t)tg->dims[0] != n || (size_t)tg->dims[1] != c)
        tb_die("%s：上游梯度形状 %dx%d 与输入 %zux%zu 不一致", who,
               tg->dims[0], tg->dims[1], n, c);
    if ((size_t)tm->dims[1] != c || (size_t)tv->dims[1] != c)
        tb_die("%s：均值/方差 的列数 %zu 与输入的 %zu 个特征不一致", who, tm->dims[1], c);
    d[0] = (int)n;
    d[1] = (int)c;
    dx = rt_tensor_new(2, d);
    dg = tb_row(c);
    db = tb_row(c);
    tdx = rt_as_tensor(dx);
    tdg = rt_as_tensor(dg);
    tdb = rt_as_tensor(db);
    for (j = 0; j < c; j++) {
        double mu = tget(tm, 0, j);
        double std = sqrt(tget(tv, 0, j));
        double g = tget(tgam, 0, j);
        double mg = 0, mgx = 0, sg = 0, sgx = 0;
        double inv_n = 1.0 / (double)n;
        if (!(std > 0.0))
            tb_die("%s：第 %zu 个特征的标准差是 %g\n"
                   "  为什么：前向用的方差必须为正（除以它才能归一化）\n"
                   "  怎么改：检查 tb.batchnorm 的 eps 与输入是否全为同一个数",
                   who, j, std);
        for (i = 0; i < n; i++) {
            double xh = (tget(tx, i, j) - mu) / std;
            double gv = tget(tg, i, j);
            mg += gv;
            mgx += gv * xh;
            sg += gv * g;
            sgx += gv * xh * g;
        }
        mg *= inv_n;
        mgx *= inv_n;
        for (i = 0; i < n; i++) {
            double xh = (tget(tx, i, j) - mu) / std;
            tset(tdx, i, j, g * (tget(tg, i, j) - mg - xh * mgx) / std);
        }
        tset(tdg, 0, j, sgx);
        tset(tdb, 0, j, sg);
    }
    return tb_packn(3, dx, dg, db);
}

/* layernorm(x, gamma, beta, eps)：**逐行**归一化（每个样本自己一套均值方差），
 * 所以没有 running 统计，训练和推理是同一个公式。
 * 返回 [y, 每行均值, 每行方差(含eps)]（后两个留给反向用） */
Value rt_tb_layernorm(Value x, Value gam, Value bet, Value epsv)
{
    const char *who = "tb.layernorm";
    RtTensor *tx, *tg, *tb, *ty;
    Value y, mu, va;
    size_t n, c, i, j;
    double eps = numv(epsv, who);
    int d[2];
    if (eps <= 0.0)
        tb_die("%s：eps 是 %g，要为正\n  怎么改：常用 1e-5", who, eps);
    tx = tens_of(x, who);
    tg = tens_of(gam, who);
    tb = tens_of(bet, who);
    if (tx->ndim != 2 || tg->ndim != 2 || tb->ndim != 2)
        tb_die("%s 需要二维张量", who);
    n = (size_t)tx->dims[0];
    c = (size_t)tx->dims[1];
    if (c < 1) tb_die("%s：特征数是 0", who);
    if ((size_t)tg->dims[1] != c || (size_t)tb->dims[1] != c)
        tb_die("%s：gamma/beta 的列数要和输入的 %zu 个特征一致（取第 0 行）", who, c);
    d[0] = (int)n;
    d[1] = (int)c;
    y = rt_tensor_new(2, d);
    ty = rt_as_tensor(y);
    mu = tb_row(n);
    va = tb_row(n);
    for (i = 0; i < n; i++) {
        double s = 0, v = 0, inv;
        for (j = 0; j < c; j++) s += tget(tx, i, j);
        s /= (double)c;
        for (j = 0; j < c; j++) {
            double dd = tget(tx, i, j) - s;
            v += dd * dd;
        }
        v /= (double)c;
        inv = 1.0 / sqrt(v + eps);
        for (j = 0; j < c; j++)
            tset(ty, i, j, tget(tg, 0, j) * (tget(tx, i, j) - s) * inv + tget(tb, 0, j));
        tset(rt_as_tensor(mu), 0, i, s);
        tset(rt_as_tensor(va), 0, i, v + eps);      /* 含 eps：反向直接开方 */
    }
    return tb_packn(3, y, mu, va);
}

/* layernorm 反向（逐行，和 batchnorm 同构，但没有跨样本平均）：
 * 返回 [dx, dgamma, dbeta] */
Value rt_tb_layernorm_dx(Value x, Value gy, Value mu, Value va, Value gam)
{
    const char *who = "tb.layernorm_dx";
    RtTensor *tx, *tg, *tm, *tv, *tgam, *tdx, *tdg, *tdb;
    Value dx, dg, db;
    double *acc_g = NULL, *acc_b = NULL;
    size_t n, c, i, j;
    int d[2];
    tx = tens_of(x, who);
    tg = tens_of(gy, who);
    tm = tens_of(mu, who);
    tv = tens_of(va, who);
    tgam = tens_of(gam, who);
    if (tx->ndim != 2 || tg->ndim != 2)
        tb_die("%s 需要二维张量", who);
    n = (size_t)tx->dims[0];
    c = (size_t)tx->dims[1];
    if ((size_t)tg->dims[0] != n || (size_t)tg->dims[1] != c)
        tb_die("%s：上游梯度形状 %dx%d 与输入 %zux%zu 不一致", who,
               tg->dims[0], tg->dims[1], n, c);
    if ((size_t)tm->dims[1] != n || (size_t)tv->dims[1] != n)
        tb_die("%s：均值/方差 的列数 %zu 应等于行数 %zu（逐行统计）",
               who, tm->dims[1], n);
    acc_g = (double *)calloc(c, sizeof(double));
    acc_b = (double *)calloc(c, sizeof(double));
    if (!acc_g || !acc_b) { free(acc_g); free(acc_b); tb_die("%s 内存不足", who); }
    d[0] = (int)n;
    d[1] = (int)c;
    dx = rt_tensor_new(2, d);
    dg = tb_row(c);
    db = tb_row(c);
    tdx = rt_as_tensor(dx);
    tdg = rt_as_tensor(dg);
    tdb = rt_as_tensor(db);
    for (i = 0; i < n; i++) {
        double m = tget(tm, 0, i);
        double std = sqrt(tget(tv, 0, i));
        double mg = 0, mgx = 0;
        double inv_c = 1.0 / (double)c;
        if (!(std > 0.0))
            tb_die("%s：第 %zu 行的标准差是 %g（每行特征全是同一个数时归一化无意义）",
                   who, i, std);
        for (j = 0; j < c; j++) {
            double xh = (tget(tx, i, j) - m) / std;
            double gv = tget(tg, i, j);
            mg += gv;
            mgx += gv * xh;
            acc_g[j] += gv * xh;
            acc_b[j] += gv;
        }
        mg *= inv_c;
        mgx *= inv_c;
        for (j = 0; j < c; j++) {
            double xh = (tget(tx, i, j) - m) / std;
            tset(tdx, i, j, tget(tgam, 0, j) * (tget(tg, i, j) - mg - xh * mgx) / std);
        }
    }
    for (j = 0; j < c; j++) { tset(tdg, 0, j, acc_g[j]); tset(tdb, 0, j, acc_b[j]); }
    free(acc_g);
    free(acc_b);
    return tb_packn(3, dx, dg, db);
}

/* ================= tb.save / tb.load：模型持久化 =================
 * 训练一次、到处推理：把权重张量写进二进制文件，之后任何程序 load 回来推理。
 *
 *   tb.save("模型.tbw", [w1, b1, w2, b2])   → 张量列表落盘
 *   vg.权重表 = tb.load("模型.tbw")          → 按保存顺序取回张量列表
 *
 * 文件格式（小端二进制）：
 *   "PYBT" | u32 版本=1 | u32 张量数 | 每张量 { u32 ndim | ndim×u32 dims |
 *   u32 prec | ndim积 × f64 数据 }
 * data 缓冲本身就是 double，f32 张量的值也严格可被 f32 表示 → 二进制往返无损。
 * 全程有校验：魔数/版本/维度不符就报三段式错误，不吞半个字节的错。 */

#define TB_IO_VERSION 1u

static void tb_wu32(FILE *f, unsigned v)
{
    unsigned char b[4] = { (unsigned char)v, (unsigned char)(v >> 8),
                           (unsigned char)(v >> 16), (unsigned char)(v >> 24) };
    if (fwrite(b, 1, 4, f) != 4)
        tb_die("tb.save：写文件失败（磁盘满了？）");
}

static unsigned tb_ru32(FILE *f, const char *path)
{
    unsigned char b[4];
    if (fread(b, 1, 4, f) != 4)
        tb_die("tb.load：文件提前结束或不是 PYbook 权重文件：%s", path);
    return (unsigned)b[0] | (unsigned)b[1] << 8
         | (unsigned)b[2] << 16 | (unsigned)b[3] << 24;
}

static void tb_wf64(FILE *f, double x)
{
    unsigned char b[8];
    memcpy(b, &x, 8);
    if (fwrite(b, 1, 8, f) != 8)
        tb_die("tb.save：写文件失败（磁盘满了？）");
}

static double tb_rf64(FILE *f, const char *path)
{
    unsigned char b[8];
    if (fread(b, 1, 8, f) != 8)
        tb_die("tb.load：文件提前结束或不是 PYbook 权重文件：%s", path);
    double x;
    memcpy(&x, b, 8);
    return x;
}

/* tb.save(文件名, 张量列表)：把 [w1, b1, w2, b2] 这样的张量列表落盘。 */
Value rt_tb_save(Value pathv, Value listv)
{
    if (!IS_STR(pathv))
        tb_die("tb.save 的文件名需要字符串");
    const char *path = AS_STR(pathv);
    if (!IS_LIST(listv))
        tb_die("tb.save 的第二个参数需要是张量列表（如 [w1, b1, w2, b2]）");
    RtList *L = AS_LIST(listv);

    FILE *f = fopen(path, "wb");
    if (!f)
        tb_die("tb.save：打不开 %s（路径不存在或被占用？）", path);
    fwrite("PYBT", 1, 4, f);
    tb_wu32(f, TB_IO_VERSION);
    tb_wu32(f, (unsigned)L->len);
    for (size_t i = 0; i < L->len; i++) {
        Value v = L->items[i];
        if (!rt_is_tensor(v) || rt_as_tensor(v) == NULL) {
            fclose(f);
            tb_die("tb.save：列表第 %zu 个元素不是张量", i + 1);
        }
        RtTensor *t = rt_as_tensor(v);
        tb_wu32(f, (unsigned)t->ndim);
        for (int k = 0; k < t->ndim; k++)
            tb_wu32(f, (unsigned)t->dims[k]);
        tb_wu32(f, (unsigned)t->prec);
        size_t n = 1;
        for (int k = 0; k < t->ndim; k++)
            n *= (size_t)t->dims[k];
        for (size_t k = 0; k < n; k++)
            tb_wf64(f, t->data[k]);
    }
    if (fclose(f) != 0)
        tb_die("tb.save：关闭 %s 失败（磁盘满了？）", path);
    return rt_none();
}

/* tb.load(文件名)：按保存顺序取回张量列表。 */
Value rt_tb_load(Value pathv)
{
    if (!IS_STR(pathv))
        tb_die("tb.load 的文件名需要字符串");
    const char *path = AS_STR(pathv);
    FILE *f = fopen(path, "rb");
    if (!f)
        tb_die("tb.load：打不开 %s（先 tb.save 过吗？）", path);
    char magic[4];
    if (fread(magic, 1, 4, f) != 4 || memcmp(magic, "PYBT", 4) != 0) {
        fclose(f);
        tb_die("tb.load：%s 不是 PYbook 权重文件（缺少 PYBT 魔数）", path);
    }
    unsigned ver = tb_ru32(f, path);
    if (ver != TB_IO_VERSION) {
        fclose(f);
        tb_die("tb.load：版本不支持（文件 %u，本机 %u）", ver, TB_IO_VERSION);
    }
    unsigned count = tb_ru32(f, path);
    Value out = rt_list_new();
    for (unsigned t = 0; t < count; t++) {
        unsigned ndim = tb_ru32(f, path);
        if (ndim < 1 || ndim > 8) {
            fclose(f);
            tb_die("tb.load：维度数 %u 不合理（文件损坏？）", ndim);
        }
        int dims[8];
        size_t n = 1;
        for (unsigned k = 0; k < ndim; k++) {
            dims[k] = (int)tb_ru32(f, path);
            if (dims[k] <= 0) {
                fclose(f);
                tb_die("tb.load：维度 %u 不合理", dims[k]);
            }
            n *= (size_t)dims[k];
        }
        unsigned prec = tb_ru32(f, path);
        Value m = rt_tensor_new_p((int)ndim, dims, (prec == TENSOR_F32) ? TENSOR_F32 : TENSOR_F64);
        RtTensor *tp = rt_as_tensor(m);
        for (size_t k = 0; k < n; k++)
            tp->data[k] = tb_rf64(f, path);
        rt_push(&out, m);
    }
    fclose(f);
    return out;
}
