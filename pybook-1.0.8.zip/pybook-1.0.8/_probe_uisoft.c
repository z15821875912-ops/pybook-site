/* _probe_uisoft.c —— 量 Path B 那两笔成本。
 *
 * 结论已经很硬（探针 1/2/3）：
 *   · 默认 ACCELERATED 选 direct3d，GL 后缓冲和 SDL 后缓冲互不可见
 *   · 强制 opengl 后端，SDL 会**自己再建一个 GL context**，纹理传不过去
 *   · 所以同屏合成只有一条路：UI 渲进离屏 surface，3D 每帧上传成纹理贴上去
 *
 * 那这条路值不值，就看两笔：
 *   (1) UI 从 GPU 加速退成软件渲染，代价多大？
 *       已知参照（同一台机器、同一验收件、差分法）：圆角 1.62 ms/帧、字符 3.95 ms/帧。
 *   (2) 每帧一次 glTexImage2D 上传 W*H*4 字节，代价多大？
 *
 * 用的是按 UI 实际负载估的合成负载，不是拿真 UI 跑 —— 真 UI 要先改引擎才能量，
 * 而这里要先知道值不值得改。
 */
#include <SDL2/SDL.h>
#include <SDL2/SDL_opengl.h>
#include <stdio.h>
#include <time.h>

#define W 880
#define H 560

/* UI 一帧大致画这么多东西：填充矩形几百个、带纹理的文字/字形四边形几十个。
   表格的竖线是"每格一次 text()"，字符风实测约 90 次。 */
#define NFILL 400
#define NBLIT 90

static double now_ms(void)
{
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec * 1000.0 + ts.tv_nsec / 1e6;
}

int main(void)
{
    SDL_SetMainReady();
    if (SDL_Init(SDL_INIT_VIDEO) != 0) { printf("SDL_Init: %s\n", SDL_GetError()); return 1; }

    SDL_Window *win = SDL_CreateWindow("soft", SDL_WINDOWPOS_CENTERED,
                                       SDL_WINDOWPOS_CENTERED, W, H,
                                       SDL_WINDOW_HIDDEN | SDL_WINDOW_OPENGL);
    SDL_Renderer *gpu = SDL_CreateRenderer(win, -1, SDL_RENDERER_ACCELERATED);
    SDL_RendererInfo ri;
    SDL_GetRendererInfo(gpu, &ri);
    printf("GPU 参照渲染器 = %s\n", ri.name);

    SDL_Surface *surf = SDL_CreateRGBSurfaceWithFormat(0, W, H, 32, SDL_PIXELFORMAT_ARGB8888);
    SDL_Renderer *soft = SDL_CreateSoftwareRenderer(surf);
    SDL_Renderer *empty = SDL_CreateSoftwareRenderer(surf);

    /* 一个 64x16 的"字形"贴图，代表 SDL_RenderCopy 那几类调用 */
    SDL_Surface *gs = SDL_CreateRGBSurfaceWithFormat(0, 64, 16, 32, SDL_PIXELFORMAT_ARGB8888);
    SDL_FillRect(gs, NULL, 0xFFCCDDEEFFu);
    SDL_Texture *gtex_gpu  = SDL_CreateTextureFromSurface(gpu, gs);
    SDL_Texture *gtex_soft = SDL_CreateTextureFromSurface(soft, gs);

    /* ---- (1) GPU 加速：同样的负载 ---- */
    double t0 = now_ms();
    for (int f = 0; f < 60; f++) {
        SDL_SetRenderDrawColor(gpu, 20, 26, 34, 255);
        SDL_RenderClear(gpu);
        for (int i = 0; i < NFILL; i++)
            SDL_RenderFillRect(gpu, &(SDL_Rect){(i * 7) % W, (i * 13) % H, 60, 24});
        for (int i = 0; i < NBLIT; i++)
            SDL_RenderCopy(gpu, gtex_gpu, NULL, &(SDL_Rect){(i * 11) % W, (i * 17) % H, 64, 16});
        SDL_RenderPresent(gpu);
    }
    double tg = (now_ms() - t0) / 60.0;

    /* ---- (2) 软件渲染：同样的负载（不减任何东西）---- */
    t0 = now_ms();
    for (int f = 0; f < 60; f++) {
        SDL_SetRenderDrawColor(soft, 20, 26, 34, 255);
        SDL_RenderClear(soft);
        for (int i = 0; i < NFILL; i++)
            SDL_RenderFillRect(soft, &(SDL_Rect){(i * 7) % W, (i * 13) % H, 60, 24});
        for (int i = 0; i < NBLIT; i++)
            SDL_RenderCopy(soft, gtex_soft, NULL, &(SDL_Rect){(i * 11) % W, (i * 17) % H, 64, 16});
        SDL_RenderPresent(soft);
    }
    double ts = (now_ms() - t0) / 60.0;

    /* ---- 软件渲染的成本拆开：填充 vs 贴图，看是哪一头贵 ---- */
    t0 = now_ms();
    for (int f = 0; f < 60; f++) {
        SDL_SetRenderDrawColor(soft, 20, 26, 34, 255);
        SDL_RenderClear(soft);
        for (int i = 0; i < NFILL; i++)
            SDL_RenderFillRect(soft, &(SDL_Rect){(i * 7) % W, (i * 13) % H, 60, 24});
        SDL_RenderPresent(soft);
    }
    double ts_fill = (now_ms() - t0) / 60.0;
    t0 = now_ms();
    for (int f = 0; f < 60; f++)
        for (int i = 0; i < NBLIT; i++)
            SDL_RenderCopy(soft, gtex_soft, NULL, &(SDL_Rect){(i * 11) % W, (i * 17) % H, 64, 16});
    double ts_blit = (now_ms() - t0) / 60.0;

    /* ---- (3) 每帧 glTexImage2D 上传整屏 ---- */
    SDL_GL_SetAttribute(SDL_GL_DOUBLEBUFFER, 1);
    SDL_GLContext ctx = SDL_GL_CreateContext(win);
    if (!ctx) { printf("GL context 失败: %s\n", SDL_GetError()); return 1; }
    SDL_GL_MakeCurrent(win, ctx);
    void *px = surf->pixels;
    GLuint tex = 0;
    glGenTextures(1, &tex);
    glBindTexture(GL_TEXTURE_2D, tex);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    /* 先跑一次把驱动状态热起来，别把首次分配算进稳态 */
    glTexImage2D(GL_TEXTURE_2D, 0, GL_BGRA, W, H, 0, GL_BGRA, GL_UNSIGNED_BYTE, px);
    glFinish();
    t0 = now_ms();
    for (int f = 0; f < 60; f++) {
        glTexImage2D(GL_TEXTURE_2D, 0, GL_BGRA, W, H, 0, GL_BGRA, GL_UNSIGNED_BYTE, px);
        glFinish();
    }
    double tu = (now_ms() - t0) / 60.0;

    /* ---- (4) 贴上去（全屏 quad） ---- */
    glViewport(0, 0, W, H);
    glMatrixMode(GL_PROJECTION); glLoadIdentity();
    glOrtho(0, W, 0, H, -1, 1);
    glMatrixMode(GL_MODELVIEW);  glLoadIdentity();
    glEnable(GL_TEXTURE_2D);
    t0 = now_ms();
    for (int f = 0; f < 60; f++) {
        glClear(GL_COLOR_BUFFER_BIT);
        glBindTexture(GL_TEXTURE_2D, tex);
        glBegin(GL_QUADS);
        glTexCoord2f(0, 0); glVertex2i(0, 0);
        glTexCoord2f(1, 0); glVertex2i(W, 0);
        glTexCoord2f(1, 1); glVertex2i(W, H);
        glTexCoord2f(0, 1); glVertex2i(0, H);
        glEnd();
        glFinish();
    }
    double tq = (now_ms() - t0) / 60.0;

    printf("\n=== UI 绘制（%d 个 FillRect + %d 个 RenderCopy，%dx%d）===\n",
           NFILL, NBLIT, W, H);
    printf("  GPU 加速  %7.3f ms/帧   <- 现在 UI 走的就是这条\n", tg);
    printf("  软件渲染  %7.3f ms/帧   <- Path B 里 UI 要退到这条\n", ts);
    printf("      其中填充 %7.3f ms，贴图 %7.3f ms\n", ts_fill, ts_blit);
    printf("  倍数      %7.2fx\n", ts / (tg > 0 ? tg : 1));

    printf("\n=== 每帧把离屏 surface 交给 3D ===\n");
    printf("  glTexImage2D %7.3f ms/帧  (%d x %d x 4 = %.2f MB)\n",
           tu, W, H, W * H * 4 / 1048576.0);
    printf("  全屏贴上去  %7.3f ms/帧\n", tq);

    printf("\n=== 合计（UI 软件渲染 + 上传 + 贴）=====\n");
    printf("  %7.3f ms/帧\n", ts + tu + tq);
    printf("  对照：现在纯 UI（GPU 加速）字符风实测 3.95 ms/帧\n");

    SDL_GL_DeleteContext(ctx);
    SDL_DestroyTexture(gtex_gpu);
    SDL_DestroyTexture(gtex_soft);
    SDL_FreeSurface(gs);
    SDL_DestroyRenderer(gpu);
    SDL_DestroyRenderer(soft);
    SDL_DestroyRenderer(empty);
    SDL_FreeSurface(surf);
    SDL_DestroyWindow(win);
    SDL_Quit();
    return 0;
}
