/* _symtest.c —— pybook_sym 核心层自检（无运行时，纯 C 对拍）
 * 编译：gcc -O2 _symtest.c pybook_sym.c -o _symtest -I.
 */
#include "pybook_sym.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>

static int fails = 0, total = 0;

static void T(const char *got, const char *want, const char *what)
{
    int match = (got == NULL && want == NULL) ||
                (got != NULL && want != NULL && strcmp(got, want) == 0);
    total++;
    if (!match) {
        fails++;
        printf("FAIL %-30s 期望 [%s]  实得 [%s]\n", what, want ? want : "(NULL)", got ? got : "(NULL)");
    } else {
        printf("ok   %-30s %s\n", what, want ? want : "(NULL)");
    }
}

static void Td(const char *expr, const char *var, const char *want, const char *what)
{
    char err[192] = "";
    char *r = sym_core_diff(expr, var, err, sizeof err);
    T(r, want, what);
    free(r);
}

static void Ti(const char *expr, const char *var, const char *want, const char *what)
{
    char err[192] = "";
    char *r = sym_core_integrate(expr, var, err, sizeof err);
    T(r, want, what);
    free(r);
}

static void Ts(const char *expr, const char *want, const char *what)
{
    char err[192] = "";
    char *r = sym_core_simplify(expr, err, sizeof err);
    T(r, want, what);
    free(r);
}

static void Te(const char *expr, const char *want, const char *what)
{
    char err[192] = "";
    char *r = sym_core_expand(expr, err, sizeof err);
    T(r, want, what);
    free(r);
}

static void Tsolve(const char *eq, const char *var, const char *want, const char *what)
{
    char err[192] = "";
    char *r = sym_core_solve(eq, var, err, sizeof err);
    T(r, want, what);
    free(r);
}

static void Tfmt(const char *expr, const char *mode, const char *want, const char *what)
{
    char err[192] = "";
    char *r = sym_core_format(expr, mode, err, sizeof err);
    T(r, want, what);
    free(r);
}

/* 期望失败且 err 含关键字 */
static void Tsolve_err(const char *eq, const char *var, const char *key, const char *what)
{
    char err[192] = "";
    char *r = sym_core_solve(eq, var, err, sizeof err);
    total++;
    if (!r && strstr(err, key)) {
        printf("ok   %-30s 报错含 [%s]\n", what, key);
    } else {
        fails++;
        printf("FAIL %-30s 期望报错含 [%s]，实得 r=[%s] err=[%s]\n",
               what, key, r ? r : "(NULL)", err);
    }
    free(r);
}

static void Tv(double got, double want, const char *what)
{
    char b[64];
    total++;
    if (!(got == want || (fabs(got - want) <= 1e-9 * (1 + fabs(want))))) {
        fails++;
        printf("FAIL %-30s 期望 %.12g  实得 %.12g\n", what, want, got);
    } else {
        snprintf(b, sizeof b, "%.12g", want);
        printf("ok   %-30s %s\n", what, b);
    }
}

/* ---- 有理积分：积分 -> 求导 -> 多点数值对拍（不依赖打印格式） ---- */
static void Tid(const char *expr, const char *var, const char *pts, const char *what)
{
    char err[192] = "";
    char *r = sym_core_integrate(expr, var, err, sizeof err);
    char *d = NULL;
    int ok = 0, n = 0, all = 1;
    total++;
    if (!r) {
        fails++;
        printf("FAIL %-30s 积分失败：%s\n", what, err);
        return;
    }
    d = sym_core_diff(r, var, err, sizeof err);
    if (!d) {
        fails++;
        printf("FAIL %-30s 求导失败：%s\n", what, err);
        free(r);
        return;
    }
    {
        const char *p = pts;
        while (*p) {
            char num[32], bind[80];
            int k = 0;
            double a, b;
            while (*p && *p != ',') { if (k < 31) num[k++] = *p; p++; }
            num[k] = 0;
            if (*p == ',') p++;
            if (k == 0) continue;
            snprintf(bind, sizeof bind, "%s=%s", var, num);
            n++;
            if (!sym_core_eval(d, bind, &a, err, sizeof err)) { all = 0; continue; }
            if (!sym_core_eval(expr, bind, &b, err, sizeof err)) { all = 0; continue; }
            if (fabs(a - b) <= 1e-7 * (1 + fabs(b))) ok++;
            else all = 0;
        }
    }
    if (ok == n && n > 0 && all) {
        printf("ok   %-30s %s [%d 点对拍]\n", what, r, n);
    } else {
        fails++;
        printf("FAIL %-30s 对拍 %d/%d：r=[%s] d=[%s]\n", what, ok, n, r, d);
    }
    free(d);
    free(r);
}

/* ---- sym.解方程组：精确字符串 ---- */
static void Tsys(const char *eqs, const char *vars, const char *want, const char *what)
{
    char err[192] = "";
    char *r = sym_core_solve_sys(eqs, vars, err, sizeof err);
    T(r, want, what);
    free(r);
}

/* 期望失败且 err 含关键字 */
static void Tsys_err(const char *eqs, const char *vars, const char *key, const char *what)
{
    char err[192] = "";
    char *r = sym_core_solve_sys(eqs, vars, err, sizeof err);
    total++;
    if (!r && strstr(err, key)) {
        printf("ok   %-30s 报错含 [%s]\n", what, key);
    } else {
        fails++;
        printf("FAIL %-30s 实得 r=[%s] err=[%s]\n", what, r ? r : "(NULL)", err);
    }
    free(r);
}

/* 期望返回文字（含关键字即可：无穷多组解等明确文字） */
static void Tsys_txt(const char *eqs, const char *vars, const char *key, const char *what)
{
    char err[192] = "";
    char *r = sym_core_solve_sys(eqs, vars, err, sizeof err);
    total++;
    if (r && strstr(r, key)) {
        printf("ok   %-30s 含 [%s]\n", what, key);
    } else {
        fails++;
        printf("FAIL %-30s 实得 r=[%s] err=[%s]\n", what, r ? r : "(NULL)", err);
    }
    free(r);
}


/* ---- sym.极限 ---- */
static void Tlim(const char *expr, const char *var, const char *pt,
                 const char *want, const char *what)
{
    char err[192] = "";
    char *r = sym_core_limit(expr, var, pt, err, sizeof err);
    T(r, want, what);
    free(r);
}

/* 期望失败且 err 含关键字 */
static void Tlim_err(const char *expr, const char *var, const char *pt,
                     const char *key, const char *what)
{
    char err[192] = "";
    char *r = sym_core_limit(expr, var, pt, err, sizeof err);
    total++;
    if (!r && strstr(err, key)) {
        printf("ok   %-30s 报错含 [%s]\n", what, key);
    } else {
        fails++;
        printf("FAIL %-30s 期望报错含 [%s]，实得 r=[%s] err=[%s]\n",
               what, key, r ? r : "(NULL)", err);
    }
    free(r);
}

/* ---- sym.级数 ---- */
static void Tser(const char *expr, const char *var, const char *pt, int order,
                 const char *want, const char *what)
{
    char err[192] = "";
    char *r = sym_core_series(expr, var, pt, order, err, sizeof err);
    T(r, want, what);
    free(r);
}

static void Tser_err(const char *expr, const char *var, const char *pt, int order,
                     const char *key, const char *what)
{
    char err[192] = "";
    char *r = sym_core_series(expr, var, pt, order, err, sizeof err);
    total++;
    if (!r && strstr(err, key)) {
        printf("ok   %-30s 报错含 [%s]\n", what, key);
    } else {
        fails++;
        printf("FAIL %-30s 期望报错含 [%s]，实得 r=[%s] err=[%s]\n",
               what, key, r ? r : "(NULL)", err);
    }
    free(r);
}

int main(void)
{
    char err[192];
    char *r;
    double v;

    setvbuf(stdout, NULL, _IOLBF, 0);   /* 行缓冲：崩了也能看到崩前输出 */

    /* ---- 解析/漂亮打印 ---- */
    r = sym_core_parse("1+2*3", err, sizeof err); T(r, "1 + 2*3", "解析 优先级"); free(r);
    r = sym_core_parse("x^2*sin(x)", err, sizeof err); T(r, "x^2*sin(x)", "解析 原样"); free(r);
    r = sym_core_parse("(x+1)*(x-1)", err, sizeof err); T(r, "(x + 1)*(x - 1)", "解析 括号"); free(r);
    r = sym_core_parse("-x+1", err, sizeof err); T(r, "-x + 1", "解析 一元负"); free(r);
    r = sym_core_parse("2^-1", err, sizeof err); T(r, "2^(-1)", "解析 负指数"); free(r);
    r = sym_core_parse("pi*x+e", err, sizeof err); T(r, "pi*x + e", "解析 常量"); free(r);
    r = sym_core_parse("x^(y^z)", err, sizeof err); T(r, "x^y^z", "解析 幂右结合"); free(r);
    r = sym_core_parse("(x^y)^z", err, sizeof err); T(r, "(x^y)^z", "解析 幂左子括号"); free(r);
    r = sym_core_parse("√(x+1)", err, sizeof err); T(r, "sqrt(x + 1)", "解析 √"); free(r);
    r = sym_core_parse("π/2", err, sizeof err); T(r, "pi/2", "解析 π"); free(r);
    r = sym_core_parse("张力*2", err, sizeof err); T(r, "2*张力", "解析 中文变量"); free(r);
    r = sym_core_parse("ln(x)", err, sizeof err); T(r, "log(x)", "解析 ln 别名"); free(r);
    r = sym_core_parse("1 - (2 - 3)", err, sizeof err); T(r, "1 - (2 - 3)", "解析 减法右括号"); free(r);
    r = sym_core_parse("x/（y*z）", err, sizeof err); T(r, NULL, "解析 全角括号报错"); free(r);
    r = sym_core_parse("", err, sizeof err); T(r, NULL, "解析 空串报错"); free(r);
    r = sym_core_parse("x +", err, sizeof err); T(r, NULL, "解析 尾残缺报错"); free(r);
    r = sym_core_parse("(x+1", err, sizeof err); T(r, NULL, "解析 缺右括号报错"); free(r);
    r = sym_core_parse("foo(x)", err, sizeof err); T(r, NULL, "解析 陌生函数报错"); free(r);
    r = sym_core_parse("2 3", err, sizeof err); T(r, NULL, "解析 多余内容报错"); free(r);

    /* ---- 求导 ---- */
    Td("x^2", "x", "2*x", "求导 幂");
    Td("x^3", "x", "3*x^2", "求导 幂2");
    Td("sin(x)", "x", "cos(x)", "求导 sin");
    Td("cos(x)", "x", "-sin(x)", "求导 cos");
    Td("tan(x)", "x", "1/cos(x)^2", "求导 tan");
    Td("exp(x)", "x", "exp(x)", "求导 exp");
    Td("log(x)", "x", "1/x", "求导 log");
    Td("sqrt(x)", "x", "1/(2*sqrt(x))", "求导 sqrt");
    Td("1/x", "x", "-1/x^2", "求导 倒数");
    Td("x*sin(x)", "x", "x*cos(x) + sin(x)", "求导 乘法法则");
    Td("x^2*sin(x)", "x", "x^2*cos(x) + 2*x*sin(x)", "求导 乘法法则2");
    Td("sin(x^2)", "x", "2*x*cos(x^2)", "求导 链式");
    Td("sin(2*x+1)", "x", "2*cos(2*x + 1)", "求导 线性内函数");
    Td("x^x", "x", "x^x*(log(x) + 1)", "求导 一般幂");
    Td("2^x", "x", "2^x*log(2)", "求导 常数底幂");
    Td("asin(x)", "x", "1/sqrt(-x^2 + 1)", "求导 asin");
    Td("atan(x)", "x", "1/(x^2 + 1)", "求导 atan");
    Td("y", "x", "0", "求导 他变量=0");
    Td("3", "x", "0", "求导 常数=0");
    Td("x*y", "y", "x", "求导 中文同理");

    /* ---- 化简 ---- */
    Ts("x + x", "2*x", "化简 同类项");
    Ts("2*x + 3*x", "5*x", "化简 同类项2");
    Ts("x - x", "0", "化简 自抵");
    Ts("x*x", "x^2", "化简 同底合幂");
    Ts("x*x^3", "x^4", "化简 合幂2");
    Ts("x*0", "0", "化简 零乘");
    Ts("x*1", "x", "化简 一乘");
    Ts("x^1", "x", "化简 一幂");
    Ts("x^0", "1", "化简 零幂");
    Ts("(x^2)^3", "x^6", "化简 幂套幂");
    Ts("2+3", "5", "化简 常数折叠");
    Ts("sin(0)", "0", "化简 sin0");
    Ts("cos(0)", "1", "化简 cos0");
    Ts("exp(0)", "1", "化简 exp0");
    Ts("log(1)", "0", "化简 log1");
    Ts("log(exp(x))", "x", "化简 log-exp 互逆");
    Ts("1/2 + 1/2", "1", "化简 分数和");
    Ts("-(x + 1)", "-(x + 1)", "化简 负号保留");
    Ts("x + 2*x + 3", "3*x + 3", "化简 混合排序");
    Ts("2*x - x", "x", "化简 差同类");

    /* ---- 展开 ---- */
    Te("(x+1)^2", "x^2 + 2*x + 1", "展开 平方");
    Te("(x+1)^3", "x^3 + 3*x^2 + 3*x + 1", "展开 立方");
    Te("x*(x+1)", "x^2 + x", "展开 单分配");
    Te("(x+1)*(x-1)", "x^2 - 1", "展开 平方差");
    Te("(x+2)*(x+3)", "x^2 + 5*x + 6", "展开 双分配");

    /* ---- 积分 ---- */
    Ti("x^2", "x", "x^3/3", "积分 幂");
    Ti("x", "x", "x^2/2", "积分 一次");
    Ti("1/x", "x", "log(x)", "积分 1/x");
    Ti("sin(x)", "x", "-cos(x)", "积分 sin");
    Ti("cos(x)", "x", "sin(x)", "积分 cos");
    Ti("exp(x)", "x", "exp(x)", "积分 exp");
    Ti("exp(2*x)", "x", "exp(2*x)/2", "积分 exp 线性内");
    Ti("sin(2*x+1)", "x", "-cos(2*x + 1)/2", "积分 sin 线性内");
    Ti("1/(2*x+1)", "x", "log(2*x + 1)/2", "积分 1/线性");
    Ti("x*exp(x)", "x", "x*exp(x) - exp(x)", "积分 分部 x·e^x");
    Ti("x*sin(x)", "x", "-x*cos(x) + sin(x)", "积分 分部 x·sin");
    Ti("x*cos(x)", "x", "x*sin(x) + cos(x)", "积分 分部 x·cos");
    Ti("x^2*sin(x)", "x", "-x^2*cos(x) + 2*x*sin(x) + 2*cos(x)", "积分 分部 x²·sin");
    Ti("x*log(x)", "x", "x^2*log(x)/2 - x^2/4", "积分 x·log");
    Ti("log(x)", "x", "x*log(x) - x", "积分 log");
    Ti("sqrt(x)", "x", "2*x^1.5/3", "积分 sqrt");
    Ti("sin(x^2)", "x", "", "积分 非初等→空串");
    Ti("x/(x^2+1)", "x", "1/2*log(x^2 + 1)", "积分 x/(x^2+1) 有理");
    Ti("(x+1)^2", "x", "x^3/3 + x^2 + x", "积分 先展开再积");
    Ti("tan(x)", "x", "-log(cos(x))", "积分 tan");

    /* ---- 求值 ---- */
    r = NULL;
    total++; if (sym_core_eval("x^2 + 1", "x=3", &v, err, sizeof err)) Tv(v, 10, "求值 单变量"); else { fails++; printf("FAIL 求值 单变量: %s\n", err); }
    total++; if (sym_core_eval("x*y", "x=2, y=3", &v, err, sizeof err)) Tv(v, 6, "求值 多变量"); else { fails++; printf("FAIL 求值 多变量: %s\n", err); }
    total++; if (sym_core_eval("sin(0)", "", &v, err, sizeof err)) Tv(v, 0, "求值 无绑定"); else { fails++; printf("FAIL 求值 无绑定: %s\n", err); }
    total++; if (sym_core_eval("2^10", "", &v, err, sizeof err)) Tv(v, 1024, "求值 幂"); else { fails++; printf("FAIL 求值 幂: %s\n", err); }
    total++; if (sym_core_eval("pi", "", &v, err, sizeof err)) Tv(v, 3.141592653589793, "求值 pi"); else { fails++; printf("FAIL 求值 pi: %s\n", err); }
    total++; if (!sym_core_eval("1/0", "x=1", &v, err, sizeof err) && strstr(err, "除以 0")) { printf("ok   %-30s 除零报错\n", "求值 除零"); } else { fails++; printf("FAIL 求值 除零没报错\n"); }
    total++; if (!sym_core_eval("x + y", "x=1", &v, err, sizeof err) && strstr(err, "y")) { printf("ok   %-30s 缺绑定报错\n", "求值 缺绑定"); } else { fails++; printf("FAIL 求值 缺绑定没报错\n"); }
    total++; if (!sym_core_eval("log(-1)", "", &v, err, sizeof err) && strstr(err, "log")) { printf("ok   %-30s 定义域报错\n", "求值 log 定义域"); } else { fails++; printf("FAIL 求值 log 定义域没报错\n"); }
    total++; if (!sym_core_eval("x=2", "x=2", &v, err, sizeof err)) { printf("ok   %-30s 公式不是表达式\n", "求值 公式缺参数"); } else { fails++; printf("FAIL 求值 公式错误没报错\n"); }

    /* ---- 变量 ---- */
    r = sym_core_vars("x*y + sin(z)", err, sizeof err); T(r, "x, y, z", "变量 多变量"); free(r);
    r = sym_core_vars("3 + pi", err, sizeof err); T(r, "", "变量 无变量"); free(r);
    r = sym_core_vars("x + x", err, sizeof err); T(r, "x", "变量 去重"); free(r);
    r = sym_core_vars("甲*乙", err, sizeof err); T(r, "甲, 乙", "变量 中文"); free(r);

    /* ---- 替换 ---- */
    r = sym_core_subst("x^2", "x", "y+1", err, sizeof err); T(r, "(y + 1)^2", "替换 基本"); free(r);
    r = sym_core_subst("x + y", "x", "1", err, sizeof err); T(r, "y + 1", "替换 数字"); free(r);
    r = sym_core_subst("sin(x)", "x", "2*x", err, sizeof err); T(r, "sin(2*x)", "替换 函数内"); free(r);
    r = sym_core_subst("x^2", "y", "1", err, sizeof err); T(r, "x^2", "替换 无匹配"); free(r);

    /* ---- 相等 ---- */
    { int e1 = sym_core_equal("2*x", "x + x", err, sizeof err);
      total++; if (e1 == 1) printf("ok   %-30s 相等\n", "相等 同类项"); else { fails++; printf("FAIL 相等 同类项 -> %d\n", e1); } }
    { int e2 = sym_core_equal("x", "y", err, sizeof err);
      total++; if (e2 == 0) printf("ok   %-30s 不等\n", "相等 不同变量"); else { fails++; printf("FAIL 相等 不同变量 -> %d\n", e2); } }
    { int e3 = sym_core_equal("x +", "x", err, sizeof err);
      total++; if (e3 == -1) printf("ok   %-30s 坏公式报错\n", "相等 坏公式"); else { fails++; printf("FAIL 相等 坏公式 -> %d\n", e3); } }

    /* ---- 解方程 ---- */
    Tsolve("x^2 - 5*x + 6 = 0", "x", "x = 2, x = 3", "求解 一元二次");
    Tsolve("2*x + 1 = 0", "x", "x = -1/2", "求解 一元一次");
    Tsolve("x = 3", "x", "x = 3", "求解 裸变量");
    Tsolve("x^2 = 4*x", "x", "x = 0, x = 4", "求解 移项");
    Tsolve("x/2 = 1", "x", "x = 2", "求解 常数分母");
    Tsolve("x*(x+1) = 0", "x", "x = -1, x = 0", "求解 未展开乘积");
    Tsolve("x^2 - 9", "x", "x = -3, x = 3", "求解 缺省=0");
    Tsolve("x^2 + 2*x + 1 = 0", "x", "x = -1", "求解 重根");
    Tsolve("x^3 - x = 0", "x", "x = -1, x = 0, x = 1", "求解 三次数值根");
    Tsolve("x^5 - x = 0", "x", "x = -1, x = 0, x = 1", "求解 五次含复根");
    Tsolve("x^2 - 2 = 0", "x", "x = -1.414213562, x = 1.414213562", "求解 无理根");
    Tsolve("1 = 1", "x", "恒等式（任何值都成立）", "求解 恒等式");
    Tsolve("1 = 2", "x", "无解（两边永远不相等）", "求解 无解");
    Tsolve("(x-1)^3 = 0", "x", "x = 1", "求解 三重根");
    Tsolve_err("x^2 + 1 = 0", "x", "判别式", "求解 无实根");
    Tsolve_err("sin(x) = 0", "x", "多项式", "求解 非多项式");
    Tsolve_err("1/x = 1", "x", "多项式", "求解 分式非多项式");
    Tsolve_err("x + y = 1", "x", "sym.替换", "求解 他变量");
    Tsolve_err("x^2 + 1", "y", "找不到变量", "求解 变量不在方程");
    Tsolve_err("x^13 = 0", "x", "次数太高", "求解 超12次");
    Tsolve_err("= 0", "x", "空的", "求解 等号左边空");

    /* ---- 输出格式 ---- */
    Tfmt("x^2*sin(x)", "latex", "x^{2} \\cdot \\sin(x)", "格式 latex 基本");
    Tfmt("(x+1)/(x-1)", "latex", "\\frac{x + 1}{x - 1}", "格式 latex 分式");
    Tfmt("sqrt(x)", "latex", "\\sqrt{x}", "格式 latex 根号");
    Tfmt("pi*x", "latex", "\\pi \\cdot x", "格式 latex 圆周率");
    Tfmt("x^-2", "latex", "x^{-2}", "格式 latex 负指数");
    Tfmt("abs(x)", "latex", "\\left|x\\right|", "格式 latex 绝对值");
    Tfmt("log(x)", "latex", "\\ln(x)", "格式 latex 对数");
    Tfmt("2*x", "latex", "2 \\cdot x", "格式 latex 系数");
    Tfmt("1/2*x", "latex", "\\frac{1}{2} \\cdot x", "格式 latex 分数系数");
    Tfmt("x^2", "unicode", "x²", "格式 unicode 上标");
    Tfmt("x^-2", "unicode", "x⁻²", "格式 unicode 负上标");
    Tfmt("x^10", "unicode", "x¹⁰", "格式 unicode 多位上标");
    Tfmt("2*x", "unicode", "2·x", "格式 unicode 乘号");
    Tfmt("sqrt(x)", "unicode", "√(x)", "格式 unicode 根号");
    Tfmt("pi", "unicode", "π", "格式 unicode 圆周率");
    Tfmt("x^1.5", "unicode", "x^1.5", "格式 unicode 非整数指数");
    Tfmt("x", "plain", "x", "格式 plain 显式");
    Tfmt("x", "", "x", "格式 空模式=plain");
    Tfmt("x^2*sin(x)", "plain", "x^2*sin(x)", "格式 plain 回归1");
    Tfmt("(x+1)*(x-1)", "plain", "(x + 1)*(x - 1)", "格式 plain 回归2");
    Tfmt("-x+1", "plain", "-x + 1", "格式 plain 回归3");
    Tfmt("2*x*cos(x^2)", "plain", "2*x*cos(x^2)", "格式 plain 乘链");
    Tfmt("2^-1", "plain", "2^(-1)", "格式 plain 负指数");
    Tfmt("√(x+1)", "plain", "sqrt(x + 1)", "格式 plain 根号");
    {   /* 坏模式 */
        char err[192] = "";
        char *r = sym_core_format("x", "html", err, sizeof err);
        total++;
        if (!r && strstr(err, "latex")) printf("ok   %-30s 报错含 [latex]\n", "格式 坏模式");
        else { fails++; printf("FAIL %-30s 实得 [%s]\n", "格式 坏模式", r ? r : "(NULL)"); }
        free(r);
    }

    /* ============ sym3：有理函数积分（对拍型） ============ */
    Tid("1/(x^2-1)", "x", "2,3,5,7", "有理积分 1/(x^2-1)");
    Tid("x/(x^2-1)", "x", "2,3,5", "有理积分 x/(x^2-1)");
    Tid("(x+1)/(x^2-1)", "x", "2,3,5", "有理积分 (x+1)/(x^2-1)");
    Tid("1/(x-1)^2", "x", "2,3,5", "有理积分 1/(x-1)^2");
    Tid("1/(x^2+1)", "x", "1,2,3", "有理积分 1/(x^2+1)");
    Tid("(2*x+3)/(x^2+1)", "x", "1,2,3", "有理积分 (2x+3)/(x^2+1)");
    Tid("x^2/(x^2+1)", "x", "1,2,3", "有理积分 x^2/(x^2+1)");
    Tid("(x^3+1)/(x+1)", "x", "2,3,5", "有理积分 (x^3+1)/(x+1)");
    Tid("x/2", "x", "1,2,3", "有理积分 x/2");
    Tid("1/((x-1)*(x-2))", "x", "3,4,5", "有理积分 双单根");
    Tid("(x^2+1)/(x^3-x)", "x", "2,3,5", "有理积分 三单根");
    Tid("1/(x-1)^3", "x", "2,3", "有理积分 三重根");
    Tid("1/((x-1)*(x^2+1))", "x", "2,3,5", "有理积分 线性+二次");

    /* ============ sym3：解方程组 ============ */
    Tsys("x+y=3;x-y=1", "x,y", "x = 2, y = 1", "方程组 2x2 整数");
    Tsys("2*x+y=5;x-y=1", "x,y", "x = 2, y = 1", "方程组 2x2 系数");
    Tsys("2*x+4*y=3;x+y=1", "x,y", "x = 1/2, y = 1/2", "方程组 分数解");
    Tsys("x+y+z=6;x-y+z=2;x+y-z=0", "x,y,z", "x = 1, y = 2, z = 3", "方程组 3x3");
    Tsys("甲+乙=3;甲-乙=1", "甲,乙", "甲 = 2, 乙 = 1", "方程组 中文变量");
    Tsys("x+y=3；x-y=1", "x,y", "x = 2, y = 1", "方程组 中文分号");
    Tsys("x+y-3=0;x-y-1=0", "x,y", "x = 2, y = 1", "方程组 缺等号当=0");
    Tsys("y+x=3;x-y=1", "x,y", "x = 2, y = 1", "方程组 项乱序");
    Tsys("2*x=4", "x", "x = 2", "方程组 单变量");
    Tsys_txt("x+y=1;2*x+2*y=2", "x,y", "无穷多", "方程组 无穷多");
    Tsys_err("x+y=3", "x,y", "方程数", "方程组 个数不符");
    Tsys_err("x*y=6;x+y=5", "x,y", "不是线性的", "方程组 非线性");
    Tsys_err("pi*x+y=1;x-y=0", "x,y", "π、e", "方程组 非有理系数");
    Tsys_err("x+z=3;x-y=1", "x,y", "变量串里没有它", "方程组 串外变量");
    Tsys_err("x+y=1;x+y=2", "x,y", "无解", "方程组 矛盾无解");
    Tsys_err("x+y=3", "", "变量串是空的", "方程组 空变量串");
    Tsys_err("", "x,y", "一条方程都没有", "方程组 空方程串");


    /* ============ sym4：双曲函数补锁（函数表/求导/积分/格式四路） ============ */
    Td("sinh(x)", "x", "cosh(x)", "求导 sinh");
    Td("cosh(x)", "x", "sinh(x)", "求导 cosh");
    Td("tanh(x)", "x", "-tanh(x)^2 + 1", "求导 tanh");
    Td("sinh(2*x)", "x", "2*cosh(2*x)", "求导 sinh 链式");
    Ti("sinh(x)", "x", "cosh(x)", "积分 sinh");
    Ti("cosh(x)", "x", "sinh(x)", "积分 cosh");
    Ti("tanh(x)", "x", "log(cosh(x))", "积分 tanh");
    Ti("sinh(2*x)", "x", "cosh(2*x)/2", "积分 sinh 线性内");
    Tid("sinh(x)", "x", "1,2,3", "对拍 sinh 积分回求导");
    Tid("cosh(2*x)", "x", "1,2,3", "对拍 cosh 线性内");
    Tfmt("sinh(x)", "latex", "\\sinh(x)", "格式 latex sinh");
    Tfmt("cosh(x)", "latex", "\\cosh(x)", "格式 latex cosh");
    Tfmt("tanh(x)", "latex", "\\tanh(x)", "格式 latex tanh");
    Tfmt("sinh(x)", "unicode", "sinh(x)", "格式 unicode sinh 原名");
    total++; if (sym_core_eval("sinh(0)", "", &v, err, sizeof err)) Tv(v, 0, "求值 sinh0"); else { fails++; printf("FAIL 求值 sinh0: %s\n", err); }
    total++; if (sym_core_eval("cosh(0)", "", &v, err, sizeof err)) Tv(v, 1, "求值 cosh0"); else { fails++; printf("FAIL 求值 cosh0: %s\n", err); }
    total++; if (sym_core_eval("tanh(0)", "", &v, err, sizeof err)) Tv(v, 0, "求值 tanh0"); else { fails++; printf("FAIL 求值 tanh0: %s\n", err); }
    total++; if (sym_core_eval("sinh(1)", "", &v, err, sizeof err)) Tv(v, 1.1752011936438014, "求值 sinh1"); else { fails++; printf("FAIL 求值 sinh1: %s\n", err); }

    /* ============ sym4：极限 ============ */
    Tlim("sin(x)/x", "x", "0", "1", "极限 sin(x)/x");
    Tlim("(x^2-4)/(x-2)", "x", "2", "4", "极限 可去奇点");
    Tlim("(1-cos(x))/x^2", "x", "0", "1/2", "极限 两轮洛必达");
    Tlim("x^2", "x", "3", "9", "极限 直接代入");
    Tlim("sin(x)", "x", "pi", "0", "极限 点是 pi");
    Tlim("x/2 + 1", "x", "pi", "2.570796327", "极限 非整洁值");
    Tlim("(2*x+1)/(x-3)", "x", "inf", "2", "极限 无穷远外推");
    Tlim("1/x^2", "x", "inf", "0", "极限 无穷远归零");
    Tlim("3", "x", "7", "3", "极限 常函数");
    Tlim_err("1/x", "x", "0", "趋于无穷", "极限 真发散");
    Tlim_err("x*sin(1/x)", "x", "0", "乱抖", "极限 零点乱抖");
    Tlim_err("log(x)", "x", "0", "没定义", "极限 定义域外");
    Tlim_err("(1+x)^(1/x)", "x", "0", "对拍不一致", "极限 1^inf 陷阱");
    Tlim_err("x*sin(x)", "x", "inf", "定不下来", "极限 无穷振荡");
    Tlim_err("sin(x)", "x", "y", "点", "极限 坏点参数");
    Tlim_err("x + y", "x", "0", "还有变量", "极限 多变量");

    /* ============ sym4：级数 ============ */
    Tser("sin(x)", "x", "0", 5, "x - 1/6*x^3 + 1/120*x^5 + O(x^6)", "级数 sin 5阶");
    Tser("cos(x)", "x", "0", 4, "1 - 1/2*x^2 + 1/24*x^4 + O(x^5)", "级数 cos 4阶");
    Tser("exp(x)", "x", "0", 3, "1 + x + 1/2*x^2 + 1/6*x^3 + O(x^4)", "级数 exp 3阶");
    Tser("log(1+x)", "x", "0", 3, "x - 1/2*x^2 + 1/3*x^3 + O(x^4)", "级数 log 3阶");
    Tser("1/(1-x)", "x", "0", 3, "1 + x + x^2 + x^3 + O(x^4)", "级数 等比");
    Tser("sin(x)", "x", "0", 0, "0 + O(x)", "级数 0阶");
    Tser("sin(x)", "x", "0", 1, "x + O(x^2)", "级数 1阶");
    Tser("exp(x)", "x", "2", 2,
         "7.389056099 + 7.389056099*(x - 2) + 3.694528049*(x - 2)^2 + O((x - 2)^3)",
         "级数 非零点");
    Tser_err("sin(x)", "x", "0", 13, "阶数", "级数 阶数超界");
    Tser_err("sin(x)", "x", "0", -1, "阶数", "级数 负阶数");
    Tser_err("sin(x)", "x", "inf", 3, "有限的点", "级数 无穷点");
    Tser_err("x + y", "x", "0", 3, "还有变量", "级数 多变量");
    Tser_err("log(x)", "x", "0", 3, "求值失败", "级数 奇点展开");
    printf("\n==== 合计 %d 项：通过 %d，失败 %d ====\n", total, total - fails, fails);
    return fails ? 1 : 0;
}
