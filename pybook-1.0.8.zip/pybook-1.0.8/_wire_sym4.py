# -*- coding: utf-8 -*-
"""四端注册 sym.极限 + sym.级数（271 -> 273）。幂等 count==1，已在位则 skip。"""
import io, sys

def apply(s, label, old, new):
    ob, nb = old, new
    n = s.count(ob)
    if n == 0 and s.count(nb) == 1:
        print('skip ' + label + '（已在位）')
        return s
    if n != 1:
        sys.stderr.write('FAIL [%s] count=%d\n' % (label, n)); sys.exit(1)
    s = s.replace(ob, nb, 1)
    print('ok  ' + label)
    return s

# 1) 前端：LIB_CALLS 形参数
p = 'pybk_front.py'
s = io.open(p, encoding='utf-8', newline='').read()
s = apply(s, 'F1 front LIB_CALLS',
    "    'sym.解方程组': 2,    # (方程串, 变量串)：线性方程组精确解\n",
    "    'sym.解方程组': 2,    # (方程串, 变量串)：线性方程组精确解\n"
    "    'sym.极限': 3,        # (表达式, 变量, 点)：点可写数字/pi/e/算式或 inf/-inf\n"
    "    'sym.级数': 4,        # (表达式, 变量, 点, 阶数)：泰勒展开 + O 余项\n")
io.open(p, 'w', encoding='utf-8', newline='').write(s)

# 2) 后端：LIB_C_NAMES
p = 'pybk_code.py'
s = io.open(p, encoding='utf-8', newline='').read()
s = apply(s, 'F2 code LIB_C_NAMES',
    "        'sym.解方程组': 'rt_lib_sym_solve_sys',\n",
    "        'sym.解方程组': 'rt_lib_sym_solve_sys',\n"
    "        'sym.极限': 'rt_lib_sym_limit',\n"
    "        'sym.级数': 'rt_lib_sym_series',\n")
io.open(p, 'w', encoding='utf-8', newline='').write(s)

# 3) VM 表：声明 + 表行 + 计数 + 头注
p = '_vm_lib_calls.inc'
s = io.open(p, encoding='utf-8', newline='').read()
s = apply(s, 'F3 inc 声明',
    'Value rt_lib_sym_solve_sys(Value, Value);\n',
    'Value rt_lib_sym_solve_sys(Value, Value);\n'
    'Value rt_lib_sym_limit(Value, Value, Value);\n'
    'Value rt_lib_sym_series(Value, Value, Value, Value);\n')
s = apply(s, 'F4 inc 表行',
    '    {"sym.解方程组", 2, (void *)rt_lib_sym_solve_sys},\n',
    '    {"sym.解方程组", 2, (void *)rt_lib_sym_solve_sys},\n'
    '    {"sym.极限", 3, (void *)rt_lib_sym_limit},\n'
    '    {"sym.级数", 4, (void *)rt_lib_sym_series},\n')
s = apply(s, 'F5 inc 计数',
    '#define G_LIB_CALLS_N 271\n',
    '#define G_LIB_CALLS_N 273\n')
s = apply(s, 'F6 inc 头注',
    '/* 由 LIB_CALLS + LIB_C_NAMES 生成：271 个库调用（VM 用；m3/hw/ui/mec 整前缀不含） */\n',
    '/* 由 LIB_CALLS + LIB_C_NAMES 生成：273 个库调用（VM 用；m3/hw/ui/mec 整前缀不含） */\n')
io.open(p, 'w', encoding='utf-8', newline='').write(s)

# 4) 存在性校验
c = io.open('pybk_front.py', encoding='utf-8', newline='').read()
d = io.open('pybk_code.py', encoding='utf-8', newline='').read()
e = io.open('_vm_lib_calls.inc', encoding='utf-8', newline='').read()
for label, cond in [
    ('front 注册 极限', "'sym.极限': 3," in c),
    ('front 注册 级数', "'sym.级数': 4," in c),
    ('code 映射 极限', "'sym.极限': 'rt_lib_sym_limit'," in d),
    ('code 映射 级数', "'sym.级数': 'rt_lib_sym_series'," in d),
    ('inc 声明', 'Value rt_lib_sym_limit(Value, Value, Value);' in e),
    ('inc 表行', '{"sym.极限", 3, (void *)rt_lib_sym_limit},' in e),
    ('inc 表行 级数', '{"sym.级数", 4, (void *)rt_lib_sym_series},' in e),
    ('inc 计数 273', '#define G_LIB_CALLS_N 273' in e),
    ('inc 头注 273', '273 个库调用' in e),
]:
    print(('PASS ' if cond else 'FAIL ') + label)
    if not cond: sys.exit(1)

# 行尾检查
for f in ('pybk_front.py', 'pybk_code.py', '_vm_lib_calls.inc'):
    raw = open(f, 'rb').read()
    cr = raw.count(b'\r')
    print('%s: %d 行, 裸 CR %d' % (f, raw.count(b'\n'), cr))
    if cr != 0: sys.stderr.write('行尾混杂!\n'); sys.exit(1)
print('=== _wire_sym4 全部通过 ===')
