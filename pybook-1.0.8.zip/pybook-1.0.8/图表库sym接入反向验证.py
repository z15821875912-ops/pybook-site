"""sym 接入这一轮的反向验证：把每一处修复逐个退回，确认对应断言真的会红。

为什么要有这一步：修完再跑一遍「全绿」什么也证明不了 —— 断言如果压根没盯住
那处修复，退回去照样全绿。本脚本要求每退回一处，验证程序就**必须**报出失败
（或中途 abort），否则说明这条断言是摆设。

（只在本地临时换文件，跑完立刻还原；任何一步异常都会先还原再退出。）

注意还原必须用 copy（刷新 mtime）而不是 copy2（保留 mtime）：rt_cache/ 的 .o
按「.o 比 .c 新」判缓存命中，copy2 会让还原后的 .c 停在修复之前的 mtime，
之后所有运行都在跑反向验证过程中编出来的旧目标文件。
"""
import os
import shutil
import subprocess
import sys

sys.stdout.reconfigure(encoding='utf-8')

HERE = os.path.dirname(os.path.abspath(__file__))
PLOT = os.path.join(HERE, 'pybook_plot.c')
FRONT = os.path.join(HERE, 'pybk_front.py')

# 名字 -> (改哪个文件, 现在的新写法, 退回的旧写法, 跑哪个验证程序)
REVERTS = [
    # ---------- pybook_plot.c ----------
    ('变量名不再限定 x',
     PLOT,
     "            if (!ps->var[0])\n"
     "                snprintf(ps->var, sizeof ps->var, \"%s\", name);\n"
     "            return ps->x;\n",
     "            pt_perr(ps, \"未知名字（函数要带括号，常量只有 pi/e/x）\");\n"
     "            return 0.0;\n",
     'sym'),

    ('标识符认数字（atan2/log10/log2）',
     PLOT,
     "                   || (*ps->p >= '0' && *ps->p <= '9')\n"
     "                   || *ps->p == '_'))\n",
     "                   ))\n",
     'sym'),

    ('本地求值器补 sinh/cosh/tanh',
     PLOT,
     "        if (strcmp(name, \"sinh\") == 0) return sinh(a);\n"
     "        if (strcmp(name, \"cosh\") == 0) return cosh(a);\n"
     "        if (strcmp(name, \"tanh\") == 0) return tanh(a);\n",
     "",
     'sym'),

    ('√x 改写成 sqrt(x)',
     PLOT,
     "            if (k > j && src[k] != '(') {          /* 不是函数调用才改写 */\n",
     "            if (0) {                                 /* 反向验证：关掉改写 */\n",
     'sym'),

    ('渐近线两侧同值只报一次',
     PLOT,
     "        if (end != r && end && *end == '\\0' && isfinite(k)\n"
     "            && fabs(k) < 1e15 && !(nfound && fabs(k - found[0]) <= 1e-12 * (1.0 + fabs(k))))\n"
     "            found[nfound++] = k;\n",
     "        if (end != r && end && *end == '\\0' && isfinite(k)\n"
     "            && fabs(k) < 1e15)\n"
     "            found[nfound++] = k;\n",
     'sym'),

    ('数值积分跟 sym 那条同号',
     PLOT,
     "    double v = pt_num_integral(f, a, b, fa, fm, fb, whole, 24);\n"
     "    return flip ? -v : v;\n",
     "    (void)flip;\n"
     "    return pt_num_integral(f, a, b, fa, fm, fb, whole, 24);\n",
     'sym'),

    ('图.试值 统一「没定义」措辞',
     PLOT,
     "    if (f.err[0] && !strstr(f.err, \"非有限\"))\n"
     "        plt_die(\"图.试值：%s\", f.err);\n"
     "    if (!isfinite(v))\n"
     "        plt_die(\"图.试值：x=%g 处 \\\"%s\\\" 没定义（除零或越界）\", x, s);\n",
     "    if (f.err[0])\n"
     "        plt_die(\"图.试值：%s\", f.err);\n"
     "    if (!isfinite(v))\n"
     "        plt_die(\"图.试值：x=%g 处 \\\"%s\\\" 没定义（除零或越界）\", x, s);\n",
     'neg'),

    # 合成「像 图.曲线 那样自己重设值域」的写法 —— 这条不是退回，而是把
    # 最容易被改坏的那种实现塞进去，看断言抓不抓得住。
    ('派生图元不许接管值域',
     PLOT,
     "    PtColor col = pt_opt_color(colv, pt_palette[1], \"导数\");\n",
     "    {   /* 反向验证注入：自己扫一遍 y 范围并重设画布值域 */\n"
     "        double lo = 0.0 / 0.0, hi = 0.0 / 0.0;\n"
     "        for (long long i = 0; i <= 800; i++) {\n"
     "            double xv = c->xmin + (c->xmax - c->xmin) * (double)i / 800.0;\n"
     "            double yv = pt_fn_eval(&f, xv);\n"
     "            if (!isfinite(yv)) continue;\n"
     "            if (!isfinite(lo) || yv < lo) lo = yv;\n"
     "            if (!isfinite(hi) || yv > hi) hi = yv;\n"
     "        }\n"
     "        if (isfinite(lo) && isfinite(hi) && hi > lo) { c->ymin = lo; c->ymax = hi; }\n"
     "    }\n"
     "    PtColor col = pt_opt_color(colv, pt_palette[1], \"导数\");\n",
     'sym'),

    # ---------- pybk_front.py ----------
    ('裸文本扫描跳过字符串与注释',
     FRONT,
     '            if ch == \'"\':\n'
     "                i += 1\n"
     "                while i < n and self.src[i] != '\"':\n"
     "                    if self.src[i] == '\\\\':\n"
     "                        i += 1\n"
     "                    i += 1\n"
     "                i += 1                    # 越过闭引号（没闭合也交给词法层去报）\n"
     "                continue\n"
     "            if ch == '#':\n"
     "                while i < n and self.src[i] != '\\n':\n"
     "                    i += 1\n"
     "                continue\n",
     '',
     'neg'),
]


def run_sym():
    env = dict(os.environ, PYTHONUTF8='1', PYTHONIOENCODING='utf-8')
    p = subprocess.run([sys.executable, 'pybk_main.py', '图表库sym接入验证.pybk'],
                       cwd=HERE, capture_output=True, text=True, encoding='utf-8', env=env)
    out = p.stdout + p.stderr
    ok = fail = None
    for line in out.splitlines():
        if line.startswith('通过'):
            parts = line.split()
            ok, fail = int(parts[1]), int(parts[3])
    # 跑到一半 abort（崩溃 / plt_die）时压根不会有「通过 …」那行。
    # 这本身就是「这条修复是必需的」的铁证，必须显式报出来，不能当成 None 混过去。
    if ok is None:
        tail = [l for l in out.splitlines() if l.strip()][-3:]
        return None, None, '\n   '.join(tail)
    return ok, fail, out


def run_neg():
    env = dict(os.environ, PYTHONUTF8='1', PYTHONIOENCODING='utf-8')
    p = subprocess.run([sys.executable, '图表库sym接入负例.py'],
                       cwd=HERE, capture_output=True, text=True, encoding='utf-8', env=env)
    return p.returncode, p.stdout + p.stderr


bad = 0
for name, path, new, old, verifier in REVERTS:
    good = open(path, encoding='utf-8', newline='').read()
    n = good.count(new)
    if n != 1:
        print('锚点不唯一：%s 命中 %d 次 —— 跳过（先修锚点，别放过）' % (name, n))
        bad += 1
        continue
    bak = path + '.revbak'
    shutil.copyfile(path, bak)          # copy 不是 copy2：要刷新 mtime
    try:
        open(path, 'w', encoding='utf-8', newline='').write(good.replace(new, old))
        if verifier == 'sym':
            ok, fail, out = run_sym()
            if ok is None:
                print('\n=== 退回「%s」后：程序中途就 abort 了（这正是该修复要防的）===' % name)
                print('   ' + out)
            else:
                print('\n=== 退回「%s」后：通过 %s 失败 %s ===' % (name, ok, fail))
                if not fail:
                    print('   !! 断言全绿 —— 这条断言没盯住该修复，反向验证不成立')
                    bad += 1
                for line in out.splitlines():
                    if '断言失败' in line:
                        print('   ' + line.strip())
        else:
            rc, out = run_neg()
            print('\n=== 退回「%s」后：负例退出码 %s ===' % (name, rc))
            if rc == 0:
                print('   !! 负例全绿 —— 这条负例没盯住该修复，反向验证不成立')
                bad += 1
            for line in out.splitlines():
                if 'FAIL' in line:
                    print('   ' + line.strip())
    finally:
        shutil.copyfile(bak, path)      # 同样用 copy，刷新 mtime
        os.remove(bak)

print('')
if verifier == 'sym':
    pass
ok, fail, out = run_sym()
print('还原后复跑 图表库sym接入验证：通过 %s 失败 %s' % (ok, fail))
rc, _ = run_neg()
print('还原后复跑 负例：退出码 %s' % rc)
if fail:
    bad += 1
if rc:
    bad += 1
print('')
print('反向验证全部成立' if not bad else '有 %d 处不成立' % bad)
raise SystemExit(1 if bad else 0)
