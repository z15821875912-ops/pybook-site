/* _gproff.c —— GPU roofline 标尺：量这块卡的 FP32 算力上限与显存读带宽。
 *
 * 为什么先量这个：
 *     「加强 GPU」有两种完全不同的做法：改内核，还是去做别的事。
 *     选哪条路取决于一个我现在还不知道的事实 —— sgemm_8x8 跑 2.1 TFLOPS，
 *     离这块卡手写 PTX 的实际天花板还差多少。
 *       若 fma_peak 能到 5 TFLOPS 上下  -> 内核还有 2 倍以上，值得狠挖
 *         （而 8x8 的载入是标量 ld.global、没用 ld.global.nc，确确实实有肉）
 *       若 fma_peak 只有 2.3 左右      -> 内核已经贴着上限，转去加数学库
 *     不量就改，是在赌。
 *
 * 两个内核：
 *   fma_peak  8 条独立 FMA 链，循环里零访存 -> 纯算力上限
 *   bw_read   只读数组 + ld.global.v4      -> 读带宽上限
 *
 * 网格怎么选：fma_peak 要把 SM 填满（块数 = SM 数 × 每 SM 若干块）；
 * bw_read 要让总线程数 × 迭代次数恰好覆盖整个数组，否则读到的是同一批缓存。
 *
 * 编译：
 *   C:\Users\zhuli\mingw64\bin\x86_64-w64-mingw32-gcc.exe _gproff.c -o _gproff.exe -O2 -lm
 * 用法：
 *   _gproff.exe [每SM块数]
 */
#include <windows.h>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>

typedef int          CUresult;
typedef int          CUdevice;
typedef void        *CUcontext;
typedef void        *CUmodule;
typedef void        *CUfunction;
typedef void        *CUstream;
typedef unsigned long long CUdeviceptr;

#define CU_DEVICE_ATTRIBUTE_CC_MAJOR 75
#define CU_DEVICE_ATTRIBUTE_CC_MINOR 76
#define CU_DEVICE_ATTRIBUTE_MULTIPROCESSOR_COUNT 16
#define CU_EVENT_DEFAULT 0

static HMODULE g_dll;
static CUresult (*p_cuInit)(unsigned);
static CUresult (*p_cuDriverGetVersion)(int *);
static CUresult (*p_cuDeviceGet)(CUdevice *, int);
static CUresult (*p_cuDeviceGetName)(char *, int, CUdevice);
static CUresult (*p_cuDeviceGetAttribute)(int *, int, CUdevice);
static CUresult (*p_cuDevicePrimaryCtxRetain)(CUcontext *, CUdevice);
static CUresult (*p_cuCtxSetCurrent)(CUcontext);
static CUresult (*p_cuCtxSynchronize)(void);
static CUresult (*p_cuModuleLoadData)(CUmodule *, const void *);
static CUresult (*p_cuModuleGetFunction)(CUfunction *, CUmodule *, const char *);
static CUresult (*p_cuMemAlloc_v2)(CUdeviceptr *, size_t);
static CUresult (*p_cuMemFree_v2)(CUdeviceptr);
static CUresult (*p_cuMemcpyHtoD_v2)(CUdeviceptr, const void *, size_t);
static CUresult (*p_cuMemcpyDtoH_v2)(void *, CUdeviceptr, size_t);
static CUresult (*p_cuLaunchKernel)(CUfunction, unsigned, unsigned, unsigned,
                                    unsigned, unsigned, unsigned,
                                    unsigned, CUstream, void **, void **);
static CUresult (*p_cuGetErrorString)(CUresult, const char **);
static CUresult (*p_cuEventCreate)(void **, unsigned);
static CUresult (*p_cuEventRecord)(void *, CUstream);
static CUresult (*p_cuEventSynchronize)(void *);
static CUresult (*p_cuEventElapsedTime)(float *, void *, void *);

static CUcontext g_ctx;
static char g_err[256];
static char g_ptx[65536];

static const char *cu_err(CUresult r)
{
    const char *s = NULL;
    if (p_cuGetErrorString && p_cuGetErrorString(r, &s) == 0 && s) return s;
    return "未知 CUDA 错误";
}

/* 每一步都要查返回值。
 * 教训（本文件第一版就栽在这）：cuEventElapsedTime 失败时 el 保持上次的值，
 * 于是 9 次取中位数得到 0.002ms，再一算就是 3357 TFLOPS —— 荒谬值却没有任何报错，
 * 因为我根本没看返回值。宁可每步检查一次，也不要拿一个没验证过的数字去定方向。 */
#define CK(expr, what) do {                                   \
        CUresult _r = (expr);                                \
        if (_r != 0) {                                       \
            printf("[错误] %s -> %s\n", (what), cu_err(_r));  \
            return 1;                                        \
        }                                                    \
    } while (0)

static int load_ptx(const char *path)
{
    FILE *f = fopen(path, "rb");
    size_t n;
    if (!f) { snprintf(g_err, sizeof g_err, "打不开 %s", path); return 0; }
    n = fread(g_ptx, 1, sizeof(g_ptx) - 1, f);
    fclose(f);
    g_ptx[n] = '\0';
    if (n < 100) { snprintf(g_err, sizeof g_err, "%s 太短（%zu 字节）", path, n); return 0; }
    return 1;
}

static int cmp_dbl(const void *a, const void *b)
{
    double x = *(const double *)a, y = *(const double *)b;
    return (x > y) - (x < y);
}

int main(int argc, char **argv)
{
    void *p;
    CUdevice dev;
    CUmodule mF = NULL, mB = NULL, mS = NULL;
    CUfunction fF = NULL, fB = NULL, fS = NULL;
    CUresult r;
    int maj = 0, min = 0, nsm = 0, rep, i;
    int blocks_per_sm = argc > 1 ? atoi(argv[1]) : 8;
    unsigned gx, gy = 1, bx = 256, by = 1;
    void *ev0 = NULL, *ev1 = NULL;
    CUdeviceptr dA = 0, dB = 0, dOut = 0;
    double t[16];
    float el;
    double g_peak_tflops = 0;   /* fma_peak 测出的算力上限，后面算比例要用 */
    double g_sgemm_tflops = 0;  /* sgemm_8x8 在同一次运行里测出的成绩 */

    SetConsoleOutputCP(65001);
    if (blocks_per_sm < 1) blocks_per_sm = 1;

    g_dll = LoadLibraryA("nvcuda.dll");
    if (!g_dll) { printf("找不到 nvcuda.dll\n"); return 1; }
#define LOAD(n, f) do { p = (void *)GetProcAddress(g_dll, n); \
    if (!p) { printf("缺 %s\n", n); return 1; } memcpy(&(f), &p, sizeof(f)); } while (0)
    LOAD("cuInit", p_cuInit);
    LOAD("cuDriverGetVersion", p_cuDriverGetVersion);
    LOAD("cuDeviceGet", p_cuDeviceGet);
    LOAD("cuDeviceGetName", p_cuDeviceGetName);
    LOAD("cuDeviceGetAttribute", p_cuDeviceGetAttribute);
    LOAD("cuDevicePrimaryCtxRetain", p_cuDevicePrimaryCtxRetain);
    LOAD("cuCtxSetCurrent", p_cuCtxSetCurrent);
    LOAD("cuCtxSynchronize", p_cuCtxSynchronize);
    LOAD("cuModuleLoadData", p_cuModuleLoadData);
    LOAD("cuModuleGetFunction", p_cuModuleGetFunction);
    LOAD("cuMemFree_v2", p_cuMemFree_v2);
    LOAD("cuMemcpyHtoD_v2", p_cuMemcpyHtoD_v2);
    LOAD("cuMemcpyDtoH_v2", p_cuMemcpyDtoH_v2);
    LOAD("cuLaunchKernel", p_cuLaunchKernel);
    LOAD("cuGetErrorString", p_cuGetErrorString);
    LOAD("cuEventCreate", p_cuEventCreate);
    LOAD("cuEventRecord", p_cuEventRecord);
    LOAD("cuEventSynchronize", p_cuEventSynchronize);
    LOAD("cuEventElapsedTime", p_cuEventElapsedTime);
    p = (void *)GetProcAddress(g_dll, "cuMemAlloc_v2");
    memcpy(&p_cuMemAlloc_v2, &p, sizeof(p));
#undef LOAD
    if (!p_cuMemAlloc_v2) { printf("缺 cuMemAlloc_v2\n"); return 1; }

    if (p_cuInit(0) != 0) { printf("cuInit 失败\n"); return 1; }
    if (p_cuDeviceGet(&dev, 0) != 0) { printf("取不到设备\n"); return 1; }
    p_cuDeviceGetName(g_err, 64, dev);
    p_cuDeviceGetAttribute(&maj, CU_DEVICE_ATTRIBUTE_CC_MAJOR, dev);
    p_cuDeviceGetAttribute(&min, CU_DEVICE_ATTRIBUTE_CC_MINOR, dev);
    p_cuDeviceGetAttribute(&nsm, CU_DEVICE_ATTRIBUTE_MULTIPROCESSOR_COUNT, dev);
    if (p_cuDevicePrimaryCtxRetain(&g_ctx, dev) != 0) { printf("建不了 context\n"); return 1; }
    p_cuCtxSetCurrent(g_ctx);

    printf("设备：%s   CC=sm_%d%d   SM 数 = %d\n", g_err, maj, min, nsm);
    gx = (unsigned)(nsm * blocks_per_sm);
    printf("网格 %u 块 × %u 线程 = %u 线程（每 SM %d 块）\n\n", gx, bx, gx * bx, blocks_per_sm);

    if (p_cuMemAlloc_v2(&dOut, 4096) != 0) { printf("显存分配失败\n"); return 1; }
    p_cuEventCreate(&ev0, CU_EVENT_DEFAULT);
    p_cuEventCreate(&ev1, CU_EVENT_DEFAULT);

    /* ---------------- fma_peak：FP32 算力上限 ---------------- */
    if (!load_ptx("_ptx_FMAPEAK.ptx")) { printf("%s\n", g_err); return 1; }
    r = p_cuModuleLoadData(&mF, g_ptx);
    if (r != 0) { printf("FMAPEAK PTX 被拒：%s\n", cu_err(r)); return 1; }
    if (p_cuModuleGetFunction(&fF, mF, "fma_peak") != 0) { printf("取不到 fma_peak\n"); return 1; }
    /* 诊断：句柄是否真的取到了？最小网格能不能发出去？
     * 「invalid argument」在发射阶段有太多可能来源（句柄为野、参数地址不对、
     * 参数宽度不符、网格非法），先把「句柄 + 最小配置」单独验掉，
     * 否则后面每个数字都不可信。 */
    {
        unsigned it1 = 4u;
        void *pa[2];
        CUresult dr;
        pa[0] = &dOut; pa[1] = &it1;
        printf("[诊断] fF=%p  mF=%p  dOut=%llu\n", (void *)fF, (void *)mF, dOut);
        dr = p_cuLaunchKernel(fF, 1, 1, 1, 32, 1, 1, 0, NULL, pa, NULL);
        printf("[诊断] 最小网格(1块x32线程) 发射 -> %d (%s)\n", (int)dr, cu_err(dr));
        if (dr != 0) return 1;
        CK(p_cuCtxSynchronize(), "最小网格同步");
        printf("[诊断] 最小网格跑通了\n");
    }
    /* ---------------- fma_peak 与 sgemm_8x8 同轮交替测 ----------------
     *
     * 为什么要交替发射、而不是各测各的：
     * 这块卡跨运行升频很凶，fma_peak 在几次不同运行里测到过 3.44~4.27 TFLOPS
     * （差 24%）。拿某一次运行的上限去比另一次运行的 sgemm，比值是编出来的。
     * 交替发射让两个内核吃到同样的频率状态，再各取 9 次的中位数。
     *
     * sgemm_8x8 的启动配置与 pybook_gpu.c 完全一致：
     *   grid = (ceil(N/128), ceil(M/128))，block = 16x16 = 256 线程
     */
    if (!load_ptx("_ptx_PTX_8X8.ptx")) { printf("%s\n", g_err); return 1; }
    r = p_cuModuleLoadData(&mS, g_ptx);
    if (r != 0) { printf("PTX_8X8 被拒：%s\n", cu_err(r)); return 1; }
    if (p_cuModuleGetFunction(&fS, mS, "sgemm_8x8") != 0) { printf("取不到 sgemm_8x8\n"); return 1; }
    {
        const int NCHK = 192;              /* 正确性自检用的小尺寸 */
        const size_t cchk = (size_t)NCHK * NCHK * sizeof(float);
        /* 扫 N。之前手上只有两个来路不同的数字在打架：这次同测 N=2048 得
         * 1.31 TFLOPS，而早前记的 N=3216 是 1.92。不扫一遍就不知道哪个能代表
         * 生产的 tb.dot 尺寸（N=3216），更不知道 37% 这个比例是不是尺寸特例。 */
        static const int nlist[] = { 1024, 2048, 3216, 4096 };
        const int nl = (int)(sizeof nlist / sizeof nlist[0]);
        unsigned iters = 20000u;
        int qi;

        /* 正确性自检：拿朴素三重循环当裁判。
           注意必须用**行距就是 NCHK 的独立小缓冲**。
           我第一版直接把 M=N=K=192 发给内核，却配着行距 2048 的大缓冲 ——
           内核只认参数里的 M，行距错了读到的是另一批数，于是报出 19.7 的
           「误差」。先确认算的是对的，否则测的是错代码的速度。 */
        {
            int i, j, kk2;
            double worst = 0.0;
            unsigned cgx = (unsigned)((NCHK + 127) / 128);
            CUdeviceptr dAs = 0, dBs = 0, dCs = 0;
            float *sA = (float *)malloc(cchk);
            float *sB = (float *)malloc(cchk);
            float *sC = (float *)malloc(cchk);
            void *cargs[6];
            int cmm, cnn, ckk;
            size_t k2; unsigned sd = 987654321u;
            if (!sA || !sB || !sC) { printf("host 内存不足\n"); return 1; }
            for (k2 = 0; k2 < cchk / sizeof(float); k2++) {
                sd = sd * 1103515245u + 12345u;
                sA[k2] = ((float)((sd >> 9) & 0xFFFF) / 32768.0f) - 1.0f;
                sd = sd * 1103515245u + 12345u;
                sB[k2] = ((float)((sd >> 9) & 0xFFFF) / 32768.0f) - 1.0f;
            }
            CK(p_cuMemAlloc_v2(&dAs, cchk), "分配自检 A");
            CK(p_cuMemAlloc_v2(&dBs, cchk), "分配自检 B");
            CK(p_cuMemAlloc_v2(&dCs, cchk), "分配自检 C");
            CK(p_cuMemcpyHtoD_v2(dAs, sA, cchk), "自检 A 上显存");
            CK(p_cuMemcpyHtoD_v2(dBs, sB, cchk), "自检 B 上显存");
            cmm = NCHK; cnn = NCHK; ckk = NCHK;
            cargs[0] = &dAs; cargs[1] = &dBs; cargs[2] = &dCs;
            cargs[3] = &cmm; cargs[4] = &cnn; cargs[5] = &ckk;
            CK(p_cuLaunchKernel(fS, cgx, cgx, 1, 16, 16, 1, 0, NULL, cargs, NULL), "sgemm 自检发射");
            CK(p_cuCtxSynchronize(), "sgemm 自检同步");
            CK(p_cuMemcpyDtoH_v2(sC, dCs, cchk), "自检 C 回主机");
            for (i = 0; i < NCHK; i++) {
                for (j = 0; j < NCHK; j++) {
                    double sum = 0.0, d, sc;
                    for (kk2 = 0; kk2 < NCHK; kk2++)
                        sum += (double)sA[(size_t)i * NCHK + kk2] * (double)sB[(size_t)kk2 * NCHK + j];
                    d = fabs(sum - (double)sC[(size_t)i * NCHK + j]);
                    sc = fabs(sum); if (sc < 1.0) sc = 1.0;
                    if (d / sc > worst) worst = d / sc;
                }
            }
            printf("sgemm_8x8 自检 %dx%dx%d  最大相对误差 %.3e\n", NCHK, NCHK, NCHK, worst);
            free(sA); free(sB); free(sC);
            p_cuMemFree_v2(dAs); p_cuMemFree_v2(dBs); p_cuMemFree_v2(dCs);
            if (!(worst < 1e-4)) {
                printf("[错误] sgemm_8x8 算错了，后面所有计时都没有意义\n");
                return 1;
            }
        }

        /* ---------------- 扫 N：每个尺寸都与 fma_peak 同轮交替测 ---------------- */
        printf("\n    N     grid    sgemm 用时   sgemm TFLOPS   fma_peak   占比\n");
        printf("  -----------------------------------------------------------\n");
        for (qi = 0; qi < nl; qi++) {
            int NTIM = nlist[qi];
            size_t cap2 = (size_t)NTIM * NTIM * sizeof(float);
            float *hA = (float *)malloc(cap2);
            float *hB = (float *)malloc(cap2);
            CUdeviceptr dA2 = 0, dB2 = 0, dC2 = 0;
            double tf[9], ts[9];
            int mm, nn, kk;
            void *sargs[6];
            void *pargs[2];
            unsigned pgx, pgy;

            if (!hA || !hB) { printf("host 内存不足\n"); return 1; }
            {
                size_t k2; unsigned s = 12345u;
                for (k2 = 0; k2 < cap2 / sizeof(float); k2++) {
                    s = s * 1103515245u + 12345u;
                    hA[k2] = ((float)((s >> 9) & 0xFFFF) / 32768.0f) - 1.0f;
                    s = s * 1103515245u + 12345u;
                    hB[k2] = ((float)((s >> 9) & 0xFFFF) / 32768.0f) - 1.0f;
                }
            }
            CK(p_cuMemAlloc_v2(&dA2, cap2), "分配 A");
            CK(p_cuMemAlloc_v2(&dB2, cap2), "分配 B");
            CK(p_cuMemAlloc_v2(&dC2, cap2), "分配 C");
            CK(p_cuMemcpyHtoD_v2(dA2, hA, cap2), "A 上显存");
            CK(p_cuMemcpyHtoD_v2(dB2, hB, cap2), "B 上显存");
            sargs[0] = &dA2; sargs[1] = &dB2; sargs[2] = &dC2;
            sargs[3] = &mm; sargs[4] = &nn; sargs[5] = &kk;
            pgx = (unsigned)((NTIM + 127) / 128); pgy = pgx;
            mm = NTIM; nn = NTIM; kk = NTIM;

            /* 预热：两个内核都要烧掉首次发射里的 JIT */
            pargs[0] = &dOut; pargs[1] = &iters;
            CK(p_cuLaunchKernel(fF, gx, gy, 1, bx, by, 1, 0, NULL, pargs, NULL), "fma_peak 预热发射");
            CK(p_cuLaunchKernel(fS, pgx, pgy, 1, 16, 16, 1, 0, NULL, sargs, NULL), "sgemm 预热发射");
            CK(p_cuCtxSynchronize(), "预热同步");

            for (rep = 0; rep < 9; rep++) {
                /* 每轮固定「先 fma 再 sgemm」，两者共享同一段频率状态 */
                CK(p_cuEventRecord(ev0, 0), "ev0 record");
                CK(p_cuLaunchKernel(fF, gx, gy, 1, bx, by, 1, 0, NULL, pargs, NULL), "fma 发射");
                CK(p_cuEventRecord(ev1, 0), "ev1 record");
                CK(p_cuEventSynchronize(ev1), "ev1 同步");
                CK(p_cuEventElapsedTime(&el, ev0, ev1), "fma 用时");
                if (el <= 0) { printf("[错误] fma 用时非正：%f ms\n", (double)el); return 1; }
                tf[rep] = el;

                CK(p_cuEventRecord(ev0, 0), "ev0 record");
                CK(p_cuLaunchKernel(fS, pgx, pgy, 1, 16, 16, 1, 0, NULL, sargs, NULL), "sgemm 发射");
                CK(p_cuEventRecord(ev1, 0), "ev1 record");
                CK(p_cuEventSynchronize(ev1), "ev1 同步");
                CK(p_cuEventElapsedTime(&el, ev0, ev1), "sgemm 用时");
                if (el <= 0) { printf("[错误] sgemm 用时非正：%f ms\n", (double)el); return 1; }
                ts[rep] = el;
            }
            qsort(tf, 9, sizeof(double), cmp_dbl);
            qsort(ts, 9, sizeof(double), cmp_dbl);
            {
                double flops = 2.0 * NTIM * NTIM * NTIM;
                double fpeak = (double)gx * bx * iters * 8.0 * 2.0 / (tf[4] / 1000.0) / 1e12;
                double sgem = flops / (ts[4] / 1000.0) / 1e12;
                printf("  %5d  %3ux%-3u  %8.3f ms  %9.2f T  %8.2f T  %5.1f%%\n",
                       NTIM, pgx, pgy, ts[4], sgem, fpeak, sgem / fpeak * 100.0);
                g_peak_tflops = fpeak;
                /* 以生产的 tb.dot 尺寸 N=3216 为准下结论 */
                if (NTIM == 3216) g_sgemm_tflops = sgem;
            }
            free(hA); free(hB);
            p_cuMemFree_v2(dA2); p_cuMemFree_v2(dB2); p_cuMemFree_v2(dC2);
        }
    }

    /* ---------------- bw_read：读带宽上限 ---------------- */
    if (!load_ptx("_ptx_BWREAD.ptx")) { printf("%s\n", g_err); return 1; }
    r = p_cuModuleLoadData(&mB, g_ptx);
    if (r != 0) { printf("BWREAD PTX 被拒：%s\n", cu_err(r)); return 1; }
    if (p_cuModuleGetFunction(&fB, mB, "bw_read") != 0) { printf("取不到 bw_read\n"); return 1; }
    {
        /* 扫数组大小，而不是只量一个尺寸。
         *
         * 为什么必须扫：只量一个尺寸时报出 13~14 TB/s，而 1060 是 GDDR5，
         * 物理带宽理论值才 ~179 GB/s，差 80 倍。那种量级只有一个解释 ——
         * 每轮读的是同一个地址，命中的全是 L1/L2。
         * 扫尺寸能一眼分辨：小数组（装得进 L2）快、大数组被 DRAM 压住 = 真带宽；
         * 各尺寸给出同一个离谱的数 = 假的。
         *
         * 只分配一次最大容量，用 iters 控制实际跑多远。
         */
        static const size_t sizes_mb[] = { 64, 256, 1024, 2048 };
        int ns = (int)(sizeof sizes_mb / sizeof sizes_mb[0]);
        int si;
        size_t cap = (size_t)sizes_mb[ns - 1] * 1024 * 1024;
        size_t stride = (size_t)gx * bx * 16;
        float *h = (float *)malloc(cap);
        CUdeviceptr dArr = 0;
        double gbs_big = 0;
        int bad = 0;

        if (!h) { printf("host 内存不足（需要 %.1f MB）\n", cap / 1048576.0); return 1; }
        /* 数组填 1.0f（不是清零）：内核把每次读到的值累加起来，
         * 于是输出必须正好等于迭代数 —— 这是「每次载入真的发生了」端到端的证据。
         * 填 0 的话累加器恒为 0，连删掉全部载入都看不出来。 */
        {
            size_t k;
            float one = 1.0f;
            for (k = 0; k < cap / sizeof(float); k++) h[k] = one;
        }
        CK(p_cuMemAlloc_v2(&dArr, cap), "分配 bw 数组");
        p_cuMemcpyHtoD_v2(dArr, h, cap);

        printf("\n  数组    迭代   累加=轮数  游标字节      用时      带宽\n");
        printf("  --------------------------------------------------------------\n");
        for (si = 0; si < ns; si++) {
            unsigned iters = (unsigned)((size_t)sizes_mb[si] * 1024 * 1024 / stride);
            void *pargs[3];
            float back[7];
            double bytes, ms, gbs;
            unsigned k;
            if (iters < 16) continue;
            pargs[0] = &dArr; pargs[1] = &dOut; pargs[2] = &iters;
            CK(p_cuLaunchKernel(fB, gx, gy, 1, bx, by, 1, 0, NULL, pargs, NULL), "bw 预热发射");
            CK(p_cuCtxSynchronize(), "bw 预热同步");

            /* 自检：数组填的是 1.0f，内核把每次读到的值累加，
             * 所以 dOut[0] 必须正好等于迭代数 —— 少一次载入都躲不过。
             * 这一条比「轮数对不对」「游标动没动」都硬：那两个查的都是
             * 记账，编译器删掉全部载入照样能通过。 */
            memset(back, 0, sizeof back);
            CK(p_cuMemcpyDtoH_v2(back, dOut, 28), "读回 bw 输出");
            if (fabs((double)back[4] - (double)iters) > 1.0) {
                printf("  %4zu MB  %5u   ** 只跑了 %.0f 轮 **  数据无效\n",
                       sizes_mb[si], iters, (double)back[4]);
                bad = 1;
                continue;
            }
            if (fabs((double)back[0] - (double)iters) > 1.0) {
                printf("  %4zu MB  %5u   ** 累加得 %.0f，应为 %.0f：载入被编译器删了 **\n",
                       sizes_mb[si], iters, (double)back[0], (double)iters);
                bad = 1;
                continue;
            }
            if (back[6] < 1.0) {
                printf("  %4zu MB  %5u   ** 游标没推进 **  读的是同一个地址，数据无效\n",
                       sizes_mb[si], iters);
                bad = 1;
                continue;
            }

            for (rep = 0; rep < 9; rep++) {
                el = -1.0f;
                CK(p_cuEventRecord(ev0, 0), "ev0 record");
                CK(p_cuLaunchKernel(fB, gx, gy, 1, bx, by, 1, 0, NULL, pargs, NULL), "bw 发射");
                CK(p_cuEventRecord(ev1, 0), "ev1 record");
                CK(p_cuEventSynchronize(ev1), "ev1 同步");
                CK(p_cuEventElapsedTime(&el, ev0, ev1), "取 event 用时");
                if (el <= 0) { printf("[错误] event 用时非正：%f ms\n", (double)el); return 1; }
                ms = el;
                bytes = (double)gx * bx * iters * 16.0;
                t[rep] = bytes / (ms / 1000.0) / 1e9;     /* GB/s */
            }
            qsort(t, 9, sizeof(double), cmp_dbl);
            gbs = t[4];
            printf("  %4zu MB  %5u   %5.0f=%5.0f  %9.0f  %7.3f ms  %8.1f GB/s\n",
                   sizes_mb[si], iters, (double)back[0], (double)back[4],
                   (double)back[6], ms, gbs);
            if (si == ns - 1) gbs_big = gbs;
        }
        free(h);
        p_cuMemFree_v2(dArr);
        if (bad) {
            printf("\n[错误] 有尺寸的数据无效，上面的带宽不能用来下结论\n");
            return 1;
        }

        /* ---------------- 结论：sgemm 还差多少 ---------------- */
        printf("\n================ 判定 ================\n");
        printf("  fma_peak 算力上限   %.2f TFLOPS（每个 N 各测一次，取 N=3216 那次）\n", g_peak_tflops);
        printf("  读带宽上限          %.1f GB/s（最大数组，GPU 理论约 179 GB/s）\n", gbs_big);
        printf("  sgemm_8x8 实测      %.2f TFLOPS（N=3216 方阵，生产的 tb.dot 尺寸）\n", g_sgemm_tflops);
        printf("  -> sgemm 达到算力上限的 %.1f%%\n", g_sgemm_tflops / g_peak_tflops * 100.0);
        {
            double si = g_peak_tflops * 1e12 / (gbs_big * 1e9);   /* flop/byte */
            printf("\n  转折强度 = %.1f flop/byte（算力上限 / 带宽上限）\n", si);
            printf("  sgemm 的算术强度 ≈ K/(2*(M+N))：K=1024 时 0.25、K=3216 时 0.50\n");
            if (0.50 < si)
                printf("  sgemm 强度比转折强度低 %.0f 倍 -> 强烈算力受限，\n"
                       "  「少搬数据」没用，该动的是每条 FMA 周围的杂指令和全局载入延迟\n", si / 0.50);
            else
                printf("  sgemm 强度高于转折强度 -> 带宽受限，要从「少搬数据」下手\n");
        }
    }
    return 0;
}
