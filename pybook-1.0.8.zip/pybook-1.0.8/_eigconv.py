﻿# -*- coding: utf-8 -*-
"""收敛体检：G&V 首向量展开式修好之后，看看几步能收敛、特征值对不对。

用法：python -B _eigconv.py
"""
import numpy as np
import _eigref as R

rng = np.random.default_rng(7)

print("%-4s %-6s %8s %8s %12s %12s %12s" %
      ("n", "试次", "步数", "收敛", "特征值误差", "‖QᵀQ−I‖", "‖A−QTQᵀ‖"))
print("-" * 74)

bad = 0
for n in (1, 2, 3, 4, 5, 6, 8, 10, 12, 16, 20, 30, 40):
    for trial in range(3):
        if n == 1:
            A = np.array([[rng.standard_normal()]])
        else:
            A = rng.standard_normal((n, n))
            if trial == 1:                       # 对称
                A = (A + A.T) / 2
            if trial == 2:                       # 上三角：全是实特征值
                A = np.triu(A)
        t, q, its, ok, wre, wim = R.schur(A, maxits=300 * n + 2000)
        if ok:
            ref = np.linalg.eigvals(A)
            mine = wre + 1j * wim
            err = np.abs(np.sort_complex(mine) - np.sort_complex(ref)).max()
            orth = np.abs(q.T @ q - np.eye(n)).max()
            rec = np.abs(A - q @ t @ q.T).max()
        else:
            err = orth = rec = float("nan")
        if (not ok) or err > 1e-8 * max(1.0, np.abs(A).max()):
            bad += 1
        print("%-4d %-6d %8d %8s %12.3e %12.3e %12.3e" %
              (n, trial, its, ok, err, orth, rec))
print("-" * 74)
print("不合格：", bad)
