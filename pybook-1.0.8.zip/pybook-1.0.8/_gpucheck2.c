/* _gpucheck2.c —— 生产入口 gpu_sgemm_f32 的路由对拍（第二跳落地验证）
 *
 * 验两件事：
 *   1. 正确性：N=1280（走 sgemm_8x8）、N=256/300/512/1024（走 sgemm_shared）、
 *      N=128（走 sgemm 4x4）都与 CPU 参考逐元素一致（f32 容差）。
 *   2. 路由真的生效：三个 kernel 各被走到 —— 直接证据见插桩构建
 *      （build_tmp/_route_dbg_patch.py 生成的 _gpu_dbg.c 打印实际入口名）。
 *
 * 编译：gcc _gpucheck2.c pybook_gpu.c -o _gpucheck2.exe -O2 -I. -lwinmm -lm
 */
#include "pybook_gpu.h"
#include "pybook_rt.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <windows.h>

/* 链接期 stub：pybook_gpu.c 引用了 pybook_rt 的这几个符号，
 * 本探针只走 gpu_available/gpu_sgemm_f32/gpu_device_name/gpu_last_error，
 * 不会真的调到它们（gpu_device_name 探测成功时直接返回 g_name）。 */
void rt_die(const char *fmt, ...) { (void)fmt; fputs("rt_die(stub)\n", stderr); exit(2); }
Value rt_str(const char *s) { (void)s; Value v; memset(&v, 0, sizeof v); return v; }

static unsigned g_seed = 777u;
static double frand(void)
{
    g_seed = g_seed * 1103515245u + 12345u;
    return (double)((g_seed >> 9) & 0xFFFF) / 65536.0 - 0.5;
}

static double now_s(void)
{
    /* 墙钟：gpu_sgemm_f32 内含 cuCtxSynchronize 阻塞，clock() 的 CPU 时间
     * 在阻塞期间不走，会量出 inf GFLOPS。必须用 QueryPerformanceCounter。 */
    static LARGE_INTEGER freq = {0};
    LARGE_INTEGER t;
    if (freq.QuadPart == 0) QueryPerformanceFrequency(&freq);
    QueryPerformanceCounter(&t);
    return (double)t.QuadPart / (double)freq.QuadPart;
}

static int check(int M, int N, int K, int rep)
{
    size_t ka = (size_t)M * K, kb = (size_t)K * N, kc = (size_t)M * N;
    double *A = malloc(ka * sizeof(double));
    double *B = malloc(kb * sizeof(double));
    double *C = malloc(kc * sizeof(double));
    double *R = malloc(kc * sizeof(double));
    double best = 1e30, gflops;
    size_t i;
    int it, bad = 0;

    if (!A || !B || !C || !R) { printf("host 内存不足\n"); return 0; }
    for (i = 0; i < ka; i++) A[i] = frand();
    for (i = 0; i < kb; i++) B[i] = frand();

    /* CPU 参考（行主序，double 累加） */
    for (int r = 0; r < M; r++)
        for (int c = 0; c < N; c++) {
            double acc = 0.0;
            for (int p = 0; p < K; p++)
                acc += A[(size_t)r * K + p] * B[(size_t)p * N + c];
            R[(size_t)r * N + c] = acc;
        }

    for (it = 0; it < rep; it++) {
        double t0 = now_s();
        int ok = gpu_sgemm_f32(A, B, C, M, N, K);
        double t1 = now_s();
        if (!ok) {
            printf("  M=%-4d N=%-4d K=%-4d  GPU 拒绝：%s\n", M, N, K, gpu_last_error());
            free(A); free(B); free(C); free(R);
            return 0;
        }
        if (t1 - t0 < best) best = t1 - t0;
    }

    /* f32 对拍：GPU 路径是 float32 累加，容差按值域给 */
    for (i = 0; i < kc; i++) {
        double d = fabs(C[i] - R[i]);
        if (d > 1e-2) { bad++; if (bad <= 3) printf("    错@%zu: gpu=%f ref=%f\n", i, C[i], R[i]); }
    }
    gflops = 2.0 * M * N * K / best / 1e9;
    printf("  M=%-4d N=%-4d K=%-4d  %s  %8.1f GFLOPS  超差元素 %d\n",
           M, N, K,
           N >= 1280 ? "[8x8   ]" : N >= 256 ? "[shared]" : "[4x4   ]",
           gflops, bad);
    free(A); free(B); free(C); free(R);
    return bad == 0;
}

int main(void)
{
    int ok = 1;
    if (!gpu_available()) {
        printf("GPU 不可用：%s\n", gpu_device_name());
        return 1;
    }
    printf("设备：%s\n", gpu_device_name());
    /* 三 kernel 路由分界（1060 六轮交替测量中位数）：N<256 走 4x4、
     * 256<=N<1280 走 shared、N>=1280 走 8x8。每档至少取一个用例。 */
    if (!check(128, 128, 128, 5)) ok = 0;
    if (!check(64, 128, 256, 5)) ok = 0;
    if (!check(256, 256, 256, 3)) ok = 0;
    if (!check(512, 512, 512, 3)) ok = 0;
    if (!check(1024, 1024, 1024, 2)) ok = 0;
    if (!check(1280, 1280, 1280, 2)) ok = 0;
    /* 尾块：N=300 不是 64 倍数、K=132 不是 8 倍数 */
    if (!check(300, 300, 132, 3)) ok = 0;
    printf("%s\n", ok ? "路由对拍全部通过" : "★有失败★");
    return ok ? 0 : 1;
}
