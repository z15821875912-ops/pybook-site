# -*- coding: utf-8 -*-
"""_probe_block.py -- 查 pybook_gpu.c 里某个 PTX 块的起止与收尾写法。

为什么要这个：_embed_ptx.py 靠找 '\\n";' 来定位块的结尾，
但 8x8 这个块的收尾写法跟 4x4 不一样，直接跑会 ValueError。
先看清楚它到底怎么收的，再决定是改工具还是改块。
"""
import io
import sys

VAR = sys.argv[1] if len(sys.argv) > 1 else 'PTX_BODY_8X8'
DST = 'pybook_gpu.c'

text = io.open(DST, encoding='utf-8', newline='').read()
anchor = 'static const char *%s =' % VAR
if text.count(anchor) != 1:
    sys.stderr.write('%s 出现 %d 次\n' % (anchor, text.count(anchor)))
    sys.exit(1)
s = text.index(anchor)
print('锚点在字节', s)

for pat in ('\\n";', '";', '";\r\n', '\n";'):
    i = text.find(pat, s)
    print('  找 %-8r -> %s' % (pat, ('+' + str(i - s)) if i >= 0 else '没找到'))

# 打印块末尾 200 字节的真实内容
j = text.find('\\n";', s)
if j < 0:
    j = text.find('";', s)
tail = text[max(s, j - 200):j + 40]
print('\n块末尾原始内容（repr，看得出 \\r \\n 和引号）:')
print(repr(tail))
