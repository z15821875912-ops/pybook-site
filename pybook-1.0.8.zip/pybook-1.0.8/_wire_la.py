# _wire_la.py — 把 linalg 的 23 个入口接进三个文件（手工改 69 处太容易漏）
#   pybk_front.py   LIB_CALLS（名字 -> 参数个数）
#   pybk_code.py    LIB_C_NAMES（名字 -> C 函数名）
#   _vm_lib_calls.inc  前置声明 + 分发表
import io, re

# (前端名, 参数个数, C 函数名)
ENTRIES = [
    ('tb.lu',        1, 'rt_lib_tb_lu'),
    ('tb.solve',     2, 'rt_lib_tb_solve'),
    ('tb.det',       1, 'rt_lib_tb_det'),
    ('tb.logdet',    1, 'rt_lib_tb_logdet'),
    ('tb.inv',       1, 'rt_lib_tb_inv'),
    ('tb.cond',      1, 'rt_lib_tb_cond'),
    ('tb.rank',      1, 'rt_lib_tb_rank'),
    ('tb.qr',        1, 'rt_lib_tb_qr'),
    ('tb.lstsq',     2, 'rt_lib_tb_lstsq'),
    ('tb.cholesky',  1, 'rt_lib_tb_cholesky'),
    ('tb.eig_sym',   1, 'rt_lib_tb_eig_sym'),
    ('tb.svd',       1, 'rt_lib_tb_svd'),
    ('mp.mat_lu',       2, 'rt_lib_mp_mat_lu'),
    ('mp.mat_solve',    3, 'rt_lib_mp_mat_solve'),
    ('mp.mat_qr',       3, 'rt_lib_mp_mat_qr'),
    ('mp.mat_svd',      3, 'rt_lib_mp_mat_svd'),
    ('mp.mat_eig_sym',  2, 'rt_lib_mp_mat_eig_sym'),
    ('mp.mat_cholesky', 2, 'rt_lib_mp_mat_cholesky'),
    ('mp.mat_ls',       4, 'rt_lib_mp_mat_ls'),
    ('mp.mat_rank',     2, 'rt_lib_mp_mat_rank'),
    ('mp.mat_cond',     2, 'rt_lib_mp_mat_cond'),
    ('mp.mat_logdet',   2, 'rt_lib_mp_mat_logdet'),
    ('mp.to_tensor',    3, 'rt_lib_mp_to_tensor'),
]


def rd(p):
    return io.open(p, encoding='utf-8', newline='').read()


def wr(p, t):
    io.open(p, 'w', encoding='utf-8', newline='').write(t)


def ins_after(text, anchor, block, path):
    if block.strip().split('\n')[0].strip() in text:
        print('  %s: 已存在，跳过' % path)
        return text
    i = text.index(anchor)
    j = i + len(anchor)
    return text[:j] + block + text[j:]


# ---------- 1. pybk_front.py : LIB_CALLS ----------
p = 'pybk_front.py'
t = rd(p)
tb_blk = ("\n    # ---- 线性代数（核心在 pybook_la.c，与 NumPy.linalg 对照到 2e-14）----\n"
          + ''.join("    '%s': %d,\n" % (n, a) for n, a, _ in ENTRIES if n.startswith('tb.')))
t = ins_after(t, "    'tb.shuffle': 2, 'tb.onehot': 2, 'tb.batch': 3,\n", tb_blk, p + ' LIB_CALLS')

mp_blk = ("\n    # ---- 线性代数的扁平列表面（内部先包成张量再算，与 tb.* 同一份实现）----\n"
          + ''.join("    '%s': %d,\n" % (n, a) for n, a, _ in ENTRIES if n.startswith('mp.')))
t = ins_after(t, "    'mp.vec_add': 2, 'mp.vec_sub': 2, 'mp.vec_scale': 2, 'mp.vec_dot': 2,\n",
              mp_blk, p + ' LIB_CALLS')
wr(p, t)
print('pybk_front.py 已接线')

# ---------- 2. pybk_code.py : LIB_C_NAMES ----------
p = 'pybk_code.py'
t = rd(p)
c_blk = ("        # 线性代数（pybook_la.c）\n"
         + ''.join("        '%s': '%s',\n" % (n, c) for n, _, c in ENTRIES))
t = ins_after(t, "        'tb.dot': 'rt_tb_dot', 'tb.tr': 'rt_tb_tr',\n", c_blk, p + ' LIB_C_NAMES')
wr(p, t)
print('pybk_code.py 已接线')

# ---------- 3. _vm_lib_calls.inc ----------
p = '_vm_lib_calls.inc'
t = rd(p)
eol = '\r\n' if '\r\n' in t else '\n'
E = eol

decls = ''.join('Value %s(%s);%s' % (c, ', '.join(['Value'] * a), E) for _, a, c in ENTRIES)
t = ins_after(t, 'Value rt_lib_mp_vec_sub(Value, Value);' + E, decls, p + ' decls')
rows = ''.join('    {"%s", %d, (void *)%s},%s' % (n, a, c, E) for n, a, c in ENTRIES)
t = ins_after(t, '    {"mp.vec_sub", 2, (void *)rt_lib_mp_vec_sub},' + E, rows, p + ' table')
wr(p, t)
print('_vm_lib_calls.inc 已接线（行尾 %s）' % ('CRLF' if eol == '\r\n' else 'LF'))
print('共 %d 个入口' % len(ENTRIES))