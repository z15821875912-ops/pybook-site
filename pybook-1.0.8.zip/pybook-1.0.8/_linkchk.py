# -*- coding: utf-8 -*-
"""_linkchk.py — 真实链接一次，拿到确切的 undefined reference 清单。
比正则扫源码可靠：正则会漏掉跨行签名 / static inline / 宏。"""
import re
import subprocess
import sys

GCC = r'C:\Users\zhuli\mingw64\bin\x86_64-w64-mingw32-gcc.exe'
SRCS = ['pyvm.c', 'pybook_rt.c', 'pybook_lib.c', 'pybook_file.c', 'pybook_music.c',
        'pybook_net.c', 'pybook_np.c', 'pybook_tb.c', 'pybook_mt.c', 'pybook_json.c',
        'pybook_csv.c', 'pybook_mm.c', 'mathplus.c', 'pybook_bits.c',
        'pybook_smoke.c', 'pybook_obj.c', 'pybook_wire.c', 'pybook_gpu.c', 'pybook_la.c']
LIBS = ['-lwinmm', '-lws2_32', '-lwininet', '-lm']

r = subprocess.run([GCC, '-O1', '-march=native', '-I.', '-DMP_RT_BINDING',
                    '-DLA_RT_BINDING'] + SRCS + ['-o', 'NUL'] + LIBS,
                   capture_output=True, text=True, errors='replace')
err = r.stderr or ''
undef = sorted(set(re.findall(r"undefined reference to `(\w+)'", err)))
print('链接退出码 %d' % r.returncode)
if not undef:
    print('没有 undefined reference —— 之前的正则审计有误报')
    if err.strip():
        print('（但有其他输出）\n' + err[:1500])
    sys.exit(0)

print('undefined reference 共 %d 个：\n' % len(undef))
byp = {}
for u in undef:
    k = 'rt_lib_' if u.startswith('rt_lib_') else (
        'rt_tensor' if u.startswith('rt_tensor') else (
            'rt_tb' if u.startswith('rt_tb') else '其他'))
    byp.setdefault(k, []).append(u)
for k in sorted(byp):
    print('  %-10s %d 个' % (k, len(byp[k])))
print()
for u in undef:
    print('  ' + u)
