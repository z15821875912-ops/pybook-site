# -*- coding: utf-8 -*-
"""_fffdcmp.py — 对比快照与当前：U+FFFD 是我重放引入的，还是本来就有。
（用字节串找，避免字面量在写文件时被吞）"""
import io
import os

BAD = b'\xef\xbf\xbd'
SNAP = 'build_tmp/_prerepair_2040'


def scan(path):
    raw = open(path, 'rb').read()
    try:
        t = raw.decode('utf-8')
    except UnicodeDecodeError:
        t = raw.decode('utf-8', 'replace')
    hits = []
    for i, line in enumerate(t.splitlines(), 1):
        if b'\xef\xbf\xbd' in line.encode('utf-8', 'replace'):
            hits.append((i, line.strip()[:90]))
    return raw.count(BAD), hits


for name in ('mathplus.c', 'pybook_lib.c'):
    cur = os.path.join('.', name)
    snap = os.path.join(SNAP, name)
    n1, h1 = scan(snap)
    n2, h2 = scan(cur)
    print('%s  快照 %d 处 -> 现在 %d 处' % (name, n1, n2))
    for i, l in h1:
        print('   [快照] 第 %d 行: %s' % (i, l))
    for i, l in h2:
        print('   [现在] 第 %d 行: %s' % (i, l))
    print()
