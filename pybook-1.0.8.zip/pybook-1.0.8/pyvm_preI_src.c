/* PYbook 字节码虚拟机（.pybc 栈式虚拟机）。
 *
 * 文件格式（与编译器同事的合同，多字节整数一律小端）：
 *   [0..3]='PYBC'；[4..7] u32 版本=1；[8..11] u32 常量数 N；[12..15] u32 函数数 F；
 *   常量池 N 项：u8 类型(1=int64, 2=float64, 3=字符串) + 内容；
 *   函数表 F 项（函数 0 = 主程序）：u32 名字常量索引 + u16 参数个数 + u16 槽位总数
 *   + u32 代码偏移 + u32 代码字节数；代码区紧随，代码偏移相对代码区起点（不是相对文件头）。
 *
 * 结构：全局 Value 操作数栈（初始 4096，满则翻倍 realloc）+ 帧栈
 *（帧 = 返回 ip + 函数索引 + 槽位数组；槽 = 参数按序 + 其余 rt_none() 填充）。
 * 值语义全部委托 pybook_rt.h：rt_add/rt_cond/rt_show_value/rt_input/rt_index/...
 * 本文件只做取指、译码、栈与帧管理、越界与格式校验。
 *
 * 编译：gcc -O2 pyvm.c pybook_rt.c -o pyvm.exe
 * 运行：pyvm.exe 文件.pybc
 * 自测：gcc -O2 -march=native -DPYVM_SELF_TEST -I. pyvm.c pybook_rt.c pybook_lib.c
 *       pybook_csv.c pybook_json.c pybook_file.c pybook_mt.c pybook_gpu.c pybook_mm.c
 *       pybook_obj.c pybook_wire.c pybook_np.c pybook_tb.c pybook_bits.c pybook_smoke.c
 *       pybook_music.c -DMP_RT_BINDING mathplus.c -o pyvm_test.exe -lwinmm -lm
 *       && ./pyvm_test
 * （-march=native 不可省：pybook_tb.c 的 AVX2 矩阵乘微内核；库文件不可省：
 *   _vm_lib_calls.inc 的库调用表引用全部 rt_* 符号）
 *   自测 main 会手工拼 4 个字节码模块：42 演示、循环+调用+列表综合、
 *   锁定/删除报错（子进程验证退出码）；参数 "dump" 把样例写成 .pybc 文件，
 *   参数 "child N" 供父进程拉起验证报错分支。
 */

#include <math.h>
#include <stdarg.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "pybook_rt.h"
#include "pybook_lib.h"

/* 标准库调用表（由 LIB_CALLS + LIB_C_NAMES 生成）：name/arity/fn 三元组。
 * CALL_LIB 指令按名字在此查表，按 arity 弹参调用。*/
Value rt_csv_dump(Value); Value rt_csv_parse(Value);
Value rt_js_dump(Value); Value rt_js_parse(Value);
Value rt_safe_get(Value, Value, Value); Value rt_safe_at(Value, Value, Value);
#include "_vm_lib_calls.inc"

_Static_assert(sizeof(double) == 8 && sizeof(long long) == 8, "需要 64 位 double/int64");

/* ================= 错误出口 ================= */

/* 虚拟机自身 / 字节码的问题 */
static void vm_die(const char *fmt, ...)
{
    va_list ap;
    fprintf(stderr, "虚拟机错误: ");
    va_start(ap, fmt);
    vfprintf(stderr, fmt, ap);
    va_end(ap);
    fputc('\n', stderr);
    exit(1);
}

/* 用户程序层面的问题（VM 代替 rt 报的少数几处），保持同一消息风格 */
static void prog_die(const char *fmt, ...)
{
    va_list ap;
    fprintf(stderr, "运行时错误: ");
    va_start(ap, fmt);
    vfprintf(stderr, fmt, ap);
    va_end(ap);
    fputc('\n', stderr);
    exit(1);
}

/* ================= 文件读取与小端解码 ================= */

static uint8_t *read_file(const char *path, size_t *out_len)
{
    FILE *fp = fopen(path, "rb");
    if (!fp)
        return NULL;
    if (fseek(fp, 0, SEEK_END) != 0) {
        fclose(fp);
        return NULL;
    }
    long size = ftell(fp);
    if (size < 0 || fseek(fp, 0, SEEK_SET) != 0) {
        fclose(fp);
        return NULL;
    }
    uint8_t *buf = (uint8_t *)malloc(size ? (size_t)size : 1);
    if (!buf) {
        fclose(fp);
        vm_die("内存不足");
    }
    if (size > 0 && fread(buf, 1, (size_t)size, fp) != (size_t)size) {
        fclose(fp);
        free(buf);
        return NULL;
    }
    fclose(fp);
    *out_len = (size_t)size;
    return buf;
}

/* 带边界检查的顺序解码器 */
typedef struct {
    const uint8_t *p;
    const uint8_t *end;
} Reader;

static const uint8_t *take(Reader *r, size_t n)
{
    if ((size_t)(r->end - r->p) < n)
        vm_die("文件格式错误：数据截断");
    const uint8_t *q = r->p;
    r->p += n;
    return q;
}

static uint8_t rd_u8(Reader *r) { return take(r, 1)[0]; }

static uint16_t rd_u16(Reader *r)
{
    const uint8_t *q = take(r, 2);
    return (uint16_t)(q[0] | (uint16_t)q[1] << 8);
}

static uint32_t rd_u32(Reader *r)
{
    const uint8_t *q = take(r, 4);
    return (uint32_t)q[0] | (uint32_t)q[1] << 8 | (uint32_t)q[2] << 16 | (uint32_t)q[3] << 24;
}

static uint64_t rd_u64(Reader *r)
{
    const uint8_t *q = take(r, 8);
    uint64_t v = 0;
    for (int i = 7; i >= 0; i--)
        v = v << 8 | q[i];
    return v;
}

/* ================= 模块加载 ================= */

typedef struct {
    uint32_t name_idx;
    uint16_t nparams;
    uint16_t nslots;
    uint32_t code_off;
    uint32_t code_len;
    void *jit_ptr;      /* JIT 原生函数指针（NULL=未编译）；仅 --jit 使用 */
    uint32_t hot;       /* 调用热计数 */
    uint8_t  jit_state; /* 0=未尝试 1=已编译 2=不可编译/失败 */
} Fn;

typedef struct {
    Value *consts;
    uint32_t nconsts;
    Fn *fns;
    uint32_t nfns;
    uint32_t code_base;   /* 代码区起点（绝对偏移） */
} Module;

static Module load_module(const uint8_t *img, size_t len)
{
    Module m;
    memset(&m, 0, sizeof m);
    if (len < 16)
        vm_die("文件格式错误：文件太短");
    if (memcmp(img, "PYBC", 4) != 0)
        vm_die("文件格式错误：魔数不是 'PYBC'");
    Reader r = { img + 4, img + len };
    if (rd_u32(&r) != 1)
        vm_die("文件格式错误：只支持版本 1");
    uint32_t n = rd_u32(&r);
    uint32_t f = rd_u32(&r);

    m.nconsts = n;
    m.consts = (Value *)calloc(n ? n : 1, sizeof(Value));
    if (!m.consts)
        vm_die("内存不足");
    for (uint32_t i = 0; i < n; i++) {
        uint8_t tag = rd_u8(&r);
        switch (tag) {
        case 1: {   /* int64 */
            int64_t v = (int64_t)rd_u64(&r);
            m.consts[i] = rt_int(v);
            break;
        }
        case 2: {   /* float64 */
            uint64_t bits = rd_u64(&r);
            double d;
            memcpy(&d, &bits, sizeof d);
            m.consts[i] = rt_float(d);
            break;
        }
        case 3: {   /* 字符串：u32 字节数 + UTF-8 */
            uint32_t blen = rd_u32(&r);
            const uint8_t *bytes = take(&r, blen);
            char *s = (char *)malloc((size_t)blen + 1);
            if (!s)
                vm_die("内存不足");
            memcpy(s, bytes, blen);
            s[blen] = '\0';
            m.consts[i] = rt_str(s);   /* rt_str 自会拷贝进运行时内存 */
            free(s);
            break;
        }
        default:
            vm_die("文件格式错误：未知常量类型 %u", (unsigned)tag);
        }
    }

    if (f == 0)
        vm_die("文件格式错误：函数表为空（缺少主程序）");
    m.nfns = f;
    m.fns = (Fn *)calloc(f, sizeof(Fn));
    if (!m.fns)
        vm_die("内存不足");
    for (uint32_t i = 0; i < f; i++) {
        Fn *fn = &m.fns[i];
        fn->name_idx = rd_u32(&r);
        fn->nparams = rd_u16(&r);
        fn->nslots = rd_u16(&r);
        fn->code_off = rd_u32(&r);
        fn->code_len = rd_u32(&r);
        if (fn->name_idx >= n)
            vm_die("文件格式错误：函数 %u 名字常量索引越界", (unsigned)i);
        if (fn->nparams > fn->nslots)
            vm_die("文件格式错误：函数 %u 槽位数少于参数个数", (unsigned)i);
        if ((uint64_t)fn->code_off + fn->code_len > len)
            vm_die("文件格式错误：函数 %u 代码区间越界", (unsigned)i);
    }
    m.code_base = (uint32_t)(r.p - img);   /* 函数表结束处即代码区起点 */
    return m;
}

#ifndef PYVM_SELF_TEST
/* ---- JIT（C 后端，--jit 启用）前向声明 ---- */
typedef Value (*JitFn)(Value *, int);
static int g_jit_enable = 0;
static uint32_t g_jit_threshold = 200;
static int g_jit_src = 0;      /* 开关来源（优先级递增）：0=默认关 1=环境变量 2=命令行 3=文件头 */

/* 文件头 jit 指令（opcode 0x38）落地：优先级最高，盖过命令行与环境变量。
 * 在主程序第一条语句执行，早于任何 CALL——JIT 触发挂在 CALL 上，时序稳。 */
static void jit_set(int on, int threshold){
    g_jit_enable = on ? 1 : 0;
    if (on && threshold > 0) g_jit_threshold = (uint32_t)threshold;
    g_jit_src = 3;
}
static int g_jit_done = 0;              /* 批量编译每轮只触发一次（成败都记） */
static void jit_batch_compile(Module *m);
#endif

/* ================= 虚拟机状态 ================= */

static const uint8_t *g_img;   /* 整个 .pybc 映像（操作数直接从这里读） */
static size_t g_img_len;

/* 操作数栈：初始 4096，满了翻倍 realloc */
static Value *g_stack;
static size_t g_sp, g_cap;

/* 帧栈 */
typedef struct {
    uint32_t ip;       /* 当前指令指针（相对整个映像） */
    uint32_t ret_ip;   /* 返回到的 ip */
    uint32_t fn;       /* 当前函数索引 */
    Value *slots;      /* 槽位数组：参数按序 + 其余 rt_none() 填满 */
} Frame;

static Frame *g_frames;
static size_t g_fp, g_fcap;

/* rt 的显示是行缓冲：SHOW_TEXT/SHOW_VALUE/MAGIC 只追加到当前行，SHOW_END 才输出。
 * VM 记录"有未结束的行"，正常停机时补一次 rt_show_end 把挂起内容刷出来。 */
static int g_line_pending;

static void vm_finish(void)
{
    if (g_line_pending) {
        g_line_pending = 0;
        rt_show_end();
    }
}

static void push(Value v)
{
    if (g_sp == g_cap) {
        g_cap = g_cap ? g_cap * 2 : 4096;
        g_stack = (Value *)realloc(g_stack, g_cap * sizeof(Value));
        if (!g_stack)
            vm_die("内存不足");
    }
    g_stack[g_sp++] = v;
}

static Value pop(void)
{
    if (g_sp == 0)
        vm_die("操作数栈下溢（字节码不平衡）");
    return g_stack[--g_sp];
}

/* ---- 操作数读取（相对整个映像做边界检查） ---- */

static uint8_t rd_ip_u8(uint32_t *ip)
{
    if ((uint64_t)*ip + 1 > g_img_len)
        vm_die("指令流截断");
    return g_img[(*ip)++];
}

static uint16_t rd_ip_u16(uint32_t *ip)
{
    if ((uint64_t)*ip + 2 > g_img_len)
        vm_die("指令流截断");
    uint16_t v = (uint16_t)(g_img[*ip] | (uint16_t)g_img[*ip + 1] << 8);
    *ip += 2;
    return v;
}

static uint32_t rd_ip_u32(uint32_t *ip)
{
    if ((uint64_t)*ip + 4 > g_img_len)
        vm_die("指令流截断");
    uint32_t v = (uint32_t)g_img[*ip] | (uint32_t)g_img[*ip + 1] << 8
               | (uint32_t)g_img[*ip + 2] << 16 | (uint32_t)g_img[*ip + 3] << 24;
    *ip += 4;
    return v;
}

/* ---- 常量/槽位取用（带校验） ---- */

static Value const_at(const Module *m, uint16_t idx)
{
    if (idx >= m->nconsts)
        vm_die("常量索引 %u 越界", (unsigned)idx);
    return m->consts[idx];
}

static const char *str_const(const Module *m, uint16_t idx)
{
    Value v = const_at(m, idx);
    if (!IS_STR(v))
        vm_die("常量 %u 不是字符串", (unsigned)idx);
    return AS_STR(v);
}

static Value *slot_ref(Frame *f, const Fn *fn, uint16_t s)
{
    if (s >= fn->nslots)
        vm_die("槽位索引 %u 越界（函数只有 %u 个槽）", (unsigned)s, (unsigned)fn->nslots);
    return &f->slots[s];
}

/* AROUND_INIT 的次数校验：INT/BOOL 可，FLOAT 须整数值 */
static long long loop_count_of(Value v)
{
    if (IS_INT(v) || IS_BIGINT(v))
        return rt_to_ll(v);
    if (IS_BOOL(v))
        return (long long)AS_BOOL(v);
    if (IS_FLT(v)) {
        double fv = AS_FLT(v);
        if (fv >= -(double)LLONG_MAX && fv <= (double)LLONG_MAX && fv == floor(fv))
            return (long long)fv;
    }
    prog_die("循环次数必须是整数");
    return 0;   /* 不可达 */
}

/* 跳转偏移相对下一条指令处（from = 已读完操作数的 ip）；越界直接报错。
 * 注意：偏移必须先读进局部变量再算目标，禁止 "f->ip + rd_ip_u32(&f->ip)"
 * 这种同一表达式读又改 f->ip 的写法——那是未定义行为。 */
static uint32_t jump_target(const Module *m, const Fn *fn, uint32_t fn_idx, uint32_t from, int32_t off)
{
    uint32_t t = from + (uint32_t)off;   /* 利用无符号回绕实现负偏移 */
    if (t < m->code_base + fn->code_off || t >= (uint64_t)m->code_base + fn->code_off + fn->code_len)
        vm_die("跳转目标越界（函数 %u）", (unsigned)fn_idx);
    return t;
}

/* 二元算术/比较的公共小助手：弹 b 弹 a，压 op(a,b) */
static Value pop2_apply(Value (*op)(Value, Value))
{
    Value b = pop();
    Value a = pop();
    return op(a, b);
}

/* ================= 执行主循环 ================= */

/* ================= 标准库调用（CALL_LIB） ================= */

typedef Value (*LibFn0)(void);
typedef Value (*LibFn1)(Value);
typedef Value (*LibFn2)(Value, Value);
typedef Value (*LibFn3)(Value, Value, Value);
typedef Value (*LibFn4)(Value, Value, Value, Value);
typedef Value (*LibFn5)(Value, Value, Value, Value, Value);
typedef Value (*LibFn6)(Value, Value, Value, Value, Value, Value);
typedef Value (*LibFn7)(Value, Value, Value, Value, Value, Value, Value);
typedef Value (*LibFn8)(Value, Value, Value, Value, Value, Value, Value, Value);

/* 按名字查库调用；找不到返回 NULL */
static void *lib_lookup(const char *name, int *arity_out)
{
    size_t n = sizeof(g_lib_calls) / sizeof(g_lib_calls[0]);
    for (size_t i = 0; i < n; i++) {
        if (strcmp(g_lib_calls[i].name, name) == 0) {
            *arity_out = g_lib_calls[i].arity;
            return g_lib_calls[i].fn;
        }
    }
    return NULL;
}

/* 按 arity 弹实参并调用；返回值压栈。栈上实参按书写序（末参在顶）。 */
static void lib_invoke(const char *name, void *fn, int arity)
{
    Value a0=rt_none(),a1=rt_none(),a2=rt_none(),a3=rt_none();
    Value a4=rt_none(),a5=rt_none(),a6=rt_none(),a7=rt_none();
    if (arity > 8 || arity < 0)
        vm_die("库 %s 的参数个数 %d 不受支持", name, arity);
    if (g_sp < (size_t)arity)
        vm_die("操作数栈下溢（调用库 %s）", name);
    switch (arity) {
    case 8: a7 = pop(); /* fallthrough */
    case 7: a6 = pop(); /* fallthrough */
    case 6: a5 = pop(); /* fallthrough */
    case 5: a4 = pop(); /* fallthrough */
    case 4: a3 = pop(); /* fallthrough */
    case 3: a2 = pop(); /* fallthrough */
    case 2: a1 = pop(); /* fallthrough */
    case 1: a0 = pop(); /* fallthrough */
    case 0: break;
    }
    Value r;
    switch (arity) {
    case 0: r = ((LibFn0)fn)(); break;
    case 1: r = ((LibFn1)fn)(a0); break;
    case 2: r = ((LibFn2)fn)(a0, a1); break;
    case 3: r = ((LibFn3)fn)(a0, a1, a2); break;
    case 4: r = ((LibFn4)fn)(a0, a1, a2, a3); break;
    case 5: r = ((LibFn5)fn)(a0, a1, a2, a3, a4); break;
    case 6: r = ((LibFn6)fn)(a0, a1, a2, a3, a4, a5); break;
    case 7: r = ((LibFn7)fn)(a0, a1, a2, a3, a4, a5, a6); break;
    default: r = ((LibFn8)fn)(a0, a1, a2, a3, a4, a5, a6, a7); break;
    }
    push(r);
}

static void run_module(const uint8_t *img, size_t len)
{
    /* 每次运行都重置虚拟机状态（自测会连续跑多个模块） */
    g_img = img;
    g_img_len = len;
    g_sp = 0;
    g_fp = 0;
    g_line_pending = 0;

    Module m = load_module(img, len);
    if (m.fns[0].nparams != 0)
        vm_die("主程序（函数 0）不能有参数");

    /* 槽位数组：参数按序 + 其余 rt_none() 填充到槽位总数 */
    Frame f0;
    f0.ip = m.code_base + m.fns[0].code_off;
    f0.ret_ip = 0;
    f0.fn = 0;
    f0.slots = (Value *)malloc((m.fns[0].nslots ? m.fns[0].nslots : 1) * sizeof(Value));
    if (!f0.slots)
        vm_die("内存不足");
    for (uint16_t i = 0; i < m.fns[0].nslots; i++)
        f0.slots[i] = rt_none();

    g_fcap = 256;
    g_frames = (Frame *)malloc(g_fcap * sizeof(Frame));
    if (!g_frames)
        vm_die("内存不足");
    static int g_trace_on = -1;
    #define VM_SET_FRAME() do { \
        f = &g_frames[g_fp - 1]; \
        fn = &m.fns[f->fn]; \
    } while (0)
    #define VM_NEXT() do { \
        if (f->ip < m.code_base + fn->code_off || \
            f->ip >= (uint64_t)m.code_base + fn->code_off + fn->code_len) \
            vm_die("程序计数器越界（函数 %u）", (unsigned)f->fn); \
        op = g_img[f->ip++]; \
        if (g_trace_on) fprintf(stderr, "[trace] fn=%u ip=%u op=%02X sp=%zu fp=%zu\n", \
                (unsigned)f->fn, (unsigned)(f->ip - 1), (unsigned)op, g_sp, g_fp); \
        goto *dispatch_table[op]; \
    } while (0)

    g_frames[g_fp++] = f0;

    /* 真·threaded dispatch / computed goto：帧指针 f/fn 跨派发存活，
       只在 CALL/RET/RET_NONE 换帧时重载；每个处理末尾 VM_NEXT() 直接 goto 下一条指令。
       VM_NEXT 顺手做 PC 越界检查（保留原 switch 每轮重算帧的安全语义）。*/
    static void *dispatch_table[256];
    static int dt_inited = 0;

        if (g_fp == 0) {
            vm_finish();   /* 主程序 RET/RET_NONE：正常结束 */
            return;
        }

        Frame *f;
        const Fn *fn;
        uint8_t op = 0;

    if (g_trace_on < 0) g_trace_on = getenv("PYVM_TRACE") ? 1 : 0;
    if (!dt_inited) {
        for (int di = 0; di < 256; di++) dispatch_table[di] = &&case_default;
        dispatch_table[0x00] = &&case_0x00;
        dispatch_table[0x01] = &&case_0x01;
        dispatch_table[0x02] = &&case_0x02;
        dispatch_table[0x03] = &&case_0x03;
        dispatch_table[0x04] = &&case_0x04;
        dispatch_table[0x05] = &&case_0x05;
        dispatch_table[0x06] = &&case_0x06;
        dispatch_table[0x10] = &&case_0x10;
        dispatch_table[0x11] = &&case_0x11;
        dispatch_table[0x12] = &&case_0x12;
        dispatch_table[0x13] = &&case_0x13;
        dispatch_table[0x14] = &&case_0x14;
        dispatch_table[0x15] = &&case_0x15;
        dispatch_table[0x16] = &&case_0x16;
        dispatch_table[0x17] = &&case_0x17;
        dispatch_table[0x18] = &&case_0x18;
        dispatch_table[0x19] = &&case_0x19;
        dispatch_table[0x1A] = &&case_0x1A;
        dispatch_table[0x1B] = &&case_0x1B;
        dispatch_table[0x1C] = &&case_0x1C;
        dispatch_table[0x1D] = &&case_0x1D;
        dispatch_table[0x1E] = &&case_0x1E;
        dispatch_table[0x1F] = &&case_0x1F;
        dispatch_table[0x20] = &&case_0x20;
        dispatch_table[0x21] = &&case_0x21;
        dispatch_table[0x22] = &&case_0x22;
        dispatch_table[0x23] = &&case_0x23;
        dispatch_table[0x24] = &&case_0x24;
        dispatch_table[0x25] = &&case_0x25;
        dispatch_table[0x26] = &&case_0x26;
        dispatch_table[0x27] = &&case_0x27;
        dispatch_table[0x28] = &&case_0x28;
        dispatch_table[0x29] = &&case_0x29;
        dispatch_table[0x2A] = &&case_0x2A;
        dispatch_table[0x2D] = &&case_0x2D;
        dispatch_table[0x2E] = &&case_0x2E;
        dispatch_table[0x2B] = &&case_0x2B;
        dispatch_table[0x2C] = &&case_0x2C;
        dispatch_table[0x30] = &&case_0x30;
        dispatch_table[0x31] = &&case_0x31;
        dispatch_table[0x32] = &&case_0x32;
        dispatch_table[0x33] = &&case_0x33;
        dispatch_table[0x34] = &&case_0x34;
        dispatch_table[0x35] = &&case_0x35;
        dispatch_table[0x36] = &&case_0x36;
        dispatch_table[0x37] = &&case_0x37;
        dispatch_table[0x38] = &&case_0x38;
        dt_inited = 1;
    }
    VM_SET_FRAME();
    VM_NEXT();
        case_0x00:   /* NOP */
            VM_NEXT();
        case_0x01:   /* HALT：正常退出 */
            vm_finish();
            return;

        case_0x02:   /* CONST u16 */
            push(const_at(&m, rd_ip_u16(&f->ip)));
            VM_NEXT();
        case_0x03:   /* LOAD u16：槽读（已删除报错走 rt_chk） */
            push(rt_chk(*slot_ref(f, fn, rd_ip_u16(&f->ip))));
            VM_NEXT();
        case_0x04: { /* STORE u16：弹出写槽（锁定/删除检查走 rt_assign） */
            uint16_t s = rd_ip_u16(&f->ip);
            Value v = pop();
            rt_assign(slot_ref(f, fn, s), v);
            VM_NEXT();
        }
        case_0x05:   /* DUP */
            if (g_sp == 0)
                vm_die("操作数栈下溢（DUP）");
            push(g_stack[g_sp - 1]);
            VM_NEXT();
        case_0x06:   /* POP */
            (void)pop();
            VM_NEXT();

        case_0x10: push(pop2_apply(rt_add));  VM_NEXT();   /* ADD  */
        case_0x11: push(pop2_apply(rt_sub));  VM_NEXT();   /* SUB  */
        case_0x12: push(pop2_apply(rt_mul));  VM_NEXT();   /* MUL  */
        case_0x13: push(pop2_apply(rt_div));  VM_NEXT();   /* DIV  */
        case_0x14: push(pop2_apply(rt_fdiv)); VM_NEXT();   /* FDIV */
        case_0x15: push(pop2_apply(rt_mod));  VM_NEXT();   /* MOD  */
        case_0x16:   /* NEG */
            push(rt_neg(pop()));
            VM_NEXT();
        case_0x17:   /* NOT */
            push(rt_not(pop()));
            VM_NEXT();

        case_0x18: push(pop2_apply(rt_eq)); VM_NEXT();   /* EQ */
        case_0x19: push(pop2_apply(rt_ne)); VM_NEXT();   /* NE */
        case_0x1A: push(pop2_apply(rt_lt)); VM_NEXT();   /* LT */
        case_0x1B: push(pop2_apply(rt_gt)); VM_NEXT();   /* GT */
        case_0x1C: push(pop2_apply(rt_le)); VM_NEXT();   /* LE */
        case_0x1D: push(pop2_apply(rt_ge)); VM_NEXT();   /* GE */

        case_0x1E: { /* JUMP i32 */
            int32_t off = (int32_t)rd_ip_u32(&f->ip);
            f->ip = jump_target(&m, fn, f->fn, f->ip, off);
            VM_NEXT();
        }
        case_0x1F: { /* JUMP_IF_FALSE i32：弹条件，假跳 */
            int32_t off = (int32_t)rd_ip_u32(&f->ip);
            if (!rt_cond(pop()))
                f->ip = jump_target(&m, fn, f->fn, f->ip, off);
            VM_NEXT();
        }
        case_0x20: { /* JUMP_IF_TRUE i32：弹条件，真跳 */
            int32_t off = (int32_t)rd_ip_u32(&f->ip);
            if (rt_cond(pop()))
                f->ip = jump_target(&m, fn, f->fn, f->ip, off);
            VM_NEXT();
        }

        case_0x21:   /* SHOW_TEXT u16 */
            rt_show_text(str_const(&m, rd_ip_u16(&f->ip)));
            g_line_pending = 1;
            VM_NEXT();
        case_0x22:   /* SHOW_VALUE：弹一显示 */
            (void)rt_show_value(pop());
            g_line_pending = 1;
            VM_NEXT();
        case_0x23:   /* MAGIC u16 */
            rt_magic(str_const(&m, rd_ip_u16(&f->ip)));
            g_line_pending = 1;
            VM_NEXT();
        case_0x24:   /* SHOW_END */
            rt_show_end();
            g_line_pending = 0;
            VM_NEXT();

        case_0x25:   /* LIST_NEW */
            push(rt_list_new());
            VM_NEXT();
        case_0x26: { /* LIST_APPEND：栈 [...,表,值] → [...,表] */
            Value v = pop();
            if (g_sp == 0)
                vm_die("操作数栈下溢（LIST_APPEND）");
            (void)rt_push(&g_stack[g_sp - 1], v);
            VM_NEXT();
        }
        case_0x27:   /* LEN */
            push(rt_len(pop()));
            VM_NEXT();
        case_0x28: { /* INDEX：弹 idx 弹 base，压 rt_index(base, idx) */
            Value idx = pop();
            Value base = pop();
            push(rt_index(base, idx));
            VM_NEXT();
        }
        case_0x29: { /* SETIDX：弹 v 弹 idx 弹 base */
            Value v = pop();
            Value idx = pop();
            Value base = pop();
            rt_setindex(&base, idx, v);
            VM_NEXT();
        }

        case_0x2A:   /* INPUT u16 */
            push(rt_input(str_const(&m, rd_ip_u16(&f->ip))));
            VM_NEXT();

        case_0x2D:   /* DICT_NEW：压空字典 */
            push(rt_dict_new());
            VM_NEXT();
        case_0x2E: { /* DICT_SET：栈 [...,字典,键,值] → [...,字典] */
            Value v = pop();
            Value k = pop();
            if (g_sp == 0)
                vm_die("操作数栈下溢（DICT_SET）");
            (void)rt_dict_set(&g_stack[g_sp - 1], k, v);
            VM_NEXT();
        }

        case_0x2B: { /* AROUND_INIT u16 u16（at槽,次数槽）：弹次数校验整数 */
            uint16_t at = rd_ip_u16(&f->ip);
            uint16_t cnt = rd_ip_u16(&f->ip);
            long long count = loop_count_of(pop());
            (void)slot_ref(f, fn, at);   /* 越界校验 */
            (void)slot_ref(f, fn, cnt);
            f->slots[at] = rt_int(0);
            f->slots[cnt] = rt_int(count);
            VM_NEXT();
        }
        case_0x2C: { /* AROUND_STEP u16 u16 i32（at槽,次数槽,回跳） */
            uint16_t at = rd_ip_u16(&f->ip);
            uint16_t cnt = rd_ip_u16(&f->ip);
            int32_t off = (int32_t)rd_ip_u32(&f->ip);
            Value *at_s = slot_ref(f, fn, at);
            Value *cnt_s = slot_ref(f, fn, cnt);
            if (!(IS_INT(*at_s) || IS_BIGINT(*at_s)) || !(IS_INT(*cnt_s) || IS_BIGINT(*cnt_s)))
                vm_die("AROUND 槽被非整数破坏");
            long long next = rt_to_ll(*at_s) + 1;
            *at_s = rt_int(next);
            if (next < rt_to_ll(*cnt_s))
                f->ip = jump_target(&m, fn, f->fn, f->ip, off);
            VM_NEXT();
        }

        case_0x30: { /* CALL u16 u8（函数索引, 参数个数）：实参按书写序压栈 */
            uint16_t fni = rd_ip_u16(&f->ip);
            uint8_t nargs = rd_ip_u8(&f->ip);
            if (fni >= m.nfns)
                vm_die("函数索引 %u 越界", (unsigned)fni);
            Fn *callee = &m.fns[fni];
            if (nargs != callee->nparams)
                vm_die("函数 %u 需要 %u 个参数，实际 %u 个",
                       (unsigned)fni, (unsigned)callee->nparams, (unsigned)nargs);
#ifndef PYVM_SELF_TEST
            if (g_jit_enable) {
                callee->hot++;
                if (!g_jit_done && callee->hot >= g_jit_threshold)
                    jit_batch_compile(&m);
                if (callee->jit_ptr && callee->hot >= g_jit_threshold) {
                    Value javbuf[8];                   /* 小参数量免 malloc/free */
                    Value *jav = (nargs <= 8) ? javbuf
                              : (Value *)malloc((nargs ? nargs : 1) * sizeof(Value));
                    if (!jav) vm_die("内存不足");
                    for (uint8_t i = nargs; i > 0; i--) jav[i - 1] = pop();
                    Value rv = ((JitFn)callee->jit_ptr)(jav, nargs);
                    if (jav != javbuf) free(jav);
                    push(rv);
                    VM_NEXT();
                }
            }
#endif
            uint32_t ret_ip = f->ip;
            Value *slots = (Value *)malloc((callee->nslots ? callee->nslots : 1) * sizeof(Value));
            if (!slots)
                vm_die("内存不足");
            for (uint16_t i = nargs; i > 0; i--)
                slots[i - 1] = pop();          /* 栈顶是最后一个参数 */
            for (uint16_t i = nargs; i < callee->nslots; i++)
                slots[i] = rt_none();
            if (g_fp == g_fcap) {
                g_fcap *= 2;
                g_frames = (Frame *)realloc(g_frames, g_fcap * sizeof(Frame));
                if (!g_frames)
                    vm_die("内存不足");
            }
            Frame nf;
            nf.ip = m.code_base + callee->code_off;
            nf.ret_ip = ret_ip;
            nf.fn = fni;
            nf.slots = slots;
            g_frames[g_fp++] = nf;
            VM_SET_FRAME(); VM_NEXT();
        }
        case_0x31: { /* RET：弹返回值回调用方 */
            Value rv = pop();
            free(f->slots);
            g_fp--;
            if (g_fp == 0) {
                vm_finish();   /* 主程序返回：正常结束 */
                return;
            }
            push(rv);
            VM_SET_FRAME(); VM_NEXT();
        }
        case_0x32: { /* RET_NONE */
            free(f->slots);
            g_fp--;
            if (g_fp == 0) {
                vm_finish();
                return;
            }
            push(rt_none());
            VM_SET_FRAME(); VM_NEXT();
        }

        case_0x33:   /* GOLD u16：锁定槽（锁记在槽地址侧表，rt_gold 写） */
            rt_gold(slot_ref(f, fn, rd_ip_u16(&f->ip)));
            VM_NEXT();
        case_0x34:   /* DEL u16：删除变量（@self 模式真释放内存） */
            rt_destroy(slot_ref(f, fn, rd_ip_u16(&f->ip)));
            VM_NEXT();

        case_0x35:   /* SETMEM u8：内存管理模式（0=自动 1=手动） */
            rt_set_memmode((int)g_img[f->ip++]);
            VM_NEXT();

        case_0x36: { /* CALL_LIB u16 u8（库名常量索引, 参数个数） */
            uint16_t namei = rd_ip_u16(&f->ip);
            uint8_t nargs = rd_ip_u8(&f->ip);
            const char *name = str_const(&m, namei);
            int arity = 0;
            void *libfn = lib_lookup(name, &arity);
            if (!libfn)
                vm_die("标准库 %s 在 VM 模式下不可用", name);
            if ((int)nargs != arity)
                vm_die("标准库 %s 需要 %d 个参数，实际 %u 个", name, arity, (unsigned)nargs);
            lib_invoke(name, libfn, arity);
            VM_NEXT();
        }

        case_0x37: { /* DEVICE u8 u16：文件头 device 旋钮（后端 + 工作线程数） */
            int backend = (int)g_img[f->ip++];
            int threads = (int)rd_ip_u16(&f->ip);
            rt_device_set(backend, threads);
            VM_NEXT();
        }

        case_0x38: { /* JIT u8 u16：文件头 jit 旋钮（开/关 + 热阈，优先级最高） */
            int on  = (int)g_img[f->ip++];
            int thr = (int)rd_ip_u16(&f->ip);
#ifndef PYVM_SELF_TEST
            jit_set(on, thr);
            if (getenv("PYVM_JIT_VERBOSE"))
                fprintf(stderr, "[JIT] 文件头指令：jit %s（阈值 %u）\n",
                        on ? "on" : "off", (unsigned)g_jit_threshold);
#else
            (void)on; (void)thr;          /* 自测构建无 JIT：操作数照常消耗，动作跳过 */
#endif
            VM_NEXT();
        }

        case_default:
            vm_die("未知指令 0x%02X（ip=%u，函数 %u）",
                   (unsigned)op, (unsigned)f->ip, (unsigned)f->fn);
        VM_NEXT();

}

/* ================= 命令行 / 自测 ================= */

#ifndef PYVM_SELF_TEST

/* ================= JIT（C 后端：字节码→C 重放） ================= */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <direct.h>
#include <process.h>
#include <sys/stat.h>

typedef struct { char *b; size_t len, cap; } JStr;
/* 可增长字符串缓冲：批量文件是几十个函数拼一个 .c，旧版定长 128KB 超容时
 * 静默截断 -> 生成残 C -> gcc 报错 -> 整轮 JIT 白编。现在按需倍增。 */
static int js_reserve(JStr *s, size_t need){
    if (s->b && s->len + need + 1 <= s->cap) return 1;
    size_t nc = s->cap ? s->cap : 65536;
    while (nc < s->len + need + 1) nc *= 2;
    char *nb = (char *)realloc(s->b, nc);
    if (!nb) return 0;
    s->b = nb; s->cap = nc;
    return 1;
}
static void js_add(JStr *s, const char *fmt, ...){
    va_list ap; va_start(ap, fmt);
    int n = vsnprintf(NULL, 0, fmt, ap);
    va_end(ap);
    if (n < 0 || !js_reserve(s, (size_t)n)) return;
    va_start(ap, fmt);
    vsnprintf(s->b + s->len, s->cap - s->len, fmt, ap);
    va_end(ap);
    s->len += (size_t)n;
}
static void js_strlit(JStr *s, const char *str){
    js_add(s, "\"");
    for (const unsigned char *p = (const unsigned char*)str; *p; p++) {
        unsigned char c = *p;
        if (c == '"') js_add(s, "\\\"");
        else if (c == '\\') js_add(s, "\\\\");
        else if (c == '\n') js_add(s, "\\n");
        else if (c == '\t') js_add(s, "\\t");
        else if (c == '\r') js_add(s, "\\r");
        else if (c < 0x20) js_add(s, "\\x%02X", c);
        else js_add(s, "%c", c);
    }
    js_add(s, "\"");
}

/* 指令操作数字节数；is_jump 标记末尾 4 字节为 i32 跳转偏移 */
static int jit_op_nops(uint8_t op, int *is_jump){
    *is_jump = 0;
    switch (op) {
    case 0x00: case 0x01: case 0x05: case 0x06:
    case 0x10: case 0x11: case 0x12: case 0x13: case 0x14: case 0x15:
    case 0x16: case 0x17:
    case 0x18: case 0x19: case 0x1A: case 0x1B: case 0x1C: case 0x1D:
    case 0x22: case 0x24: case 0x25: case 0x26: case 0x27:
    case 0x28: case 0x29: case 0x2D: case 0x2E:
    case 0x31: case 0x32:
        return 0;
    case 0x02: case 0x03: case 0x04: case 0x21: case 0x23:
    case 0x2A: case 0x33: case 0x34:
        return 2;
    case 0x35:
        return 1;
    case 0x1E: case 0x1F: case 0x20:
        *is_jump = 1; return 4;
    case 0x30: case 0x36: case 0x37: case 0x38:
        return 3;
    case 0x2B:
        return 4;
    case 0x2C:
        *is_jump = 1; return 8;
    default:
        return -1;
    }
}

/* 批量文件前导：include + 循环计数助手 + 栈宏容量（整个文件只写一次）。 */
/* 一个模块用到的不同标准库函数个数上限（够用：整表 351 条，单程序远到不了） */
#define JIT_MAXLIB 64
static char *jit_strdup(const char *s){
    size_t n = strlen(s) + 1;
    char *p = (char *)malloc(n);
    if (p) memcpy(p, s, n);
    return p;
}
/* 标准库名 → g_libp[] 下标；同名的复用同一下标 */
static int jit_lib_index(char **names, int *n, const char *nm){
    int i;
    for (i = 0; i < *n; i++)
        if (strcmp(names[i], nm) == 0) return i;
    if (*n >= JIT_MAXLIB) return -1;
    names[*n] = jit_strdup(nm);
    if (!names[*n]) return -1;
    return (*n)++;
}

/* 批量文件前导：include + 循环计数助手 + 栈宏 + 标准库函数指针表 + 递归护栏
 * （整个文件只写一次）。
 *
 * 标准库调用为什么要「函数指针表 + jit_init」而不是直接写 C 函数名：
 * 字节码里存的是 PYbook 名字（"mt.sqrt"），C 函数名（rt_lib_mt_sqrt）只存在于
 * pybk_code.py 的映射表里，pyvm.c 看不到；能看到的只有 g_lib_calls 里的**指针**。
 * 所以 DLL 侧留一张按需填充的表，由 EXE 在 LoadLibrary 之后用 lib_lookup 灌进去：
 * 既不用把地址烤进生成代码（ASLR 下每进程都不同），也不用按名字线性扫
 * （扫出来的速度和解释器一样，等于白 JIT）。
 *
 * 递归护栏：解释器的帧开在堆上，JIT 的帧开在 C 栈上。原生递归深到爆栈拿到的是
 * 段错误而不是可读报错 —— 这里自己数层数并给三段式报错。 */
static void jit_emit_prelude(JStr *s){
    js_add(s,
        "#include \"pybook_rt.h\"\n"
        "#include <stdint.h>\n"
        "#include <math.h>\n"
        "#define JIT_MAXLIB 64\n"
        "typedef Value (*JitLibFn0)(void);\n"
        "typedef Value (*JitLibFn1)(Value);\n"
        "typedef Value (*JitLibFn2)(Value, Value);\n"
        "typedef Value (*JitLibFn3)(Value, Value, Value);\n"
        "typedef Value (*JitLibFn4)(Value, Value, Value, Value);\n"
        "typedef Value (*JitLibFn5)(Value, Value, Value, Value, Value);\n"
        "typedef Value (*JitLibFn6)(Value, Value, Value, Value, Value, Value);\n"
        "typedef Value (*JitLibFn7)(Value, Value, Value, Value, Value, Value, Value);\n"
        "typedef Value (*JitLibFn8)(Value, Value, Value, Value, Value, Value, Value, Value);\n"
        "static long long jit_lc(Value v){\n"
        "  if (IS_INT(v)||IS_BIGINT(v)) return rt_to_ll(v);\n"
        "  if (IS_BOOL(v)) return (long long)AS_BOOL(v);\n"
        "  if (IS_FLT(v)){ double fv=AS_FLT(v); if(fv>=-(double)9007199254740992.0 && fv<=(double)9007199254740992.0 && fv==floor(fv)) return (long long)fv; }\n"
        "  return 0;\n"
        "}\n"
        "static inline Value jit_int(long long x){\n"
        "  if (x >= RT_INT_FAST_MIN && x <= RT_INT_FAST_MAX)\n"
        "    return 0x7FF9000000000000ULL | ((uint64_t)x & 0xFFFFFFFFFFFFULL);\n"
        "  return rt_int(x);\n"
        "}\n"
        "static inline Value jit_add(Value a, Value b){\n"
        "  if (IS_INT(a) && IS_INT(b)) { long long r;\n"
        "    if (!__builtin_add_overflow(AS_INT(a), AS_INT(b), &r)) return jit_int(r); }\n"
        "  return rt_add(a, b);\n"
        "}\n"
        "static inline Value jit_sub(Value a, Value b){\n"
        "  if (IS_INT(a) && IS_INT(b)) { long long r;\n"
        "    if (!__builtin_sub_overflow(AS_INT(a), AS_INT(b), &r)) return jit_int(r); }\n"
        "  return rt_sub(a, b);\n"
        "}\n"
        "static inline Value jit_mul(Value a, Value b){\n"
        "  if (IS_INT(a) && IS_INT(b)) { long long r;\n"
        "    if (!__builtin_mul_overflow(AS_INT(a), AS_INT(b), &r)) return jit_int(r); }\n"
        "  return rt_mul(a, b);\n"
        "}\n"
        "static inline Value jit_eq(Value a, Value b){\n"
        "  if (IS_INT(a) && IS_INT(b)) return rt_bool(AS_INT(a) == AS_INT(b));\n"
        "  return rt_eq(a, b);\n"
        "}\n"
        "static inline Value jit_lt(Value a, Value b){\n"
        "  if (IS_INT(a) && IS_INT(b)) return rt_bool(AS_INT(a) < AS_INT(b));\n"
        "  return rt_lt(a, b);\n"
        "}\n"
        "static inline Value jit_gt(Value a, Value b){\n"
        "  if (IS_INT(a) && IS_INT(b)) return rt_bool(AS_INT(a) > AS_INT(b));\n"
        "  return rt_gt(a, b);\n"
        "}\n"
        "static inline Value jit_le(Value a, Value b){\n"
        "  if (IS_INT(a) && IS_INT(b)) return rt_bool(AS_INT(a) <= AS_INT(b));\n"
        "  return rt_le(a, b);\n"
        "}\n"
        "static inline Value jit_ge(Value a, Value b){\n"
        "  if (IS_INT(a) && IS_INT(b)) return rt_bool(AS_INT(a) >= AS_INT(b));\n"
        "  return rt_ge(a, b);\n"
        "}\n"
        "static inline long long jit_to_ll(Value v){ return IS_INT(v) ? AS_INT(v) : rt_to_ll(v); }\n"
        "static inline int jit_cond(Value v){ return IS_BOOL(v) ? AS_BOOL(v) : rt_cond(v); }\n"
        "#define JIT_MAXD 1024\n"
        "static void *g_libp[JIT_MAXLIB];\n"
        "static int jit_depth = 0;\n"
        "#define JIT_MAXDEPTH 2000\n");
    js_add(s, "#define JIT_ENTER() do{ if(++jit_depth > JIT_MAXDEPTH){ jit_depth--; rt_die(");
    js_strlit(s, "JIT 原生递归太深（超过 2000 层）\n"
                 "  为什么：解释器的帧开在堆上，JIT 的帧开在 C 栈上，太深会爆栈\n"
                 "  怎么改：改写成循环 / 尾递归，或调大栈");
    js_add(s, "); } }while(0)\n"
              "#define JRET(v) do{ jit_depth--; return (v); }while(0)\n");
}

/* ---------- Phase H：可编性分析 ----------
 *
 * 「这个函数能不能编」现在依赖「它调的函数能不能编」：
 *   方() 不含调用       → 可编
 *   累方() 调 list.方() → 方可编则累方可编（同一 DLL 内直接调 jit_方）
 *   调到还在解释器上的函数 → 不可编（保守：模块全局与解释器帧共享，动不了）
 * 这是一个不动点问题：按「不含调用」求基，再反复剔除「调了不可编函数的」，
 * 直到不再变化。调用图无环时一趟到位；递归/互调也在不动点里自洽 ——
 * 要么整组可编、要么整组剔除，不会只编一半（只编一半就会出现「原生调解释器」
 * 的半吊子状态，比全不解还难查）。
 *
 * jit_scan_fn 只看字节码形状，不查 g_lib_calls（那要按名字扫 300+ 项，
 * 每个函数扫一遍、函数之间再来一遍）；标准库名对不对在发射时逐个查，
 * 不对就当这个函数不可编。 */

/* 1 = 形状上可编；顺带报出「含不含用户函数调用」 */
static int jit_scan_fn(Module *m, Fn *fn, uint8_t *has_call){
    const uint8_t *code = g_img + m->code_base + fn->code_off;
    size_t clen = fn->code_len, off = 0;
    *has_call = 0;
    if (clen == 0) return 0;
    while (off < clen) {
        uint8_t op = code[off];
        int is_jump = 0;
        int nops = jit_op_nops(op, &is_jump);
        if (nops < 0) return 0;
        if (is_jump && off + 1 + (size_t)nops > clen) return 0;
        if (op == 0x30) {
            if (nops != 3 || off + 4 > clen) return 0;
            *has_call = 1;
        }
        off += 1 + (size_t)nops;
    }
    return 1;
}

/* 函数里每个 CALL 的目标是否都可编 */
static int jit_callees_ok(Module *m, Fn *fn, const uint8_t *emittable){
    const uint8_t *code = g_img + m->code_base + fn->code_off;
    size_t clen = fn->code_len, off = 0;
    while (off < clen) {
        uint8_t op = code[off];
        int is_jump = 0;
        int nops = jit_op_nops(op, &is_jump);
        if (nops < 0) break;
        if (op == 0x30 && nops == 3 && off + 4 <= clen) {
            uint16_t tf = (uint16_t)(code[off + 1] | ((uint16_t)code[off + 2] << 8));
            uint8_t na = code[off + 3];
            if (tf == 0 || tf >= m->nfns) return 0;    /* 主程序永不被 JIT 调 */
            if ((int)na != (int)m->fns[tf].nparams) return 0;
            if (!emittable[tf]) return 0;
        }
        off += 1 + (size_t)nops;
    }
    return 1;
}

/* 发射单个函数进批量缓冲；不可 JIT 返回 0 且不回留残内容（批量拼装继续）。
 * 逐 opcode 语义与旧版 jit_emit_c 逐字一致，只是前导被拆去——
 * 多个函数因此能拼进同一个 .c、同一个 DLL（一次编译 + 一次链接）。 */
static int jit_emit_fn(JStr *s, Module *m, Fn *fn, uint32_t fni,
                       const uint8_t *emittable, char **libnames, int *nlib){
    const uint8_t *code = g_img + m->code_base + fn->code_off;
    size_t clen = fn->code_len;
    if (clen == 0) return 0;
    size_t mark = s->len;

    /* 第一遍：收集跳转目标 + 查标准库调用 + 查用户函数调用 */
    int targets[256]; int ntargets = 0;
    size_t off = 0;
    while (off < clen) {
        uint8_t op = code[off];
        int is_jump = 0;
        int nops = jit_op_nops(op, &is_jump);
        if (nops < 0) return 0;
        if (op == 0x30) {
            uint16_t tf; uint8_t na;
            if (nops != 3 || off + 4 > clen) return 0;
            tf = (uint16_t)(code[off + 1] | ((uint16_t)code[off + 2] << 8));
            na = code[off + 3];
            if (tf == 0 || tf >= m->nfns) return 0;  /* 主程序永不被 JIT 调 */
            if (!emittable[tf]) return 0;             /* 目标还在解释器上 */
            if ((int)na != (int)m->fns[tf].nparams) return 0;
        }
        if (op == 0x36) {
            Value nv; int ar = 0;
            if (nops != 3 || off + 4 > clen) return 0;
            nv = m->consts[(uint16_t)(code[off + 1] | ((uint16_t)code[off + 2] << 8))];
            if (!IS_STR(nv)) return 0;
            if (!lib_lookup(AS_STR(nv), &ar)) return 0;  /* VM 里本就不可用的库 */
            if (ar != (int)code[off + 3]) return 0;     /* 元数对不上：交给解释器报错 */
        }
        if (is_jump) {
            if (off + 1 + (size_t)nops > clen) return 0;
            const uint8_t *q = code + off + 1 + (nops - 4);
            int32_t joff = (int32_t)(q[0] | q[1]<<8 | q[2]<<16 | ((uint32_t)q[3]<<24));
            int32_t tgt = (int32_t)(off + 1 + nops) + joff;
            if (tgt >= 0 && (size_t)tgt < clen && ntargets < 256)
                targets[ntargets++] = tgt;
        }
        off += 1 + (size_t)nops;
    }

    js_add(s, "Value jit_%u(Value *a, int n){\n", fni);
    js_add(s, "  JIT_ENTER();\n");
    if (fn->nslots == 0)
        js_add(s, "  Value S[1];\n");
    else
        js_add(s, "  Value S[%u];\n", (unsigned)fn->nslots);
    js_add(s,
        "  int i;\n"
        "  for(i=0;i<n && i<(int)(sizeof(S)/sizeof(S[0]));i++) S[i]=a[i];\n"
        "  for(;i<(int)(sizeof(S)/sizeof(S[0]));i++) S[i]=rt_none();\n"
        "  Value stk[JIT_MAXD]; int sp=0;\n"
        "  #define PUSH(v) do{ if(sp>=JIT_MAXD) JRET(rt_none()); stk[sp++]=(v); }while(0)\n"
        "  #define POP() (stk[--sp])\n");

    off = 0;
    while (off < clen) {
        uint8_t op = code[off];
        int is_jump = 0;
        int nops = jit_op_nops(op, &is_jump);
        for (int ti = 0; ti < ntargets; ti++)
            if (targets[ti] == (int)off) { js_add(s, "L_%u:;\n", (unsigned)off); break; }

        size_t p = off + 1;
        uint16_t u16a=0, u16b=0; uint8_t u8a=0; int32_t i32=0;
        if (nops >= 2){ u16a = (uint16_t)(code[p] | ((uint16_t)code[p+1]<<8)); }
        if (nops >= 4){ u16b = (uint16_t)(code[p+2] | ((uint16_t)code[p+3]<<8)); }
        if (nops == 1 || nops == 3){ u8a = code[p + (nops - 1)]; }
        if (is_jump){ const uint8_t *q = code + off + 1 + (nops - 4); i32 = (int32_t)(q[0]|q[1]<<8|q[2]<<16|((uint32_t)q[3]<<24)); }

        int32_t tgt = (int32_t)(off + 1 + nops) + i32;

        switch (op) {
        case 0x00: break;
        case 0x01: js_add(s, "JRET(rt_none());\n"); break;
        case 0x02: {
            Value v = m->consts[u16a];
            if (IS_INT(v) || IS_BIGINT(v)) js_add(s, "PUSH(jit_int(%lld));\n", rt_to_ll(v));
            else if (IS_FLT(v)) js_add(s, "PUSH(rt_float(%.17g));\n", AS_FLT(v));
            else if (IS_STR(v)) { js_add(s, "PUSH(rt_str("); js_strlit(s, AS_STR(v)); js_add(s, "));\n"); }
            else { s->len = mark; return 0; }
            break;
        }
        case 0x03: js_add(s, "PUSH(S[%u]);\n", (unsigned)u16a); break;
        case 0x04: js_add(s, "S[%u]=POP();\n", (unsigned)u16a); break;
        case 0x05: js_add(s, "PUSH(stk[sp-1]);\n"); break;
        case 0x06: js_add(s, "sp--;\n"); break;
        case 0x10: js_add(s, "do{Value _b=POP();Value _a=POP();PUSH(jit_add(_a,_b));}while(0);\n"); break;
        case 0x11: js_add(s, "do{Value _b=POP();Value _a=POP();PUSH(jit_sub(_a,_b));}while(0);\n"); break;
        case 0x12: js_add(s, "do{Value _b=POP();Value _a=POP();PUSH(jit_mul(_a,_b));}while(0);\n"); break;
        case 0x13: js_add(s, "do{Value _b=POP();Value _a=POP();PUSH(rt_div(_a,_b));}while(0);\n"); break;
        case 0x14: js_add(s, "do{Value _b=POP();Value _a=POP();PUSH(rt_fdiv(_a,_b));}while(0);\n"); break;
        case 0x15: js_add(s, "do{Value _b=POP();Value _a=POP();PUSH(rt_mod(_a,_b));}while(0);\n"); break;
        case 0x16: js_add(s, "PUSH(rt_neg(POP()));\n"); break;
        case 0x17: js_add(s, "PUSH(rt_not(POP()));\n"); break;
        case 0x18: js_add(s, "do{Value _b=POP();Value _a=POP();PUSH(jit_eq(_a,_b));}while(0);\n"); break;
        case 0x19: js_add(s, "do{Value _b=POP();Value _a=POP();PUSH(rt_ne(_a,_b));}while(0);\n"); break;
        case 0x1A: js_add(s, "do{Value _b=POP();Value _a=POP();PUSH(jit_lt(_a,_b));}while(0);\n"); break;
        case 0x1B: js_add(s, "do{Value _b=POP();Value _a=POP();PUSH(jit_gt(_a,_b));}while(0);\n"); break;
        case 0x1C: js_add(s, "do{Value _b=POP();Value _a=POP();PUSH(jit_le(_a,_b));}while(0);\n"); break;
        case 0x1D: js_add(s, "do{Value _b=POP();Value _a=POP();PUSH(jit_ge(_a,_b));}while(0);\n"); break;
        case 0x1E: js_add(s, "goto L_%u;\n", (unsigned)tgt); break;
        case 0x1F: js_add(s, "if(!jit_cond(POP())) goto L_%u;\n", (unsigned)tgt); break;
        case 0x20: js_add(s, "if(jit_cond(POP())) goto L_%u;\n", (unsigned)tgt); break;
        case 0x21: { Value v=m->consts[u16a]; if(!IS_STR(v)){s->len=mark;return 0;} js_add(s,"rt_show_text("); js_strlit(s,AS_STR(v)); js_add(s,");\n"); break; }
        case 0x22: js_add(s, "rt_show_value(POP());\n"); break;
        case 0x23: { Value v=m->consts[u16a]; if(!IS_STR(v)){s->len=mark;return 0;} js_add(s,"rt_magic("); js_strlit(s,AS_STR(v)); js_add(s,");\n"); break; }
        case 0x24: js_add(s, "rt_show_end();\n"); break;
        case 0x25: js_add(s, "PUSH(rt_list_new());\n"); break;
        case 0x26: js_add(s, "do{Value _v=POP();rt_push(&stk[sp-1],_v);}while(0);\n"); break;
        case 0x27: js_add(s, "PUSH(rt_len(POP()));\n"); break;
        case 0x28: js_add(s, "do{Value _i=POP();Value _b=POP();PUSH(rt_index(_b,_i));}while(0);\n"); break;
        case 0x29: js_add(s, "do{Value _v=POP();Value _i=POP();Value _b=POP();rt_setindex(&_b,_i,_v);}while(0);\n"); break;
        case 0x2A: { Value v=m->consts[u16a]; if(!IS_STR(v)){s->len=mark;return 0;} js_add(s,"PUSH(rt_input("); js_strlit(s,AS_STR(v)); js_add(s,"));\n"); break; }
        case 0x2B: js_add(s, "do{Value _c=POP();S[%u]=jit_int(0);S[%u]=jit_int(jit_lc(_c));}while(0);\n", (unsigned)u16a, (unsigned)u16b); break;
        case 0x2C: js_add(s, "do{long long _nx=jit_to_ll(S[%u])+1;S[%u]=jit_int(_nx);if(_nx<jit_to_ll(S[%u])) goto L_%u;}while(0);\n", (unsigned)u16a,(unsigned)u16a,(unsigned)u16b,(unsigned)tgt); break;
        case 0x2D: js_add(s, "PUSH(rt_dict_new());\n"); break;
        case 0x2E: js_add(s, "do{Value _v=POP();Value _k=POP();rt_dict_set(&stk[sp-1],_k,_v);}while(0);\n"); break;
        case 0x30: {                     /* CALL u16 fn u8 nargs → 同 DLL 内直调 jit_<fni> */
            int na = (int)u8a, k;
            js_add(s, "do{Value _ja[%d];", na ? na : 1);
            for (k = na - 1; k >= 0; k--)
                js_add(s, "_ja[%d]=POP();", k);
            js_add(s, "PUSH(jit_%u(_ja, %d));}while(0);\n", (unsigned)u16a, na);
            break;
        }
        case 0x36: {                     /* CALL_LIB u16 库名 u8 nargs → 经 g_libp 间接调 */
            Value nv = m->consts[u16a];
            int idx = jit_lib_index(libnames, nlib, AS_STR(nv));
            int na = (int)u8a, k;
            if (idx < 0) { s->len = mark; return 0; }
            js_add(s, "do{");
            for (k = na - 1; k >= 0; k--)
                js_add(s, "Value _a%d=POP();", k);
            js_add(s, "PUSH(((JitLibFn%d)g_libp[%d])(", na, idx);
            for (k = 0; k < na; k++)
                js_add(s, k ? ",_a%d" : "_a%d", k);
            js_add(s, "));}while(0);\n");
            break;
        }
        case 0x31: js_add(s, "JRET(POP());\n"); break;
        case 0x32: js_add(s, "JRET(rt_none());\n"); break;
        case 0x33: js_add(s, "rt_gold(&S[%u]);\n", (unsigned)u16a); break;
        case 0x34: js_add(s, "rt_destroy(&S[%u]);\n", (unsigned)u16a); break;
        case 0x35: js_add(s, "rt_set_memmode(%d);\n", (int)u8a); break;
        default: s->len = mark; return 0;
        }
        off += 1 + (size_t)nops;
    }
    js_add(s, "  #undef PUSH\n  #undef POP\n  JRET(rt_none());\n}\n");
    return 1;
}

static void jit_mkdirs(void){
#ifdef _WIN32
    _mkdir("build");
    _mkdir("build/.jit");
    _mkdir("build/.jit/rt");
    _mkdir("build/.jit/cache");
#else
    mkdir("build", 0755);
    mkdir("build/.jit", 0755);
    mkdir("build/.jit/rt", 0755);
    mkdir("build/.jit/cache", 0755);
#endif
}

/* 目标 .o 是否需要重编：不存在，或源比它新/等大。
   16 个运行时 .c 全量编成 DLL 一次要 16 秒（实测），拆成 .o 缓存之后
   只有第一次（或改了运行时源码）贵，之后每次 JIT 只编用户函数那一个 .c。 */
static int jit_obj_stale(const char *src, const char *obj){
    struct stat s1, s2;
    if (stat(src, &s1) != 0) return 1;      /* 源读不到：交给 gcc 自己报错 */
    if (stat(obj, &s2) != 0) return 1;      /* 还没有 .o */
    if (s2.st_mtime < s1.st_mtime) return 1;
    if (s2.st_size == 0) return 1;          /* 上一轮失败留下的空壳 */
    return 0;
}

/* DLL 缓存清扫：缓存按内容寻址、每个程序版本一份，不清会无限长；
   只留最近 JIT_CACHE_KEEP 个，顺带清掉崩溃残留的 .tmp.dll。
   刚写入的新 DLL 时间最新，永远排在保留区里，不会被误删。 */
#define JIT_CACHE_KEEP 8
static void jit_cache_sweep(void){
#ifdef _WIN32
    WIN32_FIND_DATAA fd;
    HANDLE hf = FindFirstFileA("build/.jit/cache/*.dll", &fd);
    if (hf == INVALID_HANDLE_VALUE) return;
    char names[32][80]; FILETIME ts[32]; int n = 0;
    do {
        if (n >= 32) break;
        snprintf(names[n], sizeof names[n], "%s", fd.cFileName);
        ts[n] = fd.ftLastWriteTime;
        n++;
    } while (FindNextFileA(hf, &fd));
    FindClose(hf);
    for (int i = 0; i < n - 1; i++)            /* 冒泡排序：老的在前 */
        for (int j = 0; j < n - 1 - i; j++)
            if (CompareFileTime(&ts[j], &ts[j+1]) > 0) {
                FILETIME t = ts[j]; ts[j] = ts[j+1]; ts[j+1] = t;
                char tn[80]; snprintf(tn, sizeof tn, "%s", names[j]);
                snprintf(names[j], sizeof names[j], "%s", names[j+1]);
                snprintf(names[j+1], sizeof names[j+1], "%s", tn);
            }
    for (int i = 0; i < n - JIT_CACHE_KEEP; i++) {
        char p[128];
        snprintf(p, sizeof p, "build/.jit/cache/%s", names[i]);
        DeleteFileA(p);
    }
#endif
}

#define JIT_NRT 24                          /* rt_names 容量上限（现 16 个 + 余量） */

static void jit_batch_compile(Module *m){
    /* 批量 JIT（2026-10-13 两轮优化）：
     * 病根 1——旧版 rt_names 漏了后加的 pybook_gpu.c（及被 pybook_rt.c 引用
     * 的 obj/wire），链接必然 undefined reference，JIT 全灭只剩纯开销
     * （基准 44.2s vs 解释器 6.7s），这就是「加入 JIT 后 VM 慢很多」。
     * 病根 2——旧版每个热函数各编各的：N 个热函数 = N 次编译 + N 次把 16 个
     * 运行时 .o 全量链接；本机每次 gcc 进程启动约 1.2s（杀软逐进程扫描）。
     * 现在：第一个函数越过热阈时，一次性发射所有函数 -> 一个 .c -> 与 16 个
     * 运行时 .o 一次 -shared 调用出一个 DLL（编译+链接合并，3.5s -> 2.45s），
     * 成本与函数个数无关；DLL 按内容寻址缓存，同程序第二次运行零 gcc。 */
    g_jit_done = 1;                     /* 无论成败，每轮只触发一次 */

    const char *gcc = getenv("PYBOOK_JIT_GCC");
    if (!gcc) gcc = "C:/Users/zhuli/mingw64/bin/x86_64-w64-mingw32-gcc.exe";
    const char *sd = getenv("PYBOOK_JIT_SRC");
    if (!sd) sd = "C:/Users/zhuli/Desktop/pybook";

    /* ---- 第 1 步：可编性不动点（fn 0 是主程序，永不被 CALL，跳过）---- */
    uint32_t nfns = m->nfns;
    uint8_t *emittable = (uint8_t *)calloc(nfns ? nfns : 1, 1);
    uint8_t *hascall   = (uint8_t *)calloc(nfns ? nfns : 1, 1);
    uint32_t *ok = (uint32_t *)malloc((nfns ? nfns : 1) * sizeof(uint32_t));
    if (!emittable || !hascall || !ok) {
        free(emittable); free(hascall); free(ok); return;
    }
    for (uint32_t fni = 1; fni < nfns; fni++)
        emittable[fni] = (uint8_t)jit_scan_fn(m, &m->fns[fni], &hascall[fni]);

    for (int pass = 0; pass < 64; pass++) {
        int changed = 0;
        for (uint32_t fni = 1; fni < nfns; fni++) {
            if (!emittable[fni] || !hascall[fni]) continue;
            if (!jit_callees_ok(m, &m->fns[fni], emittable)) {
                emittable[fni] = 0;
                changed = 1;
            }
        }
        if (!changed) break;
    }

    /* ---- 第 2 步：发射函数体（先攒着：前导要知道用到几个库调用）---- */
    JStr fs = {NULL, 0, 0};
    char **libnames = (char **)calloc(JIT_MAXLIB, sizeof(char *));
    int nlib = 0;
    int nok = 0;
    /* 前向声明：被调的函数可能定义在后面（甚至就是自己，递归） */
    for (uint32_t fni = 1; fni < nfns; fni++)
        if (emittable[fni])
            js_add(&fs, "Value jit_%u(Value *, int);\n", fni);
    for (uint32_t fni = 1; fni < nfns; fni++) {
        if (!emittable[fni]) { m->fns[fni].jit_state = 2; continue; }
        if (jit_emit_fn(&fs, m, &m->fns[fni], fni, emittable, libnames, &nlib))
            ok[nok++] = fni;
        else {
            m->fns[fni].jit_state = 2;     /* 不可 JIT：永留解释器 */
            emittable[fni] = 0;
        }
    }
    if (nok == 0) {                        /* 没有可编的函数：零 gcc 开销 */
        free(ok); free(fs.b); free(emittable); free(hascall);
        for (int i = 0; i < nlib; i++) free(libnames[i]);
        free(libnames);
        if (getenv("PYVM_JIT_VERBOSE"))
            fprintf(stderr, "[JIT] 无可 JIT 的函数，纯解释器运行\n");
        return;
    }

    /* ---- 前导 + 库名表 + jit_init（jit_init 要在 g_libname 之后定义）---- */
    JStr s = {NULL, 0, 0};
    jit_emit_prelude(&s);
    js_add(&s, "static const char *g_libname[JIT_MAXLIB] = {");
    for (int i = 0; i < nlib; i++) {
        if (i) js_add(&s, ",");
        js_strlit(&s, libnames[i]);
    }
    js_add(&s, "};\nstatic int g_libn = %d;\n", nlib);
    js_add(&s, "void jit_init(void *(*lookup)(const char *, int *)){\n"
              "  int i, ar = 0;\n"
              "  for(i=0;i<g_libn && i<JIT_MAXLIB;i++) g_libp[i] = lookup(g_libname[i], &ar);\n"
              "}\n");
    if (fs.b && fs.len && js_reserve(&s, fs.len)) {   /* 函数体并入（memcpy，不走 printf） */
        memcpy(s.b + s.len, fs.b, fs.len);
        s.len += fs.len;
        s.b[s.len] = 0;
    }
    free(fs.b);
    for (int i = 0; i < nlib; i++) free(libnames[i]);
    free(libnames);
    free(emittable);
    free(hascall);

    /* ---- 第 2 步：运行时 .o 缓存（16 个 .c，缺/过期才编）---- */
    /* 清单与 build_pyvm.bat 的链接集保持一致（含 pybook_la.c）——少一个就 undefined
     * reference（pybook_gpu.c / pybook_obj.c / pybook_wire.c 正是这么漏的） */
    static const char *rt_names[] = {
        "pybook_rt.c","pybook_lib.c","pybook_csv.c","pybook_json.c",
        "pybook_file.c","pybook_mt.c","pybook_gpu.c","pybook_mm.c",
        "pybook_obj.c","pybook_wire.c","pybook_np.c","pybook_tb.c",
        "pybook_bits.c","pybook_smoke.c","pybook_music.c","mathplus.c",
        "pybook_la.c"
    };
    const size_t NRT = sizeof(rt_names)/sizeof(rt_names[0]);
    if (NRT >= JIT_NRT) { free(ok); free(s.b); return; }

    char iflag[512];
    snprintf(iflag, sizeof iflag, "-I%s", sd);

    int verbose = getenv("PYVM_JIT_VERBOSE") != NULL;
    char objpaths[JIT_NRT][512];
    const char *av[64]; int ac = 0; int rc;

    jit_mkdirs();
    int nbuilt = 0;
    for (size_t i = 0; i < NRT; i++) {
        char sp[512];
        snprintf(sp, sizeof sp, "%s/%s", sd, rt_names[i]);
        snprintf(objpaths[i], sizeof objpaths[i], "build/.jit/rt/%s.o", rt_names[i]);
        if (!jit_obj_stale(sp, objpaths[i])) continue;

        ac = 0;
        av[ac++] = gcc;
        av[ac++] = "-O3";            /* 运行时只编一次，用 -O3 吃满优化 */
        av[ac++] = "-march=native";
        av[ac++] = iflag;
        av[ac++] = "-fPIC";          /* 要链进 DLL；Windows PE 上无害，ELF 上必需 */
        av[ac++] = "-c";
        av[ac++] = "-DMP_RT_BINDING";
        av[ac++] = "-DLA_RT_BINDING";   /* pybook_la.c 绑定层开门宏（与 build_pyvm.bat 一致） */
        av[ac++] = sp;
        av[ac++] = "-o";
        av[ac++] = objpaths[i];
        av[ac] = NULL;
        rc = _spawnvp(_P_WAIT, gcc, av);
        if (rc != 0) {
            if (verbose) fprintf(stderr, "[JIT] 运行时编译失败 rc=%d %s\n", rc, rt_names[i]);
            free(ok); free(s.b); return;
        }
        nbuilt++;
    }
    if (verbose)
        fprintf(stderr, "[JIT] 运行时 .o：新编 %d 个 / 命中缓存 %d 个\n",
                nbuilt, (int)(NRT - nbuilt));
    if (verbose)
        fprintf(stderr, "[JIT] 批量发射 %d 个函数\n", nok);

    /* ---- 第 3 步：落盘 .c + 算内容寻址缓存键 ----
     * 本机 gcc 进程启动固定约 1.2s（杀软逐进程扫描），编译+链接分两次调用
     * 要付两次启动；合并成一次 -shared 调用实测 3.5s -> 2.45s。
     * 缓存键覆盖：生成 C 全文 + 各运行时 .o 身份（名/大小/mtime）+ gcc 路径，
     * 任何一环变化即换键——源改了自动重编，不存在陈旧 DLL。 */
    char cpath[512], dllpath[512], tmpdll[560];
    snprintf(cpath, sizeof cpath, "build/.jit/jit_batch.c");
    FILE *fp = fopen(cpath, "wb");
    if (fp) { fwrite(s.b, 1, s.len, fp); fclose(fp); }

    uint64_t hk = 1469598103934665603ULL;                /* FNV-1a 64 位 */
    for (size_t i = 0; i < s.len; i++) { hk ^= (unsigned char)s.b[i]; hk *= 1099511628211ULL; }
    for (size_t i = 0; i < NRT; i++) {
        struct stat st;
        if (stat(objpaths[i], &st) != 0) { free(ok); free(s.b); return; }
        for (const char *p = rt_names[i]; *p; p++) { hk ^= (unsigned char)*p; hk *= 1099511628211ULL; }
        uint64_t sz = (uint64_t)st.st_size;
        int64_t  mt = (int64_t)st.st_mtime;
        for (size_t k = 0; k < 8; k++) { hk ^= (unsigned char)(sz >> (8*k)); hk *= 1099511628211ULL; }
        for (size_t k = 0; k < 8; k++) { hk ^= (unsigned char)((uint64_t)mt >> (8*k)); hk *= 1099511628211ULL; }
    }
    for (const char *p = gcc; *p; p++) { hk ^= (unsigned char)*p; hk *= 1099511628211ULL; }
    free(s.b);
    snprintf(dllpath, sizeof dllpath, "build/.jit/cache/%016llx.dll", (unsigned long long)hk);
    snprintf(tmpdll, sizeof tmpdll, "build/.jit/cache/%016llx.tmp.dll", (unsigned long long)hk);

    /* ---- 第 4 步：命中缓存直接加载（零 gcc）；未命中编译+链接一次调用出 DLL ---- */
    int cached = 0;
    if (!getenv("PYVM_JIT_NOCACHE")) {
        struct stat cst;
        if (stat(dllpath, &cst) == 0 && cst.st_size > 0) cached = 1;
    }
    if (!cached) {
        ac = 0;
        av[ac++] = gcc;
        av[ac++] = "-O2";                /* 每次重编，-O2 平衡时间 */
        av[ac++] = "-march=native";
        av[ac++] = iflag;
        av[ac++] = "-fPIC";
        av[ac++] = "-shared";            /* 编译+链接合为一次 gcc 调用 */
        av[ac++] = "-DMP_RT_BINDING";
        av[ac++] = "-DLA_RT_BINDING";
        av[ac++] = cpath;
        for (size_t i = 0; i < NRT; i++) av[ac++] = objpaths[i];
        av[ac++] = "-o";
        av[ac++] = tmpdll;
        av[ac++] = "-lwinmm";
        av[ac++] = "-lm";
        av[ac] = NULL;
        rc = _spawnvp(_P_WAIT, gcc, av);
        if (rc != 0) {
            if (verbose) fprintf(stderr, "[JIT] 批量编译失败 rc=%d\n", rc);
            free(ok); return;
        }
        MoveFileExA(tmpdll, dllpath, MOVEFILE_REPLACE_EXISTING);
        jit_cache_sweep();
    }
    if (verbose)
        fprintf(stderr, cached ? "[JIT] 命中 DLL 缓存：零 gcc 开销\n"
                               : "[JIT] 新 DLL 已写入缓存（下次同程序零开销）\n");

    /* ---- 第 5 步：按符号名取回每个函数的原生指针 ---- */
    HMODULE h = LoadLibraryA(dllpath);
    if (!h) {
        if (verbose) fprintf(stderr, "[JIT] LoadLibrary 失败\n");
        if (cached) DeleteFileA(dllpath);   /* 缓存 DLL 损坏：删掉让下次重编 */
        free(ok); return;
    }
    /* 把本进程的 lib_lookup 交给 DLL：它按名字解析出函数指针灌进 g_libp，
     * 于是发射出来的是一次间接调用（比解释器的线性扫表快一个量级），
     * 又不用把任何绝对地址烤进生成代码（ASLR 下地址每进程都不同）。 */
    {
        /* GetProcAddress 返回 FARPROC，直接转函数指针是 UB 且会被编译器警告；
         * 走 union 是 Windows 上公认的干净写法。 */
        union { FARPROC p; void (*f)(void *(*)(const char *, int *)); } u;
        u.p = GetProcAddress(h, "jit_init");
        if (u.f)
            u.f((void *(*)(const char *, int *))lib_lookup);
        else if (getenv("PYVM_JIT_VERBOSE"))
            fprintf(stderr, "[JIT] DLL 里没有 jit_init（缓存是旧版生成的？）\n");
    }
    int nlinked = 0;
    for (int i = 0; i < nok; i++) {
        uint32_t fni = ok[i];
        char sym[32]; snprintf(sym, sizeof sym, "jit_%u", fni);
        void *p = (void *)GetProcAddress(h, sym);
        if (!p) { m->fns[fni].jit_state = 2; continue; }
        m->fns[fni].jit_ptr = p;
        m->fns[fni].jit_state = 1;
        nlinked++;
        if (verbose) {
            Fn *fn = &m->fns[fni];
            const char *nm = IS_STR(m->consts[fn->name_idx]) ? AS_STR(m->consts[fn->name_idx]) : "(anon)";
            fprintf(stderr, "[JIT] fn %u (%s) -> 原生\n", fni, nm);
        }
    }
    free(ok);
    if (verbose)
        fprintf(stderr, "[JIT] 批量完成：%d/%d 个函数上原生\n", nlinked, nok);
}

int main(int argc, char **argv)
{
    const char *path = NULL;
    /* 环境变量 PYVM_JIT（优先级低于命令行）：0/off=关，1/on=开，数字=开并设阈。
     * 文件头 jit 指令（opcode 0x38，主程序首条语句）优先级最高，最后落地。 */
    {
        const char *e = getenv("PYVM_JIT");
        if (e && *e && strcmp(e, "0") != 0 && strcmp(e, "off") != 0) {
            int t = atoi(e);
            g_jit_enable = 1;
            if (t > 0) g_jit_threshold = (uint32_t)t;
            g_jit_src = 1;
        } else if (e && *e) {
            g_jit_enable = 0;
            g_jit_src = 1;
        }
    }
    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--no-jit") == 0) {
            g_jit_enable = 0;                 /* 命令行显式关（仍会被文件头盖过） */
            g_jit_src = 2;
        } else if (strncmp(argv[i], "--jit", 5) == 0) {
            g_jit_enable = 1;
            g_jit_src = 2;
            const char *eq = strchr(argv[i], '=');
            if (eq && eq[1]) {
                int t = atoi(eq + 1);
                if (t > 0) g_jit_threshold = (uint32_t)t;
            }
        } else if (argv[i][0] == '-') {
            fprintf(stderr, "未知选项: %s\n", argv[i]);
            return 2;
        } else {
            path = argv[i];
        }
    }
    if (!path) {
        fprintf(stderr, "用法: pyvm.exe [--jit[=阈值]|--no-jit] 文件.pybc\n");
        return 2;
    }
    size_t len = 0;
    uint8_t *img = read_file(path, &len);
    if (!img) {
        fprintf(stderr, "虚拟机错误: 无法读取文件 %s\n", path);
        return 1;
    }
    run_module(img, len);
    return 0;
}

#else /* PYVM_SELF_TEST */

#include <unistd.h>   /* dup / dup2 / close：捕获 stdout 做字节级核对 */

/* ---- 字节码拼装小工具 ---- */

typedef struct {
    uint8_t *b;
    size_t len, cap;
} Buf;

static void emit(Buf *b, const void *data, size_t n)
{
    if (b->len + n > b->cap) {
        b->cap = b->cap ? b->cap : 256;
        while (b->len + n > b->cap)
            b->cap *= 2;
        b->b = (uint8_t *)realloc(b->b, b->cap);
    }
    memcpy(b->b + b->len, data, n);
    b->len += n;
}

static void eu8(Buf *b, unsigned v)  { emit(b, &(uint8_t){(uint8_t)v}, 1); }
static void eu16(Buf *b, unsigned v) { uint8_t q[2] = { (uint8_t)v, (uint8_t)(v >> 8) }; emit(b, q, 2); }
static void eu32(Buf *b, uint32_t v) { uint8_t q[4] = { (uint8_t)v, (uint8_t)(v >> 8), (uint8_t)(v >> 16), (uint8_t)(v >> 24) }; emit(b, q, 4); }
static void ei64(Buf *b, long long v)
{
    uint64_t u = (uint64_t)v;
    for (int i = 0; i < 8; i++)
        eu8(b, (unsigned)(u >> (8 * i) & 0xFF));
}
static void estr(Buf *b, const char *s)
{
    size_t n = strlen(s);
    eu32(b, (uint32_t)n);
    emit(b, s, n);
}

/* 指令速记 */
static void op0(Buf *b, unsigned code)                       { eu8(b, code); }
static void op_u16(Buf *b, unsigned code, unsigned a)        { eu8(b, code); eu16(b, a); }
static void op2_u16(Buf *b, unsigned code, unsigned a, unsigned c) { eu8(b, code); eu16(b, a); eu16(b, c); }

/* 常量池项 */
static void c_int(Buf *b, long long v)   { eu8(b, 1); ei64(b, v); }
static void c_str(Buf *b, const char *s) { eu8(b, 3); estr(b, s); }

/* 函数表项 */
static void fnent(Buf *b, uint32_t name, unsigned params, unsigned slots, uint32_t off, uint32_t clen)
{
    eu32(b, name);
    eu16(b, params);
    eu16(b, slots);
    eu32(b, off);
    eu32(b, clen);
}

/* ---- 模块 1（合同要求的自测）：常量 40 和 2；CONST 0, CONST 1, ADD, SHOW_VALUE, HALT ---- */

static Buf build_module1(void)
{
    Buf b = { 0 };
    Buf code = { 0 };
    op_u16(&code, 0x02, 0);   /* CONST 常量池[0] (40) */
    op_u16(&code, 0x02, 1);   /* CONST 常量池[1] (2)  */
    op0(&code, 0x10);         /* ADD（0x10） */
    op0(&code, 0x22);         /* SHOW_VALUE */
    op0(&code, 0x01);         /* HALT */

    emit(&b, "PYBC", 4);
    eu32(&b, 1);              /* 版本 */
    eu32(&b, 2);              /* 常量数 */
    eu32(&b, 1);              /* 函数数 */
    c_int(&b, 40);
    c_int(&b, 2);
    fnent(&b, 0, 0, 0, 0, (uint32_t)code.len);   /* 代码偏移相对代码区起点；名字索引指向整数常量，执行不使用 */
    emit(&b, code.b, code.len);
    free(code.b);
    return b;
}

/* ---- 模块 2：列表 + 循环 + 函数调用 综合 ----
 * main（槽 0=at, 1=次数, 2=表）：
 *   list=[7,8,9]; show(len(list))        → 3
 *   show(list[0])                        → 7
 *   list[2]=99; show(list[2])            → 99
 *   循环 3 圈 show(at)                    → 0 1 2
 *   show(double(21))                     → 42
 *   show_text("end")                     → end
 * double(n): return n + n
 */
static Buf build_module2(void)
{
    Buf b = { 0 };
    Buf main_c = { 0 }, dbl_c = { 0 };

    /* double：LOAD 0; LOAD 0; ADD; RET */
    op_u16(&dbl_c, 0x03, 0);
    op_u16(&dbl_c, 0x03, 0);
    op0(&dbl_c, 0x10);
    op0(&dbl_c, 0x31);

    /* main */
    op0(&main_c, 0x25);                        /* LIST_NEW */
    op_u16(&main_c, 0x02, 3); op0(&main_c, 0x26);   /* 7 入表 */
    op_u16(&main_c, 0x02, 4); op0(&main_c, 0x26);   /* 8 入表 */
    op_u16(&main_c, 0x02, 5); op0(&main_c, 0x26);   /* 9 入表 */
    op_u16(&main_c, 0x04, 2);                  /* STORE 2（表） */
    op_u16(&main_c, 0x03, 2); op0(&main_c, 0x27);   /* LEN */
    op0(&main_c, 0x22); op0(&main_c, 0x24);    /* SHOW_VALUE, SHOW_END → 3 */
    op_u16(&main_c, 0x03, 2);                  /* LOAD 2 */
    op_u16(&main_c, 0x02, 0);                  /* CONST 0（int 0） */
    op0(&main_c, 0x28);                        /* INDEX */
    op0(&main_c, 0x22); op0(&main_c, 0x24);    /* → 7 */
    op_u16(&main_c, 0x03, 2);                  /* LOAD 2 */
    op_u16(&main_c, 0x02, 6);                  /* CONST 6（int 2） */
    op_u16(&main_c, 0x02, 7);                  /* CONST 7（int 99） */
    op0(&main_c, 0x29);                        /* SETIDX：list[2]=99 */
    op_u16(&main_c, 0x03, 2);                  /* LOAD 2 */
    op_u16(&main_c, 0x02, 6);                  /* CONST 6 */
    op0(&main_c, 0x28);                        /* INDEX */
    op0(&main_c, 0x22); op0(&main_c, 0x24);    /* → 99 */

    op_u16(&main_c, 0x02, 1);                  /* CONST 1（int 3，循环次数） */
    op2_u16(&main_c, 0x2B, 0, 1);              /* AROUND_INIT at=0 次数=1 */
    uint32_t loop_start = (uint32_t)main_c.len;
    op_u16(&main_c, 0x03, 0);                  /* LOAD 0（at） */
    op0(&main_c, 0x22); op0(&main_c, 0x24);    /* show 0/1/2 */
    eu8(&main_c, 0x2C); eu16(&main_c, 0); eu16(&main_c, 1);
    eu32(&main_c, loop_start - (main_c.len + 4));   /* AROUND_STEP 回跳循环头 */

    op_u16(&main_c, 0x02, 2);                  /* CONST 2（int 21） */
    eu8(&main_c, 0x30); eu16(&main_c, 1); eu8(&main_c, 1);   /* CALL double 1参 */
    op0(&main_c, 0x22); op0(&main_c, 0x24);    /* → 42 */
    op_u16(&main_c, 0x02, 8);                  /* CONST 8（"end"） */
    op_u16(&main_c, 0x21, 8);                  /* SHOW_TEXT */
    op0(&main_c, 0x24);                        /* SHOW_END */
    op0(&main_c, 0x32);                        /* RET_NONE */

    emit(&b, "PYBC", 4);
    eu32(&b, 1);
    eu32(&b, 9);                 /* 常量数：0,3,21,7,8,9,2,99,"end" */
    eu32(&b, 2);                 /* 函数数 */
    c_int(&b, 0);
    c_int(&b, 3);
    c_int(&b, 21);
    c_int(&b, 7);
    c_int(&b, 8);
    c_int(&b, 9);
    c_int(&b, 2);
    c_int(&b, 99);
    c_str(&b, "end");
    /* 代码偏移相对代码区起点：fn0 从 0 开始，fn1 紧随 fn0 */
    fnent(&b, 0, 0, 4, 0, (uint32_t)main_c.len);
    fnent(&b, 0, 1, 1, (uint32_t)main_c.len, (uint32_t)dbl_c.len);
    emit(&b, main_c.b, main_c.len);
    emit(&b, dbl_c.b, dbl_c.len);
    free(main_c.b);
    free(dbl_c.b);
    return b;
}

/* ---- 模块 3：GOLD 后再赋值 → 运行时错误: 变量已锁定 ---- */
static Buf build_module3(void)
{
    Buf b = { 0 };
    Buf code = { 0 };
    op_u16(&code, 0x02, 0);   /* CONST 0（int 1） */
    op_u16(&code, 0x04, 0);   /* STORE 0 */
    op_u16(&code, 0x33, 0);   /* GOLD 0 */
    op_u16(&code, 0x02, 0);   /* CONST 0 */
    op_u16(&code, 0x04, 0);   /* STORE 0 → 报错退出 */
    emit(&b, "PYBC", 4);
    eu32(&b, 1); eu32(&b, 1); eu32(&b, 1);
    c_int(&b, 1);
    fnent(&b, 0, 0, 1, 0, (uint32_t)code.len);   /* 代码偏移相对代码区起点 */
    emit(&b, code.b, code.len);
    free(code.b);
    return b;
}

/* ---- 模块 4：DEL 后再读 → 运行时错误: 用已删除变量 ---- */
static Buf build_module4(void)
{
    Buf b = { 0 };
    Buf code = { 0 };
    op_u16(&code, 0x02, 0);   /* CONST 0 */
    op_u16(&code, 0x04, 0);   /* STORE 0 */
    op_u16(&code, 0x34, 0);   /* DEL 0 */
    op_u16(&code, 0x03, 0);   /* LOAD 0 → 报错退出 */
    emit(&b, "PYBC", 4);
    eu32(&b, 1); eu32(&b, 1); eu32(&b, 1);
    c_int(&b, 1);
    fnent(&b, 0, 0, 1, 0, (uint32_t)code.len);   /* 代码偏移相对代码区起点 */
    emit(&b, code.b, code.len);
    free(code.b);
    return b;
}

/* ---- stdout 捕获 ---- */

static FILE *s_tmp;
static int s_saved_fd;

static void capture_start(void)
{
    fflush(stdout);
    s_saved_fd = dup(1);
    s_tmp = tmpfile();
    dup2(fileno(s_tmp), 1);
}

static void capture_finish(char *buf, size_t cap)
{
    fflush(stdout);
    dup2(s_saved_fd, 1);
    close(s_saved_fd);
    rewind(s_tmp);
    size_t n = fread(buf, 1, cap - 1, s_tmp);
    buf[n] = '\0';
    fclose(s_tmp);
}

static int g_fails = 0;

static void check(int cond, const char *name)
{
    if (cond)
        printf("[通过] %s\n", name);
    else {
        printf("[失败] %s\n", name);
        g_fails++;
    }
}

/* Windows 文本模式 stdout 会把 \n 写成 \r\n；比对前把 \r 去掉，期望串里只写 \n */
static void strip_cr(char *s)
{
    char *w = s, *r = s;
    while (*r) {
        if (*r != '\r')
            *w++ = *r;
        r++;
    }
    *w = '\0';
}

/* 报错分支验证：拉起自身 "child N"，确认退出码 1 */
static void expect_die(const char *argv0, const char *kase, const char *name)
{
    char exe[512], cmd[1100];
    snprintf(exe, sizeof exe, "%s", (argv0 && *argv0) ? argv0 : "pyvm_test");
    for (char *p = exe; *p; p++)
        if (*p == '/')
            *p = '\\';   /* system() 走 cmd.exe，需要 Windows 路径分隔符 */
    snprintf(cmd, sizeof cmd, "\"%s\" %s", exe, kase);
    fflush(stdout);
    fflush(stderr);
    int rc = system(cmd);
    if (rc == 1)
        printf("[通过] %s\n", name);
    else {
        printf("[失败] %s（退出码 %d，预期 1）\n", name, rc);
        g_fails++;
    }
}

static void run_buf(const Buf *b) { run_module(b->b, b->len); }

int main(int argc, char **argv)
{
    Buf m1 = build_module1();
    Buf m2 = build_module2();
    Buf m3 = build_module3();
    Buf m4 = build_module4();

    /* 子进程模式：跑指定模块，必然报错 exit(1) */
    if (argc > 1 && strcmp(argv[1], "child") == 0 && argc > 2) {
        if (strcmp(argv[2], "3") == 0)
            run_buf(&m3);
        else if (strcmp(argv[2], "4") == 0)
            run_buf(&m4);
        printf("子进程没有触发错误！\n");
        return 3;
    }
    /* dump 模式：把样例模块写成 .pybc，供命令行版 pyvm.exe 实测 */
    if (argc > 1 && strcmp(argv[1], "dump") == 0) {
        struct { const char *name; const Buf *b; } out[] = {
            { "test42.pybc", &m1 }, { "test_full.pybc", &m2 },
            { "test_locked.pybc", &m3 }, { "test_del.pybc", &m4 },
        };
        for (size_t i = 0; i < sizeof out / sizeof out[0]; i++) {
            FILE *fp = fopen(out[i].name, "wb");
            if (!fp) {
                fprintf(stderr, "写 %s 失败\n", out[i].name);
                return 1;
            }
            fwrite(out[i].b->b, 1, out[i].b->len, fp);
            fclose(fp);
            printf("写出 %s（%zu 字节）\n", out[i].name, out[i].b->len);
        }
        return 0;
    }
    /* 文件模式：自测构建同样可以直接跑 .pybc 文件 */
    if (argc > 1) {
        size_t len = 0;
        uint8_t *img = read_file(argv[1], &len);
        if (!img) {
            fprintf(stderr, "虚拟机错误: 无法读取文件 %s\n", argv[1]);
            return 1;
        }
        run_module(img, len);
        return 0;
    }

    /* ---- 合同要求的最小自测：应打印 42 ---- */
    {
        char got[64];
        capture_start();
        run_buf(&m1);
        capture_finish(got, sizeof got);
        strip_cr(got);
        /* 本行未用过 magic，rt_show_end 不发 \033[0m 重置序列 */
        check(strcmp(got, "42\n") == 0,
              "模块1：CONST/CONST/ADD/SHOW_VALUE/HALT 打印 42（VM 停机时刷出挂起行）");
    }

    /* ---- 综合：列表 + 循环 + 调用 ---- */
    {
        char got[512];
        capture_start();
        run_buf(&m2);
        capture_finish(got, sizeof got);
        strip_cr(got);
        const char *want = "3\n"
                           "7\n"
                           "99\n"
                           "0\n"
                           "1\n"
                           "2\n"
                           "42\n"
                           "end\n";
        check(strcmp(got, want) == 0, "模块2：列表/LEN/INDEX/SETIDX/循环/调用/文本");
    }

    /* ---- 报错分支（子进程，stderr 出现对应"运行时错误: ..."） ---- */
    expect_die(argv[0], "child 3", "模块3：GOLD 后赋值 → 变量已锁定");
    expect_die(argv[0], "child 4", "模块4：DEL 后读取 → 用已删除变量");

    if (g_fails == 0)
        printf("自测全部通过。\n");
    else
        printf("自测失败 %d 项。\n", g_fails);
    return g_fails ? 1 : 0;
}

#endif /* PYVM_SELF_TEST */
