﻿# -*- coding: utf-8 -*-
"""_gpfma_gen.py -- 生成不同 FMA 链数的 FP32 上限内核，每个都自带校验量。

==============================================================================
这个工具为什么长成这样：它是为了推翻我自己之前测出来的数字
==============================================================================
    我原来有个 fma_peak，8 条「独立」FMA 链，报 3.44~4.27 TFLOPS。
    可 GTX 1060 是 640 个 FP32 核，驱动报告频率 1.708 GHz，
    理论上限 = 10 SM x 64 x 2 x 1.708 GHz = **2.19 TFLOPS**。
    **测出来的比理论还高** —— 这种数只能是错的，不是卡变强了。
    这和之前那次 13.8 TB/s 的假带宽是同一个失败模式：
    算出了漂亮数字，却没验「活是不是真干了」。

    真因：原来 8 条链全是 fma(%f1, %f2, %fN)，累加器都从 0 开始，
    **编译器可以证明这 8 条链恒等，于是只保留一条**。
    所谓「8 条独立链」从一开始就是假的，实际只跑了 1 条依赖链。
    按 1 条算，3.48 TFLOPS 的真实值其实是 **0.44 TFLOPS** ——
    一条依赖链、纯延迟受限，恰好印证了「每个调度器至少要 4 条
    互不依赖的链才喂得饱」那个硬件常识。

    修法：每条链给**自己的乘数**，恒等性就无法证明，nc 条链才真是 nc 条。
    光修这个还不够 —— 必须让机器能发现它又塌回去，所以再加一道自检：
    **各链累加值必须两两不同**（见 _gplimit.c 的自检四）。

链数为什么还是可调参数：
    FMA 延迟约 4 时钟、每调度器每时钟发 1 条，喂饱一个调度器要 >= 4 条
    独立链；SM 上有 4 个调度器，所以要 16 条才可能满载。
    1/2/4/8/16/32 全扫一遍，看拐点在哪。

转义规矩（踩过一次）：只有真正套用了 % 格式化的行才写 %%。
    %% 只在 % 运算里才还原成 %，不套格式化的行写 %% 会原样留在 PTX 里，
    于是文件里全是 %%r1 / %%p1。文件末尾有守卫：产物出现 %% 直接报错。

RULE 3（_bwrule.py 二分钉死的）：%tid/%ctaid/%ntid/%nctaid 不能直接
    当算术操作数，必须先 mov 进普通寄存器。

注释一律纯 ASCII —— 中文字符会让 JIT 失败且不给任何提示。
"""
import io
import os
import sys

OUT = "_ptx_FMA%d.ptx"
CHAIN_LIST = [1, 2, 4, 8, 16, 32]

HEAD = """.version 6.5
.target sm_61
.address_size 64
"""


def fail(msg):
    sys.stderr.write("生成失败：%s\n" % msg)
    sys.exit(1)


def build(nc):
    """nc = 独立 FMA 链数。"""
    if nc < 1:
        fail("链数 %d 太小" % nc)

    # 寄存器布局（.reg 数组 0 编号）
    #   %f1             共享乘数 a = 1.0000001
    #   %f2 .. %f(nc+1) 每条链各自不同的乘数 b_i
    #   %f(nc+2) ..     各链累加器
    #   倒数第二个        循环计数器
    #   最后一个          网格探针（只由 block 0 写）
    b_lo = 2
    acc_lo = b_lo + nc
    ctr = acc_lo + nc
    nreg = ctr + 2

    def bval(i):
        # 必须是 0f 前缀！PTX 的浮点字面量写成 0x3F7FFFEE 会被 JIT 拒，
        # 而报的还是那句没信息量的话。
        return "0f%08X" % (0x3F7FFFEE - i * 13)

    L = []
    L.append(HEAD)
    L.append("// FP32 ceiling yardstick: %d GENUINELY independent FMA chains." % nc)
    L.append("//")
    L.append("// Each chain owns its multiplier on purpose. With a shared multiplier and")
    L.append("// all accumulators starting at 0, the chains are provably equal and the")
    L.append("// compiler collapses them into one -- which is exactly how the old")
    L.append("// fma_peak came to claim 3.48 TFLOPS on a card whose ceiling at the")
    L.append("// reported 1.708 GHz is 2.19 TFLOPS. A number above the theoretical peak")
    L.append("// is a bug, not a fast card.")
    L.append("//")
    L.append("// Host checks: loop count == requested, grid size matches, and every")
    L.append("// accumulator is pairwise distinct (equal ones mean the chains were")
    L.append("// merged again).")
    L.append("//")
    L.append("// ASCII comments only -- Chinese characters make the JIT fail.")
    L.append(".visible .entry fma_peak(")
    L.append("    .param .u64 p_out,")
    L.append("    .param .u32 p_iter")
    L.append(")")
    L.append("{")
    L.append("    .reg .pred %p<4>;")
    L.append("    .reg .b32  %r<8>;")
    L.append("    .reg .b64  %rd<8>;")
    # .reg 数组 0 编号：声明 N 个只能用到 %f<N-1>，所以多给一个。
    L.append("    .reg .f32  %%f<%d>;" % (nreg + 1))
    L.append("")
    L.append("    ld.param.u64 %rd1, [p_out];")
    L.append("    ld.param.u32 %r1, [p_iter];")
    L.append("    cvta.to.global.u64 %rd2, %rd1;")
    L.append("")
    # 这条探针栽了三次：%ctaid.x 直接进 mul 编不过（RULE 3）；
    # 以为 %ctaid.x 是网格大小（其实 %nctaid.x 才是）；改成只让 block 0 写之后
    # 值恒为 0，因为 block 0 的 blockIdx 本来就是 0。
    L.append("    mov.u32 %r6, %ctaid.x;       // blockIdx.x, only used to gate the probe")
    L.append("    setp.eq.u32 %p2, %r6, 0;   // only block 0 may write the probe")
    L.append("    @!%p2 bra SKIPPROBE;")
    L.append("    mov.u32 %r7, %nctaid.x;     // gridDim.x  (NOT %ctaid.x)")
    L.append("    mov.u32 %r5, %ntid.x;       // blockDim.x")
    L.append("    mul.lo.u32 %r6, %r7, %r5;   // total threads in the grid")
    L.append("")
    L.append("    mov.f32 %f1, 0f3F800001;     // shared operand a = 1.0000001")
    for i in range(nc):
        L.append("    mov.f32 %%f%d, %s;   // chain %d: own multiplier"
                 % (b_lo + i, bval(i), i))
    for i in range(nc):
        L.append("    mov.f32 %%f%d, 0f00000000;" % (acc_lo + i))
    L.append("    mov.u32 %r2, 0;")
    L.append("LOOP:")
    for i in range(nc):
        L.append("    fma.rn.f32 %%f%d, %%f1, %%f%d, %%f%d;"
                 % (acc_lo + i, b_lo + i, acc_lo + i))
    L.append("    add.s32 %r2, %r2, 1;")
    L.append("    setp.lt.s32 %p1, %r2, %r1;")
    L.append("    @%p1 bra LOOP;")
    L.append("")
    for i in range(nc):
        L.append("    st.global.f32 [%%rd2+%d], %%f%d;" % (4 * i, acc_lo + i))
    L.append("    cvt.rn.f32.s32 %%f%d, %%r2;" % ctr)
    L.append("    st.global.f32 [%%rd2+%d], %%f%d;" % (4 * (nc + 1), ctr))
    L.append("    cvt.rn.f32.s32 %%f%d, %%r6;" % (ctr + 1))
    L.append("    st.global.f32 [%%rd2+%d], %%f%d;" % (4 * (nc + 2), ctr + 1))
    L.append("SKIPPROBE:")
    L.append("    ret;")
    L.append("}")

    text = "\n".join(L) + "\n"
    for i, l in enumerate(L):
        if any(ord(c) > 127 for c in l):
            fail("第 %d 行有非 ASCII 字符：%s" % (i + 1, l.strip()))
        if "%%" in l:
            fail("第 %d 行还留着 %%%%：%s" % (i + 1, l.strip()))

    path = OUT % nc
    with io.open(path, "w", encoding="ascii", newline="\n") as f:
        f.write(text)
    return path, nc, acc_lo, b_lo


def main():
    for nc in CHAIN_LIST:
        path, nc, acc_lo, b_lo = build(nc)
        print("生成 %-16s %2d 条链，各链独立乘数 %s..%s，累加器 %s..%s"
              % (path, nc, "0f%08X" % 0x3F7FFFEE,
                 "0f%08X" % (0x3F7FFFEE - (nc - 1) * 13),
                 "%%f%d" % acc_lo, "%%f%d" % (acc_lo + nc - 1)))
    print("\n宿主自检：out[%d]=实跑轮数  out[%d]=网格线程数  out[0..%d]=各链累加值（须两两不同）"
          % (CHAIN_LIST[0] + 1, CHAIN_LIST[0] + 2, CHAIN_LIST[-1] - 1))


if __name__ == "__main__":
    main()
