## 项目
name: 我的数学包
version: 1.2.0

## 依赖
- 基础包 => (registry) @1.0.0
