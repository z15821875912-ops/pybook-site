## 项目
name: 基础包
version: 1.0.0
