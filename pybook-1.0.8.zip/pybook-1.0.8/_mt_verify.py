# -*- coding: utf-8 -*-
"""_mt_verify.py — 把 PYbook 跑出来的 28 个值逐个与 Python math 对拍。

不做「看着像就行」的目测：解析 PYbook 的输出，逐项与 math 算出来对比，
按相对误差判过。绝对精确相等的（整数结果、0/1/-1）单独列出来。
"""
import io, math, re, subprocess, sys

p = subprocess.run([sys.executable, '-B', 'main.py', '_mt_t1.pybk'],
                   capture_output=True, text=True, encoding='utf-8',
                   errors='replace', timeout=300)
if p.returncode != 0:
    print('PYbook 运行失败:\n' + p.stderr)
    sys.exit(1)

got = {}
for line in p.stdout.replace('\r\n', '\n').split('\n'):
    if '=' not in line:
        continue
    k, v = line.split('=', 1)
    got[k.strip()] = v.strip()

# 名字 -> (Python math 里的值, 说明)
EXPECT = {
    'exp1':        (math.exp(1),                  'e'),
    'exp0':        (math.exp(0),                  'e^0=1'),
    'expm1小':      (math.expm1(1e-6),             'e^x-1，x 极小时用它而不是 exp(x)-1'),
    'log_e':       (math.log(math.e),              'ln(e)=1'),
    'log2_1024':   (math.log2(1024),               'log2'),
    'log10_1000':  (math.log10(1000),             'log10'),
    'log1p小':      (math.log1p(1e-6),             'log(1+x)，x 极小时用它而不是 log(1+x)'),
    'asin半':       (math.asin(0.5),               'π/6'),
    'acos零':       (math.acos(0.0),               'π/2'),
    'atan一':       (math.atan(1.0),               'π/4'),
    'sinh一':       (math.sinh(1.0),               ''),
    'cosh零':       (math.cosh(0.0),               '=1'),
    'tanh一':       (math.tanh(1.0),               ''),
    'asinh一':      (math.asinh(1.0),              ''),
    'acosh一':      (math.acosh(1.0),              '=0'),
    'atanh半':      (math.atanh(0.5),              'ln(√3)/2'),
    'cbrt负27':     (float(np_cbrt := round(math.copysign(abs(-27) ** (1/3), -1))), '负数立方根（pow 会给 NaN）'),
    'cbrt27':      (27.0 ** (1/3),                ''),
    'hypot34':     (math.hypot(3.0, 4.0),         '3-4-5'),
    'trunc负':      (math.trunc(-2.7),             '向零取整'),
    'trunc正':      (math.trunc(2.7),              '向零取整'),
    'sign负':       (-1.0,                         ''),
    'sign零':       (0.0,                          ''),
    'sign正':       (1.0,                          ''),
    'fmod截断':     (math.fmod(-7.0, 3.0),         'C 语义：向 0 截断'),
    'mod向下':      (float(-7 % 3 if False else ((-7) % 3)), 'Python 语义：向 -∞ 取整'),
    'exp溢出是无穷': (float('inf'),                 'e^1000 溢出'),
    '无穷减无穷是NaN': (float('nan'),               'inf-inf'),
    '有限不是无穷':  (0.0,                          ''),
    '有限不是NaN':  (0.0,                          ''),
}

# 布尔项单独判
BOOL = {'exp溢出是无穷': True, '无穷减无穷是NaN': True,
        '有限不是无穷': False, '有限不是NaN': False}

bad, exact, close = [], 0, 0
for name, (ref, note) in EXPECT.items():
    if name not in got:
        bad.append('%s: PYbook 没输出这一项' % name)
        continue
    if name in BOOL:
        want = 'true' if BOOL[name] else 'false'
        if got[name] != want:
            bad.append('%s: 期望 %s 实际 %s' % (name, want, got[name]))
        else:
            exact += 1
        continue
    g = float(got[name])
    if math.isnan(ref):
        if got[name] != 'NaN' and not math.isnan(g):
            bad.append('%s: 期望 NaN 实际 %s' % (name, got[name]))
        else:
            exact += 1
        continue
    if ref == g:
        exact += 1
        continue
    denom = max(abs(ref), abs(g), 1e-300)
    rel = abs(ref - g) / denom
    if rel <= 1e-14:
        close += 1
    else:
        bad.append('%s: PYbook=%r Python=%r 相对误差=%.3e %s'
                   % (name, g, ref, rel, note))

print('对拍 %d 项：逐位相同 %d，相对误差 <=1e-14 %d，不合格 %d'
      % (len(EXPECT), exact, close, len(bad)))
for b in bad:
    print('  ✗ ' + b)
sys.exit(1 if bad else 0)
