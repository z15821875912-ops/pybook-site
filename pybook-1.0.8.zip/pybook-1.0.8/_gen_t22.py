# -*- coding: utf-8 -*-
"""_gen_t22.py — 往 tests/cases.py 追加 T22_* 回归用例（特殊函数 / 一维极值 / 插值拟合）

家法照 T18/T21：浮点一律用语言内的 接近() 容差比较并打印通过标记，
不比对 %.15g 的打印串（差 1 个 ULP 时 %.15g 会从 0.6 变成 0.599999999999999，
那样写用例只是在锁运气）。已存在则跳过，可重跑。
"""
import io

P = 'tests/cases.py'
t = io.open(P, encoding='utf-8', newline='').read()
e = '\r\n' if '\r\n' in t else '\n'

MARK = '# ── T22 特殊函数 / 一维极值 / 插值拟合'

# 先剥离上一次追加的块（第一次跑之前没有，字符串 index 会抛错 -> 跳过）。
# 这样脚本既能自愈上一次写坏的结果，也能重跑。
if MARK in t:
    t = t[:t.index(MARK)].rstrip() + '\n'
    print('已剥离上次追加的 T22 块')

if "T22_special_ok" in t:
    print('cases.py 已有 T22_*，跳过')
    raise SystemExit(0)

# 接近() 的容差比 T18 用的 1e-6 紧：这批函数实测误差都在 1e-13 量级，
# 用 1e-6 断言等于没断言。
def near(tol):
    return ('func 接近(a, b) {\n'
            '    vg.e = a - b\n'
            '    if(e < 0) {\n'
            '        vg.e = -e\n'
            '    }\n'
            '    ret e < %s\n'
            '}\n' % tol)


NEAR1 = near('0.000000000001')      # 1e-12：特殊函数 / 插值 / 拟合
NEAR8 = near('0.00000001')           # 1e-8：黄金分割受 tol 参数限制，默认 1e-10
#                                        只能给到 ~1e-9 的极值点精度，
#                                        用 1e-12 断言等于断言一个做不到的精度。

CASES = []

CASES.append({
    'id': 'T22_special_ok', 'kind': 'normal',
    'src': '@ pybk>测试>特殊函数\n' + NEAR1 + '''GOING:{
vg.g1 = mt.gamma(1)
vg.g5 = mt.gamma(5)
vg.g05 = mt.gamma(0.5)
vg.gm05 = mt.gamma(-0.5)
vg.lg1 = mt.lgamma(1)
vg.lg100 = mt.lgamma(100)
vg.e0 = mt.erf(0)
vg.e05 = mt.erf(0.5)
vg.e2 = mt.erf(2)
vg.emn2 = mt.erf(-2)
vg.c0 = mt.erfc(0)
vg.c2 = mt.erfc(2)
vg.cmn2 = mt.erfc(-2)
vg.c6 = mt.erfc(6)
vg.z2 = mt.zeta(2)
vg.z4 = mt.zeta(4)
vg.z10 = mt.zeta(10)
if(接近(e0, 0)) {
    ns.show(erf在0处为0)
}
if(接近(g1, 1)) {
    ns.show(gamma在1处为1)
}
if(接近(g5, 24)) {
    ns.show(gamma在5处为24)
}
if(接近(g05, 1.7724538509055159)) {
    ns.show(半根号派为1.7724538509)
}
if(接近(gm05, -3.5449077018110322)) {
    ns.show(负半的派为负3.5449077018)
}
if(接近(lg1, 0)) {
    ns.show(lgamma在1处为0)
}
if(接近(lg100, 359.1342053695754)) {
    ns.show(lgamma在100处为359.1342053696)
}
if(接近(e05, 0.5204998778130465)) {
    ns.show(erf在0.5处为0.5204998778)
}
if(接近(e2, 0.9953222650189527)) {
    ns.show(erf在2处为0.9953222650)
}
if(接近(emn2, -0.9953222650189527)) {
    ns.show(erf为奇函数)
}
if(接近(e05 + 0.479500122186953, 1)) {
    ns.show(erf与erfc互补为一)
}
if(接近(c0, 1)) {
    ns.show(erfc在0处为1)
}
if(接近(c2, 0.004677734981047266)) {
    ns.show(erfc在2处为0.0046777350)
}
if(接近(cmn2, 1.9953222650189527)) {
    ns.show(erfc负半满足二减关系)
}
if(接近(c6, 0.00000000000000002151973671249867)) {
    ns.show(erfc在6处为2.15e-17)
}
if(接近(z2, 1.6449340668482264)) {
    ns.show(zeta二为圆周率平方除以六)
}
if(接近(z4, 1.0823232337111382)) {
    ns.show(zeta四为圆周率四次方除以九十)
}
if(接近(z10, 1.0009945751278181)) {
    ns.show(zeta十为1.0009945751)
}
}STOP
''',
    'out': ('erf在0处为0\ngamma在1处为1\ngamma在5处为24\n半根号派为1.7724538509\n'
            '负半的派为负3.5449077018\nlgamma在1处为0\nlgamma在100处为359.1342053696\n'
            'erf在0.5处为0.5204998778\nerf在2处为0.9953222650\nerf为奇函数\n'
            'erf与erfc互补为一\nerfc在0处为1\nerfc在2处为0.0046777350\n'
            'erfc负半满足二减关系\nerfc在6处为2.15e-17\nzeta二为圆周率平方除以六\n'
            'zeta四为圆周率四次方除以九十\nzeta十为1.0009945751\n'),
    'err': '', 'err_contains': [], 'exit': 0,
    'expect': '特殊函数：gamma/lgamma/erf/erfc/zeta 全部走语言内接近() 容差断言（1e-12）'
              '，覆盖 erf 奇函数性、erfc 的 erfc(-x)=2-erfc(x)、zeta(2)=π²/6、zeta(4)=π⁴/90',
})

CASES.append({
    'id': 'T22_optimize_ok', 'kind': 'normal',
    'src': '@ pybk>测试>一维极值\n' + NEAR8 + '''GOING:{
vg.quad = lambda(x) { ret (x - 2) * (x - 2) + 1 }
vg.dome = lambda(x) { ret 10 - (x - 3) * (x - 3) }
vg.sine = lambda(x) { ret mt.sin(x) }
vg.gmin = mt.golden_min(quad, 0, 5)
vg.gminT = mt.golden_min(quad, 0, 5, 0.000001)
vg.gminRev = mt.golden_min(quad, 5, 0)
vg.gmax = mt.golden_max(dome, 0, 10)
vg.gmaxS = mt.golden_max(sine, 0, 3.1415923267948966)
vg.零宽 = mt.golden_min(quad, 2, 2)
vg.粗细差 = gminT - gmin
if(接近(gmin, 2)) {
    ns.show(抛物线极小在2)
}
if(接近(gmax, 3)) {
    ns.show(倒抛物线极大在3)
}
if(接近(gmaxS, 1.5707963267948966)) {
    ns.show(正弦极大在二分之派)
}
if(接近(gminRev, gmin)) {
    ns.show(端点写反结果相同)
}
if(粗细差 < 0.001) {
    ns.show(容差越大结果越粗)
}
if(接近(零宽, 2)) {
    ns.show(零宽区间返回该点)
}
}STOP
''',
    'out': ('抛物线极小在2\n倒抛物线极大在3\n正弦极大在二分之派\n端点写反结果相同\n'
            '容差越大结果越粗\n零宽区间返回该点\n'),
    'err': '', 'err_contains': [], 'exit': 0,
    'expect': '黄金分割：抛物线/倒抛物线/正弦的极值点都落在真值上；端点写反结果一致；'
              '容差变大结果变粗（说明可选参数 tol 真的起作用）；零宽区间不崩。'
              '容差用 1e-8 不是 1e-12：黄金分割默认 tol=1e-10，'
              '极值点精度本来就在 1e-9 量级，断言 1e-12 是在断言一个做不到的精度',
})

CASES.append({
    'id': 'T22_interp_ok', 'kind': 'normal',
    'src': '@ pybk>测试>插值与直线拟合\n' + NEAR1 + '''GOING:{
vg.横 = [0, 1, 2, 3]
vg.平 = [0, 1, 4, 9]
vg.立 = [0, 1, 8, 27]
vg.l05 = mp.interp_linear(横, 平, 0.5)
vg.l25 = mp.interp_linear(横, 平, 2.5)
vg.lLo = mp.interp_linear(横, 平, -5)
vg.lHi = mp.interp_linear(横, 平, 99)
vg.c15 = mp.interp_cubic(横, 立, 1.5)
vg.cLo = mp.interp_cubic(横, 平, -5)
vg.cHi = mp.interp_cubic(横, 平, 99)
vg.l2 = mp.interp_linear([1, 3], [10, 20], 2)
vg.格 = [0, 1, 2.5, 4, 9]
vg.值 = [1, 2, 3, 4, 5]
vg.lu = mp.interp_linear(格, 值, 1.25)
vg.lf = mp.linfit([1, 2, 3, 4], [2.1, 4.05, 5.9, 8.1])
vg.斜率 = lf[0]
vg.截距 = lf[1]
vg.r2 = lf[2]
if(接近(l05, 0.5)) {
    ns.show(线性插值首段中点)
}
if(接近(l25, 6.5)) {
    ns.show(线性插值末段中点)
}
if(接近(lLo, 0)) {
    ns.show(线性插值越界夹到首端)
}
if(接近(lHi, 9)) {
    ns.show(线性插值越界夹到末端)
}
if(接近(l2, 15)) {
    ns.show(两点也能插值)
}
if(接近(lu, 2.1666666666666665)) {
    ns.show(不等距线性插值)
}
if(接近(c15, 3.375)) {
    ns.show(三次插值中点还原立方)
}
if(接近(cLo, 0)) {
    ns.show(三次插值越界夹到首端)
}
if(接近(cHi, 9)) {
    ns.show(三次插值越界夹到末端)
}
if(接近(斜率, 1.985)) {
    ns.show(直线拟合斜率)
}
if(接近(截距, 0.075)) {
    ns.show(直线拟合截距)
}
if(接近(r2, 0.998694674143776)) {
    ns.show(直线拟合决定系数)
}
}STOP
''',
    'out': ('线性插值首段中点\n线性插值末段中点\n线性插值越界夹到首端\n线性插值越界夹到末端\n'
            '两点也能插值\n不等距线性插值\n三次插值中点还原立方\n三次插值越界夹到首端\n'
            '三次插值越界夹到末端\n直线拟合斜率\n直线拟合截距\n直线拟合决定系数\n'),
    'err': '', 'err_contains': [], 'exit': 0,
    'expect': '插值：线性/三次在末段与越界处都正确（末段曾因二分查找上界写错而整段算错，'
              '越界曾外推成 489）；不等距点也对；linfit 给 [斜率, 截距, r²]',
})

CASES.append({
    'id': 'T22_polyfit_ok', 'kind': 'normal',
    'src': '@ pybk>测试>多项式拟合\n' + NEAR1 + '''GOING:{
vg.c2 = mp.polyfit([0, 1, 2, 3, 4], [0, 1, 4, 9, 16], 2)
vg.c2s = mp.polyfit([10, 11, 12, 13], [100, 121, 144, 169], 2)
vg.c1 = mp.polyfit([1, 2, 3, 4, 5], [2, 5, 10, 17, 26], 1)
vg.零 = c2[0]
vg.一 = c2[1]
vg.二 = c2[2]
vg.平移零 = c2s[0]
vg.平移一 = c2s[1]
vg.平移二 = c2s[2]
vg.线零 = c1[0]
vg.线一 = c1[1]
if(接近(二, 1)) {
    ns.show(拟合平方得二次系数1)
}
if(接近(一, 0)) {
    ns.show(拟合平方得一次系数0)
}
if(接近(零, 0)) {
    ns.show(拟合平方得常数项0)
}
if(接近(平移二, 1)) {
    ns.show(横轴平移后二次系数仍为1)
}
if(接近(平移零, 0)) {
    ns.show(横轴平移后常数项仍为0)
}
if(接近(线一, 6)) {
    ns.show(一次拟合斜率6)
}
if(接近(线零, -6)) {
    ns.show(一次拟合截距负6)
}
}STOP
''',
    'out': ('拟合平方得二次系数1\n拟合平方得一次系数0\n拟合平方得常数项0\n横轴平移后二次系数仍为1\n'
            '横轴平移后常数项仍为0\n一次拟合斜率6\n一次拟合截距负6\n'),
    'err': '', 'err_contains': [], 'exit': 0,
    'expect': 'polyfit 返回**原始 x 的幂**的系数（不是中心化基底的）：横轴平移到 10~13 '
              '拟合 x²，常数项仍应为 0；一次拟合斜率 6、截距 -6',
})

CASES.append({
    'id': 'T22_zeta_div_err', 'kind': 'error',
    'src': '@ pybk>测试>zeta发散\nGOING:{\nvg.z = mt.zeta(1)\n}STOP',
    'out': '', 'exit': 1,
    'err_contains': ['级数发散', '为什么：', '怎么改：', '程序异常退出，退出码 1'],
    'expect': 'mt.zeta(s<=1) → 级数发散，报三段式而不是给一个 ±inf 让用户自己猜',
})

CASES.append({
    'id': 'T22_interp_unsorted_err', 'kind': 'error',
    'src': '@ pybk>测试>插值点未排序\nGOING:{\nvg.v = mp.interp_linear([0, 2, 1, 3], [0, 1, 2, 3], 1.5)\n}STOP',
    'out': '', 'exit': 1,
    'err_contains': ['采样点必须严格递增', '第 2 个', '为什么：', '怎么改：', '程序异常退出，退出码 1'],
    'expect': '采样点乱序 → 显式报错并指出**第一个逆序下标**（点序乱了二分会静默插到错误的段上）',
})

CASES.append({
    'id': 'T22_polyfit_deg_err', 'kind': 'error',
    'src': '@ pybk>测试>拟合次数越界\nGOING:{\nvg.c = mp.polyfit([0, 1, 2], [0, 1, 4], 20)\n}STOP',
    'out': '', 'exit': 1,
    'err_contains': ['超出 0~12', '为什么：', '怎么改：', '程序异常退出，退出码 1'],
    'expect': 'mp.polyfit 次数越界 → 三段式报错并解释高次拟合的病态性',
})

CASES.append({
    'id': 'T22_polyfit_sample_err', 'kind': 'error',
    'src': '@ pybk>测试>拟合样本不足\nGOING:{\nvg.c = mp.polyfit([0, 1], [0, 1], 3)\n}STOP',
    'out': '', 'exit': 1,
    'err_contains': ['个样本拟合', '不够', '为什么：', '怎么改：', '程序异常退出，退出码 1'],
    'expect': 'mp.polyfit 样本数少于次数+1 → 三段式报错',
})

CASES.append({
    'id': 'T22_linfit_flat_err', 'kind': 'error',
    'src': '@ pybk>测试>横轴全同\nGOING:{\nvg.f = mp.linfit([2, 2, 2], [1, 3, 5])\n}STOP',
    'out': '', 'exit': 1,
    'err_contains': ['所有 x 都一样', '为什么：', '怎么改：', '程序异常退出，退出码 1'],
    'expect': 'mp.linfit 的 x 全一样 → 报「画不出直线」而不是静默给 0',
})

CASES.append({
    'id': 'T22_notlist_err', 'kind': 'error',
    'src': '@ pybk>测试>插值要列表\nGOING:{\nvg.v = mp.interp_linear(5, [0, 1], 0.5)\n}STOP',
    'out': '', 'exit': 1,
    'err_contains': ['需要列表参数', '为什么：', '怎么改：', '程序异常退出，退出码 1'],
    'expect': '插值/拟合的采样点不是列表 → 明确报错（漏掉 AS_INT(rt_len) 时这里会变成 '
              '"内存不足"，是 list 拆包失败的典型症状）',
})


def esc(v):
    # 就用 repr：它已经把换行写成 \n、单引号写成 \'，再手工转义反斜杠会把
    # \n 变成字面的「反斜杠 + n」，cases.py 直接 SyntaxError。
    return repr(v)


blocks = ['\n# ── T22 特殊函数 / 一维极值 / 插值拟合（pybook_lib.c，'
          '对拍 CPython math 与 numpy 1e-13 量级）──\n']
for c in CASES:
    # 报错用例**整个省掉 'err' 键**（runner 对它是独立精确比对的，不看
    # err_contains 有没有内容）。写成 'err': '' 会变成「stderr 必须等于空串」，
    # 于是哪怕 err_contains 全中也会判失败——T03 那批用例就是不带 err 的。
    parts = ["'id': %s" % esc(c['id']),
             "'kind': %s" % esc(c['kind']),
             "'src': %s" % esc(c['src']),
             "'out': %s" % esc(c.get('out', '')),
             "'err_contains': %s" % c['err_contains'],
             "'exit': %s" % c['exit'],
             "'expect': %s" % esc(c['expect'])]
    if 'err' in c:
        parts.insert(4, "'err': %s" % esc(c['err']))
    blocks.append("case(**{%s})\n" % ', '.join(parts))

t = t + ''.join(blocks)
io.open(P, 'w', encoding='utf-8', newline='').write(t)
print('已追加 %d 个 T22_* 用例' % len(CASES))
