# Char-style per-frame cost, differential method.
# Absolute timings are NOT comparable across runs (dynamic boost + other processes);
# only the difference between two runs in the SAME session is meaningful.
# Same exe, same .pybk, only PYBOOK_FRAME_LIMIT changes:
#   (T2 - T1) / (F2 - F1) = per-frame cost. Build time is constant and cancels out.
# NOTE: this file must stay pure ASCII -- PowerShell 5.1 reads BOM-less UTF-8
#       as ANSI and mangles non-ASCII, which breaks parsing.
$ErrorActionPreference = 'Continue'
$env:PYTHONIOENCODING = "utf-8"
Remove-Item Env:\PYBOOK_SHOT_DIR -ErrorAction SilentlyContinue
Remove-Item Env:\PYBOOK_SHOT_EVERY -ErrorAction SilentlyContinue
Remove-Item Env:\PYBOOK_SHOT_MAX -ErrorAction SilentlyContinue

$app = $args[0]
if (-not (Test-Path $app)) { Write-Output "missing $app"; exit 1 }

function Run-N($n) {
    $env:PYBOOK_FRAME_LIMIT = "$n"
    $sw = [Diagnostics.Stopwatch]::StartNew()
    & ".\$app" 2>&1 | Out-Null
    $sw.Stop()
    return $sw.Elapsed.TotalSeconds
}

Write-Output "== interleaved rounds (3) =="
$d = @()
for ($k = 0; $k -lt 3; $k++) {
    $t1 = Run-N 100
    $t2 = Run-N 300
    $ms = ($t2 - $t1) * 1000 / 200
    $d += $ms
    Write-Output ("  round {0}: F=100 {1:N3}s  F=300 {2:N3}s  delta {3:N3}s / 200 = {4:N3} ms/frame" -f `
        ($k + 1), $t1, $t2, ($t2 - $t1), $ms)
}
$mid = ($d | Sort-Object)[1]
Write-Output ("== median {0:N3} ms/frame  (rounds: {1}) ==" -f $mid, (($d | ForEach-Object { "{0:N3}" -f $_ }) -join ', '))
