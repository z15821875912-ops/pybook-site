# -*- coding: utf-8 -*-
"""列出一行（或一列）里所有"非背景"的 x 位置，用来核对框线是否对齐。
用法: python -B _lines.py <bmp> row 100 | col 444
"""
import sys, struct


def load(path):
    d = open(path, 'rb').read()
    off = struct.unpack_from('<I', d, 10)[0]
    w, h = struct.unpack_from('<ii', d, 18)
    flip = h > 0
    h = abs(h)
    bpp = struct.unpack_from('<H', d, 28)[0] // 8
    stride = ((w * bpp + 3) // 4) * 4
    return w, h, stride, off, d, flip


def main():
    path, mode, val = sys.argv[1], sys.argv[2], int(sys.argv[3])
    lo = int(sys.argv[4]) if len(sys.argv) > 4 else 0
    hi = int(sys.argv[5]) if len(sys.argv) > 5 else (10 ** 9)
    w, h, stride, off, d, flip = load(path)

    def px(x, y):
        row = (h - 1 - y) if flip else y
        i = off + row * stride + x * 3
        return (d[i + 2], d[i + 1], d[i])

    bg = px(0, h - 1)
    n = hi if mode == 'row' else h
    n = min(n, w if mode == 'row' else h)
    print(f'{mode}={val}  非背景点 (bg={bg[0]:02X}{bg[1]:02X}{bg[2]:02X})')
    out = []
    for i in range(lo, min(hi, n)):
        x, y = (i, val) if mode == 'row' else (val, i)
        if x >= w or y >= h:
            continue
        r, g, b = px(x, y)
        if abs(r - bg[0]) + abs(g - bg[1]) + abs(b - bg[2]) > 20:
            out.append((i, r, g, b))
    # 合并成段
    # ★ 必须连颜色一起判：只判下标连续会把相邻的异色并成一段，
    #   显示的却是第一颗像素的颜色 —— 看着像「这一整条都是这个颜色」，
    #   实际中间早就换了颜色。（2026-10 被这个坑带偏过一次，
    #   把「面板底没画」误判成「面板底画了但工具读错」。）
    segs = []
    for i, r, g, b in out:
        if segs and segs[-1][1] + 1 == i \
                and abs(segs[-1][2] - r) + abs(segs[-1][3] - g) + abs(segs[-1][4] - b) <= 12:
            segs[-1][1] = i
        else:
            segs.append([i, i, r, g, b])
    for a, b, r, g, bl in segs:
        tag = '主色' if (g > r + 24 and g > bl + 24) else ''
        print(f'  {a}..{b}  ({b - a + 1:3d}px)  #{r:02X}{g:02X}{bl:02X} {tag}')


main()
