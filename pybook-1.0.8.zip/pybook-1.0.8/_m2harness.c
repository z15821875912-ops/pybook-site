/* _m2harness.c — 绕开坏掉的 pybook_net.c，直接量 pybook_lib.c 里这批新函数。
 * 只链 pybook_rt.c + pybook_lib.c + mathplus.c，输出 name<TAB>value 供 Python 对拍。 */
#include <stdio.h>
#include <math.h>
#include "pybook_rt.h"

double lib_gamma(double z);
double lib_lgamma(double z);
double lib_erf(double x);
double lib_erfc(double x);
double lib_zeta(double s);
double mp_interp_linear_core(const double *x, const double *y, long long n, double q);
double mp_interp_cubic_core(const double *x, const double *y, long long n, double q);
Value rt_lib_mp_linfit(Value, Value);
Value rt_lib_mp_polyfit(Value, Value, Value);
Value rt_lib_mt_erf(Value);
Value rt_lib_mt_erfc(Value);
Value rt_lib_mt_gamma(Value);
Value rt_lib_mt_lgamma(Value);
Value rt_lib_mt_zeta(Value);

static void p(const char *k, double v) { printf("%s\t%.17g\n", k, v); }

static Value mklist(const double *a, long long n)
{
    Value l = rt_list_new();
    long long i;
    for (i = 0; i < n; i++) rt_push(&l, rt_float(a[i]));
    return l;
}

static void plist(const char *k, Value l, long long n)
{
    long long i;
    for (i = 0; i < n; i++) printf("%s[%lld]\t%.17g\n", k, i, AS_FLT(rt_index(l, rt_int(i))));
}

int main(void)
{
    double xs[6], ys[6];
    long long n;

    /* ---- 特殊函数：核层直接调 ---- */
    { double g[] = {0.5, 1.0, 1.5, 2.0, 5.0, 10.0, 20.0, 100.0, 0.001, 0.1, -0.5, -1.5, -4.5};
      long long i; char b[32];
      for (i = 0; i < (long long)(sizeof g / sizeof g[0]); i++) {
          sprintf(b, "gamma_%.4g", g[i]);  p(b, lib_gamma(g[i]));
          sprintf(b, "lgamma_%.4g", g[i]); p(b, lib_lgamma(g[i]));
      } }
    { double e[] = {0.0, 0.25, 0.5, 1.0, 1.5, 2.0, 3.0, 4.0, 6.0, -0.5, -2.0, -6.0};
      long long i; char b[32];
      for (i = 0; i < (long long)(sizeof e / sizeof e[0]); i++) {
          sprintf(b, "erf_%.4g", e[i]);   p(b, lib_erf(e[i]));
          sprintf(b, "erfc_%.4g", e[i]);  p(b, lib_erfc(e[i]));
      } }
    { double z[] = {2.0, 4.0, 5.0, 1.5, 1.1, 1.01, 1.001, 1.0001, 20.0, 50.0};
      long long i; char b[32];
      for (i = 0; i < (long long)(sizeof z / sizeof z[0]); i++) {
          sprintf(b, "zeta_%.6g", z[i]); p(b, lib_zeta(z[i]));
      } }

    /* ---- 绑定层（走 Value，顺便验 lib_unpack / AS_INT(rt_len) 修好了没有）---- */
    p("bind_erf_half", AS_FLT(rt_lib_mt_erf(rt_float(0.5))));
    p("bind_erfc_6",    AS_FLT(rt_lib_mt_erfc(rt_float(6.0))));
    p("bind_gamma_1",   AS_FLT(rt_lib_mt_gamma(rt_float(1.0))));
    p("bind_lgamma_100",AS_FLT(rt_lib_mt_lgamma(rt_float(100.0))));
    p("bind_zeta_2",    AS_FLT(rt_lib_mt_zeta(rt_float(2.0))));

    /* ---- 插值：核层 ---- */
    { double x[4] = {0, 1, 2, 3}, yq[4] = {0, 1, 4, 9}, yc[4] = {0, 1, 8, 27};
      p("lin_0.5",  mp_interp_linear_core(x, yq, 4, 0.5));
      p("lin_2.5",  mp_interp_linear_core(x, yq, 4, 2.5));
      p("lin_low",  mp_interp_linear_core(x, yq, 4, -5.0));
      p("lin_high", mp_interp_linear_core(x, yq, 4, 99.0));
      p("lin_1pt",  mp_interp_linear_core(x, yq, 1, 0.5));   /* n==1：原来越界读 x[1] */
      p("cub_0.5",  mp_interp_cubic_core(x, yc, 4, 0.5));
      p("cub_1.5",  mp_interp_cubic_core(x, yc, 4, 1.5));
      p("cub_2.5",  mp_interp_cubic_core(x, yc, 4, 2.5));
      p("cub_1pt",  mp_interp_cubic_core(x, yc, 1, 0.5));
      p("lin2_2.0", mp_interp_linear_core((double[]){1, 3}, (double[]){10, 20}, 2, 2.0));
    }
    /* Catmull-Rom 用有限差分斜率：内部段对**二次**是精确的（中心差分对二次精确），
     * 对三次不精确。所以精确性测试用 y = x²，q 取内部点。 */
    { double x[4] = {0, 1, 2, 3}, y2[4] = {0, 1, 4, 9};
      p("cq_0.25", mp_interp_cubic_core(x, y2, 4, 0.25));
      p("cq_1.25", mp_interp_cubic_core(x, y2, 4, 1.25));
      p("cq_2.25", mp_interp_cubic_core(x, y2, 4, 2.25));
      p("cq_2.75", mp_interp_cubic_core(x, y2, 4, 2.75));
      p("cq_low",  mp_interp_cubic_core(x, y2, 4, -7.0));
      p("cq_high", mp_interp_cubic_core(x, y2, 4, 42.0));
      /* 5 点、查内部段 i=2：两端都用中心差分，对二次应当**精确** */
      { double x5[5] = {0, 1, 2, 3, 4}, y5[5] = {0, 1, 4, 9, 16};
        p("cq_int_1.5", mp_interp_cubic_core(x5, y5, 5, 1.5));
        p("cq_int_2.5", mp_interp_cubic_core(x5, y5, 5, 2.5));
        p("cq_int_3.5", mp_interp_cubic_core(x5, y5, 5, 3.5)); }
    }
    /* 不等距 + 端点单边差分 */
    { double x[5] = {0, 1, 2.5, 4, 9}, y[5] = {1, 2, 3, 4, 5};
      p("cub_uneven_1.25", mp_interp_cubic_core(x, y, 5, 1.25));
      p("cub_uneven_3.0",  mp_interp_cubic_core(x, y, 5, 3.0));
      p("lin_uneven_1.25", mp_interp_linear_core(x, y, 5, 1.25)); }

    /* ---- 拟合：绑定层 ---- */
    { double x[5] = {1, 2, 3, 4, 5}, y[5] = {2.1, 4.05, 5.9, 8.1, 10.2};
      plist("linfit1", rt_lib_mp_linfit(mklist(x, 5), mklist(y, 5)), 3); }
    { double x[4] = {1, 2, 3, 4}, y[4] = {2, 5, 2, 5};
      plist("linfit2", rt_lib_mp_linfit(mklist(x, 4), mklist(y, 4)), 3); }
    { double x[5] = {0, 1, 2, 3, 4}, y[5] = {0, 1, 4, 9, 16};
      plist("pf0", rt_lib_mp_polyfit(mklist(x, 5), mklist(y, 5), rt_int(2)), 3); }
    { double x[4] = {10, 11, 12, 13}, y[4] = {100, 121, 144, 169};
      plist("pf_shift", rt_lib_mp_polyfit(mklist(x, 4), mklist(y, 4), rt_int(2)), 3); }
    { double x[6] = {0, 1, 2, 3, 4, 5}, y[6] = {1, 3, 7, 15, 31, 63};
      plist("pf3", rt_lib_mp_polyfit(mklist(x, 6), mklist(y, 6), rt_int(3)), 4); }
    { double x[7] = {0, 1, 2, 3, 4, 5, 6}, y[7] = {0, 1, 4, 9, 16, 25, 36};
      plist("pf4", rt_lib_mp_polyfit(mklist(x, 7), mklist(y, 7), rt_int(2)), 3); }
    { double x[8] = {1, 2, 3, 4, 5, 6, 7, 8}, y[8] = {3, 6, 11, 18, 27, 38, 51, 66};
      plist("pf5", rt_lib_mp_polyfit(mklist(x, 8), mklist(y, 8), rt_int(3)), 4); }
    { double x[6] = {100, 101, 102, 103, 104, 105},
             y[6] = {10000, 10201, 10404, 10609, 10816, 11025};
      plist("pf_shift2", rt_lib_mp_polyfit(mklist(x, 6), mklist(y, 6), rt_int(2)), 3); }
    /* 高次：正规方程的条件数是设计矩阵条件数的平方，这里看它到什么程度就不稳了 */
    { double x[12], y[12]; int t;
      for (t = 0; t < 12; t++) { x[t] = t; y[t] = 1.0/(t+1) + 0.5*((t%3)-1); }
      plist("pf_d6", rt_lib_mp_polyfit(mklist(x, 12), mklist(y, 12), rt_int(6)), 7); }
    { double x[20], y[20]; int t;
      for (t = 0; t < 20; t++) { x[t] = t * 0.5; y[t] = 1.0 + 0.3*t + 0.02*t*t - 0.001*t*t*t; }
      plist("pf_d8", rt_lib_mp_polyfit(mklist(x, 20), mklist(y, 20), rt_int(8)), 9); }
    (void)n;
    return 0;
}
