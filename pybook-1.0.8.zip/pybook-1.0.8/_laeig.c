/* _laeig.c — 一般实矩阵 Schur/特征值 的对拍 harness
 *
 * 用法：gcc _laeig.c pybook_la.c -o _laeig.exe -O2 -Wall
 *       .\_laeig.exe > _eig_dump.txt
 *       python -B _laeighk.py
 *
 * 沿用 _lacheck.c 的做法：C 侧只负责把输入矩阵和算出的结果**原样 dump**，
 * 参考值由 _laeighk.py 用 NumPy 拿同一批输入算。两边各写各的 RNG 是排查噩梦。
 *
 * 覆盖的是「实数域特征值算法真正会翻车的地方」，不是一堆随机方阵：
 *   - 复共轭对（旋转矩阵、随机阵）
 *   - 重特征值（单位阵、对角有重复）
 *   - 亏特征值（Jordan 块、友矩阵 x^n）
 *   - 量级悬殊（1e-8 与 1e8 混在一张阵里，专打平衡）
 *   - 全部实特征值（上三角、对称）
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "pybook_la.h"

static unsigned long long g_st = 0xDEADBEEFCAFEF00DULL;
static double urand(void)
{
    g_st ^= g_st << 13; g_st ^= g_st >> 7; g_st ^= g_st << 17;
    return ((double)(g_st >> 11) * (1.0 / 9007199254740992.0)) * 2.0 - 1.0;
}

static void pm(const char *tag, const double *a, int r, int c)
{
    int i, j;
    printf("MAT %s %d %d\n", tag, r, c);
    for (i = 0; i < r; i++) {
        for (j = 0; j < c; j++) printf(" %.17g", a[(size_t)i * c + j]);
        printf("\n");
    }
}

static void pv(const char *tag, const double *a, int n)
{
    int i;
    printf("VEC %s %d\n", tag, n);
    for (i = 0; i < n; i++) printf(" %.17g", a[i]);
    printf("\n");
}

/* 跑一个用例：A 是 n*n，跑 Schur，把 A/T/Q/特征值全 dump 出来 */
static void one(const char *tag, const double *a, int n)
{
    double *t, *q, *wre, *wim;
    int    i;

    printf("CASE %s %d\n", tag, n);
    pm("A", a, n, n);

    t   = (double *)calloc((size_t)n * n, sizeof(double));
    q   = (double *)calloc((size_t)n * n, sizeof(double));
    wre = (double *)calloc((size_t)n, sizeof(double));
    wim = (double *)calloc((size_t)n, sizeof(double));
    if (!t || !q || !wre || !wim) { fprintf(stderr, "内存不足\n"); exit(2); }

    if (!la_schur(a, t, q, n, 40 * n + 100)) {
        printf("FAIL %s not_converged\n", tag);
    } else {
        la_schur_eigvals(t, wre, wim, n);
        pm("T", t, n, n);
        pm("Q", q, n, n);
        pv("WR", wre, n);
        pv("WI", wim, n);
        /* 自检：Q 正交吗、A 能被 Q·T·Qᵀ 还原吗 —— 便宜，顺手报上来 */
        {
            double orth = 0.0, rec = 0.0, amax = 0.0;
            for (i = 0; i < n * n; i++) {
                double v = fabs(a[i]);
                if (v > amax) amax = v;
            }
            for (i = 0; i < n; i++) {
                int j, k;
                double s;
                for (j = 0; j < n; j++) {
                    s = 0.0;
                    for (k = 0; k < n; k++) s += q[(size_t)k * n + i] * q[(size_t)k * n + j];
                    s -= (i == j) ? 1.0 : 0.0;
                    if (fabs(s) > orth) orth = fabs(s);
                }
            }
            for (i = 0; i < n; i++) {
                int j, k;
                for (j = 0; j < n; j++) {
                    double s = 0.0;
                    for (k = 0; k < n; k++) s += q[(size_t)i * n + k] * t[(size_t)k * n + j];
                    for (k = 0; k < n; k++) s *= q[(size_t)k * n + j];
                    s -= a[(size_t)i * n + j];
                    if (fabs(s) > rec) rec = fabs(s);
                }
            }
            printf("SCALAR orth %.17g\n", orth);
            printf("SCALAR rec %.17g\n", rec);
            printf("SCALAR amax %.17g\n", amax);
        }
    }
    free(t); free(q); free(wre); free(wim);
}

static double *mk(int n)
{
    double *p = (double *)malloc((size_t)n * n * sizeof(double));
    if (!p) { fprintf(stderr, "内存不足\n"); exit(2); }
    return p;
}

int main(void)
{
    int    n, i, j, c;
    double *a;

    for (n = 1; n <= 12; n++) {
        char tag[64];
        a = mk(n);
        for (i = 0; i < n * n; i++) a[i] = urand();
        sprintf(tag, "rand%d", n);
        one(tag, a, n);

        for (i = 0; i < n * n; i++) a[i] = urand();
        for (i = 0; i < n; i++)               /* 对称 */
            for (j = i + 1; j < n; j++) {
                double v = (a[(size_t)i * n + j] + a[(size_t)j * n + i]) * 0.5;
                a[(size_t)i * n + j] = v; a[(size_t)j * n + i] = v;
            }
        sprintf(tag, "sym%d", n);
        one(tag, a, n);

        for (i = 0; i < n * n; i++) a[i] = 0.0;
        for (i = 0; i < n; i++)              /* 上三角：全是实特征值 */
            for (j = i; j < n; j++) a[(size_t)i * n + j] = urand();
        sprintf(tag, "triu%d", n);
        one(tag, a, n);
        free(a);
    }

    for (n = 16; n <= 40; n += 8) {
        char tag[64];
        a = mk(n);
        for (i = 0; i < n * n; i++) a[i] = urand();
        sprintf(tag, "rand%d", n);
        one(tag, a, n);
        free(a);
    }

    /* ---- 结构化难点 ---- */

    n = 2; a = mk(n);                        /* 纯旋转：特征值正好 ±i */
    a[0] = 0; a[1] = -1; a[2] = 1; a[3] = 0;
    one("rot2", a, n); free(a);

    n = 3; a = mk(n);                        /* 特征值 1 三重 + Jordan 块（亏特征值） */
    a[0] = 1; a[1] = 1; a[2] = 0;
    a[3] = 0; a[4] = 1; a[5] = 1;
    a[6] = 0; a[7] = 0; a[8] = 1;
    one("jordan3", a, n); free(a);

    n = 4; a = mk(n);                        /* 单位阵：重特征值到极点 */
    for (i = 0; i < 16; i++) a[i] = 0.0;
    for (i = 0; i < 4; i++) a[(size_t)i * 4 + i] = 1.0;
    one("eye4", a, n); free(a);

    n = 5; a = mk(n);                        /* 对角重特征值 + 一个复对 */
    for (i = 0; i < 25; i++) a[i] = 0.0;
    a[0] = 3; a[6] = 3; a[12] = 3;
    a[18] = 0; a[19] = 1; a[23] = 0; a[24] = 1;
    one("mixdiag5", a, n); free(a);

    n = 4; a = mk(n);                        /* 零阵 */
    for (i = 0; i < 16; i++) a[i] = 0.0;
    one("zero4", a, n); free(a);

    n = 6; a = mk(n);                        /* 量级悬殊，专打平衡 */
    for (i = 0; i < n; i++)
        for (j = 0; j < n; j++) {
            double sc = pow(10.0, (double)(((i * n + j) % 9) - 4));
            a[(size_t)i * n + j] = urand() * sc;
        }
    one("scaled6", a, n); free(a);

    n = 5; a = mk(n);                        /* 行随机向量和为 1（马尔可夫转移阵那种量级） */
    for (i = 0; i < n; i++) {
        double s = 0.0;
        for (j = 0; j < n; j++) { a[(size_t)i * n + j] = fabs(urand()); s += a[(size_t)i * n + j]; }
        for (j = 0; j < n; j++) a[(size_t)i * n + j] /= s;
    }
    one("stoch5", a, n); free(a);

    n = 5; a = mk(n);                        /* x^5 - 1 的友矩阵：五个单位根（4 个复数） */
    for (i = 0; i < 25; i++) a[i] = 0.0;
    for (i = 0; i < 4; i++) a[(size_t)i * 5 + (i + 1)] = 1.0;
    a[3] = -1.0; a[4] = -1.0; a[9] = 1.0; a[14] = 1.0;
    a[19] = -1.0; a[24] = 1.0;
    /* 上三角 Hessenberg 化的极端形态 */
    one("roots5", a, n); free(a);

    n = 10; a = mk(n);                       /* 稠密 + 量级悬殊 + 复特征值，大尺寸兜底 */
    for (i = 0; i < n; i++)
        for (j = 0; j < n; j++) {
            double sc = pow(10.0, (double)(((i + 2 * j) % 7) - 3));
            a[(size_t)i * n + j] = urand() * sc;
        }
    one("bigmix10", a, n); free(a);

    (void)c;
    printf("DONE\n");
    return 0;
}