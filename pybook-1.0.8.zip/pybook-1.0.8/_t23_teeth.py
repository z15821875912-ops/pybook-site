# -*- coding: utf-8 -*-
"""_t23_teeth.py —— 验证 T23 这条回归用例真的有牙：把 bug 放回去，它必须红。

为什么非做不可：
    一个「修复前也通过」的回归用例是零价值的 —— 它证明不了以后微内核再改坏时能拦住。
    只有「修复前红、修复后绿」才说明这条用例真的咬住了那个洞。
    之前给 GPU 那张表下结论时被单轮数据骗过（512 +24% 实为噪声），
    这里不重复同一个错误：断言必须两头都验。

做法：备份 pybook_tb.c -> 把 4 行改回 bug 版 -> 跑 T23 -> 立刻还原。
还原放在 finally 里：中途就算测试崩了也不会把生产源码留在坏状态。
"""
import io
import os
import re
import shutil
import subprocess
import sys

SRC = "pybook_tb.c"
BAK = "build_tmp/_t23_teeth_backup.c"

# 修好的样子：列尾巴那四行 base 直接读 O。
# 用 `(ioff + ip + 0/1/2/3)` 把它和行尾巴那行 `(ioff + ip)` 区分开 ——
# 行尾巴本来就是 `init ? 0 : O[...]` 且是正确的，反向替换绝不能碰它。
FIXED = re.compile(
    r"double\s+(base|b1|b2|b3)\s*=\s*O\[(\(ioff \+ ip \+ [0-3]\) \* bc \+ jc \+ jp)\]")


def run(cmd):
    p = subprocess.run(cmd, shell=True, capture_output=True)
    return p.returncode, (p.stdout.decode("utf-8", "replace")
                          + p.stderr.decode("utf-8", "replace"))


def main():
    if not os.path.exists(SRC):
        sys.exit("找不到 %s" % SRC)
    os.makedirs("build_tmp", exist_ok=True)
    shutil.copyfile(SRC, BAK)
    with io.open(SRC, "r", encoding="utf-8", newline="") as f:
        fixed_txt = f.read()

    n_fixed = len(FIXED.findall(fixed_txt))
    if n_fixed != 4:
        sys.exit("pybook_tb.c 里「base 直接读 O」有 %d 处（应为 4）—— "
                 "代码已经变了，先看再跑这个脚本" % n_fixed)

    print("=" * 68)
    print("第 1 步：当前状态（已修）应绿")
    rc, out = run("python -B tests\\run_tests.py --only T23_cpu_dot_nmod4_ok")
    print(out.strip())
    green_ok = ("失败 0" in out)

    try:
        # 反向：把「直接读 O」改回「init 时钉死成 0」，只动列尾巴那四行
        buggy_txt = FIXED.sub(r"double \1 = init ? 0 : O[\2]", fixed_txt.replace("\r\n", "\n"))
        if "\r\n" in fixed_txt:
            buggy_txt = buggy_txt.replace("\n", "\r\n")
        # 改完立刻核对：放回去的必须是 4 处，且行尾巴那处没被动
        n_back = len(re.findall(
            r"double\s+(?:base|b1|b2|b3)\s*=\s*init \? 0 : O\[\(ioff \+ ip \+ [0-3]\)", buggy_txt))
        rowtail = buggy_txt.count("init ? 0 : O[(ioff + ip) * bc + jc + jp]")
        print()
        print("=" * 68)
        print("第 2 步：放回 bug —— 列尾巴 %d 处（应 4），行尾巴保持原样 %d 处（应 1）"
              % (n_back, rowtail))
        if n_back != 4 or rowtail != 1:
            sys.exit("放回失败，拒绝继续跑（那这次就不是在测 bug 了）")
        with io.open(SRC, "w", encoding="utf-8", newline="") as f:
            f.write(buggy_txt)
        rc2, out2 = run("python -B tests\\run_tests.py --only T23_cpu_dot_nmod4_ok")
        print(out2.strip()[:1600])
        red_ok = ("失败 0" not in out2)
    finally:
        shutil.copyfile(BAK, SRC)
        print()
        print("=" * 68)
        print("已还原 pybook_tb.c")
        with io.open(SRC, "r", encoding="utf-8", newline="") as f:
            now = f.read()
        if now == fixed_txt:
            print("还原校验通过：与修复版逐字节一致 ✓")
        else:
            print("★★还原校验失败：当前文件与修复版不一致，立刻查★★")

    print()
    print("结论：修复后 %s，修复前 %s"
          % ("绿（通过）✓" if green_ok else "红（未通过）★★",
             "红（失败）✓ 这条用例确实咬得住" if red_ok else "绿（也通过）★★ 没用"))
    return 0 if (green_ok and red_ok) else 1


if __name__ == "__main__":
    sys.exit(main())
