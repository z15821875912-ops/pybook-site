# -*- coding: utf-8 -*-
"""_cpubench_gen.py —— 把 pybook_tb.c 里的 CPU 微内核**原文抽取**出来给测速 harness 用。

为什么不直接手抄进 harness：
    手抄一份就多一份会漂移的副本。改微内核、忘了同步 harness，
    就会出现「改了没生效、测的是旧内核」——和 _gputile.c 里
    「PTX 字符串版 vs 文件版」一模一样的坑，白查三轮。
    所以 .ptx 的规矩搬过来：微内核只有 pybook_tb.c 一个真相源，
    这里每次跑都重新抽一遍，抽取不到就直接报错、绝不退回手抄版。

抽的区间（pybook_tb.c 里是连续的）：
    #define TB_MR 4  ...  free(pB);\n}

用法：python -B _cpubench_gen.py
输出：_cpubench_core.inc
"""
import io
import os
import re
import sys

SRC = "pybook_tb.c"
DST = "_cpubench_core.inc"

BEGIN = "#define TB_MR 4"
# tb_matmul_tile 的收尾特征：释放 B 打包缓冲后紧跟函数右花括号。
# 必须带 MULTILINE —— 否则 $ 只匹配整个文件末尾，锚不到行尾，抽取直接失败。
END_RE = re.compile(r"free\(pB\);\n\}", re.MULTILINE)

# 路由阈值也要一起抽，不能让 harness 里写死一份。
#
# 为什么：2026-10-17 发现 _cpubench.c 里写的是 `mac >= 524288.0`（旧的 1<<19），
# 而生产 pybook_tb.c 早就改成 1<<24 了。于是基准输出的「路由选 / 路由损失」
# 两列反映的是一个**已经不存在的阈值**，那一屏「★该串行却并行★」的告警
# 大半已经不成立了 —— 看的人却会当成生产行为。写死两份常量，迟早漂。
#
# 现在把 TB_MM_MIN 的定义原文抽进 .inc，harness 直接用它，两边不可能再不一致。
# 自检：抽不到就报错退出，不允许静默跳过。
MMIN_RE = re.compile(r"^#define\s+TB_MM_MIN\s+.*$", re.MULTILINE)

# 分块常量覆盖（**仅用于调参实验**）：环境变量 PUBENCH_BLOCK="KC,NC,MC"。
# 生产值是 48,48,48；这里允许替换生成物里的那三行，好扫出更好的组合。
# 扫完把结果手工写回 pybook_tb.c，再删掉这个覆盖 —— 生成物永远是生成物，
# 覆盖只是实验脚手架，不留在常态路径上（没设环境变量时行为与之前完全一致）。
_BLOCK_RE = re.compile(r"#define\s+(TB_KC|TB_NC|TB_MC)\s+\d+")


def apply_block_override(body, env):
    if not env:
        return body, None
    parts = [p.strip() for p in env.split(",")]
    if len(parts) != 3 or not all(p.isdigit() for p in parts):
        sys.exit("PUBENCH_BLOCK 必须是 'KC,NC,MC' 三个整数，收到 %r" % env)
    kc, nc, mc = (int(p) for p in parts)
    if min(kc, nc, mc) <= 0:
        sys.exit("分块尺寸必须为正")
    # NC 是列分块，微内核按 TB_NR=8 一组处理；不是 8 的倍数会白走列尾巴
    if nc % 8:
        sys.exit("NC=%d 不是 8 的倍数，会让列主循环每次都带尾巴，测出来的是另一个内核" % nc)
    # MC 是行分块，微内核按 TB_MR=4 一组处理
    if mc % 4:
        sys.exit("MC=%d 不是 4 的倍数，会让行主循环每次都带尾巴，测出来的是另一个内核" % mc)

    def sub(m):
        return "#define %s %d" % (m.group(1), {"TB_KC": kc, "TB_NC": nc, "TB_MC": mc}[m.group(1)])

    out, n = _BLOCK_RE.subn(sub, body)
    if n != 3:
        sys.exit("分块常量的 #define 数量是 %d（应为 3），生产结构变了，先看代码" % n)
    return out, (kc, nc, mc)


def main():
    if not os.path.exists(SRC):
        sys.exit("找不到 %s（要在仓库根目录跑）" % SRC)
    # 读的时候统一行尾：抽取只按内容匹配，不受 CRLF/LF 影响
    with io.open(SRC, "r", encoding="utf-8", newline="") as f:
        text = f.read()
    text = text.replace("\r\n", "\n")

    i = text.find(BEGIN)
    if i < 0:
        sys.exit("在 %s 里找不到起始锚点 %r —— 生产代码结构变了，"
                 "先看一眼再改这个脚本" % (SRC, BEGIN))

    # 从起始锚点往后找第一个「free(pB); }」收尾
    m = None
    for m in END_RE.finditer(text, i):
        pass
    if m is None:
        sys.exit("在 %s 里找不到收尾锚点 free(pB); }" % SRC)
    body = text[i:m.end()]

    # 抽出来的必须含这两个函数，否则说明只抽到一半
    for need in ("tb_micro_packed", "tb_matmul_tile", "TB_KC", "TB_NC", "TB_MC"):
        if need not in body:
            sys.exit("抽取结果里少了 %s，区间锚点失效" % need)

    body, blk = apply_block_override(body, os.environ.get("PUBENCH_BLOCK"))

    # 抽 TB_MM_MIN（路由阈值），抽不到就报错
    mm = MMIN_RE.search(text)
    if mm is None:
        sys.exit("在 %s 里找不到 #define TB_MM_MIN —— "
                 "harness 的路由判据不能靠猜" % SRC)
    mmin_line = mm.group(0)
    print("抽到路由阈值：%s" % mmin_line)

    # 注意：覆盖说明必须插在 "*/" **之前**。写成 head += 那行的话它落在
    # 已闭合的块注释之外，会被当成代码 —— gcc 报「stray '\343' in program」，
    # 错误信息指向中文，看着像编码问题，其实是注释位置问题，白查一轮。
    override_line = ""
    if blk:
        override_line = (" * 【调参实验】分块常量被 PUBENCH_BLOCK 覆盖为 "
                         "KC=%d NC=%d MC=%d\n" % blk)

    head = (
        "/* 本文件由 _cpubench_gen.py 从 %s 原文抽取生成，不要手改。\n"
        " * 重新生成：python -B _cpubench_gen.py\n"
        " * 抽取区间：%r 起，到 tb_matmul_tile 的 free(pB); } 止。\n"
        " * 抽取的是生产代码本体，不是副本 —— harness 测的就是线上跑的那份。\n"
        " * 另外把生产的路由阈值一并抽到下面，避免 harness 里写死一份而悄悄漂掉。\n"
        "%s"
        " */\n%s\n"
        % (SRC, BEGIN, override_line, mmin_line)
    )
    with io.open(DST, "w", encoding="utf-8", newline="\n") as f:
        f.write(head)
        f.write(body)
        f.write("\n")

    nbytes = len(body.encode("utf-8"))
    print("抽出 %d 字节 -> %s%s"
          % (nbytes, DST, ("（分块覆盖 KC=%d NC=%d MC=%d）" % blk) if blk else ""))
    # 自检：把抽出来的行数报出来，人眼扫一眼是不是完整的三级分块
    print("行数 %d" % body.count("\n"))


if __name__ == "__main__":
    main()
