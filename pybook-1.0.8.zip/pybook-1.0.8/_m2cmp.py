# -*- coding: utf-8 -*-
"""_m2cmp.py — 跑 _m2h.exe，把输出跟可信参考值逐条对拍。
参考：math.gamma/lgamma/erf/erfc 是 CPython 的（独立实现）；zeta 用 Hasse-Sondow 高精度级数现算。"""
import math
import subprocess
import sys
from decimal import Decimal, getcontext
from fractions import Fraction

getcontext().prec = 40
BF = [float(Fraction(1, 12)), float(Fraction(-1, 720)), float(Fraction(1, 30240)),
      float(Fraction(-1, 1209600)), float(Fraction(1, 47900160)),
      float(Fraction(-691, 1307674368000))]


def zeta_ref(s):
    """Hasse–Sondow：几何收敛，与被测算法完全独立"""
    sD = Decimal(repr(s))
    two = Decimal(2)
    total = Decimal(0)
    for n in range(90):
        inner = Decimal(0)
        binom = 1
        for k in range(n + 1):
            if k:
                binom = binom * (n - k + 1) // k
            inner += Decimal(binom if k % 2 == 0 else -binom) / (Decimal(k + 1) ** sD)
        total += inner / (two ** (n + 1))
    return float(total / (Decimal(1) - two ** (Decimal(1) - sD)))


r = subprocess.run(['_m2h.exe'], capture_output=True, text=True, errors='replace')
out = {}
order = []
for line in r.stdout.splitlines():
    if '\t' not in line:
        continue
    k, v = line.split('\t', 1)
    try:
        out[k] = float(v)
    except ValueError:
        pass
    order.append(k)

if r.returncode != 0 or r.stderr.strip():
    print('!! harness 退出码 %d，stderr：' % r.returncode)
    print(r.stderr.strip()[:1200])
    print('解析到 %d 个值（应更多，说明中途退出了）' % len(out))
    print()
    sys.exit(2)

print('== gamma / lgamma（参考 math.gamma / math.lgamma）==')
print('%-16s %-24s %-24s %s' % ('点', '参考', 'C 实测', '相对/绝对误差'))
for x in (0.5, 1.0, 1.5, 2.0, 5.0, 10.0, 20.0, 100.0, 0.001, 0.1, -0.5, -1.5, -4.5):
    k = '%.4g' % x
    ref, got = math.gamma(x), out['gamma_' + k]
    print('%-16s %-24.17g %-24.17g %.2e' % (k, ref, got, abs(got-ref)/abs(ref)))
for x in (0.5, 1.0, 1.5, 5.0, 10.0, 100.0, 0.001, -0.5, -1.5):
    k = '%.4g' % x
    ref, got = math.lgamma(x), out['lgamma_' + k]
    print('%-16s %-24.17g %-24.17g %.2e (绝对)' % ('lgamma ' + k, ref, got, abs(got-ref)))

print()
print('== erf / erfc ==')
print('%-10s %-24s %-24s %-11s %-11s' % ('x', 'erf 参考', 'erf 实测', 'erf 相对误差', 'erfc 相对误差'))
for x in (0.0, 0.25, 0.5, 1.0, 1.5, 2.0, 3.0, 4.0, 6.0, -0.5, -2.0, -6.0):
    k = '%.4g' % x
    re_, ge = math.erf(x), out['erf_' + k]
    rc, gc = math.erfc(x), out['erfc_' + k]
    print('%-10s %-24.17g %-24.17g %-11.2e %-11.2e'
          % (k, re_, ge, abs(ge-re_)/abs(re_) if re_ else 0.0,
             abs(gc-rc)/abs(rc) if rc else 0.0))

print()
print('== zeta（参考：Hasse–Sondow 90 项，40 位精度）==')
print('%-12s %-26s %-26s %s' % ('s', '参考', 'C 实测', '相对误差'))
for s in (2.0, 4.0, 5.0, 1.5, 1.1, 1.01, 1.001, 1.0001, 20.0, 50.0):
    k = '%.6g' % s
    ref, got = zeta_ref(s), out['zeta_' + k]
    print('%-12s %-26.17g %-26.17g %.2e' % (k, ref, got, abs(got-ref)/abs(ref)))

print()
print('== 绑定层（走 Value，验 lib_unpack / AS_INT 修好了没有）==')
print('%-18s %-24s %s' % ('项', 'C 实测', '核层一致'))
for nm, ref in (('bind_erf_half', math.erf(0.5)),
                ('bind_erfc_6', math.erfc(6.0)),
                ('bind_gamma_1', math.gamma(1.0)),
                ('bind_lgamma_100', math.lgamma(100.0)),
                ('bind_zeta_2', zeta_ref(2.0))):
    print('%-18s %-24.17g 相对误差 %.2e' % (nm, out[nm], abs(out[nm]-ref)/abs(ref)))

print()
print('== 插值 ==')
print('%-18s %-24s %s' % ('项', 'C 实测', '说明/期望'))


def lin(x, y, q):
    i = max(0, min(len(x)-2, next((k for k in range(len(x)-1) if x[k] <= q < x[k+1]), 0)))
    if q <= x[0]:
        i = 0
    if q >= x[-1]:
        i = len(x)-2
    t = (q-x[i])/(x[i+1]-x[i])
    return y[i] + t*(y[i+1]-y[i])


xs = [0, 1, 2, 3]
yq = [0, 1, 4, 9]
yc = [0, 1, 8, 27]
for nm, q, exp in (('lin_0.5', 0.5, 0.5), ('lin_2.5', 2.5, 6.5),
                   ('lin_low', -5.0, 0.0), ('lin_high', 99.0, 9.0),
                   ('lin_1pt', 0.5, '0（n=1，原来越界）')):
    got = out[nm]
    print('%-18s %-24.17g %s' % (nm, got, exp if isinstance(exp, str)
                                  else '期望 %s，误差 %.2e' % (exp, abs(got-exp))))


def catmull(x, y, q):
    """独立的 Catmull-Rom 参考实现（Python 写的，跟 C 那份不同源）"""
    n = len(x)
    if n < 2:
        return y[0]
    if q <= x[0]:
        return y[0]
    if q >= x[-1]:
        return y[-1]
    i = max(k for k in range(n - 1) if x[k] <= q < x[k + 1])
    h = x[i + 1] - x[i]
    t = (q - x[i]) / h
    p0, p1 = y[i], y[i + 1]
    m0 = ((y[1] - y[0]) / (x[1] - x[0])) if i == 0 else \
         ((y[i + 1] - y[i - 1]) / (x[i + 1] - x[i - 1]))
    m1 = ((y[n - 1] - y[n - 2]) / (x[n - 1] - x[n - 2])) if i + 1 >= n - 1 else \
         ((y[i + 2] - y[i]) / (x[i + 2] - x[i]))
    t2, t3 = t * t, t * t * t
    h00 = 2 * t3 - 3 * t2 + 1
    h10 = t3 - 2 * t2 + t
    h01 = -2 * t3 + 3 * t2
    h11 = t3 - t2
    return h00 * p0 + h10 * h * m0 + h01 * p1 + h11 * h * m1


xu = [0, 1, 2.5, 4, 9]
yu = [1, 2, 3, 4, 5]
print('%-18s %-24s %s' % ('三次插值', 'C 实测', '对照（Python 独立实现 / 期望）'))
x5 = [0, 1, 2, 3, 4]
y5 = [0, 1, 4, 9, 16]
for nm, x, y, q in (('cq_0.25', [0, 1, 2, 3], [0, 1, 4, 9], 0.25),
                    ('cq_1.25', [0, 1, 2, 3], [0, 1, 4, 9], 1.25),
                    ('cq_2.25', [0, 1, 2, 3], [0, 1, 4, 9], 2.25),
                    ('cq_2.75', [0, 1, 2, 3], [0, 1, 4, 9], 2.75),
                    ('cq_int_1.5', x5, y5, 1.5),
                    ('cq_int_2.5', x5, y5, 2.5),
                    ('cq_int_3.5', x5, y5, 3.5),
                    ('cq_low', [0, 1, 2, 3], [0, 1, 4, 9], -7.0),
                    ('cq_high', [0, 1, 2, 3], [0, 1, 4, 9], 42.0),
                    ('cub_uneven_1.25', xu, yu, 1.25),
                    ('cub_uneven_3.0', xu, yu, 3.0)):
    ref = catmull(x, y, q)
    got = out[nm]
    # 内部段（i>0 且 i+1<n-1）两端都是中心差分，对 y=x² 应当精确
    i = next((k for k in range(len(x) - 1) if x[k] <= q < x[k + 1]), None)
    interior = i is not None and i > 0 and i + 1 < len(x) - 1
    tag = ''
    if y == [0, 1, 4, 9] + ([16] if len(x) == 5 else []):
        tag = ('内部段，对二次精确：误差 %.2e' % abs(got - q * q)) if interior \
            else ('首/末段单边差分，不精确是正常的（差 %.2e）' % abs(got - q * q))
    print('%-18s %-24.17g 参考 %.17g 差 %.2e   %s'
          % (nm, got, ref, abs(got - ref), tag))
print('%-18s %-24.17g %s' % ('lin_uneven_1.25', out['lin_uneven_1.25'],
                              '线性参考 %.17g，误差 %.2e'
                              % (lin(xu, yu, 1.25), abs(out['lin_uneven_1.25'] - lin(xu, yu, 1.25)))))
print('%-18s %-24.17g %s' % ('cub_1pt', out['cub_1pt'], '期望 0（n=1）'))
print('%-18s %-24.17g %s' % ('lin2_2.0', out['lin2_2.0'], '期望 15，误差 %.2e'
                             % abs(out['lin2_2.0']-15)))
print()
print('  备注：Catmull-Rom 用有限差分斜率，内部段对**二次**精确、对三次不精确，')
print('        所以 cub_1.5 = 3（而 x³(1.5)=3.375）是正常行为，不是 bug。')

print()
print('== 拟合 ==')
try:
    import numpy as np
    HAVE_NP = True
except ImportError:
    HAVE_NP = False

for nm in ('linfit1', 'linfit2'):
    v = [out['%s[%d]' % (nm, i)] for i in range(3)]
    print('%-10s 斜率=%.17g 截距=%.17g r²=%.17g' % (nm, v[0], v[1], v[2]))

CASES = [
    ('pf0',      [0, 1, 2, 3, 4],          [0, 1, 4, 9, 16],            2, [0, 0, 1]),
    ('pf_shift', [10, 11, 12, 13],          [100, 121, 144, 169],         2, [0, 0, 1]),
    ('pf3',      [0, 1, 2, 3, 4, 5],       [1, 3, 7, 15, 31, 63],        3, None),
    ('pf4',      [0, 1, 2, 3, 4, 5, 6],    [0, 1, 4, 9, 16, 25, 36],     2, [0, 0, 1]),
    ('pf5',      [1, 2, 3, 4, 5, 6, 7, 8], [3, 6, 11, 18, 27, 38, 51, 66], 3, None),
    ('pf_shift2', [100, 101, 102, 103, 104, 105], [10000, 10201, 10404, 10609, 10816, 11025], 2, [0, 0, 1]),
]
print()
print('%-10s %-6s %-46s %s' % ('用例', '次数', 'C 实测系数', '对 numpy.polyfit / 解析解'))
for nm, x, y, deg, exact in CASES:
    got = [out.get('%s[%d]' % (nm, i)) for i in range(deg + 1)]
    if got[0] is None:
        print('%-10s %-6d %s' % (nm, deg, '缺失（harness 没输出这一项）'))
        continue
    txt = '  '.join('%+.12g' % g for g in got)
    notes = []
    if exact:
        notes.append('解析解 %s，最大差 %.2e'
                     % (exact, max(abs(g - e) for g, e in zip(got, exact))))
    if HAVE_NP:
        ref = np.polyfit(np.array(x, float), np.array(y, float), deg)[::-1]
        # 用按系数自身量级缩放的度量：真值近 0 的系数用相对误差没有意义
        # （0 与 1e-17 的相对差是 1.0，但绝对差只有 1e-17）
        scale = max(abs(g) for g in got) or 1.0
        notes.append('vs numpy 按最大系数缩放的绝对差 %.2e'
                     % (max(abs(g - r) for g, r in zip(got, ref)) / scale))
    print('%-10s %-6d %-46s %s' % (nm, deg, txt, '；'.join(notes)))
