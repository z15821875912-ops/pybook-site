# -*- coding: utf-8 -*-
"""_chk_loss.py — 四张表被整体重写后，丢了多少原有入口？
对照 PYBOOK_AI.md 的分前缀清单和各文件里的已知锚点。"""
import io
import re
import sys

sys.path.insert(0, 'tests')

front = io.open('pybk_front.py', encoding='utf-8', newline='').read()
code = io.open('pybk_code.py', encoding='utf-8', newline='').read()
inc = io.open('_vm_lib_calls.inc', encoding='utf-8', newline='').read()

# LIB_CALLS 的键
keys = re.findall(r"^    '([a-zA-Z0-9_.]+)':", front, re.M)
print('pybk_front.py LIB_CALLS 条数：%d' % len(keys))
by_prefix = {}
for k in keys:
    p = k.split('.')[0]
    by_prefix[p] = by_prefix.get(p, 0) + 1
print('  按前缀：' + '  '.join('%s=%d' % kv for kv in sorted(by_prefix.items())))

rows = len(re.findall(r'^\s*\{"', inc, re.M))
print('_vm_lib_calls.inc 表项：%d' % rows)

print()
print('已知的「老入口」锚点是否还在（这些在我这轮之前就有）：')
ANCHORS = [
    ('mt.taylor', front, "'mt.taylor'"),
    ('mt.deriv', front, "'mt.deriv'"),
    ('mt.integrate', front, "'mt.integrate'"),
    ('mt.root_newton_d', front, "'mt.root_newton_d'"),
    ('mt.exp', front, "'mt.exp'"),
    ('mt.log1p', front, "'mt.log1p'"),
    ('mt.atanh', front, "'mt.atanh'"),
    ('mp.corr', front, "'mp.corr'"),
    ('mp.percentile', front, "'mp.percentile'"),
    ('mp.rand_lognormal', front, "'mp.rand_lognormal'"),
    ('rd.seed', front, "'rd.seed'"),
    ('tb.eig_sym', front, "'tb.eig_sym'"),
    ('tb.cholesky', front, "'tb.cholesky'"),
    ('tb.lu', front, "'tb.lu'"),
    ('mp.mat_qr', front, "'mp.mat_qr'"),
    ('mp.vector', front, "'mp.vec_add'"),
]
bad = 0
for name, txt, mark in ANCHORS:
    ok = mark in txt
    if not ok:
        bad += 1
    print('  %-20s %s' % (name, '在' if ok else '★ 不见了'))

print()
print('pybk_code.py LIB_C_NAMES 条数：%d'
      % len(re.findall(r"^        '[a-zA-Z0-9_.]+': '", code, re.M)))
print('pybook_lib.h 原型 rt_lib_* 数：%d'
      % len(re.findall(r'Value rt_lib_\w+\(', io.open('pybook_lib.h',
                                                     encoding='utf-8',
                                                     newline='').read())))
print()
print('结论：老入口丢了 %d 个' % bad if bad else '结论：老入口都在，丢的只是本轮新增')
