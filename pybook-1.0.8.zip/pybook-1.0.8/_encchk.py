# -*- coding: utf-8 -*-
"""_encchk.py — 精确查 U+FFFD（EF BF BD），并报告行尾。
上一版把替换字符字面量写丢了，count('') 匹配了每个位置，报的 28740 是假的。"""
import io

BAD = b'\xef\xbf\xbd'
for p in ('mathplus.c', 'pybook_lib.c', 'pybook_lib.h', 'pybk_front.py',
          'pybk_code.py', '_vm_lib_calls.inc', 'pybook_rt.c'):
    raw = open(p, 'rb').read()
    try:
        t = raw.decode('utf-8')
        enc = '合法 UTF-8'
    except UnicodeDecodeError as e:
        t = raw.decode('utf-8', 'replace')
        enc = '★ 不是合法 UTF-8 (%s)' % e
    n = raw.count(BAD)
    print('%-20s %-16s %7d 字节  U+FFFD=%-4d CRLF=%-5d bareLF=%-4d'
          % (p, enc, len(raw), n, raw.count(b'\r\n'),
             raw.count(b'\n') - raw.count(b'\r\n')))
    if n:
        for i, line in enumerate(t.splitlines(), 1):
            if '' in line:
                print('    第 %d 行含替换字符: %r' % (i, line[:80]))
                break
