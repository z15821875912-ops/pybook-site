# -*- coding: utf-8 -*-
"""_append_t23.py —— 把 T23 用例并进 tests/cases.py，用文件原有的 case(**{...}) 风格。

为什么单独写脚本而不是手贴：
    1. cases.py 是生成 + 手维护混编的，手贴 300 多字符的转义串容易少一个反斜杠；
    2. 这里的 src/out 都从 .pybk 和独立朴素参考算出来，脚本保证「用例内容、
       期望输出、.pybk 文件」三者同源，改一处不会漏另一处；
    3. 重复执行是幂等的：id 已存在就退出，不产生第二条。
"""
import io
import os
import sys

CASES = os.path.join("tests", "cases.py")
CASE_ID = "T23_cpu_dot_nmod4_ok"
PYBK = os.path.join("tests", CASE_ID + ".pybk")

EXPECT = (
    "CPU 路径 M>=4 且 N%4!=0：tb.dot 的最后 1 列必须正确"
    "（列尾巴曾把每个 kc 块只留最后一个 k 的乘积，静默错 1 列）"
)


def die(msg):
    sys.exit(msg)


with io.open(CASES, "r", encoding="utf-8") as f:
    cases_txt = f.read()

if CASE_ID in cases_txt:
    die("%s 已在 cases.py 里，拒绝重复追加" % CASE_ID)
if not os.path.exists(PYBK):
    die("找不到 %s（先跑 _gen_t23.py 生成）" % PYBK)

with io.open(PYBK, "r", encoding="utf-8") as f:
    src = f.read()
if not src.endswith("\n"):
    src += "\n"

# 期望值由 _gen_t23.py 用独立朴素三重循环算过，这里重算一遍当交叉核对：
# 两处算法不同实现却算出同一个数，才敢当回归基准。
M, N, K = 8, 65, 64
OFF_A, OFF_B = 0, 2


def a_of(i, k):
    return (i * 7 + k * 3 + OFF_A) % 3


def b_of(k, j):
    return (k * 7 + j * 5 + OFF_B) % 3


probes = [(i, N - 1) for i in range(M)] + [(0, 0), (0, N - 2), (M - 1, 0)]
out_lines = []
for (i, j) in probes:
    s = 0
    for k in range(K):
        s += a_of(i, k) * b_of(k, j)
    out_lines.append("第%d行第%d列=%d" % (i, j, s))
expect_out = "\n".join(out_lines) + "\n"

line = "case(**{'id': %r, 'kind': 'normal', 'src': %r, 'out': %r, 'err': '', " \
       "'err_contains': [], 'exit': 0, 'expect': %r})\n" % (
           CASE_ID, src, expect_out, EXPECT)

if not cases_txt.endswith("\n"):
    cases_txt += "\n"
cases_txt += line

with io.open(CASES, "w", encoding="utf-8", newline="\n") as f:
    f.write(cases_txt)

print("已并入 %s" % CASES)
print("用例 id: %s" % CASE_ID)
print("期望 stdout（%d 行）：" % len(out_lines))
print(expect_out)
