# -*- coding: utf-8 -*-
"""_refdgemm.py —— 用 numpy 的 BLAS 当标尺，量出「还有多少肉在肉里」。

为什么必须先有这个：
    拿「理论上应该多少」去对没有意义，那只是我的猜测。
    numpy 自带的 BLAS 是这台机器上现成的、别人认真调过的 dgemm，同为 float64，
    跟 PYbook 的 CPU 路径完全同一个问题。拿它当分母，才知道：
      PYbook 的差距是【内核不行】还是【并行不行】，该往哪使劲。

顺带量单线程 BLAS，用来分离并行效率：
    并行效率 = 多线程 BLAS / (单线程 BLAS × 核数)

用法：python -B _refdgemm.py [单线程核数]
"""
import sys
import time

import numpy as np


def bench(M, N, K, reps=5):
    # 固定成非零，避免 BLAS 对全零走特殊路径
    rng = np.random.default_rng(12345)
    A = rng.random((M, K)) - 0.5
    B = rng.random((K, N)) - 0.5
    C = A @ B                      # 预热（含第一次的代码页调入/线程池起）
    t0 = time.perf_counter()
    for _ in range(reps):
        C = A @ B
    t1 = time.perf_counter()
    ms = (t1 - t0) * 1000.0 / reps
    gf = 2.0 * M * N * K / (ms / 1000.0) / 1e9
    return ms, gf


SIZES = [256, 384, 512, 640, 768, 896, 1024, 1280, 1536, 2048, 3072]

try:
    blas = np.__config__.show(mode="dicts")["Build Dependencies"]["blas"]["name"]
except Exception:
    blas = "(读不出)"

print("numpy %s，BLAS = %s" % (np.__version__, blas))
try:
    from threadpoolctl import threadpool_info
    for d in threadpool_info():
        print("  线程池 %s：%d 线程" % (d.get("internal_api"), d.get("num_threads")))
except Exception:
    print("  （无 threadpoolctl，线程数不可见；用 OPENBLAS_NUM_THREADS 环境变量控制）")
print()
print("%6s | %10s %10s" % ("N", "ms", "GFLOPS"))
print("-------+-------------------")
for n in SIZES:
    ms, gf = bench(n, n, n, reps=3 if n >= 2048 else 5)
    print("%6d | %10.3f %10.1f" % (n, ms, gf))
