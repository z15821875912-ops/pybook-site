# -*- coding: utf-8 -*-
"""_pfqr.py — 正规方程 vs QR，同一份数据、同样的中心化，看清楚差多少。
起因：我先前拿「deg=8 残差差 56%」当理由把 polyfit 换成 QR，但那次测量是
**我的测试脚本喂错了数据**（C 端 y 用整数下标 t 算，Python 端却用 f(x=t*0.5)）。
所以这里重做一遍，把结论落实成实测，而不是靠推断。"""
import numpy as np

np.set_printoptions(precision=17)


def normal_eq_centered(x, y, deg):
    """和 C 原来一样：中心化 + 正规方程 + 部分主元高斯消元"""
    n = len(x)
    mx = np.asarray(x, float) - np.mean(x)
    my = np.asarray(y, float) - np.mean(y)
    m = deg + 1
    A = np.empty((n, m))
    for j in range(m):
        A[:, j] = mx ** j
    # 显式 VᵀV（这正是被替换掉的那一步：条件数被平方）
    G = A.T @ A
    rhs = A.T @ my
    c = np.linalg.solve(G, rhs)
    # Horner 换算回 x 的幂，并加回 ȳ
    sx = np.mean(x)
    d = np.zeros(m)
    d[0] = c[deg]
    for jj in range(deg - 1, -1, -1):
        for kk in range(deg, 0, -1):
            d[kk] = d[kk - 1] - sx * d[kk]
        d[0] = -sx * d[0] + c[jj]
    d[0] += np.mean(y)
    return d


def qr_centered(x, y, deg):
    """中心化 + 列平衡 + QR（现在的 C 做法），用 numpy.linalg.lstsq 代表"""
    n = len(x)
    mx = np.asarray(x, float) - np.mean(x)
    my = np.asarray(y, float) - np.mean(y)
    m = deg + 1
    A = np.empty((n, m))
    for j in range(m):
        A[:, j] = mx ** j
    sc = np.linalg.norm(A, axis=0)
    c = np.linalg.lstsq(A / sc, my, rcond=None)[0] / sc
    sx = np.mean(x)
    d = np.zeros(m)
    d[0] = c[deg]
    for jj in range(deg - 1, -1, -1):
        for kk in range(deg, 0, -1):
            d[kk] = d[kk - 1] - sx * d[kk]
        d[0] = -sx * d[0] + c[jj]
    d[0] += np.mean(y)
    return d


print('同一份数据（y 用整数下标 t 生成，x = t*scale）：')
for scale, n, label in ((0.5, 20, 'x∈[0,9.5], deg 6~10'),
                        (1.0, 16, 'x∈[0,15], deg 6~12'),
                        (5.0, 20, 'x∈[0,95], deg 6~10（量级大 10 倍）')):
    print('\n--- %s ---' % label)
    t = np.arange(n, dtype=float)
    x = t * scale
    y = 1.0 + 0.3*t + 0.02*t*t - 0.001*t*t*t
    print('%-6s %-12s %-12s %-12s %s' % ('deg', '正规方程', 'QR', '两者差', '拟合曲线最大相对差'))
    for deg in (6, 8, 10, 12):
        if deg + 1 > n:
            continue
        ref = np.polyfit(x, y, deg)[::-1]
        an = normal_eq_centered(x, y, deg)
        qr = qr_centered(x, y, deg)
        scale_c = max(abs(an).max(), 1e-300)
        d1 = np.max(np.abs(an - ref)) / scale_c
        d2 = np.max(np.abs(qr - ref)) / scale_c
        yn = np.polyval(an[::-1], x)
        yq = np.polyval(qr[::-1], x)
        rel = np.max(np.abs(yn - yq)) / np.max(np.abs(y))
        print('%-6d %-12.3e %-12.3e %-12.3e %.3e' % (deg, d1, d2, abs(d1-d2), rel))

print()
print('结论：正规方程那一列在次数升高时相对误差增长得比 QR 快多少？')
t = np.arange(20.0)
x = t * 0.5
y = 1.0 + 0.3*t + 0.02*t*t - 0.001*t*t*t
for deg in (6, 8, 10, 12):
    if deg + 1 > len(x):
        continue
    ref = np.polyfit(x, y, deg)[::-1]
    sc = max(abs(ref).max(), 1e-300)
    e_ne = np.max(np.abs(normal_eq_centered(x, y, deg) - ref)) / sc
    e_qr = np.max(np.abs(qr_centered(x, y, deg) - ref)) / sc
    print('  deg=%-3d 正规方程 %.2e   QR %.2e   倍数 %.1f'
          % (deg, e_ne, e_qr, (e_ne / e_qr) if e_qr > 0 else float('inf')))
