# -*- coding: utf-8 -*-
"""_gen_t23.py —— 生成「CPU 路径 N%4!=0」回归用例（修列尾巴 bug 的配套看门狗）

为什么必须有这个用例：
    bug 的触发条件是 **M >= 4 且 N % 4 != 0**。
    而现有 159 个用例里，走 CPU 的 tb.dot 全是 2×2（M<4，4 行 FMA 主循环进不去），
    走 GPU 的 N 又是 64/128/300/1280（全是 4 的倍数）——
    整套语料恰好绕开了这两个条件的交集，所以上一轮 159/159 全绿而 bug 健在。
    不补这个用例，下一次改微内核还会从同一条缝漏出去。

期望值怎么来的：
    **不手推**。这里用朴素三重循环（无分块、无打包、无向量化）算出 C，
    跟 _cpubench.c 的判官用的是同一套参考算法，
    而那套参考已被验证过：它对「修好之后」的生产微内核是 0.000e+00。
    参考本身错了的话，正会在这里表现为不一致。

输出：
    tests/T23_cpu_dot_nmod4_ok.pybk   新建文件（不覆盖任何现有东西）
    _t23_case.txt                     追加进 cases.py 的 case() 行，等合并不冲突
"""
import io
import os

M, N, K = 8, 65, 64          # M>=4 进 4 行 FMA 组；N%4==1 踩列尾巴；K 取 4 的倍数避开别的变量
OFF_A, OFF_B = 0, 2


def a_of(i, k):
    return (i * 7 + k * 3 + OFF_A) % 3


def b_of(k, j):
    return (k * 7 + j * 5 + OFF_B) % 3


def c_of(i, j):
    """朴素三重循环参考：不分组、不打包，就是 A 行乘 B 列逐项累加。"""
    s = 0
    for k in range(K):
        s += a_of(i, k) * b_of(k, j)
    return s


# 打印哪些元素：全部 8 行的最后一列（N-1=64，bug 的重灾区）+ 两个对照列
probes = [(i, N - 1) for i in range(M)] + [(0, 0), (0, N - 2), (M - 1, 0)]

# 变量名一律用纯 ASCII 的 p0..pN。之前想用「探0_64」这种中文+数字+下划线的名字，
# 但本机此刻 pyvm.exe 正被另一条线占用、**跑不了这个用例**，
# 那就别在语法上赌一把 —— 纯 ASCII 名字零风险，$插值里也最稳。
lines = []
for n, (i, j) in enumerate(probes):
    lines.append("vg.p%d = 表[%d][%d]" % (n, i, j))
show_lines = ["ns.show(第%d行第%d列=$p%d)" % (i, j, n) for n, (i, j) in enumerate(probes)]

# 模板用 @@占位符@@ 而不是 % 格式化：这份模板里全是 %3、%4、%d 这类字面量
# （PYbook 取模运算符 + 注释里的 N%4），走 % 格式化必然踩转义坑。
SRC_TMPL = (
    "@ pybk>测试>CPU矩阵乘-N非4倍\n"
    "# 回归看门狗：M>=4 且 N%4!=0 时，CPU 微内核的「末余量<4列」收尾曾经不累加，\n"
    "# 只留下最后一个 k 的乘积，最后 @@TAIL@@ 列静默算错。\n"
    "# 上一轮全部用例要么 M<4（走不进 4 行 FMA 组）、要么 N 是 4 的倍数，\n"
    "# 恰好绕开了这个条件组合，所以 159/159 全绿而 bug 健在。这个用例专门补上。\n"
    "# 数据 %3 压值域：f64 全部精确，期望值可用朴素三重循环算出来，无舍入争议。\n"
    "# M=@@M@@（%4==0，全部行都落在 4 行组内）、N=@@N@@（%4==1）、K=@@K@@（%4==0）\n"
    "func 造(行数, 列数, 乘子, 加数, 偏) {\n"
    "vg.外 = []\n"
    "rm.around(行数) -> i {\n"
    "vg.内 = []\n"
    "rm.around(列数) -> j {\n"
    "list.添加(内, (i * 乘子 + j * 加数 + 偏) % 3)\n"
    "}\n"
    "list.添加(外, 内)\n"
    "}\n"
    "ret 外\n"
    "}\n"
    "GOING:{\n"
    "vg.A = tensor.from(造(@@M@@, @@K@@, 7, 3, @@OFFA@@))\n"
    "vg.B = tensor.from(造(@@K@@, @@N@@, 7, 5, @@OFFB@@))\n"
    "vg.C = tb.dot(A, B)\n"
    "vg.表 = tensor.to_list(C)\n"
    "@@PROBES@@\n"
    "@@SHOWS@@\n"
    "}STOP\n"
)

SRC = (SRC_TMPL
       .replace("@@M@@", str(M))
       .replace("@@N@@", str(N))
       .replace("@@K@@", str(K))
       .replace("@@OFFA@@", str(OFF_A))
       .replace("@@OFFB@@", str(OFF_B))
       .replace("@@TAIL@@", str(N % 4))
       .replace("@@PROBES@@", "\n".join(lines))
       .replace("@@SHOWS@@", "\n".join(show_lines)))

if "@@" in SRC:
    raise SystemExit("模板还有未替换的占位符，拒绝写盘")

path = os.path.join("tests", "T23_cpu_dot_nmod4_ok.pybk")
if os.path.exists(path):
    raise SystemExit("%s 已存在，拒绝覆盖（换个用例名，或先确认再删）" % path)
with io.open(path, "w", encoding="utf-8", newline="\n") as f:
    f.write(SRC)

out = []
for (i, j) in probes:
    out.append("第%d行第%d列=%d" % (i, j, c_of(i, j)))
EXPECT = "\n".join(out) + "\n"

with io.open("_t23_case.txt", "w", encoding="utf-8", newline="\n") as f:
    f.write("# 追加到 tests/cases.py 末尾即可（id 唯一，未占用）\n")
    f.write("case(id='T23_cpu_dot_nmod4_ok', kind='normal',\n")
    f.write("     src=%r,\n" % SRC)
    f.write("     out=%r,\n" % EXPECT)
    f.write("     err='', err_contains=[], exit=0,\n")
    f.write("     expect='CPU 路径 M>=4 且 N%%4!=0：tb.dot 的最后 %d 列必须正确'\n" % (N % 4))
    f.write("           '（列尾巴曾把每个 kc 块只留最后一个 k 的乘积，静默错 1 列）')\n")

print("已写 %s" % path)
print("期望 stdout（%d 行）：" % len(probes))
print(EXPECT)
print("已写 _t23_case.txt（待并入 tests/cases.py）")
