# -*- coding: utf-8 -*-
"""_pfhigh.py — 高次 polyfit 的精度体检：跟 numpy 在同样输入上比最大系数缩放差。
正规方程的条件数是范德蒙德矩阵条件数的平方，所以次数一高就先在这里塌。"""
import subprocess
import numpy as np

r = subprocess.run(['_m2h.exe'], capture_output=True, text=True,
                   encoding='utf-8', errors='replace')
out = {}
for line in r.stdout.splitlines():
    if '\t' in line:
        k, v = line.split('\t', 1)
        try:
            out[k] = float(v)
        except ValueError:
            pass
if r.returncode != 0:
    print('harness 退出码 %d：%s' % (r.returncode, r.stderr[:400]))

CASES = []
x = np.arange(12.0)
CASES.append(('pf_d6', x, 1.0/(x + 1) + 0.5*(np.arange(12) % 3 - 1), 6))
# 注意：y 必须跟 C harness 里一样用**整数下标 t** 算，x 才取 t*0.5。
# 上一版这里写成 f(x2)，等于给两边喂了不同的数据，白查一场。
t = np.arange(20.0)
x2 = t * 0.5
CASES.append(('pf_d8', x2, 1.0 + 0.3*t + 0.02*t*t - 0.001*t*t*t, 8))

print('%-8s %-5s %-14s %-14s %s' % ('用例', '次数', 'C 最大系数', 'vs numpy 缩放差', '残差相对差'))
for nm, xa, ya, deg in CASES:
    got = [out.get('%s[%d]' % (nm, i)) for i in range(deg + 1)]
    if any(g is None for g in got):
        print('%-8s %-5d 缺失' % (nm, deg))
        continue
    ref = np.polyfit(xa, ya, deg)[::-1]
    scale = max(abs(g) for g in got) or 1.0
    diff = max(abs(g - rr) for g, rr in zip(got, ref)) / scale
    # 直接比拟合出来的曲线（这才是用户真正在意的）
    yc = np.polyval(got[::-1], xa)
    yr = np.polyval(ref[::-1], xa)
    rel = np.max(np.abs(yc - yr)) / max(np.max(np.abs(ya)), 1e-300)
    print('%-8s %-5d %-14.6g %-14.3e %.3e' % (nm, deg, max(abs(g) for g in got), diff, rel))
    print('         C 系数: ' + '  '.join('%+.6g' % g for g in got))
    print('         numpy : ' + '  '.join('%+.6g' % v for v in ref))
