/* PYbook MyMove3D（m3.*）实现：列表 → MC 方块 → hw.box */

#include "pybook_m3d.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <time.h>

#ifdef _WIN32
#  define WIN32_LEAN_AND_MEAN
#  include <windows.h>
#endif

/* 3D_highway 接口（实现在 pybook_hw3d.c） */
Value rt_hw_box(Value xv, Value yv, Value zv, Value wv, Value hv, Value dv,
                Value rv, Value gv, Value bv);
Value rt_hw_boxn(int nargs, Value *av);
Value rt_hw_tex(Value slot, Value path);
Value rt_hw_texuse(Value slot);
Value rt_hw_uv(Value n);
Value rt_hw_alpha(Value v);
Value rt_hw_spec(Value v);
Value rt_hw_uvoff(Value u, Value v);

/* mm 调色板（实现在 pybook_mm.c） */
int rt_mm_lookup(Value tok, int *r, int *g, int *b);
Value rt_mm_color(Value tok, Value r, Value g, Value b);

static void m3_die(const char *fmt, ...)
{
    va_list ap;
    fprintf(stderr, "运行时错误: m3.");
    va_start(ap, fmt);
    vfprintf(stderr, fmt, ap);
    va_end(ap);
    fputc('\n', stderr);
    exit(1);
}

static double m3_num(Value v, const char *who)
{
    if (IS_FLT(v))
        return AS_FLT(v);
    if (IS_INT(v) || IS_BIGINT(v))
        return (double)rt_to_ll(v);
    m3_die("%s 需要数字", who);
    return 0;
}

static long long m3_ll(Value v, const char *who)
{
    return (long long)m3_num(v, who);
}

/* ---- 贴图 token → 槽号 ---- */
typedef struct { char tok[16]; int slot; } M3Tex;
static M3Tex m3_texs[M3_TEX_SLOTS];
static int m3_ntex = 0;
static double m3_uv_rep = 1.0;

/* 玻璃 token：带 alpha；夜光 token：自发光 */
typedef struct { char tok[16]; int r, g, b; float alpha; int glow; } M3Special;
static M3Special m3_special[64];
static int m3_nspecial = 0;

static M3Special *m3_find_special(const char *tok)
{
    for (int i = 0; i < m3_nspecial; i++)
        if (!strcmp(m3_special[i].tok, tok))
            return &m3_special[i];
    return NULL;
}

int m3_lookup_token(const char *tok, int *r, int *g, int *b, int *texslot)
{
    if (!tok || !*tok)
        return 0;
    if (!strcmp(tok, ".") || !strcmp(tok, "_"))
        return 0;
    M3Special *sp = m3_find_special(tok);
    if (sp) {
        *r = sp->r;
        *g = sp->g;
        *b = sp->b;
        *texslot = 0;
        /* 5=金属 3=玻璃 4=夜光 6=纹路染色 */
        if (sp->glow == 2)
            return 5;
        if (sp->glow == 3) {
            /* 纹路：走贴图槽 + 染色 */
            for (int i = 0; i < m3_ntex; i++) {
                if (!strcmp(m3_texs[i].tok, tok)) {
                    *texslot = m3_texs[i].slot;
                    return 6;
                }
            }
            return 1;
        }
        return sp->alpha < 0.999f ? 3 : (sp->glow ? 4 : 1);
    }
    if (tok[0] == '#') {
        unsigned rr = 0, gg = 0, bb = 0;
        int slot = -1;
        const char *at = strchr(tok, '@');
        if (at) {
            slot = atoi(at + 1);
            if (sscanf(tok, "#%02x%02x%02x", &rr, &gg, &bb) == 3) {
                *r = (int)rr; *g = (int)gg; *b = (int)bb;
                if (slot >= 0 && slot < M3_TEX_SLOTS) {
                    *texslot = slot;
                    return 6;
                }
                return 1;
            }
            return -1;
        }
        if (strlen(tok) >= 7 && sscanf(tok, "#%02x%02x%02x", &rr, &gg, &bb) == 3) {
            *r = (int)rr;
            *g = (int)gg;
            *b = (int)bb;
            return 1;
        }
        return -1;
    }
    if (tok[0] == '@') {
        int slot = atoi(tok + 1);
        if (slot < 0 || slot >= M3_TEX_SLOTS)
            return -1;
        *texslot = slot;
        return 2;
    }
    for (int i = 0; i < m3_ntex; i++) {
        if (strcmp(m3_texs[i].tok, tok) == 0) {
            *texslot = m3_texs[i].slot;
            return 2;
        }
    }
    {
        Value tv = rt_str(tok);
        int kind = rt_mm_lookup(tv, r, g, b);
        if (kind == 1)
            return 1;
        if (kind == 0)
            return 0;
    }
    return -1;
}

/* ---- 解析模型列表 → M3Model ---- */
static int m3_parse(Value model, M3Model *out)
{
    memset(out, 0, sizeof *out);
    if (!IS_LIST(model) || AS_LIST(model) == NULL)
        m3_die("模型必须是列表（每个子列表 = 一个 Y 高度层）");
    RtList *L = AS_LIST(model);
    if (L->len == 0)
        m3_die("模型是空的");
    if (L->len > M3_MAX)
        m3_die("Y 层数超过 %d", M3_MAX);

    out->h = (int)L->len;
    int wmax = 0, dmax = 0;
    for (size_t y = 0; y < L->len; y++) {
        if (!IS_LIST(L->items[y]) || AS_LIST(L->items[y]) == NULL)
            m3_die("第 %zu 层必须是列表（行 = Z，格 = X）", y);
        RtList *layer = AS_LIST(L->items[y]);
        if (layer->len > M3_MAX)
            m3_die("第 %zu 层行数超过 %d", y, M3_MAX);
        if ((int)layer->len > dmax)
            dmax = (int)layer->len;
        for (size_t z = 0; z < layer->len; z++) {
            const char *row = rt_str_of(layer->items[z]);
            /* 双模式：有空格 / # / @ → token 模式（单格序列化行也是） */
            int token_mode = (strchr(row, ' ') != NULL
                              || strchr(row, '#') != NULL
                              || strchr(row, '@') != NULL);
            int x = 0;
            if (!token_mode) {
                /* 连写：按 UTF-8 字符；M3 色 token 多为单字符，先按字节试 mm */
                for (size_t j = 0; row[j]; ) {
                    char t2[2] = { row[j], 0 };
                    int r, g, b, ts;
                    int kind = m3_lookup_token(t2, &r, &g, &b, &ts);
                    if (kind < 0) {
                        /* 可能是多字节 UTF-8 单 token：跳过整码点当一个格 */
                        char t3[8];
                        size_t k = 0;
                        t3[k++] = row[j++];
                        while ((row[j] & 0xC0) == 0x80 && k < 7)
                            t3[k++] = row[j++];
                        t3[k] = 0;
                        kind = m3_lookup_token(t3, &r, &g, &b, &ts);
                        if (kind < 0)
                            m3_die("第 %zu 层第 %zu 行的 token '%s' 不认识（. _ 空气；m3.color / m3.texture）",
                                   y, z, t3);
                        if (kind > 0 && x < M3_MAX) {
                            out->kind[x][y][z] = (unsigned char)kind;
                            out->alpha[x][y][z] = 255;
                            if (kind == 1 || kind == 3 || kind == 4 || kind == 5 || kind == 6) {
                                out->rgb[x][y][z][0] = (unsigned char)r;
                                out->rgb[x][y][z][1] = (unsigned char)g;
                                out->rgb[x][y][z][2] = (unsigned char)b;
                                if (kind >= 3) {
                                    M3Special *sp = m3_find_special(t3);
                                    if (sp) out->alpha[x][y][z] = (unsigned char)(sp->alpha * 255.0f + 0.5f);
                                }
                            } else {
                                out->tex[x][y][z] = (unsigned char)ts;
                            }
                        }
                        x++;
                        continue;
                    }
                    if (kind > 0 && x < M3_MAX) {
                        out->kind[x][y][z] = (unsigned char)kind;
                        out->alpha[x][y][z] = 255;
                        if (kind == 1 || kind == 3 || kind == 4 || kind == 5 || kind == 6) {
                            out->rgb[x][y][z][0] = (unsigned char)r;
                            out->rgb[x][y][z][1] = (unsigned char)g;
                            out->rgb[x][y][z][2] = (unsigned char)b;
                            if (kind >= 3) {
                                M3Special *sp = m3_find_special(t2);
                                if (sp) out->alpha[x][y][z] = (unsigned char)(sp->alpha * 255.0f + 0.5f);
                            }
                            if (kind == 6) out->tex[x][y][z] = (unsigned char)ts;
                        } else {
                            out->tex[x][y][z] = (unsigned char)ts;
                        }
                    }
                    x++;
                    j++;
                }
            } else {
                size_t j = 0;
                while (row[j]) {
                    while (row[j] == ' ') j++;
                    if (!row[j]) break;
                    char tok[16];
                    size_t t = 0;
                    while (row[j] && row[j] != ' ' && t < 15)
                        tok[t++] = row[j++];
                    while (row[j] && row[j] != ' ') j++;
                    tok[t] = 0;
                    int r, g, b, ts;
                    int kind = m3_lookup_token(tok, &r, &g, &b, &ts);
                    if (kind < 0)
                        m3_die("第 %zu 层第 %zu 行的 token '%s' 不认识", y, z, tok);
                    if (kind > 0 && x < M3_MAX) {
                        out->kind[x][y][z] = (unsigned char)kind;
                        out->alpha[x][y][z] = 255;
                        if (kind == 1 || kind == 3 || kind == 4 || kind == 5 || kind == 6) {
                            out->rgb[x][y][z][0] = (unsigned char)r;
                            out->rgb[x][y][z][1] = (unsigned char)g;
                            out->rgb[x][y][z][2] = (unsigned char)b;
                            if (kind >= 3) {
                                M3Special *sp = m3_find_special(tok);
                                if (sp) out->alpha[x][y][z] = (unsigned char)(sp->alpha * 255.0f + 0.5f);
                            }
                            if (kind == 6) out->tex[x][y][z] = (unsigned char)ts;
                        } else {
                            out->tex[x][y][z] = (unsigned char)ts;
                        }
                    }
                    x++;
                }
            }
            if (x > wmax)
                wmax = x;
            if (x > M3_MAX)
                m3_die("第 %zu 层宽度超过 %d", y, M3_MAX);
        }
    }
    out->w = wmax;
    out->d = dmax;
    return 1;
}

int m3_count(const M3Model *m)
{
    int n = 0;
    for (int x = 0; x < m->w; x++)
        for (int y = 0; y < m->h; y++)
            for (int z = 0; z < m->d; z++)
                if (m->kind[x][y][z])
                    n++;
    return n;
}

void m3_bounds(const M3Model *m, int *w, int *h, int *d)
{
    *w = m->w;
    *h = m->h;
    *d = m->d;
}

/* ---- 绘制 ---- */
static void m3_draw_model(Value model, double ox, double oy, double oz,
                          double scale, int use_rot,
                          double rx, double ry, double rz)
{
    if (scale <= 0)
        m3_die("缩放必须为正");
    M3Model *mp = (M3Model *)calloc(1, sizeof(M3Model));
    if (!mp) m3_die("内存不足");
    m3_parse(model, mp);
    for (int y = 0; y < mp->h; y++) {
        for (int z = 0; z < mp->d; z++) {
            for (int x = 0; x < mp->w; x++) {
                int kind = mp->kind[x][y][z];
                if (!kind)
                    continue;
                double px = ox + x * scale;
                double py = oy + y * scale;
                double pz = oz + z * scale;
                rt_hw_alpha(rt_float(mp->alpha[x][y][z] / 255.0));
                rt_hw_spec(rt_float(kind == 5 ? 0.85 : 0.0));
                /* 石纹等：每块随机 UV 起点 + 微色差 */
                if (kind == 6) {
                    unsigned hsh = (unsigned)(x * 73856093u ^ y * 19349663u ^ z * 83492791u);
                    rt_hw_uvoff(rt_float((hsh % 7) / 8.0), rt_float(((hsh >> 3) % 7) / 8.0));
                    float jit = 0.88f + (float)((hsh >> 6) % 28) / 100.0f;
                    int trj = (int)(mp->rgb[x][y][z][0] * jit);
                    int tgj = (int)(mp->rgb[x][y][z][1] * jit);
                    int tbj = (int)(mp->rgb[x][y][z][2] * jit);
                    if (trj > 255) trj = 255;
                    if (tgj > 255) tgj = 255;
                    if (tbj > 255) tbj = 255;
                    mp->rgb[x][y][z][0] = (unsigned char)trj;
                    mp->rgb[x][y][z][1] = (unsigned char)tgj;
                    mp->rgb[x][y][z][2] = (unsigned char)tbj;
                } else {
                    rt_hw_uvoff(rt_float(0.0), rt_float(0.0));
                }
                if (kind == 2 || kind == 6) {
                    rt_hw_texuse(rt_int(mp->tex[x][y][z]));
                    int tr = 255, tg = 255, tb = 255;
                    if (kind == 6) {
                        tr = mp->rgb[x][y][z][0];
                        tg = mp->rgb[x][y][z][1];
                        tb = mp->rgb[x][y][z][2];
                    }
                    if (use_rot) {
                        Value av[12] = {
                            rt_float(px), rt_float(py), rt_float(pz),
                            rt_float(scale), rt_float(scale), rt_float(scale),
                            rt_int(tr), rt_int(tg), rt_int(tb),
                            rt_float(rx), rt_float(ry), rt_float(rz)
                        };
                        rt_hw_boxn(12, av);
                    } else {
                        rt_hw_box(rt_float(px), rt_float(py), rt_float(pz),
                                  rt_float(scale), rt_float(scale), rt_float(scale),
                                  rt_int(tr), rt_int(tg), rt_int(tb));
                    }
                    rt_hw_texuse(rt_int(0));
                } else {
                    int cr = mp->rgb[x][y][z][0];
                    int cg = mp->rgb[x][y][z][1];
                    int cb = mp->rgb[x][y][z][2];
                    if (kind == 4) {
                        /* 夜光：轻微提亮 */
                        if (cr < 240) cr += 15;
                        if (cg < 240) cg += 15;
                        if (cb < 240) cb += 15;
                    }
                    if (use_rot) {
                        Value av[12] = {
                            rt_float(px), rt_float(py), rt_float(pz),
                            rt_float(scale), rt_float(scale), rt_float(scale),
                            rt_int(cr), rt_int(cg), rt_int(cb),
                            rt_float(rx), rt_float(ry), rt_float(rz)
                        };
                        rt_hw_boxn(12, av);
                    } else {
                        rt_hw_box(rt_float(px), rt_float(py), rt_float(pz),
                                  rt_float(scale), rt_float(scale), rt_float(scale),
                                  rt_int(cr), rt_int(cg), rt_int(cb));
                    }
                }
            }
        }
    }
    rt_hw_alpha(rt_float(1.0));
    free(mp);
}

static long long m3_now_ms(void)
{
#ifdef _WIN32
    return (long long)GetTickCount64();
#else
    return (long long)(clock() * 1000 / CLOCKS_PER_SEC);
#endif
}

/* ---- 模型 → 列表（save / dig / put 用） ---- */
static void m3_model_to_list(const M3Model *m, Value *out)
{
    Value root = rt_list_new();
    for (int y = 0; y < m->h; y++) {
        Value layer = rt_list_new();
        for (int z = 0; z < m->d; z++) {
            char row[M3_MAX * 10 + 16];
            size_t p = 0;
            for (int x = 0; x < m->w; x++) {
                if (x) row[p++] = ' ';
                if (!m->kind[x][y][z]) {
                    row[p++] = '.';
                } else if (m->kind[x][y][z] == 2) {
                    p += (size_t)sprintf(row + p, "@%d", m->tex[x][y][z]);
                } else if (m->kind[x][y][z] == 6) {
                    /* 纹路染色：#rrggbb@槽 */
                    p += (size_t)sprintf(row + p, "#%02x%02x%02x@%d",
                                         m->rgb[x][y][z][0], m->rgb[x][y][z][1], m->rgb[x][y][z][2],
                                         m->tex[x][y][z]);
                } else {
                    p += (size_t)sprintf(row + p, "#%02x%02x%02x",
                                         m->rgb[x][y][z][0], m->rgb[x][y][z][1], m->rgb[x][y][z][2]);
                }
            }
            row[p] = 0;
            rt_push(&layer, rt_str(row));
        }
        rt_push(&root, layer);
    }
    *out = root;
}

/* ---- 绑定层 ---- */

Value rt_m3_color(Value tok, Value r, Value g, Value b)
{
    return rt_mm_color(tok, r, g, b);
}

Value rt_m3_texture(Value tok, Value path)
{
    const char *t = rt_str_of(tok);
    if (!*t || strlen(t) >= 15)
        m3_die("texture：token 长度 1..14");
    if (!strcmp(t, ".") || !strcmp(t, "_"))
        m3_die("texture：. 和 _ 是透明标记");
    const char *p = rt_str_of(path);
    if (!*p)
        m3_die("texture：路径不能为空");
    /* 已存在则覆盖路径（同槽） */
    for (int i = 0; i < m3_ntex; i++) {
        if (strcmp(m3_texs[i].tok, t) == 0) {
            rt_hw_tex(rt_int(m3_texs[i].slot), rt_str(p));
            return rt_none();
        }
    }
    if (m3_ntex >= M3_TEX_SLOTS)
        m3_die("texture：槽位已满（%d）", M3_TEX_SLOTS);
    /* hw.tex 槽位 1~7，0 = 无贴图 */
    int slot = m3_ntex + 1;
    memset(m3_texs[m3_ntex].tok, 0, sizeof m3_texs[m3_ntex].tok);
    strncpy(m3_texs[m3_ntex].tok, t, 15);
    m3_texs[m3_ntex].slot = slot;
    m3_ntex++;
    rt_hw_tex(rt_int(slot), rt_str(p));
    return rt_none();
}

/* UTF-8 路径 fopen（Windows 中文路径） */
static FILE *m3_fopen_utf8(const char *path, const char *mode)
{
#ifdef _WIN32
    wchar_t wp[512], wm[8];
    MultiByteToWideChar(CP_UTF8, 0, path, -1, wp, 512);
    MultiByteToWideChar(CP_UTF8, 0, mode, -1, wm, 8);
    return _wfopen(wp, wm);
#else
    return fopen(path, mode);
#endif
}

Value rt_m3_pack(Value dir)
{
    const char *root = rt_str_of(dir);
    if (!*root)
        m3_die("pack：目录不能为空");
    char manifest[512];
    snprintf(manifest, sizeof manifest, "%s/pack.txt", root);
    FILE *f = m3_fopen_utf8(manifest, "rb");
    if (!f) {
        f = m3_fopen_utf8(root, "rb");
        if (!f)
            m3_die("pack：找不到 %s/pack.txt", root);
        strncpy(manifest, root, sizeof manifest - 1);
        char *slash = strrchr(manifest, '/');
        if (!slash) slash = strrchr(manifest, '\\');
        if (slash) *slash = 0;
        else strcpy(manifest, ".");
    }
    char line[256];
    int n = 0;
    while (fgets(line, sizeof line, f)) {
        if (line[0] == '#' || line[0] == '\n' || line[0] == '\r')
            continue;
        char tok[16], file[200];
        if (sscanf(line, "%15s %199s", tok, file) != 2)
            continue;
        char full[512];
        snprintf(full, sizeof full, "%s/%s", manifest, file);
        rt_m3_texture(rt_str(tok), rt_str(full));
        n++;
    }
    fclose(f);
    return rt_int(n);
}

Value rt_m3_glass(Value tok, Value r, Value g, Value b, Value a)
{
    const char *t = rt_str_of(tok);
    if (!*t || strlen(t) >= 15)
        m3_die("glass：token 长度 1..14");
    if (m3_nspecial >= 64)
        m3_die("glass：特殊材质已满");
    M3Special *sp = m3_find_special(t);
    if (!sp) {
        sp = &m3_special[m3_nspecial++];
        memset(sp, 0, sizeof *sp);
        strncpy(sp->tok, t, 15);
    }
    sp->r = (int)m3_ll(r, "r");
    sp->g = (int)m3_ll(g, "g");
    sp->b = (int)m3_ll(b, "b");
    double al = m3_num(a, "alpha");
    if (al < 0.05) al = 0.05;
    if (al > 1.0) al = 1.0;
    sp->alpha = (float)al;
    sp->glow = 0;
    return rt_none();
}

Value rt_m3_glow(Value tok, Value r, Value g, Value b)
{
    const char *t = rt_str_of(tok);
    if (!*t || strlen(t) >= 15)
        m3_die("glow：token 长度 1..14");
    if (m3_nspecial >= 64)
        m3_die("glow：特殊材质已满");
    M3Special *sp = m3_find_special(t);
    if (!sp) {
        sp = &m3_special[m3_nspecial++];
        memset(sp, 0, sizeof *sp);
        strncpy(sp->tok, t, 15);
    }
    sp->r = (int)m3_ll(r, "r");
    sp->g = (int)m3_ll(g, "g");
    sp->b = (int)m3_ll(b, "b");
    sp->alpha = 1.0f;
    sp->glow = 1;
    return rt_none();
}

Value rt_m3_metal(Value tok, Value r, Value g, Value b)
{
    const char *t = rt_str_of(tok);
    if (!*t || strlen(t) >= 15)
        m3_die("metal：token 长度 1..14");
    if (m3_nspecial >= 64)
        m3_die("metal：特殊材质已满");
    M3Special *sp = m3_find_special(t);
    if (!sp) {
        sp = &m3_special[m3_nspecial++];
        memset(sp, 0, sizeof *sp);
        strncpy(sp->tok, t, 15);
    }
    sp->r = (int)m3_ll(r, "r");
    sp->g = (int)m3_ll(g, "g");
    sp->b = (int)m3_ll(b, "b");
    sp->alpha = 1.0f;
    sp->glow = 2;   /* 2 = 金属 */
    return rt_none();
}

/* m3.style(token, pattern, r, g, b)：表面纹路 + 染色
   pattern: wood/plank/brick/stone/tile/dots/lines/metal */
Value rt_m3_style(Value tok, Value pattern, Value r, Value g, Value b)
{
    const char *t = rt_str_of(tok);
    const char *pat = rt_str_of(pattern);
    if (!*t || strlen(t) >= 15)
        m3_die("style：token 长度 1..14");
    char path[256];
    snprintf(path, sizeof path, "材质/花纹/%s.png", pat);
    /* 绑到新槽（或复用同 token） */
    rt_m3_texture(rt_str(t), rt_str(path));
    M3Special *sp = m3_find_special(t);
    if (!sp) {
        if (m3_nspecial >= 64)
            m3_die("style：特殊材质已满");
        sp = &m3_special[m3_nspecial++];
        memset(sp, 0, sizeof *sp);
        strncpy(sp->tok, t, 15);
    }
    sp->r = (int)m3_ll(r, "r");
    sp->g = (int)m3_ll(g, "g");
    sp->b = (int)m3_ll(b, "b");
    sp->alpha = 1.0f;
    sp->glow = 3;   /* 3 = 纹路贴图 + 染色 */
    return rt_none();
}

Value rt_m3_uv(Value n)
{
    m3_uv_rep = m3_num(n, "m3.uv");
    return rt_hw_uv(n);
}

Value rt_m3_draw(Value model, Value x, Value y, Value z, Value scale)
{
    m3_draw_model(model, m3_num(x, "x"), m3_num(y, "y"), m3_num(z, "z"),
                  m3_num(scale, "scale"), 0, 0, 0, 0);
    return rt_none();
}

Value rt_m3_drawr(Value model, Value x, Value y, Value z, Value scale,
                  Value rx, Value ry, Value rz)
{
    m3_draw_model(model, m3_num(x, "x"), m3_num(y, "y"), m3_num(z, "z"),
                  m3_num(scale, "scale"), 1,
                  m3_num(rx, "rx"), m3_num(ry, "ry"), m3_num(rz, "rz"));
    return rt_none();
}

static void m3_draw_frame(Value frames, double x, double y, double z,
                          double scale, double fps, int use_rot,
                          double rx, double ry, double rz)
{
    if (!IS_LIST(frames) || AS_LIST(frames) == NULL)
        m3_die("anim：需要帧列表（每个元素是一个模型）");
    RtList *F = AS_LIST(frames);
    if (F->len == 0)
        m3_die("anim：帧列表是空的");
    long long fpsv = (long long)fps;
    if (fpsv < 1) fpsv = 1;
    long long idx = (m3_now_ms() / (1000 / fpsv)) % (long long)F->len;
    m3_draw_model(F->items[idx], x, y, z, scale, use_rot, rx, ry, rz);
}

Value rt_m3_anim(Value frames, Value x, Value y, Value z, Value scale, Value fps)
{
    m3_draw_frame(frames, m3_num(x, "x"), m3_num(y, "y"), m3_num(z, "z"),
                  m3_num(scale, "scale"), m3_num(fps, "fps"), 0, 0, 0, 0);
    return rt_none();
}

Value rt_m3_animr(Value frames, Value x, Value y, Value z, Value scale, Value fps,
                  Value rx, Value ry, Value rz)
{
    m3_draw_frame(frames, m3_num(x, "x"), m3_num(y, "y"), m3_num(z, "z"),
                  m3_num(scale, "scale"), m3_num(fps, "fps"), 1,
                  m3_num(rx, "rx"), m3_num(ry, "ry"), m3_num(rz, "rz"));
    return rt_none();
}

Value rt_m3_save(Value model, Value file)
{
    M3Model m;
    m3_parse(model, &m);
    const char *path = rt_str_of(file);
    FILE *f = fopen(path, "wb");
    if (!f)
        m3_die("save：打不开 %s", path);
    fputs("m3d1\n", f);
    for (int y = 0; y < m.h; y++) {
        if (y) fputs("---\n", f);
        for (int z = 0; z < m.d; z++) {
            for (int x = 0; x < m.w; x++) {
                if (!m.kind[x][y][z]) {
                    fputc('.', f);
                } else if (m.kind[x][y][z] == 2) {
                    fprintf(f, "@%d", m.tex[x][y][z]);
                } else {
                    fprintf(f, "#%02x%02x%02x",
                            m.rgb[x][y][z][0], m.rgb[x][y][z][1], m.rgb[x][y][z][2]);
                }
            }
            fputc('\n', f);
        }
    }
    fclose(f);
    return rt_str(path);
}

Value rt_m3_load(Value file)
{
    const char *path = rt_str_of(file);
    FILE *f = fopen(path, "rb");
    if (!f)
        m3_die("load：打不开 %s", path);
    char line[512];
    if (!fgets(line, sizeof line, f) || strncmp(line, "m3d1", 4) != 0) {
        fclose(f);
        m3_die("load：不是 m3d1 格式");
    }
    Value root = rt_list_new();
    Value layer = rt_list_new();
    int any = 0;
    while (fgets(line, sizeof line, f)) {
        size_t n = strlen(line);
        while (n && (line[n - 1] == '\n' || line[n - 1] == '\r'))
            line[--n] = 0;
        if (!strcmp(line, "---")) {
            if (any)
                rt_push(&root, layer);
            layer = rt_list_new();
            any = 0;
            continue;
        }
        /* 解析 #rrggbb / @N / . 到 token 行（token 模式） */
        char row[M3_MAX * 8 + 16];
        size_t p = 0;
        for (size_t i = 0; i < n && p < sizeof(row) - 16; ) {
            if (line[i] == '.') {
                if (p) row[p++] = ' ';
                row[p++] = '.';
                i++;
            } else if (line[i] == '#') {
                unsigned r = 0, g = 0, b = 0;
                if (i + 6 < n &&
                    sscanf(line + i, "#%02x%02x%02x", &r, &g, &b) == 3) {
                    if (p) row[p++] = ' ';
                    p += (size_t)sprintf(row + p, "#%02x%02x%02x", r, g, b);
                    i += 7;
                } else {
                    i++;
                }
            } else if (line[i] == '@') {
                int slot = 0;
                if (i + 1 < n && sscanf(line + i, "@%d", &slot) == 1) {
                    if (p) row[p++] = ' ';
                    p += (size_t)sprintf(row + p, "@%d", slot);
                    if (slot >= 0 && slot < 10) i += 2;
                    else if (slot >= 10 && slot < 100) i += 3;
                    else i += 4;
                } else {
                    i++;
                }
            } else {
                i++;
            }
        }
        row[p] = 0;
        rt_push(&layer, rt_str(row));
        any = 1;
    }
    if (any)
        rt_push(&root, layer);
    fclose(f);
    return root;
}

/* load 的 token 是 #hex / @N，解析器要认识 */
/* 扩展 m3_lookup_token：#rrggbb 与 @N */
/* （放在 lookup 前面太乱，这里用包装：parse 前先 normalize） */

Value rt_m3_merge(Value a, Value b, Value dx, Value dy, Value dz)
{
    M3Model *ma = (M3Model *)calloc(1, sizeof(M3Model));
    M3Model *mb = (M3Model *)calloc(1, sizeof(M3Model));
    M3Model *out = (M3Model *)calloc(1, sizeof(M3Model));
    if (!ma || !mb || !out)
        m3_die("内存不足");
    m3_parse(a, ma);
    m3_parse(b, mb);
    int ox = (int)m3_ll(dx, "dx"), oy = (int)m3_ll(dy, "dy"), oz = (int)m3_ll(dz, "dz");
    /* 拷 A */
    out->w = ma->w; out->h = ma->h; out->d = ma->d;
    memcpy(out->kind, ma->kind, sizeof out->kind);
    memcpy(out->rgb, ma->rgb, sizeof out->rgb);
    memcpy(out->tex, ma->tex, sizeof out->tex);
    /* 叠 B */
    for (int x = 0; x < mb->w; x++)
        for (int y = 0; y < mb->h; y++)
            for (int z = 0; z < mb->d; z++) {
                if (!mb->kind[x][y][z])
                    continue;
                int tx = x + ox, ty = y + oy, tz = z + oz;
                if (tx < 0 || ty < 0 || tz < 0 || tx >= M3_MAX || ty >= M3_MAX || tz >= M3_MAX)
                    continue;
                out->kind[tx][ty][tz] = mb->kind[x][y][z];
                memcpy(out->rgb[tx][ty][tz], mb->rgb[x][y][z], 3);
                out->tex[tx][ty][tz] = mb->tex[x][y][z];
                if (tx + 1 > out->w) out->w = tx + 1;
                if (ty + 1 > out->h) out->h = ty + 1;
                if (tz + 1 > out->d) out->d = tz + 1;
            }
    Value res;
    m3_model_to_list(out, &res);
    free(ma);
    free(mb);
    free(out);
    return res;
}

Value rt_m3_dig(Value model, Value x, Value y, Value z)
{
    M3Model m;
    m3_parse(model, &m);
    int ix = (int)m3_ll(x, "x"), iy = (int)m3_ll(y, "y"), iz = (int)m3_ll(z, "z");
    if (ix < 0 || iy < 0 || iz < 0 || ix >= m.w || iy >= m.h || iz >= m.d)
        return model;
    m.kind[ix][iy][iz] = 0;
    Value res;
    m3_model_to_list(&m, &res);
    return res;
}

Value rt_m3_put(Value model, Value x, Value y, Value z, Value tok)
{
    M3Model m;
    m3_parse(model, &m);
    int ix = (int)m3_ll(x, "x"), iy = (int)m3_ll(y, "y"), iz = (int)m3_ll(z, "z");
    if (ix < 0 || iy < 0 || iz < 0 || ix >= M3_MAX || iy >= M3_MAX || iz >= M3_MAX)
        m3_die("put：坐标越界");
    const char *t = rt_str_of(tok);
    int r, g, b, ts;
    int kind = m3_lookup_token(t, &r, &g, &b, &ts);
    if (kind < 0)
        m3_die("put：token '%s' 不认识", t);
    if (ix + 1 > m.w) m.w = ix + 1;
    if (iy + 1 > m.h) m.h = iy + 1;
    if (iz + 1 > m.d) m.d = iz + 1;
    if (!kind) {
        m.kind[ix][iy][iz] = 0;
    } else if (kind == 2) {
        m.kind[ix][iy][iz] = 2;
        m.tex[ix][iy][iz] = (unsigned char)ts;
    } else {
        m.kind[ix][iy][iz] = 1;
        m.rgb[ix][iy][iz][0] = (unsigned char)r;
        m.rgb[ix][iy][iz][1] = (unsigned char)g;
        m.rgb[ix][iy][iz][2] = (unsigned char)b;
    }
    Value res;
    m3_model_to_list(&m, &res);
    return res;
}

Value rt_m3_bounds(Value model)
{
    M3Model m;
    m3_parse(model, &m);
    Value out = rt_list_new();
    rt_push(&out, rt_int(m.w));
    rt_push(&out, rt_int(m.h));
    rt_push(&out, rt_int(m.d));
    return out;
}

Value rt_m3_count(Value model)
{
    M3Model m;
    m3_parse(model, &m);
    return rt_int(m3_count(&m));
}

/* ---- 建筑样式生成器 ---- */
static void m3_set_tok(M3Model *m, int x, int y, int z, const char *tok)
{
    int r, g, b, ts;
    int kind = m3_lookup_token(tok, &r, &g, &b, &ts);
    if (kind <= 0)
        m3_die("样式 token '%s' 不认识", tok);
    if (x < 0 || y < 0 || z < 0 || x >= M3_MAX || y >= M3_MAX || z >= M3_MAX)
        return;
    m->kind[x][y][z] = (unsigned char)kind;
    m->alpha[x][y][z] = 255;
    if (kind == 1 || kind == 3 || kind == 4 || kind == 5 || kind == 6) {
        m->rgb[x][y][z][0] = (unsigned char)r;
        m->rgb[x][y][z][1] = (unsigned char)g;
        m->rgb[x][y][z][2] = (unsigned char)b;
        if (kind >= 3) {
            M3Special *sp = m3_find_special(tok);
            if (sp) m->alpha[x][y][z] = (unsigned char)(sp->alpha * 255.0f + 0.5f);
        }
        if (kind == 6)
            m->tex[x][y][z] = (unsigned char)ts;
    } else {
        m->tex[x][y][z] = (unsigned char)ts;
    }
    if (x + 1 > m->w) m->w = x + 1;
    if (y + 1 > m->h) m->h = y + 1;
    if (z + 1 > m->d) m->d = z + 1;
}

/* 楼梯：steps 级，每级高 1、深 1、宽 w */
Value rt_m3_stair(Value w, Value steps, Value tok)
{
    int ww = (int)m3_ll(w, "w");
    int ns = (int)m3_ll(steps, "steps");
    if (ww < 1 || ns < 1 || ww > M3_MAX || ns > M3_MAX)
        m3_die("stair：尺寸须为 1..%d", M3_MAX);
    const char *t = rt_str_of(tok);
    M3Model *m = (M3Model *)calloc(1, sizeof(M3Model));
    if (!m) m3_die("内存不足");
    for (int s = 0; s < ns; s++) {
        for (int x = 0; x < ww; x++) {
            for (int z = 0; z <= s; z++)
                m3_set_tok(m, x, s, z, t);
        }
    }
    Value res;
    m3_model_to_list(m, &res);
    free(m);
    return res;
}

/* 平板（石板/木板面） */
Value rt_m3_slab(Value w, Value d, Value tok)
{
    int ww = (int)m3_ll(w, "w");
    int dd = (int)m3_ll(d, "d");
    if (ww < 1 || dd < 1)
        m3_die("slab：尺寸须为正");
    const char *t = rt_str_of(tok);
    M3Model *m = (M3Model *)calloc(1, sizeof(M3Model));
    if (!m) m3_die("内存不足");
    for (int x = 0; x < ww; x++)
        for (int z = 0; z < dd; z++)
            m3_set_tok(m, x, 0, z, t);
    Value res;
    m3_model_to_list(m, &res);
    free(m);
    return res;
}

/* 空心墙/房间外壳 */
Value rt_m3_wall(Value w, Value h, Value d, Value tok)
{
    int ww = (int)m3_ll(w, "w");
    int hh = (int)m3_ll(h, "h");
    int dd = (int)m3_ll(d, "d");
    if (ww < 2 || hh < 1 || dd < 2)
        m3_die("wall：宽深至少 2，高至少 1");
    const char *t = rt_str_of(tok);
    M3Model *m = (M3Model *)calloc(1, sizeof(M3Model));
    if (!m) m3_die("内存不足");
    for (int y = 0; y < hh; y++)
        for (int x = 0; x < ww; x++)
            for (int z = 0; z < dd; z++) {
                int edge = (x == 0 || x == ww - 1 || z == 0 || z == dd - 1 || y == 0);
                if (edge)
                    m3_set_tok(m, x, y, z, t);
            }
    Value res;
    m3_model_to_list(m, &res);
    free(m);
    return res;
}

/* 柱子 */
Value rt_m3_pillar(Value h, Value tok)
{
    int hh = (int)m3_ll(h, "h");
    if (hh < 1)
        m3_die("pillar：高度须为正");
    const char *t = rt_str_of(tok);
    M3Model *m = (M3Model *)calloc(1, sizeof(M3Model));
    if (!m) m3_die("内存不足");
    for (int y = 0; y < hh; y++)
        m3_set_tok(m, 0, y, 0, t);
    Value res;
    m3_model_to_list(m, &res);
    free(m);
    return res;
}

/* 斜屋顶（对称坡） */
Value rt_m3_roof(Value w, Value d, Value tok)
{
    int ww = (int)m3_ll(w, "w");
    int dd = (int)m3_ll(d, "d");
    if (ww < 2 || dd < 2)
        m3_die("roof：宽深至少 2");
    const char *t = rt_str_of(tok);
    M3Model *m = (M3Model *)calloc(1, sizeof(M3Model));
    if (!m) m3_die("内存不足");
    int peak = dd / 2;
    for (int z = 0; z < dd; z++) {
        int y = peak - (z <= peak ? z : dd - 1 - z);
        if (y < 0) y = 0;
        for (int x = 0; x < ww; x++)
            for (int yy = 0; yy <= y; yy++)
                m3_set_tok(m, x, yy, z, t);
    }
    Value res;
    m3_model_to_list(m, &res);
    free(m);
    return res;
}

/* 栅栏：n 根柱 + 横杆 */
Value rt_m3_fence(Value n, Value tok)
{
    int nn = (int)m3_ll(n, "n");
    if (nn < 2)
        m3_die("fence：至少 2 根");
    const char *t = rt_str_of(tok);
    M3Model *m = (M3Model *)calloc(1, sizeof(M3Model));
    if (!m) m3_die("内存不足");
    for (int i = 0; i < nn; i++) {
        m3_set_tok(m, i * 2, 0, 0, t);
        m3_set_tok(m, i * 2, 1, 0, t);
        m3_set_tok(m, i * 2, 2, 0, t);
        if (i + 1 < nn) {
            m3_set_tok(m, i * 2 + 1, 1, 0, t);
        }
    }
    Value res;
    m3_model_to_list(m, &res);
    free(m);
    return res;
}
