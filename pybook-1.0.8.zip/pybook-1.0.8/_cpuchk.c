/* _cpuchk.c —— 让 CPU 自己报指令集，并实测单核 FMA 峰值。
 *
 * 为什么不用 WMI 的 Win32_Processor.Flags：那个字段不带 AVX2/FMA 这些位，
 * 查 i5-10400F 会答「都没有」，是假阴性。
 *
 * 为什么还要测单核峰值：六核 dgemm 能不能打满，光看「现在 145 GFLOPS」
 * 说不出是内核不行还是并行不行。先把单核天花板量出来当分母，
 * 才分得清「改内核」和「改并行」各能拿多少。
 */
#include <windows.h>
#include <stdio.h>
#include <immintrin.h>

static double now(void)
{
    LARGE_INTEGER f, c;
    QueryPerformanceFrequency(&f);
    QueryPerformanceCounter(&c);
    return (double)c.QuadPart / (double)f.QuadPart;
}

int main(void)
{
    __m256d a = _mm256_set1_pd(1.0000001);
    __m256d b = _mm256_set1_pd(0.9999999);
    __m256d c[8];
    int i, k, rep;
    double t0, t1, best = 1e30, s = 0;
    long long iters = 20000000L;

    __builtin_cpu_init();
    printf("__builtin_cpu_supports:\n");
    printf("  avx2    %d\n", __builtin_cpu_supports("avx2"));
    printf("  fma     %d\n", __builtin_cpu_supports("fma"));
    printf("  avx512f %d\n", __builtin_cpu_supports("avx512f"));

    for (i = 0; i < 8; i++) c[i] = _mm256_setzero_pd();
    /* 8 条独立 FMA 链，与 pybook_tb.c 的 MR=4 / NR=8 寄存器分块同构 */
    for (rep = 0; rep < 5; rep++) {
        t0 = now();
        for (i = 0; i < iters; i++) {
            c[0] = _mm256_fmadd_pd(a, b, c[0]);
            c[1] = _mm256_fmadd_pd(a, b, c[1]);
            c[2] = _mm256_fmadd_pd(a, b, c[2]);
            c[3] = _mm256_fmadd_pd(a, b, c[3]);
            c[4] = _mm256_fmadd_pd(a, b, c[4]);
            c[5] = _mm256_fmadd_pd(a, b, c[5]);
            c[6] = _mm256_fmadd_pd(a, b, c[6]);
            c[7] = _mm256_fmadd_pd(a, b, c[7]);
        }
        t1 = now();
        if (t1 - t0 < best) best = t1 - t0;
    }
    /* 每轮 8 条链 × 4 个 double × 2 flops = 64 flop */
    printf("单核 FMA 峰值 = %.1f GFLOPS\n", 64.0 * (double)iters / best / 1e9);

    for (i = 0; i < 8; i++) {
        double t[4];
        _mm256_storeu_pd(t, c[i]);
        s += t[0] + t[1] + t[2] + t[3];
    }
    printf("(防优化校验和 %.3e)\n", s);
    return 0;
}
