# -*- coding: utf-8 -*-
"""BMP -> PNG 转换（只为看图，不参与任何验证逻辑）。

出图存 BMP 是因为零依赖最好写，但 BMP 太大且各平台不认。转 PNG 纯粹为了
能直接看。**像素数据一个字节都不动**（BMP 里已是 RGB 顺序，stb 读回后
逐像素换过），所以转换器不做任何颜色通道处理。
"""
import os
import sys

from PIL import Image


def conv(src, dst=None):
    if dst is None:
        dst = os.path.splitext(src)[0] + ".png"
    im = Image.open(src)
    im.save(dst)
    return dst, im.size, os.path.getsize(dst)


if __name__ == "__main__":
    args = sys.argv[1:]
    if not args:
        raise SystemExit(__doc__)
    for a in args:
        p, size, n = conv(a)
        print("%s -> %s  %dx%d  %d 字节" % (a, p, size[0], size[1], n))
