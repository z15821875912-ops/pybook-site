/* PYbook 名字映射（语言名 -> C 名） */
/* @ 验货>粒子冻结>1 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <setjmp.h>
#include "pybook_rt.h"
#include "pybook_lib.h"

/* 3D_highway（实现在 pybook_hw3d.c） */
Value rt_hw_open(Value, Value, Value);
Value rt_hw_clearcolor(Value, Value, Value);
Value rt_hw_camera(Value, Value, Value, Value, Value);
Value rt_hw_box(Value, Value, Value, Value, Value, Value, Value, Value, Value);
Value rt_hw_frame(void);
Value rt_hw_end(void);
Value rt_hw_key(Value);
Value rt_hw_hit(Value);
Value rt_hw_mx(void);
Value rt_hw_my(void);
Value rt_hw_mdown(void);
Value rt_hw_mhit(void);
Value rt_hw_text(Value, Value, Value, Value);
Value rt_hw_grab(void);
Value rt_hw_free(void);
Value rt_hw_mdx(void);
Value rt_hw_mdy(void);
Value rt_hw_wheel(void);
Value rt_hw_textc(Value, Value, Value, Value, Value, Value, Value);
Value rt_hw_rect(Value, Value, Value, Value, Value, Value, Value);
Value rt_hw_post(Value);
Value rt_hw_postfx(Value, Value);
Value rt_hw_shadow(Value);
Value rt_hw_shadowres(Value);
Value rt_hw_shadowarea(Value);
Value rt_hw_shadowbias(Value);
Value rt_hw_shadowcenter(Value, Value, Value);
Value rt_hw_bloom(Value, Value);
Value rt_hw_particles_clear(void);
Value rt_hw_burst(Value, Value, Value, Value, Value, Value, Value, Value, Value, Value, Value);
Value rt_hw_particles(Value);
Value rt_hw_boxn(int nargs, Value *av);
Value rt_hw_fog(Value, Value);
Value rt_hw_far(Value);
Value rt_hw_wire(Value);
Value rt_hw_line(Value, Value, Value, Value, Value, Value, Value, Value, Value);
Value rt_hw_light(Value, Value, Value, Value);
Value rt_hw_sphere(Value, Value, Value, Value, Value, Value, Value);
Value rt_hw_cylv(int nargs, Value *av);
Value rt_hw_fov(Value);
Value rt_hw_wininfo(void);
Value rt_hw_resize(Value, Value);
Value rt_hw_near(Value);
Value rt_hw_ortho(Value);
Value rt_hw_tex(Value, Value);
Value rt_hw_texuse(Value);
Value rt_hw_uv(Value);
Value rt_hw_push(Value, Value, Value, Value, Value, Value);
Value rt_hw_pop(void);
Value rt_hw_shader(Value, Value, Value);
Value rt_hw_preset(Value, Value);
Value rt_hw_shaderuse(Value);
Value rt_hw_univ(int nargs, Value *av);
Value rt_hw_obj(Value);
Value rt_hw_objinfo(Value);
Value rt_hw_objfix(Value, Value);
Value rt_hw_objcolor(Value, Value, Value, Value);
Value rt_hw_objdraw(Value, Value, Value, Value, Value);
Value rt_hw_objdrawr(Value, Value, Value, Value, Value, Value, Value, Value);
Value rt_hw_objfree(Value);
Value rt_hw_objh(Value, Value, Value);
Value rt_hw_rdown(void);
Value rt_hw_rhit(void);
/* 桌面 GUI（实现在 pybook_ui.c，立即模式 / SDL2 自绘） */
Value rt_ui_begin(Value, Value, Value);
Value rt_ui_row(void);
Value rt_ui_col(void);
Value rt_ui_end(void);
Value rt_ui_gap(Value);
Value rt_ui_tag(Value);
Value rt_ui_label(Value, Value);
Value rt_ui_button(Value);
Value rt_ui_input(Value);
Value rt_ui_slider(Value, Value, Value);
Value rt_ui_check(Value, Value);
Value rt_ui_table(Value, Value, Value, Value);


/* 绘(列表)：精灵属性读取（缺属性 → 带序号报错） */
static Value _pbk_sprop(Value obj, const char *name, long long idx)
{
    RtObject *o;
    size_t k;
    if (!IS_OBJ(obj)) {
        fprintf(stderr, "运行时错误: 绘 第 %lld 个元素不是对象\n");
        exit(1);
    }
    o = AS_OBJ(obj);
    for (k = 0; k < o->nprops; k++)
        if (strcmp(o->names[k], name) == 0)
            return o->vals[k];
    fprintf(stderr, "运行时错误: 绘 第 %lld 个元素缺少属性 %s\n", idx + 1, name);
    exit(1);
}
static Value _pbk_half(Value v, long long idx)
{
    if (IS_INT(v))
        return rt_int(AS_INT(v) / 2);
    if (IS_FLT(v))
        return rt_int((long long)(AS_FLT(v) / 2));
    fprintf(stderr, "运行时错误: 绘 第 %lld 个元素的宽/高需要是数字\n", idx + 1);
    exit(1);
}
Value rt_mec_apply(Value fv, Value av);

/* 类继承：类名 -> 父类名 */
static const char* rt_parent_of(const char* cls) {
    return "";
}
static int rt_inst_of(const char* x, const char* c) {
    while (x && *x) { if (strcmp(x, c) == 0) return 1; x = rt_parent_of(x); }
    return 0;
}

/* mec.apply：mec 库的 lambda/函数动态分发（编译器生成） */
Value rt_mec_apply(Value fv, Value av) {
    RtList *A = AS_LIST(av);
    if (IS_LIST(fv)) {
        RtList *P = AS_LIST(fv);
        Value nv = rt_list_new();
        for (size_t i = 1; i < P->len; i++) rt_push(&nv, P->items[i]);
        for (size_t i = 0; i < A->len; i++) rt_push(&nv, A->items[i]);
        fv = P->items[0];
        av = nv;
        A = AS_LIST(av);
    }
    const char *nm = rt_str_of(fv);
    rt_die("mec.apply: 未知函数 %s", nm);
    return rt_none();
}

int main(void) {
    setvbuf(stdout, NULL, _IONBF, 0);   /* 输出即时可见，供交互输入 */
    rt_set_fn_dispatch(rt_mec_apply);
    rt_scope_enter();
        g_cur_line = 2;
        rt_device_set(2, 0);
        rt_gc_poll();
        g_cur_line = 5;
        Value _t1 = rt_int(800LL);
        Value _t2 = rt_int(500LL);
        Value _t3 = rt_str("冻结粒子");
        rt_hw_open(_t1, _t2, _t3);
        rt_gc_poll();
        g_cur_line = 6;
        Value _t4 = rt_int(5LL);
        Value _t5 = rt_int(5LL);
        Value _t6 = rt_int(12LL);
        rt_hw_clearcolor(_t4, _t5, _t6);
        rt_gc_poll();
        g_cur_line = 7;
        Value _t7 = rt_int(0LL);
        Value _t8 = rt_float(1.5);
        Value _t9 = rt_int(6LL);
        Value _t10 = rt_int(0LL);
        Value _t11 = rt_int(0LL);
        rt_hw_camera(_t7, _t8, _t9, _t10, _t11);
        rt_gc_poll();
        g_cur_line = 8;
        rt_hw_particles_clear();
        rt_gc_poll();
        g_cur_line = 9;
        Value _t12 = rt_int(400LL);
        Value _t13 = rt_int(0LL);
        Value _t14 = rt_float(1.2);
        Value _t15 = rt_int(0LL);
        Value _t16 = rt_int(0LL);
        Value _t17 = rt_int(0LL);
        Value _t18 = rt_int(255LL);
        Value _t19 = rt_int(190LL);
        Value _t20 = rt_int(80LL);
        Value _t21 = rt_int(9999LL);
        Value _t22 = rt_int(6LL);
        rt_hw_burst(_t12, _t13, _t14, _t15, _t16, _t17, _t18, _t19, _t20, _t21, _t22);
        rt_gc_poll();
        g_cur_line = 10;
        Value _t23 = rt_int(0LL);
        rt_hw_particles(_t23);
        rt_gc_poll();
        g_cur_line = 11;
        for (;;) {
            if (rt_cond(rt_hw_end())) break;
                g_cur_line = 12;
                Value _t24 = rt_int(0LL);
                Value _t25 = rt_float(1.5);
                Value _t26 = rt_int(6LL);
                Value _t27 = rt_int(0LL);
                Value _t28 = rt_int(0LL);
                rt_hw_camera(_t24, _t25, _t26, _t27, _t28);
                rt_gc_poll();
                g_cur_line = 13;
                Value _t29 = rt_int(0LL);
                rt_hw_particles(_t29);
                rt_gc_poll();
                g_cur_line = 14;
                rt_hw_frame();
                rt_gc_poll();
        }
        rt_gc_poll();
    rt_scope_leave();
    return 0;
}