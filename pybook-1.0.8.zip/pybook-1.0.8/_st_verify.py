# -*- coding: utf-8 -*-
"""_st_verify.py — 把统计函数逐个与 numpy 对拍（同一批输入，不各写各的 RNG）"""
import io, subprocess, sys, math
import numpy as np

CASES = [
    ([3, 1, 4, 1, 5, 9, 2, 6], 'median'),
    ([1, 2, 2, 3, 3, 3, 4], 'mode'),
    ([1, 1, 2], 'mode'),                 # 全并列：并列取最小
    ([5], 'median'),                     # 单元素
    ([1, 2, 3, 4], 'quantile0.5'),
    ([1, 2, 3, 4], 'quantile0'),
    ([1, 2, 3, 4], 'quantile0.25'),
    ([1, 2, 3, 4], 'quantile0.75'),
    ([1, 2, 3, 4], 'percentile50'),
    ([1, 2, 3, 4], 'percentile90'),
    ([2.5, -1, 7.25, 0, 100], 'median'),
    ([2.5, -1, 7.25, 0, 100], 'quantile0.3'),
]

lines = ['@ pybk>测试>统计对拍', 'GOING:{']
k = 0
for data, kind in CASES:
    if kind == 'median':
        expr = 'mp.median(%s)' % data
    elif kind == 'mode':
        expr = 'mp.mode(%s)' % data
    elif kind.startswith('quantile'):
        expr = 'mp.quantile(%s, %s)' % (data, kind.split('quantile')[1])
    else:
        expr = 'mp.percentile(%s, %s)' % (data, kind.split('percentile')[1])
    lines.append('vg.r%d = %s' % (k, expr))
    lines.append('ns.show(第%d项=$r%d)' % (k, k))
    k += 1
lines += ['}STOP']
src = '\n'.join(lines) + '\n'
io.open('_st_cmp.pybk', 'w', encoding='utf-8', newline='\n').write(src)

p = subprocess.run([sys.executable, '-B', 'main.py', '_st_cmp.pybk'],
                   capture_output=True, text=True, encoding='utf-8', errors='replace',
                   timeout=300)
if p.returncode != 0:
    print('运行失败:\n' + p.stderr)
    sys.exit(1)

got = []
for line in p.stdout.replace('\r\n', '\n').split('\n'):
    if line.startswith('第'):
        got.append(float(line.split('=')[1]))

bad = 0
for (data, kind), g in zip(CASES, got):
    a = np.array(data, dtype=float)
    if kind == 'median':
        ref = np.median(a)
    elif kind == 'mode':
        vals, cnt = np.unique(a, return_counts=True)
        ref = vals[cnt.argmax()]          # numpy 无 mode，取出现次数最多的第一个
    elif kind.startswith('quantile'):
        ref = np.quantile(a, float(kind.split('quantile')[1]))
    else:
        ref = np.percentile(a, float(kind.split('percentile')[1]))
    ok = (g == ref) or abs(g - ref) <= 1e-12 * max(1.0, abs(ref))
    if not ok:
        bad += 1
    print('%s %-28s PYbook=%-20r numpy=%-20r' % ('✓' if ok else '✗',
                                                 '%s %s' % (kind, data), g, ref))

# cumsum / diff / cov / corr 单独对
print()
extra = '''@ pybk>测试>统计对拍2
GOING:{
vg.a = mp.cumsum([1, 2, 3, 4])
vg.b = mp.diff([1, 4, 9, 16])
vg.c = mp.cov([1, 2, 3, 4], [2, 4, 6, 8])
vg.d = mp.corr([1, 2, 3, 4], [2, 4, 6, 8])
vg.e = mp.corr([1, 2, 3, 4], [5, 3, -1, 2])
ns.show(cumsum=$a)
ns.show(diff=$b)
ns.show(cov=$c)
ns.show(corr1=$d)
ns.show(corr2=$e)
}STOP
'''
io.open('_st_cmp2.pybk', 'w', encoding='utf-8', newline='\n').write(extra)
p = subprocess.run([sys.executable, '-B', 'main.py', '_st_cmp2.pybk'],
                   capture_output=True, text=True, encoding='utf-8', errors='replace',
                   timeout=300)
if p.returncode != 0:
    print('运行失败:\n' + p.stderr)
    sys.exit(1)
g2 = {}
for line in p.stdout.replace('\r\n', '\n').split('\n'):
    if '=' in line:
        k, v = line.split('=', 1)
        g2[k.strip()] = v.strip()

x = np.array([1., 2., 3., 4.]); y = np.array([2., 4., 6., 8.])
z = np.array([5., 3., -1., 2.])
checks = [
    ('cumsum', eval(g2['cumsum']), np.cumsum(x)),
    ('diff',   eval(g2['diff']),   np.diff(np.array([1., 4., 9., 16.]))),
    ('cov',    float(g2['cov']),    np.cov(x, y, ddof=1)[0, 1]),
    ('corr1',  float(g2['corr1']),  np.corrcoef(x, y)[0, 1]),
    ('corr2',  float(g2['corr2']),  np.corrcoef(x, z)[0, 1]),
]
for name, g, ref in checks:
    if isinstance(ref, np.ndarray):
        ok = len(g) == len(ref) and all(abs(a - b) <= 1e-12 for a, b in zip(g, ref))
    else:
        ok = abs(g - ref) <= 1e-12 * max(1.0, abs(ref))
    if not ok:
        bad += 1
    print('%s %-8s PYbook=%-24r numpy=%r' % ('✓' if ok else '✗', name, g, ref))

print('\n不合格 %d 项' % bad)
sys.exit(1 if bad else 0)
