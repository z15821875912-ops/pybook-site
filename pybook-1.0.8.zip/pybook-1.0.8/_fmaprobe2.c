/* _fmaprobe2.c —— 隔离实验：把 _gppeak.c 新增的 CPU 内核搬进探针，
 * 看 host_replay 的结果会不会跟着变。
 *
 * 现象：_gppeak.c 的宿主参考算出 14.74259，而同样的 host_replay 单独编出来
 * 算的是 15.8535948（与 GPU 逐位一致）。两者源码逐字相同、编译选项相同。
 * 这一轮唯一的差别就是 _gppeak.c 里多了 cpu_fma_v / cpu_fma_ref。
 *
 * 用法：gcc _fmaprobe2.c -o _fp2.exe -O3 -march=native -lm & .\_fp2.exe
 */
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <immintrin.h>
#include "_fmareal_const.h"

#define CPU_ACC   8
#define CPU_LANES (CPU_ACC * 8)

static void cpu_fma_v(const float *init, float *out, unsigned iters)
{
    __m256 a[CPU_ACC];
    int c;
    unsigned it;
    int s;
    for (c = 0; c < CPU_ACC; c++) a[c] = _mm256_loadu_ps(init + c * 8);
    for (it = 0; it < iters; it++)
        for (s = 0; s < FM_S; s++)
            for (c = 0; c < CPU_ACC; c++)
                a[c] = _mm256_fmadd_ps(a[c], _mm256_set1_ps(FMK[s][c]),
                                       _mm256_set1_ps(FMB[c]));
    for (c = 0; c < CPU_ACC; c++) _mm256_storeu_ps(out + c * 8, a[c]);
}

static void cpu_fma_ref(const float *init, float *out, unsigned iters)
{
    float acc[CPU_LANES];
    int L;
    unsigned it;
    int s;
    for (L = 0; L < CPU_LANES; L++) acc[L] = init[L];
    for (it = 0; it < iters; it++)
        for (s = 0; s < FM_S; s++)
            for (L = 0; L < CPU_LANES; L++)
                acc[L] = fmaf(acc[L], FMK[s][L / 8], FMB[L / 8]);
    for (L = 0; L < CPU_LANES; L++) out[L] = acc[L];
}

/* ---- 与 _gppeak.c 里逐字相同的两个版本 ---- */

/* 版本 S：静态，被 main 调用（可能被内联） */
static void host_replay_static(float *acc, unsigned iters)
{
    unsigned it, s;
    int c;
    for (it = 0; it < iters; it++)
        for (s = 0; s < FM_S; s++)
            for (c = 0; c < FM_NC; c++)
                acc[c] = fmaf(acc[c], FMK[s][c], FMB[c]);
}

/* 版本 N：明确不许内联，用来分辨「是不是内联干的」 */
__attribute__((noinline))
static void host_replay_noinline(float *acc, unsigned iters)
{
    unsigned it, s;
    int c;
    for (it = 0; it < iters; it++)
        for (s = 0; s < FM_S; s++)
            for (c = 0; c < FM_NC; c++)
                acc[c] = fmaf(acc[c], FMK[s][c], FMB[c]);
}

/* 版本 M：关掉 FMA 收缩的版本，用来看两次舍入会不会正好等于那个 14.74259 */
__attribute__((noinline))
static void host_replay_muladd(float *acc, unsigned iters)
{
    unsigned it, s;
    int c;
    for (it = 0; it < iters; it++)
        for (s = 0; s < FM_S; s++)
            for (c = 0; c < FM_NC; c++)
                acc[c] = acc[c] * FMK[s][c] + FMB[c];   /* 有意写成非融合 */
}

static void show(const char *tag, const float *v, int n)
{
    int i;
    printf("%-22s", tag);
    for (i = 0; i < n; i++) printf(" %.9g", (double)v[i]);
    printf("\n");
}

int main(void)
{
    float a[FM_NC], b[FM_NC], d[FM_NC];
    int c;

    /* 版本 M 必须关掉收缩，否则 GCC 会把它又变回一次舍入 */
    /* 这行 pragma 放在函数外面统一控制 */
    for (c = 0; c < FM_NC; c++) a[c] = 0.5f + (float)c * 0.03125f;
    host_replay_static(a, 64);
    for (c = 0; c < FM_NC; c++) b[c] = 0.5f + (float)c * 0.03125f;
    host_replay_noinline(b, 64);
    for (c = 0; c < FM_NC; c++) d[c] = 0.5f + (float)c * 0.03125f;
    host_replay_muladd(d, 64);

    printf("iters=64, FM_S=%d, FM_NC=%d\n", FM_S, FM_NC);
    printf("GPU 实测应为 15.8535948 ...\n\n");
    show("static fmaf", a, FM_NC);
    show("noinline fmaf", b, FM_NC);
    show("muladd (两次舍入)", d, FM_NC);

    printf("\nstatic vs noinline 相同? %s\n",
           memcmp(a, b, sizeof a) == 0 ? "是" : "否 <<<< 内联改了结果");
    printf("static vs muladd   相同? %s\n",
           memcmp(a, d, sizeof a) == 0 ? "是" : "否 <<<< 是两次舍入的问题");

    /* CPU 两条路径之间也应当一致 */
    {
        float ci[CPU_LANES], cv[CPU_LANES], cr[CPU_LANES];
        int L, mism = 0;
        for (L = 0; L < CPU_LANES; L++) ci[L] = 0.5f + (float)L * 0.03125f;
        memset(cv, 0, sizeof cv);
        cpu_fma_v(ci, cv, 64);
        cpu_fma_ref(ci, cr, 64);
        for (L = 0; L < CPU_LANES; L++)
            if (memcmp(&cv[L], &cr[L], sizeof(float)) != 0) mism++;
        printf("\nCPU 向量内核 vs 标量参考：%d/%d 逐位相同\n",
               CPU_LANES - mism, CPU_LANES);
        show("CPU lane0-7", cv, 8);
    }
    return 0;
}
