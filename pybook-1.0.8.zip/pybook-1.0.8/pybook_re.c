/* PYbook 标准库实现：re（正则）。
 * 接口见 pybook_lib.h；只依赖 pybook_rt 与自研零依赖引擎 pybook_re_engine.h。
 * 字节级 POSIX-ish ERE 子集：字面、. * + ? | () [] ^ $ 与 \d \w \s（含大写取反）。
 * 多字节（如中文）按字节匹配，纯 ASCII 模式与字面串完全正常；\w 等为 ASCII 语义（v1 限制）。
 *
 * 暴露的 API（中英文同名皆可，注册见 pybk_front.py / pybk_code.py）：
 *   re.match / re.匹配(模式, 文本)        -> 真/假（是否在文本中任意位置匹配）
 *   re.find  / re.查找(模式, 文本)        -> 列表（所有不重叠匹配串）
 *   re.sub   / re.替换(模式, 替换, 文本)   -> 文本（把所有匹配替换为「替换」）
 *   re.valid / re.有效(模式)              -> 真/假（模式能否编译）
 *   re.groups/ re.分组(模式, 文本)        -> 列表（首个匹配的各捕获组；无匹配=空列表）
 */

#include "pybook_lib.h"
#include "pybook_re_engine.h"
#include <stdlib.h>
#include <string.h>

/* 取字符串参数，非字符串直接 rt_die（与 te.* 一致的错误模型） */
static const char *need_str(Value v, const char *who)
{
    if (!IS_STR(v))
        rt_die("%s 需要文本参数", who);
    return AS_STR(v);
}

/* 取 [base+so, base+eo) 子串为字符串盒（自包含，不依赖 lib_val_range） */
static Value sub_str(const char *base, int so, int eo)
{
    size_t n = (size_t)(eo - so);
    char *tmp = (char *)malloc(n + 1);
    if (tmp == NULL)
        rt_die("内存不足");
    memcpy(tmp, base + so, n);
    tmp[n] = '\0';
    Value v = rt_str(tmp);
    free(tmp);
    return v;
}

/* 编译模式；失败则把引擎错误抛成运行时错误 */
static void compile_re(const char *pat, re_prog *pr, const char *who)
{
    char errbuf[256];
    if (re_compile(pr, pat, errbuf, sizeof errbuf) != 0)
        rt_die("%s：正则模式非法：%s", who, pr->err[0] ? pr->err : errbuf);
}

/* ================= 各 API 实现 ================= */

Value rt_lib_re_match(Value patv, Value textv)
{
    const char *pat  = need_str(patv,  "re.match 第 1 个参数");
    const char *text = need_str(textv, "re.match 第 2 个参数");
    re_prog pr;
    compile_re(pat, &pr, "re.match");
    int ms, me;
    re_caps caps;
    int r = re_search(&pr, text, (int)strlen(text), &ms, &me, &caps);
    return rt_bool(r == 1);
}

Value rt_lib_re_find(Value patv, Value textv)
{
    const char *pat  = need_str(patv,  "re.find 第 1 个参数");
    const char *text = need_str(textv, "re.find 第 2 个参数");
    re_prog pr;
    compile_re(pat, &pr, "re.find");
    Value out = rt_list_new();
    int len = (int)strlen(text);
    int start = 0;
    for (;;) {
        int ms, me;
        re_caps caps;
        /* 在 text+start 子串里搜索（偏移相对子串，取回需加上 start） */
        int r = re_search(&pr, text + start, len - start, &ms, &me, &caps);
        if (r != 1)
            break;
        int abs_so = start + ms, abs_eo = start + me;
        rt_push(&out, sub_str(text, abs_so, abs_eo));
        /* 零宽匹配时至少前进一步，避免死循环 */
        start = (me > ms) ? abs_eo : (abs_so + 1);
        if (start >= len)
            break;
    }
    return out;
}

Value rt_lib_re_sub(Value patv, Value repv, Value textv)
{
    const char *pat  = need_str(patv, "re.sub 第 1 个参数");
    const char *rep  = need_str(repv, "re.sub 第 2 个参数");
    const char *text = need_str(textv, "re.sub 第 3 个参数");
    re_prog pr;
    compile_re(pat, &pr, "re.sub");

    int len = (int)strlen(text);
    /* 自包含可增长缓冲（不依赖 Buf/buf_put，那些是 pybook_lib.c 的 static） */
    size_t cap = 64, blen = 0;
    char *buf = (char *)malloc(cap);
    if (buf == NULL)
        rt_die("内存不足");
#define GB_ENSURE(n) do { if (blen + (size_t)(n) + 1 > cap) { cap = (blen + (size_t)(n) + 1) * 2; buf = (char *)realloc(buf, cap); if (!buf) rt_die("内存不足"); } } while (0)

    int start = 0;
    for (;;) {
        int ms, me;
        re_caps caps;
        int r = re_search(&pr, text + start, len - start, &ms, &me, &caps);
        if (r != 1)
            break;
        int abs_so = start + ms, abs_eo = start + me;
        GB_ENSURE(abs_so - start);
        memcpy(buf + blen, text + start, (size_t)(abs_so - start));
        blen += (size_t)(abs_so - start);
        GB_ENSURE((int)strlen(rep));
        memcpy(buf + blen, rep, strlen(rep));
        blen += strlen(rep);
        /* 零宽匹配时至少前进一步，避免死循环 */
        start = (me > ms) ? abs_eo : (abs_so + 1);
        if (start >= len)
            break;
    }
    /* 把剩余尾巴拷进去 */
    GB_ENSURE(len - start);
    memcpy(buf + blen, text + start, (size_t)(len - start));
    blen += (size_t)(len - start);
    buf[blen] = '\0';
    Value v = rt_str(buf);
    free(buf);
    return v;
#undef GB_ENSURE
}

Value rt_lib_re_valid(Value patv)
{
    const char *pat = need_str(patv, "re.valid");
    re_prog pr;
    char errbuf[256];
    int rc = re_compile(&pr, pat, errbuf, sizeof errbuf);
    return rt_bool(rc == 0);
}

Value rt_lib_re_groups(Value patv, Value textv)
{
    const char *pat  = need_str(patv,  "re.groups 第 1 个参数");
    const char *text = need_str(textv, "re.groups 第 2 个参数");
    re_prog pr;
    compile_re(pat, &pr, "re.groups");
    Value out = rt_list_new();
    int len = (int)strlen(text);
    int ms, me;
    re_caps caps;
    int r = re_search(&pr, text, len, &ms, &me, &caps);
    if (r == 1) {
        for (int g = 1; g < RE_MAXCAP; g++) {
            if (caps.so[g] < 0)
                break; /* 该组及之后均未参与匹配 */
            rt_push(&out, sub_str(text, caps.so[g], caps.eo[g]));
        }
    }
    return out;
}
