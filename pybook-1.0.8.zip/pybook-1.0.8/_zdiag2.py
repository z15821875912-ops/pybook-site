# -*- coding: utf-8 -*-
"""_zdiag2.py — 上一版诊断自己有个错：Decimal(repr(s)) 把 double 1.001 当成十进制 1.001。
真值是 1.001000000000000000888178…，差 8.9e-19 —— 在 s→1 处会被 1/(s-1)² 放大。
这次用 Decimal(s)（精确二进制值）当参考，并逐项拆开对比。"""
from decimal import Decimal, getcontext
from fractions import Fraction

getcontext().prec = 40
BF = [float(Fraction(1, 12)), float(Fraction(-1, 720)), float(Fraction(1, 30240)),
      float(Fraction(-1, 1209600)), float(Fraction(1, 47900160)),
      float(Fraction(-691, 1307674368000))]


def terms_hi(s, N):
    """全部按精确十进制算，返回 (有限和, 主尾项, 全部修正项之和)"""
    sD = Decimal(s)                      # 精确二进制值
    ND = Decimal(N)
    ssum = sum(Decimal(i) ** (-sD) for i in range(1, N))
    t = ND ** (-sD)
    tail = Decimal('0.5')*t + t*ND/(sD - 1)
    ps = sD
    corr = Decimal(0)
    for k in range(6):
        if k > 0:
            for i in range(2):
                ps *= (sD + 2*k - 1 + i)
        corr += Decimal(BF[k])*ps*ND ** (-sD - 2*k - 1)
    return ssum, tail, corr


print('%-9s %-8s %-13s %-13s %-13s %-13s' %
      ('s', 'N', '有限和误差', '主尾项误差', '修正项误差', '合计相对误差'))
for s, N in ((1.001, 10016), (1.0001, 100016), (1.01, 1015), (1.5, 36), (2.0, 26)):
    hs, ht, hc = terms_hi(s, N)
    ref = hs + ht + hc

    d_ssum = sum(float(i)**(-s) for i in range(1, N))
    t = N**(-s)
    d_tail = 0.5*t + t*N/(s-1.0)
    ps = s
    d_corr = 0.0
    for k in range(6):
        if k > 0:
            for i in range(2):
                ps *= (s + 2.0*k - 1.0 + i)
        d_corr += BF[k]*ps*N**(-s-2.0*k-1.0)
    total = d_ssum + d_tail + d_corr

    print('%-9s %-8d %-13.2e %-13.2e %-13.2e %-13.2e'
          % (s, N, float(abs(Decimal(d_ssum) - hs)), float(abs(Decimal(d_tail) - ht)),
             float(abs(Decimal(d_corr) - hc)), float(abs(Decimal(total) - ref)/abs(ref))))

print()
print('结论用：把 s 的十进制写法当成参考会虚报 %.1e 量级的误差' % 1e-13)
