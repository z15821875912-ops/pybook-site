# -*- coding: utf-8 -*-
"""_wire_math.py — 补齐基础数学函数（实测缺口：全库连 exp 和 log 都没有）

只往里加，不改任何既有实现。行尾按各文件原有风格写。
"""
import io

# ---------------------------------------------------------------- 1. C 实现
C_SRC = r'''
/* ================= mt 基础数学补齐（exp/log 族、反三角、双曲、符号与特判）=================
 * 起因是实测摸底：v2.0 的 mt.* 只有 sqrt/pow/abs/ceil/floor/mod/pi + sin/cos/tan/atan2，
 * **全库连 exp 和 log 都没有**，反三角只剩 atan2，双曲一个没有。
 * sin/cos/tan 有了但反过来求不出来、指数与对数两条最基本的非线性变换缺席，
 * softmax / log-loss / 数据标准化都得手写级数展开，这是实打实的缺口。
 *
 * 域外输入一律 rt_die 报三段式，不静默返回 NaN：宁可报错，也不要让一个 NaN
 * 顺着后面的运算一路污染下去，到最后看不出是哪一步出的问题（与 tb.cholesky 同一条原则）。
 */

/* exp/log 族：lib_num 先做类型检查，这里再做定义域检查 */
static double lib_pos(double x, const char *who, double lo)
{
    if (!(x > lo))
        rt_die("%s 的定义域是 (%g, +∞)，收到 %g\n"
               "  为什么：%s 在非正（或非正于 lo）处没有实数定义，返回 NaN 只会把错误带到后面\n"
               "  怎么改：先确认输入；对数类在 0 附近不稳定时改用 mt.log1p（算的是 log(1+x)）",
               who, lo, x, who);
    return x;
}

Value rt_lib_mt_exp(Value a)
{
    return rt_float(exp(lib_num(a, "mt.exp")));
}

Value rt_lib_mt_expm1(Value a)
{
    return rt_float(expm1(lib_num(a, "mt.expm1")));
}

Value rt_lib_mt_log(Value a)
{
    double x = lib_num(a, "mt.log");
    return rt_float(log(lib_pos(x, "mt.log", 0.0)));
}

Value rt_lib_mt_log2(Value a)
{
    double x = lib_num(a, "mt.log2");
    return rt_float(log2(lib_pos(x, "mt.log2", 0.0)));
}

Value rt_lib_mt_log10(Value a)
{
    double x = lib_num(a, "mt.log10");
    return rt_float(log10(lib_pos(x, "mt.log10", 0.0)));
}

/* log1p 算 log(1+x)：x 极小时（1+x 在 double 里已经等于 1，直接算 log 会得 0）用这个 */
Value rt_lib_mt_log1p(Value a)
{
    double x = lib_num(a, "mt.log1p");
    if (!(x > -1.0))
        rt_die("mt.log1p 的定义域是 (-1, +∞)，收到 %g\n"
               "  为什么：log(1+x) 在 x<=-1 处没有实数定义\n"
               "  怎么改：确认 1+x 为正；x 很小是正常的，那正是该用 log1p 而不是 log 的场合", x);
    return rt_float(log1p(x));
}

/* 反三角：实数定义域都是 [-1,1] */
static double lib_unit(double x, const char *who)
{
    if (!(x >= -1.0 && x <= 1.0))
        rt_die("%s 的定义域是 [-1, 1]，收到 %g\n"
               "  为什么：这个角的正弦/余弦不可能超出 ±1，域外返回 NaN 是无意义的\n"
               "  怎么改：先确认入参；若本意是「两个数求夹角」，用 mt.atan2(y, x)", who, x);
    return x;
}

Value rt_lib_mt_asin(Value a)
{
    return rt_float(asin(lib_unit(lib_num(a, "mt.asin"), "mt.asin")));
}

Value rt_lib_mt_acos(Value a)
{
    return rt_float(acos(lib_unit(lib_num(a, "mt.acos"), "mt.acos")));
}

Value rt_lib_mt_atan(Value a)
{
    return rt_float(atan(lib_num(a, "mt.atan")));
}

/* 双曲及其反函数。acosh 要 >=1，atanh 要在 (-1,1) 内 */
Value rt_lib_mt_sinh(Value a) { return rt_float(sinh(lib_num(a, "mt.sinh"))); }
Value rt_lib_mt_cosh(Value a) { return rt_float(cosh(lib_num(a, "mt.cosh"))); }
Value rt_lib_mt_tanh(Value a) { return rt_float(tanh(lib_num(a, "mt.tanh"))); }
Value rt_lib_mt_asinh(Value a){ return rt_float(asinh(lib_num(a, "mt.asinh"))); }

Value rt_lib_mt_acosh(Value a)
{
    double x = lib_num(a, "mt.acosh");
    if (!(x >= 1.0))
        rt_die("mt.acosh 的定义域是 [1, +∞)，收到 %g\n"
               "  为什么：cosh 的值恒 >=1，小于 1 的输入没有实数解\n"
               "  怎么改：确认入参；计算 log(x + sqrt(x*x-1)) 时也要先保证 x>=1", x);
    return rt_float(acosh(x));
}

Value rt_lib_mt_atanh(Value a)
{
    double x = lib_num(a, "mt.atanh");
    if (!(x > -1.0 && x < 1.0))
        rt_die("mt.atanh 的定义域是 (-1, 1)，收到 %g\n"
               "  为什么：|tanh| 恒小于 1，域外发散\n"
               "  怎么改：确认入参；x 接近 ±1 时结果会非常大，属正常", x);
    return rt_float(atanh(x));
}

/* cbrt：立方根，负数也有意义；pow(x, 1/3) 对负数会得到 NaN（那是复数分支） */
Value rt_lib_mt_cbrt(Value a)
{
    return rt_float(cbrt(lib_num(a, "mt.cbrt")));
}

/* hypot：√(x²+y²)。直接写 mt.sqrt(x*x + y*y) 在 x、y 很大时会先溢出成 inf */
Value rt_lib_mt_hypot(Value a, Value b)
{
    return rt_float(hypot(lib_num(a, "mt.hypot 的 x"), lib_num(b, "mt.hypot 的 y")));
}

/* trunc 截断取整：跟 floor/ceil 一样返回整数，只是向零取 */
Value rt_lib_mt_trunc(Value n)
{
    return rt_int(lib_round_to_ll(trunc(lib_num(n, "mt.trunc")), "mt.trunc"));
}

/* sign：-1 / 0 / 1，0 单独挑出来——不能直接写 (x>0)-(x<0) 后套 float，
 * 因为那样 0 会变成 -0.0，显示出来很难看 */
Value rt_lib_mt_sign(Value n)
{
    double x = lib_num(n, "mt.sign");
    if (x > 0.0) return rt_int(1);
    if (x < 0.0) return rt_int(-1);
    return rt_int(0);
}

/* fmod 截断取余，与 mt.mod 不同：mt.mod 是 Python 语义（向 -∞ 取整，结果可负），
 * fmod 是 C 语义（向 0 截断，结果符号跟被除数同号）。两者用错会差一个整数量级。 */
Value rt_lib_mt_fmod(Value a, Value b)
{
    double x = lib_num(a, "mt.fmod 的被除数");
    double y = lib_num(b, "mt.fmod 的除数");
    if (y == 0.0)
        rt_die("mt.fmod 的除数不能为 0\n"
               "  为什么：除零没有定义，C 的 fmod 在这里返回 NaN\n"
               "  怎么改：先判断除数是否非零");
    return rt_float(fmod(x, y));
}

/* 特殊值判定：分母、判别式、优化过程里 NaN/Inf 是最常见的污染源，
 * 能查出来就别等它一路流到结果上去 */
Value rt_lib_mt_is_nan(Value n)
{
    return rt_bool(isnan(lib_num(n, "mt.is_nan")));
}

Value rt_lib_mt_is_inf(Value n)
{
    return rt_bool(isinf(lib_num(n, "mt.is_inf")));
}
'''

# ---------------------------------------------------------------- 2. 头文件原型
H_DECLS = """/* ---- exp/log 族（v2.1 补：此前全库没有 exp 也没有 log）---- */
Value rt_lib_mt_exp(Value a);                     /* mt.exp(x)        e^x */
Value rt_lib_mt_expm1(Value a);                   /* mt.expm1(x)      e^x - 1（x 很小时用） */
Value rt_lib_mt_log(Value a);                     /* mt.log(x)        自然对数，x>0 */
Value rt_lib_mt_log2(Value a);                    /* mt.log2(x) */
Value rt_lib_mt_log10(Value a);                   /* mt.log10(x) */
Value rt_lib_mt_log1p(Value a);                   /* mt.log1p(x)      log(1+x)，x 很小时用 */

/* ---- 反三角（atan2 早已有，补齐 asin/acos/atan）---- */
Value rt_lib_mt_asin(Value a);                    /* mt.asin(x)  |x|<=1 */
Value rt_lib_mt_acos(Value a);                    /* mt.acos(x)  |x|<=1 */
Value rt_lib_mt_atan(Value a);                    /* mt.atan(x) */

/* ---- 双曲 ---- */
Value rt_lib_mt_sinh(Value a);
Value rt_lib_mt_cosh(Value a);
Value rt_lib_mt_tanh(Value a);
Value rt_lib_mt_asinh(Value a);
Value rt_lib_mt_acosh(Value a);                   /* x>=1 */
Value rt_lib_mt_atanh(Value a);                   /* |x|<1 */

/* ---- 根 / 取整 / 符号 / 特判 ---- */
Value rt_lib_mt_cbrt(Value a);                    /* 立方根，负数有意义 */
Value rt_lib_mt_hypot(Value a, Value b);          /* √(x²+y²)，大数不溢出 */
Value rt_lib_mt_trunc(Value n);                   /* 向零取整（floor/ceil 已有） */
Value rt_lib_mt_sign(Value n);                    /* -1 / 0 / 1 */
Value rt_lib_mt_fmod(Value a, Value b);           /* 截断取余（C 语义，与 mt.mod 不同） */
Value rt_lib_mt_is_nan(Value n);                  /* mt.is_nan(x) -> 真/假 */
Value rt_lib_mt_is_inf(Value n);                  /* mt.is_inf(x) -> 真/假 */
"""

# (前端名, 参数个数, C 函数名)
ENTRIES = [
    ('mt.exp', 1, 'rt_lib_mt_exp'), ('mt.expm1', 1, 'rt_lib_mt_expm1'),
    ('mt.log', 1, 'rt_lib_mt_log'), ('mt.log2', 1, 'rt_lib_mt_log2'),
    ('mt.log10', 1, 'rt_lib_mt_log10'), ('mt.log1p', 1, 'rt_lib_mt_log1p'),
    ('mt.asin', 1, 'rt_lib_mt_asin'), ('mt.acos', 1, 'rt_lib_mt_acos'),
    ('mt.atan', 1, 'rt_lib_mt_atan'),
    ('mt.sinh', 1, 'rt_lib_mt_sinh'), ('mt.cosh', 1, 'rt_lib_mt_cosh'),
    ('mt.tanh', 1, 'rt_lib_mt_tanh'), ('mt.asinh', 1, 'rt_lib_mt_asinh'),
    ('mt.acosh', 1, 'rt_lib_mt_acosh'), ('mt.atanh', 1, 'rt_lib_mt_atanh'),
    ('mt.cbrt', 1, 'rt_lib_mt_cbrt'), ('mt.hypot', 2, 'rt_lib_mt_hypot'),
    ('mt.trunc', 1, 'rt_lib_mt_trunc'), ('mt.sign', 1, 'rt_lib_mt_sign'),
    ('mt.fmod', 2, 'rt_lib_mt_fmod'),
    ('mt.is_nan', 1, 'rt_lib_mt_is_nan'), ('mt.is_inf', 1, 'rt_lib_mt_is_inf'),
]


def rd(p):
    return io.open(p, encoding='utf-8', newline='').read()


def wr(p, t):
    io.open(p, 'w', encoding='utf-8', newline='').write(t)


# ---- pybook_lib.c：接在 rt_lib_mt_atan2 之后 ----
p = 'pybook_lib.c'
t = rd(p)
assert 'rt_lib_mt_exp' not in t, '已打过补丁了'
anchor = 'Value rt_lib_te_str(Value v)'
i = t.index(anchor)
t = t[:i] + C_SRC.replace('\n', '\r\n').lstrip('\r\n') + '\r\n' + t[i:]
wr(p, t)
print('pybook_lib.c 已加实现')

# ---- pybook_lib.h：接在 atan2 原型之后 ----
p = 'pybook_lib.h'
t = rd(p)
if 'rt_lib_mt_exp' in t:
    print('pybook_lib.h 已有原型，跳过')
else:
    anchor = 'Value rt_lib_mt_atan2(Value y, Value x);'
    i = t.index(anchor)
    eol = '\r\n' if '\r\n' in t else '\n'
    blk = anchor + eol + eol + H_DECLS.replace('\n', eol).rstrip(eol) + eol
    t = t[:i] + blk + t[i + len(anchor):]
    wr(p, t)
    print('pybook_lib.h 已加原型')

# ---- pybk_front.py : LIB_CALLS ----
p = 'pybk_front.py'
t = rd(p)
if "'mt.asin'" in t:
    print('pybk_front.py 已接线')
else:
    lines = [k for k, _a, _c in ENTRIES]
    blk = ("\n    # ---- 基础数学补齐：exp/log 族、反三角、双曲、符号与特判"
           "（v2.0 只有 sin/cos/tan/atan2，连 exp 和 log 都没有）----\n"
           + ''.join("    '%s': %d,\n" % (n, a) for n, a, _ in ENTRIES))
    anchor = "'tb.shuffle': 2, 'tb.onehot': 2, 'tb.batch': 3,\n"
    i = t.index(anchor) + len(anchor)
    t = t[:i] + blk + t[i:]
    wr(p, t)
    print('pybk_front.py 已接线 (%d 个)' % len(lines))

# ---- pybk_code.py : LIB_C_NAMES ----
p = 'pybk_code.py'
t = rd(p)
if "'mt.asin'" in t:
    print('pybk_code.py 已接线')
else:
    blk = ("        # 基础数学补齐（exp/log 族、反三角、双曲、符号与特判）\n"
           + ''.join("        '%s': '%s',\n" % (n, c) for n, _a, c in ENTRIES))
    anchor = "        'tb.dot': 'rt_tb_dot', 'tb.tr': 'rt_tb_tr',\n"
    i = t.index(anchor) + len(anchor)
    t = t[:i] + blk + t[i:]
    wr(p, t)
    print('pybk_code.py 已接线 (%d 个)' % len(ENTRIES))

# ---- _vm_lib_calls.inc ----
p = '_vm_lib_calls.inc'
t = rd(p)
eol = '\r\n' if '\r\n' in t else '\n'
if '"mt.asin"' in t:
    print('_vm_lib_calls.inc 已接线')
else:
    a = 'Value rt_lib_mt_atan2(Value, Value);' + eol
    i = t.index(a) + len(a)
    decls = ''.join('Value %s(%s);%s' % (c, ', '.join(['Value'] * n), eol)
                    for _k, n, c in ENTRIES)
    t = t[:i] + decls + t[i:]
    b = '    {"mt.atan2", 2, (void *)rt_lib_mt_atan2},' + eol
    j = t.index(b) + len(b)
    rows = ''.join('    {"%s", %d, (void *)%s},%s' % (k, n, c, eol)
                   for k, n, c in ENTRIES)
    t = t[:j] + rows + t[j:]
    wr(p, t)
    print('_vm_lib_calls.inc 已接线 (%d 个)' % len(ENTRIES))

print('合计新增 %d 个入口' % len(ENTRIES))
