import subprocess, sys, io
sys.stdout.reconfigure(encoding='utf-8')

V = ['vg.数据 = [\n    ["城市", "人口", "面积"],\n    ["北京", 2189, 16410],\n    ["上海", 2487, 6340],\n    ["广州", 1868, 7434],\n    ["深圳", 1766, 1997],\n]']
V3 = [l for l in V[0].split('\n') if '广州' not in l and '深圳' not in l and ']"' not in l]
V3 = '\n'.join(V3).rstrip()
if not V3.endswith(']'):
    V3 = V3[:V3.rfind('[')] + ']'

CASES = {
    '5行3列 表.画空表头': V[0] + '\nvg.框 = 表.画(数据, [])\nns.show("长度", 长度(框))\n',
    '5行3列 表.画有表头': V[0] + '\nvg.框 = 表.画(数据, ["地区","万人","平方公里"])\nns.show("长度", 长度(框))\n',
    '5行3列 只调表.宽':   V[0] + '\nns.show("宽", 表.宽(数据))\n',
    '5行3列 只调表.列':   V[0] + '\nvg.列 = 表.列(数据, "人口")\nns.show("列长", 长度(列))\n',
    '5行3列 只调表.行-1': V[0] + '\nvg.行 = 表.行(数据, -1)\nns.show("行", 行)\n',
    '5行3列 只调表.行1':  V[0] + '\nvg.行 = 表.行(数据, 1)\nns.show("行", 行)\n',
    '3行3列 表.画':       V3 + '\nvg.框 = 表.画(数据, [])\nns.show("长度", 长度(框))\n',
}

for name, body in CASES.items():
    io.open('_最小.pybk', 'w', encoding='utf-8', newline='\n').write(
        '@ 最小>%s\n\nGOING:{\n%s\n}STOP\n' % (name, body))
    print('=== %s ===' % name, flush=True)
    try:
        r = subprocess.run([sys.executable, 'pybk_main.py', '_最小.pybk'],
                           capture_output=True, text=True, encoding='utf-8',
                           timeout=150, errors='replace')
        out = [l for l in (r.stdout or '').split('\n') if l.strip()]
        print('  rc=%d  %s' % (r.returncode, ' | '.join(out[-2:])))
    except subprocess.TimeoutExpired:
        print('  超时')
