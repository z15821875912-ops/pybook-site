# -*- coding: utf-8 -*-
"""n=4 到底卡在哪：撞上限？还是停滞？还是窗口不动？

用法：python -B _eigfail.py
"""
import numpy as np
import _eigref as R

rng = np.random.default_rng(7)
for n in (1, 2):
    for trial in range(3):
        rng.standard_normal((n, n))
for trial in range(1):
    A = rng.standard_normal((3, 3))
A = rng.standard_normal((4, 4))
n = 4
print("A =\n", A)
print("真特征值 =", np.sort_complex(np.linalg.eigvals(A)))

t, q = R.hessenberg(A)
u = n - 1
its = 0
zero_shift = False
stalls = 0
while u >= 0 and its < 400:
    while u > 0:
        sub = abs(t[u, u - 1])
        nrm = abs(t[u - 1, u - 1]) + abs(t[u, u])
        if sub > np.finfo(float).eps * (nrm + sub):
            break
        t[u, u - 1] = 0.0
        u -= 1
    if u == 0:
        break
    l = u - 1
    while l > 0 and t[l, l - 1] != 0.0:
        l -= 1
    while l < u - 1 and t[l + 1, l] == 0.0:
        l += 1
    if u - l == 1:
        wr, wi = R.eig2x2(t[u - 1, u - 1], t[u - 1, u], t[u, u - 1], t[u, u])
        R.rot2x2(t, q, n, u - 1, u)
        print("  its=%4d 窗口 [l,u]=[%d,%d] → 2x2 收尾，特征值 %.6g %+.6gi / %.6g %+.6gi"
              % (its, l, u, wr[0], wi[0], wr[1], wi[1]))
        u -= 2
        if u < 0:
            break
        continue
    st = R.francis(t, q, n, l, u, zero_shift)
    if st:
        stalls += 1
        if stalls == 1:
            print("  its=%4d 窗口 [%d,%d] **停滞**，改用应急移位" % (its, l, u))
            print("     第 l 列 =", t[l:l + u - l + 1, l])
        if zero_shift:
            print("  its=%4d 应急移位下仍停滞 → 放弃" % its)
            break
        zero_shift = True
    else:
        zero_shift = False
        if its % 20 == 0:
            print("  its=%4d 窗口 [%d,%d] 子对角链 = %s" %
                  (its, l, u, np.round([t[k + 1, k] for k in range(l, u)], 6)))
    its += 1
print("\n结束：u=%d its=%d 停滞次数=%d" % (u, its, stalls))
print("T =\n", t)
print("‖A − QTQᵀ‖ = %.3e   ‖QᵀQ − I‖ = %.3e" %
      (np.abs(A - q @ t @ q.T).max(), np.abs(q.T @ q - np.eye(n)).max()))
print("对角 =", np.round(np.diag(t), 6))