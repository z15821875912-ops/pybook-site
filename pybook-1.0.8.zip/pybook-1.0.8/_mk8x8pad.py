# -*- coding: utf-8 -*-
"""_mk8x8pad.py -- 给 sA 加一格填充，消掉 A 段共享读的 bank 冲突。

为什么是这一处（依据是指令模型，不是猜）：
    每个 K-tile 每线程要读 64 次标量 A + 16 次 v4 B。
    按 Pascal 每 SM 每周期 128 字节算：
      A 标量读 64 次 x 2 路冲突 = 128 周期
      B v4 读   16 次 x 4（v4 本底就要 4 周期/满 warp）= 128 周期
      合计 256 周期，而 512 条 FMA 只要 128 周期 —— LDS 是 FMA 的 2 倍。
    这个 2 倍关系正好对上改之前实测的「只到算力上限 45%」。

    A 段为什么冲突：读基址是 sA + ty*64（float），一个 warp 里 ty 只有
    两个取值（warp = 32 个连续 tid.x，blockDim 16x16，所以一个 warp 横跨
    ty=2w 和 ty=2w+1 两行）。两行相差 64 个 float，64 % 32 == 0，
    于是两个不同地址落进同一个 bank，2 路冲突。

    把 sA 的行距从 8 填到 9：读基址变成 ty*72，行内偏移从 8m 变 9m，
    两行相差 72 个 float，72 % 32 == 8，错开了，冲突消失。

    B 段**不填**：它的冲突发生在同一行内部（warp 里 16 个 tx 各读 tx*8
    个 float，8*tx % 32 只有 4 个取值），行距填充对同一行内部的相对 bank
    分布毫无影响，填了纯浪费。要治 B 得用 XOR swizzle，那是另一件事。

"""
==============================================================================
结论（2026-10-17 实测）：这个改动**没上线**，模型是错的。
==============================================================================
    预测 +25%（LDS 从 256 周期/线程/k-tile 降到 192），实测只有 +1.0 ~ +2.2%：
        N=3216 +1.4%   N=4096 +1.0% / +1.8%（两轮）   N=5120 +2.2%
    三个尺寸、两轮独立测量全部为正且结果正确，所以 1.6% 是真效应，不是噪声。
    但它太小，不值得为它再加一级生成链；而更重要的结论是：
    **bank 冲突假说被证伪。**

    我原先的推理是：LDS 256 周期 vs FMA 128 周期 = 2 倍，恰好对上改之前
    实测的「只到算力上限 45%」，所以判定 LDS 受限、治冲突能拿 25%。
    实际上 45% 里**延迟是大头**，预取（已上线，快 22%）已经把大头拿掉了。
    治完冲突只多 1.6%，说明**预取之后 LDS 已经不是约束**。
    那个 2:1 和 45% 的吻合是巧合 —— 两个因素当时同时存在，我错把
    巧合当成了因果。

    剩下的 ~50% 缺口目前**没有任何被我验证过的模型能解释**。
    值得试但都还没测的方向（按我的猜测排序，不是结论）：
      1. 预取多用了 8 个寄存器（.reg %f<84> -> %f<88>），每 SM 能驻留的
         块可能从 3 掉到 2，等于拿 occupancy 换延迟隐藏。可以试「只预取
         A 或只预取 B」（4 个寄存器）看是赚是亏。
      2. N=3216 时 grid 是 26x26 = 676 块 / 10 SM 的波尾量化。
      3. B 段的 4 路冲突得用 XOR swizzle 治，行距填充对它无效。

    本文件与产物保留下来，就是为了让这个结论有个出处。
==============================================================================

改了什么（都在共享内存寻址上，不碰 k 循环）：
    1. .shared sA[1024] -> sA[1152]（128 行 x 9）
    2. A 读基址：r24*32 字节 -> r24*36 字节
    3. A 写基址：r19 个 float -> (r19 + r20) 个 float
       （r19 = tid*4，r20 = tid/2；原式 (tid/2)*8 + r21 = r19，
        新式 (tid/2)*9 + r21 = r19 + r20）
    4. A 读偏移：4*kk + 32*m 字节 -> 4*kk + 36*m 字节

    因为 x = 4*kk + 32*m 且 kk<8，所以 m = x // 32，新偏移就是 x + 4*m。
    映射唯一可逆，不用猜 kk 和 m 谁是谁。

暂存这段代码在预取版里出现两次（序章 + KLOOP），所以 2 和 3 各要替换两处，
下面每一步都断言出现次数，对不上立刻报错，不静默漏改。

事实源：_ptx_PTX_8X8.ptx（已含载入预取 + ld.global.nc）。
产物：_ptx_PTX_8X8_pad.ptx。回退就是删掉这个产物，不动生产。
"""
import io
import os
import re
import sys

SRC = "_ptx_PTX_8X8.ptx"
DST = "_ptx_PTX_8X8_pad.ptx"

# 预取版里 staging 出现两次：序章 + KLOOP
N_STAGE = 2


def fail(msg):
    sys.stderr.write("生成失败：%s\n" % msg)
    sys.exit(1)


def replace_exact(lines, old, new, expect, what):
    """整块替换，断言出现次数。次数不对就报错 —— 少改一处会静默算错，
    而这种错误在 PTX 里往往编译得过、跑出来才炸。"""
    text = "\n".join(lines)
    got = text.count(old)
    if got != expect:
        fail("%s：期望出现 %d 次，实际 %d 次\n    片段：\n%s" % (what, expect, got, old))
    return text.replace(old, new).split("\n")


def main():
    lines = io.open(SRC, encoding="utf-8", newline="").read().split("\n")

    # --- 0) 前置检查：别对一个已经填过的文件再填一遍 ---
    if ".f32 sA[1152];" in "\n".join(lines):
        fail("%s 里已经有 sA[1152]，说明它被改成产物了" % SRC)

    # --- 1) 共享数组加长 ---
    lines = replace_exact(
        lines,
        ".shared .align 16 .f32 sA[1024];",
        ".shared .align 16 .f32 sA[1152];",
        1, "sA 声明")
    # sB 一律不动，理由见文件头

    # --- 2) A 读基址：r24*32 -> r24*36 字节 ---
    #     用空闲的 %rd8 做临时（.reg .b64 %rd<24> 是 0 编号，%rd8 在范围内）
    m = re.search(r"\.reg \.b64\s+%rd<(\d+)>;", "\n".join(lines))
    if not m:
        fail("找不到 .reg .b64 %rd<N>; 声明")
    if int(m.group(1)) < 9:
        fail(".reg .b64 %%rd<%s> 太小，%%rd8 越界" % m.group(1))
    lines = replace_exact(
        lines,
        "    cvt.u64.u32 %rd16, %r24;\n"
        "    shl.b64 %rd16, %rd16, 5;\n"
        "    add.u64 %rd16, %rd16, %rd13;",
        "    cvt.u64.u32 %rd16, %r24;\n"
        "    shl.b64 %rd16, %rd16, 5;\n"
        "    cvt.u64.u32 %rd8, %r24;        // padding: row stride 8 -> 9 floats\n"
        "    shl.b64 %rd8, %rd8, 2;\n"
        "    add.u64 %rd16, %rd16, %rd8;\n"
        "    add.u64 %rd16, %rd16, %rd13;",
        1, "A 读基址")

    # --- 3) A 写基址：r19 -> r19 + r20 个 float ---
    #     量纲要盯死：%rd6 是**字节**地址。
    #       cvt 出来是 r19「字节」，先左移 2 变成 r19*4 字节 = r19 个 float；
    #       r20 要加的是「r20 个 float」，也就是 r20*4 **字节**；
    #       两者单位一致，直接加，最后不再移位。
    #     我第一版把两条 shl.b64 的先后写反了：先 shl %rd8 再整体 shl %rd6，
    #     结果是 4*r19 + 16*r20（差 4 倍），后向误差 1.297e-01 直接把结果打穿。
    #     下面用 tid=2 自检：r19=8, r20=1，应得 (2/2)*9 + (2%2)*4 = 9 个 float。
    lines = replace_exact(
        lines,
        "    cvt.u64.u32 %rd6, %r19;\n"
        "    shl.b64 %rd6, %rd6, 2;\n"
        "    add.u64 %rd6, %rd6, %rd13;",
        "    cvt.u64.u32 %rd6, %r19;\n"
        "    shl.b64 %rd6, %rd6, 2;      // r19 floats -> bytes\n"
        "    cvt.u64.u32 %rd8, %r20;     // padding: add r20 floats\n"
        "    shl.b64 %rd8, %rd8, 2;      // r20 floats -> bytes\n"
        "    add.u64 %rd6, %rd6, %rd8;   // (r19 + r20) floats\n"
        "    add.u64 %rd6, %rd6, %rd13;",
        N_STAGE, "A 写基址（序章 + KLOOP 各一处）")

    # 算术自检：新公式 (r19 + r20) 必须等于老公式的推广 (tid/2)*9 + (tid%2)*4
    for tid in (0, 1, 2, 3, 127, 128, 255):
        r19, r20 = tid * 4, tid // 2
        if r19 + r20 != (tid // 2) * 9 + (tid % 2) * 4:
            fail("写基址算术不对：tid=%d 时 (r19+r20)=%d，期望 %d"
                 % (tid, r19 + r20, (tid // 2) * 9 + (tid % 2) * 4))

    # --- 4) A 读偏移：4*kk + 32*m -> 4*kk + 36*m ---
    #     x = 4*kk + 32*m，kk<8，所以 m = x // 32，新偏移 = x + 4*m
    seen = []

    def bump(mo):
        x = int(mo.group(1))
        m_ = x // 32
        kk = x - 32 * m_
        if not (0 <= kk <= 28 and kk % 4 == 0 and 0 <= m_ <= 7):
            fail("偏移 %d 解不出合法的 (kk,m)" % x)
        seen.append((x, x + 4 * m_))
        return "[%%rd16+%d]" % (x + 4 * m_)

    text = "\n".join(lines)
    text, n = re.subn(r"\[%rd16\+(\d+)\]", bump, text)
    if n != 64:
        fail("A 读偏移是 %d 条，预期 64 条（8 个 m x 8 个 kk）" % n)
    lines = text.split("\n")

    text = "\n".join(lines)
    bad = [(i + 1, l) for i, l in enumerate(lines) if any(ord(c) > 127 for c in l)]
    if bad:
        fail("第 %d 行含非 ASCII 字符：%r" % (bad[0][0], bad[0][1]))

    with io.open(DST, "w", encoding="ascii", newline="\n") as f:
        f.write(text)

    # --- 自检：边界 ---
    #     最大读基址 = ty_max*8*36 = 15*8*36 = 4320，最大偏移 = 4*7+36*7 = 280
    #     4320+280 = 4600 <= 1152*4 = 4608，差 8 字节，没越界
    mx = 15 * 8 * 36 + (4 * 7 + 36 * 7)
    if mx > 1152 * 4:
        fail("填充后最大访问偏移 %d 超过 sA 容量 %d" % (mx, 1152 * 4))

    changed = sum(1 for a, b in seen if a != b)
    print("已生成 %s" % DST)
    print("  sA 1024 -> 1152 float，A 读/写基址各改 %d 处，A 读偏移改写 %d 条（其中 %d 条数值变了）"
          % (N_STAGE + 1, len(seen), changed))
    print("  偏移映射：x -> x + 4*(x//32)，例：+0->+0  +32->+36  +224->+252  +252->+280")
    print("  边界：最大访问 %d <= sA 容量 %d（余 %d 字节）" % (mx, 1152 * 4, 1152 * 4 - mx))
    print("  sB 未动：它的冲突在行内部，行距填充管不到")


if __name__ == "__main__":
    main()
