# -*- coding: utf-8 -*-
"""定标实验：单移位隐式 QR 步（隐式 Q 定理直接适用，零化第 l 列的分量 1..s-1）
连做两步 σ₁、σ₂，看复合 Q_comp 长什么样、T 是不是真的上 Hessenberg。

只要 Q_comp 是实正交且 T_comp 是上 Hessenberg，这就是「对的」双移位步；
再回头看能不能用闭式把它表达成一个 Householder。

用法：python -B _eigcomp.py
"""
import numpy as np

np.set_printoptions(precision=8, suppress=False, linewidth=200)

A = np.array([
    [0.104849, 0.33491, 0.700101],
    [-0.149776, 0.629897, 0.941049],
    [0.195691, -0.555375, -0.961234],
])
n = 3


def hessenberg(a):
    n = a.shape[0]
    h = a.astype(float).copy()
    q = np.eye(n)
    for k in range(0, n - 1):
        m = n - k - 1
        if m <= 0:
            break
        v = h[k + 1:, k].copy()
        nrm = np.linalg.norm(v)
        if nrm == 0.0:
            continue
        alpha = -nrm if v[0] > 0 else nrm
        v[0] -= alpha
        beta = 2.0 / (v @ v)
        sub = h[k + 1:, :].copy(); h[k + 1:, :] = sub - beta * np.outer(v, v @ sub)
        sub = h[:, k + 1:].copy(); h[:, k + 1:] = sub - beta * np.outer(sub @ v, v)
        sub = q[:, k + 1:].copy();   q[:, k + 1:] = sub - beta * np.outer(sub @ v, v)
        h[k + 1, k] = alpha
        h[k + 2:, k] = 0.0
    return h, q


def one_step(t, q, n, l, u, shift):
    """单移位隐式 QR 步：反射器零化第 l 列的分量 1..s-1。
    （移位只改第 0 分量，所以反射器与移位无关 —— 这正是隐式 Q 定理的含义。）"""
    s = u - l + 1
    v = t[l:l + s, l].copy()
    xn = np.linalg.norm(v[1:])
    if xn == 0.0:
        return False
    alpha = -xn if v[0] > 0 else xn
    v[0] -= alpha
    beta = 2.0 / (v @ v)
    sub = t[l:l + s, :].copy(); t[l:l + s, :] = sub - beta * np.outer(v, v @ sub)
    sub = t[:, l:l + s].copy(); t[:, l:l + s] = sub - beta * np.outer(sub @ v, v)
    sub = q[:, l:l + s].copy();   q[:, l:l + s] = sub - beta * np.outer(sub @ v, v)
    return True


t0, q0 = hessenberg(A)
print("H =\n", t0)

# 右下 2×2 的特征值 = 移位
B = t0[1:, 1:]
lam = np.linalg.eigvals(B)
print("\n右下 2x2 特征值 =", lam)

for order in (0, 1):
    t = t0.copy()
    q = q0.copy()
    l, u = 0, 2
    ok1 = one_step(t, q, n, l, u, lam[order])
    t_mid = t.copy()
    ok2 = one_step(t, q, n, l, u, lam[1 - order])
    print("\n--- 顺序 %s（先 %s 再 %s）ok=(%s,%s) ---" %
          (order, np.round(lam[order], 6), np.round(lam[1 - order], 6), ok1, ok2))
    print("两步后 T =\n", t)
    print("  T[1,0] = %.6e   T[2,0] = %.6e   T[2,1] = %.6e" % (t[1, 0], t[2, 0], t[2, 1]))
    print("  上 Hessenberg？T[2,0] 应该 ≈0")
    print("  ‖A − QTQᵀ‖ = %.3e   ‖QᵀQ − I‖ = %.3e" %
          (np.abs(A - q @ t @ q.T).max(), np.abs(q.T @ q - np.eye(n)).max()))

    # 第一步之后的样子（应当是 Hessenberg，(1,0) 处有 bulge）
    print("  第一步后 T =\n", t_mid)
    print("  第一步后 T[1,0] = %.6e   T[2,0] = %.6e" % (t_mid[1, 0], t_mid[2, 0]))

# 对照：我那个「多项式」反射器算出来的 Q
import _eigref as R
t = t0.copy(); q = q0.copy()
R.francis(t, q, n, 0, 2)
print("\n--- 我的多项式版本 ---")
print(t)
print("  T[1,0] = %.6e   T[2,0] = %.6e" % (t[1, 0], t[2, 0]))