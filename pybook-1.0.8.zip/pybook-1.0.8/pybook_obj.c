/* PYbook obj 库：3D 建模 -> Wavefront .obj 落盘（类比 mm.draw_away 的"作品落盘"路线）。
 * obj.清()                        清空网格
 * obj.点(x, y, z)                 加顶点，返回顶点号（从 1 起，OBJ 惯例）
 * obj.面(a, b, c)                 加三角面（顶点号）
 * obj.面4(a, b, c, d)             加四边面
 * obj.块(x, y, z, 宽, 高, 深)     加立方体（一角在 (x,y,z)，向 +X/+Y/+Z 伸展）
 * obj.球(x, y, z, 半径, 段数)     加 UV 球（中心+半径；段数 = 经线数，3..256）
 * obj.柱(x, y, z, 半径, 高, 段数) 加圆柱（底面中心在 (x,y,z)，沿 +Y 拉高）
 * obj.存("名.obj")                落成 .obj 文本（v + f 纯几何，Blender 直接开）
 * obj.点数() / obj.面数()         当前顶点数 / 面数
 *
 * 约定：Y 轴向上（Blender OBJ 导入默认）；面一律逆时针（从外侧看），法线朝外。
 * 纯计算 + 文本落盘，零窗口、零设备、零阻塞 —— VM / C 双后端都能跑。 */

#include "pybook_lib.h"

#ifdef _WIN32
#  define WIN32_LEAN_AND_MEAN
#  include <windows.h>       /* 中文路径：UTF-8 -> 宽字符 _wfopen */
#endif
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#ifndef M_PI
#  define M_PI 3.14159265358979323846
#endif

static void obj_die(const char *fmt, ...)
{
    va_list ap;
    fprintf(stderr, "运行时错误: obj.");
    va_start(ap, fmt);
    vfprintf(stderr, fmt, ap);
    va_end(ap);
    fputc('\n', stderr);
    exit(1);
}

/* 数字参数：int / float 都收（照 pybook_lib.c 的 lib_num 语义） */
static double obj_num(Value v, const char *who)
{
    if (IS_FLT(v))
        return AS_FLT(v);
    if (IS_INT(v) || IS_BIGINT(v))
        return (double)rt_to_ll(v);
    if (IS_BOOL(v))
        return (double)AS_BOOL(v);
    obj_die("%s 需要数字参数", who);
    return 0;
}

/* 顶点号参数：必须是整数 */
static long long obj_ll(Value v, const char *who)
{
    if (IS_INT(v) || IS_BIGINT(v))
        return rt_to_ll(v);
    if (IS_BOOL(v))
        return (long long)AS_BOOL(v);
    obj_die("%s 需要整数参数", who);
    return 0;
}

/* ---- 网格状态（全局构建器；缓冲只增不减，运行期不 free） ---- */

typedef struct { double x, y, z; } ObjVtx;

static ObjVtx *obj_v = NULL;
static size_t  obj_nv = 0, obj_vcap = 0;

typedef struct { int a, b, c, d; } ObjFace;   /* d < 0 表示三角面 */

static ObjFace *obj_f = NULL;
static size_t   obj_nf = 0, obj_fcap = 0;

static void obj_grow_v(void)
{
    if (obj_nv < obj_vcap)
        return;
    size_t nc = obj_vcap ? obj_vcap * 2 : 256;
    ObjVtx *p = (ObjVtx *)realloc(obj_v, nc * sizeof(ObjVtx));
    if (!p)
        obj_die("点：内存不足");
    obj_v = p;
    obj_vcap = nc;
}

static void obj_grow_f(void)
{
    if (obj_nf < obj_fcap)
        return;
    size_t nc = obj_fcap ? obj_fcap * 2 : 256;
    ObjFace *p = (ObjFace *)realloc(obj_f, nc * sizeof(ObjFace));
    if (!p)
        obj_die("面：内存不足");
    obj_f = p;
    obj_fcap = nc;
}

/* 加一个顶点，返回 0 起下标 */
static int obj_push_v(double x, double y, double z)
{
    obj_grow_v();
    obj_v[obj_nv].x = x;
    obj_v[obj_nv].y = y;
    obj_v[obj_nv].z = z;
    return (int)obj_nv++;
}

/* 加一个面（0 起下标）：quad=1 四边面（d 为第 4 顶点），quad=0 三角面 */
static void obj_push_f(int a, int b, int c, int d, int quad)
{
    obj_grow_f();
    obj_f[obj_nf].a = a;
    obj_f[obj_nf].b = b;
    obj_f[obj_nf].c = c;
    obj_f[obj_nf].d = quad ? d : -1;
    obj_nf++;
}

/* 用户传的顶点号（1 起）-> 0 起下标，越界即报错 */
static int obj_idx(Value v, const char *who)
{
    long long i = obj_ll(v, who);
    if (i < 1 || (size_t)i > obj_nv)
        obj_die("%s：顶点号 %lld 越界（现有点数 %zu）", who, i, obj_nv);
    return (int)(i - 1);
}

/* ---- 基础构建 ---- */

Value rt_obj_clear(void)
{
    obj_nv = 0;
    obj_nf = 0;
    return rt_none();
}

Value rt_obj_vertex(Value xv, Value yv, Value zv)
{
    int i = obj_push_v(obj_num(xv, "obj.点"),
                       obj_num(yv, "obj.点"),
                       obj_num(zv, "obj.点"));
    return rt_int((long long)i + 1);          /* 顶点号从 1 起 */
}

Value rt_obj_face(Value av, Value bv, Value cv)
{
    obj_push_f(obj_idx(av, "obj.面"),
               obj_idx(bv, "obj.面"),
               obj_idx(cv, "obj.面"), 0, 0);
    return rt_none();
}

Value rt_obj_quad(Value av, Value bv, Value cv, Value dv)
{
    obj_push_f(obj_idx(av, "obj.面4"),
               obj_idx(bv, "obj.面4"),
               obj_idx(cv, "obj.面4"),
               obj_idx(dv, "obj.面4"), 1);
    return rt_none();
}

/* ---- 图元 ----
 * 绕向约定：全部逆时针（从外侧看），保证 (b-a)×(c-b) 指向体外。
 * 已用叉积逐面验算，别改顺序。 */

Value rt_obj_box(Value xv, Value yv, Value zv, Value wv, Value hv, Value dv)
{
    double x = obj_num(xv, "obj.块"), y = obj_num(yv, "obj.块"), z = obj_num(zv, "obj.块");
    double w = obj_num(wv, "obj.块"), h = obj_num(hv, "obj.块"), d = obj_num(dv, "obj.块");
    if (w == 0 || h == 0 || d == 0)
        obj_die("块：宽/高/深 不能为 0");
    /* 8 角点：v0..v3 = z 面（前），v4..v7 = z+d 面（后） */
    int v0 = obj_push_v(x,     y,     z);
    int v1 = obj_push_v(x + w, y,     z);
    int v2 = obj_push_v(x + w, y + h, z);
    int v3 = obj_push_v(x,     y + h, z);
    int v4 = obj_push_v(x,     y,     z + d);
    int v5 = obj_push_v(x + w, y,     z + d);
    int v6 = obj_push_v(x + w, y + h, z + d);
    int v7 = obj_push_v(x,     y + h, z + d);
    /* 6 个四边面，全部逆时针（从外侧看） */
    obj_push_f(v0, v3, v2, v1, 1);            /* 前 -Z */
    obj_push_f(v4, v5, v6, v7, 1);            /* 后 +Z */
    obj_push_f(v0, v1, v5, v4, 1);            /* 底 -Y */
    obj_push_f(v3, v7, v6, v2, 1);            /* 顶 +Y */
    obj_push_f(v0, v4, v7, v3, 1);            /* 左 -X */
    obj_push_f(v1, v2, v6, v5, 1);            /* 右 +X */
    return rt_none();
}

Value rt_obj_sphere(Value xv, Value yv, Value zv, Value rv, Value segv)
{
    double cx = obj_num(xv, "obj.球"), cy = obj_num(yv, "obj.球"), cz = obj_num(zv, "obj.球");
    double r = obj_num(rv, "obj.球");
    long long seg = obj_ll(segv, "obj.球");
    if (r <= 0)
        obj_die("球：半径须为正数");
    if (seg < 3 || seg > 256)
        obj_die("球：段数须在 3..256");
    int n = (int)seg, m = (int)seg / 2;        /* n 经线，m 纬线段（m >= 2） */
    if (m < 2)
        m = 2;

    int top = obj_push_v(cx, cy + r, cz);
    /* 中间环 i = 1..m-1，每环 n 个点 */
    int first_ring = (int)obj_nv;
    for (int i = 1; i < m; i++) {
        double phi = M_PI * (double)i / (double)m;
        double ry = r * cos(phi), rr = r * sin(phi);
        for (int j = 0; j < n; j++) {
            double th = 2.0 * M_PI * (double)j / (double)n;
            obj_push_v(cx + rr * cos(th), cy + ry, cz + rr * sin(th));
        }
    }
    int bot = obj_push_v(cx, cy - r, cz);

    int ring = first_ring;                      /* 第一环起点 */
    for (int j = 0; j < n; j++) {               /* 顶盖三角（朝 +Y） */
        int j2 = (j + 1) % n;
        obj_push_f(top, ring + j2, ring + j, 0, 0);
    }
    for (int i = 1; i < m - 1; i++) {           /* 中间四边带（朝外） */
        int r0 = first_ring + (i - 1) * n;
        int r1 = r0 + n;
        for (int j = 0; j < n; j++) {
            int j2 = (j + 1) % n;
            obj_push_f(r0 + j, r0 + j2, r1 + j2, r1 + j, 1);
        }
    }
    int last = first_ring + (m - 2) * n;        /* 底盖三角（朝 -Y） */
    for (int j = 0; j < n; j++) {
        int j2 = (j + 1) % n;
        obj_push_f(bot, last + j, last + j2, 0, 0);
    }
    return rt_none();
}

Value rt_obj_cyl(Value xv, Value yv, Value zv, Value rv, Value hv, Value segv)
{
    double cx = obj_num(xv, "obj.柱"), cy = obj_num(yv, "obj.柱"), cz = obj_num(zv, "obj.柱");
    double r = obj_num(rv, "obj.柱"), h = obj_num(hv, "obj.柱");
    long long seg = obj_ll(segv, "obj.柱");
    if (r <= 0)
        obj_die("柱：半径须为正数");
    if (h == 0)
        obj_die("柱：高不能为 0");
    if (seg < 3 || seg > 256)
        obj_die("柱：段数须在 3..256");
    int n = (int)seg;

    int bot0 = (int)obj_nv;
    for (int j = 0; j < n; j++) {               /* 底环 */
        double th = 2.0 * M_PI * (double)j / (double)n;
        obj_push_v(cx + r * cos(th), cy, cz + r * sin(th));
    }
    int top0 = (int)obj_nv;
    for (int j = 0; j < n; j++) {               /* 顶环 */
        double th = 2.0 * M_PI * (double)j / (double)n;
        obj_push_v(cx + r * cos(th), cy + h, cz + r * sin(th));
    }
    int bc = obj_push_v(cx, cy, cz);
    int tc = obj_push_v(cx, cy + h, cz);

    for (int j = 0; j < n; j++) {
        int j2 = (j + 1) % n;
        obj_push_f(bot0 + j, top0 + j, top0 + j2, bot0 + j2, 1);   /* 侧壁（朝外） */
        obj_push_f(bc, bot0 + j, bot0 + j2, 0, 0);                 /* 底盖（朝 -Y） */
        obj_push_f(tc, top0 + j2, top0 + j, 0, 0);                 /* 顶盖（朝 +Y） */
    }
    return rt_none();
}

/* ---- 落盘 ---- */

Value rt_obj_save(Value filev)
{
    const char *name = rt_str_of(filev);
    if (!*name)
        obj_die("存：文件名不能为空");
    if (obj_nv == 0 || obj_nf == 0)
        obj_die("存：网格是空的，先用 obj.点/obj.块 等加内容");

    FILE *fp = NULL;
#ifdef _WIN32
    {
        wchar_t wname[1024];
        if (MultiByteToWideChar(CP_UTF8, 0, name, -1, wname, 1024) > 0)
            fp = _wfopen(wname, L"wb");
    }
#endif
    if (!fp)
        fp = fopen(name, "wb");
    if (!fp)
        obj_die("存：无法写 %s", name);

    fprintf(fp, "# PYbook obj 库生成\n# 顶点 %zu 个，面 %zu 个\n", obj_nv, obj_nf);
    for (size_t i = 0; i < obj_nv; i++)
        fprintf(fp, "v %.6g %.6g %.6g\n", obj_v[i].x, obj_v[i].y, obj_v[i].z);
    for (size_t i = 0; i < obj_nf; i++) {
        const ObjFace *f = &obj_f[i];
        if (f->d >= 0)
            fprintf(fp, "f %d %d %d %d\n", f->a + 1, f->b + 1, f->c + 1, f->d + 1);
        else
            fprintf(fp, "f %d %d %d\n", f->a + 1, f->b + 1, f->c + 1);
    }
    fclose(fp);
    return rt_str(name);
}

/* ---- 查询 ---- */

Value rt_obj_vcount(void)
{
    return rt_int((long long)obj_nv);
}

Value rt_obj_fcount(void)
{
    return rt_int((long long)obj_nf);
}
