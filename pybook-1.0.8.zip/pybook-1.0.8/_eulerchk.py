# -*- coding: utf-8 -*-
"""_eulerchk.py — 先在 Python 里把 Euler-Maclaurin 的修正项公式钉死，再照抄进 C。
C 版现状（错的）：sum += t * BF[k] * ps / N^{2k}
正确：            sum += BF[k] * (s)_{2k+1} * N^{-s-2k-1}
对照真值用 mpmath（没有就用 math + 级数暴力）。"""

from fractions import Fraction
import math

BF = [Fraction(1, 12), Fraction(-1, 720), Fraction(1, 30240),
      Fraction(-1, 1209600), Fraction(1, 47900160), Fraction(-691, 1307674368000)]

TRUE = {2: math.pi**2/6, 4: math.pi**4/90, 1.5: 2.6123753486854883433,
        10: 1.0009945751278180853, 1.0001: 10000.577323356426}


def zeta(s, fix=True):
    if s <= 1:
        return float('nan')
    N = int(10.0/(s-1.0) + 16.0)
    N = max(20, min(N, 4000000))
    total = sum(float(i)**(-s) for i in range(1, N))
    t = N**(-s)
    total += 0.5*t + t*N/(s-1.0)
    ps = s
    for k in range(6):
        if k > 0:
            for i in range(2):
                ps *= (s + 2.0*k - 1.0 + i)
        if fix:
            total += float(BF[k]) * ps * N**(-s - 2.0*k - 1.0)
        else:
            total += t * float(BF[k]) * ps / N**(2.0*k)
    return total


print('%-8s %-24s %-24s %-12s %-12s' % ('s', '真值', '修好后', '修好后误差', 'C 版现误差'))
for s in (2, 4, 1.5, 10, 1.0001):
    tv = TRUE[s]
    good = zeta(s, True)
    bad = zeta(s, False)
    print('%-8s %-24.16g %-24.16g %-12.2e %-12.2e'
          % (s, tv, good, abs(good-tv)/abs(tv), abs(bad-tv)/abs(tv)))

print()
print('逐项核对 (s=2, N=26)：')
s, N = 2.0, 26
print('  Σ_{n=1}^{25} n^-s        =', sum(float(i)**(-s) for i in range(1, N)))
print('  N^-s/2                   =', 0.5*N**(-s))
print('  N^{1-s}/(s-1)            =', N**(1-s)/(s-1))
for k in range(4):
    ps = 1.0
    for j in range(2*k+1):
        ps *= (s+j)
    print('  B_{2k+2}/(2k+2)! 项 k=%d: ps=%.6g  N^%+.1f  项值=%.6e'
          % (k, ps, -s-2*k-1, float(BF[k])*ps*N**(-s-2*k-1)))
