# 统计截图里某个矩形区域的「亮像素主色调」
#
# 为什么不用 _at.py：粒子每帧发射位置随机，同一坐标在第 25 帧有粒子、
# 第 75 帧可能就空了。要证明「粒子颜色换了」，得看**整块区域**的色调，
# 而不是某一个点。
#
# 判据：只统计「比该区域背景明显亮」的像素（粒子是高亮光点，背景是深蓝星空），
# 对它们的 RGB 求平均。粒子色变了，平均色必须跟着变。

import struct
import sys


def read_bmp(path):
    d = open(path, 'rb').read()
    off = struct.unpack_from('<I', d, 10)[0]
    w = struct.unpack_from('<i', d, 18)[0]
    h = struct.unpack_from('<i', d, 22)[0]
    flip = h > 0                      # BMP 自底向上
    h = abs(h)
    stride = ((w * 3 + 3) // 4) * 4
    # 每行要存 w 个像素（早先只存了 1 个，stat 里 row[x] 直接越界）
    px = []
    for y in range(h):
        base = off + y * stride
        px.append([(d[base + x * 3 + 2], d[base + x * 3 + 1], d[base + x * 3])
                   for x in range(w)])
    if flip:
        px.reverse()                                    # 转成自顶向下
    return w, h, px


def stat(path, x0, y0, x1, y1, thr=70):
    w, h, px = read_bmp(path)
    n = 0
    sr = sg = sb = 0
    peak = 0
    for y in range(y0, y1 + 1):
        row = px[y]
        for x in range(x0, x1 + 1):
            r, g, b = row[x]
            lum = (r + g + b) / 3.0
            if lum > thr:
                sr += r
                sg += g
                sb += b
                n += 1
                if lum > peak:
                    peak = lum
    if n == 0:
        return None
    return (n, sr // n, sg // n, sb // n, int(peak))


if __name__ == '__main__':
    # 粒子区 (320,318)-(580,438)：喷发区；避开中栏面板和两侧
    X0, Y0, X1, Y1 = 320, 318, 580, 438
    print(f'区域 ({X0},{Y0})-({X1},{Y1})  只统计亮度 > 70 的亮像素')
    print()
    for path in sys.argv[1:]:
        s = stat(path, X0, Y0, X1, Y1)
        if s is None:
            print(f'{path}: 该区域没有亮像素')
        else:
            n, r, g, b, peak = s
            print(f'{path}  亮像素 {n:6d}  平均色 #{r:02X}{g:02X}{b:02X} '
                  f'=({r},{g},{b})  最亮 {peak}')
