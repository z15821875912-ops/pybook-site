# -*- coding: utf-8 -*-
"""_findfffd.py — 找出哪些重放脚本里含 U+FFFD（坏字符在源头，不修就会每次重放都带坏）"""
import glob
import io
import os

BAD = b'\xef\xbf\xbd'
files = sorted(glob.glob('_*.py')) + sorted(glob.glob('_*.c'))
hits = 0
for p in files:
    raw = open(p, 'rb').read()
    n = raw.count(BAD)
    if not n:
        continue
    hits += 1
    t = raw.decode('utf-8', 'replace')
    print('%s  %d 处' % (p, n))
    for i, line in enumerate(t.splitlines(), 1):
        if b'\xef\xbf\xbd' in line.encode('utf-8', 'replace'):
            print('   第 %d 行: %s' % (i, line.strip()[:100]))
print('\n共 %d 个文件含坏字符' % hits)
