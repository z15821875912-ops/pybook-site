/* _ptxdbg.c —— PTX 变体加载诊断：喂一个 .ptx 文件，打印 LoadData 与取入口结果 */
#include <windows.h>
#include <stdio.h>
#include <string.h>

typedef int CUresult;
typedef int CUdevice;
typedef void *CUmodule;
typedef void *CUfunction;
typedef void *CUcontext;

static CUresult (*p_cuInit)(unsigned);
static CUresult (*p_cuModuleLoadData)(CUmodule *, const void *);
static CUresult (*p_cuModuleGetFunction)(CUfunction *, CUmodule, const char *);
static CUresult (*p_cuGetErrorString)(CUresult, const char **);
static CUresult (*p_cuDeviceGet)(CUdevice *, int);
static CUresult (*p_cuDevicePrimaryCtxRetain)(CUcontext *, CUdevice);
static CUresult (*p_cuCtxSetCurrent)(CUcontext);

static char buf[65536];

int main(int argc, char **argv)
{
    void *p; CUresult r; CUmodule mod = NULL; CUfunction fn;
    HMODULE d = LoadLibraryA("nvcuda.dll");
    FILE *f; size_t n;
    if (!d) { printf("no dll\n"); return 1; }
    p = (void *)GetProcAddress(d, "cuInit");            memcpy(&p_cuInit, &p, sizeof p);
    p = (void *)GetProcAddress(d, "cuModuleLoadData");  memcpy(&p_cuModuleLoadData, &p, sizeof p);
    p = (void *)GetProcAddress(d, "cuModuleGetFunction"); memcpy(&p_cuModuleGetFunction, &p, sizeof p);
    p = (void *)GetProcAddress(d, "cuGetErrorString");  memcpy(&p_cuGetErrorString, &p, sizeof p);
    p = (void *)GetProcAddress(d, "cuDeviceGet");       memcpy(&p_cuDeviceGet, &p, sizeof p);
    p = (void *)GetProcAddress(d, "cuDevicePrimaryCtxRetain"); memcpy(&p_cuDevicePrimaryCtxRetain, &p, sizeof p);
    p = (void *)GetProcAddress(d, "cuCtxSetCurrent");   memcpy(&p_cuCtxSetCurrent, &p, sizeof p);
    {
        CUdevice dev; CUcontext ctx = NULL;
        p_cuInit(0);
        if (p_cuDeviceGet(&dev, 0) != 0) { printf("取不到设备\n"); return 1; }
        if (p_cuDevicePrimaryCtxRetain(&ctx, dev) != 0) { printf("建不了 context\n"); return 1; }
        if (p_cuCtxSetCurrent(ctx) != 0) { printf("切不过 context\n"); return 1; }
    }
    f = fopen(argv[1], "rb");
    if (!f) { printf("打不开 %s\n", argv[1]); return 1; }
    n = fread(buf, 1, sizeof buf - 1, f);
    fclose(f);
    buf[n] = 0;
    r = p_cuModuleLoadData(&mod, buf);
    if (r) {
        const char *e = NULL;
        p_cuGetErrorString(r, &e);
        printf("LoadData FAIL(%d): %s\n", r, e ? e : "?");
        return 2;
    }
    printf("LoadData OK (%zu bytes)\n", n);
    r = p_cuModuleGetFunction(&fn, mod, "sgemm");
    printf("  get sgemm:         %s\n", r ? "FAIL" : "OK");
    r = p_cuModuleGetFunction(&fn, mod, "sgemm_shared");
    printf("  get sgemm_shared:  %s\n", r ? "FAIL" : "OK");
    return 0;
}
