# -*- coding: utf-8 -*-
"""_audit.py — 只读盘点：事故+恢复之后，到底少了什么。不改任何文件。"""
import io
import os
import re
import subprocess
import time

NAMES = ['mt.erf', 'mt.erfc', 'mt.gamma', 'mt.lgamma', 'mt.zeta',
         'mt.golden_min', 'mt.golden_max', 'mp.interp_linear',
         'mp.interp_cubic', 'mp.linfit', 'mp.polyfit']
C = {'mt.erf': 'rt_lib_mt_erf', 'mt.erfc': 'rt_lib_mt_erfc',
     'mt.gamma': 'rt_lib_mt_gamma', 'mt.lgamma': 'rt_lib_mt_lgamma',
     'mt.zeta': 'rt_lib_mt_zeta', 'mt.golden_min': 'rt_lib_mt_golden_min',
     'mt.golden_max': 'rt_lib_mt_golden_max',
     'mp.interp_linear': 'rt_lib_mp_interp_linear',
     'mp.interp_cubic': 'rt_lib_mp_interp_cubic',
     'mp.linfit': 'rt_lib_mp_linfit', 'mp.polyfit': 'rt_lib_mp_polyfit'}
ARITY = {'mt.golden_min': 2, 'mt.golden_max': 2,
         'mp.interp_linear': 3, 'mp.interp_cubic': 3,
         'mp.linfit': 2, 'mp.polyfit': 3}

inc = io.open('_vm_lib_calls.inc', encoding='utf-8', newline='').read()
lib = io.open('pybook_lib.c', encoding='utf-8', newline='').read()
front = io.open('pybk_front.py', encoding='utf-8', newline='').read()

print('=== 1. _vm_lib_calls.inc：11 个入口的原型 / 表项 ===')
for n in NAMES:
    proto = ('Value %s(' % C[n]) in inc
    row = ('{"%s", %d,' % (n, ARITY.get(n, 1))) in inc
    flag = 'OK' if (proto and row) else ('★缺表项' if proto else '★缺原型')
    print('  %-16s 原型%s 表项%s  %s' % (n, '✓' if proto else '✗',
                                        '✓' if row else '✗', '' if proto and row else flag))

print()
print('=== 2. pybook_lib.c：本轮 12 处修复是否在 ===')
CHECKS = [
    ('1  Lanczos 补 exp(-t)', 'exp(-t) * lanczos_x(z)'),
    ('2  ig_series x=0 短路', 'P(a,0)=0'),
    ('3  erfc 直接算 Q', 'lib_gammq'),
    ('4  zeta 修正项指数', '1.0 - s - 2.0 * k - 1.0'),
    ('5  AS_INT(rt_len)', 'AS_INT(rt_len(v))'),
    ('6  interp_linear n<2', 'if (n < 2) return y[0];'),
    ('7  polyfit 范德蒙德', 'mx_i^(j+k)'),
    ('8  换算回原始 x 的幂', 'cx[deg]'),
    ('9  别忘加 ȳ', 'd[0] += sy'),
    ('10 插值越界夹取', '越界夹取'),
    ('11 lib_locate 上界', 'hi = n - 1'),
    ('12 Catmull-Rom m0 中心差分', 'y[i + 1] - y[i - 1]'),
    ('13 polyfit 换 QR', 'lib_lstsq'),
]
bad = 0
for name, mark in CHECKS:
    ok = mark in lib
    if not ok:
        bad += 1
    print('  %-28s %s' % (name, '在' if ok else '★ 不在'))
print('  —— 缺 %d / %d 处' % (bad, len(CHECKS)))

print()
print('=== 3. 本轮 11 个入口的 C 实现是否在 ===')
miss = 0
for n in NAMES:
    ok = ('Value %s(' % C[n]) in lib
    if not ok:
        miss += 1
    print('  %-16s %s' % (n, '在' if ok else '★ 不在'))
print('  —— 缺 %d / %d 个' % (miss, len(NAMES)))

print()
print('=== 4. 前几轮的老入口（锚点抽查）===')
OLD = ['mt.taylor', 'mt.deriv', 'mt.integrate', 'mt.root_newton_d', 'mt.exp',
       'mt.log1p', 'mt.atanh', 'mp.corr', 'mp.percentile', 'mp.rand_lognormal',
       'rd.seed', 'tb.eig_sym', 'tb.cholesky', 'tb.lu', 'mp.mat_qr', 'mp.vec_add']
gone = [o for o in OLD if ("'%s'" % o) not in front]
print('  在: %d / %d' % (len(OLD) - len(gone), len(OLD)))
if gone:
    print('  ★ 不见: ' + '  '.join(gone))

print()
print('=== 5. 规模 ===')
keys = re.findall(r"^    '([a-zA-Z0-9_.]+)':", front, re.M)
bp = {}
for k in keys:
    bp[k.split('.')[0]] = bp.get(k.split('.')[0], 0) + 1
print('  pybk_front.py LIB_CALLS：%d 条  %s'
      % (len(keys), '  '.join('%s=%d' % kv for kv in sorted(bp.items()))))
print('  _vm_lib_calls.inc 表项：%d' % len(re.findall(r'^\s*\{"', inc, re.M)))
m = re.search(r'(\d+) 个库调用', inc)
print('  .inc 表头写的数字：%s' % (m.group(1) if m else '?'))
print('  pybook_lib.c：%d 字节' % len(lib))

print()
print('=== 6. 测试用例 ===')
cs = io.open('tests/cases.py', encoding='utf-8', newline='').read()
t22 = re.findall(r"'id': '(T22_[a-z_]+)'", cs)
print('  cases.py 里 T22 用例：%d 个 %s' % (len(t22), t22))
print('  cases.py 总行数：%d' % cs.count('\n'))

print()
print('=== 7. 关键文件 mtime ===')
for p in ('pybook_lib.c', 'pybk_front.py', 'pybk_code.py', 'pybook_lib.h',
          '_vm_lib_calls.inc', 'tests/cases.py', 'pybook_net.c', 'pybook_la.c'):
    if os.path.exists(p):
        print('  %-20s %s  %d 字节' % (p,
              time.strftime('%H:%M:%S', time.localtime(os.path.getmtime(p))),
              os.path.getsize(p)))
    else:
        print('  %-20s ★ 不存在' % p)
