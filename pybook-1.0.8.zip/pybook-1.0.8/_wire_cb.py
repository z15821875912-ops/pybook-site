# -*- coding: utf-8 -*-
"""_wire_cb.py — 让库函数能回调用户的 lambda

## 要解决的问题

mec lambda 编译成用户程序里的顶层函数 __mec_lam_N，lambda 的「值」只是函数名字符串；
分发函数 rt_mec_apply 由编译器生成进 out.c，**不在 pyvm.exe 里**。
所以 pybook_lib.c 里的库函数想回调用户的 f（比如 mt.deriv(f, x)），
链接期就找不到 rt_mec_apply —— 符号压根不存在。

## 改法（选它而不是「生成一张注册表」）

运行时只存**一个函数指针**，由用户程序在 main() 开头装进来：

    typedef Value (*RtFnDispatch)(Value fnval, Value args);
    void  rt_set_fn_dispatch(RtFnDispatch f);
    Value rt_call_value(Value fnval, Value args);

分发表本身（strcmp 链、arity 校验、部分应用）仍然留在编译器生成的那个函数里，一行没动。
好处是 arity 检查和「函数名写错」的错误文案都还在原处，不会因为搬家而变样；
代价只是多一次间接调用，对回调这种场景完全不是瓶颈。

没装分发器的后端（.pybc 字节码）调 rt_call_value 会拿到一条说人话的报错，
而不是编译期那句「不可编译的表达式 Lambda」。
"""
import io

# ------------------------------------------------------------------ 1. pybook_rt.h
H_DECL = """
/* ---- 函数值（一等函数）回调 ----
 * lambda 编译成用户程序里的顶层函数，值是函数名字符串；真正的分发表由编译器
 * 生成进 out.c。运行时只存一个函数指针，由用户在 main() 开头用
 * rt_set_fn_dispatch 装进来 —— 这样 pybook_lib.c / pybook_rt.c 里的库函数
 * 也能回调用户的 f（rt_call_value 就是为这个存在的）。
 * 不用「生成一张注册表」是刻意的：分发表与 arity 校验留在原处不动，
 * 「函数名写错」这类错误文案不会因为搬家而变样。 */
typedef Value (*RtFnDispatch)(Value fnval, Value args);
void   rt_set_fn_dispatch(RtFnDispatch f);
Value  rt_call_value(Value fnval, Value args);   /* args 是列表；无分发器时给出可操作的报错 */
Value  rt_call1(Value fnval, Value x);           /* 单参便捷式，内部照样走 rt_call_value */
"""

# ------------------------------------------------------------------ 2. pybook_rt.c
C_IMPL = """
/* ---- 函数值回调（见 pybook_rt.h 的说明）---- */
static RtFnDispatch g_fn_dispatch = NULL;

void rt_set_fn_dispatch(RtFnDispatch f)
{
    g_fn_dispatch = f;
}

Value rt_call_value(Value fnval, Value args)
{
    if (!g_fn_dispatch)
        rt_die("这个函数需要一个函数值（lambda），但当前后端没有回调能力\\n"
               "  为什么：函数值的分发表由用户程序在启动时装进运行时；"
               "字节码后端（.pybc）目前还没有这套机制\\n"
               "  怎么改：用 C 后端运行这个程序（python -B main.py 程序.pybk）；"
               "或者把这个计算展开写成不依赖回调的写法");
    return g_fn_dispatch(fnval, args);
}

/* 单参便捷式。参数包成临时列表再交给分发器 —— 分发器只认列表，
   两边（用户直接调 mec.apply 与库函数回调）走的是同一条路，不会分叉。 */
Value rt_call1(Value fnval, Value x)
{
    Value a = rt_list_new();
    rt_push(&a, x);
    return rt_call_value(fnval, a);
}
"""

# ------------------------------------------------------------------ 3. codegen：main() 装分发器
OLD_MAIN = """        self.emit('int main(void) {')
        self.depth += 1
        self.emit('setvbuf(stdout, NULL, _IONBF, 0);   /* 输出即时可见，供交互输入 */')"""
NEW_MAIN = """        self.emit('int main(void) {')
        self.depth += 1
        self.emit('setvbuf(stdout, NULL, _IONBF, 0);   /* 输出即时可见，供交互输入 */')
        # 把 lambda/函数的动态分发表装进运行时，这样库函数（mt.deriv 之类）
        # 也能回调用户的 f。rt_mec_apply 是本文件 gen_mec_apply() 生成的，
        # 每个 C 后端程序都有，所以这行无条件安全。
        self.emit('rt_set_fn_dispatch(rt_mec_apply);')"""


def rd(p):
    return io.open(p, encoding='utf-8', newline='').read()


def wr(p, t):
    io.open(p, 'w', encoding='utf-8', newline='').write(t)


def ins_after(p, anchor, block, tag):
    t = rd(p)
    if tag in t:
        print('  %s: 已有 %s，跳过' % (p, tag))
        return
    e = '\r\n' if '\r\n' in t else '\n'
    i = t.index(anchor) + len(anchor)
    wr(p, t[:i] + block.replace('\n', e) + t[i:])
    print('  %s: 已插入' % p)


print('== pybook_rt.h ==')
ins_after('pybook_rt.h',
          'void rt_die(const char *fmt, ...);',
          H_DECL, 'rt_set_fn_dispatch')

print('== pybook_rt.c ==')
ins_after('pybook_rt.c',
          'void rt_die(const char *fmt, ...)\n{',
          C_IMPL, 'g_fn_dispatch')

print('== pybk_code.py ==')
t = rd('pybk_code.py')
if 'rt_set_fn_dispatch(rt_mec_apply);' in t:
    print('  pybk_code.py: 已接线')
else:
    o, n = OLD_MAIN.replace('\n', '\n'), NEW_MAIN.replace('\n', '\n')
    assert o in t, '找不到 main() 发射点'
    wr('pybk_code.py', t.replace(o, n, 1))
    print('  pybk_code.py: main() 已装分发器')

print('完成')
