/* PYbook 标准库：file 文件模块（UTF-8 读写）。
 *
 * 编码约定：文件内容一律按 UTF-8 字节读写（"rb"/"wb" 二进制模式，
 * 不做换行翻译；rt_file_lines 自行按 \n 切行并去掉行尾 \r）。
 * 路径是 UTF-8 字符串，经 MultiByteToWideChar 转 UTF-16 后走 _wfopen/
 * _wremove，中文路径不会因 ANSI 代码页而乱码。
 *
 * 函数清单（声明见 pybook_rt.h 的 file 模块段）：
 *   rt_file_read(路径)          → 读全部文本（字符串）
 *   rt_file_write(路径, 内容)   → 覆盖写（空盒）
 *   rt_file_add(路径, 内容)     → 追加写（空盒）
 *   rt_file_exists(路径)        → 存在？（真/假）
 *   rt_file_lines(路径)         → 按行读成列表（每行一个字符串）
 *   rt_file_del(路径)           → 删除文件（空盒）
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <windows.h>

#include "pybook_rt.h"

/* 运行时错误出口：格式与 pybook_rt 的 rt_die 一致 */
static void file_die(const char *fmt, ...)
{
    va_list ap;
    fprintf(stderr, "runtime error: ");
    va_start(ap, fmt);
    vfprintf(stderr, fmt, ap);
    va_end(ap);
    fputc(10, stderr);
    exit(1);
}

/* UTF-8 路径 → FILE*。mode 形如 "rb"/"wb"/"ab"。 */
static FILE *file_fopen(const char *path, const char *mode)
{
    wchar_t wpath[1024], wmode[8];
    if (!MultiByteToWideChar(CP_UTF8, 0, path ? path : "", -1,
                             wpath, (int)(sizeof wpath / sizeof wpath[0])))
        return NULL;
    if (!MultiByteToWideChar(CP_UTF8, 0, mode, -1,
                             wmode, (int)(sizeof wmode / sizeof wmode[0])))
        return NULL;
    return _wfopen(wpath, wmode);
}

/* UTF-8 路径 → 删除。成功返回 0。 */
static int file_remove(const char *path)
{
    wchar_t wpath[1024];
    if (!MultiByteToWideChar(CP_UTF8, 0, path ? path : "", -1,
                             wpath, (int)(sizeof wpath / sizeof wpath[0])))
        return -1;
    return _wremove(wpath);
}

static const char *file_str(Value v, const char *who)
{
    if (!IS_STR(v))
        file_die("%s 需要字符串", who);
    return AS_STR(v) ? AS_STR(v) : "";
}

/* 读整个文件到 malloc 缓冲（含 NUL）；失败/不存在 → NULL。 */
static char *file_slurp(const char *path, size_t *out_len)
{
    FILE *fp = file_fopen(path, "rb");
    char *buf;
    long sz;
    if (!fp)
        return NULL;
    if (fseek(fp, 0, SEEK_END) != 0 || (sz = ftell(fp)) < 0) {
        fclose(fp);
        return NULL;
    }
    rewind(fp);
    buf = (char *)malloc((size_t)sz + 1);
    if (!buf) {
        fclose(fp);
        file_die("内存不足");
    }
    if (sz > 0 && fread(buf, 1, (size_t)sz, fp) != (size_t)sz) {
        free(buf);
        fclose(fp);
        return NULL;
    }
    buf[sz] = '\0';
    fclose(fp);
    if (out_len)
        *out_len = (size_t)sz;
    return buf;
}

Value rt_file_read(Value path)
{
    const char *p = file_str(path, "file.read 的路径");
    char *buf = file_slurp(p, NULL);
    Value r;
    if (!buf)
        file_die("file.read：无法打开文件 %s", p);
    r = rt_str(buf);
    free(buf);          /* rt_str 内部会拷贝（见 rt_str 实现），缓冲可还 */
    return r;
}

static Value file_write_impl(Value path, Value content, const char *mode)
{
    const char *p = file_str(path, "file.write 的路径");
    const char *data = file_str(content, "file.write 的内容");
    FILE *fp = file_fopen(p, mode);
    size_t len = strlen(data);
    if (!fp)
        file_die("file.write：无法打开文件 %s", p);
    if (len > 0 && fwrite(data, 1, len, fp) != len)
        file_die("file.write：写入文件 %s 失败", p);
    fclose(fp);
    return rt_none();
}

Value rt_file_write(Value path, Value content)
{
    return file_write_impl(path, content, "wb");
}

Value rt_file_add(Value path, Value content)
{
    return file_write_impl(path, content, "ab");
}

Value rt_file_exists(Value path)
{
    const char *p = file_str(path, "file.exists 的路径");
    FILE *fp = file_fopen(p, "rb");
    if (fp)
        fclose(fp);
    return rt_bool(fp != NULL);
}

Value rt_file_lines(Value path)
{
    const char *p = file_str(path, "file.lines 的路径");
    size_t len = 0;
    char *buf = file_slurp(p, &len);
    Value lst = rt_list_new();
    size_t i = 0, start = 0;
    if (!buf)
        file_die("file.lines：无法打开文件 %s", p);
    if (len == 0) {
        free(buf);
        return lst;                    /* 空文件 → 空列表 */
    }
    while (i <= len) {
        if (i == len || buf[i] == '\n') {
            size_t end = i;
            Value line;
            char *one;
            if (end > start && buf[end - 1] == '\r')
                end--;                 /* 去掉 \r\n 的 \r */
            one = (char *)malloc(end - start + 1);
            if (!one)
                file_die("内存不足");
            memcpy(one, buf + start, end - start);
            one[end - start] = '\0';
            line = rt_str(one);
            free(one);
            rt_push(&lst, line);
            start = i + 1;
        }
        i++;
    }
    free(buf);
    return lst;
}

Value rt_file_del(Value path)
{
    const char *p = file_str(path, "file.del 的路径");
    if (file_remove(p) != 0)
        file_die("file.del：无法删除文件 %s", p);
    return rt_none();
}

/* ---------- 以下为 teamwork 库所需：size / list / split / join ---------- */

Value rt_file_size(Value path)
{
    const char *p = file_str(path, "file.size 的路径");
    FILE *fp = file_fopen(p, "rb");
    long sz;
    if (!fp)
        file_die("file.size：无法打开文件 %s", p);
    if (fseek(fp, 0, SEEK_END) != 0 || (sz = ftell(fp)) < 0) {
        fclose(fp);
        file_die("file.size：无法取得大小 %s", p);
    }
    fclose(fp);
    return rt_int(sz);
}

/* file.list(目录) → 列表的列表：[名字, 大小, "文件"|"目录"]，按名字排序 */
Value rt_file_list(Value dir)
{
    const char *p = file_str(dir, "file.list 的目录");
    wchar_t wdir[1024], pattern[1100];
    WIN32_FIND_DATAW fd;
    HANDLE h;
    Value lst = rt_list_new();

    if (!MultiByteToWideChar(CP_UTF8, 0, p ? p : "", -1,
                             wdir, (int)(sizeof wdir / sizeof wdir[0])))
        file_die("file.list：目录路径过长 %s", p);
    /* 去掉末尾反斜杠再拼 \* */
    {
        size_t n = wcslen(wdir);
        while (n > 0 && (wdir[n - 1] == L'\\' || wdir[n - 1] == L'/'))
            wdir[--n] = 0;
    }
    swprintf(pattern, sizeof pattern / sizeof pattern[0], L"%s\\*", wdir);
    h = FindFirstFileW(pattern, &fd);
    if (h == INVALID_HANDLE_VALUE)
        file_die("file.list：无法打开目录 %s", p);
    do {
        char name[1024];
        Value row;
        if (wcscmp(fd.cFileName, L".") == 0 || wcscmp(fd.cFileName, L"..") == 0)
            continue;
        if (!WideCharToMultiByte(CP_UTF8, 0, fd.cFileName, -1, name,
                                 (int)sizeof name, NULL, NULL))
            continue;
        row = rt_list_new();
        rt_push(&row, rt_str(name));
        if (fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) {
            rt_push(&row, rt_int(0));
            rt_push(&row, rt_str("目录"));
        } else {
            long long sz = ((long long)fd.nFileSizeHigh << 32) | fd.nFileSizeLow;
            rt_push(&row, rt_int((long long)sz));
            rt_push(&row, rt_str("文件"));
        }
        rt_push(&lst, row);
    } while (FindNextFileW(h, &fd));
    FindClose(h);
    return lst;
}

/* file.split(路径, 每卷字节数) → 分卷路径列表。命名：原名.partNN */
Value rt_file_split(Value path, Value chunk)
{
    const char *p = file_str(path, "file.split 的路径");
    long long csz;
    FILE *in, *out;
    char *buf;
    Value lst = rt_list_new();
    int idx = 0;
    size_t nread;

    if (IS_INT(chunk))
        csz = AS_INT(chunk);
    else if (IS_FLT(chunk))
        csz = (long long)AS_FLT(chunk);
    else
        file_die("file.split 的分块大小需要数字");
    if (csz <= 0)
        file_die("file.split 的分块大小必须 > 0");

    in = file_fopen(p, "rb");
    if (!in)
        file_die("file.split：无法打开文件 %s", p);
    buf = (char *)malloc((size_t)csz);
    if (!buf) {
        fclose(in);
        file_die("内存不足");
    }
    while ((nread = fread(buf, 1, (size_t)csz, in)) > 0) {
        char outpath[1200];
        snprintf(outpath, sizeof outpath, "%s.part%02d", p, idx);
        out = file_fopen(outpath, "wb");
        if (!out) {
            free(buf);
            fclose(in);
            file_die("file.split：无法创建分卷 %s", outpath);
        }
        if (fwrite(buf, 1, nread, out) != nread) {
            fclose(out);
            free(buf);
            fclose(in);
            file_die("file.split：写入分卷失败 %s", outpath);
        }
        fclose(out);
        rt_push(&lst, rt_str(outpath));
        idx++;
    }
    free(buf);
    fclose(in);
    return lst;
}

/* file.join(分卷列表, 输出路径) → 空盒 */
Value rt_file_join(Value parts, Value outp)
{
    const char *dst = file_str(outp, "file.join 的输出路径");
    FILE *out;
    Value n;
    long long i, cnt;

    if (!IS_LIST(parts))
        file_die("file.join 的分卷列表需要列表");
    out = file_fopen(dst, "wb");
    if (!out)
        file_die("file.join：无法创建输出 %s", dst);
    n = rt_len(parts);
    cnt = IS_INT(n) ? AS_INT(n) : 0;
    for (i = 0; i < cnt; i++) {
        Value item = rt_index(parts, rt_int(i));
        const char *pp;
        FILE *in;
        char buf[65536];
        size_t r;
        if (!IS_STR(item)) {
            fclose(out);
            file_die("file.join：第 %lld 个分卷不是字符串", (long long)i);
        }
        pp = AS_STR(item);
        in = file_fopen(pp, "rb");
        if (!in) {
            fclose(out);
            file_die("file.join：无法打开分卷 %s", pp);
        }
        while ((r = fread(buf, 1, sizeof buf, in)) > 0) {
            if (fwrite(buf, 1, r, out) != r) {
                fclose(in);
                fclose(out);
                file_die("file.join：写入输出失败 %s", dst);
            }
        }
        fclose(in);
    }
    fclose(out);
    return rt_none();
}
