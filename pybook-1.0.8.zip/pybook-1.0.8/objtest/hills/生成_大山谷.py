# -*- coding: utf-8 -*-
"""生成「白色天空 · 大山谷」场景并导出 Wavefront .obj（+ .mtl）。

这是 生成_山丘草地.py 的放大版（那个只适合 90 米的小场地）：
  · 边长 90 -> 260，格数 120 -> 200，山高 9 -> 22，草 6500 -> 28000
  · **边缘围脊**：外圈抬到 36 米，把场地围成山谷 —— 于是玩家在场地边缘
    也看不到"地图边界线"，视线被山脊挡死，边界感是"山谷"而不是"悬崖"。

原始版本说明：

用 Blender 自带 Python 跑（不需要任何插件）：
    blender -b --factory-startup --python 生成_山丘草地.py -- <输出目录>

产出：
    hills.obj     地形 + 草叶（三角化，带 vn）
    hills.mtl     4 个材质（草地 / 山坡草 / 山顶岩土 / 草叶）
    preview_1.png 远景预览（白天空 + 山丘）
    preview_2.png 低机位预览（草地近景）

导出轴向是 Blender 的默认值 forward=-Z / up=Y，正好是 PYbook 里
hw.objfix(句柄, 1) 要修的那 90°（obj 里 yaw=0 的"前方"是 -Z，hw 里是 +X）。
"""
import bpy
import math
import os
import random
import sys
from mathutils import Vector, noise

# ---------------------------------------------------------------- 参数

RES = 200              # 地形每边的格数（201×201 个顶点 -> 8 万面）
SIZE = 260.0           # 地形边长（世界单位）—— 比小地图大 2.9 倍
MAXH = 22.0            # 谷内山丘最高
GRASS_N = 28000        # 草簇数量
SEED = 20261003

# 边缘围脊：把地图外圈抬起来当"墙"，玩家就看不到地图边界了。
# RIM_IN 是"从中心算起到多少比例开始抬"（切比雪夫距离，所以围出来是方形，
# 和方形地图完全贴合，四角不会漏缝）；RIM_H 是抬到多高。
RIM_IN = 0.72
RIM_H = 36.0

argv = sys.argv
OUT_DIR = argv[argv.index("--") + 1] if "--" in argv else "."
# 必须绝对化：Blender 的 render.filepath 若是相对路径，会按"相对 .blend 文件"
# 解析，这里是 --factory-startup 没有 .blend，结果会写到盘根 C:////preview.png 上去
OUT_DIR = os.path.abspath(OUT_DIR)
os.makedirs(OUT_DIR, exist_ok=True)

random.seed(SEED)
noise.seed_set(SEED)

# ---------------------------------------------------------------- 工具


def clear_scene():
    bpy.ops.wm.read_factory_settings(use_empty=True)


def make_material(name, kd, ks=0.02, ns=8.0):
    m = bpy.data.materials.new(name)
    m.use_nodes = True
    bsdf = m.node_tree.nodes.get("Principled BSDF")
    if bsdf is not None:
        bsdf.inputs["Base Color"].default_value = (kd[0], kd[1], kd[2], 1.0)
        if "Roughness" in bsdf.inputs:
            bsdf.inputs["Roughness"].default_value = 0.92
        if "Specular IOR Level" in bsdf.inputs:
            bsdf.inputs["Specular IOR Level"].default_value = 0.08
        elif "Specular" in bsdf.inputs:
            bsdf.inputs["Specular"].default_value = 0.08
    # 老式视图颜色也一起设上，导出器取 Kd 时两条路都对
    m.diffuse_color = (kd[0], kd[1], kd[2], 1.0)
    m.specular_intensity = 0.08
    m.roughness = 0.92
    return m


# 频率缩放系数：噪声频率是按"世界坐标"写死的常量，所以地图一边长，
# 山就会一边碎。乘上 90/SIZE 之后，大地图是"同样的山形摊大"，不是"满地疙瘩"。
# （第一版忘了这一条，260 米地图渲出来是一片蛋托，见 preview_big_1 的旧版）
NF = 90.0 / SIZE
NF_DETAIL = NF * 1.6      # 地表碎细节只缩一半，留点起伏，不然地面太光


def height_at(x, y):
    """多层噪声叠出「几座圆滚滚的山丘 + 大片平草地」。

    原始噪声的取值范围不确定，所以先算一遍全场、再线性归一化到 0..1，
    最后用幂曲线压一压：低处更平（草地），高处收成圆顶（山丘）。
    """
    n = 0.0
    n += 4.20 * noise.fractal((x * 0.030 * NF, y * 0.030 * NF, 0.0), 0.55, 2.0, 4)
    n += 1.55 * noise.fractal((x * 0.085 * NF, y * 0.085 * NF, 17.0), 0.55, 2.0, 3)
    n += 0.42 * noise.noise((x * 0.230 * NF_DETAIL, y * 0.230 * NF_DETAIL, 41.0))
    return n


# 先采样全网，定出归一化范围
_raw = [[height_at(-SIZE * 0.5 + i * SIZE / RES, -SIZE * 0.5 + j * SIZE / RES)
         for j in range(RES + 1)] for i in range(RES + 1)]
_flat = [v for row in _raw for v in row]
_rmin, _rmax = min(_flat), max(_flat)
_span = (_rmax - _rmin) or 1.0


def terrain_h(i, j):
    """格点 (i,j) 的高度；先归一化到 0..1、压成圆丘，再叠一圈边缘围脊。"""
    t = (_raw[i][j] - _rmin) / _span
    t = t ** 1.55                      # 低处更平、高处更陡 → 山丘感
    h = t * MAXH

    # ---- 边缘围脊 ----
    # 用切比雪夫距离 max(|x|,|y|) 而不是欧氏距离：围出来是方框，
    # 和方形地形完全贴合，四个角不会出现"抬不到"的豁口。
    x = -SIZE * 0.5 + i * SIZE / RES
    y = -SIZE * 0.5 + j * SIZE / RES
    u = max(abs(x), abs(y)) / (SIZE * 0.5)
    if u > RIM_IN:
        k = (u - RIM_IN) / (1.0 - RIM_IN)
        k = min(1.0, max(0.0, k))
        k = k * k * (3.0 - 2.0 * k)    # smoothstep：接坡处不生硬
        # 脊线加一点周期起伏，别是一条完美平直的方框高原（正弦比噪声便宜，
        # 这个函数在撒草时会被调用上百万次）
        ridge = RIM_H + 4.5 * math.sin(x * 0.026) * math.cos(y * 0.029)
        h = h * (1.0 - k) + ridge * k
    return h


print("[gen] 高度场采完  min=%.3f max=%.3f" % (_rmin, _rmax))

# ---------------------------------------------------------------- 地形


def build_terrain():
    verts = []
    for i in range(RES + 1):
        for j in range(RES + 1):
            x = -SIZE * 0.5 + i * SIZE / RES
            y = -SIZE * 0.5 + j * SIZE / RES
            # Blender 是 Z 朝上；这里先按 Z-up 建模，导出时由导出器转成 Y-up
            verts.append((x, y, terrain_h(i, j)))

    faces = []
    for i in range(RES):
        for j in range(RES):
            a = i * (RES + 1) + j
            b = a + 1
            c = a + (RES + 1)
            d = c + 1
            faces.append((a, c, d, b))

    me = bpy.data.meshes.new("地形")
    me.from_pydata(verts, [], faces)
    me.validate()
    ob = bpy.data.objects.new("地形", me)
    bpy.context.collection.objects.link(ob)
    return ob


clear_scene()          # 必须最先做：否则工厂启动场景里的默认立方体会一起被导出去

terrain = build_terrain()

# Kd 就是"想让它长什么样" —— 引擎那边 hw 的 lambert 是
# `albedo * (0.35 + 0.75*dot)`，朝上的面系数约 1.0，等于把 Kd 原样显示。
# 所以别按"打光会提亮"去压暗（第一版压暗过一档，结果引擎里一片墨绿），
# 直接把目标显示色写进 Kd，再把下面 Blender 预览的太阳强度压到 1.0 倍左右去对齐。
MATS = [
    make_material("草地", (0.330, 0.550, 0.215)),
    make_material("山坡草", (0.420, 0.575, 0.240)),
    make_material("山顶岩土", (0.520, 0.470, 0.400)),
    make_material("草叶", (0.470, 0.730, 0.285)),
]
for m in MATS:
    terrain.data.materials.append(m)

# 分材质规则（顺序很重要）：
#   1) 坡度陡 → 岩石。按高度横着切分成一圈一圈的硬环，很假；
#      按坡度切才对 —— 陡坡本来就露岩，缓地才是草皮。
#   2) 缓坡上再按高度分草地 / 山坡草，阈值加噪声抖动破掉圆环感。
me = terrain.data
h_cut = MAXH * 0.42
for p in me.polygons:
    c = p.center
    nz = p.normal.z                      # 面法线的 Z 分量：1 = 水平面
    jit = 0.55 * noise.noise((c.x * 0.16, c.y * 0.16, 7.0))
    if nz < 0.74:                        # 陡坡 → 岩土
        p.material_index = 2
    elif c.z + jit < h_cut:
        p.material_index = 0             # 低处草地
    else:
        p.material_index = 1             # 高处山坡草
    p.use_smooth = True            # 平滑着色 → 导出的 vn 是平均法线，山丘更柔和

print("[gen] 地形 %d 顶点 / %d 面" % (len(me.vertices), len(me.polygons)))
# 原点(0,0)处的地面高度 —— 引擎侧摆角色时要用它把脚底对到地面
print("[gen] 原点高度 = %.4f" % terrain_h(RES // 2, RES // 2))

# ---------------------------------------------------------------- 草叶


def build_grass():
    """草簇 = 两片交叉的单面三角。法线强制朝上 —— 这样草不会被光照照黑，
    也省掉「每片都要正反两面」的一倍三角形。"""
    verts, faces, norms = [], [], []

    def blade(bx, by, bz, yaw, w, h, lean):
        cx, cy = math.cos(yaw), math.sin(yaw)
        px, py = -cy, cx                      # 垂直于叶片方向
        base = Vector((bx, by, bz - 0.06))    # 埋进地面一点，免 z-fighting
        v0 = (base.x - px * w, base.y - py * w, base.z)
        v1 = (base.x + px * w, base.y + py * w, base.z)
        v2 = (bx + cx * lean, by + cy * lean, bz + h)
        i0 = len(verts)
        for v in (v0, v1, v2):
            verts.append(v)
            norms.append((0.0, 0.0, 1.0))     # 朝上
        faces.append((i0, i0 + 1, i0 + 2))
        return i0

    placed = 0
    tries = 0
    while placed < GRASS_N and tries < GRASS_N * 40:
        tries += 1
        x = random.uniform(-SIZE * 0.5 + 1.0, SIZE * 0.5 - 1.0)
        y = random.uniform(-SIZE * 0.5 + 1.0, SIZE * 0.5 - 1.0)
        fi = (x + SIZE * 0.5) / SIZE * RES
        fj = (y + SIZE * 0.5) / SIZE * RES
        i0, j0 = int(fi), int(fj)
        if i0 >= RES or j0 >= RES:
            continue
        tx, ty = fi - i0, fj - j0
        z = (terrain_h(i0, j0) * (1 - tx) * (1 - ty)
             + terrain_h(i0 + 1, j0) * tx * (1 - ty)
             + terrain_h(i0, j0 + 1) * (1 - tx) * ty
             + terrain_h(i0 + 1, j0 + 1) * tx * ty)
        if z > MAXH * 0.62:               # 高处是岩土，不长草
            continue
        # 陡坡也不长草（和地形分材质用的是同一条坡度判据）
        step = SIZE / RES
        dx = (terrain_h(min(i0 + 1, RES), j0) - terrain_h(max(i0 - 1, 0), j0)) / (2 * step)
        dy = (terrain_h(i0, min(j0 + 1, RES)) - terrain_h(i0, max(j0 - 1, 0))) / (2 * step)
        if 1.0 / math.sqrt(1.0 + dx * dx + dy * dy) < 0.78:
            continue
        # 低处草高、高处草矮
        f = max(0.0, 1.0 - z / (MAXH * 0.64))
        # 宽高比控制在 1:3 左右 —— 太细长就会从"草丛"变成"针"
        h = random.uniform(0.15, 0.36) * (0.45 + 0.75 * f)
        w = random.uniform(0.065, 0.125) * (0.75 + 0.45 * f)
        yaw = random.uniform(0.0, math.pi)
        lean = random.uniform(-0.09, 0.09)
        blade(x, y, z, yaw, w, h, lean)
        blade(x, y, z, yaw + math.pi * 0.5, w, h, -lean)
        placed += 1

    me = bpy.data.meshes.new("草叶")
    me.from_pydata(verts, [], faces)
    me.validate()
    # 顺序很关键：先把 use_smooth 定下来，再灌自定义法线。
    # 反过来（先灌法线再改 use_smooth）会让 Blender 重算法线、把自定义法线丢掉 ——
    # 症状就是草叶全变成背光的黑针（竖着的三角形，真实法线是横的）。
    for p in me.polygons:
        p.use_smooth = True
    me.update()
    try:
        me.normals_split_custom_set([(0.0, 0.0, 1.0)] * len(me.loops))
        me.update()
    except Exception as e:
        print("[gen] 自定义法线失败，退化成真实法线:", e)

    ob = bpy.data.objects.new("草叶", me)
    bpy.context.collection.objects.link(ob)
    ob.data.materials.append(MATS[3])
    for p in ob.data.polygons:
        p.material_index = 0

    # 回读校验：角法线的 Z 分量应该都接近 1（朝上）。
    try:
        zs = [c.vector.z for c in me.corner_normals]
        print("[gen] 草叶法线回读: %d 条  Z 范围 %.3f ~ %.3f  平均 %.3f"
              % (len(zs), min(zs), max(zs), sum(zs) / len(zs)))
    except Exception as e:
        print("[gen] 法线回读跳过:", e)

    print("[gen] 草叶 %d 簇 / %d 顶点 / %d 面" % (placed, len(me.vertices), len(me.polygons)))
    return ob


grass = build_grass()

# ---------------------------------------------------------------- 白天空 + 灯 + 相机


def setup_world():
    """天空白，但不让"白"变成环境光。

    第一版直接把 World 设成白色（1,1,1），结果它也当环境光用 —— 整个场景被
    灌满白光，材质全洗成粉彩。所以用 Light Path 的「Is Camera Ray」分流：
        相机射线看到   -> 纯白 1.0（天空就是干净的纯白）
        其余光线（漫反射/环境）-> 0.12 的暗白（只留一点补光，不压平体积感）
    注意还有第二层原因：反照率本身也不能写太亮，见下面 MATS 的注释。
    """
    w = bpy.data.worlds.new("环境光")
    bpy.context.scene.world = w
    w.use_nodes = True
    nt = w.node_tree
    nt.nodes.clear()
    out = nt.nodes.new("ShaderNodeOutputWorld")
    out.location = (400, 0)
    mix = nt.nodes.new("ShaderNodeMixShader")
    mix.location = (180, 0)
    bg_amb = nt.nodes.new("ShaderNodeBackground")     # 环境光：暗
    bg_amb.location = (-40, -140)
    bg_cam = nt.nodes.new("ShaderNodeBackground")     # 天空：纯白
    bg_cam.location = (-40, 60)
    lp = nt.nodes.new("ShaderNodeLightPath")
    lp.location = (-260, 200)

    bg_cam.inputs[0].default_value = (1.0, 1.0, 1.0, 1.0)
    bg_cam.inputs[1].default_value = 1.0              # 相机射线的天：纯白
    bg_amb.inputs[0].default_value = (0.86, 0.90, 1.0, 1.0)   # 略偏天光蓝
    bg_amb.inputs[1].default_value = 0.12             # 补光，不做主光

    nt.links.new(lp.outputs["Is Camera Ray"], mix.inputs[0])
    nt.links.new(bg_amb.outputs[0], mix.inputs[1])    # factor = 0 → 环境
    nt.links.new(bg_cam.outputs[0], mix.inputs[2])    # factor = 1 → 白天空
    nt.links.new(mix.outputs[0], out.inputs[0])
    w.color = (1.0, 1.0, 1.0)


def setup_sky_compositor():
    """（空）—— 天空的"白"已经在 setup_world 里用 Light Path 分流做掉了。

    这条路试过又拆了：本想用「film_transparent + 合成器 Alpha Over 铺白底」，
    但 Blender 5.x 把合成器改成了 node group（scene.node_tree 没了，
    CompositorNodeComposite 也没了），跨版本不稳；换「天空穹顶网格」也不行
    （5.2 没有 object.visible_shadow，穹顶会把太阳整个遮住）。
    实测结论：Light Path 分流在 EEVEE 里是有效的（出图后背景 38.8% 的像素是纯白），
    所以留着它就够了。"""
    bpy.context.scene.render.film_transparent = False


def add_sun():
    li = bpy.data.lights.new("太阳", "SUN")
    li.energy = 1.05
    li.color = (1.0, 0.975, 0.925)
    if hasattr(li, "angle"):
        li.angle = math.radians(2.2)
    ob = bpy.data.objects.new("太阳", li)
    bpy.context.collection.objects.link(ob)
    # 压低太阳高度角：山丘的明暗面拉开，阴影也长一点
    ob.rotation_euler = (math.radians(37.0), 0.0, math.radians(-38.0))
    return ob


def add_camera(loc, target, lens=42.0):
    cam = bpy.data.cameras.new("相机")
    cam.lens = lens
    cam.clip_start = 0.1
    cam.clip_end = 2000.0
    ob = bpy.data.objects.new("相机", cam)
    bpy.context.collection.objects.link(ob)
    ob.location = Vector(loc)
    d = (Vector(target) - Vector(loc)).normalized()
    ob.rotation_euler = d.to_track_quat("-Z", "Y").to_euler()
    return ob


setup_world()
setup_sky_compositor()
add_sun()
# 260 米见方的山谷 + 36 米围脊：机位要拉高拉远才装得下
bpy.context.scene.camera = add_camera((168.0, -212.0, 118.0), (0.0, 0.0, 8.0), lens=35.0)

# ---------------------------------------------------------------- 预览渲染

sc = bpy.context.scene
sc.render.engine = "BLENDER_EEVEE"
sc.render.resolution_x = 1600
sc.render.resolution_y = 900
sc.render.resolution_percentage = 100
sc.render.film_transparent = False
sc.render.image_settings.file_format = "PNG"
sc.render.image_settings.color_mode = "RGB"
try:
    sc.eevee.taa_render_samples = 64
except Exception as e:
    print("[gen] eevee samples 设置跳过:", e)
try:
    sc.view_settings.view_transform = "Standard"   # 保住作者色，别被 AgX 洗淡
except Exception as e:
    print("[gen] view_transform 设置跳过:", e)


def render_to(path):
    sc.render.filepath = path
    try:
        bpy.ops.render.render(write_still=True)
        print("[gen] 渲染 ->", path)
    except Exception as e:
        # 预览只是给自己看的，渲不出来不能拦着 .obj 的导出
        print("[gen] 预览渲染失败（不影响导出）:", e)


cam = sc.camera
render_to(os.path.join(OUT_DIR, "preview_big_1.png"))

# 低机位近景：贴着草地看山丘
cam.location = Vector((-32.0, -58.0, 3.2))
cam.rotation_euler = (Vector((22.0, 2.0, 12.0)) - cam.location).normalized() \
    .to_track_quat("-Z", "Y").to_euler()
cam.data.lens = 34.0
render_to(os.path.join(OUT_DIR, "preview_big_2.png"))

# ---------------------------------------------------------------- 导出 .obj


def mesh_stats():
    nv = nt = 0
    for ob in bpy.context.scene.objects:
        if ob.type != "MESH":
            continue
        me = ob.data
        nv += len(me.vertices)
        for p in me.polygons:
            nt += len(p.vertices) - 2
    return nv, nt


nv, nt = mesh_stats()
print("[gen] 场景合计: %d 顶点 / %d 三角面" % (nv, nt))

# 导出前先自证：每个对象的材质槽名、以及每个槽实际分到多少面。
# 这两行能一眼抓住「槽位串了」这类问题（导出的 usemtl 跟预期不符）。
for ob in bpy.context.scene.objects:
    if ob.type != "MESH":
        continue
    slots = [m.name if m else "(空)" for m in ob.data.materials]
    cnt = {}
    for p in ob.data.polygons:
        cnt[p.material_index] = cnt.get(p.material_index, 0) + 1
    print("[gen] 对象 %s 槽=%s 面数=%s" % (ob.name, slots,
          {k: (slots[k] if k < len(slots) else "越界") for k in sorted(cnt)}))
    print("[gen]     每槽面数 %s" % {k: cnt[k] for k in sorted(cnt)})

obj_path = os.path.join(OUT_DIR, "hills_big.obj")
bpy.ops.wm.obj_export(
    filepath=obj_path,
    export_selected_objects=False,
    export_uv=True,
    export_normals=True,
    export_materials=True,
    export_triangulated_mesh=True,
    apply_modifiers=True,
    apply_transform=True,
    forward_axis="NEGATIVE_Z",      # Blender 默认；PYbook 侧用 hw.objfix(h,1) 修
    up_axis="Y",
    export_colors=False,
    export_pbr_extensions=False,
    path_mode="AUTO",
)
print("[gen] 导出 ->", obj_path)

for f in ("hills_big.obj", "hills_big.mtl"):
    p = os.path.join(OUT_DIR, f)
    print("[gen] %s  %d 字节" % (f, os.path.getsize(p) if os.path.exists(p) else -1))
print("[gen] DONE")
