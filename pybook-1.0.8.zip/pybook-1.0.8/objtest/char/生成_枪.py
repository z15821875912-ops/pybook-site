# -*- coding: utf-8 -*-
"""再生成三把枪的 Wavefront .obj（+ .mtl），给 PYbook 的 hw.obj 用。

    blender -b --factory-startup --python _bl_guns.py -- <输出目录>

约定和 gun.obj（突击步枪）完全一致，这样引擎侧挂点算法不用改：
  · 原点在"握把中心"（手握住的地方）
  · 沿 Blender +Y 指向前方 → hw.objfix(句柄, 1) 之后就是 hw 的 +X
  · 单位是米：玩家身高 1.80，狙击枪全长约 1.35 就是"确实长"
所以"枪口在自身坐标的前方距离" = Blender 里最大 y + 平移量，
脚本最后会把每把枪的这个数打印出来，直接抄进 .pybk。

导出：pistol.obj / shotgun.obj / sniper.obj（gun.obj 是之前那个突击步枪，不动它）

⚠ 导出后文件名改成了 gun_pistol.obj / gun_shotgun.obj / gun_sniper.obj，
 但 obj 里的 `mtllib` 行还是 Blender 写的老名字（pistol.mtl 等）。
 引擎的 hw.obj 读 mtllib 找不到文件就整把枪掉成默认灰 —— 手枪/霰弹枪/狙击枪
 之前全是灰的，就因为这个。改名之后记得把 `mtllib` 那一行也改掉（已修）。
"""
import math
import os
import sys

import bmesh
import bpy
from mathutils import Matrix, Vector

OUT_DIR = sys.argv[sys.argv.index("--") + 1] if "--" in sys.argv else "."
os.makedirs(OUT_DIR, exist_ok=True)

# ---------------------------------------------------------------- 材质
GUN_MATS = [
    ("枪身金属", (0.200, 0.210, 0.235)),
    ("枪管钢", (0.420, 0.440, 0.480)),
    ("木质", (0.360, 0.210, 0.100)),
    ("塑料黑", (0.110, 0.110, 0.120)),
    ("弹匣", (0.245, 0.245, 0.265)),
]
M_RECEIVER, M_STEEL, M_WOOD, M_PLASTIC, M_MAG = range(5)


# ---------------------------------------------------------------- 建模工具
def box(bm, center, size, mat, rot=None):
    hx, hy, hz = size[0] / 2.0, size[1] / 2.0, size[2] / 2.0
    loc = [(-hx, -hy, -hz), (hx, -hy, -hz), (hx, hy, -hz), (-hx, hy, -hz),
           (-hx, -hy, hz), (hx, -hy, hz), (hx, hy, hz), (-hx, hy, hz)]
    M = Matrix.Translation(Vector(center)) @ (rot or Matrix.Identity(4))
    vs = [bm.verts.new((M @ Vector(p))[:]) for p in loc]
    for q in ((0, 1, 2, 3), (4, 5, 6, 7), (0, 1, 5, 4),
              (1, 2, 6, 5), (2, 3, 7, 6), (3, 0, 4, 7)):
        bm.faces.new([vs[i] for i in q]).material_index = mat
    return vs


def cyl(bm, center, radius, length, mat, axis="Y", seg=12):
    ring0, ring1 = [], []
    for i in range(seg):
        a = 2.0 * math.pi * i / seg
        c, s = math.cos(a) * radius, math.sin(a) * radius
        if axis == "Y":
            p0, p1 = (c, -length / 2, s), (c, length / 2, s)
        elif axis == "Z":
            p0, p1 = (c, s, -length / 2), (c, s, length / 2)
        else:
            p0, p1 = (-length / 2, c, s), (length / 2, c, s)
        ring0.append(bm.verts.new((center[0] + p0[0], center[1] + p0[1], center[2] + p0[2])))
        ring1.append(bm.verts.new((center[0] + p1[0], center[1] + p1[1], center[2] + p1[2])))
    for i in range(seg):
        j = (i + 1) % seg
        bm.faces.new((ring0[i], ring0[j], ring1[j], ring1[i])).material_index = mat
    bm.faces.new(list(reversed(ring0))).material_index = mat
    bm.faces.new(ring1).material_index = mat
    return ring0 + ring1


def finish(bm, name, mats, translate=None):
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])
    if translate is not None:
        bmesh.ops.translate(bm, verts=bm.verts[:], vec=Vector(translate))
    me = bpy.data.meshes.new(name)
    bm.to_mesh(me)
    bm.free()
    for p in me.polygons:
        p.use_smooth = False
    ob = bpy.data.objects.new(name, me)
    bpy.context.collection.objects.link(ob)
    for nm, kd in mats:
        m = bpy.data.materials.new(nm)
        m.use_nodes = True
        b = m.node_tree.nodes.get("Principled BSDF")
        if b is not None:
            b.inputs["Base Color"].default_value = (kd[0], kd[1], kd[2], 1.0)
            if "Roughness" in b.inputs:
                b.inputs["Roughness"].default_value = 0.62
            if "Specular IOR Level" in b.inputs:
                b.inputs["Specular IOR Level"].default_value = 0.35
        m.diffuse_color = (kd[0], kd[1], kd[2], 1.0)
        m.specular_intensity = 0.35
        m.roughness = 0.62
        ob.data.materials.append(m)
    return ob


ROT = lambda deg: Matrix.Rotation(math.radians(deg), 4, "X")


# ---------------------------------------------------------------- 手枪
# 小巧：全长约 0.37。握把中心 (0,-0.030,-0.085) → 平移量 (0, 0.030, 0.085)
def build_pistol():
    bm = bmesh.new()
    box(bm, (0, 0.075, 0.052), (0.038, 0.185, 0.055), M_RECEIVER)     # 套筒
    cyl(bm, (0, 0.150, 0.040), 0.011, 0.090, M_STEEL, "Y", 10)        # 枪管
    cyl(bm, (0, 0.196, 0.040), 0.015, 0.020, M_STEEL, "Y", 10)        # 枪口
    box(bm, (0, 0.075, 0.006), (0.034, 0.150, 0.040), M_PLASTIC)      # 套筒座
    box(bm, (0, -0.030, -0.085), (0.040, 0.058, 0.150), M_PLASTIC, ROT(-12))  # 握把
    box(bm, (0, 0.012, -0.032), (0.014, 0.062, 0.012), M_RECEIVER)    # 扳机护圈
    box(bm, (0, 0.010, -0.016), (0.010, 0.016, 0.024), M_STEEL)       # 扳机
    box(bm, (0, -0.028, -0.162), (0.036, 0.052, 0.018), M_MAG)        # 弹匣底
    box(bm, (0, 0.152, 0.086), (0.010, 0.016, 0.016), M_RECEIVER)     # 准星
    box(bm, (0, -0.004, 0.086), (0.026, 0.014, 0.016), M_RECEIVER)    # 照门
    return finish(bm, "手枪", GUN_MATS, translate=(0, 0.030, 0.085))


# ---------------------------------------------------------------- 霰弹枪
# 粗管子 + 木质前护木，全长约 1.10。握把中心 (0,-0.085,-0.095)
def build_shotgun():
    bm = bmesh.new()
    box(bm, (0, 0.030, 0.030), (0.072, 0.300, 0.105), M_RECEIVER)     # 机匣
    cyl(bm, (0, 0.430, 0.058), 0.023, 0.520, M_STEEL, "Y", 12)        # 粗枪管
    cyl(bm, (0, 0.706, 0.058), 0.030, 0.055, M_STEEL, "Y", 12)        # 枪口
    cyl(bm, (0, 0.390, 0.018), 0.014, 0.430, M_STEEL, "Y", 10)        # 下弹管
    box(bm, (0, 0.320, 0.014), (0.074, 0.190, 0.082), M_WOOD)         # 前护木（泵）
    box(bm, (0, -0.085, -0.095), (0.052, 0.060, 0.155), M_WOOD, ROT(-18))     # 握把
    box(bm, (0, -0.245, 0.010), (0.058, 0.230, 0.105), M_WOOD)        # 枪托
    box(bm, (0, -0.372, 0.010), (0.062, 0.028, 0.115), M_PLASTIC)     # 托底
    box(bm, (0, -0.010, -0.038), (0.016, 0.070, 0.012), M_RECEIVER)   # 扳机护圈
    box(bm, (0, -0.012, -0.022), (0.010, 0.018, 0.026), M_STEEL)      # 扳机
    box(bm, (0, 0.560, 0.086), (0.012, 0.018, 0.018), M_RECEIVER)     # 准星
    box(bm, (0, -0.040, 0.090), (0.030, 0.016, 0.018), M_RECEIVER)    # 照门
    return finish(bm, "霰弹枪", GUN_MATS, translate=(0, 0.085, 0.095))


# ---------------------------------------------------------------- 狙击枪
# 长枪管 + 顶上那根镜筒，全长约 1.35。握把中心 (0,-0.095,-0.105)
def build_sniper():
    bm = bmesh.new()
    box(bm, (0, 0.040, 0.030), (0.072, 0.400, 0.115), M_RECEIVER)     # 机匣
    cyl(bm, (0, 0.540, 0.048), 0.019, 0.680, M_STEEL, "Y", 12)        # 长枪管
    cyl(bm, (0, 0.915, 0.048), 0.030, 0.075, M_STEEL, "Y", 12)        # 枪口制退器
    cyl(bm, (0, 0.090, 0.142), 0.033, 0.320, M_PLASTIC, "Y", 12)      # 瞄具镜筒
    cyl(bm, (0, 0.018, 0.142), 0.040, 0.030, M_PLASTIC, "Y", 12)      # 物镜圈
    cyl(bm, (0, 0.245, 0.142), 0.036, 0.026, M_PLASTIC, "Y", 12)      # 目镜圈
    box(bm, (0, 0.010, 0.104), (0.028, 0.028, 0.052), M_RECEIVER)     # 镜座前
    box(bm, (0, 0.170, 0.104), (0.028, 0.028, 0.052), M_RECEIVER)     # 镜座后
    box(bm, (0, 0.100, -0.062), (0.058, 0.100, 0.110), M_MAG)         # 弹匣
    box(bm, (0, -0.095, -0.105), (0.050, 0.060, 0.165), M_PLASTIC, ROT(-16))  # 握把
    box(bm, (0, -0.290, 0.010), (0.058, 0.270, 0.120), M_PLASTIC)     # 枪托
    box(bm, (0, -0.437, 0.010), (0.062, 0.030, 0.125), M_PLASTIC)     # 托底
    box(bm, (0, -0.185, 0.088), (0.044, 0.170, 0.024), M_PLASTIC)     # 贴腮板
    box(bm, (0, -0.015, -0.042), (0.016, 0.075, 0.012), M_RECEIVER)   # 扳机护圈
    box(bm, (0, -0.017, -0.026), (0.010, 0.018, 0.028), M_STEEL)      # 扳机
    return finish(bm, "狙击枪", GUN_MATS, translate=(0, 0.095, 0.105))


# ---------------------------------------------------------------- 主流程
bpy.ops.wm.read_factory_settings(use_empty=True)

GUNS = [("pistol.obj", build_pistol()),
        ("shotgun.obj", build_shotgun()),
        ("sniper.obj", build_sniper())]


def export(ob, filename):
    for o in bpy.context.scene.objects:
        o.select_set(False)
    ob.select_set(True)
    bpy.context.view_layer.objects.active = ob
    path = os.path.join(OUT_DIR, filename)
    bpy.ops.wm.obj_export(
        filepath=path,
        export_selected_objects=True,
        export_uv=True, export_normals=True, export_materials=True,
        export_triangulated_mesh=True,
        apply_modifiers=True, apply_transform=True,
        forward_axis="NEGATIVE_Z", up_axis="Y",
        export_colors=False, export_pbr_extensions=False, path_mode="AUTO",
    )
    nv = nf = nmat = 0
    mn = [1e30] * 3
    mx = [-1e30] * 3
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        for ln in f:
            if ln.startswith("v "):
                nv += 1
                q = [float(t) for t in ln.split()[1:4]]
                for k in range(3):
                    mn[k] = min(mn[k], q[k])
                    mx[k] = max(mx[k], q[k])
            elif ln.startswith("f "):
                nf += 1
            elif ln.startswith("usemtl "):
                nmat += 1
    # 注意导出时的轴变换：Blender +Y(前) → obj -Z，Blender +Z(上) → obj +Y，
    # 也就是说 obj 里"前后"落在 z 轴上，标签按 obj 轴写才不会看错。
    # 最终 hw 坐标 = (blender_y, blender_z, blender_x) = (-obj_z, obj_y, obj_x)
    b_y0, b_y1 = -mx[2], -mn[2]        # Blender y = 前后
    b_z0, b_z1 = mn[1], mx[1]          # Blender z = 上下
    b_x0, b_x1 = mn[0], mx[0]          # Blender x = 左右
    print("[gen] %-13s v=%-4d f=%-4d usemtl=%d  %6d 字节" % (filename, nv, nf, nmat, os.path.getsize(path)))
    print("        Blender x %.3f~%.3f  y %.3f~%.3f  z %.3f~%.3f" %
          (b_x0, b_x1, b_y0, b_y1, b_z0, b_z1))
    print("        → hw 里：全长 %.3f   枪口在自身坐标 +%.3f   托底 %.3f   最高 %.3f" %
          (b_y1 - b_y0, b_y1, b_y0, b_z1))


for fn, ob in GUNS:
    export(ob, fn)

# ---------------------------------------------------------------- 预览渲染
bpy.ops.mesh.primitive_plane_add(size=40.0, location=(0.0, 0.0, -0.35))
floor = bpy.context.object
fm = bpy.data.materials.new("地面")
fm.use_nodes = True
fb = fm.node_tree.nodes.get("Principled BSDF")
if fb is not None:
    fb.inputs["Base Color"].default_value = (0.55, 0.56, 0.58, 1.0)
floor.data.materials.append(fm)

w = bpy.data.worlds.new("环境光")
bpy.context.scene.world = w
w.use_nodes = True
nt = w.node_tree
nt.nodes.clear()
out = nt.nodes.new("ShaderNodeOutputWorld")
mix = nt.nodes.new("ShaderNodeMixShader")
bg_amb = nt.nodes.new("ShaderNodeBackground")
bg_cam = nt.nodes.new("ShaderNodeBackground")
lp = nt.nodes.new("ShaderNodeLightPath")
bg_cam.inputs[0].default_value = (1.0, 1.0, 1.0, 1.0)
bg_amb.inputs[0].default_value = (0.86, 0.90, 1.0, 1.0)
bg_amb.inputs[1].default_value = 0.14
nt.links.new(lp.outputs["Is Camera Ray"], mix.inputs[0])
nt.links.new(bg_amb.outputs[0], mix.inputs[1])
nt.links.new(bg_cam.outputs[0], mix.inputs[2])
nt.links.new(mix.outputs[0], out.inputs[0])

li = bpy.data.lights.new("太阳", "SUN")
li.energy = 1.05
sun = bpy.data.objects.new("太阳", li)
bpy.context.collection.objects.link(sun)
sun.rotation_euler = (math.radians(37.0), 0.0, math.radians(-38.0))

sc = bpy.context.scene
sc.render.engine = "BLENDER_EEVEE"
sc.render.resolution_x = 1400
sc.render.resolution_y = 620
sc.render.image_settings.file_format = "PNG"
try:
    sc.eevee.taa_render_samples = 48
except Exception as e:
    print("[gen] eevee samples 跳过:", e)
try:
    sc.view_settings.view_transform = "Standard"
except Exception as e:
    print("[gen] view_transform 跳过:", e)


def shot(loc, target, lens, path):
    cam = bpy.data.cameras.new("相机")
    cam.lens = lens
    cam.clip_start = 0.02
    ob = bpy.data.objects.new("相机", cam)
    bpy.context.collection.objects.link(ob)
    ob.location = Vector(loc)
    ob.rotation_euler = (Vector(target) - Vector(loc)).normalized().to_track_quat("-Z", "Y").to_euler()
    sc.camera = ob
    sc.render.filepath = os.path.join(OUT_DIR, path)
    bpy.ops.render.render(write_still=True)
    print("[gen] 渲染 ->", path)
    bpy.data.objects.remove(ob, do_unlink=True)


# 一把一张，同一个 3/4 视角 —— 省得跟"导入/新建"两套轴变换纠缠
# 枪都朝 Blender +Y（前方），相机从"右上前方"看过去，长短枪都框得住
bpy.ops.wm.obj_import(filepath=os.path.join(OUT_DIR, "gun.obj"),
                      forward_axis="NEGATIVE_Z", up_axis="Y")
rifle = bpy.context.selected_objects[-1]
rifle.name = "突击步枪_obj"

ALL = [("preview_1_步枪.png", rifle),
       ("preview_2_手枪.png", GUNS[0][1]),
       ("preview_3_霰弹枪.png", GUNS[1][1]),
       ("preview_4_狙击枪.png", GUNS[2][1])]

for path, ob in ALL:
    for o in bpy.context.scene.objects:
        if o.type == "MESH" and o is not floor:
            o.hide_render = (o is not ob)
    ob.hide_render = False
    # 把整把枪的包围盒挪到原点，画面才居中（长枪短枪同一套相机参数）
    pts = [ob.matrix_world @ v.co for v in ob.data.vertices]
    cx = sum(p.x for p in pts) / len(pts)
    cy = sum(p.y for p in pts) / len(pts)
    cz = sum(p.z for p in pts) / len(pts)
    ob.location = Vector((-cx, -cy, -cz))
    ob.rotation_euler = (0.0, 0.0, 0.0)
    span = max(max(p.y for p in pts) - min(p.y for p in pts),
               max(p.z for p in pts) - min(p.z for p in pts))
    d = 0.85 + span * 0.72
    shot((d * 0.92, -d * 0.95, d * 0.46), (0.0, 0.0, 0.0), 50.0, path)

print("[gen] DONE")
