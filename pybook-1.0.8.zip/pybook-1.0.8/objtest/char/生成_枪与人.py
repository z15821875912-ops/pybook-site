# -*- coding: utf-8 -*-
"""生成「枪」「玩家角色」和「可动关节件」三套 Wavefront .obj（+ .mtl），供 PYbook 的 hw.obj 用。

跑法（不需要任何插件）：
    blender -b --factory-startup --python 生成_枪与人.py -- <输出目录>

产出：
    gun.obj / gun.mtl          突击步枪，原点在握把（手握住的位置）
    player.obj / player.mtl    整个人形（整块网格，拿来当"木人靶"最省事）
    part_*.obj                 同一套人形的 8 个关节件，枢轴就在关节上：
        part_torso    躯干（髋+腰带+胸+肩+脖子）  枢轴 = 髋中心
        part_head     头（头+头发+眼睛）          枢轴 = 脖子根
        part_armL/R   左/右臂（上臂+前臂+手）     枢轴 = 肩
        part_thighL/R 左/右大腿                   枢轴 = 髋关节
        part_shinL/R  左/右小腿（含脚）           枢轴 = 膝盖
     引擎里用 hw.push(关节位置, 旋转) + hw.objdraw(件, 0,0,0,1) + hw.pop()
     就能摆姿势、做走路动画 —— 详见 PYBOOK_AI.md。

    preview_gun.png        枪的 3/4 俯视
    preview_player.png     整个人形的 3/4 前视
    preview_held.png       角色持枪
    preview_held_side.png  持枪右侧视（看枪是否水平、有没有穿模）
    preview_parts.png      8 个关节件按枢轴摆回去（应该和整身一模一样）
    preview_walk.png       走路姿势（腿摆开、膝盖弯、手臂甩）

坐标约定（很重要，别改）：
    Blender 是 Z 朝上、+Y 朝前。Blender 的 obj 导出走默认
    forward=-Z / up=Y，于是 obj 文件里已经是 Y-up：
        obj_x = blender_x      obj_y = blender_z      obj_z = -blender_y
    引擎的 hw.objfix(句柄, 1) 做的是 (x,y,z) -> (-z, y, x)，两步合起来：
        Blender +X（右）  -> hw +Z（右）
        Blender +Y（前）  -> hw +X（前，hw 里 yaw=0 的正前方）
        Blender +Z（上）  -> hw +Y（上）
    所以每个关节件在引擎里的关节位置 = (blender_y, blender_z, blender_x)，
    脚本会把这些数打印出来，直接抄进 .pybk 就行。

姿势说明：右手单持（肘弯约 90°），左臂自然下垂 —— 因为枪全长 1.15，
左手要扶的护木在握把前方 0.40 处，而臂长只有约 0.67，够不到。
"""
import bpy
import bmesh
import math
import os
import sys
from mathutils import Matrix, Vector

argv = sys.argv
OUT_DIR = argv[argv.index("--") + 1] if "--" in argv else "."
os.makedirs(OUT_DIR, exist_ok=True)

# Kd 直接写"想显示成什么颜色"：引擎的 lambert 是 albedo*(0.35+0.75*dot)，
# 朝上的面系数约 1.0，等于把 Kd 原样显示出来。
GUN_MATS = [
    ("枪身金属", (0.200, 0.210, 0.235)),
    ("枪管钢", (0.420, 0.440, 0.480)),
    ("木质", (0.360, 0.210, 0.100)),
    ("塑料黑", (0.110, 0.110, 0.120)),
    ("弹匣", (0.245, 0.245, 0.265)),
]
M_RECEIVER, M_STEEL, M_WOOD, M_PLASTIC, M_MAG = range(5)

PLAYER_MATS = [
    ("皮肤", (0.720, 0.530, 0.420)),
    ("上衣", (0.200, 0.320, 0.550)),
    ("裤子", (0.230, 0.240, 0.280)),
    ("鞋", (0.100, 0.100, 0.110)),
    ("头发", (0.120, 0.085, 0.060)),
    ("眼睛", (0.070, 0.070, 0.085)),
]
M_SKIN, M_SHIRT, M_PANTS, M_SHOE, M_HAIR, M_EYE = range(6)

# 关节位置（Blender 局部坐标，脚底 z=0）
SHOULDER_R = Vector((0.195, 0.000, 1.435))
ELBOW_R    = Vector((0.238, 0.045, 1.170))
HAND       = Vector((0.222, 0.345, 1.170))
SHOULDER_L = Vector((-0.195, 0.000, 1.435))
ELBOW_L    = Vector((-0.255, 0.020, 1.170))
WRIST_L    = Vector((-0.275, 0.045, 0.925))

HIP        = Vector((0.000, 0.000, 1.000))     # 躯干枢轴
NECK       = Vector((0.000, 0.005, 1.520))     # 头枢轴
HIPJ_L     = Vector((-0.095, 0.005, 0.925))    # 左大腿枢轴（髋关节）
KNEE_L     = Vector((-0.095, 0.005, 0.485))    # 左小腿枢轴（膝盖）
HIPJ_R     = Vector((0.095, 0.005, 0.925))
KNEE_R     = Vector((0.095, 0.005, 0.485))

# 关节件表：(名字, 枢轴)
PARTS = [
    ("part_torso", HIP),
    ("part_head", NECK),
    ("part_armL", SHOULDER_L),
    ("part_armR", SHOULDER_R),
    ("part_thighL", HIPJ_L),
    ("part_shinL", KNEE_L),
    ("part_thighR", HIPJ_R),
    ("part_shinR", KNEE_R),
]


# ---------------------------------------------------------------- 建模工具

def box(bm, center, size, mat, rot=None):
    """轴对齐长方体（可带一个旋转矩阵）。返回新建的 8 个顶点。"""
    hx, hy, hz = size[0] / 2.0, size[1] / 2.0, size[2] / 2.0
    loc = [(-hx, -hy, -hz), (hx, -hy, -hz), (hx, hy, -hz), (-hx, hy, -hz),
           (-hx, -hy, hz), (hx, -hy, hz), (hx, hy, hz), (-hx, hy, hz)]
    M = Matrix.Translation(Vector(center)) @ (rot or Matrix.Identity(4))
    vs = [bm.verts.new((M @ Vector(p))[:]) for p in loc]
    for q in ((0, 1, 2, 3), (4, 5, 6, 7), (0, 1, 5, 4),
              (1, 2, 6, 5), (2, 3, 7, 6), (3, 0, 4, 7)):
        f = bm.faces.new([vs[i] for i in q])
        f.material_index = mat
    return vs


def limb(bm, p0, p1, w, d, mat):
    """从 p0 到 p1 的一根方柱（w = 左右厚，d = 前后厚）。
    用关节坐标描述四肢，比"盒子 + 猜旋转角"省事也不容易错。"""
    p0, p1 = Vector(p0), Vector(p1)
    v = p1 - p0
    if v.length < 1e-6:
        return []
    q = v.normalized().to_track_quat("Z", "Y")          # 让方柱的 +Z 指向 p1
    return box(bm, (p0 + p1) * 0.5, (w, d, v.length), mat, q.to_matrix().to_4x4())


def cyl(bm, center, radius, length, mat, axis="Y", seg=12):
    """圆柱。axis 指定轴向（建模里只需要 Y 向的枪管）。"""
    ring0, ring1 = [], []
    for i in range(seg):
        a = 2.0 * math.pi * i / seg
        c, s = math.cos(a) * radius, math.sin(a) * radius
        if axis == "Y":
            p0, p1 = (c, -length / 2, s), (c, length / 2, s)
        elif axis == "Z":
            p0, p1 = (c, s, -length / 2), (c, s, length / 2)
        else:
            p0, p1 = (-length / 2, c, s), (length / 2, c, s)
        ring0.append(bm.verts.new((center[0] + p0[0], center[1] + p0[1], center[2] + p0[2])))
        ring1.append(bm.verts.new((center[0] + p1[0], center[1] + p1[1], center[2] + p1[2])))
    for i in range(seg):
        j = (i + 1) % seg
        bm.faces.new((ring0[i], ring0[j], ring1[j], ring1[i])).material_index = mat
    bm.faces.new(list(reversed(ring0))).material_index = mat
    bm.faces.new(ring1).material_index = mat
    return ring0 + ring1


def finish(bm, name, mats, translate=None):
    """统一收尾：把法线统一朝外（省得自己逐个对绕序）、建对象、挂材质槽。"""
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])
    if translate is not None:
        bmesh.ops.translate(bm, verts=bm.verts[:], vec=Vector(translate))
    me = bpy.data.meshes.new(name)
    bm.to_mesh(me)
    bm.free()
    for p in me.polygons:
        p.use_smooth = False           # 低多边形：平直着色，棱角分明
    ob = bpy.data.objects.new(name, me)
    bpy.context.collection.objects.link(ob)
    for nm, kd in mats:
        m = bpy.data.materials.new(nm)
        m.use_nodes = True
        b = m.node_tree.nodes.get("Principled BSDF")
        if b is not None:
            b.inputs["Base Color"].default_value = (kd[0], kd[1], kd[2], 1.0)
            if "Roughness" in b.inputs:
                b.inputs["Roughness"].default_value = 0.62
            if "Specular IOR Level" in b.inputs:
                b.inputs["Specular IOR Level"].default_value = 0.35
        m.diffuse_color = (kd[0], kd[1], kd[2], 1.0)
        m.specular_intensity = 0.35
        m.roughness = 0.62
        ob.data.materials.append(m)
    return ob


# ---------------------------------------------------------------- 枪
# 全长约 1.15（玩家身高 1.80，比例约 0.64），沿 +Y 指向前方。
# 原点在握把中心 —— 引擎里「把枪放到手上」就是一句平移。

def build_gun():
    bm = bmesh.new()
    rot = lambda deg, ax="X": Matrix.Rotation(math.radians(deg), 4, ax)

    box(bm, (0, 0.030, 0.015), (0.075, 0.340, 0.115), M_RECEIVER)      # 机匣
    box(bm, (0, 0.050, 0.078), (0.042, 0.320, 0.026), M_RECEIVER)      # 上导轨
    cyl(bm, (0, 0.440, 0.035), 0.017, 0.420, M_STEEL, "Y", 12)         # 枪管
    cyl(bm, (0, 0.665, 0.035), 0.027, 0.060, M_STEEL, "Y", 12)         # 枪口
    box(bm, (0, 0.300, 0.010), (0.064, 0.280, 0.080), M_WOOD)          # 护木
    box(bm, (0, 0.500, 0.070), (0.016, 0.022, 0.060), M_RECEIVER)      # 准星
    box(bm, (0, -0.030, 0.098), (0.038, 0.022, 0.030), M_RECEIVER)     # 照门
    box(bm, (0, 0.052, -0.040), (0.062, 0.100, 0.052), M_RECEIVER)     # 弹匣井
    box(bm, (0, -0.100, -0.110), (0.052, 0.062, 0.170), M_PLASTIC, rot(-18))   # 握把（后倾）
    box(bm, (0, -0.030, -0.072), (0.020, 0.095, 0.014), M_RECEIVER)    # 扳机护圈
    box(bm, (0, -0.028, -0.052), (0.012, 0.026, 0.034), M_STEEL)       # 扳机
    box(bm, (0, 0.055, -0.145), (0.056, 0.090, 0.210), M_MAG, rot(14))  # 弹匣（前倾）
    box(bm, (0, -0.300, -0.005), (0.056, 0.260, 0.105), M_WOOD)        # 枪托
    box(bm, (0, -0.442, -0.005), (0.060, 0.028, 0.115), M_PLASTIC)     # 托底板
    box(bm, (0, -0.240, 0.056), (0.040, 0.160, 0.020), M_WOOD)         # 贴腮板

    return finish(bm, "枪", GUN_MATS, translate=(0, 0.100, 0.110))


# ---------------------------------------------------------------- 人形
# 几何只写一遍：part=None 全加（拼整身），否则只加指定的关节件。
# 这样"整身"和"8 个件"永远不会走样 —— 顶点总数也必须对得上。

def emit(g, part=None):
    def want(nm):
        return part is None or part == nm

    # ---- 躯干 ----
    if want("part_torso"):
        box(g, (0, 0.000, 1.000), (0.300, 0.210, 0.150), M_PANTS)      # 髋
        box(g, (0, 0.000, 1.080), (0.312, 0.222, 0.046), M_SHOE)       # 腰带
        box(g, (0, 0.000, 1.260), (0.360, 0.230, 0.420), M_SHIRT)      # 躯干
        box(g, (0, 0.000, 1.460), (0.400, 0.220, 0.100), M_SHIRT)      # 肩
        box(g, (0, 0.005, 1.530), (0.100, 0.100, 0.080), M_SKIN)       # 脖子

    # ---- 头（头发分顶盖/后脑/两侧鬓角，正面留出来给脸）----
    if want("part_head"):
        box(g, (0, 0.010, 1.635), (0.175, 0.195, 0.235), M_SKIN)       # 头
        box(g, (0, 0.005, 1.775), (0.192, 0.202, 0.050), M_HAIR)       # 头发顶盖
        box(g, (0, -0.095, 1.676), (0.192, 0.030, 0.155), M_HAIR)      # 后脑
        for sx in (-1.0, 1.0):
            box(g, (sx * 0.0935, 0.002, 1.680), (0.018, 0.200, 0.130), M_HAIR)
            box(g, (sx * 0.044, 0.1085, 1.660), (0.036, 0.010, 0.026), M_EYE)

    # ---- 左臂（自然下垂，微微外张）----
    if want("part_armL"):
        limb(g, SHOULDER_L, ELBOW_L, 0.100, 0.105, M_SHIRT)
        limb(g, ELBOW_L, WRIST_L, 0.092, 0.096, M_SKIN)
        box(g, WRIST_L + Vector((-0.005, 0.010, -0.045)), (0.086, 0.075, 0.115), M_SKIN)

    # ---- 右臂（上臂前倾、前臂前伸，摆成持枪姿势；手的位置 = HAND）----
    if want("part_armR"):
        limb(g, SHOULDER_R, ELBOW_R, 0.100, 0.108, M_SHIRT)
        limb(g, ELBOW_R, HAND - Vector((0.0, 0.035, 0.0)), 0.092, 0.096, M_SKIN)
        box(g, HAND, (0.100, 0.130, 0.105), M_SKIN)

    # ---- 腿：大腿 / 小腿（含脚）----
    for side, hx in (("L", -1.0), ("R", 1.0)):
        if want("part_thigh" + side):
            box(g, (hx * 0.095, 0.005, 0.705), (0.145, 0.160, 0.440), M_PANTS)
        if want("part_shin" + side):
            box(g, (hx * 0.095, 0.012, 0.285), (0.128, 0.140, 0.400), M_PANTS)
            box(g, (hx * 0.098, 0.055, 0.045), (0.135, 0.270, 0.090), M_SHOE)


# ---------------------------------------------------------------- 主流程

bpy.ops.wm.read_factory_settings(use_empty=True)     # 不调会把默认立方体一起导出去

gun = build_gun()

bm_all = bmesh.new()
emit(bm_all, None)
player = finish(bm_all, "玩家", PLAYER_MATS)          # 整身（当靶子用最省事）

parts = {}
for nm, piv in PARTS:
    g = bmesh.new()
    emit(g, nm)
    parts[nm] = finish(g, nm, PLAYER_MATS, translate=(-piv[0], -piv[1], -piv[2]))


def stats(ob):
    me = ob.data
    ntri = sum(len(p.vertices) - 2 for p in me.polygons)
    lo = [min(v.co[i] for v in me.vertices) for i in range(3)]
    hi = [max(v.co[i] for v in me.vertices) for i in range(3)]
    print("[gen] %-14s %4d 顶点 / %4d 三角面 / %d 材质   包围盒 x %.3f~%.3f  y %.3f~%.3f  z %.3f~%.3f"
          % (ob.name, len(me.vertices), ntri, len(ob.data.materials),
             lo[0], hi[0], lo[1], hi[1], lo[2], hi[2]))
    return lo, hi, len(me.vertices), ntri


glo, ghi, gnv, gnt = stats(gun)
plo, phi, pnv, pnt = stats(player)

# 关键自检：8 个关节件的顶点数/面数加起来必须等于整身
snv, snt = 0, 0
for nm, piv in PARTS:
    lo, hi, nv, nt = stats(parts[nm])
    print("[gen]     枢轴(Blender) %.3f %.3f %.3f   -> hw 关节 (%.3f, %.3f, %.3f)"
          % (piv[0], piv[1], piv[2], piv[1], piv[2], piv[0]))
    snv += nv
    snt += nt
print("[gen] 关节件合计 %d 顶点 / %d 面   整身 %d / %d   %s"
      % (snv, snt, pnv, pnt, "一致 OK" if (snv == pnv and snt == pnt) else "★不一致★"))
if snv != pnv or snt != pnt:
    raise SystemExit("关节件和整身的几何对不上，先修 emit() 再导出")

# 引擎侧要用的数
print("[gen] 右手 (Blender) x=%.3f y=%.3f z=%.3f" % (HAND.x, HAND.y, HAND.z))
print("[gen] 枪的挂点（hw 偏移）dx=%.3f dy=%.3f dz=%.3f" % (HAND.y, HAND.z, HAND.x))
print("[gen] 玩家在 hw 里：高 %.3f（脚底 y=0） 前后 x %.3f~%.3f  左右 z %.3f~%.3f"
      % (phi[2] - plo[2], plo[1], phi[1], plo[0], phi[0]))
print("[gen] 枪在 hw 里：枪口 x=+%.3f  托底 x=%.3f" % (ghi[1], glo[1]))
print("[gen] 头在 hw 里 y 从 %.3f（脖子根）到 %.3f（发顶）" % (1.520, phi[2]))


def export(ob, filename):
    for o in bpy.context.scene.objects:
        o.select_set(False)
    ob.select_set(True)
    bpy.context.view_layer.objects.active = ob
    path = os.path.join(OUT_DIR, filename)
    bpy.ops.wm.obj_export(
        filepath=path,
        export_selected_objects=True,
        export_uv=True, export_normals=True, export_materials=True,
        export_triangulated_mesh=True,
        apply_modifiers=True, apply_transform=True,
        forward_axis="NEGATIVE_Z", up_axis="Y",
        export_colors=False, export_pbr_extensions=False, path_mode="AUTO",
    )
    nv, nf, nmat = 0, 0, 0
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        for ln in f:
            if ln.startswith("v "):
                nv += 1
            elif ln.startswith("f "):
                nf += 1
            elif ln.startswith("usemtl "):
                nmat += 1
    print("[gen] 导出 %-18s %6d 字节  v=%d f=%d usemtl=%d"
          % (filename, os.path.getsize(path), nv, nf, nmat))


export(gun, "gun.obj")
export(player, "player.obj")
for nm, piv in PARTS:
    export(parts[nm], nm + ".obj")

# ---------------------------------------------------------------- 预览渲染
# 地面板和灯都要在导出之后才加 —— 否则会被一起导进 .obj

bpy.ops.mesh.primitive_plane_add(size=40.0, location=(0.0, 0.0, 0.0))
floor = bpy.context.object
floor.name = "地面"
fm = bpy.data.materials.new("地面")
fm.use_nodes = True
fb = fm.node_tree.nodes.get("Principled BSDF")
if fb is not None:
    fb.inputs["Base Color"].default_value = (0.55, 0.56, 0.58, 1.0)
    if "Roughness" in fb.inputs:
        fb.inputs["Roughness"].default_value = 0.95
floor.data.materials.append(fm)

# 白天空：相机射线看到纯白，其余光线只吃到 0.12 的补光（不然场景会被照平）
w = bpy.data.worlds.new("环境光")
bpy.context.scene.world = w
w.use_nodes = True
nt = w.node_tree
nt.nodes.clear()
out = nt.nodes.new("ShaderNodeOutputWorld")
mix = nt.nodes.new("ShaderNodeMixShader")
bg_amb = nt.nodes.new("ShaderNodeBackground")
bg_cam = nt.nodes.new("ShaderNodeBackground")
lp = nt.nodes.new("ShaderNodeLightPath")
bg_cam.inputs[0].default_value = (1.0, 1.0, 1.0, 1.0)
bg_cam.inputs[1].default_value = 1.0
bg_amb.inputs[0].default_value = (0.86, 0.90, 1.0, 1.0)
bg_amb.inputs[1].default_value = 0.12
nt.links.new(lp.outputs["Is Camera Ray"], mix.inputs[0])
nt.links.new(bg_amb.outputs[0], mix.inputs[1])
nt.links.new(bg_cam.outputs[0], mix.inputs[2])
nt.links.new(mix.outputs[0], out.inputs[0])

li = bpy.data.lights.new("太阳", "SUN")
li.energy = 1.05
li.color = (1.0, 0.975, 0.925)
if hasattr(li, "angle"):
    li.angle = math.radians(2.2)
sun = bpy.data.objects.new("太阳", li)
bpy.context.collection.objects.link(sun)
sun.rotation_euler = (math.radians(37.0), 0.0, math.radians(-38.0))


def add_camera(loc, target, lens):
    cam = bpy.data.cameras.new("相机")
    cam.lens = lens
    cam.clip_start = 0.02
    cam.clip_end = 2000.0
    ob = bpy.data.objects.new("相机", cam)
    bpy.context.collection.objects.link(ob)
    ob.location = Vector(loc)
    ob.rotation_euler = (Vector(target) - Vector(loc)).normalized() \
        .to_track_quat("-Z", "Y").to_euler()
    return ob


sc = bpy.context.scene
sc.render.engine = "BLENDER_EEVEE"
sc.render.resolution_x = 1400
sc.render.resolution_y = 900
sc.render.film_transparent = False
sc.render.image_settings.file_format = "PNG"
sc.render.image_settings.color_mode = "RGB"
try:
    sc.eevee.taa_render_samples = 64
except Exception as e:
    print("[gen] eevee samples 跳过:", e)
try:
    sc.view_settings.view_transform = "Standard"
except Exception as e:
    print("[gen] view_transform 跳过:", e)


def shot(cam_loc, cam_target, lens, path):
    ob = add_camera(cam_loc, cam_target, lens)
    sc.camera = ob
    sc.render.filepath = os.path.join(OUT_DIR, path)
    bpy.ops.render.render(write_still=True)
    print("[gen] 渲染 ->", path)
    bpy.data.objects.remove(ob, do_unlink=True)


def show_parts(on):
    for nm, piv in PARTS:
        parts[nm].hide_render = not on
    player.hide_render = on


def place_parts(pose):
    """把 8 个关节件按枢轴摆到位；pose[件] = (dx,dy,dz, rx,ry,rz)（弧度）。
    引擎里是 hw.push 的父子链，子件跟着父件走；Blender 这边没有父子关系，
    所以小腿要手动补：膝盖位置 = 髋关节 + Rx(大腿角)·(膝盖-髋关节)，角度也叠加。"""
    for nm, piv in PARTS:
        p = pose.get(nm, (0, 0, 0, 0, 0, 0))
        ob = parts[nm]
        ob.location = Vector(piv) + Vector(p[:3])
        ob.rotation_euler = (p[3], p[4], p[5])
    for side, hip, knee in (("L", HIPJ_L, KNEE_L), ("R", HIPJ_R, KNEE_R)):
        a = pose.get("part_thigh" + side, (0, 0, 0, 0, 0, 0))[3]
        b = pose.get("part_shin" + side, (0, 0, 0, 0, 0, 0))
        v = knee - hip
        c, s = math.cos(a), math.sin(a)
        vy, vz = v.y * c - v.z * s, v.y * s + v.z * c
        shin = parts["part_shin" + side]
        shin.location = hip + Vector((v.x, vy, vz)) + Vector(b[:3])
        shin.rotation_euler = (b[3] + a, b[4], b[5])


# ① 枪单独
gun.location = Vector((0.0, -0.10, 0.90))
player.hide_render = True
show_parts(False)
shot((1.55, -1.45, 1.72), (0.0, 0.24, 0.86), 45.0, "preview_gun.png")

# ② 整身 3/4 前视
player.hide_render = False
gun.hide_render = True
shot((2.30, 3.45, 1.60), (0.0, 0.05, 0.92), 35.0, "preview_player.png")

# ③ 整身 + 枪在手上
gun.hide_render = False
gun.location = Vector((HAND.x, HAND.y, HAND.z))
shot((2.30, 3.45, 1.60), (0.0, 0.05, 0.92), 35.0, "preview_held.png")
shot((4.30, 0.55, 1.42), (0.0, 0.32, 1.16), 50.0, "preview_held_side.png")

# ④ 关节件零姿势摆回去 —— 应该和整身一模一样（枢轴对不对，一眼就看出来）
player.hide_render = True
gun.hide_render = True
place_parts({})
show_parts(True)
shot((2.30, 3.45, 1.60), (0.0, 0.05, 0.92), 35.0, "preview_parts.png")

# ⑤ 走路姿势：左腿前摆、右腿后摆屈膝、左臂反甩、躯干轻微上下
#    Blender 里"往前摆/往后摆"是绕 X 轴转（角色右手边 = +X）
WALK = {
    "part_torso": (0.0, 0.0, 0.03, 0.0, 0.0, 0.0),
    "part_armL": (0.0, 0.0, 0.0, -0.46, 0.0, 0.0),
    "part_thighL": (0.0, 0.0, 0.0, 0.42, 0.0, 0.0),
    "part_shinL": (0.0, 0.0, 0.0, -0.20, 0.0, 0.0),
    "part_thighR": (0.0, 0.0, 0.0, -0.36, 0.0, 0.0),
    "part_shinR": (0.0, 0.0, 0.0, -0.66, 0.0, 0.0),
}
place_parts(WALK)
gun.location = Vector((HAND.x, HAND.y, HAND.z))
gun.hide_render = False
shot((2.30, 3.45, 1.60), (0.0, 0.05, 0.92), 35.0, "preview_walk.png")

print("[gen] DONE")
