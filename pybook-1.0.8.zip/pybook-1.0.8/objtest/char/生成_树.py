# -*- coding: utf-8 -*-
"""生成三种针叶树的 Wavefront .obj（+ .mtl），给 PYbook 的 hw.obj 当"森林"用。

    blender -b --factory-startup --python 生成_树.py -- <输出目录>

三种变体（都是"树干 + 几层无底锥"的针叶树，低模风格）：
    tree_a.obj  高 15.5 m  冠幅半径 3.10   密林高松
    tree_b.obj  高 12.0 m  冠幅半径 2.60   常规
    tree_c.obj  高  8.5 m  冠幅半径 3.40   矮胖灌木松

建模约定（跟枪一致）：
  · **原点在树根**（地面高度处），树往上长 → pybk 里 push 到"地面 y"就行
  · 树干 6 面棱柱不带底盖（底盖埋在地里看不见）；每层树冠锥**带底盖**，
    不然从下往上看会因为背面剔除而"透"过去，露出一堆洞
  · 每棵面数：树干 12 + 4 层×(8 侧 + 8 底) = 76 面

⚠ 导出后**不要改名**：Blender 会把 mtllib 写成跟 obj 同名的 .mtl，
  一改名 mtllib 就对不上、引擎加载不到材质，整棵树会变成默认灰白
  （枪就是这么中招的，见 生成_枪.py 的警告）。
"""
import math
import os
import sys

import bpy
from mathutils import Vector

OUT_DIR = sys.argv[sys.argv.index("--") + 1] if "--" in sys.argv else "."
os.makedirs(OUT_DIR, exist_ok=True)

# ---------------------------------------------------------------- 材质

# Kd 直接写"想在引擎里看到的颜色"（hw 的 lambert 对着光的面系数约 1.0）
# Kd 直接写"想在引擎里看到的颜色"（hw 的 lambert 对着光的面系数约 1.0）。
# ⚠ 别写太暗：第一版针叶只有 0.07~0.13，跟草地 0.42/0.575/0.24 一比，
#   稍微远一点的林子就糊成一条黑带，中景完全没有"森林"的感觉。
TREE_MATS = [
    ("树皮", (0.300, 0.205, 0.125)),
    ("针叶下", (0.135, 0.340, 0.160)),
    ("针叶上", (0.200, 0.460, 0.225)),
]
M_BARK, M_LOW, M_TOP = 0, 1, 2


def clear_scene():
    bpy.ops.wm.read_factory_settings(use_empty=True)


def make_material(name, kd):
    m = bpy.data.materials.new(name)
    m.use_nodes = True
    bsdf = m.node_tree.nodes.get("Principled BSDF")
    if bsdf is not None:
        bsdf.inputs["Base Color"].default_value = (kd[0], kd[1], kd[2], 1.0)
        if "Roughness" in bsdf.inputs:
            bsdf.inputs["Roughness"].default_value = 0.95
        if "Specular IOR Level" in bsdf.inputs:
            bsdf.inputs["Specular IOR Level"].default_value = 0.04
        elif "Specular" in bsdf.inputs:
            bsdf.inputs["Specular"].default_value = 0.04
    m.diffuse_color = (kd[0], kd[1], kd[2], 1.0)
    m.specular_intensity = 0.04
    m.roughness = 0.95
    return m


# ---------------------------------------------------------------- 几何


def build_tree(name, height, trunk_h, r0, r1, cones, trunk_seg=6, cone_seg=8):
    """cones = [(底部z, 底部半径, 顶部z), ...]，锥尖在 (0,0,顶部z)。

    顶点/面全部手搓（不用 bmesh）：面数完全可控，也省得依赖建模算子的行为。
    """
    verts = []
    faces = []
    mats = []

    # ---- 树干：6 面棱柱，不带底盖 ----
    ring0, ring1 = [], []
    for i in range(trunk_seg):
        a = 2.0 * math.pi * i / trunk_seg
        c, s = math.cos(a), math.sin(a)
        ring0.append(len(verts))
        verts.append((c * r0, s * r0, 0.0))
    for i in range(trunk_seg):
        a = 2.0 * math.pi * i / trunk_seg
        c, s = math.cos(a), math.sin(a)
        ring1.append(len(verts))
        verts.append((c * r1, s * r1, trunk_h))
    for i in range(trunk_seg):
        j = (i + 1) % trunk_seg
        faces.append((ring0[i], ring0[j], ring1[j], ring1[i]))
        mats.append(M_BARK)

    # ---- 树冠：每层一个锥（侧面 + 底盖）----
    for k, (z0, rad, z1) in enumerate(cones):
        mat = M_TOP if k == len(cones) - 1 else M_LOW
        base = []
        for i in range(cone_seg):
            a = 2.0 * math.pi * i / cone_seg
            base.append(len(verts))
            verts.append((math.cos(a) * rad, math.sin(a) * rad, z0))
        tip = len(verts)
        verts.append((0.0, 0.0, z1))
        for i in range(cone_seg):
            j = (i + 1) % cone_seg
            faces.append((base[i], base[j], tip))       # 侧面
            mats.append(mat)
            faces.append((base[j], base[i], tip))       # 侧面（反向，双面省得不透）
            mats.append(mat)
        # 底盖：扇形拼三角，法线朝下
        for i in range(1, cone_seg - 1):
            faces.append((base[0], base[i + 1], base[i]))
            mats.append(mat)

    me = bpy.data.meshes.new(name)
    me.from_pydata(verts, [], faces)
    me.validate()
    for m in MATS:
        me.materials.append(m)
    for p, mi in zip(me.polygons, mats):
        p.material_index = mi
        p.use_smooth = True
    ob = bpy.data.objects.new(name, me)
    bpy.context.collection.objects.link(ob)
    return ob


# ---------------------------------------------------------------- 导出

clear_scene()
MATS = [make_material(n, kd) for n, kd in TREE_MATS]


def export(ob, filename):
    for o in bpy.context.scene.objects:
        o.select_set(False)
    ob.select_set(True)
    bpy.context.view_layer.objects.active = ob
    path = os.path.join(OUT_DIR, filename)
    bpy.ops.wm.obj_export(
        filepath=path,
        export_selected_objects=True,
        export_uv=True, export_normals=True, export_materials=True,
        export_triangulated_mesh=True,
        apply_modifiers=True, apply_transform=True,
        forward_axis="NEGATIVE_Z", up_axis="Y",
        export_colors=False, export_pbr_extensions=False, path_mode="AUTO",
    )
    nv = nf = nmat = 0
    mn = [1e30] * 3
    mx = [-1e30] * 3
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        for ln in f:
            if ln.startswith("v "):
                nv += 1
                q = [float(t) for t in ln.split()[1:4]]
                for k in range(3):
                    mn[k] = min(mn[k], q[k])
                    mx[k] = max(mx[k], q[k])
            elif ln.startswith("f "):
                nf += 1
            elif ln.startswith("usemtl "):
                nmat += 1
    mtl = path[:-4] + ".mtl"
    have_mtl = os.path.exists(mtl)
    # obj 里 y 是上下（导出器已转成 Y-up）
    print("[gen] %-12s v=%-4d f=%-4d usemtl=%d  %6d 字节  mtl=%s"
          % (filename, nv, nf, nmat, os.path.getsize(path), "有" if have_mtl else "**缺**"))
    print("        hw 里：高 %.2f   最大半径 %.2f   y %.3f~%.3f"
          % (mx[1] - mn[1],
             max(max(mx[0], -mn[0]), max(mx[2], -mn[2])),
             mn[1], mx[1]))
    return nf


# 三种变体：(名字, 总高, 树干高, 树干底半径, 树干顶半径, 树冠层)
VARIANTS = [
    ("tree_a.obj", 15.5, 4.20, 0.42, 0.16,
     [(2.60, 3.10, 7.60), (4.60, 2.60, 10.20), (6.60, 2.10, 12.60), (8.60, 1.50, 15.50)]),
    ("tree_b.obj", 12.0, 3.30, 0.38, 0.15,
     [(2.00, 2.60, 6.40), (3.70, 2.10, 8.90), (5.40, 1.45, 12.00)]),
    ("tree_c.obj", 8.5, 2.30, 0.34, 0.14,
     [(1.30, 3.40, 4.60), (2.60, 2.60, 6.40), (4.00, 1.60, 8.50)]),
]

total_faces = 0
for i, (fn, h, th, r0, r1, cones) in enumerate(VARIANTS):
    ob = build_tree("树_%s" % fn[:6], h, th, r0, r1, cones)
    total_faces += export(ob, fn)

print("[gen] 三种树合计 %d 面；按 480 棵算约 %d 面" % (total_faces, total_faces // 3 * 480))

# 顺带渲染一张三棵并排的预览（方便肉眼检查比例）
bpy.ops.mesh.primitive_plane_add(size=60.0, location=(0.0, 0.0, 0.0))
floor = bpy.context.object
fm = make_material("地面", (0.330, 0.550, 0.215))
floor.data.materials.append(fm)

w = bpy.data.worlds.new("环境光")
bpy.context.scene.world = w
w.use_nodes = True
nt = w.node_tree
nt.nodes.clear()
outn = nt.nodes.new("ShaderNodeOutputWorld")
bg = nt.nodes.new("ShaderNodeBackground")
bg.inputs[0].default_value = (0.94, 0.96, 1.0, 1.0)
bg.inputs[1].default_value = 1.05
nt.links.new(bg.outputs[0], outn.inputs[0])

sun = bpy.data.lights.new("太阳", type="SUN")
sun.energy = 3.0
sun.angle = 0.10
sob = bpy.data.objects.new("太阳", sun)
bpy.context.collection.objects.link(sob)
sob.rotation_euler = (math.radians(48.0), 0.0, math.radians(35.0))

cam = bpy.data.cameras.new("相机")
cam.lens = 42.0
cob = bpy.data.objects.new("相机", cam)
bpy.context.collection.objects.link(cob)
bpy.context.scene.camera = cob
cob.location = Vector((26.0, -30.0, 15.0))
d = Vector((0.0, 0.0, 7.0)) - cob.location
cob.rotation_euler = d.to_track_quat("-Z", "Y").to_euler()

sc = bpy.context.scene
sc.render.engine = "BLENDER_EEVEE_NEXT" if "BLENDER_EEVEE_NEXT" in \
    [i.identifier for i in bpy.types.RenderSettings.bl_rna.properties["engine"].enum_items] \
    else "BLENDER_EEVEE"
sc.render.resolution_x = 900
sc.render.resolution_y = 620
sc.render.filepath = os.path.join(OUT_DIR, "tree_preview.png")
sc.render.image_settings.file_format = "PNG"
bpy.ops.render.render(write_still=True)
print("[gen] 预览 ->", sc.render.filepath)
print("[gen] DONE")
