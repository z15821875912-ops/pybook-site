#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Smokeroor runner —— 期望驱动的安全体检，**不改源码就能应付新错误**。

核心设计：
  · **期望即声明**：每个用例一个 `<用例>.expect`（退出码 + 关键字）。
    新错误来了 → 加一个 .expect 就行，**不用碰 Python/C 一行**。
  · **自动学习**（`--learn`）：第一次跑就生成 .expect，之后全靠比对。
  · **打回重做**：不符 → 自动重试 N 次（抓偶发）→ 还不符 → 红 + 明确 diff。
  · **模糊匹配**：关键字去空白、可选忽略大小写、支持 `re:` 前缀写正则。
    报错文案微调也认得出来，不会因为措辞变化误报。

用法：
    python smokeroor.py                    # 跑全部
    python smokeroor.py --learn            # 学习模式：自动生成 .expect
    python smokeroor.py --filter 悬垂       # 只跑匹配的
    python smokeroor.py --retry 3          # 失败重试 3 次（默认 1）
    python smokeroor.py --strict           # 关键字严格区分大小写
    python smokeroor.py --baseline         # 存基线
    python smokeroor.py --json             # 机器可读

.expect 格式（UTF-8）：
    第 1 行：期望退出码（整数）
    第 2 行起：期望出现的关键字，**任一行命中即算过**；
              以 `re:` 开头的行按正则匹配；
              行首 `!` 表示"不应出现"（反向断言）。

退出码：0 全过 / 1 有失败 / 2 runner 自身出错。
"""
import io
import json
import os
import re
import subprocess
import sys
import time

ROOT = os.path.dirname(os.path.abspath(__file__))
SMOKE_DIR = os.path.join(ROOT, 'tests', 'smoke')
PYTHON = sys.executable
BASELINE = os.path.join(ROOT, 'smokeroor_baseline.txt')
ERRORS_DB = os.path.join(ROOT, 'smokeroor_errors.json')   # 错误指纹库（本地）

GREEN = '\033[32m'
RED = '\033[31m'
YELLOW = '\033[33m'
DIM = '\033[2m'
BOLD = '\033[1m'
OFF = '\033[0m'


def _c(s, col):
    return col + s + OFF if sys.stdout.isatty() else s


def _norm(s):
    """匹配用的规范化：折叠空白。"""
    return re.sub(r'\s+', ' ', s or '').strip()


def run_case(pybk_path, timeout=90):
    try:
        r = subprocess.run([PYTHON, os.path.join(ROOT, 'pybk_main.py'), pybk_path],
                           capture_output=True, text=True, encoding='utf-8',
                           errors='replace', timeout=timeout, cwd=ROOT)
        return r.returncode, (r.stdout or '') + (r.stderr or '')
    except subprocess.TimeoutExpired:
        return -1, '(超时)'


# ================= 错误指纹库 =================
# 思路：犯错后把"错误指纹"记进本地库（smokeroor_errors.json）。
# 下次同样的错 → 查库秒认（0 比对）；新错 → 比对/学习后入库。
# 局限：只能认"见过的"，新错误第一次还是要比对；文案大幅改写可能认不出。

def fingerprint(text):
    """错误指纹：去行号、去具体标识符/数字、折叠空白。
    这样「第 4 行：字典里没有这个键」和「第 99 行：字典里没有这个键」是同一指纹。"""
    t = text or ''
    t = re.sub(r'第\s*\d+\s*行', '第N行', t)          # 行号
    t = re.sub(r"'[^']*'", "'X'", t)                  # 引号里的标识符
    t = re.sub(r'"[^"]*"', '"X"', t)
    t = re.sub(r'\b\d+\b', 'N', t)                    # 数字
    t = re.sub(r'\s+', ' ', t).strip()
    return t


def classify(fp):
    """粗分类：给指纹贴个标签，方便统计和清理。"""
    f = fp or ''
    if '溢出' in f or '除以零' in f or '除零' in f:
        return '算术'
    if '越界' in f:
        return '边界'
    if '已删除' in f or '悬垂' in f:
        return '删除'
    if '锁定' in f:
        return '锁'
    if '类型' in f or '需要' in f or '不可' in f:
        return '类型'
    if '字典' in f or '键' in f:
        return '字典'
    if '内存' in f:
        return '内存'
    if '属性' in f:
        return '属性'
    return '其他'


def load_errors():
    if not os.path.isfile(ERRORS_DB):
        return {}
    try:
        with io.open(ERRORS_DB, encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return {}


def save_errors(db):
    with io.open(ERRORS_DB, 'w', encoding='utf-8') as f:
        json.dump(db, f, ensure_ascii=False, indent=1, sort_keys=True)


def record_error(db, fp, raw, category, outcome):
    """记录/更新一条错误指纹。"""
    import datetime
    now = datetime.datetime.now().strftime('%Y-%m-%d %H:%M')
    if fp in db:
        db[fp]['次数'] = db[fp].get('次数', 0) + 1
        db[fp]['最近'] = now
    else:
        db[fp] = {'次数': 1, '首见': now, '最近': now,
                  '类别': category, '原文案': (raw or '')[:120], '处理': outcome}
    return db[fp]


def lookup_error(db, fp):
    """查指纹库：命中返回记录（秒认），未命中返回 None。"""
    return db.get(fp)


def load_expect(pybk_path):
    """读 .expect → (期望退出码, 正向关键字表, 反向关键字表)。"""
    p = pybk_path + '.expect'
    if not os.path.isfile(p):
        return None, [], []
    pos, neg = [], []
    rc = None
    with io.open(p, encoding='utf-8') as f:
        for line in f:
            line = line.rstrip('\n')
            if not line.strip():
                continue
            if rc is None:
                try:
                    rc = int(line.strip())
                    continue
                except ValueError:
                    pass
            if line.startswith('!'):
                neg.append(line[1:].strip())
            else:
                pos.append(line.strip())
    return rc, pos, neg


def match_keys(out, pos, neg, strict=False):
    """模糊匹配：任一正向命中 + 没有反向命中 = 通过。返回 (ok, 原因)。"""
    hay = out if strict else _norm(out).lower()
    for k in pos:
        pat = k[3:] if k.startswith('re:') else (_norm(k) if not strict else k)
        if k.startswith('re:'):
            try:
                if re.search(pat, out, 0 if strict else re.IGNORECASE):
                    break
            except re.error:
                if pat in out:
                    break
        else:
            needle = pat if strict else pat.lower()
            if needle in hay:
                break
    else:
        return False, '没看到期望关键字：%s' % ' / '.join(pos) if pos else '（无正向关键字）'
    for k in neg:
        pat = k[3:] if k.startswith('re:') else (_norm(k) if not strict else k)
        if k.startswith('re:'):
            try:
                if re.search(pat, out, 0 if strict else re.IGNORECASE):
                    return False, '出现了不该有的：%s' % k
            except re.error:
                pass
        else:
            needle = pat if strict else pat.lower()
            if needle in hay:
                return False, '出现了不该有的：%s' % k
    return True, ''


def learn_expect(pybk_path, rc, out):
    """学习模式：把这次的结果写成 .expect（第一次跑用，之后比对）。"""
    # 取输出里的报错行做关键字（挑最有辨识度的一行）
    lines = [l.strip() for l in out.splitlines() if l.strip()]
    key = ''
    for l in lines:
        if '错误' in l or 'error' in l.lower() or 'Error' in l:
            key = l
            break
    if not key and lines:
        key = lines[-1]
    key = _norm(key)[:60]
    with io.open(pybk_path + '.expect', 'w', encoding='utf-8') as f:
        f.write('%d\n' % rc)
        if key:
            f.write(key + '\n')
    return key


def main():
    args = sys.argv[1:]
    flt, retry, strict, as_json, do_baseline, do_learn = None, 1, False, False, False, False
    i = 0
    while i < len(args):
        a = args[i]
        if a == '--filter' and i + 1 < len(args):
            flt = args[i + 1]; i += 2
        elif a == '--retry' and i + 1 < len(args):
            try: retry = max(1, int(args[i + 1]))
            except ValueError: pass
            i += 2
        elif a == '--strict':
            strict = True; i += 1
        elif a == '--json':
            as_json = True; i += 1
        elif a == '--baseline':
            do_baseline = True; i += 1
        elif a == '--learn':
            do_learn = True; i += 1
        else:
            i += 1

    if not os.path.isdir(SMOKE_DIR):
        print(_c('✗ 找不到用例目录 ' + SMOKE_DIR, RED))
        return 2

    cases = sorted(f for f in os.listdir(SMOKE_DIR) if f.endswith('.pybk'))
    if flt:
        keep = []
        for c in cases:
            head = io.open(os.path.join(SMOKE_DIR, c), encoding='utf-8').read(400).split('\n', 1)[0]
            if flt in c or flt in head:
                keep.append(c)
        cases = keep
    if not cases:
        print(_c('没有匹配的用例', YELLOW))
        return 2

    mode = '学习（自动生成 .expect）' if do_learn else '比对'
    print(_c('Smokeroor：%s · %d 个用例 · 重试 %d 次%s'
             % (mode, len(cases), retry, ' · 严格' if strict else ''), DIM))
    print()

    results = []
    n_pass = 0
    errdb = load_errors()          # 错误指纹库（本次会读写）
    t0 = time.time()
    for c in cases:
        path = os.path.join(SMOKE_DIR, c)
        head = io.open(path, encoding='utf-8').read(400).split('\n', 1)[0]
        title = head.lstrip('@ ').strip()

        # ---- 跑（带重试：抓偶发崩溃）----
        rc, out = run_case(path)
        tries = 1
        exp_rc, pos, neg = load_expect(path)
        if not do_learn:
            ok, why = (True, '') if exp_rc is None and not pos and not neg else match_keys(out, pos, neg, strict)
            if exp_rc is not None and rc != exp_rc:
                ok, why = False, '退出码 %d ≠ 期望 %d' % (rc, exp_rc)
            while not ok and tries < retry:
                rc, out = run_case(path)
                tries += 1
                ok, why = (True, '') if exp_rc is None and not pos and not neg else match_keys(out, pos, neg, strict)
                if exp_rc is not None and rc != exp_rc:
                    ok, why = False, '退出码 %d ≠ 期望 %d' % (rc, exp_rc)
        else:
            key = learn_expect(path, rc, out)
            ok, why = True, ''
            pos = [key] if key else []

        # ---- 错误指纹库：见过的错秒认，新的记下来 ----
        known = None
        if out.strip():
            fp = fingerprint(out)
            known = lookup_error(errdb, fp)
            if known:
                known['次数'] = known.get('次数', 0) + 1   # 命中也计一次
            else:
                raw = next((l.strip() for l in out.splitlines()
                            if '错误' in l or 'error' in l.lower()), '')
                record_error(errdb, fp, raw, classify(fp),
                             '报错退出（退出码 %d）' % rc)

        results.append({'case': c, 'title': title, 'ok': ok, 'rc': rc, 'why': why,
                        'tries': tries, 'known': bool(known),
                        'out_tail': _norm(out)[-160:]})
        if ok:
            n_pass += 1
            mark = _c('✓', GREEN)
            extra = '' if tries == 1 else _c(' (重试 %d)' % tries, YELLOW)
            ktag = _c(' [已知]' if known else '', YELLOW) if out.strip() else ''
            print(mark + ' %-32s %s%s%s' % (c, _c(title, DIM), extra, ktag))
            if do_learn:
                print('    ' + _c('已学：%d / %s' % (rc, pos[0] if pos else '(无关键字)'), DIM))
        else:
            print(_c('✗', RED) + ' %-32s %s' % (c, _c(title, DIM)))
            print('    ' + _c('· ' + why, RED))
            print('    ' + _c('· 期望退出码 %s / 关键字 %s' % (exp_rc, ' | '.join(pos) or '(无)'), DIM))
            tail = [l for l in out.splitlines() if l.strip()][-1:]
            if tail:
                print('    ' + _c('· 实际输出尾：' + _norm(tail[0]), RED))

    dt = time.time() - t0
    print()
    if n_pass == len(cases):
        print(_c('Smokeroor：%s（%d/%d）· %.1f 秒' %
                 ('已学习' if do_learn else '全部通过', n_pass, len(cases), dt), GREEN))
    else:
        print(_c('Smokeroor：%s %d 项（通过 %d/%d）· %.1f 秒'
                 % ('学习失败' if do_learn else '打回', len(cases) - n_pass,
                    n_pass, len(cases), dt), RED))

    if do_baseline:
        with io.open(BASELINE, 'w', encoding='utf-8') as f:
            for r in results:
                f.write('%s\t%s\t%s\n' % (r['case'], 'PASS' if r['ok'] else 'FAIL', r['why']))
        print(_c('基线已存 ' + BASELINE, DIM))
    elif os.path.isfile(BASELINE):
        old = {}
        with io.open(BASELINE, encoding='utf-8') as f:
            for line in f:
                parts = line.rstrip('\n').split('\t')
                if len(parts) >= 2:
                    old[parts[0]] = parts[1]
        new_fail = [r['case'] for r in results if not r['ok'] and old.get(r['case']) != 'FAIL']
        gone = [k for k in old if k not in {r['case'] for r in results}]
        if new_fail:
            print(_c('⚠ 相比基线新增失败：%s' % ', '.join(new_fail), RED))
        if gone:
            print(_c('⚠ 基线里有但现在没跑：%s' % ', '.join(gone), YELLOW))
        if not new_fail and not gone:
            print(_c('与基线一致', DIM))

    if as_json:
        import json
        print(json.dumps({'pass': n_pass, 'total': len(cases), 'results': results},
                         ensure_ascii=False, indent=1))

    if errdb:
        save_errors(errdb)          # 指纹库落盘（下次秒认）

    return 0 if n_pass == len(cases) else 1


if __name__ == '__main__':
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        sys.exit(2)
