"""修柱状图的两处真缺陷：
   1) rt_plot_bar 把 cats 校验完就扔了，画在柱底的是柱子**数值**，
      和 图.轴 画的 x 刻度数字叠成一团（实测「3.6」被值 34 压成「34.6」）。
      改成：先用画布底色刷掉 x 刻度那条带子，再写类目标签。
   2) pt_setup_axis 把区间十等分，刻度值是 4.6 / 0.495 这种数，
      加上「好数」步长（1/2/2.5/5 x 10^k），但**不动用户给的值域** ——
      动值域等于偷偷改数据映射，用户按 图.轴 返回的绘图区验 图.折线 就对不上了。
"""
import os
import sys

sys.stdout.reconfigure(encoding='utf-8')

P = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'pybook_plot.c')
src = open(P, encoding='utf-8', newline='').read()

# 锚点必须恰好出现一次
PATCHES = [
    # ---- A1: PtCanvas 加 bg 字段 ----
    (
        "    int pl, pt_, pr, pb;      /* 绘图区像素矩形（含边） */\n"
        "    double xmin, xmax, ymin, ymax;\n"
        "} PtCanvas;",
        "    int pl, pt_, pr, pb;      /* 绘图区像素矩形（含边） */\n"
        "    double xmin, xmax, ymin, ymax;\n"
        "    PtColor bg;               /* 底色：图.柱状 刷掉 x 刻度带子时要用 */\n"
        "} PtCanvas;",
    ),
    # ---- A2: pt_new_canvas 初始化 bg ----
    (
        "        pt_cv[i].xmin = pt_cv[i].xmax = pt_cv[i].ymin = pt_cv[i].ymax = 0.0;\n"
        "        return rt_int(i + 1);",
        "        pt_cv[i].xmin = pt_cv[i].xmax = pt_cv[i].ymin = pt_cv[i].ymax = 0.0;\n"
        "        pt_cv[i].bg = bg;\n"
        "        return rt_int(i + 1);",
    ),
    # ---- B1: 加「好数」步长函数 ----
    (
        "/* 把值域和绘图区写进画布，再画网格/刻度/轴线/标注。",
        "/* 好数步长：把区间切成 1 / 2 / 2.5 / 5 x 10^k 的步长。\n"
        " * 十等分出来的刻度常常是 4.6、0.495 这种数，读着像乱码。\n"
        " * 注意只改**刻度**，不改用户给的值域 —— 值域一动，图.折线/散点 的\n"
        " * 映射就跟着变，用户拿 图.轴 返回的绘图区做的断言会全部失效。 */\n"
        "static double pt_nice_step(double range, int target)\n"
        "{\n"
        "    if (!(range > 0.0)) return 1.0;\n"
        "    if (target < 1) target = 1;\n"
        "    double raw = range / (double)target;\n"
        "    if (!(raw > 0.0)) return 1.0;\n"
        "    double mag = pow(10.0, floor(log10(raw)));\n"
        "    double f = raw / mag;                 /* 落在 1..10 */\n"
        "    double n = (f <= 1.0) ? 1.0 : (f <= 2.0) ? 2.0\n"
        "             : (f <= 2.5) ? 2.5 : (f <= 5.0) ? 5.0 : 10.0;\n"
        "    return n * mag;\n"
        "}\n"
        "\n"
        "/* 把值域和绘图区写进画布，再画网格/刻度/轴线/标注。",
    ),
    # ---- B2: y 轴刻度改好数步长 ----
    (
        "    for (int i = 0; i <= 10; i++) {\n"
        "        double v = ymin + (ymax - ymin) * i / 10.0;\n"
        "        int y = (int)floor(pt_map_y(c, v) + 0.5);\n"
        "        if (y >= ptop && y <= pb) {\n"
        "            if (has_zero && fabs(v) < (ymax - ymin) * 1e-9)\n"
        "                pt_line(c, pl, y, pr, y, ink, 1);\n"
        "            else\n"
        "                pt_line(c, pl, y, pr, y, grid, 1);\n"
        "            char buf[32];\n"
        "            pt_fmt_num(buf, sizeof buf, v, 4);\n"
        "            pt_text(c, pl - 8 - pt_text_w(buf, 1), y - 3, buf, ink, 1);\n"
        "        }\n"
        "    }",
        "    double ystep = pt_nice_step(ymax - ymin, 10);\n"
        "    for (int i = 0; i < 64; i++) {\n"
        "        double v = ceil(ymin / ystep - 1e-9) * ystep + (double)i * ystep;\n"
        "        if (v > ymax + ystep * 1e-9) break;\n"
        "        int y = (int)floor(pt_map_y(c, v) + 0.5);\n"
        "        if (y >= ptop && y <= pb) {\n"
        "            if (has_zero && fabs(v) < (ymax - ymin) * 1e-9)\n"
        "                pt_line(c, pl, y, pr, y, ink, 1);\n"
        "            else\n"
        "                pt_line(c, pl, y, pr, y, grid, 1);\n"
        "            char buf[32];\n"
        "            pt_fmt_num(buf, sizeof buf, v, 4);\n"
        "            pt_text(c, pl - 8 - pt_text_w(buf, 1), y - 3, buf, ink, 1);\n"
        "        }\n"
        "    }",
    ),
    # ---- B3: x 轴刻度改好数步长 ----
    (
        "    for (int i = 0; i <= 10; i++) {\n"
        "        double v = xmin + (xmax - xmin) * i / 10.0;\n"
        "        int x = (int)floor(pt_map_x(c, v) + 0.5);\n"
        "        if (x >= pl && x <= pr) {\n"
        "            pt_line(c, x, ptop, x, pb, grid, 1);\n"
        "            char buf[32];\n"
        "            pt_fmt_num(buf, sizeof buf, v, 4);\n"
        "            pt_text(c, x - pt_text_w(buf, 1) / 2, pb + 7, buf, ink, 1);\n"
        "        }\n"
        "    }",
        "    double xstep = pt_nice_step(xmax - xmin, 10);\n"
        "    for (int i = 0; i < 64; i++) {\n"
        "        double v = ceil(xmin / xstep - 1e-9) * xstep + (double)i * xstep;\n"
        "        if (v > xmax + xstep * 1e-9) break;\n"
        "        int x = (int)floor(pt_map_x(c, v) + 0.5);\n"
        "        if (x >= pl && x <= pr) {\n"
        "            pt_line(c, x, ptop, x, pb, grid, 1);\n"
        "            char buf[32];\n"
        "            pt_fmt_num(buf, sizeof buf, v, 4);\n"
        "            pt_text(c, x - pt_text_w(buf, 1) / 2, pb + 7, buf, ink, 1);\n"
        "        }\n"
        "    }",
    ),
    # ---- C: 柱底写类目，不是写数值 ----
    (
        "    double slot = (double)(c->pr - c->pl) / (double)m;\n"
        "    int bw = (int)(slot * 0.62);\n"
        "    if (bw < 1) bw = 1;\n"
        "    for (size_t i = 0; i < m; i++) {\n"
        "        double v = pt_num(VV->items[i], \"柱状的数值\");\n"
        "        int cx = (int)(c->pl + slot * (i + 0.5));\n"
        "        int x0 = cx - bw / 2, x1 = x0 + bw - 1;\n"
        "        int yv = (int)floor(pt_map_y(c, v) + 0.5);\n"
        "        PtColor col = use_one ? one : pt_palette[i % PT_NPALETTE];\n"
        "        if (yv < y0) pt_fill(c, x0, yv, x1, y0, col);\n"
        "        else         pt_fill(c, x0, y0, x1, yv, col);\n"
        "        /* 类目标在柱底 */\n"
        "        char buf[32];\n"
        "        pt_fmt_num(buf, sizeof buf, v, 3);\n"
        "        pt_text(c, cx - pt_text_w(buf, 1) / 2, c->pb + 7, buf, (PtColor){ 60, 60, 66, 255 }, 1);\n"
        "    }\n"
        "    return cv;",
        "    /* 类目占的是 x 轴刻度那条带子：先用底色刷掉 图.轴 画的数字刻度，\n"
        "     * 否则类目和刻度值会叠在同一行糊成一团（两边都在 pb+7）。 */\n"
        "    pt_fill(c, c->pl, c->pb + 1, c->pr, c->pb + 14, c->bg);\n"
        "    double slot = (double)(c->pr - c->pl) / (double)m;\n"
        "    int bw = (int)(slot * 0.62);\n"
        "    if (bw < 1) bw = 1;\n"
        "    for (size_t i = 0; i < m; i++) {\n"
        "        double v = pt_num(VV->items[i], \"柱状的数值\");\n"
        "        int cx = (int)(c->pl + slot * (i + 0.5));\n"
        "        int x0 = cx - bw / 2, x1 = x0 + bw - 1;\n"
        "        int yv = (int)floor(pt_map_y(c, v) + 0.5);\n"
        "        PtColor col = use_one ? one : pt_palette[i % PT_NPALETTE];\n"
        "        if (yv < y0) pt_fill(c, x0, yv, x1, y0, col);\n"
        "        else         pt_fill(c, x0, y0, x1, yv, col);\n"
        "        /* 柱底写**类目**（cats[i]），不是柱子高度 */\n"
        "        const char *lab = rt_str_of(CV->items[i]);\n"
        "        pt_text(c, cx - pt_text_w(lab, 1) / 2, c->pb + 7, lab,\n"
        "                (PtColor){ 60, 60, 66, 255 }, 1);\n"
        "    }\n"
        "    return cv;",
    ),
]

ok = True
for i, (old, new) in enumerate(PATCHES, 1):
    n = src.count(old)
    print('锚点 %d 命中 %d 次 %s' % (i, n, 'OK' if n == 1 else '← 必须恰好 1 次'))
    if n != 1:
        ok = False
        continue
    src = src.replace(old, new)

if not ok:
    print('\n锚点不全等于 1，未写盘')
    raise SystemExit(1)

tmp = P + '.tmpfix'
open(tmp, 'w', encoding='utf-8', newline='').write(src)
os.replace(tmp, P)
print('\n已写盘：%d 处' % len(PATCHES))
