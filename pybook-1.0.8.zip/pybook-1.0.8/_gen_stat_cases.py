# -*- coding: utf-8 -*-
"""_gen_stat_cases.py — 把随机/统计的用例编码进 tests/cases.py

数值已实证：
  - rd.float 的分辨率 32693 -> 200000 个不同取值（200000 次采样），上限 0.9999987
  - 9 个分布的实测 mean/std 与理论值一致（20000 次采样；lognormal 因四阶矩极大，
    用 200000 次单独复核：均值 1.65302/理论 1.6487，std 2.16570/2.1612）
  - 8 个统计函数与 numpy 逐项一致（_st_verify.py，17 项 0 不合格）
"""
import io, os, subprocess, sys

PY = sys.executable
HERE = os.path.dirname(os.path.abspath(__file__))

SPEC = [
    ('_st_t1.pybk',  'T20_rd_seed_ok', 'normal',
     '随机源统一后的三件事：rd.seed 可复现、rd.* 与 mp.rand_* 同源、'
     'rd.float 的分辨率从 32693 个不同取值变成 200000 个（满 53 位）'),
    ('_st_cmp.pybk', 'T20_stat_ok',   'normal',
     'median/mode/quantile/percentile 逐项对拍 numpy（线性插值、并列取最小众数）'),
    ('_st_cmp2.pybk', 'T20_stat2_ok', 'normal',
     'cumsum/diff/cov/corr 对拍 numpy（cov 用样本协方差分母 n-1；'
     'corr 遇到常数变量报「无定义」而不是静默给 0）'),
]

ERR = [
    ('_st_e1_corr_const.pybk', 'T20_corr_const_err',
     'corr 的一个变量是常数 → 报错「无定义」，不静默返回 0',
     'mp.corr：某个变量是常数，相关系数无定义'),
    ('_st_e2_len.pybk', 'T20_stat_len_err',
     'cov/corr 两个列表长度不同 → 报错并把两个长度都算给你看',
     'mp.cov：两个列表长度要相同'),
    ('_st_e3_quantile.pybk', 'T20_quantile_range_err',
     'quantile 的 q 不在 [0,1] → 报错并给出合法区间',
     'mp.quantile 的 q 要在 [0,1]'),
    ('_st_e4_binom.pybk', 'T20_binom_range_err',
     '二项分布 p 越界 → 报错（核心层哨兵被绑定层翻译成三段式）',
     'mp.rand_binom 的参数不合法'),
    ('_st_e5_gamma.pybk', 'T20_gamma_range_err',
     '伽马分布形状为负 → 报错',
     'mp.rand_gamma 的参数不合法'),
    ('_st_e6_logistic.pybk', 'T20_logistic_range_err',
     'logistic 尺度为 0 → 报错。注意 logistic 是唯一可以为负的分布，'
     '所以绑定层不能靠「返回值<0」反推参数非法，必须显式校验',
     'mp.rand_logistic 的参数不合法'),
]


def run(src):
    env = {k: v for k, v in os.environ.items() if k != 'COLUMNS'}
    env['PYBOOK_NO_CACHE'] = '1'
    p = subprocess.run([PY, 'pybk_main.py', src], env=env, cwd=HERE,
                       capture_output=True, text=True, encoding='utf-8',
                       errors='replace', timeout=300)
    return (p.stdout.replace('\r\n', '\n'), p.stderr.replace('\r\n', '\n'), p.returncode)


lines = []
for srcf, cid, kind, expect in SPEC:
    out, err, rc = run(srcf)
    if rc != 0:
        raise SystemExit('用例 %s 退出码 %d\n%s' % (cid, rc, err))
    src = io.open(srcf, encoding='utf-8', newline='').read()
    lines.append('case(**{%s})' % (
        "'id': %s, 'kind': 'normal', 'src': %s, 'out': %s, 'err': %s, "
        "'err_contains': [], 'expect': %s"
        % (repr(cid), repr(src), repr(out), repr(err), repr(expect))))

for srcf, cid, expect, sub in ERR:
    out, err, rc = run(srcf)
    src = io.open(srcf, encoding='utf-8', newline='').read()
    lines.append('# %s 实际 stderr 首行: %s' % (cid, repr(err.split('\n')[0])))
    lines.append('case(**{%s})' % (
        "'id': %s, 'kind': 'error', 'src': %s, 'out': %s, 'exit': %d, "
        "'err_contains': [%s], 'expect': %s"
        % (repr(cid), repr(src), repr(out), rc,
           ', '.join(repr(s) for s in [sub, '程序异常退出，退出码 1']),
           repr(expect))))

block = ('\n# ── 随机源统一 + 分布补齐 + 统计补齐 ──\n'
         '# 注：rd.float 的分辨率那条断言在 T20_rd_seed_ok 里 ——\n'
         '#   修之前 200000 次采样只有 32693 个不同取值（MinGW 的 RAND_MAX=32767），\n'
         '#   修之后是 200000 个，即满 53 位有效精度。\n'
         + '\n'.join(lines) + '\n')

with io.open('tests/cases.py', 'a', encoding='utf-8', newline='\n') as f:
    f.write(block)
print('已追加 %d 个用例' % len(SPEC) + len(ERR) if False else '已追加 %d 个用例' % (len(SPEC) + len(ERR)))
