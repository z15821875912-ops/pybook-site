#ifndef PYBOOK_SYM_H
#define PYBOOK_SYM_H

/* ================= pybook_sym：符号数学（表达式树） =================
 *
 * 设计（与 mathplus 同构：核心层零运行时依赖，绑定层按需编译）：
 *
 *   核心层  纯 C：字符串 -> 表达式树 -> 求导 / 化简 / 展开 / 积分 / 求值。
 *            不碰 PYbook 运行时、不碰内存分配策略之外的任何东西
 *            （内部用一次性 arena，调用结束整体放还）。
 *   绑定层  rt_lib_sym_*：把 PYbook 的 Value 字符串 ↔ C 字符串互转，
 *            挂进前端 sym. 前缀。仅当 PYBOOK_RT_H 已定义（或 -DSYM_RT_BINDING）
 *            时编译。
 *
 * 语言侧形状（v1，全部「字符串进、字符串出」，不引入新值类型）：
 *   sym.解析("x^2*sin(x)")            -> 规范化漂亮打印（同时校验语法）
 *   sym.求导("x^2*sin(x)", "x")       -> "2*x*sin(x) + x^2*cos(x)"
 *   sym.积分("x*exp(x)", "x")         -> "x*exp(x) - exp(x)"（不会积返回 ""）
 *   sym.化简("x + x")                 -> "2*x"
 *   sym.展开("(x+1)^2")               -> "x^2 + 2*x + 1"
 *   sym.求值("x^2 + 1", "x=3")        -> 10
 *   sym.变量("x*y + sin(z)")          -> ["x", "y", "z"]
 *   sym.替换("x^2", "x", "y+1")       -> "(y + 1)^2"
 *   sym.解方程组("x+y=3;x-y=1", "x,y") -> "x = 2, y = 1"（精确有理数）
 *   sym.极限("sin(x)/x", "x", "0")       -> 1（0/0 走洛必达；点可写 inf）
 *   sym.级数("sin(x)", "x", "0", 5)      -> "x - 1/6*x^3 + 1/120*x^5 + O(x^6)"
 *   sym.相等(a, b)                    -> true/false（各自化简后结构比对）
 *
 * 约定：
 *   - 公式串用 ASCII 运算符 + - * / ^ 与括号；变量名可中文（跟语言习惯一致）；
 *     另认 π 与 √ 两个符号（π=pi，√ 只作用于紧随的原子）。
 *   - 函数名全英文：sin cos tan asin acos atan sinh cosh tanh exp log(=ln) sqrt abs；
 *     常量 pi / e。
 *   - 所有返回字符串都是 malloc 出来的，调用方负责 free。
 *   - 出错时核心函数返回 NULL（或 0），错误文案写进 errbuf（可空）。
 */

#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

/* ---- 核心层（无条件声明） ---- */

char *sym_core_parse(const char *expr, char *err, size_t errsz);
char *sym_core_diff(const char *expr, const char *var, char *err, size_t errsz);
char *sym_core_integrate(const char *expr, const char *var, char *err, size_t errsz);
char *sym_core_simplify(const char *expr, char *err, size_t errsz);
char *sym_core_expand(const char *expr, char *err, size_t errsz);
/* 求值：成功返回 1（*out 写入结果），失败返回 0（err 有文案） */
int    sym_core_eval(const char *expr, const char *bindings, double *out,
                     char *err, size_t errsz);
/* 变量表：返回逗号分隔的名字串（无变量返回 ""） */
char  *sym_core_vars(const char *expr, char *err, size_t errsz);
char *sym_core_subst(const char *expr, const char *var, const char *newexpr,
                     char *err, size_t errsz);
/* 结构相等（化简后比对，数值容差 1e-9 相对）：1=相等 0=不等 -1=出错 */
int    sym_core_equal(const char *a, const char *b, char *err, size_t errsz);
/* 解方程：eq 形如 "左=右"（缺 = 当 =0）；返回 "x = r1, x = r2"（升序）。
 * 只解单变量多项式：一/二阶闭式，三阶以上 Durand-Kerner 数值根（上限 12 次）；
 * 恒等式 / 无解 / 无实根都给明确文字；失败返回 NULL（err 有文案）。 */
char *sym_core_solve(const char *eq, const char *var, char *err, size_t errsz);
/* 解线性方程组：eqs 用 ;；\n\r 分隔多个方程（各形如 "左=右"，缺 = 当 =0）；
 * vars_str 用 ,， \t 分隔变量名。要求方程数==变量数（方阵，否则明确报错指路
 * sym.求解）；精确有理数高斯-约当消元，输出 "x = 1, y = 2"（用户变量序）。
 * 奇异分「无解（矛盾）」/「有无穷多组解（列自由变量）」两种明确文字；
 * 失败返回 NULL（err 有文案）。 */
char *sym_core_solve_sys(const char *eqs, const char *vars_str, char *err, size_t errsz);
/* 输出格式：mode = "" / "plain"（默认，与解析逐字一致）/ "latex" / "unicode" */
char *sym_core_format(const char *expr, const char *mode, char *err, size_t errsz);
/* 极限：expr 在 var → point 的极限（point 可写 inf/-inf）。有限点走代入+洛必达
 * （只对 0/0、∞/∞ 真未定式用，分子分母分别求导）并过数值对拍；无穷点走大数值
 * 外推（数值近似）。失败返回 NULL（err 有文案）。 */
char *sym_core_limit(const char *expr, const char *var, const char *point,
                     char *err, size_t errsz);
/* 泰勒展开：expr 在 var = point 处展开到 order 阶（0..12），系数尽量精确分数。
 * 输出「多项式 + O 余项」；point 不支持 inf（换元后用 sym.替换）。失败返回 NULL。 */
char *sym_core_series(const char *expr, const char *var, const char *point,
                      int order, char *err, size_t errsz);

#if defined(PYBOOK_RT_H) || defined(SYM_RT_BINDING)
#include "pybook_rt.h"   /* Value / rt_str / rt_die 等；本文件被 pybook_lib.h 带入时此处已包含过（幂等） */
/* ---- 绑定层（PYbook 命名空间 sym.*） ---- */
Value rt_lib_sym_parse(Value ev);
Value rt_lib_sym_diff(Value ev, Value varv);
Value rt_lib_sym_integrate(Value ev, Value varv);
Value rt_lib_sym_simplify(Value ev);
Value rt_lib_sym_expand(Value ev);
Value rt_lib_sym_eval(Value ev, Value bindv);
Value rt_lib_sym_vars(Value ev);
Value rt_lib_sym_subst(Value ev, Value varv, Value newv);
Value rt_lib_sym_equal(Value av, Value bv);
Value rt_lib_sym_solve(Value ev, Value varv);
Value rt_lib_sym_format(Value ev, Value modev);
Value rt_lib_sym_solve_sys(Value eqsv, Value varsv);
Value rt_lib_sym_limit(Value ev, Value varv, Value ptv);
Value rt_lib_sym_series(Value ev, Value varv, Value ptv, Value ordv);
#endif /* PYBOOK_RT_H */

#ifdef __cplusplus
}
#endif

#endif /* PYBOOK_SYM_H */
