# 悬空接口体检：LIB_C_NAMES 里映射的每个 rt_* 符号，
# C 文件里到底有没有定义？
#
# 起因：hw.particles_clear / hw.burst / hw.particles 三个映射还在 pybk_code.py 里，
# 但实现只存在于 _session_backup/hw3d_current.c，现役 pybook_hw3d.c 里 grep 不到 ——
# 调它们直接 undefined reference。而 hw.bloom 也疑似同类。
#
# 编译期不报错（映射表里有），链接期才炸一串英文，也不告诉你是实现丢了。
# 这个脚本把这类洞一次找全。
#
#   $ python -B _check_dangling.py
import re
import sys

src = open('pybk_code.py', encoding='utf-8').read()

# 只取 LIB_C_NAMES 那一段
m = re.search(r'LIB_C_NAMES\s*[:=]', src)
seg = src[m.start():m.start() + 200000]
pairs = re.findall(r"'((?:hw|ui)\.[A-Za-z_]+)'\s*:\s*'(rt_[a-z0-9_]+)'", seg)
# game.* 的 rt_game_* 在 pybook_rt.c
pairs += re.findall(r"'(圆|circle)'\s*:\s*'(rt_game_circle)'", src)

files = {
    'rt_hw_': ('pybook_hw3d.c', 'pybook_m3d.c'),
    'rt_ui_': ('pybook_ui.c', 'pybook_rt.c'),
    'rt_game_': ('pybook_rt.c',),
    'rt_m3d_': ('pybook_m3d.c',),
}
text = {}
for pref, fl in files.items():
    text[pref] = '\n'.join(open(f, encoding='utf-8').read() for f in fl)

print('%-22s %-26s %s' % ('接口', 'C 符号', '状态'))
print('-' * 70)
missing = []
for name, sym in sorted(set(pairs)):
    done = False
    for pref, fl in files.items():
        if not sym.startswith(pref):
            continue
        done = True
        body = text[pref]
        pat = re.compile(r'\b(?:Value|void|int|double|const char\s*\*|char\s*\*|float|unsigned)\s+\*?' + sym + r'\s*\(')
        hit = bool(pat.search(body))
        if hit:
            mdef = re.search(r'\b(?:Value|void|int)\s+' + sym + r'\s*\([^;]*?\)\s*\{', body, re.S)
            hit = bool(mdef)
        if hit:
            print('%-22s %-26s %s' % (name, sym, 'OK  ' + '/'.join(fl)))
        else:
            print('%-22s %-26s %s' % (name, sym, '*** 悬空（无定义）***'))
            missing.append((name, sym))
        break

print()
print('合计 %d 个接口，悬空 %d 个' % (len(set(pairs)), len(missing)))
for n, s in missing:
    print('  悬空: %s -> %s' % (n, s))
sys.exit(0)
