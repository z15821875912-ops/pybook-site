/* PYbook 多线程内核实现：常驻工人池 + 条件变量栅栏（Windows）。 */

/* ⚠⚠ 前缀陷阱，读这个文件前先看一眼 ⚠⚠
 *
 * 本文件（以及 pybook_mt.h 里）那些 `mt_` 开头的内部符号 —— mt_workers、
 * mt_rows、mt_init…… —— 这里的 mt 是 **mul**ti**t**hread，**不是** PYbook
 * 语言里那个 `mt.`。
 *
 * 语言侧的 `mt.` 是**数学**：mt.sqrt / mt.sin / mt.gamma / mt.zeta / mt.erf
 * …… 见 pybk_front.py 的 LIB_CALLS，没有一个是并行的。
 * 反过来，文件里说的 `mt.parallel`（按行切矩阵乘）**根本没有暴露给语言**，
 * 只是运行时内部在用。
 *
 * 两边前缀同名纯属历史撞车。写/读这段代码时看到 mt_ 先当多线程看；
 * 在 .pybk 里看到 mt. 先当数学看。想写并行逻辑，用文件头 `device cpu N`
 * 设线程数，或 tb.dot 那类自动并行的库入口，不要去猜 mt.parallel。
 */

#include "pybook_mt.h"
#include "pybook_rt.h"   /* rt_device_threads()：文件头 device cpu N 的线程数（实现见 pybook_rt.c） */

#define _WIN32_WINNT 0x0601
#define WIN32_LEAN_AND_MEAN
#include <windows.h>

#include <process.h>
#include <stdlib.h>

#define MT_MAXT 16      /* 工人上限（含主线程） */

typedef struct {
    void (*fn)(int cid, long long a, long long b, void *ud);
    void *ud;
    long long n;
    int left;                    /* 还没交工的池工人数 */
    int next;                    /* 下一个待领的块号 */
    unsigned long long epoch;    /* 代数：防止工人多领下一轮的活 */
} MtState;

static CRITICAL_SECTION g_cs;
static CONDITION_VARIABLE g_wake;
static CONDITION_VARIABLE g_done;
static INIT_ONCE g_once = INIT_ONCE_STATIC_INIT;
static HANDLE g_th[MT_MAXT - 1];
static int g_pooled = 0;         /* 池中工人数（不含主线程） */
static MtState g_st;

static BOOL CALLBACK mt_once(PINIT_ONCE o, PVOID p, PVOID *c)
{
    (void)o; (void)p; (void)c;
    InitializeCriticalSection(&g_cs);
    InitializeConditionVariable(&g_wake);
    InitializeConditionVariable(&g_done);
    return TRUE;
}

int mt_workers(void)
{
    static int cached = 0;
    if (cached)
        return cached;
    int t = 0;
    /* 优先级：文件头 device cpu N  >  环境变量 PYBOOK_THREADS  >  逻辑处理器数。
     * 跟 errorstopped 的「文件头 > 命令行 > 环境变量」同一套思路：
     * 旋钮写在文件里，跟着代码走，不依赖跑的人记得配什么环境。 */
    t = rt_device_threads();
    if (t <= 0) {
        const char *env = getenv("PYBOOK_THREADS");
        if (env && *env)
            t = atoi(env);
    }
    if (t <= 0) {
        SYSTEM_INFO si;
        GetSystemInfo(&si);
        t = (int)si.dwNumberOfProcessors;
        if (t > MT_MAXT)
            t = MT_MAXT;
    }
    if (t > MT_MAXT)
        t = MT_MAXT;
    if (t < 1)
        t = 1;
    cached = t;
    return t;
}

static unsigned __stdcall mt_worker(void *arg)
{
    unsigned long long seen = 0;
    (void)arg;
    for (;;) {
        EnterCriticalSection(&g_cs);
        while (g_st.epoch == seen)
            SleepConditionVariableCS(&g_wake, &g_cs, INFINITE);
        seen = g_st.epoch;
        for (;;) {
            int cid = g_st.next;
            if (cid >= MT_CHUNKS)
                break;
            g_st.next++;
            long long a = g_st.n * cid / MT_CHUNKS;
            long long b = g_st.n * (cid + 1) / MT_CHUNKS;
            void (*fn)(int, long long, long long, void *) = g_st.fn;
            void *ud = g_st.ud;
            LeaveCriticalSection(&g_cs);
            if (b > a)
                fn(cid, a, b, ud);
            EnterCriticalSection(&g_cs);
        }
        if (--g_st.left == 0)
            WakeConditionVariable(&g_done);
        LeaveCriticalSection(&g_cs);
    }
    return 0;
}

static void mt_ensure(int want)
{
    EnterCriticalSection(&g_cs);
    while (g_pooled < want) {
        HANDLE h = (HANDLE)_beginthreadex(NULL, 0, mt_worker, NULL, 0, NULL);
        if (!h)
            break;               /* 起不来就少用几个核，不报错 */
        g_th[g_pooled++] = h;
    }
    LeaveCriticalSection(&g_cs);
}

int mt_parallel(long long n,
                void (*fn)(int cid, long long a, long long b, void *ud),
                void *ud)
{
    int t = mt_workers();
    if (t <= 1 || n <= 0) {
        if (n > 0)
            fn(0, 0, n, ud);
        return 1;
    }
    InitOnceExecuteOnce(&g_once, mt_once, NULL, NULL);
    mt_ensure(t - 1);
    if (g_pooled == 0) {         // 一个工人都没起来（极端环境），退回串行
        fn(0, 0, n, ud);
        return 1;
    }

    EnterCriticalSection(&g_cs);
    g_st.fn = fn;
    g_st.ud = ud;
    g_st.n = n;
    g_st.next = 0;
    g_st.left = g_pooled;
    g_st.epoch++;
    WakeAllConditionVariable(&g_wake);

    int cid;                     /* 主线程自己也是工人 */
    while ((cid = g_st.next) < MT_CHUNKS) {
        g_st.next++;
        long long a = n * cid / MT_CHUNKS;
        long long b = n * (cid + 1) / MT_CHUNKS;
        LeaveCriticalSection(&g_cs);
        if (b > a)
            fn(cid, a, b, ud);
        EnterCriticalSection(&g_cs);
    }
    while (g_st.left > 0)
        SleepConditionVariableCS(&g_done, &g_cs, INFINITE);
    LeaveCriticalSection(&g_cs);
    return MT_CHUNKS;
}
