# _wire_sym.py —— 把 sym.*（符号数学，pybook_sym.c）接进 VM 库调用表。
# 一次性补丁：幂等（打过就别再打），每处断言 count==1。
# 前端(pybk_front)/后端(pybk_code)/pybook_lib.h/build_pyvm.bat 已手工接线，
# 这里只落 _vm_lib_calls.inc，并对其余四端做存在性校验（缺哪项报哪项）。
import io
import sys

P = '_vm_lib_calls.inc'
N_OLD = 259
ENTRIES = [
    ('sym.解析', 1, 'rt_lib_sym_parse'),
    ('sym.求导', 2, 'rt_lib_sym_diff'),
    ('sym.积分', 2, 'rt_lib_sym_integrate'),
    ('sym.化简', 1, 'rt_lib_sym_simplify'),
    ('sym.展开', 1, 'rt_lib_sym_expand'),
    ('sym.求值', 2, 'rt_lib_sym_eval'),
    ('sym.变量', 1, 'rt_lib_sym_vars'),
    ('sym.替换', 3, 'rt_lib_sym_subst'),
    ('sym.相等', 2, 'rt_lib_sym_equal'),
]

t = io.open(P, encoding='utf-8').read()
eol = '\r\n' if '\r\n' in t else '\n'

if 'rt_lib_sym_parse' in t:
    print('_vm_lib_calls.inc 已有 sym，跳过补丁')
else:
    # ① 前置声明：接在 rt_lib_te_upper 之后
    a = 'Value rt_lib_te_upper(Value);' + eol
    assert t.count(a) == 1, '声明锚点找不到或不唯一'
    decls = ''.join('Value %s(%s);%s' % (c, ', '.join(['Value'] * n), eol)
                    for _k, n, c in ENTRIES)
    t = t.replace(a, a + decls, 1)

    # ② 分发表：接在表尾 http.config 行之后（该行以 ,}; 收尾，无换行）
    b = '    {"http.config", 1, (void *)rt_http_config},};'
    assert t.count(b) == 1, '表尾锚点找不到或不唯一'
    rows = ''.join('    {"%s", %d, (void *)%s},%s' % (k, n, c, eol)
                   for k, n, c in ENTRIES)
    t = t.replace(b, b[:-2] + eol + rows + '};', 1)

    # ③ 计数宏 + 头注
    c1 = '#define G_LIB_CALLS_N %d' % N_OLD
    assert t.count(c1) == 1, '计数宏找不到'
    t = t.replace(c1, '#define G_LIB_CALLS_N %d' % (N_OLD + len(ENTRIES)), 1)
    h = '生成：%d 个库调用' % N_OLD
    if t.count(h) == 1:
        t = t.replace(h, '生成：%d 个库调用' % (N_OLD + len(ENTRIES)), 1)

    io.open(P, 'w', encoding='utf-8', newline='').write(t)
    print('_vm_lib_calls.inc 已接线（+%d = %d 个入口）' % (len(ENTRIES), N_OLD + len(ENTRIES)))

# ④ 其余四端存在性校验（缺哪项报哪项，退出码 1）
CHECKS = [
    ('pybk_front.py', ["'sym',\n}", "'sym')", "'sym.解析': 1"], '前端 KEYWORDS/LIB_PREFIXES/LIB_CALLS'),
    ('pybk_code.py', ["'rt_lib_sym_parse'", "'pybook_sym.c', 'pybook_sym.h'", "'pybook_la.c', 'pybook_sym.c'"], '后端 LIB_C_NAMES/_CACHE_DEPS/.o 清单'),
    ('pybook_lib.h', ['#include "pybook_sym.h"'], 'pybook_lib.h'),
    ('build_pyvm.bat', ['pybook_sym.c', '-DSYM_RT_BINDING'], 'VM 构建脚本'),
]
bad = 0
for f, needles, what in CHECKS:
    try:
        s = io.open(f, encoding='utf-8').read()
    except OSError as e:
        print('MISS %-22s 打不开：%s' % (what, e))
        bad += 1
        continue
    for nd in needles:
        if nd not in s:
            print('MISS %-22s 缺 [%s]' % (what, nd))
            bad += 1
if bad:
    print('四端校验未过（%d 处缺失）' % bad)
    sys.exit(1)
print('四端校验全过：front / code / lib.h / build_pyvm.bat 均已接线')
