# -*- coding: utf-8 -*-
"""_chk_wire2.py — 复查四张表里 11 个新入口的登记还在不在
（pybk_front.py 最近被外部改过好几次，得每次动手前先确认）"""
import io
import os
import re
import time

NAMES = ['mt.erf', 'mt.erfc', 'mt.gamma', 'mt.lgamma', 'mt.zeta',
         'mt.golden_min', 'mt.golden_max', 'mp.interp_linear',
         'mp.interp_cubic', 'mp.linfit', 'mp.polyfit']
C = {'mt.erf': 'rt_lib_mt_erf', 'mt.erfc': 'rt_lib_mt_erfc',
     'mt.gamma': 'rt_lib_mt_gamma', 'mt.lgamma': 'rt_lib_mt_lgamma',
     'mt.zeta': 'rt_lib_mt_zeta', 'mt.golden_min': 'rt_lib_mt_golden_min',
     'mt.golden_max': 'rt_lib_mt_golden_max',
     'mp.interp_linear': 'rt_lib_mp_interp_linear',
     'mp.interp_cubic': 'rt_lib_mp_interp_cubic',
     'mp.linfit': 'rt_lib_mp_linfit', 'mp.polyfit': 'rt_lib_mp_polyfit'}
LO = {'mt.golden_min': 2, 'mt.golden_max': 2}

FILES = ['pybk_front.py', 'pybk_code.py', 'pybook_lib.h', '_vm_lib_calls.inc']

text = {}
for p in FILES:
    text[p] = io.open(p, encoding='utf-8', newline='').read()
    print('%-20s mtime %s' % (p, time.strftime('%H:%M:%S',
          time.localtime(os.path.getmtime(p)))))

print()
miss = 0
for n in NAMES:
    row = []
    for p in FILES:
        if p == 'pybk_front.py':
            ok = ("'%s'" % n) in text[p]
        elif p == 'pybk_code.py':
            ok = ("'%s': '%s'" % (n, C[n])) in text[p]
        elif p == 'pybook_lib.h':
            ok = (C[n] + '(') in text[p]
        else:
            ok = ('{"%s", %d,' % (n, LO.get(n, 1))) in text[p] \
                 and ('Value %s(' % C[n]) in text[p]
        row.append('%s%s' % (p.split('.')[0][:6], '✓' if ok else '✗'))
        if not ok:
            miss += 1
    print('%-16s %s' % (n, '  '.join(row)))

print()
t = io.open('_vm_lib_calls.inc', encoding='utf-8', newline='').read()
m = re.search(r'(\d+) 个库调用', t)
print('表头计数 %s / 实际表项 %d' % (m.group(1) if m else '?',
                                  len(re.findall(r'^\s*\{"', t, re.M))))
print('\n%s' % ('全部齐全' if miss == 0 else '缺 %d 处' % miss))
