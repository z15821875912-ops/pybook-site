# P0 编译器回归：引用+类合并失效（最小复现）

## 现象
任意 .pybk 包定义 lb.类，消费者 引用("包") 后 lb.类() 构造 → 「未定义的类」。
已知良好的 mec（lb.泛表，游戏一直在用）**同样失败** → 仓库级回归，不是个别包问题。

## 复现（文件已在 _自动微分验证/）
    # _最小包.pybk
    lb.工具 {
        vg.值 = 1
    }
    # _最小消费.pybk
    @ t>最小>1
    引用("_最小包")
    GOING:{
    vg.t = lb.工具()
    ns.show("值 =", t.值)
    }STOP
    $ python pybk_main.py --check _自动微分验证/_最小消费.pybk
    → 编译失败: 第 4 行：未定义的类 '工具'

## 定位线索
- pybk_code._load_imports 正常读到了模块（找不到文件的报错点在 3717，早于合并）
- pybk_code 的语义检查（702/716/1523/2317）查 self.classes——合并后的类没进这个表
- pybk_front 有 958 行未提交改动（jit/device/tensor 批次）——回归大概率随该批进入
  （_preload_module_classes 的 cwd 探测坑已另行修复）
- 前后矛盾点：tb.c/当前 tb.c 引用 RtTensor 能过、mec 泛表不能——
  疑似 parse_module 的类收集在某个重构后漏了「被引用模块」的路径

## 影响
所有 lb.类 + 引用 的库（mec、自动微分、未来一切带类的包）全部无法编译。
