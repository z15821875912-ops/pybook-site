/* _laeig_dbg.c — 单步探针：直接把 pybook_la.c 整个 include 进来，
 * 这样它的 static 内部函数（la_hessenberg / la_francis / la_balance）都能调。
 * 只编译 pybook_la.c 一次、不定义 LA_RT_BINDING，所以没有绑定层。
 *
 * 用法：gcc _laeig_dbg.c -o _laeig_dbg.exe -O2 -Wall
 */

#include <stdio.h>
#include "pybook_la.c"

static unsigned long long g_st = 0xDEADBEEFCAFEF00DULL;
static double urand(void)
{
    g_st ^= g_st << 13; g_st ^= g_st >> 7; g_st ^= g_st << 17;
    return ((double)(g_st >> 11) * (1.0 / 9007199254740992.0)) * 2.0 - 1.0;
}

static void dump(const char *tag, const double *a, int n)
{
    int i, j;
    printf("--- %s ---\n", tag);
    for (i = 0; i < n; i++) {
        for (j = 0; j < n; j++) printf("%12.6g", a[(size_t)i * n + j]);
        printf("\n");
    }
}

int main(void)
{
    const int n = 3;
    double a[9], t[9], q[9];
    int    i, j, l, u, iter;
    double detA;

    /* 复现 rand3 的第一个 3x3：先把前两轮（n=1、n=2）的随机数吃掉 */
    for (i = 0; i < 1 * 1; i++) urand();
    for (i = 0; i < 2 * 2; i++) urand();
    for (i = 0; i < 9; i++) a[i] = urand();
    dump("A", a, n);
    detA = a[0] * (a[4] * a[8] - a[5] * a[7])
         - a[1] * (a[3] * a[8] - a[5] * a[6])
         + a[2] * (a[3] * a[7] - a[4] * a[6]);

    {
        int dsc[3];
        la_balance(a, dsc, n);
        dump("平衡后", a, n);
    }
    for (i = 0; i < n; i++)
        for (j = 0; j < n; j++) q[i * n + j] = (i == j) ? 1.0 : 0.0;
    la_hessenberg(a, q, n);
    dump("Hessenberg H", a, n);
    dump("Q", q, n);

    memcpy(t, a, sizeof(t));
    l = 0; u = n - 1;
    printf("窗口 [%d,%d]  s=%d\n", l, u, u - l + 1);
    {
        double p  = t[(u - 1) * n + (u - 1)] + t[u * n + u];
        double qq = t[(u - 1) * n + (u - 1)] * t[u * n + u]
                  - t[(u - 1) * n + u] * t[u * n + (u - 1)];
        double col[8], col2[8], nrm;
        printf("p=%g q=%g\n", p, qq);
        for (i = 0; i <= u - l; i++) col[i] = t[(l + i) * n + l];
        for (i = 0; i <= u - l; i++) {
            double acc = 0.0;
            int    j0 = (i >= 1) ? i - 1 : 0;
            for (j = j0; j <= u - l; j++) acc += t[(l + i) * n + (l + j)] * col[j];
            col2[i] = acc - p * col[i];
            printf("  x[%d] = %g   (M·col 那一项 %g)\n", i, col2[i], acc);
        }
        col2[0] += qq;
        nrm = 0.0;
        for (i = 1; i <= u - l; i++) nrm += col2[i] * col2[i];
        printf("x[0]=%g  |x[1:]|=%g\n", col2[0], sqrt(nrm));
    }

    /* 先记下 l+2,l 这一格「不强制清零」时的真实值 */
    {
        double save = t[(l + 2) * n + l];
        la_francis(t, q, n, l, u, 0);
        printf("不强制清零时 t[l+2][l] = %g   （原值 %g）\n", t[(l + 2) * n + l], save);
    }
    dump("一步 Francis 之后", t, n);

    /* 继续迭代看它往哪儿走 */
    for (iter = 0; iter < 60; iter++) {
        double sub, nrm;
        sub = fabs(t[u * n + (u - 1)]);
        nrm = fabs(t[(u - 1) * n + (u - 1)]) + fabs(t[u * n + u]);
        if (iter % 5 == 0) {
            /* 相似变换是否精确？迹已验证过，再看行列式与特征值 */
            double det = t[0] * (t[4] * t[8] - t[5] * t[7])
                       - t[1] * (t[3] * t[8] - t[5] * t[6])
                       + t[2] * (t[3] * t[7] - t[4] * t[6]);
            printf("iter %2d: sub=%.8g  t[1][0]=%.8g  det(T)=%.15g  (det(A)=%.15g)\n",
                   iter, sub, t[1 * n + 0], det, detA);
        }
        if (sub <= LA_EPS * (nrm + sub)) { printf("  %d: 劈开了\n", iter); u--; if (u == 0) break; continue; }
        l = u - 1;
        while (l > 0 && t[l * n + (l - 1)] != 0.0) l--;
        if (u - l == 1) {
            double r[2], im[2];
            la_eig2x2(t[(u-1)*n+(u-1)], t[(u-1)*n+u], t[u*n+(u-1)], t[u*n+u], r, im);
            printf("  %d: 窗口收成 2x2，特征值 %.8g%+.8gi / %.8g%+.8gi\n", iter, r[0], im[0], r[1], im[1]);
            u -= 2; if (u <= 0) break; continue;
        }
        if (la_francis(t, q, n, l, u, 0)) printf("  %d: ** stagn **\n", iter);
    }
    printf("最终 u=%d\n", u);
    dump("60 步之后", t, n);
    return 0;
}