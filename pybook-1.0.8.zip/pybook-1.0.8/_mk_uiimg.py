# 造 UI 图片能力的测试素材（不依赖 PIL，直接写 PNG）
#
# 为什么图案要这样设计 —— 每一处都是可自证的判据，不能只是「好看」：
#
#   静态图 64x48：
#     三条竖色带红/绿/蓝  -> 截图里数得清有没有被缩放/错位
#     左上角 8x8 纯白方块 -> **不对称特征**。没有它，一张左右镜像的图
#                             截图上完全一样，1:1 就成了空话
#     底部 8 行半透明黑   -> alpha=100。贴到面板上应该透出底色，
#                             不透明就说明 BLEND 模式没生效
#
#   序列帧 32x32 x 8：
#     底色逐帧变         -> 两帧不同才看得出动画在动
#     左侧 (帧号+1)*4 像素宽纯白竖条 -> 帧号直接可读。截图不需要跑起来
#                             就能断言「第几帧」
#     底部 8 行半透明黑   -> 同上，验 alpha
#
import struct
import zlib


def write_png(path, w, h, pix):
    """pix 是 bytearray，长度 w*h*4，RGBA 顺序，自顶向下。"""
    raw = bytearray()
    for y in range(h):
        raw.append(0)                      # 每行的 filter byte，0 = None
        raw += pix[y * w * 4:(y + 1) * w * 4]

    def chunk(tag, data):
        body = tag + data
        return (struct.pack('>I', len(data)) + body +
                struct.pack('>I', zlib.crc32(body) & 0xffffffff))

    out = b'\x89PNG\r\n\x1a\n'
    out += chunk(b'IHDR', struct.pack('>IIBBBBB', w, h, 8, 6, 0, 0, 0))
    out += chunk(b'IDAT', zlib.compress(bytes(raw), 9))
    out += chunk(b'IEND', b'')
    with open(path, 'wb') as f:
        f.write(out)
    return len(out)


def put(pix, w, x, y, r, g, b, a):
    i = (y * w + x) * 4
    pix[i:i + 4] = bytes((r, g, b, a))


# ---------------- 静态图 64x48 ----------------
W, H = 64, 48
pix = bytearray(W * H * 4)
for y in range(H):
    for x in range(W):
        if x < 22:
            c = (220, 60, 60)          # 红
        elif x < 43:
            c = (60, 200, 90)          # 绿
        else:
            c = (70, 110, 230)         # 蓝
        a = 100 if y >= H - 8 else 255  # 底部 8 行半透明黑
        put(pix, W, x, y, c[0], c[1], c[2], a)
# 左上角 8x8 纯白 —— 不对称特征
for y in range(8):
    for x in range(8):
        put(pix, W, x, y, 255, 255, 255, 255)
n = write_png('_ui_img_红绿蓝.png', W, H, pix)
print(f'_ui_img_红绿蓝.png  {W}x{H}  {n} 字节')

# ---------------- 序列帧 32x32 x 8 ----------------
SW, SH = 32, 32
for f in range(8):
    pix = bytearray(SW * SH * 4)
    bg = (f * 32, 255 - f * 32, 128)      # 底色逐帧变
    for y in range(SH):
        for x in range(SW):
            a = 100 if y >= SH - 8 else 255
            put(pix, SW, x, y, bg[0], bg[1], bg[2], a)
    bar = (f + 1) * 4                      # 白条宽度 = 帧号
    for y in range(SH):
        for x in range(bar):
            put(pix, SW, x, y, 255, 255, 255, 255)
    n = write_png(f'_ui_seq_{f + 1:02d}.png', SW, SH, pix)
    print(f'_ui_seq_{f + 1:02d}.png  {SW}x{SH}  {n} 字节  白条 {bar}px')

# ---------------- 已知 alpha 的纯色对照图 ----------------
# 用来分清「surface 里 alpha 就没写对」和「GL 上传丢了 alpha」：
#   2D 窗口模式  期望 = 220*a + 11*(1-a)      （窗底 #0B0E14）
#   3D 同屏模式  期望 = surface值*a + 场景色*(1-a)  （场景 #121622）
# 两边对不上就是 GL 那一环的问题，跟 UI 无关。
for a in (128, 64):
    pix = bytearray(16 * 16 * 4)
    for y in range(16):
        for x in range(16):
            put(pix, 16, x, y, 220, 60, 60, a)
    write_png(f'_ui_alpha_{a}.png', 16, 16, pix)
    # 2D 模式期望值：220*a/255 + 11*(255-a)/255
    e2 = round(220 * a / 255 + 11 * (255 - a) / 255)
    # 3D 模式：surface 存 straight alpha (220,60,60,a)，GL 再混一次
    sr = round(220 * a / 255)
    e3 = round(sr * a / 255 + 18 * (255 - a) / 255)
    print(f'_ui_alpha_{a}.png  a={a}  2D期望 #{e2:02X}{e2:02X}{e2:02X}  '
          f'3D期望 #{e3:02X}... (R通道)')

# ---------------- LRU 素材：320 张 8x8 小图 ----------------
# 缓存从 48 槽涨到 256 槽 LRU 后，要验的是「超过 256 张不崩」——
# 原行为是 rt_die 直接退程序，所以这个必须真跑一遍。
# 320 > 256，保证第 257 张之后一定触发淘汰 + 重载。
# 每张颜色由序号决定，最后一张（第 320）用显眼的白，方便截图确认还在画。
LW, LH = 8, 8
for i in range(1, 321):
    pix = bytearray(LW * LH * 4)
    if i == 320:
        c = (255, 255, 255)
    else:
        c = ((i * 7) % 256, (i * 13) % 256, (i * 29) % 256)
    for y in range(LH):
        for x in range(LW):
            put(pix, LW, x, y, c[0], c[1], c[2], 255)
    write_png(f'_ui_lru_{i}.png', LW, LH, pix)
print(f'_ui_lru_1..320.png  {LW}x{LH}  共 320 张（>256 槽，用来验 LRU 不崩）')
print('  ★ 文件名故意不带补零 —— PYbook 的 $(序号) 插值不带格式说明，'
      '补零的 001 得靠别的办法才拼得出来')
