# PYbook 架构速览（给贡献者）

一门**中文优先**的编译型语言。同一个 `.pybk` 文件走两条后端：

- **C 后端**：`pybk_main.py` → gcc → 原生 exe（窗口 / 3D / 游戏 / 桌面 GUI）。
- **VM 后端**：`pybk_bc.py` → `.pybc` 字节码 → `pyvm.exe` 纯 C 虚拟机（不装编译器也能跑）。

---

## 双后端分工原则：按任务性质分流，不是两套实现

两个后端**不冲突**，因为它们服务的不是"同一件事的两个实现"，而是**两类不同性质的任务**。判断一个库该走哪个后端，看它**绑没绑 OS 资源**，不看它"算得重不重"。

### 设计目标边界（按任务性质，而非按前缀）

| 后端 | 一句话 | 判据 | 库 |
|---|---|---|---|
| **VM —— 给素材、算东西** | 批处理，跑完就退 | **无窗口、无设备、无阻塞**；输入/输出都是**文件或值** | ① 离屏渲染（输入列表 → 输出文件）：`音.奏`、`音.音`、`mm.draw_away`、`mm.色`、`obj.*`（网格 → .obj 落盘）、`mm.贴`、`mm.动` ② 纯计算/纯数据：`tb np te list dict mt file csv rd bs tensor smoke 调色板` |
| **C —— 搞正事** | 需要 OS 资源 | **绑定了窗口 / 设备 / socket / 编译器** | ① 窗口/交互：`hw`（含 10 个键鼠函数）、`ui`、`m3`、`web` ② 音频设备：`音.正弦`、`音.三角`、`音.快`、`音.放`、`音.谱` ③ 网络：`net`、`http` ④ 编译期展开 C：`ffi` |

注意 `音.*` 内部是**分裂**的：`音.奏`（把乐谱列表渲染成 WAV 落盘）、`音.音`（注册自定义音符）是离屏/数据 → VM；`音.正弦/三角/快/放/谱` 是实时播放 → C。同理 `mu.*` 是 `音.*` 的英文别名，整组镜像这套分法。

### 为什么两个后端都要存在

- **VM 值得存在**：素材生成是批处理，跑完就退，**编译时间直接进成本**。实测 VM 跑一个 `.pybc` ≈ 206ms，而 C 后端冷编译 1.3s–4.5s——批处理场景里省掉编译就是省真金白银。例：`晚风.pybk` 在 VM 上出 WAV，`示例_射击场.pybk` 在 C 后端开窗口打靶，两件事之间**没有任何竞争关系**。
- **C 后端值得存在**：产出的 exe 可随便分发、离线跑、不需要解释器；且只有它能碰窗口/设备/socket。

### 当前实现状态：边界是"撞出来的"，不是设计的（已知缺口）

> ⚠️ 下面三条是**当前真实 bug**，不是设计。设计目标见上表。

边界目前由**编译期前缀黑名单 `_VM_UNAVAILABLE`**（`pybk_bc.py:541` = `('mu','音','mm','net','m3','ui','http')`）整块拦截，而这张黑名单是按"哪些 `.c` 没链进 `pyvm.exe`"列的，**不是按任务性质**。两者恰好大部分重合，但边界上错得离谱，已逐一核实：

1. **该在 VM 却被拒**（物理可用，仅被前缀误拦）：
   - `音.奏`（→`rt_mu_away`，渲染 WAV 落盘，零设备）、`音.音`（→`rt_mu_note`，注册音符，纯数据）、`mm.*`（`mm.draw_away`→`rt_mm_draw_away` 落成 PNG、手写编码器零依赖；`mm.色/贴/动` 同理）**都已经在 `pyvm.exe` 里**——因为 `build_pyvm.bat:45-46` 把 `pybook_music.c`、`pybook_mm.c` 都链进去了。但它们因 `音`/`mm` 前缀被 `_VM_UNAVAILABLE` 整块挡在门外。
2. **不该在 VM 却在运行时表里**（`_vm_lib_calls.inc:295-298` = `mu.play / mu.sine / mu.stop / mu.tri`）：这是实时播放，`mu.sine/mu.tri` 经 `mu_tone` 会 `Sleep(1)` 自旋到播放结束。它们能留在表里，**只是因为 `pybook_music.c` 整个文件被链进了 `pyvm.exe`**。编译期 `mu`/`音` 已拦，所以"在表里但没人能调到"。
3. **别名错配掩盖了上述事实**：`音.*` 共 8 个（`音.正弦/三角/放/停/快/音/奏/谱`，见 `pybk_front.py:533-534` 的 `LIB_CALLS`），但前端会把 `mu` 归一化成 `音`（`pybk_front.py:2325-2326`），运行时派发表里只有 `mu.*` 没有 `音.*`。这层错配让人误以为"实时播放不在 VM 里"，其实它（以 `mu.*` 之名）一直在表里。

**已实施（2026-10-11）**：黑名单已从"按前缀"改为"按函数"（`pybk_bc.py` 的 `_VM_BLOCK_PREFIXES` + `_VM_BLOCK_FUNCS`，详见该文件注释）：
- **放行给 VM**（已注册进 `_vm_lib_calls.inc` 派发表，实测产出文件）：`音.奏`（WAV 落盘，零设备）、`音.音`（注册音符，纯数据）、`mm.draw_away`（PNG 落盘，手写编码器零依赖）、`mm.色`/`mm.color`（设色令牌，纯数据）。
- **维持 C 后端、编译期即拒**：实时播放类 `音.正弦/三角/快/放/停/谱`（waveOut 阻塞式）；窗口类 `mm.贴`/`mm.blt`/`mm.动`/`mm.anim`（需 SDL 窗口，`g_sdl_ren == NULL` 即死）。
- 顺带把原表里 4 个死条目 `mu.play/sine/stop/tri`（实时播放，VM 永远到不了——前端已把 `mu.*` 归一化到 `音.*`）替换为上述离屏条目，边界从此是设计的而非撞出来的。
- **关键修正（与原讨论不同）**：原讨论把 `mm.贴`/`mm.动` 也归为离屏，但源码 `rt_mm_blt`/`rt_mm_anim` 开头都是 `if (g_sdl_ren == NULL) rt_die("还没开窗口")`，即窗口模式，**必须走 C 后端**；真正离屏的 mm.* 只有 `mm.draw_away` 与 `mm.色`。
- 验证：`build_tmp/vm_test_*.pybk` / `vm_neg_*.pybk` 共 4 正 + 至少 3 反例——正例（`音.奏`/`音.音`/`mm.draw_away`/`mm.色`）产出合法 WAV/PNG（RIFF/WAVE、PNG 签名校验通过）；反例（`音.正弦`/`音.停`/`mm.贴`）编译期即报「实时播放/窗口类，仅 C 后端支持」。全过。

---

## 编译器管线（`pybk_front` → `pybk_code` / `pybk_bc`）

| 文件 | 职责 |
|---|---|
| `pybk_front.py` | 词法 / 语法 / 语义分析，产出 AST（`Program`）。含保留字表、模块前缀 `LIB_PREFIXES`、宏展开。 |
| `pybk_code.py` | C 后端代码生成（emit C 源码）。 |
| `pybk_bc.py` | VM 字节码生成（`compile_source` → `.pybc`）。 |
| `pybk_main.py` | 入口：`--check` / `--check-json` 语法语义检查；C 后端调 gcc；`--version`。 |
| `pybk_types.py` | 类型 / 复杂度检查（`errorstopped` 严格度旋钮 hard/normal/simple）。 |
| `pybk_project.py` | 项目级静态分析（依赖图、环检测、拓扑序）—— 不改 codegen。 |

---

## 运行时（C，两个后端共用 / 各自链接）

| 文件 | 职责 |
|---|---|
| `pyvm.c` | VM 主循环（字节码解释器，computed-goto 派发）+ 启动 + **JIT（`--jit`，见下）**。 |
| `pybook_rt.c` | 核心运行时（内存管理 Memoryment、异常、测试断言 `rt_test_*`；另有 `rt_device_set` 设后端/线程数）。 |
| `pybook_lib.h` | 公共头（`Value` 联合体、`rt_*` 原型）。 |
| `pybook_lib.c` | 标准库分发（库调用跳转表 `G_LIB_CALLS`）；另有 `mt.*` 基础数学、`te.*` 文本、`tm.*` 时间等实现。 |
| `pybook_mt.c` | 线程池（`mt.parallel` / 矩阵乘按行切 12 线程）。工人数 `mt_workers()`：文件头 `device cpu N` > `PYBOOK_THREADS` > 逻辑处理器数。 |
| `pybook_mm.c` | 内存 / 字符串 / 列表等基础类型。 |
| `pybook_np.c` | 数值（`np.*`）。 |
| `pybook_tb.c` | **矩阵 / 张量库（`tb.*`）：含手写 AVX2+FMA 分块 matmul —— 性能热点，见下；以及 GPU 路由。** |
| `pybook_gpu.c` / `.h` | **GPU 后端（NVIDIA CUDA driver API 动态加载 + 手写 PTX），零构建期依赖，见下。** |
| `pybook_csv` / `json` / `file` / `smoke` / `bits` / `music` | 各标准库模块。 |
| `pybook_hw3d.c` | 3D highway（`hw.*`，SDL2 + OpenGL）—— 仅 C 后端 3D 需要。 |
| `pybook_net.c` | 网络（`http.*`）。 |
| `mathplus.c` | `mp.*` 数学扩展（需 `-DMP_RT_BINDING` 绑定宏）。`mat_det` / `mat_inverse` 已改走 `pybook_la.c` 的 LU 底座。 |
| `pybook_la.c` / `.h` | **线性代数核心（`pybook_la.h` 的 `[1]` 层，纯 `double*`，不碰运行时）+ 绑定层（`[2]`，需 `-DLA_RT_BINDING`）—— 见下。** |

---

## `tb.dot` 性能热点（`pybook_tb.c`）

- **三级分块 matmul**：`kc → jc → ic`，最内层 `MR×NR = 4×8` 寄存器分块（8 条独立 FMA 链打满 AVX2 吞吐）。
- **B 打包**成 `KC×NC` 连续面板（每个 k 块只从内存读一次 B），消除原内核 `B[k*bc+jj]` 的 ~8000B 跨距冲突未命中；**A 的 k 维本就单位步长，不打包**（打包是纯开销）。
- **块尺寸 `KC=NC=MC=48` 是扫描调出来的，不要改大**：12 线程按**行**切（1000³ 每线程 ~83 行），大面板（>128）打包 memcpy 开销主导且溢出 per-core L2(256KB)。K=48 时两面板合计 ~36KB，全进 L1/L2。改回 128 会让 1000³ 从 ~20ms/rep 退到 ~27ms/rep。
- 与朴素三重循环**逐位等价**（相对均方误差 ~1e-30）。

---

## 函数值回调：库函数怎么调到用户的 lambda（`pybook_rt.c`）

mec lambda 编译成用户程序里的顶层函数 `__mec_lam_N`，lambda 的「值」只是函数名字符串
（`rt_str("__mec_lam_1")`），真正的分发表 `rt_mec_apply` 由 `pybk_code.gen_mec_apply()`
生成进 `out.c` —— **它不在 pyvm.exe 里**。

所以库函数（`pybook_lib.c` / `pybook_rt.c` 里的）想回调用户的 f，**链接期就找不到符号**。
这是「库函数收函数」这条路以前走不通的唯一原因，不是算法问题。

### 改法：运行时只存一个函数指针

```c
typedef Value (*RtFnDispatch)(Value fnval, Value args);
void   rt_set_fn_dispatch(RtFnDispatch f);   /* 用户程序在 main() 开头调 */
Value  rt_call_value(Value fnval, Value args);
Value  rt_call1(Value fnval, Value x);
```

`pybk_code.py` 在生成的 `main()` 第二行发射 `rt_set_fn_dispatch(rt_mec_apply);`。

**为什么不是「生成一张注册表」**：分发表本体（strcmp 链、每个函数的 arity 校验、部分应用展开）
仍然留在编译器生成的那个函数里，一行没动。注册表方案要额外生成 `Value w_f_N(Value*, int)` 包装函数，
把 arity 检查也搬到运行时 —— 那样「函数名写错」「参数个数不对」这类错误文案会跟着搬家，
容易变样。现在这两种错误仍旧从 `rt_mec_apply` 原样抛出。代价只是一次间接调用。

`rt_call_value` 在没装分发器时给出可操作的报错（而不是崩），但实际上 C 后端每个程序都会装，
所以那条分支只在极端情况下才会走到。

### 库入口的可选参数

`LIB_CALLS` 的值是**参数个数**。写成元组 `(最少, 最多)` 表示可选参数：

- `pybk_front.py`：元组时做区间校验并早返回，不进后面的定长比较。
- `pybk_code.py`：用户少给时用 `rt_none()` 补齐到 `最多` 个，C 层认空盒当「用缺省值」。

既有入口的值都是 `int`，`isinstance(want, tuple)` 为假，**走的是原来那条路，一行行为不变**。

判据是「want 是不是元组」，**不能**写成 `want[1] > len(args)` —— 用户给满参数时那条为假，
会掉回定长校验，报出「需要 (2, 3) 个参数」这种把元组原样打出来的怪消息。这个坑踩过一次。

### 数值微积分（`mt.*`）

`deriv`（中心差分）、`integrate`（复合 Simpson）、`root_bisect`（二分）、`root_newton` /
`root_newton_d`（牛顿，数值/解析导数两种）、`taylor`。

几个刻意选的地方：

- **缺省步长 `1e-5·max(1,|x|)`**：再小就撞上 double 的相减相消（`f(x+h)` 与 `f(x-h)`
  相减本身要损失精度），再大就差商误差上去。
- **步长相对 x 太小时报错**，因为 `x+h` 舍入后还是 x，差商会静默变成 0。
- **Simpson 的区间数是奇数就 +1**：Simpson 要求偶数个区间，补一个比报错好，但补了要说。
- **二分法两端同号就报错，并把两端的函数值算出来**。同号时二分法会收敛到一个错的点，
  静默返回一个数会让人以为求成功了 —— 这比报错坏得多。
- **牛顿法迭代发散 / 不收敛 / 导数为 0 各有独立文案**，都指出下一步该做什么。

### 字节码后端的现状

`.pybc` 后端**不支持 lambda**（`pybk_bc.py` 不 import `Lambda`）。现在遇到会给出可操作提示，
指明受影响的是哪些入口。真要支持需要给它一套自己的函数调用指令，是更大的活。

顺带一条实测结论：**`pybk_main.py` 和 `main.py` 走的是同一个 C 后端**（都调
`pybk_code.compile_and_run`）。字节码后端的入口是 `pybk_build.py x.pybk -r` → `pyvm.exe`。

---

## 随机子系统（`rd.*` 与 `mp.rand_*`）

**全库只有一个随机源**：`mathplus.c` 核心层的 xorshift128（`mp_rand_u01` / `mp_rand_seed` /
`mp_rand_normal`）。`rd.*` 通过 `#include "mathplus.h"` 委托给它。

这是一次实测后改的，不是重构洁癖。改之前 `rd.*` 走 C 的 `rand()`，量出来三个问题：

| 症状 | 修前 | 修后 |
|---|---|---|
| `rd.float()` 20 万次采样的不同取值个数 | 32693 | 200000 |
| `rd.float()` 可达上限 | 0.999969482421875 | 0.99999867189189 |
| `mp.rand_seed(42)` 能否让 `rd.*` 复现 | 不能 | 能 |
| 有没有 `rd.seed` | 没有 | 有 |

第一行是精度 bug：`rd.float()` 只调一次 `rand()`，而 MinGW 的 `RAND_MAX` 就是 32767，
等于只有 15 位有效精度，`double` 的 53 位用不上。第二行是它永远取不到 1.0 的直接后果。

**为什么统一到 `mathplus.c` 而不是反过来**：那边的随机函数是**核心层的无条件纯 C**，
不碰 Value、不 printf、不 exit，所以 `mathplus.c` 的「可独立编译」性质保住了；
反过来把 xorshift 挪进 `pybook_rt.c` 会让 `mathplus.c` 依赖运行时，破坏它的分层约定。
三处构建（`Makefile`、`build_pyvm.bat`、`pybk_code.py`）都带 `mathplus.c`，链接没问题。

`rd.int` / `rd.float` / `rd.pick` / `rd.shuffle` 的参数、范围、语义**一律没动**
（`rd.int` 仍含两端、`rd.float` 仍 `[0,1)`、`rd.shuffle` 仍原地 Fisher-Yates），
只换了随机源、修了精度、补了播种。

### 分布的正确性怎么验的

**单个采样证明不了分布对不对**。所以每个分布采 20000 次，比对理论均值/标准差 ——
这一步抓到两个不报错、结果看着挺正常的 bug：

- `mp_rand_gamma` 均值 128（理论 2）：`v = 1 + z/sqrt(9d)` 被写成了 `v = 1 + z*sqrt(9d)`，
  `c = 1/sqrt(9d)` 是除数却被当乘数又除了回去，尺度放大 9d 倍。
- `mp_rand_beta` 均值 0.468（理论 0.2857）：Johnk 接受条件 `u*s^(a+b) <= x^a*y^b`
  被硬编码成 `u*s^3 <= x^2*y`。改用 `pow` 后**仍然系统性有偏**（beta(10,1) 实测 0.821、
  理论 0.909），根因是 `X = U1^(1/a)` 把 Gamma 变量截断在 (0,1)，拒绝权重补不回这个截断。
  最终改用 **Gamma 比值法**（`X~Gamma(a,1)`、`Y~Gamma(b,1)` → `X/(X+Y)`），构造上就成立。
  **先在 Python 里对四组参数验证过 mean/std 再写 C**，不在 C 里试错。

还有一个**哨兵约定自己撞车**的例子：分布核心层用「返回 -1 表示参数非法」，
这 7 个分布取值域都 >= 0 所以安全，但 **logistic 以 mu 为中心对称，`mu=0` 时结果可以是负数**，
拿 `r < 0` 去反推参数非法会把合法调用误报成错误。改成调用前显式校验尺度。

对数正态要单独说：它四阶矩极大，20000 个样本时**方差估计本身的噪声就有 ±5%**
（不是实现问题）。用 200000 个样本复核：均值 1.65302 / 理论 1.6487、
std 2.16570 / 2.1612、中位数 1.00595 / 1.0、P90 3.62225 / 3.60222。

### 统计为什么都是纯 `double*`

`mp_median` / `mp_mode` / `mp_quantile` / `mp_cov` / `mp_corr` / `mp_cumsum` / `mp_diff`
的核心层签名全是 `const double *`，绑定层用 `mp_unpack` 把 PYbook 列表展平后调用。
这跟文件里已有的 `mp_mean` / `mp_var` 是同一个套路，也是为了让 `mathplus.c`
保持「核心层不碰运行时、可独立编译」的约定（`gcc -O2 -c mathplus.c -Wall` 零告警）。

`mp_corr` 遇到某个变量是常数时报**「无定义」而不是静默给 0** —— 分母为 0 时那是
「没定义」，不是「不相关」，给 0 会让人得出错误结论。

---

## 基础数学的定义域策略（`mt.*`，`pybook_lib.c`）

`mt.*` 原来 18 个入口，只有 `sin/cos/tan/atan2` 和 `sqrt/pow` —— **`exp` 和 `log` 都没有**，
反三角只剩 `atan2`，双曲一个没有。现补到 40 个（exp/log 族、反三角、双曲、`cbrt`/`hypot`、
`trunc`/`sign`/`fmod`、`is_nan`/`is_inf`）。

一条贯穿的原则：**定义域越界一律 `rt_die` 报三段式，绝不静默返回 NaN**。
`log/log2/log10/log1p` 要正、`asin/acos` 要 [-1,1]、`acosh` 要 ≥1、`atanh` 要 (-1,1)、
`fmod` 除数非零。

理由和 `tb.cholesky` 是同一条：**一个 NaN 顺着后面的运算流下去，到最后根本看不出是哪一步出的问题**。
宁可当场报错，也不让它污染整条链。

三个容易写错的点，实现里都单独注释了：

- **`fmod` 和 `mod` 不是一回事**：`mt.mod` 是 Python 语义（向 -∞ 取整），`fmod` 是 C 语义
  （向 0 截断）。`fmod(-7,3) = -1` 而 `mod(-7,3) = 2`，用错会差一个整数量级。
- **`cbrt` 不能用 `pow(x, 1/3)` 代替**：负数会走复数分支返回 NaN。
- **`expm1` / `log1p` 不是 `expm1 = exp(x)-1` 的别名**：x 极小时后者的 double 结果直接是 0。

验证方式是逐项对拍 **Python 的 `math` 模块**（`_mt_verify.py`）：
30 个值里 21 项逐位相同、9 项相对误差 ≤1e-14。

**一处有意没统一的既有行为**：`mt.*` 的*类型*错误走 `lib_num → lib_die`（无行号、无三段式），
*定义域*错误走 `rt_die`（有行号、三段式）。新函数跟着既有的 `mt.sin`/`mt.sqrt` 保持一致，
没有单造新格式；真要统一得改 `lib_die`，会波及全部既有 `mt.*`/`te.*` 入口。

---

## 线性代数（`pybook_la.c`）

### 为什么分成两层

`pybook_la.h` 和 `mathplus.h` 是同一个套路：`[1] 核心层` 无条件编译，`[2] 绑定层` 用
`#if defined(PYBOOK_RT_H) || defined(LA_RT_BINDING)` 隔开。

这么分不是为了好看，是因为**核心层不 include `pybook_rt.h`、不用 `Value`、不 printf、不 exit**，
于是 `_lacheck.c` 能把 `pybook_la.c` 单独编进去，对着 NumPy 逐项对拍：

```
gcc _lacheck.c pybook_la.c -o _lacheck.exe -O2 -Wall -lm
```

数值错了在接进语言之前就能发现，而不是变成「某个 `.pybk` 程序结果不对」这种难查的现象。

对拍方法上有两条不能省的规矩：

1. **C 侧只把输入矩阵原样 dump 出来**，NumPy 侧读同一份输入算参考值。不让两边各写各的 RNG
   去"生成同一批数"——只要有一边 RNG 写错，就会得到「两边都在算，但输入不同」的现象，排查成本极高。
2. **能写成数学恒等式就直接验证恒等式，不去比单个元素**。QR 的 `Q` 有列符号的自由度，
   逐元素比 `Q`/`R` 只会一直假报警；验 `A=QR` + 正交性 + 上三角性，既能抓住「`Qᵀ` 写反了」
   这种结构性错误，又不会被符号晃到。

**实测：261 项检查全部通过，最大相对误差 2.108e-14**（各算法典型误差：QR `A=QR` 8.5e-16、
Cholesky `A=LLᵀ` 2.0e-16、eig `A·V=V·Λ` 7.4e-15、SVD 奇异值 3.3e-15、det 3.9e-15、inv 3.4e-15）。
覆盖方阵 2/3/5/8/12/20/40、矩形 12×4 / 4×12 / 25×7 / 7×25、对称、对称正定、秩亏 6×2 / 10×3 / 20×5。

对拍过程中抓到三个真 bug（都是推导层面、不报错、不越界，只是结果全错）：

- `la_qr_form_q` 左乘顺序反了（升序得到 `H_{p-1}···H_0`）——症状是 `Q` 看着还挺正交，但 `A=QR` 只在第 0 列成立。
- 单边 Jacobi 的 `t` 差一个符号——症状特别隐蔽：`A = U·S·Vᵀ` 仍然成立（那是构造保证的），只有正交性露馅。
- `la_lu_solve` 里按步长 1 取右端元素，但行主序里右端向量步长是 `nrhs`——`nrhs=1` 恰好蒙对，
  所以 `solve` 单右端一路绿灯，只有 `inv`（nrhs=n）炸成 8e6。

### 算法选择的三个决定

- **`la_lstsq` 刻意走 SVD 而不是 QR**：数值上最准，且欠定（min-norm 解）与秩亏自动截断是同一段代码，
  没有「有损精度」的取舍。
- **`la_svd` 用单边 Jacobi，而不是「先算 `AᵀA` 再求特征值」**：后者会把条件数平方掉。
- **奇异时 LU 仍要把因子矩阵与 `piv` 填满**（只置 0 那一列的乘子），否则调用方没法算秩；
  但 `la_lu` 的返回值仍然标明是否可逆。

### 反复出现的三个约定（照抄 LAPACK 的人会在这里踩）

- LU 的 `piv[k]` 必须**按 k 升序**应用到右端，这是 LAPACK 的 `ipiv` 语义，顺序反了就全错。
- QR 的 `Q = H_0···H_{p-1}` 要**左乘 + k 倒序**累加。
- SVD 输出形状：`U` 是 `m×min(m,n)`、`VT` 是 `min(m,n)×n`，重建式 `A = U·diag(S)·VT`
  （与 LAPACK `dgesvd` / `numpy.linalg.svd` 一致）。`mp.mat_svd` 沿用同一约定，第三项就是 `VT`。

### 两个面：23 个入口

`tb.*` 直接吃真张量，`mp.*` 吃「扁平列表 + 行列数」，但 `mp.*` 内部先用 `la_from_flat()`
包成张量再算，**两边结果必然一致**（`T18_la_mp_flat_ok` 这条回归就是在锁这件事）。

精度传播沿用 `tb.dot` 的规矩：任一输入是 f32 就返回 f32，内部一律按 double 算完再
`rt_tensor_round` 舍入。

### 两个坑

1. **C 后端的函数原型只能靠头文件链带进来**。`pybk_code.py` 生成 `out_*.c` 后单独编译，
   它认识符号靠的是 `pybook_lib.h` 这条 include 链；只写进 `_vm_lib_calls.inc` 的是**前置声明**，
   只服务 VM 后端。所以绑定层原型必须放在 `pybook_la.h`，且 `pybook_lib.h` 要 `#include "pybook_la.h"`。
   另外 `pybook_la.c` 自己也必须在 `#include "pybook_la.h"` **之前**带上守卫块 include `pybook_rt.h`
   （与 `mathplus.c` 第 7~9 行同构），否则被 `-DLA_RT_BINDING` 编译时会报 `unknown type name 'Value'`。
2. **`tb.rank` 只对方阵有效**：它走 LU，而 `la_rank` 的签名只有阶数 `n`。
   NumPy 的 `matrix_rank` 接受矩形矩阵，这里暂不支持（`tb.svd` 可以自己数非零奇异值绕过去）。

---

## `device` 文件头指令（后端 + 线程数）

```
device auto          # 探测一次：有 NVIDIA 卡走 GPU，没有就走 CPU
device cpu           # 显式 CPU，线程数按老规矩自动定
device cpu 8         # 显式 CPU，8 个工作线程
device gpu           # 显式上卡；探测不到卡 → 运行时报错，绝不静默退回 CPU
```

**走「语句」路线，与 `Memoryment` 完全对称**，保证双后端语义一致：

| 阶段 | 文件 | 产物 |
|---|---|---|
| 前端 | `pybk_front.py` `parse_device()` | `DeviceMode(backend, threads, line)`，前置到 `GOING` 开头 |
| C 后端 | `pybk_code.py` | `rt_device_set(backend, threads);` |
| 字节码 | `pybk_bc.py` | opcode `0x37 DEVICE 'BU'`：`[op][backend:u8][threads:u16le]` |
| VM | `pyvm.c` `case_0x37` | 读出两个操作数调同一个 `rt_device_set` |
| 运行时 | `pybook_rt.c` / `pybook_mt.c` / `pybook_tb.c` | `mt_workers()` 的第一优先级来源；`tb.dot` / `tb.lin` 的 GPU 路由读 `rt_device_backend()` |

> ⚠️ `DEVICE` 的操作数布局是 **1 字节 backend + 2 字节小端线程数**，不是「都在末尾」。
> 写字节码时 `buf[pos+1]=backend; set_u16(pos, 2, threads)`；写成 `buf[-1]`/`set_u16(pos,1,…)`
> 会让两个字段串位，反汇编能看出来（`DEVICE 6 256` 而不是 `DEVICE 1 6`）。

**为什么 `gpu` 改成运行时探测**：`gpu` 从「编译期就拒」翻成了「编译期只查语法，
有没有卡交给运行时」。理由是编译期根本无从知道目标机器有没有 NVIDIA 卡——
同一份 `.pybk` 在开发机和没卡的机器上编译结果不该不同。
现在的语义是三条硬规矩：

| 档位 | 有卡 | 没卡 |
|---|---|---|
| `auto` | 走 GPU | 走 CPU |
| `cpu` | 走 CPU | 走 CPU |
| `gpu` | 走 GPU | **运行时报错并退出** |

第三行是重点：用户明写了 `gpu`，静默退回 CPU 等于骗人。报错带「为什么 / 怎么改」。

> 调试钩子：设 `PYBOOK_GPU_DISABLE=1` 可强制当作「没有 GPU」，
> 用来在有卡的机器上验证上面第三行那条语义（用例 `P0_27` 就是这么跑的）。

---

## GPU 后端（`pybook_gpu.c` / `pybook_gpu.h`）

走 **NVIDIA CUDA driver API**，三条设计约束都是踩过坑之后定的：

1. **不链 `cuda.lib`、不 `include cuda.h`**。`LoadLibrary("nvcuda.dll")` + `GetProcAddress`
   取 21 个入口。没装 NVIDIA 驱动的机器照样编译、链接、运行，只是探测返回 0。
   （先例：`pybook_hw3d.c` 的 `wglGetProcAddress`。）
2. **kernel 是手写 PTX 字符串**，驱动自己 JIT。零构建期依赖——不要 `nvcc`、不要 NVRTC、
   不要 CUDA Toolkit。
3. **显存 API 必须取 `*_v2` 版本化符号**。用旧名会一路报 CUDA 201 invalid device context，
   极具误导性（context 明明是好的）。

PTX 的 `.target` 按探测到的真实 CC 生成（不是写死 `sm_61`），`.version` 从 8.7 到 6.0
倒着试，第一个能编译的就算过。换卡不用重编 PYbook。

### 手写 PTX 的坑（都实测踩过）

1. PTX 只认 `//` 行注释且只收 ASCII。块注释、**中文注释**混进 PTX 字符串 → 整份编译失败，
   ptxas 一个字都不说，只回 CUDA 218。
2. `%ntid.x` 不能直接当 `mul` 的操作数，要先 `mov` 进普通 `.b32` 寄存器。
3. `mul.wide.u32` 的第二个操作数不能直接用立即数——**静默算错，不报错**。
   统一用 `cvt.u64.u32` + `shl.b64`。
4. `%ctaid` 是块编号、`%tid` 才是块内线程编号；全局坐标自己算 `blockIdx*blockDim + tid`。
5. `ld.global.f32 f, [%rd1 + %rd5]` 非法（寄存器+寄存器），必须先算进临时寄存器。
6. **`ld.global.f32 f, [%rd]` 里的地址寄存器，每轮都要从 `k` 重算。** 用「单游标 + 偏移寄存器」
   推进的写法在 ptxas 下会**静默只算 k=0 一项**——不报错、不越界，结果全错。
   与已验证的朴素 kernel 同构的「每轮 `mul.wide.u32` 重算」写法一次就过。
7. **C 的基址必须把 `col0` 加进去。** 漏加 → 每个 block 都往 `C[r][0..3]` 写，最后跑的
   block 赢。现象是读到 B 的第 60~63 列（因为 `col0` 最大正好是 60），极易被误判成
   「行映射错了」而查错方向。
8. **发射配置写错，现象和 kernel 写错一模一样。** grid/block 是 host 侧的，换个 tile
   若忘了同步改 `launch_cfg()`，算出来的结果既不越界也不报错，只是全错。

### kernel 结构：为什么是 4×4 + float4

朴素 kernel（每线程算 1 个输出）每次 FMA 要从显存取 2 个标量，访存/计算比
**0.125 FMA/字节**，N=3216 只有 161 GFLOPS —— 1060 FP32 峰值的 3.7%。

现在每线程算 **4 行 × 4 列**（block 16×16，输出块 64×64，grid = `ceil(N/64) × ceil(M/64)`），
一轮 `k` 取 8 个 `ld.global.v4.f32`（128 字节）喂 64 次 FMA，比值 **0.5**，提升 4 倍。

- A 是行主序、`k` 连续，所以 `A[row0+i][k..k+3]` 是**一个** float4；
- B 的相邻 `k` 相隔 N 个元素，取不出一个 float4，只能每个 `k` 各取一个 float4。

边界不靠「补零 kernel」，靠两点：行/列索引用 `min()` 钳到最后一行/最后**四列**
（钳到 `N-1` 会让 float4 错位，`N-1` 不是 4 的倍数），越界的输出用谓词 `st` 关掉。
所以 `M` 可以是任意正数，只有 `N`、`K` 要求是 4 的倍数（16 字节对齐）。

### float32 是一等公民

`RtTensor` 加了 `prec` 字段（`TENSOR_F64=0` / `TENSOR_F32=1`）。**存储仍是 `double` 缓冲，
但 f32 张量所有写入先经 `(double)(float)v` 舍入**，于是缓冲里每个值都严格可被 float32
精确表示，上卡/下卡无损。省一半内存可以将来再加真 `float*` 缓冲，现在不急。

`arith()` 的精度传播规则：任一输入 f32 → 输出 f32。`tb.dot` / `tb.lin` 同样
（`dot_prec()`），**保证 CPU 与 GPU 两条路返回同一种类型**——否则「换个 device 档位
返回类型就变了」，那是会咬人的暗坑。CPU 微内核全程 double 累加，输出是 f32 时
用 `round_out()` 收尾统一舍一遍，维持 f32 不变量。

### 路由规则：什么时候真的上卡

`gpu_dot_try()` 四个条件全满足才上，少一条就留在 CPU——这是「不合适」，不是故障：

1. 后端确实是 GPU；
2. 输入两个张量都是 f32。1060 的 FP64 只有 FP32 的 1/64 吞吐，double 张量上卡不是加速
   是倒退（1060 FP64 = 1/64 FP32），所以让它留在 CPU；
3. `N`、`K` 都能被 4 整除（float4 载入要 16 字节对齐）；`M` 不限，尾巴由 kernel 内部
   `min()` 钳位加载 + 谓词存储处理；
4. `M*N*K >= GPU_DOT_MIN_MAC`（65536），以下搬运+启动开销盖过并行收益。

**一旦上了卡却失败（显存不够、kernel 报错），直接 `tb_die`，不吞**。
回退是设计，报错是真出事——两种情况必须分开。

### 实测（GTX 1060 6GB / CC 6.1 / 驱动 13000 / 12 逻辑处理器）

**正确性**：`_gpucheck.c` 对拍 harness（直接打生产代码 `gpu_sgemm_f32`），
64~3216 全尺寸 + 三组非方阵 + 四组边缘尺寸（68 / 100×132 / 260×68 / 4×4，
专门踩 M、N 的尾巴），**分量后向误差 2.1e-7 ~ 2.7e-7**
（float32 eps 2⁻²⁴ ≈ 6e-8 乘 √K，正是 FMA 与顺序累加的正常差异）。

**性能，N=3216 float32 sgemm**（2·N³ FLOP）：

| 实现 | 最好 | 最好 GFLOPS | 平均 GFLOPS |
|---|---|---|---|
| NumPy 2.4.6 / OpenBLAS，12 线程 | 0.156 s | 425.7 | 369.2 |
| **PYbook `device gpu`（CUDA）** | **0.328 s** | **608.5** | 608.5 |
| PYbook `device cpu`（AVX2+FMA 多线程） | 2.532 s | 78.8 | 78.8 |

GPU 比 NumPy 快 **1.43×**（对最好值）、**1.65×**（对 NumPy 平均值），
比自己 CPU 快 **7.7×**。

kernel-only（不含 double→float 转换与 PCIe 搬运，`_gputile.exe 4x4`）：
**1014 ~ 1178 GFLOPS**（同一个 N=3216 跑几轮，差异来自显卡 boost 波动），
即 1060 FP32 峰值的 **23% ~ 27%**。端到端 608 与 kernel-only 的差距主要是
三张 41 MB 矩阵的 PCIe 往返 + 转换，不是 kernel 本身。

> 上一版（朴素 kernel）在这台机器上是 133 GFLOPS，比 NumPy 慢 3 倍。提升 **4.6×** 全部来自
> 把访存量压下来（float4 向量化），没有用 shared memory、没有用 double buffering。
> 下一步的余量在 kernel 本身（还有 3~4 倍空间）和搬运层（合并 A/B 分块、异步搬运）。

### 遗留产物（有意保留）

| 文件 | 是什么 |
|---|---|
| `_gpucheck.c` | 本模块的对拍 harness：`gcc _gpucheck.c pybook_gpu.c -o _gpucheck.exe -O2` 可独立编译 |
| `_gputile.c` | kernel 迭代 harness，内置朴素 / 1×4 / 4×4+float4 三个 PTX（从 `.ptx` 文件读）+ `probe()` + 尺寸扇形 |
| `_ptx_PTX_*.ptx` | 三个 kernel 的 PTX 纯文本。**改 kernel 直接改这些文件**，diff 一眼能看懂 |
| `_ptxdump.py` | 从 `_gputile.c` 的 C 字符串还原 `.ptx`（现在只用于校验，不再是主线） |
| `_embed_ptx.py` | 把 `_ptx_PTX_4X4.ptx` 转成 C 字符串字面量写回 `pybook_gpu.c`。**搬 kernel 到生产代码只走这一条路**，手敲转义必错 |
| `_gputest.c` | 更早的连线探针 |
| `_ptx_tiled.inc` | 最早的 4×4 寄存器分块归档（无 float4，202 已作废）。三个真 bug 记在文件头：漏行偏移、边界比较拿已乘 4 的值去比 M、寄存器被复用冲掉边界值 |

---

**实测（同一份程序，只改文件头）**：

| 负载 | `cpu 1` | `cpu 12` | 加速 |
|---|---|---|---|
| 300×300 矩阵乘 × 600（C 后端） | 1.394 s | 0.968 s | 1.44× |
| 300×300 矩阵乘 × 600（VM 后端） | 1.020 s | 0.614 s | 1.66× |
| 200 万元素求和 × 200（C 后端） | 1.440 s | 0.731 s | 1.97× |
| 200 万元素求和 × 200（VM 后端） | 1.088 s | 0.387 s | 2.81× |

> 表中为第一次实测。随后又独立跑了一轮，得到 1.64×/1.63×（矩阵乘）与 2.84×/1.64×（归约）——
> **倍数随机器当时的负载波动，量级稳定，别拿这里的第三位有效数字当承诺**。

> **线程数不是越大越好**：100×100 矩阵乘（单次 1e6 次乘加 ÷ 64 块 = 每块仅 1.5 万）实测
> `cpu 12` 比 `cpu 1` **慢一倍以上**——派发 64 块的条件变量同步开销盖过了并行收益。
> 线程数在**大块**负载上才划算。

**换线程数不改结果**：归约类算子固定切 64 块、按块号顺序累加 `parts[]`，位级可复现。
实测 200 万元素求和结果 `3999998000000` 在 `cpu 1` / `cpu 12` / 默认 × C 后端 / VM 后端
全部 6 种组合下完全相同。

---

## VM 的 JIT（`pyvm.exe --jit[=阈值]`）

VM 默认是**纯解释器**（computed-goto 派发，每条字节码一次间接跳转，分支预测永远失手）。
加 `--jit` 后，热函数会被**字节码 → C 重放 → gcc 编成 DLL → `LoadLibrary`** 编译成本地代码，
之后直跳原生。**不传 `--jit` 时行为与改动前逐字一致。**

### 能 JIT 什么

只有**叶子函数**：字节码里不含 `CALL(0x30)`（调用户函数）、不含 `CALL_LIB(0x36)`（调标准库）、
不含未知 opcode 的函数才会被编译，否则永远留给解释器。这样设计是为了彻底规避共享状态分叉。

### ⚠️ 主程序的循环走另一条路上原生

函数靠热计数触发（`CALL(0x30)` 里的 `callee->hot++`）；**主程序 fn 0 永不被 CALL**，
所以它在 `run_module` 入口单独判一次：静态估算 `GOING:` 要执行的指令总量
（循环次数 × 循环体指令数），≥ `JIT_MAIN_MIN_INSN`（2000 万）就把整段编成原生代码，
从入口一路跑到 `JRET`：

```python
GOING:{ rm.around(20000000){ ... } }     # ✓ 估算过门限，加速约 5~6×（mt.* 密集则 72~76×）
func 数到(n){ rm.around(n){ ... } }      # ✓ 函数热计数触发，加速 4.2×
```

估算不足门限的小脚本留在解释器，避免为一个 hello world 付一次编译。
没有做 OSR：决策点固定在主程序入口（此刻它一条指令都还没执行，槽位全是 none），
不做「跑到一半才换栈」。

### 实测（5000 万次热循环 = 200 次调用 × 250000 循环）

| | 时间 |
|---|---|
| 解释器 | 1.850 s |
| **JIT（含编译，`.o` 已缓存）** | **1.122 s** |
| C 后端 exe（纯运行） | 0.759 s |

直接跑原生函数（绕开 gcc 编译）：**0.539 s —— 比解释器快 4.25×，比 C 后端 exe 还快 1.44×**。
JIT 版循环是裸 `goto`，唯一检查是 `sp>=JIT_MAXD`；C 后端还带着 `rt_gc_poll()` 与内存模式调用。

### 编译成本与 `.o` 缓存

JIT 要调 gcc 把 **13 个运行时 `.c` 链进每个 DLL**。全量编译要 13~16 秒，会把运行收益吃光。
所以拆成三步，运行时那 13 个 `.o` 缓存在 `build/.jit/rt/`（只在缺失/过期时重编）：

| | 冷启动 | 热启动 |
|---|---|---|
| 全量编译（改造前） | 13.560 s | 13.157 s |
| **`.o` 缓存（改造后）** | 16.875 s | **1.122 s** |

**热启动省 12.04 秒（11.7×）。** 冷启动变慢是 13 次 `gcc` spawn 的固定开销，换来的是热启动的质变。

`PYVM_JIT_VERBOSE=1` 看日志；`pybktl clean` 可清 `build/.jit/`。详见 [`JIT_DESIGN.md`](JIT_DESIGN.md)。

---

## 构建

- **构建 VM**：`build_pyvm.bat`（Windows，自动探测 gcc）或 `make`（跨平台）。产物 `pyvm.exe`。
- **前置依赖**：MinGW-w64 gcc（仓库已自带 `发布打包_102/mingw64`，无需另装）；`hw3d` 的 3D 需要 SDL2。
- **从 `.pybk` 跑起来**：`python pybk_main.py 程序.pybk`（VM 后端，无需 gcc）/ 加 `--check` 仅语法检查。

---

## 版本

- **单一真相源**：`CHANGELOG.md` + `README.md` 顶部版本号（当前 **1.0.5.2**）。
