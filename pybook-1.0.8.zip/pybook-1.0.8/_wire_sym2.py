# _wire_sym2.py —— 把 sym.求解 / sym.格式 接进四端（front / code / vm inc / 头注）。
# 一次性补丁：幂等（打过就别再打），每处断言 count==1。
# 核心层 pybook_sym.c（sym_core_solve/sym_core_format + rt_lib_sym_solve/rt_lib_sym_format 绑定）
# 与 pybook_sym.h 声明、pybook_lib.h include、build_pyvm.bat 编译项此前已落，这里只做注册接线。
import io
import sys

EOL = '\n'   # 仓库全是 LF（2026-10-17 实测 grep -c $'\r' == 0）

# ---------------- 1. 前端 LIB_CALLS（pybk_front.py） ----------------
F = 'pybk_front.py'
s = io.open(F, encoding='utf-8').read()
if "'sym.求解'" in s:
    print('%s 已有 sym.求解，跳过' % F)
else:
    a = "    'sym.相等': 2," + EOL
    assert s.count(a) == 1, 'front 锚点找不到或不唯一'
    new = a + "    'sym.求解': 2,        # (方程, 变量)：解单变量多项式，升序实根" + EOL \
             + "    'sym.格式': 2,        # (表达式, 模式)：plain/latex/unicode 渲染" + EOL
    s = s.replace(a, new, 1)
    io.open(F, 'w', encoding='utf-8', newline='').write(s)
    print('%s 已接线：+sym.求解 +sym.格式' % F)

# ---------------- 2. 后端 LIB_C_NAMES（pybk_code.py） ----------------
F = 'pybk_code.py'
s = io.open(F, encoding='utf-8').read()
if "'rt_lib_sym_solve'" in s:
    print('%s 已有 rt_lib_sym_solve，跳过' % F)
else:
    a = "        'sym.相等': 'rt_lib_sym_equal'," + EOL
    assert s.count(a) == 1, 'code 锚点找不到或不唯一'
    new = a + "        'sym.求解': 'rt_lib_sym_solve'," + EOL \
             + "        'sym.格式': 'rt_lib_sym_format'," + EOL
    s = s.replace(a, new, 1)
    io.open(F, 'w', encoding='utf-8', newline='').write(s)
    print('%s 已接线：+rt_lib_sym_solve +rt_lib_sym_format' % F)

# ---------------- 3. VM 库调用表（_vm_lib_calls.inc） ----------------
F = '_vm_lib_calls.inc'
N_OLD = 268
t = io.open(F, encoding='utf-8').read()
if 'rt_lib_sym_solve' in t:
    print('%s 已有 sym.求解，跳过' % F)
else:
    # ① 前置声明
    a = 'Value rt_lib_sym_equal(Value, Value);' + EOL
    assert t.count(a) == 1, 'inc 声明锚点找不到或不唯一'
    t = t.replace(a, a + 'Value rt_lib_sym_solve(Value, Value);' + EOL
                     + 'Value rt_lib_sym_format(Value, Value);' + EOL, 1)

    # ② 分发表行
    b = '    {"sym.相等", 2, (void *)rt_lib_sym_equal},' + EOL
    assert t.count(b) == 1, 'inc 表行锚点找不到或不唯一'
    t = t.replace(b, b + '    {"sym.求解", 2, (void *)rt_lib_sym_solve},' + EOL
                     + '    {"sym.格式", 2, (void *)rt_lib_sym_format},' + EOL, 1)

    # ③ 计数宏 + 头注（头注第 1 行「268 个库调用」）
    c1 = '#define G_LIB_CALLS_N %d' % N_OLD
    assert t.count(c1) == 1, '计数宏找不到'
    t = t.replace(c1, '#define G_LIB_CALLS_N %d' % (N_OLD + 2), 1)
    h = '生成：%d 个库调用' % N_OLD
    assert t.count(h) == 1, '头注计数找不到'
    t = t.replace(h, '生成：%d 个库调用' % (N_OLD + 2), 1)

    io.open(F, 'w', encoding='utf-8', newline='').write(t)
    print('%s 已接线：+2 入口（%d -> %d）' % (F, N_OLD, N_OLD + 2))

# ---------------- 4. 存在性校验（缺哪项报哪项，退出码 1） ----------------
CHECKS = [
    ('pybook_sym.c', ['char *sym_core_solve(', 'char *sym_core_format(',
                      'Value rt_lib_sym_solve(Value ev, Value varv)',
                      'Value rt_lib_sym_format(Value ev, Value modev)'], '核心+绑定层'),
    ('pybook_sym.h', ['sym_core_solve', 'sym_core_format',
                      'rt_lib_sym_solve(Value', 'rt_lib_sym_format(Value'], '头文件声明'),
    ('pybook_lib.h', ['#include "pybook_sym.h"'], 'pybook_lib.h'),
    ('build_pyvm.bat', ['pybook_sym.c', '-DSYM_RT_BINDING'], 'VM 构建脚本'),
    ('pybk_front.py', ["'sym.求解': 2", "'sym.格式': 2"], '前端 LIB_CALLS'),
    ('pybk_code.py', ["'sym.求解': 'rt_lib_sym_solve'", "'sym.格式': 'rt_lib_sym_format'"], '后端 LIB_C_NAMES'),
    ('_vm_lib_calls.inc', ['#define G_LIB_CALLS_N 270', '{"sym.求解", 2, (void *)rt_lib_sym_solve}',
                           '{"sym.格式", 2, (void *)rt_lib_sym_format}', '270 个库调用'], 'VM 库调用表'),
]
bad = 0
for f, needles, what in CHECKS:
    try:
        s = io.open(f, encoding='utf-8').read()
    except OSError as e:
        print('MISS %-22s 打不开：%s' % (what, e))
        bad += 1
        continue
    for nd in needles:
        if nd not in s:
            print('MISS %-22s 缺 [%s]' % (what, nd))
            bad += 1
if bad:
    print('校验未过（%d 处缺失）' % bad)
    sys.exit(1)
print('四端校验全过：sym.求解 / sym.格式 已注册（268 -> 270）')
