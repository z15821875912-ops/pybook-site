"""独立校验 mm.draw_away 产出的 PNG：不走被测代码的读回路径。
逐块核 CRC32 -> 解 IDAT 验 Adler32 -> 反滤波 -> 跟期望像素逐格比。
（PNG 的 CRC 是流式的，编码器里多插一次异或收尾就会全错，文件还在但没人打得开。）"""
import struct, zlib, sys
sys.stdout.reconfigure(encoding='utf-8')

PAL = {'r': (229, 57, 53), 'g': (67, 160, 71), 'b': (66, 133, 244), 'w': (250, 250, 250)}
GRID = ["rrggbb", "rrrggg", "ggggbb", "ggggrr", "bbbwwr", "bbwwrr", "wwrrgg"]
SCALE = 8

path = sys.argv[1] if len(sys.argv) > 1 else '_png回归检查.png'
raw = open(path, 'rb').read()
fail = 0


def ck(cond, msg):
    global fail
    print(('  OK  ' if cond else '  FAIL') + '  ' + msg)
    if not cond:
        fail += 1


print('校验 %s（%d 字节）' % (path, len(raw)))
ck(raw[:8] == b'\x89PNG\r\n\x1a\n', '文件签名 8 字节正确')

# ---- 逐块核 CRC32 ----
i, chunks, idat = 8, [], b''
while i + 8 <= len(raw):
    ln = struct.unpack('>I', raw[i:i + 4])[0]
    typ = raw[i + 4:i + 8]
    data = raw[i + 8:i + 8 + ln]
    crc = struct.unpack('>I', raw[i + 8 + ln:i + 12 + ln])[0]
    calc = zlib.crc32(typ + data) & 0xFFFFFFFF
    ck(calc == crc, '块 %s 的 CRC32 正确（声明 %08X，实算 %08X）'
       % (typ.decode('ascii', 'replace'), crc, calc))
    chunks.append(typ.decode('ascii', 'replace'))
    if typ == b'IHDR':
        w, h, depth, ctype = struct.unpack('>IIBB', data[:10])
    if typ == b'IDAT':
        idat += data
    i += 12 + ln

ck(chunks[0] == 'IHDR', '第一个块是 IHDR')
ck(chunks[-1] == 'IEND', '最后一个块是 IEND')
ck(depth == 8 and ctype == 6, '位深 8、颜色类型 6(RGBA)')

# ---- 解 IDAT，Adler32 由 zlib 自己核 ----
try:
    rawpix = zlib.decompress(idat)
    ck(True, 'IDAT 能被 zlib 解开（%d 字节，内含 Adler32 校验）' % len(rawpix))
except Exception as e:
    ck(False, 'IDAT 解压失败：%r' % (e,))
    raise SystemExit(1)

W, H = len(GRID[0]) * SCALE, len(GRID) * SCALE
ck((w, h) == (W, H), '尺寸应为 %dx%d，实为 %dx%d' % (W, H, w, h))
ck(len(rawpix) == H * (W * 4 + 1), '反滤波前每行前置 1 字节，过滤全为 0')

# ---- 像素比对（过滤字节全是 0，所以不用做反滤波算法）----
bad = 0
for y in range(H):
    assert rawpix[y * (W * 4 + 1)] == 0, '第 %d 行的过滤字节应为 0' % y
    gy = y // SCALE
    for x in range(W):
        r, g, b = PAL[GRID[gy][x // SCALE]]
        o = y * (W * 4 + 1) + 1 + x * 4
        if (rawpix[o], rawpix[o + 1], rawpix[o + 2]) != (r, g, b):
            bad += 1
ck(bad == 0, '全部 %d 个像素颜色与调色板一致（不符 %d 个）' % (W * H, bad))

print('\n%s' % ('全部通过' if fail == 0 else '失败 %d 项' % fail))
raise SystemExit(1 if fail else 0)
