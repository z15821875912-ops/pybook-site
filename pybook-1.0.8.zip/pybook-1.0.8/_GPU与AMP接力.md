# GPU 通路扩展 + F16 混合格式：接力设计（PYbook AI 栈最后两块）

> 五缺口账本：conv2d+pooling ✅ / LR 调度 ✅ / Dropout+BN+LN ✅（含独立验收）/ 
> 自动微分+优化器 ✅ / **GPU 通路扩展 ⬜ / F16 混合格式 ⬜**。
> 这两项是 C 运行时工程，不是"一口气"量级——本文是给下一个车道的施工图。

## 开工前纪律（血税换来的）
1. 开工前 `git status` + 看 pybook_rt.c / pybook_lib.c / pybook_gpu.c 的 mtime——
   2026-10-17 17:24 rt.c 曾处于半保存编译不过状态约数分钟。
2. 一个车道一次只动一个 C 文件；四表面（pybk_front LIB_CALLS / pybk_code
   LIB_C_NAMES+gen_protos / pybook_lib.h / _vm_lib_calls.inc+重建 pyvm）同一批提交。
3. 改 RtTensor 结构是核弹级：F64=0/F32=1 已占用 prec 槽，动存储布局前先跑
   全量对拍基线（见下）留档。

## A. GPU 通路扩展（matmul → conv2d/pool/norm）
- 现状核实点：GPU 通路现仅 matmul，先 `grep -rn "gpu" pybook_*.c` 摸清现有
  调度方式（哪层分派、显存怎么管），再谈扩展。
- 优先级：conv2d（算力大头）> maxpool/avgpool > batchnorm/layernorm > 其余。
- 分派策略建议：算子级 fallback——GPU 路径失败/不可用自动回 CPU，调用方无感；
  张量常驻显存与否先不做（每算子拷入拷出，简单正确优先）。
- **验收直接复用现成锚点**：卷积对拍.pybk（5 项）、算子对拍.pybk（10 项）、
  卷积预言机、卷积库演示——GPU 路径跑同一套锚点逐数比对即验收，
  这是本轮做独立锚点的最大红利，零额外验收成本。

## B. F16 混合格式 + 梯度缩放
- 顺序（每步可独立验收）：
  1. `prec=2`（F16）存储 + `tb.to_fp16 / tb.to_fp32` 转换算子 +
     往返精度锚点（F16 可精确表示的小整数/半格点值逐位断言）。
  2. matmul/conv2d 两条 F16 计算内核，其余算子保持 F32（混合策略：
     前向激活 F16、累加 F32、参数与梯度 F32——即 OCP/AMP 惯例）。
  3. 动态 loss scale：scale 初值 2^16，溢出（inf/nan 检测）减半、
     连续 N 步无溢出翻倍；`tb.sgd/adam` 加 scale 参数或包一层
     `缩放梯度 → 步 → 缩回去`。
- 验收：小 MLP/conv 训练 E2E（神经网络演示.pybk 改 F16 版）loss 不发散、
  与 F32 版末损同量级；往返锚点全过。
- 注意 VM：`ret 空` 会挂（见 _语法新发现.md §7，用 ret 0）；
  新算子记得到 _vm_lib_calls.inc 注册并重建 pyvm。

## 已就位的验收资产（双后端全绿，直接当回归基线）
一键回归：`pybktl airegress --save`（跑下表全部资产×双后端，存档到 _验收基线/）。
动编译器/rt/lib/GPU 之前跑一次存档，改完再跑对档。

| 资产 | 项数 | 覆盖 |
|---|---|---|
| 卷积对拍.pybk | 5 | conv2d/dk/dx、maxpool/avgpool 前向，三方逐数 |
| 算子对拍.pybk | 10 | 池化dx、BN/LN 前向+dx、dropout 三态 |
| 卷积库演示.pybk | 9 | 纯 PYbook 卷积库全 API |
| 神经网络演示.pybk | — | XOR E2E（动量 1.4e-13 / 亚当 8e-25；VM 跳过） |
| _卷积验收/卷积预言机.pybk | 7 | 纯 PYbook 卷积/池化锚点 |

## A 已落地（2026-10-17 GPU 车道本轮交付）
- **GPU conv2d**：PTX 内核 `conv2d`（独立模块 compile_conv，编不过自动降级 CPU，
  不堵 sgemm）；路由 gpu_conv_try 四条件（device gpu / F32 / pad=0 /
  O·OH·OW·I·kh·kw ≥ GPU_CONV_MIN_MAC=65536）。实测 384² I4 O4 K8x8 S2：
  **GPU 16ms vs CPU 547ms（约 30 倍）**，恒等核双后端逐位为 0。
- **GPU maxpool/avgpool**：同模块 `maxpool`/`avgpool` entry（可选降级）；
  2048² K4x4 S4 正确（max 逐位精确，avg 4e-8=f32 噪声）。注意：池化是带宽瓶颈，
  数据每次过卡，这个规模 GPU 不比 CPU 快——存在意义是"通路全 + 未来常驻显存"。
- 调试：`PYBOOK_GPU_TRACE=1` 环境变量打印上卡轨迹。
- 对拍资产：`_gpu卷积对拍.pybk` / `_cpu卷积对拍.pybk`（孪生，device 语句区分）。
- airegress 双后端全绿，基线在 _验收基线/。

## B F16/AMP 现状（被 sym 车道阻塞）
- F16 转换算子（tb.to_fp16/to_fp32）需要四表面注册，而 pybk_front.py/pybk_code.py
  正被 sym 车道高频编辑（19:30 仍在写）——注册动作等它安静后一批做。
- 真正的 F16 存储（prec=2）是 RtTensor 手术（rt.c/h，数学车道），按本文档顺序做。

## 数据集下载情报（2026-10-18 实测，值千金）
- **国际出口总带宽 ~15KB/s 封顶**（toronto/S3/jsDelivr 全一样），多连接并行不分摊
  ——国际源拉大数据集不可行。
- **国内快道：dataset.bj.bcebos.com（百度 BOS）**，实测 5.4MB/s，170MB 的
  CIFAR-10 **3.3 秒**。Paddle 系数据集都在这（cifar-10-python.tar.gz 实测存在；
  binary 版 404）。找数据先试 BOS/国内源，再想国际线。
- jsDelivr 单文件 ≤20MB 可用（fastly 镜像支持 -C - 断点续传，mnist idx 就这么拉的）。
- 本机有 numpy 2.4.6（pickle 版 CIFAR 可解）；PYBT 转换器见 _cifar转换.py/_mn转换.py。

## CIFAR-10 里程碑（2026-10-18）
- 5 万×3072 F32 端到端：载入→3072-256-10 MLP→全梯度链→Adam→评估，原生 6.2s/轮。
- GPU 孪生同跑（lin 的 dot 39G MAC 达 GPU_CONV... GPU_DOT_MIN_MAC 门槛，路由成立），
  6.6s/轮——无显存常驻设计下搬运吃掉收益，属预期；"结果正确性"与"加速"是两件事。
- 裸像素 MLP 40 轮 37.5% 仍在上行（公开基线 50-55%，差在全批收敛慢+无增广）；
  终局长训见 _cifar_final.log。
- 待办：gpu_dot_try 补 PYBOOK_GPU_TRACE 轨迹（conv/pool 有、dot 没有）；
  conv 反向链（dx/dk/db）上卡 + minibatch 切片训练 = CNN 战场，排在 F16 之后。

## CNN 里程碑收官（2026-10-18 停在 93.7%，随时可续）
- **PYbook 第一个 CNN**：mnist_cnn.pybk（conv3x3 1→8 → relu → conv3x3 步长2 8→16 → relu
  → lin 2304→10 → softmax → 交叉熵 → Adam），5 轮即 **93.68%**（MLP 10 轮 = 97.18%
  在 MNIST 上接近天花板，CNN 上限 99%+，续训只需 `python pybk_main.py mnist_cnn.pybk`
  ——检查点 cnn_ckpt.bin 已在盘上）。
- **批量 conv 全链落地**：4D (N,I,H,W) 语义贯通 fwd/dx/dk/db + GPU 内核（批次内环）；
  批量 vs 逐图三连 0 偏差；airegress 全绿（2D 零回归）。
- 配套 4D 基建：at/set_at 元素视图、rows_of/cols_of 前积/末维、mul 总量扁平、
  lin/tr/lin_dx lin 视图、tensor_flat/slice 保维。
- **未决**：GPU 批量 conv vs CPU 单图对照有 0.256 偏差（f32-vs-f64 解释不了，
  疑 GPU 批量内核小 bug，待 GPU-vs-GPU 对照排查）；GPU conv 内核未加 mt 并行。
- RL 车道（他人）：REINFORCE 摆杆 93% 满分率（纯 PYbook 手搓梯度，13 秒/千回合）
  ——AI 栈首次跑强化学习，其 7 条新语言坑见 _rl_摆杆训练.pybk 头注释。
- 新工具：`pybktl hottable`（PID 17884 watcher 攒事件，10 秒轮询）——
  改哪先看排行榜；本文件的更新会被它记事件。
