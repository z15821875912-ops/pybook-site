# -*- coding: utf-8 -*-
"""_sym4_patch.py —— sym.极限 / sym.级数 核心层+绑定层落进 pybook_sym.c/.h。
幂等 count==1，二进制读写保行尾（仓库全 LF）。"""
import io, sys

def apply(s, label, old, new):
    n = s.count(old)
    if n != 1:
        sys.stderr.write('FAIL [%s] count=%d\n' % (label, n)); sys.exit(1)
    s = s.replace(old, new, 1)
    print('ok  ' + label)
    return s

MARK = 'sym_core_limit(const char *expr'

# ================= 1) pybook_sym.c：核心层（插在绑定层注释前） =================
CORE = r'''
/* ==================== 极限与级数（sym.极限 / sym.级数） ==================== */

/* ---- 点的解析：数字 / pi / e / 算式；inf 系列字符串 ----
 * 返回 1=有限点（*pt 出值）；2=无穷（*sgn 出 ±1）；0=失败（err 有文案）。 */
static int parse_point(const char *s, double *pt, int *sgn, char *err, size_t errsz)
{
    const char *t = s;
    size_t n;
    char buf[128];
    Arena ar = {0};
    Node *pn;
    double v;
    int ok;

    while (*t == ' ' || *t == '\t') t++;
    n = strlen(t);
    while (n > 0 && (t[n-1]==' '||t[n-1]=='\t'||t[n-1]=='\n'||t[n-1]=='\r')) n--;
    if (n == 3 && strncmp(t, "inf", 3) == 0) { *sgn = 1; return 2; }
    if (n == 4 && strncmp(t, "+inf", 4) == 0) { *sgn = 1; return 2; }
    if (n == 4 && strncmp(t, "-inf", 4) == 0) { *sgn = -1; return 2; }
    if (n == 3 && (unsigned char)t[0]==0xE2 && (unsigned char)t[1]==0x88 &&
        (unsigned char)t[2]==0x9E) { *sgn = 1; return 2; }              /* "∞" */
    if (n == 4 && (unsigned char)t[0]=='-' && (unsigned char)t[1]==0xE2 &&
        (unsigned char)t[2]==0x88 && (unsigned char)t[3]==0x9E) { *sgn = -1; return 2; }  /* "-∞" */
    if (n == 0 || n >= sizeof buf) {
        if (err) snprintf(err, errsz,
            "第三个参数（点）看不懂：\"%s\"——写个数字、pi、e 或算式，无穷写 inf", s);
        return 0;
    }
    memcpy(buf, t, n);
    buf[n] = 0;
    pn = compile1(buf, &ar, err, errsz);
    if (!pn) { ar_free(&ar); return 0; }
    ok = eval_node(pn, NULL, NULL, 0, &v, NULL, 0);
    ar_free(&ar);
    if (!ok || !isfinite(v)) {
        if (err) snprintf(err, errsz,
            "第三个参数（点）看不懂：\"%s\"——写个数字、pi、e 或算式，无穷写 inf", s);
        return 0;
    }
    *pt = v;
    return 1;
}

/* ---- 极限专用求值：单变量绑到 pt ----
 * 除 0 不报错，按 IEEE 出 inf/nan（0/0=nan、∞/∞=nan，供洛必达判定未定式）；
 * 定义域错误（log<=0 / sqrt<0 / asin|acos 越界 / 负底非整数次幂）返回 0。
 * 公式里出现别的变量时该变量按 nan 参与运算（调用方已前置挡掉）。 */
static int eval_lim(Node *n, const char *var, double pt, double *out)
{
    double a = 0, b = 0;
    if (!n) return 0;
    switch (n->kind) {
    case N_NUM: *out = n->num; return 1;
    case N_CONST:
        *out = strcmp(n->str, "pi") == 0 ? 3.14159265358979323846 : 2.71828182845904523536;
        return 1;
    case N_VAR:
        *out = (strcmp(n->str, var) == 0) ? pt : NAN;
        return 1;
    case N_NEG:
        if (!eval_lim(n->a, var, pt, &a)) return 0;
        *out = -a;
        return 1;
    case N_ADD: case N_SUB: case N_MUL: case N_DIV: case N_POW:
        if (!eval_lim(n->a, var, pt, &a)) return 0;
        if (!eval_lim(n->b, var, pt, &b)) return 0;
        switch (n->kind) {
        case N_ADD: *out = a + b; return 1;
        case N_SUB: *out = a - b; return 1;
        case N_MUL: *out = a * b; return 1;
        case N_DIV: *out = a / b; return 1;      /* IEEE：0/0=nan、x/0=±inf */
        default:
            *out = pow(a, b);
            if (!isfinite(*out) && a < 0) return 0;   /* 负底非整数次幂不是实数 */
            return 1;
        }
    case N_FUNC: {
        int id = fn_id(n->str);
        if (!eval_lim(n->a, var, pt, &a)) return 0;
        switch (id) {
        case F_SIN: *out = sin(a); return 1;
        case F_COS: *out = cos(a); return 1;
        case F_TAN: *out = tan(a); return 1;
        case F_ASIN: if (a < -1 || a > 1) return 0; *out = asin(a); return 1;
        case F_ACOS: if (a < -1 || a > 1) return 0; *out = acos(a); return 1;
        case F_ATAN: *out = atan(a); return 1;
        case F_SINH: *out = sinh(a); return 1;
        case F_COSH: *out = cosh(a); return 1;
        case F_TANH: *out = tanh(a); return 1;
        case F_EXP: *out = exp(a); return 1;
        case F_LOG: if (a <= 0) return 0; *out = log(a); return 1;
        case F_SQRT: if (a < 0) return 0; *out = sqrt(a); return 1;
        case F_ABS: *out = fabs(a); return 1;
        }
        return 0;
    }
    }
    return 0;
}

/* 单侧探针：把 var 换成 x 求值（定义域外返回 0）。对拍与佐证共用。 */
static int probe_one(Arena *ar, Node *n, const char *var, double x, double *out)
{
    Node *s = subst_node(ar, n, var, nd_num(ar, x));
    if (!s) return 0;
    return eval_lim(s, var, x, out);
}

/* ---- 有限点：代入 + 洛必达 ----
 * 关键纪律：洛必达是「分子分母各自求导」，不是对商整体求导；而且只对真未定式
 * （0/0、∞/∞，IEEE 下都出 nan）用——5/0 出 inf 是真发散，x*sin(1/x) 出 nan 是
 * 内部乱抖，滥用洛必达会算出假答案（经典反例：1/x 在 0 处"洛"出 0）。 */
static int limit_finite(Arena *ar, Node *n, const char *var, double pt,
                        double *out, char *err, size_t errsz)
{
    Node *num = n, *den = nd_num(ar, 1);
    int iter;
    double q = 0, vn = 0, vd = 1;

    for (iter = 0; iter <= 8; iter++) {
        Node *sn = subst_node(ar, num, var, nd_num(ar, pt));
        Node *sd = subst_node(ar, den, var, nd_num(ar, pt));
        Node *dn, *dd;
        if (!sn || !sd) {
            if (err) snprintf(err, errsz, "代入时内存不足");
            return 0;
        }
        if (!eval_lim(sn, var, pt, &vn) || !eval_lim(sd, var, pt, &vd)) {
            if (err) snprintf(err, errsz,
                "把 %s = %.10g 代进去之后，函数在那附近没定义（定义域越界）"
                "——极限可能还存在，但第一版看不出来", var, pt);
            return 0;
        }
        q = vn / vd;
        if (isfinite(q)) { *out = q; return 1; }
        if (isnan(q) && ((vn == 0 && vd == 0) || (isinf(vn) && isinf(vd)))) {
            dn = diff(ar, num, var);
            dd = diff(ar, den, var);
            if (!dn || !dd) {
                if (err) snprintf(err, errsz,
                    "这是个未定式，但洛必达法则要求的那一步求导没做出来"
                    "（比如 abs 在 0 处不可导）");
                return 0;
            }
            num = dn;
            den = dd;
            continue;
        }
        break;
    }
    if (isinf(q)) {
        /* 声称发散前先两侧探数：探测却收敛到一块儿，说明有 IEEE 陷阱，不敢下结论 */
        double pa, pb, h = 1e-6 * (1 + fabs(pt));
        if (probe_one(ar, n, var, pt + h, &pa) && probe_one(ar, n, var, pt - h, &pb) &&
            fabs(pa - pb) <= 1e-3 * (1 + fabs(pa))) {
            if (err) snprintf(err, errsz,
                "符号上看是发散，但两侧数值探测却收敛到一块儿（%.10g 与 %.10g）"
                "——可能是 1^inf、inf*0 这类 IEEE 陷阱，第一版认输", pa, pb);
        } else {
            if (err) snprintf(err, errsz,
                "极限不存在：%s 趋近 %.10g 时函数趋于无穷——左右两侧要分开看，"
                "第一版不分侧", var, pt);
        }
        return 0;
    }
    if (vn == 0 && vd == 0) {
        if (err) snprintf(err, errsz,
            "0/0 型未定式，洛必达法则迭代 8 次还没定下来"
            "（可能是更复杂的未定式，第一版认输）");
    } else if (isinf(vn) && isinf(vd)) {
        if (err) snprintf(err, errsz,
            "∞/∞ 型未定式，洛必达法则迭代 8 次还没定下来"
            "（可能是更复杂的未定式，第一版认输）");
    } else {
        if (err) snprintf(err, errsz,
            "把 %s = %.10g 代进去，式子里抖出了 nan（比如 sin(1/x) 乘 x 这类"
            "在零点附近乱抖的）——极限可能还存在（夹逼可能逼得出来），但第一版看不出来",
            var, pt);
    }
    return 0;
}

/* ---- 无穷远：±1e8/1e9/1e10 三点外推 ----
 * 相邻相对变化 ≤1e-6 判收敛；连续 10 倍暴涨判发散；否则（振荡/收敛极慢）认输。
 * 数值近似，不是符号计算——文档里如实写明。 */
static int limit_inf(Arena *ar, Node *n, const char *var, int sgn,
                     double *out, char *err, size_t errsz)
{
    static const double M[3] = { 1e8, 1e9, 1e10 };
    double v[3];
    int i;
    for (i = 0; i < 3; i++) {
        double x = sgn * M[i];
        if (!probe_one(ar, n, var, x, &v[i])) {
            if (err) snprintf(err, errsz,
                "在很大的数（%.0g）处函数没定义——无穷远的极限看不出来，第一版认输", x);
            return 0;
        }
    }
    if (isinf(v[0]) && isinf(v[1]) && isinf(v[2])) {
        if (err) snprintf(err, errsz,
            "极限不存在：函数随 %s 趋于无穷而发散（数值上直接溢成无穷）", var);
        return 0;
    }
    if (fabs(v[1]) > 10 * fabs(v[0]) && fabs(v[2]) > 10 * fabs(v[1])) {
        if (err) snprintf(err, errsz,
            "极限不存在：函数随 %s 趋于无穷而发散（数值上越涨越疯）", var);
        return 0;
    }
    if (fabs(v[2] - v[1]) <= 1e-6 * (1 + fabs(v[2])) &&
        fabs(v[1] - v[0]) <= 1e-6 * (1 + fabs(v[1]))) {
        *out = v[2];
        return 1;
    }
    if (err) snprintf(err, errsz,
        "在无穷远处定不下来（数值上在振荡或收敛极慢）——第一版只做数值外推，认输");
    return 0;
}

/* 数值对拍：pt±h 两侧探点，探到的侧必须全部落在答案 1e-4 相对容差内，且至少
 * 探到一侧（某一侧定义域外不算失败）。挡「符号算错」。 */
static int limit_anti(Arena *ar, Node *n, const char *var, double pt, double v)
{
    double h = 1e-6 * (1 + fabs(pt));
    double pa, pb;
    int oka = -1, okb = -1;
    if (probe_one(ar, n, var, pt + h, &pa))
        oka = (fabs(pa - v) <= 1e-4 * (1 + fabs(v)));
    if (probe_one(ar, n, var, pt - h, &pb))
        okb = (fabs(pb - v) <= 1e-4 * (1 + fabs(v)));
    if (oka < 0 && okb < 0) return 0;      /* 两侧都没定义：不敢认这份答案 */
    if (oka == 0 || okb == 0) return 0;    /* 探到的侧必须全过 */
    return 1;
}

/* 数值→小分母分数（dens 1..64，相对 1e-6 内才认）：数值外推的答案和 IEEE 噪声
 * （sin(pi)=1.2e-16）靠这个回到 "2"、"0" 这类干净形式；认不亲返回 0。 */
static int snap_frac(double v, Frac *out)
{
    int d;
    double n;
    if (!isfinite(v) || fabs(v) > 1e12) return 0;
    for (d = 1; d <= 64; d++) {
        n = floor(v * d + 0.5);
        if (fabs(v - n / d) <= 1e-6 * (1 + fabs(v))) {
            *out = fr_norm((long long)n, d);
            return out->den != 0;
        }
    }
    return 0;
}

/* 极限值格式化：尽量收成整数/小分母分数，收不成 %.10g。 */
static char *fmt_limit_val(double v)
{
    Frac f;
    SB b;
    char buf[48];
    if (fr_from_double(v, &f) || snap_frac(v, &f)) {
        sb_init(&b);
        fmt_frac(f, buf, sizeof buf);
        sb_puts(&b, buf);
        return b.p;
    }
    sb_init(&b);
    snprintf(buf, sizeof buf, "%.10g", v);
    sb_puts(&b, buf);
    return b.p;
}

/* 极限：expr 在 var → point 处的极限。point 可写数字/pi/e/算式，或 inf/-inf。
 * 有限点：代入 + 洛必达（只对 0/0、∞/∞ 真未定式用），答案过数值对拍才收；
 * 无穷点：大数值外推（数值近似，非符号计算）。失败返回 NULL（err 有文案）。 */
char *sym_core_limit(const char *expr, const char *var, const char *point,
                     char *err, size_t errsz)
{
    Arena ar = {0};
    Node *n;
    char *names[64];
    int nn = 0, i, ps, sgn = 1, r;
    double pt = 0, v = 0;
    char *out;

    if (bad_var_name(var, err, errsz)) return NULL;
    ps = parse_point(point, &pt, &sgn, err, errsz);
    if (ps == 0) return NULL;
    n = compile1(expr, &ar, err, errsz);
    if (!n) { ar_free(&ar); return NULL; }
    collect_vars(n, names, &nn, 64);
    for (i = 0; i < nn; i++)
        if (strcmp(names[i], var) != 0) {
            if (err) snprintf(err, errsz,
                "公式里还有变量 %s——sym.极限 一次只取一个变量的极限"
                "（可以先用 sym.替换 把别的变量换成具体数）", names[i]);
            ar_free(&ar);
            return NULL;
        }
    r = (ps == 2) ? limit_inf(&ar, n, var, sgn, &v, err, errsz)
                  : limit_finite(&ar, n, var, pt, &v, err, errsz);
    if (!r) { ar_free(&ar); return NULL; }
    if (ps == 1 && !limit_anti(&ar, n, var, pt, v)) {
        if (err) snprintf(err, errsz,
            "符号答案（%.10g）和两侧数值对拍不一致——第一版不敢认，交回给你", v);
        ar_free(&ar);
        return NULL;
    }
    out = fmt_limit_val(v);
    ar_free(&ar);
    return out;
}

/* ---- 泰勒展开（sym.级数） ---- */

/* 阶乘（0..12：12! = 479001600，int64 无压力；与 sym.求解 的 12 次上限对齐） */
static long long ser_fact(int k)
{
    long long f = 1;
    int i;
    for (i = 2; i <= k; i++) f *= i;
    return f;
}

/* 泰勒展开：expr 在 var = point 处展开到 order 阶（0..12）。
 * 系数 c_k = f^(k)(point)/k!：f^(k)(point) 数值求值，能收成整数/小分母分数
 * （Frac）就出精确形式，收不成的老实留 double；|f^(k)(point)| < 1e-12 当 0 舍去。
 * 输出「多项式 + O 余项」；point 不支持 inf（换元后用 sym.替换）。
 * 失败返回 NULL（err 有文案）。 */
char *sym_core_series(const char *expr, const char *var, const char *point,
                      int order, char *err, size_t errsz)
{
    Arena ar = {0};
    Node *n, *cur, *acc = NULL, *base;
    char *names[64];
    char *vname;
    double pt = 0;
    int ps, sgn = 1, k, i, nn = 0;
    SB b, ob;
    char *out;

    if (bad_var_name(var, err, errsz)) return NULL;
    if (order < 0 || order > 12) {
        if (err) snprintf(err, errsz,
            "阶数要在 0 到 12 之间（收到 %d）——教学级展开 12 阶够用，"
            "再高阶乘会溢出一颗 int64", order);
        return NULL;
    }
    ps = parse_point(point, &pt, &sgn, err, errsz);
    if (ps == 0) return NULL;
    if (ps == 2) {
        if (err) snprintf(err, errsz,
            "sym.级数 只支持有限的点（收到 inf）——无穷远的展开要先把 x 换成 1/t 之类"
            "（用 sym.替换 换元，再对 t 展开）");
        return NULL;
    }
    n = compile1(expr, &ar, err, errsz);
    if (!n) { ar_free(&ar); return NULL; }
    collect_vars(n, names, &nn, 64);
    for (i = 0; i < nn; i++)
        if (strcmp(names[i], var) != 0) {
            if (err) snprintf(err, errsz,
                "公式里还有变量 %s——sym.级数 一次只展开一个变量"
                "（可以先用 sym.替换 把别的变量换成具体数）", names[i]);
            ar_free(&ar);
            return NULL;
        }
    vname = ar_strdup(&ar, var, strlen(var));
    if (!vname) {
        if (err) snprintf(err, errsz, "内存不够了");
        ar_free(&ar);
        return NULL;
    }
    base = (pt == 0) ? nd_var(&ar, var)
                     : nd_bin(&ar, N_SUB, nd_var(&ar, var), nd_num(&ar, pt));
    cur = simplified(&ar, n);
    for (k = 0; k <= order; k++) {
        Node *sub = subst_node(&ar, cur, var, nd_num(&ar, pt));
        double v;
        Frac c;
        int exact, neg, one;
        Node *t;
        if (!sub) {
            if (err) snprintf(err, errsz, "代入时内存不足");
            goto fail;
        }
        if (!eval_node(sub, &vname, &pt, 1, &v, err, errsz)) {
            char why[192];
            snprintf(why, sizeof why, "%s", err);
            if (err) snprintf(err, errsz,
                "第 %d 阶导数在 %s = %.10g 处求值失败：%s", k, var, pt, why);
            goto fail;
        }
        if (fabs(v) >= 1e-12) {                 /* 0 系数项不占位 */
            exact = fr_from_double(v, &c);
            if (exact) {
                c = fr_div(c, fr_int(ser_fact(k)));
                if (!c.den) exact = 0;
            }
            if (k == 0) {
                /* 常数项必是首项：负号留在系数里出 "-1/6"，不包 NEG */
                t = exact ? nd_frac(&ar, c) : nd_num(&ar, v);
            } else {
                Node *pw = nd_bin(&ar, N_POW, base, nd_num(&ar, (double)k));
                Node *inner;
                if (exact) {
                    Frac pc = (c.num < 0) ? fr_neg(c) : c;
                    one = (pc.num == 1 && pc.den == 1);
                    inner = one ? pw : nd_bin(&ar, N_MUL, nd_frac(&ar, pc), pw);
                    neg = (c.num < 0);
                } else {
                    double cv = v / (double)ser_fact(k);
                    double pcv = (cv < 0) ? -cv : cv;
                    one = (pcv == 1.0);
                    inner = one ? pw : nd_bin(&ar, N_MUL, nd_num(&ar, pcv), pw);
                    neg = (cv < 0);
                }
                t = neg ? nd_neg(&ar, inner) : inner;
            }
            acc = acc ? nd_bin(&ar, N_ADD, acc, t) : t;
        }
        if (k < order) {
            Node *d;
            norm_sub(&ar, cur);
            d = diff(&ar, cur, var);
            if (!d) {
                if (err) snprintf(err, errsz,
                    "第 %d 阶求导没做出来（比如 abs 在 0 处不可导）——展开失败", k + 1);
                goto fail;
            }
            cur = simplified(&ar, d);
        }
    }
    /* ---- 渲染：多项式 + O 余项 ---- */
    sb_init(&b);
    if (b.oom) { if (err) snprintf(err, errsz, "内存不够了"); goto fail; }
    if (acc) rend(&b, acc, 0, 0, &ST_PLAIN);
    else sb_puts(&b, "0");
    sb_init(&ob);
    if (ob.oom) { free(b.p); if (err) snprintf(err, errsz, "内存不够了"); goto fail; }
    sb_puts(&ob, " + O(");
    if (pt != 0) sb_putc(&ob, '(');
    rend(&ob, base, 0, 0, &ST_PLAIN);
    if (pt != 0) sb_putc(&ob, ')');
    sb_putc(&ob, '^');
    {
        char nb[16];
        snprintf(nb, sizeof nb, "%d", order + 1);
        sb_puts(&ob, nb);
    }
    sb_putc(&ob, ')');
    if (ob.oom) { free(b.p); free(ob.p); if (err) snprintf(err, errsz, "内存不够了"); goto fail; }
    sb_put(&b, ob.p, ob.n);
    free(ob.p);
    if (b.oom) { free(b.p); if (err) snprintf(err, errsz, "内存不够了"); goto fail; }
    out = b.p;
    ar_free(&ar);
    return out;
fail:
    ar_free(&ar);
    return NULL;
}
'''

BIND = r'''
Value rt_lib_sym_limit(Value ev, Value varv, Value ptv)
{
    char err[192] = "";
    char *r;
    sym_chk_str(ev, "sym.极限", "一", "sin(x)/x");
    sym_chk_str(varv, "sym.极限", "二", "x");
    sym_chk_str(ptv, "sym.极限", "三", "0");
    r = sym_core_limit(AS_STR(ev), AS_STR(varv), AS_STR(ptv), err, sizeof err);
    if (!r) rt_die("sym.极限：%s", err);
    return sym_out(r);
}

Value rt_lib_sym_series(Value ev, Value varv, Value ptv, Value ordv)
{
    char err[192] = "";
    char *r;
    long long o;
    sym_chk_str(ev, "sym.级数", "一", "sin(x)");
    sym_chk_str(varv, "sym.级数", "二", "x");
    sym_chk_str(ptv, "sym.级数", "三", "0");
    if (!IS_INT(ordv))
        rt_die("sym.级数 的第四个参数（阶数）要是整数，比如 5");
    o = AS_INT(ordv);
    if (o < 0 || o > 12)
        rt_die("sym.级数 的阶数要在 0 到 12 之间（收到 %lld）", o);
    r = sym_core_series(AS_STR(ev), AS_STR(varv), AS_STR(ptv), (int)o, err, sizeof err);
    if (!r) rt_die("sym.级数：%s", err);
    return sym_out(r);
}

'''

p = 'pybook_sym.c'
raw = open(p, 'rb').read()
s = raw.decode('utf-8')
if MARK in s:
    print('skip pybook_sym.c（已应用）')
else:
    s = apply(s, 'C1 核心层插入',
        '/* ==================== 绑定层 ==================== */\n#if defined(PYBOOK_RT_H) || defined(SYM_RT_BINDING)\n',
        CORE + '\n/* ==================== 绑定层 ==================== */\n#if defined(PYBOOK_RT_H) || defined(SYM_RT_BINDING)\n')
    s = apply(s, 'C2 绑定函数插入',
        '    r = sym_core_solve_sys(AS_STR(eqsv), AS_STR(varsv), err, sizeof err);\n'
        '    if (!r) rt_die("sym.解方程组：%s", err);\n'
        '    return sym_out(r);\n'
        '}\n'
        '\n'
        '#endif /* PYBOOK_RT_H */\n',
        '    r = sym_core_solve_sys(AS_STR(eqsv), AS_STR(varsv), err, sizeof err);\n'
        '    if (!r) rt_die("sym.解方程组：%s", err);\n'
        '    return sym_out(r);\n'
        '}\n'
        + BIND +
        '#endif /* PYBOOK_RT_H */\n')
    open(p, 'wb').write(s.encode('utf-8'))
    print('写入 ' + p)

# ================= 2) pybook_sym.h：声明 + 文档 =================
p = 'pybook_sym.h'
raw = open(p, 'rb').read()
s = raw.decode('utf-8')
if MARK in s:
    print('skip pybook_sym.h（已应用）')
else:
    s = apply(s, 'H1 核心声明',
        '/* 输出格式：mode = "" / "plain"（默认，与解析逐字一致）/ "latex" / "unicode" */\n'
        'char *sym_core_format(const char *expr, const char *mode, char *err, size_t errsz);\n',
        '/* 输出格式：mode = "" / "plain"（默认，与解析逐字一致）/ "latex" / "unicode" */\n'
        'char *sym_core_format(const char *expr, const char *mode, char *err, size_t errsz);\n'
        '/* 极限：expr 在 var → point 的极限（point 可写 inf/-inf）。有限点走代入+洛必达\n'
        ' * （只对 0/0、∞/∞ 真未定式用，分子分母分别求导）并过数值对拍；无穷点走大数值\n'
        ' * 外推（数值近似）。失败返回 NULL（err 有文案）。 */\n'
        'char *sym_core_limit(const char *expr, const char *var, const char *point,\n'
        '                     char *err, size_t errsz);\n'
        '/* 泰勒展开：expr 在 var = point 处展开到 order 阶（0..12），系数尽量精确分数。\n'
        ' * 输出「多项式 + O 余项」；point 不支持 inf（换元后用 sym.替换）。失败返回 NULL。 */\n'
        'char *sym_core_series(const char *expr, const char *var, const char *point,\n'
        '                      int order, char *err, size_t errsz);\n')
    s = apply(s, 'H2 绑定声明',
        'Value rt_lib_sym_solve_sys(Value eqsv, Value varsv);\n',
        'Value rt_lib_sym_solve_sys(Value eqsv, Value varsv);\n'
        'Value rt_lib_sym_limit(Value ev, Value varv, Value ptv);\n'
        'Value rt_lib_sym_series(Value ev, Value varv, Value ptv, Value ordv);\n')
    s = apply(s, 'H3 形状文档',
        ' *   sym.解方程组("x+y=3;x-y=1", "x,y") -> "x = 2, y = 1"（精确有理数）\n',
        ' *   sym.解方程组("x+y=3;x-y=1", "x,y") -> "x = 2, y = 1"（精确有理数）\n'
        ' *   sym.极限("sin(x)/x", "x", "0")       -> 1（0/0 走洛必达；点可写 inf）\n'
        ' *   sym.级数("sin(x)", "x", "0", 5)      -> "x - 1/6*x^3 + 1/120*x^5 + O(x^6)"\n')
    open(p, 'wb').write(s.encode('utf-8'))
    print('写入 ' + p)

# 行尾检查
for f in ('pybook_sym.c', 'pybook_sym.h'):
    b = open(f, 'rb').read()
    print('%s: %d 行, 裸 CR %d' % (f, b.count(b'\n'), b.count(b'\r')))
    if b.count(b'\r'): sys.stderr.write('行尾混杂!\n'); sys.exit(1)
print('=== _sym4_patch 全部通过 ===')
