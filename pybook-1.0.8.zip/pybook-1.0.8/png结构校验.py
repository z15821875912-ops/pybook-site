"""独立校验图库产出的 PNG：结构 + 逐像素统计，不走被测代码的读回路径。

PNG 的 CRC32 是流式的，编码器里多插/漏一次异或收尾就会全错——
文件还在、字节数看着对，但没有任何查看器打得开。所以每块 CRC 必须逐块实算。
（本脚本只依赖 zlib，和 PYbook 运行时无关。）
"""
import struct
import sys
import zlib
from collections import Counter

sys.stdout.reconfigure(encoding='utf-8')


def check(path):
    raw = open(path, 'rb').read()
    fail = []

    def ck(cond, msg):
        print(('  OK  ' if cond else '  FAIL') + '  ' + msg)
        if not cond:
            fail.append(msg)

    print('\n=== %s（%d 字节）===' % (path, len(raw)))
    ck(raw[:8] == b'\x89PNG\r\n\x1a\n', '文件签名 8 字节正确')

    i, chunks, idat = 8, [], b''
    w = h = depth = ctype = None
    while i + 8 <= len(raw):
        ln = struct.unpack('>I', raw[i:i + 4])[0]
        typ = raw[i + 4:i + 8]
        data = raw[i + 8:i + 8 + ln]
        crc = struct.unpack('>I', raw[i + 8 + ln:i + 12 + ln])[0]
        calc = zlib.crc32(typ + data) & 0xFFFFFFFF
        if calc != crc:
            ck(False, '块 %s 的 CRC32 错（声明 %08X，实算 %08X）'
               % (typ.decode('ascii', 'replace'), crc, calc))
        if typ == b'IHDR':
            w, h, depth, ctype, _, _, _ = struct.unpack('>IIBBBBB', data)
        if typ == b'IDAT':
            idat += data
        chunks.append(typ.decode('ascii', 'replace'))
        i += 12 + ln

    ck(not fail, '全部 %d 个数据块的 CRC32 实算一致' % len(chunks))
    ck(chunks[0] == 'IHDR' and chunks[-1] == 'IEND',
       '首块 IHDR、末块 IEND（实际 %s ... %s）' % (chunks[0], chunks[-1]))
    ck(depth == 8 and ctype == 6, '位深 8、颜色类型 6(RGBA)')
    ck(w > 0 and h > 0, '尺寸 %dx%d' % (w, h))

    try:
        px = zlib.decompress(idat)
        ck(True, 'IDAT 能被 zlib 解开（%d 字节，内含 Adler32 校验）' % len(px))
    except Exception as e:
        ck(False, 'IDAT 解压失败：%r' % (e,))
        return fail

    stride = w * 4 + 1
    ck(len(px) == h * stride, '反滤波前每行前置 1 过滤字节，长度 %d == %d' % (len(px), h * stride))
    fset = Counter(px[y * stride] for y in range(h))
    ck(set(fset) == {0}, '所有 %d 行的过滤字节都是 0（实际出现 %s）' % (h, dict(fset)))

    # 统计用色 + 看图面是不是「一片空白」（出图失败的典型症状）
    cnt = Counter()
    opaque = 0
    for y in range(h):
        row = px[y * stride + 1:(y + 1) * stride]
        for x in range(w):
            o = x * 4
            cnt[(row[o], row[o + 1], row[o + 2])] += 1
            if row[o + 3] == 255:
                opaque += 1
    total = w * h
    top = cnt.most_common(6)
    print('       前 6 色（占 %d 像素）：' % total)
    for c, n in top:
        print('         rgb%-18s %7d  %5.1f%%' % (str(c), n, 100.0 * n / total))
    ck(len(cnt) >= 3, '用色 %d 种（背景/线框/图形至少 3 种）' % len(cnt))
    # 「图面非空」不能只看主色占比：折线/函数图像本来就大片留白，主色能到 98%。
    # 改成看「有没有真的画出图形」—— 除背景和网格色之外，
    # 至少有一种颜色铺了够多的像素（柱/饼是几千，函数图像的线也有几百）。
    FIG = {c for c in cnt if c != (255, 255, 255) and cnt[c] >= 200 and c != (226, 228, 234)}
    ck(bool(FIG), '除了背景与网格色外，至少有一种颜色铺了 >=200 像素（图面非空），实际 %s'
       % sorted(FIG))
    ck(opaque == total, '全部 %d 像素不透明（alpha 全 255）' % total)
    return fail


allfail = []
for p in sys.argv[1:]:
    allfail += check(p)
print('\n%s' % ('全部通过' if not allfail else '失败 %d 项' % len(allfail)))
raise SystemExit(1 if allfail else 0)
