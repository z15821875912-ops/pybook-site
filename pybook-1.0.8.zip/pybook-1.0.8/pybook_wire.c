/* PYbook wire 库：接线式测试 —— 针对"两个及以上存在联动关系的功能"的三档验证。
 *
 * 方法论（三类用例依次开展）：
 *   通（连通）：极简程序跑通基础链路，确认模块间逻辑接线能正常连通
 *   扰（刁钻）：构造边界、乱序时序与脏数据，挖掘联动场景下的隐式 bug
 *   危（隔离）：执行一旦出错就引发严重后果的高危程序，检验故障隔离能力、评估失效后的连锁影响
 *
 * API（中英双名，前缀 接线 / wire）：
 *   通档：接线.接(标签)          wire.tap      痕迹打点（记录联动链路经过哪一步）
 *         接线.迹()              wire.trace    -> [标签...]（打点顺序 = 联动顺序）
 *         接线.迹数()            wire.tcount   -> 打点数
 *         接线.例(类别,名,条件)  wire.case     登记一条用例结果（类别：通/扰/危）
 *   扰档：接线.边界(数)          wire.edge     -> [0,1,-1,n-1,n,n+1,-n] 边界值集
 *         接线.乱序(表,种子)     wire.shuffle  确定性乱序（新表）——乱序时序刁钻
 *         接线.脏串(种子)        wire.dirtystr -> 脏字符串（空/引号/格式串/超长/unicode...）
 *         接线.脏数(种子)        wire.dirtynum -> 脏数字（NaN/Inf/-0/精度陷阱...）
 *         接线.脏表(种子)        wire.dirtylist-> 脏列表（空/深层嵌套/混合类型...）
 *   危档：接线.炸(类别,说明)     wire.boom     故障注入：抛可捕获运行时错误（try/catch 接）
 *         接线.快照()            wire.snap     -> [单元,字节,迹,错] 状态快照
 *         接线.对照(快照)        wire.diff     -> [Δ单元,Δ字节,Δ迹,Δ错] 连锁影响量化
 *   汇总：接线.报()              wire.report   三档报告（通→扰→危），返回失败数
 *         接线.败数()            wire.fails    -> 失败总数
 *         接线.清()              wire.clear    清痕迹与计数（缓冲复用不回收）
 *
 * 判读约定（危档连锁影响）：炸被 catch 后 ——
 *   Δ错 == 1        恰好一次失效，无级联报错
 *   Δ迹 == 预期值   炸点之后该停的步骤确实停了（失效无蔓延）
 *   Δ单元 ≈ 0       无泄漏型连锁
 * 纯数据 + 痕迹记录，零窗口零设备 —— VM / C 双后端都能跑（try/catch 仅 C 后端）。 */

#include "pybook_lib.h"

#include <math.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* ---- 错误出口：走 rt_die（带行号、可被 try/catch 捕获） ---- */
static void wire_die(const char *fmt, ...)
{
    char buf[512];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(buf, sizeof buf, fmt, ap);
    va_end(ap);
    rt_die("接线.%s", buf);
}

/* 小工具：造列表（照 pybook_smoke.c 的 mk2/mk3） */
static Value mk1(Value a)
{
    Value l = rt_list_new();
    rt_push(&l, a);
    return l;
}

static Value mk2(Value a, Value b)
{
    Value l = rt_list_new();
    rt_push(&l, a);
    rt_push(&l, b);
    return l;
}

static Value mk4(Value a, Value b, Value c, Value d)
{
    Value l = rt_list_new();
    rt_push(&l, a);
    rt_push(&l, b);
    rt_push(&l, c);
    rt_push(&l, d);
    return l;
}

/* ---- 痕迹（联动链路打点） ---- */

static char **w_trace = NULL;
static size_t w_nt = 0, w_tcap = 0;

Value rt_wire_tap(Value label)
{
    const char *s = rt_str_of(label);
    if (w_nt == w_tcap) {
        size_t nc = w_tcap ? w_tcap * 2 : 64;
        char **p = (char **)realloc(w_trace, nc * sizeof(char *));
        if (!p)
            wire_die("接：内存不足");
        w_trace = p;
        w_tcap = nc;
    }
    size_t n = strlen(s) + 1;
    char *c = (char *)malloc(n);
    if (!c)
        wire_die("接：内存不足");
    memcpy(c, s, n);
    w_trace[w_nt++] = c;
    return rt_int((long long)w_nt);           /* 返回当前打点序号（1 起） */
}

Value rt_wire_trace(void)
{
    Value l = rt_list_new();
    for (size_t i = 0; i < w_nt; i++)
        rt_push(&l, rt_str(w_trace[i]));
    return l;
}

Value rt_wire_tcount(void)
{
    return rt_int((long long)w_nt);
}

/* ---- 三档用例登记 ---- */

static long long w_pass[3], w_fail[3];        /* 0=通 1=扰 2=危 */
static char w_failnames[64][96];
static int w_nfailnames = 0;

/* 类别："通"/"扰"/"危" 或 "smoke"/"fuzz"/"risk" 或 0/1/2 */
static int wire_tier(Value v)
{
    if (IS_INT(v) || IS_BIGINT(v)) {
        long long k = rt_to_ll(v);
        if (k >= 0 && k <= 2)
            return (int)k;
        wire_die("例：类别 %lld 超出 0..2", k);
    }
    if (IS_STR(v)) {
        const char *s = rt_str_of(v);
        if (!strcmp(s, "通") || !strcmp(s, "smoke")) return 0;
        if (!strcmp(s, "扰") || !strcmp(s, "fuzz"))  return 1;
        if (!strcmp(s, "危") || !strcmp(s, "risk"))  return 2;
        wire_die("例：类别 %s 只能是 通/扰/危（或 smoke/fuzz/risk）", s);
    }
    wire_die("例：类别需要文本或整数");
    return 0;
}

Value rt_wire_case(Value tier, Value name, Value cond)
{
    int t = wire_tier(tier);
    const char *s = rt_str_of(name);
    if (!*s)
        wire_die("例：用例名不能为空");
    int ok = rt_cond(cond);
    if (ok) {
        w_pass[t]++;
    } else {
        w_fail[t]++;
        if (w_nfailnames < 64) {
            snprintf(w_failnames[w_nfailnames], sizeof w_failnames[0],
                     "[%s] %s", t == 0 ? "通" : t == 1 ? "扰" : "危", s);
            w_nfailnames++;
        }
    }
    return rt_int(ok);
}

/* ---- 扰档：刁钻数据发生器 ---- */

/* 边界值集：[0, 1, -1, n-1, n, n+1, -n]（整数保整数，浮点保浮点） */
Value rt_wire_edge(Value nv)
{
    Value l = rt_list_new();
    if (IS_INT(nv) || IS_BIGINT(nv)) {
        long long n = rt_to_ll(nv);
        rt_push(&l, rt_int(0));
        rt_push(&l, rt_int(1));
        rt_push(&l, rt_int(-1));
        rt_push(&l, rt_int(n - 1));
        rt_push(&l, rt_int(n));
        rt_push(&l, rt_int(n + 1));
        rt_push(&l, rt_int(-n));
    } else if (IS_FLT(nv)) {
        double n = AS_FLT(nv);
        rt_push(&l, rt_float(0.0));
        rt_push(&l, rt_float(1.0));
        rt_push(&l, rt_float(-1.0));
        rt_push(&l, rt_float(n - 1.0));
        rt_push(&l, rt_float(n));
        rt_push(&l, rt_float(n + 1.0));
        rt_push(&l, rt_float(-n));
    } else {
        wire_die("边界：需要数字参数");
    }
    return l;
}

/* 确定性乱序（xorshift32 + Fisher-Yates），返回新表不改原表 */
Value rt_wire_shuffle(Value list, Value seedv)
{
    if (!IS_LIST(list) || AS_LIST(list) == NULL)
        wire_die("乱序：需要列表参数");
    RtList *src = AS_LIST(list);
    size_t n = src->len;
    Value out = rt_list_new();
    if (n == 0)
        return out;
    Value *tmp = (Value *)malloc(n * sizeof(Value));
    if (!tmp)
        wire_die("乱序：内存不足");
    memcpy(tmp, src->items, n * sizeof(Value));

    unsigned int x = (unsigned int)rt_to_ll(seedv);
    if (x == 0)
        x = 0x9E3779B9u;                       /* 种子 0 也不能退化成不动点 */
    for (size_t i = n - 1; i > 0; i--) {
        x ^= x << 13; x ^= x >> 17; x ^= x << 5;
        size_t j = (size_t)(x % (unsigned int)(i + 1));
        Value t = tmp[i]; tmp[i] = tmp[j]; tmp[j] = t;
    }
    for (size_t i = 0; i < n; i++)
        rt_push(&out, tmp[i]);
    free(tmp);
    return out;
}

/* 脏字符串：空 / 空白 / 格式串炸弹 / 引号汤 / 超长 / 控制符 / 数字样文本 / 路径穿越 / unicode / 零宽 */
Value rt_wire_dirtystr(Value seedv)
{
    static const char *cat[] = {
        "",
        " ",
        "%s%s%s%n",
        "\"'`\\${}",
        "0",
        "1e999",
        "\t\n\r",
        "..\\../etc/passwd",
        "\xE4\xB8\xAD\xE6\x96\x87\xF0\x9F\x98\x80",   /* 中文😀 */
    };
    size_t ncat = sizeof cat / sizeof cat[0];
    long long k = rt_to_ll(seedv);
    if (k < 0)
        k = -k;
    if ((size_t)k % ncat == 4) {               /* 第 4 档：超长串（1000 个 A） */
        char *long1 = (char *)malloc(1001);
        if (!long1)
            wire_die("脏串：内存不足");
        memset(long1, 'A', 1000);
        long1[1000] = 0;
        Value r = rt_str(long1);
        free(long1);
        return r;
    }
    return rt_str(cat[(size_t)k % ncat]);
}

/* 脏数字：NaN / ±Inf / -0 / 近溢出 / 最小次正规 / 2^53+1 精度陷阱 */
Value rt_wire_dirtynum(Value seedv)
{
    long long k = rt_to_ll(seedv);
    if (k < 0)
        k = -k;
    switch (k % 7) {
    case 0: return rt_float(NAN);
    case 1: return rt_float(INFINITY);
    case 2: return rt_float(-INFINITY);
    case 3: return rt_float(-0.0);
    case 4: return rt_float(1e308);
    case 5: return rt_float(5e-324);
    default: return rt_float(9007199254740993.0);  /* 2^53+1：整数精度边界 */
    }
}

/* 脏列表：空 / 含空 / 深层嵌套 / 混合类型 / 长表 / 单元素 */
Value rt_wire_dirtylist(Value seedv)
{
    long long k = rt_to_ll(seedv);
    if (k < 0)
        k = -k;
    switch (k % 6) {
    case 0:
        return rt_list_new();                       /* [] */
    case 1:
        return mk1(rt_none());                      /* [空] */
    case 2: {                                       /* [[[[[0]]]]] 深层嵌套 */
        Value v = mk1(rt_int(0));
        for (int i = 0; i < 5; i++)
            v = mk1(v);
        return v;
    }
    case 3: {                                       /* [1,"a",空,真] 混合类型 */
        Value l = rt_list_new();
        rt_push(&l, rt_int(1));
        rt_push(&l, rt_str("a"));
        rt_push(&l, rt_none());
        rt_push(&l, rt_bool(1));
        return l;
    }
    case 4: {                                       /* 100 个 0 的长表 */
        Value l = rt_list_new();
        for (int i = 0; i < 100; i++)
            rt_push(&l, rt_int(0));
        return l;
    }
    default:
        return mk1(rt_int(0));                      /* [0] */
    }
}

/* ---- 危档：故障注入 + 快照/对照 ---- */

/* 故障注入：抛可捕获运行时错误。类别只是标签（用于区分注入点），说明写清语义。 */
Value rt_wire_boom(Value kind, Value msg)
{
    const char *k = rt_str_of(kind);
    const char *m = rt_str_of(msg);
    if (!*k)
        wire_die("炸：类别不能为空");
    /* 炸点也进痕迹：连锁分析要看得见"在哪炸的" */
    rt_wire_tap(rt_str(k));
    rt_die("接线.炸[%s]：%s", k, m);
    return rt_none();                              /* 不可达 */
}

/* 快照：[内存单元, 内存字节, 痕迹数, 错误数] */
Value rt_wire_snap(void)
{
    size_t bytes = 0;
    size_t cells = rt_mem_stats(&bytes);
    return mk4(rt_int((long long)cells),
               rt_int((long long)bytes),
               rt_int((long long)w_nt),
               rt_int(rt_q_errors()));
}

/* 对照：当前状态 - 快照 -> [Δ单元, Δ字节, Δ迹, Δ错]（连锁影响量化） */
Value rt_wire_diff(Value snapv)
{
    if (!IS_LIST(snapv) || AS_LIST(snapv) == NULL)
        wire_die("对照：需要快照列表（接线.快照() 的返回值）");
    RtList *s = AS_LIST(snapv);
    if (s->len != 4)
        wire_die("对照：快照应有 4 项 [单元,字节,迹,错]，实际 %zu 项", s->len);
    for (size_t i = 0; i < 4; i++)
        if (!IS_INT(s->items[i]) && !IS_BIGINT(s->items[i]))
            wire_die("对照：快照第 %zu 项不是整数", i + 1);

    size_t bytes = 0;
    size_t cells = rt_mem_stats(&bytes);
    return mk4(rt_int((long long)cells - rt_to_ll(s->items[0])),
               rt_int((long long)bytes - rt_to_ll(s->items[1])),
               rt_int((long long)w_nt - rt_to_ll(s->items[2])),
               rt_int(rt_q_errors() - rt_to_ll(s->items[3])));
}

/* ---- 汇总 ---- */

Value rt_wire_report(void)
{
    static const char *tn[3] = {"通（连通）", "扰（刁钻）", "危（隔离）"};
    long long tot_p = w_pass[0] + w_pass[1] + w_pass[2];
    long long tot_f = w_fail[0] + w_fail[1] + w_fail[2];
    if (tot_p + tot_f == 0) {
        printf("接线报告：还没有用例（先用 接线.例 登记）\n");
        return rt_int(0);
    }
    printf("接线报告：\n");
    for (int t = 0; t < 3; t++)
        printf("  %s：%lld/%lld 通过\n", tn[t], w_pass[t], w_pass[t] + w_fail[t]);
    printf("  合计 %lld 例，通过 %lld，失败 %lld\n",
           tot_p + tot_f, tot_p, tot_f);
    if (w_nfailnames > 0) {
        printf("失败明细：\n");
        for (int i = 0; i < w_nfailnames; i++)
            printf("  %s\n", w_failnames[i]);
    }
    return rt_int(tot_f);
}

Value rt_wire_fails(void)
{
    return rt_int(w_fail[0] + w_fail[1] + w_fail[2]);
}

Value rt_wire_clear(void)
{
    w_nt = 0;
    w_pass[0] = w_pass[1] = w_pass[2] = 0;
    w_fail[0] = w_fail[1] = w_fail[2] = 0;
    w_nfailnames = 0;
    return rt_none();
}
