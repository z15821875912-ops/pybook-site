# -*- coding: utf-8 -*-
"""_sym7_patch.py —— 两处收尾。
    S3  cases.py T28_sym_limit_inf_ok: 1/x@-inf 期望 -1e-10 -> 0（极限值就是 0，
        snap_frac 把 -1e-10 认回 0 是正确行为，符号不携带信息）
    S4  pybook_sym.c series snap 防误认：非零系数不许 snap 成 0/1
幂等 count==1，二进制保 LF。"""
import io, sys

def patch(path, items):
    s = io.open(path, 'rb').read()
    for label, old, new in items:
        ob, nb = old.encode('utf-8'), new.encode('utf-8')
        n = s.count(ob)
        if n == 0 and s.count(nb) == 1:
            print('skip ' + label + '（已在位）')
            continue
        if n != 1:
            sys.stderr.write('FAIL [%s] count=%d\n' % (label, n)); sys.exit(1)
        s = s.replace(ob, nb, 1)
        print('ok  ' + label)
    io.open(path, 'wb').write(s)
    print('写入 %s, 裸 CR %d' % (path, s.count(b'\r')))

patch('tests/cases.py', [
    ("S3 T28 1/x@-inf 期望改 0",
     "'out': '0\\n-1e-10\\n2.570796327\\n0\\n', 'expect': '±inf 双侧可写；pi 当点（sin(pi)=1.2e-16 被 snap 回 0）；非整洁值留 %.10g'",
     "'out': '0\\n0\\n2.570796327\\n0\\n', 'expect': '±inf 双侧可写；pi 当点（sin(pi)=1.2e-16 被 snap 回 0）；1/x@-inf 外推 -1e-10 也 snap 回 0（极限值本就是 0，负号不携带信息）；非整洁值留 %.10g'"),
])

patch('pybook_sym.c', [
    ("S4 series snap 防把非零认成 0",
     "                if (snap_frac(v / (double)ser_fact(k), &sc) && sc.den != 0) {\n"
     "                    c = sc; exact = 1;\n"
     "                }\n",
     "                if (snap_frac(v / (double)ser_fact(k), &sc) && sc.den != 0\n"
     "                    && !(sc.num == 0 && v != 0.0)) {   /* 非零系数不许认成 0 */\n"
     "                    c = sc; exact = 1;\n"
     "                }\n"),
])
print('=== _sym7_patch 全部通过 ===')
