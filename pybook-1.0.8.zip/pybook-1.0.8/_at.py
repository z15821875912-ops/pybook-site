# -*- coding: utf-8 -*-
"""直接点名若干 (x,y)，把两张图的像素并排打出来 —— 用来排除读图工具本身的分歧。
用法: python -B _at.py <bmp_a> <bmp_b> "x,y" "x,y" ...
"""
import sys, struct


def load(path):
    d = open(path, 'rb').read()
    off = struct.unpack_from('<I', d, 10)[0]
    w, h = struct.unpack_from('<ii', d, 18)
    flip = h > 0
    h = abs(h)
    bpp = struct.unpack_from('<H', d, 28)[0] // 8
    stride = ((w * bpp + 3) // 4) * 4
    return dict(w=w, h=h, stride=stride, off=off, d=d, flip=flip)


def px(im, x, y):
    row = (im['h'] - 1 - y) if im['flip'] else y
    i = im['off'] + row * im['stride'] + x * 3
    return (im['d'][i + 2], im['d'][i + 1], im['d'][i])


a = load(sys.argv[1])
b = load(sys.argv[2])
print(f"A = {sys.argv[1]}  {a['w']}x{a['h']}  top-down={not a['flip']}  stride={a['stride']}")
print(f"B = {sys.argv[2]}  {b['w']}x{b['h']}  top-down={not b['flip']}  stride={b['stride']}")
for s in sys.argv[3:]:
    x, y = (int(v) for v in s.split(','))
    pa, pb = px(a, x, y), px(b, x, y)
    same = '==' if pa == pb else '!='
    print(f'  ({x:4d},{y:4d}) {same}  A=#{pa[0]:02X}{pa[1]:02X}{pa[2]:02X}   B=#{pb[0]:02X}{pb[1]:02X}{pb[2]:02X}')
