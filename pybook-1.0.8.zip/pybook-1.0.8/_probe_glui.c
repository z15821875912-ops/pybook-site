/* _probe_glui.c —— 决定性实验：SDL2 能不能在**同一个 OpenGL 窗口**上
 * 同时给出 (a) 一个可用的 SDL_Renderer 和 (b) 一个活的 GL context？
 *
 * 这决定了「UI 引擎 + 3D 引擎同屏」到底走哪条路：
 *   能 —— UI 保持 GPU 加速，3D 复用 SDL 的 context，两边纹理还能共享（最优）
 *   不能 —— 只能退到「UI 渲进离屏 surface，3D 每帧当纹理贴上去」（UI 变软件渲染）
 *
 * 不问清楚就动手 = 架构赌运气。所以先花 60 行测出来。
 *
 * 测法（每步都打印能不能、为什么）：
 *   1. 带 SDL_WINDOW_OPENGL 建窗
 *   2. hw3d 的顺序：先 SDL_GL_CreateContext
 *   3. 能不能在这个窗口上 SDL_CreateRenderer(ACCELERATED)
 *   4. 反过来：先 SDL_CreateRenderer 再 SDL_GL_CreateContext，两个 context 是不是同一个
 *   5. SDL_RenderPresent 之后 GL 状态还活着吗（hw3d 要在 present 前后继续画）
 *   6. SDL_RenderReadPixels 能不能读回来（UI 出图/验收依赖它）
 */
#include <SDL2/SDL.h>
#include <SDL2/SDL_opengl.h>
#include <stdio.h>

static void banner(const char *s) { printf("\n=== %s ===\n", s); }

int main(void)
{
    SDL_SetMainReady();
    if (SDL_Init(SDL_INIT_VIDEO) != 0) {
        printf("[1] SDL_Init 失败: %s\n", SDL_GetError());
        return 1;
    }
    printf("[1] SDL_Init ok，video driver = %s\n", SDL_GetCurrentVideoDriver());

    int W = 640, H = 480;
    SDL_Window *win = SDL_CreateWindow("probe", SDL_WINDOWPOS_CENTERED,
                                       SDL_WINDOWPOS_CENTERED, W, H,
                                       SDL_WINDOW_SHOWN | SDL_WINDOW_RESIZABLE
                                       | SDL_WINDOW_OPENGL);
    if (!win) { printf("[2] 带 OPENGL 建窗失败: %s\n", SDL_GetError()); return 1; }
    printf("[2] 带 SDL_WINDOW_OPENGL 建窗 ok");

    /* ---- 步骤 3：hw3d 的顺序，先建 GL context ---- */
    banner("顺序 A：先 GL context，再 SDL_Renderer（hw3d 现在的做法 + 加 renderer）");
    SDL_GL_SetAttribute(SDL_GL_DOUBLEBUFFER, 1);
    SDL_GL_SetAttribute(SDL_GL_DEPTH_SIZE, 24);
    SDL_GLContext ctxA = SDL_GL_CreateContext(win);
    if (!ctxA) { printf("[3] SDL_GL_CreateContext 失败: %s\n", SDL_GetError()); return 1; }
    printf("[3] SDL_GL_CreateContext ok, ctx=%p", (void *)ctxA);
    printf(", GLSL=%s", (const char *)glGetString(GL_SHADING_LANGUAGE_VERSION));
    printf(", RENDERER=%s\n", (const char *)glGetString(GL_RENDERER));

    SDL_Renderer *renA = SDL_CreateRenderer(win, -1, SDL_RENDERER_ACCELERATED);
    if (renA) {
        SDL_RendererInfo ri;
        SDL_GetRendererInfo(renA, &ri);
        printf("[4] SDL_CreateRenderer(ACCELERATED) ok：%s\n", ri.name);
        printf("    SDL 里绑的 GL context = %p，和我们自己建的是不是同一个：%s\n",
               (void *)SDL_GL_GetCurrentContext(),
               SDL_GL_GetCurrentContext() == ctxA ? "是" : "**否（两个 context！）**");

        /* 真的画一笔，确认 renderer 可用 */
        SDL_SetRenderDrawColor(renA, 200, 40, 40, 255);
        SDL_RenderClear(renA);
        SDL_SetRenderDrawColor(renA, 40, 200, 120, 255);
        SDL_RenderFillRect(renA, &(SDL_Rect){100, 100, 200, 120});
        SDL_RenderPresent(renA);
        printf("[5] SDL_RenderDraw + Present 跑完没崩");

        /* present 之后 GL 还活着吗 —— hw3d 要接着画 3D */
        SDL_GL_MakeCurrent(win, ctxA);
        GLenum err = glGetError();
        printf("[6] present 后 GL 仍可用：glGetError=0x%x %s\n", err,
               err == GL_NO_ERROR ? "(干净)" : "**有残留错误**");

        /* 出图能力：UI 验收件全靠它 */
        unsigned char *px = (unsigned char *)malloc(W * H * 4);
        if (SDL_RenderReadPixels(renA, NULL, SDL_PIXELFORMAT_RGBA32, px, W * 4) == 0) {
            printf("[7] SDL_RenderReadPixels ok，中心像素 = %02X %02X %02X (期望 28 C8 78 附近)\n",
                   px[(240 * W + 320) * 4 + 0], px[(240 * W + 320) * 4 + 1],
                   px[(240 * W + 320) * 4 + 2]);
        } else {
            printf("[7] SDL_RenderReadPixels **失败**: %s\n", SDL_GetError());
        }
        free(px);

        /* 关键：GL 自己画一笔 + present，看 SDL 能不能把它翻上去 */
        banner("交叉验证：GL 画 + SDL present，能不能把 3D 内容显示出来");
        glViewport(0, 0, W, H);
        glClearColor(0.1f, 0.3f, 0.8f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT);
        glFlush();
        unsigned char *px2 = (unsigned char *)malloc(W * H * 4);
        if (SDL_RenderReadPixels(renA, NULL, SDL_PIXELFORMAT_RGBA32, px2, W * 4) == 0) {
            printf("[8] GL 画完之后 SDL_RenderReadPixels 中心像素 = %02X %02X %02X\n",
                   px2[(240 * W + 320) * 4 + 0], px2[(240 * W + 320) * 4 + 1],
                   px2[(240 * W + 320) * 4 + 2]);
            printf("    （若接近 1A 4D CC 说明 GL 直接画进同一个后缓冲，"
                   "两套绘制能叠在同一张图上）");
        }
        free(px2);
        SDL_DestroyRenderer(renA);
    } else {
        printf("[4] SDL_CreateRenderer(ACCELERATED) **失败**: %s\n", SDL_GetError());
        printf("    -> 只能退到「UI 渲进离屏 surface，3D 当纹理贴上去」\n");
        SDL_Surface *sw = SDL_CreateRGBSurfaceWithFormat(0, W, H, 32,
                                                        SDL_PIXELFORMAT_ARGB8888);
        SDL_Renderer *swr = sw ? SDL_CreateSoftwareRenderer(sw) : NULL;
        printf("    离屏软件 surface + renderer %s\n", swr ? "可用（UI 可改走这条路）" : "不可用");
        if (swr) SDL_DestroyRenderer(swr);
        if (sw) SDL_FreeSurface(sw);
    }

    SDL_GL_DeleteContext(ctxA);
    SDL_DestroyWindow(win);
    SDL_Quit();
    return 0;
}
