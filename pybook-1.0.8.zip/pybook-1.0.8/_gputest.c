﻿/* CUDA 连线测试 v2 —— 原生后端最小可证伪探针
 *
 * 结论（这台机器实测）：
 *   · LoadLibrary("nvcuda.dll") + GetProcAddress 完全可行，不链 cuda.lib
 *   · 手写 PTX 内嵌字符串，驱动自己编译，完全不需要 nvcc / NVRTC / CUDA Toolkit
 *   · 显存 API 必须用 _v2 版本化符号（cuMemAlloc_v2 等），旧名会报 CUDA 201
 *
 * 两种计时口径（真实后端要付的钱不一样）：
 *   kernel-only = 只算 kernel 本身（数据常驻显存的情形）
 *   端到端     = H2D + kernel + D2H（每次调用都搬数据的情形）
 *
 * 编译：gcc _gputest.c -o _gputest.exe -O2 -lm
 */
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

typedef int CUresult;
typedef int CUdevice;
typedef void *CUcontext;
typedef void *CUmodule;
typedef void *CUfunction;
typedef unsigned long long CUdeviceptr;

static HMODULE g_nvcuda = NULL;
static CUresult (*p_cuInit)(unsigned);
static CUresult (*p_cuDriverGetVersion)(int *);
static CUresult (*p_cuDeviceGetCount)(int *);
static CUresult (*p_cuDeviceGet)(CUdevice *, int);
static CUresult (*p_cuDeviceGetName)(char *, int, CUdevice);
static CUresult (*p_cuDeviceTotalMem)(size_t *, CUdevice);
static CUresult (*p_cuDeviceGetAttribute)(int *, int, CUdevice);
static CUresult (*p_cuDevicePrimaryCtxRetain)(CUcontext *, CUdevice);
static CUresult (*p_cuCtxSetCurrent)(CUcontext);
static CUresult (*p_cuCtxSynchronize)(void);
static CUresult (*p_cuModuleLoadData)(CUmodule *, const void *);
static CUresult (*p_cuModuleGetFunction)(CUfunction *, CUmodule, const char *);
static CUresult (*p_cuMemAlloc_v2)(CUdeviceptr *, size_t);
static CUresult (*p_cuMemFree_v2)(CUdeviceptr);
static CUresult (*p_cuMemcpyHtoD_v2)(CUdeviceptr, const void *, size_t);
static CUresult (*p_cuMemcpyDtoH_v2)(void *, CUdeviceptr, size_t);
static CUresult (*p_cuLaunchKernel)(CUfunction, unsigned, unsigned, unsigned,
                                    unsigned, unsigned, unsigned,
                                    unsigned, void *, void **, void **);
static CUresult (*p_cuGetErrorString)(CUresult, const char **);

#define CU_DEVICE_ATTRIBUTE_CC_MAJOR 75
#define CU_DEVICE_ATTRIBUTE_CC_MINOR 76

static const char *errstr(CUresult r)
{
    const char *s = NULL;
    if (p_cuGetErrorString && p_cuGetErrorString(r, &s) == 0 && s) return s;
    return "?";
}

#define CK(expr)                                                   \
    do {                                                           \
        CUresult _r = (expr);                                      \
        if (_r != 0) {                                             \
            fprintf(stderr, "!! %s -> CUDA %d: %s\n", #expr, _r,   \
                    errstr(_r));                                   \
            return 1;                                              \
        }                                                          \
    } while (0)

static double now_sec(void)
{
    LARGE_INTEGER f, t;
    QueryPerformanceFrequency(&f);
    QueryPerformanceCounter(&t);
    return (double)t.QuadPart / (double)f.QuadPart;
}

/* ── 手写 PTX：朴素 sgemm ──
 * 陷阱备忘：%ctaid 是「块编号」，%tid 才是「块内线程编号」。
 * 全局坐标必须自己算：mad(blockIdx, blockDim, tid)。
 * 没有 .cl 文件、没有编译器，源码就是一段字符串。 */
static const char *PTX_SGEMM =
    ".version 6.5\n"
    ".target sm_61\n"
    ".address_size 64\n"
    "\n"
    ".visible .entry sgemm(\n"
    "    .param .u64 sgemm_param_0,\n"
    "    .param .u64 sgemm_param_1,\n"
    "    .param .u64 sgemm_param_2,\n"
    "    .param .u32 sgemm_param_3,\n"
    "    .param .u32 sgemm_param_4,\n"
    "    .param .u32 sgemm_param_5\n"
    ")\n"
    "{\n"
    "    .reg .pred  %p<4>;\n"
    "    .reg .b32   %r<16>;\n"
    "    .reg .b64   %rd<12>;\n"
    "    .reg .f32   %f<4>;\n"
    "\n"
    "    ld.param.u64 %rd1, [sgemm_param_0];\n"
    "    ld.param.u64 %rd2, [sgemm_param_1];\n"
    "    ld.param.u64 %rd3, [sgemm_param_2];\n"
    "    ld.param.u32  %r1,  [sgemm_param_3];\n"
    "    ld.param.u32  %r2,  [sgemm_param_4];\n"
    "    ld.param.u32  %r3,  [sgemm_param_5];\n"
    "\n"
    "    mov.u32 %r7, %tid.x;\n"
    "    mov.u32 %r8, %tid.y;\n"
    "    mov.u32 %r9, %ctaid.x;\n"
    "    mov.u32 %r10, %ctaid.y;\n"
    "    mov.u32 %r11, %ntid.x;\n"        /* 注意：%ntid 不能直接当 mul 的操作数，必须先 mov 出来 */
    "    mov.u32 %r12, %ntid.y;\n"
    "    mul.lo.s32 %r9, %r9, %r11;\n"
    "    mul.lo.s32 %r10, %r10, %r12;\n"
    "    add.s32 %r4, %r9, %r7;\n"            /* col = blockIdx.x*blockDim.x + threadIdx.x */
    "    add.s32 %r5, %r10, %r8;\n"           /* row = blockIdx.y*blockDim.y + threadIdx.y */
    "    setp.ge.u32 %p1, %r4, %r2;\n"
    "    setp.ge.u32 %p2, %r5, %r1;\n"
    "    or.pred  %p3, %p1, %p2;\n"
    "    @%p3 bra DONE;\n"
    "\n"
    "    mov.f32 %f1, 0f00000000;\n"
    "    mov.u32 %r6, 0;\n"
    "\n"
    "KLOOP:\n"
    "    setp.ge.u32 %p1, %r6, %r3;\n"
    "    @%p1 bra STORE;\n"
    "\n"
    "    mul.wide.u32 %rd4, %r5, %r3;\n"
    "    cvt.u64.u32   %rd5, %r6;\n"
    "    add.s64       %rd4, %rd4, %rd5;\n"
    "    shl.b64       %rd4, %rd4, 2;\n"
    "    add.s64       %rd4, %rd4, %rd1;\n"
    "    ld.global.f32 %f2, [%rd4];\n"
    "\n"
    "    mul.wide.u32 %rd6, %r6, %r2;\n"
    "    cvt.u64.u32   %rd7, %r4;\n"
    "    add.s64       %rd6, %rd6, %rd7;\n"
    "    shl.b64       %rd6, %rd6, 2;\n"
    "    add.s64       %rd6, %rd6, %rd2;\n"
    "    ld.global.f32 %f3, [%rd6];\n"
    "\n"
    "    fma.rn.f32    %f1, %f2, %f3, %f1;\n"
    "    add.u32       %r6, %r6, 1;\n"
    "    bra KLOOP;\n"
    "\n"
    "STORE:\n"
    "    mul.wide.u32 %rd8, %r5, %r2;\n"
    "    cvt.u64.u32   %rd9, %r4;\n"
    "    add.s64       %rd8, %rd8, %rd9;\n"
    "    shl.b64       %rd8, %rd8, 2;\n"
    "    add.s64       %rd8, %rd8, %rd3;\n"
    "    st.global.f32 [%rd8], %f1;\n"
    "\n"
    "DONE:\n"
    "    ret;\n"
    "}\n";

static CUcontext g_ctx;
static CUfunction g_fn;
static CUdeviceptr g_dA, g_dB, g_dC;

#define BX 16
#define BY 16
static int g_tile = 16;   /* 每块覆盖 TILE x TILE 个输出元素 */
#include "_ptx_tiled.inc"

static CUresult g_last_launch_rc = 0;

static double run_once_gpu(int M, int N, int reps)
{
    int m = M, n = N, k = N;
    void *params[] = { &g_dA, &g_dB, &g_dC, &m, &n, &k };
    /* grid = 块数，不是元素数 */
    unsigned gx = (unsigned)((N + g_tile - 1) / g_tile);
    unsigned gy = (unsigned)((M + g_tile - 1) / g_tile);
    double t0 = now_sec();
    for (int rep = 0; rep < reps; rep++) {
        CUresult lr = p_cuLaunchKernel(g_fn, gx, gy, 1, BX, BY, 1, 0, NULL, params, NULL);
        if (lr != 0 && g_last_launch_rc == 0) g_last_launch_rc = lr;
    }
    g_last_launch_rc |= p_cuCtxSynchronize();
    return now_sec() - t0;
}

static double run_e2e_gpu(int M, int N, int reps,
                          const float *A, const float *B, float *C)
{
    int m = M, n = N, k = N;
    void *params[] = { &g_dA, &g_dB, &g_dC, &m, &n, &k };
    unsigned gx = (unsigned)((N + g_tile - 1) / g_tile);
    unsigned gy = (unsigned)((M + g_tile - 1) / g_tile);
    size_t na = (size_t)M * N * sizeof(float);
    size_t nb = (size_t)N * N * sizeof(float);
    size_t nc = (size_t)M * N * sizeof(float);
    double t0 = now_sec();
    for (int rep = 0; rep < reps; rep++) {
        p_cuMemcpyHtoD_v2(g_dA, A, na);
        p_cuMemcpyHtoD_v2(g_dB, B, nb);
        CUresult lr = p_cuLaunchKernel(g_fn, gx, gy, 1, BX, BY, 1, 0, NULL, params, NULL);
        if (lr != 0 && g_last_launch_rc == 0) g_last_launch_rc = lr;
        p_cuMemcpyDtoH_v2(C, g_dC, nc);
    }
    g_last_launch_rc |= p_cuCtxSynchronize();
    return now_sec() - t0;
}

int main(int argc, char **argv)
{
    int maxn = argc > 1 ? atoi(argv[1]) : 1024;

    printf("== CUDA 连线测试 ==\n");
    g_nvcuda = LoadLibraryA("nvcuda.dll");
    if (!g_nvcuda) {
        printf("  !! LoadLibrary(\"nvcuda.dll\") 失败 err=%lu\n", GetLastError());
        return 1;
    }
#define LOAD(name, field)                                               \
    do {                                                                \
        *(void **)(&field) = GetProcAddress(g_nvcuda, name);            \
        if (!field) { printf("  !! 缺符号 %s\n", name); return 1; }      \
    } while (0)
#define LOAD_V2(base, v2name, field)                                    \
    do {                                                                \
        *(void **)(&field) = GetProcAddress(g_nvcuda, v2name);          \
        if (!field) *(void **)(&field) = GetProcAddress(g_nvcuda, base); \
        if (!field) { printf("  !! 缺符号 %s\n", v2name); return 1; }   \
    } while (0)
    LOAD("cuInit", p_cuInit);
    LOAD("cuDriverGetVersion", p_cuDriverGetVersion);
    LOAD("cuDeviceGetCount", p_cuDeviceGetCount);
    LOAD("cuDeviceGet", p_cuDeviceGet);
    LOAD("cuDeviceGetName", p_cuDeviceGetName);
    LOAD("cuDeviceTotalMem", p_cuDeviceTotalMem);
    LOAD("cuDeviceGetAttribute", p_cuDeviceGetAttribute);
    LOAD_V2("cuDevicePrimaryCtxRetain", "cuDevicePrimaryCtxRetain", p_cuDevicePrimaryCtxRetain);
    LOAD("cuCtxSetCurrent", p_cuCtxSetCurrent);
    LOAD("cuCtxSynchronize", p_cuCtxSynchronize);
    LOAD("cuModuleLoadData", p_cuModuleLoadData);
    LOAD("cuModuleGetFunction", p_cuModuleGetFunction);
    LOAD_V2("cuMemAlloc", "cuMemAlloc_v2", p_cuMemAlloc_v2);
    LOAD_V2("cuMemFree", "cuMemFree_v2", p_cuMemFree_v2);
    LOAD_V2("cuMemcpyHtoD", "cuMemcpyHtoD_v2", p_cuMemcpyHtoD_v2);
    LOAD_V2("cuMemcpyDtoH", "cuMemcpyDtoH_v2", p_cuMemcpyDtoH_v2);
    LOAD("cuLaunchKernel", p_cuLaunchKernel);
    LOAD("cuGetErrorString", p_cuGetErrorString);

    CK(p_cuInit(0));
    int drv = 0, ndev = 0;
    p_cuDriverGetVersion(&drv);
    CK(p_cuDeviceGetCount(&ndev));
    CUdevice dev;
    CK(p_cuDeviceGet(&dev, 0));
    char name[128] = {0};
    p_cuDeviceGetName(name, sizeof(name), dev);
    int ccmaj = 0, ccmin = 0;
    p_cuDeviceGetAttribute(&ccmaj, CU_DEVICE_ATTRIBUTE_CC_MAJOR, dev);
    p_cuDeviceGetAttribute(&ccmin, CU_DEVICE_ATTRIBUTE_CC_MINOR, dev);
    size_t total = 0;
    p_cuDeviceTotalMem(&total, dev);
    printf("  [1] nvcuda.dll 动态加载成功，未链任何 import lib\n");
    printf("  [2] 驱动 API %d · 设备 %d · %s · CC %d.%d · 显存 %.1f GB\n",
           drv, ndev, name, ccmaj, ccmin, total / 1073741824.0);

    CK(p_cuDevicePrimaryCtxRetain(&g_ctx, dev));
    CK(p_cuCtxSetCurrent(g_ctx));

    /* argv[2]: naive（每线程 1 输出）/ tiled（每线程 4x4） */
    int tiled = (argc > 2 && strcmp(argv[2], "tiled") == 0);
    const char *ptx_src = tiled ? PTX_SGEMM_TILED : PTX_SGEMM;
    g_tile = tiled ? 64 : 16;
    printf("  [模式] %s（每块覆盖 %dx%d，PTX %zu 字节）\n",
           tiled ? "寄存器 4x4 分块" : "朴素每线程 1 输出",
           g_tile, g_tile, strlen(ptx_src));

    CUmodule mod = NULL;
    CUresult r = p_cuModuleLoadData(&mod, ptx_src);
    if (r != 0) {
        FILE *fp = fopen("_ptx_dump.txt", "wb");
        if (fp) { fwrite(ptx_src, 1, strlen(ptx_src), fp); fclose(fp); }
        printf("  [3] !! cuModuleLoadData -> %d: %s（PTX 已存 _ptx_dump.txt）\n",
               r, errstr(r));
        return 1;
    }
    CK(p_cuModuleGetFunction(&g_fn, mod, "sgemm"));
    printf("  [3] PTX 被驱动编译通过，sgemm 就绪\n");

    printf("\n%6s %12s %10s %12s %10s %12s %10s\n",
           "N", "kernel秒", "GFLOPS", "端到端秒", "GFLOPS", "对拍最大相对", "判定");
    for (int N = 64; N <= maxn; N *= 2) {
        size_t na = (size_t)N * N, nb = (size_t)N * N, nc = (size_t)N * N;
        float *A = malloc(na * sizeof(float));
        float *B = malloc(nb * sizeof(float));
        float *C = malloc(nc * sizeof(float));
        for (size_t i = 0; i < na; i++) A[i] = (float)(rand() / (double)RAND_MAX);
        for (size_t i = 0; i < nb; i++) B[i] = (float)(rand() / (double)RAND_MAX);

        p_cuMemFree_v2(g_dA); p_cuMemFree_v2(g_dB); p_cuMemFree_v2(g_dC);
        CK(p_cuMemAlloc_v2(&g_dA, na * sizeof(float)));
        CK(p_cuMemAlloc_v2(&g_dB, nb * sizeof(float)));
        CK(p_cuMemAlloc_v2(&g_dC, nc * sizeof(float)));
        CK(p_cuMemcpyHtoD_v2(g_dA, A, na * sizeof(float)));
        CK(p_cuMemcpyHtoD_v2(g_dB, B, nb * sizeof(float)));

        /* 预热：第一次 launch 触发模块加载/JIT，必须排除 */
        int m = N, n = N, k = N;
        void *params[] = { &g_dA, &g_dB, &g_dC, &m, &n, &k };
        p_cuLaunchKernel(g_fn, (unsigned)((N + g_tile - 1) / g_tile),
                         (unsigned)((N + g_tile - 1) / g_tile), 1, BX, BY, 1,
                         0, NULL, params, NULL);
        p_cuCtxSynchronize();

        int reps = N <= 256 ? 200 : (N <= 512 ? 100 : 30);
        double t_k = run_once_gpu(N, N, reps);
        int ereps = reps < 20 ? reps : 20;
        double t_e = run_e2e_gpu(N, N, ereps, A, B, C);

        /* 正确性：抽 512 个元素，用完整的 K 项内积做参考
         C[i] 对应 row = i / N，col = i % N（别弄反） */
        double maxrel = 0.0, refmax = 1e-30;
        int step = (int)(nc / 512); if (step < 1) step = 1;
        for (size_t i = 0; i < nc; i += (size_t)step) {
            size_t row = i / (size_t)N, col = i % (size_t)N;
            double s = 0.0;
            for (int kk = 0; kk < N; kk++)
                s += (double)A[row * N + kk] * (double)B[(size_t)kk * N + col];
            if (fabs(s) > refmax) refmax = fabs(s);
        }
        for (size_t i = 0; i < nc; i += (size_t)step) {
            size_t row = i / (size_t)N, col = i % (size_t)N;
            double s = 0.0;
            for (int kk = 0; kk < N; kk++)
                s += (double)A[row * N + kk] * (double)B[(size_t)kk * N + col];
            double d = fabs((double)C[i] - s) / refmax;
            if (d > maxrel) {
                maxrel = d;
                if (N <= 256) printf("   [worst] i=%zu row=%zu col=%zu C[i]=%f s=%f\n",
                                     i, row, col, C[i], s);
            }
        }
        double fl = 2.0 * N * (double)N * N;
        if (N <= 256) {
            {
                size_t row0 = 0, col0 = 0;
                double s0 = 0.0;
                for (int kk = 0; kk < N; kk++)
                    s0 += (double)A[row0 * N + kk] * (double)B[(size_t)kk * N + col0];
                printf("   [dbg] C[0]=%.6f  s0=%.6f  diff=%.3e  refmax=%.6f  maxrel=%.3e\n",
                       C[0], s0, fabs((double)C[0] - s0), refmax, maxrel);
            }
            printf("   [dbg] C[0..3] = %.6f %.6f %.6f %.6f\n",
                   C[0], C[1], C[2], C[3]);
            printf("   [dbg] C[%d..] = %.6f %.6f %.6f %.6f\n",
                   N, C[N], C[N + 1], C[N + 2], C[N + 3]);
            for (int d = 0; d < 4; d++) {
                double s0 = 0, s1 = 0;
                for (int kk = 0; kk < N; kk++) s0 += (double)A[kk] * (double)B[(size_t)kk * N + d];
                for (int kk = 0; kk < N; kk++)
                    s1 += (double)A[(size_t)d * N + kk] * (double)B[(size_t)kk * N];
                printf("   [dbg] 参考 C[0][%d]=%.6f   参考 C[%d][0]=%.6f\n", d, s0, d, s1);
            }
        }
        printf("%6d %12.5f %10.1f %12.5f %10.1f %12.2e %10s %s\n",
               N, t_k, fl * reps / t_k / 1e9,
               t_e, fl * ereps / t_e / 1e9,
               maxrel, maxrel < 1e-4 ? "OK" : "!!",
               g_last_launch_rc ? errstr(g_last_launch_rc) : "");
        g_last_launch_rc = 0;

        free(A); free(B); free(C);
    }
    printf("\n（对拍：抽 512 个元素，用完整 K 项双精度内积做参考，阈值 1e-4）\n");
    FreeLibrary(g_nvcuda);
    return 0;
}