# -*- coding: utf-8 -*-
"""修两处编译错误：rt_list_push → rt_push(&out, …)；lib_gauss 里未用的 big。

pybook_lib.c 是混合行尾，用 Python 按字节替换，不用 PowerShell 正则。
"""
import io
import re

P = "pybook_lib.c"
s = io.open(P, "r", encoding="utf-8", newline="").read()
before = s

# 1) rt_list_push(out, X) -> rt_push(&out, X)
s = re.sub(r"rt_list_push\((\w+),\s*", r"rt_push(&\1, ", s)

# 2) lib_gauss 里没用到的 big
s = s.replace("    double t, big;\r\n", "    double t;\r\n")

io.open(P, "w", encoding="utf-8", newline="").write(s)
print("改动 %d 字节；rt_push 处 %d 个" %
      (len(s) - len(before), s.count("rt_push(&out")))