# -*- coding: utf-8 -*-
"""_bwbisect.py -- 生成 bw_read 的逐特性 PTX 变体，用来二分定位编译失败点。

为什么需要它：这台机器上拿不到驱动的 JIT 编译日志（CUjit_options 全被拒），
机器上也没有 ptxas。所以定位「哪条指令编不过」只剩二分法这一个办法：
一次加一个特性，看从哪个变体开始失败。

每个变体都从同一个最小骨架出发，逐个叠加一个特性：
    v1_base   参数取址 + 一次标量 ld.global.f32 + 一次 st.global.f32
    v2_cvta   + cvta.to.global（FMAPEAK 里用过，应该没问题，查一遍）
    v3_idx    + 线程号/总线程数/位移计算（mul.lo / shl.b32 / %nctaid / %ntid）
    v4_loopadd+ 循环 + 在 generic 空间做 add.s64 游标推进
    v5_v4     + ld.global.v4.f32 向量载入（头号嫌疑）
    v6_v4loop + cvta + 循环 + 向量载入（组合，但地址用每次重算而不是游标推进）
    v7_full   当前的完整文件（对照组，已知编不过）

注释一律纯 ASCII —— 中文会让 JIT 失败且不给任何提示。
"""
import os
import sys

HEAD = """.version 6.5
.target sm_61
.address_size 64
"""

DECL = """    .reg .pred %p<4>;
    .reg .b32  %r<8>;
    .reg .b64  %rd<8>;
    .reg .f32  %f<8>;
"""

TAIL = """    ret;
}
"""

# --- 变体主体：每段都是可直接塞进 .visible .entry 里的行 -------------------

V1 = """
    ld.param.u64 %rd1, [p_a];
    ld.param.u64 %rd2, [p_out];
    ld.param.u32 %r1, [p_iter];
    cvta.to.global.u64 %rd3, %rd1;
    cvta.to.global.u64 %rd4, %rd2;
    ld.global.f32 %f1, [%rd3];
    st.global.f32 [%rd4], %f1;
"""

V2_EXTRA = """
    ld.param.u64 %rd1, [p_a];
    ld.param.u64 %rd2, [p_out];
    cvta.to.global.u64 %rd3, %rd1;
    cvta.to.global.u64 %rd4, %rd2;
    ld.global.f32 %f1, [%rd3];
    st.global.f32 [%rd4], %f1;
"""

# 线程号/总线程数/字节位移
V3_EXTRA = """
    ld.param.u64 %rd1, [p_a];
    ld.param.u64 %rd2, [p_out];
    ld.param.u32 %r1, [p_iter];
    mov.u32  %r2, %ctaid.x;
    mul.lo.u32 %r2, %r2, %ntid.x;
    add.u32  %r2, %r2, %tid.x;
    mul.lo.u32 %r3, %nctaid.x, %ntid.x;
    shl.b32  %r4, %r3, 4;
    shl.b32  %r5, %r2, 4;
    cvt.s64.u32 %rd5, %r5;
    add.s64  %rd6, %rd1, %rd5;
    cvta.to.global.u64 %rd3, %rd6;
    cvta.to.global.u64 %rd4, %rd2;
    ld.global.f32 %f1, [%rd3];
    st.global.f32 [%rd4], %f1;
"""

# 循环 + generic 游标推进
V4_EXTRA = """
    ld.param.u64 %rd1, [p_a];
    ld.param.u64 %rd2, [p_out];
    ld.param.u32 %r1, [p_iter];
    mov.u32  %r2, %ctaid.x;
    mul.lo.u32 %r2, %r2, %ntid.x;
    add.u32  %r2, %r2, %tid.x;
    mul.lo.u32 %r3, %nctaid.x, %ntid.x;
    shl.b32  %r4, %r3, 4;
    shl.b32  %r5, %r2, 4;
    cvt.s64.u32 %rd4, %r4;
    cvt.s64.u32 %rd5, %r5;
    add.s64  %rd6, %rd1, %rd5;
    cvta.to.global.u64 %rd7, %rd2;
    mov.u32  %r7, 0;
LOOP:
    cvta.to.global.u64 %rd3, %rd6;
    ld.global.f32 %f1, [%rd3];
    add.s64 %rd6, %rd6, %rd4;
    add.s32 %r7, %r7, 1;
    setp.lt.s32 %p1, %r7, %r1;
    @%p1 bra LOOP;
    st.global.f32 [%rd7], %f1;
"""

# 向量载入
V5_EXTRA = """
    ld.param.u64 %rd1, [p_a];
    ld.param.u64 %rd2, [p_out];
    cvta.to.global.u64 %rd3, %rd1;
    cvta.to.global.u64 %rd4, %rd2;
    ld.global.v4.f32 {%f1,%f2,%f3,%f4}, [%rd3];
    st.global.f32 [%rd4], %f1;
"""

# cvta + 循环 + 向量载入，地址每轮重算而非游标推进
V6_EXTRA = """
    ld.param.u64 %rd1, [p_a];
    ld.param.u64 %rd2, [p_out];
    ld.param.u32 %r1, [p_iter];
    mov.u32  %r2, %ctaid.x;
    mul.lo.u32 %r2, %r2, %ntid.x;
    add.u32  %r2, %r2, %tid.x;
    mul.lo.u32 %r3, %nctaid.x, %ntid.x;
    shl.b32  %r5, %r2, 4;
    cvt.s64.u32 %rd5, %r5;
    add.s64  %rd6, %rd1, %rd5;
    cvta.to.global.u64 %rd7, %rd2;
    mov.u32  %r7, 0;
LOOP:
    cvta.to.global.u64 %rd3, %rd6;
    ld.global.v4.f32 {%f1,%f2,%f3,%f4}, [%rd3];
    add.s32 %r7, %r7, 1;
    setp.lt.s32 %p1, %r7, %r1;
    @%p1 bra LOOP;
    st.global.f32 [%rd7], %f1;
"""

SIG = """( .param .u64 p_a, .param .u64 p_out, .param .u32 p_iter )"""

VARIANTS = [
    ("_ptx_BW_v1.ptx",   "最小骨架：标量载入+标量存储", "v1 minimal: scalar ld + scalar st", V1),
    ("_ptx_BW_v2.ptx",   "加 cvta（FMAPEAK 用过）",     "v2 plus cvta (FMAPEAK uses it)", V2_EXTRA),
    ("_ptx_BW_v3.ptx",   "加线程号/位移计算",           "v3 plus thread-id math", V3_EXTRA),
    ("_ptx_BW_v4.ptx",   "加循环 + generic add.s64",   "v4 plus loop with generic add.s64", V4_EXTRA),
    ("_ptx_BW_v5.ptx",   "加 ld.global.v4 向量载入",   "v5 plus ld.global.v4", V5_EXTRA),
    ("_ptx_BW_v6.ptx",   "cvta+循环+向量载入",          "v6 cvta + loop + v4 load", V6_EXTRA),
]


def build(path, cn_note, ascii_note, body):
    """cn_note 只打印到控制台；进 PTX 的必须是 ascii_note。
    混过一次中文进注释，结果就是 JIT 失败且零提示 —— 这条铁律就在文件头上。"""
    print("生成", path, "|", cn_note)
    txt = (HEAD
           + "// bw bisect variant: " + ascii_note + "\n"
           + "// ASCII comments only -- Chinese breaks the JIT with no message.\n"
           + ".visible .entry bw_read" + SIG + "\n{\n"
           + DECL + body + TAIL)
    with open(path, "w", encoding="ascii", newline="\n") as f:
        f.write(txt)
    return path


def main():
    made = []
    for name, cn_note, ascii_note, body in VARIANTS:
        made.append(build(name, cn_note, ascii_note, body))
    if os.path.exists("_ptx_BW_v7.ptx"):
        print("_ptx_BW_v7.ptx 已存在，跳过")
    else:
        os.replace("_ptx_BWREAD.ptx", "_ptx_BW_v7.ptx")
        print("_ptx_BWREAD.ptx -> _ptx_BW_v7.ptx（保留为对照组）")
        made.append("_ptx_BW_v7.ptx")
    print()
    print(" ".join(made))


if __name__ == "__main__":
    main()
