# _gen_la_cases.py — 把 _la_*.pybk 编码成 tests/cases.py 的回归用例
# 数值已逐个手算核对过（det=10、解=[6,-2]、eig 升序 [2,3]、svd 降序 [3,2]、
# lstsq 精确解 [-1,1]、Cholesky [2,0,1,2]），这里只负责把 stdout/stderr/退出码
# 锁成精确比对串。
import io, os, subprocess, sys

PY = sys.executable

# (源文件, 用例 id, kind, expect, 错误用例要锁的子串)
SPEC = [
    ('_la_t1_solve.pybk',    'T18_la_solve_ok',       'normal',
     '线性代数张量面：行列式/logdet/条件数/秩/solve 的精确值 + A·inv≈I 的残差断言'),
    ('_la_t2_qr.pybk',       'T18_la_qr_ok',          'normal',
     'QR：A=QR 逐项还原、QᵀQ≈I、R 严格上三角（R 的列符号自由，故只验恒等式不逐元素比 Q）'),
    ('_la_t3_chol_eig.pybk', 'T18_la_chol_eig_ok',    'normal',
     'Cholesky 的 A=LLᵀ 还原 + 对称特征值升序、A·V=V·λ、特征值之和等于迹'),
    ('_la_t4_svd_ls.pybk',   'T18_la_svd_lstsq_ok',   'normal',
     'SVD 输出形状 U m×min、VT min×n、奇异值降序；最小二乘给精确解且三个残差为零'),
    ('_la_t5_mp.pybk',       'T18_la_mp_flat_ok',     'normal',
     'mp.* 扁平列表面与 tb.* 张量面同源：mat_det/mat_solve/mat_rank/mat_qr/mat_svd/mat_ls/to_tensor'),

    ('_la_e1_singular.pybk', 'T18_la_singular_err',   'error',
     '奇异矩阵求逆 → 带三段式的运行时错误，并指向 tb.rank/tb.lstsq 的出路',
     ['运行时错误: 第 3 行: tb.inv：这个矩阵是奇异的', '为什么：', '怎么改：', '程序异常退出，退出码 1']),
    ('_la_e2_nonsquare.pybk', 'T18_la_nonsquare_err', 'error',
     '非方阵求行列式 → 带三段式的运行时错误，并指向 tb.qr/tb.svd 的出路',
     ['运行时错误: 第 3 行: tb.det 需要方阵（当前 2x3）', '为什么：', '怎么改：', '程序异常退出，退出码 1']),
    ('_la_e3_notspd.pybk',   'T18_la_notspd_err',     'error',
     '非正定矩阵做 Cholesky → 带三段式的运行时错误（刻意保守，不用不成立的分解算出看着正常的数）',
     ['运行时错误: 第 3 行: tb.cholesky：矩阵不对称，或者不是正定', '为什么：', '怎么改：', '程序异常退出，退出码 1']),
    ('_la_e4_nonsym.pybk',   'T18_la_nonsym_err',     'error',
     '非对称矩阵求特征值 → 带三段式的运行时错误，并指向对称化或 tb.svd',
     ['运行时错误: 第 3 行: tb.eig_sym：矩阵不对称', '为什么：', '怎么改：', '程序异常退出，退出码 1']),
    ('_la_e5_notensor.pybk', 'T18_la_notensor_err',   'error',
     '把普通列表当矩阵传进去 → 带三段式的运行时错误，并给出造张量的正确写法',
     ['运行时错误: 第 3 行: tb.det 需要张量', '为什么：', '怎么改：', '程序异常退出，退出码 1']),
    ('_la_e6_rhslen.pybk',   'T18_la_rhs_len_err',    'error',
     '右端向量长度与系数矩阵阶数不符 → 报错并把目标长度算给你看',
     ['运行时错误: 第 3 行: tb.solve：右端向量长度 3', '为什么：', '怎么改：', '程序异常退出，退出码 1']),
    ('_la_e7_flatlen.pybk',  'T18_la_flat_len_err',   'error',
     'mp.* 扁平列表长度与行列数之积不符 → math+ 自己的维度校验（mat_det 走的是 mathplus.c 那条老路）',
     ['math+ 运行时错误: mp.mat_det 维度不符', '程序异常退出，退出码 1']),
]


def rd(p):
    return io.open(p, encoding='utf-8', newline='').read()


def run(src_path):
    env = {k: v for k, v in os.environ.items() if k != 'COLUMNS'}
    env['PYBOOK_NO_CACHE'] = '1'
    p = subprocess.run([PY, 'pybk_main.py', src_path], env=env,
                       capture_output=True, text=True, encoding='utf-8',
                       errors='replace', timeout=180)
    return (p.stdout.replace('\r\n', '\n'), p.stderr.replace('\r\n', '\n'),
            p.returncode)


def lit(s):
    """Python 字面量，保留中文可读性（不用 ascii()，cases.py 本身就是 UTF-8 中文）。"""
    return repr(s)


lines = []
for spec in SPEC:
    srcf, cid, kind, expect = spec[0], spec[1], spec[2], spec[3]
    contains = spec[4] if len(spec) > 4 else []
    src = rd(srcf)
    out, err, rc = run(srcf)
    d = "'id': %s, 'kind': %s, 'src': %s" % (lit(cid), lit(kind), lit(src))
    if kind == 'normal':
        d += ", 'out': %s, 'err': %s" % (lit(out), lit(err))
        d += ", 'err_contains': []"
        if rc != 0:
            # 正常用例却拿到非 0 退出码：不当成通过，直接炸出来让人看
            raise SystemExit('用例 %s 退出码 %d，stderr:\n%s' % (cid, rc, err))
    else:
        d += ", 'out': %s, 'exit': %d" % (lit(out), rc)
        d += ", 'err_contains': [%s]" % ', '.join(lit(s) for s in contains)
    d += ", 'expect': %s" % lit(expect)
    if kind == 'error':
        # 错误用例不锁 stderr 全文（文案会迭代），把实际首行留在上一行注释里备查。
        # 注释必须单独成行：放在 case(...) 同一行的行尾会把收尾的 }) 一起吃掉。
        lines.append('# %s 实际 stderr 首行: %s' % (cid, lit(err.split('\n')[0])))
    lines.append('case(**{%s})' % d)

block = ('\n# ── 线性代数（pybook_la.c，对拍 NumPy.linalg 到 2.1e-14）──\n'
         '# 浮点断言一律走语言内的 接近() 容差比较并打印通过标记，'
         '不比对 %.15g 的打印串：\n'
         '# 差 1 个 ULP 时 %.15g 会从 0.6 变成 0.599999999999999，'
         '那样写用例就只是在锁运气。\n'
         + '\n'.join(lines) + '\n')

with io.open('tests/cases.py', 'a', encoding='utf-8', newline='\n') as f:
    f.write(block)
print('已追加 %d 个用例到 tests/cases.py' % len(lines))
