# -*- coding: utf-8 -*-
"""_gen_calc_cases.py — 把数值微积分/求根的用例编码进 tests/cases.py

数值已逐个核对：
  x² 在 3 的导数      6.00000000003931  （理论 6）
  x³ 在 2 的导数      12.0000000003895  （理论 12）
  sin 在 0 的导数     0.999999999983333 （理论 1）
  x³ 积分 0→2        4                 （理论 x⁴/4 = 4，Simpson 对三次多项式精确）
  sin 积分 0→π       2.0000000108245   （理论 2）
  x³ 在 1 的泰勒系数 [1, 3, 1.5, 0.5]  （精确等于展开式）
  mec.apply 仍返回 25（回调槽没改动原有分发表）
"""
import io, os, subprocess, sys

PY = sys.executable
HERE = os.path.dirname(os.path.abspath(__file__))

SPEC = [('_calc_t1.pybk', 'T21_calc_ok', 'normal',
         '库函数回调用户 lambda：中心差分求导（默认步长与显式步长）、'
         '复合 Simpson 积分、二分/牛顿求根（数值导数与解析导数）、泰勒系数；'
         '同时验证 mec.apply 原有的分发表没被动过')]

ERR = [
    ('_calc_e1_bisect.pybk', 'T21_bisect_same_sign_err',
     '二分法两端同号 → 报错并把两端的函数值算给你看（同号时二分会收敛到错的点，'
     '静默返回一个数会让人以为求成功了）', '两端同号'),
    ('_calc_e2_newton.pybk', 'T21_newton_stall_err',
     '牛顿法在导数为 0 处卡住 → 报错并说明除数为 0', '导数为 0'),
    ('_calc_e3_deriv.pybk', 'T21_deriv_step_err',
     '步长相对 x 太小（x+h 舍入后还是 x）→ 报错并给出可用的替代步长', '来说太小'),
    ('_calc_e4_ret.pybk', 'T21_callback_type_err',
     '回调的函数返回的不是数字 → 报错（静默当 0 会让结果全错却看不出原因）',
     '没有返回数字'),
    ('_calc_e5_arity.pybk', 'T21_calc_arity_err',
     '可选参数入口的参数个数越界 → **编译期**报错写成 2~3 的区间（新机制）。'
     '注意它走的是前端 PybkError（编译失败）这条路，stderr 里没有运行时的尾行',
     '需要 2~3 个参数'),
    ('_calc_e6_revb.pybk', 'T21_integrate_range_err',
     '积分上限小于下限 → 报错（本函数按 [下限,上限] 处理，不做反向）', '上限要大于下限'),
]


def run(src):
    env = {k: v for k, v in os.environ.items() if k != 'COLUMNS'}
    env['PYBOOK_NO_CACHE'] = '1'
    p = subprocess.run([PY, 'pybk_main.py', src], env=env, cwd=HERE,
                       capture_output=True, text=True, encoding='utf-8',
                       errors='replace', timeout=300)
    return (p.stdout.replace('\r\n', '\n'), p.stderr.replace('\r\n', '\n'), p.returncode)


# 编译期错误（前端 PybkError）没有「程序异常退出」尾行，其余是运行时错误
SUBS = {c: ([s] if c == 'T21_calc_arity_err' else [s, '程序异常退出，退出码 1'])
        for _f, c, _e, s in ERR}

lines = []
for srcf, cid, kind, expect in SPEC:
    out, err, rc = run(srcf)
    if rc != 0:
        raise SystemExit('用例 %s 退出码 %d\n%s' % (cid, rc, err))
    src = io.open(srcf, encoding='utf-8', newline='').read()
    lines.append('case(**{%s})' % (
        "'id': %s, 'kind': 'normal', 'src': %s, 'out': %s, 'err': %s, "
        "'err_contains': [], 'expect': %s"
        % (repr(cid), repr(src), repr(out), repr(err), repr(expect))))

for srcf, cid, expect, sub in ERR:
    out, err, rc = run(srcf)
    src = io.open(srcf, encoding='utf-8', newline='').read()
    lines.append('# %s 实际 stderr 首行: %s' % (cid, repr(err.split('\n')[0])))
    lines.append('case(**{%s})' % (
        "'id': %s, 'kind': 'error', 'src': %s, 'out': %s, 'exit': %d, "
        "'err_contains': [%s], 'expect': %s"
        % (repr(cid), repr(src), repr(out), rc,
           ', '.join(repr(s) for s in SUBS[cid]), repr(expect))))

block = ('\n# ── 数值微积分与求根（库函数回调用户 lambda；C 后端）──\n'
         '# 回调靠运行时新加的分发函数指针（rt_set_fn_dispatch / rt_call_value），\n'
         '# 由编译器在 main() 开头装入。lambda 本身在字节码后端还不支持，\n'
         '# pybk_bc.py 会给出可操作的提示而不是节点名。\n'
         + '\n'.join(lines) + '\n')

with io.open('tests/cases.py', 'a', encoding='utf-8', newline='\n') as f:
    f.write(block)
print('已追加 %d 个用例' % (len(SPEC) + len(ERR)))
