"""把 PNG 的某条横带裁出来放大 N 倍另存，用来肉眼核对图上到底写了什么字。
只用标准库（zlib + struct 手写 PNG 编码），不依赖 PYbook。"""
import struct
import sys
import zlib

sys.stdout.reconfigure(encoding='utf-8')


def read_png(path):
    raw = open(path, 'rb').read()
    i, idat = 8, b''
    while i + 8 <= len(raw):
        ln = struct.unpack('>I', raw[i:i + 4])[0]
        typ = raw[i + 4:i + 8]
        if typ == b'IHDR':
            W, H = struct.unpack('>II', raw[i + 8:i + 16])
        if typ == b'IDAT':
            idat += raw[i + 8:i + 8 + ln]
        i += 12 + ln
    px = zlib.decompress(idat)
    return W, H, px


def write_png(path, w, h, rows):
    def chunk(t, d):
        c = t + d
        return struct.pack('>I', len(d)) + c + struct.pack('>I', zlib.crc32(c) & 0xFFFFFFFF)

    ihdr = struct.pack('>IIBBBBB', w, h, 8, 6, 0, 0, 0)
    body = b''.join(b'\x00' + r for r in rows)
    open(path, 'wb').write(
        b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', ihdr)
        + chunk(b'IDAT', zlib.compress(body, 9)) + chunk(b'IEND', b''))


src, dst = sys.argv[1], sys.argv[2]
y0, y1, scale = int(sys.argv[3]), int(sys.argv[4]), int(sys.argv[5])
x0 = int(sys.argv[6]) if len(sys.argv) > 6 else 0
x1 = int(sys.argv[7]) if len(sys.argv) > 7 else 0

W, H, px = read_png(src)
st = W * 4 + 1
if x1 <= x0:
    x1 = W
cw, ch = x1 - x0, y1 - y0

rows = []
for y in range(y0, y1):
    line = px[y * st + 1 + x0 * 4: y * st + 1 + x1 * 4]
    big = b''.join(line[k * 4:k * 4 + 4] * scale for k in range(cw))
    for _ in range(scale):
        rows.append(big)

write_png(dst, cw * scale, ch * scale, rows)
print('已写 %s（%dx%d -> %dx%d）' % (dst, cw, ch, cw * scale, ch * scale))
