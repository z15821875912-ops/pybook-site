/* _pfrepro.c — 最小复现：照抄 polyfit 的建矩阵 + lib_gauss，把矩阵和主元打出来 */
#include <stdio.h>
#include <math.h>
#include <stdlib.h>

static int lib_gauss(double *a, double *b, int m, double *x)
{
    int    i, j, k;
    double t;
    for (k = 0; k < m; k++) {
        int    piv = k;
        double best = fabs(a[(size_t)k * m + k]);
        for (i = k + 1; i < m; i++) {
            t = fabs(a[(size_t)i * m + k]);
            if (t > best) { best = t; piv = i; }
        }
        printf("  第%d列主元 = %g (行 %d)%s\n", k, best, piv,
               best < 1e-300 ? "  <<< 判成奇异" : "");
        if (best < 1e-300) return 0;
        if (piv != k) {
            for (j = 0; j < m; j++) {
                t = a[(size_t)k * m + j];
                a[(size_t)k * m + j] = a[(size_t)piv * m + j];
                a[(size_t)piv * m + j] = t;
            }
            t = b[k]; b[k] = b[piv]; b[piv] = t;
        }
        for (i = k + 1; i < m; i++) {
            double f = a[(size_t)i * m + k] / a[(size_t)k * m + k];
            a[(size_t)i * m + k] = 0.0;
            for (j = k + 1; j < m; j++)
                a[(size_t)i * m + j] -= f * a[(size_t)k * m + j];
            b[i] -= f * b[k];
        }
    }
    for (i = m - 1; i >= 0; i--) {
        double s = b[i];
        for (j = i + 1; j < m; j++) s -= a[(size_t)i * m + j] * x[j];
        x[i] = s / a[(size_t)i * m + i];
    }
    return 1;
}

int main(void)
{
    double x[5] = {0, 1, 2, 3, 4}, y[5] = {0, 1, 4, 9, 16};
    long long n = 5, i, j, k;
    int deg = 2, m = deg + 1;
    double mx[5], my[5], A[9], B[3], cx[3];
    double sx = 0, sy = 0;

    for (i = 0; i < n; i++) { sx += x[i]; sy += y[i]; }
    sx /= (double)n; sy /= (double)n;
    for (i = 0; i < n; i++) { mx[i] = x[i] - sx; my[i] = y[i] - sy; }
    printf("mx = "); for (i = 0; i < n; i++) printf("%g ", mx[i]);
    printf("\nmy = "); for (i = 0; i < n; i++) printf("%g ", my[i]);
    printf("\n\n");

    for (i = 0; i < (long long)(m * m); i++) A[i] = 0.0;
    for (i = 0; i < m; i++) B[i] = 0.0;
    for (i = 0; i < n; i++) {
        double pw = 1.0;
        for (j = 0; j < m; j++) {
            for (k = 0; k < m; k++) A[(size_t)j * m + k] += pw;
            B[j] += pw * my[i];
            pw *= mx[i];
        }
    }
    printf("A =\n");
    for (j = 0; j < m; j++) {
        printf("  ");
        for (k = 0; k < m; k++) printf("%12.6f", A[(size_t)j * m + k]);
        printf("\n");
    }
    printf("B = "); for (j = 0; j < m; j++) printf("%g ", B[j]); printf("\n\n");

    printf("消元：\n");
    int ok = lib_gauss(A, B, m, cx);
    printf("lib_gauss 返回 %d\n", ok);
    if (ok) {
        printf("系数（中心化基底）c = ");
        for (j = 0; j < m; j++) printf("%g ", cx[j]);
        printf("\n  注意这是 (x-2) 的幂，不是 x 的幂\n");
    }
    return 0;
}
