/* 探针：SDL 软件渲染器「命令队列」到底什么时候才落进 target surface
 *
 * 背景：3D+UI 同屏时 UI 渲进一块内存 surface，没有 SDL_RenderPresent 那一环
 * （Present 是窗口模式 rt_game_frame 的活）。如果软件渲染器把绘制命令排队、
 * 直到 present 才 flush，那 UI 就等于什么都没画 —— 但 clear() 又确实落了盘，
 * 两者矛盾，必须实测分清。
 *
 * 测 4 组，每组都在 present 前后各读一次 surface 像素：
 *   A  RenderClear
 *   B  RenderFillRect
 *   C  RenderCopy（文字纹理走的就是这条路）
 *   D  RenderDrawLine
 * 另外测：RenderReadPixels 自己会不会顺手 flush。
 */
#include <stdio.h>
#include <string.h>
#include <SDL2/SDL.h>

static SDL_Surface *g_surf = NULL;
static SDL_Renderer *g_ren  = NULL;

static void px(const char *tag, int x, int y)
{
    Uint32 v = 0;
    uint8_t *p = (uint8_t *)g_surf->pixels + y * g_surf->pitch + x * 4;
    SDL_memcpy(&v, p, 4);
    printf("  %-22s (%3d,%3d) = A%02X R%02X G%02X B%02X\n",
           tag, x, y, (v >> 24) & 0xFF, (v >> 16) & 0xFF, (v >> 8) & 0xFF, v & 0xFF);
}

static int fail(const char *what)
{
    printf("[FAIL] %s: %s\n", what, SDL_GetError());
    return 1;
}

int main(void)
{
    SDL_Surface *tiny;
    SDL_Texture *tex;
    int bad = 0;

    if (SDL_Init(SDL_INIT_VIDEO) != 0)
        return fail("SDL_Init");

    g_surf = SDL_CreateRGBSurfaceWithFormat(0, 64, 64, 32, SDL_PIXELFORMAT_ARGB8888);
    if (!g_surf)
        return fail("CreateRGBSurface");
    SDL_FillRect(g_surf, NULL, 0x00000000u);
    printf("surface = %dx%d pitch=%d ARGB8888\n", g_surf->w, g_surf->h, g_surf->pitch);

    g_ren = SDL_CreateSoftwareRenderer(g_surf);
    if (!g_ren)
        return fail("CreateSoftwareRenderer");

    /* 一张 8x8 纯红纹理，代表「文字光栅化出来的字形纹理」 */
    tiny = SDL_CreateRGBSurfaceWithFormat(0, 8, 8, 32, SDL_PIXELFORMAT_ARGB8888);
    SDL_FillRect(tiny, NULL, 0xFFFF2020u);
    tex = SDL_CreateTextureFromSurface(g_ren, tiny);
    if (!tex)
        bad |= fail("CreateTextureFromSurface");

    SDL_SetRenderDrawBlendMode(g_ren, SDL_BLENDMODE_BLEND);

    /* A: 清屏成半透明绿 */
    SDL_SetRenderDrawColor(g_ren, 0, 200, 0, 128);
    SDL_RenderClear(g_ren);
    /* B: 填充矩形成实心蓝 */
    SDL_SetRenderDrawColor(g_ren, 0, 0, 255, 255);
    { SDL_Rect r = { 20, 20, 10, 10 }; SDL_RenderFillRect(g_ren, &r); }
    /* C: 贴纹理到 (40,40) */
    { SDL_Rect d = { 40, 40, 8, 8 }; SDL_RenderCopy(g_ren, tex, NULL, &d); }
    /* D: 画线从 (0,60) 到 (63,60) */
    SDL_SetRenderDrawColor(g_ren, 255, 255, 0, 255);
    SDL_RenderDrawLine(g_ren, 0, 60, 63, 60);

    printf("\n--- present 之前（只发了命令，没 present）---\n");
    px("A clear",        0,  0);
    px("B fillrect",    25, 25);
    px("C texture",     44, 44);
    px("D drawline",    30, 60);

    printf("\n--- SDL_RenderPresent 之后 ---\n");
    SDL_RenderPresent(g_ren);
    px("A clear",        0,  0);
    px("B fillrect",    25, 25);
    px("C texture",     44, 44);
    px("D drawline",    30, 60);

    /* 结论校验：present 后应当 A=8020C800? 实际 alpha 混合的清屏语义见下 */
    {
        Uint32 *pp = (Uint32 *)((uint8_t *)g_surf->pixels + 25 * g_surf->pitch + 25 * 4);
        if ((*pp & 0x00FFFFFFu) != 0x0000FFu) {
            printf("[FAIL] B: 填充矩形没落进 surface\n");
            bad = 1;
        } else {
            printf("[OK] B RenderFillRect 落盘（需要 Present/Flush）\n");
        }
        pp = (Uint32 *)((uint8_t *)g_surf->pixels + 44 * g_surf->pitch + 44 * 4);
        if ((*pp & 0x00FFFFFFu) != 0x002020u) {
            printf("[FAIL] C: 纹理没落进 surface\n");
            bad = 1;
        } else {
            printf("[OK] C RenderCopy 落盘（需要 Present/Flush）\n");
        }
        pp = (Uint32 *)((uint8_t *)g_surf->pixels + 60 * g_surf->pitch + 30 * 4);
        if ((*pp & 0x00FFFFFFu) != 0x00FFFFu) {
            printf("[FAIL] D: 画线没落进 surface\n");
            bad = 1;
        } else {
            printf("[OK] D RenderDrawLine 落盘（需要 Present/Flush）\n");
        }
    }

    /* 第二问：RenderReadPixels 会不会顺手 flush？（截图路径依赖它） */
    {
        Uint32 *out = (Uint32 *)SDL_malloc(64 * 64 * 4);
        Uint32 *p2;
        SDL_SetRenderDrawColor(g_ren, 0, 0, 0, 0);
        { SDL_Rect r = { 0, 30, 4, 4 }; SDL_RenderFillRect(g_ren, &r); }
        px("before readpixels", 1, 31);
        if (SDL_RenderReadPixels(g_ren, NULL, SDL_PIXELFORMAT_ARGB8888, out, 64 * 4) != 0) {
            bad |= fail("RenderReadPixels");
        }
        p2 = (Uint32 *)((uint8_t *)g_surf->pixels + 31 * g_surf->pitch + 1 * 4);
        printf("  after  readpixels -> surface A%02X R%02X G%02X B%02X\n",
               (*p2 >> 24) & 0xFF, (*p2 >> 16) & 0xFF, (*p2 >> 8) & 0xFF, *p2 & 0xFF);
        SDL_free(out);
    }

    /* 第三问：SDL_RenderFlush 是不是比 Present 更轻？语义等价吗？ */
    {
        Uint32 *p2;
        SDL_SetRenderDrawColor(g_ren, 0, 255, 255, 255);
        { SDL_Rect r = { 50, 5, 6, 6 }; SDL_RenderFillRect(g_ren, &r); }
        px("flush 前", 52, 7);
        SDL_RenderFlush(g_ren);
        p2 = (Uint32 *)((uint8_t *)g_surf->pixels + 7 * g_surf->pitch + 52 * 4);
        printf("  flush 后 -> A%02X R%02X G%02X B%02X  (0,255,255,255 = flush 生效)\n",
               (*p2 >> 24) & 0xFF, (*p2 >> 16) & 0xFF, (*p2 >> 8) & 0xFF, *p2 & 0xFF);
        if ((*p2 & 0x00FFFFFFu) != 0x00FFFFu) {
            printf("[FAIL] SDL_RenderFlush 没落盘\n");
            bad = 1;
        } else {
            printf("[OK] SDL_RenderFlush 落盘\n");
        }
    }

    SDL_DestroyTexture(tex);
    SDL_FreeSurface(tiny);
    SDL_DestroyRenderer(g_ren);
    SDL_FreeSurface(g_surf);
    SDL_Quit();
    printf("\n%s\n", bad ? "=== 有 FAIL ===" : "=== 全过 ===");
    return bad;
}
