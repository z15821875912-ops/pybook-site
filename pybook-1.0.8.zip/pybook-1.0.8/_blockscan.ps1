$ErrorActionPreference = 'Continue'
$env:PYTHONIOENCODING = "utf-8"
$gcc = "C:\Users\zhuli\mingw64\bin\x86_64-w64-mingw32-gcc.exe"
$env:PUBENCH_BLOCK = $null

# 候选：先扫等边，再试 KC/NC 与 MC 拆开配。
# 背景：注释说 48 是「扫描调优定的」，但扫描出来的曲线坐在 640/896 两个坑里 ——
# 说明那次只看平均值。这里看**中位数**，并且宁可全尺寸一起好，也不要只在某一点好看。
$cands = @(
  "48,48,48",   # 生产现值
  "64,64,64",
  "96,96,96",
  "64,64,48",
  "96,96,64",
  "32,32,32"
)

foreach ($c in $cands) {
  $env:PUBENCH_BLOCK = $c
  $tag = $c -replace ',', '-'
  Write-Output "########## KC,NC,MC = $c ##########"
  python -B _cpubench_gen.py 2>&1 | Out-String | Write-Output
  & $gcc _cpubench.c pybook_mt.c -o _cpubench.exe -O3 -march=native -lm 2>&1 | Out-String | Write-Output
  if ($LASTEXITCODE -ne 0) { Write-Output "编译失败，跳过"; continue }
  .\_cpubench.exe 6 9 2>&1 | Select-String -Pattern '^\s+\d+\s+\d+\s+\d+\s+\|' |
      ForEach-Object { $_.Line } | Tee-Object -FilePath "_scan_$tag.txt" | Write-Output
}

# 扫完必须还原成生产分块，别把实验脚手架留在生成物里
$env:PUBENCH_BLOCK = $null
Write-Output "########## 还原生产分块 ##########"
python -B _cpubench_gen.py 2>&1 | Out-String | Write-Output
& $gcc _cpubench.c pybook_mt.c -o _cpubench.exe -O3 -march=native -lm 2>&1 | Out-String | Write-Output
Select-String -Path _cpubench_core.inc -Pattern '^#define TB_(KC|NC|MC)' |
    ForEach-Object { "  $($_.Line)" }
