import subprocess, sys, io
sys.stdout.reconfigure(encoding='utf-8')

EXPRS = [
    ('1+2*3', 0, 7), ('(1+2)*3', 0, 9), ('2^10', 0, 1024),
    ('2^3^2', 0, 512), ('-3^2', 0, -9), ('0-3^2', 0, -9),
    ('2^-2', 0, 0.25), ('7/2', 0, 3.5), ('sin(0)', 0, 0),
    ('x*x', 7, 49), ('x^2+1', 3, 10), ('sqrt(16)', 0, 4),
    ('abs(0-3.5)', 0, 3.5), ('max(2,9)', 0, 9), ('pi', 0, 3.14159),
    ('sin(x)', 1.5707963, 1),
]

for e, x, want in EXPRS:
    src = ('@ 试值>%s\n\nGOING:{\nvg.v = 图.试值("%s", %s)\n'
           'ns.show("%s @ x=%s ->", v)\n}STOP\n' % (e, e, x, e, x))
    io.open('_试值.pybk', 'w', encoding='utf-8', newline='\n').write(src)
    try:
        r = subprocess.run([sys.executable, 'pybk_main.py', '_试值.pybk'],
                           capture_output=True, text=True, encoding='utf-8',
                           timeout=120, errors='replace')
        out = [l for l in (r.stdout or '').split('\n') if l.strip()]
        got = out[-1] if out else '(无输出)'
        ok = 'OK ' if r.returncode == 0 else 'ERR'
        print('  %s %-14s x=%-9s 期望 %-9s  %s' % (ok, e, x, want, got))
    except subprocess.TimeoutExpired:
        print('  TIMEOUT %s' % e)
