#version 120
// 星核 · 顶点阶段：沿半径方向做"活体脉动"位移 + 重算法线
//
// 两件固定管线做不到的事：
//   1. 顶点的位置是算出来的 —— 球面被顶成一圈圈鼓包；
//   2. 位移之后法线必须跟着重算。只位移不算法线 = 明暗还是光溜溜的球，
//      鼓包看起来像贴上去的花纹；重算法线之后才真的是"长出来的"。
//
// 球面是二维曲面，所以在切平面里取两个正交方向做有限差分，叉乘就是新法线。
// 每次多算 4 遍噪声，一个球 ~434 个顶点，代价可以忽略。
varying vec3 vN;
varying vec3 vC;
varying vec2 vUV;
varying vec3 vW;
varying vec3 vNat;
varying vec3 vEye;
varying float vD;

uniform float cTime;
uniform float cSpike;
uniform vec3  cCenter;     // 球心（世界坐标）
uniform float cRad;        // 球半径

float lump(vec3 p){
  return sin(p.x * 2.3 + p.y * 1.7)
       * sin(p.y * 2.9 - p.z * 2.1)
       * sin(p.z * 2.5 + p.x * 1.3);
}

// 只跟"方向"有关 → 相机绕圈时图案锁在球上，不会滑动
float wave(vec3 n){
  return lump(n * 3.1 + vec3(0.0, cTime * 1.10, 0.0))
       + 0.62 * lump(n * 6.7 - vec3(cTime * 1.60, 0.0, cTime * 0.90))
       + 0.30 * sin(n.y * 11.0 - cTime * 2.30);
}

void main(){
  vec3  p = gl_Vertex.xyz;
  vec3  n = normalize(p - cCenter);
  float w = wave(n) * cSpike;

  // 切平面基（n 接近 ±Y 时换一个 up，避免叉乘退化成 0）
  vec3 up = (abs(n.y) < 0.95) ? vec3(0.0, 1.0, 0.0) : vec3(1.0, 0.0, 0.0);
  vec3 t1 = normalize(cross(n, up));
  vec3 t2 = normalize(cross(n, t1));

  float e  = 0.07;
  vec3  n1 = normalize(n + t1 * e);
  vec3  n2 = normalize(n + t2 * e);

  vec3 P0 = n  * (cRad + w);
  vec3 P1 = n1 * (cRad + wave(n1) * cSpike);
  vec3 P2 = n2 * (cRad + wave(n2) * cSpike);

  // (t1, t2, n) 是右手系 → 差分叉乘出来的法线朝外，不用再翻符号
  vec3 nw = normalize(cross(P1 - P0, P2 - P0));
  vec3 pp = P0 + cCenter;

  vD   = wave(n);
  vNat = nw;
  vN   = gl_NormalMatrix * nw;
  vC   = gl_Color.rgb;
  vUV  = gl_MultiTexCoord0.xy;
  vW   = pp;
  vEye = (gl_ModelViewMatrix * vec4(pp, 1.0)).xyz;
  gl_Position = gl_ModelViewProjectionMatrix * vec4(pp, 1.0);
}
