#version 120
// 地面 · 片段阶段：现场算网格（不采样任何贴图）+ 向外走的能量环
// fract() 直接把世界坐标变成格子，所以网格是"世界锁定"的：地形起伏时
// 网格跟着扭。固定管线只能靠贴图 + UV 硬凑，一扭就穿帮。
varying vec3 vN;
varying vec2 vUV;
varying vec3 vW;
varying vec3 vNat;
varying vec3 vEye;

uniform vec3 uLight;

uniform float fTime;
uniform float fCell;      // 一格的边长（世界单位）
uniform vec3  fLine;      // 网格线颜色
uniform vec3  fFill;      // 底色

float grid(vec2 q, float w){
  vec2 g = abs(fract(q) - vec2(0.5, 0.5));
  float d = min(g.x, g.y);
  return 1.0 - smoothstep(0.0, w, d);
}

void main(){
  vec3 N = normalize(vN);
  vec3 L = normalize(uLight);
  float dif = max(dot(N, L), 0.0);
  float cut = clamp(0.30 + 0.85 * dif, 0.0, 1.20);

  vec2 q = vW.xz / fCell;
  float g1 = grid(q, 0.055);                 // 细格
  float g2 = grid(q * 0.2, 0.020);           // 每 5 格一条粗线

  float r = length(vW.xz);
  float puls = sin(r * 0.55 - fTime * 2.60);
  float ring = smoothstep(0.20, 0.98, puls * 0.5 + 0.5);

  float lift = clamp(vW.y * 0.42 + 0.55, 0.05, 1.55);

  vec3 col = fFill * cut;
  col = col + fLine * (g1 * 0.20 + g2 * 0.52) * (0.35 + 0.60 * lift);
  col = col + fLine * ring * g1 * 0.50;
  col = col * (0.70 + 0.35 * ring);

  gl_FragColor = vec4(col, 1.0);
}
