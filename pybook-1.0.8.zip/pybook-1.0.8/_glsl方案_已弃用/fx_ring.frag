#version 120
// 能量环 / 冲击波壁 · 片段阶段：按世界角向算"彗尾脉冲"
//
// atan(d.z, d.x) 得到绕竖轴的角度 → 几段脉冲沿环流动。
// 因为用的是**世界角度**，环被拆成几十个独立盒子照样连成一条完整光带 ——
// 固定管线只能靠每段自己的 UV，段与段之间必然接不上。
//
// rCut 是"暗尾挖空阈值"：环用 0（暗尾也留一点，光带不断），
// 冲击波用大一点的值 → 墙变成一圈断续飞散的弧，而不是一堵实心紫墙。
// 两个槽各自装一份程序、uniform 互相独立，所以同一份源码能有两副面孔。
varying vec3 vN;
varying vec2 vUV;
varying vec3 vW;
varying vec3 vNat;
varying vec3 vEye;

uniform vec3 uLight;

uniform vec3  rCore;     // 环心（只用 x/z）
uniform float rTime;
uniform float rFlow;     // 流动速度
uniform float rBand;     // 环上一共几段脉冲
uniform float rGain;
uniform float rFade;     // 整体淡出（冲击波用）
uniform float rSharp;    // 1 → 彗尾；0 → 均匀环
uniform float rCut;      // 脉冲弱于它就 discard
uniform vec3  rColA;     // 尾巴色
uniform vec3  rColB;     // 头部色

void main(){
  vec3 d = vW - rCore;
  float ang = atan(d.z, d.x) * 0.15915494;         // /2pi → -0.5 .. 0.5
  float f = fract(ang * rBand - rTime * rFlow);
  float pulse = 1.0 - f;                            // 0 在头部，1 在尾端
  pulse = pulse * pulse * pulse;
  pulse = mix(pulse, 1.0, 1.0 - rSharp);

  if (pulse < rCut) discard;

  vec3 N = normalize(vN);
  vec3 V = normalize(-vEye);
  float rim = 1.0 - abs(dot(N, V));
  rim = rim * rim;

  vec3 col = mix(rColA, rColB, pulse);
  col = col * (0.52 + 1.85 * pulse);
  col = col + rColB * rim * 1.30;

  gl_FragColor = vec4(col * rGain * rFade, 1.0);
}
