#version 120
// 通用顶点阶段：不做位移，只把坐标系搬到 varying 里
// 注意 vW = gl_Vertex 是"世界坐标"—— hw.box / hw.sphere / hw.cyl 都把顶点
// 直接写在绝对坐标上，所以 vW 就是世界位置。于是"沿环流动"这种效果可以
// 按世界角度算，整圈图案天然连成一体，跨几十个独立盒子也对得上。
varying vec3 vN;
varying vec2 vUV;
varying vec3 vW;
varying vec3 vNat;
varying vec3 vEye;

void main(){
  vN   = gl_NormalMatrix * gl_Normal;
  vNat = gl_Normal;
  vUV  = gl_MultiTexCoord0.xy;
  vW   = gl_Vertex.xyz;
  vEye = (gl_ModelViewMatrix * gl_Vertex).xyz;
  gl_Position = gl_ModelViewProjectionMatrix * gl_Vertex;
}
