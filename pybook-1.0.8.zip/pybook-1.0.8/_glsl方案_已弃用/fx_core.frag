#version 120
// 星核 · 片段阶段：双色等离子 + 菲涅尔边缘 + 流动的丝
// 位移量 vD 直接参与配色：鼓出来的地方就是"最热"的地方。
varying vec3 vN;
varying vec3 vC;
varying vec2 vUV;
varying vec3 vW;
varying vec3 vNat;
varying vec3 vEye;
varying float vD;

uniform vec3  uLight;      // 引擎每帧灌

uniform float cTime;
uniform float cGain;
uniform float cVein;
uniform vec3  cHot;        // 凸起/受光处
uniform vec3  cCool;       // 凹陷/背光处

void main(){
  vec3 N = normalize(vN);
  vec3 V = normalize(-vEye);
  vec3 L = normalize(uLight);

  float dif = max(dot(N, L), 0.0);
  float amb = 0.22 + 0.78 * dif;
  float rim = 1.0 - max(dot(N, V), 0.0);
  rim = rim * rim * rim;

  // 三层不同频率/方向的条纹 —— 看起来像流动的等离子丝
  float s1 = sin(vW.y * 5.7 - cTime * 5.0 + vW.x * 2.9);
  float s2 = sin(vW.z * 6.3 + cTime * 3.7 - vW.y * 4.1);
  float s3 = sin(vNat.x * 13.0 + vNat.z * 10.0 - cTime * 6.0);
  float vein = 0.5 + 0.20 * s1 + 0.20 * s2 + 0.14 * s3;

  float hot = clamp(vD * 0.85 + 0.50, 0.0, 1.0);
  vec3 col = mix(cCool, cHot, clamp(hot * 0.80 + (vein - 0.5) * 0.90, 0.0, 1.0));
  col = col * (0.30 + 0.85 * amb);
  col = col + cHot * rim * 0.90;
  col = col + cHot * (hot * hot) * cVein * 0.45;

  gl_FragColor = vec4(col * cGain * (0.80 + 0.35 * vein), 1.0);
}
