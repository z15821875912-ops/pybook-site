#version 120
// 光柱 / 火花 · 片段阶段：沿世界 y 滚动的能量带 + 轮廓光
// 粒子也用这颗 shader 画：小盒子在世界里飘，明暗带随高度自己流动。
varying vec3 vN;
varying vec2 vUV;
varying vec3 vW;
varying vec3 vNat;
varying vec3 vEye;

uniform vec3 uLight;

uniform float pTime;
uniform float pGain;
uniform float pSpeed;
uniform vec3  pColA;
uniform vec3  pColB;

void main(){
  float band = 0.5 + 0.5 * sin(vW.y * 1.35 - pTime * pSpeed);
  band = band * band;
  float fine = 0.5 + 0.5 * sin(vW.y * 7.0 - pTime * pSpeed * 1.7);

  vec3 N = normalize(vN);
  vec3 V = normalize(-vEye);
  float rim = 1.0 - abs(dot(N, V));
  rim = rim * rim;

  vec3 col = mix(pColA, pColB, band);
  col = col * (0.10 + 1.05 * band) + pColB * rim * 1.05;
  col = col * (0.80 + 0.25 * fine);

  gl_FragColor = vec4(col * pGain, 1.0);
}
