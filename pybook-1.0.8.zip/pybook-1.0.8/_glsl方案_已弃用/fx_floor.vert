#version 120
// 地面 · 顶点阶段：把 y 抬成高度场（只动 y，不动 x/z → 是标准的高度场变形）
// 地面由 400 块小砖拼成，所以能真的起伏；一整块大板子的话只有 4 个角会动。
varying vec3 vN;
varying vec2 vUV;
varying vec3 vW;
varying vec3 vNat;
varying vec3 vEye;

uniform float fTime;
uniform float fAmp;

void main(){
  vec3 p = gl_Vertex.xyz;
  float r  = length(p.xz);

  float w1 = sin(p.x * 0.21 + fTime * 0.85) * cos(p.z * 0.185 - fTime * 0.70);
  float w2 = sin(r * 0.62 - fTime * 2.30);          // 从核心向外扩散的圆波
  float w3 = 2.60 * exp(0.0 - r * 0.045);            // 核心脚下隆起

  p.y = p.y + (w1 * 0.70 + w2 * 0.85 + w3) * fAmp;

  vW   = p;
  vN   = gl_NormalMatrix * gl_Normal;
  vNat = gl_Normal;
  vUV  = gl_MultiTexCoord0.xy;
  vEye = (gl_ModelViewMatrix * vec4(p, 1.0)).xyz;
  gl_Position = gl_ModelViewProjectionMatrix * vec4(p, 1.0);
}
