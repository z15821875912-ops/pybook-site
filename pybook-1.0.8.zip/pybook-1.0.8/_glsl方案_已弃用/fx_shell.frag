#version 120
// 力场壳 · 片段阶段：三平面六边形晶格 + 菲涅尔 + 竖向扫掠
//
// 关键是"三平面"投影：uv = D.zx / |D.y| —— 除以主轴分量之后，六边形在
// 球面上才近似等大；不除的话格子会被斜着拉长，糊成一片三角屑。
// 三个平面各算一套，再用 |D| 的四次方当权重混合（过渡带很窄，看不出接缝）。
//
// 最后一行 discard 把格心整块丢掉 → 壳变成"镂空的笼子"，
// 于是能透过网格看到里面的星核：不靠混合、不靠贴图，纯算出来的。
varying vec3 vN;
varying vec2 vUV;
varying vec3 vW;
varying vec3 vNat;
varying vec3 vEye;

uniform vec3 uLight;

uniform float sTime;
uniform float sGain;
uniform float sCell;
uniform float sEdge;
uniform vec3  sColA;
uniform vec3  sColB;

// 二维六边形网格：返回 0 = 格心，1 = 格边
float hexDist(vec2 p){
  vec2 r = vec2(1.0, 1.7320508);
  vec2 h = r * 0.5;
  vec2 a = mod(p, r) - h;
  vec2 b = mod(p - h, r) - h;
  vec2 gv = (dot(a, a) < dot(b, b)) ? a : b;
  vec2 ap = abs(gv);
  return clamp(max(ap.x * 1.7320508 + gv.y, ap.y * 2.0), 0.0, 1.0);
}

void main(){
  vec3 D  = normalize(vNat);            // 物体空间方向（球面上就是径向）
  vec3 ad = abs(D);

  // ---- 三平面投影：除以主轴分量，格子就不会被斜拉 ----
  float l1 = hexDist(D.zy / max(ad.x, 0.001) * sCell);
  float l2 = hexDist(D.xz / max(ad.y, 0.001) * sCell);
  float l3 = hexDist(D.xy / max(ad.z, 0.001) * sCell);

  // |D| 的四次方当权重（过渡带窄），归一化后混合
  vec3 w = ad * ad; w = w * w;
  float ws = w.x + w.y + w.z;
  float lat = (l1 * w.x + l2 * w.y + l3 * w.z) / max(ws, 0.0001);

  float edge = smoothstep(sEdge, sEdge + 0.11, lat);
  if (edge < 0.03) discard;             // 挖掉格心 → 镂空

  vec3 N = normalize(vN);
  vec3 V = normalize(-vEye);
  float fres = 1.0 - abs(dot(N, V));
  fres = fres * fres * fres;

  float sweep = 0.5 + 0.5 * sin(D.y * 6.0 - sTime * 2.20 + lat * 9.0);

  vec3 col = sColA * edge * (0.55 + 1.35 * sweep);
  col = col + sColB * fres * 1.20;
  col = col * (0.45 + 0.90 * fres);

  gl_FragColor = vec4(col * sGain, 1.0);
}
