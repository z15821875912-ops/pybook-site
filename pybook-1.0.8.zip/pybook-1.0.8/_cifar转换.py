# -*- coding: utf-8 -*-
# CIFAR-10 python 批次 -> PYBT（F32，像素 /255，标签 N×1）
import tarfile, pickle, io, struct
import numpy as np

def write_pybt(path, dims, arr_f32):
    with open(path, "wb") as f:
        f.write(b"PYBT")
        f.write(struct.pack("<II", 1, 1))
        f.write(struct.pack("<I", len(dims)))
        for d in dims:
            f.write(struct.pack("<I", d))
        f.write(struct.pack("<I", 1))          # prec = F32
        f.write(arr_f32.astype("<f8").tobytes())

tf = tarfile.open("cifar10.tar.gz", "r:gz")
xs, ts = [], []
for name in [f"data_batch_{i}" for i in range(1, 6)]:
    d = pickle.load(tf.extractfile(f"cifar-10-batches-py/{name}"), encoding="bytes")
    a = d[b"data"].astype(np.float32) / 255.0
    xs.append(a)
    ts.append(np.array(d[b"labels"], dtype=np.float32).reshape(-1, 1))
    print(name, a.shape)
xtr = np.concatenate(xs)
ttr = np.concatenate(ts)
d = pickle.load(tf.extractfile("cifar-10-batches-py/test_batch"), encoding="bytes")
xte = d[b"data"].astype(np.float32) / 255.0
tte = np.array(d[b"labels"], dtype=np.float32).reshape(-1, 1)

write_pybt("cifar_x_train.bin", list(xtr.shape), xtr)
write_pybt("cifar_y_train.bin", list(ttr.shape), ttr)
write_pybt("cifar_x_test.bin", list(xte.shape), xte)
write_pybt("cifar_y_test.bin", list(tte.shape), tte)
print("train", xtr.shape, "test", xte.shape, "标签范围", ttr.min(), ttr.max())
