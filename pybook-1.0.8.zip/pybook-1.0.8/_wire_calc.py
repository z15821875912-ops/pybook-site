# -*- coding: utf-8 -*-
"""_wire_calc.py — 1) 库入口可选参数（加法式） 2) 数值微积分与求根

## 为什么先做 1)

LIB_CALLS 的值原本是「固定参数个数」，`if len(args) != want: err`。
mt.integrate(f,a,b) 想让区间数可选、mt.deriv(f,x) 想让步长可选，
没有机制就只能拆成 integrate / integrate_n 这种带后缀的名字，难看。

改成：值写成元组 (最少, 最多) 时走新分支。
**既有 448 个入口的值全是 int，isinstance 判断为假，走的还是原来那条路**，一行行为不变。

缺省参数在 codegen 里补 `rt_none()`（空盒）—— C 层认这个当「用户没给」。
这跟用户 func 的缺省参数是同一套思路（那边补的是缺省表达式的值）。
"""
import io

# ============================================================ 1. 前端：允许 (lo, hi)
FRONT_OLD = """        want = LIB_CALLS[full]"""
FRONT_NEW = """        want = LIB_CALLS[full]
        if isinstance(want, tuple):     # (最少, 最多)：缺省参数由 codegen 补空盒
            lo, hi = want
            if not (lo <= len(args) <= hi):
                self.err(f"第 {ln} 行：{full} 需要 {lo}~{hi} 个参数，实际 {len(args)} 个")
            return Call(full, args, ln)
        """


def rd(p):
    return io.open(p, encoding='utf-8', newline='').read()


def wr(p, t):
    io.open(p, 'w', encoding='utf-8', newline='').write(t)


def sub1(p, old, new, tag):
    t = rd(p)
    assert old in t, '%s: 找不到 %s' % (p, tag)
    wr(p, t.replace(old, new, 1))
    print('  %s: 已改 %s' % (p, tag))


# ---------- pybk_front.py 已在 edit 工具里改完，跳过 ----------

# ---------- pybk_code.py ----------
sub1('pybk_code.py',
     "        want = LIB_CALLS[e.name]\n",
     "        want = LIB_CALLS[e.name]\n"
     "        opt = isinstance(want, tuple) and want[1] > len(e.args)\n",
     'opt 标志')

sub1('pybk_code.py',
     """        if e.name == 'hw.uni':
            # rt_hw_univ(nargs, (Value[]){ ... }) —— 2~5 个实参都走这里
            return stmts, (f'rt_hw_univ({len(args)}, (Value[]){{ {", ".join(args)} }})')
        return stmts, f'{c_func}({", ".join(args)})'""",
     """        if e.name == 'hw.uni':
            # rt_hw_univ(nargs, (Value[]){ ... }) —— 2~5 个实参都走这里
            return stmts, (f'rt_hw_univ({len(args)}, (Value[]){{ {", ".join(args)} }})')
        if opt:
            # (最少,最多) 形式的入口且用户少给了参数：补空盒，C 层认这个当「没给」
            args += ['rt_none()'] * (want[1] - len(args))
        return stmts, f'{c_func}({", ".join(args)})'""",
     '缺省参数补空盒')

sub1('pybk_code.py',
     "        elif len(e.args) != want:\n"
     "            self.err(e, f'{e.name} 需要 {want} 个参数，得到 {len(e.args)} 个')\n",
     "        elif not opt and len(e.args) != want:\n"
     "            self.err(e, f'{e.name} 需要 {want} 个参数，得到 {len(e.args)} 个')\n",
     '跳过可选入口的定长校验')

print('可选参数机制完成')
