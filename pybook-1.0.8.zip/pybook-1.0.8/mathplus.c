/* =============================================================================
 * mathplus.c — math+ 模块实现
 *   核心层 (mp_*)       : 无条件编译，纯 C / double*，无运行时依赖。
 *   绑定层 (rt_lib_mp_*) : 仅当 PYBOOK_RT_H 已定义（即 pybook_rt.h 已包含）时编译。
 * ========================================================================== */

#if defined(MP_RT_BINDING) || defined(PYBOOK_RT_H)
#include "pybook_rt.h"   /* 绑定层需要 Value / rt_*：必须在 mathplus.h 之前 */
#endif

#include "mathplus.h"
#include "pybook_la.h"

#include <math.h>
#include <stdlib.h>
#include <string.h>

/* =============================================================================
 * [1] 核心层：向量
 * ========================================================================== */

void mp_vec_add(const double *a, const double *b, double *out, int n)
{
    for (int i = 0; i < n; i++) out[i] = a[i] + b[i];
}

void mp_vec_sub(const double *a, const double *b, double *out, int n)
{
    for (int i = 0; i < n; i++) out[i] = a[i] - b[i];
}

void mp_vec_scale(const double *a, double s, double *out, int n)
{
    for (int i = 0; i < n; i++) out[i] = a[i] * s;
}

double mp_vec_dot(const double *a, const double *b, int n)
{
    double s = 0.0;
    for (int i = 0; i < n; i++) s += a[i] * b[i];
    return s;
}

double mp_vec_norm(const double *a, int n)
{
    return sqrt(mp_vec_dot(a, a, n));
}

double mp_vec_dist(const double *a, const double *b, int n)
{
    double s = 0.0;
    for (int i = 0; i < n; i++) {
        double d = a[i] - b[i];
        s += d * d;
    }
    return sqrt(s);
}

void mp_vec_cross(const double *a, const double *b, double out[3])
{
    out[0] = a[1] * b[2] - a[2] * b[1];
    out[1] = a[2] * b[0] - a[0] * b[2];
    out[2] = a[0] * b[1] - a[1] * b[0];
}

void mp_vec_lerp(const double *a, const double *b, double *out, int n, double t)
{
    for (int i = 0; i < n; i++) out[i] = a[i] + (b[i] - a[i]) * t;
}

/* =============================================================================
 * [1] 核心层：矩阵
 * ========================================================================== */

void mp_mat_add(const double *a, const double *b, double *out, int r, int c)
{
    int n = r * c;
    for (int i = 0; i < n; i++) out[i] = a[i] + b[i];
}

void mp_mat_scale(const double *a, double s, double *out, int r, int c)
{
    int n = r * c;
    for (int i = 0; i < n; i++) out[i] = a[i] * s;
}

void mp_mat_mul(const double *a, const double *b, double *out, int r, int m, int c)
{
    for (int i = 0; i < r; i++) {
        for (int j = 0; j < c; j++) {
            double s = 0.0;
            for (int k = 0; k < m; k++)
                s += a[(size_t)i * m + k] * b[(size_t)k * c + j];
            out[(size_t)i * c + j] = s;
        }
    }
}

void mp_mat_transpose(const double *a, double *out, int r, int c)
{
    for (int i = 0; i < r; i++)
        for (int j = 0; j < c; j++)
            out[(size_t)j * r + i] = a[(size_t)i * c + j];
}

void mp_mat_identity(double *out, int n)
{
    memset(out, 0, (size_t)n * n * sizeof(double));
    for (int i = 0; i < n; i++) out[(size_t)i * n + i] = 1.0;
}

void mp_mat_vec_mul(const double *a, const double *x, double *out, int r, int c)
{
    for (int i = 0; i < r; i++) {
        double s = 0.0;
        for (int j = 0; j < c; j++) s += a[(size_t)i * c + j] * x[j];
        out[i] = s;
    }
}

double mp_mat_det(const double *a, int n)
{
    /* 改走 pybook_la 的 LU 底座：原来这里是本文件里私藏的一套部分主元消元，
     * 与 mp_mat_inverse 各写各的，既重复又在近奇异时更脆。现在 det / inv /
     * solve / rank 共用同一份分解，行为一致。 */
    double *lu;
    int    *piv;
    double  d;
    if (n <= 0) return 0.0;
    lu  = (double *)malloc((size_t)n * (size_t)n * sizeof(double));
    piv = (int *)malloc((size_t)n * sizeof(int));
    if (!lu || !piv) { free(lu); free(piv); return 0.0; }
    la_lu(a, lu, piv, n);              /* 奇异也返回，因子已填满 */
    d = la_lu_det(lu, piv, n);
    free(lu); free(piv);
    return d;
}

int mp_mat_inverse(const double *a, double *out, int n)
{
    double *lu;
    int    *piv;
    int     ok = 0;
    if (n <= 0) return -1;
    lu  = (double *)malloc((size_t)n * (size_t)n * sizeof(double));
    piv = (int *)malloc((size_t)n * sizeof(int));
    if (!lu || !piv) { free(lu); free(piv); return -1; }
    if (la_lu(a, lu, piv, n)) ok = la_lu_inv(lu, piv, out, n);
    free(lu); free(piv);
    return ok ? 0 : -1;
}

void mp_mat_rot_x(double *out, double ang)
{
    double s = sin(ang), c = cos(ang);
    mp_mat_identity(out, 3);
    out[4] = c; out[5] = -s;   /* 标准右手系：+ang 为绕 X 逆时针 */
    out[7] = s; out[8] = c;
}

void mp_mat_rot_y(double *out, double ang)
{
    double s = sin(ang), c = cos(ang);
    mp_mat_identity(out, 3);
    out[0] = c; out[2] = s;
    out[6] = -s; out[8] = c;
}

void mp_mat_rot_z(double *out, double ang)
{
    double s = sin(ang), c = cos(ang);
    mp_mat_identity(out, 3);
    out[0] = c; out[1] = -s;
    out[3] = s; out[4] = c;
}

void mp_mat_perspective(double *out, double fovy, double aspect, double zn, double zf)
{
    memset(out, 0, 16 * sizeof(double));
    double f = 1.0 / tan(fovy / 2.0);
    out[0] = f / aspect;
    out[5] = f;
    out[10] = (zf + zn) / (zn - zf);
    out[11] = -1.0;
    out[14] = (2.0 * zf * zn) / (zn - zf);
}

void mp_mat_translate(double *out, double x, double y, double z)
{
    mp_mat_identity(out, 4);
    out[3] = x; out[7] = y; out[11] = z;
}

/* =============================================================================
 * [1] 核心层：统计 / 变换 / 标量
 * ========================================================================== */

double mp_sum(const double *a, int n)
{
    double s = 0.0;
    for (int i = 0; i < n; i++) s += a[i];
    return s;
}

double mp_mean(const double *a, int n)
{
    if (n <= 0) return 0.0;
    return mp_sum(a, n) / n;
}

double mp_var(const double *a, int n, int ddof)
{
    if (n <= 0) return 0.0;
    double mu = mp_mean(a, n);
    double s = 0.0;
    for (int i = 0; i < n; i++) { double d = a[i] - mu; s += d * d; }
    int denom = n - ddof;
    if (denom <= 0) denom = 1;
    return s / denom;
}

double mp_std(const double *a, int n, int ddof)
{
    return sqrt(mp_var(a, n, ddof));
}

void mp_minmax(const double *a, int n, double *mn, double *mx)
{
    if (n <= 0) { *mn = 0.0; *mx = 0.0; return; }
    double lo = a[0], hi = a[0];
    for (int i = 1; i < n; i++) {
        if (a[i] < lo) lo = a[i];
        if (a[i] > hi) hi = a[i];
    }
    *mn = lo; *mx = hi;
}

void mp_linspace(double *out, int n, double lo, double hi)
{
    if (n <= 1) { if (n == 1) out[0] = lo; return; }
    double step = (hi - lo) / (n - 1);
    for (int i = 0; i < n; i++) out[i] = lo + step * i;
}

double mp_clamp(double v, double lo, double hi)
{
    if (v < lo) return lo;
    if (v > hi) return hi;
    return v;
}

double mp_mix(double a, double b, double t) { return a + (b - a) * t; }

double mp_smoothstep(double e0, double e1, double x)
{
    if (e1 == e0) return (x < e0) ? 0.0 : 1.0;
    double t = mp_clamp((x - e0) / (e1 - e0), 0.0, 1.0);
    return t * t * (3.0 - 2.0 * t);
}

double mp_sign(double x) { return (x > 0) ? 1.0 : (x < 0) ? -1.0 : 0.0; }
double mp_radians(double deg) { return deg * M_PI / 180.0; }
double mp_degrees(double rad) { return rad * 180.0 / M_PI; }

/* =============================================================================
 * [1] 核心层：随机数（xorshift128，自带状态，独立于标准库 rd）
 * ========================================================================== */

static uint64_t g_mp_seed = 0x9E3779B97F4A7C15ULL;

void mp_rand_seed(uint64_t s)
{
    g_mp_seed = s ? s : 0x9E3779B97F4A7C15ULL;
}

double mp_rand_u01(void)
{
    uint64_t x = g_mp_seed;
    x ^= x << 13;
    x ^= x >> 7;
    x ^= x << 17;
    g_mp_seed = x;
    /* 53 位精度映射到 [0,1) */
    return (double)(x >> 11) / (double)(1ULL << 53);
}

double mp_rand_normal(double mean, double sd)
{
    double u1 = mp_rand_u01();
    if (u1 < 1e-12) u1 = 1e-12;
    double u2 = mp_rand_u01();
    double z = sqrt(-2.0 * log(u1)) * cos(2.0 * M_PI * u2);
    return mean + sd * z;
}


/* ---------- 常见分布补齐（全部与 mp.rand_* 共用同一个 xorshift128）----------
 * 参数非法一律返回 -1 / -1.0 作哨兵：这些分布的取值域都 >= 0，
 * 所以 -1 不可能与合法结果撞上，由绑定层翻译成带三段式的报错。
 * 核心层不 printf 不 exit —— 保住 mathplus.c 的可独立编译性。 */

/* 标准正态：Box-Muller。u1 取不到 0（log(0) = -inf 会毁掉结果） */
static double mp_std_normal(void)
{
    double u1, u2;
    do { u1 = mp_rand_u01(); } while (u1 <= 0.0);
    u2 = mp_rand_u01();
    return sqrt(-2.0 * log(u1)) * cos(6.28318530717959 * u2);
}

double mp_rand_exponential(double rate)
{
    double u;
    if (!(rate > 0.0)) return -1.0;
    do { u = mp_rand_u01(); } while (u <= 0.0);
    return -log(u) / rate;
}

/* 泊松：λ<30 用 Knuth（小 λ 时这个才准），λ>=30 走正态近似 */
double mp_rand_poisson(double lam)
{
    double L, p;
    long long k = 0;
    if (lam < 0.0) return -1.0;
    if (lam < 30.0) {
        L = exp(-lam);
        p = 1.0;
        do {
            p *= mp_rand_u01();
            k++;
        } while (p > L && k < 100000000LL);
        return (double)(k - 1);
    }
    {
        double v = lam + sqrt(lam) * mp_std_normal();
        return v < 0.0 ? 0.0 : v;
    }
}

/* 几何：成功概率 p，返回首次成功所需的试验次数（>=1） */
int mp_rand_geom(double p)
{
    double u;
    if (!(p > 0.0 && p <= 1.0)) return -1;
    do { u = mp_rand_u01(); } while (u <= 0.0);
    return (int)(log(u) / log(1.0 - p)) + 1;
}

/* 二项 B(n,p)：n<40 逐次 Bernoulli（精确），否则正态近似并截断到 [0,n] */
double mp_rand_binom(int n, double p)
{
    long long i, k = 0;
    double mean, sd, v;
    if (n < 0 || p < 0.0 || p > 1.0) return -1.0;
    if (n < 40) {
        for (i = 0; i < n; i++)
            if (mp_rand_u01() < p) k++;
        return (double)k;
    }
    mean = n * p;
    sd = sqrt((double)n * p * (1.0 - p));
    if (sd <= 0.0) return mean;
    v = mean + sd * mp_std_normal();
    if (v < 0.0) v = 0.0;
    if (v > (double)n) v = (double)n;
    return v;
}

/* Gamma(k, θ)：Marsaglia-Tsang 压缩拒绝法；k<1 先用 k+1 抽样再取幂（Boost 变换） */
double mp_rand_gamma(double shape, double scale)
{
    double d, c, v, u, z;
    if (!(shape > 0.0) || !(scale > 0.0)) return -1.0;
    if (shape < 1.0) {
        double g = mp_rand_gamma(shape + 1.0, 1.0);
        double w;
        if (g < 0.0) return -1.0;          /* 递归里参数非法 */
        do { w = mp_rand_u01(); } while (w <= 0.0);
        return g * pow(w, 1.0 / shape) * scale;
    }
    d = shape - 1.0 / 3.0;
    c = 1.0 / sqrt(9.0 * d);
    for (;;) {
        z = mp_std_normal();
        v = 1.0 + z * c;            /* c 是乘数：等价于 1 + z/sqrt(9d) */
        if (v <= 0.0) continue;
        v = v * v * v;
        u = mp_rand_u01();
        if (u < 1.0 - 0.0331 * z * z * z * z) return d * v * scale;
        if (log(u) < 0.5 * z * z + d * (1.0 - v + log(v))) return d * v * scale;
    }
}

/* Beta(a,b)：X ~ Gamma(a,1)、Y ~ Gamma(b,1) 独立，则 X/(X+Y) ~ Beta(a,b)。
 * 构造上就成立，不需要拒绝采样，也没有接受率问题。
 * 之前用的 Johnk 拒绝法是系统性有偏（beta(10,1) 均值实测 0.821、理论 0.909），
 * 根源是 X = U1^(1/a) 把 Gamma 变量截断在 (0,1)，拒绝权重补不回这个截断。
 * 代价是要抽两个 Gamma，比拒绝法慢一点，但正确性没有商量余地。 */
double mp_rand_beta(double a, double b)
{
    double x, y, s;
    if (!(a > 0.0) || !(b > 0.0)) return -1.0;
    for (;;) {
        x = mp_rand_gamma(a, 1.0);
        y = mp_rand_gamma(b, 1.0);
        if (x < 0.0 || y < 0.0) return -1.0;   /* 参数非法，递归里传下来的 */
        s = x + y;
        if (s > 0.0) return x / s;             /* s==0 只可能两边都下溢，重抽 */
    }
}

/* 对数正态：ln X ~ N(mu, sigma^2) */
double mp_rand_lognormal(double mu, double sigma)
{
    if (sigma < 0.0) return -1.0;
    return exp(mu + sigma * mp_std_normal());
}

/* Logistic：位置 mu、尺度 s。注意它是唯一取值可以为负的分布，
   所以绑定层不能用「返回值 < 0」反推参数非法，必须显式校验尺度。 */
double mp_rand_logistic(double mu, double s)
{
    double u;
    if (!(s > 0.0)) return -1.0;
    do { u = mp_rand_u01(); } while (u <= 0.0);
    return mu + s * log(u / (1.0 - u));
}

/* ---------- 统计补齐（此前只有 mean/var/std/minmax/sum）----------
 * 一律纯 double*、就地排序副本，不碰 Value —— 与本文件核心层的分层约定一致。
 * 输入非法时返回 NAN，由绑定层翻译成报错。 */

/* 插入排序：n 通常几百到几千，O(n^2) 的常数比 qsort 小得多，
   也不必考虑 qsort 比较函数里拿不到上下文的问题 */
static void st_sort_d(double *a, int n)
{
    int i, j;
    for (i = 1; i < n; i++) {
        double key = a[i];
        for (j = i - 1; j >= 0 && a[j] > key; j--)
            a[j + 1] = a[j];
        a[j + 1] = key;
    }
}

/* 返回一份升序副本（调用方 free）；n<1 返回 NULL */
static double *st_sorted(const double *a, int n)
{
    double *s;
    if (n < 1) return NULL;
    s = (double *)malloc((size_t)n * sizeof(double));
    if (!s) return NULL;
    memcpy(s, a, (size_t)n * sizeof(double));
    st_sort_d(s, n);
    return s;
}

/* 中位数。偶数个取中间两个的平均（与 numpy 一致） */
double mp_median(const double *a, int n)
{
    double *s = st_sorted(a, n), m;
    if (!s) return NAN;
    m = (n % 2) ? s[n / 2] : (s[n / 2 - 1] + s[n / 2]) / 2.0;
    free(s);
    return m;
}

/* 众数。并列时返回最小的那��� —— 保证结果确定，不依赖排序实现的稳定性 */
double mp_mode(const double *a, int n)
{
    double *s = st_sorted(a, n), best = 0.0;
    int i, bestn = 0;
    if (!s) return NAN;
    for (i = 0; i < n; ) {
        int j = i;
        while (j + 1 < n && s[j + 1] == s[i]) j++;
        if (j - i + 1 > bestn) {
            bestn = j - i + 1;
            best = s[i];
        }
        i = j + 1;
    }
    free(s);
    return best;
}

/* 分位数，线性插值法，与 numpy.percentile 的默认 linear 一致。
   q ∈ [0,1]；q<0 或 >1 返回 NAN */
double mp_quantile(const double *a, int n, double q)
{
    double *s, idx, frac;
    int pos;
    if (!(q >= 0.0 && q <= 1.0)) return NAN;
    s = st_sorted(a, n);
    if (!s) return NAN;
    idx = q * (double)(n - 1);
    pos = (int)idx;
    frac = idx - (double)pos;
    frac = (pos + 1 < n) ? s[pos] + frac * (s[pos + 1] - s[pos]) : s[n - 1];
    free(s);
    return frac;
}

/* 样本协方差（分母 n-1，与 numpy.cov 默认一致）。n<2 返回 NAN */
double mp_cov(const double *x, const double *y, int n)
{
    double mx = 0.0, my = 0.0, s = 0.0;
    int i;
    if (n < 2) return NAN;
    for (i = 0; i < n; i++) mx += x[i];
    for (i = 0; i < n; i++) my += y[i];
    mx /= (double)n;
    my /= (double)n;
    for (i = 0; i < n; i++) s += (x[i] - mx) * (y[i] - my);
    return s / (double)(n - 1);
}

/* 皮尔逊相关系数 = cov / (std_x * std_y)。
   某一边是常数时分母为 0，此时相关系数无定义，返回 NAN 让调用方报错，
   静默给 0 会让人以为「不相关」而其实是「没定义」 */
double mp_corr(const double *x, const double *y, int n)
{
    double mx = 0.0, my = 0.0, sxy = 0.0, sxx = 0.0, syy = 0.0, den;
    int i;
    if (n < 2) return NAN;
    for (i = 0; i < n; i++) mx += x[i];
    for (i = 0; i < n; i++) my += y[i];
    mx /= (double)n;
    my /= (double)n;
    for (i = 0; i < n; i++) {
        double dx = x[i] - mx, dy = y[i] - my;
        sxy += dx * dy;
        sxx += dx * dx;
        syy += dy * dy;
    }
    den = sqrt(sxx * syy);
    if (den <= 0.0) return NAN;
    return sxy / den;
}

/* 前缀和：out 需 n 个 */
void mp_cumsum(const double *a, int n, double *out)
{
    double s = 0.0;
    int i;
    for (i = 0; i < n; i++) {
        s += a[i];
        out[i] = s;
    }
}

/* 逐差分：out 需 n-1 个（n<2 时什么都不写） */
void mp_diff(const double *a, int n, double *out)
{
    int i;
    for (i = 1; i < n; i++) out[i - 1] = a[i] - a[i - 1];
}
/* =============================================================================
 * [2] 绑定层：PYbook Value <-> double*（仅 PYBOOK_RT_H 已定义时编译）
 * ========================================================================== */
#if defined(PYBOOK_RT_H) || defined(MP_RT_BINDING)


#include <stdio.h>
#include <stdarg.h>

static void mp_die(const char *fmt, ...)
{
    va_list ap;
    fprintf(stderr, "math+ 运行时错误: ");
    va_start(ap, fmt);
    vfprintf(stderr, fmt, ap);
    va_end(ap);
    fputc('\n', stderr);
    exit(1);
}

static double mp_num(Value v, const char *who)
{
    if (IS_FLT(v)) return AS_FLT(v);
    if (IS_INT(v) || IS_BIGINT(v)) return (double)rt_to_ll(v);
    if (IS_BOOL(v)) return (double)AS_BOOL(v);
    mp_die("%s 需要数字参数", who);
    return 0.0;
}

static long long mp_ll(Value v, const char *who)
{
    if (IS_INT(v) || IS_BIGINT(v)) return rt_to_ll(v);
    if (IS_BOOL(v)) return (long long)AS_BOOL(v);
    mp_die("%s 需要整数参数", who);
    return 0;
}

/* 把 PYbook 列表展开成 double*（调用方负责 free） */
static double *mp_unpack(Value v, long long *out_n, const char *who)
{
    if (!IS_LIST(v)) mp_die("%s 需要列表参数", who);
    long long n = rt_list_len_ll(v);
    double *buf = (double *)malloc((size_t)(n > 0 ? n : 1) * sizeof(double));
    if (!buf) mp_die("math+ 内存不足");
    for (long long i = 0; i < n; i++)
        buf[i] = mp_num(rt_index(v, rt_int(i)), who);
    *out_n = n;
    return buf;
}

/* ---------------- 分布与统计的绑定层 ---------------- */

/* 核心层用 -1 / NAN 作哨兵表示参数非法，这里统一翻译成报错。
   这些分布取值域都 >= 0，-1 不可能与合法结果撞车。 */
static void dist_die(const char *who, const char *need)
{
    rt_die("%s 的参数不合法：要求 %s\n"
           "  为什么：参数越界的分布没有定义，硬算只会得到垃圾数\n"
           "  怎么改：按上面这个要求检查参数再传进来", who, need);
}

Value rt_lib_mp_rand_exponential(Value rate)
{
    double r = mp_rand_exponential(mp_num(rate, "mp.rand_exponential 的 λ"));
    if (r < 0.0) dist_die("mp.rand_exponential", "λ > 0");
    return rt_float(r);
}

Value rt_lib_mp_rand_poisson(Value lambda)
{
    double r = mp_rand_poisson(mp_num(lambda, "mp.rand_poisson 的 λ"));
    if (r < 0.0) dist_die("mp.rand_poisson", "λ >= 0");
    return rt_float(r);
}

Value rt_lib_mp_rand_geom(Value pv)
{
    int k = mp_rand_geom(mp_num(pv, "mp.rand_geom 的 p"));
    if (k < 0) dist_die("mp.rand_geom", "0 < p <= 1");
    return rt_int(k);
}

Value rt_lib_mp_rand_binom(Value nv, Value pv)
{
    long long n = mp_ll(nv, "mp.rand_binom 的 n");
    double p = mp_num(pv, "mp.rand_binom 的 p");
    double r;
    if (n < 0 || n > 1000000000LL)
        rt_die("mp.rand_binom 的 n 要在 [0, 1e9]，收到 %lld\n"
               "  为什么：n 是试验次数，必须是非负且可枚举的整数\n"
               "  怎么改：把 n 调小；n 很大时走正态近似更合适", n);
    r = mp_rand_binom((int)n, p);
    if (r < 0.0) dist_die("mp.rand_binom", "n >= 0 且 0 <= p <= 1");
    return rt_float(r);
}

Value rt_lib_mp_rand_gamma(Value kv, Value thv)
{
    double r = mp_rand_gamma(mp_num(kv, "mp.rand_gamma 的形状"),
                             mp_num(thv, "mp.rand_gamma 的尺度"));
    if (r < 0.0) dist_die("mp.rand_gamma", "形状 > 0 且尺度 > 0");
    return rt_float(r);
}

Value rt_lib_mp_rand_beta(Value av, Value bv)
{
    double r = mp_rand_beta(mp_num(av, "mp.rand_beta 的 a"),
                            mp_num(bv, "mp.rand_beta 的 b"));
    if (r < 0.0) dist_die("mp.rand_beta", "a > 0 且 b > 0");
    return rt_float(r);
}

Value rt_lib_mp_rand_lognormal(Value muv, Value sv)
{
    double s = mp_num(sv, "mp.rand_lognormal 的 sigma");
    double r;
    if (s < 0.0) dist_die("mp.rand_lognormal", "sigma >= 0");
    r = mp_rand_lognormal(mp_num(muv, "mp.rand_lognormal 的 mu"), s);
    return rt_float(r);
}

/* logistic 不走「返回值 < 0 即参数非法」那条哨兵路：
 * 它以 mu 为中心对称，mu=0 时结果本来就可以是负数，拿结果反推参数非法会误报。
 * 所以先把参数取出来显式校验，再调核心层。 */
Value rt_lib_mp_rand_logistic(Value muv, Value sv)
{
    double mu = mp_num(muv, "mp.rand_logistic 的 mu");
    double s = mp_num(sv, "mp.rand_logistic 的 s");
    if (!(s > 0.0)) dist_die("mp.rand_logistic", "尺度 s > 0");
    return rt_float(mp_rand_logistic(mu, s));
}

/* ---- 统计 ---- */

/* 解包成 double* 并顺带检查元素全是数字；调用方 free */
static double *stat_unpack(Value v, long long *n, const char *who)
{
    return mp_unpack(v, n, who);
}

Value rt_lib_mp_median(Value listv)
{
    long long n;
    double *a = stat_unpack(listv, &n, "mp.median");
    double r;
    if (n < 1) mp_die("mp.median：空列表");
    r = mp_median(a, (int)n);
    free(a);
    return rt_float(r);
}

Value rt_lib_mp_mode(Value listv)
{
    long long n;
    double *a = stat_unpack(listv, &n, "mp.mode");
    double r;
    if (n < 1) mp_die("mp.mode：空列表");
    r = mp_mode(a, (int)n);
    free(a);
    return rt_float(r);
}

Value rt_lib_mp_quantile(Value listv, Value qv)
{
    long long n;
    double q = mp_num(qv, "mp.quantile 的 q");
    double *a = stat_unpack(listv, &n, "mp.quantile");
    double r;
    if (!(q >= 0.0 && q <= 1.0)) {
        free(a);
        mp_die("mp.quantile 的 q 要在 [0,1]，收到 %g", q);
    }
    if (n < 1) { free(a); mp_die("mp.quantile：空列表"); }
    r = mp_quantile(a, (int)n, q);
    free(a);
    return rt_float(r);
}

Value rt_lib_mp_percentile(Value listv, Value pv)
{
    double p = mp_num(pv, "mp.percentile 的 p");
    return rt_lib_mp_quantile(listv, rt_float(p / 100.0));
}

Value rt_lib_mp_cov(Value xv, Value yv)
{
    long long nx, ny;
    double *x = mp_unpack(xv, &nx, "mp.cov 的 x");
    double *y = mp_unpack(yv, &ny, "mp.cov 的 y");
    double r;
    if (nx != ny) {
        free(x); free(y);
        mp_die("mp.cov：两个列表长度要相同（%lld 与 %lld）", nx, ny);
    }
    if (nx < 2) { free(x); free(y); mp_die("mp.cov：至少要 2 个样本"); }
    r = mp_cov(x, y, (int)nx);
    free(x); free(y);
    return rt_float(r);
}

Value rt_lib_mp_corr(Value xv, Value yv)
{
    long long nx, ny;
    double *x = mp_unpack(xv, &nx, "mp.corr 的 x");
    double *y = mp_unpack(yv, &ny, "mp.corr 的 y");
    double r;
    if (nx != ny) {
        free(x); free(y);
        mp_die("mp.corr：两个列表长度要相同（%lld 与 %lld）", nx, ny);
    }
    if (nx < 2) { free(x); free(y); mp_die("mp.corr：至少要 2 个样本"); }
    r = mp_corr(x, y, (int)nx);
    free(x); free(y);
    if (isnan(r))
        mp_die("mp.corr：某个变量是常数，相关系数无定义\n"
               "  为什么：标准差为 0 时分母为 0，不是「不相关」而是「没定义」\n"
               "  怎么改：先检查两个列表里有没有全员相同的");
    return rt_float(r);
}

Value rt_lib_mp_cumsum(Value listv)
{
    long long i, n;
    double *a = mp_unpack(listv, &n, "mp.cumsum");
    double *out = (double *)malloc((size_t)(n > 0 ? n : 1) * sizeof(double));
    Value r;
    if (!out) { free(a); mp_die("math+ 内存不足"); }
    mp_cumsum(a, (int)n, out);
    r = rt_list_new();
    for (i = 0; i < n; i++) rt_push(&r, rt_float(out[i]));
    free(a); free(out);
    return r;
}

Value rt_lib_mp_diff(Value listv)
{
    long long i, n;
    double *a = mp_unpack(listv, &n, "mp.diff");
    double *out = (double *)malloc((size_t)(n > 0 ? n : 1) * sizeof(double));
    Value r;
    if (!out) { free(a); mp_die("math+ 内存不足"); }
    mp_diff(a, (int)n, out);
    r = rt_list_new();
    for (i = 1; i < n; i++) rt_push(&r, rt_float(out[i - 1]));
    free(a); free(out);
    return r;
}

/* 把 double* 打包成 PYbook 列表（浮点） */
static Value mp_pack(const double *a, long long n)
{
    Value out = rt_list_new();
    for (long long i = 0; i < n; i++) rt_push(&out, rt_float(a[i]));
    return out;
}

/* 维度检查：扁平长度必须等于 r*c（或对应维度） */
static void mp_dim_check(long long got, long long need, const char *who)
{
    if (got != need)
        mp_die("%s 维度不符：列表长度 %lld，期望 %lld", who, got, need);
}

/* ---------- 向量 ---------- */

Value rt_lib_mp_vec_add(Value a, Value b)
{
    long long n1, n2;
    double *A = mp_unpack(a, &n1, "mp.vec_add");
    double *B = mp_unpack(b, &n2, "mp.vec_add");
    if (n1 != n2) mp_die("mp.vec_add 两向量长度不等：%lld vs %lld", n1, n2);
    double *o = (double *)malloc((size_t)n1 * sizeof(double));
    mp_vec_add(A, B, o, (int)n1);
    Value r = mp_pack(o, n1);
    free(A); free(B); free(o);
    return r;
}

Value rt_lib_mp_vec_sub(Value a, Value b)
{
    long long n1, n2;
    double *A = mp_unpack(a, &n1, "mp.vec_sub");
    double *B = mp_unpack(b, &n2, "mp.vec_sub");
    if (n1 != n2) mp_die("mp.vec_sub 两向量长度不等");
    double *o = (double *)malloc((size_t)n1 * sizeof(double));
    mp_vec_sub(A, B, o, (int)n1);
    Value r = mp_pack(o, n1);
    free(A); free(B); free(o);
    return r;
}

Value rt_lib_mp_vec_scale(Value a, Value s)
{
    long long n;
    double *A = mp_unpack(a, &n, "mp.vec_scale");
    double *o = (double *)malloc((size_t)n * sizeof(double));
    mp_vec_scale(A, mp_num(s, "mp.vec_scale 第 2 个参数"), o, (int)n);
    Value r = mp_pack(o, n);
    free(A); free(o);
    return r;
}

Value rt_lib_mp_vec_dot(Value a, Value b)
{
    long long n1, n2;
    double *A = mp_unpack(a, &n1, "mp.vec_dot");
    double *B = mp_unpack(b, &n2, "mp.vec_dot");
    if (n1 != n2) mp_die("mp.vec_dot 两向量长度不等");
    double d = mp_vec_dot(A, B, (int)n1);
    free(A); free(B);
    return rt_float(d);
}

Value rt_lib_mp_vec_norm(Value a)
{
    long long n;
    double *A = mp_unpack(a, &n, "mp.vec_norm");
    double d = mp_vec_norm(A, (int)n);
    free(A);
    return rt_float(d);
}

Value rt_lib_mp_vec_dist(Value a, Value b)
{
    long long n1, n2;
    double *A = mp_unpack(a, &n1, "mp.vec_dist");
    double *B = mp_unpack(b, &n2, "mp.vec_dist");
    if (n1 != n2) mp_die("mp.vec_dist 两向量长度不等");
    double d = mp_vec_dist(A, B, (int)n1);
    free(A); free(B);
    return rt_float(d);
}

Value rt_lib_mp_vec_cross(Value a, Value b)
{
    long long n1, n2;
    double *A = mp_unpack(a, &n1, "mp.vec_cross");
    double *B = mp_unpack(b, &n2, "mp.vec_cross");
    if (n1 != 3 || n2 != 3) mp_die("mp.vec_cross 仅支持 3 维向量");
    double o[3];
    mp_vec_cross(A, B, o);
    free(A); free(B);
    return mp_pack(o, 3);
}

Value rt_lib_mp_vec_lerp(Value a, Value b, Value t)
{
    long long n1, n2;
    double *A = mp_unpack(a, &n1, "mp.vec_lerp");
    double *B = mp_unpack(b, &n2, "mp.vec_lerp");
    if (n1 != n2) mp_die("mp.vec_lerp 两向量长度不等");
    double *o = (double *)malloc((size_t)n1 * sizeof(double));
    mp_vec_lerp(A, B, o, (int)n1, mp_num(t, "mp.vec_lerp 第 3 个参数"));
    Value r = mp_pack(o, n1);
    free(A); free(B); free(o);
    return r;
}

/* ---------- 矩阵 ---------- */

Value rt_lib_mp_mat_add(Value a, Value b, Value rv, Value cv)
{
    int r = (int)mp_ll(rv, "mp.mat_add 第 3 个参数");
    int c = (int)mp_ll(cv, "mp.mat_add 第 4 个参数");
    long long n1, n2;
    double *A = mp_unpack(a, &n1, "mp.mat_add");
    double *B = mp_unpack(b, &n2, "mp.mat_add");
    mp_dim_check(n1, (long long)r * c, "mp.mat_add(矩阵A)");
    mp_dim_check(n2, (long long)r * c, "mp.mat_add(矩阵B)");
    double *o = (double *)malloc((size_t)(r * c) * sizeof(double));
    mp_mat_add(A, B, o, r, c);
    Value res = mp_pack(o, (long long)r * c);
    free(A); free(B); free(o);
    return res;
}

Value rt_lib_mp_mat_scale(Value a, Value s, Value rv, Value cv)
{
    int r = (int)mp_ll(rv, "mp.mat_scale 第 3 个参数");
    int c = (int)mp_ll(cv, "mp.mat_scale 第 4 个参数");
    long long n;
    double *A = mp_unpack(a, &n, "mp.mat_scale");
    mp_dim_check(n, (long long)r * c, "mp.mat_scale");
    double *o = (double *)malloc((size_t)(r * c) * sizeof(double));
    mp_mat_scale(A, mp_num(s, "mp.mat_scale 第 2 个参数"), o, r, c);
    Value res = mp_pack(o, (long long)r * c);
    free(A); free(o);
    return res;
}

Value rt_lib_mp_mat_mul(Value a, Value b, Value rv, Value mv, Value cv)
{
    int r = (int)mp_ll(rv, "mp.mat_mul 第 3 个参数");
    int m = (int)mp_ll(mv, "mp.mat_mul 第 4 个参数");
    int c = (int)mp_ll(cv, "mp.mat_mul 第 5 个参数");
    long long n1, n2;
    double *A = mp_unpack(a, &n1, "mp.mat_mul");
    double *B = mp_unpack(b, &n2, "mp.mat_mul");
    mp_dim_check(n1, (long long)r * m, "mp.mat_mul(矩阵A)");
    mp_dim_check(n2, (long long)m * c, "mp.mat_mul(矩阵B)");
    double *o = (double *)malloc((size_t)(r * c) * sizeof(double));
    mp_mat_mul(A, B, o, r, m, c);
    Value res = mp_pack(o, (long long)r * c);
    free(A); free(B); free(o);
    return res;
}

Value rt_lib_mp_mat_transpose(Value a, Value rv, Value cv)
{
    int r = (int)mp_ll(rv, "mp.mat_transpose 第 2 个参数");
    int c = (int)mp_ll(cv, "mp.mat_transpose 第 3 个参数");
    long long n;
    double *A = mp_unpack(a, &n, "mp.mat_transpose");
    mp_dim_check(n, (long long)r * c, "mp.mat_transpose");
    double *o = (double *)malloc((size_t)(r * c) * sizeof(double));
    mp_mat_transpose(A, o, r, c);
    Value res = mp_pack(o, (long long)r * c);
    free(A); free(o);
    return res;
}

Value rt_lib_mp_mat_identity(Value nv)
{
    int n = (int)mp_ll(nv, "mp.mat_identity");
    if (n <= 0) mp_die("mp.mat_identity 维度必须为正整数");
    double *o = (double *)malloc((size_t)(n * n) * sizeof(double));
    mp_mat_identity(o, n);
    Value res = mp_pack(o, (long long)n * n);
    free(o);
    return res;
}

Value rt_lib_mp_mat_det(Value a, Value nv)
{
    int n = (int)mp_ll(nv, "mp.mat_det 第 2 个参数");
    long long len;
    double *A = mp_unpack(a, &len, "mp.mat_det");
    mp_dim_check(len, (long long)n * n, "mp.mat_det");
    double d = mp_mat_det(A, n);
    free(A);
    return rt_float(d);
}

Value rt_lib_mp_mat_inverse(Value a, Value nv)
{
    int n = (int)mp_ll(nv, "mp.mat_inverse 第 2 个参数");
    long long len;
    double *A = mp_unpack(a, &len, "mp.mat_inverse");
    mp_dim_check(len, (long long)n * n, "mp.mat_inverse");
    double *o = (double *)malloc((size_t)(n * n) * sizeof(double));
    if (mp_mat_inverse(A, o, n) != 0) mp_die("mp.mat_inverse 矩阵奇异，不可逆");
    Value res = mp_pack(o, (long long)n * n);
    free(A); free(o);
    return res;
}

Value rt_lib_mp_mat_vec_mul(Value a, Value x, Value rv, Value cv)
{
    int r = (int)mp_ll(rv, "mp.mat_vec_mul 第 3 个参数");
    int c = (int)mp_ll(cv, "mp.mat_vec_mul 第 4 个参数");
    long long n1, n2;
    double *A = mp_unpack(a, &n1, "mp.mat_vec_mul");
    double *X = mp_unpack(x, &n2, "mp.mat_vec_mul");
    mp_dim_check(n1, (long long)r * c, "mp.mat_vec_mul(矩阵)");
    mp_dim_check(n2, (long long)c, "mp.mat_vec_mul(向量)");
    double *o = (double *)malloc((size_t)r * sizeof(double));
    mp_mat_vec_mul(A, X, o, r, c);
    Value res = mp_pack(o, (long long)r);
    free(A); free(X); free(o);
    return res;
}

/* ---------- 统计 ---------- */

Value rt_lib_mp_mean(Value list)
{
    long long n;
    double *A = mp_unpack(list, &n, "mp.mean");
    double d = mp_mean(A, (int)n);
    free(A);
    return rt_float(d);
}

Value rt_lib_mp_var(Value list, Value ddof)
{
    long long n;
    double *A = mp_unpack(list, &n, "mp.var");
    double d = mp_var(A, (int)n, (int)mp_ll(ddof, "mp.var 第 2 个参数"));
    free(A);
    return rt_float(d);
}

Value rt_lib_mp_std(Value list, Value ddof)
{
    long long n;
    double *A = mp_unpack(list, &n, "mp.std");
    double d = mp_std(A, (int)n, (int)mp_ll(ddof, "mp.std 第 2 个参数"));
    free(A);
    return rt_float(d);
}

Value rt_lib_mp_sum(Value list)
{
    long long n;
    double *A = mp_unpack(list, &n, "mp.sum");
    double d = mp_sum(A, (int)n);
    free(A);
    return rt_float(d);
}

Value rt_lib_mp_minmax(Value list)
{
    long long n;
    double *A = mp_unpack(list, &n, "mp.minmax");
    double mn, mx;
    mp_minmax(A, (int)n, &mn, &mx);
    free(A);
    double out[2] = { mn, mx };
    return mp_pack(out, 2);
}

Value rt_lib_mp_linspace(Value lo, Value hi, Value nv)
{
    int n = (int)mp_ll(nv, "mp.linspace 第 3 个参数");
    if (n <= 0) mp_die("mp.linspace 元素数必须为正整数");
    double *o = (double *)malloc((size_t)n * sizeof(double));
    mp_linspace(o, n, mp_num(lo, "mp.linspace 第 1 个参数"),
                mp_num(hi, "mp.linspace 第 2 个参数"));
    Value res = mp_pack(o, (long long)n);
    free(o);
    return res;
}

/* ---------- 标量/变换 ---------- */

Value rt_lib_mp_clamp(Value v, Value lo, Value hi)
{
    return rt_float(mp_clamp(mp_num(v, "mp.clamp 第 1 个参数"),
                             mp_num(lo, "mp.clamp 第 2 个参数"),
                             mp_num(hi, "mp.clamp 第 3 个参数")));
}

Value rt_lib_mp_smoothstep(Value e0, Value e1, Value x)
{
    return rt_float(mp_smoothstep(mp_num(e0, "mp.smoothstep 第 1 个参数"),
                                 mp_num(e1, "mp.smoothstep 第 2 个参数"),
                                 mp_num(x, "mp.smoothstep 第 3 个参数")));
}

Value rt_lib_mp_lerp(Value a, Value b, Value t)
{
    return rt_float(mp_mix(mp_num(a, "mp.lerp 第 1 个参数"),
                           mp_num(b, "mp.lerp 第 2 个参数"),
                           mp_num(t, "mp.lerp 第 3 个参数")));
}

Value rt_lib_mp_radians(Value deg)
{
    return rt_float(mp_radians(mp_num(deg, "mp.radians")));
}

Value rt_lib_mp_degrees(Value rad)
{
    return rt_float(mp_degrees(mp_num(rad, "mp.degrees")));
}

/* ---------- 随机 ---------- */

Value rt_lib_mp_rand_seed(Value s)
{
    mp_rand_seed((uint64_t)mp_ll(s, "mp.rand_seed"));
    return rt_none();
}

Value rt_lib_mp_rand_u01(void)
{
    return rt_float(mp_rand_u01());
}

Value rt_lib_mp_rand_normal(Value m, Value sd)
{
    return rt_float(mp_rand_normal(mp_num(m, "mp.rand_normal 第 1 个参数"),
                                   mp_num(sd, "mp.rand_normal 第 2 个参数")));
}

#endif /* PYBOOK_RT_H */
