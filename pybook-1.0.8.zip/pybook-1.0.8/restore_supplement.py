# -*- coding: utf-8 -*-
"""restore_supplement.py — 把加强轮改动补回（配合 _session_backup 的覆盖式复原）。

用法：在仓库根目录 python restore_supplement.py
做三件事：
  ① pybook_net.c：v1 服务端区段整体替换为终版（查询参数/URL解码/有界头扫描/
     同包体 carry/GC 根三件套/http.post 客户端——每个修复都在）
  ② 前端三表补 http.post 登记（pybk_front / pybk_code / pybook_lib.h）
  ③ _vm_lib_calls.inc 补第 14 条 http.post（计数 256→257）
全部幂等：有标记就跳过。
"""
import io
import re

NEW_SERVER = r'''/* ================= HTTP 服务端（http.listen / serve / req / resp） =================
 * 四件套，和 http.get（客户端）同住一文件，C / VM 双管线可用：
 *   http.listen(端口)              → 监听句柄（同 net.listen，net.close 可关）
 *   http.serve(监听句柄)           → 阻塞等一个完整请求 → 会话句柄（>0）；垃圾请求
 *                                    被丢弃继续等，不砸死服务器
 *   http.req(会话句柄)             → 请求字典 {"方法","路径","参数","头","体"}；头的键已小写
 *   http.resp(会话,状态码,正文,"类型") → 发响应并关会话（Connection: close）
 * 会话里的字典挂 GC 根（rt_root_add）。头/体上限 1MB，读超时 10s。 */

#define HTTP_MAX_SESS   64
#define HTTP_MAX_HEAD   (64 * 1024)
#define HTTP_MAX_BODY   (1024 * 1024)
#define HTTP_TIMEOUT_MS 10000

typedef struct {
    SOCKET sock;              /* INVALID_SOCKET = 空槽 */
    Value  req;               /* 请求字典（挂 GC 根），resp 后置空 */
} HttpSess;

static HttpSess g_sess[HTTP_MAX_SESS];
static int g_sess_init = 0;

/* 请求组装三件套：serve 里要边分配边填（rt_str/dict 增长会触发 GC），
   必须挂在 GC 根上才活得到装进 g_sess[i].req 那一刻。全局槽一次挂根、
   每请求换新值，比给栈变量 rt_root_add（悬垂栈地址）安全。 */
static Value g_b_params;
static Value g_b_hdr;
static Value g_b_d;

static void http_sess_init(void)
{
    int i;
    if (g_sess_init)
        return;
    for (i = 0; i < HTTP_MAX_SESS; i++) {
        g_sess[i].sock = INVALID_SOCKET;
        g_sess[i].req = 0;
        rt_root_add(&g_sess[i].req);     /* 字典要在 serve→req 之间活过 GC */
    }
    rt_root_add(&g_b_params);
    rt_root_add(&g_b_hdr);
    rt_root_add(&g_b_d);
    g_sess_init = 1;
}

/* 会话槽校验：返回 NULL 表示句柄无效（调用方自行决定报错还是丢弃） */
static HttpSess *http_sess(Value hv, const char *who)
{
    long long h;
    http_sess_init();
    if (!IS_INT(hv))
        net_die("%s 需要整数会话句柄", who);
    h = AS_INT(hv);
    if (h < 0 || h >= HTTP_MAX_SESS || g_sess[h].sock == INVALID_SOCKET)
        return NULL;
    return &g_sess[h];
}

/* 阻塞收请求头到终止空行；返回 1=收齐 0=对端断/超时。
 * 头在 g_headbuf[0, *outlen)；*out_body_start 起是同包捎带来的体前段，
 * *out_total 是本次总共收到的字节数（体 carry = total - body_start）。 */
static char g_headbuf[HTTP_MAX_HEAD + 1];

static int http_recv_head(SOCKET s, size_t *outlen, size_t *out_body_start, size_t *out_total)
{
    size_t len = 0;
    for (;;) {
        size_t i;
        int r = recv(s, g_headbuf + len, (int)(HTTP_MAX_HEAD - len), 0);
        if (r <= 0)
            return 0;                    /* 断开 / 超时 / 错 */
        len += (size_t)r;
        g_headbuf[len] = '\0';
        for (i = 0; i + 3 < len; i++) {
            if (g_headbuf[i] == '\r' && g_headbuf[i + 1] == '\n'
                && g_headbuf[i + 2] == '\r' && g_headbuf[i + 3] == '\n') {
                g_headbuf[i] = '\0';     /* 掐掉终止空行（体从 i+4 起，留在缓冲里别丢） */
                *outlen = i;
                *out_body_start = i + 4;
                *out_total = len;
                return 1;
            }
        }
        if (len >= HTTP_MAX_HEAD)
            return 0;                    /* 头太大：当垃圾丢弃 */
    }
}

/* 小写化 + 去首尾空白的头名字拷贝（调用方 free） */
static char *http_lower_dup(const char *s, size_t n)
{
    char *p = (char *)malloc(n + 1);
    size_t a = 0, b = n;
    size_t k;
    if (!p)
        net_die("内存不足");
    while (a < b && (s[a] == ' ' || s[a] == '\t'))
        a++;
    while (b > a && (s[b - 1] == ' ' || s[b - 1] == '\t'))
        b--;
    for (k = a; k < b; k++)
        p[k - a] = (s[k] >= 'A' && s[k] <= 'Z') ? (char)(s[k] + 32) : s[k];
    p[b - a] = '\0';
    return p;
}

/* 去首尾空白、保留大小写（头的值 / 请求路径用：它们大小写敏感） */
static char *http_trim_dup(const char *s, size_t n)
{
    char *p;
    size_t a = 0, b = n, k;
    while (a < b && (s[a] == ' ' || s[a] == '\t'))
        a++;
    while (b > a && (s[b - 1] == ' ' || s[b - 1] == '\t'))
        b--;
    p = (char *)malloc(b - a + 1);
    if (!p)
        net_die("内存不足");
    for (k = a; k < b; k++)
        p[k - a] = s[k];
    p[b - a] = '\0';
    return p;
}

static int http_hexv(int c)
{
    if (c >= '0' && c <= '9')
        return c - '0';
    if (c >= 'a' && c <= 'f')
        return c - 'a' + 10;
    if (c >= 'A' && c <= 'F')
        return c - 'A' + 10;
    return -1;
}

/* URL 解码：%XX 十六进制还原，+ 还原成空格；其余原样（不校验 UTF-8 合法性） */
static char *http_url_decode(const char *s, size_t n)
{
    char *p = (char *)malloc(n + 1);
    size_t r = 0, w = 0;
    if (!p)
        net_die("内存不足");
    while (r < n) {
        if (s[r] == '%' && r + 2 < n &&
            http_hexv(s[r + 1]) >= 0 && http_hexv(s[r + 2]) >= 0) {
            p[w++] = (char)(http_hexv(s[r + 1]) * 16 + http_hexv(s[r + 2]));
            r += 3;
        } else if (s[r] == '+') {
            p[w++] = ' ';
            r++;
        } else {
            p[w++] = s[r];
            r++;
        }
    }
    p[w] = '\0';
    return p;
}

Value rt_http_listen(Value portv)
{
    return rt_net_listen(portv);         /* 监听句柄与 net.* 同一张表 */
}

Value rt_http_serve(Value lv)
{
    NetHandle *l;
    SOCKET c;
    size_t hlen = 0, blen = 0;
    size_t bstart = 0, total = 0, carry = 0;   /* 同包捎带来的体字节数 */
    char *body = NULL;
    char *method = NULL, *path = NULL;
    long long sh;

    net_ensure_init();
    http_sess_init();
    g_b_params = rt_dict_new();          /* 查询参数（无 query 就是空字典） */
    l = net_handle(lv);
    for (;;) {                           /* 垃圾请求：丢弃，回到 accept 继续等 */
        size_t i, line_start;
        int r;
        char *sp;
        c = accept(l->sock, NULL, NULL);
        if (c == INVALID_SOCKET) {
            if (WSAGetLastError() == WSAEWOULDBLOCK) {
                Sleep(1);
                continue;
            }
            net_die("http.serve：accept 失败（错误 %d）", WSAGetLastError());
        }
        {
            DWORD tmo = HTTP_TIMEOUT_MS;
            u_long blk = 0;
            /* Windows 的 accept 会继承监听套接字的非阻塞模式（和 BSD 不同）：
               监听是 net.listen 拨成非阻塞的，这里必须拨回阻塞，
               否则 recv 全部 WSAEWOULDBLOCK、请求被当断开丢弃。 */
            ioctlsocket(c, FIONBIO, &blk);
            setsockopt(c, SOL_SOCKET, SO_RCVTIMEO, (const char *)&tmo, sizeof tmo);
        }
        {
            if (!http_recv_head(c, &hlen, &bstart, &total)) {
                closesocket(c);
                continue;
            }
            carry = (total > bstart) ? (total - bstart) : 0;   /* 同包捎带来的体字节数 */
        }

        /* ---- 请求行：METHOD SP PATH [SP HTTP/x] ---- */
        for (i = 0; i < hlen; i++)
            if (g_headbuf[i] == '\r' || g_headbuf[i] == '\n')
                break;
        g_headbuf[i] = '\0';
        sp = strchr(g_headbuf, ' ');
        if (sp == NULL) {
            closesocket(c);
            continue;                    /* 请求行不合法 → 丢弃重等 */
        }
        *sp = '\0';
        method = http_trim_dup(g_headbuf, strlen(g_headbuf));
        {
            size_t q;
            for (q = 0; method[q]; q++)  /* 方法按惯例大写 */
                if (method[q] >= 'a' && method[q] <= 'z')
                    method[q] = (char)(method[q] - 32);
        }
        path = http_trim_dup(sp + 1, strlen(sp + 1));
        sp = strchr(path, ' ');
        if (sp != NULL)
            *sp = '\0';                  /* 掐掉 HTTP/x */

        /* ---- 查询字符串：路径?名=值&... → 路径（URL 解码）+ 参数（解码字典） ---- */
        {
            char *qm = strchr(path, '?');
            if (qm != NULL) {
                /* query 必须先拷出来：path 马上被解码替换并 free，
                   拿旧缓冲的指针解析 = use-after-free（实测第二组参数
                   读进分配器复用后的垃圾）。 */
                char *query = http_trim_dup(qm + 1, strlen(qm + 1));
                char *seg;
                char *dec;
                *qm = '\0';
                dec = http_url_decode(path, strlen(path));
                free(path);
                path = dec;
                seg = query;
                while (*seg != '\0') {
                    char *amp = strchr(seg, '&');
                    char *eq;
                    char *name, *val;
                    if (amp != NULL)
                        *amp = '\0';
                    eq = strchr(seg, '=');
                    if (eq != NULL) {
                        name = http_url_decode(seg, (size_t)(eq - seg));
                        val = http_url_decode(eq + 1, strlen(eq + 1));
                    } else {
                        name = http_url_decode(seg, strlen(seg));
                        val = http_url_decode("", 0);
                    }
                    rt_dict_set(&g_b_params, rt_str(name), rt_str(val));
                    free(name);
                    free(val);
                    if (amp == NULL)
                        break;
                    seg = amp + 1;
                }
                free(query);
            }
        }

        /* ---- 头：小写键 → 值（行 "Name: value"，到空行止）。
            有界扫描，绝不改写缓冲——旧版把行尾写 '\0'，strchr 从下一行
            一开始就被它挡住，第一条之后的头全部静默丢失。 ---- */
        g_b_hdr = rt_dict_new();
        line_start = i + 1;
        while (line_start < hlen) {
            size_t e = line_start, colon = 0, vs;
            int has_colon = 0, c2;
            while (e < hlen && g_headbuf[e] != '\r' && g_headbuf[e] != '\n')
                e++;
            for (c2 = (int)line_start; c2 < (int)e; c2++) {
                if (g_headbuf[c2] == ':') {
                    colon = (size_t)c2;
                    has_colon = 1;
                    break;
                }
            }
            if (has_colon && e > colon) {
                char *name = http_lower_dup(g_headbuf + line_start, colon - line_start);
                char *val;
                vs = colon + 1;
                while (vs < e && (g_headbuf[vs] == ' ' || g_headbuf[vs] == '\t'))
                    vs++;
                val = http_trim_dup(g_headbuf + vs, e - vs);
                rt_dict_set(&g_b_hdr, rt_str(name), rt_str(val));
                free(name);
                free(val);
            }
            while (e < hlen && (g_headbuf[e] == '\r' || g_headbuf[e] == '\n'))
                e++;
            line_start = e;
        }

        /* ---- 体：按 Content-Length（头键已小写，直接查表） ---- */
        if (rt_dict_has(g_b_hdr, rt_str("content-length"))) {
            const char *cl = AS_STR(rt_dict_get(g_b_hdr, rt_str("content-length")));
            long long want = _atoi64(cl);
            if (want > 0 && want <= HTTP_MAX_BODY) {
                body = (char *)malloc((size_t)want + 1);
                if (body != NULL) {
                    /* ① 先吃同包捎带的（recv_head 在终止空行后多收到的） */
                    carry = (carry > (size_t)want) ? (size_t)want : carry;
                    memcpy(body, g_headbuf + bstart, carry);
                    blen = carry;
                    /* ② 再从套接字收余下 */
                    while ((long long)blen < want) {
                        r = recv(c, body + blen, (int)(want - blen), 0);
                        if (r <= 0)
                            break;
                        blen += (size_t)r;
                    }
                    body[blen] = '\0';
                }
            }
        }

        /* ---- 组请求字典，占一个会话槽 ---- */
        g_b_d = rt_dict_new();
        rt_dict_set(&g_b_d, rt_str("方法"), rt_str(method));
        rt_dict_set(&g_b_d, rt_str("路径"), rt_str(path));
        rt_dict_set(&g_b_d, rt_str("参数"), g_b_params);
        rt_dict_set(&g_b_d, rt_str("头"), g_b_hdr);
        rt_dict_set(&g_b_d, rt_str("体"), rt_str(body ? body : ""));
        free(body);
        free(method);
        free(path);

        for (sh = 0; sh < HTTP_MAX_SESS; sh++) {
            if (g_sess[sh].sock == INVALID_SOCKET)
                break;
        }
        if (sh >= HTTP_MAX_SESS) {
            const char *busy = "HTTP/1.1 503 Busy\r\nContent-Length: 0\r\nConnection: close\r\n\r\n";
            send(c, busy, (int)strlen(busy), 0);
            closesocket(c);
            continue;
        }
        g_sess[sh].sock = c;
        g_sess[sh].req = g_b_d;
        return rt_int(sh);
    }
}

Value rt_http_req(Value sv)
{
    HttpSess *s = http_sess(sv, "http.req");
    if (s == NULL)
        net_die("http.req：会话不存在或已应答");
    return s->req;
}

Value rt_http_resp(Value sv, Value codev, Value bodyv, Value ctypev)
{
    HttpSess *s = http_sess(sv, "http.resp");
    long long code;
    const char *body, *ctype;
    char head[512];
    int hl, sent, total;
    static const struct { int c; const char *t; } REASONS[] = {
        {200, "OK"}, {201, "Created"}, {204, "No Content"},
        {301, "Moved Permanently"}, {302, "Found"},
        {400, "Bad Request"}, {403, "Forbidden"}, {404, "Not Found"},
        {405, "Method Not Allowed"}, {500, "Internal Server Error"},
        {502, "Bad Gateway"}, {503, "Service Unavailable"},
    };
    const char *reason = "OK";
    size_t k;

    if (s == NULL)
        net_die("http.resp：会话不存在或已应答");
    if (!IS_INT(codev))
        net_die("http.resp 的状态码需要整数");
    code = AS_INT(codev);
    body = net_str(bodyv, "http.resp 的正文");
    ctype = net_str(ctypev, "http.resp 的类型");
    if (ctype[0] == '\0')
        ctype = "text/html; charset=utf-8";
    for (k = 0; k < sizeof REASONS / sizeof REASONS[0]; k++)
        if (REASONS[k].c == (int)code)
            reason = REASONS[k].t;

    hl = snprintf(head, sizeof head,
                  "HTTP/1.1 %lld %s\r\n"
                  "Content-Type: %s\r\n"
                  "Content-Length: %zu\r\n"
                  "Connection: close\r\n"
                  "\r\n",
                  code, reason, ctype, strlen(body));
    total = 0;
    while (total < hl) {
        sent = send(s->sock, head + total, hl - total, 0);
        if (sent <= 0)
            break;
        total += sent;
    }
    if (total == hl) {
        size_t bl = strlen(body);
        total = 0;
        while ((size_t)total < bl) {
            sent = send(s->sock, body + total, (int)(bl - total), 0);
            if (sent <= 0)
                break;
            total += sent;
        }
    }
    closesocket(s->sock);
    s->sock = INVALID_SOCKET;
    s->req = 0;
    return rt_none();
}

/* 读光一个已发出的请求： realloc 缓冲 → NUL 结尾 char*（调用方 free） */
static char *http_read_all(HINTERNET req)
{
    size_t cap = 65536, len = 0;
    char *body = (char *)malloc(cap);
    char tmp[8192];
    DWORD n = 0;
    if (!body)
        net_die("内存不足");
    while (InternetReadFile(req, tmp, (DWORD)sizeof tmp, &n) && n > 0) {
        if (len + n + 1 > cap) {
            char *nb;
            cap = (len + n + 1) * 2;
            nb = (char *)realloc(body, cap);
            if (!nb) {
                free(body);
                net_die("内存不足");
            }
            body = nb;
        }
        memcpy(body + len, tmp, n);
        len += n;
    }
    body[len] = 0;
    return body;
}

/* http.post(网址, 体, "Content-Type")：POST 上去拿回正文（http/https 自动）。
 * 和 http.get 同族：状态码落 http.code()；失败正文为空串（用 http.code 查 0）。 */
Value rt_http_post(Value urlv, Value bodyv, Value ctypev)
{
    const char *url = net_str(urlv, "http.post 的网址");
    const char *body = net_str(bodyv, "http.post 的体");
    const char *ctype = net_str(ctypev, "http.post 的类型");
    HINTERNET ses = NULL, conn = NULL, req = NULL;
    char *host = NULL, *path = NULL;
    char hdrs[512];
    char *out = NULL;
    DWORD code = 0, clen = (DWORD)sizeof code, https = 0, port = 0;

    if (ctype[0] == '\0')
        ctype = "application/x-www-form-urlencoded";
    g_http_code = 0;

    {
        const char *p = strstr(url, "://");
        const char *hostp, *slash;
        if (p != NULL) {
            https = (_strnicmp(url, "https", 5) == 0) ? 1 : 0;
            hostp = p + 3;
        } else {
            hostp = url;
        }
        slash = strchr(hostp, '/');
        if (slash != NULL) {
            host = http_trim_dup(hostp, (size_t)(slash - hostp));
            path = http_trim_dup(slash, strlen(slash));
        } else {
            host = http_trim_dup(hostp, strlen(hostp));
            path = http_trim_dup("/", 1);
        }
    }
    {
        char *colon = strchr(host, ':');        /* host:port */
        if (colon != NULL) {
            *colon = '\0';
            port = (DWORD)_atoi64(colon + 1);
        }
    }
    if (path[0] == '\0')
        path[0] = '/';

    ses = InternetOpenA("pybook", INTERNET_OPEN_TYPE_PRECONFIG, 0, 0, 0);
    if (!ses)
        goto done;
    conn = InternetConnectA(ses, host,
                            port ? port : (https ? INTERNET_DEFAULT_HTTPS_PORT
                                                 : INTERNET_DEFAULT_HTTP_PORT),
                            NULL, NULL, INTERNET_SERVICE_HTTP, 0, 0);
    if (!conn)
        goto done;
    req = HttpOpenRequestA(conn, "POST", path, "HTTP/1.1", NULL, NULL,
                           https ? INTERNET_FLAG_SECURE
                                 : INTERNET_FLAG_RELOAD | INTERNET_FLAG_NO_CACHE_WRITE,
                           0);
    if (!req)
        goto done;
    snprintf(hdrs, sizeof hdrs, "Content-Type: %s\r\n", ctype);
    if (!HttpSendRequestA(req, hdrs, -1, (LPVOID)body, (DWORD)strlen(body)))
        goto done;
    HttpQueryInfoA(req, HTTP_QUERY_STATUS_CODE | HTTP_QUERY_FLAG_NUMBER,
                   &code, &clen, 0);
    g_http_code = (int)code;
    out = http_read_all(req);

done:
    if (req)
        InternetCloseHandle(req);
    if (conn)
        InternetCloseHandle(conn);
    if (ses)
        InternetCloseHandle(ses);
    free(host);
    free(path);
    {
        Value v;
        if (out != NULL) {
            v = rt_str(out);
            free(out);
        } else {
            v = rt_str("");
        }
        return v;
    }
}

'''

def rd(p):
    return io.open(p, 'rb').read().decode('utf-8').replace('\r\n', '\n')

def wr(p, t):
    raw = io.open(p, 'rb').read().decode('utf-8')
    eol = '\r\n' if '\r\n' in raw else '\n'
    io.open(p, 'wb').write(t.replace('\n', eol).encode('utf-8'))

# ---------- ① pybook_net.c：v1 服务端区段 → 终版 ----------
P = 'pybook_net.c'
t = rd(P)
START = '/* ================= HTTP 服务端（http.listen / serve / req / resp） ================='
END = '/* ================= 自测（-DNET_SELF_TEST） ================='
if 'query 必须先拷出来' in t:
    print('① pybook_net.c：已是终版，跳过')
else:
    assert START in t and END in t, '服务端区段标记没找到'
    a, b = t.index(START), t.index(END)
    t = t[:a] + NEW_SERVER + '\n' + t[b:]
    wr(P, t)
    print('① pybook_net.c：服务端区段已替换为终版（含加强轮全部修复 + http.post）')

# ---------- ② 前端三表：http.post ----------
P = 'pybk_front.py'
t = rd(P)
if "'http.post': 3" not in t:
    a = "'http.listen': 1, 'http.serve': 1, 'http.req': 1, 'http.resp': 4,"
    assert a in t
    t = t.replace(a, a + "\n    'http.post': 3,", 1)
    wr(P, t)
    print('② pybk_front.py：http.post 已登记')
else:
    print('② pybk_front.py：已有')

P = 'pybk_code.py'
t = rd(P)
if "'http.post': 'rt_http_post'" not in t:
    a = "'http.req': 'rt_http_req', 'http.resp': 'rt_http_resp',"
    assert a in t
    t = t.replace(a, a + "\n        'http.post': 'rt_http_post',", 1)
    wr(P, t)
    print('② pybk_code.py：http.post 已映射')
else:
    print('② pybk_code.py：已有')

P = 'pybook_lib.h'
t = rd(P)
if 'rt_http_post' not in t:
    a = 'Value rt_http_listen(Value port);'
    assert a in t
    t = t.replace(a, 'Value rt_http_post(Value url, Value body, Value ctype);  /* http.post(网址,体,"类型") */\n' + a, 1)
    wr(P, t)
    print('② pybook_lib.h：rt_http_post 原型已加')
else:
    print('② pybook_lib.h：已有')

# ---------- ③ inc：第 14 条 http.post ----------
P = '_vm_lib_calls.inc'
t = rd(P)
if 'rt_http_post' in t:
    print('③ _vm_lib_calls.inc：已有 http.post')
else:
    a = '{"http.resp", 4, (void *)rt_http_resp},'
    assert a in t, 'inc 里没有 http.resp 锚点（inc 不是还原后的 256 版？）'
    t = t.replace(a, a + '\n    {"http.post", 3, (void *)rt_http_post},', 1)
    m = re.search(r'#define G_LIB_CALLS_N (\d+)', t)
    n = int(m.group(1))
    t = t.replace(m.group(0), '#define G_LIB_CALLS_N %d' % (n + 1), 1)
    wr(P, t)
    print('③ _vm_lib_calls.inc：http.post 已接线（%d → %d）' % (n, n + 1))

print('复原补丁全部完成')
