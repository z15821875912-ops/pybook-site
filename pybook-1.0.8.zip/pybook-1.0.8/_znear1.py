# -*- coding: utf-8 -*-
"""_znear1.py — N = C/(s-1) + 16 里的 C 取多少，才够 1e-12 / 1e-15。
现值 C=10 在 s=1.0001 上只有 1e-8。代价是 N 次 pow()。"""

from fractions import Fraction
import math
import time

BF = [Fraction(1, 12), Fraction(-1, 720), Fraction(1, 30240),
      Fraction(-1, 1209600), Fraction(1, 47900160), Fraction(-691, 1307674368000)]
BFf = [float(x) for x in BF]


def zeta(s, C, K=6, cap=4000000):
    N = int(C/(s-1.0) + 16.0)
    N = max(20, min(N, cap))
    total = sum(float(i)**(-s) for i in range(1, N))
    t = N**(-s)
    total += 0.5*t + t*N/(s-1.0)
    ps = s
    for k in range(K):
        if k > 0:
            for i in range(2):
                ps *= (s + 2.0*k - 1.0 + i)
        total += BFf[k]*ps*N**(-s-2.0*k-1.0)
    return total, N


TRUE = {1.0001: 10000.577323356426, 1.001: 1000.5773323590681,
        1.01: 100.58804025751788, 1.1: 10.5844484649508, 1.5: 2.6123753486854883433,
        2.0: math.pi**2/6, 5.0: 1.0369277551433699, 20.0: 1.0000009539620339}

print('%-9s' % 's', ''.join('%-22s' % ('C=%d' % C) for C in (10, 30, 60, 120, 250)))
for s, tv in TRUE.items():
    row = '%-9s' % s
    for C in (10, 30, 60, 120, 250):
        v, N = zeta(s, C)
        row += '%-22s' % ('%.1e (N=%d)' % (abs(v-tv)/abs(tv), N))
    print(row)

print()
print('耗时（C 越大 N 越大，s=1.0001 这一格）：')
for C in (10, 30, 60, 120, 250):
    t0 = time.perf_counter()
    zeta(1.0001, C)
    print('  C=%-4d %6.1f ms' % (C, (time.perf_counter()-t0)*1000))

print()
print('扩大 K（修正项数）能不能便宜地补精度？C=10, s=1.0001：')
for K in (6, 8, 10, 12):
    v, N = zeta(1.0001, 10, K=K)
    print('  K=%-3d 误差 %.2e' % (K, abs(v-TRUE[1.0001])/TRUE[1.0001]))
