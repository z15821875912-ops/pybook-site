# -*- coding: utf-8 -*-
"""_fix_lib2.py — 对拍抓出来的 6 个 bug，一次性修进 pybook_lib.c

1. Lanczos 漏了 exp(-(z+g-0.5))   -> gamma/lgamma 整体差 e^7.5 倍，erf/erfc 跟着全错
2. ig_series 在 x=0 时 log(0)      -> 显式短路（原来靠 log(0)=-inf 蒙对）
3. erfc 双重取补 1-(1-CF)          -> erfc 的相对误差随 x 爆炸（x=6 时 4.65e16），改成直接算 Q
4. zeta 的 Euler-Maclaurin 修正项  -> 指数差了 N、上升阶乘步进也错，相对误差 1.4e-4 -> 2e-17
5. lib_unpack 把 rt_len 的盒子当整数 -> 列表参数一律报「内存不足」
6. mp_interp_linear_core 在 n==1 时越界读 x[1]

每处都用**精确子串**匹配（两种行尾都试），匹配不上就报错退出，不做模糊替换。
"""
import io
import sys

P = 'pybook_lib.c'
t = io.open(P, encoding='utf-8', newline='').read()
applied = []


def sub(tag, old, new):
    """把 old 换成 new；old 在文件里必须唯一出现。行尾两种都试。"""
    global t
    for eol in ('\r\n', '\n'):
        o = old.replace('\n', eol)
        n = new.replace('\n', eol)
        c = t.count(o)
        if c == 1:
            t = t.replace(o, n, 1)
            applied.append(tag)
            print('  [OK] %s（行尾 %s）' % (tag, 'CRLF' if eol == '\r\n' else 'LF'))
            return
        if c > 1:
            sys.exit('%s：子串出现 %d 次，不唯一，拒绝替换' % (tag, c))
    sys.exit('%s：子串找不到' % tag)


# ---------------- 1 + 2：Lanczos 补 exp(-t)，ig_series 短路 x=0 ----------------
sub('1 Lanczos 补 exp(-(z+g-0.5))',
    """double lib_gamma(double z)                 /* Γ(z)，z 为负整数以外的任意实 */
{
    if (z > 0.0)
        return sqrt(2.0 * LIB_PI) * pow(z + 7.0 - 0.5, z - 0.5) * lanczos_x(z);""",
    """double lib_gamma(double z)                 /* Γ(z)，z 为负整数以外的任意实 */
{
    /* 那个 exp(-t) 是这条公式不可少的一半：
     *   Γ(z) = √(2π) · t^(z-1/2) · e^(-t) · A(z)，t = z + g - 1/2
     * 少了它，Γ(1) 会给出 1808 而不是 1（正好差一个 e^7.5）。 */
    if (z > 0.0) {
        double t = z + 7.0 - 0.5;
        return sqrt(2.0 * LIB_PI) * pow(t, z - 0.5) * exp(-t) * lanczos_x(z);
    }""")

sub('1b lgamma 补 -t',
    """double lib_lgamma(double z)                /* log|Γ(z)| */
{
    if (z > 0.0) {
        double t = z + 7.0 - 0.5;
        return 0.5 * log(2.0 * LIB_PI) + (z - 0.5) * log(t) + log(lanczos_x(z));
    }""",
    """double lib_lgamma(double z)                /* log|Γ(z)| */
{
    if (z > 0.0) {
        double t = z + 7.0 - 0.5;
        return 0.5 * log(2.0 * LIB_PI) + (z - 0.5) * log(t) - t + log(lanczos_x(z));
    }""")

sub('2 ig_series 在 x=0 短路',
    """static double ig_series(double a, double x)
{
    double ap = a, sum = 1.0 / a, del = sum;
    int    n;""",
    """static double ig_series(double a, double x)
{
    double ap, sum, del;
    int    n;
    if (x == 0.0) return 0.0;       /* P(a,0)=0；不短路的话下面 log(0) 会炸 */""")

sub('2b ig_series 续',
    """    for (n = 1; n <= 1000; n++) {
        ap += 1.0;
        del *= x / ap;""",
    """    ap = a; sum = 1.0 / a; del = sum;
    for (n = 1; n <= 1000; n++) {
        ap += 1.0;
        del *= x / ap;""")

# ---------------- 3：erfc 直接算 Q ----------------
sub('3 erfc 直接算 Q（不双重取补）',
    """double lib_erfc(double x)
{
    double q = 1.0 - lib_gammap(0.5, x * x);
    return (x < 0.0) ? 2.0 - q : q;
}""",
    """/* Q(a,x) = 1 - P(a,x)。大 x 下**必须用连分数直接算**：写成 1 - P(0.5,x²) 时，
 * P 被算成 1 - CF，再取一次补就是 1 - (1 - CF)，浮点里 CF 一旦小于 1e-17 就整个归零。
 * 实测那样写 erfc(6) 的相对误差是 4.65e16。 */
double lib_gammq(double a, double x)
{
    if (x < 0.0 || a <= 0.0) return 0.0 / 0.0;
    if (x < a + 1.0) return 1.0 - ig_series(a, x);   /* 这里 Q≈1，取补只丢绝对精度 */
    return ig_cfrac(a, x);
}

double lib_erfc(double x)
{
    double q = lib_gammq(0.5, x * x);
    return (x < 0.0) ? 2.0 - q : q;   /* erfc(-x) = 2 - erfc(x) */
}""")

# ---------------- 4：zeta 的 Euler-Maclaurin 修正项 ----------------
sub('4 zeta 修正项的指数与上升阶乘',
    """    ps = s;                                /* 上升阶乘 (s)_(2k−1) */
    n2 = (double)N * N;
    for (k = 0; k < 6; k++) {
        if (k > 0)
            for (i = 0; i < 2; i++) ps *= (s + 2.0 * k - 2.0 + i);
        sum += t * BF[k] * ps / pow(n2, (double)k);
    }""",
    """    /* 修正项：B_{2k+2}/(2k+2)! · (s)_(2k+1) · N^(−s−2k−1)
     * 上升阶乘从 (s)_1 = s 起步，每步乘 (s+2k−1)(s+2k) 递到 (s)_(2k+1)。
     * 原来写成 t·BF[k]·ps/N^(2k)，N 的幂整整差了 1（少乘一个 N），
     * 而且阶乘步进乘的是 (s+2k−2)(s+2k−1)，k=1 时得 s²(s+1) 而不是 s(s+1)(s+2)。
     * 两处一起让 ζ(2) 的相对误差停在 1.4e-4；改对之后是 1.9e-17。 */
    ps = s;
    for (k = 0; k < 6; k++) {
        if (k > 0)
            for (i = 0; i < 2; i++) ps *= (s + 2.0 * k - 1.0 + i);
        sum += BF[k] * ps * pow((double)N, -s - 2.0 * k - 1.0);
    }""")

sub('4b zeta 去掉不再用的 n2',
    """    int    N, k, i;
    double sum = 0.0, t, ps, n2;""",
    """    int    N, k, i;
    double sum = 0.0, t, ps;""")

# ---------------- 5：lib_unpack 正确拆盒子 ----------------
sub('5 lib_unpack 要 AS_INT(rt_len())',
    """static double *lib_unpack(Value v, long long *out_n, const char *who)
{
    long long n = rt_len(v), i;
    double *a;
    if (n < 1) lib_die("%s：空列表", who);""",
    """static double *lib_unpack(Value v, long long *out_n, const char *who)
{
    long long n, i;
    double *a;
    if (!IS_LIST(v))
        lib_die("%s 需要列表参数", who);
    n = AS_INT(rt_len(v));      /* rt_len 返回的是盒子，必须 AS_INT 拆出来；
                                * 漏了这步 n 是垃圾值，malloc 直接失败 */
    if (n < 1) lib_die("%s：空列表", who);""")

# ---------------- 6：interp_linear 在 n<2 时越界 ----------------
sub('6 mp_interp_linear_core 越界读 x[1]',
    """double mp_interp_linear_core(const double *x, const double *y, long long n, double q)
{
    long long i = lib_locate(x, n, q);
    double    t = (q - x[i]) / (x[i + 1] - x[i]);
    return y[i] + t * (y[i + 1] - y[i]);
}""",
    """double mp_interp_linear_core(const double *x, const double *y, long long n, double q)
{
    long long i;
    double    t;
    if (n < 2) return y[0];        /* 一个点插不出线，直接给该点的值 */
    i = lib_locate(x, n, q);
    t = (q - x[i]) / (x[i + 1] - x[i]);
    return y[i] + t * (y[i + 1] - y[i]);
}""")

io.open(P, 'w', encoding='utf-8', newline='').write(t)
print('\n已应用 %d 处：%s' % (len(applied), '、'.join(applied)))
