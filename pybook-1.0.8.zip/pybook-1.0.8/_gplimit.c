﻿/* _gplimit.c -- 测这张卡的 FP32 极限速度。
 *
 * ==========================================================================
 * 结论（2026-10-17）：**这个工具测不出可信的 FMA 上限，别信它出的数。**
 * ==========================================================================
 * 先说硬事实：
 *     驱动报告频率 = 1.708 GHz，SM 数 = 10
 *     按架构手册每 SM 64 个 FP32 单元 -> 理论上限 = 10 x 64 x 2 x 1.708 GHz
 *     = 2.19 TFLOPS（每 SM 单元数是我按手册写死的常量，不是查出来的）
 *
 * 而我之前拿 fma_peak 报的是 **3.44 ~ 4.27 TFLOPS —— 比理论还高**。
 * 测出来的数超过硬件上限，说明的是测量错了，不是卡变强了。
 * 这和之前那次 13.8 TB/s 的假带宽是同一个失败模式。
 *
 * 为什么错：原来的 8 条「独立」FMA 链全是 fma(%f1, %f2, %fN)，累加器都从 0
 * 开始，**编译器可以证明它们恒等，于是 8 条塌成 1 条**。按 8 条去算 TFLOPS
 * 就虚高 8 倍，真实值约 **0.44 TFLOPS** —— 一条依赖链、纯延迟受限，
 * 恰好印证了「每个调度器至少要 4 条独立链才喂得饱」。
 *
 * 修掉链合并之后（每条链给各自的乘数），**数字还是不可信**，因为编译器
 * 又用了第二招：acc += 常数 是等差数列，可以直接化简成 acc = n x 常数，
 * 循环体里一条 FMA 都不留。证据是 nc=1 时用时几乎不随网格变化：
 *     10 块 0.134 ms   160 块 0.133 ms   （工作量 16 倍，时间不变）
 * 而把迭代数拉高 10 倍，用时确实涨 9.3 倍 —— 说明循环在跑，但循环体是空的。
 * 按吞吐算，16 块/SM 时每调度器每轮要发 16 warp x 8 = 128 条 FMA，
 * 至少 128 个时钟；而实测每轮只有 19 个时钟，对不上。
 *
 * 第三招也堵不住：要让「乘法操作数每轮都不同」，就得动态索引，
 * 而 PTX 的访存地址只准「寄存器 + 立即数」，寄存器 + 寄存器非法，
 * 所以必须展开 64 次才能用上立即数下标，代价大到不值得。
 *
 * 所以：**本文件保留下来是为了留证据，不是为了出数。**
 * 目前唯一敢报的算力数字是生产内核那个 ——
 * sgemm_8x8 在 N=3216 上 2.07 TFLOPS，正确性由 tests/T23 与 P0_30 端到端验过，
 * 每线程干的活数由独立朴素三重循环当裁判核对过。
 *
 * 下面是完整的三道自检和扫描逻辑，修法都对，只是还顶不住编译器。
 * 想真测 FMA 上限，得换一个编译器没法化简的结构（比如每轮从 host 填的
 * 数组里取操作数，并展开到能用立即数下标），那是另一件事。
 *
 * --------------------------------------------------------------------------
 * 编译：
 *   C:\Users\zhuli\mingw64\bin\x86_64-w64-mingw32-gcc.exe _gplimit.c -o _gplimit.exe -O2 -lm
 * PTX 由 _gpfma_gen.py 生成：python -B _gpfma_gen.py
 */
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

typedef int          CUresult;
typedef int          CUdevice;
typedef void        *CUcontext;
typedef void        *CUmodule;
typedef void        *CUfunction;
typedef void        *CUevent;
typedef unsigned long long CUdeviceptr;

#define CU_DEVICE_ATTRIBUTE_CC_MAJOR            75
#define CU_DEVICE_ATTRIBUTE_CC_MINOR            76
#define CU_DEVICE_ATTRIBUTE_MULTIPROCESSOR_COUNT 16
#define CU_DEVICE_ATTRIBUTE_CLOCK_RATE          13
#define CU_DEVICE_ATTRIBUTE_MAX_THREADS_PER_BLOCK 39
#define CU_DEVICE_ATTRIBUTE_WARP_SIZE           37
#define CU_EVENT_DEFAULT 0

/* 每个 SM 的 FP32 单元数。Pascal GP106（sm_61）每个 SM 4 个处理块 x 16 = 64。
 * 这个数我是按架构手册写死的，不是查来的 —— 所以下面用它算出的「理论上限」
 * 只当作参考标尺，报告里会明说这一点。 */
#define LANES_PER_SM 64

static HMODULE g_dll;
static CUresult (*p_cuInit)(unsigned);
static CUresult (*p_cuDeviceGet)(CUdevice *, int);
static CUresult (*p_cuDeviceGetName)(char *, int, CUdevice);
static CUresult (*p_cuDeviceGetAttribute)(int *, int, CUdevice);
static CUresult (*p_cuDevicePrimaryCtxRetain)(CUcontext *, CUdevice);
static CUresult (*p_cuCtxSetCurrent)(CUcontext);
static CUresult (*p_cuCtxSynchronize)(void);
static CUresult (*p_cuModuleLoadData)(CUmodule *, const void *);
static CUresult (*p_cuModuleGetFunction)(CUfunction *, CUmodule *, const char *);
static CUresult (*p_cuMemAlloc_v2)(CUdeviceptr *, size_t);
static CUresult (*p_cuMemFree_v2)(CUdeviceptr);
static CUresult (*p_cuMemcpyHtoD_v2)(CUdeviceptr, const void *, size_t);
static CUresult (*p_cuMemcpyDtoH_v2)(void *, CUdeviceptr, size_t);
static CUresult (*p_cuLaunchKernel)(CUfunction, unsigned, unsigned, unsigned,
                                    unsigned, unsigned, unsigned,
                                    unsigned, void *, void **, void **);
static CUresult (*p_cuGetErrorString)(CUresult, const char **);
static CUresult (*p_cuEventCreate)(CUevent *, unsigned);
static CUresult (*p_cuEventRecord)(CUevent, void *);
static CUresult (*p_cuEventSynchronize)(CUevent);
static CUresult (*p_cuEventElapsedTime)(float *, CUevent, CUevent);

static CUcontext g_ctx;
static char g_err[256];
static char g_ptx[1 << 16];

static const char *cu_err(CUresult r)
{
    const char *s = NULL;
    if (p_cuGetErrorString && p_cuGetErrorString(r, &s) == 0 && s) return s;
    return "未知 CUDA 错误";
}

/* 每一步都查返回值。教训（本会话）：cuEventElapsedTime 静默失败时 el 保留旧值，
 * 于是报出过 3357 TFLOPS 这种荒谬数字却毫无报错。 */
#define CK(expr, what) do {                                   \
        CUresult _r = (expr);                                \
        if (_r != 0) {                                       \
            printf("[错误] %s -> %s\n", (what), cu_err(_r));  \
            return 1;                                        \
        }                                                    \
    } while (0)

static int load_ptx(const char *path)
{
    FILE *f = fopen(path, "rb");
    size_t n;
    if (!f) { snprintf(g_err, sizeof g_err, "打不开 %s", path); return 0; }
    n = fread(g_ptx, 1, sizeof(g_ptx) - 1, f);
    fclose(f);
    g_ptx[n] = '\0';
    if (n < 100) { snprintf(g_err, sizeof g_err, "%s 太短", path); return 0; }
    return 1;
}

static int cmp_dbl(const void *a, const void *b)
{
    double x = *(const double *)a, y = *(const double *)b;
    return (x > y) - (x < y);
}

static const int CHAIN[] = { 1, 2, 4, 8, 16, 32 };
#define NCHAIN ((int)(sizeof CHAIN / sizeof CHAIN[0]))

/* 每线程每轮做 nc 条 FMA，每条 2 flop。 */
static double flops_of(int nc, unsigned blocks, unsigned threads, unsigned iters)
{
    return (double)blocks * threads * iters * (double)nc * 2.0;
}

int main(int argc, char **argv)
{
    void *p;
    CUdevice dev;
    CUmodule mod;
    CUfunction fn;
    CUdeviceptr dOut = 0;
    CUevent ev0 = NULL, ev1 = NULL;
    CUresult r;
    int maj = 0, min = 0, nsm = 0, khz = 0, max_thr = 0, wsize = 0;
    int ci, rep, bi;
    double clock_hz, tpeak;
    double t[15];
    float el;
    unsigned bx = 256;
    int rounds = argc > 1 ? atoi(argv[1]) : 3;
    unsigned iters = argc > 2 ? (unsigned)atoi(argv[2]) : 20000u;
    static const int BPSM[] = { 1, 2, 4, 6, 8, 12, 16 };
    const int nbpsm = (int)(sizeof BPSM / sizeof BPSM[0]);

    SetConsoleOutputCP(65001);
    if (rounds < 1) rounds = 1;

    g_dll = LoadLibraryA("nvcuda.dll");
    if (!g_dll) { printf("找不到 nvcuda.dll\n"); return 1; }
#define LOAD(nm, fn_) do { p = (void *)GetProcAddress(g_dll, nm); \
    if (!p) { printf("缺 %s\n", nm); return 1; } memcpy(&(fn_), &p, sizeof(fn_)); } while (0)
    LOAD("cuInit", p_cuInit);
    LOAD("cuDeviceGet", p_cuDeviceGet);
    LOAD("cuDeviceGetName", p_cuDeviceGetName);
    LOAD("cuDeviceGetAttribute", p_cuDeviceGetAttribute);
    LOAD("cuDevicePrimaryCtxRetain", p_cuDevicePrimaryCtxRetain);
    LOAD("cuCtxSetCurrent", p_cuCtxSetCurrent);
    LOAD("cuCtxSynchronize", p_cuCtxSynchronize);
    LOAD("cuModuleLoadData", p_cuModuleLoadData);
    LOAD("cuModuleGetFunction", p_cuModuleGetFunction);
    LOAD("cuMemAlloc_v2", p_cuMemAlloc_v2);
    LOAD("cuMemFree_v2", p_cuMemFree_v2);
    LOAD("cuMemcpyHtoD_v2", p_cuMemcpyHtoD_v2);
    LOAD("cuMemcpyDtoH_v2", p_cuMemcpyDtoH_v2);
    LOAD("cuLaunchKernel", p_cuLaunchKernel);
    LOAD("cuGetErrorString", p_cuGetErrorString);
    LOAD("cuEventCreate", p_cuEventCreate);
    LOAD("cuEventRecord", p_cuEventRecord);
    LOAD("cuEventSynchronize", p_cuEventSynchronize);
    LOAD("cuEventElapsedTime", p_cuEventElapsedTime);

    if (p_cuInit(0) != 0) { printf("cuInit 失败\n"); return 1; }
    if (p_cuDeviceGet(&dev, 0) != 0) { printf("cuDeviceGet 失败\n"); return 1; }
    if (p_cuDevicePrimaryCtxRetain(&g_ctx, dev) != 0) { printf("取主上下文失败\n"); return 1; }
    if (p_cuCtxSetCurrent(g_ctx) != 0) { printf("置当前上下文失败\n"); return 1; }

    { char nm[128]; p_cuDeviceGetName(nm, sizeof nm, dev); }
    p_cuDeviceGetAttribute(&maj, CU_DEVICE_ATTRIBUTE_CC_MAJOR, dev);
    p_cuDeviceGetAttribute(&min, CU_DEVICE_ATTRIBUTE_CC_MINOR, dev);
    p_cuDeviceGetAttribute(&nsm, CU_DEVICE_ATTRIBUTE_MULTIPROCESSOR_COUNT, dev);
    p_cuDeviceGetAttribute(&khz, CU_DEVICE_ATTRIBUTE_CLOCK_RATE, dev);
    p_cuDeviceGetAttribute(&max_thr, CU_DEVICE_ATTRIBUTE_MAX_THREADS_PER_BLOCK, dev);
    p_cuDeviceGetAttribute(&wsize, CU_DEVICE_ATTRIBUTE_WARP_SIZE, dev);

    clock_hz = (double)khz * 1000.0;
    tpeak = nsm * (double)LANES_PER_SM * 2.0 * clock_hz / 1e12;

    printf("设备：NVIDIA GeForce GTX 1060 6GB   CC=sm_%d%d   SM 数 = %d\n", maj, min, nsm);
    printf("报告频率 = %.3f GHz（驱动时钟属性；这卡跨运行升频很凶，实测以本次为准）\n",
           clock_hz / 1e9);
    printf("每 SM 按架构手册取 %d 个 FP32 单元 -> 理论上限 = %d x %d x 2 x %.3f GHz = %.2f TFLOPS\n",
           LANES_PER_SM, nsm, LANES_PER_SM, clock_hz / 1e9, tpeak);
    printf("（每 SM 单元数是按手册写死的常量，不是查出来的，报告时会标明）\n");
    printf("每块 %u 线程，每线程 %u 轮，每点 %d 轮取中位数\n\n", bx, iters, rounds);

    CK(p_cuMemAlloc_v2(&dOut, 4096), "分配输出缓冲");
    CK(p_cuEventCreate(&ev0, CU_EVENT_DEFAULT), "建 ev0");
    CK(p_cuEventCreate(&ev1, CU_EVENT_DEFAULT), "建 ev1");

    printf("  链数  块/SM   网格      用时      TFLOPS   占理论   内核实跑轮数\n");
    printf("  ---------------------------------------------------------------\n");

    for (ci = 0; ci < NCHAIN; ci++) {
        int nc = CHAIN[ci];
        char path[64];
        snprintf(path, sizeof path, "_ptx_FMA%d.ptx", nc);
        if (!load_ptx(path)) { printf("%s\n", g_err); return 1; }
        r = p_cuModuleLoadData(&mod, g_ptx);
        if (r != 0) { printf("%s 被拒：%s\n", path, cu_err(r)); return 1; }
        if (p_cuModuleGetFunction(&fn, mod, "fma_peak") != 0) {
            printf("取不到 %s 的 fma_peak\n", path); return 1;
        }

        for (bi = 0; bi < nbpsm; bi++) {
            unsigned gx = (unsigned)(nsm * BPSM[bi]);
            void *pargs[2];
            float back[40];
            double ms, tf;
            int bad = 0;

            pargs[0] = &dOut; pargs[1] = &iters;
            /* 预热：首次发射含 JIT */
            CK(p_cuLaunchKernel(fn, gx, 1, 1, bx, 1, 1, 0, NULL, pargs, NULL), "预热发射");
            CK(p_cuCtxSynchronize(), "预热同步");

            /* --- 自检一：内核到底跑了多少轮 --- */
            memset(back, 0, sizeof back);
            CK(p_cuMemcpyDtoH_v2(back, dOut, sizeof(float) * (nc + 3)), "读回输出");
            if (fabs((double)back[nc + 1] - (double)iters) > 1.0) {
                printf("  %4d  %5d  %6u  ** 实跑 %.0f 轮，要求 %u 轮 **  数据无效\n",
                       nc, BPSM[bi], gx, (double)back[nc + 1], iters);
                continue;
            }
            /* --- 自检二：网格大小反查（内核写的是 gridDim.x * blockDim.x） --- */
            if (fabs((double)back[nc + 2] - (double)gx * (double)bx) > 1.0) {
                printf("  %4d  %5d  %6u  ** 网格反查 %.0f，应为 %.0f **  数据无效\n",
                       nc, BPSM[bi], gx, (double)back[nc + 2], (double)gx * (double)bx);
                continue;
            }
            /* --- 自检四：各链累加值必须两两不同 ---
             * 全部共用一个乘数、累加器都从 0 开始时，链之间**可证明恒等**，
             * 编译器会把 nc 条塌成 1 条，而按 nc 条去算 TFLOPS 就会虚高 nc 倍。
             * 这正是原来那个 fma_peak 报 3.48 TFLOPS 的根因。
             * 所以这里直接查「有没有两条链算出同一个数」。 */
            {
                int a, b2, dup = -1;
                for (a = 0; a < nc && dup < 0; a++) {
                    for (b2 = a + 1; b2 < nc; b2++) {
                        double x = (double)back[a], y = (double)back[b2];
                        double d = fabs(x - y) / (fabs(x) > 1.0 ? fabs(x) : 1.0);
                        if (d < 1e-5) { dup = b2; break; }
                    }
                }
                if (dup >= 0) {
                    printf("  %4d  %5d  %6u  ** 链 %d 和链 %d 算出同一个值(%.4f) "
                           "-> 编译器把它们合并了，实际只跑了更少的链 **\n",
                           nc, BPSM[bi], gx, dup - 1, dup, (double)back[dup]);
                    continue;
                }
            }

            for (rep = 0; rep < rounds; rep++) {
                el = -1.0f;
                CK(p_cuEventRecord(ev0, NULL), "ev0 record");
                CK(p_cuLaunchKernel(fn, gx, 1, 1, bx, 1, 1, 0, NULL, pargs, NULL), "发射");
                CK(p_cuEventRecord(ev1, NULL), "ev1 record");
                CK(p_cuEventSynchronize(ev1), "ev1 同步");
                CK(p_cuEventElapsedTime(&el, ev0, ev1), "取 event 用时");
                if (el <= 0) { printf("[错误] 用时非正 %f\n", (double)el); return 1; }
                t[rep] = el;
            }
            /* 取中位数：动态升频会骗人，别取最优。样本不足时用最后一组补齐再排序。 */
            {
                double s[15];
                int k;
                for (k = 0; k < 15; k++) s[k] = (k < rounds) ? t[k] : t[rounds - 1];
                qsort(s, 15, sizeof(double), cmp_dbl);
                ms = s[7];
            }
            tf = flops_of(nc, gx, bx, iters) / (ms / 1000.0) / 1e12;

            /* --- 自检三：不得超过理论上限的 105% --- */
            if (tf > tpeak * 1.05) {
                printf("  %4d  %5d  %6u  %7.3f ms  %7.2f T   %6.1f%%  ** 超过理论上限，数据不可信 **\n",
                       nc, BPSM[bi], gx, ms, tf, tf / tpeak * 100.0);
                bad = 1;
            }
            if (!bad) {
                printf("  %4d  %5d  %6u  %7.3f ms  %7.2f T   %6.1f%%  %8.0f\n",
                       nc, BPSM[bi], gx, ms, tf, tf / tpeak * 100.0, (double)back[nc + 1]);
            }
        }
        putchar('\n');
    }

    CK(p_cuMemFree_v2(dOut), "释放输出缓冲");
    printf("说明：占理论 = 实测 TFLOPS / (SM 数 x 每 SM 单元数 x 2 x 报告频率)。\n");
    printf("      真正最高的那一格才是「这张卡的极限速度」。\n");
    (void)argc;
    return 0;
}
