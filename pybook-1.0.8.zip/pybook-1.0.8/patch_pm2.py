# -*- coding: utf-8 -*-
"""patch_pm2.py — 包管理器第二批加强（配合已写入的第一批）。
① pack 携带传递依赖清单 + 质量门接入 pack/publish
② pkg search / pkg uninstall 两个新动作
③ pybk_code._main_file_dir 扫 argv 里的 .pybk（修 --check 跨目录引用解析）
全部幂等。"""
import io
import re

def rd(p):
    return io.open(p, 'rb').read().decode('utf-8').replace('\r\n', '\n')

def wr(p, t):
    raw = io.open(p, 'rb').read().decode('utf-8')
    eol = '\r\n' if '\r\n' in raw else '\n'
    io.open(p, 'wb').write(t.replace('\n', eol).encode('utf-8'))

def sub1(t, old, new, tag):
    if new in t:
        print('  %s: 已有，跳过' % tag)
        return t
    assert old in t, tag + ' 锚点没找到'
    print('  %s: 已应用' % tag)
    return t.replace(old, new, 1)

P = 'tools/pybktl/pybktl.py'
t = rd(P)

# ---- ① _pack_zip：携带传递依赖清单 ----
old = '''    manifest_text = (
        f"# PYbook 包：{name}\\n\\n"
        "## 包信息\\n"
        f"name: {name}\\n"
        f"version: {version}\\n"
        f"packed_at: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\\n"
        f"files: {len(files)}\\n\\n"
        "## 文件\\n"
        + "".join(f"- {rel}\\n" for rel, _ in files)
        + "\\n## 依赖\\n"
        "- （无）\\n"'''
new = '''    # 传递依赖：包目录自己的 pybook.md「## 依赖」段原样带走（install 时按名解析）
    carried = []
    dir_md = os.path.join(srcdir, MANIFEST)
    if os.path.isfile(dir_md):
        for _n, _p, _v in parse_manifest(dir_md).get("deps", []):
            carried.append(f"- {_n} => (registry) @{_v}" if _v else f"- {_n} => (registry)")
    carried_text = "".join(f"{c}\\n" for c in carried) or "- （无）\\n"
    manifest_text = (
        f"# PYbook 包：{name}\\n\\n"
        "## 包信息\\n"
        f"name: {name}\\n"
        f"version: {version}\\n"
        f"packed_at: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\\n"
        f"files: {len(files)}\\n\\n"
        "## 文件\\n"
        + "".join(f"- {rel}\\n" for rel, _ in files)
        + "\\n## 依赖\\n"
        + carried_text'''
assert 'manifest_text = (' in t
t = sub1(t, old, new, '_pack_zip 携带依赖')

# ---- ② 质量门接进 pack/publish（_pack_zip 调用前）----
old = """    if act == "pack":
        srcdir = _winpath(args.name or ".")
        if not os.path.isdir(srcdir):
            err(f"✗ 目录不存在: {srcdir}")
            return 1
        name, version = _pkg_name_version(srcdir, args)"""
new = """    if act == "pack":
        srcdir = _winpath(args.name or ".")
        if not os.path.isdir(srcdir):
            err(f"✗ 目录不存在: {srcdir}")
            return 1
        _quality_gate(srcdir, force=getattr(args, "force", False))
        name, version = _pkg_name_version(srcdir, args)"""
t = sub1(t, old, new, 'pack 质量门')

old = """    if act == "publish":
        srcdir = _winpath(args.name or ".")
        if not os.path.isdir(srcdir):
            err(f"✗ 目录不存在: {srcdir}")
            return 1
        reg = _registry_dir(args)"""
new = """    if act == "publish":
        srcdir = _winpath(args.name or ".")
        if not os.path.isdir(srcdir):
            err(f"✗ 目录不存在: {srcdir}")
            return 1
        _quality_gate(srcdir, force=getattr(args, "force", False))
        reg = _registry_dir(args)"""
t = sub1(t, old, new, 'publish 质量门')

# ---- ③ search / uninstall 两个动作（插在 install 分支后）----
old = """    if act == "install":
        return _pkg_install(args)
    return 1"""
new = '''    if act == "search":
        reg = _registry_dir(args)
        rows = _read_registry_index(reg)
        kw = (args.name or "").lower()
        hits = [r for r in rows if not kw or kw in r[0].lower()]
        if not hits:
            out(f"· registry 里没有匹配的包（{reg}，共 {len(rows)} 个）")
            return 0
        out(f"registry {reg}（{len(rows)} 个包，匹配 {len(hits)}）：")
        for name, version, fname, sha, size, when in hits:
            out(f"  - {name} @{version}  {size} 字节  {when}")
        out("  安装：pybktl pkg install 名字[@版本]")
        return 0
    if act == "uninstall":
        data = parse_manifest(manifest)
        name = (args.name or "").strip()
        import shutil as _sh
        libdir = os.path.join(os.getcwd(), "libs", name)
        removed = []
        if os.path.isdir(libdir):
            for dirpath, _dirs, files in os.walk(libdir):
                for fn in files:
                    if fn.endswith(".pybk"):
                        rootcopy = os.path.join(os.getcwd(), fn)
                        if os.path.isfile(rootcopy):
                            os.remove(rootcopy)
            _sh.rmtree(libdir, ignore_errors=True)
            removed.append(f"libs/{name}/")
        keep = [d for d in data["deps"] if d[0] != name]
        if len(keep) != len(data["deps"]):
            lines = io_lines(os.path.join(os.getcwd(), MANIFEST))
            outl = [l for l in lines if not (l.strip().startswith(f"- {name} ") or l.strip() == f"- {name}")]
            io.open(os.path.join(os.getcwd(), MANIFEST), "w", encoding="utf-8", newline="").write("\\n".join(outl))
            removed.append("清单条目")
        if removed:
            out(f"✓ 已卸载 {name}：" + "、".join(removed))
            return 0
        err(f"✗ 没找到已安装的包：{name}")
        return 1
    if act == "install":
        return _pkg_install(args)
    return 1


def io_lines(path):
    if os.path.isfile(path):
        return io_open_lines(path)
    return []


def io_open_lines(path):
    import io as _io
    return _io.open(path, encoding="utf-8").read().split("\\n")'''
t = sub1(t, old, new, 'search/uninstall 动作')

# ---- ④ 解析器 choices + force ----
old = '''    pp.add_argument("pkg_action",
                    choices=["add", "lock", "sync", "list", "pack", "publish", "install"])'''
new = '''    pp.add_argument("pkg_action",
                    choices=["add", "lock", "sync", "list", "pack", "publish", "install",
                             "search", "uninstall"])'''
t = sub1(t, old, new, 'choices')
old = '''    pp.add_argument("-o", "--out", help="pack 时的输出 .pybp 路径")'''
new = '''    pp.add_argument("-o", "--out", help="pack 时的输出 .pybp 路径")
    pp.add_argument("--registry", help="registry 目录（默认 ~/.pybook/registry）")
    pp.add_argument("--force", action="store_true", help="跳过质量门/锁校验")
    pp.add_argument("--as-name", help="pack 时覆盖包名")
    pp.add_argument("--version", help="pack 时覆盖版本号")'''
t = sub1(t, old, new, 'pkg 参数')

wr(P, t)

# ---- ⑤ pybk_main 引用解析：扫 argv 里的 .pybk ----
P = 'pybk_main.py'
t = rd(P)
old = '''def main():
    argv = sys.argv[1:]'''
if '_pybk_arg_dir' not in t:
    helper = '''
def _pybk_arg_dir():
    """--check/--check-json 在 argv[1] 位上时，引用() 的解析目录退化成进程 cwd——
    从别的目录跑就找不到同目录的包。这里扫 argv 找第一个真实存在的 .pybk 取其目录。"""
    import os as _os
    for _a in sys.argv[1:]:
        if _a.lower().endswith(".pybk") and _os.path.isfile(_a):
            return _os.path.dirname(_os.path.abspath(_a)) or "."
    return None


def main():
    argv = sys.argv[1:]'''
    assert old in t, 'main 锚点没找到'
    t = t.replace(old, helper, 1)
    # 注入到编译入口：pybk_main 调 _完整编译/compile_and_run 前
    old2 = """    try:
        compile_and_run(src)"""
    new2 = """    try:
        _d = _pybk_arg_dir()
        if _d:
            os.environ["PYBK_IMPORT_DIR"] = _d
        compile_and_run(src)"""
    assert old2 in t, 'compile 锚点没找到'
    t = t.replace(old2, new2, 1)
    wr(P, t)
    print('  pybk_main.py：argv 目录扫描已接（PYBK_IMPORT_DIR 自动设）')
else:
    print('  pybk_main.py：已有')

# ---- ⑥ pybk_code：_main_file_dir 也认 PYBK_IMPORT_DIR ----
P = 'pybk_code.py'
t = rd(P)
if 'PYBK_IMPORT_DIR' in t:
    print('  pybk_code.py：已有 PYBK_IMPORT_DIR')
else:
    old = """    if len(sys.argv) >= 2 and os.path.isfile(sys.argv[1]):
        return os.path.dirname(os.path.abspath(sys.argv[1])) or '.'
    return os.getcwd()"""
    new = """    env_dir = os.environ.get('PYBK_IMPORT_DIR')
    if env_dir:
        return env_dir
    if len(sys.argv) >= 2 and os.path.isfile(sys.argv[1]):
        return os.path.dirname(os.path.abspath(sys.argv[1])) or '.'
    return os.getcwd()"""
    t = sub1(t, old, new, 'pybk_code PYBK_IMPORT_DIR')
    wr(P, t)

print('patch_pm2 全部完成')
