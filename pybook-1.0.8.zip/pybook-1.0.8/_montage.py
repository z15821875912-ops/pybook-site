# 把若干张 BMP 的同一区域横向拼成一张对比条（BMP 输出，24bpp，自底向上）
#
# 用法: python -B _montage.py 出图.bmp x0 y0 x1 y1 输入1.bmp 输入2.bmp ...
# 用途: _demostat.py 是用数值证明「粒子颜色换了」，这个是把眼睛能看的那部分
#       直接拼出来 —— 青 / 橙 / 紫 三个状态并排，色相差异一目了然。

import struct
import sys


def read_bmp(path):
    d = open(path, 'rb').read()
    off = struct.unpack_from('<I', d, 10)[0]
    w = struct.unpack_from('<i', d, 18)[0]
    h = struct.unpack_from('<i', d, 22)[0]
    flip = h > 0                      # BMP 高度为正 = 自底向上
    h = abs(h)
    stride = ((w * 3 + 3) // 4) * 4
    rows = []
    for y in range(h):
        b = off + y * stride
        rows.append([(d[b + x * 3 + 2], d[b + x * 3 + 1], d[b + x * 3])
                     for x in range(w)])
    # ★ 必须翻成自顶向下，否则调用方给的 (x0,y0,x1,y1) 裁到的是镜像区域。
    #   （_demostat.py 里有这一步，早先漏了，裁出来是能量环而不是粒子区。）
    if flip:
        rows.reverse()
    return w, h, rows


def write_bmp(path, w, h, rows):
    stride = ((w * 3 + 3) // 4) * 4
    pad = stride - w * 3
    out = bytearray()
    out += b'BM'
    out += struct.pack('<IHHI', 14 + 40 + stride * h, 0, 0, 14 + 40)
    out += struct.pack('<IiiHHIIiiII', 40, w, h, 1, 24, 0,
                       stride * h, 2835, 2835, 0, 0)
    for y in range(h - 1, -1, -1):                 # BMP 自底向上
        for r, g, b in rows[y]:
            out += bytes((b, g, r))
        out += bytes(pad)
    open(path, 'wb').write(bytes(out))


def main():
    out = sys.argv[1]
    x0, y0, x1, y1 = map(int, sys.argv[2:6])
    srcs = sys.argv[6:]
    cw = x1 - x0 + 1
    gap = 3
    W = cw * len(srcs) + gap * (len(srcs) - 1)
    H = y1 - y0 + 1
    rows = [[(255, 0, 0)] * W for _ in range(H)]   # 缝用红色，漏了看不出来
    for k, s in enumerate(srcs):
        _, _, src = read_bmp(s)
        ox = k * (cw + gap)
        for y in range(H):
            sr = src[y0 + y]
            dst = rows[y]
            for x in range(cw):
                dst[ox + x] = sr[x0 + x]
    write_bmp(out, W, H, rows)
    print(f'{out}  {W}x{H}  {len(srcs)} 块并排  源区 ({x0},{y0})-({x1},{y1})')


if __name__ == '__main__':
    main()
