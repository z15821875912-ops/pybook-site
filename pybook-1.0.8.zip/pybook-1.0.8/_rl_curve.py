# 画 REINFORCE 训 CartPole 的收敛曲线（numpy + PIL，只用现成库）
#
# 数据来自 _rl_摆杆训练.pybk 的 stdout：
#   曲线 10 12 9 45 ... 30        每 10 回合一行，后跟那 10 个回合的分数
# PYbook 没有写文件的接口，所以只能解析 stdout。
#
# 画两条线：
#   裸分（暗）   每回合的分数，抖得厉害，但那是真实数据
#   滑动平均（亮）窗口 50，那是趋势
# 再画两条参考线：400（学会线）/ 500（满分行）。

import sys
import numpy as np
from PIL import Image, ImageDraw, ImageFont

SRC = sys.argv[1] if len(sys.argv) > 1 else '_rl_train_1000.txt'
OUT = sys.argv[2] if len(sys.argv) > 2 else 'shots_rl/reinforce_curve.png'

BG = (11, 16, 24)
GRID = (26, 36, 50)
AXIS = (58, 74, 96)
RAW = (72, 92, 122)
MA = (90, 220, 255)
LEARN = (255, 96, 96)
FULL = (150, 140, 120)
TXT = (176, 194, 214)
TXT_DIM = (98, 112, 132)

W, H = 1180, 660
ML, MR, MT, MB = 78, 210, 62, 74          # 左边距/右边距/上边距/下边距
PW, PH = W - ML - MR, H - MT - MB


def load(path):
    # PowerShell 5.1 的 `>` 重定向写的是 UTF-16LE，这里按 BOM 认，别写死 utf-8
    with open(path, 'rb') as fh:
        raw = fh.read()
    enc = 'utf-16' if raw[:2] in (b'\xff\xfe', b'\xfe\xff') else 'utf-8'
    scores = {}
    for line in raw.decode(enc).splitlines():
        p = line.split()
        if len(p) == 12 and p[0] == '曲线':
            f = int(p[1])
            for i, v in enumerate(p[2:]):
                # 第 f 帧那一行打的是 记分[f-10] .. 记分[f-1]，即第 f-9 .. f 回合
                scores[f - 9 + i] = int(v)
    if not scores:
        raise SystemExit('没读到曲线行，检查 ' + path)
    n = max(scores)
    return np.array([scores[i] for i in range(1, n + 1)], dtype=float)


def moving_average(a, win):
    c = np.cumsum(np.insert(a, 0, 0.0))
    lo = np.maximum(0, np.arange(len(a)) - win + 1)
    return (c[np.arange(len(a)) + 1] - c[lo]) / (np.arange(len(a)) - lo + 1)


def font(px):
    for f in (r'C:\Windows\Fonts\msyh.ttc', r'C:\Windows\Fonts\simhei.ttf',
              r'C:\Windows\Fonts\simsun.ttc'):
        try:
            return ImageFont.truetype(f, px)
        except OSError:
            pass
    return ImageFont.load_default()


def main():
    a = load(SRC)
    n = len(a)
    ma = moving_average(a, 50)

    im = Image.new('RGB', (W, H), BG)
    d = ImageDraw.Draw(im, 'RGBA')
    f_ttl = font(23)
    f_lbl = font(14)
    f_sm = font(12)

    ymax = 520.0

    def px(e):
        return ML + e / n * PW

    def py(s):
        return MT + PH - s / ymax * PH

    # ---- 网格 ----
    for s in range(0, 501, 100):
        d.line([(ML, py(s)), (ML + PW, py(s))], fill=GRID, width=1)
        d.text((ML - 10, py(s) - 7), str(s), font=f_sm, fill=TXT_DIM, anchor='ra')
    for e in range(0, n + 1, 100):
        d.line([(px(e), MT), (px(e), MT + PH)], fill=GRID, width=1)
        d.text((px(e), MT + PH + 8), str(e), font=f_sm, fill=TXT_DIM, anchor='ma')

    # ---- 参考线 ----
    d.line([(ML, py(400)), (ML + PW, py(400))], fill=LEARN, width=2)
    d.line([(ML, py(500)), (ML + PW, py(500))], fill=FULL, width=2)
    for s, c in ((400, LEARN), (500, FULL)):
        t = '学会线 400' if s == 400 else '满分行 500'
        d.rectangle([ML + PW - 118, py(s) - 20, ML + PW - 6, py(s) - 2],
                    fill=(BG + (200,)))
        d.text((ML + PW - 112, py(s) - 18), t, font=f_sm, fill=c)

    # ---- 坐标轴 ----
    d.line([(ML, MT), (ML, MT + PH)], fill=AXIS, width=2)
    d.line([(ML, MT + PH), (ML + PW, MT + PH)], fill=AXIS, width=2)

    # ---- 裸分（暗，密集）----
    pts = [(px(i + 1), py(a[i])) for i in range(n)]
    d.line(pts, fill=(RAW + (170,)), width=1)

    # ---- 滑动平均（亮，粗）----
    mpts = [(px(i + 1), py(ma[i])) for i in range(n)]
    d.line(mpts, fill=MA, width=3)

    # ---- 首次触顶 500 ----
    top = np.where(a >= 500)[0]
    if len(top):
        t = top[0] + 1
        d.line([(px(t), py(0)), (px(t), py(500))], fill=(255, 210, 90), width=2)
        d.text((px(t) + 8, MT + 6), '首次 500 分：第 %d 回合' % t,
               font=f_lbl, fill=(255, 210, 90))

    # ---- 学会线标注 ----
    above = np.where(ma >= 400)[0]
    if len(above):
        d.text((ML + 12, py(400) - 26), '滑动平均首次越过 400：第 %d 回合' % (above[0] + 1),
               font=f_lbl, fill=LEARN)

    # ---- 标题 ----
    d.text((ML, 14), 'REINFORCE 训 CartPole（4→16 tanh→2 softmax，114 参数，Adam 5e-3）',
           font=f_ttl, fill=(228, 240, 252))
    d.text((ML, 38), '%d 回合 · 每回合 1 帧 · 分数上限 500 · 随机策略约 22 分' % n,
           font=f_lbl, fill=TXT_DIM)

    # ---- 图例 ----
    lx, ly = ML + PW + 10, MT + 4
    d.line([(lx, ly), (lx + 26, ly)], fill=RAW, width=1)
    d.text((lx + 34, ly - 8), '裸分', font=f_sm, fill=TXT)
    ly += 26
    d.line([(lx, ly), (lx + 26, ly)], fill=MA, width=3)
    d.text((lx + 34, ly - 8), '滑动平均(50)', font=f_sm, fill=MA)
    ly += 32
    d.text((lx, ly), '收敛统计', font=f_lbl, fill=TXT)
    ly += 22
    tail = a[-100:]
    stats = [('裸分 前 100 均值', a[:100].mean()),
             ('裸分 后 100 均值', tail.mean()),
             ('后 100 最小值', tail.min()),
             ('后 100 满分数占比', '%.0f%%' % (100.0 * (tail >= 500).mean())),
             ('历史最高', a.max())]
    for k, v in stats:
        d.text((lx, ly), k, font=f_sm, fill=TXT_DIM)
        d.text((lx + 150, ly), ('%.1f' % v) if isinstance(v, float) else str(v),
               font=f_sm, fill=TXT, anchor='ra')
        ly += 19

    d.text((ML + PW // 2, H - 26), '回合数', font=f_lbl, fill=TXT_DIM, anchor='ma')
    # y 轴标题竖排：不 rotate 的横向文字放左边距会被裁掉，绕不开就把画布留宽
    lab = Image.new('RGBA', (150, 26), BG + (0,))
    ImageDraw.Draw(lab).text((75, 13), '回合分数', font=f_lbl, fill=TXT_DIM, anchor='mm')
    im.paste(lab.rotate(90, expand=True), (14, MT + PH // 2 - 75), lab.rotate(90, expand=True))

    import os
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    im.save(OUT)

    # ---- 控制台里的 ASCII 版（无头环境也能看）----
    BARS = ' .:-=+*#%@'
    print('裸分 ASCII 图（每列 2 回合，%d 回合 → %d 列）' % (n, n // 2))
    for s in range(500, -25, -25):
        row = ''.join(BARS[min(9, int(a[i] / 525.0 * 9.999))] if a[i] >= s - 12 else ' '
                     for i in range(0, n, 2))
        print('%4d |%s' % (s, row))
    print('     +' + '-' * (n // 2))
    print('      0' + ' ' * ((n // 2) // 2 - 1) + str(n))
    print()
    print('写入', OUT)
    print('前 100 回合均值 %.1f  →  后 100 回合均值 %.1f' % (a[:100].mean(), tail.mean()))
    if len(above):
        print('滑动平均首次越过 400：第 %d 回合' % (above[0] + 1))
    if len(top):
        print('裸分首次 500：第 %d 回合；后 100 回合满分数占比 %.0f%%'
              % (top[0] + 1, 100.0 * (tail >= 500).mean()))


if __name__ == '__main__':
    main()
