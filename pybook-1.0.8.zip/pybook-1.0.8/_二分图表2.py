import subprocess, sys, io
sys.stdout.reconfigure(encoding='utf-8')

CASES = {
    '表统': '''vg.销 = [["华东","Q1",120],["华东","Q2",150],["华北","Q1",90],["华北","Q2",60]]
vg.汇 = 表.统(销, 0, 2, "求和")
ns.show("组数", 长度(汇), " 首组", 汇[0][0], " 值", 汇[0][1])
''',
    '表统最大': '''vg.销 = [["华东","Q1",120],["华东","Q2",150],["华北","Q1",90]]
vg.汇 = 表.统(销, 0, 2, "最大")
ns.show("最大", 汇[0][1])
''',
    '表补': '''vg.缺 = [["a", 1], ["b"]]
vg.补 = 表.补(缺, 0)
ns.show("补齐", 补[1][0], 补[1][1])
''',
    '表排': '''vg.体 = [["a", 3], ["b", 1], ["c", 2]]
vg.降 = 表.排(体, 1, 1)
ns.show("降序首行", 降[0][0], 降[0][1])
''',
    '小画布轴': '''vg.板 = 图.画布(40, 40)
vg.区 = 图.轴(板, 0, 10, 0, 100, "测试", "x", "y")
ns.show("绘图区", 区)
''',
    '小画布折线': '''vg.板 = 图.画布(40, 40)
图.轴(板, 0, 10, 0, 100, "测试", "x", "y")
图.折线(板, [0,2,4,6,8,10], [0,40,80,60,20,100], [200,30,90], 2)
图.散点(板, [0,2,4], [0,40,80], [0,0,0], 3)
ns.show("走完")
''',
    '框圆字': '''vg.板 = 图.画布(40, 40)
图.框(板, 30, 30, 8, 8, [255,0,0], 1)
图.圆(板, 10, 30, 5, [0,160,0], 1)
图.字(板, 2, 2, "AB", [0,0,0], 2)
ns.show("走完")
''',
    '存盘小': '''vg.板 = 图.画布(40, 40)
图.存(板, "_二分_小.png")
ns.show("走完")
''',
}

for name, body in CASES.items():
    src = '@ 二分>%s\n\nGOING:{\n%s\n}STOP\n' % (name, body)
    f = '_二分.pybk'
    io.open(f, 'w', encoding='utf-8', newline='\n').write(src)
    print('=== %s ===' % name, flush=True)
    try:
        r = subprocess.run([sys.executable, 'pybk_main.py', f],
                           capture_output=True, text=True, encoding='utf-8',
                           timeout=120, errors='replace')
        out = (r.stdout or '').strip().split('\n')
        print('  rc=%d  %s' % (r.returncode, ' | '.join(out[-2:])))
        if r.stderr:
            print('  stderr:', r.stderr.strip()[:160])
    except subprocess.TimeoutExpired:
        print('  超时')
