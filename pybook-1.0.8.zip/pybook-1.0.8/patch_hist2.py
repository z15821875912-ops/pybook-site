# -*- coding: utf-8 -*-
"""patch_hist2.py — hist 团队化加强：push/pull（共享历史）+ claim（软锁）
+ save 红绿灯（改动的 .pybk 自动过静态检查）+ decide（团队决策记录）。幂等。"""
import io

def rd(p):
    return io.open(p, 'rb').read().decode('utf-8').replace('\r\n', '\n')

def wr(p, t):
    raw = io.open(p, 'rb').read().decode('utf-8')
    eol = '\r\n' if '\r\n' in raw else '\n'
    io.open(p, 'wb').write(t.replace('\n', eol).encode('utf-8'))

P = 'tools/pybktl/hist.py'
t = rd(P)

# ---------- ① save：红绿灯 + 他人软锁提醒 ----------
old = """def _save(root_note, auto=False):
    os.makedirs(_hist(), exist_ok=True)
    rows = _read_index()
    prev = rows[-1]["files"] if rows else {}
    cur = _current_state()
    added, removed, changed = _diff_states(prev, cur)
    if not (added or removed or changed):
        out("· 与上一次快照完全一致，无需新快照")
        return"""
new = """def _find_compiler():
    \"\"\"从 cwd 一路向上找 pybk_main.py（红绿灯要用它跑 --check-json）。\"\"\"
    d = os.getcwd()
    while d:
        cand = os.path.join(d, 'pybk_main.py')
        if os.path.isfile(cand):
            return cand
        parent = os.path.dirname(d)
        if parent == d:
            break
        d = parent
    return None


def _light(pybk_files):
    \"\"\"红绿灯：改动的 .pybk 过一遍静态检查。返回 '绿'/'红'/None（找不到编译器不亮灯）。
    库豁免：只犯「GOING 块」错误的视为库文件，放行。\"\"\"
    import subprocess as sp
    mainpy = _find_compiler()
    if not mainpy or not pybk_files:
        return None
    import sys as _s
    ok = True
    for f in pybk_files:
        try:
            r = sp.run([_s.executable, mainpy, '--check-json', f],
                       capture_output=True, text=True, encoding='utf-8',
                       errors='replace', timeout=60)
        except Exception:
            return None
        line = (r.stdout or '').strip().splitlines()[-1] if (r.stdout or '').strip() else ''
        bad = r.returncode != 0 or ('"ok": false' in line.replace(' ', ''))
        if bad and 'GOING 块' not in line:
            ok = False
    return '绿' if ok else '红'


def _active_claims():
    \"\"\"30 分钟内有效的软锁登记。\"\"\"
    import json
    p = os.path.join('.pybook', '编辑中.jsonl')
    rows = []
    if os.path.isfile(p):
        import time as _t
        now = _t.time()
        for line in open(p, encoding='utf-8'):
            line = line.strip()
            if not line:
                continue
            try:
                r = json.loads(line)
            except Exception:
                continue
            if now - r.get('ts', 0) < 1800:
                rows.append(r)
    return rows


def _claim_conflicts(files):
    \"\"\"我正要快照的文件里，有没有别人 30 分钟内登记过「我在改」？\"\"\"
    me = _author()
    hits = []
    for r in _active_claims():
        if r.get('author') == me:
            continue
        for f in files:
            if f in r.get('files', []) or f in r.get('files', {}):
                import time as _t
                mins = int((_t.time() - r.get('ts', 0)) / 60)
                hits.append(f"{r.get('author')} {mins} 分钟前也在改 {f}")
    return hits


def _save(root_note, auto=False):
    os.makedirs(_hist(), exist_ok=True)
    rows = _read_index()
    prev = rows[-1]["files"] if rows else {}
    cur = _current_state()
    added, removed, changed = _diff_states(prev, cur)
    if not (added or removed or changed):
        out("· 与上一次快照完全一致，无需新快照")
        return
    for h in _claim_conflicts(list(cur.keys())):
        out(f"⚠ 软锁提醒: {h}——先和对方打个招呼再覆盖")
    pybk_changed = [f for f in changed + added if f.endswith('.pybk')]
    light = _light(pybk_changed)"""
assert old in t, 'save 头锚点没找到'
t = t.replace(old, new, 1)

old = """    row = {"id": sid, "time": now.strftime("%Y-%m-%d %H:%M:%S"),
           "author": _author(), "note": (root_note or note)[:80],
           "added": added, "removed": removed, "changed": changed,
           "files": cur}
    _append_index(row)"""
new = """    row = {"id": sid, "time": now.strftime("%Y-%m-%d %H:%M:%S"),
           "author": _author(), "note": (root_note or note)[:80],
           "added": added, "removed": removed, "changed": changed,
           "files": cur, "灯": light or "无"}
    _append_index(row)"""
assert old in t, 'row 锚点没找到'
t = t.replace(old, new, 1)

old = """    out(f"✓ 快照 {sid}  作者 {_author()}  （{' / '.join(parts) or '无变化'}）")"""
new = """    lamp = {'绿': '●绿', '红': '●红'}.get(light or '', '○')
    out(f"✓ 快照 {sid}  {lamp}  作者 {_author()}  （{' / '.join(parts) or '无变化'}）")"""
assert old in t, '输出锚点没找到'
t = t.replace(old, new, 1)

# ---------- ② log：显示红绿灯 ----------
old = """    for r in rows:
        n = len(r.get("changed", [])) + len(r.get("added", [])) + len(r.get("removed", []))
        out(f"  {r['id']}  {r['time']}  {r['author']:<8} 改动{n:>2}  {r['note'][:46]}")"""
new = """    for r in rows:
        n = len(r.get("changed", [])) + len(r.get("added", [])) + len(r.get("removed", []))
        lamp = {'绿': '●绿', '红': '●红'}.get(r.get('灯', ''), '○')
        out(f"  {r['id']}  {lamp}  {r['time']}  {r['author']:<8} 改动{n:>2}  {r['note'][:40]}")"""
assert old in t, 'log 锚点没找到'
t = t.replace(old, new, 1)

# ---------- ③ push / pull / claim / claims / decide ----------
NEW_CMDS = '''

def cmd_push(args):
    """把本地新快照推到共享历史目录（索引 + blobs 增量合并，按 id 去重）。"""
    target = args.path
    os.makedirs(target, exist_ok=True)
    local = _read_index()
    tidx = os.path.join(target, "索引.jsonl")
    shared = []
    if os.path.isfile(tidx):
        import json
        for line in open(tidx, encoding="utf-8"):
            line = line.strip()
            if line:
                shared.append(json.loads(line))
    have = {r["id"] for r in shared}
    fresh = [r for r in local if r["id"] not in have]
    tblobs = os.path.join(target, "blobs")
    pushed_shas = 0
    for r in fresh:
        for sha in r.get("files", {}).values():
            src = _blob_path(sha)
            dst = os.path.join(tblobs, sha)
            if os.path.isfile(src) and not os.path.isfile(dst):
                os.makedirs(tblobs, exist_ok=True)
                shutil.copy(src, dst)
                pushed_shas += 1
    import json
    with open(tidx, "a", encoding="utf-8") as f:
        for r in fresh:
            f.write(json.dumps(r, ensure_ascii=False) + "\\n")
    authors = sorted({r["author"] for r in fresh})
    out(f"✓ 已推送 {len(fresh)} 条快照（{pushed_shas} 个内容块）→ {target}")
    out(f"  作者: {'、'.join(authors) or '—'}；共享历史现共 {len(shared) + len(fresh)} 条")
    return 0


def cmd_pull(args):
    """从共享历史目录拉取新快照（只增不删；restore 永远先存安全快照，不吞工作）。"""
    import json
    target = args.path
    tidx = os.path.join(target, "索引.jsonl")
    if not os.path.isfile(tidx):
        err(f"✗ 共享历史不存在: {tidx}")
        return 1
    shared = []
    for line in open(tidx, encoding="utf-8"):
        line = line.strip()
        if line:
            shared.append(json.loads(line))
    local = _read_index()
    have = {r["id"] for r in local}
    incoming = [r for r in shared if r["id"] not in have]
    os.makedirs(os.path.join(_hist(), "blobs"), exist_ok=True)
    for r in incoming:
        for sha in r.get("files", {}).values():
            src = os.path.join(target, "blobs", sha)
            dst = _blob_path(sha)
            if os.path.isfile(src) and not os.path.isfile(dst):
                shutil.copy(src, dst)
    _write_index(local + incoming)
    out(f"✓ 已拉取 {len(incoming)} 条快照（共享共 {len(shared)} 条）")
    if incoming:
        authors = sorted({r["author"] for r in incoming})
        out("  作者: " + "、".join(authors))
        latest = incoming[-1]
        diffs = []
        for f, sha in latest.get("files", {}).items():
            if os.path.isfile(f) and _sha(f) != sha:
                diffs.append(f)
        if diffs:
            out("  ⚠ 注意: " + "、".join(diffs[:5]) +
                " 与拉到的最新快照不同（你本地也有新改动）——restore 前先 hist diff 对比，"
                "restore 本身会自动存安全快照，不会吞你的工作")
        out("  回滚: pybktl hist restore <id>")
    return 0


def cmd_claim(args):
    """登记「我正在改这些文件」（软锁，30 分钟自动过期）。"""
    import json
    import time as _t
    files = []
    for f in args.files:
        f = f.replace(os.sep, "/")
        if os.path.isfile(f) and f not in files:
            files.append(f)
    if not files:
        err("用法: pybktl hist claim 文件.pybk [更多文件…]")
        return 2
    os.makedirs(".pybook", exist_ok=True)
    p = os.path.join(".pybook", "编辑中.jsonl")
    with open(p, "a", encoding="utf-8") as f:
        f.write(json.dumps({"author": _author(), "ts": _t.time(), "files": files},
                           ensure_ascii=False) + "\\n")
    out(f"✓ 已登记（30 分钟有效）: {', '.join(files)} ｜ 作者 {_author()}")
    for h in _claim_conflicts(files):
        out(f"⚠ {h}")
    return 0


def cmd_claims(args):
    rows = _active_claims()
    if not rows:
        out("· 当前没有有效软锁（登记 30 分钟自动过期）")
        return 0
    import time as _t
    me = _author()
    out(f"有效软锁 {len(rows)} 条：")
    for r in rows:
        mins = int((_t.time() - r.get("ts", 0)) / 60)
        who = r.get("author") + ("（你）" if r.get("author") == me else "")
        out(f"  - {who}  {mins} 分钟前  {', '.join(r.get('files', []))}")
    return 0


def cmd_decide(args):
    """团队决策记录：一行一条，写进 决定.md（日期 + 作者 + 决定）。"""
    note = (args.note or "").strip()
    if not note:
        err('用法: pybktl hist decide "一句话决定（含原因更好）"')
        return 2
    p = os.path.join(_root(), "决定.md")
    line = f"- {datetime.date.today().isoformat()} {_author()}：{note}\\n"
    with open(p, "a", encoding="utf-8") as f:
        if not os.path.isfile(p) or os.path.getsize(p) == 0:
            f.write("# 团队决策记录\\n\\n")
        f.write(line)
    out(f"✓ 已记入 {p}: {line.strip()}")
    return 0
'''
t = t + NEW_CMDS

# ---------- ④ build_subparser：新子命令 ----------
old = """    hg = hsub.add_parser("gc", help="清理老快照")
    hg.add_argument("--keep", type=int, default=30, help="保留最近多少条（默认 30）")

    ph.set_defaults(func=_dispatch)"""
new = """    hg = hsub.add_parser("gc", help="清理老快照")
    hg.add_argument("--keep", type=int, default=30, help="保留最近多少条（默认 30）")

    hp = hsub.add_parser("push", help="推送本地新快照到共享历史目录（团队）")
    hp.add_argument("path", help="共享历史目录（共享盘/git 仓库均可）")

    hpl = hsub.add_parser("pull", help="从共享历史目录拉取新快照")
    hpl.add_argument("path", help="共享历史目录")

    hc = hsub.add_parser("claim", help="登记「我正在改这些文件」（软锁 30 分钟）")
    hc.add_argument("files", nargs="+", help="要登记的文件")

    hcs = hsub.add_parser("claims", help="查看当前有效软锁")

    hdj = hsub.add_parser("decide", help="团队决策记录（写一行进 决定.md）")
    hdj.add_argument("note", help="一句话决定（含原因更好）")

    ph.set_defaults(func=_dispatch)"""
assert old in t, 'subparser 锚点没找到'
t = t.replace(old, new, 1)

old = """    table = {"save": cmd_save, "log": cmd_log, "show": cmd_show,
             "diff": cmd_diff, "restore": cmd_restore, "undo": cmd_undo,
             "gc": cmd_gc}"""
new = """    table = {"save": cmd_save, "log": cmd_log, "show": cmd_show,
             "diff": cmd_diff, "restore": cmd_restore, "undo": cmd_undo,
             "gc": cmd_gc, "push": cmd_push, "pull": cmd_pull,
             "claim": cmd_claim, "claims": cmd_claims, "decide": cmd_decide}"""
assert old in t, 'dispatch 表锚点没找到'
t = t.replace(old, new, 1)

# ---------- ⑤ hist 免 pybk_main 依赖（团队项目里也能用）----------
old = """def _root():
    if not os.path.isfile("pybk_main.py"):
        err("✗ 请在 PYbook 仓库（或项目）根目录运行")
        raise SystemExit(1)
    return os.getcwd()"""
new = """def _root():
    return os.getcwd()"""
assert old in t, '_root 锚点没找到'
t = t.replace(old, new, 1)

wr(P, t)
print('hist 团队化加强全部写入')
