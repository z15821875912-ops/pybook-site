# -*- coding: utf-8 -*-
"""_fix_inc_count.py — .inc 表头那句「N 个库调用」早就过期了（写着 243，实际 331）。
按真实表项数改掉，免得下一个人又照着它手工递增。"""
import io
import re

p = '_vm_lib_calls.inc'
t = io.open(p, encoding='utf-8', newline='').read()
rows = len(re.findall(r'^\s*\{"', t, re.M))
m = re.search(r'\d+ 个库调用', t)
print('旧：%s   真实表项：%d' % (m.group(0), rows))
if int(re.search(r'\d+', m.group(0)).group(0)) != rows:
    t = t[:m.start()] + '%d 个库调用' % rows + t[m.end():]
    io.open(p, 'w', encoding='utf-8', newline='').write(t)
    print('已改为 %d 个库调用' % rows)
else:
    print('已一致，不动')
