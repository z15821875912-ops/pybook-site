/* _gpucheck.c —— pybook_gpu.c 的对拍 / 性能 harness
 *
 * 编译：gcc _gpucheck.c pybook_gpu.c -o _gpucheck.exe -O2
 * 只 stub 一个 rt_die，不把 pybook_rt.c 拉进来。
 *
 * 用法：
 *   _gpucheck.exe                 全尺寸对拍（16~2048 + 三组非方阵）
 *   _gpucheck.exe 3216 5          只跑 N=3216、重复 5 次（性能测量）
 *
 * 判据用**分量后向误差** |算错-精确| / Σ|a_k·b_k|，不是相对误差：
 * 输出元素接近 0 时相对误差会无意义地爆掉（float32 矩阵乘必然有接近 0 的元素）。
 * float32 单次舍入 2^-24≈6e-8，K 项顺序累加的最坏界约 sqrt(K)*6e-8*Σ，
 * 所以阈值取 1e-5 足够宽松，实测真值在 2.4e-7。
 */
#include <windows.h>
#include "pybook_gpu.h"
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <stdarg.h>

void rt_die(const char *fmt, ...)
{
    va_list ap;
    va_start(ap, fmt);
    printf("[rt_die] ");
    vprintf(fmt, ap);
    printf("\n");
    va_end(ap);
    exit(3);
}

static double now(void)
{
    LARGE_INTEGER f, c;
    QueryPerformanceFrequency(&f);
    QueryPerformanceCounter(&c);
    return (double)c.QuadPart / (double)f.QuadPart;
}

static unsigned s = 12345u;
static double frand(void)
{
    s = s * 1103515245u + 12345u;
    return (double)((s >> 9) & 0xFFFF) / 65536.0 - 0.5;
}

static int run(int M, int N, int K)
{
    size_t  ka = (size_t)M * K, kb = (size_t)K * N, kc = (size_t)M * N;
    double *A = malloc(ka * sizeof(double));
    double *B = malloc(kb * sizeof(double));
    double *R = malloc(kc * sizeof(double));
    double  t0, t1, gflop, e0 = 0, e1 = 0;
    size_t  i, step, checked = 0;
    int     bad = 0, r, q, p;

    for (i = 0; i < ka; i++) A[i] = (double)(float)frand();
    for (i = 0; i < kb; i++) B[i] = (double)(float)frand();

    t0 = now();
    if (!gpu_sgemm_f32(A, B, R, M, N, K)) {
        printf("%4dx%-4dx%-4d  失败：%s\n", M, N, K, gpu_last_error());
        free(A); free(B); free(R);
        return 0;
    }
    t1 = now();
    gflop = 2.0 * (double)M * (double)N * (double)K / (t1 - t0) / 1e9;

    /* 只在抽样点上算参考，大矩阵别让参考实现自己变成瓶颈 */
    step = kc > 65536 ? kc / 65536 : 1;
    for (i = 0; i < kc; i += step) {
        double acc = 0.0, mag = 0.0;
        r = (int)(i / (size_t)N);
        q = (int)(i % (size_t)N);
        for (p = 0; p < K; p++) {
            double a = (double)(float)A[(size_t)r * K + p];
            double b = (double)(float)B[(size_t)p * N + q];
            acc += a * b;
            mag += fabs(a * b);
        }
        {
            double d   = fabs(R[i] - acc);
            double rel = mag > 0 ? d / mag : d;
            if (rel > e0) e0 = rel;
            if (d > e1) e1 = d;
            if (rel > 1e-5) bad++;
        }
        checked++;
    }
    printf("%4dx%-4dx%-4d  %8.1f GFLOPS  后向误差 %.3e  绝对偏差 %.3e  抽 %lu 项  %s\n",
           M, N, K, gflop, e0, e1, (unsigned long)checked, bad ? "★有错★" : "OK");
    free(A); free(B); free(R);
    return bad == 0;
}

/* 地址探针：A 取单位阵、B[i]=i+1。C[r][c] 应正好等于 B[r][c] = r*16+c+1。
 * 对拍一旦报错，先跑这个：它能一眼分清「寻址错了」还是「算错了」，
 * 比读 kernel 源码快得多。（当初那轮「全尺寸误差 1e4」就是靠它定位到
 * 真正的问题在参考实现身上，不在 GPU。） */
static void probe_addr(void)
{
    double A[256], B[256], R[256];
    int r, c;
    for (r = 0; r < 16; r++)
        for (c = 0; c < 16; c++)
            A[r * 16 + c] = (r == c) ? 1.0 : 0.0;
    for (r = 0; r < 256; r++)
        B[r] = (double)(r + 1);
    if (!gpu_sgemm_f32(A, B, R, 16, 16, 16)) {
        printf("地址探针失败：%s\n", gpu_last_error());
        return;
    }
    printf("地址探针（每格应等于 行*16+列+1）：\n");
    for (r = 0; r < 4; r++) {
        printf("  行%d 实际: ", r);
        for (c = 0; c < 16; c++) printf("%5.0f ", R[r * 16 + c]);
        printf("\n  行%d 应为: ", r);
        for (c = 0; c < 16; c++) printf("%5.0f ", (double)(r * 16 + c + 1));
        printf("\n");
    }
}

int main(int argc, char **argv)
{
    int sizes[] = {16, 32, 64, 128, 256, 512, 1024, 2048};
    int i, ok = 1;

    if (!gpu_probe()) {
        printf("探测失败：%s\n", gpu_device_name());
        return 1;
    }
    printf("设备：%s   驱动版本：%d\n\n", gpu_device_name(), gpu_driver_version());

    if (argc > 1) {                 /* 只跑指定尺寸（性能测量用） */
        int n = atoi(argv[1]);
        int rep = argc > 2 ? atoi(argv[2]) : 1;
        printf("只测 N=%d，重复 %d 次\n\n", n, rep);
        for (i = 0; i < rep; i++)
            if (!run(n, n, n))
                ok = 0;
        printf("\n%s\n", ok ? "全部通过" : "★有失败★");
        return ok ? 0 : 1;
    }

    probe_addr();
    printf("\n");
    for (i = 0; i < (int)(sizeof(sizes) / sizeof(sizes[0])); i++)
        if (!run(sizes[i], sizes[i], sizes[i]))
            ok = 0;
    /* 非方阵也过一遍，确认行列映射没搞反 */
    if (!run(64, 128, 256)) ok = 0;
    if (!run(256, 64, 128)) ok = 0;
    if (!run(128, 512, 64)) ok = 0;
    printf("\n%s\n", ok ? "全部通过" : "★有失败★");
    return ok ? 0 : 1;
}
