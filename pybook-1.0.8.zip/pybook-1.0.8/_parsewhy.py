# -*- coding: utf-8 -*-
"""直接调 pybk_front.parse 看真实异常 —— 绕开 pybk_main 的错误包装。

背景：写 UI 体检件时报「第 N 行：文件必须包含恰好一个 GOING 块」，而 N 与
GOING 的真实行号对不上（最小复现里差 3 行），说明报的不是 GOING 本身的位置。
与其猜，不如把 parse 的原始异常打出来。
"""
import sys
import traceback

sys.path.insert(0, '.')

from pybk_front import parse   # noqa: E402

path = sys.argv[1] if len(sys.argv) > 1 else '_UI最小.pybk'
with open(path, encoding='utf-8') as f:
    src = f.read()

print('=== %s  共 %d 行 ===' % (path, src.count('\n') + 1))
try:
    prog = parse(src)
    print('parse OK   window_open =', getattr(prog, 'window_open', 0))
    print('go_body 语句数 =', len(prog.go_body))
    for i, s in enumerate(prog.go_body):
        print('  [%d] %s' % (i, type(s).__name__))
except Exception as e:
    print('parse 抛异常：', type(e).__name__)
    print(str(e))
    print('--- traceback ---')
    traceback.print_exc(limit=8)
