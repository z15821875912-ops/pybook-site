# -*- coding: utf-8 -*-
"""_cropzoom.py —— 从截图里裁一块并放大 N 倍（专治"放大才知道毛刺"）

像素级细节（圆角过渡带、1px 描边、对勾的斜边）在整图缩略图上根本看不出来，
说"已经抗锯齿了"只能靠嘴。这里裁一块用最近邻放大，肉眼直接验。

  python -B _cropzoom.py shots_look/ui_001.bmp 36 140 120 40 6
  python -B _cropzoom.py shots_look/ui_001.bmp 36 140 120 40 6 out_zoom.png
"""
import os
import sys

from PIL import Image


def main():
    args = sys.argv[1:]
    if len(args) < 5:
        raise SystemExit(__doc__)
    src = args[0]
    x, y, w, h, k = (int(v) for v in args[1:6])
    dst = args[6] if len(args) > 6 else os.path.splitext(src)[0] + '_zoom.png'
    im = Image.open(src).crop((x, y, x + w, y + h))
    # 最近邻：放大就是为了看"每个像素本身长什么样"，插值会把毛刺糊掉
    im = im.resize((w * k, h * k), Image.NEAREST)
    im.save(dst)
    print("%s  裁 (%d,%d,%d,%d) 放大 %dx -> %s  %dx%d" %
          (src, x, y, w, h, k, dst, w * k, h * k))


if __name__ == '__main__':
    main()
