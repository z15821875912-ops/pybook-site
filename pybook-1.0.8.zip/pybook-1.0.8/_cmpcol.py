# -*- coding: utf-8 -*-
"""两张同尺寸 BMP 的列区间比对，附带抽样像素对，用来判断差异是"设计如此"还是 bug。

用法: python -B _cmpcol.py <bmp_a> <bmp_b> x0 x1
"""
import sys, struct


def load(path):
    d = open(path, 'rb').read()
    off = struct.unpack_from('<I', d, 10)[0]
    w, h = struct.unpack_from('<ii', d, 18)
    flip = h > 0
    h = abs(h)
    bpp = struct.unpack_from('<H', d, 28)[0] // 8
    stride = ((w * bpp + 3) // 4) * 4
    return w, h, stride, off, d, flip


def main():
    pa, pb = sys.argv[1], sys.argv[2]
    x0 = int(sys.argv[3]) if len(sys.argv) > 3 else 0
    x1 = int(sys.argv[4]) if len(sys.argv) > 4 else 10 ** 9
    y0 = int(sys.argv[5]) if len(sys.argv) > 5 else 0
    y1 = int(sys.argv[6]) if len(sys.argv) > 6 else 10 ** 9
    wa, ha, sa, oa, da, fa = load(pa)
    wb, hb, sb, ob, db, fb = load(pb)
    assert (wa, ha) == (wb, hb), f'尺寸不同 {wa}x{ha} vs {wb}x{hb}'
    x1 = min(x1, wa)
    y1 = min(y1, ha)

    def px(d, off, stride, row, x):
        i = off + row * stride + x * 3
        return (d[i + 2], d[i + 1], d[i])

    def A(x, y):
        return px(da, oa, sa, (ha - 1 - y) if fa else y, x)

    def B(x, y):
        return px(db, ob, sb, (hb - 1 - y) if fb else y, x)

    same = tot = 0
    bad_rows = []
    maxdelta = 0
    over14 = 0
    worst_at = None
    for y in range(y0, y1):
        nbad = 0
        for x in range(x0, x1):
            a = A(x, y)
            b = B(x, y)
            if a == b:
                same += 1
            else:
                nbad += 1
                d = max(abs(a[0] - b[0]), abs(a[1] - b[1]), abs(a[2] - b[2]))
                if d > maxdelta:
                    maxdelta = d
                    worst_at = (x, y, a, b)
                if d > 14:
                    over14 += 1
        tot += x1 - x0
        if nbad:
            bad_rows.append((y, nbad))
    print(f'比对区 x in [{x0},{x1}) y in [{y0},{y1})  共 {tot} 像素')
    print(f'逐位相同 {same} ({100.0*same/tot:.2f}%)   不同 {tot-same} ({100.0*(tot-same)/tot:.2f}%)')
    print(f'最大通道差 {maxdelta}   差值>14 的像素 {over14} 个'
          + (f'   最差点 ({worst_at[0]},{worst_at[1]}) A=#{worst_at[2][0]:02X}{worst_at[2][1]:02X}{worst_at[2][2]:02X} '
             f'B=#{worst_at[3][0]:02X}{worst_at[3][1]:02X}{worst_at[3][2]:02X}' if worst_at else ''))
    if bad_rows:
        segs = []
        for y, n in bad_rows:
            if segs and segs[-1][1] == y - 1:
                segs[-1][1] = y; segs[-1][2] += n
            else:
                segs.append([y, y, n])
        print(f'差异行段 {len(segs)} 段:')
        for s in segs[:30]:
            print(f'  y {s[0]}..{s[1]}  不同像素 {s[2]}')
    else:
        print('[OK] 整块逐位相同')

    print('\n抽样像素对 (A=3D+UI, B=纯2D):')
    for y in (2, 8, 16, 40, 100, 200, 300, 430, 470, 500, 540):
        for x in (521, 536, 545, 560, 700, 860, 875, 879):
            a, b = A(x, y), B(x, y)
            mark = '  ' if a == b else '≠ '
            print(f'  ({x:3d},{y:3d}) {mark} A=#{a[0]:02X}{a[1]:02X}{a[2]:02X}  B=#{b[0]:02X}{b[1]:02X}{b[2]:02X}')


main()
