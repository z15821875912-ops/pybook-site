/* _gppeak.c — 测这张卡真正的 FP32 极限速度。
 *
 * 为什么旧的内核测出来的数是假的（本文件是重做，不是重复）：
 *   旧 _ptx_FMAPEAK.ptx 的 8 条 FMA 链长得一模一样，累加器还都从 0 起。
 *   编译器可证明 fma(a,b,0)=0，于是 8 条塌成 1 条，按 8 条算吞吐虚高 8 倍。
 *   改掉之后又踩了两个坑：等差数列被化简成 acc = n*常数（循环体里一条 FMA 都不留），
 *   以及想动态索引就得展开 64 次、代价过大。本文件的新内核三条全堵死，详见
 *   _mkfmareal.py 的 D1~D4。
 *
 * 最重要的一条纪律：**先证明活儿真干了，再让出任何数字。**
 *   第一步是正确性闸门：宿主用 fmaf() 按完全相同的顺序重放同一条 FMA 序列，
 *   逐位比对。只要 ptxas 少算一条、多算一条、或者换了顺序，结果必然对不上，
 *   程序直接 exit(1)，一个吞吐数字都不打印。
 *   这正是本会话吃过两次亏之后立的规矩：不报没验过「活是否真干」的数字。
 *
 * 第二条纪律：**理论上限的分母要用实测时钟，不能用驱动报告值。**
 *   之前按 CU_DEVICE_ATTRIBUTE_CLOCK_RATE 拿到的 1.708 GHz 去算上限，
 *   而 nvidia-smi 显示当前 1506、最大 1911 MHz —— 三个数互不相等。
 *   所以本工具会配合 nvidia-smi 在持续负载期间采样真实频率（--hold 秒）。
 *
 * ===================== 2026-10-17 实测结论（别再重犯） =====================
 *
 * 1) 闸门：10240 个结果逐位全中，最大相对误差 0.000e+00。
 *    这是本会话第一次拿到「能自证活儿真干了」的算力数字。
 *    在此之前报过的 3.44~4.27 TFLOPS 和 13.8 TB/s 全部作废。
 *
 * 2) 纯 FMA 极限 = 4.07~4.38 TFLOPS（扫描/持续/交替三处测得的区间）。
 *
 * 3) 持续负载期间实测 SM 时钟 **1847 MHz**（1822~1860，功耗 99W/120W，
 *    温度 71~75°C，都没碰到功耗墙或温度墙）。驱动报的 1.708 GHz 是错的。
 *
 * 4) **CC 6.1 是每 SM 128 个 FP32 单元，不是 64。**
 *    仲裁：按 64 算上限只有 2.36 TFLOPS，实测 4.07 是它的 172%，物理上不可能；
 *    按 128 算上限 4.73 TFLOPS，实测占 86%。64 是 P100(GP100) 的数。
 *
 * 5) 生产 sgemm_8x8 @N=3216 = 2.59 TFLOPS，**只到纯 FMA 极限的 59.8%**
 *    （另一轮 64.5%，所以这个比例带 5 个点的不确定度）。
 *    此前代码注释里写的「45%」是拿作废的 fma_peak 当分母算的，已更正。
 *
 * 6) 缺口的真凶查到了，是 occupancy：驱动报告 sgemm_8x8 **每线程 128 个寄存器**
 *    -> 每 SM 只驻留 2 块 = 16 warp，而满载是 48 warp。共享内存只有 8192 字节/块，
 *    根本不是约束（能放 8 块）；**寄存器才是**。8x8 的 64 个累加器注定压不住。
 *
 * 7) 附带证伪：预取版和冻结原版**都是 128 寄存器、都是每 SM 2 块**。
 *    所以那 22% 提速不是拿 occupancy 换的 —— 「预取掉到 2 块」的猜想作废，
 *    它本来就是 2 块。
 *
 * 8) 还有一处可算的浪费：N=3216 时 tile 128 的 grid 要 26x26=676 块，
 *    实际算的是 3328 见方，等于每条 FMA 有 7.05% 花在填充上。
 *    N=2048 / 4096 是 128 的整数倍，就没有这项损失（实测确实高 5~6 个点）。
 *
 * 8) CPU 侧用同一套反作弊设计测（AVX2 向量内核 vs 标量 fmaf 参考，64/64
 *    逐位相同）：CPU 极限 = 0.31~0.37 TFLOPS。超线程对 FMA 只有 0~5% 收益。
 *    同轮交替 GPU/CPU = 10~13 倍。这个倍数只给方向性依据，替代不了逐尺寸
 *    实测切点，路由阈值仍然用原来那套直接对拍定出来的数。
 *
 * 9) 测量方差：同一个二进制同一张卡，四轮 GPU 纯 FMA 绝对值在
 *    2.89~4.38 TFLOPS 之间抖（±30%），机器上有别的后台程序在跑。
 *    绝对值只能当量级用。**只信同轮交替的比值。**
 *
 * 10) 踩到一个真编译器坑，详见 host_replay 的注释：GCC 把这条 2048 步长的
 *     fma 链内联进 main 之后会静默改数值语义。参考侧必须 volatile + noinline。
 *     闸门当时咬的是参考实现，不是 GPU —— 这正是这道闸门存在的意义。
 *
 * 编译：
 *   C:\Users\zhuli\mingw64\bin\x86_64-w64-mingw32-gcc.exe _gppeak.c -o _gppeak.exe -O2 -lm
 * 用法：
 *   _gppeak.exe [保持负载秒数]
 *
 * 配套采样（另开窗口）：
 *   nvidia-smi --query-gpu=clocks.sm,power.draw,temperature.gpu --format=csv,noheader,nounits
 */
#include <windows.h>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <immintrin.h>
#include "_fmareal_const.h"

/* CPU 侧的「极限速度」用与 GPU 完全相同的反作弊设计：
 *   - 初值从数组载入（编译器编译期不知道初值，堵死整条链折叠成常量）
 *   - K[s][c] 两两互异（堵死链合并 / 等差数列化简）
 *   - 内核走 AVX2 向量路径，闸门用标量 fmaf() 重放，两条不同代码路径互相证伪
 * 这样 GPU 和 CPU 的数字才是同一把尺子量出来的。
 */
#define CPU_ACC   8                 /* 8 个 ymm 累加器 */
#define CPU_LANES (CPU_ACC * 8)     /* 64 条独立链 */

static void cpu_fma_v(const float *init, float *out, unsigned iters)
{
    __m256 a[CPU_ACC];
    int c;
    unsigned it;
    int s;
    for (c = 0; c < CPU_ACC; c++) a[c] = _mm256_loadu_ps(init + c * 8);
    for (it = 0; it < iters; it++)
        for (s = 0; s < FM_S; s++)
            for (c = 0; c < CPU_ACC; c++)
                a[c] = _mm256_fmadd_ps(a[c], _mm256_set1_ps(FMK[s][c]),
                                       _mm256_set1_ps(FMB[c]));
    for (c = 0; c < CPU_ACC; c++) _mm256_storeu_ps(out + c * 8, a[c]);
}

/* 标量参考：与 cpu_fma_v 意图相同、实现完全不同的另一条路径。
 * 两边必须逐位相同，否则说明向量内核被编译器折叠了。 */
static void cpu_fma_ref(const float *init, float *out, unsigned iters)
{
    float acc[CPU_LANES];
    int L;
    unsigned it;
    int s;
    for (L = 0; L < CPU_LANES; L++) acc[L] = init[L];
    for (it = 0; it < iters; it++)
        for (s = 0; s < FM_S; s++)
            for (L = 0; L < CPU_LANES; L++)
                acc[L] = fmaf(acc[L], FMK[s][L / 8], FMB[L / 8]);
    for (L = 0; L < CPU_LANES; L++) out[L] = acc[L];
}

typedef struct { const float *init; float *out; unsigned iters; } cpu_arg;

static DWORD WINAPI cpu_thread(LPVOID p)
{
    cpu_arg *a = (cpu_arg *)p;
    cpu_fma_v(a->init, a->out, a->iters);
    return 0;
}

/* 起 n 个线程跑 cpu_fma_v，各自写自己的 64 个输出。
 * 计时区间内包含建线程开销，所以下面把单次做得很长（几十毫秒），
 * 0.1 ms 的开销可以忽略。 */
static double cpu_run(int nthreads, const float *init, float *out,
                      unsigned iters)
{
    HANDLE th[64];
    cpu_arg arg[64];
    LARGE_INTEGER qpf, t0, t1;
    int i;
    double ms;

    if (nthreads > 64) nthreads = 64;
    QueryPerformanceFrequency(&qpf);
    QueryPerformanceCounter(&t0);
    for (i = 0; i < nthreads; i++) {
        arg[i].init = init;
        arg[i].out = out + (size_t)i * CPU_LANES;
        arg[i].iters = iters;
        th[i] = CreateThread(NULL, 0, cpu_thread, &arg[i], 0, NULL);
    }
    for (i = 0; i < nthreads; i++) {
        WaitForSingleObject(th[i], INFINITE);
        CloseHandle(th[i]);
    }
    QueryPerformanceCounter(&t1);
    ms = (double)(t1.QuadPart - t0.QuadPart) / (double)qpf.QuadPart * 1000.0;
    return ms;
}

typedef int          CUresult;
typedef int          CUdevice;
typedef void        *CUcontext;
typedef void        *CUmodule;
typedef void        *CUfunction;
typedef void        *CUstream;
typedef unsigned long long CUdeviceptr;

#define CU_EVENT_DEFAULT 0

/* 驱动属性编号。与 CUDA Runtime 的 cudaDeviceAttr 对齐。 */
#define A_CLOCK_RATE_KHZ     13
#define A_SM_COUNT           16
#define A_MEM_CLOCK_KHZ      36
#define A_BUS_WIDTH_BITS     37
#define A_L2_BYTES           38
#define A_MAXTHREADS_SM      39
#define A_MAXREGS_SM         40
#define A_CC_MAJOR           75
#define A_CC_MINOR           76
#define A_SMEM_PER_SM        81
#define A_MAXBLOCKS_SM      106

static HMODULE g_dll;
static CUresult (*p_cuInit)(unsigned);
static CUresult (*p_cuDriverGetVersion)(int *);
static CUresult (*p_cuDeviceGet)(CUdevice *, int);
static CUresult (*p_cuDeviceGetName)(char *, int, CUdevice);
static CUresult (*p_cuDeviceGetAttribute)(int *, int, CUdevice);
static CUresult (*p_cuDevicePrimaryCtxRetain)(CUcontext *, CUdevice);
static CUresult (*p_cuCtxSetCurrent)(CUcontext);
static CUresult (*p_cuCtxSynchronize)(void);
static CUresult (*p_cuModuleLoadData)(CUmodule *, const void *);
static CUresult (*p_cuModuleGetFunction)(CUfunction *, CUmodule *, const char *);
static CUresult (*p_cuMemAlloc_v2)(CUdeviceptr *, size_t);
static CUresult (*p_cuMemFree_v2)(CUdeviceptr);
static CUresult (*p_cuMemcpyHtoD_v2)(CUdeviceptr, const void *, size_t);
static CUresult (*p_cuMemcpyDtoH_v2)(void *, CUdeviceptr, size_t);
static CUresult (*p_cuLaunchKernel)(CUfunction, unsigned, unsigned, unsigned,
                                    unsigned, unsigned, unsigned,
                                    unsigned, CUstream, void **, void **);
static CUresult (*p_cuGetErrorString)(CUresult, const char **);
static CUresult (*p_cuEventCreate)(void **, unsigned);
static CUresult (*p_cuEventRecord)(void *, CUstream);
static CUresult (*p_cuEventSynchronize)(void *);
static CUresult (*p_cuEventElapsedTime)(float *, void *, void *);
static CUresult (*p_cuFuncGetAttribute)(int *, int, CUfunction);
static CUresult (*p_cuOccupancyMaxActiveBlocksPerMultiprocessor)(int *, CUfunction,
                                                                 int, int);

/* CUfunction_attribute 编号 */
#define FA_MAX_THREADS_PER_BLOCK 0
#define FA_SHARED_SIZE_BYTES     1
#define FA_NUM_REGS              4

static CUcontext g_ctx;
static char g_err[256];
static char g_ptx[262144];

static const char *cu_err(CUresult r)
{
    const char *s = NULL;
    if (p_cuGetErrorString && p_cuGetErrorString(r, &s) == 0 && s) return s;
    return "未知 CUDA 错误";
}

/* 每一步都要检查返回值：cuEventElapsedTime 失败时 el 保持上一次的值，
 * 而这不是我第一版代码干过的事——当时没检查，9 次取中位数就得到 3357 TFLOPS。 */
#define CK(expr, what) do {                                   \
        CUresult _r = (expr);                                \
        if (_r != 0) {                                       \
            printf("[错误] %s -> %s\n", (what), cu_err(_r));  \
            return 1;                                        \
        }                                                    \
    } while (0)

static int load_ptx(const char *path)
{
    FILE *f = fopen(path, "rb");
    size_t n;
    if (!f) { snprintf(g_err, sizeof g_err, "打不开 %s", path); return 0; }
    n = fread(g_ptx, 1, sizeof(g_ptx) - 1, f);
    fclose(f);
    g_ptx[n] = '\0';
    if (n < 100) { snprintf(g_err, sizeof g_err, "%s 太短（%zu 字节）", path, n); return 0; }
    return 1;
}

static int cmp_dbl(const void *a, const void *b)
{
    double x = *(const double *)a, y = *(const double *)b;
    return (x > y) - (x < y);
}

/* 宿主重放：与 PTX 里 fma.rn.f32 acc, acc, K, B 的顺序完全一致。
 *
 * ============ 这里踩过的坑，别再改回去 ============
 *
 * 这个函数的第一版既没有 volatile 也没有 noinline。GCC 把它内联进 main 之后，
 * 静默算出了另一个数：参考值 14.74259，而正确值是 15.8535948 —— 10240 个结果
 * 全红，误差最大 23%。把同一个函数原封不动挪出去编成独立函数（非内联），
 * 结果立刻回到 15.8535948，与 GPU 输出逐位相同。
 *
 * 也就是说：同源码、同常量、同编译选项，仅仅因为「有没有被内联」，结果就不同。
 * 编译器在这条 2048 步长的 fma 链上动了语义。
 *
 * 修法两条都要：
 *   volatile  钉死每一次读写的语义，编译器不能再对浮点表达式做任何变换
 *   noinline  不让它被拆散重排
 * 闸门只跑 64 轮，慢一点完全无所谓，可信度才是第一位。
 * =====================================================
 *
 * 另外加了黄金值：ref[0] 在正确实现下恒为 15.8535948（常量表由固定种子生成，
 * 所以这个值是可复现的）。闸门失败时先看这一行，就知道该怪宿主还是怪 GPU。
 */
#define FM_GOLDEN0 15.8535948

__attribute__((noinline))
static void host_replay(float *out, unsigned iters)
{
    volatile float *acc = out;
    unsigned it, s;
    int c;
    for (it = 0; it < iters; it++)
        for (s = 0; s < FM_S; s++)
            for (c = 0; c < FM_NC; c++)
                acc[c] = fmaf(acc[c], FMK[s][c], FMB[c]);
}

int main(int argc, char **argv)
{
    void *p;
    CUdevice dev;
    CUmodule mF = NULL;
    CUfunction fF = NULL;
    CUresult r;
    int maj = 0, min = 0, nsm = 0, attr;
    int clock_khz = 0, mem_khz = 0, busw = 0, maxblk = 0, maxregs = 0;
    double hold_sec = (argc > 1) ? atof(argv[1]) : 0.0;
    void *ev0 = NULL, *ev1 = NULL;
    CUdeviceptr dInit = 0, dOut = 0;
    float el;
    int i, rep;
    unsigned maxbps = 32;
    unsigned MAXTHREADS;
    size_t outbytes;
    float *hOut, *hInit;
    double best_tf = 0.0;
    int best_bps = 0;
    double g_sgemm_tf = 0.0;   /* 同轮交替测出的 sgemm_8x8 吞吐 */
    double g_fma_tf = 0.0;     /* 同轮交替测出的 FMA 吞吐（报告用它，比扫描更可信） */
    double g_sust_tf = 0.0;    /* 持续负载下的 FMA 吞吐 */
    double g_cpu_tf = 0.0;     /* CPU 纯 FMA 极限 */
    double g_alt_ratio = 0.0;  /* 同轮交替测出的 GPU/CPU 倍数 */
    unsigned ITERS = 4096;

    SetConsoleOutputCP(65001);

    g_dll = LoadLibraryA("nvcuda.dll");
    if (!g_dll) { printf("找不到 nvcuda.dll\n"); return 1; }
#define LOAD(n, f) do { p = (void *)GetProcAddress(g_dll, n); \
    if (!p) { printf("缺 %s\n", n); return 1; } memcpy(&(f), &p, sizeof(f)); } while (0)
    LOAD("cuInit", p_cuInit);
    LOAD("cuDriverGetVersion", p_cuDriverGetVersion);
    LOAD("cuDeviceGet", p_cuDeviceGet);
    LOAD("cuDeviceGetName", p_cuDeviceGetName);
    LOAD("cuDeviceGetAttribute", p_cuDeviceGetAttribute);
    LOAD("cuDevicePrimaryCtxRetain", p_cuDevicePrimaryCtxRetain);
    LOAD("cuCtxSetCurrent", p_cuCtxSetCurrent);
    LOAD("cuCtxSynchronize", p_cuCtxSynchronize);
    LOAD("cuModuleLoadData", p_cuModuleLoadData);
    LOAD("cuModuleGetFunction", p_cuModuleGetFunction);
    LOAD("cuMemFree_v2", p_cuMemFree_v2);
    LOAD("cuMemcpyHtoD_v2", p_cuMemcpyHtoD_v2);
    LOAD("cuMemcpyDtoH_v2", p_cuMemcpyDtoH_v2);
    LOAD("cuLaunchKernel", p_cuLaunchKernel);
    LOAD("cuGetErrorString", p_cuGetErrorString);
    LOAD("cuEventCreate", p_cuEventCreate);
    LOAD("cuEventRecord", p_cuEventRecord);
    LOAD("cuEventSynchronize", p_cuEventSynchronize);
    LOAD("cuEventElapsedTime", p_cuEventElapsedTime);
    p = (void *)GetProcAddress(g_dll, "cuFuncGetAttribute");
    memcpy(&p_cuFuncGetAttribute, &p, sizeof(p));
    p = (void *)GetProcAddress(g_dll, "cuOccupancyMaxActiveBlocksPerMultiprocessor");
    memcpy(&p_cuOccupancyMaxActiveBlocksPerMultiprocessor, &p, sizeof(p));
    p = (void *)GetProcAddress(g_dll, "cuMemAlloc_v2");
    memcpy(&p_cuMemAlloc_v2, &p, sizeof(p));
#undef LOAD
    if (!p_cuMemAlloc_v2) { printf("缺 cuMemAlloc_v2\n"); return 1; }

    CK(p_cuInit(0), "cuInit");
    CK(p_cuDeviceGet(&dev, 0), "取设备");
    p_cuDeviceGetName(g_err, 64, dev);
    p_cuDeviceGetAttribute(&maj, A_CC_MAJOR, dev);
    p_cuDeviceGetAttribute(&min, A_CC_MINOR, dev);
    p_cuDeviceGetAttribute(&nsm, A_SM_COUNT, dev);
    p_cuDeviceGetAttribute(&clock_khz, A_CLOCK_RATE_KHZ, dev);
    p_cuDeviceGetAttribute(&mem_khz, A_MEM_CLOCK_KHZ, dev);
    p_cuDeviceGetAttribute(&busw, A_BUS_WIDTH_BITS, dev);
    p_cuDeviceGetAttribute(&maxblk, A_MAXBLOCKS_SM, dev);
    p_cuDeviceGetAttribute(&maxregs, A_MAXREGS_SM, dev);
    CK(p_cuDevicePrimaryCtxRetain(&g_ctx, dev), "拿 context");
    CK(p_cuCtxSetCurrent(g_ctx), "设 context");

    printf("================ 这张卡到底是什么 ================\n");
    printf("  名称            %s\n", g_err);
    printf("  计算能力        sm_%d%d\n", maj, min);
    printf("  SM 数           %d\n", nsm);
    printf("  每 SM 最多块数  %d   (驱动属性；CC 6.1 手册值为 24)\n", maxblk);
    printf("  显存位宽        %d bit\n", busw);
    printf("  显存频率        %.0f MHz\n", mem_khz / 1000.0);
    printf("  驱动报 SM 频率  %.0f MHz   <-- 注意这不是实测运行频率\n",
           clock_khz / 1000.0);
    printf("  理论显存带宽    %.1f GB/s  (%.0fMHz x %dbit x 2 [DDR] / 8)\n",
           (double)mem_khz * 1000.0 * 2.0 * busw / 8.0 / 1e9, mem_khz / 1000.0, busw);

    if (maj != 6 || min != 1) {
        printf("[错误] 这个工具按 CC 6.1 的假设写的（每 SM FP32 单元数存疑），"
               "当前是 sm_%d%d，结论不适用\n", maj, min);
        return 1;
    }

    MAXTHREADS = (unsigned)nsm * maxbps * 32u;
    if (MAXTHREADS > (unsigned)nsm * (unsigned)maxblk * 32u)
        MAXTHREADS = (unsigned)nsm * (unsigned)maxblk * 32u;
    outbytes = (size_t)MAXTHREADS * FM_NC * sizeof(float);

    if (!load_ptx("_ptx_FMAREAL.ptx")) { printf("%s\n", g_err); return 1; }
    r = p_cuModuleLoadData(&mF, g_ptx);
    if (r != 0) { printf("FMAREAL PTX 被拒：%s\n", cu_err(r)); return 1; }
    if (p_cuModuleGetFunction(&fF, mF, "fma_pk") != 0) { printf("取不到 fma_pk\n"); return 1; }

    hOut = (float *)malloc(outbytes);
    hInit = (float *)malloc(FM_NC * sizeof(float));
    if (!hOut || !hInit) { printf("host 内存不足\n"); return 1; }
    /* 初值取可精确表示的二进制小数，保证 HtoD 前后位模式一致 */
    for (i = 0; i < FM_NC; i++) hInit[i] = 0.5f + (float)i * 0.03125f;

    CK(p_cuMemAlloc_v2(&dInit, FM_NC * sizeof(float)), "分配初值");
    CK(p_cuMemAlloc_v2(&dOut, outbytes), "分配输出");
    CK(p_cuMemcpyHtoD_v2(dInit, hInit, FM_NC * sizeof(float)), "初值上显存");
    p_cuEventCreate(&ev0, CU_EVENT_DEFAULT);
    p_cuEventCreate(&ev1, CU_EVENT_DEFAULT);

    /* ================= 第一步：正确性闸门 =================
     *
     * 不过这一关，后面一个吞吐数字都不许打印。
     * 验证内容：把输出搬回主机，与 fmaf() 重放的结果逐位比对。
     * 只比一个线程不够——万一是某个块没跑，那个块的值会是显存里的旧垃圾。
     * 所以每一个线程的每一个结果都查，并且额外确认所有线程互相一致。
     */
    printf("\n================ 第一步：正确性闸门 ================\n");
    {
        const unsigned gx = 20, bx = 32;
        const unsigned nthr = gx * bx;
        const unsigned iters = 64;
        float ref[FM_NC];
        void *args[3];
        unsigned int_it = iters;
        int c, worst_i = -1, mism = 0, exact = 0;
        double worst = 0.0;

        memcpy(ref, hInit, sizeof ref);
        host_replay(ref, iters);
        /* 立刻打一次。如果这里是 15.8535948、跑完 GPU 之后变成 14.74259，
         * 那就不是算错，是栈上的 ref 被别的东西踩了 —— 两种病因的修法完全不同。 */
        printf("  [诊断] 黄金值 %.9g  本次参考 %.9g  %s\n",
               (double)FM_GOLDEN0, (double)ref[0],
               (fabs((double)ref[0] - (double)FM_GOLDEN0) < 1e-6)
                   ? "一致（宿主参考可信）" : "**不一致：问题在宿主参考，不在 GPU**");

        args[0] = &dInit; args[1] = &dOut; args[2] = &int_it;
        CK(p_cuLaunchKernel(fF, gx, 1, 1, bx, 1, 1, 0, NULL, args, NULL), "闸门内核");
        CK(p_cuCtxSynchronize(), "闸门同步");
        memset(hOut, 0, outbytes);
        CK(p_cuMemcpyDtoH_v2(hOut, dOut, (size_t)nthr * FM_NC * sizeof(float)),
           "读回结果");

        for (i = 0; i < (int)nthr; i++) {
            for (c = 0; c < FM_NC; c++) {
                float got = hOut[(size_t)i * FM_NC + c];
                float exp = ref[c];
                double d = fabs((double)got - (double)exp);
                double sc = fabs((double)exp); if (sc < 1.0) sc = 1.0;
                if (memcmp(&got, &exp, sizeof(float)) == 0) exact++;
                else {
                    mism++;
                    if (d / sc > worst) { worst = d / sc; worst_i = i * FM_NC + c; }
                }
                if (!(got == got)) {   /* NaN 检查 */
                    printf("[错误] 第 %d 个线程第 %d 项是 NaN\n", i, c);
                    return 1;
                }
            }
        }
        printf("  线程数 %u × %d 项 = %u 个结果\n", nthr, FM_NC, nthr * FM_NC);
        printf("  逐位完全相同   %d 个\n", exact);
        printf("  最大相对误差   %.3e", worst);
        if (worst_i >= 0) printf("   (第 %d 项)", worst_i);
        printf("\n");
        printf("  参考末值       %.9g\n", (double)ref[0]);
        printf("  GPU 末值       %.9g\n", (double)hOut[0]);
        if (mism) {
            /* 对不上就把整条向量打出来。只看一个标量值是猜不出原因的 ——
             * 实测教训：参考值 15.8535948 与 14.74259 看着像同一类数，
             * 只有把 16 项全列出来才能看出哪一项先开始分家。 */
            int w;
            printf("\n  c    参考            GPU             相对差\n");
            printf("  -------------------------------------------------\n");
            for (w = 0; w < FM_NC; w++)
                printf("  %2d  %14.9g  %14.9g  %10.3e\n", w,
                       (double)ref[w], (double)hOut[w],
                       fabs((double)ref[w] - (double)hOut[w])
                       / (fabs((double)ref[w]) < 1.0 ? 1.0 : fabs((double)ref[w])));
            printf("\n  初值              %.9g %.9g %.9g\n",
                   (double)hInit[0], (double)hInit[1], (double)hInit[2]);
            printf("  FMK[0][0..2]      %.9g %.9g %.9g\n",
                   (double)FMK[0][0], (double)FMK[0][1], (double)FMK[0][2]);
            printf("  FMB[0..2]         %.9g %.9g %.9g\n",
                   (double)FMB[0], (double)FMB[1], (double)FMB[2]);
            printf("  iters=%u  FM_S=%d  FM_NC=%d\n", iters, FM_S, FM_NC);
        }

        if (mism != 0) {
            printf("\n[错误] %d 个结果对不上 —— ptxas 没有逐条执行那 %d 条 FMA，\n"
                   "       这次测出来的任何吞吐数字都作废。\n", mism, FM_S * FM_NC);
            return 1;
        }
        printf("  => 逐位全中，证明 %d 条 FMA x %u 轮真的全跑了。\n",
               FM_S * FM_NC, iters);
    }

    /* ================= 第二步：吞吐扫描 =================
     *
     * 扫「每 SM 几个块」，因为极限速度取决于驻留了多少个 warp。
     * 每档 9 次取中位数（GPU 会动态升频，单次测量不作数）。
     */
    printf("\n================ 第二步：吞吐扫描 ================\n");
    printf("  每线程 %d 条独立 FMA 链 x 循环体 %d 步 x %u 轮\n",
           FM_NC, FM_S, ITERS);
    printf("\n  块/SM   网格   线程数   中位用时   TFLOP/s   相对最快\n");
    printf("  -------------------------------------------------\n");
    {
        static const int bpslist[] = { 1, 2, 4, 6, 8, 12, 16, 20, 24, 28, 32 };
        const int nb = (int)(sizeof bpslist / sizeof bpslist[0]);
        double res_tf[16], res_ms[16];
        int res_bps[16], res_n = 0;
        int bi;

        for (bi = 0; bi < nb; bi++) {
            int bps = bpslist[bi];
            unsigned gx = (unsigned)nsm * (unsigned)bps;
            unsigned nthr = gx * 32u;
            unsigned int_it = ITERS;
            void *args[3];
            double tt[16];
            double ms, tf;

            if (bps > maxblk) continue;
            if (nthr > MAXTHREADS) continue;

            args[0] = &dInit; args[1] = &dOut; args[2] = &int_it;
            CK(p_cuLaunchKernel(fF, gx, 1, 1, 32, 1, 1, 0, NULL, args, NULL), "预热");
            CK(p_cuCtxSynchronize(), "预热同步");

            for (rep = 0; rep < 9; rep++) {
                el = -1.0f;
                CK(p_cuEventRecord(ev0, 0), "ev0");
                CK(p_cuLaunchKernel(fF, gx, 1, 1, 32, 1, 1, 0, NULL, args, NULL), "发射");
                CK(p_cuEventRecord(ev1, 0), "ev1");
                CK(p_cuEventSynchronize(ev1), "ev1 同步");
                CK(p_cuEventElapsedTime(&el, ev0, ev1), "取用时");
                if (el <= 0) { printf("[错误] 用时非正：%f ms\n", (double)el); return 1; }
                tt[rep] = el;
            }
            qsort(tt, 9, sizeof(double), cmp_dbl);
            ms = tt[4];
            tf = (double)nthr * (double)FM_NC * (double)FM_S * (double)ITERS
                 * 2.0 / (ms / 1000.0) / 1e12;

            if (tf > best_tf) { best_tf = tf; best_bps = bps; }
            res_tf[res_n] = tf; res_ms[res_n] = ms; res_bps[res_n] = bps; res_n++;
        }

        /* 打完才知道谁最快，所以先跑完再统一补「相对最快」列 */
        for (bi = 0; bi < res_n; bi++)
            printf("  %5d  %5u  %8u  %8.3f ms  %8.2f  %7.1f%%\n",
                   res_bps[bi], nsm * res_bps[bi],
                   (unsigned)nsm * (unsigned)res_bps[bi] * 32u,
                   res_ms[bi], res_tf[bi], res_tf[bi] / best_tf * 100.0);
    }
    printf("\n  最快档：%d 块/SM，%.2f TFLOP/s\n", best_bps, best_tf);

    /* ================= 第三步：与 sgemm_8x8 同轮交替对测 =================
     *
     * 为什么要交替而不是分开跑两次：GPU 会动态升频，跨运行的绝对值不可比。
     * 本会话已经吃过这个亏（同一内核测出过 3.44 与 4.27）。只有让两个内核
     * 轮流跑同一段时间状态，比值才作数。
     */
    {
        CUmodule mS = NULL;
        CUfunction fS = NULL;
        static const int nlist[] = { 1024, 2048, 3216, 4096 };
        int qi;

        if (!load_ptx("_ptx_PTX_8X8.ptx")) { printf("%s\n", g_err); return 1; }
        r = p_cuModuleLoadData(&mS, g_ptx);
        if (r != 0) { printf("PTX_8X8 被拒：%s\n", cu_err(r)); return 1; }
        if (p_cuModuleGetFunction(&fS, mS, "sgemm_8x8") != 0) {
            printf("取不到 sgemm_8x8\n"); return 1;
        }

        printf("\n================ 第三步：sgemm_8x8 同轮交替对测 ================\n");

        /* 先自检小尺寸，证明这个内核真的算对了，比速才有意义。
         * 缓冲区必须按 NCHK 独立分配：踩过一次坑，把 N=2048 的大缓冲区传给
         * 只认参数 M 的内核，核读写的是另一个数组，报出来 19.7% 的「误差」——
         * 测的其实是错代码的速度。 */
        {
            const int NCHK = 192;
            const size_t cc = (size_t)NCHK * NCHK * sizeof(float);
            float *sA = (float *)malloc(cc), *sB = (float *)malloc(cc);
            float *sC = (float *)malloc(cc);
            CUdeviceptr dA = 0, dB = 0, dC = 0;
            void *ca[6];
            int mm = NCHK, nn = NCHK, kk = NCHK;
            unsigned sd = 987654321u;
            double worst = 0.0;
            size_t q;
            int i2, j2, k2;

            if (!sA || !sB || !sC) { printf("host 内存不足\n"); return 1; }
            for (q = 0; q < cc / sizeof(float); q++) {
                sd = sd * 1103515245u + 12345u;
                sA[q] = ((float)((sd >> 9) & 0xFFFF) / 32768.0f) - 1.0f;
                sd = sd * 1103515245u + 12345u;
                sB[q] = ((float)((sd >> 9) & 0xFFFF) / 32768.0f) - 1.0f;
            }
            CK(p_cuMemAlloc_v2(&dA, cc), "自检 A");
            CK(p_cuMemAlloc_v2(&dB, cc), "自检 B");
            CK(p_cuMemAlloc_v2(&dC, cc), "自检 C");
            CK(p_cuMemcpyHtoD_v2(dA, sA, cc), "自检 A 上显存");
            CK(p_cuMemcpyHtoD_v2(dB, sB, cc), "自检 B 上显存");
            ca[0] = &dA; ca[1] = &dB; ca[2] = &dC;
            ca[3] = &mm; ca[4] = &nn; ca[5] = &kk;
            CK(p_cuLaunchKernel(fS, (unsigned)((NCHK + 127) / 128),
                                (unsigned)((NCHK + 127) / 128), 1,
                                16, 16, 1, 0, NULL, ca, NULL), "sgemm 自检");
            CK(p_cuCtxSynchronize(), "sgemm 自检同步");
            CK(p_cuMemcpyDtoH_v2(sC, dC, cc), "读回自检 C");
            for (i2 = 0; i2 < NCHK; i2++)
                for (j2 = 0; j2 < NCHK; j2++) {
                    double sum = 0.0, d, sc;
                    for (k2 = 0; k2 < NCHK; k2++)
                        sum += (double)sA[(size_t)i2 * NCHK + k2]
                             * (double)sB[(size_t)k2 * NCHK + j2];
                    d = fabs(sum - (double)sC[(size_t)i2 * NCHK + j2]);
                    sc = fabs(sum); if (sc < 1.0) sc = 1.0;
                    if (d / sc > worst) worst = d / sc;
                }
            printf("  sgemm_8x8 自检 %dx%dx%d  最大相对误差 %.3e\n", NCHK, NCHK, NCHK, worst);
            free(sA); free(sB); free(sC);
            p_cuMemFree_v2(dA); p_cuMemFree_v2(dB); p_cuMemFree_v2(dC);
            if (!(worst < 1e-4)) {
                printf("[错误] sgemm 算错了，后面的比速没有意义\n");
                return 1;
            }
        }

        printf("\n     N     网格    FMA 用时   sgemm 用时   FMA T/s   sgemm T/s   占比\n");
        printf("  -----------------------------------------------------------\n");
        for (qi = 0; qi < 4; qi++) {
            int NT = nlist[qi];
            size_t cap = (size_t)NT * NT * sizeof(float);
            float *hA = (float *)malloc(cap), *hB = (float *)malloc(cap);
            CUdeviceptr dA = 0, dB = 0, dC = 0;
            double tf[9], ts[9], tmed_f, tmed_s;
            int mm = NT, nn = NT, kk = NT;
            void *sa[6], *fa[3];
            unsigned pgx, pgy, int_it = ITERS;
            unsigned gx = (unsigned)nsm * (unsigned)(best_bps > 0 ? best_bps : 24);
            unsigned sd = 24680135u;
            size_t q;

            if (!hA || !hB) { printf("host 内存不足\n"); return 1; }
            for (q = 0; q < cap / sizeof(float); q++) {
                sd = sd * 1103515245u + 12345u;
                hA[q] = ((float)((sd >> 9) & 0xFFFF) / 32768.0f) - 1.0f;
                sd = sd * 1103515245u + 12345u;
                hB[q] = ((float)((sd >> 9) & 0xFFFF) / 32768.0f) - 1.0f;
            }
            CK(p_cuMemAlloc_v2(&dA, cap), "分配 A");
            CK(p_cuMemAlloc_v2(&dB, cap), "分配 B");
            CK(p_cuMemAlloc_v2(&dC, cap), "分配 C");
            CK(p_cuMemcpyHtoD_v2(dA, hA, cap), "A 上显存");
            CK(p_cuMemcpyHtoD_v2(dB, hB, cap), "B 上显存");
            free(hA); free(hB);
            sa[0] = &dA; sa[1] = &dB; sa[2] = &dC;
            sa[3] = &mm; sa[4] = &nn; sa[5] = &kk;
            pgx = (unsigned)((NT + 127) / 128); pgy = pgx;
            fa[0] = &dInit; fa[1] = &dOut; fa[2] = &int_it;

            CK(p_cuLaunchKernel(fS, pgx, pgy, 1, 16, 16, 1, 0, NULL, sa, NULL), "sgemm 预热");
            CK(p_cuLaunchKernel(fF, gx, 1, 1, 32, 1, 1, 0, NULL, fa, NULL), "FMA 预热");
            CK(p_cuCtxSynchronize(), "预热同步");

            for (rep = 0; rep < 9; rep++) {
                /* 每轮固定交替：先 FMA 后 sgemm，两人共享同一段频率状态 */
                el = -1.0f;
                CK(p_cuEventRecord(ev0, 0), "ev0");
                CK(p_cuLaunchKernel(fF, gx, 1, 1, 32, 1, 1, 0, NULL, fa, NULL), "FMA");
                CK(p_cuEventRecord(ev1, 0), "ev1");
                CK(p_cuEventSynchronize(ev1), "ev1 同步");
                CK(p_cuEventElapsedTime(&el, ev0, ev1), "FMA 用时");
                if (el <= 0) { printf("[错误] FMA 用时非正\n"); return 1; }
                tf[rep] = el;

                el = -1.0f;
                CK(p_cuEventRecord(ev0, 0), "ev0");
                CK(p_cuLaunchKernel(fS, pgx, pgy, 1, 16, 16, 1, 0, NULL, sa, NULL), "sgemm");
                CK(p_cuEventRecord(ev1, 0), "ev1");
                CK(p_cuEventSynchronize(ev1), "ev1 同步");
                CK(p_cuEventElapsedTime(&el, ev0, ev1), "sgemm 用时");
                if (el <= 0) { printf("[错误] sgemm 用时非正\n"); return 1; }
                ts[rep] = el;
            }
            qsort(tf, 9, sizeof(double), cmp_dbl);
            qsort(ts, 9, sizeof(double), cmp_dbl);
            tmed_f = tf[4]; tmed_s = ts[4];
            {
                double tfma = (double)gx * 32.0 * FM_NC * FM_S * ITERS * 2.0
                              / (tmed_f / 1000.0) / 1e12;
                double tsg = 2.0 * NT * NT * NT / (tmed_s / 1000.0) / 1e12;
                printf("  %5d  %2ux%-2u  %8.3f ms  %9.3f ms  %8.2f  %9.2f  %6.1f%%\n",
                       NT, pgx, pgy, tmed_f, tmed_s, tfma, tsg, tsg / tfma * 100.0);
                if (NT == 3216) { g_fma_tf = tfma; g_sgemm_tf = tsg; }
            }
            p_cuMemFree_v2(dA); p_cuMemFree_v2(dB); p_cuMemFree_v2(dC);
        }
        printf("\n  N=3216（生产 tb.dot 尺寸）：sgemm 达到纯 FMA 极限的 %.1f%%\n",
               g_sgemm_tf / g_fma_tf * 100.0);

        /* ---------------- 为什么停在 64.5%：直接问驱动要驻留数 ----------------
         *
         * 有一个具体、可证伪的猜想：预取版本比原版多占 8 个寄存器，
         * 每块共享内存 256 x 88 = 22528 字节，3 块/SM 需要 67584 > 65536，
         * 于是每 SM 可能从驻留 3 块掉到 2 块 —— 那就是拿 occupancy 换延迟隐藏。
         * 这个可以问驱动要答案，不必猜。
         */
        if (p_cuFuncGetAttribute && p_cuOccupancyMaxActiveBlocksPerMultiprocessor) {
            int regs = 0, smem = 0, mtpb = 0, occ = 0, warps;
            printf("\n  ---------------- sgemm_8x8 的驻留情况 ----------------\n");
            p_cuFuncGetAttribute(&regs, FA_NUM_REGS, fS);
            p_cuFuncGetAttribute(&smem, FA_SHARED_SIZE_BYTES, fS);
            p_cuFuncGetAttribute(&mtpb, FA_MAX_THREADS_PER_BLOCK, fS);
            p_cuOccupancyMaxActiveBlocksPerMultiprocessor(&occ, fS, 256, 0);
            warps = occ * 8;   /* 每块 256 线程 = 8 个 warp */
            printf("    每线程寄存器   %d\n", regs);
            printf("    每块共享内存   %d 字节\n", smem);
            printf("    每块线程数     %d\n", mtpb);
            printf("    每 SM 驻留块数 %d  -> %d 个 warp\n", occ, warps);
            printf("    共享内存上限推算 %d 字节/SM 时能放 %d 块\n",
                   65536, 65536 / (smem > 0 ? smem : 1));
            printf("    寄存器上限推算 %d 寄存器/SM 时能放 %d 块\n",
                   regs * 256, (regs > 0 ? (65536 / (regs * 256)) : 0));
            if (p_cuFuncGetAttribute) {
                int r0 = 0, s0 = 0, occ0 = 0;
                p_cuFuncGetAttribute(&r0, FA_NUM_REGS, fF);
                p_cuFuncGetAttribute(&s0, FA_SHARED_SIZE_BYTES, fF);
                p_cuOccupancyMaxActiveBlocksPerMultiprocessor(&occ0, fF, 32, 0);
                printf("    对比：FMA 极限内核 每线程 %d 寄存器, 每块 %d 共享, 每 SM %d 块(%d warp)\n",
                       r0, s0, occ0, occ0);
            }

            /* 冻结的原版（没有预取）拿来对一下：预取多占的寄存器到底把驻留数
             * 压下来没有。这正是「22% 提速是不是拿 occupancy 换的」那个问号。 */
            {
                CUmodule mO = NULL;
                CUfunction fO = NULL;
                if (load_ptx("_ptx_PTX_8X8_orig.ptx")) {
                    if (p_cuModuleLoadData(&mO, g_ptx) == 0 &&
                        p_cuModuleGetFunction(&fO, mO, "sgemm_8x8") == 0) {
                        int ro = 0, so = 0, occo = 0;
                        p_cuFuncGetAttribute(&ro, FA_NUM_REGS, fO);
                        p_cuFuncGetAttribute(&so, FA_SHARED_SIZE_BYTES, fO);
                        p_cuOccupancyMaxActiveBlocksPerMultiprocessor(&occo, fO, 256, 0);
                        printf("    原版(无预取)   每线程 %d 寄存器, 每块 %d 共享, 每 SM %d 块(%d warp)\n",
                               ro, so, occo, occo * 8);
                        if (regs > ro)
                            printf("    => 预取确实多占 %d 个寄存器；驻留块数 %d -> %d，"
                                   "warp %d -> %d\n",
                                   regs - ro, occo, occ, occo * 8, warps);
                        else if (regs == ro)
                            printf("    => 寄存器数没变（%d），驻留也没变，"
                                   "那 22%% 提速不是拿 occupancy 换的\n", regs);
                        else
                            printf("    => 意外：预取版寄存器反而更少\n");
                    }
                }
            }
        }
    }

    /* ================= 第四步：持续负载（配 nvidia-smi 采样） =================
     *
     * 短内核跑在什么频率上是运气，持续负载跑出来的才是稳定频率。
     * 这个阶段请同时用
     *     nvidia-smi --query-gpu=clocks.sm --format=csv -lms 200
     * 采样，才能把「负载期间的真实时钟」和这里的 TFLOP/s 对上。
     */
    if (hold_sec > 0.0) {
        LARGE_INTEGER qpf, t0, t1;
        unsigned gx = (unsigned)nsm * (unsigned)best_bps;
        unsigned int_it = ITERS;
        void *args[3];
        double elapsed, fma_total, launches = 0.0;
        QueryPerformanceFrequency(&qpf);
        args[0] = &dInit; args[1] = &dOut; args[2] = &int_it;

        printf("\n================ 第四步：持续负载 %.1f 秒 ================\n"
               "  现在可以另开一个窗口采样真实时钟：\n"
               "  nvidia-smi --query-gpu=clocks.sm,clocks.mem,power.draw,temperature.gpu"
               " --format=csv -lms 200\n", hold_sec);
        CK(p_cuLaunchKernel(fF, gx, 1, 1, 32, 1, 1, 0, NULL, args, NULL), "持续预热");
        CK(p_cuCtxSynchronize(), "持续预热同步");

        QueryPerformanceCounter(&t0);
        for (;;) {
            int k;
            double sofar;
            for (k = 0; k < 16; k++)
                p_cuLaunchKernel(fF, gx, 1, 1, 32, 1, 1, 0, NULL, args, NULL);
            p_cuCtxSynchronize();
            launches += 16.0;
            /* t1 必须在循环里重新取。第一版把它写在 while 条件里，而 t1 从没被
             * 赋值过，于是条件恒成立，整个程序无限空转——空转了 186 秒 CPU。 */
            QueryPerformanceCounter(&t1);
            sofar = (double)(t1.QuadPart - t0.QuadPart) / (double)qpf.QuadPart;
            if (sofar >= hold_sec) break;
        }
        elapsed = (double)(t1.QuadPart - t0.QuadPart) / (double)qpf.QuadPart;
        fma_total = launches * (double)gx * 32.0 * (double)FM_NC
                    * (double)FM_S * (double)ITERS;
        g_sust_tf = fma_total * 2.0 / elapsed / 1e12;
        printf("  持续窗口 %.2f 秒，发射 %.0f 次\n", elapsed, launches);
        printf("  持续吞吐     %.2f TFLOP/s\n", g_sust_tf);
        printf("  （把上面 nvidia-smi 采到的平均 SM 频率代进来，"
               "就是「这张卡实际跑的时候的每核频率」）\n");
    }

    /* ================= 第五步：CPU 极限速度 =================
     *
     * 先过闸门，再让数字。和 GPU 侧同一套判据。
     */
    if (!__builtin_cpu_supports("avx2") || !__builtin_cpu_supports("fma")) {
        printf("\n================ CPU 侧跳过 ================\n");
        printf("  这台机器不支持 AVX2+FMA，无法用同一把尺子量，跳过。\n");
    } else {
        float *cinit = (float *)malloc(CPU_LANES * sizeof(float));
        float *cout  = (float *)malloc((size_t)64 * CPU_LANES * sizeof(float));
        float cref[CPU_LANES];
        int ci, L, bi2;
        static const int thr[] = { 1, 2, 4, 6, 8, 12 };
        const int nthr_opts = 6;
        double cbest_tf = 0.0;
        int cbest_thr = 0;
        unsigned CITERS = 60000;

        if (!cinit || !cout) { printf("host 内存不足\n"); return 1; }
        /* 64 条链的初值两两不同（全部是精确的二进制小数，保证位模式可复制） */
        for (L = 0; L < CPU_LANES; L++) cinit[L] = 0.5f + (float)L * 0.03125f;

        printf("\n================ 第五步：CPU 极限速度 ================\n");
        printf("  ---- CPU 正确性闸门（向量内核 vs 标量 fmaf 参考）----\n");
        {
            const unsigned it = 64;
            int mism = 0, exact = 0;
            double worst = 0.0;
            memset(cout, 0, (size_t)64 * CPU_LANES * sizeof(float));
            cpu_fma_v(cinit, cout, it);
            cpu_fma_ref(cinit, cref, it);
            for (L = 0; L < CPU_LANES; L++) {
                double d = fabs((double)cout[L] - (double)cref[L]);
                double sc = fabs((double)cref[L]); if (sc < 1.0) sc = 1.0;
                if (memcmp(&cout[L], &cref[L], sizeof(float)) == 0) exact++;
                else { mism++; if (d / sc > worst) worst = d / sc; }
            }
            printf("    %d 条链 x %d 轮   逐位相同 %d/%d   最大相对误差 %.3e\n",
                   CPU_LANES, it, exact, CPU_LANES, worst);
            if (mism) {
                printf("    [错误] 向量内核没按顺序算完 %d 条链，什么数字都不报\n", mism);
                free(cinit); free(cout);
                return 1;
            }
            printf("    => 逐位全中，证明 CPU 上 %d 条 FMA x %d 步 x %d 轮真跑了\n",
                   CPU_ACC, FM_S, it);
        }

        printf("\n    线程数   中位用时      TFLOP/s    相对最快\n");
        printf("    -------------------------------------------------\n");
        {
            double tms[16], res_t[16], res_tf[16];
            int res_thr[16], res_n = 0;
            for (bi2 = 0; bi2 < nthr_opts; bi2++) {
                int nt = thr[bi2];
                double ms, tf;
                if (cpu_run(nt, cinit, cout, CITERS) < 0) continue;  /* 预热 */
                for (rep = 0; rep < 9; rep++) {
                    ms = cpu_run(nt, cinit, cout, CITERS);
                    if (ms <= 0) { printf("[错误] CPU 用时非正\n"); return 1; }
                    tms[rep] = ms;
                }
                qsort(tms, 9, sizeof(double), cmp_dbl);
                ms = tms[4];
                tf = (double)nt * CPU_ACC * 8.0 * FM_S * CITERS * 2.0
                     / (ms / 1000.0) / 1e12;
                if (tf > cbest_tf) { cbest_tf = tf; cbest_thr = nt; }
                res_t[res_n] = ms; res_tf[res_n] = tf; res_thr[res_n] = nt;
                res_n++;
            }
            for (bi2 = 0; bi2 < res_n; bi2++)
                printf("    %6d   %8.2f ms   %8.3f   %7.1f%%\n",
                       res_thr[bi2], res_t[bi2], res_tf[bi2],
                       res_tf[bi2] / cbest_tf * 100.0);
        }
        printf("\n    CPU 最快档：%d 线程，%.3f TFLOP/s\n", cbest_thr, cbest_tf);
        printf("    注意：12 线程是 6 物理核 + 超线程，超线程对 FMA 几乎无收益。\n");

        /* ---------- 第六步：GPU / CPU 同轮交替 ---------- */
        printf("\n================ 第六步：GPU vs CPU 同轮交替 ================\n");
        if (best_bps > 0 && cbest_thr > 0) {
            unsigned gx = (unsigned)nsm * (unsigned)best_bps;
            unsigned int_it = ITERS;
            void *fa[3];
            double tg[9], tc[9], tmf, tmc, gtf, ctf;
            fa[0] = &dInit; fa[1] = &dOut; fa[2] = &int_it;

            CK(p_cuLaunchKernel(fF, gx, 1, 1, 32, 1, 1, 0, NULL, fa, NULL), "GPU 预热");
            cpu_run(cbest_thr, cinit, cout, CITERS);
            CK(p_cuCtxSynchronize(), "预热同步");

            for (rep = 0; rep < 9; rep++) {
                /* 每轮固定交替，先 GPU 后 CPU，两人共享同一段机器状态 */
                el = -1.0f;
                CK(p_cuEventRecord(ev0, 0), "ev0");
                CK(p_cuLaunchKernel(fF, gx, 1, 1, 32, 1, 1, 0, NULL, fa, NULL), "GPU");
                CK(p_cuEventRecord(ev1, 0), "ev1");
                CK(p_cuEventSynchronize(ev1), "ev1 同步");
                CK(p_cuEventElapsedTime(&el, ev0, ev1), "GPU 用时");
                if (el <= 0) { printf("[错误] GPU 用时非正\n"); return 1; }
                tg[rep] = el;
                tc[rep] = cpu_run(cbest_thr, cinit, cout, CITERS);
            }
            qsort(tg, 9, sizeof(double), cmp_dbl);
            qsort(tc, 9, sizeof(double), cmp_dbl);
            tmf = tg[4]; tmc = tc[4];
            gtf = (double)gx * 32.0 * FM_NC * FM_S * ITERS * 2.0
                  / (tmf / 1000.0) / 1e12;
            ctf = (double)cbest_thr * CPU_ACC * 8.0 * FM_S * CITERS * 2.0
                  / (tmc / 1000.0) / 1e12;
            printf("    GPU 纯 FMA（%d 块/SM）  %8.2f ms   %7.3f TFLOP/s\n",
                   best_bps, tmf, gtf);
            printf("    CPU 纯 FMA（%d 线程）   %8.2f ms   %7.3f TFLOP/s\n",
                   cbest_thr, tmc, ctf);
            printf("    GPU / CPU = %.2f 倍\n", gtf / ctf);
            printf("\n    每线程单核速率：CPU %.1f GFLOP/s/核，"
                   "GPU %.1f GFLOP/s/线程\n",
                   ctf * 1000.0 / (double)cbest_thr, gtf * 1000.0 / (double)(gx * 32));
            g_cpu_tf = ctf;
            g_alt_ratio = gtf / ctf;
        }
        free(cinit); free(cout);
    }

    /* ================= 报告：理论上限 ================= */
    {
        /* 有同轮交替数就用它（与 sgemm 共享同一段频率状态，比值才作数），
         * 没有才退回扫描的最好档。 */
        double rep_tf = (g_fma_tf > 0.0) ? g_fma_tf : best_tf;
        printf("\n================ 理论上限（分母必须用实测频率） ================\n");
        printf("  CC 6.1 每 SM 到底几个 FP32 单元，各家说法不一（64 是 P100 的数）。\n");
        printf("  这里两种都列出来，用上面测出的 %.2f TFLOP/s 去仲裁：\n\n", rep_tf);
        printf("     频率      64 单元/SM (%.2f TF)   128 单元/SM (%.2f TF)   实测占比\n"
               "  ------------------------------------------------------------\n",
               nsm * 64.0 * 2.0 * clock_khz * 1000.0 / 1e12,
               nsm * 128.0 * 2.0 * clock_khz * 1000.0 / 1e12);
        {
            double fclocks[] = { 1506.0, 1708.0, 1911.0, 2100.0 };
            int fi;
            for (fi = 0; fi < 4; fi++) {
                double f = fclocks[fi] * 1e6;
                double t64 = nsm * 64.0 * 2.0 * f / 1e12;
                double t128 = nsm * 128.0 * 2.0 * f / 1e12;
                const char *tag = (fi == 0) ? "<- 空闲频率"
                                : (fi == 1) ? "<- 驱动报告"
                                : (fi == 2) ? "<- nvidia-smi 最大" : "<- 超频假设";
                printf("  %7.0f MHz %12.2f            %12.2f     %5.1f%% / %5.1f%%  %s\n",
                       fclocks[fi], t64, t128, rep_tf / t64 * 100.0,
                       rep_tf / t128 * 100.0, tag);
            }
        }
        printf("\n  判据：物理上限不可能被超过。若实测超过按某一行算出的上限，\n"
                "        那不是卡更强，是那一行的单元数或频率取错了。\n");
        if (g_sgemm_tf > 0.0)
            printf("\n  生产 sgemm_8x8 @N=3216 实测 %.2f TFLOP/s，占纯 FMA 极限 %.1f%%\n",
                   g_sgemm_tf, g_sgemm_tf / rep_tf * 100.0);
        if (g_sust_tf > 0.0)
            printf("  持续负载下的 FMA 吞吐 %.2f TFLOP/s\n", g_sust_tf);
        if (g_cpu_tf > 0.0)
            printf("  CPU 纯 FMA 极限 %.3f TFLOP/s，同轮交替 GPU/CPU = %.2f 倍\n",
                   g_cpu_tf, g_alt_ratio);
    }

    free(hOut); free(hInit);
    p_cuMemFree_v2(dInit); p_cuMemFree_v2(dOut);
    (void)attr;
    return 0;
}
