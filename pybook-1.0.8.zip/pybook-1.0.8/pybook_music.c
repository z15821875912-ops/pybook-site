/* PYbook 音 模块：正弦/三角波合成（waveOut）+ 外部音频播放（MCI，支持 MP3/WAV）。
 * 接口见 pybook_lib.h；依赖 windows.h（winmm），无第三方库。
 * 约定：正弦/三角是阻塞式（播完才返回，适合写旋律）；音.放 是后台异步播放。 */

#include "pybook_lib.h"

#include <windows.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>

#define MU_SR        44100          /* 采样率 */
#define MU_AMplitude 0.28           /* 音量系数（防爆音） */
#define MU_TAU       6.28318530717958647692

/* 运行时错误出口（lib_die 是 lib.c 的静态函数，这里自备一份） */
static void mu_die(const char *fmt, ...)
{
    va_list ap;
    fprintf(stderr, "运行时错误: ");
    va_start(ap, fmt);
    vfprintf(stderr, fmt, ap);
    va_end(ap);
    fputc('\n', stderr);
    exit(1);
}

/* 参数取数字 */
static double mu_num(Value v, const char *who)
{
    if (IS_FLT(v))
        return AS_FLT(v);
    if (IS_INT(v) || IS_BIGINT(v))
        return (double)rt_to_ll(v);
    if (IS_BOOL(v))
        return (double)AS_BOOL(v);
    mu_die("%s 需要数字参数", who);
    return 0;
}

/* UTF-8 → UTF-16（路径含中文也稳） */
static int mu_wide(const char *s, wchar_t *out, int cap)
{
    return MultiByteToWideChar(CP_UTF8, 0, s ? s : "", -1, out, cap);
}

/* ============ 音量 / ADSR 包络 / 乐器（新增段） ============
 * 这一段全部是「状态 + 纯计算」，除了 音.演 会真的开声卡。
 * 设计约束：默认值必须复刻改动前的行为（音量 28 == 原来的 MU_AMplitude 0.28），
 * 这样老脚本一个字节都不变。 */

typedef struct { double a, d, s, r; } MuEnv;   /* 攻/减/延/放：毫秒 / 0..1 */

static double      g_mu_volume = 28.0;         /* 主音量 0..100（28 == 旧 MU_AMplitude） */
static MuEnv       g_mu_env    = { 0.0, 0.0, 1.0, 0.0 };  /* 全局 ADSR，默认=不整形 */
static int         g_mu_env_set = 0;            /* 音.包络 是否被显式设过 */
static int         g_mu_instr_idx = 0;          /* 当前乐器下标 */

/* 乐器 = 波形 + 谐波 + 幅度 + 自己的 ADSR */
typedef struct {
    const char *name;
    int    wave;        /* 基准波形 0正弦 1三角 2噪声 3方波 4锯齿 */
    double h2, h3;      /* 2/3 次谐波幅度比（0 = 没有） */
    double amp;         /* 基础幅度 0..1 */
    MuEnv  env;
} MuInstr;

/* 默认乐器的 wave/h2/h3/amp 必须等价于改动前的正弦单音，否则老脚本听感会变。
 * amp 对 奏/谱 无影响（那里做峰值归一化），对 正弦/三角/快/演 有影响。 */
static const MuInstr mu_instrs[] = {
    { "默认",   0, 0.00, 0.00, 0.28, {   0.0,   0.0, 1.00,   0.0 } },
    { "钢琴",   0, 0.50, 0.25, 0.30, {   5.0, 120.0, 0.25,  60.0 } },
    { "电钢",   0, 0.30, 0.00, 0.28, {   3.0,  80.0, 0.45,  40.0 } },
    { "小号",   4, 0.60, 0.35, 0.30, {  25.0,  60.0, 0.80,  50.0 } },
    { "长笛",   0, 0.12, 0.05, 0.26, {  70.0,  50.0, 0.85,  60.0 } },
    { "单簧管", 1, 0.70, 0.30, 0.28, {  40.0,  50.0, 0.85,  45.0 } },
    { "贝斯",   0, 0.45, 0.15, 0.34, {   6.0,  90.0, 0.55,  50.0 } },
    { "钟",     0, 0.60, 0.20, 0.26, {   2.0, 400.0, 0.18, 500.0 } },
};
#define MU_NINSTR ((int)(sizeof mu_instrs / sizeof mu_instrs[0]))

static const MuInstr *mu_cur_instr(void) { return &mu_instrs[g_mu_instr_idx]; }

/* 主音量比例：28 -> 1.0（等于改动前），0 -> 静音，100 -> 约 3.6 倍 */
static double mu_vol_scale(void) { return g_mu_volume / 28.0; }

/* 当前生效的 ADSR：音.包络 显式设过就盖掉乐器自带的 */
static MuEnv mu_cur_env(const MuInstr *ins)
{
    return g_mu_env_set ? g_mu_env : ins->env;
}

/* 通用波形发生器（新增 3=方波 4=锯齿；st 是噪声用的滚动种子） */
static double mu_wave(double ph, int wave, unsigned *st)
{
    switch (wave) {
        case 1:                                        /* 三角 */
            return (2.0 / MU_TAU) * asin(sin(ph));
        case 2:                                        /* 噪声 */
            *st = *st * 1664525u + 1013904223u;
            return ((double)((*st >> 8) & 0xFFFF) / 32768.0) - 1.0;
        case 3:                                        /* 方波 */
            return (sin(ph) >= 0.0) ? 1.0 : -1.0;
        case 4: {                                      /* 锯齿 */
            double f = ph / MU_TAU;
            f = f - floor(f);
            return 2.0 * f - 1.0;
        }
        default:                                       /* 正弦 */
            return sin(ph);
    }
}

/* ADSR 包络在 t 时刻的增益 0..1。total 是该音的总长（毫秒）。
 * 边界：t<=0 或 t>=total 都是 0（保证首尾归零，不爆音）。
 * A+D+R 装不进 total 时等比压缩，绝不返回 >1 或 <0。 */
static double mu_env_gain(double t, double total, MuEnv e)
{
    if (total <= 0.0) return 0.0;
    if (t <= 0.0 || t >= total) return 0.0;
    double A = (e.a < 0.0) ? 0.0 : e.a;
    double D = (e.d < 0.0) ? 0.0 : e.d;
    double R = (e.r < 0.0) ? 0.0 : e.r;
    double S = (e.s < 0.0) ? 0.0 : (e.s > 1.0 ? 1.0 : e.s);
    double sum = A + D + R;
    if (sum <= 0.0) return 1.0;                      /* 无包络：恒 1 */
    if (sum >= total) {                              /* 装不下：等比压缩到 total */
        double k = total / sum;
        A *= k; D *= k; R *= k;
    }
    double t1 = A;                                   /* 攻击结束 */
    double t2 = A + D;                               /* 衰减结束 */
    double t3 = total - R;                           /* 松开开始 */
    if (t3 < t2) t3 = t2;                            /* 松开不许早于衰减结束 */
    if (t < t1) return (t1 > 0.0) ? t / t1 : 1.0;
    if (t < t2) return (t2 > t1) ? 1.0 + (S - 1.0) * (t - t1) / (t2 - t1) : S;
    if (t < t3) return S;
    return (total > t3) ? S * (total - t) / (total - t3) : 0.0;
}

/* 起止防爆音的线性淡入淡出（沿用旧实现，5ms 上限） */
static double mu_edge_fade(size_t i, size_t n)
{
    size_t fade = n / 4;
    if (fade > (size_t)(MU_SR * 0.005)) fade = (size_t)(MU_SR * 0.005);
    if (fade == 0) fade = 1;
    double g = 1.0;
    if (i < fade) g = (double)i / (double)fade;
    if (n - i < fade) g = (double)(n - i) / (double)fade;
    return g;
}

/* 合成一段波形并阻塞播放：fade 5ms 消除起止爆音 */
static Value mu_tone(Value fv, Value mv, int triangle)
{
    double f = mu_num(fv, triangle ? "音.三角 的频率" : "音.正弦 的频率");
    double ms = mu_num(mv, "时长");
    if (f < 1.0)
        f = 1.0;
    if (f > 20000.0)
        f = 20000.0;
    if (ms < 0.0)
        ms = 0.0;
    if (ms > 60000.0)
        ms = 60000.0;

    size_t n = (size_t)(MU_SR * ms / 1000.0);
    if (n == 0)
        return rt_none();
    short *pcm = (short *)malloc(n * sizeof(short));
    if (pcm == NULL)
        mu_die("音：内存不足");

    /* 正弦/三角 是「纯单音」：不吃乐器的谐波，但吃主音量和全局 ADSR。 */
    MuEnv env = g_mu_env;
    double amp = MU_AMplitude * mu_vol_scale();
    if (amp > 1.0) amp = 1.0;
    double w = MU_TAU * f / MU_SR;
    for (size_t i = 0; i < n; i++) {
        double ph = w * (double)i;
        double t  = 1000.0 * (double)i / (double)MU_SR;
        double v = triangle ? (2.0 / MU_TAU) * asin(sin(ph)) : sin(ph);
        double g = mu_edge_fade(i, n) * mu_env_gain(t, ms, env);
        pcm[i] = (short)(v * amp * 32767.0 * g);
    }

    HWAVEOUT h = NULL;
    WAVEFORMATEX fmt;
    memset(&fmt, 0, sizeof fmt);
    fmt.wFormatTag = WAVE_FORMAT_PCM;
    fmt.nChannels = 1;
    fmt.nSamplesPerSec = MU_SR;
    fmt.wBitsPerSample = 16;
    fmt.nBlockAlign = fmt.nChannels * fmt.wBitsPerSample / 8;
    fmt.nAvgBytesPerSec = MU_SR * fmt.nBlockAlign;
    if (waveOutOpen(&h, WAVE_MAPPER, &fmt, 0, 0, CALLBACK_NULL) != MMSYSERR_NOERROR) {
        free(pcm);
        return rt_none();   /* 无可用音频输出（设备被占/静音拔线）：静默跳过不崩游戏 */
    }
    WAVEHDR hdr;
    memset(&hdr, 0, sizeof hdr);
    hdr.lpData = (LPSTR)pcm;
    hdr.dwBufferLength = (DWORD)(n * sizeof(short));
    waveOutPrepareHeader(h, &hdr, sizeof hdr);
    waveOutWrite(h, &hdr, sizeof hdr);
    while (!(hdr.dwFlags & WHDR_DONE))
        Sleep(1);
    waveOutUnprepareHeader(h, &hdr, sizeof hdr);
    waveOutClose(h);
    free(pcm);
    return rt_none();
}

Value rt_mu_sine(Value freq, Value ms)
{
    return mu_tone(freq, ms, 0);
}

Value rt_mu_tri(Value freq, Value ms)
{
    return mu_tone(freq, ms, 1);
}

/* ---- 外部音频（MCI：MP3/WAV/WMA 都行）----
 * 用别名 pybkmusic 管理一个后台播放器；音.放 会先收掉上一个。 */

static void mu_mci_close(void)
{
    mciSendStringW(L"close pybkmusic", NULL, 0, NULL);
}

/* 背景音乐音量跟着主音量走：默认 28 -> 280（与加音量功能之前一致）。 */
static void mu_apply_bg_volume(void)
{
    int v = (int)(g_mu_volume * 10.0);
    if (v < 0) v = 0;
    if (v > 1000) v = 1000;
    wchar_t cmd[64];
    _snwprintf(cmd, 63, L"setaudio pybkmusic volume to %d", v);
    mciSendStringW(cmd, NULL, 0, NULL);
}

/* ---- 非阻塞音效：fire-and-forget，绝不卡游戏帧 ---- */

#define SFX_RING 12

static HWAVEOUT g_sfx_hwo = NULL;     /* 音效专用设备句柄（复用，免打开延迟） */
static WAVEHDR  g_sfx_hdr[SFX_RING];
static short   *g_sfx_pcm[SFX_RING];
static int      g_sfx_next = 0;

static void sfx_reclaim(void)
{
    for (int i = 0; i < SFX_RING; i++) {
        if (g_sfx_pcm[i] != NULL && (g_sfx_hdr[i].dwFlags & WHDR_DONE)) {
            waveOutUnprepareHeader(g_sfx_hwo, &g_sfx_hdr[i], sizeof(WAVEHDR));
            free(g_sfx_pcm[i]);
            g_sfx_pcm[i] = NULL;
        }
    }
}

Value rt_mu_quick(Value fv, Value mv, Value wv)
{
    double f = mu_num(fv, "音.快 的频率");
    double ms = mu_num(mv, "音.快 的时长");
    long long wave = 0;
    if (IS_INT(wv) || IS_BIGINT(wv))
        wave = rt_to_ll(wv);
    if (f < 20.0)
        f = 20.0;
    if (f > 8000.0)
        f = 8000.0;
    if (ms < 5.0)
        ms = 5.0;
    if (ms > 400.0)
        ms = 400.0;

    if (g_sfx_hwo == NULL) {
        WAVEFORMATEX fmt;
        memset(&fmt, 0, sizeof fmt);
        fmt.wFormatTag = WAVE_FORMAT_PCM;
        fmt.nChannels = 1;
        fmt.nSamplesPerSec = MU_SR;
        fmt.wBitsPerSample = 16;
        fmt.nBlockAlign = 2;
        fmt.nAvgBytesPerSec = MU_SR * 2;
        if (waveOutOpen(&g_sfx_hwo, WAVE_MAPPER, &fmt, 0, 0, CALLBACK_NULL) != MMSYSERR_NOERROR)
            return rt_none();   /* 无音频设备：静默跳过 */
    }
    sfx_reclaim();

    size_t n = (size_t)(MU_SR * ms / 1000.0);
    if (n == 0)
        return rt_none();
    short *pcm = (short *)malloc(n * sizeof(short));
    if (pcm == NULL)
        return rt_none();
    int slot = -1;
    for (int i = 0; i < SFX_RING; i++)
        if (g_sfx_pcm[i] == NULL) {
            slot = i;
            break;
        }
    if (slot < 0) {                 /* 环满：挤掉最旧的一个 */
        slot = g_sfx_next % SFX_RING;
        waveOutUnprepareHeader(g_sfx_hwo, &g_sfx_hdr[slot], sizeof(WAVEHDR));
        free(g_sfx_pcm[slot]);
    }
    double w = MU_TAU * f / MU_SR;
    size_t fade = n / 5;
    if (fade < 16)
        fade = 16;
    if (fade > n)
        fade = n;
    unsigned seed = (unsigned)(f * 977 + ms * 31 + wave * 7 + n);
    for (size_t i = 0; i < n; i++) {
        double ph = w * (double)i;
        double v;
        if (wave == 1)
            v = (2.0 / MU_TAU) * asin(sin(ph)) * 0.9;
        else if (wave == 2) {
            seed = seed * 1664525u + 1013904223u;
            v = ((double)((seed >> 8) & 0xFFFF) / 32768.0) - 1.0;
        } else
            v = sin(ph);
        double g = 1.0;
        if (i < fade)
            g = (double)i / (double)fade;
        if (n - i < fade)
            g = (double)(n - i) / (double)fade;
        double t = 1000.0 * (double)i / (double)MU_SR;
        g *= mu_env_gain(t, ms, g_mu_env);
        pcm[i] = (short)(v * (0.30 * mu_vol_scale()) * 32767.0 * g);
    }

    WAVEHDR *h = &g_sfx_hdr[slot];
    memset(h, 0, sizeof *h);
    h->lpData = (LPSTR)pcm;
    h->dwBufferLength = (DWORD)(n * sizeof(short));
    waveOutPrepareHeader(g_sfx_hwo, h, sizeof(WAVEHDR));
    if (waveOutWrite(g_sfx_hwo, h, sizeof(WAVEHDR)) != MMSYSERR_NOERROR) {
        free(pcm);
        g_sfx_pcm[slot] = NULL;
        return rt_none();
    }
    g_sfx_pcm[slot] = pcm;
    g_sfx_next++;
    return rt_none();
}

Value rt_mu_play(Value path)
{
    const char *p = rt_str_of(path);
    wchar_t wpath[1024];
    if (mu_wide(p, wpath, 1024) <= 0)
        mu_die("音.放：路径转码失败 %s", p);
    wchar_t dos[1024];
    for (int i = 0; wpath[i] != L'\0' && i < 1023; i++)
        dos[i] = (wpath[i] == L'/') ? L'\\' : wpath[i];
    dos[1023] = L'\0';
    wchar_t cmd[1200];
    _snwprintf(cmd, 1199, L"open \"%s\" alias pybkmusic", dos);
    mu_mci_close();
    /* 背景音乐是锦上添花：设备被占用/没有音频输出时静默跳过，不许崩游戏 */
    if (mciSendStringW(cmd, NULL, 0, NULL) != 0)
        return rt_none();
    /* 背景音乐默认压到约 28%：战斗曲不能盖过音效和人声喊话 */
    mu_apply_bg_volume();
    if (mciSendStringW(L"play pybkmusic", NULL, 0, NULL) != 0)
        return rt_none();
    return rt_none();
}

Value rt_mu_stop(void)
{
    mu_mci_close();
    return rt_none();
}

/* ============ 列表方式做音乐（类比 mm 的 draw_away：列表即乐谱） ============
 * 一行字符串 = 一条音轨；一个词 = 一拍（一个音符）。
 * 休止符：. _ r 都算静音（类比 mymove 的透明标记）。
 * 音符写法：科学音名 C4 D#4 Eb5 A3 …（默认正弦波）；音.音 可注册自定义音符。
 * 时长：默认 1 拍；token 后接 :N 表示 N 拍，如 C4:2 表示两拍。
 * 音.音(名, 频率, 波形)            注册/覆盖自定义音符（波形 0正弦/1三角/2噪声）
 * 音.奏(表, "名.wav", 速度)        列表 → 渲染成 WAV 落盘（速度 = 拍/分 BPM）
 * 音.谱(表, 速度)                 列表 → 即时播放（阻塞，播完才返回） */

typedef struct { char name[16]; double freq; int wave; } MuNote;
static MuNote mu_notes[256];
static int    mu_nnotes = 0;

/* 音名 → 半音（A B C D E F G） */
static int mu_letter_semitone(char c)
{
    switch (c) {
        case 'C': return 0;  case 'D': return 2;  case 'E': return 4;
        case 'F': return 5;  case 'G': return 7;  case 'A': return 9;
        case 'B': return 11; default: return -1;
    }
}

/* 解析音符：自定义优先；否则科学音名。命中返回 1 并写出 freq/wave；-1 不认识。
 * is_custom 区分「音.音 注册过」和「科学音名」：注册过的用它自己的波形，
 * 科学音名才吃当前乐器的波形与谐波。 */
static int mu_parse_note2(const char *tok, double *freq, int *wave, int *is_custom)
{
    for (int i = 0; i < mu_nnotes; i++)
        if (strcmp(mu_notes[i].name, tok) == 0) {
            *freq = mu_notes[i].freq; *wave = mu_notes[i].wave;
            if (is_custom) *is_custom = 1;
            return 1;
        }
    const char *p = tok;
    int semi = mu_letter_semitone(*p);
    if (semi < 0)
        return -1;
    p++;
    if (*p == '#') { semi++; p++; }
    else if (*p == 'b') { semi--; p++; }
    if (*p < '0' || *p > '9')
        return -1;
    int oct = 0;
    while (*p >= '0' && *p <= '9') { oct = oct * 10 + (*p - '0'); p++; }
    if (*p) return -1;                       /* 尾部多余字符 */
    int midi = (oct + 1) * 12 + semi;        /* C4 = 60 */
    *freq = 440.0 * pow(2.0, (midi - 69) / 12.0);
    *wave = 0;
    if (is_custom) *is_custom = 0;
    return 1;
}


Value rt_mu_note(Value namev, Value freqv, Value wavev)
{
    const char *t = rt_str_of(namev);
    if (!*t || strlen(t) >= 16)
        mu_die("音.音：名字长度须为 1..15");
    if (!strcmp(t, ".") || !strcmp(t, "_") || !strcmp(t, "r"))
        mu_die("音.音：. _ r 是保留的休止符，不能当音符名");
    double f = mu_num(freqv, "音.音 的频率");
    long long w = 0;
    if (IS_INT(wavev) || IS_BIGINT(wavev) || IS_FLT(wavev))
        w = rt_to_ll(wavev);
    if (f <= 0.0 || f > 30000.0)
        mu_die("音.音：频率须在 1..30000");
    MuNote *slot = NULL;
    for (int i = 0; i < mu_nnotes; i++)
        if (!strcmp(mu_notes[i].name, t)) { slot = &mu_notes[i]; break; }
    if (!slot) {
        if (mu_nnotes >= 256)
            mu_die("音.音：自定义音符已满（256 个）");
        slot = &mu_notes[mu_nnotes++];
        memset(slot->name, 0, sizeof slot->name);
        strncpy(slot->name, t, 15);
    }
    slot->freq = f;
    slot->wave = (int)w;
    return rt_none();
}

/* 把乐谱列表渲染成混合 PCM float 缓冲（调用方 free）；写样本数到 *nsamp */
static float *mu_raster(Value rows, double beat_ms, size_t *nsamp, int *ntracks_out)
{
    if (!IS_LIST(rows) || AS_LIST(rows) == NULL)
        mu_die("音.奏/谱 需要列表（一行字符串一条音轨）");
    RtList *L = AS_LIST(rows);
    if (L->len == 0 || L->len > 256)
        mu_die("音轨数须为 1..256");
    if (beat_ms <= 0)
        beat_ms = 1;
    double spb = beat_ms / 1000.0 * MU_SR;          /* 每拍样本数 */

    /* 第一遍：算总拍数（取最长音轨） */
    double max_beats = 0;
    for (size_t i = 0; i < L->len; i++) {
        const char *row = rt_str_of(L->items[i]);
        double beats = 0;
        size_t j = 0;
        while (row[j]) {
            while (row[j] == ' ') j++;
            if (!row[j]) break;
            char tok[32]; size_t t = 0;
            while (row[j] && row[j] != ' ' && t < 31) tok[t++] = row[j++];
            while (row[j] && row[j] != ' ') j++;
            tok[t] = '\0';
            double dur = 1;
            char *colon = strchr(tok, ':');
            if (colon) { *colon = '\0'; dur = atof(colon + 1); if (dur <= 0) dur = 1; }
            beats += dur;
        }
        if (beats > max_beats) max_beats = beats;
    }
    if (max_beats <= 0)
        mu_die("乐谱里没有任何音符（每行至少一个 token，如 C4；. _ r 是休止）");
    size_t total = (size_t)(max_beats * spb) + 1;
    float *mix = (float *)calloc(total, sizeof(float));
    if (!mix)
        mu_die("音：内存不足");

    int ntracks = 0;
    for (size_t i = 0; i < L->len; i++) {
        const char *row = rt_str_of(L->items[i]);
        size_t j = 0;
        double cursor = 0;          /* 样本游标 */
        int had = 0;
        while (row[j]) {
            while (row[j] == ' ') j++;
            if (!row[j]) break;
            char tok[32]; size_t t = 0;
            while (row[j] && row[j] != ' ' && t < 31) tok[t++] = row[j++];
            while (row[j] && row[j] != ' ') j++;
            tok[t] = '\0';
            double dur = 1;
            char *colon = strchr(tok, ':');
            if (colon) { *colon = '\0'; dur = atof(colon + 1); if (dur <= 0) dur = 1; }

            if (!strcmp(tok, ".") || !strcmp(tok, "_") || !strcmp(tok, "r")
                || !strcmp(tok, "R")) {
                cursor += dur * spb;
                continue;
            }
            double fr = 0; int wv = 0; int custom = 0;
            if (mu_parse_note2(tok, &fr, &wv, &custom) < 0)
                mu_die("音.奏：不认识的音符 '%s'（音.音 可自定义；. _ r 是休止）", tok);
            had = 1;
            const MuInstr *ins = mu_cur_instr();
            MuEnv env = mu_cur_env(ins);
            int    wave = custom ? wv      : ins->wave;
            double h2   = custom ? 0.0     : ins->h2;
            double h3   = custom ? 0.0     : ins->h3;
            double dur_ms = dur * beat_ms;
            size_t ns = (size_t)(dur * spb);
            for (size_t k = 0; k < ns && (size_t)(cursor + (double)k) < total; k++) {
                double pos = cursor + (double)k;
                double ph = MU_TAU * fr * pos / MU_SR;
                /* 包络的时间必须是「音内相对时间」，不是全曲绝对时间：
                 * 用 pos 算的话，除第一个音外 t 都 >= dur_ms，
                 * mu_env_gain 直接判 0 —— 整首只剩开头一个音在响。 */
                double t  = 1000.0 * (double)k / (double)MU_SR;
                unsigned st = (unsigned)(fr * 977.0 + (double)k * 31.0);
                double v = mu_wave(ph, wave, &st);
                if (h2 > 0.0) v += h2 * mu_wave(ph * 2.0, wave, &st);
                if (h3 > 0.0) v += h3 * mu_wave(ph * 3.0, wave, &st);
                v *= mu_env_gain(t, dur_ms, env);
                size_t idx = (size_t)pos;
                if (idx < total) mix[idx] += (float)v;
            }
            cursor += dur * spb;
        }
        if (had) ntracks++;
    }
    *nsamp = total;
    if (ntracks_out) *ntracks_out = ntracks;
    return mix;
}

/* 写 16-bit PCM 单声道 WAV（含中文路径：UTF-8 → 宽字符） */
static void mu_write_wav(const char *name, const short *pcm, size_t n)
{
    FILE *fp = NULL;
#ifdef _WIN32
    wchar_t wn[1024];
    if (MultiByteToWideChar(CP_UTF8, 0, name, -1, wn, 1024) > 0)
        fp = _wfopen(wn, L"wb");
#endif
    if (!fp)
        fp = fopen(name, "wb");
    if (!fp)
        mu_die("音.奏：无法写 %s", name);
    unsigned char h[44];
    memset(h, 0, 44);
    unsigned int dataBytes = (unsigned int)(n * 2);
    unsigned int riff = dataBytes + 36;
    memcpy(h, "RIFF", 4);
    h[4] = riff & 0xFF; h[5] = (riff >> 8) & 0xFF; h[6] = (riff >> 16) & 0xFF; h[7] = (riff >> 24) & 0xFF;
    memcpy(h + 8, "WAVE", 4);
    memcpy(h + 12, "fmt ", 4);
    h[16] = 16;
    h[20] = 1;                         /* PCM */
    h[22] = 1;                         /* 单声道 */
    unsigned int sr = MU_SR;
    h[24] = sr & 0xFF; h[25] = (sr >> 8) & 0xFF; h[26] = (sr >> 16) & 0xFF; h[27] = (sr >> 24) & 0xFF;
    unsigned int bps = sr * 2;
    h[28] = bps & 0xFF; h[29] = (bps >> 8) & 0xFF; h[30] = (bps >> 16) & 0xFF; h[31] = (bps >> 24) & 0xFF;
    h[32] = 2;                         /* block align */
    h[34] = 16;                        /* bits */
    memcpy(h + 36, "data", 4);
    h[40] = dataBytes & 0xFF; h[41] = (dataBytes >> 8) & 0xFF; h[42] = (dataBytes >> 16) & 0xFF; h[43] = (dataBytes >> 24) & 0xFF;
    fwrite(h, 1, 44, fp);
    fwrite(pcm, 2, n, fp);
    fclose(fp);
}

/* 乐谱 → 16-bit PCM：峰值归一到 0.7 再乘主音量比例（默认比例 1.0 = 改动前的行为）。
 * 调用方 free。音.奏 / 音.谱 共用，消除原来那段逐字重复。 */
static short *mu_mix_pcm(Value rows, double bpm, size_t *n_out)
{
    if (bpm < 20.0) bpm = 20.0;
    if (bpm > 400.0) bpm = 400.0;
    double beat_ms = 60000.0 / bpm;

    size_t n; int nt;
    float *mix = mu_raster(rows, beat_ms, &n, &nt);
    if (n == 0) { free(mix); *n_out = 0; return NULL; }
    short *pcm = (short *)malloc(n * sizeof(short));
    if (!pcm) { free(mix); mu_die("音：内存不足"); }

    float peak = 0;
    for (size_t i = 0; i < n; i++) {
        float v = (mix[i] < 0) ? -mix[i] : mix[i];
        if (v > peak) peak = v;
    }
    float g = (peak > 0) ? (0.7f * (float)mu_vol_scale() / peak) : 0.0f;
    for (size_t i = 0; i < n; i++) {
        float v = mix[i] * g;
        if (v > 1) v = 1;
        if (v < -1) v = -1;
        pcm[i] = (short)(v * 32767.0f);
    }
    free(mix);
    *n_out = n;
    return pcm;
}

/* 列表 → 落盘 WAV（类比 mm.draw_away 落盘 PNG） */
Value rt_mu_away(Value rows, Value filev, Value bpmv)
{
    double bpm = mu_num(bpmv, "速度");
    size_t n = 0;
    short *pcm = mu_mix_pcm(rows, bpm, &n);
    if (!pcm) return rt_none();
    const char *name = rt_str_of(filev);
    mu_write_wav(name, pcm, n);
    free(pcm);
    return rt_str(name);
}

/* 列表 → 即时播放（阻塞；类比不想落盘、直接听） */
Value rt_mu_play_list(Value rows, Value bpmv)
{
    double bpm = mu_num(bpmv, "速度");
    size_t n = 0;
    short *pcm = mu_mix_pcm(rows, bpm, &n);
    if (!pcm) return rt_none();

    HWAVEOUT h = NULL;
    WAVEFORMATEX fmt;
    memset(&fmt, 0, sizeof fmt);
    fmt.wFormatTag = WAVE_FORMAT_PCM;
    fmt.nChannels = 1;
    fmt.nSamplesPerSec = MU_SR;
    fmt.wBitsPerSample = 16;
    fmt.nBlockAlign = 2;
    fmt.nAvgBytesPerSec = MU_SR * 2;
    if (waveOutOpen(&h, WAVE_MAPPER, &fmt, 0, 0, CALLBACK_NULL) != MMSYSERR_NOERROR) {
        free(pcm);
        return rt_none();   /* 无音频设备：静默跳过 */
    }
    WAVEHDR hdr;
    memset(&hdr, 0, sizeof hdr);
    hdr.lpData = (LPSTR)pcm;
    hdr.dwBufferLength = (DWORD)(n * sizeof(short));
    waveOutPrepareHeader(h, &hdr, sizeof hdr);
    waveOutWrite(h, &hdr, sizeof hdr);
    while (!(hdr.dwFlags & WHDR_DONE))
        Sleep(1);
    waveOutUnprepareHeader(h, &hdr, sizeof hdr);
    waveOutClose(h);
    free(pcm);
    return rt_none();
}

/* ---- 出口 ---- */

/* 音.音量(音量)：设主音量 0..100，返回生效值 */
Value rt_mu_volume_set(Value v)
{
    double x = mu_num(v, "音.音量 的音量");
    if (x < 0.0) x = 0.0;
    if (x > 100.0) x = 100.0;
    g_mu_volume = x;
    /* 已经开着的背景音乐跟着走 */
    mu_apply_bg_volume();
    return rt_float(x);
}

/* 音.包络(攻击ms, 衰减ms, 延音0到1, 松开ms)：设全局 ADSR */
Value rt_mu_env_set(Value av, Value dv, Value sv, Value rv)
{
    MuEnv e;
    e.a = mu_num(av, "音.包络 的攻击");
    e.d = mu_num(dv, "音.包络 的衰减");
    e.s = mu_num(sv, "音.包络 的延音");
    e.r = mu_num(rv, "音.包络 的松开");
    if (e.a < 0.0) e.a = 0.0;
    if (e.d < 0.0) e.d = 0.0;
    if (e.r < 0.0) e.r = 0.0;
    if (e.s < 0.0) e.s = 0.0;
    if (e.s > 1.0) e.s = 1.0;
    g_mu_env = e;
    /* 全默认参数 = 「撤销覆盖」，让乐器回到自带包络。
       否则一旦调过 音.包络，乐器的包络就永久失效、没法回退。 */
    g_mu_env_set = (e.a > 0.0 || e.d > 0.0 || e.r > 0.0 || e.s < 1.0) ? 1 : 0;
    return rt_none();
}

/* 音.包络值(时刻ms, 总长ms)：查包络增益 0..1（纯计算，可断言，不碰声卡） */
Value rt_mu_env_at(Value tv, Value lv)
{
    double t = mu_num(tv, "音.包络值 的时刻");
    double total = mu_num(lv, "音.包络值 的总长");
    const MuInstr *ins = mu_cur_instr();
    return rt_float(mu_env_gain(t, total, mu_cur_env(ins)));
}

/* 音.乐器(名)：选当前乐器，返回生效的乐器名 */
Value rt_mu_instr_set(Value namev)
{
    const char *t = rt_str_of(namev);
    for (int i = 0; i < MU_NINSTR; i++)
        if (!strcmp(mu_instrs[i].name, t)) {
            g_mu_instr_idx = i;
            return rt_str(mu_instrs[i].name);
        }
    /* 没说清有哪些乐器时，把可选值直接列出来，省得回去翻文档 */
    char buf[512]; size_t p = 0; buf[0] = '\0';
    for (int i = 0; i < MU_NINSTR; i++) {
        const char *nm = mu_instrs[i].name;
        size_t l = strlen(nm);
        if (p + l + 3 >= sizeof buf) break;
        memcpy(buf + p, nm, l); p += l;
        buf[p++] = (i + 1 < MU_NINSTR) ? '|' : '\0';
    }
    mu_die("音.乐器：没有叫「%s」的乐器。可选：%s", t, buf);
    return rt_none();
}

/* 音.乐器表()：返回全部预设乐器名 */
Value rt_mu_instr_list(void)
{
    Value out = rt_list_new();
    for (int i = 0; i < MU_NINSTR; i++)
        rt_push(&out, rt_str(mu_instrs[i].name));
    return out;
}

/* 音.演(音名或频率, 毫秒)：用当前乐器奏一个音 */
Value rt_mu_play_instr(Value nv, Value mv)
{
    double ms = mu_num(mv, "音.演 的时长");
    if (ms < 0.0) ms = 0.0;
    if (ms > 60000.0) ms = 60000.0;
    double fr = 0;
    int wv = 0, custom = 0;
    if (IS_INT(nv) || IS_BIGINT(nv) || IS_FLT(nv)) {
        fr = mu_num(nv, "音.演 的频率");
    } else {
        if (mu_parse_note2(rt_str_of(nv), &fr, &wv, &custom) < 0)
            mu_die("音.演：不认识的音符 '%s'（音.音 可自定义；也接受频率数字）",
                   rt_str_of(nv));
    }
    if (fr < 1.0) fr = 1.0;
    if (fr > 20000.0) fr = 20000.0;

    size_t n = (size_t)(MU_SR * ms / 1000.0);
    if (n == 0) return rt_none();
    short *pcm = (short *)malloc(n * sizeof(short));
    if (!pcm) mu_die("音：内存不足");

    const MuInstr *ins = mu_cur_instr();
    MuEnv env = mu_cur_env(ins);
    double amp = ins->amp * mu_vol_scale();
    if (amp > 1.0) amp = 1.0;
    /* 和 音.奏 保持一致：音.音 注册过的音符用它自己的波形，
     * 科学音名才吃当前乐器的波形与谐波。 */
    int    wave = custom ? wv  : ins->wave;
    double h2   = custom ? 0.0 : ins->h2;
    double h3   = custom ? 0.0 : ins->h3;
    unsigned st = (unsigned)(fr * 977.0 + n);
    for (size_t i = 0; i < n; i++) {
        double t  = 1000.0 * (double)i / (double)MU_SR;
        double ph = MU_TAU * fr * (double)i / (double)MU_SR;
        double v  = mu_wave(ph, wave, &st);
        if (h2 > 0.0) v += h2 * mu_wave(ph * 2.0, wave, &st);
        if (h3 > 0.0) v += h3 * mu_wave(ph * 3.0, wave, &st);
        double g = mu_edge_fade(i, n) * mu_env_gain(t, ms, env);
        pcm[i] = (short)(v * amp * 32767.0 * g);
    }

    HWAVEOUT h = NULL;
    WAVEFORMATEX fmt;
    memset(&fmt, 0, sizeof fmt);
    fmt.wFormatTag = WAVE_FORMAT_PCM;
    fmt.nChannels = 1;
    fmt.nSamplesPerSec = MU_SR;
    fmt.wBitsPerSample = 16;
    fmt.nBlockAlign = 2;
    fmt.nAvgBytesPerSec = MU_SR * 2;
    if (waveOutOpen(&h, WAVE_MAPPER, &fmt, 0, 0, CALLBACK_NULL) != MMSYSERR_NOERROR) {
        free(pcm);
        return rt_none();   /* 无音频设备：静默跳过 */
    }
    WAVEHDR hdr;
    memset(&hdr, 0, sizeof hdr);
    hdr.lpData = (LPSTR)pcm;
    hdr.dwBufferLength = (DWORD)(n * sizeof(short));
    waveOutPrepareHeader(h, &hdr, sizeof hdr);
    waveOutWrite(h, &hdr, sizeof hdr);
    while (!(hdr.dwFlags & WHDR_DONE))
        Sleep(1);
    waveOutUnprepareHeader(h, &hdr, sizeof hdr);
    waveOutClose(h);
    free(pcm);
    return rt_none();
}
