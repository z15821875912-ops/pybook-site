# -*- coding: utf-8 -*-
"""_colscan.py —— 按列/按行扫描 BMP 的颜色分段（UI 版式体检用）

为什么需要它：肉眼判断"这个面板到底盖到哪儿了"靠不住 ——
面板底色 (#12171F) 和窗底 (#0B0E14) 只差 7 级，缩略图上一片黑。
改布局更是最容易被"看着差不多"糊过去的地方。这一版 UI 视觉升级里，
就是靠它量出「分组面板高度取的是上一帧缓存」这个机制在多列布局下取错了值。

  python -B _colscan.py shots_look/ui_001.bmp --col 30 --y0:400
  python -B _colscan.py shots_look/ui_001.bmp --row 240 --x0:880
"""
import sys
import struct


def load(path):
    with open(path, 'rb') as f:
        data = f.read()
    if data[:2] != b'BM':
        raise SystemExit('不是 BMP：' + path)
    off = struct.unpack_from('<I', data, 10)[0]
    hsz = struct.unpack_from('<I', data, 14)[0]
    w = struct.unpack_from('<i', data, 18)[0]
    h = struct.unpack_from('<i', data, 22)[0]
    bpp = struct.unpack_from('<H', data, 28)[0]
    flip = h > 0                       # 自底向上
    h = abs(h)
    stride = ((w * bpp + 31) // 32) * 4
    return w, h, stride, data, off, flip, bpp


def px(w, h, stride, data, off, flip, bpp, x, y):
    row = (h - 1 - y) if flip else y
    o = off + row * stride + x * (bpp // 8)
    if bpp == 32:
        b, g, r = data[o], data[o + 1], data[o + 2]
    else:
        b, g, r = data[o], data[o + 1], data[o + 2]
    return '#%02X%02X%02X' % (r, g, b)


def runs(w, h, stride, data, off, flip, bpp, fixed, axis, lo, hi):
    out = []
    cur = None
    for i in range(lo, hi):
        x, y = (fixed, i) if axis == 'col' else (i, fixed)
        c = px(w, h, stride, data, off, flip, bpp, x, y)
        if cur and cur[2] == c and cur[1] + 1 == i:
            cur[1] = i
        else:
            if cur:
                out.append(cur)
            cur = [i, i, c]
    if cur:
        out.append(cur)
    return out


def main():
    args = sys.argv[1:]
    if not args:
        raise SystemExit(__doc__)
    path = args[0]
    w, h, stride, data, off, flip, bpp = load(path)
    axis = 'col'
    fixed = 0
    lo, hi = 0, (h if axis == 'col' else w)
    # PowerShell 5.1 会把 "--y0:400" 传成 "-y0:400"，所以这里按去横线后的
    # 前缀匹配，不去数横线有几个 —— 那属于命令行外壳的脾气，不是脚本该管的。
    for i, a in enumerate(args[1:], 1):
        t = a.lstrip('-')
        if t.startswith('col'):
            axis, fixed = 'col', int(args[i + 1])
        elif t.startswith('row'):
            axis, fixed = 'row', int(args[i + 1])
        elif t.startswith('x') and t[1:]:
            p = t[1:].split(':')
            lo, hi = int(p[0]), int(p[-1])
        elif t.startswith('y') and t[1:]:
            p = t[1:].split(':')
            lo, hi = int(p[0]), int(p[-1])
        elif t.startswith('h'):
            lo, hi = 0, (h if axis == 'col' else w)
    if axis == 'col':
        lo, hi = max(0, lo), min(h, hi + 1)
    else:
        lo, hi = max(0, lo), min(w, hi + 1)
    print('%s  %dx%d %dbpp  %s=%d  %s %d..%d' % (path, w, h, bpp, axis, fixed, 'y' if axis == 'col' else 'x', lo, hi))
    for a, b, c in runs(w, h, stride, data, off, flip, bpp, fixed, axis, lo, hi):
        print('  %4d..%-4d (%3d)  %s' % (a, b, b - a + 1, c))


if __name__ == '__main__':
    main()
