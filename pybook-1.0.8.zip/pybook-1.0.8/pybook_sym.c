/* ================= pybook_sym.c：符号数学实现 =================
 * 设计说明见 pybook_sym.h。核心层零运行时依赖；绑定层在
 * PYBOOK_RT_H / SYM_RT_BINDING 下编译（pybook_sym.h 负责引入 pybook_rt.h）。
 */
#include "pybook_sym.h"

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <math.h>
#include <ctype.h>

/* ==================== 致命错误（核心层没有 rt_die 时的兜底） ==================== */
#if !defined(PYBOOK_RT_H)
static void sym_fatal(const char *msg)
{
    fprintf(stderr, "sym: %s\n", msg);
    exit(1);
}
#define SYM_DIE(msg) sym_fatal(msg)
#else
#define SYM_DIE(msg) rt_die("%s", msg)
#endif

/* ==================== arena ==================== */

typedef struct ABlock {
    struct ABlock *next;
    size_t used, cap;
} ABlock;

typedef struct {
    ABlock *head;
} Arena;

#define SYM_BLOCK (64 * 1024)

static void *ar_alloc(Arena *ar, size_t n)
{
    n = (n + 15u) & ~(size_t)15u;
    if (!ar->head || ar->head->used + n > ar->head->cap) {
        size_t cap = SYM_BLOCK;
        ABlock *b;
        if (cap < n) cap = n;
        b = (ABlock *)malloc(sizeof(ABlock) + cap);
        if (!b) SYM_DIE("内存不足");
        b->next = ar->head;
        b->used = 0;
        b->cap = cap;
        ar->head = b;
    }
    {
        void *p = (char *)(ar->head + 1) + ar->head->used;
        ar->head->used += n;
        return p;
    }
}

static char *ar_strdup(Arena *ar, const char *s, size_t n)
{
    char *p = (char *)ar_alloc(ar, n + 1);
    memcpy(p, s, n);
    p[n] = 0;
    return p;
}

static void ar_free(Arena *ar)
{
    ABlock *b = ar->head;
    while (b) {
        ABlock *nx = b->next;
        free(b);
        b = nx;
    }
    ar->head = NULL;
}

/* ==================== AST ==================== */

enum {
    N_NUM, N_VAR, N_CONST,
    N_ADD, N_SUB, N_MUL, N_DIV, N_POW,
    N_NEG, N_FUNC
};

typedef struct Node Node;
struct Node {
    int kind;
    double num;   /* N_NUM 的值 */
    char *str;    /* N_VAR/N_CONST 的名字；N_FUNC 的函数名 */
    Node *a, *b;
};

/* 函数表：下标即函数 id，渲染与查表共用 */
static const char *SYM_FUNCS[] = {
    "sin", "cos", "tan", "asin", "acos", "atan",
    "sinh", "cosh", "tanh", "exp", "log", "sqrt", "abs",
    NULL
};
enum { F_SIN = 0, F_COS, F_TAN, F_ASIN, F_ACOS, F_ATAN,
       F_SINH, F_COSH, F_TANH, F_EXP, F_LOG, F_SQRT, F_ABS };

static int fn_id(const char *name)
{
    int i;
    for (i = 0; SYM_FUNCS[i]; i++)
        if (strcmp(name, SYM_FUNCS[i]) == 0) return i;
    if (strcmp(name, "ln") == 0) return F_LOG;   /* ln 是 log 的别名 */
    return -1;
}

static Node *nd(Arena *ar, int kind)
{
    Node *n = (Node *)ar_alloc(ar, sizeof(Node));
    n->kind = kind;
    n->num = 0;
    n->str = NULL;
    n->a = n->b = NULL;
    return n;
}
static Node *nd_num(Arena *ar, double v) { Node *n = nd(ar, N_NUM); n->num = v; return n; }
static Node *nd_named(Arena *ar, int kind, const char *s)
{
    Node *n = nd(ar, kind);
    n->str = ar_strdup(ar, s, strlen(s));
    return n;
}
static Node *nd_bin(Arena *ar, int kind, Node *a, Node *b)
{
    Node *n = nd(ar, kind);
    n->a = a;
    n->b = b;
    return n;
}
static Node *nd_neg(Arena *ar, Node *a) { return nd_bin(ar, N_NEG, a, NULL); }
static Node *nd_fn(Arena *ar, int fid, Node *a)
{
    Node *n = nd(ar, N_FUNC);
    n->str = ar_strdup(ar, SYM_FUNCS[fid], strlen(SYM_FUNCS[fid]));
    n->a = a;
    return n;
}
static Node *nd_var(Arena *ar, const char *name)
{
    return nd_named(ar, N_VAR, name);
}

/* ==================== 字符串 builder ==================== */

typedef struct {
    char *p;
    size_t n, cap;
    int oom;
} SB;

static void sb_init(SB *b)
{
    b->cap = 128;
    b->p = (char *)malloc(b->cap);
    b->n = 0;
    b->oom = (b->p == NULL);
    if (b->p) b->p[0] = 0;
}
static void sb_put(SB *b, const char *s, size_t n)
{
    if (b->oom) return;
    if (b->n + n + 1 > b->cap) {
        size_t nc = b->cap * 2;
        char *np;
        while (nc < b->n + n + 1) nc *= 2;
        np = (char *)realloc(b->p, nc);
        if (!np) { b->oom = 1; return; }
        b->p = np;
        b->cap = nc;
    }
    memcpy(b->p + b->n, s, n);
    b->n += n;
    b->p[b->n] = 0;
}
static void sb_puts(SB *b, const char *s) { sb_put(b, s, strlen(s)); }
static void sb_putc(SB *b, char c) { sb_put(b, &c, 1); }

/* ==================== 渲染风格（plain / latex / unicode） ==================== */

typedef struct {
    const char *mul_sep;         /* 乘号：plain "*"｜latex " \cdot "｜unicode "·" */
    int frac;                    /* 1=DIV 出 \frac{a}{b}；0=plain a/b */
    int pow_brace;               /* 1=POW 出 x^{...}（LaTeX 指数恒上花括号） */
    int sup;                     /* 1=POW 整数指数出 unicode 上标（x²） */
    const char *sqrt_o, *sqrt_c; /* sqrt 包裹：plain "sqrt(" ")"｜latex "\sqrt{" "}"｜unicode "√(" ")" */
    const char *pi;              /* 常量名：plain "pi"｜latex "\pi"｜unicode "π" */
    int frac_num;                /* 1=数字折 \frac{a}{b}；0=fmt_num 原样 */
    int latex;                   /* 1=函数名映射（sin→\sin）、abs 出 \left| */
} RendStyle;

static const RendStyle ST_PLAIN = { "*", 0, 0, 0, "sqrt(", ")", "pi", 0, 0 };
static const RendStyle ST_LATEX = { " \\cdot ", 1, 1, 0, "\\sqrt{", "}", "\\pi", 1, 1 };
static const RendStyle ST_UNI   = { "·", 0, 0, 1, "√(", ")", "π", 0, 0 };

/* LaTeX 函数名映射（sqrt/abs 走专门分支，其余原名） */
static const char *fn_latex(const char *name)
{
    if (strcmp(name, "sin") == 0) return "\\sin";
    if (strcmp(name, "cos") == 0) return "\\cos";
    if (strcmp(name, "tan") == 0) return "\\tan";
    if (strcmp(name, "asin") == 0) return "\\arcsin";
    if (strcmp(name, "acos") == 0) return "\\arccos";
    if (strcmp(name, "atan") == 0) return "\\arctan";
    if (strcmp(name, "sinh") == 0) return "\\sinh";
    if (strcmp(name, "cosh") == 0) return "\\cosh";
    if (strcmp(name, "tanh") == 0) return "\\tanh";
    if (strcmp(name, "exp") == 0) return "\\exp";
    if (strcmp(name, "log") == 0) return "\\ln";
    return name;
}

/* unicode 上标数字：整数指数 → ⁰¹²³⁴⁵⁶⁷⁸⁹（负号 ⁻） */
static void sup_digits(SB *o, long long e)
{
    char dig[24];
    int n = 0, i;
    static const char *D[] = { "⁰", "¹", "²", "³", "⁴", "⁵", "⁶", "⁷", "⁸", "⁹" };
    if (e < 0) { sb_puts(o, "⁻"); e = -e; }
    if (e == 0) { sb_puts(o, D[0]); return; }
    while (e > 0 && n < 20) { dig[n++] = (char)('0' + (int)(e % 10)); e /= 10; }
    for (i = n - 1; i >= 0; i--) sb_puts(o, D[dig[i] - '0']);
}

/* 风格化数字：plain 与 fmt_num 逐字一致；latex 把 0<|v|<1 的小分母折成 \frac{a}{b} */
static void fmt_num_st(double v, char *buf, size_t sz, const RendStyle *st)
{
    static const int dens[] = { 2, 3, 4, 5, 6, 8, 10, 12 };
    double a;
    int d, k;
    if (v == 0) v = 0;                      /* 归一化 -0 */
    a = fabs(v);
    if (a > 0 && a < 1) {
        for (k = 0; k < (int)(sizeof dens / sizeof *dens); k++) {
            d = dens[k];
            if (fabs(a * d - floor(a * d + 0.5)) < 1e-9) {
                if (st->frac_num)
                    snprintf(buf, sz, "%s\\frac{%d}{%d}", v < 0 ? "-" : "",
                             (int)floor(a * d + 0.5), d);
                else
                    snprintf(buf, sz, "%s%d/%d", v < 0 ? "-" : "",
                             (int)floor(a * d + 0.5), d);
                return;
            }
        }
    }
    if (fabs(v) == floor(fabs(v)) && fabs(v) < 1e15)
        snprintf(buf, sz, "%.0f", v);
    else
        snprintf(buf, sz, "%.10g", v);
}

/* ==================== 解析器 ==================== */

typedef struct {
    const char *s;
    size_t i;
    Arena *ar;
    char err[192];
    int bad;
    int depth;
} P;

static size_t char_pos(const char *s, size_t byte)
{
    size_t k = 0, j;
    for (j = 0; j < byte; j++)
        if (((unsigned char)s[j] & 0xC0) != 0x80) k++;
    return k + 1;
}

static void perr(P *p, size_t at, const char *why, const char *fix)
{
    if (!p->bad) {
        /* 三段式（与运行时错误同款排版）：问题行 + 为什么 + 怎么改，各占一行 */
        snprintf(p->err, sizeof p->err,
                 "第 %zu 个字符处公式不合语法\n  为什么：%s\n  怎么改：%s",
                 char_pos(p->s, at), why, fix);
        p->bad = 1;
    }
}

static void skipws(P *p)
{
    while (p->s[p->i] == ' ' || p->s[p->i] == '\t' ||
           p->s[p->i] == '\n' || p->s[p->i] == '\r')
        p->i++;
}

static int is_name_start(unsigned char c)
{
    return isalpha(c) || c == '_' || c >= 0x80;
}
static int is_name_char(unsigned char c)
{
    return isalnum(c) || c == '_' || c >= 0x80;
}

static int is_ident(const char *s)
{
    size_t i;
    if (!s || !*s || !is_name_start((unsigned char)s[0])) return 0;
    for (i = 1; s[i]; i++)
        if (!is_name_char((unsigned char)s[i])) return 0;
    return 1;
}

static int is_const_name(const char *s)
{
    return strcmp(s, "pi") == 0 || strcmp(s, "π") == 0 || strcmp(s, "e") == 0;
}

static Node *parse_expr(P *p);
static Node *parse_power(P *p);

static Node *parse_atom(P *p)
{
    size_t st;
    char c;
    skipws(p);
    st = p->i;
    c = p->s[p->i];

    if (c == '(') {
        Node *e;
        p->i++;
        e = parse_expr(p);
        if (p->bad) return NULL;
        skipws(p);
        if (p->s[p->i] != ')') {
            perr(p, p->i, "括号开了没合上", "数一数左右括号，要成对");
            return NULL;
        }
        p->i++;
        return e;
    }
    if (isdigit((unsigned char)c) ||
        (c == '.' && isdigit((unsigned char)p->s[p->i + 1]))) {
        char *end = NULL;
        double v = strtod(p->s + p->i, &end);
        if (end == p->s + p->i) {
            perr(p, p->i, "这个数字看不懂", "检查是不是多写了小数点或字母");
            return NULL;
        }
        p->i = (size_t)(end - p->s);
        return nd_num(p->ar, v);
    }
    if (is_name_start((unsigned char)c)) {
        char buf[64];
        size_t n = 0;
        for (;;) {
            unsigned char ch = (unsigned char)p->s[st + n];
            /* 全角区 U+FF00–U+FFEF（全角括号/逗号/加减乘除/数字…）一律拦下 */
            if (ch == 0xEF && ((unsigned char)p->s[st + n + 1] == 0xBC ||
                               (unsigned char)p->s[st + n + 1] == 0xBD)) {
                perr(p, st + n, "公式里有全角符号",
                     "全角（），，＋－＊／＾ 都要换成半角：( ) , . + - * / ^");
                return NULL;
            }
            if (!is_name_char(ch)) break;
            n++;
        }
        if (n >= sizeof buf) {
            perr(p, st, "名字太长了", "变量名短一点（64 字节以内）");
            return NULL;
        }
        memcpy(buf, p->s + st, n);
        buf[n] = 0;
        p->i = st + n;

        if (strcmp(buf, "pi") == 0 || strcmp(buf, "π") == 0)
            return nd_named(p->ar, N_CONST, "pi");
        if (strcmp(buf, "e") == 0)
            return nd_named(p->ar, N_CONST, "e");
        if (strcmp(buf, "√") == 0) {
            /* 根号：√(x+1) 整括，或 √x 作用于紧随的原子/幂 */
            Node *arg;
            skipws(p);
            if (p->s[p->i] == '(') {
                p->i++;
                arg = parse_expr(p);
                if (p->bad) return NULL;
                skipws(p);
                if (p->s[p->i] != ')') {
                    perr(p, p->i, "√ 后面的括号开了没合上", "写成 √(x + 1) 整括起来");
                    return NULL;
                }
                p->i++;
            } else {
                arg = parse_power(p);
                if (p->bad) return NULL;
            }
            return nd_fn(p->ar, F_SQRT, arg);
        }
        skipws(p);
        if (p->s[p->i] == '(') {
            int id = fn_id(buf);
            Node *arg;
            if (id < 0) {
                perr(p, st, "不认识的函数",
                     "v1 支持：sin cos tan asin acos atan sinh cosh tanh exp log(=ln) sqrt abs");
                return NULL;
            }
            p->i++;
            arg = parse_expr(p);
            if (p->bad) return NULL;
            skipws(p);
            if (p->s[p->i] != ')') {
                perr(p, p->i, "函数的括号开了没合上", "每次调用都要写成 名(参数) 成对括号");
                return NULL;
            }
            p->i++;
            return nd_fn(p->ar, id, arg);
        }
        return nd_var(p->ar, buf);
    }
    perr(p, p->i, "看不懂这里",
         "公式里可以有：数字、变量、+ - * / ^、括号、pi/e，以及已支持的函数");
    return NULL;
}

static Node *parse_unary(P *p)
{
    skipws(p);
    if (p->s[p->i] == '-') {
        Node *a;
        p->i++;
        a = parse_unary(p);
        return p->bad ? NULL : nd_neg(p->ar, a);
    }
    if (p->s[p->i] == '+') {
        p->i++;
        return parse_unary(p);
    }
    return parse_power(p);
}

static Node *parse_power(P *p)
{
    Node *base = parse_atom(p);
    if (p->bad) return NULL;
    skipws(p);
    if (p->s[p->i] == '^') {
        Node *ex;
        p->i++;
        ex = parse_unary(p);          /* 右结合，且允许负指数 2^-1 */
        if (p->bad) return NULL;
        return nd_bin(p->ar, N_POW, base, ex);
    }
    return base;
}

static Node *parse_term(P *p)
{
    Node *a = parse_unary(p);
    if (p->bad) return NULL;
    for (;;) {
        char c;
        skipws(p);
        c = p->s[p->i];
        if (c == '*' || c == '/') {
            Node *b;
            p->i++;
            b = parse_unary(p);
            if (p->bad) return NULL;
            a = nd_bin(p->ar, c == '*' ? N_MUL : N_DIV, a, b);
        } else {
            break;
        }
    }
    return a;
}

static Node *parse_expr(P *p)
{
    Node *a;
    if (++p->depth > 128) {
        perr(p, p->i, "括号套得太深了", "拆成几步算，用 sym.替换 分步代入");
        p->depth--;
        return NULL;
    }
    a = parse_term(p);
    if (p->bad) { p->depth--; return NULL; }
    for (;;) {
        char c;
        skipws(p);
        c = p->s[p->i];
        if (c == '+' || c == '-') {
            Node *b;
            p->i++;
            b = parse_term(p);
            if (p->bad) { p->depth--; return NULL; }
            a = nd_bin(p->ar, c == '+' ? N_ADD : N_SUB, a, b);
        } else {
            break;
        }
    }
    p->depth--;
    return a;
}

static Node *parse_full(P *p, const char *expr)
{
    Node *n;
    p->s = expr;
    p->i = 0;
    p->bad = 0;
    p->depth = 0;
    p->err[0] = 0;
    skipws(p);
    if (!p->s[p->i]) {
        perr(p, p->i, "空表达式", "写成像 \"x^2 + 1\" 这样再来");
        return NULL;
    }
    n = parse_expr(p);
    if (p->bad) return NULL;
    skipws(p);
    if (p->s[p->i]) {
        perr(p, p->i, "表达式后面有多余的内容", "看看是不是多了符号、漏了运算符（乘号 * 不能省）");
        return NULL;
    }
    return n;
}

/* ==================== 渲染（漂亮打印） ==================== */

static int prec_of(int k)
{
    switch (k) {
    case N_ADD: case N_SUB: return 1;
    case N_MUL: case N_DIV: case N_NEG: return 2;
    case N_POW: return 3;
    default: return 4;
    }
}

static void rend_inner(SB *o, Node *n, const RendStyle *st);

/* pp=父优先级；right=是否为父节点的右操作数 */
static void rend(SB *o, Node *n, int pp, int right, const RendStyle *st)
{
    int need = 0;
    if (n) {
        int cp = prec_of(n->kind);
        if (cp < pp) need = 1;
        else if (cp == pp && right && n->kind != N_POW) need = 1;  /* POW 右结合 */
        if (pp == 3 && !right && cp == 3) need = 1;                /* POW 的左子同级要括号 */
    }
    if (need) sb_putc(o, '(');
    rend_inner(o, n, st);
    if (need) sb_putc(o, ')');
}

/* 加法/减法的右操作数：负项渲染成减法 */
static void rend_sum_rhs(SB *o, Node *b, int sub, const RendStyle *st)
{
    int neg = 0;
    Node *core = b;
    char buf[40];
    if (b->kind == N_NUM && b->num < 0) neg = 1;
    else if (b->kind == N_NEG) { neg = 1; core = b->a; }
    /* 父op(+/-) 与 右子符号(-) 异号 → " - "，同号 → " + "
     * neg=0,sub=0 → " + "；neg=1,sub=0 → " - "；neg=0,sub=1 → " - "；neg=1,sub=1 → " + " */
    sb_puts(o, (neg != sub) ? " - " : " + ");
    if (core->kind == N_NUM) {
        fmt_num_st(fabs(core->num), buf, sizeof buf, st);
        sb_puts(o, buf);
    } else {
        rend(o, core, 2, 0, st);
    }
}

/* 乘法：乘链扁平化 + 负因子按奇偶前置成 '-' + 数字系数排最前
 * MUL(MUL(2,x),cos(x^2)) → 2*x*cos(x^2)（不再出现 2*(x*cos(x^2))） */
static void mul_collect(Node *n, Node **fa, int *cnt, int cap, int *negc)
{
    if (*cnt >= cap - 1) { fa[(*cnt)++] = n; return; }   /* 超容量：原样当因子 */
    if (n->kind == N_MUL) {
        mul_collect(n->a, fa, cnt, cap, negc);
        mul_collect(n->b, fa, cnt, cap, negc);
        return;
    }
    if (n->kind == N_NEG) { (*negc)++; mul_collect(n->a, fa, cnt, cap, negc); return; }
    if (n->kind == N_NUM && n->num < 0) (*negc)++;
    fa[(*cnt)++] = n;
}

static void rend_mul(SB *o, Node *n, int extra_neg, const RendStyle *st)
{
    Node *fa[24], *ord[24];
    int cnt = 0, negc = extra_neg, k, m = 0, numi = -1;
    char buf[40];
    mul_collect(n, fa, &cnt, 24, &negc);
    for (k = 0; k < cnt; k++)
        if (fa[k]->kind == N_NUM) { numi = k; break; }
    if (numi >= 0) ord[m++] = fa[numi];
    for (k = 0; k < cnt; k++)
        if (k != numi) ord[m++] = fa[k];
    if (negc & 1) sb_putc(o, '-');
    for (k = 0; k < m; k++) {
        Node *c = ord[k];
        if (k) sb_puts(o, st->mul_sep);
        if (c->kind == N_NUM) {
            fmt_num_st(fabs(c->num), buf, sizeof buf, st);   /* 符号已由负计数前置 */
            sb_puts(o, buf);
        } else {
            rend(o, c, 2, k > 0, st);
        }
    }
}

static void rend_inner(SB *o, Node *n, const RendStyle *st)
{
    char buf[40];
    switch (n->kind) {
    case N_NUM:
        fmt_num_st(n->num, buf, sizeof buf, st);
        sb_puts(o, buf);
        break;
    case N_CONST:
    case N_VAR:
        sb_puts(o, (n->kind == N_CONST && strcmp(n->str, "pi") == 0) ? st->pi : n->str);
        break;
    case N_FUNC: {
        int fid = fn_id(n->str);
        if (fid == F_SQRT) {
            sb_puts(o, st->sqrt_o);
            rend(o, n->a, 0, 0, st);
            sb_puts(o, st->sqrt_c);
        } else if (fid == F_ABS && st->latex) {
            sb_puts(o, "\\left|");
            rend(o, n->a, 0, 0, st);
            sb_puts(o, "\\right|");
        } else {
            sb_puts(o, st->latex ? fn_latex(n->str) : n->str);
            sb_putc(o, '(');
            rend(o, n->a, 0, 0, st);
            sb_putc(o, ')');
        }
        break;
    }
    case N_NEG:
        if (n->a->kind == N_MUL) {
            rend_mul(o, n->a, 1, st);   /* -(x*cos(x)) → -x*cos(x)：乘链无需括号 */
        } else {
            sb_putc(o, '-');
            rend(o, n->a, 2, 1, st);
        }
        break;
    case N_ADD:
        rend(o, n->a, 1, 0, st);
        rend_sum_rhs(o, n->b, 0, st);
        break;
    case N_SUB:
        rend(o, n->a, 1, 0, st);
        rend_sum_rhs(o, n->b, 1, st);
        break;
    case N_MUL:
        rend_mul(o, n, 0, st);
        break;
    case N_DIV:
        if (st->frac) {
            sb_puts(o, "\\frac{");
            rend(o, n->a, 1, 0, st);
            sb_puts(o, "}{");
            rend(o, n->b, 1, 0, st);
            sb_putc(o, '}');
        } else {
            rend(o, n->a, 2, 0, st);
            sb_putc(o, '/');
            rend(o, n->b, 2, 1, st);
        }
        break;
    case N_POW:
        rend(o, n->a, 3, 0, st);
        if (st->pow_brace) {                 /* LaTeX：指数恒上花括号 */
            sb_puts(o, "^{");
            rend(o, n->b, 0, 0, st);
            sb_putc(o, '}');
            break;
        }
        if (st->sup) {                       /* unicode：整数指数换上标（含负） */
            double e = 0;
            int hav = 0;
            if (n->b->kind == N_NUM) { e = n->b->num; hav = 1; }
            else if (n->b->kind == N_NEG && n->b->a->kind == N_NUM) { e = -n->b->a->num; hav = 1; }
            if (hav && e == floor(e) && fabs(e) < 1e9) {
                sup_digits(o, (long long)e);
                break;
            }
        }
        sb_putc(o, '^');
        /* 指数是常数且渲染出来含 '/' 或以 '-' 开头 → 括号：x^(-2)、x^(1/2) */
        if (n->b->kind == N_NUM) {
            fmt_num_st(n->b->num, buf, sizeof buf, st);
            if (strchr(buf, '/') || buf[0] == '-') {
                sb_putc(o, '(');
                sb_puts(o, buf);
                sb_putc(o, ')');
                break;
            }
            sb_puts(o, buf);
            break;
        }
        rend(o, n->b, 3, 1, st);
        break;
    default:
        sb_puts(o, "?");
        break;
    }
}

/* 规范串：同类项/同底合并的唯一键（带括号，无歧义） */
static char *canon(Node *n, Arena *ar)
{
    SB b;
    char *r;
    sb_init(&b);
    rend(&b, n, 0, 0, &ST_PLAIN);
    r = ar_strdup(ar, b.p ? b.p : "?", b.n);
    free(b.p);
    return r;
}

static char *render_malloc(Node *n)
{
    SB b;
    sb_init(&b);
    rend(&b, n, 0, 0, &ST_PLAIN);
    return b.p;
}

/* ==================== 结构工具 ==================== */

static int has_var(Node *n, const char *var)
{
    if (!n) return 0;
    if (n->kind == N_VAR) return strcmp(n->str, var) == 0;
    return has_var(n->a, var) || has_var(n->b, var);
}

/* 取常数数值：NUM 或 -NUM */
static int as_const_num(Node *n, double *v)
{
    if (n->kind == N_NUM) { *v = n->num; return 1; }
    if (n->kind == N_NEG && n->a->kind == N_NUM) { *v = -n->a->num; return 1; }
    return 0;
}

static void collect_add(Node *n, Node **ts, int *nt, int cap)
{
    if (n->kind == N_ADD) {
        collect_add(n->a, ts, nt, cap);
        collect_add(n->b, ts, nt, cap);
    } else if (*nt < cap) {
        ts[(*nt)++] = n;
    }
}

static void collect_mul(Node *n, Node **fs, int *nf, int cap)
{
    if (n->kind == N_MUL) {
        collect_mul(n->a, fs, nf, cap);
        collect_mul(n->b, fs, nf, cap);
    } else if (*nf < cap) {
        fs[(*nf)++] = n;
    }
}

static Node *build_sum(Arena *ar, Node **ts, int nt)
{
    Node *acc = NULL;
    int i;
    for (i = 0; i < nt; i++)
        acc = acc ? nd_bin(ar, N_ADD, acc, ts[i]) : ts[i];
    return acc;
}

static Node *build_prod(Arena *ar, Node **fs, int nf)
{
    Node *acc = NULL;
    int i;
    for (i = 0; i < nf; i++)
        acc = acc ? nd_bin(ar, N_MUL, acc, fs[i]) : fs[i];
    return acc;
}

/* ==================== 化简 ==================== */

static Node *simp(Arena *ar, Node *n);

/* SUB → ADD(a, -b) */
static void norm_sub(Arena *ar, Node *n)
{
    if (!n) return;
    norm_sub(ar, n->a);
    norm_sub(ar, n->b);
    if (n->kind == N_SUB) {
        n->kind = N_ADD;
        n->b = nd_neg(ar, n->b);
    }
}

/* 项的「度数」：变量幂次之和（排序用，高次在前） */
static int term_degree(Node *n)
{
    switch (n->kind) {
    case N_VAR: return 1;
    case N_POW: {
        double e;
        if (as_const_num(n->b, &e) && e >= 0 && e == floor(e))
            return term_degree(n->a) * (int)e;
        return term_degree(n->a);
    }
    case N_MUL: case N_DIV:
        return term_degree(n->a) + term_degree(n->b);
    case N_ADD: case N_SUB: case N_NEG: {
        int x = term_degree(n->a);
        int y = n->b ? term_degree(n->b) : 0;
        return x > y ? x : y;
    }
    case N_FUNC: return term_degree(n->a);
    default: return 0;
    }
}

typedef struct {
    double c;      /* 系数 */
    Node *rest;    /* 非常数部分 */
    int deg;       /* 度数，排序用 */
    char *key;     /* rest 的规范串 */
} TermX;

static int termx_cmp(const void *x, const void *y)
{
    const TermX *a = (const TermX *)x, *b = (const TermX *)y;
    if (a->deg != b->deg) return b->deg - a->deg;      /* 高次在前 */
    return strcmp(a->key, b->key);
}

static Node *simp_add(Arena *ar, Node *n)
{
    Node *terms[256];
    TermX tx[256];
    int nt = 0, nx = 0, i, j;
    double cst = 0;
    int has_cst = 0;

    collect_add(n, terms, &nt, 256);
    for (i = 0; i < nt; i++) {
        Node *t = terms[i];
        double c = 1;
        Node *rest = t;
        if (t->kind == N_NUM) { cst += t->num; has_cst = 1; continue; }
        if (t->kind == N_NEG) {
            double v;
            if (as_const_num(t->a, &v)) { cst -= v; has_cst = 1; continue; }
            c = -1;
            rest = t->a;
        } else if (t->kind == N_MUL) {
            double v;
            if (as_const_num(t->a, &v)) { c = v; rest = t->b; }
            else if (as_const_num(t->b, &v)) { c = v; rest = t->a; }
        }
        {   /* 合并同类项 */
            char *key = canon(rest, ar);
            int found = -1;
            for (j = 0; j < nx; j++)
                if (strcmp(tx[j].key, key) == 0) { found = j; break; }
            if (found >= 0) {
                tx[found].c += c;
            } else {
                tx[nx].c = c;
                tx[nx].rest = rest;
                tx[nx].deg = term_degree(rest);
                tx[nx].key = key;
                nx++;
            }
        }
    }
    if (nx > 1) qsort(tx, (size_t)nx, sizeof(TermX), termx_cmp);
    {   /* 重建：高次在前，常数垫底 */
        Node *out[256];
        int no = 0;
        for (i = 0; i < nx; i++) {
            double c = tx[i].c;
            Node *node;
            if (c == 0) continue;
            if (c == 1) node = tx[i].rest;
            else if (c == -1) node = nd_neg(ar, tx[i].rest);
            else if (c < 0) node = nd_neg(ar, nd_bin(ar, N_MUL, nd_num(ar, -c), tx[i].rest));
            else node = nd_bin(ar, N_MUL, nd_num(ar, c), tx[i].rest);
            out[no++] = node;
        }
        if (has_cst && cst != 0) out[no++] = nd_num(ar, cst);
        if (no == 0) return nd_num(ar, 0);
        return build_sum(ar, out, no);
    }
}

typedef struct {
    Node *base;
    double e;
    char *key;
    int rank;   /* 0=VAR 1=POW 2=其他 */
} FactorX;

static int factorx_cmp(const void *x, const void *y)
{
    const FactorX *a = (const FactorX *)x, *b = (const FactorX *)y;
    if (a->rank != b->rank) return a->rank - b->rank;
    return strcmp(a->key, b->key);
}

static int base_rank(Node *n)
{
    if (n->kind == N_VAR) return 0;
    if (n->kind == N_POW) return 1;
    return 2;
}

static Node *simp_mul(Arena *ar, Node *n)
{
    Node *fs[256];
    FactorX fx[256];
    int nf = 0, nx = 0, i, j;
    double p = 1;

    collect_mul(n, fs, &nf, 256);
    for (i = 0; i < nf; i++) {
        Node *f = fs[i];
        double v;
        Node *base = f;
        double e = 1;
        if (f->kind == N_NUM) { p *= f->num; continue; }
        if (f->kind == N_NEG) {
            double w;
            if (as_const_num(f->a, &w)) { p *= -w; continue; }
            p *= -1;
            base = f->a;
        }
        if (f->kind == N_DIV) {
            double vd;
            if (!as_const_num(f->b, &vd)) {
                /* 1/x → x^(-1) 参与合幂（x*(1/x) → 1）；x/(x+1) 整块当因子 */
                if (as_const_num(f->a, &vd)) { p *= vd; base = f->b; e = -1; }
                else base = f;
            }
            /* 常数分母（x/2）保持整块因子，保留 x/2 形态 */
        }
        if (base->kind == N_POW && as_const_num(base->b, &v)) {
            base = base->a;
            e *= v;                       /* *= 兼容 DIV(1,x^2) 递进来的 e=-1 */
            if (base->kind == N_NUM) { p *= pow(base->num, e); continue; }
        } else if (base->kind == N_NUM) {
            p *= base->num;
            continue;
        }
        {   /* 按 base 合并指数 */
            char *key = canon(base, ar);
            int found = -1;
            for (j = 0; j < nx; j++)
                if (strcmp(fx[j].key, key) == 0) { found = j; break; }
            if (found >= 0) {
                fx[found].e += e;
            } else {
                fx[nx].base = base;
                fx[nx].e = e;
                fx[nx].key = key;
                fx[nx].rank = base_rank(base);
                nx++;
            }
        }
    }
    if (p == 0) return nd_num(ar, 0);
    if (nx > 1) qsort(fx, (size_t)nx, sizeof(FactorX), factorx_cmp);
    {
        Node *out[256];
        int no = 0;
        for (i = 0; i < nx; i++) {
            double e = fx[i].e;
            Node *node;
            if (e == 0) continue;
            if (e == 1) node = fx[i].base;
            else if (e == -1) node = nd_bin(ar, N_DIV, nd_num(ar, 1), fx[i].base);
            else if (e <= -2 && e == floor(e))
                node = nd_bin(ar, N_DIV, nd_num(ar, 1),
                              nd_bin(ar, N_POW, fx[i].base, nd_num(ar, -e)));
            else node = nd_bin(ar, N_POW, fx[i].base, nd_num(ar, e));
            out[no++] = node;
        }
        if (no == 0) return nd_num(ar, p);
        if (p != 1) {
            Node *rest = build_prod(ar, out, no);
            if (p == -1) return nd_neg(ar, rest);
            return nd_bin(ar, N_MUL, nd_num(ar, p), rest);
        }
        return build_prod(ar, out, no);
    }
}

static Node *simp(Arena *ar, Node *n)
{
    if (!n) return NULL;
    switch (n->kind) {
    case N_NUM:
    case N_VAR:
    case N_CONST:
        return n;
    case N_NEG: {
        Node *a = simp(ar, n->a);
        if (a->kind == N_NUM) return nd_num(ar, -a->num);
        if (a->kind == N_NEG) return a->a;
        if (a->kind == N_ADD) {
            /* -(全负项的和) → 正项的和：消掉 -(-2a - 2b) 这种双重负；
             * 有正项时保持 -(x + 1) 形态（结构更清楚） */
            Node *terms[256], *out[256];
            int nt = 0, no = 0, i, allneg = 1;
            collect_add(a, terms, &nt, 256);
            for (i = 0; i < nt; i++) {
                if (terms[i]->kind == N_NEG) continue;
                if (terms[i]->kind == N_NUM && terms[i]->num < 0) continue;
                allneg = 0;
                break;
            }
            if (allneg && nt > 0) {
                for (i = 0; i < nt; i++)
                    out[no++] = terms[i]->kind == N_NEG ? terms[i]->a
                                                        : nd_num(ar, -terms[i]->num);
                return simp_add(ar, build_sum(ar, out, no));
            }
        }
        if (a->kind == N_MUL) {
            /* -(2*x) → -2*x；-(x*y) → -1*x*y */
            Node *fs[256];
            int nf = 0, i, seen = 0;
            collect_mul(a, fs, &nf, 256);
            for (i = 0; i < nf; i++) {
                double w;
                if (as_const_num(fs[i], &w)) {
                    fs[i] = nd_num(ar, -w);
                    seen = 1;
                    break;
                }
            }
            if (seen) return simp_mul(ar, build_prod(ar, fs, nf));
            {
                Node *fs2[257];
                fs2[0] = nd_num(ar, -1);
                for (i = 0; i < nf; i++) fs2[i + 1] = fs[i];
                return simp_mul(ar, build_prod(ar, fs2, nf + 1));
            }
        }
        n->a = a;
        return n;
    }
    case N_SUB: {
        Node *a = simp(ar, n->a);
        Node *b = simp(ar, n->b);
        return simp_add(ar, nd_bin(ar, N_ADD, a, nd_neg(ar, b)));
    }
    case N_ADD: {
        Node *a = simp(ar, n->a);
        Node *b = simp(ar, n->b);
        return simp_add(ar, nd_bin(ar, N_ADD, a, b));
    }
    case N_MUL: {
        Node *a = simp(ar, n->a);
        Node *b = simp(ar, n->b);
        return simp_mul(ar, nd_bin(ar, N_MUL, a, b));
    }
    case N_DIV: {
        Node *a = simp(ar, n->a);
        Node *b = simp(ar, n->b);
        double va, vb;
        if (as_const_num(a, &va) && as_const_num(b, &vb) && vb != 0)
            return nd_num(ar, va / vb);
        if (as_const_num(a, &va) && va == 0) return nd_num(ar, 0);
        if (as_const_num(b, &vb) && vb == 1) return a;
        if (strcmp(canon(a, ar), canon(b, ar)) == 0) return nd_num(ar, 1);
        n->a = a;
        n->b = b;
        return n;
    }
    case N_POW: {
        Node *a = simp(ar, n->a);
        Node *b = simp(ar, n->b);
        double va, vb;
        if (as_const_num(a, &va) && as_const_num(b, &vb)) {
            double r = pow(va, vb);
            if (isfinite(r)) return nd_num(ar, r);
        }
        if (as_const_num(b, &vb)) {
            if (vb == 0) return nd_num(ar, 1);
            if (vb == 1) return a;
            if (as_const_num(a, &va)) {
                if (va == 1) return nd_num(ar, 1);
                if (va == 0 && vb > 0) return nd_num(ar, 0);
            }
            if (a->kind == N_POW && as_const_num(a->b, &va)) {
                /* (x^m)^n → x^(m*n) */
                return nd_bin(ar, N_POW, a->a, nd_num(ar, va * vb));
            }
        }
        n->a = a;
        n->b = b;
        return n;
    }
    case N_FUNC: {
        Node *a = simp(ar, n->a);
        int id = fn_id(n->str);
        n->a = a;
        if (a->kind == N_NUM) {
            double v = a->num, r = 0;
            int ok = 1;
            switch (id) {
            case F_SIN: r = sin(v); break;
            case F_COS: r = cos(v); break;
            case F_TAN: r = tan(v); break;
            case F_ASIN: r = asin(v); break;
            case F_ACOS: r = acos(v); break;
            case F_ATAN: r = atan(v); break;
            case F_SINH: r = sinh(v); break;
            case F_COSH: r = cosh(v); break;
            case F_TANH: r = tanh(v); break;
            case F_EXP: r = exp(v); break;
            case F_LOG: if (v == 1) r = 0; else ok = 0; break;   /* 只折 log(1)；log(2) 等保持符号形式 */
            case F_SQRT: if (v >= 0) r = sqrt(v); else ok = 0; break;
            case F_ABS: r = fabs(v); break;
            default: ok = 0; break;
            }
            if (ok && isfinite(r)) return nd_num(ar, r);
        }
        if (id == F_LOG && a->kind == N_FUNC && fn_id(a->str) == F_EXP) return a->a;
        if (id == F_EXP && a->kind == N_FUNC && fn_id(a->str) == F_LOG) return a->a;
        return n;
    }
    }
    return n;
}

static Node *simplified(Arena *ar, Node *n)
{
    norm_sub(ar, n);
    return simp(ar, n);
}

/* ==================== 展开 ==================== */

static Node *expand(Arena *ar, Node *n)
{
    switch (n->kind) {
    case N_NUM:
    case N_VAR:
    case N_CONST:
        return n;
    case N_NEG: {
        Node *a = expand(ar, n->a);
        if (a->kind == N_ADD)
            return nd_bin(ar, N_ADD, nd_neg(ar, a->a), nd_neg(ar, a->b));
        return nd_neg(ar, a);
    }
    case N_ADD:
        return nd_bin(ar, N_ADD, expand(ar, n->a), expand(ar, n->b));
    case N_SUB:
        return nd_bin(ar, N_ADD, expand(ar, n->a), nd_neg(ar, expand(ar, n->b)));
    case N_MUL: {
        Node *a = expand(ar, n->a);
        Node *b = expand(ar, n->b);
        if (a->kind == N_ADD && b->kind == N_ADD) {
            Node *t1 = expand(ar, nd_bin(ar, N_MUL, a->a, b->a));
            Node *t2 = expand(ar, nd_bin(ar, N_MUL, a->a, b->b));
            Node *t3 = expand(ar, nd_bin(ar, N_MUL, a->b, b->a));
            Node *t4 = expand(ar, nd_bin(ar, N_MUL, a->b, b->b));
            return nd_bin(ar, N_ADD,
                          nd_bin(ar, N_ADD, t1, t2),
                          nd_bin(ar, N_ADD, t3, t4));
        }
        if (a->kind == N_ADD)
            return expand(ar, nd_bin(ar, N_ADD,
                                     nd_bin(ar, N_MUL, a->a, b),
                                     nd_bin(ar, N_MUL, a->b, b)));
        if (b->kind == N_ADD)
            return expand(ar, nd_bin(ar, N_ADD,
                                     nd_bin(ar, N_MUL, a, b->a),
                                     nd_bin(ar, N_MUL, a, b->b)));
        return nd_bin(ar, N_MUL, a, b);
    }
    case N_POW: {
        Node *a = expand(ar, n->a);
        Node *b = expand(ar, n->b);
        double e;
        if (a->kind == N_ADD && as_const_num(b, &e) &&
            e >= 2 && e <= 64 && e == floor(e)) {
            /* 重复乘；指数有上限，防 (x+x+...)^1000 爆炸 */
            Node *acc = a;
            long long k;
            for (k = 1; k < (long long)e; k++)
                acc = expand(ar, nd_bin(ar, N_MUL, acc, a));
            return acc;
        }
        return nd_bin(ar, N_POW, a, b);
    }
    case N_DIV:
        return nd_bin(ar, N_DIV, expand(ar, n->a), expand(ar, n->b));
    case N_FUNC:
        return nd_fn(ar, fn_id(n->str), expand(ar, n->a));
    }
    return n;
}

/* ==================== 求导 ==================== */

static Node *diff(Arena *ar, Node *n, const char *var)
{
    Node *da, *db, *a, *b;
    switch (n->kind) {
    case N_NUM:
    case N_CONST:
        return nd_num(ar, 0);
    case N_VAR:
        return nd_num(ar, strcmp(n->str, var) == 0 ? 1 : 0);
    case N_ADD:
        return nd_bin(ar, N_ADD, diff(ar, n->a, var), diff(ar, n->b, var));
    case N_SUB:
        return nd_bin(ar, N_SUB, diff(ar, n->a, var), diff(ar, n->b, var));
    case N_NEG:
        return nd_neg(ar, diff(ar, n->a, var));
    case N_MUL:
        a = n->a; b = n->b;
        da = diff(ar, a, var);
        db = diff(ar, b, var);
        return nd_bin(ar, N_ADD,
                      nd_bin(ar, N_MUL, da, b),
                      nd_bin(ar, N_MUL, a, db));
    case N_DIV:
        a = n->a; b = n->b;
        da = diff(ar, a, var);
        db = diff(ar, b, var);
        return nd_bin(ar, N_DIV,
                      nd_bin(ar, N_SUB,
                             nd_bin(ar, N_MUL, da, b),
                             nd_bin(ar, N_MUL, a, db)),
                      nd_bin(ar, N_POW, b, nd_num(ar, 2)));
    case N_POW:
        a = n->a; b = n->b;
        da = diff(ar, a, var);
        db = diff(ar, b, var);
        if (!has_var(b, var)) {
            double k;
            if (!as_const_num(b, &k)) k = 1;   /* 常数指数（含 pi 这类）按 1 处理 */
            return nd_bin(ar, N_MUL,
                          nd_bin(ar, N_MUL, nd_num(ar, k),
                                 nd_bin(ar, N_POW, a, nd_num(ar, k - 1))),
                          da);
        }
        if (!has_var(a, var)) {
            /* a^b（a 为常数）：a^b * log(a) * b' */
            return nd_bin(ar, N_MUL,
                          nd_bin(ar, N_POW, a, b),
                          nd_bin(ar, N_MUL, nd_fn(ar, F_LOG, a), db));
        }
        /* 一般情形：a^b * (b'*log(a) + b*a'/a) */
        return nd_bin(ar, N_MUL,
                      nd_bin(ar, N_POW, a, b),
                      nd_bin(ar, N_ADD,
                             nd_bin(ar, N_MUL, db, nd_fn(ar, F_LOG, a)),
                             nd_bin(ar, N_MUL, b, nd_bin(ar, N_DIV, da, a))));
    case N_FUNC: {
        int id = fn_id(n->str);
        Node *arg = n->a;
        Node *dg = diff(ar, arg, var);
        Node *fp = NULL;
        switch (id) {
        case F_SIN:  fp = nd_fn(ar, F_COS, arg); break;
        case F_COS:  fp = nd_neg(ar, nd_fn(ar, F_SIN, arg)); break;
        case F_TAN:  fp = nd_bin(ar, N_DIV, nd_num(ar, 1),
                                 nd_bin(ar, N_POW, nd_fn(ar, F_COS, arg), nd_num(ar, 2))); break;
        case F_ASIN: fp = nd_bin(ar, N_DIV, nd_num(ar, 1),
                                 nd_fn(ar, F_SQRT,
                                       nd_bin(ar, N_SUB, nd_num(ar, 1),
                                              nd_bin(ar, N_POW, arg, nd_num(ar, 2))))); break;
        case F_ACOS: fp = nd_neg(ar, nd_bin(ar, N_DIV, nd_num(ar, 1),
                                 nd_fn(ar, F_SQRT,
                                       nd_bin(ar, N_SUB, nd_num(ar, 1),
                                              nd_bin(ar, N_POW, arg, nd_num(ar, 2)))))); break;
        case F_ATAN: fp = nd_bin(ar, N_DIV, nd_num(ar, 1),
                                 nd_bin(ar, N_ADD, nd_num(ar, 1),
                                        nd_bin(ar, N_POW, arg, nd_num(ar, 2)))); break;
        case F_SINH: fp = nd_fn(ar, F_COSH, arg); break;
        case F_COSH: fp = nd_fn(ar, F_SINH, arg); break;
        case F_TANH: fp = nd_bin(ar, N_SUB, nd_num(ar, 1),
                                 nd_bin(ar, N_POW, nd_fn(ar, F_TANH, arg), nd_num(ar, 2))); break;
        case F_EXP:  fp = nd_fn(ar, F_EXP, arg); break;
        case F_LOG:  fp = nd_bin(ar, N_DIV, nd_num(ar, 1), arg); break;
        case F_SQRT: fp = nd_bin(ar, N_DIV, nd_num(ar, 1),
                                 nd_bin(ar, N_MUL, nd_num(ar, 2), nd_fn(ar, F_SQRT, arg))); break;
        case F_ABS:  fp = NULL; break;   /* abs 在 0 处不可导，v1 不支持 */
        default:     fp = NULL; break;
        }
        if (!fp) return NULL;
        return nd_bin(ar, N_MUL, dg, fp);
    }
    }
    return NULL;
}

/* ==================== 积分 ==================== */

static int integ(Arena *ar, Node *n, const char *var, Node **out);
static int integ_rational(Arena *ar, Node *num, Node *den, const char *var, Node **out);

/* 判断 n 是否为 m*x + c 形式（相对于 var） */
static int as_linear(Node *n, const char *var, double *m, double *c)
{
    double v;
    if (n->kind == N_VAR && strcmp(n->str, var) == 0) { *m = 1; *c = 0; return 1; }
    if (n->kind == N_MUL) {
        if (as_const_num(n->a, &v) && n->b->kind == N_VAR && strcmp(n->b->str, var) == 0)
            { *m = v; *c = 0; return 1; }
        if (as_const_num(n->b, &v) && n->a->kind == N_VAR && strcmp(n->a->str, var) == 0)
            { *m = v; *c = 0; return 1; }
        return 0;
    }
    if (n->kind == N_ADD) {
        double mm = 1, cc = 0;
        if (as_linear(n->a, var, &mm, &cc) && as_const_num(n->b, &v)) { *m = mm; *c = cc + v; return 1; }
        if (as_linear(n->b, var, &mm, &cc) && as_const_num(n->a, &v)) { *m = mm; *c = cc + v; return 1; }
        return 0;
    }
    return 0;
}

/* q·x^n 的漂亮形态：q 整数 → q*x^n；q=a/b（小分母）→ a*x^n/b（a=1 时 x^n/b）
 * 例：∫2x → x^2；∫x^2 → x^3/3；∫√x → 2*x^1.5/3（不出 0.6666666667*x^1.5） */
static Node *coef_pow(Arena *ar, double q, Node *x, double n)
{
    static const int dens[] = { 2, 3, 4, 5, 6, 8, 10, 12 };
    double a = fabs(q);
    int k, d, num;
    Node *pw;
    if (q == 0) return nd_num(ar, 0);
    if (n == 1) pw = x; else pw = nd_bin(ar, N_POW, x, nd_num(ar, n));
    if (a == floor(a) && a < 1e15) {
        if (a == 1) return q < 0 ? nd_neg(ar, pw) : pw;
        return nd_bin(ar, N_MUL, nd_num(ar, q), pw);
    }
    for (k = 0; k < (int)(sizeof dens / sizeof *dens); k++) {
        d = dens[k];
        if (fabs(a * d - floor(a * d + 0.5)) < 1e-9) {
            num = (int)floor(a * d + 0.5);
            if (num == 1)
                return nd_bin(ar, N_DIV, pw, nd_num(ar, q < 0 ? -d : d));
            return nd_bin(ar, N_DIV,
                          nd_bin(ar, N_MUL, nd_num(ar, q < 0 ? -num : num), pw),
                          nd_num(ar, d));
        }
    }
    return nd_bin(ar, N_MUL, nd_num(ar, q), pw);   /* 兜底：普通系数 */
}

/* ∫f(u)du，u 为变量 var 本身 */
static Node *func_int_var(Arena *ar, int fn, const char *var)
{
    Node *u = nd_var(ar, var);
    Node *one = nd_num(ar, 1);
    Node *two = nd_num(ar, 2);
    switch (fn) {
    case F_SIN:  return nd_neg(ar, nd_fn(ar, F_COS, u));
    case F_COS:  return nd_fn(ar, F_SIN, u);
    case F_TAN:  return nd_neg(ar, nd_fn(ar, F_LOG, nd_fn(ar, F_COS, u)));
    case F_EXP:  return nd_fn(ar, F_EXP, u);
    case F_LOG:  return nd_bin(ar, N_SUB, nd_bin(ar, N_MUL, u, nd_fn(ar, F_LOG, u)), u);
    case F_SQRT: return coef_pow(ar, 2.0 / 3.0, u, 1.5);   /* 2*x^1.5/3 */
    case F_ASIN: return nd_bin(ar, N_ADD,
                               nd_bin(ar, N_MUL, u, nd_fn(ar, F_ASIN, u)),
                               nd_fn(ar, F_SQRT, nd_bin(ar, N_SUB, one,
                                        nd_bin(ar, N_POW, u, two))));
    case F_ACOS: return nd_bin(ar, N_SUB,
                               nd_bin(ar, N_MUL, u, nd_fn(ar, F_ACOS, u)),
                               nd_fn(ar, F_SQRT, nd_bin(ar, N_SUB, one,
                                        nd_bin(ar, N_POW, u, two))));
    case F_ATAN: return nd_bin(ar, N_SUB,
                               nd_bin(ar, N_MUL, u, nd_fn(ar, F_ATAN, u)),
                               nd_bin(ar, N_MUL, nd_num(ar, 0.5),
                                      nd_fn(ar, F_LOG,
                                            nd_bin(ar, N_ADD, one,
                                                   nd_bin(ar, N_POW, u, two)))));
    case F_SINH: return nd_fn(ar, F_COSH, u);
    case F_COSH: return nd_fn(ar, F_SINH, u);
    case F_TANH: return nd_fn(ar, F_LOG, nd_fn(ar, F_COSH, u));
    default:     return NULL;   /* abs 不积 */
    }
}

/* 把节点里的 VAR(var) 全部替换成 u（同一 arena，共享指针安全） */
static Node *subst_node(Arena *ar, Node *n, const char *var, Node *u)
{
    Node *a, *r;
    if (!n) return NULL;
    if (n->kind == N_VAR) {
        if (strcmp(n->str, var) == 0) return u;
        r = nd(ar, N_VAR);
        r->str = n->str;
        return r;
    }
    if (n->kind == N_NUM || n->kind == N_CONST) {
        r = nd(ar, n->kind);
        r->num = n->num;
        r->str = n->str;
        return r;
    }
    a = subst_node(ar, n->a, var, u);
    if (n->kind == N_FUNC) return nd_fn(ar, fn_id(n->str), a);
    if (n->kind == N_NEG) return nd_neg(ar, a);
    return nd_bin(ar, n->kind, a, subst_node(ar, n->b, var, u));
}

/* x^k * g（g ∈ exp/sin/cos）的分部积分，递归 */
static int integ_parts(Arena *ar, double k, int fn, const char *var, int depth, Node **out)
{
    Node *G, *t1, *x, *u, *rest, *ig;
    if (depth > 12) return 0;
    G = func_int_var(ar, fn, var);
    if (!G) return 0;
    x = nd_var(ar, var);
    t1 = nd_bin(ar, N_MUL, nd_bin(ar, N_POW, x, nd_num(ar, k)), G);
    if (k <= 1) {
        if (!integ(ar, G, var, &ig)) return 0;
        *out = nd_bin(ar, N_SUB, t1, ig);
        return 1;
    }
    /* ∫x^k·g = x^k·G - ∫(k·x^(k-1)·G)dx；后项交给 integ 递归（不是再套 integ_parts） */
    u = nd_bin(ar, N_MUL, nd_num(ar, k),
               nd_bin(ar, N_MUL, nd_bin(ar, N_POW, x, nd_num(ar, k - 1)), G));
    if (!integ(ar, u, var, &rest)) return 0;
    *out = nd_bin(ar, N_SUB, t1, rest);
    return 1;
}

static int integ(Arena *ar, Node *n, const char *var, Node **out)
{
    double v;
    Node *x;

    /* 线性：∫(a+b+...) */
    if (n->kind == N_ADD) {
        Node *terms[128];
        int nt = 0, i;
        Node *acc = NULL;
        collect_add(n, terms, &nt, 128);
        for (i = 0; i < nt; i++) {
            Node *t;
            if (!integ(ar, terms[i], var, &t)) return 0;
            acc = acc ? nd_bin(ar, N_ADD, acc, t) : t;
        }
        if (!acc) return 0;
        *out = acc;
        return 1;
    }
    /* ∫-f dx = -∫f dx */
    if (n->kind == N_NEG) {
        Node *t;
        if (!integ(ar, n->a, var, &t)) return 0;
        *out = nd_neg(ar, t);
        return 1;
    }
    /* 纯常数（含 pi、其他不含 var 的变量）：∫c dx = c*x */
    if (!has_var(n, var)) {
        *out = nd_bin(ar, N_MUL, n, nd_var(ar, var));
        return 1;
    }
    x = nd_var(ar, var);

    /* x^n */
    if (n->kind == N_POW && n->a->kind == N_VAR && strcmp(n->a->str, var) == 0 &&
        as_const_num(n->b, &v)) {
        if (v == -1) { *out = nd_fn(ar, F_LOG, x); return 1; }
        *out = nd_bin(ar, N_DIV, nd_bin(ar, N_POW, x, nd_num(ar, v + 1)), nd_num(ar, v + 1));
        return 1;
    }
    if (n->kind == N_VAR && strcmp(n->str, var) == 0) {
        *out = nd_bin(ar, N_DIV, nd_bin(ar, N_POW, x, nd_num(ar, 2)), nd_num(ar, 2));
        return 1;
    }
    /* 函数（含线性内函数的链式） */
    if (n->kind == N_FUNC) {
        int fn = fn_id(n->str);
        Node *a = n->a;
        double m, c;
        if (a->kind == N_VAR && strcmp(a->str, var) == 0) {
            Node *F = func_int_var(ar, fn, var);
            if (F) { *out = F; return 1; }
            return 0;
        }
        if (as_linear(a, var, &m, &c) && m != 0) {
            Node *F = func_int_var(ar, fn, var);
            if (F) {
                Node *sub = subst_node(ar, F, var, a);
                *out = nd_bin(ar, N_DIV, sub, nd_num(ar, m));
                return 1;
            }
        }
        return 0;
    }
    /* 除法 */
    if (n->kind == N_DIV) {
        double m, c;
        if (n->b->kind == N_VAR && strcmp(n->b->str, var) == 0 && !has_var(n->a, var)) {
            *out = nd_bin(ar, N_MUL, n->a, nd_fn(ar, F_LOG, x));
            return 1;
        }
        if (as_linear(n->b, var, &m, &c) && m != 0 && !has_var(n->a, var)) {
            *out = nd_bin(ar, N_DIV, nd_bin(ar, N_MUL, n->a, nd_fn(ar, F_LOG, n->b)), nd_num(ar, m));
            return 1;
        }
        if (n->b->kind == N_POW && n->b->a->kind == N_VAR &&
            strcmp(n->b->a->str, var) == 0 && as_const_num(n->b->b, &v) &&
            v != -1 && !has_var(n->a, var)) {
            *out = nd_bin(ar, N_MUL, n->a,
                          nd_bin(ar, N_DIV, nd_bin(ar, N_POW, x, nd_num(ar, 1 - v)),
                                 nd_num(ar, 1 - v)));
            return 1;
        }
        /* 常数分母：∫(f/c) = (∫f)/c（补 x/2 这类基线缺口） */
        if (!has_var(n->b, var)) {
            double cc;
            if (as_const_num(n->b, &cc) && cc != 0) {
                Node *fi;
                if (integ(ar, n->a, var, &fi)) {
                    *out = nd_bin(ar, N_DIV, fi, nd_num(ar, cc));
                    return 1;
                }
            }
        }
        /* 有理函数：长除 + 分母按有理根分解 → 部分分式 → 汇入表驱动，
         * 末尾数值对拍（极点右侧采点中心差分），对不上即认输不交错答案 */
        {
            Node *rn;
            if (integ_rational(ar, n->a, n->b, var, &rn)) { *out = rn; return 1; }
        }
        return 0;
    }
    /* 乘积 */
    if (n->kind == N_MUL) {
        Node *fs[64];
        Node *rest_fs[64];
        int nf = 0, nr = 0, i;
        double c = 1;
        int vp = -1;      /* rest_fs 里 x 幂因子的下标 */
        double vpk = 0;
        int fn = -1;      /* rest_fs 里 exp/sin/cos/log 因子的 id */
        int fnidx = -1;

        collect_mul(n, fs, &nf, 64);
        for (i = 0; i < nf; i++) {
            double vv;
            Node *f = fs[i];
            int sgn = 1;
            if (f->kind == N_NEG) { sgn = -1; f = f->a; }   /* -(cos x) 的符号进系数 */
            if (as_const_num(f, &vv)) { c *= sgn * vv; continue; }
            if (sgn < 0) { c *= sgn; fs[i] = f; }      /* -(cos x) 的符号进系数，因子去壳 */
            rest_fs[nr++] = fs[i];
        }
        for (i = 0; i < nr; i++) {
            Node *f = rest_fs[i];
            double vv;
            if (vp < 0 && f->kind == N_VAR && strcmp(f->str, var) == 0) { vp = i; vpk = 1; continue; }
            if (vp < 0 && f->kind == N_POW && f->a->kind == N_VAR &&
                strcmp(f->a->str, var) == 0 && as_const_num(f->b, &vv) &&
                vv >= 1 && vv == floor(vv) && vv <= 12) { vp = i; vpk = vv; continue; }
            if (fn < 0 && f->kind == N_FUNC) {
                int id = fn_id(f->str);
                if (id == F_EXP || id == F_SIN || id == F_COS || id == F_LOG) { fn = id; fnidx = i; continue; }
            }
        }
        /* x^k * log(x)：直接公式 */
        if (vp >= 0 && fn == F_LOG && nr == 2) {
            Node *lg = rest_fs[fnidx];
            if (lg->a->kind == N_VAR && strcmp(lg->a->str, var) == 0) {
                Node *t1 = nd_bin(ar, N_DIV,
                                  nd_bin(ar, N_MUL,
                                         nd_bin(ar, N_POW, x, nd_num(ar, vpk + 1)),
                                         nd_fn(ar, F_LOG, x)),
                                  nd_num(ar, vpk + 1));
                Node *t2 = nd_bin(ar, N_DIV,
                                  nd_bin(ar, N_POW, x, nd_num(ar, vpk + 1)),
                                  nd_num(ar, (vpk + 1) * (vpk + 1)));
                Node *r = nd_bin(ar, N_SUB, t1, t2);
                if (c != 1) r = nd_bin(ar, N_MUL, nd_num(ar, c), r);
                *out = r;
                return 1;
            }
            return 0;
        }
        /* x^k * g 分部积分 */
        if (vp >= 0 && fn >= 0 && fn != F_LOG && nr == 2) {
            Node *r;
            if (!integ_parts(ar, vpk, fn, var, 0, &r)) return 0;
            if (c != 1) r = nd_bin(ar, N_MUL, nd_num(ar, c), r);
            *out = r;
            return 1;
        }
        /* 全是同变量幂 → 合并指数（也防 ∫x*x 的无限递归） */
        {
            int allp = (nr >= 1);
            double es = 0;
            for (i = 0; i < nr; i++) {
                Node *f = rest_fs[i];
                double vv;
                if (f->kind == N_VAR && strcmp(f->str, var) == 0) es += 1;
                else if (f->kind == N_POW && f->a->kind == N_VAR &&
                         strcmp(f->a->str, var) == 0 && as_const_num(f->b, &vv)) es += vv;
                else { allp = 0; break; }
            }
            if (allp) {
                *out = coef_pow(ar, c / (es + 1), x, es + 1);
                return 1;
            }
        }
        /* 常数外提：rest = 所有非常数因子 */
        {
            Node *rest = build_prod(ar, rest_fs, nr);
            Node *ri;
            if (strcmp(canon(rest, ar), canon(n, ar)) == 0) return 0;  /* 防呆 */
            if (!integ(ar, rest, var, &ri)) return 0;
            if (c != 1) ri = nd_bin(ar, N_MUL, nd_num(ar, c), ri);
            *out = ri;
            return 1;
        }
    }
    return 0;
}

/* ==================== 求值 ==================== */

static int lookup_var(Node *n, char **names, double *vals, int nn, double *out)
{
    int i;
    for (i = 0; i < nn; i++)
        if (strcmp(n->str, names[i]) == 0) { *out = vals[i]; return 1; }
    return 0;
}

static int eval_node(Node *n, char **names, double *vals, int nn,
                     double *out, char *err, size_t errsz)
{
    double a = 0, b = 0;
    switch (n->kind) {
    case N_NUM: *out = n->num; return 1;
    case N_CONST:
        *out = strcmp(n->str, "pi") == 0 ? 3.14159265358979323846 : 2.71828182845904523536;
        return 1;
    case N_VAR:
        if (!lookup_var(n, names, vals, nn, out)) {
            if (err) snprintf(err, errsz,
                "表达式里有变量 %s，但绑定串里没给它的值（可以先用 sym.变量(表达式) 看它要哪些）", n->str);
            return 0;
        }
        return 1;
    case N_NEG:
        if (!eval_node(n->a, names, vals, nn, &a, err, errsz)) return 0;
        *out = -a;
        return 1;
    case N_ADD: case N_SUB: case N_MUL: case N_DIV: case N_POW:
        if (!eval_node(n->a, names, vals, nn, &a, err, errsz)) return 0;
        if (!eval_node(n->b, names, vals, nn, &b, err, errsz)) return 0;
        switch (n->kind) {
        case N_ADD: *out = a + b; return 1;
        case N_SUB: *out = a - b; return 1;
        case N_MUL: *out = a * b; return 1;
        case N_DIV:
            if (b == 0) {
                if (err) snprintf(err, errsz, "除以 0 了（%.10g / %.10g）", a, b);
                return 0;
            }
            *out = a / b;
            return 1;
        default:
            *out = pow(a, b);
            if (!isfinite(*out) && a < 0) {
                if (err) snprintf(err, errsz, "负数 %.10g 的 %.10g 次方不是实数", a, b);
                return 0;
            }
            return 1;
        }
    case N_FUNC: {
        int id = fn_id(n->str);
        if (!eval_node(n->a, names, vals, nn, &a, err, errsz)) return 0;
        switch (id) {
        case F_SIN: *out = sin(a); return 1;
        case F_COS: *out = cos(a); return 1;
        case F_TAN: *out = tan(a); return 1;
        case F_ASIN:
            if (a < -1 || a > 1) {
                if (err) snprintf(err, errsz, "asin 的参数要在 [-1, 1]，收到 %.10g", a);
                return 0;
            }
            *out = asin(a); return 1;
        case F_ACOS:
            if (a < -1 || a > 1) {
                if (err) snprintf(err, errsz, "acos 的参数要在 [-1, 1]，收到 %.10g", a);
                return 0;
            }
            *out = acos(a); return 1;
        case F_ATAN: *out = atan(a); return 1;
        case F_SINH: *out = sinh(a); return 1;
        case F_COSH: *out = cosh(a); return 1;
        case F_TANH: *out = tanh(a); return 1;
        case F_EXP: *out = exp(a); return 1;
        case F_LOG:
            if (a <= 0) {
                if (err) snprintf(err, errsz, "log 的参数要 > 0，收到 %.10g", a);
                return 0;
            }
            *out = log(a); return 1;
        case F_SQRT:
            if (a < 0) {
                if (err) snprintf(err, errsz, "sqrt 的参数要 >= 0，收到 %.10g", a);
                return 0;
            }
            *out = sqrt(a); return 1;
        case F_ABS: *out = fabs(a); return 1;
        }
        return 0;
    }
    }
    return 0;
}

/* ==================== 变量 / 相等 ==================== */

static void collect_vars(Node *n, char **buf, int *nn, int cap)
{
    int i;
    if (!n) return;
    if (n->kind == N_VAR) {
        for (i = 0; i < *nn; i++)
            if (strcmp(n->str, buf[i]) == 0) return;
        if (*nn < cap) buf[(*nn)++] = n->str;
        return;
    }
    collect_vars(n->a, buf, nn, cap);
    collect_vars(n->b, buf, nn, cap);
}

static int eq_node(Node *a, Node *b)
{
    if (a->kind != b->kind) return 0;
    switch (a->kind) {
    case N_NUM: {
        double d = fabs(a->num - b->num);
        double s = 1 + fabs(a->num) + fabs(b->num);
        return d <= 1e-9 * s;
    }
    case N_VAR:
    case N_CONST:
        return strcmp(a->str, b->str) == 0;
    case N_FUNC:
    case N_NEG:
        return eq_node(a->a, b->a);
    default:
        return eq_node(a->a, b->a) && eq_node(a->b, b->b);
    }
}

/* ==================== 核心入口 ==================== */

static Node *compile1(const char *expr, Arena *ar, char *err, size_t errsz)
{
    P p;
    Node *n;
    p.ar = ar;
    n = parse_full(&p, expr);
    if (!n) {
        if (err) snprintf(err, errsz, "%s", p.err[0] ? p.err : "表达式看不懂");
        return NULL;
    }
    return n;
}

static int bad_var_name(const char *var, char *err, size_t errsz)
{
    if (!is_ident(var) || is_const_name(var)) {
        if (err) snprintf(err, errsz,
            "第二个参数要是个变量名（pi 和 e 是常量，不能当变量；名字里不要带运算符）");
        return 1;
    }
    return 0;
}

char *sym_core_parse(const char *expr, char *err, size_t errsz)
{
    Arena ar = {0};
    Node *n;
    char *out;
    n = compile1(expr, &ar, err, errsz);
    if (!n) return NULL;
    out = render_malloc(n);
    ar_free(&ar);
    return out;
}

char *sym_core_diff(const char *expr, const char *var, char *err, size_t errsz)
{
    Arena ar = {0};
    Node *n, *d;
    char *out;
    if (bad_var_name(var, err, errsz)) return NULL;
    n = compile1(expr, &ar, err, errsz);
    if (!n) return NULL;
    norm_sub(&ar, n);
    d = diff(&ar, n, var);
    if (!d) {
        if (err) snprintf(err, errsz,
            "abs 在 0 处不可导，符号求导暂不支持它；可以自己分段写（x>=0 与 x<0 两瓣）");
        ar_free(&ar);
        return NULL;
    }
    out = render_malloc(simp(&ar, d));
    ar_free(&ar);
    return out;
}

char *sym_core_integrate(const char *expr, const char *var, char *err, size_t errsz)
{
    Arena ar = {0};
    Node *n, *r, *e;
    char *out;
    if (bad_var_name(var, err, errsz)) return NULL;
    n = compile1(expr, &ar, err, errsz);
    if (!n) return NULL;
    n = simplified(&ar, n);
    if (integ(&ar, n, var, &r)) {
        out = render_malloc(simp(&ar, expand(&ar, r)));   /* 分部积分的结果先展开再化简，出经典形式 */
        ar_free(&ar);
        return out;
    }
    /* 直接积不动 → 展开成多项式再试 */
    e = simp(&ar, expand(&ar, n));
    if (integ(&ar, e, var, &r)) {
        out = render_malloc(simp(&ar, expand(&ar, r)));
        ar_free(&ar);
        return out;
    }
    ar_free(&ar);
    out = (char *)malloc(1);       /* 不会积：空串（与报错区分） */
    if (out) out[0] = 0;
    return out;
}

char *sym_core_simplify(const char *expr, char *err, size_t errsz)
{
    Arena ar = {0};
    Node *n;
    char *out;
    n = compile1(expr, &ar, err, errsz);
    if (!n) return NULL;
    out = render_malloc(simplified(&ar, n));
    ar_free(&ar);
    return out;
}

char *sym_core_expand(const char *expr, char *err, size_t errsz)
{
    Arena ar = {0};
    Node *n;
    char *out;
    n = compile1(expr, &ar, err, errsz);
    if (!n) return NULL;
    out = render_malloc(simp(&ar, expand(&ar, simplified(&ar, n))));
    ar_free(&ar);
    return out;
}

int sym_core_eval(const char *expr, const char *bindings, double *out,
                  char *err, size_t errsz)
{
    Arena ar = {0};
    Node *n;
    char *names[64];
    double vals[64];
    int nn = 0;
    const char *p = bindings;
    double r;

    n = compile1(expr, &ar, err, errsz);
    if (!n) return 0;
    while (*p) {
        const char *eq = strchr(p, '=');
        char name[64];
        size_t len, st;
        char *end = NULL;
        double v;
        if (!eq) {
            if (err) snprintf(err, errsz,
                "绑定串里「%s」这一段没有 '='，应该写成 名=值，多组用逗号分隔，比如 \"x=2, y=3\"", p);
            goto fail;
        }
        len = (size_t)(eq - p);
        while (len > 0 && (p[len - 1] == ' ' || p[len - 1] == '\t')) len--;
        st = 0;
        while (st < len && (p[st] == ' ' || p[st] == '\t')) st++;
        len -= st;
        if (len == 0 || len >= sizeof name) {
            if (err) snprintf(err, errsz, "绑定串里的变量名看不懂（空名字或太长）");
            goto fail;
        }
        memcpy(name, p + st, len);
        name[len] = 0;
        v = strtod(eq + 1, &end);
        if (end == eq + 1) {
            if (err) snprintf(err, errsz, "绑定串里 %s 的值不是数字", name);
            goto fail;
        }
        if (nn < 64) {
            names[nn] = ar_strdup(&ar, name, len);
            vals[nn] = v;
            nn++;
        }
        p = end;
        while (*p == ' ' || *p == '\t') p++;
        if (*p == ',') {
            p++;
            while (*p == ' ' || *p == '\t') p++;
        } else if (*p) {
            if (err) snprintf(err, errsz, "绑定串里 %s 后面多了东西，多组绑定用逗号分隔", name);
            goto fail;
        }
    }
    if (!eval_node(n, names, vals, nn, &r, err, errsz)) goto fail;
    *out = r;
    ar_free(&ar);
    return 1;
fail:
    ar_free(&ar);
    return 0;
}

char *sym_core_vars(const char *expr, char *err, size_t errsz)
{
    Arena ar = {0};
    Node *n;
    char *names[64];
    int nn = 0, i;
    SB b;
    n = compile1(expr, &ar, err, errsz);
    if (!n) return NULL;
    collect_vars(n, names, &nn, 64);
    sb_init(&b);
    for (i = 0; i < nn; i++) {
        if (i) sb_puts(&b, ", ");
        sb_puts(&b, names[i]);
    }
    ar_free(&ar);
    return b.p;
}

char *sym_core_subst(const char *expr, const char *var, const char *newexpr,
                     char *err, size_t errsz)
{
    Arena ar = {0};
    Node *n, *u, *r;
    char *out;
    if (bad_var_name(var, err, errsz)) return NULL;
    n = compile1(expr, &ar, err, errsz);
    if (!n) return NULL;
    u = compile1(newexpr, &ar, err, errsz);
    if (!u) { ar_free(&ar); return NULL; }
    r = subst_node(&ar, n, var, u);
    out = render_malloc(simplified(&ar, r));
    ar_free(&ar);
    return out;
}

int sym_core_equal(const char *a, const char *b, char *err, size_t errsz)
{
    Arena ar = {0};
    Node *na, *nb;
    int r;
    na = compile1(a, &ar, err, errsz);
    if (!na) { ar_free(&ar); return -1; }
    nb = compile1(b, &ar, err, errsz);
    if (!nb) { ar_free(&ar); return -1; }
    na = simplified(&ar, na);
    nb = simplified(&ar, nb);
    r = eq_node(na, nb);
    ar_free(&ar);
    return r;
}

/* ==================== 解方程（sym.求解） ==================== */

/* 无变量子式的常数值（NUM、pi、折叠过的 sin(1) 等）；非有限（inf/nan）算失败 */
static int const_eval(Node *n, double *v)
{
    if (!eval_node(n, NULL, NULL, 0, v, NULL, 0)) return 0;
    return isfinite(*v) ? 1 : 0;
}

/* 按 var 收集多项式系数：coef[k] += 该项贡献的 x^k 系数。
 * sgn / scale 是递归递下来的符号与常数比例。是多项式返回 1，否则 0。 */
static int poly_term_s(Node *n, const char *var, int maxdeg,
                       double *coef, double sgn, double scale)
{
    double v;
    int i;

    if (!has_var(n, var)) {                 /* 纯常数段（NUM、pi、sin(1) 折叠项） */
        if (!const_eval(n, &v)) return 0;
        coef[0] += sgn * scale * v;
        return 1;
    }
    switch (n->kind) {
    case N_VAR:
        if (strcmp(n->str, var) == 0 && maxdeg >= 1) {
            coef[1] += sgn * scale;
            return 1;
        }
        return 0;                            /* 方程里还有别的变量 */
    case N_NEG:
        return poly_term_s(n->a, var, maxdeg, coef, -sgn, scale);
    case N_ADD:
        if (!poly_term_s(n->a, var, maxdeg, coef, sgn, scale)) return 0;
        return poly_term_s(n->b, var, maxdeg, coef, sgn, scale);
    case N_SUB:
        if (!poly_term_s(n->a, var, maxdeg, coef, sgn, scale)) return 0;
        return poly_term_s(n->b, var, maxdeg, coef, -sgn, scale);
    case N_DIV: {
        double vd;
        if (as_const_num(n->b, &vd) && vd != 0 && !has_var(n->b, var))
            return poly_term_s(n->a, var, maxdeg, coef, sgn, scale / vd);
        return 0;                            /* 1/x、x/(x+1) 都不是多项式 */
    }
    case N_POW: {
        double e;
        if (n->a->kind == N_VAR && strcmp(n->a->str, var) == 0 &&
            as_const_num(n->b, &e) && e >= 0 && e == floor(e)) {
            if (e > maxdeg) return 0;
            coef[(int)e] += sgn * scale;
            return 1;
        }
        if (n->a->kind == N_NUM && n->b->kind == N_NUM) {
            double r = pow(n->a->num, n->b->num);
            if (isfinite(r)) { coef[0] += sgn * scale * r; return 1; }
        }
        return 0;                            /* x^0.5、x^y、2^x 交给展开或认输 */
    }
    case N_MUL: {
        Node *fs[256];
        int nf = 0;
        double sc = sgn * scale;
        int e = 0;
        collect_mul(n, fs, &nf, 256);
        if (nf == 0) return 0;
        for (i = 0; i < nf; i++) {
            Node *f = fs[i];
            double vv;
            int es = 0, neg = 0;
            if (f->kind == N_NEG) { neg = 1; f = f->a; }
            if (f->kind == N_NUM) { sc *= neg ? -f->num : f->num; continue; }
            if (!has_var(f, var)) {           /* 常数因子（pi、e、折叠过的 sin(1)） */
                if (!const_eval(f, &vv)) return 0;
                sc *= neg ? -vv : vv;
                continue;
            }
            if (f->kind == N_VAR && strcmp(f->str, var) == 0) {
                es = 1;
            } else if (f->kind == N_POW && f->a->kind == N_VAR &&
                       strcmp(f->a->str, var) == 0 && as_const_num(f->b, &vv) &&
                       vv >= 0 && vv == floor(vv) && vv <= maxdeg) {
                es = (int)vv;
            } else {
                return 0;                     /* sin(x)*x、x*(x+1)：先展开 */
            }
            if (neg) sc *= -1;
            e += es;
        }
        if (e > maxdeg) return 0;
        coef[e] += sc;
        return 1;
    }
    }
    return 0;                                 /* FUNC：sin(x)=0 这类不是多项式 */
}

static int gcd_int(int a, int b)
{
    if (a < 0) a = -a;
    if (b < 0) b = -b;
    while (b) { int t = a % b; a = b; b = t; }
    return a;
}

/* 数值根美化：整数优先，其次小分母分数（约分），否则 %.10g */
static void fmt_root(double r, char *buf, size_t sz)
{
    static const int dens[] = { 2, 3, 4, 5, 6, 8, 10, 12 };
    double a = fabs(r);
    int d, k, num, den, g;
    if (r == 0) { snprintf(buf, sz, "0"); return; }
    if (fabs(r - floor(r + 0.5)) <= 1e-9 * (1 + a)) {
        snprintf(buf, sz, "%.0f", r);
        return;
    }
    for (k = 0; k < (int)(sizeof dens / sizeof *dens); k++) {
        d = dens[k];
        if (fabs(a * d - floor(a * d + 0.5)) <= 1e-9 * d) {
            num = (int)floor(a * d + 0.5);
            g = gcd_int(num, d);
            if (g < 1) g = 1;
            num /= g;
            den = d / g;
            snprintf(buf, sz, "%s%d/%d", r < 0 ? "-" : "", num, den);
            return;
        }
    }
    snprintf(buf, sz, "%.10g", r);
}

/* 多项式求值（Horner，实系数） */
static double poly_at(const double *c, int n, double x)
{
    double r = 0;
    int i;
    for (i = n; i >= 0; i--) r = r * x + c[i];
    return r;
}

/* Durand-Kerner 复数迭代求全部根 → 取实根 → Newton 精修 → 去重。
 * 返回实根个数（0 = 没找到实根）；n 不在 [3,12] 返回 -1。 */
static int poly_real_roots(const double *c, int n, double *roots, int cap)
{
    double zr[16], zi[16], m[16], cr[16], ci[16];
    int i, j, it, cnt = 0;
    if (n < 3 || n > 12) return -1;
    for (i = 0; i <= n; i++) m[i] = c[i] / c[n];      /* 首一化 */
    zr[0] = 1; zi[0] = 0;                             /* 初始猜测 (0.4+0.9i)^k */
    for (i = 1; i < n; i++) {
        double tr = zr[i - 1] * 0.4 - zi[i - 1] * 0.9;
        double ti = zr[i - 1] * 0.9 + zi[i - 1] * 0.4;
        zr[i] = tr;
        zi[i] = ti;
    }
    for (it = 0; it < 400; it++) {
        double maxp = 0;
        for (i = 0; i < n; i++) {
            double pr = m[n], pi = 0, dr = 1, di = 0, den, qr, qi, pm;
            int k;
            for (k = n - 1; k >= 0; k--) {            /* p(z)：复数 Horner */
                double tr = pr * zr[i] - pi * zi[i] + m[k];
                pi = pr * zi[i] + pi * zr[i];
                pr = tr;
            }
            for (j = 0; j < n; j++) {                 /* prod(z - zj) */
                double ar, ai, tr;
                if (j == i) continue;
                ar = zr[i] - zr[j];
                ai = zi[i] - zi[j];
                tr = dr * ar - di * ai;
                di = dr * ai + di * ar;
                dr = tr;
            }
            den = dr * dr + di * di;
            if (den < 1e-300) { cr[i] = 0; ci[i] = 0; continue; }
            qr = (pr * dr + pi * di) / den;
            qi = (pi * dr - pr * di) / den;
            cr[i] = qr;
            ci[i] = qi;
            pm = sqrt(pr * pr + pi * pi);
            if (pm > maxp) maxp = pm;
        }
        for (i = 0; i < n; i++) { zr[i] -= cr[i]; zi[i] -= ci[i]; }
        if (maxp < 1e-12) break;
    }
    for (i = 0; i < n && cnt < cap; i++) {
        double re = zr[i], im = zi[i];
        int k, dup = 0;
        if (!(fabs(re) < 1e12)) continue;              /* NaN/inf 挡掉 */
        if (fabs(im) > 1e-7 * (1 + fabs(re))) continue;/* 非实根跳过 */
        for (k = 0; k < 60; k++) {                     /* Newton 精修（重根线性收敛也够） */
            double p = poly_at(c, n, re), d = 0, step;
            int t;
            for (t = n; t >= 1; t--) d = d * re + t * c[t];
            if (fabs(d) < 1e-300) break;
            step = p / d;
            if (!(fabs(step) < 1e8)) break;
            re -= step;
            if (fabs(step) <= 1e-15 * (1 + fabs(re))) break;
        }
        if (!isfinite(re)) continue;
        for (j = 0; j < cnt; j++)
            if (fabs(roots[j] - re) <= 1e-7 * (1 + fabs(re))) { dup = 1; break; }
        if (!dup) roots[cnt++] = re;
    }
    return cnt;
}

/* 解方程：eq 形如 "左=右"（缺 = 当右边是 0）。返回 "x = r1, x = r2"（升序）；
 * 恒等式 / 无解 / 无实根都给明确文字；失败返回 NULL（err 有文案）。 */
char *sym_core_solve(const char *eq, const char *var, char *err, size_t errsz)
{
    Arena ar = {0};
    Node *lh, *rh, *e;
    const char *eqp;
    char *names[64];
    int nn = 0, i, deg = 0, nr;
    double coef[80];
    double roots[16];
    SB b;

    if (bad_var_name(var, err, errsz)) return NULL;

    eqp = strchr(eq, '=');
    if (eqp) {
        size_t ll = (size_t)(eqp - eq);
        const char *rs = eqp + 1;
        int lempty = 1, rempty = 1;
        char *ls;
        for (i = 0; i < (int)ll; i++)
            if (!isspace((unsigned char)eq[i])) { lempty = 0; break; }
        for (i = 0; rs[i]; i++)
            if (!isspace((unsigned char)rs[i])) { rempty = 0; break; }
        if (lempty || rempty) {
            if (err) snprintf(err, errsz,
                "等号%s边是空的（解方程要写成 左=右，比如 \"x^2 - 5*x + 6 = 0\"）",
                lempty ? "左" : "右");
            return NULL;
        }
        ls = ar_strdup(&ar, eq, ll);
        lh = compile1(ls, &ar, err, errsz);
        if (!lh) goto fail;
        rh = compile1(rs, &ar, err, errsz);
        if (!rh) goto fail;
    } else {
        lh = compile1(eq, &ar, err, errsz);
        if (!lh) goto fail;
        rh = nd_num(&ar, 0);
    }

    /* 左 - 右；先化简再展开——(x-1)^3、x*(x+1) 这类要先展开才收得动系数 */
    e = simp(&ar, expand(&ar, simplified(&ar, nd_bin(&ar, N_SUB, lh, rh))));

    collect_vars(e, names, &nn, 64);
    if (nn > 0) {
        int has = 0;
        SB vb;
        sb_init(&vb);
        for (i = 0; i < nn; i++) {
            if (strcmp(names[i], var) == 0) { has = 1; continue; }
            if (vb.n) sb_puts(&vb, "、");
            sb_puts(&vb, names[i]);
        }
        if (!has || vb.n) {
            if (err) {
                if (has)
                    snprintf(err, errsz,
                        "方程里还有别的变量 %s，第一版只解单变量方程（先用 sym.替换 把它们代成数字）",
                        vb.p);
                else
                    snprintf(err, errsz,
                        "方程里找不到变量 %s（里面出现的是 %s）", var, vb.p);
            }
            free(vb.p);
            goto fail;
        }
        free(vb.p);
    }

    for (i = 0; i < 80; i++) coef[i] = 0;
    if (!poly_term_s(e, var, 12, coef, 1, 1)) {
        for (i = 0; i < 80; i++) coef[i] = 0;
        if (poly_term_s(e, var, 64, coef, 1, 1)) {
            if (err) snprintf(err, errsz,
                "方程次数太高了（超过 12 次），数值求根不可靠（先因式分解，再分开解）");
            goto fail;
        }
        if (err) snprintf(err, errsz,
            "方程不是 %s 的多项式（含 sin(%s)、1/%s、%s^0.5 或未展开的乘积这类项），"
            "第一版只解多项式方程；可以先 sym.展开 / sym.化简，或用 sym.求值 做数值代入",
            var, var, var, var);
        goto fail;
    }
    for (i = 79; i >= 1; i--)
        if (fabs(coef[i]) > 1e-12) { deg = i; break; }
    for (i = 0; i <= deg; i++)
        if (fabs(coef[i]) < 1e-12) coef[i] = 0;

    if (deg == 0) {                       /* 方程与 var 无关：恒等或无解 */
        sb_init(&b);
        sb_puts(&b, fabs(coef[0]) < 1e-12 ? "恒等式（任何值都成立）"
                                          : "无解（两边永远不相等）");
        ar_free(&ar);
        return b.p;
    }
    if (deg == 1) {
        roots[0] = -coef[0] / coef[1];
        nr = 1;
    } else if (deg == 2) {
        double a2 = coef[2], a1 = coef[1], a0 = coef[0];
        double disc = a1 * a1 - 4 * a2 * a0;
        double tol = 1e-12 * (1 + fabs(a1) + fabs(a2 * a0));
        if (disc > tol) {
            double sq = sqrt(disc);
            roots[0] = (-a1 - sq) / (2 * a2);
            roots[1] = (-a1 + sq) / (2 * a2);
            nr = 2;
        } else if (disc < -tol) {
            if (err) snprintf(err, errsz,
                "没有实数解（判别式 %.10g < 0，根是一对复数）", disc);
            goto fail;
        } else {
            roots[0] = -a1 / (2 * a2);      /* 重根 */
            nr = 1;
        }
    } else {
        nr = poly_real_roots(coef, deg, roots, 16);
        if (nr < 0) {
            if (err) snprintf(err, errsz, "数值求根失败（方程太病态了，换数值方法吧）");
            goto fail;
        }
        if (nr == 0) {
            if (err) snprintf(err, errsz,
                "没有找到实数解（根全是复数，或者数值求根没收敛）");
            goto fail;
        }
    }
    for (i = 1; i < nr; i++) {             /* 升序 */
        double key = roots[i];
        int j = i - 1;
        while (j >= 0 && roots[j] > key) { roots[j + 1] = roots[j]; j--; }
        roots[j + 1] = key;
    }
    sb_init(&b);
    for (i = 0; i < nr; i++) {
        char rb[48];
        fmt_root(roots[i], rb, sizeof rb);
        if (i) sb_puts(&b, ", ");
        sb_puts(&b, var);
        sb_puts(&b, " = ");
        sb_puts(&b, rb);
    }
    ar_free(&ar);
    return b.p;
fail:
    ar_free(&ar);
    return NULL;
}

/* ==================== 输出格式（sym.格式） ==================== */

/* mode："" / "plain"（默认，与 sym.解析 逐字一致）/ "latex" / "unicode"（认 uni） */
char *sym_core_format(const char *expr, const char *mode, char *err, size_t errsz)
{
    Arena ar = {0};
    Node *n;
    const RendStyle *st;
    SB b;

    if (!mode || !*mode || strcmp(mode, "plain") == 0) st = &ST_PLAIN;
    else if (strcmp(mode, "latex") == 0) st = &ST_LATEX;
    else if (strcmp(mode, "unicode") == 0 || strcmp(mode, "uni") == 0) st = &ST_UNI;
    else {
        if (err) snprintf(err, errsz,
            "输出模式只认 plain / latex / unicode（收到 \"%s\"）", mode);
        return NULL;
    }
    n = compile1(expr, &ar, err, errsz);
    if (!n) return NULL;
    sb_init(&b);
    rend(&b, n, 0, 0, st);
    ar_free(&ar);
    return b.p;
}

/* ==================== 线性代数地基：精确分数 + 线性收集 + 高斯消元 ==================== */

/* 精确分数：num/den 恒约分、分母恒正；den==0 是「溢出毒丸」，随运算传播，
 * 使用者查到毒丸就认输（返回明确错误），绝不把错数当答案。 */
typedef struct { long long num, den; } Frac;
#define FR_POISON ((Frac){0, 0})

static long long gcd_ll(long long a, long long b)
{
    if (a < 0) a = -a;
    if (b < 0) b = -b;
    while (b) { long long t = a % b; a = b; b = t; }
    return a;
}

static Frac fr_int(long long v) { Frac f; f.num = v; f.den = 1; return f; }

/* 量级上限：本模块的系数都来自教学级表达式，1e15 足够；再大直接毒丸，
 * 免得 int64 中间量溢出后悄悄给出错答案。 */
static int fr_big(Frac f)
{
    return f.num > 1000000000000000LL || f.num < -1000000000000000LL;
}

static Frac fr_norm(long long n, long long d)
{
    Frac f;
    long long g;
    if (d == 0) return FR_POISON;
    if (d < 0) { n = -n; d = -d; }
    g = gcd_ll(n, d);
    if (g > 1) { n /= g; d /= g; }
    f.num = n;
    f.den = d;
    return f;
}

static Frac fr_neg(Frac a) { Frac f; f.num = -a.num; f.den = a.den; return f; }

static Frac fr_add(Frac a, Frac b)
{
    long long g, n1, n2, n, d;
    if (!a.den || !b.den) return FR_POISON;
    if (fr_big(a) || fr_big(b)) return FR_POISON;
    g = gcd_ll(a.den, b.den);
    if (__builtin_mul_overflow(a.num, b.den / g, &n1)) return FR_POISON;
    if (__builtin_mul_overflow(b.num, a.den / g, &n2)) return FR_POISON;
    if (__builtin_add_overflow(n1, n2, &n)) return FR_POISON;
    if (__builtin_mul_overflow(a.den / g, b.den, &d)) return FR_POISON;
    return fr_norm(n, d);
}

static Frac fr_sub(Frac a, Frac b) { return fr_add(a, fr_neg(b)); }

static Frac fr_mul(Frac a, Frac b)
{
    long long g, n, d;
    if (!a.den || !b.den) return FR_POISON;
    if (fr_big(a) || fr_big(b)) return FR_POISON;
    g = gcd_ll(a.num, b.den);               /* 先交叉约分再乘，防溢出 */
    if (g > 1) { a.num /= g; b.den /= g; }
    g = gcd_ll(b.num, a.den);
    if (g > 1) { b.num /= g; a.den /= g; }
    if (__builtin_mul_overflow(a.num, b.num, &n)) return FR_POISON;
    if (__builtin_mul_overflow(a.den, b.den, &d)) return FR_POISON;
    return fr_norm(n, d);
}

static Frac fr_div(Frac a, Frac b)
{
    Frac t;
    if (!a.den || !b.den || b.num == 0) return FR_POISON;
    t.num = b.den;                                /* a/b = a·(b.den/b.num) */
    t.den = b.num;
    if (t.num < 0) { t.num = -t.num; t.den = -t.den; }
    return fr_mul(a, t);
}

static double fr_val(Frac f) { return f.den ? (double)f.num / (double)f.den : 0.0; }

static int fr_eq(Frac a, Frac b) { return a.den && b.den && a.num == b.num && a.den == b.den; }

/* double → 精确分数：整数优先，其次小分母（dens 到 64，容差 1e-9·den·(1+|v|)）。
 * 是「普通有理数」才成功；π、sin(1)、0.3333333334 这类一律拒绝（返回 0）。 */
static int fr_from_double(double v, Frac *out)
{
    static const int dens[] = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 12, 16, 20, 24, 32, 48, 64 };
    double a = fabs(v);
    int k, num, den, g;
    if (v == 0) { *out = fr_int(0); return 1; }
    if (!(a < 1e12)) return 0;
    for (k = 0; k < (int)(sizeof dens / sizeof *dens); k++) {
        den = dens[k];
        if (fabs(a * den - floor(a * den + 0.5)) <= 1e-9 * den * (1 + a)) {
            num = (int)floor(a * den + 0.5);
            g = gcd_int(num, den);
            if (g < 1) g = 1;
            num /= g;
            den /= g;
            *out = fr_norm((long long)(v < 0 ? -num : num), (long long)den);
            return out->den != 0;
        }
    }
    return 0;
}

/* 有理平方根：D 是有理数的完全平方才成功（其余返回 0，调用方回落 double） */
static long long isqrt_ll(long long v)
{
    long long r;
    if (v < 0) return -1;
    r = (long long)sqrt((double)v);
    while (r > 0 && r * r > v) r--;
    while ((r + 1) * (r + 1) <= v) r++;
    return r;
}

static int fr_sqrt_rat(Frac d, Frac *out)
{
    long long p, q;
    if (!d.den || d.num < 0) return 0;
    p = isqrt_ll(d.num);
    q = isqrt_ll(d.den);
    if (p < 0 || q < 1) return 0;
    if (p * p != d.num || q * q != d.den) return 0;
    *out = fr_norm(p, q);
    return out->den != 0;
}

static void fmt_frac(Frac f, char *buf, size_t sz)
{
    if (!f.den) { snprintf(buf, sz, "?"); return; }
    if (f.den == 1) snprintf(buf, sz, "%lld", f.num);
    else snprintf(buf, sz, "%lld/%lld", f.num, f.den);
}

static Node *nd_frac(Arena *ar, Frac f)
{
    if (f.den == 1) return nd_num(ar, (double)f.num);
    return nd_bin(ar, N_DIV, nd_num(ar, (double)f.num), nd_num(ar, (double)f.den));
}

/* ---------- 多项式（Frac 系数，c[0] 常数项；deg=-1 零多项式） ---------- */
#define FP_MAX 16

typedef struct { Frac c[FP_MAX]; int deg; } FPoly;

static void fp_zero(FPoly *p)
{
    int i;
    for (i = 0; i < FP_MAX; i++) p->c[i] = fr_int(0);
    p->deg = -1;
}

static void fp_trim(FPoly *p)
{
    while (p->deg >= 0 && p->c[p->deg].den && p->c[p->deg].num == 0) p->deg--;
}

static int fp_ok(const FPoly *p)
{
    int i;
    for (i = 0; i <= p->deg; i++) if (!p->c[i].den) return 0;
    return 1;
}

static int fp_from_coefs(FPoly *p, const double *c, int n)
{
    int i;
    if (n < 0 || n >= FP_MAX) return 0;
    fp_zero(p);
    for (i = 0; i <= n; i++)
        if (!fr_from_double(c[i], &p->c[i])) return 0;
    p->deg = n;
    fp_trim(p);
    return 1;
}

static int fp_mul(FPoly *r, const FPoly *a, const FPoly *b)
{
    FPoly t;
    int i, j;
    if (a->deg < 0 || b->deg < 0) { fp_zero(r); return 1; }
    if (a->deg + b->deg >= FP_MAX) return 0;
    fp_zero(&t);
    for (i = 0; i <= a->deg; i++) {
        if (a->c[i].num == 0) continue;
        for (j = 0; j <= b->deg; j++) {
            if (b->c[j].num == 0) continue;
            t.c[i + j] = fr_add(t.c[i + j], fr_mul(a->c[i], b->c[j]));
            if (!t.c[i + j].den) return 0;
        }
    }
    t.deg = a->deg + b->deg;
    fp_trim(&t);
    *r = t;
    return 1;
}

/* 综合除法：a(x) = (x - r)·q(x) + rem */
static int fp_div_lin(FPoly *q, Frac *rem, const FPoly *a, Frac r)
{
    FPoly t;
    int k;
    if (a->deg < 0) { fp_zero(q); if (rem) *rem = fr_int(0); return 1; }
    if (a->deg >= FP_MAX) return 0;
    fp_zero(&t);
    t.deg = a->deg - 1;
    if (t.deg >= 0) {
        t.c[t.deg] = a->c[a->deg];
        for (k = a->deg - 2; k >= 0; k--) {
            Frac v = fr_add(a->c[k + 1], fr_mul(r, t.c[k + 1]));
            if (!v.den) return 0;
            t.c[k] = v;
        }
    }
    if (rem) {
        Frac rr = a->deg >= 1 ? fr_add(a->c[0], fr_mul(r, t.c[0])) : a->c[0];
        if (!rr.den) return 0;
        *rem = rr;
    }
    *q = t;
    return 1;
}

static Frac fp_at(const FPoly *p, Frac x)
{
    Frac r = fr_int(0);
    int i;
    for (i = p->deg; i >= 0; i--) {
        r = fr_add(fr_mul(r, x), p->c[i]);
        if (!r.den) return FR_POISON;
    }
    return r;
}

/* 多项式长除：a = b·q + r（deg r < deg b） */
static int fp_divmod(FPoly *q, FPoly *r, const FPoly *a, const FPoly *b)
{
    FPoly rem, quo;
    if (b->deg < 0) return 0;
    rem = *a;
    fp_zero(&quo);
    while (rem.deg >= b->deg && rem.deg >= 0) {
        Frac lc = fr_div(rem.c[rem.deg], b->c[b->deg]);
        int k = rem.deg - b->deg, j;
        if (!lc.den) return 0;
        quo.c[k] = lc;
        for (j = 0; j <= b->deg; j++) {
            Frac v = fr_sub(rem.c[k + j], fr_mul(lc, b->c[j]));
            if (!v.den) return 0;
            rem.c[k + j] = v;
        }
        fp_trim(&rem);
    }
    quo.deg = a->deg >= b->deg ? a->deg - b->deg : -1;
    fp_trim(&quo);
    *q = quo;
    *r = rem;
    return 1;
}

/* 多项式 → 节点（经典形式：次数降序） */
/* ∫p dx：把 Frac 系数多项式积成 Node（零多项式返回 NULL） */
static Node *fp_integ_node(Arena *ar, const FPoly *p, const char *var)
{
    Node *acc = NULL;
    int i;
    for (i = 0; i <= p->deg; i++) {
        Frac co;
        Node *pw, *t;
        if (p->c[i].num == 0) continue;
        co = fr_div(p->c[i], fr_int(i + 1));
        if (!co.den) return NULL;
        pw = nd_bin(ar, N_POW, nd_var(ar, var), nd_num(ar, (double)(i + 1)));
        t = (co.num == 1 && co.den == 1)
            ? pw : nd_bin(ar, N_MUL, nd_frac(ar, co), pw);
        acc = acc ? nd_bin(ar, N_ADD, acc, t) : t;
    }
    return acc;
}

/* ---------- 精确线性求解（高斯-约当，n≤12） ---------- */

/* A（n×n 行优先，A[i][j] = 第 i 个方程里第 j 个未知数的系数）x = b。
 * 返回 1=唯一解（x 按未知数下标）；0=奇异（*rank 出秩、pivcol 出主元列、
 * *incon 出是否矛盾）；-1=算术溢出（毒丸）。 */
static int lin_solve(Frac *A, Frac *b, int n, Frac *x,
                     int *rank, int *pivcol, int *incon)
{
    int r = 0, c, i, j;
    *incon = 0;
    for (c = 0; c < n && r < n; c++) {
        int pr = -1;
        Frac pv;
        for (i = r; i < n; i++)
            if (A[i * n + c].den && A[i * n + c].num != 0) { pr = i; break; }
        if (pr < 0) continue;
        if (pr != r) {
            for (j = 0; j < n; j++) {
                Frac t = A[r * n + j]; A[r * n + j] = A[pr * n + j]; A[pr * n + j] = t;
            }
            { Frac t = b[r]; b[r] = b[pr]; b[pr] = t; }
        }
        pv = A[r * n + c];
        for (j = c; j < n; j++) {
            A[r * n + j] = fr_div(A[r * n + j], pv);
            if (!A[r * n + j].den) return -1;
        }
        b[r] = fr_div(b[r], pv);
        if (!b[r].den) return -1;
        for (i = 0; i < n; i++) {
            Frac f;
            if (i == r) continue;
            f = A[i * n + c];
            if (f.num == 0) continue;
            for (j = c; j < n; j++) {
                A[i * n + j] = fr_sub(A[i * n + j], fr_mul(f, A[r * n + j]));
                if (!A[i * n + j].den) return -1;
            }
            b[i] = fr_sub(b[i], fr_mul(f, b[r]));
            if (!b[i].den) return -1;
        }
        pivcol[r] = c;
        r++;
    }
    *rank = r;
    for (i = 0; i < n; i++) {               /* 全零系数行却有非零右端 → 矛盾 */
        int allz = 1;
        for (j = 0; j < n; j++)
            if (A[i * n + j].den && A[i * n + j].num != 0) { allz = 0; break; }
        if (allz && b[i].den && b[i].num != 0) { *incon = 1; return 0; }
    }
    if (r < n) return 0;                    /* 秩不满 → 无穷多组解 */
    for (i = 0; i < n; i++) x[pivcol[i]] = b[i];
    return 1;
}

/* ---------- 多元线性收集 ---------- */

static int has_var_any(Node *n, char **vars, int nv)
{
    int i;
    for (i = 0; i < nv; i++) if (has_var(n, vars[i])) return 1;
    return 0;
}

/* 把「已展开」的表达式按 vars[0..nv) 收成 Σcoef[i]*vars[i] + cst。
 * why：0 成功；1 非线性（高次幂/变量乘变量/sin(x)/变量在分母）；
 *      2 系数不是普通有理数（π、sin(1)、怪小数）；3 出现变量串外的变量。
 * sgn/scale 递归传递符号与常数比例（分数精确累乘）。 */
static int lin_collect(Node *n, char **vars, int nv, Frac *coef, Frac *cst,
                       int sgn, Frac scale, int *why, char *badvar, size_t badsz)
{
    Frac f;
    double v;
    int i;

    if (n->kind == N_NEG)
        return lin_collect(n->a, vars, nv, coef, cst, -sgn, scale, why, badvar, badsz);
    if (n->kind == N_ADD) {
        if (!lin_collect(n->a, vars, nv, coef, cst, sgn, scale, why, badvar, badsz)) return 0;
        return lin_collect(n->b, vars, nv, coef, cst, sgn, scale, why, badvar, badsz);
    }
    if (n->kind == N_SUB) {
        if (!lin_collect(n->a, vars, nv, coef, cst, sgn, scale, why, badvar, badsz)) return 0;
        return lin_collect(n->b, vars, nv, coef, cst, -sgn, scale, why, badvar, badsz);
    }
    if (n->kind == N_DIV) {                 /* 分母不许含变量 */
        for (i = 0; i < nv; i++)
            if (has_var(n->b, vars[i])) { *why = 1; return 0; }
        if (!const_eval(n->b, &v) || v == 0) { *why = 1; return 0; }
        if (!fr_from_double(v, &f)) { *why = 2; return 0; }
        return lin_collect(n->a, vars, nv, coef, cst, sgn, fr_div(scale, f),
                           why, badvar, badsz);
    }
    if (n->kind == N_MUL) {
        Node *fs[256];
        int nf = 0, vi = -1;
        Frac sc = scale;
        collect_mul(n, fs, &nf, 256);
        if (nf == 0) { *why = 1; return 0; }
        for (i = 0; i < nf; i++) {
            Node *g = fs[i];
            int neg = 0, j;
            if (g->kind == N_NEG) { neg = 1; g = g->a; }
            if (!has_var_any(g, vars, nv)) {          /* 常数因子（含 pi/e 折叠项） */
                double vv;
                if (!const_eval(g, &vv)) { *why = 1; return 0; }
                if (!fr_from_double(vv, &f)) { *why = 2; return 0; }
                if (neg) f = fr_neg(f);
                sc = fr_mul(sc, f);
                if (!sc.den) { *why = 2; return 0; }
                continue;
            }
            if (g->kind == N_DIV) {                   /* x/2 这类：分母常数、分子单变量 */
                double vd;
                Node *num;
                int nneg = 0;
                for (j = 0; j < nv; j++)
                    if (has_var(g->b, vars[j])) { *why = 1; return 0; }
                if (!const_eval(g->b, &vd) || vd == 0) { *why = 1; return 0; }
                if (!fr_from_double(vd, &f)) { *why = 2; return 0; }
                if (neg) f = fr_neg(f);
                sc = fr_mul(sc, fr_div(fr_int(1), f));
                if (!sc.den) { *why = 2; return 0; }
                num = g->a;
                if (num->kind == N_NEG) { nneg = 1; num = num->a; }
                if (num->kind != N_VAR) { *why = 1; return 0; }
                g = num;
                neg = nneg;
            }
            if (g->kind != N_VAR) { *why = 1; return 0; }  /* x^2、x*y、sin(x)*x 都到这 */
            if (vi >= 0) { *why = 1; return 0; }           /* 第二个变量因子 → 二次 */
            for (j = 0; j < nv; j++)
                if (strcmp(g->str, vars[j]) == 0) { vi = j; break; }
            if (vi < 0) {
                *why = 3;
                if (badvar) snprintf(badvar, badsz, "%s", g->str);
                return 0;
            }
            if (neg) sc = fr_neg(sc);
        }
        {
            Frac contrib = fr_mul(fr_int(sgn), sc);
            if (!contrib.den) { *why = 2; return 0; }
            if (vi >= 0) {
                coef[vi] = fr_add(coef[vi], contrib);
                if (!coef[vi].den) { *why = 2; return 0; }
            } else {
                *cst = fr_add(*cst, contrib);
                if (!cst->den) { *why = 2; return 0; }
            }
        }
        return 1;
    }
    if (n->kind == N_VAR) {
        int idx = -1;
        for (i = 0; i < nv; i++)
            if (strcmp(n->str, vars[i]) == 0) { idx = i; break; }
        if (idx < 0) {
            *why = 3;
            if (badvar) snprintf(badvar, badsz, "%s", n->str);
            return 0;
        }
        {
            Frac contrib = fr_mul(fr_int(sgn), scale);
            if (!contrib.den) { *why = 2; return 0; }
            coef[idx] = fr_add(coef[idx], contrib);
            if (!coef[idx].den) { *why = 2; return 0; }
        }
        return 1;
    }
    /* 常数段：NUM / CONST(pi,e) / 折叠过的 FUNC(1) / 常数 POW */
    if (!has_var_any(n, vars, nv)) {
        if (!const_eval(n, &v)) { *why = 1; return 0; }
        if (!fr_from_double(v, &f)) { *why = 2; return 0; }
        {
            Frac contrib = fr_mul(fr_int(sgn), fr_mul(scale, f));
            if (!contrib.den) { *why = 2; return 0; }
            *cst = fr_add(*cst, contrib);
            if (!cst->den) { *why = 2; return 0; }
        }
        return 1;
    }
    *why = 1;                                /* POW(x,2)/FUNC(sin(x)) 等 */
    return 0;
}

/* ---------- 解线性方程组 ---------- */

static char *xdup(const char *s)
{
    size_t n = strlen(s) + 1;
    char *p = (char *)malloc(n);
    if (p) memcpy(p, s, n);
    return p;
}

/* 按分隔符集切串（跳过空段、去首尾空白）；段数写入 *cnt。返回 malloc 的段数组。 */
static char **split_sep(const char *s, const char *seps, int *cnt, int cap)
{
    char **out = (char **)malloc(sizeof(char *) * (size_t)cap);
    const char *p = s;
    int n = 0;
    if (!out) { *cnt = 0; return NULL; }
    while (*p && n < cap) {
        const char *q = p;
        size_t st, len;
        char *seg;
        while (*q && !strchr(seps, *q)) q++;
        st = 0;
        len = (size_t)(q - p);
        while (len > 0 && (p[len - 1] == ' ' || p[len - 1] == '\t')) len--;
        while (st < len && (p[st] == ' ' || p[st] == '\t')) st++;
        len -= st;
        if (len > 0) {
            seg = (char *)malloc(len + 1);
            if (!seg) break;
            memcpy(seg, p + st, len);
            seg[len] = 0;
            out[n++] = seg;
        }
        p = *q ? q + 1 : q;
    }
    *cnt = n;
    return out;
}

static void free_segs(char **segs, int n)
{
    int i;
    for (i = 0; i < n; i++) free(segs[i]);
    free(segs);
}

/* 解线性方程组：eqs 形如 "x+y=3;x-y=1"（; ；换行分隔，缺 = 当右边是 0），
 * vars 形如 "x,y"（, ，分隔）。返回 "x = 1, y = 2"（按变量串顺序）；
 * 奇异分无解（矛盾）/ 无穷多组解（点名自由变量）；失败返回 NULL（err 有文案）。 */
char *sym_core_solve_sys(const char *eqs, const char *vars_str, char *err, size_t errsz)
{
    Arena ar = {0};
    char *vnames[8];
    char **eqsegs;
    int nv = 0, ne = 0, i, j, rc, rank, incon, why = 0;
    int pivcol[8];
    Frac A[64], b[8], x[8], coef[8], cst;
    char badvar[64] = "";
    char buf[600];
    size_t pos = 0;

    /* ---- 变量串 ---- */
    {
        char **vs = split_sep(vars_str, ",， \t", &nv, 8);
        if (!vs) { snprintf(err, errsz, "内存不够了"); return NULL; }
        if (nv == 0) {
            free_segs(vs, nv);
            snprintf(err, errsz,
                "变量串是空的——第二个参数要写变量名，多变量用逗号分隔，比如 \"x,y\"");
            return NULL;
        }
        for (i = 0; i < nv; i++) {
            if (!is_ident(vs[i]) || is_const_name(vs[i])) {
                snprintf(err, errsz,
                    "变量名「%s」看不懂（pi 和 e 是常量，不能当变量；名字里不要带运算符）", vs[i]);
                free_segs(vs, nv);
                return NULL;
            }
            for (j = 0; j < i; j++) {
                if (strcmp(vs[i], vs[j]) == 0) {
                    snprintf(err, errsz, "变量串里有重复的 %s", vs[i]);
                    free_segs(vs, nv);
                    return NULL;
                }
            }
            vnames[i] = ar_strdup(&ar, vs[i], strlen(vs[i]));
            if (!vnames[i]) { free_segs(vs, nv); snprintf(err, errsz, "内存不够了"); return NULL; }
        }
        free_segs(vs, nv);
    }

    /* ---- 方程串 ---- */
    eqsegs = split_sep(eqs, ";；\n\r", &ne, 8);
    if (!eqsegs) { snprintf(err, errsz, "内存不够了"); goto fail; }
    if (ne == 0) {
        snprintf(err, errsz,
            "一条方程都没有——第一个参数要写方程，多条用分号隔开，比如 \"x+y=3;x-y=1\"");
        free_segs(eqsegs, ne);
        goto fail;
    }
    if (ne != nv) {
        snprintf(err, errsz,
            "方程数（%d）和变量数（%d）不一样——第一版只解个数相同的方程组"
            "（单方程用 sym.求解；想多退少补，先补上或去掉方程）", ne, nv);
        free_segs(eqsegs, ne);
        goto fail;
    }

    for (i = 0; i < ne; i++) {
        int k2;
        const char *eq = strchr(eqsegs[i], '=');
        for (k2 = 0; k2 < nv; k2++) coef[k2] = fr_int(0);
        cst = fr_int(0);
        Node *lh, *rh, *e;
        if (eq) {
            size_t ll = (size_t)(eq - eqsegs[i]);
            const char *rs = eq + 1;
            int lempty = 1, rempty = 1;
            size_t t;
            for (t = 0; t < ll; t++)
                if (!isspace((unsigned char)eqsegs[i][t])) { lempty = 0; break; }
            for (t = 0; rs[t]; t++)
                if (!isspace((unsigned char)rs[t])) { rempty = 0; break; }
            if (lempty || rempty) {
                snprintf(err, errsz,
                    "第 %d 条方程的等号%s边是空的（要写成 左=右，比如 \"x + y = 3\"）",
                    i + 1, lempty ? "左" : "右");
                free_segs(eqsegs, ne);
                goto fail;
            }
            {
                char *ls = ar_strdup(&ar, eqsegs[i], ll);
                if (!ls) { snprintf(err, errsz, "内存不够了"); free_segs(eqsegs, ne); goto fail; }
                lh = compile1(ls, &ar, err, errsz);
                if (!lh) { free_segs(eqsegs, ne); goto fail; }
                rh = compile1(rs, &ar, err, errsz);
                if (!rh) { free_segs(eqsegs, ne); goto fail; }
            }
        } else {
            lh = compile1(eqsegs[i], &ar, err, errsz);
            if (!lh) { free_segs(eqsegs, ne); goto fail; }
            rh = nd_num(&ar, 0);
        }
        e = simp(&ar, expand(&ar, simplified(&ar, nd_bin(&ar, N_SUB, lh, rh))));

        for (j = 0; j < nv; j++) coef[j] = fr_int(0);
        cst = fr_int(0);
        why = 0;
        if (!lin_collect(e, vnames, nv, coef, &cst, 1, fr_int(1), &why, badvar, sizeof badvar)) {
            if (why == 1)
                snprintf(err, errsz,
                    "第 %d 条方程不是线性的（出现高次幂、变量乘变量、sin(x) 或变量在分母里）"
                    "——第一版只解线性方程组", i + 1);
            else if (why == 2)
                snprintf(err, errsz,
                    "第 %d 条方程里有 π、e 或很怪的小数值当系数——第一版只解有理数系数的"
                    "线性方程组", i + 1);
            else
                snprintf(err, errsz,
                    "第 %d 条方程里出现变量 %s，但变量串里没有它（变量串：%s）",
                    i + 1, badvar, vars_str);
            free_segs(eqsegs, ne);
            goto fail;
        }
        /* 对拍：线性形式在两个采样点上必须和原表达式一致（挡错转分数） */
        {
            static double pv[16] = { 2, -3, 5, 7, -11, 13, 17, -19,
                                           3, -5, 7, -9, 11, -13, 15, -17 };
            int t, okc = 1;
            for (t = 0; t < 2 && okc; t++) {
                double sum = 0, ev, lv;
                for (j = 0; j < nv; j++)
                    sum += fr_val(coef[j]) * pv[t + j];
                sum += fr_val(cst);
                if (!eval_node(e, vnames, pv + t, nv, &ev, NULL, 0)) { okc = 0; break; }
                lv = sum;
                if (!(fabs(ev - lv) <= 1e-9 * (1 + fabs(ev)))) okc = 0;
            }
            if (!okc) {
                snprintf(err, errsz,
                    "第 %d 条方程的系数没法精确表示（有小数值但不是普通分数）"
                    "——第一版只解有理数系数的线性方程组", i + 1);
                free_segs(eqsegs, ne);
                goto fail;
            }
        }
        for (j = 0; j < nv; j++) A[i * nv + j] = coef[j];
        b[i] = fr_neg(cst);
    }
    free_segs(eqsegs, ne);

    rc = lin_solve(A, b, nv, x, &rank, pivcol, &incon);
    if (rc < 0) {
        snprintf(err, errsz, "算术溢出（系数太大了，换数值方法吧）");
        goto fail;
    }
    if (rc == 0) {
        if (incon) {
            snprintf(err, errsz, "无解（这些方程互相矛盾，比如加起来推出 0=1）");
            ar_free(&ar);
            return NULL;
        } else {
            int first = 1;
            pos += (size_t)snprintf(buf + pos, sizeof buf - pos,
                "有无穷多组解（%d 个变量只有 %d 个独立方程；自由变量：", nv, rank);
            for (j = 0; j < nv; j++) {
                int ispiv = 0;
                for (i = 0; i < rank; i++) if (pivcol[i] == j) { ispiv = 1; break; }
                if (ispiv) continue;
                pos += (size_t)snprintf(buf + pos, sizeof buf - pos,
                    "%s%s", first ? "" : "、", vnames[j]);
                first = 0;
            }
            snprintf(buf + pos, sizeof buf - pos, "）");
        }
        ar_free(&ar);
        return xdup(buf);
    }
    for (i = 0; i < nv; i++) {
        char rb[48];
        fmt_frac(x[i], rb, sizeof rb);
        pos += (size_t)snprintf(buf + pos, sizeof buf - pos,
            "%s%s = %s", i ? ", " : "", vnames[i], rb);
        if (pos >= sizeof buf - 64) break;
    }
    ar_free(&ar);
    return xdup(buf);

fail:
    ar_free(&ar);
    return NULL;
}

/* ==================== 有理函数积分（长除 + 部分分式） ==================== */

/* 把首一多项式 Qm 分解成「有理线性因子（带重数）+ 至多一个最简二次」。
 * 线性因子写进 roots/rmul，Qm 自身被改成剩项。成功 1；形态不支持 0。 */
static int factor_den(FPoly *Qm, Frac *roots, int *rmul, int *nroots,
                      int *quad, Frac *qp, Frac *qs)
{
    int i;
    *nroots = 0;
    *quad = 0;
    while (Qm->deg >= 1) {
        Frac r;
        int found = 0;
        if (Qm->deg == 1) {
            r = fr_div(fr_neg(Qm->c[0]), Qm->c[1]);
            if (!r.den) return 0;
            found = 1;
        } else if (Qm->deg == 2) {
            Frac D = fr_sub(fr_mul(Qm->c[1], Qm->c[1]), fr_mul(fr_int(4), Qm->c[0]));
            Frac s;
            if (!D.den) return 0;
            if (D.num < 0) break;                       /* 最简二次，收工 */
            if (fr_sqrt_rat(D, &s)) {
                r = fr_div(fr_sub(fr_neg(Qm->c[1]), s), fr_int(2));
                if (!r.den) return 0;
                found = 1;
            } else break;                               /* 无理实根：认输 */
        } else {
            double qc[FP_MAX], rr[16];
            int nr, j2;
            for (j2 = 0; j2 <= Qm->deg; j2++) qc[j2] = fr_val(Qm->c[j2]);
            nr = poly_real_roots(qc, Qm->deg, rr, 16);
            if (nr <= 0) break;                         /* 没实根：剩项必然高次 → 认输 */
            for (j2 = 0; j2 < nr; j2++) {
                Frac cand, at;
                if (!fr_from_double(rr[j2], &cand)) continue;
                at = fp_at(Qm, cand);
                if (!at.den || at.num != 0) continue;   /* 精确验证，防数值根张冠李戴 */
                r = cand;
                found = 1;
                break;
            }
            if (!found) break;
        }
        {
            int m = 0;
            for (i = 0; i < *nroots; i++)
                if (fr_eq(roots[i], r)) return 0;       /* 防呆：不该重复找到 */
            if (*nroots >= 12) return 0;
            roots[*nroots] = r;
            while (Qm->deg >= 1) {
                Frac at = fp_at(Qm, r);
                FPoly q;
                if (!at.den || at.num != 0) break;
                if (!fp_div_lin(&q, NULL, Qm, r)) return 0;
                *Qm = q;
                m++;
            }
            if (m == 0) return 0;                       /* 防呆 */
            rmul[*nroots] = m;
            (*nroots)++;
        }
    }
    if (Qm->deg == 0) return 1;
    if (Qm->deg == 2) {
        Frac D = fr_sub(fr_mul(Qm->c[1], Qm->c[1]), fr_mul(fr_int(4), Qm->c[0]));
        if (D.den && D.num < 0) { *quad = 1; *qp = fr_neg(Qm->c[1]); *qs = Qm->c[0]; return 1; }
    }
    return 0;                                           /* 剩项既非 0 也非最简二次 */
}

/* 反导数值对拍：在「所有极点右侧」采 5 个点做中心差分，和原被积函数比。
 * 全过返回 1；对不上返回 0（调用方认输，绝不把错答案当真的交出去）。 */
static int anti_check(Arena *ar, Node *F, Node *g, const char *var, double maxpole)
{
    char *names[1];
    double base = maxpole > -1e8 ? maxpole : 0.0;
    double off[5];
    int i, ok = 0;
    names[0] = (char *)var;
    off[0] = 0.5; off[1] = 1.9; off[2] = 4.1; off[3] = 7.3; off[4] = 11.7;
    for (i = 0; i < 5; i++) {
        double xv = base + off[i], h = 1e-5 * (1 + fabs(xv));
        double d, gv;
        {
            double xp = xv + h, xm = xv - h, f2, f0;
            if (!eval_node(F, names, &xp, 1, &f2, NULL, 0)) continue;
            if (!eval_node(F, names, &xm, 1, &f0, NULL, 0)) continue;
            if (!isfinite(f2) || !isfinite(f0)) continue;
            d = (f2 - f0) / (2 * h);
        }
        if (!eval_node(g, names, &xv, 1, &gv, NULL, 0)) continue;
        if (!isfinite(d) || !isfinite(gv)) continue;
        if (fabs(d - gv) > 1e-4 * (1 + fabs(gv))) return 0;
        ok++;
    }
    return ok >= 3;
}

/* 有理函数积分：∫num/den dx。返回 1 成功（*out 原函数）、0 形态不支持（认输）。
 * 流水线：两侧展开成多项式 → 首一化 → 长除 → 分母分解（线性因子带重数 + 最简二次）
 * → 部分分式待定系数（清分母逐幂匹配，Frac 精确解）→ 逐项积分 → 数值对拍。 */
static int integ_rational(Arena *ar, Node *num, Node *den, const char *var, Node **out)
{
    double nc[FP_MAX], dc[FP_MAX];
    FPoly P, Q, Qm, quo, rem, R;
    Frac roots[12];
    int rmul[12], nroots = 0;
    int i, k, t, dn, qn, quad = 0, col, U;
    Frac qp = fr_int(0), qs = fr_int(0);
    Frac M[144], rhs[12], sol[12];
    int pivcol[12], rank, incon, rc;
    FPoly lin_all, base_all, tmp, f1, rest, basis;
    Node *acc, *x;

    for (i = 0; i < FP_MAX; i++) { nc[i] = 0; dc[i] = 0; }
    {
        Node *nn = simp(ar, expand(ar, simplified(ar, num)));
        Node *dd = simp(ar, expand(ar, simplified(ar, den)));
        if (!poly_term_s(nn, var, 12, nc, 1, 1)) return 0;
        if (!poly_term_s(dd, var, 12, dc, 1, 1)) return 0;
    }
    dn = 12; while (dn > 0 && dc[dn] == 0) dn--;
    qn = 12; while (qn > 0 && nc[qn] == 0) qn--;
    if (dn < 1 || dc[dn] == 0) return 0;
    if (!fp_from_coefs(&P, nc, qn)) return 0;
    if (!fp_from_coefs(&Q, dc, dn)) return 0;
    if (!fp_ok(&P) || !fp_ok(&Q)) return 0;
    {
        Frac lead = Q.c[Q.deg];                          /* 首一化：lead 摊进分子 */
        for (i = 0; i <= Q.deg; i++) {
            Q.c[i] = fr_div(Q.c[i], lead);
            if (!Q.c[i].den) return 0;
        }
        for (i = 0; i <= P.deg; i++) {
            P.c[i] = fr_div(P.c[i], lead);
            if (!P.c[i].den) return 0;
        }
    }
    if (P.deg >= Q.deg) {
        if (!fp_divmod(&quo, &rem, &P, &Q)) return 0;
    } else {
        fp_zero(&quo);
        rem = P;
    }
    R = rem;
    Qm = Q;
    if (!factor_den(&Qm, roots, rmul, &nroots, &quad, &qp, &qs)) return 0;

    U = 0;
    for (i = 0; i < nroots; i++) U += rmul[i];
    if (quad) U += 2;
    if (U < 1 || U > 12 || U >= FP_MAX) return 0;
    if (R.deg >= U) return 0;                            /* 真分式保证 deg R < U */

    /* lin_all = ∏(x-r_i)^m_i；base_all = lin_all ·(二次?) —— 就是分母 */
    fp_zero(&lin_all);
    lin_all.deg = 0;
    lin_all.c[0] = fr_int(1);
    for (i = 0; i < nroots; i++) {
        for (k = 0; k < rmul[i]; k++) {
            FPoly lin;
            fp_zero(&lin);
            lin.deg = 1;
            lin.c[1] = fr_int(1);
            lin.c[0] = fr_neg(roots[i]);
            if (!fp_mul(&tmp, &lin_all, &lin)) return 0;
            lin_all = tmp;
        }
    }
    base_all = lin_all;
    if (quad) {
        FPoly q2;
        fp_zero(&q2);
        q2.deg = 2;
        q2.c[2] = fr_int(1);
        q2.c[1] = qp;
        q2.c[0] = qs;
        if (!fp_mul(&tmp, &base_all, &q2)) return 0;
        base_all = tmp;
    }
    if (base_all.deg != U) return 0;                     /* 防呆 */

    /* 恒等式逐幂匹配：对每个幂次 t（行），未知数 col（列）的基函数系数 */
    for (i = 0; i < U * U; i++) M[i] = fr_int(0);
    for (i = 0; i < U; i++) rhs[i] = i <= R.deg ? R.c[i] : fr_int(0);
    col = 0;
    for (i = 0; i < nroots; i++) {
        for (k = 1; k <= rmul[i]; k++) {
            rest = base_all;                             /* 分母除掉 (x-r)^m */
            for (t = 0; t < rmul[i]; t++) {
                FPoly q;
                if (!fp_div_lin(&q, NULL, &rest, roots[i])) return 0;
                rest = q;
            }
            fp_zero(&f1);                                /* (x-r)^(m-k) */
            if (rmul[i] - k == 0) {
                f1.deg = 0;
                f1.c[0] = fr_int(1);
            } else {
                FPoly lin, pw;
                fp_zero(&lin);
                lin.deg = 1;
                lin.c[1] = fr_int(1);
                lin.c[0] = fr_neg(roots[i]);
                fp_zero(&pw);
                pw.deg = 0;
                pw.c[0] = fr_int(1);
                for (t = 0; t < rmul[i] - k; t++) {
                    if (!fp_mul(&tmp, &pw, &lin)) return 0;
                    pw = tmp;
                }
                f1 = pw;
            }
            if (!fp_mul(&basis, &f1, &rest)) return 0;
            if (basis.deg >= U) return 0;
            for (t = 0; t < U; t++)
                M[t * U + col] = t <= basis.deg ? basis.c[t] : fr_int(0);
            col++;
        }
    }
    if (quad) {
        FPoly xlin, xmono;
        fp_zero(&xmono);                                /* 单项式 x */
        xmono.deg = 1;
        xmono.c[1] = fr_int(1);
        if (!fp_mul(&xlin, &lin_all, &xmono)) return 0;
        for (t = 0; t < U; t++)
            M[t * U + col] = t <= xlin.deg ? xlin.c[t] : fr_int(0);       /* B 的基：x·∏线性 */
        col++;
        for (t = 0; t < U; t++)
            M[t * U + col] = t <= lin_all.deg ? lin_all.c[t] : fr_int(0); /* C 的基：∏线性 */
        col++;
    }
    if (col != U) return 0;                              /* 防呆 */

    rc = lin_solve(M, rhs, U, sol, &rank, pivcol, &incon);
    if (rc != 1) return 0;

    /* ---- 组装原函数 ---- */
    x = nd_var(ar, var);
    acc = fp_integ_node(ar, &quo, var);                  /* 长除商积分后的多项式部分 */
    col = 0;
    for (i = 0; i < nroots; i++) {
        Node *xr = nd_bin(ar, N_SUB, x, nd_frac(ar, roots[i]));
        for (k = 1; k <= rmul[i]; k++) {
            Frac A = sol[col++];
            Node *term;
            if (A.num == 0) continue;
            if (k == 1) {
                term = nd_bin(ar, N_MUL, nd_frac(ar, A), nd_fn(ar, F_LOG, xr));
            } else {
                Frac co = fr_div(A, fr_int(1 - k));
                if (!co.den) return 0;
                term = nd_bin(ar, N_MUL, nd_frac(ar, co),
                              nd_bin(ar, N_POW, xr, nd_num(ar, (double)(1 - k))));
            }
            acc = acc ? nd_bin(ar, N_ADD, acc, term) : term;
        }
    }
    if (quad) {
        Frac B = sol[col], C = sol[col + 1];
        Frac w2, half_p = fr_div(qp, fr_int(2));
        if (B.num != 0) {                                /* (B/2)·log(x^2+px+s) */
            Frac h = fr_div(B, fr_int(2));
            Node *term = nd_bin(ar, N_MUL, nd_frac(ar, h),
                                nd_fn(ar, F_LOG,
                                      nd_bin(ar, N_ADD,
                                             nd_bin(ar, N_ADD,
                                                    nd_bin(ar, N_POW, x, nd_num(ar, 2)),
                                                    nd_bin(ar, N_MUL, nd_frac(ar, qp), x)),
                                             nd_frac(ar, qs))));
            acc = acc ? nd_bin(ar, N_ADD, acc, term) : term;
        }
        w2 = fr_sub(qs, fr_div(fr_mul(qp, qp), fr_int(4)));   /* s - p^2/4 > 0 */
        if (!w2.den || w2.num <= 0) return 0;
        {
            Frac k2 = fr_sub(C, fr_div(fr_mul(B, qp), fr_int(2)));  /* C - B·p/2 */
            if (k2.num != 0) {
                Frac w;
                Node *arg, *coef_node, *term;
                if (fr_sqrt_rat(w2, &w) && w.num != 0) {
                    coef_node = nd_frac(ar, fr_div(k2, w));
                    arg = nd_bin(ar, N_DIV,
                                 nd_bin(ar, N_ADD, x, nd_frac(ar, half_p)),
                                 nd_frac(ar, w));
                } else {
                    double wd = sqrt(fr_val(w2));
                    if (!(wd > 0) || !isfinite(wd)) return 0;
                    coef_node = nd_num(ar, fr_val(k2) / wd);
                    arg = nd_bin(ar, N_DIV,
                                 nd_bin(ar, N_ADD, x, nd_frac(ar, half_p)),
                                 nd_num(ar, wd));
                }
                if (!coef_node || !arg) return 0;
                term = nd_bin(ar, N_MUL, coef_node, nd_fn(ar, F_ATAN, arg));
                acc = acc ? nd_bin(ar, N_ADD, acc, term) : term;
            }
        }
    }

    /* ---- 数值对拍 ---- */
    {
        double maxpole = -1e9;
        for (i = 0; i < nroots; i++) {
            double v = fr_val(roots[i]);
            if (v > maxpole) maxpole = v;
        }
        if (!anti_check(ar, acc, nd_bin(ar, N_DIV, num, den), var, maxpole)) return 0;
    }
    *out = acc;
    return 1;
}


/* ==================== 极限与级数（sym.极限 / sym.级数） ==================== */

/* ---- 点的解析：数字 / pi / e / 算式；inf 系列字符串 ----
 * 返回 1=有限点（*pt 出值）；2=无穷（*sgn 出 ±1）；0=失败（err 有文案）。 */
static int parse_point(const char *s, double *pt, int *sgn, char *err, size_t errsz)
{
    const char *t = s;
    size_t n;
    char buf[128];
    Arena ar = {0};
    Node *pn;
    double v;
    int ok;

    while (*t == ' ' || *t == '\t') t++;
    n = strlen(t);
    while (n > 0 && (t[n-1]==' '||t[n-1]=='\t'||t[n-1]=='\n'||t[n-1]=='\r')) n--;
    if (n == 3 && strncmp(t, "inf", 3) == 0) { *sgn = 1; return 2; }
    if (n == 4 && strncmp(t, "+inf", 4) == 0) { *sgn = 1; return 2; }
    if (n == 4 && strncmp(t, "-inf", 4) == 0) { *sgn = -1; return 2; }
    if (n == 3 && (unsigned char)t[0]==0xE2 && (unsigned char)t[1]==0x88 &&
        (unsigned char)t[2]==0x9E) { *sgn = 1; return 2; }              /* "∞" */
    if (n == 4 && (unsigned char)t[0]=='-' && (unsigned char)t[1]==0xE2 &&
        (unsigned char)t[2]==0x88 && (unsigned char)t[3]==0x9E) { *sgn = -1; return 2; }  /* "-∞" */
    if (n == 0 || n >= sizeof buf) {
        if (err) snprintf(err, errsz,
            "第三个参数（点）看不懂：\"%s\"——写个数字、pi、e 或算式，无穷写 inf", s);
        return 0;
    }
    memcpy(buf, t, n);
    buf[n] = 0;
    pn = compile1(buf, &ar, err, errsz);
    if (!pn) { ar_free(&ar); return 0; }
    ok = eval_node(pn, NULL, NULL, 0, &v, NULL, 0);
    ar_free(&ar);
    if (!ok || !isfinite(v)) {
        if (err) snprintf(err, errsz,
            "第三个参数（点）看不懂：\"%s\"——写个数字、pi、e 或算式，无穷写 inf", s);
        return 0;
    }
    *pt = v;
    return 1;
}

/* ---- 极限专用求值：单变量绑到 pt ----
 * 除 0 不报错，按 IEEE 出 inf/nan（0/0=nan、∞/∞=nan，供洛必达判定未定式）；
 * 定义域错误（log<=0 / sqrt<0 / asin|acos 越界 / 负底非整数次幂）返回 0。
 * 公式里出现别的变量时该变量按 nan 参与运算（调用方已前置挡掉）。 */
static int eval_lim(Node *n, const char *var, double pt, double *out)
{
    double a = 0, b = 0;
    if (!n) return 0;
    switch (n->kind) {
    case N_NUM: *out = n->num; return 1;
    case N_CONST:
        *out = strcmp(n->str, "pi") == 0 ? 3.14159265358979323846 : 2.71828182845904523536;
        return 1;
    case N_VAR:
        *out = (strcmp(n->str, var) == 0) ? pt : NAN;
        return 1;
    case N_NEG:
        if (!eval_lim(n->a, var, pt, &a)) return 0;
        *out = -a;
        return 1;
    case N_ADD: case N_SUB: case N_MUL: case N_DIV: case N_POW:
        if (!eval_lim(n->a, var, pt, &a)) return 0;
        if (!eval_lim(n->b, var, pt, &b)) return 0;
        switch (n->kind) {
        case N_ADD: *out = a + b; return 1;
        case N_SUB: *out = a - b; return 1;
        case N_MUL: *out = a * b; return 1;
        case N_DIV: *out = a / b; return 1;      /* IEEE：0/0=nan、x/0=±inf */
        default:
            *out = pow(a, b);
            if (!isfinite(*out) && a < 0) return 0;   /* 负底非整数次幂不是实数 */
            return 1;
        }
    case N_FUNC: {
        int id = fn_id(n->str);
        if (!eval_lim(n->a, var, pt, &a)) return 0;
        switch (id) {
        case F_SIN: *out = sin(a); return 1;
        case F_COS: *out = cos(a); return 1;
        case F_TAN: *out = tan(a); return 1;
        case F_ASIN: if (a < -1 || a > 1) return 0; *out = asin(a); return 1;
        case F_ACOS: if (a < -1 || a > 1) return 0; *out = acos(a); return 1;
        case F_ATAN: *out = atan(a); return 1;
        case F_SINH: *out = sinh(a); return 1;
        case F_COSH: *out = cosh(a); return 1;
        case F_TANH: *out = tanh(a); return 1;
        case F_EXP: *out = exp(a); return 1;
        case F_LOG: if (a <= 0) return 0; *out = log(a); return 1;
        case F_SQRT: if (a < 0) return 0; *out = sqrt(a); return 1;
        case F_ABS: *out = fabs(a); return 1;
        }
        return 0;
    }
    }
    return 0;
}

/* 单侧探针：把 var 换成 x 求值（定义域外返回 0）。对拍与佐证共用。 */
static int probe_one(Arena *ar, Node *n, const char *var, double x, double *out)
{
    Node *s = subst_node(ar, n, var, nd_num(ar, x));
    if (!s) return 0;
    return eval_lim(s, var, x, out);
}

/* ---- 有限点：代入 + 洛必达 ----
 * 关键纪律：洛必达是「分子分母各自求导」，不是对商整体求导；而且只对真未定式
 * （0/0、∞/∞，IEEE 下都出 nan）用——5/0 出 inf 是真发散，x*sin(1/x) 出 nan 是
 * 内部乱抖，滥用洛必达会算出假答案（经典反例：1/x 在 0 处"洛"出 0）。 */
static int limit_finite(Arena *ar, Node *n, const char *var, double pt,
                        double *out, char *err, size_t errsz)
{
    Node *num, *den;
    /* 顶层是商才拆成 num/den 对——洛必达的地基。不拆的话整个表达式当分子，
     * sin(x)/x 代入得 nan 而不是 0/0，未定式分支永远进不去 */
    if (n->kind == N_DIV) { num = n->a; den = n->b; }
    else { num = n; den = nd_num(ar, 1); }
    int iter;
    double q = 0, vn = 0, vd = 1;

    for (iter = 0; iter <= 8; iter++) {
        Node *sn = subst_node(ar, num, var, nd_num(ar, pt));
        Node *sd = subst_node(ar, den, var, nd_num(ar, pt));
        Node *dn, *dd;
        if (!sn || !sd) {
            if (err) snprintf(err, errsz, "代入时内存不足");
            return 0;
        }
        if (!eval_lim(sn, var, pt, &vn) || !eval_lim(sd, var, pt, &vd)) {
            if (err) snprintf(err, errsz,
                "把 %s = %.10g 代进去之后，函数在那附近没定义（定义域越界）"
                "——极限可能还存在，但第一版看不出来", var, pt);
            return 0;
        }
        q = vn / vd;
        if (isfinite(q)) { *out = q; return 1; }
        if (isnan(q) && ((vn == 0 && vd == 0) || (isinf(vn) && isinf(vd)))) {
            dn = diff(ar, num, var);
            dd = diff(ar, den, var);
            if (!dn || !dd) {
                if (err) snprintf(err, errsz,
                    "这是个未定式，但洛必达法则要求的那一步求导没做出来"
                    "（比如 abs 在 0 处不可导）");
                return 0;
            }
            num = dn;
            den = dd;
            continue;
        }
        break;
    }
    if (isinf(q)) {
        /* 声称发散前先两侧探数：探测却收敛到一块儿，说明有 IEEE 陷阱，不敢下结论 */
        double pa, pb, h = 1e-6 * (1 + fabs(pt));
        if (probe_one(ar, n, var, pt + h, &pa) && probe_one(ar, n, var, pt - h, &pb) &&
            fabs(pa - pb) <= 1e-3 * (1 + fabs(pa))) {
            if (err) snprintf(err, errsz,
                "符号上看是发散，但两侧数值探测却收敛到一块儿（%.10g 与 %.10g）"
                "——可能是 1^inf、inf*0 这类 IEEE 陷阱，第一版认输", pa, pb);
        } else {
            if (err) snprintf(err, errsz,
                "极限不存在：%s 趋近 %.10g 时函数趋于无穷——左右两侧要分开看，"
                "第一版不分侧", var, pt);
        }
        return 0;
    }
    if (vn == 0 && vd == 0) {
        if (err) snprintf(err, errsz,
            "0/0 型未定式，洛必达法则迭代 8 次还没定下来"
            "（可能是更复杂的未定式，第一版认输）");
    } else if (isinf(vn) && isinf(vd)) {
        if (err) snprintf(err, errsz,
            "∞/∞ 型未定式，洛必达法则迭代 8 次还没定下来"
            "（可能是更复杂的未定式，第一版认输）");
    } else {
        if (err) snprintf(err, errsz,
            "把 %s = %.10g 代进去，式子里抖出了 nan（比如 sin(1/x) 乘 x 这类"
            "在零点附近乱抖的）——极限可能还存在（夹逼可能逼得出来），但第一版看不出来",
            var, pt);
    }
    return 0;
}

/* ---- 无穷远：±1e8/1e9/1e10 三点外推 ----
 * 相邻相对变化 ≤1e-6 判收敛；连续 10 倍暴涨判发散；否则（振荡/收敛极慢）认输。
 * 数值近似，不是符号计算——文档里如实写明。 */
static int limit_inf(Arena *ar, Node *n, const char *var, int sgn,
                     double *out, char *err, size_t errsz)
{
    static const double M[3] = { 1e8, 1e9, 1e10 };
    double v[3];
    int i;
    for (i = 0; i < 3; i++) {
        double x = sgn * M[i];
        if (!probe_one(ar, n, var, x, &v[i])) {
            if (err) snprintf(err, errsz,
                "在很大的数（%.0g）处函数没定义——无穷远的极限看不出来，第一版认输", x);
            return 0;
        }
    }
    if (isinf(v[0]) && isinf(v[1]) && isinf(v[2])) {
        if (err) snprintf(err, errsz,
            "极限不存在：函数随 %s 趋于无穷而发散（数值上直接溢成无穷）", var);
        return 0;
    }
    if (fabs(v[1]) > 10 * fabs(v[0]) && fabs(v[2]) > 10 * fabs(v[1])) {
        if (err) snprintf(err, errsz,
            "极限不存在：函数随 %s 趋于无穷而发散（数值上越涨越疯）", var);
        return 0;
    }
    if (fabs(v[2] - v[1]) <= 1e-6 * (1 + fabs(v[2])) &&
        fabs(v[1] - v[0]) <= 1e-6 * (1 + fabs(v[1]))) {
        *out = v[2];
        return 1;
    }
    if (err) snprintf(err, errsz,
        "在无穷远处定不下来（数值上在振荡或收敛极慢）——第一版只做数值外推，认输");
    return 0;
}

/* 数值对拍：pt±h 两侧探点，探到的侧必须全部落在答案 1e-4 相对容差内，且至少
 * 探到一侧（某一侧定义域外不算失败）。挡「符号算错」。 */
static int limit_anti(Arena *ar, Node *n, const char *var, double pt, double v)
{
    double h = 1e-6 * (1 + fabs(pt));
    double pa, pb;
    int oka = -1, okb = -1;
    if (probe_one(ar, n, var, pt + h, &pa))
        oka = (fabs(pa - v) <= 1e-4 * (1 + fabs(v)));
    if (probe_one(ar, n, var, pt - h, &pb))
        okb = (fabs(pb - v) <= 1e-4 * (1 + fabs(v)));
    if (oka < 0 && okb < 0) return 0;      /* 两侧都没定义：不敢认这份答案 */
    if (oka == 0 || okb == 0) return 0;    /* 探到的侧必须全过 */
    return 1;
}

/* 数值→小分母分数（dens 1..64，相对 1e-6 内才认）：数值外推的答案和 IEEE 噪声
 * （sin(pi)=1.2e-16）靠这个回到 "2"、"0" 这类干净形式；认不亲返回 0。 */
static int snap_frac(double v, Frac *out)
{
    int d;
    double n;
    if (!isfinite(v) || fabs(v) > 1e12) return 0;
    for (d = 1; d <= 64; d++) {
        n = floor(v * d + 0.5);
        if (fabs(v - n / d) <= 1e-6 * (1 + fabs(v))) {
            *out = fr_norm((long long)n, d);
            return out->den != 0;
        }
    }
    return 0;
}

/* 极限值格式化：尽量收成整数/小分母分数，收不成 %.10g。 */
static char *fmt_limit_val(double v)
{
    Frac f;
    SB b;
    char buf[48];
    if (fr_from_double(v, &f) || snap_frac(v, &f)) {
        sb_init(&b);
        fmt_frac(f, buf, sizeof buf);
        sb_puts(&b, buf);
        return b.p;
    }
    sb_init(&b);
    snprintf(buf, sizeof buf, "%.10g", v);
    sb_puts(&b, buf);
    return b.p;
}

/* 极限：expr 在 var → point 处的极限。point 可写数字/pi/e/算式，或 inf/-inf。
 * 有限点：代入 + 洛必达（只对 0/0、∞/∞ 真未定式用），答案过数值对拍才收；
 * 无穷点：大数值外推（数值近似，非符号计算）。失败返回 NULL（err 有文案）。 */
char *sym_core_limit(const char *expr, const char *var, const char *point,
                     char *err, size_t errsz)
{
    Arena ar = {0};
    Node *n;
    char *names[64];
    int nn = 0, i, ps, sgn = 1, r;
    double pt = 0, v = 0;
    char *out;

    if (bad_var_name(var, err, errsz)) return NULL;
    ps = parse_point(point, &pt, &sgn, err, errsz);
    if (ps == 0) return NULL;
    n = compile1(expr, &ar, err, errsz);
    if (!n) { ar_free(&ar); return NULL; }
    collect_vars(n, names, &nn, 64);
    for (i = 0; i < nn; i++)
        if (strcmp(names[i], var) != 0) {
            if (err) snprintf(err, errsz,
                "公式里还有变量 %s——sym.极限 一次只取一个变量的极限"
                "（可以先用 sym.替换 把别的变量换成具体数）", names[i]);
            ar_free(&ar);
            return NULL;
        }
    r = (ps == 2) ? limit_inf(&ar, n, var, sgn, &v, err, errsz)
                  : limit_finite(&ar, n, var, pt, &v, err, errsz);
    if (!r) { ar_free(&ar); return NULL; }
    if (ps == 1 && !limit_anti(&ar, n, var, pt, v)) {
        if (err) snprintf(err, errsz,
            "符号答案（%.10g）和两侧数值对拍不一致——第一版不敢认，交回给你", v);
        ar_free(&ar);
        return NULL;
    }
    out = fmt_limit_val(v);
    ar_free(&ar);
    return out;
}

/* ---- 泰勒展开（sym.级数） ---- */

/* 阶乘（0..12：12! = 479001600，int64 无压力；与 sym.求解 的 12 次上限对齐） */
static long long ser_fact(int k)
{
    long long f = 1;
    int i;
    for (i = 2; i <= k; i++) f *= i;
    return f;
}

/* 泰勒展开：expr 在 var = point 处展开到 order 阶（0..12）。
 * 系数 c_k = f^(k)(point)/k!：f^(k)(point) 数值求值，能收成整数/小分母分数
 * （Frac）就出精确形式，收不成的老实留 double；|f^(k)(point)| < 1e-12 当 0 舍去。
 * 输出「多项式 + O 余项」；point 不支持 inf（换元后用 sym.替换）。
 * 失败返回 NULL（err 有文案）。 */
char *sym_core_series(const char *expr, const char *var, const char *point,
                      int order, char *err, size_t errsz)
{
    Arena ar = {0};
    Node *n, *cur, *acc = NULL, *base;
    char *names[64];
    char *vname;
    double pt = 0;
    int ps, sgn = 1, k, i, nn = 0;
    SB b, ob;
    char *out;

    if (bad_var_name(var, err, errsz)) return NULL;
    if (order < 0 || order > 12) {
        if (err) snprintf(err, errsz,
            "阶数要在 0 到 12 之间（收到 %d）——教学级展开 12 阶够用，"
            "再高阶乘会溢出一颗 int64", order);
        return NULL;
    }
    ps = parse_point(point, &pt, &sgn, err, errsz);
    if (ps == 0) return NULL;
    if (ps == 2) {
        if (err) snprintf(err, errsz,
            "sym.级数 只支持有限的点（收到 inf）——无穷远的展开要先把 x 换成 1/t 之类"
            "（用 sym.替换 换元，再对 t 展开）");
        return NULL;
    }
    n = compile1(expr, &ar, err, errsz);
    if (!n) { ar_free(&ar); return NULL; }
    collect_vars(n, names, &nn, 64);
    for (i = 0; i < nn; i++)
        if (strcmp(names[i], var) != 0) {
            if (err) snprintf(err, errsz,
                "公式里还有变量 %s——sym.级数 一次只展开一个变量"
                "（可以先用 sym.替换 把别的变量换成具体数）", names[i]);
            ar_free(&ar);
            return NULL;
        }
    vname = ar_strdup(&ar, var, strlen(var));
    if (!vname) {
        if (err) snprintf(err, errsz, "内存不够了");
        ar_free(&ar);
        return NULL;
    }
    base = (pt == 0) ? nd_var(&ar, var)
                     : nd_bin(&ar, N_SUB, nd_var(&ar, var), nd_num(&ar, pt));
    cur = simplified(&ar, n);
    for (k = 0; k <= order; k++) {
        Node *sub = subst_node(&ar, cur, var, nd_num(&ar, pt));
        double v;
        Frac c;
        int exact, neg, one;
        Node *t;
        if (!sub) {
            if (err) snprintf(err, errsz, "代入时内存不足");
            goto fail;
        }
        if (!eval_node(sub, &vname, &pt, 1, &v, err, errsz)) {
            char why[192];
            snprintf(why, sizeof why, "%s", err);
            if (err) snprintf(err, errsz,
                "第 %d 阶导数在 %s = %.10g 处求值失败：%s", k, var, pt, why);
            goto fail;
        }
        if (fabs(v) >= 1e-12) {                 /* 0 系数项不占位 */
            exact = fr_from_double(v, &c);
            if (exact) {
                c = fr_div(c, fr_int(ser_fact(k)));
                if (!c.den) exact = 0;
            }
            if (!exact) {
                /* 数值系数也试一次小分母分数回认（dens<=64、相对 1e-6 内才认）：
                 * -7/54 这类 diff 数值噪声后面的整齐分数不该留成一串小数 */
                Frac sc;
                if (snap_frac(v / (double)ser_fact(k), &sc) && sc.den != 0
                    && !(sc.num == 0 && v != 0.0)) {   /* 非零系数不许认成 0 */
                    c = sc; exact = 1;
                }
            }
            if (k == 0) {
                /* 常数项必是首项：负号留在系数里出 "-1/6"，不包 NEG */
                t = exact ? nd_frac(&ar, c) : nd_num(&ar, v);
            } else {
                /* k==1 时不包 POW：base^1 就是 base 本身，出 "x" 而不是 "x^1" */
                Node *pw = (k == 1) ? base
                                    : nd_bin(&ar, N_POW, base, nd_num(&ar, (double)k));
                Node *inner;
                if (exact) {
                    Frac pc = (c.num < 0) ? fr_neg(c) : c;
                    one = (pc.num == 1 && pc.den == 1);
                    inner = one ? pw : nd_bin(&ar, N_MUL, nd_frac(&ar, pc), pw);
                    neg = (c.num < 0);
                } else {
                    double cv = v / (double)ser_fact(k);
                    double pcv = (cv < 0) ? -cv : cv;
                    one = (pcv == 1.0);
                    inner = one ? pw : nd_bin(&ar, N_MUL, nd_num(&ar, pcv), pw);
                    neg = (cv < 0);
                }
                t = neg ? nd_neg(&ar, inner) : inner;
            }
            acc = acc ? nd_bin(&ar, N_ADD, acc, t) : t;
        }
        if (k < order) {
            Node *d;
            norm_sub(&ar, cur);
            d = diff(&ar, cur, var);
            if (!d) {
                if (err) snprintf(err, errsz,
                    "第 %d 阶求导没做出来（比如 abs 在 0 处不可导）——展开失败", k + 1);
                goto fail;
            }
            cur = simplified(&ar, d);
        }
    }
    /* ---- 渲染：多项式 + O 余项 ---- */
    sb_init(&b);
    if (b.oom) { if (err) snprintf(err, errsz, "内存不够了"); goto fail; }
    if (acc) rend(&b, acc, 0, 0, &ST_PLAIN);
    else sb_puts(&b, "0");
    sb_init(&ob);
    if (ob.oom) { free(b.p); if (err) snprintf(err, errsz, "内存不够了"); goto fail; }
    sb_puts(&ob, " + O(");
    if (pt != 0) sb_putc(&ob, '(');
    rend(&ob, base, 0, 0, &ST_PLAIN);
    if (pt != 0) sb_putc(&ob, ')');
    if (order + 1 != 1) {          /* 0 阶级数出 "O(x)"，不出 "O(x^1)" */
        sb_putc(&ob, '^');
        {
            char nb[16];
            snprintf(nb, sizeof nb, "%d", order + 1);
            sb_puts(&ob, nb);
        }
    }
    sb_putc(&ob, ')');
    if (ob.oom) { free(b.p); free(ob.p); if (err) snprintf(err, errsz, "内存不够了"); goto fail; }
    sb_put(&b, ob.p, ob.n);
    free(ob.p);
    if (b.oom) { free(b.p); if (err) snprintf(err, errsz, "内存不够了"); goto fail; }
    out = b.p;
    ar_free(&ar);
    return out;
fail:
    ar_free(&ar);
    return NULL;
}

/* ==================== 绑定层 ==================== */
#if defined(PYBOOK_RT_H) || defined(SYM_RT_BINDING)

static Value sym_out(char *s)
{
    Value v;
    if (!s) return rt_str("");
    v = rt_str(s);
    free(s);
    return v;
}

static void sym_chk_str(Value v, const char *who, const char *which, const char *eg)
{
    if (!IS_STR(v))
        rt_die("%s 的第%s个参数要是公式字符串，比如 \"%s\"", who, which, eg);
}

Value rt_lib_sym_parse(Value ev)
{
    char err[192] = "";
    char *r;
    sym_chk_str(ev, "sym.解析", "一", "x^2*sin(x)");
    r = sym_core_parse(AS_STR(ev), err, sizeof err);
    if (!r) rt_die("sym.解析：%s", err);
    return sym_out(r);
}

Value rt_lib_sym_diff(Value ev, Value varv)
{
    char err[192] = "";
    char *r;
    sym_chk_str(ev, "sym.求导", "一", "x^2*sin(x)");
    sym_chk_str(varv, "sym.求导", "二", "x");
    r = sym_core_diff(AS_STR(ev), AS_STR(varv), err, sizeof err);
    if (!r) rt_die("sym.求导：%s", err);
    return sym_out(r);
}

Value rt_lib_sym_integrate(Value ev, Value varv)
{
    char err[192] = "";
    char *r;
    sym_chk_str(ev, "sym.积分", "一", "x*exp(x)");
    sym_chk_str(varv, "sym.积分", "二", "x");
    r = sym_core_integrate(AS_STR(ev), AS_STR(varv), err, sizeof err);
    if (!r) rt_die("sym.积分：%s", err);
    return sym_out(r);
}

Value rt_lib_sym_simplify(Value ev)
{
    char err[192] = "";
    char *r;
    sym_chk_str(ev, "sym.化简", "一", "x + x");
    r = sym_core_simplify(AS_STR(ev), err, sizeof err);
    if (!r) rt_die("sym.化简：%s", err);
    return sym_out(r);
}

Value rt_lib_sym_expand(Value ev)
{
    char err[192] = "";
    char *r;
    sym_chk_str(ev, "sym.展开", "一", "(x+1)^2");
    r = sym_core_expand(AS_STR(ev), err, sizeof err);
    if (!r) rt_die("sym.展开：%s", err);
    return sym_out(r);
}

Value rt_lib_sym_eval(Value ev, Value bindv)
{
    char err[192] = "";
    double out = 0;
    const char *bind = "";
    sym_chk_str(ev, "sym.求值", "一", "x^2 + 1");
    if (!IS_NONE(bindv)) {                 /* 第二参可省：sym.求值("2^10") */
        sym_chk_str(bindv, "sym.求值", "二", "x=3");
        bind = AS_STR(bindv);
    }
    if (!sym_core_eval(AS_STR(ev), bind, &out, err, sizeof err))
        rt_die("sym.求值：%s", err);
    return rt_float(out);
}

Value rt_lib_sym_vars(Value ev)
{
    char err[192] = "";
    char *r;
    Value lst;
    char *p;
    sym_chk_str(ev, "sym.变量", "一", "x*y + sin(z)");
    r = sym_core_vars(AS_STR(ev), err, sizeof err);
    if (!r) rt_die("sym.变量：%s", err);
    lst = rt_list_new();
    p = r;
    while (*p) {
        char *q = strstr(p, ", ");
        size_t len = q ? (size_t)(q - p) : strlen(p);
        char *name = (char *)malloc(len + 1);
        if (!name) { free(r); rt_die("sym.变量：内存不足"); }
        memcpy(name, p, len);
        name[len] = 0;
        rt_push(&lst, rt_str(name));
        free(name);
        if (!q) break;
        p = q + 2;
    }
    free(r);
    return lst;
}

Value rt_lib_sym_subst(Value ev, Value varv, Value newv)
{
    char err[192] = "";
    char *r;
    sym_chk_str(ev, "sym.替换", "一", "x^2");
    sym_chk_str(varv, "sym.替换", "二", "x");
    sym_chk_str(newv, "sym.替换", "三", "y+1");
    r = sym_core_subst(AS_STR(ev), AS_STR(varv), AS_STR(newv), err, sizeof err);
    if (!r) rt_die("sym.替换：%s", err);
    return sym_out(r);
}

Value rt_lib_sym_equal(Value av, Value bv)
{
    char err[192] = "";
    int r;
    sym_chk_str(av, "sym.相等", "一", "2*x");
    sym_chk_str(bv, "sym.相等", "二", "x + x");
    r = sym_core_equal(AS_STR(av), AS_STR(bv), err, sizeof err);
    if (r < 0) rt_die("sym.相等：%s", err);
    return rt_bool(r);
}

Value rt_lib_sym_solve(Value ev, Value varv)
{
    char err[192] = "";
    char *r;
    sym_chk_str(ev, "sym.求解", "一", "x^2 - 5*x + 6 = 0");
    sym_chk_str(varv, "sym.求解", "二", "x");
    r = sym_core_solve(AS_STR(ev), AS_STR(varv), err, sizeof err);
    if (!r) rt_die("sym.求解：%s", err);
    return sym_out(r);
}

Value rt_lib_sym_format(Value ev, Value modev)
{
    char err[192] = "";
    char *r;
    sym_chk_str(ev, "sym.格式", "一", "x^2*sin(x)");
    sym_chk_str(modev, "sym.格式", "二", "latex");
    r = sym_core_format(AS_STR(ev), AS_STR(modev), err, sizeof err);
    if (!r) rt_die("sym.格式：%s", err);
    return sym_out(r);
}

Value rt_lib_sym_solve_sys(Value eqsv, Value varsv)
{
    char err[192] = "";
    char *r;
    sym_chk_str(eqsv, "sym.解方程组", "一", "x+y=3;x-y=1");
    sym_chk_str(varsv, "sym.解方程组", "二", "x,y");
    r = sym_core_solve_sys(AS_STR(eqsv), AS_STR(varsv), err, sizeof err);
    if (!r) rt_die("sym.解方程组：%s", err);
    return sym_out(r);
}

Value rt_lib_sym_limit(Value ev, Value varv, Value ptv)
{
    char err[192] = "";
    char *r;
    sym_chk_str(ev, "sym.极限", "一", "sin(x)/x");
    sym_chk_str(varv, "sym.极限", "二", "x");
    sym_chk_str(ptv, "sym.极限", "三", "0");
    r = sym_core_limit(AS_STR(ev), AS_STR(varv), AS_STR(ptv), err, sizeof err);
    if (!r) rt_die("sym.极限：%s", err);
    return sym_out(r);
}

Value rt_lib_sym_series(Value ev, Value varv, Value ptv, Value ordv)
{
    char err[192] = "";
    char *r;
    long long o;
    sym_chk_str(ev, "sym.级数", "一", "sin(x)");
    sym_chk_str(varv, "sym.级数", "二", "x");
    sym_chk_str(ptv, "sym.级数", "三", "0");
    if (!IS_INT(ordv))
        rt_die("sym.级数 的第四个参数（阶数）要是整数，比如 5");
    o = AS_INT(ordv);
    if (o < 0 || o > 12)
        rt_die("sym.级数 的阶数要在 0 到 12 之间（收到 %lld）", o);
    r = sym_core_series(AS_STR(ev), AS_STR(varv), AS_STR(ptv), (int)o, err, sizeof err);
    if (!r) rt_die("sym.级数：%s", err);
    return sym_out(r);
}

#endif /* PYBOOK_RT_H */
