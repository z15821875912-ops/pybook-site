# P0 引擎回归：3D 主渲染路径整体失效（最小复现）

## 现象
_on 3D_highway 的任何场景：清屏色正常、窗口正常、无报错——但所有几何（hw.box/hw.line/
粒子/引用闭包）全部不渲染。开场时（会话早期）3D演示.pybk 可正常出图，
现在同文件只剩 1.9% 非背景像素（应为楼群+公路占大半屏）。

## 最小复现（_min_hw.pybk，已在仓库根）
    ON 3D_highway
    GOING:{
    hw.open(800, 500, "最小hw")
    hw.clearcolor(5, 5, 12)
    hw.camera(0, 1.5, 6, 0)
    rm.aging.while(hw.end()) {
        hw.camera(0, 1.5, 6, 0)
        hw.box(0, 1.2, 0, 0.35, 0.35, 0.35, 0, 255, 0)
        hw.frame()
    }
    }STOP
    $ PYBOOK_SHOT_DIR=_session_backup/shots python pybk_main.py _min_hw.pybk
    → 截图 800x500 全是背景色，绿色盒子 0 像素

## 已排除
- GL_POINTS/混合/点大小（极简 draw_box 版同样不显示——不只点精灵）
- device gpu 头（去掉后依旧）
- 后处理链（未开 post 的直通路径同样不显示）
- 阴影 pass 抢 FBO（未开阴影的场景同样不显示）
- 像素分析器（开场时同一分析器出过正确夜景图）

## 高度可疑
pybook_hw3d.c 相对 HEAD：1953 insertions / 47 deletions（未提交）——
jit/device/GPU 后处理大改期间主渲染路径被动过。GL 上下文本身活着
（[shadow] 深度贴图能建 = 着色器/FBO 通路正常），死的是「命令流重放画几何」那一段。

## 修复者提示
draw_ops 的重放 switch 在 2189 附近，case OP_BOX 在 2302；
重点查：主 pass 的 MODELVIEW/PROJECTION 在重放时是否还是相机矩阵
（嫌疑：post/shadow 重构后矩阵设置被移位或漏设）。
