# -*- coding: utf-8 -*-
"""_symtest_ext.py —— _symtest.c 加 sym4 用例：双曲函数补锁 + 极限 + 级数。
幂等 count==1，二进制读写保 LF。"""
import io, sys

def apply(s, label, old, new):
    n = s.count(old)
    if n != 1:
        sys.stderr.write('FAIL [%s] count=%d\n' % (label, n)); sys.exit(1)
    s = s.replace(old, new, 1)
    print('ok  ' + label)
    return s

HELPERS = r'''
/* ---- sym.极限 ---- */
static void Tlim(const char *expr, const char *var, const char *pt,
                 const char *want, const char *what)
{
    char err[192] = "";
    char *r = sym_core_limit(expr, var, pt, err, sizeof err);
    T(r, want, what);
    free(r);
}

/* 期望失败且 err 含关键字 */
static void Tlim_err(const char *expr, const char *var, const char *pt,
                     const char *key, const char *what)
{
    char err[192] = "";
    char *r = sym_core_limit(expr, var, pt, err, sizeof err);
    total++;
    if (!r && strstr(err, key)) {
        printf("ok   %-30s 报错含 [%s]\n", what, key);
    } else {
        fails++;
        printf("FAIL %-30s 期望报错含 [%s]，实得 r=[%s] err=[%s]\n",
               what, key, r ? r : "(NULL)", err);
    }
    free(r);
}

/* ---- sym.级数 ---- */
static void Tser(const char *expr, const char *var, const char *pt, int order,
                 const char *want, const char *what)
{
    char err[192] = "";
    char *r = sym_core_series(expr, var, pt, order, err, sizeof err);
    T(r, want, what);
    free(r);
}

static void Tser_err(const char *expr, const char *var, const char *pt, int order,
                     const char *key, const char *what)
{
    char err[192] = "";
    char *r = sym_core_series(expr, var, pt, order, err, sizeof err);
    total++;
    if (!r && strstr(err, key)) {
        printf("ok   %-30s 报错含 [%s]\n", what, key);
    } else {
        fails++;
        printf("FAIL %-30s 期望报错含 [%s]，实得 r=[%s] err=[%s]\n",
               what, key, r ? r : "(NULL)", err);
    }
    free(r);
}

'''

CASES = r'''
    /* ============ sym4：双曲函数补锁（函数表/求导/积分/格式四路） ============ */
    Td("sinh(x)", "x", "cosh(x)", "求导 sinh");
    Td("cosh(x)", "x", "sinh(x)", "求导 cosh");
    Td("tanh(x)", "x", "1 - tanh(x)^2", "求导 tanh");
    Td("sinh(2*x)", "x", "2*cosh(2*x)", "求导 sinh 链式");
    Ti("sinh(x)", "x", "cosh(x)", "积分 sinh");
    Ti("cosh(x)", "x", "sinh(x)", "积分 cosh");
    Ti("tanh(x)", "x", "log(cosh(x))", "积分 tanh");
    Ti("sinh(2*x)", "x", "cosh(2*x)/2", "积分 sinh 线性内");
    Tid("sinh(x)", "x", "1,2,3", "对拍 sinh 积分回求导");
    Tid("cosh(2*x)", "x", "1,2,3", "对拍 cosh 线性内");
    Tfmt("sinh(x)", "latex", "\\sinh(x)", "格式 latex sinh");
    Tfmt("cosh(x)", "latex", "\\cosh(x)", "格式 latex cosh");
    Tfmt("tanh(x)", "latex", "\\tanh(x)", "格式 latex tanh");
    Tfmt("sinh(x)", "unicode", "sinh(x)", "格式 unicode sinh 原名");
    total++; if (sym_core_eval("sinh(0)", "", &v, err, sizeof err)) Tv(v, 0, "求值 sinh0"); else { fails++; printf("FAIL 求值 sinh0: %s\n", err); }
    total++; if (sym_core_eval("cosh(0)", "", &v, err, sizeof err)) Tv(v, 1, "求值 cosh0"); else { fails++; printf("FAIL 求值 cosh0: %s\n", err); }
    total++; if (sym_core_eval("tanh(0)", "", &v, err, sizeof err)) Tv(v, 0, "求值 tanh0"); else { fails++; printf("FAIL 求值 tanh0: %s\n", err); }
    total++; if (sym_core_eval("sinh(1)", "", &v, err, sizeof err)) Tv(v, 1.1752011936438014, "求值 sinh1"); else { fails++; printf("FAIL 求值 sinh1: %s\n", err); }

    /* ============ sym4：极限 ============ */
    Tlim("sin(x)/x", "x", "0", "1", "极限 sin(x)/x");
    Tlim("(x^2-4)/(x-2)", "x", "2", "4", "极限 可去奇点");
    Tlim("(1-cos(x))/x^2", "x", "0", "1/2", "极限 两轮洛必达");
    Tlim("x^2", "x", "3", "9", "极限 直接代入");
    Tlim("sin(x)", "x", "pi", "0", "极限 点是 pi");
    Tlim("x/2 + 1", "x", "pi", "2.570796327", "极限 非整洁值");
    Tlim("(2*x+1)/(x-3)", "x", "inf", "2", "极限 无穷远外推");
    Tlim("1/x^2", "x", "inf", "0", "极限 无穷远归零");
    Tlim("3", "x", "7", "3", "极限 常函数");
    Tlim_err("1/x", "x", "0", "趋于无穷", "极限 真发散");
    Tlim_err("x*sin(1/x)", "x", "0", "乱抖", "极限 零点乱抖");
    Tlim_err("log(x)", "x", "0", "没定义", "极限 定义域外");
    Tlim_err("(1+x)^(1/x)", "x", "0", "数值探测", "极限 1^inf 陷阱");
    Tlim_err("x*sin(x)", "x", "inf", "定不下来", "极限 无穷振荡");
    Tlim_err("sin(x)", "x", "y", "点", "极限 坏点参数");
    Tlim_err("x + y", "x", "0", "还有变量", "极限 多变量");

    /* ============ sym4：级数 ============ */
    Tser("sin(x)", "x", "0", 5, "x - 1/6*x^3 + 1/120*x^5 + O(x^6)", "级数 sin 5阶");
    Tser("cos(x)", "x", "0", 4, "1 - 1/2*x^2 + 1/24*x^4 + O(x^5)", "级数 cos 4阶");
    Tser("exp(x)", "x", "0", 3, "1 + x + 1/2*x^2 + 1/6*x^3 + O(x^4)", "级数 exp 3阶");
    Tser("log(1+x)", "x", "0", 3, "x - 1/2*x^2 + 1/3*x^3 + O(x^4)", "级数 log 3阶");
    Tser("1/(1-x)", "x", "0", 3, "1 + x + x^2 + x^3 + O(x^4)", "级数 等比");
    Tser("sin(x)", "x", "0", 0, "0 + O(x)", "级数 0阶");
    Tser("sin(x)", "x", "0", 1, "x + O(x^2)", "级数 1阶");
    Tser("exp(x)", "x", "2", 2,
         "7.389056099 + 7.389056099*(x - 2) + 3.694528049*(x - 2)^2 + O((x - 2)^3)",
         "级数 非零点");
    Tser_err("sin(x)", "x", "0", 13, "阶数", "级数 阶数超界");
    Tser_err("sin(x)", "x", "0", -1, "阶数", "级数 负阶数");
    Tser_err("sin(x)", "x", "inf", 3, "有限的点", "级数 无穷点");
    Tser_err("x + y", "x", "0", 3, "还有变量", "级数 多变量");
    Tser_err("log(x)", "x", "0", 3, "求值失败", "级数 奇点展开");
'''

p = '_symtest.c'
raw = open(p, 'rb').read()
s = raw.decode('utf-8')
if 'Tlim(' in s:
    print('skip _symtest.c（已应用）')
else:
    s = apply(s, 'X1 辅助函数',
        'int main(void)\n{\n',
        HELPERS + 'int main(void)\n{\n')
    s = apply(s, 'X2 用例',
        '    printf("\\n==== 合计 %d 项：通过 %d，失败 %d ====\\n", total, total - fails, fails);\n',
        CASES + '    printf("\\n==== 合计 %d 项：通过 %d，失败 %d ====\\n", total, total - fails, fails);\n')
    open(p, 'wb').write(s.encode('utf-8'))
    print('写入 ' + p)

b = open(p, 'rb').read()
print('%s: %d 行, 裸 CR %d' % (p, b.count(b'\n'), b.count(b'\r')))
if b.count(b'\r'): sys.stderr.write('行尾混杂!\n'); sys.exit(1)
print('=== _symtest_ext 全部通过 ===')
