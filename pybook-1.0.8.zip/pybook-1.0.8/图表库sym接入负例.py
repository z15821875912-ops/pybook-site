"""sym 接入图表库的**负例**验证：每条都该中止，并给出能指路的报错。

这些错误都是 plt_die 里的 exit(1)，没法在同一个程序里断言，所以驱动脚本
逐条起一个子进程跑，比对 stderr 里必须出现的关键字。

顺带说明这些负例在验什么：
  - 没有坐标系就画：四个派生图元都该拦下来，而不是自己悄悄定一个值域
    （自己定域会把画布上原有的曲线重新映射，图错位却看不出来）；
  - 两个自由变量：x*t 这类画不出单变量曲线，要报错而不是静默丢掉一个；
  - 定义域外：sym 的求值失败是「这个 x 上没定义」，要报出来，
    更不能退回给某个变量名后安静返回一个不相干的数。

跑法：python 图表库sym接入负例.py
"""
import io
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
TMP = os.path.join(HERE, 'build_tmp', 'probe', 'sym负例')

# (名字, 程序体, 必须出现在 stderr 里的片段)
CASES = [
    ('导数-没有坐标系',
     '板 = 图.画布(200, 160)\n图.导数(板, "x^2", "x", [0,0,255], 2)',
     '定好坐标系'),
    ('切线-没有坐标系',
     '板 = 图.画布(200, 160)\n图.切线(板, "x^2", "x", 1, [0,0,255])',
     '定好坐标系'),
    ('渐近线-没有坐标系',
     '板 = 图.画布(200, 160)\n图.渐近线(板, "1/x", "x", [0,0,255])',
     '定好坐标系'),
    ('面积-没有坐标系',
     '板 = 图.画布(200, 160)\n图.面积(板, "x^2", "x", 0, 3, [0,0,255])',
     '定好坐标系'),
    ('试值-两个自由变量',
     'ns.show(图.试值("x*t", 0))',
     '自由变量'),
    ('曲线-两个自由变量',
     '板 = 图.画布(200, 160)\n图.曲线(板, "x*t", -1, 1, [0,0,255], 2)',
     '自由变量'),
    ('试值-中文名两个变量',
     'ns.show(图.试值("sin(角)*x", 0))',
     '自由变量'),
    ('试值-除零',
     'ns.show(图.试值("1/(t-1)", 1))',
     '没定义'),
    ('试值-log越界',
     'ns.show(图.试值("log(角)", 0))',
     '没定义'),
    ('试值-负数开方',
     'ns.show(图.试值("√x", -1))',
     '没定义'),
    ('曲线-根号负半轴',
     '板 = 图.画布(200, 160)\n图.曲线(板, "√x", -4, -1, [0,0,255], 2)',
     '一个有限值都没算出来'),
    ('面积-区间内有极点',
     '板 = 图.画布(200, 160)\n图.轴(板, -2, 2, -2, 2, "", "", "")\n'
     'ns.show(图.面积(板, "1/(x-1)", "x", 0, 2, [0,0,255]))',
     '没定义'),
    ('切线-切点处无定义',
     '板 = 图.画布(200, 160)\n图.轴(板, -3, 3, -3, 3, "", "", "")\n'
     '图.切线(板, "1/x", "x", 0, [0,0,255])',
     '算不出值'),
    ('导数-abs不可导',
     '板 = 图.画布(200, 160)\n图.轴(板, -3, 3, -3, 3, "", "", "")\n'
     '图.导数(板, "abs(x)", "x", [0,0,255], 2)',
     '不可导'),
    ('试值-根号套函数不给猜',
     'ns.show(图.试值("√sin(x)", 0))',
     '合语法'),
    ('试值-左括号不配对',
     'ns.show(图.试值("x^2+(1*2", 0))',
     '合语法'),
]

TPL = '@ 负例>%s\nGOING:{\n%s\n}STOP\n'


def run_case(name, body, want):
    os.makedirs(TMP, exist_ok=True)
    path = os.path.join(TMP, name + '.pybk')
    with io.open(path, 'w', encoding='utf-8', newline='\n') as f:
        f.write(TPL % (name, body))
    env = dict(os.environ)
    env['PYTHONUTF8'] = '1'
    env['PYTHONIOENCODING'] = 'utf-8'
    r = subprocess.run([sys.executable, 'pybk_main.py', path],
                       capture_output=True, cwd=HERE, env=env)
    err = r.stderr.decode('utf-8', 'replace')
    # 报错行是带「运行时错误」的那条；pybk_main.py 之后还会跟一句 Python 层的
    # 收尾提示，直接取最后一行会永远看到那句、看不到真正的错误文案。
    hit = [l for l in err.splitlines() if '运行时错误' in l]
    if r.returncode == 0:
        return '本该中止却跑完了（退出码 0）'
    if not hit:
        return '中止了但 stderr 里没有「运行时错误」：%s' % err.strip()[:200]
    if want not in err:
        return '报错里没有「%s」，实际：%s' % (want, hit[0][:200])
    return None


bad = 0
print('sym 接入负例：共 %d 条' % len(CASES))
for name, body, want in CASES:
    problem = run_case(name, body, want)
    if problem:
        bad += 1
        print('  FAIL  %-22s %s' % (name, problem))
    else:
        print('  OK    %-22s stderr 含「%s」' % (name, want))
print('')
print('全部通过' if not bad else '失败 %d 条' % bad)
raise SystemExit(1 if bad else 0)
