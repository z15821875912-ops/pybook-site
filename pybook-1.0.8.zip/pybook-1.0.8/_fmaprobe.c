/* _fmaprobe.c —— 揪出「宿主参考值为什么会随编译选项变」。
 *
 * 背景：_gppeak.c 的正确性闸门在换成 -O3 -march=native 之后突然全红
 * （10240 个结果 0 个相同），而 GPU 侧的输出一个字节都没变。
 * 也就是说变的是宿主参考。这本身就是闸门该做的事：它发现「参考」不可信。
 *
 * 本程序把 host_replay 单独拎出来，用不同编译选项各编一份，比较输出。
 * 用法：
 *   gcc _fmaprobe.c -o _fp_O2.exe     -O2
 *   gcc _fmaprobe.c -o _fp_native.exe -O3 -march=native
 *   .\_fp_O2.exe
 *   .\_fp_native.exe
 */
#include <stdio.h>
#include <math.h>
#include "_fmareal_const.h"

static void host_replay(float *acc, unsigned iters)
{
    unsigned it;
    int s, c;
    for (it = 0; it < iters; it++)
        for (s = 0; s < FM_S; s++)
            for (c = 0; c < FM_NC; c++)
                acc[c] = fmaf(acc[c], FMK[s][c], FMB[c]);
}

int main(void)
{
    float acc[FM_NC];
    int c;
    unsigned i;
    /* 把整条链真正用到的常量也打出来，方便对照 PTX */
    printf("FMK[0][0]=%.9g FMK[0][1]=%.9g FMB[0]=%.9g\n",
           (double)FMK[0][0], (double)FMK[0][1], (double)FMB[0]);
    for (c = 0; c < FM_NC; c++) acc[c] = 0.5f + (float)c * 0.03125f;
    host_replay(acc, 64);
    for (c = 0; c < FM_NC; c++) printf("%.9g%s", (double)acc[c], c + 1 == FM_NC ? "" : " ");
    printf("\n");
    /* 再跑一遍不同的迭代数，看误差是不是随迭代数放大 */
    for (c = 0; c < FM_NC; c++) acc[c] = 0.5f + (float)c * 0.03125f;
    host_replay(acc, 1);
    printf("iters=1  acc[0]=%.9g\n", (double)acc[0]);
    for (c = 0; c < FM_NC; c++) acc[c] = 0.5f + (float)c * 0.03125f;
    host_replay(acc, 2);
    printf("iters=2  acc[0]=%.9g\n", (double)acc[0]);
    for (c = 0; c < FM_NC; c++) acc[c] = 0.5f + (float)c * 0.03125f;
    host_replay(acc, 4096);
    printf("iters=4096 acc[0]=%.9g\n", (double)acc[0]);
    (void)i;
    return 0;
}
