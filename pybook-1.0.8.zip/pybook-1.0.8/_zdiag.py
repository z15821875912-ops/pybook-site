# -*- coding: utf-8 -*-
"""_zdiag.py — s→1 剩下那 1.1e-13 到底出在哪一项？逐项和 Decimal 高精度对拍。
候选：(a) pow(N,-s) 的相对误差  (b) s-1.0 的表示误差  (c) 参考值用的 s 与 double 不一致
"""
from decimal import Decimal, getcontext
from fractions import Fraction
import math

getcontext().prec = 40
BF = [float(Fraction(1, 12)), float(Fraction(-1, 720)), float(Fraction(1, 30240)),
      float(Fraction(-1, 1209600)), float(Fraction(1, 47900160)),
      float(Fraction(-691, 1307674368000))]


def dsum(s, N):
    """Decimal 版：有限和 + 主尾项，30 位有效数字"""
    sD = Decimal(repr(s))
    ND = Decimal(N)
    total = sum(Decimal(i) ** (-sD) for i in range(1, N))
    t = ND ** (-sD)
    total += Decimal('0.5')*t + t*ND/(sD - 1)
    ps = sD
    for k in range(6):
        if k > 0:
            for i in range(2):
                ps *= (sD + 2*k - 1 + i)
        total += Decimal(BF[k]) * ps * ND ** (-sD - 2*k - 1)
    return total


for s in (1.001, 1.0001):
    N = max(20, min(int(10.0/(s-1.0) + 16.0), 4000000))
    ref = dsum(s, N)

    # 双精度版，逐项拆开看
    ssum = sum(float(i)**(-s) for i in range(1, N))
    t = N**(-s)
    tail = t*N/(s-1.0)
    half = 0.5*t
    total = ssum + half + tail

    # 各分量单独的高精度真值
    ssum_hi = float(sum(Decimal(i) ** (-Decimal(repr(s))) for i in range(1, N)))
    tail_hi = float(ref - Decimal(repr(ssum_hi)) - Decimal('0.5')*Decimal(N)**(-Decimal(repr(s))))

    print('s=%-9s N=%-9d' % (s, N))
    print('  有限和 Σ n^-s        双 %-22.16g 高 %-22.16g 绝对差 %.3e'
          % (ssum, ssum_hi, abs(ssum - ssum_hi)))
    print('  主尾项 t*N/(s-1)     双 %-22.16g 高 %-22.16g 绝对差 %.3e'
          % (tail, tail_hi, abs(tail - tail_hi)))
    print('  pow(N,-s)            双 %-22.16g 相对误差 %.3e'
          % (t, abs(Decimal(repr(t)) - Decimal(N)**(-Decimal(repr(s))))/Decimal(N)**(-Decimal(repr(s)))))
    print('  合计相对误差         %.3e' % float(abs(Decimal(repr(total)) - ref)/abs(ref)))
    print('  s-1 的表示误差贡献   %.3e'
          % (abs(Decimal(repr(s-1.0)) - (Decimal(repr(s)) - 1)) / (Decimal(repr(s)) - 1)))
    print()
