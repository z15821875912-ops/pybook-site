# -*- coding: utf-8 -*-
"""_sym2_patch.py —— 给 pybook_sym.c 落 sym.求解 / sym.格式 一整套改动（幂等，可重复跑）。

在仓库根执行：python _sym2_patch.py

改动清单：
  1. 渲染风格机械：RendStyle（plain/latex/unicode）+ fmt_num_st + fn_latex + sup_digits
     —— plain 风格与改动前逐字一致（109 条老自检锁死这一点）
  2. 渲染器 rend/rend_sum_rhs/rend_mul/rend_inner/canon/render_malloc 穿 RendStyle
  3. 新增解方程段：const_eval / poly_term_s / gcd_int / fmt_root / poly_at /
     poly_real_roots（Durand-Kerner）/ sym_core_solve
  4. 新增输出格式段：sym_core_format
  5. 绑定层：rt_lib_sym_solve / rt_lib_sym_format

每处补丁断言 count(old)==1，全部在内存里顺序替换完后一次性写回（UTF-8、行尾原样）。
"""
import io
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
PATH = os.path.join(HERE, "pybook_sym.c")

P = []  # (label, old, new)


def add(label, old, new):
    P.append((label, old, new))


# ==================== 1. 渲染风格机械（fmt_num 之后） ====================
add("style-after-fmtnum", r'''    if (fabs(v) == floor(fabs(v)) && fabs(v) < 1e15)
        snprintf(buf, sz, "%.0f", v);
    else
        snprintf(buf, sz, "%.10g", v);
}

/* ==================== 解析器 ==================== */''', r'''    if (fabs(v) == floor(fabs(v)) && fabs(v) < 1e15)
        snprintf(buf, sz, "%.0f", v);
    else
        snprintf(buf, sz, "%.10g", v);
}

/* ==================== 渲染风格（plain / latex / unicode） ==================== */

typedef struct {
    const char *mul_sep;         /* 乘号：plain "*"｜latex " \cdot "｜unicode "·" */
    int frac;                    /* 1=DIV 出 \frac{a}{b}；0=plain a/b */
    int pow_brace;               /* 1=POW 出 x^{...}（LaTeX 指数恒上花括号） */
    int sup;                     /* 1=POW 整数指数出 unicode 上标（x²） */
    const char *sqrt_o, *sqrt_c; /* sqrt 包裹：plain "sqrt(" ")"｜latex "\sqrt{" "}"｜unicode "√(" ")" */
    const char *pi;              /* 常量名：plain "pi"｜latex "\pi"｜unicode "π" */
    int frac_num;                /* 1=数字折 \frac{a}{b}；0=fmt_num 原样 */
    int latex;                   /* 1=函数名映射（sin→\sin）、abs 出 \left| */
} RendStyle;

static const RendStyle ST_PLAIN = { "*", 0, 0, 0, "sqrt(", ")", "pi", 0, 0 };
static const RendStyle ST_LATEX = { " \\cdot ", 1, 1, 0, "\\sqrt{", "}", "\\pi", 1, 1 };
static const RendStyle ST_UNI   = { "·", 0, 0, 1, "√(", ")", "π", 0, 0 };

/* LaTeX 函数名映射（sqrt/abs 走专门分支，其余原名） */
static const char *fn_latex(const char *name)
{
    if (strcmp(name, "sin") == 0) return "\\sin";
    if (strcmp(name, "cos") == 0) return "\\cos";
    if (strcmp(name, "tan") == 0) return "\\tan";
    if (strcmp(name, "asin") == 0) return "\\arcsin";
    if (strcmp(name, "acos") == 0) return "\\arccos";
    if (strcmp(name, "atan") == 0) return "\\arctan";
    if (strcmp(name, "sinh") == 0) return "\\sinh";
    if (strcmp(name, "cosh") == 0) return "\\cosh";
    if (strcmp(name, "tanh") == 0) return "\\tanh";
    if (strcmp(name, "exp") == 0) return "\\exp";
    if (strcmp(name, "log") == 0) return "\\ln";
    return name;
}

/* unicode 上标数字：整数指数 → ⁰¹²³⁴⁵⁶⁷⁸⁹（负号 ⁻） */
static void sup_digits(SB *o, long long e)
{
    char dig[24];
    int n = 0, i;
    static const char *D[] = { "⁰", "¹", "²", "³", "⁴", "⁵", "⁶", "⁷", "⁸", "⁹" };
    if (e < 0) { sb_puts(o, "⁻"); e = -e; }
    if (e == 0) { sb_puts(o, D[0]); return; }
    while (e > 0 && n < 20) { dig[n++] = (char)('0' + (int)(e % 10)); e /= 10; }
    for (i = n - 1; i >= 0; i--) sb_puts(o, D[dig[i] - '0']);
}

/* 风格化数字：plain 与 fmt_num 逐字一致；latex 把 0<|v|<1 的小分母折成 \frac{a}{b} */
static void fmt_num_st(double v, char *buf, size_t sz, const RendStyle *st)
{
    static const int dens[] = { 2, 3, 4, 5, 6, 8, 10, 12 };
    double a;
    int d, k;
    if (v == 0) v = 0;                      /* 归一化 -0 */
    a = fabs(v);
    if (a > 0 && a < 1) {
        for (k = 0; k < (int)(sizeof dens / sizeof *dens); k++) {
            d = dens[k];
            if (fabs(a * d - floor(a * d + 0.5)) < 1e-9) {
                if (st->frac_num)
                    snprintf(buf, sz, "%s\\frac{%d}{%d}", v < 0 ? "-" : "",
                             (int)floor(a * d + 0.5), d);
                else
                    snprintf(buf, sz, "%s%d/%d", v < 0 ? "-" : "",
                             (int)floor(a * d + 0.5), d);
                return;
            }
        }
    }
    if (fabs(v) == floor(fabs(v)) && fabs(v) < 1e15)
        snprintf(buf, sz, "%.0f", v);
    else
        snprintf(buf, sz, "%.10g", v);
}

/* ==================== 解析器 ==================== */''')

# ==================== 2. rend：穿 RendStyle ====================
add("rend-sig", r'''static void rend_inner(SB *o, Node *n);

/* pp=父优先级；right=是否为父节点的右操作数 */
static void rend(SB *o, Node *n, int pp, int right)
{
    int need = 0;
    if (n) {
        int cp = prec_of(n->kind);
        if (cp < pp) need = 1;
        else if (cp == pp && right && n->kind != N_POW) need = 1;  /* POW 右结合 */
        if (pp == 3 && !right && cp == 3) need = 1;                /* POW 的左子同级要括号 */
    }
    if (need) sb_putc(o, '(');
    rend_inner(o, n);
    if (need) sb_putc(o, ')');
}''', r'''static void rend_inner(SB *o, Node *n, const RendStyle *st);

/* pp=父优先级；right=是否为父节点的右操作数 */
static void rend(SB *o, Node *n, int pp, int right, const RendStyle *st)
{
    int need = 0;
    if (n) {
        int cp = prec_of(n->kind);
        if (cp < pp) need = 1;
        else if (cp == pp && right && n->kind != N_POW) need = 1;  /* POW 右结合 */
        if (pp == 3 && !right && cp == 3) need = 1;                /* POW 的左子同级要括号 */
    }
    if (need) sb_putc(o, '(');
    rend_inner(o, n, st);
    if (need) sb_putc(o, ')');
}''')

# ==================== 3. rend_sum_rhs：穿 RendStyle ====================
add("rend-sum-rhs", r'''static void rend_sum_rhs(SB *o, Node *b, int sub)
{
    int neg = 0;
    Node *core = b;
    char buf[40];
    if (b->kind == N_NUM && b->num < 0) neg = 1;
    else if (b->kind == N_NEG) { neg = 1; core = b->a; }
    /* 父op(+/-) 与 右子符号(-) 异号 → " - "，同号 → " + "
     * neg=0,sub=0 → " + "；neg=1,sub=0 → " - "；neg=0,sub=1 → " - "；neg=1,sub=1 → " + " */
    sb_puts(o, (neg != sub) ? " - " : " + ");
    if (core->kind == N_NUM) {
        fmt_num(fabs(core->num), buf, sizeof buf);
        sb_puts(o, buf);
    } else {
        rend(o, core, 2, 0);
    }
}''', r'''static void rend_sum_rhs(SB *o, Node *b, int sub, const RendStyle *st)
{
    int neg = 0;
    Node *core = b;
    char buf[40];
    if (b->kind == N_NUM && b->num < 0) neg = 1;
    else if (b->kind == N_NEG) { neg = 1; core = b->a; }
    /* 父op(+/-) 与 右子符号(-) 异号 → " - "，同号 → " + "
     * neg=0,sub=0 → " + "；neg=1,sub=0 → " - "；neg=0,sub=1 → " - "；neg=1,sub=1 → " + " */
    sb_puts(o, (neg != sub) ? " - " : " + ");
    if (core->kind == N_NUM) {
        fmt_num_st(fabs(core->num), buf, sizeof buf, st);
        sb_puts(o, buf);
    } else {
        rend(o, core, 2, 0, st);
    }
}''')

# ==================== 4. rend_mul：穿 RendStyle ====================
add("rend-mul", r'''static void rend_mul(SB *o, Node *n, int extra_neg)
{
    Node *fa[24], *ord[24];
    int cnt = 0, negc = extra_neg, k, m = 0, numi = -1;
    char buf[40];
    mul_collect(n, fa, &cnt, 24, &negc);
    for (k = 0; k < cnt; k++)
        if (fa[k]->kind == N_NUM) { numi = k; break; }
    if (numi >= 0) ord[m++] = fa[numi];
    for (k = 0; k < cnt; k++)
        if (k != numi) ord[m++] = fa[k];
    if (negc & 1) sb_putc(o, '-');
    for (k = 0; k < m; k++) {
        Node *c = ord[k];
        if (k) sb_putc(o, '*');
        if (c->kind == N_NUM) {
            fmt_num(fabs(c->num), buf, sizeof buf);   /* 符号已由负计数前置 */
            sb_puts(o, buf);
        } else {
            rend(o, c, 2, k > 0);
        }
    }
}''', r'''static void rend_mul(SB *o, Node *n, int extra_neg, const RendStyle *st)
{
    Node *fa[24], *ord[24];
    int cnt = 0, negc = extra_neg, k, m = 0, numi = -1;
    char buf[40];
    mul_collect(n, fa, &cnt, 24, &negc);
    for (k = 0; k < cnt; k++)
        if (fa[k]->kind == N_NUM) { numi = k; break; }
    if (numi >= 0) ord[m++] = fa[numi];
    for (k = 0; k < cnt; k++)
        if (k != numi) ord[m++] = fa[k];
    if (negc & 1) sb_putc(o, '-');
    for (k = 0; k < m; k++) {
        Node *c = ord[k];
        if (k) sb_puts(o, st->mul_sep);
        if (c->kind == N_NUM) {
            fmt_num_st(fabs(c->num), buf, sizeof buf, st);   /* 符号已由负计数前置 */
            sb_puts(o, buf);
        } else {
            rend(o, c, 2, k > 0, st);
        }
    }
}''')

# ==================== 5. rend_inner：穿 RendStyle + 风格分支 ====================
add("rend-inner", r'''static void rend_inner(SB *o, Node *n)
{
    char buf[40];
    switch (n->kind) {
    case N_NUM:
        fmt_num(n->num, buf, sizeof buf);
        sb_puts(o, buf);
        break;
    case N_CONST:
    case N_VAR:
        sb_puts(o, n->str);
        break;
    case N_FUNC:
        sb_puts(o, n->str);
        sb_putc(o, '(');
        rend(o, n->a, 0, 0);
        sb_putc(o, ')');
        break;
    case N_NEG:
        if (n->a->kind == N_MUL) {
            rend_mul(o, n->a, 1);   /* -(x*cos(x)) → -x*cos(x)：乘链无需括号 */
        } else {
            sb_putc(o, '-');
            rend(o, n->a, 2, 1);
        }
        break;
    case N_ADD:
        rend(o, n->a, 1, 0);
        rend_sum_rhs(o, n->b, 0);
        break;
    case N_SUB:
        rend(o, n->a, 1, 0);
        rend_sum_rhs(o, n->b, 1);
        break;
    case N_MUL:
        rend_mul(o, n, 0);
        break;
    case N_DIV:
        rend(o, n->a, 2, 0);
        sb_putc(o, '/');
        rend(o, n->b, 2, 1);
        break;
    case N_POW:
        rend(o, n->a, 3, 0);
        sb_putc(o, '^');
        /* 指数是常数且渲染出来含 '/' 或以 '-' 开头 → 括号：x^(-2)、x^(1/2) */
        if (n->b->kind == N_NUM) {
            fmt_num(n->b->num, buf, sizeof buf);
            if (strchr(buf, '/') || buf[0] == '-') {
                sb_putc(o, '(');
                sb_puts(o, buf);
                sb_putc(o, ')');
                break;
            }
            sb_puts(o, buf);
            break;
        }
        rend(o, n->b, 3, 1);
        break;
    default:
        sb_puts(o, "?");
        break;
    }
}''', r'''static void rend_inner(SB *o, Node *n, const RendStyle *st)
{
    char buf[40];
    switch (n->kind) {
    case N_NUM:
        fmt_num_st(n->num, buf, sizeof buf, st);
        sb_puts(o, buf);
        break;
    case N_CONST:
    case N_VAR:
        sb_puts(o, (n->kind == N_CONST && strcmp(n->str, "pi") == 0) ? st->pi : n->str);
        break;
    case N_FUNC: {
        int fid = fn_id(n->str);
        if (fid == F_SQRT) {
            sb_puts(o, st->sqrt_o);
            rend(o, n->a, 0, 0, st);
            sb_puts(o, st->sqrt_c);
        } else if (fid == F_ABS && st->latex) {
            sb_puts(o, "\\left|");
            rend(o, n->a, 0, 0, st);
            sb_puts(o, "\\right|");
        } else {
            sb_puts(o, st->latex ? fn_latex(n->str) : n->str);
            sb_putc(o, '(');
            rend(o, n->a, 0, 0, st);
            sb_putc(o, ')');
        }
        break;
    }
    case N_NEG:
        if (n->a->kind == N_MUL) {
            rend_mul(o, n->a, 1, st);   /* -(x*cos(x)) → -x*cos(x)：乘链无需括号 */
        } else {
            sb_putc(o, '-');
            rend(o, n->a, 2, 1, st);
        }
        break;
    case N_ADD:
        rend(o, n->a, 1, 0, st);
        rend_sum_rhs(o, n->b, 0, st);
        break;
    case N_SUB:
        rend(o, n->a, 1, 0, st);
        rend_sum_rhs(o, n->b, 1, st);
        break;
    case N_MUL:
        rend_mul(o, n, 0, st);
        break;
    case N_DIV:
        if (st->frac) {
            sb_puts(o, "\\frac{");
            rend(o, n->a, 1, 0, st);
            sb_puts(o, "}{");
            rend(o, n->b, 1, 0, st);
            sb_putc(o, '}');
        } else {
            rend(o, n->a, 2, 0, st);
            sb_putc(o, '/');
            rend(o, n->b, 2, 1, st);
        }
        break;
    case N_POW:
        rend(o, n->a, 3, 0, st);
        if (st->pow_brace) {                 /* LaTeX：指数恒上花括号 */
            sb_puts(o, "^{");
            rend(o, n->b, 0, 0, st);
            sb_putc(o, '}');
            break;
        }
        if (st->sup) {                       /* unicode：整数指数换上标（含负） */
            double e = 0;
            int hav = 0;
            if (n->b->kind == N_NUM) { e = n->b->num; hav = 1; }
            else if (n->b->kind == N_NEG && n->b->a->kind == N_NUM) { e = -n->b->a->num; hav = 1; }
            if (hav && e == floor(e) && fabs(e) < 1e9) {
                sup_digits(o, (long long)e);
                break;
            }
        }
        sb_putc(o, '^');
        /* 指数是常数且渲染出来含 '/' 或以 '-' 开头 → 括号：x^(-2)、x^(1/2) */
        if (n->b->kind == N_NUM) {
            fmt_num_st(n->b->num, buf, sizeof buf, st);
            if (strchr(buf, '/') || buf[0] == '-') {
                sb_putc(o, '(');
                sb_puts(o, buf);
                sb_putc(o, ')');
                break;
            }
            sb_puts(o, buf);
            break;
        }
        rend(o, n->b, 3, 1, st);
        break;
    default:
        sb_puts(o, "?");
        break;
    }
}''')

# ==================== 6. canon / render_malloc：锁 plain ====================
add("canon-plain", r'''    sb_init(&b);
    rend(&b, n, 0, 0);
    r = ar_strdup(ar, b.p ? b.p : "?", b.n);''', r'''    sb_init(&b);
    rend(&b, n, 0, 0, &ST_PLAIN);
    r = ar_strdup(ar, b.p ? b.p : "?", b.n);''')

add("render-malloc-plain", r'''static char *render_malloc(Node *n)
{
    SB b;
    sb_init(&b);
    rend(&b, n, 0, 0);
    return b.p;
}''', r'''static char *render_malloc(Node *n)
{
    SB b;
    sb_init(&b);
    rend(&b, n, 0, 0, &ST_PLAIN);
    return b.p;
}''')

# ==================== 7. 解方程 + 输出格式（核心入口区末尾） ====================
add("solve-core", r'''/* ==================== 绑定层 ==================== */
#if defined(PYBOOK_RT_H) || defined(SYM_RT_BINDING)''', r'''/* ==================== 解方程（sym.求解） ==================== */

/* 无变量子式的常数值（NUM、pi、折叠过的 sin(1) 等）；非有限（inf/nan）算失败 */
static int const_eval(Node *n, double *v)
{
    if (!eval_node(n, NULL, NULL, 0, v, NULL, 0)) return 0;
    return isfinite(*v) ? 1 : 0;
}

/* 按 var 收集多项式系数：coef[k] += 该项贡献的 x^k 系数。
 * sgn / scale 是递归递下来的符号与常数比例。是多项式返回 1，否则 0。 */
static int poly_term_s(Node *n, const char *var, int maxdeg,
                       double *coef, double sgn, double scale)
{
    double v;
    int i;

    if (!has_var(n, var)) {                 /* 纯常数段（NUM、pi、sin(1) 折叠项） */
        if (!const_eval(n, &v)) return 0;
        coef[0] += sgn * scale * v;
        return 1;
    }
    switch (n->kind) {
    case N_VAR:
        if (strcmp(n->str, var) == 0 && maxdeg >= 1) {
            coef[1] += sgn * scale;
            return 1;
        }
        return 0;                            /* 方程里还有别的变量 */
    case N_NEG:
        return poly_term_s(n->a, var, maxdeg, coef, -sgn, scale);
    case N_ADD:
        if (!poly_term_s(n->a, var, maxdeg, coef, sgn, scale)) return 0;
        return poly_term_s(n->b, var, maxdeg, coef, sgn, scale);
    case N_SUB:
        if (!poly_term_s(n->a, var, maxdeg, coef, sgn, scale)) return 0;
        return poly_term_s(n->b, var, maxdeg, coef, -sgn, scale);
    case N_DIV: {
        double vd;
        if (as_const_num(n->b, &vd) && vd != 0 && !has_var(n->b, var))
            return poly_term_s(n->a, var, maxdeg, coef, sgn, scale / vd);
        return 0;                            /* 1/x、x/(x+1) 都不是多项式 */
    }
    case N_POW: {
        double e;
        if (n->a->kind == N_VAR && strcmp(n->a->str, var) == 0 &&
            as_const_num(n->b, &e) && e >= 0 && e == floor(e)) {
            if (e > maxdeg) return 0;
            coef[(int)e] += sgn * scale;
            return 1;
        }
        if (n->a->kind == N_NUM && n->b->kind == N_NUM) {
            double r = pow(n->a->num, n->b->num);
            if (isfinite(r)) { coef[0] += sgn * scale * r; return 1; }
        }
        return 0;                            /* x^0.5、x^y、2^x 交给展开或认输 */
    }
    case N_MUL: {
        Node *fs[256];
        int nf = 0;
        double sc = sgn * scale;
        int e = 0;
        collect_mul(n, fs, &nf, 256);
        if (nf == 0) return 0;
        for (i = 0; i < nf; i++) {
            Node *f = fs[i];
            double vv;
            int es = 0, neg = 0;
            if (f->kind == N_NEG) { neg = 1; f = f->a; }
            if (f->kind == N_NUM) { sc *= neg ? -f->num : f->num; continue; }
            if (!has_var(f, var)) {           /* 常数因子（pi、e、折叠过的 sin(1)） */
                if (!const_eval(f, &vv)) return 0;
                sc *= neg ? -vv : vv;
                continue;
            }
            if (f->kind == N_VAR && strcmp(f->str, var) == 0) {
                es = 1;
            } else if (f->kind == N_POW && f->a->kind == N_VAR &&
                       strcmp(f->a->str, var) == 0 && as_const_num(f->b, &vv) &&
                       vv >= 0 && vv == floor(vv) && vv <= maxdeg) {
                es = (int)vv;
            } else {
                return 0;                     /* sin(x)*x、x*(x+1)：先展开 */
            }
            if (neg) sc *= -1;
            e += es;
        }
        if (e > maxdeg) return 0;
        coef[e] += sc;
        return 1;
    }
    }
    return 0;                                 /* FUNC：sin(x)=0 这类不是多项式 */
}

static int gcd_int(int a, int b)
{
    if (a < 0) a = -a;
    if (b < 0) b = -b;
    while (b) { int t = a % b; a = b; b = t; }
    return a;
}

/* 数值根美化：整数优先，其次小分母分数（约分），否则 %.10g */
static void fmt_root(double r, char *buf, size_t sz)
{
    static const int dens[] = { 2, 3, 4, 5, 6, 8, 10, 12 };
    double a = fabs(r);
    int d, k, num, den, g;
    if (r == 0) { snprintf(buf, sz, "0"); return; }
    if (fabs(r - floor(r + 0.5)) <= 1e-9 * (1 + a)) {
        snprintf(buf, sz, "%.0f", r);
        return;
    }
    for (k = 0; k < (int)(sizeof dens / sizeof *dens); k++) {
        d = dens[k];
        if (fabs(a * d - floor(a * d + 0.5)) <= 1e-9 * d) {
            num = (int)floor(a * d + 0.5);
            g = gcd_int(num, d);
            if (g < 1) g = 1;
            num /= g;
            den = d / g;
            snprintf(buf, sz, "%s%d/%d", r < 0 ? "-" : "", num, den);
            return;
        }
    }
    snprintf(buf, sz, "%.10g", r);
}

/* 多项式求值（Horner，实系数） */
static double poly_at(const double *c, int n, double x)
{
    double r = 0;
    int i;
    for (i = n; i >= 0; i--) r = r * x + c[i];
    return r;
}

/* Durand-Kerner 复数迭代求全部根 → 取实根 → Newton 精修 → 去重。
 * 返回实根个数（0 = 没找到实根）；n 不在 [3,12] 返回 -1。 */
static int poly_real_roots(const double *c, int n, double *roots, int cap)
{
    double zr[16], zi[16], m[16], cr[16], ci[16];
    int i, j, it, cnt = 0;
    if (n < 3 || n > 12) return -1;
    for (i = 0; i <= n; i++) m[i] = c[i] / c[n];      /* 首一化 */
    zr[0] = 1; zi[0] = 0;                             /* 初始猜测 (0.4+0.9i)^k */
    for (i = 1; i < n; i++) {
        double tr = zr[i - 1] * 0.4 - zi[i - 1] * 0.9;
        double ti = zr[i - 1] * 0.9 + zi[i - 1] * 0.4;
        zr[i] = tr;
        zi[i] = ti;
    }
    for (it = 0; it < 400; it++) {
        double maxp = 0;
        for (i = 0; i < n; i++) {
            double pr = m[n], pi = 0, dr = 1, di = 0, den, qr, qi, pm;
            int k;
            for (k = n - 1; k >= 0; k--) {            /* p(z)：复数 Horner */
                double tr = pr * zr[i] - pi * zi[i] + m[k];
                pi = pr * zi[i] + pi * zr[i];
                pr = tr;
            }
            for (j = 0; j < n; j++) {                 /* prod(z - zj) */
                double ar, ai, tr;
                if (j == i) continue;
                ar = zr[i] - zr[j];
                ai = zi[i] - zi[j];
                tr = dr * ar - di * ai;
                di = dr * ai + di * ar;
                dr = tr;
            }
            den = dr * dr + di * di;
            if (den < 1e-300) { cr[i] = 0; ci[i] = 0; continue; }
            qr = (pr * dr + pi * di) / den;
            qi = (pi * dr - pr * di) / den;
            cr[i] = qr;
            ci[i] = qi;
            pm = sqrt(pr * pr + pi * pi);
            if (pm > maxp) maxp = pm;
        }
        for (i = 0; i < n; i++) { zr[i] -= cr[i]; zi[i] -= ci[i]; }
        if (maxp < 1e-12) break;
    }
    for (i = 0; i < n && cnt < cap; i++) {
        double re = zr[i], im = zi[i];
        int k, dup = 0;
        if (!(fabs(re) < 1e12)) continue;              /* NaN/inf 挡掉 */
        if (fabs(im) > 1e-7 * (1 + fabs(re))) continue;/* 非实根跳过 */
        for (k = 0; k < 60; k++) {                     /* Newton 精修（重根线性收敛也够） */
            double p = poly_at(c, n, re), d = 0, step;
            int t;
            for (t = n; t >= 1; t--) d = d * re + t * c[t];
            if (fabs(d) < 1e-300) break;
            step = p / d;
            if (!(fabs(step) < 1e8)) break;
            re -= step;
            if (fabs(step) <= 1e-15 * (1 + fabs(re))) break;
        }
        if (!isfinite(re)) continue;
        for (j = 0; j < cnt; j++)
            if (fabs(roots[j] - re) <= 1e-7 * (1 + fabs(re))) { dup = 1; break; }
        if (!dup) roots[cnt++] = re;
    }
    return cnt;
}

/* 解方程：eq 形如 "左=右"（缺 = 当右边是 0）。返回 "x = r1, x = r2"（升序）；
 * 恒等式 / 无解 / 无实根都给明确文字；失败返回 NULL（err 有文案）。 */
char *sym_core_solve(const char *eq, const char *var, char *err, size_t errsz)
{
    Arena ar = {0};
    Node *lh, *rh, *e;
    const char *eqp;
    char *names[64];
    int nn = 0, i, deg = 0, nr;
    double coef[80];
    double roots[16];
    SB b;

    if (bad_var_name(var, err, errsz)) return NULL;

    eqp = strchr(eq, '=');
    if (eqp) {
        size_t ll = (size_t)(eqp - eq);
        const char *rs = eqp + 1;
        int lempty = 1, rempty = 1;
        char *ls;
        for (i = 0; i < (int)ll; i++)
            if (!isspace((unsigned char)eq[i])) { lempty = 0; break; }
        for (i = 0; rs[i]; i++)
            if (!isspace((unsigned char)rs[i])) { rempty = 0; break; }
        if (lempty || rempty) {
            if (err) snprintf(err, errsz,
                "等号%s边是空的（解方程要写成 左=右，比如 \"x^2 - 5*x + 6 = 0\"）",
                lempty ? "左" : "右");
            return NULL;
        }
        ls = ar_strdup(&ar, eq, ll);
        lh = compile1(ls, &ar, err, errsz);
        if (!lh) goto fail;
        rh = compile1(rs, &ar, err, errsz);
        if (!rh) goto fail;
    } else {
        lh = compile1(eq, &ar, err, errsz);
        if (!lh) goto fail;
        rh = nd_num(&ar, 0);
    }

    /* 左 - 右；先化简再展开——(x-1)^3、x*(x+1) 这类要先展开才收得动系数 */
    e = simp(&ar, expand(&ar, simplified(&ar, nd_bin(&ar, N_SUB, lh, rh))));

    collect_vars(e, names, &nn, 64);
    if (nn > 0) {
        int has = 0;
        SB vb;
        sb_init(&vb);
        for (i = 0; i < nn; i++) {
            if (strcmp(names[i], var) == 0) { has = 1; continue; }
            if (vb.n) sb_puts(&vb, "、");
            sb_puts(&vb, names[i]);
        }
        if (!has || vb.n) {
            if (err) {
                if (has)
                    snprintf(err, errsz,
                        "方程里还有别的变量 %s，第一版只解单变量方程（先用 sym.替换 把它们代成数字）",
                        vb.p);
                else
                    snprintf(err, errsz,
                        "方程里找不到变量 %s（里面出现的是 %s）", var, vb.p);
            }
            free(vb.p);
            goto fail;
        }
        free(vb.p);
    }

    for (i = 0; i < 80; i++) coef[i] = 0;
    if (!poly_term_s(e, var, 12, coef, 1, 1)) {
        for (i = 0; i < 80; i++) coef[i] = 0;
        if (poly_term_s(e, var, 64, coef, 1, 1)) {
            if (err) snprintf(err, errsz,
                "方程次数太高了（超过 12 次），数值求根不可靠（先因式分解，再分开解）");
            goto fail;
        }
        if (err) snprintf(err, errsz,
            "方程不是 %s 的多项式（含 sin(%s)、1/%s、%s^0.5 或未展开的乘积这类项），"
            "第一版只解多项式方程；可以先 sym.展开 / sym.化简，或用 sym.求值 做数值代入",
            var, var, var, var);
        goto fail;
    }
    for (i = 79; i >= 1; i--)
        if (fabs(coef[i]) > 1e-12) { deg = i; break; }
    for (i = 0; i <= deg; i++)
        if (fabs(coef[i]) < 1e-12) coef[i] = 0;

    if (deg == 0) {                       /* 方程与 var 无关：恒等或无解 */
        sb_init(&b);
        sb_puts(&b, fabs(coef[0]) < 1e-12 ? "恒等式（任何值都成立）"
                                          : "无解（两边永远不相等）");
        ar_free(&ar);
        return b.p;
    }
    if (deg == 1) {
        roots[0] = -coef[0] / coef[1];
        nr = 1;
    } else if (deg == 2) {
        double a2 = coef[2], a1 = coef[1], a0 = coef[0];
        double disc = a1 * a1 - 4 * a2 * a0;
        double tol = 1e-12 * (1 + fabs(a1) + fabs(a2 * a0));
        if (disc > tol) {
            double sq = sqrt(disc);
            roots[0] = (-a1 - sq) / (2 * a2);
            roots[1] = (-a1 + sq) / (2 * a2);
            nr = 2;
        } else if (disc < -tol) {
            if (err) snprintf(err, errsz,
                "没有实数解（判别式 %.10g < 0，根是一对复数）", disc);
            goto fail;
        } else {
            roots[0] = -a1 / (2 * a2);      /* 重根 */
            nr = 1;
        }
    } else {
        nr = poly_real_roots(coef, deg, roots, 16);
        if (nr < 0) {
            if (err) snprintf(err, errsz, "数值求根失败（方程太病态了，换数值方法吧）");
            goto fail;
        }
        if (nr == 0) {
            if (err) snprintf(err, errsz,
                "没有找到实数解（根全是复数，或者数值求根没收敛）");
            goto fail;
        }
    }
    for (i = 1; i < nr; i++) {             /* 升序 */
        double key = roots[i];
        int j = i - 1;
        while (j >= 0 && roots[j] > key) { roots[j + 1] = roots[j]; j--; }
        roots[j + 1] = key;
    }
    sb_init(&b);
    for (i = 0; i < nr; i++) {
        char rb[48];
        fmt_root(roots[i], rb, sizeof rb);
        if (i) sb_puts(&b, ", ");
        sb_puts(&b, var);
        sb_puts(&b, " = ");
        sb_puts(&b, rb);
    }
    ar_free(&ar);
    return b.p;
fail:
    ar_free(&ar);
    return NULL;
}

/* ==================== 输出格式（sym.格式） ==================== */

/* mode："" / "plain"（默认，与 sym.解析 逐字一致）/ "latex" / "unicode"（认 uni） */
char *sym_core_format(const char *expr, const char *mode, char *err, size_t errsz)
{
    Arena ar = {0};
    Node *n;
    const RendStyle *st;
    SB b;

    if (!mode || !*mode || strcmp(mode, "plain") == 0) st = &ST_PLAIN;
    else if (strcmp(mode, "latex") == 0) st = &ST_LATEX;
    else if (strcmp(mode, "unicode") == 0 || strcmp(mode, "uni") == 0) st = &ST_UNI;
    else {
        if (err) snprintf(err, errsz,
            "输出模式只认 plain / latex / unicode（收到 \"%s\"）", mode);
        return NULL;
    }
    n = compile1(expr, &ar, err, errsz);
    if (!n) return NULL;
    sb_init(&b);
    rend(&b, n, 0, 0, st);
    ar_free(&ar);
    return b.p;
}

/* ==================== 绑定层 ==================== */
#if defined(PYBOOK_RT_H) || defined(SYM_RT_BINDING)''')

# ==================== 8. 绑定层两个新函数 ====================
add("solve-binding", r'''Value rt_lib_sym_equal(Value av, Value bv)
{
    char err[192] = "";
    int r;
    sym_chk_str(av, "sym.相等", "一", "2*x");
    sym_chk_str(bv, "sym.相等", "二", "x + x");
    r = sym_core_equal(AS_STR(av), AS_STR(bv), err, sizeof err);
    if (r < 0) rt_die("sym.相等：%s", err);
    return rt_bool(r);
}

#endif /* PYBOOK_RT_H */''', r'''Value rt_lib_sym_equal(Value av, Value bv)
{
    char err[192] = "";
    int r;
    sym_chk_str(av, "sym.相等", "一", "2*x");
    sym_chk_str(bv, "sym.相等", "二", "x + x");
    r = sym_core_equal(AS_STR(av), AS_STR(bv), err, sizeof err);
    if (r < 0) rt_die("sym.相等：%s", err);
    return rt_bool(r);
}

Value rt_lib_sym_solve(Value ev, Value varv)
{
    char err[192] = "";
    char *r;
    sym_chk_str(ev, "sym.求解", "一", "x^2 - 5*x + 6 = 0");
    sym_chk_str(varv, "sym.求解", "二", "x");
    r = sym_core_solve(AS_STR(ev), AS_STR(varv), err, sizeof err);
    if (!r) rt_die("sym.求解：%s", err);
    return sym_out(r);
}

Value rt_lib_sym_format(Value ev, Value modev)
{
    char err[192] = "";
    char *r;
    sym_chk_str(ev, "sym.格式", "一", "x^2*sin(x)");
    sym_chk_str(modev, "sym.格式", "二", "latex");
    r = sym_core_format(AS_STR(ev), AS_STR(modev), err, sizeof err);
    if (!r) rt_die("sym.格式：%s", err);
    return sym_out(r);
}

#endif /* PYBOOK_RT_H */''')


def main():
    with io.open(PATH, encoding="utf-8", newline="") as f:
        s = f.read()
    orig = s

    if "sym_core_solve" in s:
        print("pybook_sym.c 已含 sym_core_solve，跳过（幂等）")
        return 0

    for label, old, new in P:
        n = s.count(old)
        if n != 1:
            sys.stderr.write("FAIL [%s] count=%d（锚点没命中或命中了多处，未写任何文件）\n"
                             % (label, n))
            return 1
        s = s.replace(old, new, 1)
        print("ok   " + label)

    # 落笔前自检：新符号都在位
    for tok in ("RendStyle", "fmt_num_st", "sup_digits", "fn_latex",
                "sym_core_solve", "sym_core_format",
                "rt_lib_sym_solve", "rt_lib_sym_format",
                "poly_term_s", "poly_real_roots", "fmt_root"):
        if tok not in s:
            sys.stderr.write("FAIL 落笔前自检：缺 %s\n" % tok)
            return 1
    if s.count("rend(") != s.count("rend("):  # 占位防呆
        return 1
    if ", st)" not in s:
        sys.stderr.write("FAIL 落笔前自检：rend 调用没穿上 st\n")
        return 1

    with io.open(PATH, "w", encoding="utf-8", newline="") as f:
        f.write(s)
    print("\n全部 %d 处补丁落盘：%s" % (len(P), PATH))
    return 0


if __name__ == "__main__":
    sys.exit(main())
