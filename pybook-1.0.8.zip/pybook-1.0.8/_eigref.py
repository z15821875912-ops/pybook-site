# -*- coding: utf-8 -*-
"""Francis 双移位 QR 的**独立参考实现**，用来判 C 版到底是「算法对但慢」还是「C 写错了」。

同样的矩阵、同样的移位、同样的反射，Python 这边用 numpy 重写一遍。
C 的 la_francis 是手抄进 C 的，两边独立写错了同一个地方是有可能的，但不太可能同时错；
所以「Python 快、C 慢」就说明 C 有 bug，「Python 也慢」就说明是算法/判据的问题。

用法：python -B _eigref.py
"""
import numpy as np

np.set_printoptions(precision=12, suppress=False)


def hessenberg(a):
    """EISPACK elmhes / LAPACK dgehrd 的约定：
    第 k 步的反射器作用在 (h[k+1][k], h[k+2..n-1][k]) 上，
    把 h[k+1][k] 重写成 alpha、把更下面的全清零。
    次对角元**参与**反射并被改写——这一点写错，整张表就不是上 Hessenberg，
    后面所有 Francis 步的前提（隐式 Q 定理）全部作废。
    """
    n = a.shape[0]
    h = a.astype(float).copy()
    q = np.eye(n)
    for k in range(0, n - 1):
        m = n - k - 1
        if m <= 0:
            break
        v = np.zeros(m)
        v[:] = h[k + 1:, k]
        nrm = np.linalg.norm(v)
        if nrm == 0.0:
            continue
        alpha = -nrm if v[0] > 0 else nrm
        v[0] -= alpha
        vv = v @ v
        beta = 2.0 / vv

        # H = P·H：只动行 k+1..n-1
        sub = h[k + 1:, :].copy()
        h[k + 1:, :] = sub - beta * np.outer(v, v @ sub)
        # H = H·P：只动列 k+1..n-1
        sub = h[:, k + 1:].copy()
        h[:, k + 1:] = sub - beta * np.outer(sub @ v, v)
        # Q = Q·P
        sub = q[:, k + 1:].copy()
        q[:, k + 1:] = sub - beta * np.outer(sub @ v, v)

        h[k + 1, k] = alpha
        h[k + 2:, k] = 0.0
    return h, q


def francis(t, q, n, l, u, zero_shift=False):
    """一步隐式 Francis 双移位。返回 True 表示停滞（没有反射可作用）。

    反射向量就是 **(M² − p·M + q·I)·e₀** 的前 s 项，其中 M 是窗口子矩阵。
    直接用 `m @ m[:,0]` 算就行——因为 Me₀ 的支撑就在窗口内、窗口外是零填充，
    窗口子矩阵的乘积恰好给出完整矩阵那几项，不多不少。
    （曾经试过手抄 G&V Alg 7.5.1 的首向量展开式，三项全放错位置；
     相似性照样成立——任何正交反射都是相似变换——但不是 QR 步，迭代会卡死在不动点。
     这种 bug 极阴险：不报错、不炸，只是不收敛。）
    """
    s = u - l + 1
    a = t[u - 1, u - 1]
    b = t[u - 1, u]
    c = t[u, u - 1]
    d = t[u, u]
    p = a + d
    qq = a * d - b * c
    if zero_shift:
        qq = 0.0

    m = t[l:l + s, l:l + s]
    col2 = m @ (m[:, 0].copy()) - p * m[:, 0]
    col2[0] += qq

    v = col2.copy()
    if np.linalg.norm(v[1:]) == 0.0:
        return True                      # x 已经在 span(e₀) 里，没有反射可做
    # Householder 要把 x 映成 (alpha,0,...,0)，构造是 v = x + sign(x0)*|x|*e0。
    # |x| 是**整个**向量的范数；用尾段范数 |x[1:]| 算出来的 P 照样正交、
    # 照样是相似变换（迹、det 全都守恒，一个错都不报），但它不是那一个反射，
    # QR 迭代会安安静静滑进不动点。这是本项目踩过最阴险的一个 bug。
    xn = np.linalg.norm(v)
    alpha = -xn if v[0] > 0 else xn
    v[0] -= alpha
    beta = 2.0 / (v @ v)

    # T = P·T：只动窗口里的行，但**每一列**
    sub = t[l:l + s, :].copy()
    t[l:l + s, :] = sub - beta * np.outer(v, v @ sub)
    # T = T·P：只动窗口里的列，但**每一行**
    sub = t[:, l:l + s].copy()
    t[:, l:l + s] = sub - beta * np.outer(sub @ v, v)
    # Q = Q·P
    sub = q[:, l:l + s].copy()
    q[:, l:l + s] = sub - beta * np.outer(sub @ v, v)
    return False


def eig2x2(a, b, c, d):
    tr = 0.5 * (a + d)
    hh = 0.5 * (a - d)
    disc = hh * hh + b * c
    sc = abs(a) + abs(b) + abs(c) + abs(d)
    if disc < 0.0 and disc > -2.220446049250313e-16 ** 2 * sc:
        disc = 0.0
    sq = np.sqrt(abs(disc))
    if disc >= 0.0:
        return np.array([tr - sq, tr + sq]), np.array([0.0, 0.0])
    return np.array([tr, tr]), np.array([sq, -sq])


def qr1(t, q, n, i, j, tau):
    """**单移位**隐式 QR 步：反射器零化 (a−τ, c)，即第 i 列去掉平移后。
    2×2 窗口必须走这条路，不能用「特征向量旋转」——
    非对称矩阵**不能**正交对角化，特征向量旋转对已经是上三角的块什么都不做，
    于是白白烧掉几千步上限（实测 n=6 撞满 3800 步仍不收敛）。
    双移位在 2×2 上也不行：尾随 2×2 就是整个块，x = (M²−pM+qI)e₀ 恒为 0。
    """
    v = np.array([t[i, i] - tau, t[i + 1, i]])
    nrm = np.linalg.norm(v)
    if nrm == 0.0:
        return False
    alpha = -nrm if v[0] > 0 else nrm
    v[0] -= alpha
    beta = 2.0 / (v @ v)
    sub = t[i:i + 2, :].copy(); t[i:i + 2, :] = sub - beta * np.outer(v, v @ sub)
    sub = t[:, i:i + 2].copy(); t[:, i:i + 2] = sub - beta * np.outer(sub @ v, v)
    sub = q[:, i:i + 2].copy();   q[:, i:i + 2] = sub - beta * np.outer(sub @ v, v)
    return True


def rot2x2(t, q, n, i, j):
    """把 2×2 块 (i,j) 收尾。

    两条硬约束：
      1) 共轭复数对的**子对角元不能清**——[[0,1],[-1,0]] 的特征值是 ±i，子对角元是 -1，
         清成 0 就是把相似性当破坏掉。转不动就原样留着（它本来就是合法块）。
      2) 两个**不同**的实特征值也**不能**把超对角清零：任何实正交旋转一旦清掉子对角，
         超对角就变成 ‖λ₁‖ 和 ‖λ₂‖ 的组合，非零是转不掉的（转第二次会把子对角弄乱）。
         真正标准形里两个实特征值各占一个 1×1 块，那要靠「迭代到超对角自己变小」，
         不是靠一次强转。

    所以这里只做「清子对角」这一步，**超对角原样保留**（它此时应该已经很小）。
    """
    a, b, c, d = t[i, i], t[i, j], t[j, i], t[j, j]
    wr, wi = eig2x2(a, b, c, d)
    if wi[0] != 0.0:
        return                       # 共轭复数对：2×2 块原样保留
    x0, x1 = b, wr[0] - a            # λ 对应的特征向量 (b, λ-a)
    nx = np.sqrt(x0 * x0 + x1 * x1)
    if nx == 0.0:
        return                       # b == 0，已经是上三角
    alpha = -nx if x0 > 0 else nx
    u0, u1 = x0 - alpha, x1
    beta = 2.0 / (u0 * u0 + u1 * u1)

    sub = t[i:j + 1, :].copy()
    t[i:j + 1, :] = sub - beta * np.outer([u0, u1], [u0, u1] @ sub)
    sub = t[:, i:j + 1].copy()
    t[:, i:j + 1] = sub - beta * np.outer(sub @ np.array([u0, u1]), [u0, u1])
    sub = q[:, i:j + 1].copy()
    q[:, i:j + 1] = sub - beta * np.outer(sub @ np.array([u0, u1]), [u0, u1])
    t[i, i], t[j, i] = wr[0], 0.0    # 只写回对角与**子**对角，超对角保留
    t[j, j] = wr[1]


def deflate_all(t, n):
    """把所有相对邻元可忽略的子对角元显式清零。

    不做这一步的话，已经裂开的子对角元会带着 ~1e-163 的舍入残余留在原地，
    而窗口选择是用 `!= 0.0` 判的 —— 认不出来，于是窗口一直不肯收缩，
    Francis 步作用在一个本该已经拆开的窗口上，几十步后直接冻在不动点。
    实测：n=4 的一块含复共轭特征值的矩阵，卡在 ~7 位有效数字不动，
    相似性完好（3.9e-15）——所以只看残差根本发现不了。
    """
    for k in range(1, n):
        sub = abs(t[k, k - 1])
        nrm = abs(t[k - 1, k - 1]) + abs(t[k, k])
        if sub <= np.finfo(float).eps * (nrm + sub):
            t[k, k - 1] = 0.0


def schur(a, maxits=2000, trace=False):
    """实 Schur 分解。返回 (T, Q, 迭代步数, 是否收敛, 特征值实部, 特征值虚部)。

    特征值在**迭代过程中**按块记下来，而不是事后靠「超对角非零就是 2×2 块」
    去反推——事后反推对两个实特征值的 2×2 块会误判（超对角清不掉，非零是正常的）。
    """
    n = a.shape[0]
    t, q = hessenberg(a)
    wre = np.zeros(n)
    wim = np.zeros(n)
    u = n - 1
    its = 0
    zero_shift = False
    while u >= 0:
        deflate_all(t, n)
        # 劈开：子对角元相对邻元小到可以当 0
        while u > 0:
            sub = abs(t[u, u - 1])
            nrm = abs(t[u - 1, u - 1]) + abs(t[u, u])
            if sub > np.finfo(float).eps * (nrm + sub):
                break
            t[u, u - 1] = 0.0
            wre[u] = t[u, u]
            wim[u] = 0.0
            u -= 1
        if u == 0:
            wre[0] = t[0, 0]
            wim[0] = 0.0
            break
        l = u - 1
        while l > 0 and t[l, l - 1] != 0.0:
            l -= 1
        # 窗口顶端也可能已经裂开（t[l+1][l] == 0）。必须一起收拾：
        # 顶端一裂，反射向量 x 的第 1..s-1 项全为 0 → la_francis 报「停滞」，
        # 而停滞不是「该换移位了」，是「窗口该往上收一格了」。少这一句，
        # n>=4 一律在几十步后走进死路（n<=3 因为窗口总是满的反而没事）。
        while l < u - 1 and t[l + 1, l] == 0.0:
            l += 1
        if u - l == 1:
            # 窗口只剩 2×2。**判据不能用「判别式为负」**——中途态的 2×2 也可能
            # 暂时呈复数对的样子，提前收下就等于把错的块焊进 Schur 形式，
            # 后面几步必然僵在那儿（实测 n=6 撞满 3800 步上限）。
            #
            # 用 LAPACK dlahqr 的判据：**收敛后的复数对，两个对角元都趋于 Re(λ)**，
            # 所以 |H(i,i) − H(i+1,i+1)| 可忽略、而超对角不可忽略。
            # 「对角元相等」这一条是关键：假的复数对两个对角元不会相等。
            a_, b_, c_, d_ = t[u - 1, u - 1], t[u - 1, u], t[u, u - 1], t[u, u]
            wr, wi = eig2x2(a_, b_, c_, d_)
            scale = abs(a_) + abs(d_)
            diag_same = abs(a_ - d_) <= 1e-12 * (scale + abs(b_) + abs(c_) + 1e-300)
            sup_small = abs(b_) <= np.finfo(float).eps * scale
            if sup_small:
                # 超对角已塌：两个 1×1 块，特征值就是两个对角元
                wre[u - 1], wre[u] = a_, d_
                wim[u - 1], wim[u] = 0.0, 0.0
                t[u, u - 1] = 0.0
                u -= 2
                if u < 0:
                    break
                continue
            if diag_same and wi[0] != 0.0:
                # 判别式为负 **且** 两个对角元已经相等（都趋于 Re(λ)）——两条都满足
                # 才是真的共轭复数对。只看判别式会把中途态也收下（n=5 直接退化）。
                wre[u - 1], wre[u] = wr[0], wr[1]
                wim[u - 1], wim[u] = wi[0], wi[1]
                u -= 2
                if u < 0:
                    break
                continue
            # 还没收敛：走单移位 QR 步，移位取离 a_ 更近的那个特征值
            tau = wr[0] if abs(wr[0] - a_) <= abs(wr[1] - a_) else wr[1]
            qr1(t, q, n, u - 1, u, tau)
            its += 1
            if its >= maxits:
                return t, q, its, False, wre, wim
            continue
        if its >= maxits:
            return t, q, its, False, wre, wim
        if francis(t, q, n, l, u, zero_shift):
            if zero_shift:
                return t, q, its, False, wre, wim
            zero_shift = True
        else:
            zero_shift = False
        its += 1
        if trace and its % 25 == 0:
            print("    its=%4d sub=%.6g" % (its, abs(t[u, u - 1])))
    return t, q, its, True, wre, wim


if __name__ == "__main__":
    A = np.array([
        [0.104849, 0.33491, 0.700101],
        [-0.149776, 0.629897, 0.941049],
        [0.195691, -0.555375, -0.961234],
    ])
    print("=== rand3（和 C 探针同一块矩阵）===")
    t, q, its, ok = schur(A, maxits=3000, trace=True)
    print("迭代步数 =", its, " 收敛 =", ok)
    print("T =\n", t)
    print("特征值(C) =", np.sort(np.linalg.eigvals(A)))
    print("det(A) =", np.linalg.det(A), "  det(T) =", np.linalg.det(t))
    print("‖QᵀQ − I‖ =", np.abs(q.T @ q - np.eye(3)).max())
    print("‖A − QTQᵀ‖ =", np.abs(A - q @ t @ q.T).max())

    print()
    print("=== 另几块，看是不是普遍慢 ===")
    rng = np.random.default_rng(7)
    for n in (3, 4, 5, 8, 12):
        for trial in range(3):
            B = rng.standard_normal((n, n))
            t, q, its, ok = schur(B, maxits=3000)
            ref = np.sort_complex(np.linalg.eigvals(B))
            mine = np.sort_complex(np.diag(t)) if ok else None
            err = np.abs(np.sort_complex(mine) - ref).max() if ok else float("nan")
            print("n=%2d trial=%d  步数=%4d 收敛=%s  特征值最大误差=%.3g"
                  % (n, trial, its, ok, err))