# -*- coding: utf-8 -*-
"""tests/jit_correctness.py — JIT 与解释器逐字一致性回归（Phase H 独立于 run_tests.py）

为什么单列：JIT 把字节码重放成 C 再交给 gcc，语义必须**逐字**和解释器一样。
cases.py 每次只跑一个后端，结构上比不了"同一段代码两个后端跑出来一模一样"。

用法：python tests/jit_correctness.py
判据：stdout / stderr / 退出码 三项全等；任何一项不等即失败。
"""
import os
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.stdout.reconfigure(encoding="utf-8")
os.chdir(ROOT)
OUT = os.path.join(ROOT, "build_tmp", "probe")
os.makedirs(OUT, exist_ok=True)

HEAD = "@ 回归>JIT一致性>1\n"
# 外层反复调用，让热计数越过阈值（阈值 4）；内层做真正的活。
# ROUND 占位：这个调用要再追加 ", at"（外层轮号）作为第二个实参 ——
# 错误用例靠它把失败推迟到第 11 轮，否则函数第一次调用就死，热计数永远到不了阈值，
# 根本不会上原生，「两边一致」就只是因为两边都在解释器上跑，等于没测到原生路径。
WRAP = 'GOING:{\nrm.around(12) {\n    vg.好 = %s\n}\nns.show("结果 =", 好)\n}STOP\n'

CASES = {
 # ── 纯算术 / 快路 ──
 'int_arith': ('''func f(n) {
    vg.和 = 0
    rm.around(n) {
        vg.和 = 和 + at * 3 - 1
    }
    ret 和
}
''', 'list.f(500)'),
 'int_edges': ('''func f(n) {
    vg.和 = 0
    rm.around(n) {
        vg.和 = 和 + at % 7
    }
    ret 和 - 4611686018427387904
}
''', 'list.f(500)'),
 'float': ('''func f(n) {
    vg.和 = 0.0
    rm.around(n) {
        vg.和 = 和 + at / 3.0
    }
    ret 和
}
''', 'list.f(500)'),
 'mixed_cmp': ('''func f(n) {
    vg.和 = 0
    rm.around(n) {
        if(at < n / 2) {
            vg.和 = 和 + 1
        } else {
            if(at > n - 3) {
                vg.和 = 和 + 100
            } else {
                vg.和 = 和 + 2
            }
        }
    }
    ret 和
}
''', 'list.f(500)'),
 'str_concat': ('''func f(n) {
    vg.串 = ""
    rm.around(n) {
        vg.串 = 串 + te.str(at)
    }
    ret 长度(串)
}
''', 'list.f(200)'),
 # ── 列表 / 字典 ──
 'list_basic': ('''func f(n) {
    vg.表 = []
    rm.around(n) {
        list.添加(表, at * at)
    }
    vg.和 = 0
    rm.around(n) {
        vg.和 = 和 + 表[n - 1 - at]
    }
    ret 和
}
''', 'list.f(200)'),
 'dict_basic': ('''func f(n) {
    vg.表 = {}
    rm.around(n) {
        dict.set(表, te.str(at), at * 2)
    }
    ret dict.get(表, "7", -1)
}
''', 'list.f(200)'),
 # ── 标准库调用（CALL_LIB，Phase H 新解锁）──
 'mt_sqrt': ('''func f(n) {
    vg.和 = 0.0
    rm.around(n) {
        vg.和 = 和 + mt.sqrt(at / 4.0) + mt.floor(at / 3.0)
    }
    ret 和
}
''', 'list.f(500)'),
 'mt_misc': ('''func f(n) {
    vg.和 = 0
    rm.around(n) {
        vg.和 = 和 + mt.abs(0 - at) + mt.clamp(at, 10, 200)
    }
    ret 和
}
''', 'list.f(500)'),
 'te_ops': ('''func f(n) {
    vg.串 = ""
    rm.around(n) {
        vg.串 = 串 + te.upper(te.str(at % 10))
    }
    ret 串
}
''', 'list.f(200)'),
 'list_lib': ('''func f(n) {
    vg.表 = []
    rm.around(n) {
        list.添加(表, n - at)
    }
    vg.升 = list.sorted(表)
    ret 升[0] + 升[n - 1] + list.max(升) + list.count(升, 升[0])
}
''', 'list.f(200)'),
 # ── 用户函数调用（Phase H 新解锁）──
 'fn_simple': ('''func g(x) {
    ret x * x + 1
}
func f(n) {
    vg.和 = 0
    rm.around(n) {
        vg.和 = 和 + list.g(at)
    }
    ret 和
}
''', 'list.f(500)'),
 'fn_recursive': ('''func 阶乘(k) {
    if(k <= 1) {
        ret 1
    }
    ret k * list.阶乘(k - 1)
}
func f(n) {
    vg.和 = 0
    rm.around(n) {
        vg.和 = 和 + list.阶乘(6)
    }
    ret 和
}
''', 'list.f(300)'),
 'fn_fib': ('''func fib(k) {
    if(k < 2) {
        ret k
    }
    ret list.fib(k - 1) + list.fib(k - 2)
}
func f(n) {
    vg.和 = 0
    rm.around(n) {
        vg.和 = 和 + list.fib(12)
    }
    ret 和
}
''', 'list.f(50)'),
 'fn_mutual': ('''func 奇(k) {
    if(k == 0) {
        ret 1
    }
    ret list.偶(k - 1)
}
func 偶(k) {
    if(k == 0) {
        ret 0
    }
    ret list.奇(k - 1)
}
func f(n) {
    vg.和 = 0
    rm.around(n) {
        vg.和 = 和 + list.奇(9) + list.偶(9)
    }
    ret 和
}
''', 'list.f(500)'),
 # ── 混合 ──
 'mixed_all': ('''func 平方(x) {
    ret x * x
}
func f(n) {
    vg.和 = 0.0
    vg.表 = []
    rm.around(n) {
        list.添加(表, mt.sqrt(list.平方(at) / 2.0))
    }
    rm.around(n) {
        vg.和 = 和 + 表[at]
    }
    ret 和
}
''', 'list.f(200)'),
 # ── 错误路径 ──
 # 失败必须推迟到第 11 轮（见 ROUND 注释）：先让函数在原生路径上跑够 10 轮，
 # 第 11 轮才炸，这样才能验「原生代码里报错」时的 stderr 与退出码是否和解释器一致。
 'err_index_oob': ('''func f(n, 轮) {
    vg.表 = [1, 2, 3]
    vg.和 = 0
    rm.around(n) {
        vg.和 = 和 + 表[at % 3]
    }
    if(轮 > 10) {
        ret 表[n * 1000]
    }
    ret 和
}
''', 'list.f(500, ROUND)'),
 'err_div_zero': ('''func f(n, 轮) {
    vg.和 = 0
    vg.零 = 0
    rm.around(n) {
        vg.和 = 和 + at
    }
    if(轮 > 10) {
        ret 100 / 零
    }
    ret 和
}
''', 'list.f(300, ROUND)'),
 'err_type_mt': ('''func f(n, 轮) {
    vg.和 = 0
    rm.around(n) {
        vg.和 = 和 + mt.floor(mt.sqrt(at / 4.0))
    }
    if(轮 > 10) {
        ret mt.sqrt(te.str(和))
    }
    ret 和
}
''', 'list.f(300, ROUND)'),
 'err_index_in_fn': ('''func g(x) {
    vg.表 = [1, 2]
    ret 表[x]
}
func f(n) {
    vg.和 = 0
    rm.around(n) {
        vg.和 = 和 + list.g(0)
    }
    ret list.g(5)
}
''', 'list.f(300)'),
}

# 只跑 JIT 侧的用例：解释器对照在这里是不成立的（不是行为不同，是跑不完）。
# 解释器的帧开在堆上，无限递归会一路吃到 OOM；JIT 的帧开在 C 栈上，
# 没有护栏就是段错误。Phase H 加的 JIT_ENTER/JRET 就是为了把它变成可读报错。
JIT_ONLY = {
 'guard_deep_recursion': ('''func down(k) {
    ret list.down(k + 1)
}
func f(n) {
    ret list.down(0)
}
''', 'list.f(20)', '运行时错误', '递归太深'),
}

def build(tag, src):
    p = os.path.join(OUT, "jc_%s.pybk" % tag)
    open(p, "w", encoding="utf-8").write(src)
    pybc = p[:-5] + ".pybc"
    r = subprocess.run([sys.executable, "pybk_build.py", p, pybc],
                       capture_output=True, text=True, encoding="utf-8", errors="replace")
    if r.returncode != 0:
        return None, (r.stdout or "")[-900:] + (r.stderr or "")[-900:]
    return pybc, None


def run(exe, pybc, jit):
    env = dict(os.environ)
    env["PYTHONUTF8"] = "1"
    env["PYTHONIOENCODING"] = "utf-8"
    env["PYVM_JIT_VERBOSE"] = "1"
    args = [exe] + (["--jit=4"] if jit else []) + [pybc]
    p = subprocess.run(args, capture_output=True, text=True, encoding="utf-8",
                       errors="replace", env=env, cwd=ROOT, timeout=300)
    return p.returncode, p.stdout, p.stderr


def jit_state(stderr):
    for line in stderr.split("\n"):
        if "批量发射" in line or "无可 JIT" in line:
            return line.strip()
    if "编译失败" in stderr or "error:" in stderr:
        return "!! 编译失败（JIT 被静默回退）"
    return "?"


if __name__ == "__main__":
    EXE = "pyvm.exe"
    fails = []
    print("%-18s %-6s %s" % ("用例", "JIT", "判定"))
    for tag, spec in CASES.items():
        body, call = spec[0], spec[1]
        call = call.replace(", ROUND)", ", at)")
        pybc, err = build(tag, HEAD + body + WRAP % call)
        if pybc is None:
            print("%-18s %-6s 编译失败：%s" % (tag, '-', err[:120]))
            fails.append(tag + "(编译)")
            continue
        ri, oi, ei = run(EXE, pybc, False)
        rj, oj, ej = run(EXE, pybc, True)
        st = jit_state(ej)
        same = (ri == rj) and (oi == oj) and (ei == ej)
        # stderr 里 JIT 自己的日志不算差异
        ei_clean = "\n".join(l for l in ei.split("\n") if not l.startswith("[JIT]"))
        ej_clean = "\n".join(l for l in ej.split("\n") if not l.startswith("[JIT]"))
        same = (ri == rj) and (oi == oj) and (ei_clean == ej_clean)
        # 必须真的编上了：否则「一致」只是因为两边都在解释器上跑，等于没测
        compiled = "批量发射" in ej
        if not compiled:
            same = False
            fails.append(tag + "(未编译)")
        detail = ""
        if not same:
            if oi != oj:
                detail = "stdout 解=%r 原=%r" % (oj[:70], oi[:70])
            elif ei_clean != ej_clean:
                detail = "stderr 解=%r 原=%r" % (ej_clean[-90:], ei_clean[-90:])
            else:
                detail = "退出码 解=%s 原=%s" % (rj, ri)
            fails.append(tag)
        print("%-18s %-6s %s %s" % (tag, "开",
                                    "一致" if same else "!! " + detail, st[:46]))
    print()
    print("--- 只跑 JIT 侧（解释器对照不成立，见 JIT_ONLY 注释）---")
    for tag, (body, call, want_a, want_b) in JIT_ONLY.items():
        pybc, err = build(tag, HEAD + body + WRAP % call)
        if pybc is None:
            print("%-24s 编译失败：%s" % (tag, err[:120]))
            fails.append(tag + "(编译)")
            continue
        rj, oj, ej = run(EXE, pybc, True)
        ej_clean = "\n".join(l for l in ej.split("\n") if not l.startswith("[JIT]"))
        good = (rj != 0) and (want_a in ej_clean) and (want_b in ej_clean)
        if not good:
            fails.append(tag)
        print("%-24s %s  rc=%s  %s" % (
            tag, "符合预期" if good else "!! 不符合",
            rj, ej_clean.strip().replace("\n", " | ")[:130]))

    print()
    if fails:
        print("失败 %d 项：%s" % (len(fails), ", ".join(fails)))
        sys.exit(1)
    print("JIT 与解释器逐字一致：%d/%d" % (len(CASES), len(CASES)))
