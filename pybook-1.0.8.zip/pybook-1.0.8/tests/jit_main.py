# -*- coding: utf-8 -*-
"""fn 0（GOING 主程序）上原生的逐字一致回归。

为什么单独一个文件：Phase H 的 tests/jit_correctness.py 测的是「函数上原生」，
走的是解释器 case_0x30 里的 CALL 路由；主程序不是被 CALL 来的，是 run_module
入口直接调一次的，路由、门限、退出刷新三处都是新代码，形状不一样，得单独盯。

两条铁律：
1. 同一个 .pybc 跑「解释器 / JIT」，比 stdout / stderr / 退出码三项全等。
2. **主动断言 fn 0 真的上原生**。JIT 编译失败是静默回退解释器——不断言就会把
   「静默没生效」读成「一致通过」（Phase H 已经在 typedef 上栽过一次）。

用例分两类：
  native=True  = 期望主程序上原生（stderr 里必须有 "fn 0" + "-> 原生"）
  native=False = 期望主程序留在解释器（门限没过 / 文件头关了），
                 此时只比对输出，用来证明「没编译」也不改变行为。

用例里的循环次数不是随便写的：预编译门限按「静态估算指令数 >= 2000 万」判
（pyvm.c 的 JIT_MAIN_MIN_INSN），循环次数 × 循环体指令数就是估算值。
调小循环次数请同步改期望，否则会从「该上的没上」变成静默通过。
"""
import os
import re
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.stdout.reconfigure(encoding='utf-8')
os.chdir(ROOT)
OUT = os.path.join('build_tmp', 'probe', 'jit_main')
os.makedirs(OUT, exist_ok=True)
EXE = 'pyvm.exe'


def hdr(tag, *knobs):
    """文件头：@ 标签 + 若干旋钮行。PYbook 要求块与块之间空一行。"""
    return '@ 临时>fn0>%s\n%s\n' % (tag, ('\n'.join(knobs) + '\n') if knobs else '')


# 循环体约 5~8 条指令；乘出来的估算值要过 2000 万门限
BIG = 4000000        # ×5~8 条 ≈ 2000 万~3200 万
SMALL = 2000         # ×5~8 条 ≈ 1~2 万，够不着门限
LISTN = 3000000      # list.添加 循环体较短，次数要更大
ERRN = 6000000       # 错误路径：主程序要够重才会被预编译
DICTN = 6000000      # 字典用例同理：循环体只有一条赋值，次数要更大


def heavy(body_iter, extra=''):
    return ('GOING:{\n'
            'vg.和 = 0\nvg.积 = 1\nvg.名 = "abc"\nvg.大 = 1.5\nvg.根 = 0.0\nvg.表 = []\n'
            'rm.around(%d) {\n%s}\n'
            'vg.表长 = list.长度(表)\nvg.根2 = mt.sqrt(和 / 10.0)\n'
            'ns.show(和=$和 积=$积 大=$大 根=$根2 名=$名 表长=$表长)\n}STOP\n'
            % (body_iter, extra))


CASES = []


def case(tag, src, native=True, jit_args=('--jit',)):
    CASES.append((tag, src, native, list(jit_args)))


# ---- 1. 纯整数大循环：只调一次、内部循环很大 —— 本轮要堵的那个洞 ----
case('main_loop_int', hdr('loop_int') + heavy(BIG,
     '    vg.和 = 和 + at\n    vg.积 = 积 + 1\n    vg.大 = 大 + 0.5\n'))

# ---- 2. 标准库调用密集（Phase H 的收益面搬到主程序上）----
case('main_loop_lib', hdr('loop_lib') + heavy(BIG,
     '    vg.根 = mt.sqrt(和 / 1000.0)\n    vg.积 = mt.floor(和 / 3.0)\n'))

# ---- 3. 列表：主程序里建表并追加 ----
case('main_loop_list', hdr('loop_list') + (
    'GOING:{\nvg.和 = 0\nvg.表 = []\nvg.名 = "abc"\nvg.大 = 1.5\nvg.积 = 1\nvg.根 = 0.0\n'
    'rm.around(%d) {\n    list.添加(表, at)\n    vg.和 = 和 + at\n}\n'
    'vg.表长 = list.长度(表)\nvg.根 = mt.sqrt(和 / 10.0)\nvg.积 = mt.floor(和 / 3.0)\n'
    'ns.show(和=$和 积=$积 大=$大 根=$根 名=$名 表长=$表长)\n}STOP\n' % LISTN))

# ---- 4. 主程序调用户函数（直调 jit_<fni>）----
case('main_calls_fn', hdr('calls_fn') + (
    'func 方(x) {\n    ret x * x + 1\n}\n\n'
    'func 立方(x) {\n    ret 方(x) * x\n}\n\n'
    'GOING:{\nvg.和 = 0\nvg.名 = "abc"\nvg.大 = 1.5\nvg.根 = 0.0\nvg.积 = 1\nvg.表 = []\n'
    'rm.around(4000000) {\n    vg.和 = 和 + list.立方(at % 1000)\n}\n'
    'vg.表长 = list.长度(表)\nvg.根 = mt.sqrt(和 / 10.0)\nvg.积 = mt.floor(和 / 3.0)\n'
    'ns.show(和=$和 积=$积 大=$大 根=$根 名=$名 表长=$表长)\n}STOP\n'))

# ---- 5. 主程序调递归函数 ----
case('main_calls_rec', hdr('calls_rec') + (
    'func 阶乘(n) {\n'
    '    if(n <= 1) {\n'
    '        ret 1\n'
    '    }\n\n'
    '    ret n * list.阶乘(n - 1)\n'
    '}\n\n'
    'GOING:{\nvg.和 = 0\nvg.名 = "abc"\nvg.大 = 1.5\nvg.根 = 0.0\nvg.积 = 1\nvg.表 = []\n'
    'rm.around(3000000) {\n    vg.和 = 和 + list.阶乘(at % 12 + 1)\n}\n'
    'vg.表长 = list.长度(表)\nvg.根 = mt.sqrt(和 / 10.0)\nvg.积 = mt.floor(和 / 3.0)\n'
    'ns.show(和=$和 积=$积 大=$大 根=$根 名=$名 表长=$表长)\n}STOP\n'))

# ---- 6. 分支 / 比较 / 逻辑 ----
case('main_branch', hdr('branch') + (
    'GOING:{\nvg.和 = 0\nvg.名 = "abc"\nvg.大 = 1.5\nvg.根 = 0.0\nvg.积 = 1\nvg.表 = []\n'
    'rm.around(1000000) {\n'
    '    if(at % 3 == 0) {\n'
    '        vg.和 = 和 + at\n'
    '    } else {\n'
    '        if(at % 3 == 1) {\n'
    '            vg.和 = 和 - at\n'
    '        } else {\n'
    '            vg.和 = 和 + at * 2\n'
    '        }\n'
    '    }\n'
    '}\n'
    'vg.表长 = list.长度(表)\nvg.根 = mt.sqrt(和 / 10.0)\nvg.积 = mt.floor(和 / 3.0)\n'
    'ns.show(和=$和 积=$积 大=$大 根=$根 名=$名 表长=$表长)\n}STOP\n'))

# ---- 7. 字典 ----
case('main_dict', hdr('dict') + (
    'GOING:{\nvg.字 = {"甲": 1, "乙": 2}\nvg.和 = 0\nvg.名 = "abc"\nvg.大 = 1.5\n'
    'vg.根 = 0.0\nvg.积 = 1\nvg.表 = []\n'
    'rm.around(%d) {\n    vg.和 = 和 + at\n}\n'
    'vg.表长 = list.长度(表)\nvg.根 = mt.sqrt(和 / 10.0)\nvg.积 = mt.floor(和 / 3.0)\n'
    'ns.show(和=$和 积=$积 根=$根 字典=$字 名=$名 表长=$表长)\n}STOP\n' % DICTN))

# ---- 8. 错误路径：循环里就炸（fn 0 原生下的报错必须逐字一致）----
case('main_err_loop', hdr('err_loop') + (
    'GOING:{\nvg.和 = 0\nvg.零 = 0\nvg.名 = "abc"\nvg.大 = 1.5\nvg.根 = 0.0\n'
    'vg.积 = 1\nvg.表 = []\n'
    'rm.around(%d) {\n    vg.和 = 和 + at\n    vg.根 = 和 / 零\n}\n'
    'ns.show(和=$和)\n}STOP\n' % ERRN))

# ---- 9. 错误路径：主程序末尾炸 ----
case('main_err_tail', hdr('err_tail') + (
    'GOING:{\nvg.和 = 0\nvg.名 = "abc"\nvg.大 = 1.5\nvg.根 = 0.0\nvg.积 = 1\nvg.表 = []\n'
    'rm.around(%d) {\n    vg.和 = 和 + at\n}\n'
    'vg.表长 = list.长度(表)\nvg.根 = mt.sqrt(和 / 10.0)\nvg.积 = mt.floor(和 / 3.0)\n'
    'ns.show(和=$和 积=$积 根=$根 名=$名 表长=$表长)\n'
    'vg.坏 = 表[999999999]\nns.show(坏=$坏)\n}STOP\n' % ERRN))

# ---- 10. 文件头 device 旋钮（0x37 之前在发射器里是「不可编」，主程序带它就编不了）----
case('main_device', hdr('device', 'device cpu 2') + heavy(BIG,
     '    vg.和 = 和 + at\n    vg.积 = 积 + 1\n    vg.大 = 大 + 0.5\n'))

# ---- 11. 文件头 jit on：不传 --jit 也要上原生（预读旋钮那条路）----
case('main_hdr_on', hdr('hdr_on', 'device cpu 2', 'jit on 16') + heavy(BIG,
     '    vg.和 = 和 + at\n    vg.积 = 积 + 1\n    vg.大 = 大 + 0.5\n'),
     jit_args=[])

# ---- 12. 文件头 jit off：盖过 --jit，主程序必须留在解释器 ----
case('main_hdr_off', hdr('hdr_off', 'jit off') + heavy(BIG,
     '    vg.和 = 和 + at\n    vg.积 = 积 + 1\n    vg.大 = 大 + 0.5\n'), native=False)

# ---- 13. 门限负例：小程序不过门限，纯解释器，行为照旧 ----
case('main_tiny', hdr('tiny') + heavy(SMALL,
     '    vg.和 = 和 + at\n    vg.积 = 积 + 1\n    vg.大 = 大 + 0.5\n'), native=False)


def build(tag, src):
    p = os.path.join(OUT, 'jm_%s.pybk' % tag)
    open(p, 'w', encoding='utf-8').write(src)
    pybc = p[:-5] + '.pybc'
    r = subprocess.run([sys.executable, 'pybk_build.py', p, pybc],
                       capture_output=True, text=True, encoding='utf-8', errors='replace')
    if r.returncode != 0:
        return None, (r.stdout or '')[-600:] + (r.stderr or '')[-600:]
    return pybc, None


def run(args, pybc, verbose=False):
    env = dict(os.environ)
    env['PYTHONUTF8'] = '1'
    env['PYTHONIOENCODING'] = 'utf-8'
    env.pop('PYVM_JIT', None)
    if verbose:
        env['PYVM_JIT_VERBOSE'] = '1'
    else:
        env.pop('PYVM_JIT_VERBOSE', None)
    p = subprocess.run([EXE] + args + [pybc], capture_output=True, text=True,
                       encoding='utf-8', errors='replace', env=env, cwd=ROOT, timeout=900)
    return p.returncode, p.stdout, p.stderr


NATIVE_RE = re.compile(r'\[JIT\] fn 0 .*-> 原生')
COST_RE = re.compile(r'\[JIT\] 主程序预判：(.+)$', re.M)

print('%-18s %-4s %s' % ('用例', 'JIT', '判定'))
fails = []
for tag, src, want_native, jargs in CASES:
    pybc, err = build(tag, src)
    if pybc is None:
        print('%-18s %-4s 编译失败：%s' % (tag, '-', err[:160]))
        fails.append(tag + '(编译)')
        continue
    ri, oi, ei = run([], pybc)
    rj, oj, ej = run(jargs, pybc, verbose=True)
    # JIT 自己的日志不算行为差异
    ej_clean = '\n'.join(l for l in ej.split('\n') if not l.startswith('[JIT]'))
    same = (ri == rj) and (oi == oj) and (ei == ej_clean)
    # 「fn 0 -> 原生」只说明编出了指针，主程序未必真跑在原生上——它也可能是被
    # 热函数那条路顺带编出来的（此时主程序早已在解释器上跑了一半）。
    # 真正决定「整段走原生」的是 jit_entry 的预判结果，所以两个条件都要。
    m = COST_RE.search(ej)
    cost_line = m.group(0) if m else '（无预判日志）'
    gate = '未启用'
    if m:
        gate = '预编译' if '，预编译' in m.group(1) else '不预编译'
    got_native = (gate == '预编译') and bool(NATIVE_RE.search(ej))
    why = []
    if not same:
        why.append('输出不一致 rc %s/%s' % (ri, rj))
        if oi != oj:
            why.append('stdout: %r vs %r' % (oi[:80], oj[:80]))
        if ei != ej_clean:
            why.append('stderr: %r vs %r' % (ei[:120], ej_clean[:120]))
    if got_native != want_native:
        why.append('fn0 原生=%s（期望 %s）；%s' % (got_native, want_native, cost_line))
    mode = '开' if jargs else '头'
    if same and got_native == want_native:
        print('%-18s %-4s 一致  fn0原生=%-5s %s' % (tag, mode, got_native, cost_line))
    else:
        fails.append(tag)
        print('%-18s %-4s !! %s' % (tag, mode, '；'.join(why)))

print()
if fails:
    print('fn 0 回归：%d/%d 不通过 -> %s' % (len(fails), len(CASES), ', '.join(fails)))
    sys.exit(1)
print('fn 0 与解释器逐字一致：%d/%d' % (len(CASES), len(CASES)))
