# -*- coding: utf-8 -*-
"""tests/net_http_smoke.py — net/http 双后端端到端冒烟（独立于 run_tests.py）

为什么单列一个脚本：tests/cases.py 的每个用例是**一个进程跑一段 .pybk**，
而 HTTP 服务端四件套天生要"一个进程当服务端、另一个进程当客户端"。
这个脚本起本地回环服务，用真实客户端打真实请求，验的是 cases.py 结构上测不到的东西。

用法：python tests/net_http_smoke.py
覆盖：
  A. 服务端 —— pyvm.exe 跑自带 _http服务.pybk，Python 打 8 个请求（含 404 / POST /
     查询串 / 头回显），验退出码 0。**这一条是 P0 回归**：http.serve 的会话句柄
     曾经是 0 基槽号，判成功写 `会话 > 0` 会把每个进程的头号请求静默丢掉。
  B. 客户端 —— 起 Python HTTP 服务，pyvm.exe 带请求头打过来，验请求头真的到了、
     响应头读得到、404 不算错误、超时按 http.config 生效。
  C. 失败分类 —— DNS 解析不了 / 连不上，各自带 WinINet 错误码。
  D. onerror（C 后端）—— 传输层失败能被接住，接住后 code = -1、err 有内容。
全本地回环，不依赖外网。
"""
import os
import socket
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.stdout.reconfigure(encoding="utf-8")
os.chdir(ROOT)

fails = []


def check(ok, name, detail=""):
    print(("  [OK ] " if ok else "  [FAIL] ") + name + (("  " + detail) if detail else ""))
    if not ok:
        fails.append(name)


def compile_vm(src_name, tag):
    """源码 → .pybc，返回 .pybc 路径"""
    pybc = os.path.join("build_tmp", "probe", "smoke_%s.pybc" % tag)
    os.makedirs(os.path.dirname(pybc), exist_ok=True)
    r = subprocess.run([sys.executable, "pybk_build.py", src_name, pybc],
                       capture_output=True, text=True, encoding="utf-8", errors="replace")
    if r.returncode != 0:
        print("  编译失败：\n" + (r.stdout or "")[-2000:] + (r.stderr or "")[-2000:])
        return None
    return pybc


def free_port():
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    p = s.getsockname()[1]
    s.close()
    return p


# ───────────────────────── A. 服务端（自带示例，pyvm 后端）─────────────────────────
def part_a():
    print("A. HTTP 服务端 —— pyvm.exe 跑自带 _http服务.pybk")
    pybc = compile_vm("_http服务.pybk", "srv")
    if pybc is None:
        check(False, "A 编译 _http服务.pybk")
        return
    proc = subprocess.Popen(["pyvm.exe", pybc], stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT, text=True,
                            encoding="utf-8", errors="replace", cwd=ROOT)
    time.sleep(1.2)
    base = "http://127.0.0.1:8090"
    cases = [("GET", "/", None), ("GET", "/hi?name=zhuli&score=99", None),
             ("POST", "/api", None), ("GET", "/echo", None),
             ("GET", "/nope", None), ("GET", "/", None),
             ("GET", "/hi", None), ("GET", "/", None)]
    hit = 0
    for meth, path, _ in cases:
        try:
            req = urllib.request.Request(base + path, method=meth,
                                         data=b"" if meth == "POST" else None)
            with urllib.request.urlopen(req, timeout=6) as resp:
                body = resp.read().decode("utf-8", "replace")
                print("    [%d] %s %s -> %s %r" % (hit + 1, meth, path, resp.status, body[:56]))
                hit += 1
        except urllib.error.HTTPError as e:
            print("    [%d] %s %s -> %s %r" % (hit + 1, meth, path, e.code,
                                               e.read().decode("utf-8", "replace")[:56]))
            hit += 1
        except Exception as e:
            print("    [%d] %s %s -> EXC %s: %s" % (hit + 1, meth, path, type(e).__name__, e))
            break
    check(hit == 8, "A 八连请求全部应答", "%d/8" % hit)
    try:
        out, _ = proc.communicate(timeout=8)
    except subprocess.TimeoutExpired:
        proc.kill()
        out, _ = proc.communicate()
        print("    !! 服务未在超时内退出")
    print("    --- pyvm 输出 ---\n    " + out.strip().replace("\n", "\n    ")[:1200])
    check(proc.returncode == 0, "A 服务端自己退出码 0", "rc=%s" % proc.returncode)


# ───────────────────────── B/C. 客户端（pyvm 后端）─────────────────────────
def part_bc():
    print("B. HTTP 客户端 —— pyvm.exe 打本地服务")
    import http.server
    import socketserver

    class H(http.server.BaseHTTPRequestHandler):
        protocol_version = "HTTP/1.1"

        def log_message(self, *a):
            pass

        def _go(self):
            if self.path.startswith("/echo"):
                body = ("AGENT=%s|KEY=%s|AUTH=%s" % (
                    self.headers.get("User-Agent"),
                    self.headers.get("X-Api-Key"),
                    self.headers.get("Authorization"))).encode()
                self.send_response(200)
                self.send_header("Content-Type", "text/plain; charset=utf-8")
                self.send_header("X-Custom-Probe", "probe-ABC123")
                self.send_header("Set-Cookie", "sid=42; Path=/")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
            elif self.path.startswith("/post"):
                n = int(self.headers.get("Content-Length") or 0)
                got = self.rfile.read(n).decode("utf-8", "replace")
                body = ("METHOD=%s|CT=%s|BODY=%s" % (
                    self.command, self.headers.get("Content-Type"), got)).encode()
                self.send_response(200)
                self.send_header("Content-Type", "text/plain; charset=utf-8")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
            elif self.path.startswith("/hang"):
                time.sleep(30)                        # 黑洞：触发超时
                self.send_response(200)
                self.send_header("Content-Length", "0")
                self.end_headers()
            else:
                body = b"NOPE"
                self.send_response(404)
                self.send_header("Content-Type", "text/plain")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

        do_GET = _go
        do_POST = _go

    srv = socketserver.ThreadingTCPServer(("127.0.0.1", 0), H)
    srv.daemon_threads = True
    port = srv.server_address[1]
    threading.Thread(target=srv.serve_forever, daemon=True).start()

    src = os.path.join("build_tmp", "probe", "smoke_cli.pybk")
    open(src, "w", encoding="utf-8").write('''@ 探针>http客户端>1
GOING:{
http.config({"超时": 3, "Agent": "PYbook-Smoke/1.0", "头": {"X-Api-Key": "k123", "Authorization": "Bearer tok"}})
vg.体 = http.get("http://127.0.0.1:%d/echo")
ns.show("请求头到了:", 体)
ns.show("状态:", http.code())
ns.show("响应头 Content-Type:", http.header("Content-Type"))
ns.show("小写头名也查得到:", http.header("x-custom-probe"))
ns.show("没有的头:", "[", http.header("X-Nope"), "]")
ns.show("err:", "[", http.err(), "]")
vg.四零四 = http.get("http://127.0.0.1:%d/nope")
ns.show("404 长度:", 长度(四零四), " 状态:", http.code(), " err:", "[", http.err(), "]")
vg.回 = http.post("http://127.0.0.1:%d/post", "{\\"k\\":1}", "application/json")
ns.show("POST 回显:", 回)
ns.show("POST 状态:", http.code())
vg.默认型 = http.post("http://127.0.0.1:%d/post", "裸体", "")
ns.show("POST 缺省类型回显:", 默认型)
}STOP
''' % (port, port, port, port))
    pybc = compile_vm(src, "cli")
    if pybc is None:
        check(False, "B 编译客户端探针")
        srv.shutdown()
        return
    t0 = time.time()
    p = subprocess.run(["pyvm.exe", pybc], capture_output=True, text=True,
                       encoding="utf-8", errors="replace", cwd=ROOT, timeout=90)
    out = p.stdout.strip()
    print("    --- pyvm 输出（%.1fs，rc=%d）---" % (time.time() - t0, p.returncode))
    print("    " + out.replace("\n", "\n    "))
    check("AGENT=PYbook-Smoke/1.0|KEY=k123|AUTH=Bearer tok" in out, "B 请求头真的发到了服务端")
    check("状态: 200" in out, "B 200 状态码")
    check("text/plain; charset=utf-8" in out, "B 读得到 Content-Type")
    check("probe-ABC123" in out, "B 响应头大小写不敏感")
    check("404 长度: 4  状态: 404" in out, "B 404 不是错误、正文照给")

    print("C. 超时按 http.config 生效（不该挂死）")
    src2 = os.path.join("build_tmp", "probe", "smoke_hang.pybk")
    open(src2, "w", encoding="utf-8").write('''@ 探针>http超时>1
GOING:{
http.config({"超时": 2})
vg.页 = http.get("http://127.0.0.1:%d/hang")
ns.show("不该走到这里")
}STOP
''' % port)
    pybc2 = compile_vm(src2, "hang")
    t0 = time.time()
    p2 = subprocess.run(["pyvm.exe", pybc2], capture_output=True, text=True,
                        encoding="utf-8", errors="replace", cwd=ROOT, timeout=90)
    dt = time.time() - t0
    print("    耗时 %.1fs  stderr: %s" % (dt, p2.stderr.strip()[:220]))
    check(p2.returncode != 0 and "超时" in p2.stderr, "C 黑洞地址超时退出而不是挂死", "%.1fs" % dt)
    check(dt < 20, "C 超时在合理时间内生效", "%.1fs" % dt)

    print("D. 失败分类（C 后端，onerror 接住）")
    src3 = os.path.join("build_tmp", "probe", "smoke_fail.pybk")
    open(src3, "w", encoding="utf-8").write('''@ 探针>http失败>1
GOING:{
onerror 抓 {
    ns.show("接住了:", 抓)
    ns.show("接住后 code =", http.code())
    ns.show("接住后 err =", http.err())
}
vg.页 = http.get("http://127.0.0.1:1/x")
ns.show("不该走到这里")
}STOP
''')
    p3 = subprocess.run([sys.executable, "-B", "pybk_main.py", src3],
                        capture_output=True, text=True, encoding="utf-8",
                        errors="replace", cwd=ROOT, timeout=90)
    out3 = p3.stdout.strip() + p3.stderr.strip()
    print("    " + out3.replace("\n", "\n    ")[:700])
    check("接住了" in out3 and "接住后 code = -1" in out3, "D onerror 接住失败且 code = -1")
    check("连接打不开" in out3 or "12029" in out3, "D 失败原因说清是连不上而非 404")
    srv.shutdown()


if __name__ == "__main__":
    os.makedirs(os.path.join(ROOT, "build_tmp", "probe"), exist_ok=True)
    part_a()
    print()
    part_bc()
    print()
    if fails:
        print("失败 %d 项：%s" % (len(fails), ", ".join(fails)))
        sys.exit(1)
    print("net/http 冒烟全过")
