# Course state: PYbook 语言 + 3D_highway 标准库
**Mode:** 自学（AI 掌握，非教学）
**Learner:** MiMo agent
**Source:** PYBOOK_AI.md / pybook_hw3d.c / pybk_front.py / pybk_code.py / 示例 .pybk

## Status
- [x] 语言骨架与硬规则 — 已掌握
- [x] 3D_highway 全 API（图元/相机/光照/阴影/后处理/着色器/输入/HUD）
- [x] 相关标准库：mt / rd / list / rm / mp
- [x] 循环语义陷阱（rm.aging.while = until）— 实测确认
- [x] 读透示例（3D演示 / 爆炸模拟器 / 3deditor / probe_shadow）
- [x] 自写验证程序 `自学验证.pybk` --check 通过

## 产出
- `自我掌握笔记.md` — 内化知识库
- `自学验证.pybk` — 综合 API 验收程序
- `_until_probe.pybk` — until 语义实证（输出 5）

## Concept table
| Concept | Status | Evidence | Next review |
|---|---|---|---|
| 文件骨架 @/GOING/STOP / ON 3D_highway | mastered | 笔记 + 验证程序 | |
| vg. 声明 / 函数读不到全局 / 调用需赋值 | mastered | 笔记 + 语法通过 | |
| rm.aging.while = until | mastered | 实测输出 5 | |
| hw 坐标系 + camera yaw/pitch | mastered | 源码注释 + 示例 | |
| box 9/12 参 / sphere 中心 / cyl | mastered | rt_hw_boxn/cylv | |
| fog/far/near/fov/ortho | mastered | 源码 + CHANGELOG | |
| push/pop 层级 / light / shadow / post | mastered | 爆炸模拟器 + 源码 | |
| tex/shader/preset/uni | mastered | CHANGELOG + 映射表 | |
| 输入 grab/mdx/key/hit + HUD text/rect | mastered | 示例 | |

## Review queue
- （空，已自洽）

## Error log
- 无（自学验证一次通过）
