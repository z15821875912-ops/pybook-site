# net 网络模块（TCP 行协议）交付与验收说明

## 交付物
- `pybook_net.c`（新建）：rt_net_listen / rt_net_accept / rt_net_connect /
  rt_net_read（非阻塞 recv）/ rt_net_read_block（阻塞 readline）/
  rt_net_write（send，原样字节）/ rt_net_close
- `pybook_lib.h`（追加）：net 七函数声明（与音模块同款风格）
- `pybk_front.py`（三处注册）：KEYWORDS += 'net'；LIB_PREFIXES += 'net'；
  LIB_CALLS += listen/accept/connect/recv/readline/send/close 七条
- `pybk_code.py`：LIB_C_NAMES 七条映射（net.recv→rt_net_read、
  net.readline→rt_net_read_block、net.send→rt_net_write）；运行时源列表
  加 pybook_net.c；链接加 -lws2_32
- 备份：`pybk_front.py.bak`（动手前快照，红线要求的 .bak）

## 实现要点（对照任务要求）
1. 独立文件 pybook_net.c，未触碰 pybook_rt.c；gcc 源列表加 pybook_net.c、
   链接加 -lws2_32。
2. **每句柄接收缓冲**：句柄表是 `{SOCKET sock; char buf[65536]; size_t len}`
   数组（上限 64 句柄），recv 进缓冲、按 \n 切行、半行留在缓冲；
   非阻塞模式（ioctlsocket FIONBIO）。
3. WSAStartup 惰性初始化（首次调 net.* 时），`atexit(WSACleanup)`。
4. UTF-8：收发字节原样进出字符串盒；连接地址经 MultiByteToWideChar 转
   UTF-16 后 GetAddrInfoW 解析（支持域名）。
5. 阻塞函数（accept/readline）= 非阻塞调用 + Sleep(1) 循环，无线程。
6. 语言层 `net.send` 的"自动补 \n"在 codegen 层完成：
   `rt_net_write(句, rt_add(文本, rt_str("\n")))`——rt_net_write 本身发原样
   字节，这让 C 层自测可以构造真正的半包场景。

## 验收输出（全部实测）

### 1. 双进程探针（整行协议）
服务端 `__net_srv.pybk`（listen 7777 → accept → readline → 回发 → close）：
```
收到 hello server
```
客户端 `__net_cli.pybk`（connect → send → readline → close）：
```
回 hello client
```
两进程各自独立编译、独立运行，退出码均 0。

### 2. 非阻塞验证（服务端实测输出）
```
100次recv耗时毫秒=0
非阻塞验证通过
对端关闭后=断
```
连接后客户端不发数据，服务端 net.recv 循环 100 次全部返回空串、
tm.now() 差值 0ms（< 200ms，证明未阻塞）；客户端关闭后服务端
net.recv 返回 "断"。

### 3. 半包验证（C 层自测，-DNET_SELF_TEST）
```
net 自测：通过 106 项，失败 0 项
```
覆盖：非阻塞 100 次 recv 全空且耗时 <200ms；客户端先发 "abc"（无 \n，
经 rt_net_write 原样字节）服务端不上交半行；隔 30ms 再发 "def\n" 后
net.recv 收到完整一行 "abcdef"；阻塞 readline 整行；对端 close 后返回 "断"。

说明：语言层 net.send 按规格"自动补 \n"（codegen 层实现），PYbook 源码
无法表达不带换行的裸发送，因此半包场景在 C 层自测中驱动（语义与语言层
完全一致：同一条 rt_net_write 路径 + 同一个每句柄接收缓冲）。

### 4. 回归
- `python pybk_front.py`：自测全过（分支链/when/$插值/裸 ret/web/lb 类/
  帧动画/go/key/模块引用 均正确，错误带行号）。
- `python pybk_main.py games/飞船大战.pybk`：正常启动运行，ESC 退出码 0。
- `python tests/run_tests.py`：**96/96 全过**（gcc 链接新增 pybook_net.c +
  -lws2_32 后无任何回归；pybook_net.o 走既有 rt_cache 缓存机制）。

## Windows 防火墙
首次 net.listen 时 Windows 防火墙可能弹"是否允许访问网络"提示，点允许即可；
仅监听 127.0.0.1 回环时实际不经防火墙，弹窗属系统正常行为。

## 已知边界
- 句柄上限 64 个（句柄表容量）；单行上限 64KB（接收缓冲容量，溢出报错退出）。
- net.recv 对端关闭但缓冲里还有无换行的残余字节时，会把残余作为最后一行
  返回，之后才返回 "断"（半行数据不丢）。
- net.listen 端口需 INT；地址/内容需字符串（类型错误带原因退出）。
- **仅 Windows**：非 Windows 构建里 net/http 全族是报错的桩（`_vm_lib_calls.inc`
  要这 18 个符号才能链接），绝不静默返回空。
- `net.send` 的"自动补 \n"在 codegen 层，语言层表达不了裸字节发送 → **写不了
  二进制协议 / 自定义分帧**，只能做行协议。
- `net.accept` / `net.readline` 是 `Sleep(1)` 忙等（无线程、无 select），CPU 空转。
- `onerror` / `try` 只有 C 后端支持（VM 后端错误链没有跳转目标，编译期拒绝），
  所以 HTTP 传输层失败在 VM 侧只能靠 `http.err()` 显式判。

---

# 2026-10 网络升级（第二轮）

## 修掉的缺陷

### P0：HTTP 服务端头号请求被静默丢弃
`rt_http_serve` 返回的是 `g_sess[]` 的 **0 基**槽号，而文档和自带示例
`_http服务.pybk` 都按 `if(会话 > 0)` 判成功 —— 槽 0 是完全合法的会话，却会被
这个判断当成失败。后果：**每个进程的第一个请求必然被静默丢掉**（TCP 握手在
backlog 里完成，客户端一直等到超时；示例则永远转圈不出）。
实测 A/B（同一探针，只改判断式）：

| 条件 | 会话值 | 客户端收到 | 程序输出 |
|---|---|---|---|
| `会话 > 0`（修复前） | 0 | `ConnectionReset` | 走了 else 分支 |
| `会话 >= 0` | 0 | `HTTP/1.1 200 OK ... pong` | 路径 = /probe |

**修法**：会话句柄对外改成 **1 基**（`serve` 返回 `sh + 1`，`http_sess` 校验时
`h-1`），保持文档承诺的「> 0 即成功」不变，改动不外溢到示例和文档。
修复后 `会话 = 1`，两种写法都拿到 200。

### P0：`net_die` 绕过了项目的错误链
`net_die` 自己 `fprintf + exit(1)`，而项目有一套 `try` / `onerror` 的长跳转
错误链（`pybook_rt.c` 的 `g_err_top` / `rt_err_raise`）。只有 `rt_die` 才会被
它们接住 —— 也就是说端口被占用这类运行期状况在 net/http 里**一点补救余地都没有**。
**修法**：`net_die` 改走 `rt_die`。

### P1：`http.get` 所有失败一律返回 `""`
DNS 解析不了 / 连不上 / 超时 / TLS 失败 / 404 —— 五种完全不同的结果返回同一个
空串，`http.code()` 一律 0。爬虫会把空页面当正常结果存盘（`_爬虫迷你.pybk`
就是这个写法）。**修法**：分两类
- **HTTP 层**（404/500…）不是错：正文照给，`http.code()` 是真状态码
- **传输层失败**报错（`onerror` 可接住），`http.code()` = `-1`，原因留在 `http.err()`

### P1：写不了 API 客户端
原来走 `InternetOpenUrlA` —— 既不能带自定义请求头，也不能逐段设超时。
**修法**：换成 `InternetOpenA → InternetConnectA → HttpOpenRequestA →
HttpSendRequestA`，新增 `http.config`（`超时`/`Agent`/`头`）、`http.header`、
`http.headers`、`http.err`。

### P1：没有超时
`InternetOpenUrlA` 不设超时，黑洞连接会永久挂死 —— 挂死和"慢"长得一模一样。
**修法**：连接 / 发送 / 接收三段各设一份（默认 15 秒，`http.config` 可改）。

### 顺带
- `rt_http_post` 在 `_vm_lib_calls.inc` 里**漏了函数原型**，靠隐式声明蒙混过关。
- `safe.get` / `safe.at` 实现了也链进了 `pyvm.exe`，但不在 VM 库表里 → VM 运行时报
  「标准库 safe.get 在 VM 模式下不可用」。自带示例 `_http服务.pybk` 正用它，所以
  那个示例在 VM 后端跑不起来。已补进库表。
- 头文件里 `HttpQueryInfoA(HTTP_QUERY_RAW_HEADERS_CRLF, NULL, &n, NULL)` 这一趟
  按文档返回 **FALSE + ERROR_INSUFFICIENT_BUFFER(122)** 但长度照样填好了 ——
  当成失败就 return，响应头会永远读不出来。
- 头名比较必须是**前缀**比：拿整行去和头名做全串比较，碰到 `:` 必然不等。
- `pybook_net.c` 头部写的自测命令漏了 `pybook_gpu.c`（`pybook_rt.c` 的 gpu 包装要
  调它的 `gpu_probe`），照抄会 undefined reference。

## 验收输出（全部实测）

### 1. HTTP 服务端八连请求（`pyvm.exe` 跑自带 `_http服务.pybk`）
```
[1] GET /       -> 200 '<h1>PYbook HTTP 服务器</h1><p>四件套在跑</p>'
[2] GET /hi?name=zhuli&score=99 -> 200 '你好 zhuli，分数 99'
[3] POST /api   -> 200 '{"引擎":"PYbook","方法":"POST"}'
[4] GET /echo   -> 200 '回声(0)：'
[5] GET /nope   -> 404 '没有 /nope'
[6] GET /       -> 200 ...
[7] GET /hi     -> 200 '你好 ?，分数 ?'
[8] GET /       -> 200 ...
--- 退出码 0 ---   SMOKE PASS
```
（修复前第 1 个请求就 RST、服务永不退出。）

### 2. 客户端请求头 / 响应头（VM 后端，Python 起本地服务）
```
[1] 服务端看到的请求头 = AGENT=PYbook-Probe/9.9|KEY=abc123|AUTH=Bearer tok|PATH=/echo
[2] 状态 = 200
[3] Content-Type = text/plain; charset=utf-8
[4] 小写头名查得到吗 = probe-ABC123          ← 头名大小写不敏感
[5] 没有的头 = [  ]
[6] err = [  ]
[7] 头表键 = [server, date, content-type, x-custom-probe, set-cookie, content-length]
[8] set-cookie = sid=42; Path=/
[9] 404: 正文长度 = 4  状态 = 404  err = [  ]   ← 404 不是错误
```

### 3. 失败分类（C 后端）
```
DNS 解析不了  → 运行时错误: 第 9 行: 请求发不出去：域名解析不了（DNS 查不到这个主机，或网络断了）（WinINet 12007）（网址 ...）
                 onerror 接住了 → 接住后 code = -1  err = [ 请求发不出去：域名解析不了 ... ]
连接打不开    → 运行时错误: 第 4 行: 请求发不出去：连接打不开（对方没在监听，或被防火墙挡了）（WinINet 12029）（网址 http://127.0.0.1:1/x）
超时          → 运行时错误: 请求发不出去：超时（对方没在时限内应答）（WinINet 12002）（网址 .../hang）
                 按 http.config({"超时": 2}) 生效，不再永久挂死
```

### 4. C 层自测
```
net 自测：通过 106 项，失败 0 项
gcc -O2 -DNET_SELF_TEST pybook_net.c pybook_rt.c pybook_gpu.c -o net_test.exe -lws2_32 -lwininet -I.
```

### 5. 非 Windows 桩路径
抽出 `#else` 段单独编译：18 个桩函数 **0 error**。

### 6. 语言层回归（`tests/cases.py` 新增 T24 组，8 例）
`T24_http_state_initial_ok` / `T24_get_arity_err` / `T24_config_notdict_err` /
`T24_config_unknown_key_err` / `T24_config_bad_timeout_err` /
`T24_config_bad_headers_err` / `T24_header_arg_err` / `T24_conn_refused_err`
—— 全部 8/8 通过，纯回环无外网依赖。
