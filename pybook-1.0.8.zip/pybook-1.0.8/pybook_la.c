/* pybook_la.c — 线性代数核心层（纯 double*，可独立编译）
 *
 * 刻意不碰 PYbook 运行时：不 include pybook_rt.h、不用 Value、不 printf、不 exit。
 * 这样 _lacheck.c 能单独把本文件编进去，对着 NumPy 逐项对拍；数值错了在接进语言
 * 之前就能发现，而不是变成「某个 .pybk 程序结果不对」这种难查的现象。
 * 绑定层放在文件末尾，用 LA_RT_BINDING 包起来，与 mathplus.c 的 MP_RT_BINDING 同构。
 */

#if defined(LA_RT_BINDING) || defined(PYBOOK_RT_H)
#include "pybook_rt.h"   /* 绑定层需要 Value / rt_*：必须在 pybook_la.h 之前 */
#endif

#include "pybook_la.h"
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <float.h>

#define LA_EPS DBL_EPSILON

/* =============================================================================
 * LU（部分主元 Doolittle）
 * ========================================================================== */

int la_lu(const double *a, double *lu, int *piv, int n)
{
    int k, i, j, singular = 0;
    memcpy(lu, a, (size_t)n * (size_t)n * sizeof(double));
    for (k = 0; k < n; k++) {
        int    p    = k;
        double best = fabs(lu[(size_t)k * n + k]);
        for (i = k + 1; i < n; i++) {
            double v = fabs(lu[(size_t)i * n + k]);
            if (v > best) { best = v; p = i; }
        }
        piv[k] = p;
        if (p != k) {
            for (j = 0; j < n; j++) {
                double t = lu[(size_t)k * n + j];
                lu[(size_t)k * n + j] = lu[(size_t)p * n + j];
                lu[(size_t)p * n + j] = t;
            }
        }
        {
            double pk = lu[(size_t)k * n + k];
            /* 奇异时不提前 return：因子矩阵与 piv 必须填满，否则调用方没法算秩。
             * 把这一列的乘子置 0，等价于「这一列已经消完了」。 */
            if (pk == 0.0) {
                singular = 1;
                for (i = k + 1; i < n; i++) lu[(size_t)i * n + k] = 0.0;
                continue;
            }
            for (i = k + 1; i < n; i++) {
                double f = lu[(size_t)i * n + k] / pk;
                lu[(size_t)i * n + k] = f;
                for (j = k + 1; j < n; j++)
                    lu[(size_t)i * n + j] -= f * lu[(size_t)k * n + j];
            }
        }
    }
    return !singular;
}

double la_lu_det(const double *lu, const int *piv, int n)
{
    double det = 1.0;
    int    k, sign = 1;
    for (k = 0; k < n; k++) {
        if (piv[k] != k) sign = -sign;
        det *= lu[(size_t)k * n + k];
    }
    return sign * det;
}

int la_lu_solve(const double *lu, const int *piv, double *b, int n, int nrhs)
{
    int i, j, k;
    /* 置换必须按 k 升序逐步应用（LAPACK ipiv 语义）。顺序反了结果全错，
     * 而且不会报错 —— 这个坑踩过一次。 */
    for (k = 0; k < n; k++) {
        int p = piv[k];
        if (p != k) {
            for (j = 0; j < nrhs; j++) {
                double t = b[(size_t)k * nrhs + j];
                b[(size_t)k * nrhs + j] = b[(size_t)p * nrhs + j];
                b[(size_t)p * nrhs + j] = t;
            }
        }
    }
    /* b 是 n*nrhs 行主序：第 j 个右端是 b[0*nrhs+j .. (n-1)*nrhs+j]，**步长是 nrhs 不是 1**。
     * 早先图省事写成 double *col = b + j 然后 col[i]，nrhs=1 时碰巧是对的，
     * 于是 solve 单右端一路绿灯，只有 inv（nrhs=n）炸成 8e6。 */
    for (j = 0; j < nrhs; j++) {
        for (i = 1; i < n; i++) {
            double s = b[(size_t)i * nrhs + j];
            for (k = 0; k < i; k++) s -= lu[(size_t)i * n + k] * b[(size_t)k * nrhs + j];
            b[(size_t)i * nrhs + j] = s;
        }
        for (i = n - 1; i >= 0; i--) {
            double s = b[(size_t)i * nrhs + j];
            for (k = i + 1; k < n; k++) s -= lu[(size_t)i * n + k] * b[(size_t)k * nrhs + j];
            b[(size_t)i * nrhs + j] = s / lu[(size_t)i * n + i];
        }
    }
    return 1;
}

int la_lu_inv(const double *lu, const int *piv, double *out, int n)
{
    int i, j;
    for (i = 0; i < n; i++)
        for (j = 0; j < n; j++)
            out[(size_t)i * n + j] = (i == j) ? 1.0 : 0.0;
    return la_lu_solve(lu, piv, out, n, n);
}

/* =============================================================================
 * QR（Householder）
 * ========================================================================== */

int la_qr(const double *a, double *r, double *v, double *tau, int m, int n)
{
    int k, i, j, p = (m < n) ? m : n;
    memcpy(r, a, (size_t)m * (size_t)n * sizeof(double));
    for (k = 0; k < p; k++) {
        double normx = 0.0, alpha, vn = 0.0, x0;
        for (i = k; i < m; i++) {
            double t = r[(size_t)i * n + k];
            normx += t * t;
        }
        normx = sqrt(normx);
        if (normx == 0.0) {          /* 这一列已在 e_k 方向，反射退化为恒等 */
            tau[k] = 0.0;
            for (i = k; i < m; i++) v[(size_t)i * p + k] = 0.0;
            continue;
        }
        /* alpha 与 x0 反号：避免 v[0] = x0 - alpha 发生灾难性抵消 */
        x0    = r[(size_t)k * n + k];
        alpha = (x0 >= 0.0) ? -normx : normx;
        for (i = k; i < m; i++) {
            double t = r[(size_t)i * n + k];
            if (i == k) t -= alpha;
            v[(size_t)i * p + k] = t;
            vn += t * t;
        }
        vn = sqrt(vn);
        if (vn == 0.0) { tau[k] = 0.0; continue; }
        for (i = k; i < m; i++) v[(size_t)i * p + k] /= vn;
        tau[k] = 2.0;

        /* H = I - 2 v v^T，只作用在第 k..m-1 行 */
        for (j = k; j < n; j++) {
            double s = 0.0;
            for (i = k; i < m; i++) s += v[(size_t)i * p + k] * r[(size_t)i * n + j];
            s *= 2.0;
            for (i = k; i < m; i++) r[(size_t)i * n + j] -= s * v[(size_t)i * p + k];
        }
        r[(size_t)k * n + k] = alpha;
        for (i = k + 1; i < m; i++) r[(size_t)i * n + k] = 0.0;
    }
    return p;
}

void la_qr_form_q(const double *v, const double *tau, double *q, int m, int p)
{
    int k, i, j;
    /* Q = H_0 H_1 ... H_{p-1}。
     * 这里用的是**左乘**（Q = H_k · Q），所以 k 必须**倒着**来：k 倒序左乘一圈，
     * 最后才得到 H_0·H_1·...·H_{p-1}。k 升序左乘得到的是反过来那个 H_{p-1}···H_0，
     * 与 R 对不上 —— 症状是 Q 的第 0 行少乘了最后一个反射，Q 看着还挺正交，
     * 但 A = QR 只在第 0 列成立。 */
    for (k = p - 1; k >= 0; k--) {
        if (tau[k] == 0.0) continue;
        for (j = k; j < m; j++) {
            double s = 0.0;
            for (i = k; i < m; i++) s += v[(size_t)i * p + k] * q[(size_t)i * m + j];
            s *= tau[k];
            for (i = k; i < m; i++) q[(size_t)i * m + j] -= s * v[(size_t)i * p + k];
        }
    }
}

/* =============================================================================
 * Cholesky
 * ========================================================================== */

int la_cholesky(const double *a, double *l, int n)
{
    int i, j, k;
    /* 逐元素查对称性。给非对称阵还指望它跑，那是在制造一个看着正常的错数。 */
    for (i = 0; i < n; i++)
        for (j = i + 1; j < n; j++) {
            double d = fabs(a[(size_t)i * n + j] - a[(size_t)j * n + i]);
            double s = fabs(a[(size_t)i * n + j]) + fabs(a[(size_t)j * n + i]) + 1.0;
            if (d > 1e-12 * s) return 0;
        }
    memset(l, 0, (size_t)n * (size_t)n * sizeof(double));
    for (i = 0; i < n; i++) {
        for (j = 0; j <= i; j++) {
            double s = a[(size_t)i * n + j];
            for (k = 0; k < j; k++) s -= l[(size_t)i * n + k] * l[(size_t)j * n + k];
            if (i == j) {
                if (s <= 0.0) return 0;       /* 不是正定 */
                l[(size_t)i * n + i] = sqrt(s);
            } else {
                l[(size_t)i * n + j] = s / l[(size_t)j * n + j];
            }
        }
    }
    return 1;
}

/* =============================================================================
 * 对称矩阵特征值/特征向量（循环 Jacobi）
 * ========================================================================== */

/* 对称 Jacobi 旋转的 t = sign(τ)/(|τ|+√(1+τ²))，|t| ≤ 1（Numerical Recipes 的约定）。
 * τ 很大时 τ*τ 会溢出到 inf，所以分两段算。 */
static double jacobi_t_sym(double tau)
{
    double a = fabs(tau);
    if (a > 1e15) return 0.5 / tau;
    return (tau >= 0.0 ? 1.0 : -1.0) / (a + sqrt(1.0 + tau * tau));
}

/* 单边 SVD 用的 t。与上面**差一个符号**，不是笔误：
 *   要让 W 的 p、q 两列正交，得 (c²-s²)γ + cs(β-α) = 0，
 *   代入 c=1/√(1+t²)、s=t·c 整理成 t² - 2ζt - 1 = 0（ζ=(β-α)/(2γ)），
 *   取模最小的根 t = -sign(ζ)/(|ζ|+√(1+ζ²))。
 *   拿对称那一路的 t 直接用会得到反号的根，于是每一轮都在两个错位之间来回，
 *   单看「A = U·S·Vᵀ」还成立（那是构造保证的），只有正交性会露馅。 */
static double jacobi_t_svd(double zeta)
{
    return -jacobi_t_sym(zeta);
}

int la_eig_sym(const double *a, double *vals, double *vecs, int n, int maxsweeps)
{
    int    i, j, k, p, q, sweep, idx;
    double *b, offmax, diagmax, nrm;
    for (i = 0; i < n; i++)
        for (j = i + 1; j < n; j++) {
            double d = fabs(a[(size_t)i * n + j] - a[(size_t)j * n + i]);
            double s = fabs(a[(size_t)i * n + j]) + fabs(a[(size_t)j * n + i]) + 1.0;
            if (d > 1e-12 * s) return 0;
        }
    if (n == 0) return 1;
    b = (double *)malloc((size_t)n * (size_t)n * sizeof(double));
    if (!b) return 0;
    memcpy(b, a, (size_t)n * (size_t)n * sizeof(double));
    for (i = 0; i < n; i++)
        for (j = 0; j < n; j++) vecs[(size_t)i * n + j] = (i == j) ? 1.0 : 0.0;

    for (sweep = 0; sweep < maxsweeps; sweep++) {
        offmax = 0.0; diagmax = 0.0;
        for (i = 0; i < n; i++) {
            double d = fabs(b[(size_t)i * n + i]);
            if (d > diagmax) diagmax = d;
            for (j = i + 1; j < n; j++) {
                double v = fabs(b[(size_t)i * n + j]);
                if (v > offmax) offmax = v;
            }
        }
        nrm = sqrt(2.0 * offmax * offmax + diagmax * diagmax);
        if (offmax <= 1e-16 * nrm) break;
        for (p = 0; p < n - 1; p++) {
            for (q = p + 1; q < n; q++) {
                double apq, app, aqq, tau, t, c, s;
                apq = b[(size_t)p * n + q];
                if (apq == 0.0) continue;
                app = b[(size_t)p * n + p];
                aqq = b[(size_t)q * n + q];
                tau = (aqq - app) / (2.0 * apq);
                t   = jacobi_t_sym(tau);
                c   = 1.0 / sqrt(1.0 + t * t);
                s   = t * c;
                for (k = 0; k < n; k++) {
                    double bkp, bkq;
                    if (k == p || k == q) continue;
                    bkp = b[(size_t)k * n + p];
                    bkq = b[(size_t)k * n + q];
                    b[(size_t)k * n + p] = c * bkp - s * bkq;
                    b[(size_t)p * n + k] = b[(size_t)k * n + p];
                    b[(size_t)k * n + q] = s * bkp + c * bkq;
                    b[(size_t)q * n + k] = b[(size_t)k * n + q];
                }
                b[(size_t)p * n + p] = c * c * app - 2.0 * s * c * apq + s * s * aqq;
                b[(size_t)q * n + q] = s * s * app + 2.0 * s * c * apq + c * c * aqq;
                b[(size_t)p * n + q] = 0.0;
                b[(size_t)q * n + p] = 0.0;
                for (k = 0; k < n; k++) {          /* 累积特征向量 */
                    double vkp = vecs[(size_t)k * n + p];
                    double vkq = vecs[(size_t)k * n + q];
                    vecs[(size_t)k * n + p] = c * vkp - s * vkq;
                    vecs[(size_t)k * n + q] = s * vkp + c * vkq;
                }
            }
        }
    }
    for (i = 0; i < n; i++) vals[i] = b[(size_t)i * n + i];
    free(b);

    /* 升序排（n 本来就不大，插入排序比快排更好读也没差多少） */
    for (i = 1; i < n; i++) {
        double v = vals[i];
        idx = i - 1;
        while (idx >= 0 && vals[idx] > v) {
            vals[idx + 1] = vals[idx];
            for (k = 0; k < n; k++) {
                double t = vecs[(size_t)k * n + idx];
                vecs[(size_t)k * n + idx] = vecs[(size_t)k * n + idx + 1];
                vecs[(size_t)k * n + idx + 1] = t;
            }
            idx--;
        }
        vals[idx + 1] = v;
    }
    return 1;
}

/* =============================================================================
 * 奇异值分解（单边 Jacobi）
 * ========================================================================== */

/* 直接对 W(m*n) 的列做正交化，V 同步累积。收敛后 W 的列范数就是奇异值。
 * 精度比「先算 A^T A 再求特征值」高得多 —— 后者会把条件数平方掉。 */
static void svd_one_side(double *w, double *v, int m, int n, int maxsweeps)
{
    int sweep, p, q, i;
    for (sweep = 0; sweep < maxsweeps; sweep++) {
        double off = 0.0;
        for (p = 0; p < n - 1; p++) {
            for (q = p + 1; q < n; q++) {
                double alpha = 0.0, beta = 0.0, gamma = 0.0, zeta, t, c, s, rho;
                for (i = 0; i < m; i++) {
                    double a = w[(size_t)i * n + p], b = w[(size_t)i * n + q];
                    alpha += a * a; beta += b * b; gamma += a * b;
                }
                if (alpha <= 0.0 || beta <= 0.0) continue;
                rho = gamma / sqrt(alpha * beta);        /* 归一化夹角余弦，与尺度无关 */
                if (rho * rho <= LA_EPS * LA_EPS) continue;
                off += rho * rho;
                zeta = (beta - alpha) / (2.0 * gamma);
                t    = jacobi_t_svd(zeta);
                c    = 1.0 / sqrt(1.0 + t * t);
                s    = t * c;
                for (i = 0; i < m; i++) {                 /* W 列 */
                    double a = w[(size_t)i * n + p], b = w[(size_t)i * n + q];
                    w[(size_t)i * n + p] = c * a + s * b;
                    w[(size_t)i * n + q] = c * b - s * a;
                }
                for (i = 0; i < n; i++) {                 /* V 列 */
                    double a = v[(size_t)i * n + p], b = v[(size_t)i * n + q];
                    v[(size_t)i * n + p] = c * a + s * b;
                    v[(size_t)i * n + q] = c * b - s * a;
                }
            }
        }
        if (off < 1e-24 * (double)n) break;
    }
}

int la_svd(const double *a, double *u, double *s, double *vt, int m, int n,
           int maxsweeps)
{
    int i, j, k, idx;
    int    mn = (m < n) ? m : n;
    double *w, *v;
    if (m <= 0 || n <= 0) return 1;

    /* 输出形状（与 LAPACK dgesvd / numpy.linalg.svd 一致）：
     *   U  是 m*mn，VT 是 mn*n，S 是 mn 个。重建式 A = U · diag(S) · VT。
     * 早先这里把 VT 存成 n*mn（列步长 mn），结果 m<n 时整条重建链错位，
     * 是靠 _lachk.py 拿 numpy 的 vh 形状（mn*n）对出来的。 */
    if (m >= n) {
        w = (double *)malloc((size_t)m * (size_t)n * sizeof(double));
        v = (double *)malloc((size_t)n * (size_t)n * sizeof(double));
        if (!w || !v) { free(w); free(v); return 0; }
        memcpy(w, a, (size_t)m * (size_t)n * sizeof(double));
        for (i = 0; i < n; i++)
            for (j = 0; j < n; j++) v[(size_t)i * n + j] = (i == j) ? 1.0 : 0.0;
        svd_one_side(w, v, m, n, maxsweeps);
        for (j = 0; j < n; j++) {
            double nrm = 0.0;
            for (i = 0; i < m; i++) nrm += w[(size_t)i * n + j] * w[(size_t)i * n + j];
            nrm = sqrt(nrm);
            s[j] = nrm;
            if (nrm > 0.0) {
                for (i = 0; i < m; i++) w[(size_t)i * n + j] /= nrm;
            } else {
                for (i = 0; i < m; i++) w[(size_t)i * n + j] = 0.0;
            }
        }
        memcpy(u, w, (size_t)m * (size_t)n * sizeof(double));   /* U = 归一化后的列 */
        for (i = 0; i < n; i++)                                 /* VT = V^T（n*n） */
            for (j = 0; j < n; j++) vt[(size_t)i * n + j] = v[(size_t)j * n + i];
    } else {
        /* 对 B = A^T（n*m）做：B ≈ Ub(n*m) S(m) Vb^T(m*m)
         * 转置回来 A = Vb S Ub^T，于是 U = Vb（m*m），VT = Ub^T（m*n）。 */
        w = (double *)malloc((size_t)n * (size_t)m * sizeof(double));
        v = (double *)malloc((size_t)m * (size_t)m * sizeof(double));
        if (!w || !v) { free(w); free(v); return 0; }
        for (i = 0; i < n; i++)
            for (j = 0; j < m; j++) w[(size_t)i * m + j] = a[(size_t)j * n + i];
        for (i = 0; i < m; i++)
            for (j = 0; j < m; j++) v[(size_t)i * m + j] = (i == j) ? 1.0 : 0.0;
        svd_one_side(w, v, n, m, maxsweeps);
        for (j = 0; j < m; j++) {
            double nrm = 0.0;
            for (i = 0; i < n; i++) nrm += w[(size_t)i * m + j] * w[(size_t)i * m + j];
            nrm = sqrt(nrm);
            s[j] = nrm;
            if (nrm > 0.0) {
                for (i = 0; i < n; i++) w[(size_t)i * m + j] /= nrm;
            } else {
                for (i = 0; i < n; i++) w[(size_t)i * m + j] = 0.0;
            }
        }
        memcpy(u, v, (size_t)m * (size_t)m * sizeof(double));   /* U = Vb */
        for (j = 0; j < m; j++)                                 /* VT = Ub^T（m*n） */
            for (i = 0; i < n; i++)
                vt[(size_t)j * n + i] = w[(size_t)i * m + j];
    }
    free(w); free(v);

    /* 奇异值降序：s 降序；u 换**列**，vt 换**行**（VT 是 mn*n，第 j 行是第 j 个右奇异向量） */
    for (i = 1; i < mn; i++) {
        double val = s[i];
        idx = i - 1;
        while (idx >= 0 && s[idx] < val) {
            s[idx + 1] = s[idx];
            for (k = 0; k < m; k++) {
                double t = u[(size_t)k * mn + idx];
                u[(size_t)k * mn + idx] = u[(size_t)k * mn + idx + 1];
                u[(size_t)k * mn + idx + 1] = t;
            }
            for (k = 0; k < n; k++) {
                double t = vt[(size_t)idx * n + k];
                vt[(size_t)idx * n + k] = vt[(size_t)(idx + 1) * n + k];
                vt[(size_t)(idx + 1) * n + k] = t;
            }
            idx--;
        }
        s[idx + 1] = val;
    }
    return 1;
}

/* =============================================================================
 * 最小二乘
 * ========================================================================== */

int la_lstsq(const double *a, const double *b, double *x, int m, int n)
{
    int    i, j, r, mn = (m < n) ? m : n;
    double *u, *s, *vt, *c, smax = 0.0;
    /* 刻意用 SVD 而不是 QR：
     *   1. 数值上 SVD 就是最准的那一路，QR 求最小二乘要多绕两步三角求解，
     *      条件数大时精度差一个量级；
     *   2. 欠定（m<n）时 QR 要另外处理 min-norm，秩亏时 QR 会直接除零；
     *      SVD 这两种情况是同一段代码：把小于容差的奇异值对应的 y 置 0。 */
    u  = (double *)malloc((size_t)m * (size_t)mn * sizeof(double));
    s  = (double *)malloc((size_t)mn * sizeof(double));
    vt = (double *)malloc((size_t)mn * (size_t)n * sizeof(double));
    c  = (double *)malloc((size_t)mn * sizeof(double));
    if (!u || !s || !vt || !c) { free(u); free(s); free(vt); free(c); return 0; }

    if (!la_svd(a, u, s, vt, m, n, 60)) { free(u); free(s); free(vt); free(c); return 0; }
    for (j = 0; j < mn; j++) if (s[j] > smax) smax = s[j];
    for (j = 0; j < mn; j++) c[j] = 0.0;
    for (j = 0; j < mn; j++) {                 /* c = U^T b */
        double t = 0.0;
        for (i = 0; i < m; i++) t += u[(size_t)i * mn + j] * b[i];
        c[j] = t;
    }
    for (j = 0; j < mn; j++) {                 /* y = S^+ U^T b */
        double y = 0.0;
        if (s[j] > mn * LA_EPS * smax && s[j] > 0.0) y = c[j] / s[j];
        c[j] = y;
    }
    for (i = 0; i < n; i++) {                  /* x = V y = VT^T y */
        double t = 0.0;
        for (j = 0; j < mn; j++) t += vt[(size_t)j * n + i] * c[j];
        x[i] = t;
    }
    r = 0;
    for (j = 0; j < mn; j++) if (s[j] > mn * LA_EPS * smax && s[j] > 0.0) r++;
    free(u); free(s); free(vt); free(c);
    return r;                                  /* 返回数值秩 */
}

/* =============================================================================
 * 数值秩
 * ========================================================================== */

int la_rank(const double *a, int n, double tol)
{
    double  amax = 0.0;
    double *lu;
    int    *piv, k, r = 0;
    for (k = 0; k < n * n; k++) {
        double v = fabs(a[k]);
        if (v > amax) amax = v;
    }
    if (tol <= 0.0) tol = n * LA_EPS * amax;
    lu  = (double *)malloc((size_t)n * (size_t)n * sizeof(double));
    piv = (int *)malloc((size_t)n * sizeof(int));
    if (!lu || !piv) { free(lu); free(piv); return 0; }
    la_lu(a, lu, piv, n);                 /* 奇异也返回 —— lu/piv 已被填满 */
    for (k = 0; k < n; k++)
        if (fabs(lu[(size_t)k * n + k]) > tol) r++;
    free(lu); free(piv);
    return r;
}

/* =============================================================================
 * 一般实矩阵：实 Schur 分解            ★★★ 未完成，禁止接入 ★★★
 *
 * 【状态】核心算法在 Python 参考实现 `_eigref.py` 里已经验证到 n≤5 全档正确
 *        （对 NumPy `eigvals` 逐项，误差 3e-16 ~ 9e-15，重构残差 ~1e-15），
 *        但 **n≥6 的含复共轭特征值对的矩阵仍不收敛**（撞迭代上限）。
 *        下面这份 C 代码只搬了其中一部分修正，是**半成品**：
 *        - la_hessenberg 用的是错误版本（反射范围），需按 elmhes 约定改回；
 *        - la_francis 的 alpha 仍用 ‖x[1:]‖（应为 ‖x‖），且还留着 t[l+2][l]=0 的强制清零；
 *        - la_schur 缺 deflate_all、缺窗口顶端收缩、2×2 分支判据不对；
 *        - la_schur_eigvals 靠超对角反推块，应改成迭代过程中记特征值；
 *        - 缺 qr1（2×2 单移位 QR 步）。
 *        **在补齐之前不要往 LIB_CALLS / LIB_C_NAMES 里加 tb.schur / tb.eig，
 *          否则会给出看起来正常、实则错误的数。**
 *
 * 【已钉死的 5 个 bug 与数值证据】见 _EIG_排查记录.md。最阴险的一个：
 *        Householder 要 v = x + sign(x₀)·‖x‖·e₀，‖x‖ 是**整个**向量；
 *        写成 ‖x[1:]‖ 得到的 P 仍然正交、仍是相似变换（迹、det、残差全正常），
 *        但不是那一个反射，QR 迭代会悄悄冻在不动点上。
 *
 * 为什么要做：对称阵有 la_eig_sym（循环 Jacobi），但**一般实矩阵没有**。
 * 缺了它，PYbook 连一个二维旋转 [[0,-1],[1,0]]、一条马尔可夫转移矩阵、
 * 一个非对称 ODE 的系数阵都算不了——这三类恰恰都是不对称的。
 *
 * 路线是标准三段式（LAPACK dgeev 同款）：
 *   [1] Parlett-Reinsch 平衡，把行列的量级拉平（只乘 2 的幂，浮点上完全等价）
 *   [2] Householder 相似变换化成上 Hessenberg，H = Q₁ᵀ·A·Q₁
 *   [3] 对 H 做隐式 Francis 双移位 QR，收敛到实 Schur 形式 T（上准三角）
 * 为什么必须是**双**移位：单移位实 QR 在尾块特征值为共轭复数时移位取不到实数，
 * 迭代根本不动。双移位一次吃掉一对复特征值，这是实数域里唯一能走的路。
 * ========================================================================== */

/* 2×2 实块 a b / c d 的特征值，写进 wre[0..1] / wim[0..1]。
 *
 * 判别式 ((a-d)/2)² + bc 落在 0 附近时按 0 处理：完全缩掉的实块本来就该是
 * 两个实特征值，只是浮点把它算成了负数，直接 sqrt 会吐出一对假复数。
 * 实数对按**升序**给，跟 la_eig_sym 一个脾气；复数对给 (+i, −i) 相邻排列。 */
static void la_eig2x2(double a, double b, double c, double d,
                       double *wre, double *wim)
{
    double tr  = 0.5 * (a + d);
    double hh  = 0.5 * (a - d);
    double disc = hh * hh + b * c;
    double sc  = fabs(a) + fabs(b) + fabs(c) + fabs(d);
    double sq, lo, hi;

    if (disc < 0.0 && disc > -LA_EPS * LA_EPS * sc) disc = 0.0;
    sq = sqrt(fabs(disc));
    hi = tr + sq;
    lo = tr - sq;
    if (disc >= 0.0) {
        wre[0] = lo; wre[1] = hi;      /* 小的在前 */
        wim[0] = 0.0; wim[1] = 0.0;
    } else {
        wre[0] = tr; wre[1] = tr;
        wim[0] = sq; wim[1] = -sq;     /* 共轭对相邻 */
    }
}

/* [1] Parlett-Reinsch 平衡。
 *
 * 对角元不动（动了就等于给每个特征值加了个常数，特征值就全错了），
 * 只用「行乘 2^k、列除 2^k」这种对角相似变换。**只用 2 的幂是必须的**：
 * 这样缩放因子能被二进制精确表示，变换前后在浮点上完全等价，一点舍入都不引入。
 * dsc[j] 记下第 j 个方向累计的 2 的幂，最后要拿来把 Q 反平衡回去。 */
static void la_balance(double *h, int *dsc, int n)
{
    int    j, i, round;
    const double radix = 2.0, sqrdx = 4.0;

    for (j = 0; j < n; j++) dsc[j] = 1;
    for (round = 0; round < 64; round++) {     /* 64 轮足够收敛，纯属兜底 */
        int changed = 0;
        for (j = 0; j < n; j++) {
            double c = 0.0, r = 0.0, f = 1.0, g, s, cur;
            for (i = 0; i < n; i++) {
                if (i == j) continue;
                c += fabs(h[(size_t)i * n + j]);
                r += fabs(h[(size_t)j * n + i]);
            }
            if (c == 0.0 || r == 0.0) continue;
            s = c + r;
            cur = dsc[j];
            g   = r / radix;
            while (c < g)  { f *= radix; c *= sqrdx; cur *= radix; }
            g = r * radix;
            while (c > g)  { f /= radix; c /= sqrdx; cur /= radix; }
            if ((c + r) / f < 0.95 * s) {
                /* f 是 2 的幂，正负都安全；但 D 累乘可能溢出/下溢，出界就跳过这一轮 */
                if (cur < 1e-200 || cur > 1e200) continue;
                changed = 1;
                g = 1.0 / f;
                for (i = 0; i < n; i++) {
                    h[(size_t)i * n + j] *= f;
                    h[(size_t)j * n + i] *= g;
                }
                dsc[j] = cur;
            }
        }
        if (!changed) break;
    }
}

/* [2] Householder 相似变换：A → 上 Hessenberg H = Qᵀ·A·Q。
 * 每步的左右作用是**同一个**反射，所以作用完把 v 攒进 Q 就行，
 * 不必每步显式构造 n×n 矩阵再乘（那样是 O(n⁴)，这里 O(n³)）。
 *
 * 反射向量取 **h[k+2..n-1][k]**，不是 h[k+1..n-1][k]。h[k+1][k] 是次对角元，
 * 它本来就该留着（上 Hessenberg 只要求低于对角线**两行**以上为 0）。
 * 把它也卷进反射、再强行写回 alpha 看着像那么回事，实际写进去的值不是相似变换
 * 该有的值——相似性当场就破了，而且**迹还是守恒的**，只有 det/特征值会露馅。
 * 这跟 LAPACK dgehrd 里 DLARFG(N-K-1, A(K+2,K), …) 的取法是同一件事。 */
static void la_hessenberg(double *h, double *q, int n)
{
    int    i, j, k, m;
    double *v, alpha, beta, vv, nrm;

    for (i = 0; i < n; i++)
        for (j = 0; j < n; j++) q[(size_t)i * n + j] = (i == j) ? 1.0 : 0.0;
    if (n <= 2) return;

    v = (double *)malloc((size_t)n * sizeof(double));
    if (!v) return;                          /* 分配失败：h 保持原样，la_schur 后面会验出来 */
    for (k = 0; k + 2 < n; k++) {
        m = n - k - 2;                       /* 反射覆盖的行数 */
        if (m <= 1) break;                   /* 只有一个元素时无反射可做（dlarfg 的同款约定） */
        nrm = 0.0;
        for (i = 0; i < m; i++) {
            v[i] = h[(size_t)(k + 2 + i) * n + k];
            nrm += v[i] * v[i];
        }
        nrm = sqrt(nrm);
        if (nrm == 0.0) continue;             /* 这一列下面已经全是 0 */
        alpha = (v[0] > 0.0) ? -nrm : nrm;   /* 符号约定，保证 v[0]-alpha 不会抵消 */
        v[0] -= alpha;
        vv = 0.0;
        for (i = 0; i < m; i++) vv += v[i] * v[i];
        beta = 2.0 / vv;

        for (j = 0; j < n; j++) {            /* H = P·H：只动行 k+2..n-1 */
            double acc = 0.0;
            for (i = 0; i < m; i++) acc += v[i] * h[(size_t)(k + 2 + i) * n + j];
            acc *= beta;
            for (i = 0; i < m; i++) h[(size_t)(k + 2 + i) * n + j] -= acc * v[i];
        }
        for (i = 0; i < n; i++) {            /* H = H·P：只动列 k+2..n-1 */
            double acc = 0.0;
            for (j = 0; j < m; j++) acc += h[(size_t)i * n + (k + 2 + j)] * v[j];
            acc *= beta;
            for (j = 0; j < m; j++) h[(size_t)i * n + (k + 2 + j)] -= acc * v[j];
        }
        for (i = 0; i < n; i++) {            /* Q = Q·P */
            double acc = 0.0;
            for (j = 0; j < m; j++) acc += q[(size_t)i * n + (k + 2 + j)] * v[j];
            acc *= beta;
            for (j = 0; j < m; j++) q[(size_t)i * n + (k + 2 + j)] -= acc * v[j];
        }
        h[(size_t)(k + 2) * n + k] = alpha;  /* 精确写回，消掉舍入残留 */
        for (i = k + 3; i < n; i++) h[(size_t)i * n + k] = 0.0;
    }
    free(v);
}

/* [3] 隐式 Francis 双移位 QR 的一步，作用在窗口 [l, u] 上（要求 t[l][l-1] == 0）。
 *
 * 移位取窗口右下 2×2 的两个特征值之积，于是这次迭代同时消掉 t[l+1][l] **和**
 * t[l+2][l]（单移位只能消一个）。
 *
 * 反射向量**不抄书上的闭式**，而是当场把 (M² − p·M + q·I) 的第一列真算一遍：
 * 上 Hessenberg 矩阵乘一列是 O(n) 的，两列加起来 O(n)，比抄错一个系数的代价低得多。
 * 隐式 Q 定理保证这个 x 正是想要的左单步特征向量。
 *
 * stagnation（x 的第 2..s 项全为 0，压根没反射可作用）时返回 1，让外层换移位重试。 */
static int la_francis(double *t, double *q, int n, int l, int u, int zero_shift)
{
    int    i, j, s = u - l + 1;
    double p, qq, alpha, beta, vv, nrm;
    double *col, *col2, *v;

    col  = (double *)malloc(sizeof(double) * (size_t)(s + 1));
    col2 = (double *)malloc(sizeof(double) * (size_t)(s + 1));
    v    = (double *)malloc(sizeof(double) * (size_t)(s + 1));
    if (!col || !col2 || !v) { free(col); free(col2); free(v); return 0; }

    {
        double a = t[(size_t)(u - 1) * n + (u - 1)];
        double b = t[(size_t)(u - 1) * n + u];
        double c = t[(size_t)u * n + (u - 1)];
        double d = t[(size_t)u * n + u];
        p  = a + d;                 /* 两个特征值之和 */
        qq = a * d - b * c;         /* 两个特征值之积 */
        if (zero_shift) qq = 0.0;   /* 应急移位：双零移位 */
    }

    for (i = 0; i < s; i++) col[i] = t[(size_t)(l + i) * n + l];      /* M 的第一列 */
    for (i = 0; i < s; i++) {                                        /* col2 = M·col */
        double acc = 0.0;
        int    j0  = (i >= 1) ? i - 1 : 0;   /* Hessenberg：第 i 行从 j=i-1 起才可能非零 */
        for (j = j0; j < s; j++) acc += t[(size_t)(l + i) * n + (l + j)] * col[j];
        col2[i] = acc - p * col[i];
    }
    col2[0] += qq;                                                    /* + q·e₀ */

    nrm = 0.0;
    for (i = 1; i < s; i++) nrm += col2[i] * col2[i];
    nrm = sqrt(nrm);
    if (nrm == 0.0) { free(col); free(col2); free(v); return 1; }    /* 没进展 */

    alpha = (col2[0] > 0.0) ? -nrm : nrm;
    v[0] = col2[0] - alpha;
    for (i = 1; i < s; i++) v[i] = col2[i];
    vv = 0.0;
    for (i = 0; i < s; i++) vv += v[i] * v[i];
    beta = 2.0 / vv;

    for (j = 0; j < n; j++) {                    /* T = P·T：只动窗口里的行 */
        double acc = 0.0;
        for (i = 0; i < s; i++) acc += v[i] * t[(size_t)(l + i) * n + j];
        acc *= beta;
        for (i = 0; i < s; i++) t[(size_t)(l + i) * n + j] -= acc * v[i];
    }
    /* T = T·P：只动窗口里的**列**，但**每一行**都要扫。
     * 容易写成 i <= u —— 窗口不含末行时，u 以下的行同样含 T[i][l..u]，一样会被改，
     * 漏掉就是一次静默的相似性破坏（迹照样守恒，只有 det/特征值露馅）。 */
    for (i = 0; i < n; i++) {
        double acc = 0.0;
        for (j = 0; j < s; j++) acc += t[(size_t)i * n + (l + j)] * v[j];
        acc *= beta;
        for (j = 0; j < s; j++) t[(size_t)i * n + (l + j)] -= acc * v[j];
    }
    for (i = 0; i < n; i++) {                    /* Q = Q·P */
        double acc = 0.0;
        for (j = 0; j < s; j++) acc += q[(size_t)i * n + (l + j)] * v[j];
        acc *= beta;
        for (j = 0; j < s; j++) q[(size_t)i * n + (l + j)] -= acc * v[j];
    }
    t[(size_t)(l + 2) * n + l] = 0.0;           /* 双移位的效果：第三行也被消掉 */

    free(col); free(col2); free(v);
    return 0;
}

int la_schur(const double *a, double *t, double *q, int n, int maxits)
{
    int    i, j, u, l, its = 0, zero_shift = 0;
    double *h;
    int    *dsc;

    if (n == 0) return 1;
    h   = (double *)malloc((size_t)n * n * sizeof(double));
    dsc = (int *)malloc((size_t)n * sizeof(int));
    if (!h || !dsc) { free(h); free(dsc); return 0; }
    memcpy(h, a, (size_t)n * n * sizeof(double));

    la_balance(h, dsc, n);
    la_hessenberg(h, q, n);
    memcpy(t, h, (size_t)n * n * sizeof(double));
    free(h);

    u = n - 1;
    while (u > 0) {
        double sub, nrm;
        for (;;) {                    /* 劈开：子对角元相对邻元小到可以当 0 */
            sub = fabs(t[(size_t)u * n + (u - 1)]);
            nrm = fabs(t[(size_t)(u - 1) * n + (u - 1)]) + fabs(t[(size_t)u * n + u]);
            if (sub > LA_EPS * (nrm + sub)) break;
            t[(size_t)u * n + (u - 1)] = 0.0;
            if (--u == 0) break;
        }
        if (u == 0) break;

        l = u - 1;                    /* 活动窗口 [l, u]，t[l][l-1] 已经是 0 */
        while (l > 0 && t[(size_t)l * n + (l - 1)] != 0.0) l--;

        if (u - l == 1) {             /* 窗口只剩 2×2：直接读特征值并收尾 */
            double r[2], im[2];
            la_eig2x2(t[(size_t)(u - 1) * n + (u - 1)], t[(size_t)(u - 1) * n + u],
                      t[(size_t)u * n + (u - 1)],     t[(size_t)u * n + u], r, im);
            t[(size_t)u * n + (u - 1)] = 0.0;
            if (im[0] == 0.0) t[(size_t)(u - 1) * n + u] = 0.0;   /* 两个都实 → 拆成 1×1 块 */
            u -= 2;
            continue;
        }

        if (its >= maxits) { free(dsc); return 0; }
        if (la_francis(t, q, n, l, u, zero_shift)) {
            /* 这一步没进展：连着几次应急双零移位还是不动，就是真不收敛了 */
            if (zero_shift) { free(dsc); return 0; }
            zero_shift = 1;
        } else {
            zero_shift = 0;
        }
        its++;
    }

    /* 反平衡：B = D⁻¹·A·D、B = Q_B·T·Q_Bᵀ ⇒ A = (D·Q_B)·T·(D·Q_B)ᵀ */
    for (j = 0; j < n; j++)
        for (i = 0; i < n; i++) q[(size_t)i * n + j] *= (double)dsc[j];
    free(dsc);
    return 1;
}

/* 从实 Schur 形式读特征值。
 *
 * 靠「超对角线非零 ⇒ 这两格是一个 2×2 块」来认块：la_schur 收 2×2 块时，
 * 两个特征值都是实数就把超对角线显式清零了，所以 T 里留着的 2×2 块一定是
 * 真·共轭复数对。这样判块才准，不用再去算一遍判别式。 */
void la_schur_eigvals(const double *t, double *wre, double *wim, int n)
{
    int i = 0;
    while (i < n) {
        if (i + 1 < n && t[(size_t)i * n + (i + 1)] != 0.0) {
            la_eig2x2(t[(size_t)i * n + i],       t[(size_t)i * n + (i + 1)],
                      t[(size_t)(i + 1) * n + i], t[(size_t)(i + 1) * n + (i + 1)],
                      wre + i, wim + i);
            i += 2;
        } else {
            wre[i] = t[(size_t)i * n + i];
            wim[i] = 0.0;
            i += 1;
        }
    }
}

/* =============================================================================
 * [2] 绑定层：PYbook 语言面
 *
 * 两套门面并存，这是刻意的（用户拍板）：
 *   tb.*  张量面。直接吃 RtTensor，将来要接 GPU 路由时改的就是这一层。
 *   mp.*  扁平列表面。沿用「扁平列表 + 显式维度参数」的旧签名，老代码一行不用改；
 *         但内部**一律先包成张量再算**，不再直接对裸 double* 做矩阵运算 ——
 *         两套门面因此共用同一份实现，不会各自漂移。
 *
 * 精度传播沿用 tb.dot 的规矩：任一输入是 f32 → 输出 f32，内部一律按 double 算完再舍入。
 * 分解类算子（LU/QR/SVD）也遵守：用户拿 f32 进来就得到 f32 结果，这是精度选择而不是
 * 算法在 f32 里跑。
 * ========================================================================== */

#ifdef LA_RT_BINDING

#include "pybook_rt.h"
#include <stdarg.h>
#include <stdio.h>

static void la_die(const char *fmt, ...)
{
    va_list ap;
    char    msg[1024];
    va_start(ap, fmt);
    vsnprintf(msg, sizeof msg, fmt, ap);
    va_end(ap);
    rt_die("%s", msg);
}

static RtTensor *la_ten(Value v, const char *who)
{
    if (!rt_is_tensor(v) || rt_as_tensor(v) == NULL)
        la_die("%s 需要张量\n  为什么：这里要一个二维矩阵当输入，而收到的是 %s\n"
               "  怎么改：先用 tensor.from([[...],[...]]) 或 tb.mat(r,c) 造一个矩阵张量",
               who, "非张量");
    return rt_as_tensor(v);
}

static int la_int(Value v, const char *who)
{
    if (IS_INT(v) || IS_BIGINT(v)) return (int)rt_to_ll(v);
    if (IS_BOOL(v)) return AS_BOOL(v) ? 1 : 0;
    la_die("%s 的维度参数要是整数\n  为什么：矩阵函数按「行数、列数」两个整数定位\n"
           "  怎么改：写成 mp.mat_qr(A, 行数, 列数) 这样的形式，维度用整数", who);
    return 0;
}

static double la_num(Value v, const char *who)
{
    if (IS_FLT(v)) return AS_FLT(v);
    if (IS_INT(v) || IS_BIGINT(v)) return (double)rt_to_ll(v);
    if (IS_BOOL(v)) return AS_BOOL(v) ? 1.0 : 0.0;
    la_die("%s 的元素要是数字\n  为什么：矩阵运算的每个元素都得是数值\n"
           "  怎么改：把列表里的非数字项换掉，或先用 tensor.cast 转一下", who);
    return 0.0;
}

/* 2D 方阵 -> 阶数 */
static int la_sq(RtTensor *t, const char *who)
{
    if (t->ndim != 2)
        la_die("%s 需要二维张量（当前 %d 维）\n  为什么：这一类算子按方阵定义\n"
               "  怎么改：把输入规整成二维，比如 tb.tr(T[0:行, 0:列])", who, t->ndim);
    if (t->dims[0] != t->dims[1])
        la_die("%s 需要方阵（当前 %dx%d）\n  为什么：行列式、逆、LU、对角化都只对方阵有定义\n"
               "  怎么改：先切一个方阵出来，或改用 tb.qr / tb.svd（接受矩形矩阵）",
               who, t->dims[0], t->dims[1]);
    if (t->dims[0] < 1)
        la_die("%s 的维度必须为正整数\n  怎么改：至少 1x1", who);
    return (int)t->dims[0];
}

static int la_prec2(Value a, Value b)
{
    int p = TENSOR_F64;
    if (rt_is_tensor(a) && rt_as_tensor(a) && rt_as_tensor(a)->prec == TENSOR_F32) p = TENSOR_F32;
    if (rt_is_tensor(b) && rt_as_tensor(b) && rt_as_tensor(b)->prec == TENSOR_F32) p = TENSOR_F32;
    return p;
}

static Value la_mat(int r, int c, const double *d, int prec)
{
    int      dm[2] = { r, c };
    Value    v = rt_tensor_new_p(2, dm, prec);
    RtTensor *t = rt_as_tensor(v);
    int      i, n = r * c;
    for (i = 0; i < n; i++) t->data[i] = rt_tensor_round(prec, d[i]);
    return v;
}

static Value la_vec(int n, const double *d, int prec)
{
    int      dm[1] = { n };
    Value    v = rt_tensor_new_p(1, dm, prec);
    RtTensor *t = rt_as_tensor(v);
    int      i;
    for (i = 0; i < n; i++) t->data[i] = rt_tensor_round(prec, d[i]);
    return v;
}

static Value la_pack(Value a, Value b)
{
    Value l = rt_list_new();
    rt_push(&l, a);
    rt_push(&l, b);
    return l;
}

static Value la_pack3(Value a, Value b, Value c)
{
    Value l = rt_list_new();
    rt_push(&l, a);
    rt_push(&l, b);
    rt_push(&l, c);
    return l;
}

static Value la_singular_die(const char *who)
{
    la_die("%s：这个矩阵是奇异的（某个主元恰好为 0）\n"
           "  为什么：奇异矩阵没有逆，行列式恒为 0，LU 因子也不存在\n"
           "  怎么改：先用 tb.rank(A) 看清秩；秩亏时求解请改用 tb.lstsq（能给出最小范数解）", who);
    return 0;
}

/* ---------------- tb.* 张量面 ---------------- */

Value rt_lib_tb_lu(Value A)
{
    RtTensor *ta = la_ten(A, "tb.lu");
    int    n = la_sq(ta, "tb.lu"), prec = la_prec2(A, 0), i, ok;
    double *lu = (double *)malloc((size_t)n * n * sizeof(double));
    int    *piv = (int *)malloc((size_t)n * sizeof(int));
    Value   pl, out;
    if (!lu || !piv) { free(lu); free(piv); la_die("tb.lu 内存不足（%dx%d）", n, n); }
    ok = la_lu(ta->data, lu, piv, n);
    if (!ok) { free(lu); free(piv); return la_singular_die("tb.lu"); }
    pl = rt_list_new();
    for (i = 0; i < n; i++) rt_push(&pl, rt_int(piv[i]));
    out = la_pack(la_mat(n, n, lu, prec), pl);
    free(lu); free(piv);
    return out;
}

Value rt_lib_tb_solve(Value A, Value B)
{
    RtTensor *ta = la_ten(A, "tb.solve"), *tb = la_ten(B, "tb.solve");
    int      n = la_sq(ta, "tb.solve"), prec = la_prec2(A, B), nrhs, vec;
    double  *lu, *rhs;
    int     *piv;
    Value    out;
    if (tb->ndim == 1) {
        if (tb->dims[0] != n)
            la_die("tb.solve：右端向量长度 %d，要和系数矩阵的阶 %d 一样\n"
                   "  为什么：A(%dx%d) 只能解出长度 %d 的 x\n  怎么改：把右端补齐/裁到 %d 个分量",
                   (int)tb->dims[0], n, n, n, n, n);
        nrhs = 1; vec = 1;
    } else if (tb->ndim == 2) {
        if (tb->dims[0] != n)
            la_die("tb.solve：右端矩阵 %dx%d， 行数要等于系数矩阵的阶 %d\n"
                   "  怎么改：右端每行给一个方程，行数必须对上 A 的阶数",
                   (int)tb->dims[0], (int)tb->dims[1], n);
        nrhs = (int)tb->dims[1]; vec = 0;
    } else {
        return la_die("tb.solve 的右端要是向量或矩阵（%d 维不支持）", tb->ndim), (Value)0;
    }
    lu  = (double *)malloc((size_t)n * n * sizeof(double));
    piv = (int *)malloc((size_t)n * sizeof(int));
    rhs = (double *)malloc((size_t)n * nrhs * sizeof(double));
    if (!lu || !piv || !rhs) { free(lu); free(piv); free(rhs); la_die("tb.solve 内存不足"); }
    if (!la_lu(ta->data, lu, piv, n)) { free(lu); free(piv); free(rhs); return la_singular_die("tb.solve"); }
    memcpy(rhs, tb->data, (size_t)n * nrhs * sizeof(double));
    la_lu_solve(lu, piv, rhs, n, nrhs);
    out = vec ? la_vec(n, rhs, prec) : la_mat(n, nrhs, rhs, prec);
    free(lu); free(piv); free(rhs);
    return out;
}

Value rt_lib_tb_det(Value A)
{
    RtTensor *ta = la_ten(A, "tb.det");
    int    n = la_sq(ta, "tb.det"), ok;
    double *lu = (double *)malloc((size_t)n * n * sizeof(double));
    int    *piv = (int *)malloc((size_t)n * sizeof(int));
    double d;
    if (!lu || !piv) { free(lu); free(piv); la_die("tb.det 内存不足"); }
    ok = la_lu(ta->data, lu, piv, n);
    d  = la_lu_det(lu, piv, n);
    free(lu); free(piv);
    (void)ok;
    return rt_float(d);
}

Value rt_lib_tb_logdet(Value A)
{
    RtTensor *ta = la_ten(A, "tb.logdet");
    int    n = la_sq(ta, "tb.logdet"), i;
    double *lu = (double *)malloc((size_t)n * n * sizeof(double));
    int    *piv = (int *)malloc((size_t)n * sizeof(int));
    double s = 0.0;
    if (!lu || !piv) { free(lu); free(piv); la_die("tb.logdet 内存不足"); }
    la_lu(ta->data, lu, piv, n);
    /* log|det| = Σ log|对角元|，符号无关。矩阵一大 det 很快就溢出/下溢，
     * 所以大矩阵一律走这条路而不是先算 det 再取对数。 */
    for (i = 0; i < n; i++) s += log(fabs(lu[(size_t)i * n + i]));
    free(lu); free(piv);
    return rt_float(s);
}

Value rt_lib_tb_inv(Value A)
{
    RtTensor *ta = la_ten(A, "tb.inv");
    int    n = la_sq(ta, "tb.inv"), prec = la_prec2(A, 0);
    double *lu = (double *)malloc((size_t)n * n * sizeof(double));
    double *iv = (double *)malloc((size_t)n * n * sizeof(double));
    int    *piv = (int *)malloc((size_t)n * sizeof(int));
    Value   out;
    if (!lu || !iv || !piv) { free(lu); free(iv); free(piv); la_die("tb.inv 内存不足"); }
    if (!la_lu(ta->data, lu, piv, n) || !la_lu_inv(lu, piv, iv, n)) {
        free(lu); free(iv); free(piv);
        return la_singular_die("tb.inv");
    }
    out = la_mat(n, n, iv, prec);
    free(lu); free(iv); free(piv);
    return out;
}

Value rt_lib_tb_cond(Value A)
{
    RtTensor *ta = la_ten(A, "tb.cond");
    int    n = la_sq(ta, "tb.cond"), i, j;
    double *lu = (double *)malloc((size_t)n * n * sizeof(double));
    double *iv = (double *)malloc((size_t)n * n * sizeof(double));
    int    *piv = (int *)malloc((size_t)n * sizeof(int));
    double na = 0.0, ni = 0.0, cs;
    if (!lu || !iv || !piv) { free(lu); free(iv); free(piv); la_die("tb.cond 内存不足"); }
    if (!la_lu(ta->data, lu, piv, n) || !la_lu_inv(lu, piv, iv, n)) {
        free(lu); free(iv); free(piv);
        return la_singular_die("tb.cond");
    }
    /* 1-范数条件数 = ||A||_1 · ||A^-1||_1；1-范数是各列绝对值之和的最大者 */
    for (j = 0; j < n; j++) {
        cs = 0.0;
        for (i = 0; i < n; i++) cs += fabs(ta->data[(size_t)i * n + j]);
        if (cs > na) na = cs;
        cs = 0.0;
        for (i = 0; i < n; i++) cs += fabs(iv[(size_t)i * n + j]);
        if (cs > ni) ni = cs;
    }
    free(lu); free(iv); free(piv);
    return rt_float(na * ni);
}

Value rt_lib_tb_rank(Value A)
{
    RtTensor *ta = la_ten(A, "tb.rank");
    int n = la_sq(ta, "tb.rank");
    return rt_int(la_rank(ta->data, n, 0.0));
}

Value rt_lib_tb_qr(Value A)
{
    RtTensor *ta = la_ten(A, "tb.qr");
    int    m = (int)ta->dims[0], n = (int)ta->dims[1], prec = la_prec2(A, 0), p, i;
    double *r  = (double *)malloc((size_t)m * n * sizeof(double));
    double *vv = (double *)malloc((size_t)m * (m < n ? m : n) * sizeof(double));
    double *tau = (double *)malloc((m < n ? m : n) * sizeof(double));
    double *q  = (double *)malloc((size_t)m * m * sizeof(double));
    Value   out;
    if (!r || !vv || !tau || !q) { free(r); free(vv); free(tau); free(q); la_die("tb.qr 内存不足"); }
    p = la_qr(ta->data, r, vv, tau, m, n);
    for (i = 0; i < m * m; i++) q[i] = ((i / m) == (i % m)) ? 1.0 : 0.0;
    la_qr_form_q(vv, tau, q, m, p);
    out = la_pack(la_mat(m, m, q, prec), la_mat(m, n, r, prec));
    free(r); free(vv); free(tau); free(q);
    return out;
}

Value rt_lib_tb_lstsq(Value A, Value b)
{
    RtTensor *ta = la_ten(A, "tb.lstsq"), *tb = la_ten(b, "tb.lstsq");
    int    m = (int)ta->dims[0], n = (int)ta->dims[1], prec = la_prec2(A, b);
    double *x = (double *)malloc((size_t)n * sizeof(double));
    Value   out;
    if (ta->ndim != 2 || tb->ndim != 1)
        la_die("tb.lstsq 需要二维系数矩阵 + 一维右端（当前 %d 维 / %d 维）", ta->ndim, tb->ndim);
    if (tb->dims[0] != m)
        la_die("tb.lstsq：右端长度 %d，要等于系数矩阵的行数 %d\n"
               "  为什么：每个方程给一个残差，行数就是方程个数\n  怎么改：把右端长度对齐到 %d",
               (int)tb->dims[0], m, m);
    if (!x) la_die("tb.lstsq 内存不足");
    la_lstsq(ta->data, tb->data, x, m, n);
    out = la_vec(n, x, prec);
    free(x);
    return out;
}

Value rt_lib_tb_cholesky(Value A)
{
    RtTensor *ta = la_ten(A, "tb.cholesky");
    int    n = la_sq(ta, "tb.cholesky"), prec = la_prec2(A, 0);
    double *l = (double *)malloc((size_t)n * n * sizeof(double));
    Value   out;
    if (!l) la_die("tb.cholesky 内存不足");
    if (!la_cholesky(ta->data, l, n)) {
        free(l);
        la_die("tb.cholesky：矩阵不对称，或者不是正定\n"
               "  为什么：Cholesky 要求 A = L·Lᵀ，只有对称正定阵才有这种分解\n"
               "  怎么改：先对称化 A=(A+Aᵀ)/2；协方差矩阵这类才满足正定；"
               "任意矩阵请改用 tb.qr 或 tb.svd");
    }
    out = la_mat(n, n, l, prec);
    free(l);
    return out;
}

Value rt_lib_tb_eig_sym(Value A)
{
    RtTensor *ta = la_ten(A, "tb.eig_sym");
    int    n = la_sq(ta, "tb.eig_sym"), prec = la_prec2(A, 0);
    double *vals = (double *)malloc((size_t)n * sizeof(double));
    double *vecs = (double *)malloc((size_t)n * n * sizeof(double));
    Value   out;
    if (!vals || !vecs) { free(vals); free(vecs); la_die("tb.eig_sym 内存不足"); }
    if (!la_eig_sym(ta->data, vals, vecs, n, 100)) {
        free(vals); free(vecs);
        la_die("tb.eig_sym：矩阵不对称\n  为什么：对角化只对实对称矩阵保证有实特征值\n"
               "  怎么改：先对称化 A=(A+Aᵀ)/2，或改用 tb.svd（任意矩阵都能分解）");
    }
    out = la_pack(la_vec(n, vals, prec), la_mat(n, n, vecs, prec));
    free(vals); free(vecs);
    return out;
}

Value rt_lib_tb_svd(Value A)
{
    RtTensor *ta = la_ten(A, "tb.svd");
    int    m = (int)ta->dims[0], n = (int)ta->dims[1], prec = la_prec2(A, 0), mn;
    double *u, *s, *vt;
    Value   out;
    if (ta->ndim != 2) la_die("tb.svd 需要二维矩阵（当前 %d 维）", ta->ndim);
    mn = m < n ? m : n;
    u  = (double *)malloc((size_t)m * mn * sizeof(double));
    s  = (double *)malloc((size_t)mn * sizeof(double));
    vt = (double *)malloc((size_t)mn * n * sizeof(double));
    if (!u || !s || !vt) { free(u); free(s); free(vt); la_die("tb.svd 内存不足"); }
    la_svd(ta->data, u, s, vt, m, n, 60);
    out = la_pack3(la_mat(m, mn, u, prec), la_vec(mn, s, prec), la_mat(mn, n, vt, prec));
    free(u); free(s); free(vt);
    return out;
}

/* ---------------- mp.* 扁平列表面（内部仍走张量） ---------------- */

static Value la_from_flat(Value a, int r, int c, const char *who)
{
    int       dm[2] = { r, c };
    Value     v;
    RtTensor *t;
    long long i, n = (long long)r * (long long)c, got;
    if (!IS_LIST(a))
        la_die("%s 需要列表参数\n  怎么改：写成 [1,2,3,4] 这样的扁平列表，再用后面的行数列数说明形状", who);
    got = rt_list_len_ll(a);
    if (got != n)
        la_die("%s 的列表长度是 %lld，但 %dx%d 需要 %lld 个元素\n"
               "  为什么：mp.* 的矩阵就是一个扁平列表，形状靠行数列数两个参数交代\n"
               "  怎么改：补齐或删减到 %lld 个元素", who, got, r, c, n, n);
    v = rt_tensor_new_p(2, dm, TENSOR_F64);
    t = rt_as_tensor(v);
    for (i = 0; i < n; i++) t->data[i] = la_num(rt_index(a, rt_int(i)), who);
    return v;
}

static Value la_to_flat(Value v, const char *who)
{
    RtTensor *t = rt_as_tensor(v);
    Value      out = rt_list_new();
    long long  i, n = 1;
    int        k;
    (void)who;
    for (k = 0; k < t->ndim; k++) n *= t->dims[k];
    for (i = 0; i < n; i++) rt_push(&out, rt_float(t->data[i]));
    return out;
}

Value rt_lib_mp_mat_lu(Value a, Value nv)
{
    int   n = la_int(nv, "mp.mat_lu");
    Value t = la_from_flat(a, n, n, "mp.mat_lu");
    Value r = rt_lib_tb_lu(t);
    Value lu = rt_index(r, rt_int(0));
    Value pv = rt_index(r, rt_int(1));
    Value out = rt_list_new();
    rt_push(&out, la_to_flat(lu, "mp.mat_lu"));
    rt_push(&out, pv);
    return out;
}

Value rt_lib_mp_mat_solve(Value a, Value b, Value nv)
{
    int   n = la_int(nv, "mp.mat_solve");
    Value t = la_from_flat(a, n, n, "mp.mat_solve");
    long long bn;
    Value tb;
    int    i;
    double *tmp;
    Value  bl, out;
    if (!IS_LIST(b)) la_die("mp.mat_solve 的右端需要列表\n  怎么改：给一个长度 %d 的列表", n);
    bn = rt_list_len_ll(b);
    if (bn != n)
        la_die("mp.mat_solve 的右端长度 %lld，要等于阶数 %d\n  怎么改：右端长度对齐到 %d", bn, n, n);
    tb = rt_tensor_new_p(1, (int[]){ n }, TENSOR_F64);
    tmp = rt_as_tensor(tb)->data;
    for (i = 0; i < n; i++) tmp[i] = la_num(rt_index(b, rt_int(i)), "mp.mat_solve");
    out = rt_lib_tb_solve(t, tb);
    bl = la_to_flat(out, "mp.mat_solve");
    return bl;
}

Value rt_lib_mp_mat_qr(Value a, Value rv, Value cv)
{
    int   r = la_int(rv, "mp.mat_qr"), c = la_int(cv, "mp.mat_qr");
    Value t = la_from_flat(a, r, c, "mp.mat_qr");
    Value o = rt_lib_tb_qr(t);
    Value out = rt_list_new();
    rt_push(&out, la_to_flat(rt_index(o, rt_int(0)), "mp.mat_qr"));
    rt_push(&out, la_to_flat(rt_index(o, rt_int(1)), "mp.mat_qr"));
    return out;
}

Value rt_lib_mp_mat_svd(Value a, Value rv, Value cv)
{
    int   r = la_int(rv, "mp.mat_svd"), c = la_int(cv, "mp.mat_svd");
    Value t = la_from_flat(a, r, c, "mp.mat_svd");
    Value o = rt_lib_tb_svd(t);
    Value out = rt_list_new();
    rt_push(&out, la_to_flat(rt_index(o, rt_int(0)), "mp.mat_svd"));
    rt_push(&out, la_to_flat(rt_index(o, rt_int(1)), "mp.mat_svd"));
    rt_push(&out, la_to_flat(rt_index(o, rt_int(2)), "mp.mat_svd"));
    return out;
}

Value rt_lib_mp_mat_eig_sym(Value a, Value nv)
{
    int   n = la_int(nv, "mp.mat_eig_sym");
    Value t = la_from_flat(a, n, n, "mp.mat_eig_sym");
    Value o = rt_lib_tb_eig_sym(t);
    Value out = rt_list_new();
    rt_push(&out, la_to_flat(rt_index(o, rt_int(0)), "mp.mat_eig_sym"));
    rt_push(&out, la_to_flat(rt_index(o, rt_int(1)), "mp.mat_eig_sym"));
    return out;
}

Value rt_lib_mp_mat_cholesky(Value a, Value nv)
{
    int   n = la_int(nv, "mp.mat_cholesky");
    Value t = la_from_flat(a, n, n, "mp.mat_cholesky");
    return la_to_flat(rt_lib_tb_cholesky(t), "mp.mat_cholesky");
}

Value rt_lib_mp_mat_ls(Value a, Value b, Value mv, Value nv)
{
    int   m = la_int(mv, "mp.mat_ls"), n = la_int(nv, "mp.mat_ls"), i;
    Value t = la_from_flat(a, m, n, "mp.mat_ls");
    long long bn;
    Value tb;
    double *tmp;
    if (!IS_LIST(b)) la_die("mp.mat_ls 的右端需要列表\n  怎么改：给一个长度 %d 的列表", m);
    bn = rt_list_len_ll(b);
    if (bn != m)
        la_die("mp.mat_ls 的右端长度 %lld，要等于系数矩阵的行数 %d\n  怎么改：对齐到 %d", bn, m, m);
    tb = rt_tensor_new_p(1, (int[]){ m }, TENSOR_F64);
    tmp = rt_as_tensor(tb)->data;
    for (i = 0; i < m; i++) tmp[i] = la_num(rt_index(b, rt_int(i)), "mp.mat_ls");
    return la_to_flat(rt_lib_tb_lstsq(t, tb), "mp.mat_ls");
}

Value rt_lib_mp_mat_rank(Value a, Value nv)
{
    int   n = la_int(nv, "mp.mat_rank");
    Value t = la_from_flat(a, n, n, "mp.mat_rank");
    return rt_lib_tb_rank(t);
}

Value rt_lib_mp_mat_cond(Value a, Value nv)
{
    int   n = la_int(nv, "mp.mat_cond");
    Value t = la_from_flat(a, n, n, "mp.mat_cond");
    return rt_lib_tb_cond(t);
}

Value rt_lib_mp_mat_logdet(Value a, Value nv)
{
    int   n = la_int(nv, "mp.mat_logdet");
    Value t = la_from_flat(a, n, n, "mp.mat_logdet");
    return rt_lib_tb_logdet(t);
}

/* 互转：扁平列表 + 维度 -> 张量（往 tb.* 那套去的入口） */
Value rt_lib_mp_to_tensor(Value a, Value rv, Value cv)
{
    return la_from_flat(a, la_int(rv, "mp.to_tensor"), la_int(cv, "mp.to_tensor"),
                        "mp.to_tensor");
}

#endif /* LA_RT_BINDING */
