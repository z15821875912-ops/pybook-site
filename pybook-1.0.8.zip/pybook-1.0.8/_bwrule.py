# -*- coding: utf-8 -*-
"""_bwrule.py -- 确认「special register 不能直接做算术操作数」这条规则的边界。

第二轮二分已经把罪魁钉在一行上（实测）：
    mov.u32 %r2, %ctaid.x;            通过
    mul.lo.u32 %r2, %r2, %ntid.x;     失败      <-- 就是这行

也就是说 PTX 里 %tid/%ctaid/%ntid/%nctaid 这类 special register
必须先 mov 进普通寄存器，才能拿去参与算术运算，直接当操作数会被 JIT 拒。
本轮把这个结论钉死，免得下次又踩：

  t_ok_mov   先 mov %ntid.x 到普通寄存器再乘      期望通过
  t_bad_mul  直接把 %ntid.x 当乘数               期望失败
  t_bad_add  直接把 %tid.x 当加数                期望失败
  t_bad_cta  直接把 %nctaid.x 当乘数             期望失败
  t_ok_all   四个 special register 全部先 mov     期望通过

注释一律纯 ASCII。
"""
import os

HEAD = """.version 6.5
.target sm_61
.address_size 64
"""

DECL = """    .reg .pred %p<4>;
    .reg .b32  %r<8>;
    .reg .b64  %rd<8>;
    .reg .f32  %f<8>;
"""

PRE = """
    ld.param.u64 %rd1, [p_a];
    ld.param.u64 %rd2, [p_out];
    cvta.to.global.u64 %rd3, %rd1;
    cvta.to.global.u64 %rd4, %rd2;
"""

TAIL = """
    ld.global.f32 %f1, [%rd3];
    st.global.f32 [%rd4], %f1;
    ret;
}
"""

SIG = "( .param .u64 p_a, .param .u64 p_out, .param .u32 p_iter )"

CASES = [
    ("t_ok_mov",   "mov %ntid.x first, then multiply",
     "    mov.u32 %r2, %ctaid.x;\n    mov.u32 %r5, %ntid.x;\n"
     "    mul.lo.u32 %r2, %r2, %r5;\n"),
    ("t_bad_mul",  "%ntid.x used directly as multiplier",
     "    mov.u32 %r2, %ctaid.x;\n    mul.lo.u32 %r2, %r2, %ntid.x;\n"),
    ("t_bad_add",  "%tid.x used directly as addend",
     "    mov.u32 %r2, %ctaid.x;\n    add.u32 %r2, %r2, %tid.x;\n"),
    ("t_bad_cta",  "%nctaid.x used directly as multiplier",
     "    mov.u32 %r2, %ctaid.x;\n    mul.lo.u32 %r2, %nctaid.x, %ntid.x;\n"),
    ("t_ok_all",   "all four special regs moved out first",
     "    mov.u32 %r2, %ctaid.x;\n    mov.u32 %r5, %ntid.x;\n"
     "    add.u32  %r2, %r2, %tid.x;\n    mul.lo.u32 %r2, %r2, %r5;\n"
     "    mov.u32  %r6, %nctaid.x;\n    mul.lo.u32 %r2, %r2, %r6;\n"),
]


def main():
    made = []
    for name, note, body in CASES:
        txt = (HEAD
               + "// bw rule check: " + note + "\n"
               + "// ASCII comments only -- Chinese breaks the JIT with no message.\n"
               + ".visible .entry bw_read" + SIG + "\n{\n"
               + DECL + PRE + body + TAIL)
        with open("_ptx_BW_%s.ptx" % name, "w", encoding="ascii", newline="\n") as f:
            f.write(txt)
        made.append("_ptx_BW_%s.ptx" % name)
    print(" ".join(made))


if __name__ == "__main__":
    main()
