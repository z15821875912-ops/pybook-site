# -*- coding: utf-8 -*-
# IDX(.gz) -> PYBT（tb.load 直读）：f64、像素 /255、标签 N×1
import gzip, struct

def read_idx(path):
    with gzip.open(path, "rb") as f:
        data = f.read()
    magic, ndim = data[2], data[3]
    dims = struct.unpack(">" + "I" * ndim, data[4:4 + 4 * ndim])
    body = data[4 + 4 * ndim:]
    return dims, body

def write_pybt(path, dims, flat):
    with open(path, "wb") as f:
        f.write(b"PYBT")
        f.write(struct.pack("<II", 1, 1))
        f.write(struct.pack("<I", len(dims)))
        for d in dims:
            f.write(struct.pack("<I", d))
        f.write(struct.pack("<I", 0))          # prec = F64
        f.write(struct.pack("<%dd" % len(flat), *flat))

for tag, pre in [("练", "train"), ("测", "t10k")]:
    dims, body = read_idx(f"_mn_{tag[0]}i.gz".replace("练i", "ti").replace("测i", "qi"))
    n, r, c = dims
    assert (r, c) == (28, 28), dims
    px = list(body)
    x = [v / 255.0 for v in px]
    _, lbody = read_idx(f"_mn_{tag[0]}l.gz".replace("练l", "tl").replace("测l", "ql"))
    lab = list(lbody)
    assert len(lab) == n, (len(lab), n)
    write_pybt(f"mnist{tag}图.bin", [n, r * c], x)
    write_pybt(f"mnist{tag}标.bin", [n, 1], [float(v) for v in lab])
    print(tag, n, "done, 类分布采样:", sorted(set(lab)))
