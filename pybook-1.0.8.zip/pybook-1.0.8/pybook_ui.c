/* pybook_ui.c —— 桌面 GUI 引擎（立即模式 / SDL2 自绘）
 *
 * 三条设计决策：
 *   ① 立即模式（IMGUI）：每帧重新声明控件，函数直接返回交互结果。
 *      契合 PYbook 的 `rm.aging.while(end()) { ... show() }` 帧循环 ——
 *      不用注册回调、不用管控件生命周期，新手友好、代码量小。
 *   ② SDL2 自绘，不用系统原生控件：零新增依赖、Windows 与 Linux 表现一致、
 *      风格统一成 PYbook 的深色终端风。
 *   ③ API 全英文：关键字早已迁英文，中文只出现在变量名 / 字符串 / 注释。
 *
 * 复用的现成部件（这是本引擎能写得这么短的原因）：
 *   · 窗口 / 渲染器 —— rt_game_win 与 game_renderer（2D 游戏已有）
 *   · 中文字       —— rt_game_text（pybook_rt.c 的 stb_truetype + 纹理缓存）
 *   · 鼠标         —— rt_game_mx / my / mhit / mdown
 *   · 文本输入     —— game_take_text（SDL_TEXTINPUT；中文 IME 也走这条）
 *   · 文字测宽     —— game_text_width（布局要用）
 *
 * 状态怎么存：控件要跨帧记住文本 / 滑条值。默认按「容器内调用序号」生成 id；
 *   把控件放进 if 分支会让序号错位，那种情况先用 ui.tag("名字") 钉住稳定 id。
 *
 * ================= 2026-08 实测记录（三条都踩过，写下来免得再踩）=================
 *
 * ★ 1. 焦点释放必须在「消费焦点」之前，不能放在后面
 *   原来的写法是
 *       if (g_focus == id && g_down) { 用 g_mx 反算滑条值 }
 *       if (g_click && !hover) g_focus = 0;          <- 放在后面
 *   于是"按住滑条不松手、再去点别处"时，滑条仍攥着上一帧的 g_focus，
 *   g_down 又还是 1，就用新的鼠标位置把值改掉：实测点表格第三行时
 *   音量自己从 28 跳到 100（(520-24)/275 = 1.8 → clamp 成 1.0）。
 *   ui.table 的滚动条是同一个形状的错（else if 挂在滚动分支上，一样漏）。
 *   正确顺序：先按"新的按下且不在本控件上"释放焦点，再消费焦点。
 *   注意别改坏另一件事：**纯拖动**（g_click=0，没有新边沿）不该释放，
 *   "按住拖出控件范围还继续跟手"是滑条该有的手感。
 *
 * ★ 2. 这个引擎的 stderr 在 window(normal, open) 框架模式下是**看不到的**
 *   （pybook_rt.c 的 stdout 捕获机制会把它一并带走）。往 UI 引擎里塞
 *   fprintf(stderr, ...) 调试探针，会得到"一行都不打印"的假象 ——
 *   当时误判成"函数根本没被调用"，白查了半天。
 *   引擎内调试一律走 stdout + fflush(stdout)；出图日志（rt_shot_*）在
 *   开窗口阶段打印，早于捕获，所以不受影响。
 *
 * ★ 3. g_frame_ui 统计的是 ui.begin 的**调用次数**，不是游戏帧数
 *   一帧里有几列就 ui.begin 几次（两列 = 每帧 +2）。当帧号用没问题，
 *   但别拿它跟脚本里的帧计数器对数，会差一倍而以为自己算错了。
 *
 * ================= 新增接口（2026-08）=================
 *   ui.矩形(name)         回读被 ui.tag(name) 钉住的控件的 [x, y, w, h]
 *   ui.测试输入(x,y,点击,按住)  覆写本帧输入快照（必须在 ui.begin 之前）
 *   ui.测试输入恢复()      交回真实鼠标
 *   ui.分组(标题)          带面板的小节容器，到 ui.end 为止
 *   ui.样式("圆角"|"字符")  一行切整套外观（"字符"会同时把窗口字体切成等宽）
 *   ui.字格(像素)          把字符网格的步进钉死（默认跟字号走）
 *
 *   后者是为了让交互测试**自己算出该点哪儿**。以前只能看着截图量像素，
 *   而坐标随字号/文案/间距一起变 —— 改一行布局，测试就悄悄点空了，
 *   而且不会报错，只是"没反应"。量图取坐标是最容易放过这类 bug 的方式。
 *
 * ================= 2026-08 视觉升级：把「原边 / 像素化 / 字幕化」拆开看 =========
 * 用户只说了"还是不好"，实测下来是三个独立的病根，各治各的：
 *
 * ★ A. 没有层次 —— 不是没画阴影，是**没地方放阴影**
 *   原来只有「窗底 #0B0E14 / 控件底 #131820」两级深色，控件和它下面的一切
 *   一样黑，投影叠上去等于没叠，边框画几道都读不出厚度。
 *   现在按"离眼睛越近越亮"排成阶梯：11 → 18 → 30 → 42，
 *   投影落在控件与面板之间那 12 级差里才看得见（SH_CTRL 150 / SH_PANEL 90）。
 *
 * ★ B. 原边 + 像素化 —— 硬边矩形和 Bresenham 铺方块，天生有台阶
 *   见下面「抗锯齿圆角」一节：主体照旧批量 FillRect，只在 4 个 r×r 角区
 *   逐像素按覆盖率画；ui_line 改成按到线段的距离算覆盖率。
 *
 * ★ C. 字幕化 —— 整屏控件平铺，中间不留结构，看着像字幕浮在黑底上
 *   新增 ui.分组：圆角面板 + 主色竖条 + 标题 + 右延伸分隔线。
 *
 * ★ D. 这套改动顺手挖出来的一个**运行时真 bug**（不在本文件，在编译器）
 *   `clear()` 无参调用原本发的是 `rt_game_clear(11, 14, 20)` 这样的裸整数，
 *   而 Value 是 `typedef uint64_t` —— 传裸整数在 C 里合法且**无警告**，
 *   运行时 game_num 收到没打标的位模式读出 0，于是每个程序的
 *   color(...) + clear() 背景一直被清成纯黑。已改成 rt_int(...) 装箱。
 *
 * ================= 新增的坑（2026-08 视觉升级期间踩的）=================
 *
 * ★ 4. 分组面板高度的键不能是容器 hash，也不能在 ui.begin 里清零
 *   面板要垫在子控件**底下**，可立即模式只有等 ui.end 才知道多高，
 *   所以用上一帧量到的高度画底（面板纯装饰、不参与布局，晚一帧看不出来）。
 *   键的选择踩了两次：
 *     · 先用容器 hash → 多列布局里每列的根容器 hash 都是 0（ui.begin 清零），
 *       左列第 1 个分组和右列第 1 个分组撞成同一个 id，互相套对方的高度。
 *       实测日志：「播放控制」画成 274（那是「图元清单」的高），反之 140。
 *     · 改成"本帧调用序号"后仍错，因为序号是在 **ui.begin 里**清零的，
 *       而一帧可以有多列（demo 就是 begin 两次）—— 第二列从头数，又撞上。
 *   现在：序号按**帧**计数，由 pybook_rt.c 的 rt_game_show 在帧末调
 *   rt_ui_new_frame() 清零。帧的边界只有 show 知道。
 *
 * ★ 5. UI 帧内必须显式把 blend 模式设成 BLEND
 *   SDL2 渲染器默认是 SDL_BLENDMODE_NONE，alpha 直接被丢掉（全当不透明），
 *   投影和圆角覆盖率全废。rt_ui_begin 设成 BLEND、根容器 ui.end 收尾时还原
 *   NONE —— pybook_rt.c 的 game.* 图元是按不透明绘制的，不能被顺手改掉。
 *
 * ★ 6. 抗锯齿靠的是"覆盖率当 alpha"，不是靠开 MSAA
 *   SDL_RenderSetLogicalSize 那套对 SDL_RenderFillRect 无效，逐图元走
 *   SDL_RenderGeometry 又得把整个 UI 重写成三角形。角区逐像素是唯一划算的路。
 *
 * ★ 7. 读截图 BMP 时别默认 32bpp
 *   出图写的是 **24bpp**（880×620×3+54 = 1636854 字节，数一下就知道）。
 *   按 4 字节/像素去取会整列错位，读出来是"看起来像噪声"的颜色 ——
 *   差点据此得出"渲染有 bug"的结论。
 *   另一头：BMP 是**自底向上**存的（高度字段为正），不翻的话整张图上下颠倒，
 *   量出来的 y 全是镜像坐标。_colscan.py 处理了，_hscan.py / _map.py 最初没处理，
 *   差点据此断言"表格的上下边框根本没画出来"。
 *
 * ================= 2026-08 字符边框风格 =================
 *
 * 用户澄清要的"由字母组成的边框"是 ┌─┐│└┘ / [ 文本 ] / [√] 那一挂，
 * 不是圆角矩形。两套外观都留着，ui.样式("圆角"|"字符") 一行切。
 *
 * ★ 8. 字符风必须换等宽字体，否则框线连不起来
 *   微软雅黑是比例字体：┌ ─ │ ┐ 步进确实都是 14px（和拉丁 A 同宽，实测），
 *   但**字形画得比步进窄** —— ─ 的笔画约 10px、│ 的笔画 13px 而格高 16。
 *   横排每 14px 断 4px、竖排每格断 3px，画出来是虚线。
 *   换宋体（ASCII 定宽 + CJK 全角 + 制表符按字宽设计）才接得上。
 *   找不到等宽字体不算致命错：退化成有断口的字符框，功能照常。
 *
 * ★ 9. game_text_width 不能当字符步进
 *   它返回的是纹理宽 = 4 + Σ(advance+2)，单字符也 +6、n 字符 +4+2n。
 *   拿它当步进，角会画到 x+8、横线从 x+14 起，中间凭空多 6px 断口。
 *   game_text_advance() 返回纯 advance 之和，才是步进。
 *   用错的后果不止框线：按钮 "低"(advance 16) 会被算成 2 格，按钮凭空宽一格，
 *   排在一起就是 `[ 低 ]  [中] [高] [极高]` 这种忽宽忽窄（实测）。
 *   连带的：ui.slider 里给数值预留的位置也从 width 改成 advance，
 *   轨道 tw 随之少了 8px —— _UI交互.pybk 的音量终值从 28.1954887218045
 *   变成 27.3722627737226。不是交互回归，改完才和 CHANGELOG 里
 *   早就写着的「25% 落点换算成 27.3%」对上。
 *
 * ★ 10. 等宽字体里有一批常用符号**根本没有字形**
 *   逐个画出来量像素才知道（_UI字形.pybk 探针）：
 *     可用 —— ◆ ● ○ √ × ┃ │ ▌ █ ≡ ║ ┄ ┊ » ├ ┤ ┌ ┐ └ ┘
 *     缺字 —— ▶ ▸ ► ❯ ✔      （画出来是空白）
 *   表格选中指针原来用 ▸(U+25B8)，所以字符风下"选中行"一直是看不见的 ——
 *   不报错、不崩，只是那个字没画出来。现已改用 ▌。
 *
 * ★ 11. 同一个几何量只能有一份
 *   本轮四个 bug 全是"同一个量在两处各算一遍"：
 *     · 表格竖线一套循环、横线另一套字符串循环，竖线整体比 ┬ ┼ ┴ 左移一整列
 *       （实测 80px = 5 格），而且右边框那条竖线根本没画（循环只跑 ncols 次）；
 *     · total_cells 多算一格（1 + Σ(ccw+1) 是字符数，列位表是格号，差 1）；
 *     · 分组框的**下边框**跟着标题的偏移走 —— 下边没标题，却也从标题末尾开始，
 *       左下角空一大截（实测偏 9 格）；
 *     · 滑条右端的 ┤ 画在"整个控件最右"，正好压在右边预留的数值上，
 *       ┤ 跑到 "60" 后面去了。右端 ┤ 该封的是**轨道**。
 *   现在表格用一张 colx[] 列位表做唯一真源，竖线 / 横线接点 / 表头文字 /
 *   数据文字 / 滚动条轨道全从它取 x。
 *
 * ★ 12. 字符风每帧比圆角风贵 2.4 倍（实测 3.95 vs 1.62 ms/帧，同一次 session）
 *   原因很具体：竖线是**每格一次 text()**，一帧下来框线+表格约 90 次调用。
 *   横线已经是一次 text() 连排（ui_rep），竖排没法这么合 ——
 *   "│││" 拼出来是横排不是竖排。想省得给 pybook_rt.c 加一个"把某个字形
 *   纵向拉伸绘制"的接口：仍是那个字形，只是一次 draw call 而不是 N 次。
 */

#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>      /* uint64_t：ui.序列 的高精度起始时刻（QPC） */
#include <math.h>

#include "pybook_rt.h"
#include <SDL2/SDL.h>

/* ---- pybook_rt.c 跨文件提供 ---- */
extern int           game_text_width(const char *s, int px);
extern int           game_text_advance(const char *s, int px);
extern const char   *game_take_text(void);
extern int           game_take_backspace(void);
extern SDL_Renderer *game_renderer(void);
extern int           game_height(void);
/* 贴图（stb_image 解码 + 缓存，实现在 pybook_rt.c）。
   拿到的纹理用 game_renderer() 直接 RenderCopy —— 离屏模式下那个渲染器
   就是绑到 ARGB8888 surface 的软件渲染器，所以 2D 窗口和 3D 同屏共用这一条路。 */
extern SDL_Texture  *game_img_tex_pub(const char *path, int *w, int *h);
/* 切到/切回等宽中文字体（字符网格风格要用，见 pybook_rt.c 里的实测记录） */
extern int           rt_game_font_mono(int on);

/* ⚠ rt_die 是 pybook_rt.c 的 static，这里拿不到 —— 自带一份报错出口。
   退出码 1，跟 PYbook 其它运行时错误一致。 */
static void ui_die(const char *fmt, ...)
{
    va_list ap;
    va_start(ap, fmt);
    fflush(stdout);
    fputs("ui 错误：", stderr);
    vfprintf(stderr, fmt, ap);
    fputc('\n', stderr);
    va_end(ap);
    exit(1);
}

/* ---- PYbook 深色终端风配色 ----
   用结构体而不是多值宏：宏在 `a ? C_X : C_Y` 这种三元里没法正确展开。

   ★ 2026-08 视觉升级重排了明度阶梯。原来只有「底 / 控件」两级深色，
     控件和它下面的东西一样黑，所以无论加多少边框都读不出层次 ——
     这才是「没有阴影、原边」的根因：不是没画阴影，是**没地方放阴影**。
     现在按「离眼睛越近越亮」排成一条阶梯：
        窗底 11 → 面板 18 → 控件 30 → 悬停 42
     阴影落在控件与面板之间的那 12 级差里，才看得见。 */
typedef struct { int r, g, b; } UiCol;

static const UiCol COL_BG     = {  11,  14,  20 };   /* #0B0E14 窗底 */
static const UiCol COL_SURF   = {  18,  23,  31 };   /* 分组面板（ui.分组 画的底） */
static const UiCol COL_PANEL  = {  30,  38,  50 };   /* 控件底 */
static const UiCol COL_PANEL2 = {  42,  53,  69 };   /* 悬停 */
static const UiCol COL_TRACK  = {  24,  31,  41 };   /* 滑条轨道 / 表头（比控件低，凹陷感） */
static const UiCol COL_BORDER = {  52,  63,  82 };   /* 容器边框 */
static const UiCol COL_LINE   = {  74,  88, 112 };   /* 控件描边：比填充亮一档，当高光用 */
static const UiCol COL_SHADOW = {   0,   0,   0 };   /* 投影（靠 alpha 出效果，见 SH_*） */
static const UiCol COL_TEXT   = { 232, 237, 244 };   /* #E8EDF4 正文 */
static const UiCol COL_DIM    = { 138, 149, 167 };   /* 次要文字 */
static const UiCol COL_ACCENT = {  53, 224, 122 };   /* #35E07A 主色 */
static const UiCol COL_PURPLE = { 154, 140, 245 };   /* #9A8CF5 辅色 */
static const UiCol COL_ZEBRA  = {  22,  28,  37 };   /* 表格斑马纹 */

/* 投影强度：深色底上黑影子很弱，alpha 必须给足（160 约等于面板再暗四成） */
#define SH_CTRL 150          /* 控件 */
#define SH_PANEL 90          /* 分组面板：面积大，压太狠会糊 */
#define SH_SOFT  60

enum { UI_COL = 0, UI_ROW = 1 };

#define UI_DEPTH 16

typedef struct {
    int      dir;        /* UI_COL 竖排 / UI_ROW 横排 */
    int      x, y, w, h; /* 容器矩形 */
    int      cx, cy;     /* 光标：下一个控件的左上角 */
    unsigned hash;       /* 容器 id 哈希，给子控件生成稳定 id */
    int      seq;        /* 本容器内已放置的控件数 */
    unsigned grp_id;     /* ui.分组 的序号 + 1，0 = 普通容器 */
    int      pad_v;      /* 分组容器额外留出的上下内边距 */
} UiBox;

static UiBox g_st[UI_DEPTH];
static int   g_depth = 0;

static int g_pad     = 8;    /* 控件间距 */
static int g_ctrl_h  = 32;   /* 控件默认高 */
static int g_font_px = 16;   /* 默认字号 */

/* ---- 每帧的输入快照（ui.begin 时采一次，控件共用） ---- */
static int g_mx = 0, g_my = 0;
static int g_click = 0;      /* 本帧左键刚按下（边沿） */
static int g_down  = 0;      /* 左键按住中 */

/* ---- 无头测试注入钩子 ----
   鼠标位置取自 SDL_GetMouseState（真实 OS 光标），按键状态也取自真实物理按键，
   所以「点一下按钮」这件事在 CI / 截图探针里没法合成事件（引擎不读事件队列）。
   这个钩子让探针在 rt_ui_begin 之前覆写本帧快照。

   【2026-08 改动】原来是"故意不注册进 LIB_C_NAMES，PYbook 调不到，只有直接
   链接 .o 的 C 探针能用"。但这个限制本身就是问题：PYbook 代码里没法表达
   "第 3 帧把鼠标挪到 (120,180) 并点一下"，于是 ui.* 的**交互**永远只能靠人
   手点窗口验证，改一行布局/状态机也没有回归可跑 —— 而 UI 引擎真正会坏的地方
   恰恰是交互（hover 判定、边沿 vs 电平、跨帧状态），不是绘制。
   现在注册成 `ui.测试输入(x, y, 点击, 按住)`，见下面的 rt_ui_test_input。 */
static int g_tx = 0, g_ty = 0, g_tclick = 0, g_tdown = 0, g_tforce = 0;

void ui_test_input(int x, int y, int click, int down)
{
    g_tx = x; g_ty = y; g_tclick = click; g_tdown = down; g_tforce = 1;
}

void ui_test_input_reset(void)
{
    g_tforce = 0;
}

/* rt_ui_test_input / rt_ui_test_input_reset 这两个绑定包装不能放这儿：
   它们要用 ui_num()，而 ui_num 定义在文件中部（控件状态表之后），
   放在前面会撞 implicit declaration。已挪到「对外 API」区。 */

/* ---- 控件状态表（跨帧记忆） ---- */
#define UI_STATE_MAX 256
typedef struct {
    unsigned id;
    char    *text;      /* 输入框文本 */
    double   num;       /* 滑条值 / 勾选值 */
    int      init;      /* 已用外部值初始化过 */
} UiState;

static UiState  g_state[UI_STATE_MAX];
static int      g_state_n = 0;
static unsigned g_focus = 0;     /* 当前获得键盘输入的控件 id */
static unsigned g_tag   = 0;     /* ui.tag 设的下一个 id（用一次即清） */

/* ---------------- 小工具 ---------------- */

static char *ui_dup(const char *s)
{
    if (s == NULL)
        s = "";
    size_t n = strlen(s) + 1;
    char *p = (char *)malloc(n);
    if (p == NULL)
        ui_die("内存不足");
    memcpy(p, s, n);
    return p;
}

static double ui_num(Value v, const char *who)
{
    if (IS_FLT(v))
        return AS_FLT(v);
    if (IS_INT(v) || IS_BIGINT(v))
        return (double)rt_to_ll(v);
    if (IS_BOOL(v))
        return (double)AS_BOOL(v);
    ui_die("%s 需要数字参数", who);
    return 0;
}

static const char *ui_str(Value v)
{
    return rt_str_of(v);
}

/* 稳定 id：ui.tag 优先，否则按容器内序号 */
static unsigned ui_id(void)
{
    if (g_tag != 0) {
        unsigned t = g_tag;
        g_tag = 0;
        return t;
    }
    UiBox *c = &g_st[g_depth - 1];
    c->seq++;
    return c->hash * 131u + (unsigned)c->seq;
}

static unsigned ui_hash(const char *s)
{
    unsigned h = 2166136261u;
    for (const unsigned char *p = (const unsigned char *)s; *p; p++) {
        h ^= *p;
        h *= 16777619u;
    }
    return h ? h : 1u;      /* 0 留给「没设 tag」 */
}

static UiState *ui_state(unsigned id)
{
    for (int i = 0; i < g_state_n; i++)
        if (g_state[i].id == id)
            return &g_state[i];
    if (g_state_n >= UI_STATE_MAX)
        return &g_state[UI_STATE_MAX - 1];   /* 满了就复用最后一条：退化但不崩 */
    UiState *s = &g_state[g_state_n++];
    memset(s, 0, sizeof *s);
    s->id   = id;
    s->text = ui_dup("");
    return s;
}

/* ---- 绘制 ---- */

static void ui_text(int x, int y, const char *s, int px, UiCol c);   /* 前置声明 */

/* ================= 字符边框风格（TUI 风）=================
 *
 * 用户要的是"由字母（字符）组成的边框"，不是圆角矩形。两种风格都留着：
 *   ui.样式("圆角")  默认，上一版那套抗锯齿圆角 + 投影
 *   ui.样式("字符")  终端风，全部控件贴到字符网格上
 *
 * 为什么能连起来：实测（微软雅黑，16px）┌ ─ │ ┐ 的步进**全是 14px**，
 * 和拉丁字母 A 同宽，不是全角。所以横排直接重复同一个字符就能首尾相接，
 * 不用去凑格子宽度 —— 前提是别逐字画，要一次 text() 画一整条。
 *
 * 网格步进：横向 = "─" 的步进 aw，纵向 = 字号 ah（行高）。
 * 格不是方的（14×16），这正好跟普通文本的行布局一致。
 */
static int g_style  = 0;       /* 0 = 圆角实心；1 = 字符边框 */
static int g_aw     = 0;       /* 字符格横向步进 */
static int g_ah     = 16;      /* 字符格纵向步进（= 一行文本高） */

/* 布局常量随风格走：字符风一切贴网格，行高 = 一格、控件间距 = 一格 */
static int ui_pad(void)  { return g_style ? g_ah : g_pad; }
static int ui_chgt(void) { return g_style ? g_ah : g_ctrl_h; }

static int ui_cols(int textw);      /* 定义在 ui_ch_frame 后面，这里先挂个前向声明 */

static int ui_aw_get(void)
{
    if (g_aw <= 0)
        g_aw = game_text_advance("─", g_font_px);   /* 真实步进，不是排版宽度 */
    if (g_aw < 4)
        g_aw = 4;
    return g_aw;
}

/* 横向连画 n 个同字符：一次 text() 搞定。
   逐字画不但慢十几倍，还会在字与字之间留缝。 */
static void ui_rep(int x, int y, int n, const char *g, UiCol c)
{
    if (n <= 0)
        return;
    char buf[3 * 160 + 1];
    int len = (int)strlen(g), k = 0;
    if (len <= 0 || len > 3)
        return;
    if (n > 160)
        n = 160;
    for (int i = 0; i < n; i++) {
        memcpy(buf + k, g, (size_t)len);
        k += len;
    }
    buf[k] = '\0';
    ui_text(x, y, buf, g_font_px, c);
}

/* 纵向连画 n 个同字符（每个占一格行高） */
static void ui_rep_v(int x, int y, int n, const char *g, UiCol c)
{
    for (int i = 0; i < n; i++)
        ui_text(x, y + i * g_ah, g, g_font_px, c);
}

/* 字符边框：cols × rows 格的框，标题（可空）嵌在上边。
   这是"由字符组成的边框"这件事的全部基本功，其余控件都是它的拼法。 */
static void ui_ch_frame(int x, int y, int cols, int rows,
                        const char *title, UiCol c)
{
    int aw = ui_aw_get();
    if (cols < 2 || rows < 2)
        return;
    int rx = x + (cols - 1) * aw;
    int by = y + (rows - 1) * g_ah;
    ui_text(x,  y, "┌", g_font_px, c);
    ui_text(rx, y, "┐", g_font_px, c);
    ui_text(x,  by, "└", g_font_px, c);
    ui_text(rx, by, "┘", g_font_px, c);

    /* 上下横边。**两边的起点不一样**：上边中间嵌标题，要绕开；
       下边没有标题，整条填满。早先两边共用同一个 used 偏移，
       于是下边框也从标题末尾才开始，左下角空一大截（实测偏 9 格）。 */
    int used = 1;                       /* 上边已占格数（含左上角） */
    if (title != NULL && title[0] != '\0') {
        char t[160];
        snprintf(t, sizeof t, " %s ", title);
        int tcols = ui_cols(game_text_advance(t, g_font_px));
        if (3 + tcols <= cols) {        /* 左角 + 一格 ─ + 标题 + 余量 */
            ui_text(x + aw, y, "─", g_font_px, c);
            ui_text(x + 2 * aw, y, t, g_font_px, c);
            used = 2 + tcols;
        }
    }
    if (cols - 1 - used > 0)
        ui_rep(x + used * aw, y, cols - 1 - used, "─", c);
    if (cols - 2 > 0)
        ui_rep(x + aw, by, cols - 2, "─", c);
    ui_rep_v(x,  y + g_ah, rows - 2, "│", c);
    ui_rep_v(rx, y + g_ah, rows - 2, "│", c);
}

/* 填进 n 列需要几格：文本宽 / 步进，向上取整 */
static int ui_cols(int textw)
{
    int aw = ui_aw_get();
    return (textw + aw - 1) / aw;
}

/* 往字符缓冲里追加一段（拼 ┌─┬─┐ 这种横线用）。
   每个制表符 3 字节，一次画一条横边，别用 strcat 逐个拼。 */
static char *chput(char *p, const char *s)
{
    int n = (int)strlen(s);
    memcpy(p, s, (size_t)n);
    return p + n;
}

/* 填充（带 alpha 版）。UI 帧内 blend 模式是 BLEND（rt_ui_begin 设的），
   所以 alpha 真的生效 —— 默认的 SDL_BLENDMODE_NONE 会把它当不透明。 */
static void ui_fill_a(int x, int y, int w, int h, UiCol c, int a)
{
    SDL_Renderer *ren = game_renderer();
    if (ren == NULL || w <= 0 || h <= 0 || a <= 0)
        return;
    if (a > 255)
        a = 255;
    SDL_SetRenderDrawColor(ren, (Uint8)c.r, (Uint8)c.g, (Uint8)c.b, (Uint8)a);
    SDL_Rect rc;
    rc.x = x; rc.y = y; rc.w = w; rc.h = h;
    SDL_RenderFillRect(ren, &rc);
}

static void ui_fill(int x, int y, int w, int h, UiCol c)
{
    ui_fill_a(x, y, w, h, c, 255);
}

/* ---- 抗锯齿圆角（2026-08 视觉升级新增）----

   原来所有控件都是 SDL_RenderFillRect 的硬边矩形 + 四条 1px 实线，
   在 45° 斜角上必然是台阶 —— 这就是「原边 + 像素化」的全部来源。

   做法不是上 MSAA（SDL_RenderSetLogicalSize 那套对 FillRect 无效，
   而逐图元走 SDL_RenderGeometry 又得把整个 UI 重写成三角形），
   而是**只在 4 个 r×r 的角区逐像素按覆盖率画**，中间三条矩形照旧批量填。
   一个 200×32 的控件多花 ~150 次 DrawPoint（实测十几微秒），
   60 帧下无感，换来斜边干净、圆角顺滑。

   覆盖率用解析式而不是 4×4 超采样：
       像素中心 (px+0.5, py+0.5) 到圆心的距离 d，
       它被半径 r 的圆盘盖住的比例 = clamp(r + 0.5 - d, 0, 1)。
   过渡带正好 1 像素宽，误差小于 1/256，肉眼看不出台阶。 */
static int ui_cov(int px, int py, int cx, int cy, int r)
{
    float dx = (float)px + 0.5f - (float)cx;
    float dy = (float)py + 0.5f - (float)cy;
    float d  = sqrtf(dx * dx + dy * dy);
    float c  = (float)r + 0.5f - d;
    if (c <= 0.0f)
        return 0;
    if (c >= 1.0f)
        return 255;
    return (int)(c * 255.0f + 0.5f);
}

/* 半透明单像素（覆盖率 → alpha 再乘整体强度） */
static void ui_px_cov(int px, int py, int cx, int cy, int r, UiCol c, int a)
{
    if (a <= 0)
        return;
    int cov = ui_cov(px, py, cx, cy, r);
    if (cov <= 0)
        return;
    SDL_Renderer *ren = game_renderer();
    if (ren == NULL)
        return;
    SDL_SetRenderDrawColor(ren, (Uint8)c.r, (Uint8)c.g, (Uint8)c.b,
                           (Uint8)((cov * a + 127) / 255));
    SDL_RenderDrawPoint(ren, px, py);
}

/* 四角矩形：圆角位 = fl(1=左上 2=右上 4=左下 8=右下)，不圆的那几个照样铺满 */
static void ui_corners(int x, int y, int w, int h, int r, UiCol c, int a, int fl)
{
    int j, i;
    if (fl & 1) {
        for (j = 0; j < r; j++)
            for (i = 0; i < r; i++)
                ui_px_cov(x + i, y + j, x + r, y + r, r, c, a);
    } else
        ui_fill_a(x, y, r, r, c, a);
    if (fl & 2) {
        int cx = x + w - r;
        for (j = 0; j < r; j++)
            for (i = 0; i < r; i++)
                ui_px_cov(cx + i, y + j, cx, y + r, r, c, a);
    } else
        ui_fill_a(x + w - r, y, r, r, c, a);
    if (fl & 4) {
        int cy = y + h - r;
        for (j = 0; j < r; j++)
            for (i = 0; i < r; i++)
                ui_px_cov(x + i, cy + j, x + r, cy, r, c, a);
    } else
        ui_fill_a(x, y + h - r, r, r, c, a);
    if (fl & 8) {
        int cx = x + w - r, cy = y + h - r;
        for (j = 0; j < r; j++)
            for (i = 0; i < r; i++)
                ui_px_cov(cx + i, cy + j, cx, cy, r, c, a);
    } else
        ui_fill_a(x + w - r, y + h - r, r, r, c, a);
}

/* 圆角实心（带 alpha、可选只圆某几个角）。三条主体互不重叠，
   所以半透明时也不会在接缝上二次混合。 */
static void ui_round_a(int x, int y, int w, int h, int r, UiCol c, int a, int fl)
{
    if (w <= 0 || h <= 0 || a <= 0)
        return;
    if (game_renderer() == NULL)
        return;
    int rr = r;
    if (rr > w / 2)
        rr = w / 2;
    if (rr > h / 2)
        rr = h / 2;
    if (rr <= 0) {
        ui_fill_a(x, y, w, h, c, a);
        return;
    }
    ui_fill_a(x, y + rr, w, h - 2 * rr, c, a);          /* 贯通横带 */
    ui_fill_a(x + rr, y, w - 2 * rr, rr, c, a);         /* 上下窄带 */
    ui_fill_a(x + rr, y + h - rr, w - 2 * rr, rr, c, a);
    ui_corners(x, y, w, h, rr, c, a, fl);
}

#define UIRC_ALL 15
static void ui_round(int x, int y, int w, int h, int r, UiCol c)
{
    ui_round_a(x, y, w, h, r, c, 255, UIRC_ALL);
}

/* 把四角「圆角矩形以外」的那一小块涂回底色。
   场景：表格的行是矩形，铺到容器边角时会盖掉圆角（方角行穿出圆弧）。
   不能靠留空带解决 —— 那要吃掉 8+8 像素表格高度。
   办法是在行画完之后，按**反向覆盖率**（1 - 圆内占比）把底色混回去：
   圆弧内的像素覆盖率 1 → 一个底色都不混（行色原样保留），
   圆弧外覆盖率 0 → 全部换成底色，过渡带自然接上。 */
static void ui_corner_cut(int x, int y, int w, int h, int r, UiCol c)
{
    if (r <= 0 || game_renderer() == NULL)
        return;
    SDL_Renderer *ren = game_renderer();
    int j, i;
    for (int k = 0; k < 4; k++) {
        int ox = (k & 1) ? x + w - r : x;
        int oy = (k & 2) ? y + h - r : y;
        int cx = (k & 1) ? x + w - r : x + r;
        int cy = (k & 2) ? y + h - r : y + r;
        for (j = 0; j < r; j++) {
            for (i = 0; i < r; i++) {
                int cov = ui_cov(ox + i, oy + j, cx, cy, r);
                if (cov >= 255)
                    continue;
                SDL_SetRenderDrawColor(ren, (Uint8)c.r, (Uint8)c.g, (Uint8)c.b,
                                       (Uint8)(255 - cov));
                SDL_RenderDrawPoint(ren, ox + i, oy + j);
            }
        }
    }
}

/* 1px 圆角描边：**画在内容之上**。
   嵌套圆角实心那套（ui_ctrl_box 用的）便宜，但只能垫在底下 ——
   表格没表头时行是直接铺到容器顶边的，方角会把容器的圆角盖掉，
   于是"圆角表格"在无表头时露出两个直角。描边放最后画就没事。
   四条直边用批量填充，四个角算「外圆覆盖率 − 内圆(r-1)覆盖率」。 */
static void ui_round_stroke(int x, int y, int w, int h, int r, UiCol c)
{
    if (w <= 2 || h <= 2)
        return;
    int rr = r;
    if (rr > w / 2) rr = w / 2;
    if (rr > h / 2) rr = h / 2;
    if (rr <= 0) {
        ui_fill(x, y, w, 1, c);
        ui_fill(x, y + h - 1, w, 1, c);
        ui_fill(x, y, 1, h, c);
        ui_fill(x + w - 1, y, 1, h, c);
        return;
    }
    ui_fill(x + rr, y, w - 2 * rr, 1, c);
    ui_fill(x + rr, y + h - 1, w - 2 * rr, 1, c);
    ui_fill(x, y + rr, 1, h - 2 * rr, c);
    ui_fill(x + w - 1, y + rr, 1, h - 2 * rr, c);

    SDL_Renderer *ren = game_renderer();
    if (ren == NULL)
        return;
    int j, i, a1, a2;
    for (j = 0; j < rr; j++) {
        for (i = 0; i < rr; i++) {
            int xs[4] = { x + i, x + w - rr + i, x + i, x + w - rr + i };
            int ys[4] = { y + j, y + j, y + h - rr + j, y + h - rr + j };
            int cs[4] = { x + rr, x + w - rr, x + rr, x + w - rr };
            int ct[4] = { y + rr, y + rr, y + h - rr, y + h - rr };
            for (int k = 0; k < 4; k++) {
                a1 = ui_cov(xs[k], ys[k], cs[k], ct[k], rr);
                a2 = ui_cov(xs[k], ys[k], cs[k], ct[k], rr - 1);
                if (a1 > a2) {
                    SDL_SetRenderDrawColor(ren, (Uint8)c.r, (Uint8)c.g, (Uint8)c.b,
                                           (Uint8)(a1 - a2));
                    SDL_RenderDrawPoint(ren, xs[k], ys[k]);
                }
            }
        }
    }
}

/* ★ 控件三件套：下方投影 + 圆角本体 + 比填充亮一档的圆角描边。
   三条缺一不可：
     · 只画阴影 —— 深色底上黑影子几乎不可见（底 #0B0E14 已经很黑）
     · 只画描边 —— 还是平的，没有厚度
     · 只画描边+填充 —— 有边框了，但控件像贴纸一样浮在上面
   描边用「外圈圆角实心 + 内缩 1px 圆角实心」实现，比逐像素算圆环覆盖率
   便宜得多，边缘同样是抗锯齿的过渡带。 */
static void ui_ctrl_box(int x, int y, int w, int h, int r,
                        UiCol fill, UiCol line, int shadow)
{
    if (w <= 2 || h <= 2)
        return;
    if (shadow > 0)
        ui_round_a(x, y + 2, w, h, r, COL_SHADOW, shadow, UIRC_ALL);
    ui_round(x, y, w, h, r, line);
    ui_round(x + 1, y + 1, w - 2, h - 2, r - 1, fill);
}

/* 分隔线（表格表头下沿、分组标题右边的横线） */
static void ui_hline(int x, int y, int w, UiCol c)
{
    ui_fill(x, y, w, 1, c);
}

/* 任意方向粗线（**抗锯齿**）。
   原来是 Bresenham 逐点铺 t×t 方块：斜边是阶梯状的，
   复选框那个 10 像素长的对勾一眼就能看出锯齿。
   现在按「像素中心到线段的距离 < 半宽即覆盖」算，覆盖率 = 半宽 + 0.5 - d。
   一个 t=3、长 14 的对勾只扫 17×9 = 153 个像素，比铺方块还少。 */
static void ui_line(int x0, int y0, int x1, int y1, int t, UiCol c)
{
    SDL_Renderer *ren = game_renderer();
    if (ren == NULL || t <= 0)
        return;
    float ax = (float)x0 + 0.5f, ay = (float)y0 + 0.5f;
    float bx = (float)x1 + 0.5f, by = (float)y1 + 0.5f;
    float dx = bx - ax, dy = by - ay;
    float len2 = dx * dx + dy * dy;
    float hw = (float)t * 0.5f;
    int m = t;
    int xa = (x0 < x1 ? x0 : x1) - m, xb = (x0 > x1 ? x0 : x1) + m;
    int ya = (y0 < y1 ? y0 : y1) - m, yb = (y0 > y1 ? y0 : y1) + m;
    for (int py = ya; py <= yb; py++) {
        for (int px = xa; px <= xb; px++) {
            float fx = (float)px + 0.5f - ax;
            float fy = (float)py + 0.5f - ay;
            float u  = (len2 > 0.0f) ? (fx * dx + fy * dy) / len2 : 0.0f;
            if (u < 0.0f) u = 0.0f;
            if (u > 1.0f) u = 1.0f;
            float ex = fx - u * dx, ey = fy - u * dy;
            float d  = sqrtf(ex * ex + ey * ey);
            float cv = hw + 0.5f - d;
            if (cv <= 0.0f)
                continue;
            int a = (cv >= 1.0f) ? 255 : (int)(cv * 255.0f + 0.5f);
            SDL_SetRenderDrawColor(ren, (Uint8)c.r, (Uint8)c.g, (Uint8)c.b, (Uint8)a);
            SDL_RenderDrawPoint(ren, px, py);
        }
    }
}

static void ui_text(int x, int y, const char *s, int px, UiCol c)
{
    if (s == NULL || s[0] == '\0')
        return;
    rt_game_color(rt_int(c.r), rt_int(c.g), rt_int(c.b));
    rt_game_text(rt_int(x), rt_int(y), rt_str(s), rt_int(px));
}

static int ui_in(int x, int y, int w, int h)
{
    return g_mx >= x && g_mx < x + w && g_my >= y && g_my < y + h;
}

/* ---- 控件矩形回读（2026-08 新增）----
   为什么需要：交互测试总得知道"「确定」按钮在哪"才能把鼠标点过去。
   在这个能力出现之前只能**看着截图量像素**，而坐标会随字号/文案/间距/容器宽度
   一起变 —— 改一行布局，测试就悄悄点空了，而且它不会报错，只是"没反应"。
   实测就栽在这：量的是另一个布局的图，y 偏了 45 像素，复选框点了空气。

   现在 ui.tag("名字") 钉住的那个控件，它的矩形会被记下来，
   下一帧用 ui.矩形("名字") 读回 [x, y, w, h]，测试自己算出该点哪儿：
       vg.r = ui.矩形("确定")
       ui.测试输入(r[0] + r[2] / 2, r[1] + r[3] / 2, 1, 1)
   布局怎么改都不用改测试 —— 这才是探针该干的事，不是人肉干的活。 */
#define UI_RECT_MAX 64
typedef struct {
    char name[32];
    int  x, y, w, h;
    int  frame;          /* 最近一次更新时的帧号 */
} UiRect;
static UiRect g_rects[UI_RECT_MAX];
static int    g_rect_n   = 0;
static int    g_frame_ui = 0;    /* rt_ui_begin 每帧 ++ */
static char   g_tag_name[32] = "";  /* ui.tag 钉的名字，只对下一个控件生效 */

/* ---- ui.分组 的面板高度缓存 ----
   立即模式有个先天麻烦：面板要垫在子控件底下，可只有等 ui.end 才知道多高。
   办法是记上一帧的量，逐帧修正（面板纯装饰，不参与布局，晚一帧无感）。

   ★ 键必须是「本帧第几个 ui.分组」，不能用容器 hash —— 实测踩过：
     多列布局里每一列的根容器 hash 都是 0（ui.begin 都把 hash 清零），
     于是左列第 1 个分组和右列第 1 个分组拿到同一个 id，互相把对方的高度
     当成自己的画：日志里「播放控制」画成 274（那是「图元清单」的高度），
     「图元清单」画成 140，两列各画各的宽度却套着对方的高度。
     调用序号在脚本结构不变时逐帧稳定，跟引擎给其它控件算 id 的假设同源。 */
#define UI_GRP_MAX 32
static int g_grp_h[UI_GRP_MAX];      /* 按调用序号存上一帧量到的面板高，0 = 还没量过 */
static int g_grp_slot = 0;           /* 本帧 ui.分组 的调用序号 */

/* ---- ui.序列 的起始时刻 ----
   序列要知道自己「第几帧」，就得记住起点。起点不能按容器 hash 找
   —— 同一个序列在同一位置逐帧稳定，容器 hash 够用；但多列布局里
   每列根容器 hash 都是 0（同 g_grp_slot 的坑），所以跟 ui.分组 一样
   改用「本帧第几个 ui.序列」当键。
   ★ 时钟用 SDL_GetPerformanceCounter 而不是 tm.now()：
     后者是 GetTickCount64，**分辨率 15.625ms**（pybook_lib.c 的 rt_lib_tm_now），
     而序列帧时长常见 30~100ms —— 用它会一格跳两帧，动画肉眼可见地卡。
     QPC 是纳秒级，够用。 */
#define UI_SEQ_MAX 32
static uint64_t g_seq_t0[UI_SEQ_MAX];    /* 各槽位的起始时刻，0 = 还没起播 */
static int      g_seq_slot = 0;          /* 本帧 ui.序列 的调用序号 */
/* ui.粒子 的区序号，同一个理由（多列里容器 hash 都是 0）。定义放这儿是因为
   rt_ui_new_frame() 在前面要清它 —— C 不允许后置定义，池子在后面才实现。 */
static int      g_fx_slot = 0;           /* 本帧 ui.粒子 的调用序号 */

/* 一帧开始了（由 pybook_rt.c 的 rt_game_show 在每帧末尾调）。
   ★ 为什么必须挂在这里、而不是 ui.begin 里清零：一帧里可以有多列
     （demo 就是 ui.begin 两次），在 ui.begin 清零会让第二列从头数，
     于是左右两列的第 1 个分组撞在同一个槽上互相套高度 ——
     实测「播放控制」画成 274（那是「图元清单」的高）、「图元清单」画成 140。
     ★ ui.序列 的槽位同理：第二列的序列会抢第一列的起始时刻，
       两套动画一起跳帧。 */
void rt_ui_new_frame(void)
{
    g_grp_slot = 0;
    g_seq_slot = 0;
    g_fx_slot = 0;
}

/* ---------------- 布局 ---------------- */

/* 在光标处占一块地，返回实际矩形。竖排时宽度撑满容器。
   所有控件都走这里，所以"记矩形"只需要在这一处埋点。 */
static void ui_rect(int w, int h, int *ox, int *oy, int *ow, int *oh)
{
    UiBox *c = &g_st[g_depth - 1];
    *ox = c->cx;
    *oy = c->cy;
    *ow = (c->dir == UI_COL) ? c->w : w;
    *oh = h;
    /* ui.tag("名") 只钉住紧随其后的那一个控件：用掉就清空 */
    if (g_tag_name[0] != '\0') {
        int i;
        for (i = 0; i < g_rect_n; i++)
            if (strcmp(g_rects[i].name, g_tag_name) == 0)
                break;
        if (i == g_rect_n) {
            if (g_rect_n < UI_RECT_MAX)
                g_rect_n++;
            else
                i = 0;                 /* 表满：覆盖第一条，宁可错也不崩 */
        }
        snprintf(g_rects[i].name, sizeof g_rects[i].name, "%s", g_tag_name);
        g_rects[i].x = *ox; g_rects[i].y = *oy;
        g_rects[i].w = *ow; g_rects[i].h = *oh;
        g_rects[i].frame = g_frame_ui;
        g_tag_name[0] = '\0';
    }
}

static void ui_advance(int w, int h)
{
    UiBox *c = &g_st[g_depth - 1];
    if (c->dir == UI_COL) {
        c->cy += h + ui_pad();
    } else {
        c->cx += w + ui_pad();
        if (h > c->h)
            c->h = h;                        /* 行内高度取最大 */
    }
}

/* ---------------- 对外 API ---------------- */

/* ui.测试输入(x, y, 点击, 按住)：覆写**本帧**的输入快照。
   必须在 ui.begin 之前调用（ui.begin 每帧采一次快照，设晚了不起作用）。
   点击 = 本帧左键边沿（相当于真实的一次按下），按住 = 左键当前是否压着。
   分帧脚本化一段交互：
       帧 1  ui.测试输入(51, 145, 1, 1)   点「确定」
       帧 2  ui.测试输入(51, 145, 0, 0)   松开（不给边沿，按钮不会连点）
   两次注入之间一定要夹一帧「点击=0 按住=0」—— 这本身就是对控件
   "按下/松开配对"的检验。
   要交回真实鼠标/键盘就调 ui.测试输入恢复()。 */
Value rt_ui_test_input(Value xv, Value yv, Value cv, Value dv)
{
    ui_test_input((int)ui_num(xv, "ui.测试输入 的 x"),
                  (int)ui_num(yv, "ui.测试输入 的 y"),
                  ui_num(cv, "ui.测试输入 的 点击") != 0.0 ? 1 : 0,
                  ui_num(dv, "ui.测试输入 的 按住") != 0.0 ? 1 : 0);
    return rt_none();
}

/* ui.测试输入恢复()：交回真实鼠标 / 键盘。 */
Value rt_ui_test_input_reset(void)
{
    ui_test_input_reset();
    return rt_none();
}

/* ui.begin(x, y, w)：每帧开一次，重置布局并把光标放到 (x, y)。
   之后所有 ui.* 都活在这个根容器里（竖排）。 */
Value rt_ui_begin(Value xv, Value yv, Value wv)
{
    int x = (int)ui_num(xv, "ui.begin 的 x");
    int y = (int)ui_num(yv, "ui.begin 的 y");
    int w = (int)ui_num(wv, "ui.begin 的宽");
    if (w < 8)
        w = 8;

    /* 每帧采一次输入快照：mhit 是「本帧边沿」，多次调用只会翻页一次 */
    g_frame_ui++;                 /* 控件矩形回读用的帧号 */
    g_tag_name[0] = '\0';         /* ui.tag 只对紧随其后的一个控件生效，跨帧不留 */
    /* 分组槽位**不**在这里清零：一帧可以有多列，清了会串。见 rt_ui_new_frame。 */
    /* 抗锯齿圆角 / 投影靠 alpha 混合。SDL2 渲染器默认是 BLENDMODE_NONE，
       alpha 会被直接丢掉（全当不透明），所以这里显式切到 BLEND，
       根容器 ui.end 收尾时再还原 —— pybook_rt.c 的 game.* 图元是按
       不透明绘制的，不能被 UI 顺手改成半透明叠加。 */
    {
        SDL_Renderer *ren0 = game_renderer();
        if (ren0 != NULL)
            SDL_SetRenderDrawBlendMode(ren0, SDL_BLENDMODE_BLEND);
    }
    if (g_tforce) {
        g_mx    = g_tx;
        g_my    = g_ty;
        g_click = g_tclick;
        g_down  = g_tdown;
    } else {
        g_mx    = (int)rt_to_ll(rt_game_mx());
        g_my    = (int)rt_to_ll(rt_game_my());
        g_click = rt_to_ll(rt_game_mhit()) ? 1 : 0;
        g_down  = rt_to_ll(rt_game_mdown()) ? 1 : 0;
    }

    g_depth     = 1;                 /* 根容器常驻，ui.end 收到 0 才结束这一帧 */
    g_tag       = 0;                 /* 每帧重置：上一帧没人消费的 tag 不许漏到这一帧 */
    g_st[0].dir = UI_COL;
    g_st[0].x   = x;
    g_st[0].y   = y;
    g_st[0].w   = w;
    g_st[0].h   = game_height() - y - 20;
    if (g_st[0].h < 8)
        g_st[0].h = 8;
    g_st[0].cx   = x;
    g_st[0].cy   = y;
    g_st[0].hash = 0;
    g_st[0].seq  = 0;
    g_st[0].grp_id = 0;
    g_st[0].pad_v  = 0;
    return rt_none();
}

/* ui.row() / ui.col()：压入一个横排 / 竖排容器 */
static void ui_push(int dir)
{
    if (g_depth >= UI_DEPTH)
        ui_die("容器嵌套超过 %d 层", UI_DEPTH);
    if (g_depth <= 0)
        ui_die("ui.row / ui.col 必须在 ui.begin 之后调用");
    UiBox *p = &g_st[g_depth - 1];
    UiBox *c = &g_st[g_depth];
    c->dir  = dir;
    c->x    = p->cx;
    c->y    = p->cy;
    c->w    = p->x + p->w - p->cx;          /* 吃掉父容器剩余宽度 */
    if (c->w < 8)
        c->w = 8;
    c->h    = ui_chgt();
    c->cx   = c->x;
    c->cy   = c->y;
    c->hash = p->hash * 131u + (unsigned)(p->seq + 1);
    c->seq  = 0;
    c->grp_id = 0;
    c->pad_v  = 0;
    g_depth++;
}

Value rt_ui_row(void) { ui_push(UI_ROW); return rt_none(); }
Value rt_ui_col(void) { ui_push(UI_COL); return rt_none(); }

Value rt_ui_end(void)
{
    if (g_depth <= 0)
        ui_die("ui.end：没有可结束的容器（ui.begin / ui.row / ui.col 要与 ui.end 配对）");
    UiBox *c = &g_st[g_depth - 1];
    int used_w = (c->dir == UI_ROW) ? (c->cx - c->x - ui_pad()) : c->w;
    int used_h = (c->dir == UI_COL) ? (c->cy - c->y - ui_pad()) : c->h;
    if (used_w < 0) used_w = 0;
    if (used_h < 0) used_h = 0;
    int adv_h = used_h + c->pad_v;      /* 分组容器的上下内边距算进占位 */

    if (g_depth >= 2) {                      /* 根容器没有父级，不用回写 */
        UiBox *p = &g_st[g_depth - 2];
        if (p->dir == UI_COL)
            p->cy = c->y + adv_h + ui_pad();
        else
            p->cx = c->x + used_w + ui_pad();
        p->seq++;
    }
    /* ui.分组 的面板高度缓存：面板要画在子控件**底下**，
       可 ui.end 才知道有多高（立即模式没有"回头补画"的机会）。
       所以用上一帧量到的高度画底，下一帧就准了 ——
       面板只是装饰，不参与布局，所以晚一帧没人看得出来。 */
    if (c->grp_id != 0) {
        int s = (int)c->grp_id - 1;          /* 存的是序号 + 1，0 = 不是分组 */
        if (s >= 0 && s < UI_GRP_MAX)
            g_grp_h[s] = adv_h + c->pad_v;
    }
    g_depth--;
    if (g_depth <= 0) {
        SDL_Renderer *ren0 = game_renderer();   /* 还原成不透明，别影响 game.* */
        if (ren0 != NULL)
            SDL_SetRenderDrawBlendMode(ren0, SDL_BLENDMODE_NONE);
    }
    return rt_none();
}

/* ui.分组(标题)：开一个带标题的小节，到 ui.end 为止的控件都归它管。
 *
 * 为什么补这个：以前整屏控件平铺在窗底上，中间不留任何结构，
 * 看上去就是「一堆字幕浮在黑底上」—— 这正是「字幕化」的由来。
 * 现在每个小节有一块圆角面板（比窗底亮一档）+ 左侧主色竖条 + 标题
 * + 右延伸的分隔线，层次立刻就出来了。
 *
 * 内边距：面板四周比子控件各留 12 / 10 px，不然控件贴着面板边走，挤成一团。
 * 面板高度取上一帧的缓存（原因见 rt_ui_end 的 g_grp_h 那段），所以第一帧
 * 没有底板、第二帧起就有了 —— 60 帧下根本看不见。
 *
 * ★ 「首帧没有底板」和无头出图叠在一起，是个能把人带进沟里的组合（2026-10 踩过）：
 *   pybook_rt.c 的 rt_shot_maybe 是 `if ((g_shot_seen++ % every) != 0) return;`
 *   —— g_shot_seen 从 0 起，所以**第一张图就是第 1 帧**，不是第 `every` 帧。
 *   于是一份同样布局的 UI，跑出 fx_000(帧1，无底板) 和 ui_001(帧7，有底板)，
 *   拿第 1 张去跟第 7 张逐像素比，就得出「2D 窗口模式下分组底板根本没画」的结论 ——
 *   其实底板一直都在，回读那一颗像素是 FF12171F（COL_SURF 不透明）。
 *   比对两张图之前先确认帧号一致：看 ui_000 / ui_001 哪张有底板。
 *   顺带一提 g_grp_slot 由 rt_ui_new_frame() 清零，它原来只挂在 2D 的
 *   rt_game_show() 上；离屏（3D+UI）模式没人调，分组底板就一帧都不画，
 *   现在 pybook_rt.c 的 rt_ui_frame_step() 里补上了。 */
Value rt_ui_group(Value tv)
{
    if (g_depth <= 0)
        ui_die("ui.分组 必须在 ui.begin 之后调用");
    const char *s = ui_str(tv);
    ui_push(UI_COL);

    /* 内边距随风格走：圆角风 12/10 像素；字符风正好 1 格 —— 边框自己就是内边距，
       再多留就等于在框里又套了一层空。 */
    int aw = ui_aw_get();
    int P  = g_style ? aw : 12;
    int PV = g_style ? g_ah : 10;
    UiBox *c = &g_st[g_depth - 1];
    c->x += P;
    c->w -= P * 2;
    if (c->w < 24)
        c->w = 24;
    c->cx    = c->x;
    c->cy    = c->y + PV;
    c->pad_v = PV;
    int slot = g_grp_slot++;
    if (slot >= UI_GRP_MAX)
        slot = UI_GRP_MAX - 1;              /* 分组多到 32 个：复用最后一格，不崩 */
    c->grp_id = (unsigned)slot + 1;

    int px = c->x - P, pw = c->w + P * 2, py = c->y - PV;
    int ph = g_grp_h[slot];
    if (g_style) {
        /* 字符风：标题直接嵌进上边框 ┌─ 播放控制 ─────┐，不另占一行，
           所以内容光标从框下一格开始。 */
        if (ph > 0) {
            int cols = (pw + aw - 1) / aw;
            int rows = ph / g_ah;
            if (cols < 4)  cols = 4;
            if (rows < 2)  rows = 2;
            ui_ch_frame(px, py, cols, rows, s, COL_LINE);
        }
        return rt_none();
    }
    if (ph > 0) {
        ui_round_a(px, py + 3, pw, ph, 10, COL_SHADOW, SH_PANEL, UIRC_ALL);
        ui_ctrl_box(px, py, pw, ph, 10, COL_SURF, COL_BORDER, 0);
    }

    /* 标题行：主色竖条 + 标题 + 右侧分隔线，占掉本容器第一行 */
    int th = g_font_px + 10;
    int bx = c->cx, by = c->cy;
    ui_round(bx, by + 3, 3, th - 6, 2, COL_ACCENT);
    ui_text(bx + 10, by + (th - g_font_px) / 2, s, g_font_px, COL_TEXT);
    int linex = bx + 10 + game_text_width(s, g_font_px) + 10;
    int linew = (c->x + c->w) - linex;
    if (linew > 8)
        ui_hline(linex, by + th / 2, linew, COL_BORDER);
    c->cy += th + ui_pad();
    c->seq++;
    return rt_none();
}

/* ui.样式(名字)：切整套外观。两种都留着，按应用挑。
 *   "圆角"（默认）抗锯齿圆角 + 投影 + 明度阶梯，适合普通桌面窗口
 *   "字符" 全贴字符网格，边框就是 ┌─┐│└┘ 本身（终端 / TUI 味）
 * 不认识的名字直接报错，别默默回退 —— 拼错了却看不出效果更费时间。 */
Value rt_ui_style(Value nv)
{
    const char *s = ui_str(nv);
    if (strcmp(s, "圆角") == 0 || strcmp(s, "rounded") == 0) {
        g_style = 0;
        rt_game_font_mono(0);
    } else if (strcmp(s, "字符") == 0 || strcmp(s, "ascii") == 0
               || strcmp(s, "tui") == 0) {
        /* 字符风格必须连等宽中文字体：比例字体下制表符笔画比步进窄，
           框线画出来全是断口（详见 pybook_rt.c rt_game_font_mono 的注释）。 */
        rt_game_font_mono(1);
        g_style = 1;
        g_aw = 0;                /* 字体换了，步进要重量 */
    } else {
        ui_die("ui.样式 不认识「%s」，只有「圆角」和「字符」", s);
    }
    return rt_none();
}

/* ui.字格(像素)：字符风格的网格步进（默认跟着字号走）。
   字体是比例字体，制表符虽然彼此等宽，但换个字号就换步进；
   想让两段 UI 的框线对齐，就用这个把步进钉死。 */
Value rt_ui_cell(Value pv)
{
    int n = (int)ui_num(pv, "ui.字格 的像素");
    if (n < 6)
        n = 6;
    if (n > 64)
        n = 64;
    g_aw = n;
    g_ah = n;
    return rt_none();
}

/* ui.gap(px)：插一段空白 */
Value rt_ui_gap(Value pv)
{
    if (g_depth <= 0)
        ui_die("ui.gap 必须在 ui.begin 之后调用");
    int n = (int)ui_num(pv, "ui.gap 的像素");
    if (n < 0)
        n = 0;
    UiBox *c = &g_st[g_depth - 1];
    if (c->dir == UI_COL)
        c->cy += n;
    else
        c->cx += n;
    return rt_none();
}

/* ui.tag(name)：给下一个控件钉一个稳定 id。
   把控件写在 if 分支里时序号 id 会错位 —— 用这个就不会。
   同时把名字留在 g_tag_name 里，ui_rect() 会顺手记下该控件的矩形，
   供 ui.矩形(name) 回读（见上面「控件矩形回读」的说明）。 */
Value rt_ui_tag(Value nv)
{
    const char *s = ui_str(nv);
    snprintf(g_tag_name, sizeof g_tag_name, "%s", s);
    g_tag = ui_hash(s);
    return rt_none();
}

/* ui.矩形(name)：回读被 ui.tag(name) 钉住的控件上一帧的 [x, y, w, h]。
   找不到（没钉过这个名 / 表满被挤掉）返回空列表 —— 脚本里判长度即可。 */
Value rt_ui_rect(Value nv)
{
    const char *s = ui_str(nv);
    for (int i = 0; i < g_rect_n; i++) {
        if (strcmp(g_rects[i].name, s) == 0) {
            Value r = rt_list_new();
            rt_push(&r, rt_int(g_rects[i].x));
            rt_push(&r, rt_int(g_rects[i].y));
            rt_push(&r, rt_int(g_rects[i].w));
            rt_push(&r, rt_int(g_rects[i].h));
            return r;
        }
    }
    return rt_list_new();
}

/* ui.label(text, px)：一行静态文字 */
Value rt_ui_label(Value tv, Value pv)
{
    if (g_depth <= 0)
        ui_die("ui.label 必须在 ui.begin 之后调用");
    const char *s  = ui_str(tv);
    int         px = (int)ui_num(pv, "ui.label 的字号");
    if (px < 6)
        px = 6;
    int tw = game_text_width(s, px);
    /* 字符风格：宽高都贴网格，文字从格子左上角起画，不加 2px 内缩 —— 内缩会
       把整列文字推离网格，后面 ┌───┐ 这类框就跟着歪。 */
    int w = g_style ? ui_cols(tw) * ui_aw_get() : tw + 4;
    int h = g_style ? g_ah : px + 8;
    int x, y, rw, rh;
    ui_rect(w, h, &x, &y, &rw, &rh);
    ui_text(x + (g_style ? 0 : 2), y + (g_style ? 0 : 2), s, px,
            g_style ? COL_DIM : COL_TEXT);
    ui_advance(w, h);
    return rt_none();
}

/* ---- ui.图 / ui.序列：把图片放进 UI ----
 *
 * 为什么不直接复用 game.图：那张图是**裸贴图**，既不占位也不推进布局光标，
 * 放进 UI 里会和后面的控件叠在一起。UI 的控件都要走 ui_rect（占位 + 记
 * ui.tag 矩形）和 ui_advance（推进光标），这里照 rt_ui_label 的范式补齐。
 *
 * ★ 离屏（3D 同屏）不用写第二套：UI 所有绘制都经 game_renderer()，
 *   而 ui.离屏 模式下那个渲染器就是绑到 ARGB8888 surface 的软件渲染器
 *   （pybook_rt.c 的 SDL_CreateSoftwareRenderer），所以 SDL_RenderCopy
 *   画进去的东西，3D 每帧连同整个 surface 一起贴上窗口。
 * ★ 跨模式切换安全：SDL_Texture 绑定在创建它的渲染器上，缓存里做了归属
 *   检测（pybook_rt.c 的 g_img_ren），换渲染器自动作废重载。
 *
 * ★ 缓存容量：256 槽 LRU（原来 48 槽满了直接退程序）。一套序列 8~24 帧，
 *   每帧只画 1 帧 —— 只要所有序列的总帧数 < 256 就不会抖动；
 *   超了会 LRU 反复重载退化（不崩，但会卡）。按 24 帧算约 10 套。
 *
 * 字符风格（ui.样式("字符")）下按格吸附：宽向上取整到字符格宽的整数倍、
 * 高向上取整到字符格高的整数倍，右侧/下侧仍落在网格上，后面的 ┌───┐
 * 不会歪。图本身**不缩放**（缩放会破坏像素风），只是占位变大。 */

/* 贴一张图，占位并推进布局。want_w/want_h <= 0 表示用原图尺寸。
   这是 ui.图 和 ui.序列 共用的落地路径 —— 两者只在「路径怎么来」上不同。 */
static void ui_img_blit(const char *who, const char *path, int want_w, int want_h)
{
    SDL_Renderer *ren = game_renderer();
    if (ren == NULL) {
        ui_die("%s：还没开窗口（先调用 win，或 ui.离屏 走 3D 同屏）", who);
        return;
    }
    int iw = 0, ih = 0;
    SDL_Texture *tex = game_img_tex_pub(path, &iw, &ih);   /* 只查一次，顺带拿原图尺寸 */
    int w = (want_w > 0) ? want_w : iw;
    int h = (want_h > 0) ? want_h : ih;
    if (g_style) {
        int aw = ui_aw_get();
        if (aw > 0) {
            w = ((w + aw - 1) / aw) * aw;      /* 向上取整到整格，不缩放图本身 */
            h = ((h + g_ah - 1) / g_ah) * g_ah;
        }
    }
    if (w < 1) w = 1;
    if (h < 1) h = 1;
    int x, y, rw, rh;
    ui_rect(w, h, &x, &y, &rw, &rh);           /* 占位（顺便处理 ui.tag 钉矩形） */
    SDL_Rect dst;
    dst.x = x; dst.y = y; dst.w = w; dst.h = h;
    SDL_RenderCopy(ren, tex, NULL, &dst);
    ui_advance(w, h);
}

/* ui.图(路径, 宽, 高)：贴一张静态图。宽或高传 0 = 用图片原始尺寸。 */
Value rt_ui_img(Value pv, Value wv, Value hv)
{
    if (g_depth <= 0)
        ui_die("ui.图 必须在 ui.begin 之后调用");
    const char *path = ui_str(pv);
    ui_img_blit("ui.图", path,
                (int)ui_num(wv, "ui.图 的宽"), (int)ui_num(hv, "ui.图 的高"));
    return rt_none();
}

/* ui.序列(路径模板, 首帧, 末帧, 每帧毫秒, 宽, 高)：就地画序列动画的一帧。
 * 模板里必须有 %d 当帧号占位符：ui.序列("爆炸%d.png", 1, 8, 80, 64, 64)
 * 宽或高传 0 = 用原图尺寸。返回本帧实际画的帧号（验收件可以拿它断言）。
 *
 * ★ 时钟用 QPC 不用 tm.now()：后者是 GetTickCount64，分辨率 15.625ms，
 *   而帧时长常见 30~100ms —— 用它一格跳两帧，动画肉眼可见地卡。 */
Value rt_ui_seq(Value tv, Value fv, Value lv, Value mv, Value wv, Value hv)
{
    if (g_depth <= 0)
        ui_die("ui.序列 必须在 ui.begin 之后调用");
    const char *tmpl = ui_str(tv);
    int first = (int)ui_num(fv, "ui.序列 的首帧");
    int last  = (int)ui_num(lv,  "ui.序列 的末帧");
    int per   = (int)ui_num(mv,  "ui.序列 的每帧毫秒");
    if (last < first)
        last = first;
    int span = last - first + 1;
    if (per < 1)
        per = 1;

    /* 防格式化串注入：snprintf 的格式来自脚本。
       放行 %[标志][宽度][.精度][length]d|i —— 宽度和精度必须放行，
       "%02d"（补零）是最常见的写法，挡掉它等于逼用户手拼文件名。
       但 "*" 宽度要拒：%*d 会从参数列表取值，这里只给了一个 int frame，
       放行就是未定义行为。%s / %n / %p 一律拒。 */
    {
        int has_d = 0;
        const char *p;
        for (p = tmpl; *p; p++) {
            if (*p != '%')
                continue;
            if (p[1] == '%') { p++; continue; }
            p++;
            while (*p == '-' || *p == '+' || *p == ' ' || *p == '#' || *p == '0')
                p++;
            while (*p >= '0' && *p <= '9')          /* 宽度 */
                p++;
            if (*p == '.') {                       /* 精度 */
                p++;
                while (*p >= '0' && *p <= '9')
                    p++;
            }
            while (*p == 'h' || *p == 'l' || *p == 'z' || *p == 'j' || *p == 't')
                p++;                                /* 长度修饰：整型，无副作用 */
            if (*p == 'd' || *p == 'i') {
                has_d = 1;
                p++;
                continue;
            }
            ui_die("ui.序列 的路径模板里只允许 %%[宽度][.精度]d 或 i（当前在 \"%%%s\"）", p);
            return rt_none();
        }
        if (!has_d)
            ui_die("ui.序列 的路径模板里要有 %%d 当帧号占位符（现在拿到的是 \"%s\"）", tmpl);
    }

    /* 槽位 = 本帧第几个 ui.序列。多列布局里每列根容器 hash 都是 0，
       用 hash 会让左右两列抢同一个起始时刻（跟 ui.分组 同一个坑）。 */
    int slot = (g_seq_slot < UI_SEQ_MAX) ? g_seq_slot++ : 0;
    uint64_t now = SDL_GetPerformanceCounter();
    if (g_seq_t0[slot] == 0)
        g_seq_t0[slot] = now ? now : 1;         /* QPC 理论上非 0，兜个底 */
    uint64_t freq = SDL_GetPerformanceFrequency();
    uint64_t dt   = now - g_seq_t0[slot];
    uint64_t ms   = (freq > 0) ? (dt * 1000ull / freq) : 0;
    int frame = first + (int)((ms / (uint64_t)per) % (uint64_t)span);

    char path[1024];
    snprintf(path, sizeof path, tmpl, frame);
    ui_img_blit("ui.序列", path,
                (int)ui_num(wv, "ui.序列 的宽"), (int)ui_num(hv, "ui.序列 的高"));
    return rt_int(frame);
}

/* ---- ui.粒子 / ui.粒子调：UI 里的粒子挂件 ----
 *
 * 为什么不直接用 fancy2d（星核特效/fancy2d.pybk）：它用 color() + 圆() 裸绘制，
 * 能和 ui.* 同框（同一个 SDL_Renderer），但粒子是**绝对屏幕坐标**，不占位、
 * 不推进光标、ui.tag 钉不住 —— 也就是说它不算 UI 的一个控件。
 * 这里是真正的挂件：占位 -> 发射 -> 演化 -> 绘制 -> 推进，
 * 和 ui.图 同级。
 *
 * ★ 区按「本帧第几个 ui.粒子」索引，不用容器 hash —— 多列布局里每列根容器
 *   hash 都是 0（ui.分组 已经吃过这个亏，见 g_grp_slot 的注释）。
 * ★ 字符风下**不吸附网格**：粒子是连续运动的光点，吸到格子上反而更怪。
 *   这是和 ui.图 故意不同的处理。
 * ★ 用 rand() 不 srand：每次运行的粒子序列一致，验收截图可复现
 *   （和 hw.burst 同一个取舍）。 */
#define UI_FX_MAX   8        /* 同时存在的粒子区上限 */
#define UI_FX_PART  160      /* 每个区的粒子数（环形复用） */
typedef struct {
    float  x, y;
    float  vx, vy;
    float  life;
    float  size;
    UiCol  c;
} UiPart;
static UiPart g_fx[UI_FX_MAX][UI_FX_PART];
static int    g_fx_head[UI_FX_MAX];      /* 环形游标：满了就覆盖最老的 */
/* g_fx_slot 定义在上面 rt_ui_new_frame 附近（那里先要用到它）。 */

/* 全局物理参数，由 ui.粒子调 改（和 ui.样式 / ui.字格 同属「全局旋钮」风格）。
   屏幕 y 向下为正，所以负重力 = 往上飘。 */
static float g_fx_grav = -0.02f;
static float g_fx_drag =  0.98f;
static float g_fx_spd  =  1.0f;
static float g_fx_size =  3.0f;
static int   g_fx_life =  60;            /* 单位：帧 */

/* 一个抗锯齿差的实心小圆（扫描线填充，和 rt_game_circle 同款）。
   不复用 rt_game_circle：那个吃的是**当前画笔色**且 alpha 硬编码 255，
   而粒子要逐个按寿命比例调颜色和 alpha。 */
static void ui_dot(int cx, int cy, int r, UiCol c, int a)
{
    SDL_Renderer *ren = game_renderer();
    if (ren == NULL || r < 1 || a <= 0)
        return;
    if (a > 255)
        a = 255;
    SDL_SetRenderDrawColor(ren, (Uint8)c.r, (Uint8)c.g, (Uint8)c.b, (Uint8)a);
    for (int dy = -r; dy <= r; dy++) {
        int w2 = r * r - dy * dy;
        if (w2 <= 0)
            continue;
        int w = (int)sqrt((double)w2);
        SDL_Rect rc;
        rc.x = cx - w;
        rc.y = cy + dy;
        rc.w = w * 2 + 1;
        rc.h = 1;
        SDL_RenderFillRect(ren, &rc);
    }
}

/* ui.粒子(宽, 高, 每帧发射数, R, G, B)：一块持续冒粒子的区域，占位并推进布局。
   粒子从矩形**底部**往上飘（像火苗/蒸汽），飞出矩形边界一定距离就熄掉，
   免得拖一长串到别的控件上。 */
Value rt_ui_fx(Value wv, Value hv, Value ratev, Value rv, Value gv, Value bv)
{
    if (g_depth <= 0)
        ui_die("ui.粒子 必须在 ui.begin 之后调用");
    int w    = (int)ui_num(wv,    "ui.粒子 的宽");
    int h    = (int)ui_num(hv,    "ui.粒子 的高");
    int rate = (int)ui_num(ratev, "ui.粒子 的每帧发射数");
    int rr   = (int)ui_num(rv,    "ui.粒子 的 R");
    int gg   = (int)ui_num(gv,    "ui.粒子 的 G");
    int bb   = (int)ui_num(bv,    "ui.粒子 的 B");
    if (w < 4) w = 4;
    if (h < 4) h = 4;
    if (rate < 0) rate = 0;
    if (rate > 40) rate = 40;             /* 每帧 40 个 ×160 槽 4 秒就转满，够了 */

    int x, y, rw, rh;
    ui_rect(w, h, &x, &y, &rw, &rh);      /* 占位（顺便处理 ui.tag） */
    ui_advance(w, h);

    int slot = (g_fx_slot < UI_FX_MAX) ? g_fx_slot++ : 0;
    UiPart *pool = g_fx[slot];
    int *head = &g_fx_head[slot];

    /* ---- 发射 ---- */
    UiCol base;
    base.r = (unsigned char)(rr < 0 ? 0 : (rr > 255 ? 255 : rr));
    base.g = (unsigned char)(gg < 0 ? 0 : (gg > 255 ? 255 : gg));
    base.b = (unsigned char)(bb < 0 ? 0 : (bb > 255 ? 255 : bb));
    for (int k = 0; k < rate; k++) {
        UiPart *p = &pool[*head];
        *head = (*head + 1) % UI_FX_PART;
        p->x = (float)x + (float)rand() / (float)RAND_MAX * (float)w;
        p->y = (float)(y + h - 1);
        /* -pi/2 是正上方；±0.9 弧度的锥形散开 */
        float ang = -1.5708f + ((float)rand() / (float)RAND_MAX * 2.0f - 1.0f) * 0.9f;
        float spd = 0.5f + (float)rand() / (float)RAND_MAX * 1.4f;
        p->vx = cosf(ang) * spd;
        p->vy = sinf(ang) * spd;
        p->life  = (float)g_fx_life;
        p->size  = g_fx_size * (0.6f + (float)rand() / (float)RAND_MAX * 0.8f);
        p->c = base;
    }

    /* ---- 演化 + 绘制 ---- */
    float maxlife = (float)(g_fx_life > 0 ? g_fx_life : 1);
    for (int i = 0; i < UI_FX_PART; i++) {
        UiPart *p = &pool[i];
        if (p->life <= 0.0f)
            continue;
        p->life -= 1.0f;
        if (p->life <= 0.0f)
            continue;
        p->vy += g_fx_grav;
        p->vx *= g_fx_drag;
        p->vy *= g_fx_drag;
        p->x  += p->vx * g_fx_spd;
        p->y  += p->vy * g_fx_spd;
        if (p->y < (float)(y - 40) || p->y > (float)(y + h + 40) ||
            p->x < (float)(x - 40) || p->x > (float)(x + w + 40)) {
            p->life = 0.0f;                /* 飞出边界太远就熄，别拖到别的控件上 */
            continue;
        }
        float a = p->life / maxlife;
        int rr2 = (int)(p->size * a + 0.5f);
        if (rr2 < 1)
            rr2 = 1;
        ui_dot((int)p->x, (int)p->y, rr2, p->c, (int)(a * 255.0f));
    }
    return rt_none();
}

/* ui.粒子调(重力, 阻力, 速度, 大小, 寿命)：改所有粒子区的物理参数（全局旋钮）。
   屏幕 y 向下为正：重力 0 = 匀速飘，负 = 上飘，正 = 下落。 */
Value rt_ui_fx_tune(Value gravv, Value dragv, Value spdv, Value szv, Value lifev)
{
    g_fx_grav = (float)ui_num(gravv, "ui.粒子调 的重力");
    g_fx_drag = (float)ui_num(dragv, "ui.粒子调 的阻力");
    g_fx_spd  = (float)ui_num(spdv,  "ui.粒子调 的速度");
    g_fx_size = (float)ui_num(szv,   "ui.粒子调 的大小");
    g_fx_life = (int)ui_num(lifev,  "ui.粒子调 的寿命");
    if (g_fx_drag < 0.0f)  g_fx_drag = 0.0f;
    if (g_fx_drag > 1.0f)  g_fx_drag = 1.0f;
    if (g_fx_spd < 0.0f)   g_fx_spd = 0.0f;
    if (g_fx_size < 1.0f)  g_fx_size = 1.0f;
    if (g_fx_size > 24.0f) g_fx_size = 24.0f;
    if (g_fx_life < 2)     g_fx_life = 2;
    if (g_fx_life > 600)   g_fx_life = 600;
    return rt_none();
}

/* ui.button(text)：返回本帧是否被点（1/0） */
Value rt_ui_button(Value tv)
{
    if (g_depth <= 0)
        ui_die("ui.button 必须在 ui.begin 之后调用");
    const char *s = ui_str(tv);
    /* 字符风格按**真实步进**算格数和居中，不能用 game_text_width：
       那个是纹理宽 = 4 + Σ(advance+2)，单字符也 +6、n 字符 +4+2n。
       拿它算格，"低"(advance 16) 会算成 2 格，按钮凭空宽一格，
       排在一起就变成 `[ 低 ]  [中] [高] [极高]` 这种忽宽忽窄。 */
    int tw = game_text_advance(s, g_font_px);
    int cw = ui_cols(tw);                       /* 文本占几格 */
    int aw = ui_aw_get();
    /* 字符风格：[ 文本 ] —— 两端各一格括号；圆角风格：宽度 = 文本 + 28 */
    int w  = g_style ? (cw + 2) * aw : tw + 28;
    int h  = ui_chgt();
    int x, y, rw, rh;
    ui_rect(w, h, &x, &y, &rw, &rh);

    int hover = ui_in(x, y, rw, rh);
    if (g_style) {
        int rx = x + rw - aw;
        ui_text(x,  y, "[", g_font_px, hover ? COL_ACCENT : COL_LINE);
        ui_text(rx, y, "]", g_font_px, hover ? COL_ACCENT : COL_LINE);
        ui_text(x + (rw - tw) / 2, y, s, g_font_px,
                hover ? COL_ACCENT : COL_TEXT);
    } else {
        ui_ctrl_box(x, y, rw, rh, 6, hover ? COL_PANEL2 : COL_PANEL,
                    hover ? COL_ACCENT : COL_LINE, SH_CTRL);
        ui_text(x + (rw - tw) / 2, y + (rh - g_font_px) / 2, s, g_font_px,
                hover ? COL_ACCENT : COL_TEXT);
    }

    int hit = (hover && g_click) ? 1 : 0;
    ui_advance(w, h);
    return rt_bool(hit);
}

/* ui.input(value)：单行输入框。返回当前文本。
   典型写法 `名字 = ui.input(名字)` —— 传进去当初始值，拿回来是新值。
   点一下获得焦点；有焦点时键盘输入直接进来（中文 IME 也走 SDL_TEXTINPUT）。 */
Value rt_ui_input(Value vv)
{
    if (g_depth <= 0)
        ui_die("ui.input 必须在 ui.begin 之后调用");
    const char *val = ui_str(vv);
    int w = 220, h = ui_chgt();
    int x, y, rw, rh;
    ui_rect(w, h, &x, &y, &rw, &rh);

    unsigned id = ui_id();
    UiState *st = ui_state(id);
    if (!st->init || strcmp(st->text, val) != 0) {
        /* 首次、或外部把这个值改了（比如点了个「清空」按钮）→ 采纳外部值 */
        free(st->text);
        st->text = ui_dup(val);
        st->init = 1;
    }

    int hover = ui_in(x, y, rw, rh);
    if (hover && g_click)
        g_focus = id;
    else if (g_click && !hover && g_focus == id)
        g_focus = 0;                       /* 点到别处就失焦 */

    if (g_focus == id) {
        const char *t = game_take_text();
        if (t != NULL && t[0] != '\0') {
            size_t n1 = strlen(st->text), n2 = strlen(t);
            char *p = (char *)realloc(st->text, n1 + n2 + 1);
            if (p != NULL) {
                st->text = p;
                memcpy(st->text + n1, t, n2 + 1);
            }
        }
        int bs = game_take_backspace();
        while (bs-- > 0 && st->text[0] != '\0') {
            /* 退掉一个完整 UTF-8 字符（中文不能退半个） */
            size_t n = strlen(st->text);
            size_t k = 1;
            while (k < n && ((unsigned char)st->text[n - k - 1] & 0xC0) == 0x80)
                k++;
            if (k > 4)
                k = 4;
            st->text[n - k] = '\0';
        }
    }

    int focused = (g_focus == id);
    int tw = game_text_width(st->text, g_font_px);
    int aw = ui_aw_get();
    if (g_style) {
        /* 字符风格：│ 文本 │，聚焦时两端竖线转主色，光标是一根实心块 ▌ */
        int rx = x + rw - aw;
        int inner = rw - aw * 2;
        int tx2 = x + aw;
        if (tw > inner)
            tx2 = x + aw - (tw - inner);        /* 太长就把尾部滚出来 */
        UiCol bc = focused ? COL_ACCENT : (hover ? COL_LINE : COL_BORDER);
        ui_text(x,  y, "│", g_font_px, bc);
        ui_text(rx, y, "│", g_font_px, bc);
        ui_text(tx2, y, st->text, g_font_px, COL_TEXT);
        if (focused && (int)((SDL_GetTicks() / 500) % 2))
            ui_text(tx2 + tw, y, "▌", g_font_px, COL_ACCENT);
        ui_advance(w, h);
        return rt_str(st->text);
    }

    ui_ctrl_box(x, y, rw, rh, 6, focused ? COL_PANEL2 : COL_PANEL,
                focused ? COL_ACCENT : (hover ? COL_LINE : COL_BORDER), SH_CTRL);

    int tx = x + 8;
    if (tw > rw - 16)                       /* 太长就把尾部截出来显示 */
        tx = x + 8 - (tw - (rw - 16));
    ui_text(tx, y + (rh - g_font_px) / 2, st->text, g_font_px, COL_TEXT);

    if (focused && (int)((SDL_GetTicks() / 500) % 2)) {   /* 光标：1 秒一闪 */
        int cx = x + 8 + (tw < rw - 16 ? tw : rw - 16);
        ui_fill(cx, y + 6, 2, rh - 12, COL_ACCENT);
    }

    ui_advance(w, h);
    return rt_str(st->text);
}

/* ui.slider(value, min, max)：拖动条。返回当前值。
   按住左键在条上拖即可；也支持点一下跳过去。 */
Value rt_ui_slider(Value vv, Value mnv, Value mxv)
{
    if (g_depth <= 0)
        ui_die("ui.slider 必须在 ui.begin 之后调用");
    double val = ui_num(vv,  "ui.slider 的值");
    double mn  = ui_num(mnv, "ui.slider 的最小值");
    double mx  = ui_num(mxv, "ui.slider 的最大值");
    if (mx < mn) { double t = mn; mn = mx; mx = t; }
    if (mx - mn < 1e-9)
        mx = mn + 1.0;

    int w = 200, h = ui_chgt();
    int x, y, rw, rh;
    ui_rect(w, h, &x, &y, &rw, &rh);

    unsigned id = ui_id();
    UiState *st = ui_state(id);
    if (!st->init) {
        st->num  = val;
        st->init = 1;
    }

    /* 右端要标当前数值，先把它的宽度量出来并从轨道里扣掉 ——
       不扣的话数值会画到容器右外侧、被窗口边缘裁掉（实测 "50" 被切一半）。 */
    char buf[48];
    snprintf(buf, sizeof buf, "%.0f", st->num);
    int vw = game_text_advance(buf, g_font_px);   /* 真实步进，理由同 ui.button */
    int tw = rw - (vw + 12);
    if (tw < 40)
        tw = rw;              /* 容器太窄就不留数值位，优先保住能拖的范围 */
    if (g_style) {
        /* 字符风轨道必须整格：拖动范围要和画出来的格子对齐，滑块跟手才不差半格。
           同时给右端 ┤ 和数值各留一格，别让它们挤在一起。 */
        int aw0 = ui_aw_get();
        int t2 = (rw - vw - aw0 * 2) / aw0 * aw0;
        if (t2 >= 2 * aw0)
            tw = t2;
    }

    int hover = ui_in(x, y, rw, rh);
    /* 本帧点中 → 接管拖动；已经接管且左键还按着 → 继续跟手 */
    if (hover && g_click)
        g_focus = id;
    /* ★ 修复（2026-08 交互验收实测抓到）：这一行原来在设值分支**之后**，
       于是"按住滑条不松手、再去点别处"时，滑条仍攥着上一帧的 g_focus，
       而 g_down 还是 1 —— 它就用鼠标位置反算 t=(520-24)/275=1.8 → clamp 成 1.0，
       把音量拽到了 100。表现是：我去点表格第三行，音量自己跳满了。
       语义上"新的按下应当抢走拖动焦点"，所以释放必须发生在设值**之前**；
       纯拖动（g_click=0）不触发释放，所以"按住拖出控件还继续跟手"不受影响。 */
    if (g_click && !hover)
        g_focus = 0;
    if (g_focus == id && g_down) {
        double t = (double)(g_mx - x) / (double)tw;
        if (t < 0.0) t = 0.0;
        if (t > 1.0) t = 1.0;
        st->num = mn + t * (mx - mn);
    }
    /* 上面已提前处理 g_focus 释放，这里不再重复 */

    double t = (st->num - mn) / (mx - mn);
    if (t < 0.0) t = 0.0;
    if (t > 1.0) t = 1.0;

    int aw = ui_aw_get();
    if (g_style) {
        /* 字符风格：├────●────┤，滑块是个 ●，轨道是 ─ 连排。
           轨道占 [x, x+cells*aw]：第 0 格是 ├，第 1..cells-1 格是 ─，
           第 cells 格是 ┤。右端的 ┤ 封的是**轨道**而不是整个控件 ——
           早先画在 x+rw-aw，正好压在右边预留的数值上（实测 ┤ 跑到 "60" 后面）。 */
        int cells = tw / aw;
        if (cells < 2) cells = 2;
        int rx2 = x + cells * aw;                  /* 轨道右端 */
        int kcell = 1 + (int)((cells - 2) * t);   /* 滑块所在格：1..cells-1，永远落在 ─ 上，不压 ├ ┤ */
        if (kcell > cells) kcell = cells;
        if (kcell < 1)   kcell = 1;
        int hot = (hover || g_focus == id);
        ui_text(x,  y, "├", g_font_px, hot ? COL_ACCENT : COL_LINE);
        ui_text(rx2, y, "┤", g_font_px, hot ? COL_ACCENT : COL_LINE);
        ui_rep(x + aw, y, cells - 1, "─", COL_LINE);
        if (kcell > 0)
            ui_rep(x + aw, y, kcell, "─", COL_ACCENT);   /* 第 1..kcell 格 */
        ui_text(x + kcell * aw, y, "●", g_font_px,
                hot ? COL_ACCENT : COL_TEXT);
        int vx = rx2 + aw;
        if (vx + vw > x + rw)
            vx = x + rw - vw;
        ui_text(vx, y, buf, g_font_px, hot ? COL_TEXT : COL_DIM);
        ui_advance(w, h);
        return rt_float(st->num);
    }

    /* 轨道做成胶囊（高 6、半径 3），滑块做成带投影的圆角柱 ——
       原来 4px 方条 + 10×16 方块，在一片圆角控件里是两个"原边"的刺眼点。 */
    int th_track = 6;
    int ky = y + rh / 2 - th_track / 2;
    ui_round(x, ky, tw, th_track, th_track / 2, COL_TRACK);
    int fw = (int)(tw * t);
    if (fw > 0) {
        /* 已填充段两端都圆，不然左端贴着轨道左缘会有个直角缺口 */
        ui_round(x, ky, fw > th_track ? fw : th_track, th_track, th_track / 2, COL_ACCENT);
    }
    int kw = 14, kh = 20;
    int kx = x + fw - kw / 2;
    if (kx < x)                  kx = x;
    if (kx > x + tw - kw)        kx = x + tw - kw;
    int kyy = y + rh / 2 - kh / 2;
    ui_ctrl_box(kx, kyy, kw, kh, 7,
                (hover || g_focus == id) ? COL_ACCENT : COL_TEXT,
                (hover || g_focus == id) ? COL_ACCENT : COL_DIM, SH_CTRL);

    /* 数值右对齐贴容器右缘，跟轨道保持 12px 呼吸 */
    ui_text(x + rw - vw, y + (rh - g_font_px) / 2, buf, g_font_px,
            (hover || g_focus == id) ? COL_TEXT : COL_DIM);

    ui_advance(w, h);
    return rt_float(st->num);
}

/* ui.check(text, value)：勾选框。返回当前是否勾上（1/0）。 */
Value rt_ui_check(Value tv, Value vv)
{
    if (g_depth <= 0)
        ui_die("ui.check 必须在 ui.begin 之后调用");
    const char *s  = ui_str(tv);
    int on = ui_num(vv, "ui.check 的值") != 0.0;
    int tw = game_text_width(s, g_font_px);
    int aw = ui_aw_get();
    /* 字符风格：[√] 文本 —— 方括号 + 勾，占 3 格；圆角风格：20px 方框 */
    int w  = g_style ? (ui_cols(tw) + 3) * aw : 20 + 8 + tw + 8;
    int h  = ui_chgt();
    int x, y, rw, rh;
    ui_rect(w, h, &x, &y, &rw, &rh);

    unsigned id = ui_id();
    UiState *st = ui_state(id);
    if (!st->init) {
        st->num  = on ? 1.0 : 0.0;
        st->init = 1;
    }

    int hover = ui_in(x, y, rw, rh);
    if (hover && g_click)
        st->num = (st->num != 0.0) ? 0.0 : 1.0;

    if (g_style) {
        /* √ 的步进和制表符同宽（实测 14px @16px 字号），正好落在中间那格里；
           用 ▣/□ 也行，但 √ 在雅黑里一定有，不必赌字形覆盖。 */
        int on2 = (st->num != 0.0);
        ui_text(x,        y, "[", g_font_px, on2 ? COL_ACCENT : COL_LINE);
        ui_text(x + 2*aw, y, "]", g_font_px, on2 ? COL_ACCENT : COL_LINE);
        ui_text(x + aw,   y, on2 ? "√" : " ", g_font_px,
                on2 ? COL_ACCENT : (hover ? COL_LINE : COL_DIM));
        ui_text(x + 3*aw, y, s, g_font_px, (on2 || hover) ? COL_TEXT : COL_DIM);
        ui_advance(w, h);
        return rt_bool(on2);
    }

    int bs = 20;
    int bx = x, by = y + (rh - bs) / 2;
    if (st->num != 0.0)
        ui_ctrl_box(bx, by, bs, bs, 6, COL_ACCENT, COL_ACCENT, SH_CTRL);
    else
        ui_ctrl_box(bx, by, bs, bs, 6, COL_PANEL,
                    hover ? COL_ACCENT : COL_LINE, SH_CTRL);
    if (st->num != 0.0) {
        /* 对勾：短斜下 + 长斜上，比一条横线一眼能认出是"勾上了"。
           原来是 Bresenham 铺 3×3 方块，10px 长的斜边全是台阶。 */
        ui_line(bx + 5, by + 10, bx + 9, by + 14, 3, COL_BG);
        ui_line(bx + 9, by + 14, bx + 15, by + 5, 3, COL_BG);
    }
    ui_text(x + 28, y + (rh - g_font_px) / 2, s, g_font_px,
            (st->num != 0.0 || hover) ? COL_TEXT : COL_DIM);

    ui_advance(w, h);
    return rt_bool(st->num != 0.0);
}

/* ---- ui.table：任意格子值 → malloc 文本（用完 free）。
   数字 / 真假 / 空都按 ns.show 的口径转，混型表格不用先 te.str。 ---- */
static char *ui_cell_text(Value v)
{
    char buf[48];
    if (IS_STR(v))
        return ui_dup(rt_str_of(v));
    if (IS_INT(v) || IS_BIGINT(v)) {
        snprintf(buf, sizeof buf, "%lld", rt_to_ll(v));
        return ui_dup(buf);
    }
    if (IS_FLT(v)) {
        snprintf(buf, sizeof buf, "%g", AS_FLT(v));
        return ui_dup(buf);
    }
    if (IS_BOOL(v))
        return ui_dup(AS_BOOL(v) ? "真" : "假");
    if (IS_NONE(v))
        return ui_dup("空");
    return ui_dup("?");
}

/* ui.table(selected, data, headers, view_h)：数据表 —— 应用级「看表 + 点行」。
 *
 *   selected  当前选中行号（0 起，-1 = 没选中）
 *   data      列表的列表：每行一个子列表，格子自动转文本
 *   headers   表头字符串列表；空表 [] = 不画表头
 *   view_h    >0 = 视口高（超出出右缘滚动条，可拖）；<=0 = 自然高（全展开）
 *
 * 列宽自动：每列取「表头 + 所有格子」的最大文本宽 + 12，总宽超出容器按比例压缩。
 * 交互：悬停行高亮；点行选中、再点同一行取消（回 -1）。
 * 返回：本帧的选中行号 —— 惯用法 `选中 = ui.表格(选中, 数据, 表头, 260)`。
 * 表格是通栏控件：总是撑满当前容器剩余宽（竖排流里用最自然）。
 * 限制：每帧 O(行×列) 次文本测量，千行级先分页；2D 运行时没有滚轮，v1 靠滚动条。 */
Value rt_ui_table(Value selv, Value datav, Value headv, Value vhv)
{
    if (g_depth <= 0)
        ui_die("ui.table 必须在 ui.begin 之后调用");
    if (!IS_LIST(datav))
        ui_die("ui.table 的数据需要是列表（每个元素是一行子列表）");
    if (!IS_LIST(headv))
        ui_die("ui.table 的表头需要是字符串列表（不要表头就传 []）");

    /* 首帧裸名进来是空盒 → 当作「没选中」；整数/真假照收 */
    long long sel = IS_NONE(selv) ? -1 : rt_to_ll(selv);
    RtList  *rl   = AS_LIST(datav);
    RtList  *hl   = AS_LIST(headv);
    long long nrows = rt_list_len_ll(datav);
    long long nh    = (long long)hl->len;
    int       vh_req = (int)ui_num(vhv, "ui.table 的视口高");

    if (sel >= nrows)
        sel = -1;                       /* 数据变短了，旧选中号作废 */

    unsigned id = ui_id();
    UiState *st = ui_state(id);

    /* ---- 一次取齐所有文本：量宽和绘制共用（用完就放） ---- */
    char **hdr = NULL;
    if (nh > 0) {
        hdr = (char **)calloc((size_t)nh, sizeof(char *));
        if (hdr == NULL)
            ui_die("内存不足");
        for (long long c = 0; c < nh; c++)
            hdr[c] = ui_cell_text(hl->items[c]);
    }
    long long ncols = nh;
    for (long long i = 0; i < nrows; i++) {
        Value rv = rl->items[i];
        if (IS_LIST(rv) && (long long)AS_LIST(rv)->len > ncols)
            ncols = (long long)AS_LIST(rv)->len;
    }
    char **grid = NULL;
    if (nrows > 0 && ncols > 0) {
        grid = (char **)calloc((size_t)(nrows * ncols), sizeof(char *));
        if (grid == NULL)
            ui_die("内存不足");
        for (long long i = 0; i < nrows; i++) {
            Value rv = rl->items[i];
            RtList *r = IS_LIST(rv) ? AS_LIST(rv) : NULL;
            for (long long c = 0; c < ncols; c++)
                grid[i * ncols + c] =
                    (r != NULL && c < (long long)r->len) ? ui_cell_text(r->items[c])
                                                          : ui_dup("");
        }
    }

    /* ---- 列宽：最大文本宽 + 12；总宽超出容器按比例压（单列保底 24） ---- */
    long long *colw = NULL;
    if (ncols > 0) {
        colw = (long long *)calloc((size_t)ncols, sizeof(long long));
        if (colw == NULL)
            ui_die("内存不足");
        for (long long cc = 0; cc < ncols; cc++) {
            long long wmax = 0;
            if (cc < nh && hdr[cc] != NULL)
                wmax = game_text_width(hdr[cc], g_font_px);
            if (grid != NULL) {
                for (long long i = 0; i < nrows; i++) {
                    int cw = game_text_width(grid[i * ncols + cc], g_font_px);
                    if (cw > wmax)
                        wmax = cw;
                }
            }
            colw[cc] = wmax + 12;
        }
    }
    UiBox *cur = &g_st[g_depth - 1];
    int avail = cur->x + cur->w - cur->cx;         /* 容器剩余宽 */
    if (avail < 60)
        avail = 60;
    long long total = 0;
    for (long long cc = 0; cc < ncols; cc++)
        total += colw[cc];
    if (total > avail && total > 0) {
        for (long long cc = 0; cc < ncols; cc++) {
            colw[cc] = colw[cc] * avail / total;
            if (colw[cc] < 24)
                colw[cc] = 24;
        }
    }

    /* ---- 占位：表格是通栏控件，撑满容器剩余宽 ---- */
    int rowh    = g_style ? g_ah : g_font_px + 8;
    int has_hdr = (nh > 0);
    int headerh = has_hdr ? rowh : 0;
    int contenth = (int)(nrows * rowh);
    int vh = (vh_req > 0) ? vh_req : headerh + contenth;
    if (vh < headerh + rowh)
        vh = headerh + rowh;

    int x, y, rw, rh;
    ui_rect(8, vh, &x, &y, &rw, &rh);
    (void)rw;
    (void)rh;
    int w = cur->x + cur->w - x;
    if (w < 60)
        w = 60;

    /* 表体几何只算一次：滚动条拖动判定、行命中判定、绘制全都用同一组数。
       原来交互段和绘制段各抄了一份 trackx / thumbh，两处一漂移就是
       "看得见滑块但点不着"这种查起来最费劲的毛病。
       inset 是为了让行不盖住外框那 1px，所以可滚动量按内缩后的高度算。 */
    int inset  = g_style ? 0 : 1;
    int bodyx  = x + inset;
    int bodyy  = y + headerh;
    int bodyh2 = vh - inset - headerh;
    if (bodyh2 < 4)
        bodyh2 = 4;
    /* 字符风格：可视区上下各留一格给 ┌─┐ / └─┘ 两道框 */
    if (g_style) {
        int rows = bodyh2 / g_ah - 2;
        if (rows < 1) rows = 1;
        bodyy = y + headerh + g_ah + (has_hdr ? g_ah : 0);
        bodyh2 = rows * g_ah;
    }
    int maxscroll = (contenth > bodyh2) ? (contenth - bodyh2) : 0;
    int sb_w   = (maxscroll > 0) ? 8 : 0;
    int bodyw  = w - inset * 2 - sb_w;
    if (bodyw < 8)
        bodyw = 8;
    int trackx = x + w - inset - sb_w;
    int thumbh = bodyh2;
    if (contenth > 0) {
        thumbh = bodyh2 * bodyh2 / contenth;
        if (thumbh < 16) thumbh = 16;
        if (thumbh > bodyh2) thumbh = bodyh2;
    }
    double scroll = st->num;
    if (scroll < 0)
        scroll = 0;
    if (scroll > maxscroll)
        scroll = maxscroll;
    int thumby = (maxscroll > 0)
                    ? bodyy + (int)((bodyh2 - thumbh) * (scroll / (double)maxscroll))
                    : bodyy;

    /* ---- 交互：滚动条拖动（借 slider 的焦点-拖动手势） ---- */
    if (maxscroll > 0) {
        int in_track = ui_in(trackx, bodyy, sb_w, bodyh2);
        if (in_track && g_click)
            g_focus = id;
        /* 同 rt_ui_slider 的修复：释放必须发生在滚动分支**之前**。
           原来写成 else if，于是"按住滚动条再去点表格外的地方"时滚动分支先命中，
           焦点不释放，滚动量会跟着鼠标位置跳。 */
        if (g_click && !ui_in(x, y, w, vh))
            g_focus = 0;
        if (g_focus == id && g_down) {
            double t = (double)(g_my - bodyy - thumbh / 2) / (double)(bodyh2 - thumbh);
            if (t < 0.0) t = 0.0;
            if (t > 1.0) t = 1.0;
            scroll = t * maxscroll;
            if (scroll > maxscroll)
                scroll = maxscroll;
            thumby = bodyy + (int)((bodyh2 - thumbh) * (scroll / (double)maxscroll));
        }
    }

    /* ---- 交互：点行选中 / 再点取消 ---- */
    long long hover_row = -1;
    if (g_mx >= bodyx && g_mx < bodyx + bodyw && g_my >= bodyy && g_my < bodyy + bodyh2) {
        long long i = (long long)(g_my - bodyy + scroll) / rowh;
        if (i >= 0 && i < nrows)
            hover_row = i;
    }
    if (hover_row >= 0 && g_click)
        sel = (sel == hover_row) ? -1 : hover_row;

    /* ---- 画 ---- */
    SDL_Renderer *ren = game_renderer();
    if (g_style) {
        /* 字符风格表格：整张表就是一堵 ┌─┬─┐ 的字墙。
           列不按像素算宽，按**格**算 —— 否则汉字/拉丁混排时框线会错位。 */
        int aw = ui_aw_get();
        int *ccw = NULL;
        if (ncols > 0) {
            ccw = (int *)calloc((size_t)ncols, sizeof(int));
            if (ccw == NULL)
                ui_die("内存不足");
            for (long long cc = 0; cc < ncols; cc++) {
                int mw = 0, tw2;
                /* 用真实步进而不是 game_text_width：后者含 4+2n 的排版余量，
                   ceil 之后每列会凭空多占一格（实测"体素墙" 3 格被算成 4 格）。 */
                if (cc < nh && hdr[cc] != NULL)
                    mw = game_text_advance(hdr[cc], g_font_px);
                for (long long i = 0; i < nrows; i++) {
                    tw2 = game_text_advance(grid ? grid[i * ncols + cc] : "",
                                            g_font_px);
                    if (tw2 > mw)
                        mw = tw2;
                }
                ccw[cc] = ui_cols(mw) + 1;      /* 右侧留 1 格空当 */
                if (ccw[cc] < 3)
                    ccw[cc] = 3;
            }
            /* 装不下就按比例收：每列至少 3 格 */
            int total = 1;
            for (long long cc = 0; cc < ncols; cc++)
                total += ccw[cc] + 1;
            int maxcells = w / aw;
            if (maxcells < ncols * 4 + 1)
                maxcells = ncols * 4 + 1;
            while (total > maxcells) {
                int cut = 0;
                for (long long cc = 0; cc < ncols; cc++)
                    if (ccw[cc] > 3)
                        cut++;
                if (cut == 0)
                    break;
                for (long long cc = 0; cc < ncols; cc++)
                    if (ccw[cc] > 3) {
                        ccw[cc]--;
                        total--;
                    }
            }
            /* 还有富余就把整张表撑满容器右边 —— 表格比分组框窄一截时，
               右边会空出好几格，看着像没画完（实测空 6 格）。 */
            if (total < maxcells) {
                int left = maxcells - total;
                int per = left / (int)ncols, rem = left % (int)ncols;
                for (long long cc = 0; cc < ncols; cc++)
                    ccw[cc] += per + ((cc + 1 == ncols) ? rem : 0);
            }
        }
        /* ---- 列位表 colx[]：唯一真源 ----
           竖线、横线的 ┬ ┼ ┴、表头文字、数据文字、滚动条轨道，全部从这里取 x。
           上一版是竖线一套循环、横线另一套字符串循环、两处各抄一遍列宽，
           结果竖线整体比 ┬ ┼ ┴ 左移一整列（实测 80px = 5 格），
           而且右边框那条竖线根本没画（循环只跑 ncols 次）。
           这类"同一个几何量在两处各算一遍"的坑，正是上一轮分组面板
           高度取错值的同一个病根，所以这次只留一份。 */
        int *colx = NULL;
        if (ncols > 0) {
            colx = (int *)calloc((size_t)ncols + 1, sizeof(int));
            if (colx == NULL)
                ui_die("内存不足");
            colx[0] = 0;
            for (long long cc = 0; cc < ncols; cc++)
                colx[cc + 1] = colx[cc] + ccw[cc] + 1;
        }
        int y_top = y;
        int y_bot = y + vh - g_ah;
        int nv    = (y_bot - y_top) / g_ah + 1;
        if (nv < 2)
            nv = 2;

        /* 竖线：ncols+1 条 —— 左边框 + ncols-1 条列分隔 + 右边框。
           colx[ncols] 是右边框所在"格号"（不是字符数，差 1，别混）。 */
        if (ncols > 0) {
            for (long long cc = 0; cc <= ncols; cc++)
                ui_rep_v(x + colx[cc] * aw, y_top, nv, "│", COL_LINE);
        } else {
            ui_rep_v(x, y_top, nv, "│", COL_LINE);
        }
        /* 横线：上框 / 表头分隔 / 下框 */
        char line[3 * 220 + 1];
        char *p;
        for (int which = 0; which < 3; which++) {
            int yy = (which == 0) ? y_top
                   : (which == 1) ? (has_hdr ? y_top + 2 * g_ah : -1)
                                  : y_bot;
            if (yy < 0)
                continue;
            p = line;
            p = chput(p, which == 0 ? "┌" : (which == 2 ? "└" : "├"));
            for (long long cc = 0; cc < ncols; cc++) {
                for (int i = 0; i < ccw[cc]; i++)
                    p = chput(p, "─");
                p = chput(p, (cc + 1 < ncols)
                              ? (which == 0 ? "┬" : (which == 2 ? "┴" : "┼"))
                              : (which == 0 ? "┐" : (which == 2 ? "┘" : "┤")));
            }
            *p = '\0';
            ui_text(x, yy, line, g_font_px, COL_LINE);
        }

        /* 表头文字：贴本列内容的第一格，不留像素补白 —— 补白会把列推出网格 */
        if (has_hdr) {
            for (long long cc = 0; cc < nh && cc < ncols; cc++) {
                ui_text(x + (colx[cc] + 1) * aw, y_top + g_ah,
                        hdr[cc], g_font_px, COL_DIM);
            }
        }

        /* 数据行 */
        if (ren != NULL) {
            SDL_Rect clip;
            clip.x = x; clip.y = bodyy; clip.w = w; clip.h = bodyh2;
            SDL_RenderSetClipRect(ren, &clip);
        }
        for (long long i = 0; i < nrows; i++) {
            int ry = bodyy + (int)(i * rowh) - (int)scroll;
            if (ry + rowh <= bodyy || ry >= bodyy + bodyh2)
                continue;
            for (long long cc = 0; cc < ncols; cc++) {
                ui_text(x + (colx[cc] + 1) * aw, ry,
                        grid ? grid[i * ncols + cc] : "",
                        g_font_px, (i == sel) ? COL_ACCENT : COL_TEXT);
            }
            /* 选中行：左边框那一格换成实心半块。
               原来用 ▸(U+25B8)，等宽字体里实测**根本没画出来**（空白），
               所以选中指针在字符风格下一直是看不见的。
               同批实测可用的：◆ ● ○ √ ┃ ▌ █ ≡ ║ ┄ ┊ »；
               缺字的是 ▶ ▸ ► ❯ ✔。▌ 输入框光标已经在用，出图可见。 */
            if (i == sel)
                ui_text(x, ry, "▌", g_font_px, COL_ACCENT);
        }
        if (ren != NULL)
            SDL_RenderSetClipRect(ren, NULL);

        /* 滚动条复用右边框那一列：轨道 │（已画），滑块 ┃ */
        if (maxscroll > 0) {
            int trx = x + colx[ncols] * aw;
            int rows_v = bodyh2 / g_ah;
            int th = rows_v * bodyh2 / contenth;
            if (th < 1) th = 1;
            if (th > rows_v) th = rows_v;
            int thy = bodyy + (rows_v - th) * (int)(scroll / (double)maxscroll);
            for (int i = 0; i < th; i++)
                ui_text(trx, thy + i * g_ah, "┃", g_font_px,
                        g_focus == id ? COL_ACCENT : COL_BORDER);
        }
        free(colx);
        free(ccw);
    } else {
    /* ---- 画：底槽 → 裁剪画行 → 表头 → 滚动条 → **最后**画外框圆角描边 ----
       描边必须垫在最后：表格没有表头时行是从容器顶边铺下去的（bodyy = y），
       嵌套圆角那套垫在底下的外框会被方角行盖掉，圆角表格露出两个直角。 */
    {
        int r = 8;
        ui_round_a(x, y + 3, w, vh, r, COL_SHADOW, SH_PANEL, UIRC_ALL);
        ui_round(x, y, w, vh, r, COL_TRACK);
    }

    if (ren != NULL) {
        SDL_Rect clip;
        clip.x = bodyx; clip.y = bodyy; clip.w = bodyw; clip.h = bodyh2;
        SDL_RenderSetClipRect(ren, &clip);
    }
    for (long long i = 0; i < nrows; i++) {
        int ry = bodyy + (int)(i * rowh) - (int)scroll;
        if (ry + rowh <= bodyy || ry >= bodyy + bodyh2)
            continue;
        UiCol rc = (i == hover_row) ? COL_PANEL2
                 : ((i == sel)        ? COL_PANEL
                                     : ((i % 2 == 0) ? COL_PANEL : COL_ZEBRA));
        ui_fill(bodyx, ry, bodyw, rowh, rc);
        if (i == sel) {
            ui_round(bodyx, ry, 3, rowh, 2, COL_ACCENT);   /* 选中行的主色标记 */
        }
        int tx = bodyx + 6;
        for (long long cc = 0; cc < ncols; cc++) {
            ui_text(tx, ry + (rowh - g_font_px) / 2, grid ? grid[i * ncols + cc] : "",
                    g_font_px, (i == sel) ? COL_ACCENT : COL_TEXT);
            tx += (int)colw[cc];
        }
    }
    if (ren != NULL)
        SDL_RenderSetClipRect(ren, NULL);

    if (has_hdr) {
        /* 表头只圆上面两个角：底下是直的，接表格主体 */
        ui_round_a(x + 1, y + 1, w - 2, headerh, 7, COL_TRACK, 255, 1 | 2);
        ui_hline(x + 1, y + headerh - 1, w - 2, COL_BORDER);
        int tx = bodyx + 6;
        for (long long cc = 0; cc < nh; cc++) {
            ui_text(tx, y + (headerh - g_font_px) / 2, hdr[cc], g_font_px, COL_DIM);
            tx += (int)colw[cc];
        }
    }
    if (maxscroll > 0) {
        ui_round(trackx, bodyy, sb_w, bodyh2, sb_w / 2, COL_BG);
        ui_round(trackx + 1, thumby, sb_w - 2, thumbh, (sb_w - 2) / 2,
                 (g_focus == id) ? COL_ACCENT : COL_BORDER);
    }
    ui_corner_cut(x, y, w, vh, 8, COL_TRACK);
    ui_round_stroke(x, y, w, vh, 8, COL_BORDER);
    }   /* 圆角风格结束 */

    st->num = scroll;
    if (grid != NULL) {
        for (long long k = 0; k < nrows * ncols; k++)
            free(grid[k]);
        free(grid);
    }
    if (hdr != NULL) {
        for (long long c = 0; c < nh; c++)
            free(hdr[c]);
        free(hdr);
    }
    free(colw);

    ui_advance(w, vh);
    return rt_int(sel);
}
