# -*- coding: utf-8 -*-
"""往 pybook_lib.c 插入一批新数学库入口（特殊函数 / 一维优化 / 插值 / 拟合）。

pybook_lib.c 是混合行尾（实测 CRLF=1155 bareLF=12），这里一律用 \\r\\n 写。
锚点用**下一节的注释头**，不用「函数名 + {」——后者会插进函数体内部。
"""
import io
import sys

PATH = "pybook_lib.c"

CODE = r'''
/* ================= 特殊函数：gamma / lgamma / erf / erfc / zeta =================
 *
 * 这五个是真正「没有就写不出东西」的一档：正态分布的 CDF 要 erf，
 * 阶乘要 gamma，狄利克雷卷积、贝塞尔积分、Zeta 分布都要 gamma；
 * 解析数论和级数求和则离不开 zeta。它们都不是「C 标准库顺手就有」的东西
 * —— <math.h> 里只有 lgamma 一个，erf 在 MinGW 上要 C99 才给。
 *
 * 精度上刻意不做「够用就行」的近似：
 *   - gamma / lgamma 用 Lanczos g=7 的 9 项有理式，相对误差 ~1e-15；
 *     lgamma 走同一条级数取对数，而不是用 lgamma() 也不该信的老近似。
 *   - erf / erfc 走**不完全 gamma**（a=1/2）而不是那张误差 1.5e-7 的
 *     Abramowitz-Stegun 表 —— 7 位有效数字在拟合/统计里是会出事的。
 *   - zeta 用 Euler-Maclaurin，尾部展开到 6 项。
 * ------------------------------------------------------------------------- */

#define LIB_PI 3.14159265358979323846

/* Lanczos g=7 的 9 个系数（Gamma 函数的经典有理逼近） */
static const double LG7[9] = {
    0.99999999999980993, 676.5203681218851,   -1259.1392167224028,
    771.32342877765313,  -176.61502916214059, 12.507343278686905,
    -0.13857109526572012, 9.9843695780195716e-6, 1.5056327351493116e-7
};

/* 同一条级数的值：x = c0 + c1/(z) + c2/(z+1) + …（z > 0） */
static double lanczos_x(double z)
{
    double x = LG7[0];
    int    i;
    for (i = 1; i < 9; i++) x += LG7[i] / (z + i - 1.0);
    return x;
}

double lib_gamma(double z)                 /* Γ(z)，z 为负整数以外的任意实 */
{
    if (z > 0.0)
        return sqrt(2.0 * LIB_PI) * pow(z + 7.0 - 0.5, z - 0.5) * lanczos_x(z);
    /* z <= 0：反射公式 Γ(z)Γ(1−z) = π/sin(πz) */
    {
        double s = sin(LIB_PI * z);
        if (s == 0.0) return 0.0 / 0.0;   /* 极点 */
        return LIB_PI / (s * lib_gamma(1.0 - z));
    }
}

double lib_lgamma(double z)                /* log|Γ(z)| */
{
    if (z > 0.0) {
        double t = z + 7.0 - 0.5;
        return 0.5 * log(2.0 * LIB_PI) + (z - 0.5) * log(t) + log(lanczos_x(z));
    }
    {
        double s = sin(LIB_PI * z);
        if (s == 0.0) return 1.0 / 0.0;   /* 极点 */
        return log(LIB_PI / fabs(s)) - lib_lgamma(1.0 - z);
    }
}

/* ---- 不完全 gamma：P(a,x) 用级数，Q(a,x) 用连分数（Numerical Recipes 的标准分法） ---- */

static double ig_series(double a, double x)
{
    double ap = a, sum = 1.0 / a, del = sum;
    int    n;
    for (n = 1; n <= 1000; n++) {
        ap += 1.0;
        del *= x / ap;
        sum += del;
        if (fabs(del) <= fabs(sum) * 1e-16) break;
    }
    return sum * exp(-x + a * log(x) - lib_lgamma(a));
}

static double ig_cfrac(double a, double x)
{
    const double tiny = 1e-300;
    double b = x + 1.0 - a, c = 1.0 / tiny, d = 1.0 / b, h = d;
    int    i;
    for (i = 1; i <= 1000; i++) {
        double an = -(double)i * ((double)i - a);
        double del;
        b += 2.0;
        d = an * d + b; if (fabs(d) < tiny) d = tiny;
        c = b + an / c;  if (fabs(c) < tiny) c = tiny;
        d = 1.0 / d;
        del = d * c;
        h *= del;
        if (fabs(del - 1.0) <= 1e-16) break;
    }
    return exp(-x + a * log(x) - lib_lgamma(a)) * h;
}

double lib_gammap(double a, double x)       /* P(a,x) = γ(a,x)/Γ(a) */
{
    if (x < 0.0 || a <= 0.0) return 0.0 / 0.0;
    if (x < a + 1.0) return ig_series(a, x);
    return 1.0 - ig_cfrac(a, x);
}

/* erf / erfc —— 都是不完全 gamma 在 a=1/2 上的特例 */
double lib_erf(double x)
{
    double p = lib_gammap(0.5, x * x);
    return (x < 0.0) ? -p : p;
}

double lib_erfc(double x)
{
    double q = 1.0 - lib_gammap(0.5, x * x);
    return (x < 0.0) ? 2.0 - q : q;
}

Value rt_lib_mt_erf(Value x)
{
    return rt_float(lib_erf(lib_num(x, "mt.erf 的 x")));
}

Value rt_lib_mt_erfc(Value x)
{
    return rt_float(lib_erfc(lib_num(x, "mt.erfc 的 x")));
}

Value rt_lib_mt_gamma(Value x)
{
    return rt_float(lib_gamma(lib_num(x, "mt.gamma 的 x")));
}

Value rt_lib_mt_lgamma(Value x)
{
    return rt_float(lib_lgamma(lib_num(x, "mt.lgamma 的 x")));
}

/* Riemann ζ(s)：Euler-Maclaurin，尾部展开到 6 项。
 * s <= 1 是发散点，直接报「无定义」而不是给一个 ±inf 让用户自己猜。 */
double lib_zeta(double s)
{
    static const double BF[6] = {         /* B_{2k}/(2k)! */
        1.0 / 12.0, -1.0 / 720.0, 1.0 / 30240.0,
        -1.0 / 1209600.0, 1.0 / 47900160.0, -691.0 / 1307674368000.0
    };
    int    N, k, i;
    double sum = 0.0, t, ps, n2;

    if (s <= 1.0) return 0.0 / 0.0;       /* 发散 */

    /* s 越靠近 1，N/(s−1) 那项越突出，级数要求越大的 N */
    N = (int)(10.0 / (s - 1.0) + 16.0);
    if (N < 20) N = 20;
    if (N > 4000000) N = 4000000;

    for (i = 1; i < N; i++) sum += pow((double)i, -s);

    t = pow((double)N, -s);
    sum += 0.5 * t + t * (double)N / (s - 1.0);

    ps = s;                                /* 上升阶乘 (s)_(2k−1) */
    n2 = (double)N * N;
    for (k = 0; k < 6; k++) {
        if (k > 0)
            for (i = 0; i < 2; i++) ps *= (s + 2.0 * k - 2.0 + i);
        sum += t * BF[k] * ps / pow(n2, (double)k);
    }
    return sum;
}

Value rt_lib_mt_zeta(Value s)
{
    double sv = lib_num(s, "mt.zeta 的 s");
    if (sv <= 1.0)
        lib_die("mt.zeta：s=%g 处级数发散\n"
                "  为什么：ζ(s)=Σ n^(−s) 只有 s>1 才收敛，s=1 是调和级数\n"
                "  怎么改：换个 s>1；要做 s<1 的解析延拓请显式指定你要的是哪一个分支", sv);
    return rt_float(lib_zeta(sv));
}

/* ================= 一维极值：黄金分割搜索 =================
 * 为什么不直接牛顿：极值点处导数为 0，牛顿的分母为零、方向也乱。
 * 黄金分割对「单峰/单谷」函数无条件收敛，慢一点但**不依赖梯度**——
 * 用户手上往往只有一个 f，没有 f'。 */

#define GOLD_R 0.61803398874989484820      /* (√5−1)/2 */

static double golden_core(Value fnval, double a, double b,
                          int want_max, double tol, const char *who)
{
    int    it, maxit = 200;
    double c, d, fc, fd, best_x, best_f;

    if (!(a < b)) {
        double t = a; a = b; b = t;
    }
    c = b - GOLD_R * (b - a);
    d = a + GOLD_R * (b - a);
    fc = cb_num(fnval, c, who);
    fd = cb_num(fnval, d, who);
    best_x = (fc <= fd) ? c : d;
    best_f = (fc <= fd) ? fc : fd;

    for (it = 0; it < maxit && (b - a) > tol; it++) {
        if (want_max ? (fc < fd) : (fc > fd)) {
            a = c; c = d; fc = fd;
            d = a + GOLD_R * (b - a);
            fd = cb_num(fnval, d, who);
            if (want_max ? (fd > best_f) : (fd < best_f)) { best_f = fd; best_x = d; }
        } else {
            b = d; d = c; fd = fc;
            c = b - GOLD_R * (b - a);
            fc = cb_num(fnval, c, who);
            if (want_max ? (fc > best_f) : (fc < best_f)) { best_f = fc; best_x = c; }
        }
    }
    /* 中点通常比记住的那个内部点更好，两边都看一眼 */
    {
        double mid = 0.5 * (a + b);
        double fm  = cb_num(fnval, mid, who);
        if (want_max ? (fm > best_f) : (fm < best_f)) { best_f = fm; best_x = mid; }
    }
    return best_x;
}

/* mt.golden_min(f, a, b[, tol]) —— [a,b] 上找 f 的极小值点 */
Value rt_lib_mt_golden_min(Value fnval, Value av, Value bv, Value tolv)
{
    return rt_float(golden_core(fnval,
                                lib_num(av, "mt.golden_min 的左端点"),
                                lib_num(bv, "mt.golden_min 的右端点"),
                                0,
                                opt_num(tolv, 1e-10, "mt.golden_min 的容差"),
                                "mt.golden_min"));
}

/* mt.golden_max(f, a, b[, tol]) —— [a,b] 上找 f 的极大值点 */
Value rt_lib_mt_golden_max(Value fnval, Value av, Value bv, Value tolv)
{
    return rt_float(golden_core(fnval,
                                lib_num(av, "mt.golden_max 的左端点"),
                                lib_num(bv, "mt.golden_max 的右端点"),
                                1,
                                opt_num(tolv, 1e-10, "mt.golden_max 的容差"),
                                "mt.golden_max"));
}

/* ================= 插值与拟合 =================
 * 采样点(xs, ys) **必须严格递增**。这一点反复踩：二分查找找不到区间时会静默
 * 取端点插值，插出一段看着平滑、其实完全错误的曲线。所以这里显式报错，
 * 并把第一个逆序的下标算给你看。 */

static double *lib_unpack(Value v, long long *out_n, const char *who)
{
    long long n = rt_len(v), i;
    double *a;
    if (n < 1) lib_die("%s：空列表", who);
    a = (double *)malloc((size_t)n * sizeof(double));
    if (!a) lib_die("%s 内存不足", who);
    for (i = 0; i < n; i++) a[i] = lib_num(rt_index(v, rt_int(i)), who);
    *out_n = n;
    return a;
}

static void lib_check_sorted(const double *x, long long n, const char *who)
{
    long long i;
    for (i = 1; i < n; i++)
        if (!(x[i] > x[i - 1]))
            lib_die("%s：采样点必须严格递增，第 %lld 个是 %g、上一个是 %g\n"
                    "  为什么：插值靠二分找区间；点序乱了会静默插到错误的段上，"
                    "出来的曲线看着平滑、其实是错的\n"
                    "  怎么改：先把 x 排好序再传进来（mp.sorted 那类），或按同一顺序重排 y",
                    who, i, x[i], x[i - 1]);
}

/* 找 x 落在哪一段：返回 i 使得 x[i] <= q < x[i+1]；超出范围夹到端点 */
static long long lib_locate(const double *x, long long n, double q)
{
    long long lo = 0, hi = n - 2, mid;
    if (n < 2) return 0;
    if (q <= x[0])   return 0;
    if (q >= x[n - 1]) return n - 2;
    while (hi - lo > 1) {
        mid = (lo + hi) / 2;
        if (x[mid] <= q) lo = mid; else hi = mid;
    }
    return lo;
}

double mp_interp_linear_core(const double *x, const double *y, long long n, double q)
{
    long long i = lib_locate(x, n, q);
    double    t = (q - x[i]) / (x[i + 1] - x[i]);
    return y[i] + t * (y[i + 1] - y[i]);
}

/* Catmull-Rom 三次样条：过点、光滑、无需解方程组（比真样条便宜得多） */
double mp_interp_cubic_core(const double *x, const double *y, long long n, double q)
{
    long long i;
    double    t, h, p0, p1, m0, m1, h00, h10, h01, h11;
    if (n < 2) return y[0];
    if (n == 2) return y[0] + (q - x[0]) / (x[1] - x[0]) * (y[1] - y[0]);
    i = lib_locate(x, n, q);
    if (q <= x[0])     i = 0;
    if (q >= x[n - 1]) i = n - 2;
    h  = x[i + 1] - x[i];
    t  = (q - x[i]) / h;
    p0 = y[i];
    p1 = y[i + 1];
    /* 两端斜率：内部用中心差分，端点用单边差分 */
    if (i == 0)
        m0 = (y[1] - y[0]) / (x[1] - x[0]);
    else
        m0 = (y[i] - y[i - 1]) / (x[i] - x[i - 1]);
    if (i + 1 >= n - 1)
        m1 = (y[n - 1] - y[n - 2]) / (x[n - 1] - x[n - 2]);
    else
        m1 = (y[i + 2] - y[i]) / (x[i + 2] - x[i]);
    h00 =  2 * t * t * t - 3 * t * t + 1;
    h10 =    t * t * t - 2 * t * t + t;
    h01 = -2 * t * t * t + 3 * t * t;
    h11 =    t * t * t -     t * t;
    return h00 * p0 + h10 * h * m0 + h01 * p1 + h11 * h * m1;
}

Value rt_lib_mp_interp_linear(Value xv, Value yv, Value qv)
{
    long long nx, ny;
    double    q = lib_num(qv, "mp.interp_linear 的查询点");
    double   *x = lib_unpack(xv, &nx, "mp.interp_linear 的 xs");
    double   *y = lib_unpack(yv, &ny, "mp.interp_linear 的 ys");
    double    r;
    if (nx != ny) {
        free(x); free(y);
        lib_die("mp.interp_linear：xs 长度 %lld 与 ys 长度 %lld 不一致", nx, ny);
    }
    lib_check_sorted(x, nx, "mp.interp_linear");
    r = mp_interp_linear_core(x, y, nx, q);
    free(x); free(y);
    return rt_float(r);
}

Value rt_lib_mp_interp_cubic(Value xv, Value yv, Value qv)
{
    long long nx, ny;
    double    q = lib_num(qv, "mp.interp_cubic 的查询点");
    double   *x = lib_unpack(xv, &nx, "mp.interp_cubic 的 xs");
    double   *y = lib_unpack(yv, &ny, "mp.interp_cubic 的 ys");
    double    r;
    if (nx != ny) {
        free(x); free(y);
        lib_die("mp.interp_cubic：xs 长度 %lld 与 ys 长度 %lld 不一致", nx, ny);
    }
    lib_check_sorted(x, nx, "mp.interp_cubic");
    r = mp_interp_cubic_core(x, y, nx, q);
    free(x); free(y);
    return rt_float(r);
}

/* 最小二乘直线：解正规方程（中心化后斜率 = Σ(x−x̄)(y−ȳ)/Σ(x−x̄)²）。
 * 中心化这一步不是为了好看：直接解 [[Σx²,Σx],[Σx,n]] 那个正规方程，
 * x 的量级一大就数值不稳（这是教科书上要中心化的原因，不是审美问题）。 */
Value rt_lib_mp_linfit(Value xv, Value yv)
{
    long long n, ny, i;
    double   *x = lib_unpack(xv, &n, "mp.linfit 的 x");
    double   *y = lib_unpack(yv, &ny, "mp.linfit 的 y");
    double    sx = 0, sy = 0, sxx = 0, sxy = 0, syy = 0, mx, my, k, b, r2, den;
    Value     out;

    if (ny != n) {
        free(x); free(y);
        lib_die("mp.linfit：x 长度 %lld 与 y 长度 %lld 不一致", n, ny);
    }
    if (n < 2) { free(x); free(y); lib_die("mp.linfit：至少要 2 个样本"); }

    for (i = 0; i < n; i++) { sx += x[i]; sy += y[i]; }
    mx = sx / (double)n;
    my = sy / (double)n;
    for (i = 0; i < n; i++) {
        double dx = x[i] - mx, dy = y[i] - my;
        sxx += dx * dx;
        sxy += dx * dy;
        syy += dy * dy;
    }
    den = sxx;
    if (den == 0.0) {
        free(x); free(y);
        lib_die("mp.linfit：所有 x 都一样，画不出直线\n"
                "  为什么：最小二乘要对 x 求导，x 没有变化就没有斜率可言\n"
                "  怎么改：给 x 一些分散的值；纯竖直的数据请改用别的模型");
    }
    k = sxy / den;
    b = my - k * mx;
    r2 = (syy > 0.0) ? (sxy * sxy) / (den * syy) : 1.0;
    out = rt_list_new();
    rt_list_push(out, rt_float(k));
    rt_list_push(out, rt_float(b));
    rt_list_push(out, rt_float(r2));
    free(x); free(y);
    return out;
}

/* 高斯消元（带部分主元），就地解 A·x = b，A 是 m×m 行主序 */
static int lib_gauss(double *a, double *b, int m, double *x)
{
    int    i, j, k;
    double t, big;
    for (k = 0; k < m; k++) {
        int    piv = k;
        double best = fabs(a[(size_t)k * m + k]);
        for (i = k + 1; i < m; i++) {
            t = fabs(a[(size_t)i * m + k]);
            if (t > best) { best = t; piv = i; }
        }
        if (best < 1e-300) return 0;
        if (piv != k) {
            for (j = 0; j < m; j++) {
                t = a[(size_t)k * m + j];
                a[(size_t)k * m + j] = a[(size_t)piv * m + j];
                a[(size_t)piv * m + j] = t;
            }
            t = b[k]; b[k] = b[piv]; b[piv] = t;
        }
        for (i = k + 1; i < m; i++) {
            double f = a[(size_t)i * m + k] / a[(size_t)k * m + k];
            a[(size_t)i * m + k] = 0.0;
            for (j = k + 1; j < m; j++)
                a[(size_t)i * m + j] -= f * a[(size_t)k * m + j];
            b[i] -= f * b[k];
        }
    }
    for (i = m - 1; i >= 0; i--) {
        double s = b[i];
        for (j = i + 1; j < m; j++) s -= a[(size_t)i * m + j] * x[j];
        x[i] = s / a[(size_t)i * m + i];
    }
    return 1;
}

/* mp.polyfit(xs, ys, deg) —— 最小二乘多项式拟合，返回系数 [c0, c1, …, cdeg]（升幂） */
Value rt_lib_mp_polyfit(Value xv, Value yv, Value degv)
{
    long long n, ny, i, j, k;
    double   *x = lib_unpack(xv, &n, "mp.polyfit 的 x");
    double   *y = lib_unpack(yv, &ny, "mp.polyfit 的 y");
    int       deg = (int)lib_num(degv, "mp.polyfit 的次数");
    int       m = deg + 1;
    double   *A, *B, *cx, *mx, *my;
    Value     out;

    if (ny != n) {
        free(x); free(y);
        lib_die("mp.polyfit：x 长度 %lld 与 y 长度 %lld 不一致", n, ny);
    }
    if (deg < 0 || deg > 12) {
        free(x); free(y);
        lib_die("mp.polyfit：次数 %d 超出 0~12\n"
                "  为什么：范德蒙德正规方程的条件数随次数指数增长，再高就数值不稳了\n"
                "  怎么改：换横轴单位缩小 x 的量级（拟合前先减掉均值），或分段低次拟合", deg);
    }
    if (n < m) {
        free(x); free(y);
        lib_die("mp.polyfit：%lld 个样本拟合 %d 次多项式不够（至少要 %d 个）", n, deg, m);
    }

    /* 同样先中心化：x 的量级一大，正规方程直接失稳 */
    mx = (double *)malloc(sizeof(double) * (size_t)n);
    my = (double *)malloc(sizeof(double) * (size_t)n);
    A  = (double *)calloc((size_t)m * m, sizeof(double));
    B  = (double *)calloc((size_t)m, sizeof(double));
    cx = (double *)calloc((size_t)m, sizeof(double));
    if (!mx || !my || !A || !B || !cx) {
        free(x); free(y); free(mx); free(my); free(A); free(B); free(cx);
        lib_die("mp.polyfit 内存不足");
    }
    {   double sx = 0, sy = 0;
        for (i = 0; i < n; i++) { sx += x[i]; sy += y[i]; }
        sx /= (double)n; sy /= (double)n;
        for (i = 0; i < n; i++) { mx[i] = x[i] - sx; my[i] = y[i] - sy; }
    }
    for (i = 0; i < n; i++) {
        double pw = 1.0;
        for (j = 0; j < m; j++) {
            for (k = 0; k < m; k++) A[(size_t)j * m + k] += pw;
            B[j] += pw * my[i];
            pw *= mx[i];
        }
    }
    if (!lib_gauss(A, B, m, cx)) {
        free(x); free(y); free(mx); free(my); free(A); free(B); free(cx);
        lib_die("mp.polyfit：正规方程奇异，样本在横轴上退化（比如有重复的 x）\n"
                "  为什么：x 全都一样或只有有限几种取值时，多项式拟合不唯一\n"
                "  怎么改：让 x 有足够多的不同取值");
    }
    out = rt_list_new();
    for (j = 0; j < m; j++) rt_list_push(out, rt_float(cx[j]));
    free(x); free(y); free(mx); free(my); free(A); free(B); free(cx);
    return out;
}

'''

ANCHOR = "/* ================= tm \xe6\x97\xb6\xe9\x97\xb4\xe6\xa8\xa1\xe5\x9d\x97 ================= */".encode("utf-8").decode("utf-8")
ANCHOR = "/* ================= tm 时间模块 ================= */"

src = io.open(PATH, "r", encoding="utf-8", newline="").read()
if "rt_lib_mt_erf" in src:
    print("已经插过了，跳过")
    sys.exit(0)

idx = src.find(ANCHOR)
if idx < 0:
    print("!! 锚点没找到")
    sys.exit(1)

block = CODE.replace("\r\n", "\n").replace("\n", "\r\n")
src = src[:idx] + block + src[idx:]
io.open(PATH, "w", encoding="utf-8", newline="").write(src)
print("OK 已插入 %d 字节" % len(block.encode("utf-8")))