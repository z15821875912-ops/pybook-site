"""对 图表库验证.pybk 做前缀二分：每 N 行插一个 }STOP，看从第几行开始崩。
（前面 _调试图/_二分 只能覆盖单点，覆盖不到组合触发。）"""
import io, subprocess, sys, os
sys.stdout.reconfigure(encoding='utf-8')

SRC = '图表库验证.pybk'
orig = io.open(SRC, encoding='utf-8').read().split('\n')
head = [i for i, l in enumerate(orig) if l.strip() == 'GOING:{'][0]
body = orig[head + 1:]
stop_at = next(i for i, l in enumerate(body) if l.strip() == '}STOP')

def run(nlines):
    # 语言要求「恰好一个 GOING 块、其后无内容」，所以只能截断、不能留尾巴
    lines = list(orig[:head + 1]) + body[:nlines] + ['}STOP']
    io.open('_前缀.pybk', 'w', encoding='utf-8', newline='\n').write('\n'.join(lines))
    try:
        r = subprocess.run([sys.executable, 'pybk_main.py', '_前缀.pybk'],
                           capture_output=True, text=True, encoding='utf-8',
                           timeout=180, errors='replace')
        return r.returncode, (r.stderr or '').strip()[:90]
    except subprocess.TimeoutExpired:
        return -1, 'timeout'

print('总正文 %d 行' % stop_at, flush=True)
lo, hi = 1, stop_at          # 前 lo 行能过、前 hi 行崩
if run(lo)[0] == 0 and run(hi)[0] == 0:
    print('整个文件都不过不了二分，先单看整体')
    lo, hi = 1, stop_at
else:
    while hi - lo > 1:
        mid = (lo + hi) // 2
        rc, err = run(mid)
        mark = '过' if rc == 0 else '崩'
        print('  前 %3d 行 -> %s %s   (%s)' % (mid, mark, err, body[mid - 1].strip()[:48]), flush=True)
        if rc == 0:
            lo = mid
        else:
            hi = mid
    print('\n★ 第一个崩点在前 %d 行，最后一行是：' % hi)
    for k in range(max(0, hi - 4), hi):
        print('   %4d| %s' % (k + 1, body[k]))
