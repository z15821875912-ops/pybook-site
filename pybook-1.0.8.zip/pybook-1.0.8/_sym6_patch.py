# -*- coding: utf-8 -*-
"""_sym6_patch.py —— 修「2x 省乘号」用例写法 + series 小数系数 snap_frac 回认。
    S1  cases.py T28_sym_limit_ok: (2x+1) -> (2*x+1)（sym 公式语言要求显式乘号）
    S2  pybook_sym.c series: double 系数先试 snap_frac 回认小分母分数（dens<=64, 1e-6）
幂等 count==1，二进制保 LF。"""
import io, sys

def patch(path, items):
    s = io.open(path, 'rb').read()
    for label, old, new in items:
        ob, nb = old.encode('utf-8'), new.encode('utf-8')
        n = s.count(ob)
        if n == 0 and s.count(nb) == 1:
            print('skip ' + label + '（已在位）')
            continue
        if n != 1:
            sys.stderr.write('FAIL [%s] count=%d\n' % (label, n)); sys.exit(1)
        s = s.replace(ob, nb, 1)
        print('ok  ' + label)
    io.open(path, 'wb').write(s)
    print('写入 %s, 裸 CR %d' % (path, s.count(b'\r')))

patch('tests/cases.py', [
    ("S1 T28 极限用例改显式乘号",
     'ns.show(sym.极限("(2x+1)/(x-3)", "x", "inf"))',
     'ns.show(sym.极限("(2*x+1)/(x-3)", "x", "inf"))'),
])

patch('pybook_sym.c', [
    ("S2 series double 系数 snap 回认",
     "            if (k == 0) {\n"
     "                /* 常数项必是首项：负号留在系数里出 \"-1/6\"，不包 NEG */\n"
     "                t = exact ? nd_frac(&ar, c) : nd_num(&ar, v);\n"
     "            } else {\n",
     "            if (!exact) {\n"
     "                /* 数值系数也试一次小分母分数回认（dens<=64、相对 1e-6 内才认）：\n"
     "                 * -7/54 这类 diff 数值噪声后面的整齐分数不该留成一串小数 */\n"
     "                Frac sc;\n"
     "                if (snap_frac(v / (double)ser_fact(k), &sc) && sc.den != 0) {\n"
     "                    c = sc; exact = 1;\n"
     "                }\n"
     "            }\n"
     "            if (k == 0) {\n"
     "                /* 常数项必是首项：负号留在系数里出 \"-1/6\"，不包 NEG */\n"
     "                t = exact ? nd_frac(&ar, c) : nd_num(&ar, v);\n"
     "            } else {\n"),
])
print('=== _sym6_patch 全部通过 ===')
