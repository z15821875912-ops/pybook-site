"""反向验证：把三个修复逐个退回旧写法，确认新加的断言真的会失败。
（只在本地临时换文件，跑完立刻还原；任何一步异常都会先还原再退出。）"""
import os
import shutil
import subprocess
import sys

sys.stdout.reconfigure(encoding='utf-8')

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, 'pybook_plot.c')
BAK = os.path.join(HERE, '_pybook_plot_备份.c')

# 名字 -> (现在的新写法, 退回的旧写法)
REVERTS = {
    '饼图多边形闭合': (
        "            int vn = steps + 2;\n"
        "            for (int k = 0; k < vn; k++) {\n"
        "                int k2 = (k + 1) % vn;\n",
        "            for (int k = 0; k <= steps; k++) {\n"
        "                int k2 = k + 1;\n",
    ),
    '柱底不写类目': (
        "    pt_fill(c, c->pl - 6, c->pb + 1, c->pr + 6, c->pb + 14, c->bg);\n",
        "",
    ),
    '柱底写数值': (
        "        /* 柱底写**类目**（cats[i]），不是柱子高度 */\n"
        "        const char *lab = rt_str_of(CV->items[i]);\n"
        "        pt_text(c, cx - pt_text_w(lab, 1) / 2, c->pb + 7, lab,\n",
        "        char buf[32];\n"
        "        pt_fmt_num(buf, sizeof buf, v, 3);\n"
        "        pt_text(c, cx - pt_text_w(buf, 1) / 2, c->pb + 7, buf,\n",
    ),
    '好数刻度-y': (
        "    double ystep = pt_nice_step(ymax - ymin, 10);\n"
        "    for (int i = 0; i < 64; i++) {\n"
        "        double v = ceil(ymin / ystep - 1e-9) * ystep + (double)i * ystep;\n"
        "        if (v > ymax + ystep * 1e-9) break;\n",
        "    for (int i = 0; i <= 10; i++) {\n"
        "        double v = ymin + (ymax - ymin) * i / 10.0;\n",
    ),
    '好数刻度-x': (
        "    double xstep = pt_nice_step(xmax - xmin, 10);\n"
        "    for (int i = 0; i < 64; i++) {\n"
        "        double v = ceil(xmin / xstep - 1e-9) * xstep + (double)i * xstep;\n"
        "        if (v > xmax + xstep * 1e-9) break;\n",
        "    for (int i = 0; i <= 10; i++) {\n"
        "        double v = xmin + (xmax - xmin) * i / 10.0;\n",
    ),
    # ---- 下面两条是「画极点函数」时补的 ----
    '除零不再中断整张图': (
        "            if (b == 0.0) return 0.0 / 0.0;\n",
        '            if (b == 0.0) { pt_perr(ps, "除以零"); return 0.0; }\n',
    ),
    '孤立点要画出来': (
        "        else pt_disc(c, px, py, (double)w * 0.5 + 0.5, col, 1);\n",
        "",
    ),
}


def run_verify():
    env = dict(os.environ, PYTHONUTF8='1', PYTHONIOENCODING='utf-8')
    p = subprocess.run([sys.executable, 'pybk_main.py', '图表库验证.pybk'],
                       cwd=HERE, capture_output=True, text=True, encoding='utf-8', env=env)
    out = p.stdout + p.stderr
    ok = fail = None
    for line in out.splitlines():
        if line.startswith('通过'):
            parts = line.split()
            ok, fail = int(parts[1]), int(parts[3])
    # 跑到一半 abort（崩溃 / plt_die）时根本不会有「通过 …」那行。
    # 这本身就是「这条修复是必需的」的铁证，必须显式报出来，不能当成 None 混过去。
    if ok is None:
        tail = [l for l in out.splitlines() if l.strip()][-3:]
        return None, None, '\n   '.join(tail)
    return ok, fail, out


good = open(SRC, encoding='utf-8', newline='').read()
shutil.copy2(SRC, BAK)
try:
    for name, (new, old) in REVERTS.items():
        if good.count(new) != 1:
            print('锚点不唯一：%s 命中 %d 次，跳过' % (name, good.count(new)))
            continue
        open(SRC, 'w', encoding='utf-8', newline='').write(good.replace(new, old))
        ok, fail, out = run_verify()
        if ok is None:
            print('\n=== 退回「%s」后：程序中途就 abort 了（这正是该修复要防的）===' % name)
            print('   ' + out)
        else:
            print('\n=== 退回「%s」后：通过 %s 失败 %s ===' % (name, ok, fail))
            for line in out.splitlines():
                if '断言失败' in line:
                    print('   ' + line.strip())
finally:
    # 关键：必须用 copy（刷新 mtime）而不是 copy2（保留 mtime）。
    # rt_cache/ 的 .o 是按「.o 比 .c 新」判缓存命中的；copy2 会把还原后的
    # pybook_plot.c 的 mtime 留在修复之前，于是缓存误判有效，之后所有运行
    # 都在跑反向验证过程中编出来的**旧版本**目标文件（表现为「新代码看着没生效」）。
    shutil.copyfile(BAK, SRC)
    os.remove(BAK)
    print('\n已还原 pybook_plot.c（mtime 已刷新）')

ok, fail, out = run_verify()
print('还原后复跑：通过 %s 失败 %s' % (ok, fail))
