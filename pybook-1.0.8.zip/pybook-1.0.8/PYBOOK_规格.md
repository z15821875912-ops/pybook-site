# PYbook 语言规格（EBNF）

> 版本：v1.0（对应编译器 1.0.11）
> 性质：**形式规格（spec）**，不是教程。本文件的目标——不看 `pybk_front.py` 源码也能照着实现一遍。
> 教程见 `语法手册.md`；库函数清单见 `PYBOOK_AI.md`。

---

## 0. 元记号约定

| 写法 | 含义 |
|---|---|
| `"vg"` / `'{'` | 字面终结符（PYbook 源码里的字符/关键字）；用引号包住避免和文档括号混 |
| `name` / `expr` / `stmt` | 非终结符 |
| `A B` | 顺序拼接 |
| `A \| B` | 二选一 |
| `( A )` | 分组 |
| `A?` | 可选（0 或 1 次） |
| `A*` | 重复 0 次或多次 |
| `A+` | 重复 1 次或多次 |
| `A , B` | 表示 A 与 B 之间有一个逗号分隔（仅用于说明，逗号本身是 `" , "` 终结符） |

**关于花括号**：EBNF 本身不用 `{}` 表示重复（那是 PYbook 代码里的块），重复一律用 `* / + / ?` 后缀表示。PYbook 源码里的块花括号写成字面 `'{' '}'`。

---

## 1. 词法（Lexicon）

### 1.1 注释
```
comment      ::= line_comment | block_comment
line_comment ::= "#" 任意字符* (直到行尾)
block_comment::= "/*" 任意字符* "*/"
```
`#` 与 `/* */` 不进入任何 Token。

### 1.2 标识符
```
ident   ::= id_start id_char*          # 允许中文、字母、下划线、数字（数字不能开头）
id_start::= 中文字 | "A".."Z" | "a".."z" | "_"
id_char ::= id_start | "0".."9"
```
标识符与关键字由词法器区分：命中 §1.5 关键字表的整体词素算关键字，否则算 `NAME`。

### 1.3 字面量
```
number  ::= [ "-" ] ( int | float )        # 注意：负号是表达式层的一元运算符，词法只出正数
int     ::= digit+
float   ::= digit+ "." digit+             # 含小数点才算浮点
string  ::= '"' string_char* '"'          # 双引号；支持转义 \n \r \t \\ \" \'
                                        # 串内含 "$名字" 视为插值（见 §11）
bool    ::= "true" | "false" | "真" | "假"
none    ::= "空" | "none"
```

### 1.4 运算符与标点
```
two_op ::= "==" | "!=" | "<=" | ">=" | "//"
one_op ::= "." | "(" | ")" | "{" | "}" | "=" | "+" | "-" | "*" | "/" | "%"
         | "<" | ">" | "," | ":" | "[" | "]" | "?" | "@"
```
复合赋值（语句层识别）：`"+=" "-"="*=" "/=" "%=" "//="`。

### 1.5 关键字（完整集合，共 79 个）
下列整体作为关键字 Token，不能当变量名/函数名：
```
net  GOING  STOP  vg  vg_ro  ns  rm  when  func  ip  vc  lock  del  list  show
input  ret  at  try  catch  onerror  and  or  not  true  false  真  假  空  none
Memoryment  web  js  csv  查  mm  lb  静  self  te  mt  rd  file  if  elif  else  while
引用  break  断  for  in  window  tm  音  调色板  import  mu  palette  macro  宏  http
ON  hw  np  tb  mp  ui  bs  tw  data  m3  smoke  ffi  lambda  mec  device
tensor  errorstopped
```
> 实现提示：碰到上面这些词直接切关键字；但注意它们也常作「前缀」用（见 §3、§9），即
> `te.split`、`lb.狗`、`web.show`、`func mec.map` 里 `te/lb/web/mec` 仍是关键字 Token，
> 靠后面的 `"."` 决定它是库调用/类/网页语句而不是普通变量。

### 1.6 保留的库模块前缀（标准库调用必须带前缀）
```
LIB_PREFIX ::= te | mt | rd | list | file | tm | 音 | 调色板 | mu | palette | http
             | net | hw | np | tb | mp | ui | bs | tw | data | m3 | smoke | ffi | mec
             | dict | js | csv | mm
```
前缀是关键字，但只在与 `"." NAME "("` 组合时才是「库调用」；单独出现或作其它组合时按对应规则处理。

---

## 2. 程序顶层结构（Program）

```
program ::= meta? prelude* main
meta    ::= "@" 任意文本 (直到行尾)            # 可选；不写按「未命名」处理
prelude ::= import_stmt                        # 引用("名") / import("名")
          | macro_def                          # 宏 名(参数){...}
          | class_def                           # lb.名 {...}
          | func_def                            # func 名(参数){...}
          | web_block_def                       # web.块 名(参数){...}  （仅顶层）
          | memoryment_stmt                    # Memoryment @N
          | on_stmt                            # ON 3D_highway
          | device_stmt                        # device auto|cpu|gpu [线程数]
          | window_stmt                        # window(normal, open)
main    ::= "GOING" ":"? block "STOP"          # STOP 必须与最后的 } 同行
```
**约束**：
- 主文件（`require_going=True`）必须恰好有一个 `GOING ... STOP`；`GOING` 之后不能再有内容。
- `prelude` 各项必须出现在 `@` 元信息之后、`GOING` 之前。
- 被 `引用()` 的模块文件：`GOING` 可有可无（有也被忽略），允许顶层 `vg.` 赋值作初始化；`GOING` 之后不能再有内容。

---

## 3. 上下文相关消歧规则（Context-Sensitive Disambiguation）—— 核心

PYbook 故意用**前缀关键字**区分「同名词素的不同角色」，这是它和 Python 最大的语法差异，也是本规格要钉死的部分。

| 前缀/位置 | 角色 | 出现位置 |
|---|---|---|
| `vg.` / `vg_ro.` | 可变全局变量（声明/赋值/下标/属性） | 语句、类体内、函数体 |
| `func` | 函数定义 | 顶层 prelude、类体内（方法） |
| `lb.名 { }` | **类定义**（多行） | 顶层 prelude |
| `lb.名(属性=默认)` | **单行类定义**（语句位置） | 语句（会被提升到类表） |
| `lb.名(...)` | **构造实例** | 表达式 / 语句（作为表达式时构造对象） |
| `lb.名.静态字段` / `lb.名.静态方法(...)` | 静态成员访问 | 表达式 / 语句 |
| `静` | 静态属性/静态方法（类体内） | 类体内 |
| `self` | 当前实例（方法内） | 表达式 / 语句（`self.属性 = ...`） |
| `web.块 名(...){}` | 网页组件定义 | 顶层 prelude |
| `web.XXX(...)` | 网页语句 / 表达式（见 §11） | 语句、表达式 |
| `ON 3D_highway` | 开启 3D 高速渲染模块 | 顶层 prelude（@ 之后、GOING 之前） |
| `引用("名")` / `import("名")` | 加载同目录 `.pybk` 模块 | 顶层 prelude |
| `Memoryment @N` | 设置内存管理模式 | 顶层 prelude |
| `LIB_PREFIX "." NAME "("` | 标准库/用户库调用 | 表达式、语句 |
| `宏 名` / `macro 名` | 宏定义 | 顶层 prelude |

**消歧判定（实现时必须按此顺序 lookahead）**：
1. 语句/表达式以 `lb` 开头时：
   - 后跟 `"." NAME "("` → 构造实例 / 静态访问（看再后面是 `"."` 还是 `"("`）；
   - 后跟 `"("` 且当前在语句位置 → 单行类定义 `lb.名(属性=默认)`；
   - 后跟 `"." NAME "." NAME "("` → 静态方法调用作语句；
   - 后跟 `"." NAME` 再 `"="` → 静态字段赋值作语句。
2. `web` 开头：后跟 `"."` 再跟 `块` → 组件定义；后跟 `"."` 其它词 → 网页语句/表达式。
3. `list` / `tw` / `data` 开头且形状为 `前缀 "." NAME "("` → 库调用（普通前缀同理，但 `list` 因与裸赋值冲突需先排除 `NAME "="` 形态）。
4. 裸 `NAME` 开头：
   - 后跟 `"("` 且 `NAME∈GAME_CALLS` → 游戏内置调用（如 `show(...)` `win(...)` `key(...)`）；
   - 后跟 `"("` 且 `NAME` 是普通名 → 用户函数调用；
   - 后跟 `"="` → 裸赋值（自动声明为模块全局）；
   - 后跟 `"["` → 下标赋值（严格模式下需 `vg.` 前缀或函数参数，否则报错）；
   - 后跟 `",` → 多重赋值/交换。

---

## 4. 语句（Statements）

```
stmt ::= vg_stmt
       | bare_assign
       | multi_assign
       | index_assign
       | member_assign
       | static_assign
       | self_assign
       | func_call_stmt          # NAME "(" args ")" 或 LIB_PREFIX"."NAME"("args")" 或 mec.名(...)
       | method_call_stmt        # expr "." NAME "(" args ")"  （实例.方法(...)）
       | game_call_stmt          # show/win/key/clear/color/box/... 内置
       | if_stmt
       | for_stmt
       | while_aging_stmt        # rm.aging.while(条件){...}
       | around_stmt             # rm.around(次数)[-> 名]{...}
       | when_stmt               # when{...}if(N)
       | try_stmt                # try{...}catch[NAME]{...}
       | onerror_stmt            # onerror[NAME]{...}  （GOING 顶层，包裹其后全部）
       | break_stmt              # break | 断
       | ret_stmt                # ret [expr]
       | class_oneline_stmt      # lb.名(属性=默认)  （语句位置单行类）
       | macro_invoke_stmt       # 宏名(实参)  （编译期内联展开）
       | ns_stmt                 # ns.show(...)  见 §11
       | web_stmt                # web.big/mid/show/img/line/link/draw/... 见 §11
       | go_stmt                 # go(方向,距离,速度)
       | check_stmt              # 查(条件,"名字")
       | lock_stmt               # lock(名) | del(名)
       | memoryment_stmt         # Memoryment @N
       | ffi_stmt                # ffi.包含/链接/声明/码/调用  （仅顶层）
       | import_stmt
       | block                   # 裸 {...} 不是语句；语句只能出现在块内
```

### 4.1 变量（vg / 裸）
```
vg_stmt       ::= ("vg" | "vg_ro") "." name
                  ( "=" expr
                  | compound_op expr          # += -= *= /= %= //=
                  | "[" expr "]" "=" expr     # 下标赋值
                  | "." name+ "=" expr        # 实例.属性 链式赋值
                  | "," ("vg"|"vg_ro") "." name )* "=" expr_list )?   # 多定义一行
ip_assign     ::= ("vg"|"vg_ro") "(" "ip" ")" "." name "=" "input" "(" string ")"
bare_assign   ::= name "=" expr               # 自动声明为模块全局
multi_assign  ::= name ("," name)* "=" (expr ("," expr)* | expr)   # 右值可单值广播
index_assign  ::= name "[" expr "]" "=" expr  # 严格模式需 vg. 前缀或当前函数参数
member_assign ::= expr "." name "=" expr     # 含 for-in 循环变量 self.属性
static_assign ::= "lb" "." name "." name "=" expr
self_assign   ::= "self" ("." name)* "=" expr
```
> 约定：显式 `vg.名 = ...` 是推荐写法；裸 `名 = ...` 在语法上也被接受（自动声明全局），
> 但下标赋值 `名[i]=` 在严格模式下必须用 `vg.名[i]=`（或处于 `@self`/`window` 框架模式、或 `名` 是当前函数参数）。

### 4.2 控制流
```
if_stmt  ::= "if" "(" expr ")" block
             ("elif" "(" expr ")" block)*
             ("else" block)?
for_stmt ::= "for" name ("," name)? "in" expr block     # 双名 = 遍历字典(键,值)
while_aging_stmt ::= "rm" "." "aging" "." "while" "(" expr ")" block
around_stmt     ::= "rm" "." "around" "(" expr ")"
                    ("-" ">" name)? block                # 自定义计数器名，默认 "at"
when_stmt       ::= "when" block "if" "(" integer ")"    # 数字优先级
try_stmt        ::= "try" block "catch" (name)? block
onerror_stmt    ::= "onerror" (name)? block              # 文件兜底 catch
break_stmt      ::= "break" | "断"                        # 仅循环内
ret_stmt        ::= "ret" (expr)?                        # 裸 ret = 返回空
```

### 4.3 游戏 / 网页 / 其它
```
go_stmt     ::= "go" "(" direction "," expr "," expr ")"
direction   ::= "右"|"左"|"上"|"下"|"right"|"left"|"up"|"down"
check_stmt  ::= "查" "(" expr "," string ")"             # 测试断言
lock_stmt   ::= ("lock" | "del") "(" name ")"
ns_stmt     ::= "ns" "." "show" "(" ns_content ")" ("/" "magic" "(" magic_args ")")?
                ("vc" ":" expr "?" "(" ns_content ")")?   # 短 vc 条件替代
web_stmt    ::= "web" "." web_comp                       # 见 §11
```
`ns_content` 与 `magic_args` 走「原始扫描」规则（见 §11），不是普通表达式语法。

---

## 5. 表达式（Expressions）—— 运算符优先级（低→高）

```
expr        ::= ternary
ternary     ::= or_expr ("?" expr ":" ternary)?
or_expr     ::= and_expr ("or" and_expr)*
and_expr    ::= cmp_expr ("and" cmp_expr)*
cmp_expr    ::= add_expr ((CMP_OP | "in" | "not" "in") add_expr)*
add_expr    ::= mul_expr (("+"|"-") mul_expr)*
mul_expr    ::= unary_expr (("*"|"/"|"%"|"//") unary_expr)*
unary_expr  ::= ("-"|"not") unary_expr | primary
primary     ::= literal
              | "true"|"false"|"真"|"假"|"空"|"none"
              | "input" "(" string ")"
              | name (suffixes)? ( "(" args ")" suffixes? )?   # 变量 / 函数调用 / 调用后链式
              | "(" expr ")"
              | "[" (expr ("," expr)*)? "]" (comprehension | suffixes)?   # 列表字面量/推导
              | "{" (pair ("," pair)*)? "}" (dict_comp | suffixes)?        # 字典字面量/推导
              | "self" suffixes?
              | "at"                                # rm.around 循环计数器
              | "lb" "." name ( "." name ( "(" args ")" | ε )        # 构造 / 静态访问
                            | "(" ctor_args ")" )
              | "lambda" "(" (name ("," name)*)? ")" block           # mec lambda
              | "frame" | "sec"                      # 内置：当前帧数 / 秒数
              | LIB_PREFIX "." name "(" args ")"      # 标准库 / 用户库调用（含 音.正弦 等别名翻译）
              | "list" "." name "(" args ")"
              | ("tw"|"data") "." name "(" args ")"
              | "web" "." ("click"|"mx"|"my") "(" ")"
              | "web" "." ("text"|"down") "(" expr ")"
              | "web" "." "存" "(" expr "," expr ")"
              | "调色板" "." color ( "(" ")" )?       # 零参库调用，返回 [r,g,b]
              | GAME_CALLS_NAME "(" args ")"          # key/win/clear/color/box/show/wait/end...
              | macro_invoke_expr                     # 宏在表达式位置展开（极少见）

suffixes    ::= ( "[" subscript "]" | "." name ( "(" args ")" )? )*   # 可任意叠加（链式）
subscript   ::= expr (":" (expr)? (":" (expr)?)?)?     # 普通下标 或 切片 [a:b:c]
pair        ::= expr ":" expr
ctor_args    ::= (name "=" expr ("," name "=" expr)*)      # 关键字构造实参
              | (expr ("," expr)*)                         # 位置构造实参
              | ε
args        ::= (expr ("," expr)*)?
CMP_OP      ::= "==" | "!=" | "<" | ">" | "<=" | ">="
literal     ::= number | string | bool | none
```

**优先级速记**：`or` < `and` < 比较/`in` < `+ -` < `* / % //` < 一元 `-`/`not` < 后缀(下标/属性/调用)。
三元 `? :` 优先级仅高于 `or`，且 `:` 右侧可再套三元（右结合）。

---

## 6. 函数（func）

```
func_def ::= "func" (name | LIB_PREFIX "." name)        # func mec.map 形式
             "(" (param ("=" expr)? ("," param ("=" expr)?)*)? ")"
             ( "=" expr                          # 单行函数：func f(x) = 表达式
             | block )
param    ::= name
```
- 参数可带默认值（`func f(x, n=0)`），默认值在解析期求值。
- 函数名可带库前缀（`func mec.map(...)`），用以定义用户库函数。
- 方法（类体内）也是 `func`，只是出现在 `class_def` 的 `class_member` 位置。

---

## 7. 宏（宏 / macro）

```
macro_def ::= ("宏" | "macro") name
              "(" (param ("," param)*)? ")"
              block
```
- 宏是**编译期内联展开**：在 codegen 期把实参替换形参后，把宏体语句就地展开到调用点。
- 宏**只能当语句**（语句位置写 `宏名(实参)` 触发展开），不支持递归，参数不可重复。
- 实参个数必须与形参一致（否则报「宏 需要 N 个参数」）。
- 同名宏重复定义 / 宏名与函数名冲突，在 codegen 期报错。

---

## 8. 类系统（lb.）

```
class_def ::= "lb" "." name
              ("(" (param ("," param)*)? ")")?     # 构造形参（位置实参用）
              (":" name)?                          # 父类（继承，单继承）
              "{" class_member* "}"
class_member ::= ("静")?
                 ( "vg" "." name ("=" expr)?        # 实例属性(带默认) / 静态字段(带 静)
                 | "func" func_body )               # 方法 / 静态方法(带 静)
class_oneline ::= "lb" "." name "(" (name "=" expr ("," name "=" expr)*)? ")"
```
规则：
- **属性**：`vg.属性名 = 默认值`；不写 `=` 仅声明（默认 `none`）。
- **方法**：`func 方法名(参数){...}`；方法体内用 `self` 指代当前实例，`self.属性` 访问成员。
- **构造形参**：写在类头部 `lb.点(x,y){...}`，位置实参按序注入；约定用名为 `构造` 的方法作构造函数体（接收这些形参）。
- **继承**：`lb.狗 : 动物`；运行时沿继承链分发方法，属性表合并（子类在后）。构造实参/属性名按「本类 + 全部父类」校验。
- **静态**：`静 vg.字段 = 默认` 为文件级全局静态字段（启动初始化）；`静 func 方法(){...}` 为静态方法，调用写 `lb.类名.方法(...)`、`lb.类名.字段` 访问静态字段。
- 单行类 `lb.名(属性=默认)` 出现在语句位置时，被提升到类表（等同多行只含属性的类）。

---

## 9. 标准库调用（前缀.函数）

```
lib_call ::= LIB_PREFIX "." name "(" args ")"
```
- 名字 = `前缀.函数` 必须落在 `LIB_CALLS` 表中（除 `mec.` 为用户库，名字对错交 codegen 期判定）。
- 参数个数在解析期校验（`tm.stop` 特例：1 或 2 个；`hw.camera` 4 参补俯仰 0；`hw.box` 12 参含旋转；`hw.cyl` 10 参；`hw.uni` 2~5 参；`ffi.调用` 至少 1 参）。
- 别名翻译：`音.sine→音.正弦` 等；`调色板.红()` 等价于 `调色板.红`（零参，返回 [r,g,b]）。
- `hw.*` 必须在文件顶部先 `ON 3D_highway`，否则报「hw 模块需要先在文件顶部写 ON 3D_highway」。

---

## 10. 游戏子系统

```
game_call ::= "key"   "(" string ")"              # 键名必须是字符串字面量，且 ∈ KEY_NAMES
            | "win"   "(" expr "," expr "," string ")"
            | "clear" "(" ")"
            | "color" "(" (expr | expr "," expr "," expr) ")"
            | "box"   "(" args ")"                # 游戏矩形
            | "show"  "(" args ")"
            | "wait"  "(" expr ")"
            | "end"   "(" ")"
            | "text"  "(" args ")"                # 文本，文本参数支持 $插值
            | "img"   "(" args ")"
            | "hit"   "(" expr ")"
game_call 也可作语句（裸 `show(...)` / `win(...)` 等），因为 `show/win/key/...` 是关键字且后跟 `(`。
```
`KEY_NAMES`：`right left up down space enter esc shift` 及 `a-z` 字母，加中文 `右 左 上 下 空格 回车`。

---

## 11. 网页子系统（ns.show / web.*）

### 11.1 ns.show 的内容扫描（raw scan）
`ns.show(...)` 与 `web.big/mid/show(...)` 的圆括号**内部不走普通表达式语法**，而是「原始扫描」：
- 先按括号嵌套计数找到匹配的右 `)`；
- 顶层逗号（引号外、括号外）切分多段，各段独立处理；
- 每段若是 `"..."` 字符串 → 按文本（支持 `$插值`）；否则尝试当表达式（含 `()`/`[]` 才当表达式，否则当裸文本兼容旧写法）；解析失败自动退回裸文本；
- `$名字` 在文本里被切出为插值变量（如 `$分`）。
- 插值表达式里**不能含逗号**（先把结果存变量再显示）。

```
ns_stmt ::= "ns" "." "show" "(" ns_content ")"
            ("/" "magic" "(" magic_args ")")?        # 仅 show 支持 /magic
            ("vc" ":" expr "?" "(" ns_content ")")?  # 条件成立时显示替代内容
magic_args ::= (("c"|"b"|"i"|"u"|"s") "=" expr ("," ...)*)?   # 颜色/加粗/斜体/下划线/删除线
                                                        # 至少一段；缺段报「缺少完整的 r,g,b 三段」
```

### 11.2 web.* 语句
```
web_stmt ::= "web" "." ( "big" | "mid" | "show" ) "(" ns_content ")" ("/" "magic" "(" magic_args ")")?
           | "web" "." "img"  "(" string ")"
           | "web" "." "link" "(" string ("," string)? ")"
           | "web" "." "line"
           | "web" "." "draw" "." draw_op "(" (expr ("," expr)*)? ")"
           | "web" "." ("帧"|"frame") ("(" integer ")")? block        # 一帧动画
           | "web" "." "实时" ("(" integer ")")? block                # 浏览器实时循环
           | "web" "." ("播放"|"play") "(" expr ")"                    # 循环播放前面所有帧
           | "web" "." "textbox" "(" string "," string ("," string)? ")"
           | "web" "." "button"   "(" string "," string ")"
           | "web" "." "audio"    "(" string ")" | "web" "." "audio" "." "stop" "(" ")"
           | "web" "." "align"    "(" string ")"
           | "web" "." "gap"      "(" integer ")"
           | "web" "." "open"     "(" string ")"
           | "web" "." "style"    "(" string ")"
           | "web" "." "storage"  "(" expr "," expr ")"
           | "web" "." "waitsec"  "(" integer ")"
           | "web" "." "title"    "(" string ")"
           | "web" "." "置"       "(" expr "," expr ")"
           | "web" "." "页"       "(" string ")" block                 # 子页面（烤成独立 HTML）
           | "web" "." component_name "(" args ")"                     # 已定义的 web.块 组件
draw_op  ::= 始|色|圆|方|线|清|字|图|图缩|终  (及对应英文 begin|color|circle|rect|line|clear|text|img|imgs)
```
约束：`web.块` 组件定义只能出现在**文件顶层**（与 `func` 并列）；`web.页` 内不能用 帧/播放/实时/draw/嵌套页；`web.播放` 前必须至少有一个 `web.帧`。

### 11.3 表达式位置的 web
```
web_expr ::= "web" "." ("click"|"mx"|"my") "(" ")"
           | "web" "." ("text"|"down") "(" expr ")"
           | "web" "." "存" "(" expr "," expr ")"
```

---

## 12. 3D 高速渲染（hw.* + ON）

```
on_stmt   ::= "ON" 3D_highway          # 行尾整段必须等于 3D_highway，否则报错
hw_call   ::= "hw" "." name "(" args ")"   # 仅在 ON 3D_highway 后可用
```
`hw.*` 调用（box/cyl/uni/camera/text/...）参数个数见 §9。`hw.text` 第四参若含 `$` 自动转插值。
> 注：VM 后端（pybk_bc.py）**不支持** `hw.*`；`hw.*` 仅 C 后端可用。

---

## 13. 内存管理（Memoryment@N）

```
memoryment_stmt ::= "Memoryment" "@" mem_mode
mem_mode ::= "normal" | "self" | "1" | "2" | "3" | "4" | "5" | "6"
```
映射：`@1→普通 @2→手动(self) @3→引用计数 @4→竞技场 @5→标记清除 @6→分代+增量`。
`@self`（`@2`）模式下赋值可省 `vg.` 前缀（裸名即声明）。

---

## 14. 计算后端与线程数（device）

```
device_stmt ::= "device" dev_backend [线程数]
dev_backend ::= "auto" | "cpu" | "gpu"
```

写在文件头（`GOING`/`func` 之前），**整行扫描解析**：从 `device` 起到行尾全部按空白切 token，
多余的、非法的都报错（仿 `errorstopped` / `ON`）。

**语法约束（编译期全部拦下，不留到运行时）：**
- 缺后端 → 报「要写后端档位」；未知档位 → 报「只支持 auto / cpu / gpu」。
- 线程数只允许跟在 `cpu` 后面；`auto`/`gpu` 带数字 → 报「只有 device cpu 能带线程数」。
- 线程数必须是十进制整数且落在 `1~1024`；`cpu 4 5` 这类多余 token 报错。

**语义：有没有卡是运行时才知道的事，编译期只查语法、不查硬件。**
同一份 `.pybk` 在开发机和没卡的机器上编译结果不该不同，所以探测一律推到运行时：

| 档位 | 有 NVIDIA 卡 | 没卡 |
|---|---|---|
| `auto` | 走 GPU | 走 CPU |
| `cpu [N]` | 走 CPU，`N` 个工作线程 | 同左 |
| `gpu` | 走 GPU | **运行时报错并退出** |

`gpu` 档探测不到卡时走 `gpu_die_unavailable()`，报错带「为什么 / 怎么改」三段式，
**绝不静默退回 CPU** —— 用户明写了 `gpu`，假装上卡却跑在 CPU 上等于骗人。
一次探测定终身：定下来之后不再复探，保证同一程序前后行为一致。

调试钩子：环境变量 `PYBOOK_GPU_DISABLE=1` 强制当作「没有 GPU」，用来在有卡的机器上
验证上面第三行那条语义（回归用例 `P0_27` 就是这么跑的）。

**GPU 后端（`pybook_gpu.c`）**：NVIDIA CUDA driver API **动态加载**
（`LoadLibrary("nvcuda.dll")` + `GetProcAddress`，不链 `cuda.lib`、不 `include cuda.h`），
kernel 是**手写 PTX 字符串**、由驱动 JIT。**零构建期依赖**：不要 nvcc / NVRTC / CUDA Toolkit，
驱动在就能跑。没装 NVIDIA 驱动的机器照样编译链接运行，只是探测返回 0。

**GPU 路由规则**（`gpu_dot_try()`，四条全满足才上卡，少一条就留在 CPU）：
1. 后端确实是 GPU；
2. 输入两个张量都是 float32（FP64 吞吐通常只有 FP32 的 1/32~1/64，double 上卡是倒退）；
3. `N`、`K` 都能被 4 整除（kernel 用 float4 向量化载入，要求 16 字节对齐；`M` 不限，
   边界由 kernel 内部钳位加载 + 谓词存储处理）；
4. `M*N*K ≥ GPU_DOT_MIN_MAC`（65536）。

**上了卡却失败（显存不足、kernel 报错）一律 `tb_die`，不吞** ——
回退是设计，报错是真出事，两者必须分开。

**float32 是一等公民**：`RtTensor` 带 `prec` 字段（`TENSOR_F64=0` / `TENSOR_F32=1`）。
存储仍是 `double` 缓冲，但 f32 张量所有写入先经 `(double)(float)v` 舍入，
于是每个值都严格可被 float32 精确表示，上卡/下卡无损。
精度传播：任一输入 f32 → 输出 f32（`arith()`、`tb.dot`、`tb.lin` 一致），
**CPU 与 GPU 两条路返回同一种类型**。

**线程数优先级（三层，旋钮跟着代码走）：**
1. 文件头 `device cpu N`（最高，压过环境变量）
2. 环境变量 `PYBOOK_THREADS`
3. 逻辑处理器数（`GetSystemInfo`，上限 16 工人）

**实现要点**：走「语句」路线，与 `Memoryment` 完全对称 ——
C 后端 `pybk_code.py` emit `rt_device_set(backend, threads);`；
字节码后端 `pybk_bc.py` emit opcode `0x37 DEVICE 'BU'`（1 字节 backend + 2 字节小端线程数），
`pyvm.c` 的 `case_0x37` 读出来调同一个 `rt_device_set`。
`device` 被前置到 `GOING` 开头，保证早于任何一次 `mt_parallel`。
`pybook_tb.c` 通过 `rt_device_backend()` 读档位决定 `tb.dot` / `tb.lin` 走哪条路。

---

## 14b. 线性代数（`tb.*` 张量面 / `mp.*` 扁平面）

实现在 `pybook_la.c`。两个面共用同一份核心算法（纯 `double*`、行主序、0 基下标），
`mp.*` 内部先用 `la_from_flat()` 把「扁平列表 + 行列数」包成张量再算，**两边结果必然一致**。

**`tb.*`（吃真张量）**

| 入口 | 返回 | 说明 |
|---|---|---|
| `tb.lu(A)` | `[L, piv]` | 部分主元 Doolittle；`piv[k]` 是第 k 步换到第 k 行的行号 |
| `tb.solve(A, B)` | `x` | 解 `Ax=B`；`B` 可 1-D（单右端）或 2-D（每行一个右端） |
| `tb.det(A)` / `tb.logdet(A)` | 标量 | `logdet` 走 `Σlog|对角元|`，大矩阵不溢出 |
| `tb.inv(A)` | `A⁻¹` | 奇异时报错 |
| `tb.cond(A)` | 标量 | **1-范数**条件数 `‖A‖₁·‖A⁻¹‖₁` |
| `tb.rank(A)` | 整数 | **只对方阵有效**（走 LU） |
| `tb.qr(A)` | `[Q, R]` | Householder；`A = Q·R`，`Q` 是 `m×m`，`R` 是 `m×n` 上梯形 |
| `tb.lstsq(A, b)` | `x` | `min‖Ax-b‖`；走 SVD，欠定给 min-norm 解，秩亏自动截断 |
| `tb.cholesky(A)` | `L` | `A = L·Lᵀ`；不对称或非正定**直接报错**，不用不成立的分解算出一个看着正常的数 |
| `tb.eig_sym(A)` | `[vals, V]` | 实对称矩阵循环 Jacobi；**`vals` 升序**，`V` 第 k 列对应 `vals[k]` |
| `tb.svd(A)` | `[U, S, VT]` | 单边 Jacobi；`U` 是 `m×min`、`VT` 是 `min×n`、`S` **降序**，重建式 `A = U·diag(S)·VT` |

**`mp.*`（吃扁平列表 + 行列数）**

`mp.mat_lu(a,n)` / `mat_solve(a,b,n)` / `mat_qr(a,r,c)` / `mat_svd(a,r,c)` / `mat_eig_sym(a,n)` /
`mat_cholesky(a,n)` / `mat_ls(a,b,m,n)` / `mat_rank(a,n)` / `mat_cond(a,n)` / `mat_logdet(a,n)`，
以及互转函数 `mp.to_tensor(a,r,c)`。返回形状与 `tb.*` 一致（`mat_svd` 第三项也是 `VT`）。
反向的张量→列表用运行时现成的 `tensor.to_list`，不需要另加函数。

**精度**：任一输入是 f32 → 输出 f32，内部一律按 double 算完再舍入（与 `tb.dot` 同规矩）。

**实测精度**：对拍 NumPy `linalg` 共 261 项检查全过，最大相对误差 **2.108e-14**。

**取元素的既有语义（容易踩）**：`T[i,j]` 返回**标量**，`T[i]` 返回**行/切片张量**；
1-D 张量的 `T[i,j]` 会忽略第二个下标（`x[0,1]` 与 `x[0,0]` 同值），取第 k 个分量要用 `T[k,0]`。

---

## 15. 模块（引用 / import）

```
import_stmt ::= ("引用" | "import") "(" string ")"
```
- 加载同目录 `名字.pybk`（带不带 `.pybk` 都行）。
- 必须在 `GOING` 之前；主文件里借它被引模块的类属性表做构造器存在性/属性名校验。
- 路径/解析失败在解析期静默放过，正式报错交给 codegen 期的合并逻辑。

---

## 16. 已知歧义与解析决策（实现必读）

1. **`lb.` 三态**：顶层 `lb.名 { }`=类定义；语句位置 `lb.名(属性=默认)`=单行类定义；表达式/语句 `lb.名(...)`=构造实例；`lb.名.静态`=静态访问。靠「后跟 `{` / `(` / `.`」判别。
2. **裸赋值 vs 函数调用**：裸 `名 = ...` 是赋值（自动声明），`名(...)` 是调用——靠 `=` 还是 `(` 判别。
3. **`vg.` 不是关键字组合而是前缀**：`vg.名` 的 `vg` 是关键字，`名` 之后才能跟 `=`/`[`/`.`/`+=`。
4. **`ns.show` / `web.big/mid/show` 内容用 raw scan**：不进表达式语法，避免 `$`、括号、逗号与表达式规则冲突；这是 PYbook 与常规语言最大的「上下文相关」处。
5. **宏只展开为语句**：宏调用出现在语句位置才展开，不出现在表达式里（表达式位置若写宏名会被当普通调用处理，codegen 期才报错）。
6. **`STOP` 必须紧贴 `}`**：`GOING` 块以 `}STOP` 收尾（同一行）；否则报「STOP 必须紧跟在 } 之后」。
7. **保留字 79 个**：完整表见 §1.5；用户变量/函数名撞保留字会报「期望 'NAME'，实际是 'X'」（并附「X 是保留字」建议）。

---

## 17. 与 `语法手册.md` 的关系

- `语法手册.md` = 教程（按特性讲、给例子、给「怎么写」），**不是无歧义规格**。
- 本文件 = 形式规格（给实现者看，定义「什么算合法程序」）。
- 两者可能暂时不完全同步；以**本文件 + 测试套件 `tests/`** 为权威。新增语法特性时，先改本文件，再补 `cases.py` 用例。
