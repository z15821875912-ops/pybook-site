import subprocess, sys, os, io
sys.stdout.reconfigure(encoding='utf-8')

CASES = {
    '柱状': 'vg.板 = 图.画布(300, 200)\n图.柱状(板, ["甲","乙","丙"], [10,20,15], 0)\n',
    '直方': 'vg.板 = 图.画布(300, 200)\n图.直方(板, [1,2,2,3,3,3,4,5,5,9], 5, [70,130,220])\n',
    '饼图': 'vg.板 = 图.画布(300, 200)\n图.饼图(板, ["一","二","三"], [10,20,30])\n',
    '曲线': 'vg.板 = 图.画布(400, 300)\n图.曲线(板, "sin(x)", -6.283, 6.283, [220,40,40], 2)\n',
    '图例': 'vg.板 = 图.画布(300, 200)\n图.图例(板, 10, 10, [["甲",[255,0,0]],["乙",[0,255,0]]])\n',
    '存盘': 'vg.板 = 图.画布(120, 90)\n图.像素(板, 1, 1, [255,0,0])\n图.存(板, "_二分_存盘.png")\n',
    '轴':   'vg.板 = 图.画布(300, 200)\nvg.区 = 图.轴(板, 0, 10, 0, 100, "t", "x", "y")\n',
}

for name, body in CASES.items():
    src = '@ 二分>%s\n\nGOING:{\n%s\nns.show("走到最后了")\n}STOP\n' % (name, body)
    f = '_二分.pybk'
    io.open(f, 'w', encoding='utf-8', newline='\n').write(src)
    print('=== %s ===' % name, flush=True)
    try:
        r = subprocess.run([sys.executable, 'pybk_main.py', f],
                           capture_output=True, text=True, encoding='utf-8',
                           timeout=120, errors='replace')
        out = (r.stdout or '').strip().split('\n')
        tail = out[-2:] if len(out) > 1 else out
        print('  rc=%d  %s' % (r.returncode, ' | '.join(tail)))
        if r.stderr:
            print('  stderr:', r.stderr.strip()[:200])
    except subprocess.TimeoutExpired:
        print('  超时（死循环？）')
