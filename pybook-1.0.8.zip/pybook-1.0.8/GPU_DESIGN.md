# GPU_DESIGN.md —— GPU sgemm kernel 演进记录

> 记录 `pybook_gpu.c` 手写 PTX kernel 的优化历程。每条跳都按同一格式记：
> **病根 → 方案 → 数据 → 踩坑**。数据全部是 GTX 1060 6GB（CC 6.1，驱动 13000）
> 上的实测，口径写清楚（kernel-only = 数据常驻显存；端到端 = 含 H2D+D2H）。

## 背景：14% vs 70% 的诊断

「pybook kernel 14% vs cuBLAS 70%」的差距不在算，在**访存**。两种 kernel 的乘法
指令一模一样（FLOP 数相同），差距全在「数据住在哪、核要不要空等」：

- **数据住显存**：每次 FMA 从 global 取操作数，核大量时间空转等数据，算力饿着；
- **数据块进寄存器/共享内存**：核在快存储里现取现算，算力吃饱。

诊断落到 PTX 行：旧 kernel（4x4 寄存器分块 + float4 直取 global）每轮 4k 取
128 字节喂 64 FMA，访存/计算比 0.5 FMA/B；更致命的是 block 内 256 线程对同一
tile 元素**重复取 16 次**（A 的 64×4 tile 每元素被 16 个列方向线程各取一遍，
B 同理）——每个元素从 global 取了 16 次，而不是 1 次进 shared 后复用。

## 第一跳：shared memory tiling（2026-10-14 落地）

### 方案

BM=64 × BN=64 × BK=8，block 16×16 线程，每线程仍算 4×4 输出（**索引代码一行
没改**，风险被圈在加载段）：

1. 每轮 K-tile：256 线程**协作**把 A 的 64×8 + B 的 8×64 搬进 static shared
   （每线程 2+2 个标量，M/N/K 尾块 predicated 存 0）；
2. `bar.sync`；
3. 每线程从 shared 预取 16 个 v4（A 4 行 × 8 kk + B 8 kk × 4 列）→ 128 FMA；
4. `bar.sync`（防跑快的线程覆盖别人还没读完的 shared）。

**访存/计算比 0.5 → 8 FMA/B（16 倍）**：每个元素从 global 只取 1 次。

bank conflict 复查（v4 粒度）：A tile 行距 8 float = 32B，warp 内 ty 步进落
不同 128B 段、tx 维同地址广播；B tile tx 步进 16B，8 个 tx 一段。**两侧均无
冲突，无需 padding**。

### 尺寸路由（关键决策）

实测发现 shared 版不是全面赢：

| N | 4x4 旧版 | shared 新版 | 变化 |
|---|---|---|---|
| 128 | 208.7 | 114.9 | **−45%** |
| 256 | 569.7 | 694.7 | +22% |
| 1024 | 978.5 | 1510.1 | +54% |
| 2048 | 1008.3 | 1627.2 | **+61%** |
| 3216 | 1089.9 | 1484.1 | +36% |

（GFLOPS，kernel-only，1060 实测。4x4 在 N=2048 的 1008 是该 kernel 的历史
最好成绩，之前注释里记的 1014~1178 是另一台机器的数，以本次同机同驱动为准。）

小矩阵回退的根因：**bar.sync 串行化 + 低 occupancy**（~110 寄存器 → 每 SM
2 个 block）。小矩阵块数少，没有别的 warp 掩护加载延迟，bar 的代价全暴露；
大矩阵带宽敏感，shared 复用是净赚。

**路由规则：N ≥ 256 走 `sgemm_shared`，否则走 `sgemm`（4x4）**。实测 6 个
N≥256 用例全赢、4 个 N<256 全输，阈值干净。两个 entry 的 launch 配置完全
相同（block 16×16、grid 64 步进），C 侧只多一个函数指针选择。

### 收益（kernel-only，1060，峰值 4.37 TFLOPS）

- N=2048：1008 → 1627 GFLOPS，利用率 **23% → 37%（+14pp）**
- 第一跳到此为止；到 70%（cuBLAS 水平）还要第二跳（寄存器 4×4→8×8，+5~10pp）
  和第三跳（软件双缓冲藏 global 延迟，+5~10pp）。

### 验证

- **harness**（`_gputile.c`，kernel 从 `.ptx` 文件读、2 秒编译验证）：
  probe 诊断数据 8/8 行全对；全尺寸 bench 后向误差 ~1e-7（float 累加正常
  水平），含 68/100/132/4 等尾块尺寸；
- **生产入口**（`_gpucheck2.c` 直链 `pybook_gpu.c`）：N=128 走 4x4、N=256/512/
  1024/300 走 shared，全部与 CPU 参考一致（超差元素 0），连跑三次稳定；
- **端到端**（`build_tmp/gpu_route_e2e.pybk`，`device gpu`）：小矩阵 128³ 与
  大矩阵 512³，数据设计成 f32 精确（%3 压值域），**GPU 与 device cpu 输出
  逐字一致**（唯一差异是 `tb.gpu()` 本身 true/false）；
- 回归：`tests/run_tests.py` 136/136 + smokeroor 8/8。

### 踩坑（本轮新增 4 条）

1. **C 字符串版 PTX 与 .ptx 文件版不一致**（老坑复发）：`pybook_gpu.c` 内嵌版
   和 `_ptx_PTX_4X4.ptx` 文件版内容有差异——「改的文件没生效、测的是旧 kernel」
   正是这个坑的描述。**修复决策：以 .ptx 文件为唯一真相源**，整体替换生产字符串
   （文件版已在 1060 上全尺寸对拍验证过）。`_embed_shared_patch.py` 落地。
2. **提取 C 字符串的正则把末行 `}` 当结束标记吃掉**：`(.*?)\n\s*"\}";` 的 group
   不含 `}` 行，dump 出的 PTX 缺 `}` → JIT 218。症状是「同样的内容 harness 能
   编译、生产编不过」。排查法：diff dump 与源文件。
3. **发布打包_102 的 gcc 链接失败时吞掉 ld 全部诊断**（只有 `collect2.exe:
   error: ld returned 5`，连 undefined 列表都没有）。换 `C:\Users\zhuli\mingw64`
   的系统 gcc 立刻看到 `undefined reference to rt_die`。**链接不过又无诊断时，
   换工具链复现**。
4. **CUDA 201「invalid device context」极具误导性**（pybook_gpu.c 铁律第 3 条
   的又一例）：诊断工具 `_ptxdbg.c` 没建 context 就 `cuModuleLoadData`，报的是
   context 错而不是真因。补 `cuDevicePrimaryCtxRetain + cuCtxSetCurrent` 后
   才看到真实错误。

## 第二跳：8x8 寄存器分块（2026-10-15 落地）

### 方案

block 16×16 不变、tile 128×128、每线程 8×8 输出（64 个累加器，Pascal 255 寄存器
上限内）、每轮 512 FMA、static shared 8KB：

1. 协作加载：256 线程把 A 的 128×8 + B 的 8×128 搬进 shared（每线程 4+4 标量，
   尾块 predicated 存 0）；
2. `bar.sync`；
3. 计算段每 kk：8 个 A 标量 + 2 个 B v4 → 64 FMA，8 个 kk 共 512 FMA；
4. `bar.sync`；8×8 predicated store。

**关键优化：shared 行寻址改「基址寄存器 + 立即数」**。8x8 每线程要摸 64 个 shared
标量 + 16 个 v4，寻址指令量是 4x4 的两倍——不优化的话地址指令会淹没 FMA。改法：
每行 shared 的基址算一次进寄存器，行内 8 个元素用立即数偏移。**地址指令
320 → 3 条**。访存/计算比 8 → 16 FMA/B（global 流量再减半）。寄存器 ~104，
occupancy 与第一跳持平（每 SM 2 个 block）。

### 尺寸路由：三 kernel（关键决策，含一次数据翻案）

**初版阈值 N≥512，建立在单轮测量上**（512 +24% / 1024 +12% / 2048 +27% /
3216 +30%）。六轮交替复测把这个图景推翻了——见踩坑第 1 条，GPU 动态升频让
单次测量不可信。翻案后的同场数据（1060，kernel-only，GFLOPS，每格 4~6 轮
取中位数）：

| N | 4x4（基线） | shared | 8x8 | 8x8 vs shared | 8x8 赢的轮数 |
|---|---|---|---|---|---|
| 128 | 166.4¹ | 166.4 | 64.7 | −61% | 0/6 |
| 256 | 569.7¹ | 676.5 | 398.5 | −41% | 0/6 |
| 512 | — | 1427 | 1401 | −1.8% | 4/6 |
| 1024 | 990 | 1757 | 1664 | **−5.3%** | 1/6 |
| 1280 | — | 1568 | 1846 | **+17.7%** | 4/4 |
| 1536 | — | 1581 | 1752 | **+10.8%** | 4/4 |
| 2048 | 980 | 1866 | 2155 | **+15.5%** | 6/6 |
| 3216 | — | 1570 | 1964 | **+25.2%** | 5/6 |

（¹ 128/256 两行的 4x4 列借自第一跳同机数据表，仅作量级参考；本轮只重测了
1024/2048 两个基线。shared/8x8 列全部是本轮六轮交替实测中位数。）

**拐点是波尾量化，不是玄学**：1060 是 10 SM × 每 SM 2 个常驻 block = 每波
20 个 block。tile 128 的 grid：

| N | 8x8 block 数 | 波数 | 尾波填充 | 实测 |
|---|---|---|---|---|
| 512 | 16 | 0.8 | 机器都没铺满 | −1.8% |
| 1024 | 64 | 3.2 | 尾波只站 4 个 | −5.3% |
| 1280 | 100 | **5.0** | **正好的整波** | +17.7% |
| 2048 | 256 | 12.8 | 尾波站 16 个 | +15.5% |
| 3216 | 676 | 33.8 | 尾波站 16 个 | +25.2% |

**定稿路由：N<256 走 `sgemm`（4x4）、256≤N<1280 走 `sgemm_shared`、
N≥1280 走 `sgemm_8x8`**。grid 步进随 tile（8x8 是 128、其余 64），block 恒
16×16。N=1280 是 8x8 第一个「整波 + 够铺」的尺寸——它下面 1024 稳定小输，
它上面全赢。已知局限：路由只看了 N，瘦长形（M 很小）的 8x8 一样吃波尾，
将来可以改成按 block 数路由（`ceil(N/128)*ceil(M/128) >= 100`）。

### 收益（同场中位数，1060，峰值 4.37 TFLOPS）

- N=2048：4x4 980 → shared 1866 → 8x8 **2155 GFLOPS**，利用率
  **22% → 43% → 49%**（两跳累计 +27pp）
- 跨会话波动注记：昨天同点测过 shared 1627 / 8x8 2089，今天同点是 1866 /
  2155——升频状态不同，**跨会话比绝对值没有意义，要比就同场比**。这就是
  本条全部用中位数的原因。

### 验证

- **harness**（`_gputile.exe 8x8`）：probe 8/8 行全对；全尺寸 bench 后向误差
  ~1e-7（float 累加正常水平），含 68/100/132/4 尾块与 M=4 的极端瘦条；
- **六轮交替 bench**：`_gputile.exe shared` 与 `8x8` 交替跑 6 轮取中位数
  （翻案数据即出自这里）；补测中间尺寸用 `build_tmp/_gputile_sizes.c`
  （改 harness 的 `ns[]` 生成变体，不动原文件）；
- **生产入口**（`_gpucheck2.c` 直链 `pybook_gpu.c`）：七形状（128/64×128/256/
  512/1024/1280/300）与 CPU 参考超差全 0；
- **路由直接证据**（插桩构建）：`build_tmp/_route_dbg_patch.py` 从
  `pybook_gpu.c` 生成插桩版 `_gpu_dbg.c`（仓库正本不碰），打印实测：
  N=128→`sgemm`、N=256/512/1024/300→`sgemm_shared`、**N=1280→`sgemm_8x8`
  step=128 grid=10×10（恰好 100 block = 5 整波，与拐点分析吻合）**；
- **端到端**（`tests/cases.py`）：P0_29（128³ 走 4x4 + 300×132×300 走 shared，
  逐字不变）+ **P0_30（M=8/N=1280/K=64 瘦长形走 8x8**，M 无对齐要求、尾行
  谓词兜住；期望值 `(i%3)×64` 由 Python 精确复算）；
- 回归：512 阈值版全量 **161/161** + smokeroor **8/8**；1280 阈值版针对性
  验证全过（生产入口 + 路由插桩 + 两端到端），全量回归因并行 agent 同在
  仓库开发（net/mt 入口）择期补跑。

### 踩坑（本轮新增 3 条）

1. **单轮 kernel 测量会被 GPU 动态升频骗**（本轮最大的坑）：初版阈值 512
   建立在单轮数据上（512 曾测到 +24%），六轮交替复测只有 −2%、1024 甚至
   −5%——单轮恰好采到高升频窗口，8x8 吃得比 shared 更狠。**kernel 性能阈值
   必须多轮交替测量取中位数，单轮数据只能当线索**。复现工具：
   `for i in 1 2 3; do ./_gputile.exe 8x8; ./_gputile.exe shared; done`。
2. **波尾量化是 tile 大小的隐藏约束**：tile 128 不是「越大越好」——grid 的
   block 数要够铺满 GPU 的波（1060：20 block/波），否则尾波空转吃掉寄存器
   分块省下的访存。100 block（N=1280，5 整波）是实测拐点。选 tile 尺寸时
   先算 `ceil(N/tile)² / (SM数 × 每SM常驻block)`。
3. **并行 agent 同仓库开发时构建会互相锁**：重编 pyvm.exe 连续 5 次
   `ld: cannot open output file pyvm.exe: Permission denied`——另一个 agent
   正在同一仓库给 VM 加 net/mt 入口并频繁重编。识别法：`Get-CimInstance
   Win32_Process` 看谁拿着 exe；应对：构建带重试循环，或等对方收摊。本次
   用对方更新后的权威命令（含 `pybook_net.c` + `-lws2_32 -lwininet`）一次
   链过，证明两边的改动共存无冲突。

## 工具链（第一跳 + 第二跳沉淀）

| 文件 | 用途 |
|---|---|
| `_ptx_PTX_4X4.ptx` | 4x4 kernel 真相源（harness 与生产同源） |
| `_ptx_PTX_SHARED.ptx` | shared tiling kernel 真相源 |
| `_ptx_PTX_8X8.ptx` | 8x8 寄存器分块 kernel 真相源（第二跳） |
| `build_tmp/_gen_ptx_shared.py` | 生成 SHARED.ptx（128 条 FMA 程序展开，自检指令计数） |
| `build_tmp/_gen_ptx_8x8.py` | 生成 8X8.ptx（512 FMA 展开；自检：st.shared 8 / bar.sync 2 / ld.shared 64+16v4 / fma 512 / st.global 64） |
| `build_tmp/_embed_shared_patch.py` | 第一跳生产嵌入（幂等，每处 count==1） |
| `build_tmp/_embed_8x8_patch.py` | 第二跳生产嵌入：三 entry + img 65536 + 路由 + 宏（幂等） |
| `build_tmp/_dump_ptx_variants.py` | 从 pybook_gpu.c 反提取变体，排查生产/harness 差异 |
| `build_tmp/_route_dbg_patch.py` | 生成插桩版 `_gpu_dbg.c`：打印实际 launch 的 kernel/step/grid（路由直接证据） |
| `build_tmp/_gputile_sizes.c` | 由 `_gputile.c` 改 `ns[]` 生成的补测变体（任意中间尺寸） |
| `_gputile.c` | kernel 开发 harness（probe 诊断 + 后向误差对拍 + 边界尺寸 + bench） |
| `_gpucheck2.c` | 生产入口 `gpu_sgemm_f32` 路由对拍（CPU 参考 + 墙钟计时） |
| `_ptxdbg.c` | PTX 加载诊断（LoadData + 取入口，定位 JIT 失败在哪一层） |

## 第三跳预告（未实施）

- **第三跳：软件双缓冲**（两级 shared buffer 乒乓，算 tile[i] 时预取 tile[i+1]）。
  1060 是 Pascal 没有 `cp.async`，只能手工流水。第一跳后加载段就是仅剩的
  暴露延迟，第二跳把计算/访存比推高后它更显眼。注意 8x8 的 shared 已 8KB/
  block，双缓冲要 16KB——Pascal 的 96KB/SM 还撑得住，但 occupancy 要重测。
- 再往上要 splitK / warp specialization / Tensor Core（另一套 mma PTX，
  独立课题）。以第二跳后的 49% 为基点，第三跳的合理预期是 +5~10pp。
