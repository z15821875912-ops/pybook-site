/* _cpubench.c —— PYbook CPU 矩阵乘路径的串行 vs 多线程测速
 *
 * 测的是什么（严格对应 pybook_tb.c 的 rt_tb_dot 里的 CPU 分支）：
 *   串行：  清零 O + tb_matmul_tile(Ad,Bd,Od, ac,bc, 0,M)
 *   多线程：清零 O + mt_parallel(M, chunk, &job)，chunk 里调 tb_matmul_tile(Ad,Bd,Od, ac,bc, ra,rb)
 *   生产在 M*N*K >= TB_MM_MIN 时走多线程，否则走串行。
 *   TB_MM_MIN 由 _cpubench_gen.py 从 pybook_tb.c 原文抽取（当前是 1<<24）。
 *   本文件曾写死 524288（旧的 1<<19），而生产早已改成 1<<24，导致
 *   「路由选 / 路由损失」两列反映的是过期阈值。现在两边共用同一份定义。
 *   本 harness 把两条都跑一遍，看这个分界选得对不对。
 *
 * 微内核是**从 pybook_tb.c 原文抽取**的（_cpubench_core.inc，由 _cpubench_gen.py 生成），
 * 不是手抄副本 —— 改生产内核只要重跑生成器，测的就永远是线上跑的那份。
 *
 * 没测的（明确排除，不是漏）：round_out 的 f32 收尾舍入 —— 它是 O(M*N)，
 * 相对 O(M*N*K) 微不足道；gpu_dot_try 那条路是 GPU，见 _gpucmp.c。
 *
 * 编译（**必须跟生产同款优化档**，否则测的不是同一个内核）：
 *   C:\Users\zhuli\mingw64\bin\x86_64-w64-mingw32-gcc.exe _cpubench.c pybook_mt.c ^
 *       -o _cpubench.exe -O3 -march=native
 * 用法：
 *   _cpubench.exe [模式] [轮数]
 *     模式 1 = 方阵扫（含 TB_MM_MIN 分界附近）
 *     模式 2 = 定规模换长宽比（找「行数少 -> 并行度不够」的病态）
 *     模式 3 = 尾巴形状（N 非 8 倍 / K 非 48 倍）
 *     不给就全跑
 */
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <stdarg.h>
#include <immintrin.h>

#include "pybook_mt.h"

/* 微内核抽取件（含 TB_MR/NR/KC/NC/MC、tb_micro_packed、tb_matmul_tile） */
#include "_cpubench_core.inc"

/* pybook_mt.c 的 mt_workers() 依赖 rt_device_threads()。
 * 它返回 rt_device_set() 记下的文件头线程数；harness 没跑文件头，
 * 生产里的真实取值就是 0（= 未指定），于是 mt_workers 落到
 * PYBOOK_THREADS 环境变量 / GetSystemInfo，上限 16。
 * 所以这里返回 0 不是「随便 stub」，是**生产的真值**。 */
int rt_device_threads(void) { return 0; }

/* 生产里 tb_die 会带 PYbook 栈信息直接退出；harness 里只要能报出来 */
static void tb_die(const char *fmt, ...)
{
    va_list ap;
    va_start(ap, fmt);
    vprintf(fmt, ap);
    va_end(ap);
    printf("\n");
    exit(1);
}

static double now(void)
{
    LARGE_INTEGER f, c;
    QueryPerformanceFrequency(&f);
    QueryPerformanceCounter(&c);
    return (double)c.QuadPart / (double)f.QuadPart;
}

/* pybook_tb.c:323 dot_chunk 的等价物，去掉 RtTensor 外壳只留裸指针。
 * 语义与生产完全一致：整块行由同一个工人算完，所以 MT 结果应当与串行逐位相同。 */
typedef struct { const double *A, *B; double *O; size_t ac, bc; } Job;

static void chunk(int cid, long long ra, long long rb, void *ud)
{
    Job *x = (Job *)ud;
    long long i;
    (void)cid;
    for (i = ra; i < rb; i++) {
        double *Or = x->O + (size_t)i * x->bc;
        size_t j;
        for (j = 0; j < x->bc; j++) Or[j] = 0.0;
    }
    tb_matmul_tile(x->A, x->B, x->O, x->ac, x->bc, (size_t)ra, (size_t)rb);
}

static unsigned g_seed = 987654321u;
static double frand(void)
{
    g_seed = g_seed * 1103515245u + 12345u;
    return (double)((g_seed >> 9) & 0xFFFF) / 65536.0 - 0.5;
}

static int cmp_dbl(const void *a, const void *b)
{
    double x = *(const double *)a, y = *(const double *)b;
    return (x > y) - (x < y);
}

/* mt_parallel 的固定开销：空函数，只量「唤醒 11 个工人 + 栅栏归队」的成本。
 * 这是 TB_MM_MIN 该定多大的下界依据 —— 单次乘法的计算量低于这个开销，
 * 再怎么并行都是净亏。 */
static void noop_chunk(int cid, long long a, long long b, void *ud)
{ (void)cid; (void)a; (void)b; (void)ud; }

static double mt_overhead_ms(int R)
{
    double t[64];
    int r, i;
    for (r = 0; r < R; r++) {
        double t0 = now();
        for (i = 0; i < 100; i++) mt_parallel(1000, noop_chunk, NULL);
        t[r] = (now() - t0) * 10.0;          /* 100 次摊回每次：s * 1000 / 100 = ms */
    }
    qsort(t, R, sizeof(double), cmp_dbl);
    return (R & 1) ? t[R/2] : 0.5 * (t[R/2 - 1] + t[R/2]);
}

/* 形状 + 全局缓冲（按最大形状一次开够，避免每点重分配把计时搅乱） */
typedef struct { int M, N, K; const char *note; } Shape;
static double *g_A, *g_B, *g_O, *g_Oref;

/* 独立朴素参考：对抽样元素直接三重循环累加（不打包、不分块、不向量化）。
 * 这是判「串行 / MT / 4行FMA 列尾巴」谁对的唯一裁判 —— 三条路互相投票
 * 只能证明它们不一样，指不出谁对。 */
static double ref_elem(const double *A, const double *B, int M, int N, int K,
                       int r, int c)
{
    double s = 0.0;
    int p;
    for (p = 0; p < K; p++) s += A[(size_t)r * K + p] * B[(size_t)p * N + c];
    return s;
}

static void ref_check(const Shape *s)
{
    size_t kc = (size_t)s->M * s->N, i;
    Job job;
    int r, c, probes = 0;
    double worst_s = 0, worst_m = 0;
    int ns = 0, nc = 0, bad_s = 0, bad_m = 0;

    job.A = g_A; job.B = g_B; job.O = g_O; job.ac = (size_t)s->K; job.bc = (size_t)s->N;

    memset(g_O, 0, kc * sizeof(double));
    tb_matmul_tile(g_A, g_B, g_O, (size_t)s->K, (size_t)s->N, 0, (size_t)s->M);
    memcpy(g_Oref, g_O, kc * sizeof(double));
    memset(g_O, 0, kc * sizeof(double));
    mt_parallel((long long)s->M, chunk, &job);

    /* 抽样：头 2 行、尾 2 行，各列再取头 2 / 尾 4 个 —— 专门盯最后几列 */
    for (ns = 0; ns < 2; ns++) {
        int rr[2];
        rr[0] = ns == 0 ? 0 : s->M - 1;
        rr[1] = s->M / 2;
        for (r = 0; r < 2; r++) {
            int row = rr[r];
            if (row < 0 || row >= s->M) continue;
            for (nc = 0; nc < 6; nc++) {
                int col = (nc < 2) ? nc : s->N - (6 - nc);
                double ref, mag = 0, es, em;
                int q;
                if (col < 0 || col >= s->N) continue;
                ref = ref_elem(g_A, g_B, s->M, s->N, s->K, row, col);
                for (q = 0; q < s->K; q++)
                    mag += fabs(g_A[(size_t)row * s->K + q] * g_B[(size_t)q * s->N + col]);
                if (mag < 1e-12) mag = 1e-12;
                es = fabs(g_Oref[(size_t)row * s->N + col] - ref) / mag;
                em = fabs(g_O[(size_t)row * s->N + col] - ref) / mag;
                if (es > worst_s) worst_s = es;
                if (em > worst_m) worst_m = em;
                if (es > 1e-12) bad_s++;
                if (em > 1e-12) bad_m++;
                probes++;
            }
        }
    }
    printf("  朴素参考对拍 %dx%dx%d：抽 %d 个元素（%d 行 x 6 列，头尾各取）\n",
           s->M, s->N, s->K, probes, 4);
    printf("    串行(4行FMA列尾巴)  最大后向误差 %.3e   超 1e-12 的 %d 个\n", worst_s, bad_s);
    printf("    MT(逐行标量尾巴)    最大后向误差 %.3e   超 1e-12 的 %d 个\n", worst_m, bad_m);
    (void)i;
}

static int run_shape(const Shape *s, int R)
{
    size_t ka = (size_t)s->M * s->K, kb = (size_t)s->K * s->N, kc = (size_t)s->M * s->N;
    double t_ser[64], t_mt[64];
    double mac = (double)ka * s->N;              /* M*N*K */
    double med_s, med_m, gflop, loss, best;
    Job job;
    int r, bad = 0, prod_mt, inner = 1, q;
    size_t i;

    job.A = g_A; job.B = g_B; job.O = g_O; job.ac = (size_t)s->K; job.bc = (size_t)s->N;

    /* 大形状少跑几轮：CPU 上 3000³ 一次就是好几秒，别把整轮拖太长 */
    if (mac > 2.0e8) inner = 1; else if (mac > 2.0e7) inner = 2;

    /* 先各跑一发验结果：MT 与串行必须逐位相同。
     * 能逐位相同是因为整块行由同一个工人算完，每个输出元素的 k 累加顺序
     * 不随行块切分而变 —— MC 随 (i1-i0) 变，但 MC 只影响行循环怎么分组。 */
    memset(g_O, 0, kc * sizeof(double));
    tb_matmul_tile(g_A, g_B, g_O, (size_t)s->K, (size_t)s->N, 0, (size_t)s->M);
    memcpy(g_Oref, g_O, kc * sizeof(double));
    memset(g_O, 0, kc * sizeof(double));
    mt_parallel((long long)s->M, chunk, &job);
    for (i = 0; i < kc; i++)
        if (g_O[i] != g_Oref[i]) bad++;
    /* 不一致必须转储出来看：只报一个「有 N 处」没法判断是位末ulp 的正常差异、
     * 还是某一块行整个算错了。前者幅度 1ulp，后者幅度是整个元素的值。 */
    if (bad) {
        int shown = 0;
        printf("    [转储 %dx%dx%d 不一致 %d 处，前 8 处：]\n", s->M, s->N, s->K, bad);
        for (i = 0; i < kc && shown < 8; i++) {
            if (g_O[i] == g_Oref[i]) continue;
            printf("      O[%zu][%zu]  MT=%.17g  串=%.17g  差=%.3g  (%.2f ulp)\n",
                   i / (size_t)s->N, i % (size_t)s->N, g_O[i], g_Oref[i],
                   g_O[i] - g_Oref[i],
                   fabs(g_O[i] - g_Oref[i]) / (fabs(g_Oref[i]) * 2.220446049250313e-16 + 1e-300));
            shown++;
        }
        fflush(stdout);
    }

    /* 轮转顺序打散：串行/MT 轮流当先手，谁都不固定抢在 CPU 升频窗口前面 */
    for (r = 0; r < R; r++) {
        int pass;
        for (pass = 0; pass < 2; pass++) {
            int which = (pass + r) & 1;
            double t0, t1;
            t0 = now();
            for (q = 0; q < inner; q++) {
                memset(g_O, 0, kc * sizeof(double));
                if (which == 0)
                    tb_matmul_tile(g_A, g_B, g_O, (size_t)s->K, (size_t)s->N, 0, (size_t)s->M);
                else
                    mt_parallel((long long)s->M, chunk, &job);
            }
            t1 = now();
            if (which == 0) t_ser[r] = (t1 - t0) * 1000.0 / inner;
            else           t_mt[r]  = (t1 - t0) * 1000.0 / inner;
        }
    }
    {
        double a[64], b[64];
        memcpy(a, t_ser, R * sizeof(double)); qsort(a, R, sizeof(double), cmp_dbl);
        memcpy(b, t_mt,  R * sizeof(double)); qsort(b, R, sizeof(double), cmp_dbl);
        med_s = (R & 1) ? a[R/2] : 0.5 * (a[R/2 - 1] + a[R/2]);
        med_m = (R & 1) ? b[R/2] : 0.5 * (b[R/2 - 1] + b[R/2]);
    }
    best  = med_s < med_m ? med_s : med_m;
    /* best 是**毫秒**。FLOP / (ms) / 1e6 = GFLOPS（除 1e9 会小 1000 倍）。 */
    gflop = 2.0 * mac / best / 1.0e6;
    /* 路由阈值用生产源码抽过来的 TB_MM_MIN（_cpubench_gen.py 一并抽取）。
     * 这里原来写死 524288.0，也就是旧的 1<<19，而生产早已改成 1<<24 ——
     * 结果「路由选 / 路由损失」两列反映的是一个已经不存在的阈值。 */
    prod_mt = (mac >= TB_MM_MIN);
    loss = (prod_mt ? med_m : med_s) / best * 100.0 - 100.0;

    printf("%5d %5d %5d | %9.3f %9.3f | %7.2f | %-6s %-6s %+7.1f%% ",
           s->M, s->N, s->K, med_s, med_m, gflop,
           med_m < med_s ? "MT" : "串行", prod_mt ? "MT" : "串行", loss);
    if (bad) printf("★MT/串行不一致 %d 处★", bad);
    if (!prod_mt && med_m < med_s * 0.95) printf("★该并行却串行★");
    if (prod_mt  && med_s < med_m * 0.95) printf("★该串行却并行★");
    if (s->note[0]) printf("(%s)", s->note);
    printf("\n");
    fflush(stdout);
    return bad == 0;
}

/* 三段形状表。每段 = {标题, 形状数} + 形状数组。
 * 分段跑而不是一口气混着跑：换长宽比那段和尾巴那段各自要单独看，
 * 混在一张表里会以为「GFLOPS 掉下去」是形状问题，其实是规模问题。 */

static Shape sq_sh[] = {
    /* 方阵扫：80³=512000 落在 TB_MM_MIN 之下，81³=531441 刚过，
     * 这两个点是整个阈值的判卷题，必须都在。 */
    { 48, 48, 48, "" }, { 64, 64, 64, "" }, { 72, 72, 72, "" },
    { 80, 80, 80, "MNK<阈值" }, { 81, 81, 81, "MNK>阈值" },
    { 88, 88, 88, "" }, { 96, 96, 96, "" }, { 108, 108, 108, "" },
    { 128, 128, 128, "" }, { 144, 144, 144, "" }, { 160, 160, 160, "" },
    { 192, 192, 192, "" }, { 224, 224, 224, "" }, { 256, 256, 256, "" },
    { 288, 288, 288, "" }, { 320, 320, 320, "" }, { 384, 384, 384, "" },
    { 448, 448, 448, "" }, { 512, 512, 512, "" }, { 640, 640, 640, "" },
    { 768, 768, 768, "" }, { 896, 896, 896, "" }, { 1024, 1024, 1024, "" },
    { 1280, 1280, 1280, "" }, { 1536, 1536, 1536, "" }, { 2048, 2048, 2048, "" },
    { 2560, 2560, 2560, "" }, { 3072, 3072, 3072, "" }
};
static Shape ar_sh[] = {
    /* 定规模换长宽比：M*N*K 都在 5e5~1e6 附近（阈值两侧），
     * 看行数少的时候并行度够不够 —— CPU 上最可能病态的形状。
     * mt_parallel 按【行】切 64 块，M 小于 64 时有一半以上的块是空的。 */
    { 4096,  16,   8, "M=4096" }, { 2048,  16,  16, "M=2048" },
    { 1024,  32,  16, "M=1024" }, {  512,  32,  32, "M=512" },
    {  256,  64,  32, "M=256" }, {  128,  64,  64, "M=128" },
    {   81,  81,  81, "M=81" },  {   64,  90,  90, "M=64" },
    {   32, 128, 128, "M=32" },  {   16, 181, 181, "M=16" },
    {    8, 256, 256, "M=8" },   {    4, 362, 362, "M=4" },
    {    2, 512, 512, "M=2" },   {  128, 128,  32, "K=32" },
    {   64, 128,  64, "K=64" },  {   16, 256, 128, "M=16,K=128" }
};
static Shape tl_sh[] = {
    /* 尾巴形状：微内核 NR=8（列）、KC=NC=48（K 与列分块）。
     * N 非 8 倍会走 4 路 ymm 收尾 + 标量余数；K 非 48 倍会让最后一个 k 面板不满。 */
    { 1000,  96,  96, "对齐" },   { 1000, 100, 100, "N非8倍" },
    { 1000, 104, 104, "N非8倍" }, { 1000, 132, 132, "N非8倍" },
    { 1000, 300, 300, "N非8倍" }, {  512,  48,  48, "对齐48" },
    {  512,  49,  49, "K非48倍" },{  512,  47,  47, "K非48倍" },
    {  512,  50,  50, "K非48倍" },{  512,  90,  90, "K非48倍" },
    {  512,  45,  45, "K非48倍" },{  512,  53,  53, "K非48倍" }
};

static int g_maxA, g_maxB, g_maxC;

static void need(int M, int N, int K)
{
    if (M > g_maxA) g_maxA = M;
    if (K > g_maxB) g_maxB = K;
    if (N > g_maxC) g_maxC = N;
}

static void seg(const char *title, Shape *sh, int n, int R, int *ok)
{
    int i;
    printf("\n=== %s ===\n", title);
    printf("每点 %d 轮，串行/多线程轮流当先手（打散 CPU 升频窗口），取中位数\n", R);
    printf("%5s %5s %5s | %9s %9s | %7s | %-6s %-6s %-8s %s\n",
           "M", "N", "K", "串行ms", "MTms", "GFLOPS", "实测优", "路由选", "路由损失", "备注");
    fflush(stdout);
    for (i = 0; i < n; i++)
        if (!run_shape(&sh[i], R)) *ok = 0;
}

int main(int argc, char **argv)
{
    int mode = argc > 1 ? atoi(argv[1]) : 0;
    int R    = argc > 2 ? atoi(argv[2]) : 7;
    int i, ok = 1;
    size_t capA, capB, capC;

    SetConsoleOutputCP(65001);
    if (R < 1) R = 1;
    if (R > 64) R = 64;
    printf("工人数 = %d（mt_workers 实读；PYBOOK_THREADS 环境变量可覆盖）\n", mt_workers());
    printf("微内核取自 _cpubench_core.inc（_cpubench_gen.py 从 pybook_tb.c 原文抽取）\n");
    printf("mt_parallel 固定开销 = %.3f ms/次（空函数，唤醒 %d 个工人 + 栅栏归队的中位数）\n",
           mt_overhead_ms(7), mt_workers() - 1);

    for (i = 0; i < (int)(sizeof(sq_sh)/sizeof(sq_sh[0])); i++) need(sq_sh[i].M, sq_sh[i].N, sq_sh[i].K);
    for (i = 0; i < (int)(sizeof(ar_sh)/sizeof(ar_sh[0])); i++) need(ar_sh[i].M, ar_sh[i].N, ar_sh[i].K);
    for (i = 0; i < (int)(sizeof(tl_sh)/sizeof(tl_sh[0])); i++) need(tl_sh[i].M, tl_sh[i].N, tl_sh[i].K);

    capA = (size_t)g_maxA * g_maxB;   /* A 是 M*K */
    capB = (size_t)g_maxB * g_maxC;   /* B 是 K*N */
    capC = (size_t)g_maxA * g_maxC;   /* O 是 M*N */
    printf("最大形状 A=%zux%zu  B=%zux%zu  O=%dx%d  （合计 %.1f MB）\n",
           g_maxA, g_maxB, g_maxB, g_maxC, g_maxA, g_maxC,
           (double)(capA + capB + 2 * capC) * 8.0 / 1048576.0);

    g_A = (double *)malloc(capA * sizeof(double));
    g_B = (double *)malloc(capB * sizeof(double));
    g_O = (double *)malloc(capC * sizeof(double));
    g_Oref = (double *)malloc(capC * sizeof(double));
    if (!g_A || !g_B || !g_O || !g_Oref) { printf("内存不足\n"); return 1; }
    for (i = 0; i < (int)capA; i++) g_A[i] = frand();
    for (i = 0; i < (int)capB; i++) g_B[i] = frand();
    printf("\n");

    if (mode == 0 || mode == 1)
        seg("方阵扫（判 TB_MM_MIN，由 pybook_tb.c 抽取）", sq_sh,
                                    (int)(sizeof(sq_sh)/sizeof(sq_sh[0])), R, &ok);
    if (mode == 0 || mode == 2) seg("定规模换长宽比（找并行度不够的病态形状）", ar_sh,
                                    (int)(sizeof(ar_sh)/sizeof(ar_sh[0])), R, &ok);
    if (mode == 0 || mode == 3) seg("尾巴形状（N 非 8 倍 / K 非 48 倍）", tl_sh,
                                    (int)(sizeof(tl_sh)/sizeof(tl_sh[0])), R, &ok);
    if (mode == 5) {
        /* 模型验证：mt_parallel 固定切 64 块，所以「每块工作量」= ceil(M/64)*N*K。
         * 固定 N*K 只扫 M，把这个自变量单独拎出来看分界在哪；
         * 再固定 M 只扫 N*K，验证分界只跟每块工作量走、与形状无关。 */
        static Shape sa[] = {
            {   64, 256, 256, "1行/块" }, {  128, 256, 256, "2行/块" },
            {  192, 256, 256, "3行/块" }, {  256, 256, 256, "4行/块" },
            {  384, 256, 256, "6行/块" }, {  512, 256, 256, "8行/块" },
            {  768, 256, 256, "12行/块"}, { 1024, 256, 256, "16行/块" },
            { 1536, 256, 256, "24行/块"}, { 2048, 256, 256, "32行/块" }
        };
        static Shape sb[] = {
            { 1024,  48,  48, "NK=2304" }, { 1024,  64,  64, "NK=4096" },
            { 1024,  80,  80, "NK=6400" }, { 1024,  96,  96, "NK=9216" },
            { 1024, 112, 112, "NK=12544"}, { 1024, 128, 128, "NK=16384"},
            { 1024, 160, 160, "NK=25600"}, { 1024, 192, 192, "NK=36864"},
            { 1024, 256, 256, "NK=65536"}
        };
        int j;
        for (j = 0; j < (int)(sizeof(sa)/sizeof(sa[0])); j++) need(sa[j].M, sa[j].N, sa[j].K);
        for (j = 0; j < (int)(sizeof(sb)/sizeof(sb[0])); j++) need(sb[j].M, sb[j].N, sb[j].K);
        seg("模型验证 A：固定 N*K=65536，只扫 M（行/块是唯一变量）", sa,
            (int)(sizeof(sa)/sizeof(sa[0])), R, &ok);
        seg("模型验证 B：固定 M=1024（16行/块），只扫 N*K", sb,
            (int)(sizeof(sb)/sizeof(sb[0])), R, &ok);
    }
    if (mode == 6) {
        /* 只扫大尺寸、高轮次，专门回答一个问题：
         * 之前单次扫描看到 512/768/1024 高、640/896 低的「锯齿」到底是结构还是噪声。
         * 本机 run-to-run 噪声实测到 27~58%，远大于想看的差距，
         * 所以这里轮次拉高、只留大尺寸，让每点的中位数真正站得住。 */
        static Shape lg[] = {
            { 512, 512, 512, "" }, { 640, 640, 640, "" }, { 768, 768, 768, "" },
            { 896, 896, 896, "" }, { 1024,1024,1024, "" }, { 1280,1280,1280, "" },
            { 1536,1536,1536, "" }, { 2048,2048,2048, "" }
        };
        int j;
        for (j = 0; j < (int)(sizeof(lg)/sizeof(lg[0])); j++) need(lg[j].M, lg[j].N, lg[j].K);
        seg("大尺寸复打（验「锯齿」是结构还是噪声）", lg,
            (int)(sizeof(lg)/sizeof(lg[0])), R, &ok);
    }
    if (mode == 4 || mode == 0) {
        /* 正确性判官：N 取 4 的倍数与不是 4 的倍数各一组，其余维度取 4 的倍数，
         * 这样「N%4」是唯一变量，能把嫌疑钉死在列尾巴那条路上。 */
        static Shape ck[] = {
            { 64, 64, 64, "N%4==0" }, { 64, 65, 64, "N%4==1" },
            { 64, 66, 64, "N%4==2" }, { 64, 67, 64, "N%4==3" },
            { 64,  80, 64, "N%4==0" }, { 64,  81, 64, "N%4==1" },
            { 64,  82, 64, "N%4==2" }, { 64,  83, 64, "N%4==3" },
            { 64,  97, 64, "N%4==1" }, { 65,  65, 64, "M,N%4==1" },
            { 63,  65, 64, "M%4==3,N%4==1" }
        };
        printf("\n=== 正确性判官（朴素参考 vs 串行 vs MT） ===\n");
        for (i = 0; i < (int)(sizeof(ck)/sizeof(ck[0])); i++) {
            printf("  --- %dx%dx%d  N%%4=%d  %s ---\n",
                   ck[i].M, ck[i].N, ck[i].K, ck[i].N & 3, ck[i].note);
            ref_check(&ck[i]);
        }
    }

    if (mode >= 1 && mode <= 3)
        printf("\n%s\n", ok ? "以上形状：多线程结果与串行逐位一致"
                             : "★有不一致的形状（见上面 ★ 标记）★");
    else
        printf("\n（本模式只做正确性对拍，不做串行/MT 计时）\n");
    return ok ? 0 : 1;
}
