# -*- coding: utf-8 -*-
"""_sym5_patch.py —— sym4 首轮跑分后的三处代码修复 + 两处测试期望修正。
幂等纪律：每处断言 count==1；二进制读写保 LF；跑完自检裸 CR。
    C1  limit_finite 顶层 DIV 拆 num/den 对（洛必达地基，不拆则 sin(x)/x 进不了未定式分支）
    C2  级数 k==1 不包 POW（出 "x" 而不是 "x^1"）
    C3  O 余项指数为 1 时省略 "^1"（0 阶级数出 "O(x)"）
    C4  tanh 求导期望对齐实际渲染序（-tanh(x)^2 + 1，数学等价）
    C5  1^inf 陷阱期望改 [对拍不一致]（pow(1,inf)=1 陷阱实际撞的是对拍闸，文案准确）
"""
import io, sys

def patch(path, items):
    s = io.open(path, 'rb').read()
    for label, old, new in items:
        ob, nb = old.encode('utf-8'), new.encode('utf-8')
        n = s.count(ob)
        if n == 0 and s.count(nb) == 1:
            print('skip ' + label + '（已在位）')
            continue
        if n != 1:
            sys.stderr.write('FAIL [%s] count=%d\n' % (label, n))
            sys.exit(1)
        s = s.replace(ob, nb, 1)
        print('ok  ' + label)
    io.open(path, 'wb').write(s)
    print('写入 %s, 裸 CR %d' % (path, s.count(b'\r')))

# ---------- pybook_sym.c ----------
sym_items = [
    ("C1 limit_finite 拆 DIV",
     "    Node *num = n, *den = nd_num(ar, 1);\n    int iter;\n",
     "    Node *num, *den;\n"
     "    /* 顶层是商才拆成 num/den 对——洛必达的地基。不拆的话整个表达式当分子，\n"
     "     * sin(x)/x 代入得 nan 而不是 0/0，未定式分支永远进不去 */\n"
     "    if (n->kind == N_DIV) { num = n->a; den = n->b; }\n"
     "    else { num = n; den = nd_num(ar, 1); }\n"
     "    int iter;\n"),
    ("C2 级数 k==1 不包 POW",
     "                Node *pw = nd_bin(&ar, N_POW, base, nd_num(&ar, (double)k));\n",
     "                /* k==1 时不包 POW：base^1 就是 base 本身，出 \"x\" 而不是 \"x^1\" */\n"
     "                Node *pw = (k == 1) ? base\n"
     "                                    : nd_bin(&ar, N_POW, base, nd_num(&ar, (double)k));\n"),
    ("C3 O 余项省略 ^1",
     "    sb_putc(&ob, '^');\n"
     "    {\n"
     "        char nb[16];\n"
     "        snprintf(nb, sizeof nb, \"%d\", order + 1);\n"
     "        sb_puts(&ob, nb);\n"
     "    }\n",
     "    if (order + 1 != 1) {          /* 0 阶级数出 \"O(x)\"，不出 \"O(x^1)\" */\n"
     "        sb_putc(&ob, '^');\n"
     "        {\n"
     "            char nb[16];\n"
     "            snprintf(nb, sizeof nb, \"%d\", order + 1);\n"
     "            sb_puts(&ob, nb);\n"
     "        }\n"
     "    }\n"),
]
patch('pybook_sym.c', sym_items)

# ---------- _symtest.c ----------
tst_items = [
    ("C4 tanh 求导期望对齐渲染序",
     'Td("tanh(x)", "x", "1 - tanh(x)^2", "求导 tanh");',
     'Td("tanh(x)", "x", "-tanh(x)^2 + 1", "求导 tanh");'),
    ("C5 1^inf 陷阱期望改对拍不一致",
     'Tlim_err("(1+x)^(1/x)", "x", "0", "数值探测", "极限 1^inf 陷阱");',
     'Tlim_err("(1+x)^(1/x)", "x", "0", "对拍不一致", "极限 1^inf 陷阱");'),
]
patch('_symtest.c', tst_items)

print('=== _sym5_patch 全部通过 ===')
