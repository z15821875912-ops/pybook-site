# -*- coding: utf-8 -*-
"""_blockscan.py —— 扫三级分块常量 KC/NC/MC，找一个把 640/896 两个坑填平、又不牺牲其它尺寸的组合。

为什么值得扫：
    pybook_tb.c 里写着「48 是扫描调优定的，不要改大」，但我实测的曲线
    在 N=640（中位数 50 GFLOPS）和 N=896（65.8）明显塌下去，
    而邻居 512=92.6 / 768=117.5 / 1024=120.0。
    「扫描调优过」却坐在坑里，说明那次扫描看的是平均值，不是逐尺寸曲线。

为什么只信中位数：
    本机 run-to-run 噪声实测 ±27~38%（896 三遍跑出 47.2 / 65.8 / 71.3）。
    在这种噪声上比单次数字，就是在追噪声 —— GPU 那张表就是这么被 +24% 骗过的。
    每个候选跑 9 轮取中位数；宁要全尺寸一起好，不要只在某一点好看。

约束（写死在 apply_block_override 里）：
    NC 必须是 8 的倍数（列主循环按 TB_NR=8 走）
    MC 必须是 4 的倍数（行主循环按 TB_MR=4 走）
    否则测的就不是同一个内核了，比较没有意义。

用法：python -B _blockscan.py [轮数]
"""
import io
import os
import re
import subprocess
import sys

GCC = r"C:\Users\zhuli\mingw64\bin\x86_64-w64-mingw32-gcc.exe"
CANDS = [
    ("48,48,48", "生产现值"),
    ("64,64,64", "面板大一倍"),
    ("96,96,96", "再大一倍"),
    ("64,64,48", "只放大 KC/NC"),
    ("96,96,64", "KC/NC 大、MC 中"),
    ("32,32,32", "更小面板，试 L1"),
]
ROW_RE = re.compile(r"^\s*(\d+)\s+(\d+)\s+(\d+)\s+\|\s*([\d.]+)\s+([\d.]+)\s+\|\s*([\d.]+)")


def run(cmd, env=None):
    e = dict(os.environ)
    e["PYTHONIOENCODING"] = "utf-8"
    if env:
        e.update(env)
    p = subprocess.run(cmd, shell=True, capture_output=True, env=e)
    return p.returncode, p.stdout.decode("utf-8", "replace") + p.stderr.decode("utf-8", "replace")


def gen(block):
    env = {"PUBENCH_BLOCK": block} if block else {"PUBENCH_BLOCK": ""}
    rc, out = run("python -B _cpubench_gen.py", env)
    if rc != 0:
        raise SystemExit("生成失败 %s：%s" % (block, out.strip()))
    return out.strip()


def compile_exe():
    rc, out = run('"%s" _cpubench.c pybook_mt.c -o _cpubench.exe -O3 -march=native -lm' % GCC)
    if rc != 0:
        raise SystemExit("编译失败：\n" + out)
    return out.strip()


def measure(rounds):
    rc, out = run("_cpubench.exe 6 %d" % rounds)
    res = {}
    for ln in out.splitlines():
        m = ROW_RE.match(ln)
        if m:
            res[int(m.group(1))] = float(m.group(6))     # 第 6 列 = GFLOPS
    return res


def main():
    rounds = int(sys.argv[1]) if len(sys.argv) > 1 else 9
    table = {}
    for block, note in CANDS:
        print("=" * 72)
        print("KC,NC,MC = %-10s （%s）" % (block, note))
        gen(block)
        compile_exe()
        r = measure(rounds)
        table[block] = r
        for n in sorted(r):
            print("    N=%-5d %7.1f GFLOPS" % (n, r[n]))
    # 还原生产分块：扫描脚手架不许留在生成物里
    print("=" * 72)
    print("还原生产分块")
    gen(None)
    compile_exe()

    sizes = sorted({n for r in table.values() for n in r})
    print()
    print("%-12s %s %8s" % ("KC,NC,MC", " ".join("%8d" % n for n in sizes), "中位数"))
    base = None
    for block, _ in CANDS:
        r = table[block]
        vals = [r[n] for n in sizes if n in r]
        med = sorted(vals)[len(vals) // 2] if vals else 0
        if base is None:
            base = med
        print("%-12s %s %8.1f (%+.0f%%)"
              % (block, " ".join("%8.1f" % r.get(n, 0) for n in sizes), med,
                 (med - base) / base * 100.0 if base else 0))

    with io.open("_blockscan_result.txt", "w", encoding="utf-8", newline="\n") as f:
        for block, r in table.items():
            f.write("%s\t%s\n" % (block, "\t".join("%.2f" % r.get(n, 0) for n in sizes)))
        f.write("# sizes\t%s\n" % "\t".join(str(n) for n in sizes))


if __name__ == "__main__":
    main()
