﻿/* _gpucmp.c —— sgemm 三个 kernel 的多轮交替对拍测速
 *
 * 存在的理由（不是重写 _gputile.c 的功能，是补它测不准的地方）：
 *   1. _gputile.c 一次只测一个 kernel，且 N 写死 {64,128,256,512,1024,2048,3216}、
 *      重复仅 2~3 次取**最优**。单 kernel 连测取最优 = 每次都撞在 GPU 动态升频窗口上，
 *      上轮就因此把 N=512 记成 +24%，六轮交替复测其实只有 -2%。
 *   2. 1280 这个拐点在旧 N 表里根本没有，1280 附近一个点都没测。
 *   3. 取最优值在多 kernel 对比里是**错的统计量**：要问的是「稳态下谁快」，
 *      不是「谁运气好」，所以这里取中位数。
 *
 * 方法：
 *   - 三个 PTX 同时载入，各自 CUfunction（4x4 / shared / 8x8）
 *   - 每个 N 跑 R 轮，**每轮轮转 kernel 顺序**，谁都不固定抢在第一位
 *   - 每轮每 kernel 一次定时 = inner 次连续发射的总时长 / inner（摊掉启动开销）
 *   - R 轮取中位数
 *   - 顺便按生产阈值算「路由会选谁」，对比实测最优，直接给出病态损失
 *
 * 编译：
 *   C:\Users\zhuli\mingw64\bin\x86_64-w64-mingw32-gcc.exe _gpucmp.c -o _gpucmp.exe -O2 -lm
 * 用法：
 *   _gpucmp.exe [轮数]   （默认 7 轮）
 */
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <math.h>

/* ───────── CUDA driver API 的最小 typedef ───────── */
typedef int      CUresult;
typedef int      CUdevice;
typedef void    *CUcontext;
typedef void    *CUmodule;
typedef void    *CUfunction;
typedef void    *CUstream;
typedef unsigned long long CUdeviceptr;

#define CU_DEVICE_ATTRIBUTE_CC_MAJOR 75
#define CU_DEVICE_ATTRIBUTE_CC_MINOR 76
#define CU_EVENT_DEFAULT 0

static HMODULE g_dll;
static CUresult (*p_cuInit)(unsigned);
static CUresult (*p_cuDriverGetVersion)(int *);
static CUresult (*p_cuDeviceGetCount)(int *);
static CUresult (*p_cuDeviceGet)(CUdevice *, int);
static CUresult (*p_cuDeviceGetName)(char *, int, CUdevice);
static CUresult (*p_cuDeviceGetAttribute)(int *, int, CUdevice);
static CUresult (*p_cuDevicePrimaryCtxRetain)(CUcontext *, CUdevice);
static CUresult (*p_cuCtxSetCurrent)(CUcontext);
static CUresult (*p_cuCtxSynchronize)(void);
static CUresult (*p_cuModuleLoadData)(CUmodule *, const void *);
static CUresult (*p_cuModuleGetFunction)(CUfunction *, CUmodule *, const char *);
static CUresult (*p_cuMemAlloc_v2)(CUdeviceptr *, size_t);
static CUresult (*p_cuMemFree_v2)(CUdeviceptr);
static CUresult (*p_cuMemcpyHtoD_v2)(CUdeviceptr, const void *, size_t);
static CUresult (*p_cuMemcpyDtoH_v2)(void *, CUdeviceptr, size_t);
static CUresult (*p_cuLaunchKernel)(CUfunction, unsigned, unsigned, unsigned,
                                    unsigned, unsigned, unsigned,
                                    unsigned, CUstream, void **, void **);
static CUresult (*p_cuGetErrorString)(CUresult, const char **);
static CUresult (*p_cuEventCreate)(void **, unsigned);
static CUresult (*p_cuEventRecord)(void *, CUstream);
static CUresult (*p_cuEventSynchronize)(void *);
static CUresult (*p_cuEventElapsedTime)(float *, void *, void *);
static CUresult (*p_cuEventDestroy)(void *);

static CUcontext g_ctx;
static char      g_err[256];

static const char *cu_err(CUresult r)
{
    const char *s = NULL;
    if (p_cuGetErrorString && p_cuGetErrorString(r, &s) == 0 && s) return s;
    return "未知 CUDA 错误";
}

static int fail(const char *fmt, ...)
{
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(g_err, sizeof g_err, fmt, ap);
    va_end(ap);
    return 0;
}

/* ───────── 生产路由阈值（必须与 pybook_gpu.c 保持一致） ─────────
 * 复制而非 include：这是独立 harness，不该把整个 GPU 生产代码拖进来。
 * 若 pybook_gpu.c 改了阈值，这里要同步改，改错的后果是「测的是另一套路由」。 */
#define PROD_8X8_MIN_N   1280
#define PROD_SHARED_MIN_N 256

/* ───────── 三个待测 kernel ───────── */
typedef struct {
    const char *tag;          /* 打印用 */
    const char *entry;        /* PTX 入口名 */
    const char *file;         /* PTX 文件 */
    unsigned    step;         /* grid 步进：4x4/shared 64，8x8 128 */
    CUmodule    mod;
    CUfunction  fn;
    int         ok;
    double      t;            /* 本 N 上的中位数（毫秒） */
} Kern;

/* 常驻表：路由用的三个内核 + 新旧 8x8 对照 + 已证伪的候选。
 *   索引 2  冻结的原版 8x8（上线前的基准，永远不动）
 *   索引 3  生产用的 8x8（_mk8x8v2.py 从原版生成，已含载入预取 + .nc）
 *   索引 4  bank 冲突填充候选 —— 实测只有 +1.0~+2.2%，**没有上线**。
 *           留着是因为它是「bank 冲突假说被证伪」的证据，换个候选时删掉即可。
 * 回退：把 _ptx_PTX_8X8_orig.ptx 拷回 _ptx_PTX_8X8.ptx 再跑
 * _embed_ptx.py _ptx_PTX_8X8.ptx PTX_BODY_8X8。 */
static Kern g_k[5] = {
    { "4x4  ", "sgemm",         "_ptx_PTX_4X4.ptx",       64, NULL, NULL, 0, 0 },
    { "共享 ", "sgemm_shared",  "_ptx_PTX_SHARED.ptx",    64, NULL, NULL, 0, 0 },
    { "旧8x8", "sgemm_8x8",     "_ptx_PTX_8X8_orig.ptx", 128, NULL, NULL, 0, 0 },
    { "8x8  ", "sgemm_8x8",     "_ptx_PTX_8X8.ptx",      128, NULL, NULL, 0, 0 },
    { "填充 ", "sgemm_8x8",     "_ptx_PTX_8X8_pad.ptx",  128, NULL, NULL, 0, 0 },
};
#define NK 5

static CUdeviceptr g_dA, g_dB, g_dC;
static size_t g_cap;
static void   *g_ev0, *g_ev1;

/* 前向声明：下面几组变量的定义在文件后半段，这里就要用 */
static int   g_ev_ok;              /* -1 = 还没探过；0 = 墙钟；1 = event */
static float *g_fA, *g_fB, *g_fC;
static size_t g_fcap;

static char g_ptx[262144];    /* 8x8 的 PTX 有 36KB，留足余量 */

static int load_ptx(const char *path)
{
    FILE *f = fopen(path, "rb");
    size_t n;
    if (!f) return fail("打不开 PTX 文件 %s", path);
    n = fread(g_ptx, 1, sizeof(g_ptx) - 1, f);
    fclose(f);
    g_ptx[n] = '\0';
    if (n < 100) return fail("PTX 文件 %s 太短（%zu 字节），像是空的", path, n);
    return 1;
}

static int ensure(size_t bytes)
{
    if (bytes <= g_cap) return 1;
    if (g_cap) { p_cuMemFree_v2(g_dA); p_cuMemFree_v2(g_dB); p_cuMemFree_v2(g_dC); g_cap = 0; }
    if (p_cuMemAlloc_v2(&g_dA, bytes) != 0) return fail("显存分配失败");
    if (p_cuMemAlloc_v2(&g_dB, bytes) != 0) return fail("显存分配失败");
    if (p_cuMemAlloc_v2(&g_dC, bytes) != 0) return fail("显存分配失败");
    g_cap = bytes;
    return 1;
}

static int driver_init(void)
{
    void *p;
    CUdevice dev;
    int maj = 0, min = 0, dver = 0, cc = 0;
    int i;

    g_ev_ok = -1;                 /* -1 = 还没探过；0 = 墙钟；1 = event */
    g_dll = LoadLibraryA("nvcuda.dll");
    if (!g_dll) return fail("找不到 nvcuda.dll");
#define LOAD(n, f) do { p = (void *)GetProcAddress(g_dll, n); \
    if (!p) return fail("缺 %s", n); \
    memcpy(&(f), &p, sizeof(f)); } while (0)
    LOAD("cuInit", p_cuInit);
    LOAD("cuDriverGetVersion", p_cuDriverGetVersion);
    LOAD("cuDeviceGetCount", p_cuDeviceGetCount);
    LOAD("cuDeviceGet", p_cuDeviceGet);
    LOAD("cuDeviceGetName", p_cuDeviceGetName);
    LOAD("cuDeviceGetAttribute", p_cuDeviceGetAttribute);
    LOAD("cuDevicePrimaryCtxRetain", p_cuDevicePrimaryCtxRetain);
    LOAD("cuCtxSetCurrent", p_cuCtxSetCurrent);
    LOAD("cuCtxSynchronize", p_cuCtxSynchronize);
    LOAD("cuModuleLoadData", p_cuModuleLoadData);
    LOAD("cuModuleGetFunction", p_cuModuleGetFunction);
    LOAD("cuMemFree_v2", p_cuMemFree_v2);
    LOAD("cuMemcpyHtoD_v2", p_cuMemcpyHtoD_v2);
    LOAD("cuMemcpyDtoH_v2", p_cuMemcpyDtoH_v2);
    LOAD("cuLaunchKernel", p_cuLaunchKernel);
    LOAD("cuGetErrorString", p_cuGetErrorString);
    LOAD("cuEventCreate", p_cuEventCreate);
    LOAD("cuEventRecord", p_cuEventRecord);
    LOAD("cuEventSynchronize", p_cuEventSynchronize);
    LOAD("cuEventElapsedTime", p_cuEventElapsedTime);
    LOAD("cuEventDestroy", p_cuEventDestroy);
    p = (void *)GetProcAddress(g_dll, "cuMemAlloc_v2");
    memcpy(&p_cuMemAlloc_v2, &p, sizeof(p));
#undef LOAD
    if (!p_cuMemAlloc_v2) return fail("缺 cuMemAlloc_v2");
    if (!p_cuEventCreate) return fail("缺 cuEventCreate（本 harness 用 event 计时）");

    if (p_cuInit(0) != 0) return fail("cuInit 失败");
    if (p_cuDeviceGetCount(&i) != 0 || i < 1) return fail("取不到设备");
    if (p_cuDeviceGet(&dev, 0) != 0) return fail("取不到 0 号设备");
    p_cuDeviceGetName(g_err, 64, dev);                 /* g_err 先借用存设备名 */
    p_cuDeviceGetAttribute(&maj, CU_DEVICE_ATTRIBUTE_CC_MAJOR, dev);
    p_cuDeviceGetAttribute(&min, CU_DEVICE_ATTRIBUTE_CC_MINOR, dev);
    cc = maj * 10 + min;
    p_cuDriverGetVersion(&dver);
    if (p_cuDevicePrimaryCtxRetain(&g_ctx, dev) != 0) return fail("建不了 context");
    if (p_cuCtxSetCurrent(g_ctx) != 0) return fail("切不过 context");
    printf("设备：%s   CC=sm_%d%d   驱动 API %d   可见设备 %d\n\n",
           g_err, maj, min, dver, i);

    for (i = 0; i < NK; i++) {
        CUresult r;
        if (!load_ptx(g_k[i].file)) return fail("%s", g_err);
        r = p_cuModuleLoadData(&g_k[i].mod, g_ptx);
        if (r != 0) return fail("%s 的 PTX 被拒：%s", g_k[i].file, cu_err(r));
        if (p_cuModuleGetFunction(&g_k[i].fn, g_k[i].mod, g_k[i].entry) != 0)
            return fail("取不到入口 %s（%s）", g_k[i].entry, g_k[i].file);
        g_k[i].ok = 1;
        printf("  %s 已载入 %-22s 入口 %-13s grid 步进 %u\n",
               g_k[i].tag, g_k[i].file, g_k[i].entry, g_k[i].step);
    }
    printf("\n");
    fflush(stdout);

    if (p_cuEventCreate(&g_ev0, CU_EVENT_DEFAULT) != 0) return fail("建不了 event");
    if (p_cuEventCreate(&g_ev1, CU_EVENT_DEFAULT) != 0) return fail("建不了 event");
    return 1;
}

/* grid 形状：与 pybook_gpu.c 的 launch 完全一致 */
static void grid_of(const Kern *k, int M, int N, unsigned *gx, unsigned *gy)
{
    *gx = (unsigned)((N + (int)k->step - 1) / (int)k->step);
    *gy = (unsigned)((M + (int)k->step - 1) / (int)k->step);
}

/* 前向声明已在文件头部给出 */

/* 跑一发，用来验结果对不对（正确性只要一发；计时另走 inner 次连发） */
static int run_once(int ki, int M, int N, int K)
{
    unsigned gx, gy;
    int m = M, n = N, k = K;
    void *params[] = { &g_dA, &g_dB, &g_dC, &m, &n, &k };
    CUresult cr;

    grid_of(&g_k[ki], M, N, &gx, &gy);
    cr = p_cuLaunchKernel(g_k[ki].fn, gx, gy, 1, 16, 16, 1, 0, NULL, params, NULL);
    if (cr != 0) return fail("launch 失败：%s", cu_err(cr));
    if (p_cuCtxSynchronize() != 0) return fail("kernel 出错：%s", cu_err(cr));
    return 1;
}

static double now(void)
{
    LARGE_INTEGER f, c;
    QueryPerformanceFrequency(&f);
    QueryPerformanceCounter(&c);
    return (double)c.QuadPart / (double)f.QuadPart;
}

/* inner 次连续发射的每发平均毫秒。优先 CUDA event；不可用则墙钟
 * （inner 次连发摊掉 sync 开销，最小 N 下也能压到几个百分点）。 */
static int time_one(int ki, int M, int N, int K, int inner, double *out_ms)
{
    unsigned gx, gy;
    float el = 0;
    int i, m = M, n = N, k = K;
    CUresult cr;
    double w0, w1;
    void *params[] = { &g_dA, &g_dB, &g_dC, &m, &n, &k };

    grid_of(&g_k[ki], M, N, &gx, &gy);

    /* 先空跑一发预热：首次发射含 JIT/载入/缓存冷启动，直接计进去会离谱 */
    cr = p_cuLaunchKernel(g_k[ki].fn, gx, gy, 1, 16, 16, 1, 0, NULL, params, NULL);
    if (cr != 0) return fail("launch 失败（预热）：%s", cu_err(cr));
    if (p_cuCtxSynchronize() != 0) return fail("预热 kernel 出错：%s", cu_err(cr));

    w0 = now();
    if (g_ev_ok != 0 && g_ev0 && g_ev1 && p_cuEventRecord(g_ev0, 0) != 0) g_ev_ok = 0;
    for (i = 0; i < inner; i++) {
        cr = p_cuLaunchKernel(g_k[ki].fn, gx, gy, 1, 16, 16, 1, 0, NULL, params, NULL);
        if (cr != 0) return fail("launch 失败：%s", cu_err(cr));
    }
    /* 这次两个 event 都 record 过了，现在问才问得出真话 */
    if (g_ev_ok != 0 && g_ev0 && g_ev1) {
        if (p_cuEventRecord(g_ev1, 0) != 0 ||
            p_cuEventSynchronize(g_ev1) != 0 ||
            p_cuEventElapsedTime(&el, g_ev0, g_ev1) != 0 || el <= 0) {
            printf("[诊断] event 计时不可用（el=%.6f），退回墙钟\n", (double)el);
            g_ev_ok = 0;
        } else {
            *out_ms = (double)el / (double)inner;
            return 1;
        }
    }
    if (p_cuCtxSynchronize() != 0) return fail("kernel 出错：%s", cu_err(cr));
    w1 = now();
    *out_ms = (w1 - w0) * 1000.0 / (double)inner;
    return 1;
}

static unsigned g_seed = 12345u;
static double frand(void)
{
    g_seed = g_seed * 1103515245u + 12345u;
    return (double)((g_seed >> 9) & 0xFFFF) / 65536.0 - 0.5;
}

static int cmp_dbl(const void *a, const void *b)
{
    double x = *(const double *)a, y = *(const double *)b;
    return (x > y) - (x < y);
}

/* 抽样后向误差：|算错-精确| / Σ|a·b|。
 * 不用相对误差 —— 输出接近 0 时相对误差会爆，那是度量的问题不是 kernel 的问题。 */
static int check(int M, int N, int K, const float *fA, const float *fB, double *err_out)
{
    size_t kc = (size_t)M * (size_t)N, i, step;
    float *fC = g_fC;                 /* 复用，容量由 ensure_host 保证 >= kc */
    int r, q, p, bad = 0;
    double e0 = 0;

    if (!fC) { printf("  host 内存不足\n"); return 0; }
    if (p_cuMemcpyDtoH_v2(fC, g_dC, kc * sizeof(float)) != 0)
        return fail("回读失败");
    step = kc > 20000 ? kc / 20000 : 1;
    for (i = 0; i < kc; i += step) {
        double acc = 0.0, mag = 0.0, d, rel;
        r = (int)(i / (size_t)N);
        q = (int)(i % (size_t)N);
        for (p = 0; p < K; p++) {
            double a = (double)fA[(size_t)r * K + p];
            double b = (double)fB[(size_t)p * N + q];
            acc += a * b;
            mag += fabs(a * b);
        }
        d = fabs((double)fC[i] - acc);
        rel = mag > 0 ? d / mag : d;
        if (rel > e0) e0 = rel;
        if (rel > 1e-5) bad++;
    }
    *err_out = e0;
    return bad == 0;
}

static int ensure_host(size_t need)
{
    if (need <= g_fcap) return 1;
    free(g_fA); free(g_fB); free(g_fC);
    g_fA = (float *)malloc(need * sizeof(float));
    g_fB = (float *)malloc(need * sizeof(float));
    g_fC = (float *)malloc(need * sizeof(float));   /* 回读缓冲也必须跟着涨 */
    if (!g_fA || !g_fB || !g_fC) return 0;
    g_fcap = need;
    return 1;
}

/* event 计时的可用性说明：
 * **不能在两个 event 都 record 之前就问一次**——还没 record 时问，
 * 拿到的是 400 (INVALID_HANDLE)，那是「还没记录」不是「驱动不支持」。
 * 误判一次就永久退回墙钟，而墙钟在小矩阵上摊不干净 sync 开销
 * （5 次连发摊一次 sync，N=96 时每发才 14us，开销能占到 25%），
 * 于是把噪声当成 N=96 的真实差异。所以判定放在 time_one 里、
 * 第一次 record 之后再做，判完就不再回头预探。 */

int main(int argc, char **argv)
{
    /* N 密集扫：256 是 shared 阈值，1280 是 8x8 阈值，两个拐点附近都得有点。
     * 1216/1276/1280/1284/1344 是故意塞的——阈值±16 和 ±4，
     * 「阈值写错 4」和「阈值写错 64」得能分开。 */
    static const int def_ns[] = {
        256, 320, 384, 448, 512, 640, 768, 896, 1024, 1088, 1152, 1216,
        1276, 1280, 1284, 1344, 1408, 1536, 1792, 2048, 2560, 3216
    };
    int  ns[64];
    int  nsz;
    int R    = argc > 1 ? atoi(argv[1]) : 7;
    int inner = 5;
    /* [N 点][轮][kernel]。必须是三维：二维会退化成「每轮覆盖上一轮」，
     * 取中位数时读到未初始化内存，输出全是 0.000 而且不报错。 */
    static double samp[64][64][NK];
    int i, k, r, allok = 1, prod, bestk;

    /* 命令行给了尺寸就用给的（hammer 某个可疑带），没给就用默认全扫 */
    if (argc > 2) {
        nsz = argc - 2;
        if (nsz > 64) nsz = 64;
        for (i = 0; i < nsz; i++) ns[i] = atoi(argv[2 + i]);
    } else {
        nsz = (int)(sizeof(def_ns) / sizeof(def_ns[0]));
        memcpy(ns, def_ns, sizeof(def_ns));
    }

    SetConsoleOutputCP(65001);
    if (R < 1) R = 1;
    if (R > 64) R = 64;
    if (!driver_init()) { printf("初始化失败：%s\n", g_err); return 1; }
    printf("每点 %d 轮，每轮每 kernel 连发 %d 次取平均，每点取 %d 轮的中位数\n",
           R, inner, R);
    printf("路由阈值按生产代码：N>=%d 用 8x8，N>=%d 用 shared，否则 4x4\n\n",
           PROD_8X8_MIN_N, PROD_SHARED_MIN_N);

    /* 表头同样按 NK 生成，和数据行永远对得上 */
    printf("%-6s |", "N");
    for (k = 0; k < NK; k++) printf(" %9s", g_k[k].tag);
    printf(" | %6s %6s %6s | %-5s %-6s %-9s\n", "块4x4", "块共", "块8x8", "最优", "路由", "路由损失");
    for (k = 0; k < NK; k++) printf("--------");
    printf("\n");
    fflush(stdout);

    for (i = 0; i < nsz; i++) {
        int N = ns[i], M = N, K = N;
        size_t ka = (size_t)M * K, kb = (size_t)K * N, kc = (size_t)M * N;
        double err;
        unsigned bx, by, sx, sy, ox, oy;
        int inner_use = inner;

        /* 显存/内存随 N 涨，别每次都重 malloc */
        if (!ensure_host(ka > kb ? ka : kb)) { printf("host 内存不足\n"); return 1; }
        if (!ensure(kc * sizeof(float))) { printf("显存不足：%s\n", g_err); return 1; }
        for (r = 0, k = 0; k < (int)ka; k++) g_fA[k] = (float)frand();
        for (r = 0, k = 0; k < (int)kb; k++) g_fB[k] = (float)frand();
        p_cuMemcpyHtoD_v2(g_dA, g_fA, ka * sizeof(float));
        p_cuMemcpyHtoD_v2(g_dB, g_fB, kb * sizeof(float));
        memset(g_fC, 0, kc * sizeof(float));
        p_cuMemcpyHtoD_v2(g_dC, g_fC, kc * sizeof(float));

        /* 大矩阵少发几发，别把整轮拖太长（用户要的是速度） */
        if (N >= 2048) inner_use = 3;

        /* 先各跑一发验结果对不对。正确性与计时分开：
         * 正确性只要一发（这里的时间不参与统计），计时另走 inner 次连发。 */
        for (k = 0; k < NK; k++) {
            if (!run_once(k, M, N, K)) {
                printf("N=%-5d %s 发射失败：%s\n", N, g_k[k].tag, g_err);
                allok = 0;
                continue;
            }
            if (!check(M, N, K, g_fA, g_fB, &err)) {
                printf("N=%-5d %s ★结果不对★ 后向误差 %.3e\n", N, g_k[k].tag, err);
                allok = 0;
            }
        }

        /* 轮转顺序打散：第 r 轮从 (r%NK) 开始测，谁都不固定抢在升频窗口第一位 */
        for (r = 0; r < R; r++)
            for (k = 0; k < NK; k++) {
                int ki = (k + r) % NK;
                if (!time_one(ki, M, N, K, inner_use, &samp[i][r][ki])) {
                    printf("N=%-5d %s 计时失败：%s\n", N, g_k[ki].tag, g_err);
                    samp[i][r][ki] = 1e30;
                    allok = 0;
                }
            }
        /* samp 的下标是 [N][轮][kernel]，三个维度各管各的。
         * （曾经把它当成 [N][kernel] 存、又当成 [N][轮] 取，d[ki] 每轮覆盖同一格，
         *   取中位数时越界读栈垃圾，于是三列全是 0.000 —— 这种错不会崩，只会安静地说谎。） */
        for (k = 0; k < NK; k++) {
            double s[64];
            for (r = 0; r < R; r++) s[r] = samp[i][r][k];
            qsort(s, R, sizeof(double), cmp_dbl);
            g_k[k].t = (R & 1) ? s[R / 2] : 0.5 * (s[R / 2 - 1] + s[R / 2]);
        }

        grid_of(&g_k[0], M, N, &bx, &by);
        grid_of(&g_k[1], M, N, &sx, &sy);
        grid_of(&g_k[2], M, N, &ox, &oy);

        bestk = 0;
        for (k = 1; k < NK; k++) if (g_k[k].t < g_k[bestk].t) bestk = k;
        prod = (N >= PROD_8X8_MIN_N) ? 3 : (N >= PROD_SHARED_MIN_N) ? 1 : 0;

        /* 列按 NK 通用生成。之前手写死 4 列，一加变体就得改三处，
         * 迟早漏一列 —— 这种「加一列要改三个地方」的表越长越容易对不上。
         * 印的是时间 g_k[k].t，不是标签；印错过一次，整张表看起来像在
         * 比较字符串，浪费一轮实验才反应过来。 */
        printf("%-6d |", N);
        for (k = 0; k < NK; k++) printf(" %9.3f", g_k[k].t);
        printf(" | %6u %6u %6u | %-5s %-6s %+8.1f%%",
               bx * by, sx * sy, ox * oy,
               g_k[bestk].tag, g_k[prod].tag,
               g_k[bestk].t > 0 ? (g_k[prod].t - g_k[bestk].t) / g_k[bestk].t * 100.0 : 0.0);
        if (prod != bestk && g_k[bestk].t > 0 &&
            (g_k[prod].t - g_k[bestk].t) / g_k[bestk].t > 0.20)
            printf("  ★病态★");
        printf("\n");
        fflush(stdout);
    }

    printf("\n%s\n", allok ? "三个 kernel 全部结果正确" : "★有失败★");
    return allok ? 0 : 1;
}
