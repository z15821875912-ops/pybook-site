# -*- coding: utf-8 -*-
"""_calc_c.py — 数值微积分与求根（实现在 pybook_lib.c）+ 原型 + 三张前端表

依赖刚接好的运行时回调槽：库函数通过 rt_call1 回调用户的 lambda。
lambda 在字节码后端还不支持，rt_call_value 会在那时给出可操作的报错（不是 cryptic 的编译错）。

## 算法选择（都是标准且好解释的，刻意不搞花活）
- 导数：中心差分 (f(x+h) - f(x-h)) / (2h)。默认 h = 1e-5·max(1,|x|) ——
  再小就撞上 double 的相减相消（f(x+h) 和 f(x-h) 相减本身要损失精度）。
- 积分：复合 Simpson。区间数必须是偶数（Simpson 要求），用户给了奇数就 +1 并说明。
- 二分法：要求 f(a)·f(b) < 0。不满足时报错并把两端的函数值算给你看 ——
  「没有变号」是调用方的问题，静默返回一个数会让人以为求成功了。
- 牛顿法：给解析导数就用它（更快更准），不给就用中心差分估导数。
  两种都给：mt.root_newton(f, x0) 用数值导数，mt.root_newton_d(f, df, x0) 用解析导数。
"""
import io

C_SRC = r'''
/* ================= 数值微积分与求根（需要函数值回调）=================
 * 这批函数是「库函数回调用户 lambda」的这一批用户。之前做不到：
 * mec lambda 的分发函数 rt_mec_apply 由编译器生成进 out.c，不在 pyvm.exe 里，
 * 库函数链接期根本找不到它。现在运行时存了一个分发函数指针
 * （rt_set_fn_dispatch / rt_call1），用户程序在 main() 开头装进来。
 *
 * 步长 / 区间数 / 容差都做成可选参数（LIB_CALLS 里写成 (最少,最多)），
 * 用户没给时 codegen 补空盒，这里把空盒当「用缺省值」。
 */

/* 缺省参数的取值：空盒 = 用户没给 */
static double opt_num(Value v, double deflt, const char *who)
{
    if (IS_NONE(v)) return deflt;
    return lib_num(v, who);
}

/* 回调 f(x) 并取结果必须是数字。f 不是数字就报错 —— 求导/积分里 f 返回列表
   或文本是调用方的类型错误，静默当 0 会让结果完全错但看不出原因。 */
static double cb_num(Value fnval, double x, const char *who)
{
    Value r = rt_call1(fnval, rt_float(x));
    if (IS_FLT(r)) return AS_FLT(r);
    if (IS_INT(r) || IS_BIGINT(r)) return (double)rt_to_ll(r);
    if (IS_BOOL(r)) return AS_BOOL(r) ? 1.0 : 0.0;
    rt_die("%s：被调的函数在 %g 处没有返回数字（拿到 %s）\n"
           "  为什么：求导/积分靠的是对函数值做差商，函数值不是数就没有差商\n"
           "  怎么改：确认 lambda 的最后一句是 ret 一个数字", who, x,
           rt_q_typename ? rt_q_typename(r) : "非数字");
    return 0.0;
}

/* 中心差分。h <= 0 时自动取一个合适的缺省步长 */
static double deriv_core(Value fnval, double x, double h, const char *who)
{
    if (!(h > 0.0))
        h = 1e-5 * (fabs(x) > 1.0 ? fabs(x) : 1.0);
    if (h < x * 1e-12 || h < 1e-300)    /* x 附近再小步长就等于 x 了 */
        rt_die("%s：步长 %g 对 x=%g 来说太小\n"
               "  为什么：x+h 舍入后还是 x，差商会变成 0\n"
               "  怎么改：换一个显式步长，比如 mt.deriv(f, x, 0.01)", who, h, x);
    return (cb_num(fnval, x + h, who) - cb_num(fnval, x - h, who)) / (2.0 * h);
}

/* mt.deriv(f, x[, h]) —— 数值导数 */
Value rt_lib_mt_deriv(Value fnval, Value xv, Value hv)
{
    return rt_float(deriv_core(fnval, lib_num(xv, "mt.deriv 的 x"),
                              opt_num(hv, 0.0, "mt.deriv 的步长"), "mt.deriv"));
}

/* mt.integrate(f, a, b[, n]) —— 复合 Simpson */
Value rt_lib_mt_integrate(Value fnval, Value av, Value bv, Value nv)
{
    double a = lib_num(av, "mt.integrate 的下限");
    double b = lib_num(bv, "mt.integrate 的上限");
    long long n = (long long)opt_num(nv, 100.0, "mt.integrate 的区间数");
    double h, s;
    long long i;
    if (!(b > a))
        rt_die("mt.integrate：上限要大于下限（收到 a=%g, b=%g）\n"
               "  为什么：反向区间的定积分是负的，本函数按 [下限,上限] 处理\n"
               "  怎么改：把两个端点对调，或者自己在结果前面加负号", a, b);
    if (n < 2)
        rt_die("mt.integrate：区间数至少要 2（收到 %lld）\n"
               "  为什么：Simpson 每个区间用 3 个点，至少要 1 个区间\n"
               "  怎么改：给一个 >= 2 的区间数", n);
    if (n % 2) n++;                     /* Simpson 要求偶数个区间，补一个 */
    h = (b - a) / (double)n;
    s = cb_num(fnval, a, "mt.integrate") + cb_num(fnval, b, "mt.integrate");
    for (i = 1; i < n; i++) {
        double w = (i % 2) ? 4.0 : 2.0;
        s += w * cb_num(fnval, a + h * (double)i, "mt.integrate");
    }
    return rt_float(s * h / 3.0);
}

/* mt.root_bisect(f, a, b[, tol]) —— 二分法，要求端点异号 */
Value rt_lib_mt_root_bisect(Value fnval, Value av, Value bv, Value tolv)
{
    double a = lib_num(av, "mt.root_bisect 的左端");
    double b = lib_num(bv, "mt.root_bisect 的右端");
    double tol = opt_num(tolv, 1e-12, "mt.root_bisect 的容差");
    double fa, fb, m;
    int guard;
    if (!(a < b)) {
        if (b < a) { double t = a; a = b; b = t; }
        else rt_die("mt.root_bisect：两个端点不能相同（都是 %g）\n"
                    "  为什么：区间长度是 0，二分无从下手\n"
                    "  怎么改：给一个真正跨越根的区间", a);
    }
    if (!(tol > 0.0))
        rt_die("mt.root_bisect：容差要大于 0（收到 %g）\n"
               "  怎么改：写一个正数，比如 1e-10", tol);
    fa = cb_num(fnval, a, "mt.root_bisect");
    fb = cb_num(fnval, b, "mt.root_bisect");
    if (fa * fb > 0.0)
        rt_die("mt.root_bisect：区间 [%g, %g] 上两端同号（f(%g)=%g, f(%g)=%g），里面没有变号点\n"
               "  为什么：连续函数要在区间内有根，两端必须异号；同号时二分法收敛到的是错的点\n"
               "  怎么改：扩大区间直到两端异号；或者函数在区间内有偶数个根时改用 mt.root_newton\n"
               "        并给一个更靠近根的初值", a, b, a, fa, b, fb);
    /* 上面的 while 语义在这里写成显式循环，避免 C 的 do-while 把 fb 更新漏掉 */
    for (guard = 0; guard < 4096; guard++) {
        m = 0.5 * (a + b);
        if (b - a < tol || m == a || m == b) break;
        fa = cb_num(fnval, a, "mt.root_bisect");
        if (fa * cb_num(fnval, m, "mt.root_bisect") <= 0.0) b = m;
        else a = m;
    }
    return rt_float(0.5 * (a + b));
}

/* 牛顿法的共用主体；dfopt 为空盒时用中心差分估导数 */
static double newton_core(Value fnval, Value dfopt, double x0,
                          double tol, long long maxiter, const char *who)
{
    double x = x0, fx, dx;
    long long k;
    for (k = 0; k < maxiter; k++) {
        fx = cb_num(fnval, x, who);
        if (fabs(fx) < tol) return x;
        dx = IS_NONE(dfopt) ? deriv_core(fnval, x, 0.0, who)
                            : cb_num(dfopt, x, who);
        if (dx == 0.0)
            rt_die("%s：在 x=%g 处导数为 0，牛顿法没法往下走\n"
                   "  为什么：x_{n+1} = x_n - f/f'，除数为 0\n"
                   "  怎么改：换一个初值，或先用 mt.root_bisect 定位到导数不为 0 的一段", who, x);
        x -= fx / dx;
        if (IS_INF(x) || IS_NAN(x))
            rt_die("%s：从初值 %g 出发迭代发散了（算到了非数）\n"
                   "  为什么：牛顿法只在根附近收敛，初值太远就会跳飞\n"
                   "  怎么改：换一个更靠近根的初值，或改用 mt.root_bisect（要求两端异号但全局稳）", x0);
    }
    rt_die("%s：从 %g 迭代 %lld 次仍没收敛\n"
           "  为什么：牛顿法只在根附近收敛\n"
           "  怎么改：给更近的初值，或改用 mt.root_bisect", who, x0, maxiter);
    return x;
}

/* mt.root_newton(f, x0[, tol[, 最多步数]]) —— 导数用中心差分估 */
Value rt_lib_mt_root_newton(Value fnval, Value x0v, Value tolv, Value maxv)
{
    return rt_float(newton_core(fnval, rt_none(),
                                lib_num(x0v, "mt.root_newton 的初值"),
                                opt_num(tolv, 1e-12, "mt.root_newton 的容差"),
                                (long long)opt_num(maxv, 100.0, "mt.root_newton 的最多步数"),
                                "mt.root_newton"));
}

/* mt.root_newton_d(f, df, x0[, tol[, 最多步数]]) —— 用解析导数，更快更准 */
Value rt_lib_mt_root_newton_d(Value fnval, Value dfv, Value x0v,
                              Value tolv, Value maxv)
{
    return rt_float(newton_core(fnval, dfv,
                                lib_num(x0v, "mt.root_newton_d 的初值"),
                                opt_num(tolv, 1e-12, "mt.root_newton_d 的容差"),
                                (long long)opt_num(maxv, 100.0, "mt.root_newton_d 的最多步数"),
                                "mt.root_newton_d"));
}

/* mt.taylor(f, x, n) —— x 处的前 n 项泰勒展开系数（0..n-1 阶导数 / k!） */
Value rt_lib_mt_taylor(Value fnval, Value xv, Value nv)
{
    double x = lib_num(xv, "mt.taylor 的 x");
    long long n = (long long)lib_num(nv, "mt.taylor 的阶数"), k;
    double fact = 1.0;
    Value out = rt_list_new();
    if (n < 1)
        rt_die("mt.taylor：阶数至少要 1（收到 %lld）\n"
               "  为什么：0 阶就是函数值本身，不需要展开\n"
               "  怎么改：给一个 >= 1 的阶数", n);
    rt_push(&out, rt_float(cb_num(fnval, x, "mt.taylor")));
    for (k = 1; k < n; k++) {
        fact *= (double)k;
        rt_push(&out, rt_float(deriv_core(fnval, x, 0.0, "mt.taylor") / fact));
    }
    return out;
}
'''

H_DECLS = r"""
/* ---- 数值微积分与求根（需要函数值回调；lambda 目前只有 C 后端支持）---- */
Value rt_lib_mt_deriv(Value f, Value x, Value h);                       /* mt.deriv(f,x[,h]) */
Value rt_lib_mt_integrate(Value f, Value a, Value b, Value n);          /* mt.integrate(f,a,b[,n]) */
Value rt_lib_mt_root_bisect(Value f, Value a, Value b, Value tol);     /* mt.root_bisect(f,a,b[,tol]) */
Value rt_lib_mt_root_newton(Value f, Value x0, Value tol, Value mx);    /* mt.root_newton(f,x0[,tol[,最多步]]) */
Value rt_lib_mt_root_newton_d(Value f, Value df, Value x0, Value tol, Value mx); /* mt.root_newton_d(f,df,x0[,tol[,最多步]]) */
Value rt_lib_mt_taylor(Value f, Value x, Value n);                      /* mt.taylor(f,x,n) */
"""

# (前端名, (最少,最多), C 函数名)
ENTRIES = [
    ('mt.deriv',         (2, 3), 'rt_lib_mt_deriv'),
    ('mt.integrate',     (3, 4), 'rt_lib_mt_integrate'),
    ('mt.root_bisect',   (3, 4), 'rt_lib_mt_root_bisect'),
    ('mt.root_newton',   (2, 4), 'rt_lib_mt_root_newton'),
    ('mt.root_newton_d', (3, 5), 'rt_lib_mt_root_newton_d'),
    ('mt.taylor',        (3, 3), 'rt_lib_mt_taylor'),
]


def rd(p):
    return io.open(p, encoding='utf-8', newline='').read()


def wr(p, t):
    io.open(p, 'w', encoding='utf-8', newline='').write(t)


def ins_after(p, anchor, block, tag):
    t = rd(p)
    if tag in t:
        print('  %s: 已有 %s，跳过' % (p, tag))
        return
    e = '\r\n' if '\r\n' in t else '\n'
    # pybook_lib.c 是混合行尾（多数 CRLF，夹着少数裸 LF），
    # 所以锚点要两种行尾都试，不能假定整份文件统一。
    for ae in (e, '\n', '\r\n'):
        a = anchor.replace('\n', ae)
        if a in t:
            break
    else:
        raise SystemExit('%s: 锚点找不到\n%r' % (p, anchor))
    i = t.index(a) + len(a)
    wr(p, t[:i] + block.replace('\n', e) + t[i:])
    print('  %s: 已插入（锚点行尾 %s）' % (p, 'CRLF' if ae == '\r\n' else 'LF'))


print('== pybook_lib.c ==')
ins_after('pybook_lib.c',
          'Value rt_lib_mt_is_inf(Value n)\n{',
          C_SRC, 'rt_lib_mt_deriv')
print('== pybook_lib.h ==')
ins_after('pybook_lib.h',
          'Value rt_lib_mt_is_inf(Value n);',
          H_DECLS, 'rt_lib_mt_deriv')

print('== pybk_front.py : LIB_CALLS ==')
t = rd('pybk_front.py')
if "'mt.deriv'" in t:
    print('  已接线')
else:
    blk = ("\n    # ---- 数值微积分与求根（(最少,最多) = 可选参数，缺省由 codegen 补空盒）----\n"
           + ''.join("    '%s': (%d, %d),\n" % (n, lo, hi)
                     for n, (lo, hi), _c in ENTRIES))
    a = "    'tb.shuffle': 2, 'tb.onehot': 2, 'tb.batch': 3,\n"
    i = t.index(a) + len(a)
    wr('pybk_front.py', t[:i] + blk + t[i:])
    print('  已接线 (%d 个)' % len(ENTRIES))

print('== pybk_code.py : LIB_C_NAMES ==')
t = rd('pybk_code.py')
if "'mt.deriv'" in t:
    print('  已接线')
else:
    blk = ("        # 数值微积分与求根（pybook_lib.c，依赖运行时回调槽）\n"
           + ''.join("        '%s': '%s',\n" % (n, c) for n, _a, c in ENTRIES))
    a = "        'tb.dot': 'rt_tb_dot', 'tb.tr': 'rt_tb_tr',\n"
    i = t.index(a) + len(a)
    wr('pybk_code.py', t[:i] + blk + t[i:])
    print('  已接线 (%d 个)' % len(ENTRIES))

print('== _vm_lib_calls.inc ==')
t = rd('_vm_lib_calls.inc')
e = '\r\n' if '\r\n' in t else '\n'
if '"mt.deriv"' in t:
    print('  已接线')
else:
    a = 'Value rt_lib_mp_rand_binom(Value, Value);' + e
    i = t.index(a) + len(a)
    decls = ''.join('Value %s(%s);%s' % (c, ', '.join(['Value'] * hi), e)
                    for _n, (_lo, hi), c in ENTRIES)
    t = t[:i] + decls + t[i:]
    b = '    {"mp.rand_binom", 2, (void *)rt_lib_mp_rand_binom},' + e
    j = t.index(b) + len(b)
    rows = ''.join('    {"%s", %d, (void *)%s},%s' % (n, lo, c, e)
                   for n, (lo, _hi), c in ENTRIES)
    t = t[:j] + rows + t[j:]
    wr('_vm_lib_calls.inc', t)
    print('  已接线 (%d 个) —— 只登记最小参数个数，缺省由各后端自己处理' % len(ENTRIES))

print('共 %d 个入口' % len(ENTRIES))
