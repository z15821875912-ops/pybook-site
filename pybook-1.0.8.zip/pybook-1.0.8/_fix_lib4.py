# -*- coding: utf-8 -*-
"""_fix_lib4.py — 对拍第二轮抓到的 3 处

1. polyfit 换算回原幂时忘了把 ȳ 加回去 -> 拟合 x² 得到 [-6,0,1] 而不是 [0,0,1]
2. 插值越界：注释说「夹到端点」，代码却在末段上线性外推（查 99 得 489）。
   改成真夹取，两种插值一致（numpy.interp 的做法）。
3. harness 的期望值写错了：Catmull-Rom 用有限差分斜率，只对二次精确、对三次不精确。
"""
import io
import sys

P = 'pybook_lib.c'
t = io.open(P, encoding='utf-8', newline='').read()


def sub(tag, old, new):
    global t
    for eol in ('\r\n', '\n'):
        o, n = old.replace('\n', eol), new.replace('\n', eol)
        c = t.count(o)
        if c == 1:
            t = t.replace(o, n, 1)
            print('  [OK] %s（行尾 %s）' % (tag, 'CRLF' if eol == '\r\n' else 'LF'))
            return
        if c > 1:
            sys.exit('%s：子串出现 %d 次，不唯一' % (tag, c))
    sys.exit('%s：子串找不到' % tag)


# ---- 1. 把 ȳ 加回去 ----
sub('1 polyfit 别忘了加回 ȳ',
    """            d[0] = -sx * d[0] + cx[jj];
        }""",
    """            d[0] = -sx * d[0] + cx[jj];
        }
        d[0] += sy;          /* 拟合的是 my = y − ȳ，别忘了把 ȳ 加回来；
                              * 漏掉的话拟合 x² 会得到 [−6, 0, 1] 而不是 [0, 0, 1] */
    }""")

# ---- 2. 插值越界改成夹取 ----
sub('2a 线性插值越界夹取',
    """/* 找 x 落在哪一段：返回 i 使得 x[i] <= q < x[i+1]；超出范围夹到端点 */
static long long lib_locate(const double *x, long long n, double q)
{
    long long lo = 0, hi = n - 2, mid;
    if (n < 2) return 0;
    if (q <= x[0])   return 0;
    if (q >= x[n - 1]) return n - 2;""",
    """/* 找 x 落在哪一段：返回 i 使得 x[i] <= q < x[i+1]。
 * 越界的返回值由调用方决定是夹取还是外推（这里两种插值都选夹取，
 * 与 numpy.interp 一致；末段线性外推会把 99 处的查询算成 489）。 */
static long long lib_locate(const double *x, long long n, double q)
{
    long long lo = 0, hi = n - 2, mid;
    if (n < 2) return 0;
    if (q <= x[0])   return 0;
    if (q >= x[n - 1]) return n - 2;""")

sub('2b 线性插值：越界直接给端点值',
    """    long long i;
    double    t;
    if (n < 2) return y[0];        /* 一个点插不出线，直接给该点的值 */
    i = lib_locate(x, n, q);
    t = (q - x[i]) / (x[i + 1] - x[i]);
    return y[i] + t * (y[i + 1] - y[i]);""",
    """    long long i;
    double    t;
    if (n < 2) return y[0];        /* 一个点插不出线，直接给该点的值 */
    if (q <= x[0])     return y[0];            /* 越界夹取，不外推 */
    if (q >= x[n - 1]) return y[n - 1];
    i = lib_locate(x, n, q);
    t = (q - x[i]) / (x[i + 1] - x[i]);
    return y[i] + t * (y[i + 1] - y[i]);""")

sub('2c 三次插值：越界直接给端点值',
    """    if (n < 2) return y[0];
    if (n == 2) return y[0] + (q - x[0]) / (x[1] - x[0]) * (y[1] - y[0]);
    i = lib_locate(x, n, q);
    if (q <= x[0])     i = 0;
    if (q >= x[n - 1]) i = n - 2;""",
    """    if (n < 2) return y[0];
    if (q <= x[0])     return y[0];            /* 越界夹取，与线性插值一致 */
    if (q >= x[n - 1]) return y[n - 1];
    if (n == 2) return y[0] + (q - x[0]) / (x[1] - x[0]) * (y[1] - y[0]);
    i = lib_locate(x, n, q);""")

io.open(P, 'w', encoding='utf-8', newline='').write(t)
print('\n第二轮 3 处已修')
