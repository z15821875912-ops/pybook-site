﻿/* _cpupk.c —— CPU 的 FP64 / FP32 极限速度，以及两者的比值。
 *
 * 为什么要单独测这个：
 *   PYbook 的 CPU 矩阵乘微内核（pybook_tb.c 的 tb_micro_packed）是 FP64 的
 *   （_mm256_fmadd_pd）。而实测大矩阵能跑到 80 GFLOPS，
 *   按「这颗 U 的 FP64 是 FP32 的 1/64」去推，天花板只有 4~13 GFLOPS —— 对不上。
 *   到底是微内核已经贴着上限，还是我记错了 FP64 比例，必须实测仲裁。
 *   没有这根标尺，说不清还剩多少空间，也就没法判断值不值得优化。
 *
 * 反作弊设计与 GPU 侧完全一致（_mkfmareal.py 的 D1~D4）：
 *   D1 初值从内存载入 -> 编译期不知道初值，堵死整条链折叠成常量
 *   D2 K[s][c] 两两互异 -> 堵死链合并 / 等差数列化简
 *   D3 K 取 1.0 附近的随机值，不构成等差/等比数列
 *   D4 宿主标量 fma()/fmaf() 重放逐位对拍 -> 兜底
 *
 * ============ 两处踩过的坑，别改回去 ============
 *
 * (1) D4 的标量参考如果被 GCC 内联进调用方，它会在这条长 fma 链上
 *     静默改数值语义（GPU 那轮实测：参考值 15.8535948 -> 14.74259，
 *     10240 个结果全红，而 GPU 一个字节都没变）。
 *     参考侧必须 volatile + noinline，否则闸门咬的是参考实现而不是内核。
 *
 * (2) noinline 不只是给参考用的。向量内核一旦被内联进 worker()，
 *     GCC 会把这条 8x32 的 FMA 链拆散，实测吞吐掉一个数量级
 *     （2626 -> 约 350 GFLOPS）。所以向量内核也标 noinline。
 *     用 -DNOINLINE_OFF 可以编一份对照来复现这个差别。
 *
 * (3) 计时参数必须显式赋值。曾经漏掉 arg[k].diters/fiters，
 *     循环一次都没跑，量到的纯粹是建线程开销，于是报出 5354 GFLOPS
 *     这种物理上不可能的数。
 * =================================================
 *
 * 编译：
 *   C:\Users\zhuli\mingw64\bin\x86_64-w64-mingw32-gcc.exe _cpupk.c -o _cpupk.exe -O3 -march=native -lm
 * 对照：
 *   同上加 -DNOINLINE_OFF
 * 用法：
 *   _cpupk.exe
 */
#include <windows.h>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <immintrin.h>
#include "_cpupk_const.h"
#include "_fmareal_const.h"

#define F64_LANES (CP_ACC * 4)      /* 32 条独立链 */
#define F32_LANES (8 * 8)           /* 64 条独立链，与 GPU 侧同数量便于对照 */

#ifdef NOINLINE_OFF
#define NI
#else
#define NI __attribute__((noinline))
#endif

/* ---------------- FP64 向量内核：8 个 ymm 累加器 ---------------- */
NI
static void f64_v(const double *init, double *out, unsigned iters)
{
    __m256d a[CP_ACC];
    int c;
    unsigned it;
    int s;
    for (c = 0; c < CP_ACC; c++) a[c] = _mm256_loadu_pd(init + c * 4);
    for (it = 0; it < iters; it++)
        for (s = 0; s < CP_S; s++)
            for (c = 0; c < CP_ACC; c++)
                a[c] = _mm256_fmadd_pd(a[c], _mm256_set1_pd(CPK[s][c]),
                                       _mm256_set1_pd(CPB[c]));
    for (c = 0; c < CP_ACC; c++) _mm256_storeu_pd(out + c * 4, a[c]);
}

/* ---------------- FP64 标量参考：volatile + noinline ---------------- */
NI
static void f64_ref(const double *init, double *out, unsigned iters)
{
    volatile double *acc = out;
    int L;
    unsigned it;
    int s;
    for (L = 0; L < F64_LANES; L++) acc[L] = init[L];
    for (it = 0; it < iters; it++)
        for (s = 0; s < CP_S; s++)
            for (L = 0; L < F64_LANES; L++)
                acc[L] = fma(acc[L], CPK[s][L / 4], CPB[L / 4]);
}

/* ---------------- FP32 向量内核：8 个 ymm 累加器 ---------------- */
NI
static void f32_v(const float *init, float *out, unsigned iters)
{
    __m256 a[8];
    int c;
    unsigned it;
    int s;
    for (c = 0; c < 8; c++) a[c] = _mm256_loadu_ps(init + c * 8);
    for (it = 0; it < iters; it++)
        for (s = 0; s < FM_S; s++)
            for (c = 0; c < 8; c++)
                a[c] = _mm256_fmadd_ps(a[c], _mm256_set1_ps(FMK[s][c]),
                                       _mm256_set1_ps(FMB[c]));
    for (c = 0; c < 8; c++) _mm256_storeu_ps(out + c * 8, a[c]);
}

/* ---------------- FP32 标量参考 ---------------- */
NI
static void f32_ref(const float *init, float *out, unsigned iters)
{
    volatile float *acc = out;
    int L;
    unsigned it;
    int s;
    for (L = 0; L < F32_LANES; L++) acc[L] = init[L];
    for (it = 0; it < iters; it++)
        for (s = 0; s < FM_S; s++)
            for (L = 0; L < F32_LANES; L++)
                acc[L] = fmaf(acc[L], FMK[s][L / 8], FMB[L / 8]);
}

typedef struct {
    const double *dinit;
    double *dout;
    unsigned diters;
    const float *finit;
    float *fout;
    unsigned fiters;
    int which;                 /* 0 = 跑 FP64, 1 = 跑 FP32 */
} jarg;

static DWORD WINAPI worker(LPVOID p)
{
    jarg *a = (jarg *)p;
    if (a->which == 0)
        f64_v(a->dinit, a->dout, a->diters);
    else
        f32_v(a->finit, a->fout, a->fiters);
    return 0;
}

/* mask = 0 表示不绑核；否则只允许在 mask 指定的逻辑核上跑。
 * 整机满载时测不出可信数字，但「FP32:FP64 比值」是单核架构属性，
 * 只需要一根安静的核就够了 —— 所以逐核绑定各测一遍，取最闲的那根。 */
static double run_threads(int n, jarg *a, DWORD_PTR mask)
{
    HANDLE th[64];
    int i;
    LARGE_INTEGER qpf, t0, t1;
    QueryPerformanceFrequency(&qpf);
    QueryPerformanceCounter(&t0);
    for (i = 0; i < n; i++) {
        if (mask) SetThreadAffinityMask(GetCurrentThread(), mask);
        th[i] = CreateThread(NULL, 0, worker, &a[i], 0, NULL);
    }
    for (i = 0; i < n; i++) { WaitForSingleObject(th[i], INFINITE); CloseHandle(th[i]); }
    SetThreadAffinityMask(GetCurrentThread(), (DWORD_PTR)-1);
    QueryPerformanceCounter(&t1);
    return (double)(t1.QuadPart - t0.QuadPart) / (double)qpf.QuadPart * 1000.0;
}

static int cmp_dbl(const void *a, const void *b)
{
    double x = *(const double *)a, y = *(const double *)b;
    return (x > y) - (x < y);
}

/* ================= 机器负载守卫 =================
 *
 * 为什么要专门写这个：2026-10-17 第一次跑这套工具，机器上同时有 WorkBuddy /
 * ZCode / Doubao 在烧，CPU 总占用 89~92%、12 个逻辑核全部 83~95%。
 * 于��同一个内核的吞吐在四轮之间从 2626 GFLOPS 抖到 183 GFLOPS（14 倍），
 * 报出去的数全是争抢出来的，不是内核的速度。
 *
 * 这类错误比「编译不过」危险得多 —— 它不会报错，只会安静地给出一个看着
 * 很正常的数字。所以让工具自己判断：机器不空闲就不许报吞吐。
 * 判据用 GetSystemTimes，Windows API，不引任何外部依赖。
 */
#define LOAD_SAMPLE_MS 400
#define LOAD_CEILING   25.0    /* 总占用超过这个百分比就判为「机器不空闲」 */

static double sys_busy_pct(void)
{
    FILETIME i0, k0, u0, i1, k1, u1;
    ULARGE_INTEGER ii, kk, uu, ii2, kk2, uu2;
    double idle, kern, user, total;

    GetSystemTimes(&i0, &k0, &u0);
    Sleep(LOAD_SAMPLE_MS);
    GetSystemTimes(&i1, &k1, &u1);

    ii.LowPart = i0.dwLowDateTime;  ii.HighPart = i0.dwHighDateTime;
    kk.LowPart = k0.dwLowDateTime;  kk.HighPart = k0.dwHighDateTime;
    uu.LowPart = u0.dwLowDateTime;  uu.HighPart = u0.dwHighDateTime;
    ii2.LowPart = i1.dwLowDateTime; ii2.HighPart = i1.dwHighDateTime;
    kk2.LowPart = k1.dwLowDateTime; kk2.HighPart = k1.dwHighDateTime;
    uu2.LowPart = u1.dwLowDateTime; uu2.HighPart = u1.dwHighDateTime;

    idle = (double)(ii2.QuadPart - ii.QuadPart);
    kern = (double)(kk2.QuadPart - kk.QuadPart);
    user = (double)(uu2.QuadPart - uu.QuadPart);
    /* Windows 的 kernel 时间已经包含 idle */
    total = kern + user;
    if (total <= 0.0) return 0.0;
    return (total - idle) / total * 100.0;
}

/* 吞吐类测量一律用「最短用时」而不是中位数：干扰只会让程序变慢，
 * 不会让它变快，所以最短的那一轮最接近真实内核速度。
 * 但最短值本身也可能偶尔「假快」（比如某一轮没真正做完），
 * 所以最小/中位/最大三个一起打出来，让人自己判断这一轮干不干净。 */
static void report_row(const char *tag, int nt, double dms, double dgf,
                       double fms, double fgf,
                       double dmin, double dmed, double dmax,
                       double fmin, double fmed, double fmax)
{
    printf("  %5d   %6.2f/%6.2f/%6.2f  %8.2f   %6.2f/%6.2f/%6.2f  %8.2f   %6.1f\n",
           nt, dmin, dmed, dmax, dgf, fmin, fmed, fmax, fgf, fgf / dgf);
    (void)tag;
}

/* 生产 CPU 矩阵乘在 2048³ 上的实测值，来自 _cpubench（见文件头）。 */
#define PROD_GFLOPS_2048 80.75

int main(int argc, char **argv)
{
    static const int thr[] = { 1, 2, 4, 6, 8, 12 };
    const unsigned DITERS = 4000, FITERS = 60000;
    int force = (argc > 1 && strcmp(argv[1], "--force") == 0);
    double busy = 0.0;
    double g_arch_d = 0.0, g_arch_f = 0.0;   /* 逐核阶段选出的单核最优值 */
    double *dinit = (double *)malloc(F64_LANES * sizeof(double));
    double *dout  = (double *)malloc((size_t)64 * F64_LANES * sizeof(double));
    double dref[F64_LANES];
    float *finit = (float *)malloc(F32_LANES * sizeof(float));
    float *fout  = (float *)malloc((size_t)64 * F32_LANES * sizeof(float));
    float fref[F32_LANES];
    jarg arg[64];
    int i, rep, ti;

    SetConsoleOutputCP(65001);
    if (!dinit || !dout || !finit || !fout) { printf("内存不足\n"); return 1; }

    for (i = 0; i < F64_LANES; i++) dinit[i] = 0.5 + (double)i * 0.03125;
    for (i = 0; i < F32_LANES; i++) finit[i] = 0.5f + (float)i * 0.03125f;

    /* ---------------- 正确性闸门 ----------------
     *
     * 关键：闸门必须覆盖**基准真正跑的那个迭代数**。
     * 反汇编发现循环体里的 fma 指令数远少于 8x32=256 条，说明编译器把 s 循环
     * 折叠了。原来闸门只测 64 轮、基准跑 4000 轮 —— 如果折叠的偏差只在高迭代数
     * 下显现，这道闸门根本抓不到，等于白设。所以两个迭代数都验：
     *   64 轮    验结构对不对
     *   4000 轮  验「我待会儿要测的那个东西」本身是不是真的在算
     */
    printf("================ 正确性闸门 ================\n");
    {
        int mism = 0, exact = 0;
        double worst = 0.0;
        int k2;

        for (k2 = 0; k2 < 2; k2++) {
            unsigned it = k2 ? DITERS : 64u;
            memset(dout, 0, (size_t)64 * F64_LANES * sizeof(double));
            f64_v(dinit, dout, it);
            f64_ref(dinit, dref, it);
            mism = 0; exact = 0; worst = 0.0;
            for (i = 0; i < F64_LANES; i++) {
                double d = fabs(dout[i] - dref[i]);
                double sc = fabs(dref[i]);
                if (sc < 1.0) sc = 1.0;
                if (memcmp(&dout[i], &dref[i], sizeof(double)) == 0) exact++;
                else { mism++; if (d / sc > worst) worst = d / sc; }
            }
            printf("  FP64  %d 条链 x %-5u 轮  逐位相同 %2d/%d   最大相对误差 %.3e\n",
                   F64_LANES, it, exact, F64_LANES, worst);
            if (mism) {
                printf("  [错误] %u 轮下向量内核与标量参考不一致"
                       "（最大相对误差 %.3e）—— 编译器折叠在高迭代数下露馅了，\n"
                       "         或者参考侧又被动了。所有吞吐数字作废。\n", it, worst);
                return 1;
            }
            if (!k2) {
                /* 黄金值只对应 64 轮。4000 轮的结果本来就该是另一个数，
                 * 拿 64 轮的黄金值去比它是我自己写错了检查位置。 */
                printf("        参考链0 = %.17g\n", dref[0]);
                if (fabs(dref[0] - 14.329965928236684) > 1e-9) {
                    printf("        [错误] 黄金值不符（应为 14.329965928236684）\n"
                           "               —— 是宿主参考被编译器改了，不是内核的锅\n");
                    return 1;
                }
                printf("        黄金值一致，宿主参考可信\n");
            } else {
                printf("        参考链0(4000轮) = %.17g\n", dref[0]);
            }
        }

        mism = 0; exact = 0; worst = 0.0;
        memset(fout, 0, (size_t)64 * F32_LANES * sizeof(float));
        f32_v(finit, fout, FITERS);
        f32_ref(finit, fref, FITERS);
        for (i = 0; i < F32_LANES; i++) {
            double d = fabs((double)fout[i] - (double)fref[i]);
            double sc = fabs((double)fref[i]);
            if (sc < 1.0) sc = 1.0;
            if (memcmp(&fout[i], &fref[i], sizeof(float)) == 0) exact++;
            else { mism++; if (d / sc > worst) worst = d / sc; }
        }
        printf("  FP32  %d 条链 x %-5u 轮  逐位相同 %2d/%d   最大相对误差 %.3e\n",
               F32_LANES, FITERS, exact, F32_LANES, worst);
        if (mism) { printf("  [错误] FP32 向量内核没算完，数字作废\n"); return 1; }
    }

    /* ---------------- 架构比值：逐核自选最闲的那根 ----------------
     *
     * 整机满载时，多线程吞吐一定是假的。但 FP32:FP64 是**单核架构属性**，
     * 只需要一根安静的核就够 —— 所以逐个逻辑核绑上去各测一遍，
     * 取用时最短的那根（干扰只会让程序变慢，不会让它变快）。
     * 这一段不受负载守卫拦截：它要的就是「在噪声里挑出最干净的那一次」。
     */
    printf("================ 架构比值：逐核单线程（不受负载守卫拦截） ================\n");
    {
        int ncpu = (int)GetActiveProcessorCount(ALL_PROCESSOR_GROUPS);
        double best_core_d = 0.0, best_core_f = 0.0;
        int best_core = -1;
        int cpu;
        if (ncpu > 12) ncpu = 12;

        printf("  每核单线程，%d 次取最短。每格 = 最短用时(ms)\n\n", 15);
        printf("   逻辑核   FP64 ms   FP64 GFLOPS   FP32 ms   FP32 GFLOPS   比值\n");
        printf("  -------------------------------------------------------\n");
        fflush(stdout);

        for (cpu = 0; cpu < ncpu; cpu++) {
            double dm[16], fm[16], dgf, fgf;
            int rep2, k;
            DWORD_PTR mask = ((DWORD_PTR)1) << cpu;
            for (k = 0; k < 1; k++) {
                arg[k].dinit = dinit;
                arg[k].dout = dout;
                arg[k].diters = DITERS;
                arg[k].finit = finit;
                arg[k].fout = fout;
                arg[k].fiters = FITERS;
            }
            arg[0].which = 0;
            run_threads(1, arg, mask);          /* 预热 */
            for (rep2 = 0; rep2 < 15; rep2++) {
                arg[0].which = 0;
                dm[rep2] = run_threads(1, arg, mask);
                arg[0].which = 1;
                fm[rep2] = run_threads(1, arg, mask);
            }
            qsort(dm, 15, sizeof(double), cmp_dbl);
            qsort(fm, 15, sizeof(double), cmp_dbl);
            dgf = (double)F64_LANES * CP_S * DITERS * 2.0 / (dm[0] / 1000.0) / 1e9;
            fgf = (double)F32_LANES * FM_S * FITERS * 2.0 / (fm[0] / 1000.0) / 1e9;
            printf("  %7d   %8.2f   %10.2f   %8.2f   %10.2f   %5.1f\n",
                   cpu, dm[0], dgf, fm[0], fgf, fgf / dgf);
            fflush(stdout);
            /* 以「两根都好」为准选核：只看 FP32 会偏向 FP64 受害少的核，
             * 这里用两条线各自最优的那根分别报告，最后再看比值。 */
            if (dgf > best_core_d) best_core_d = dgf;
            if (fgf > best_core_f) best_core_f = fgf;
            if (best_core < 0) best_core = cpu;
        }
        printf("\n  全核最优：FP64 %.2f GFLOPS，FP32 %.2f GFLOPS\n",
               best_core_d, best_core_f);
        printf("  => 单核 FP32/FP64 = %.1f 倍\n", best_core_f / best_core_d);
        printf("\n  解读：常见说法是「客户级 CPU 的 FP64 只有 FP32 的 1/64」。\n");
        printf("        上面的比值若不是 64，说明那条规则对这颗 U 不成立，\n");
        printf("        具体数值只认这里测出来的。\n");
        printf("        生产 CPU 矩阵乘是 FP64（_mm256_fmadd_pd），\n");
        printf("        所以它的天花板是 FP64 这条线，不是 FP32 那条。\n");
        printf("\n  生产矩阵乘对照：2048³ 实测 %.2f GFLOPS = 单核 FP64 上限的 %.0f%%\n",
               PROD_GFLOPS_2048, PROD_GFLOPS_2048 / best_core_d * 100.0);
        printf("  （12 线程并行还能再高若干倍，但那是另一回事，另测）\n");
        g_arch_d = best_core_d;
        g_arch_f = best_core_f;
    }

    /* ---------------- 线程扫描 ---------------- */
    printf("\n================ 机器负载守卫 ================\n");
    {
        double busy = sys_busy_pct();
        printf("  采样 %.0f ms，CPU 总占用 %.1f%%（本工具自己的线程不计入采样窗口）\n",
               (double)LOAD_SAMPLE_MS, busy);
        if (busy > LOAD_CEILING) {
            printf("\n  [拒绝] 机器不空闲（阈值 %.0f%%），下面的吞吐数字是在跟别的程序\n"
                   "         抢 CPU，测的是争抢不是内核。关掉占 CPU 的程序再跑。\n\n",
                   LOAD_CEILING);
            printf("  想强行看个大概，加 --force；\n"
                   "  但要清楚这些数字只能当量级，不能拿去跟别的数比较。\n\n");
            if (!force) {
                free(dinit); free(dout); free(finit); free(fout);
                return 2;
            }
            printf("  --force 已指定，继续（数字不可信）。\n\n");
        } else {
            printf("  机器空闲，可以测。\n");
        }
    }

    printf("================ 线程扫描 ================\n");
    printf("  每线程每轮：FP64 %d 条链 x %d 步 x %u 轮 | "
           "FP32 %d 条链 x %d 步 x %u 轮\n",
           F64_LANES, CP_S, DITERS, F32_LANES, FM_S, FITERS);
    printf("  每格三个数 = 最短/中位/最长用时(ms)，吞吐按最短那轮算\n");
    printf("\n   线程   FP64 ms(min/med/max)  GFLOPS   FP32 ms(min/med/max)  GFLOPS   FP32/FP64\n");
    printf("  --------------------------------------------------------------------------\n");
    {
        double best_d = 0.0, best_f = 0.0;
        int bd = 0, bf = 0;
        for (ti = 0; ti < 6; ti++) {
            int nt = thr[ti];
            double dm[16], fm[16], dgf, fgf;
            int k;
            for (k = 0; k < nt; k++) {
                arg[k].dinit = dinit;
                arg[k].dout = dout;
                arg[k].diters = DITERS;
                arg[k].finit = finit;
                arg[k].fout = fout;
                arg[k].fiters = FITERS;
            }
            for (k = 0; k < nt; k++) arg[k].which = 0;
            run_threads(nt, arg, 0);      /* 预热 */
            for (rep = 0; rep < 9; rep++) {
                for (k = 0; k < nt; k++) arg[k].which = 0;
                dm[rep] = run_threads(nt, arg, 0);
                for (k = 0; k < nt; k++) arg[k].which = 1;
                fm[rep] = run_threads(nt, arg, 0);
            }
            qsort(dm, 9, sizeof(double), cmp_dbl);
            qsort(fm, 9, sizeof(double), cmp_dbl);
            dgf = (double)nt * F64_LANES * CP_S * DITERS * 2.0
                  / (dm[0] / 1000.0) / 1e9;
            fgf = (double)nt * F32_LANES * FM_S * FITERS * 2.0
                  / (fm[0] / 1000.0) / 1e9;
            if (dgf > best_d) { best_d = dgf; bd = nt; }
            if (fgf > best_f) { best_f = fgf; bf = nt; }
            report_row("scan", nt, dm[4], dgf, fm[4], fgf,
                       dm[0], dm[4], dm[8], fm[0], fm[4], fm[8]);
            fflush(stdout);
        }
        printf("\n  FP64 极限 %.2f GFLOPS（%d 线程）\n", best_d, bd);
        printf("  FP32 极限 %.2f GFLOPS（%d 线程）\n", best_f, bf);
        printf("  FP32/FP64 = %.1f 倍\n", best_f / best_d);
        printf("\n  这个比值就是这颗 U 的 FP64 相对 FP32 的真实速率。\n");
        printf("  常被引用的说法是「客户级 CPU 的 FP64 是 FP32 的 1/64」，\n");
        printf("  实测不是这个数，以实测为准。\n");
        printf("\n  对照：生产 CPU 矩阵乘（_cpubench，2048³）实测 %.2f GFLOPS\n",
               PROD_GFLOPS_2048);
        printf("        = FP64 极限的 %.1f%%\n", PROD_GFLOPS_2048 / best_d * 100.0);
        if (busy > LOAD_CEILING)
            printf("\n  注意：本次是在机器不空闲的状态下跑的，以上数字只能当量级。\n");
    }

    free(dinit); free(dout); free(finit); free(fout);
    return 0;
}
