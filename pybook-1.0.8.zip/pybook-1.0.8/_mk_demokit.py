# 造「星港 · 反应堆控制台」演示素材（不依赖任何第三方库）
#
# 和 _mk_uiimg.py 的分工：
#   _mk_uiimg.py 是**验收**素材 —— 每张图都带可自证的判据（不对称白块、白条宽=帧号），
#                            难看不要紧，能断言才要紧。
#   本文件是**演示**素材 —— 目标是好看。这里没有一处是为了断言，
#                            全部是为了让 ui.图 / ui.序列 / ui.粒子 摆在一起像个成品。
#
# 生成物（27 张）：
#   _d_bg.png          900x560  星空背景（垂直渐变 + 星点 + 银河带 + 底部 alpha 渐降）
#   _d_glow.png        220x220  径向辉光（纯 alpha 渐变，垫在粒子区下面）
#   _d_panel.png       292x320  半透明圆角面板（alpha 170 + 青色边框）
#   _d_head.png        128x128  圆形徽章头像
#   _d_core_%02d.png   12 帧 180x180 旋转能量环
#   _d_flow_%02d.png    8 帧 240x20  能量流动条（斜纹平移）
#   _d_ico_%d.png       3 张 64x64  图标（推进 / 警戒 / 冷却）
#
# 全部函数自己算像素，覆盖率做抗锯齿（不是二值 inside/outside）。

import math
import struct
import zlib

# 确定性伪随机：不用 random，固定 LCG，保证每次生成结果一致、截图可比对
class R:
    def __init__(self, seed):
        self.s = seed & 0x7fffffff or 1

    def f(self):
        self.s = (self.s * 1103515245 + 12345) & 0x7fffffff
        return self.s / 0x7fffffff

    def i(self, a, b):
        return a + int(self.f() * (b - a + 1))


def write_png(path, w, h, pix):
    """pix 是 bytearray，长度 w*h*4，RGBA，自顶向下。"""
    raw = bytearray()
    for y in range(h):
        raw.append(0)
        raw += pix[y * w * 4:(y + 1) * w * 4]

    def chunk(tag, data):
        body = tag + data
        return (struct.pack('>I', len(data)) + body +
                struct.pack('>I', zlib.crc32(body) & 0xffffffff))

    out = b'\x89PNG\r\n\x1a\n'
    out += chunk(b'IHDR', struct.pack('>IIBBBBB', w, h, 8, 6, 0, 0, 0))
    out += chunk(b'IDAT', zlib.compress(bytes(raw), 9))
    out += chunk(b'IEND', b'')
    with open(path, 'wb') as fh:
        fh.write(out)
    return len(out)


class Img:
    """RGBA 画布，带 alpha 混合的 put（源 over 目标）。"""

    def __init__(self, w, h):
        self.w, self.h = w, h
        self.p = bytearray(w * h * 4)

    def set(self, x, y, r, g, b, a):
        if 0 <= x < self.w and 0 <= y < self.h and a > 0:
            i = (y * self.w + x) * 4
            self.p[i:i + 4] = bytes((r, g, b, min(255, int(a))))

    def over(self, x, y, r, g, b, a):
        """源 over 目标，a 是源覆盖率 0..255。"""
        if not (0 <= x < self.w and 0 <= y < self.h) or a <= 0:
            return
        i = (y * self.w + x) * 4
        p = self.p
        sa = a / 255.0
        da = p[i + 3] / 255.0
        oa = sa + da * (1 - sa)
        if oa <= 0:
            p[i:i + 4] = bytes(4)
            return
        for k, sv in enumerate((r, g, b)):
            dv = p[i + k]
            p[i + k] = int(round((sv * sa + dv * da * (1 - sa)) / oa))
        p[i + 3] = int(round(oa * 255))

    def save(self, path):
        return write_png(path, self.w, self.h, self.p)


def clamp(v, a, b):
    return a if v < a else (b if v > b else v)


def lerp(a, b, t):
    return a + (b - a) * t


def aa_step(edge, x):
    """一维覆盖率：edge 是边界像素坐标，x 是像素中心 (x+0.5)。返回 0..1。"""
    return clamp(edge - (x + 0.5) + 0.5, 0.0, 1.0)


# --------------------------------------------------------------- 星空背景
def make_bg(w=900, h=480):
    im = Img(w, h)
    rnd = R(20261018)
    # 预生成星点，避免逐像素遍历时反复取随机
    stars = []
    for _ in range(int(w * h / 1900)):
        stars.append((rnd.f() * w, rnd.f() * h,
                      rnd.f() ** 2.2,          # 亮度分布：暗星多亮星少
                      rnd.i(0, 1)))            # 1 = 带一点色偏
    for y in range(h):
        ty = y / (h - 1)
        # 三段渐变：顶 #0a0e1a -> 中 #16203a -> 底 #0d1526
        if ty < 0.5:
            t = ty / 0.5
            br, bg, bb = lerp(10, 22, t), lerp(14, 32, t), lerp(26, 58, t)
        else:
            t = (ty - 0.5) / 0.5
            br, bg, bb = lerp(22, 13, t), lerp(32, 21, t), lerp(58, 38, t)
        # 银河带：一条斜向的软亮带
        for x in range(w):
            d = abs((x / w) - (0.15 + ty * 0.55))
            milky = math.exp(-(d * d) / 0.0030) * 17
            im.p[(y * w + x) * 4:(y * w + x) * 4 + 4] = bytes((
                int(br + milky * 0.9), int(bg + milky * 0.8), int(bb + milky), 255))
    # 星星（带 4 邻域柔化当辉光）
    for sx, sy, mag, warm in stars:
        v = int(60 + mag * 195)
        col = (v, v - int(mag * 12), v - int(mag * 30)) if warm else (v, v, v)
        r = 0 if mag > 0.82 else 1
        if r == 1:
            for dx in (-1, 0, 1):
                for dy in (-1, 0, 1):
                    d = math.hypot(dx, dy)
                    if 0.1 < d <= 1.2:
                        k = 0.22 * (1 - d / 1.2)
                        im.over(int(sx) + dx, int(sy) + dy, *col, v * k)
        im.over(int(sx), int(sy), *col, v)
        im.over(int(sx), int(sy), 255, 255, 255, int(v * (0.35 + mag * 0.5)))
    # 底部 alpha 渐降：让窗口底色透上来，画面不死板
    for y in range(h):
        if y < h - int(h * 0.27):
            continue
        t = (y - (h - int(h * 0.27))) / (h * 0.27)
        a = int(255 - t * 105)
        row = y * w * 4
        for x in range(w):
            im.p[row + x * 4 + 3] = a
    n = im.save('_d_bg.png')
    print(f'_d_bg.png  {w}x{h}  {n} 字节  {len(stars)} 星 + 银河带 + 底部 alpha 渐降')


# --------------------------------------------------------------- 横条能量槽
def make_slot(w=264, h=12):
    """包在流动条外面的静态框：凹槽 + 上下缘光。
    流动条本身是半透明的斜纹，两侧要有东西才看得出它在一条槽里跑。"""
    im = Img(w, h)
    rad = 5
    for y in range(h):
        for x in range(w):
            cov = rr_cov(0, 0, w, h, rad, x, y)
            if cov <= 0:
                continue
            t = y / (h - 1)
            im.set(x, y, 6, 14, 26, int(200 * cov))
            ring = cov - rr_cov(1.0, 1.0, w - 2, h - 2, rad - 1, x, y)
            if ring > 0.01:
                im.over(x, y, 70, 130, 180, int(120 * ring))
    for x in range(1, w - 1):
        im.over(x, 0, 90, 160, 210, 70)
    n = im.save('_d_slot.png')
    print(f'_d_slot.png  {w}x{h}  {n} 字节  凹槽外框')


# --------------------------------------------------------------- 径向辉光
def make_glow(size=220):
    im = Img(size, size)
    cx = cy = (size - 1) / 2.0
    R0 = size * 0.52
    for y in range(size):
        for x in range(size):
            d = math.hypot(x - cx, y - cy)
            if d >= R0:
                continue
            t = 1.0 - d / R0
            # ★ 峰值 alpha 105 -> 70。辉光是**垫底**，不是主角：
            #   给到 251 时中心是个近乎不透明的白球，把 180x180 的能量环整个盖死；
            #   压到 105 还不够 —— 青色弧 (110,245,255) 和青色辉光几乎同色，
            #   截图里弧亮度和背景亮度挨着，看着像「弧没画」。降到 70 才拉开。
            a = t ** 2.2 * 70
            r = int(lerp(30, 150, t ** 0.6))
            g = int(lerp(120, 210, t ** 0.4))
            b = int(lerp(210, 255, t ** 0.3))
            im.set(x, y, r, g, b, a)
    n = im.save('_d_glow.png')
    print(f'_d_glow.png  {size}x{size}  {n} 字节  径向辉光（青->白，峰值 a=105）')


# --------------------------------------------------------------- 圆角面板
def rr_cov(x, y, w, h, rad, px, py):
    """圆角矩形（容器原点 x,y，尺寸 w,h，圆角半径 rad）在像素中心 (px+0.5, py+0.5) 的覆盖率 0..1。

    标准圆角矩形 SDF：q = abs(p - 中心) - (半尺寸 - r)
                      d = length(max(q,0)) + min(max(qx,qy), 0) - r
    d < 0 在内部，d > 0 在外部，正好等于到边界的距离。

    ★ 早先这函数写错了：把 x0,y0 先赋成「像素相对容器的坐标」，
      下一行又写 cx0 = x0 + rad —— 角圆心跟着像素跑而不是固定在容器角上，
      于是内区判定全不成立，_d_panel.png 和 _d_ico_*.png 的底色**一个像素都没写进去**
      （实测 (8,8) 和 (146,160) 全是 (0,0,0,0)），只剩后面的 glyph 可见。
      看预览才发现：64x64 的图标在白底上看不出底色。 """
    cx, cy = x + w / 2.0, y + h / 2.0
    qx = abs(px + 0.5 - cx) - (w / 2.0 - rad)
    qy = abs(py + 0.5 - cy) - (h / 2.0 - rad)
    d = math.hypot(max(qx, 0.0), max(qy, 0.0)) + min(max(qx, qy), 0.0) - rad
    return clamp(0.5 - d, 0.0, 1.0)


def make_panel(w=292, h=320, rad=12):
    im = Img(w, h)
    for y in range(h):
        for x in range(w):
            cov = rr_cov(0, 0, w, h, rad, x, y)
            if cov <= 0:
                continue
            # 竖向微渐变，让面板不像一块死板贴纸
            t = y / (h - 1)
            im.set(x, y, int(lerp(18, 10, t)), int(lerp(28, 18, t)),
                   int(lerp(48, 32, t)), int(168 * cov))
    # 边框：外扩半像素的环，再减掉内部
    for y in range(h):
        for x in range(w):
            c_out = rr_cov(0, 0, w, h, rad, x, y)
            c_in = rr_cov(1.0, 1.0, w - 2, h - 2, max(rad - 1, 1), x, y)
            ring = c_out - c_in
            if ring > 0.01:
                im.over(x, y, 90, 220, 255, int(96 * ring))
    n = im.save('_d_panel.png')
    print(f'_d_panel.png  {w}x{h}  {n} 字节  半透明圆角面板 a=168 + 青色边框')


# --------------------------------------------------------------- 圆形徽章
def make_head(size=128):
    im = Img(size, size)
    c = (size - 1) / 2.0
    for y in range(size):
        for x in range(size):
            d = math.hypot(x - c, y - c)
            if d > c:
                continue
            cov = clamp(c - d + 0.5, 0, 1)
            # 外环金
            if d > size * 0.435:
                t = (d - size * 0.435) / (size * 0.065)
                im.over(x, y, int(lerp(210, 255, t)), int(lerp(150, 205, t)), 60, int(cov * 255))
                continue
            if d > size * 0.415:          # 内侧暗描边
                im.over(x, y, 40, 30, 10, int(cov * 200))
                continue
            # 内盘：斜向渐变深蓝
            t = ((x - c) + (y - c)) / (size * 1.2) + 0.5
            im.over(x, y, int(lerp(16, 30, t)), int(lerp(32, 58, t)),
                    int(lerp(58, 92, t)), int(cov * 255))
    # 中心符号：一枚五角星（金）
    pts = []
    for k in range(10):
        ang = -math.pi / 2 + k * math.pi / 5
        rad = size * 0.30 if k % 2 == 0 else size * 0.125
        pts.append((c + math.cos(ang) * rad, c + math.sin(ang) * rad))
    for y in range(size):
        for x in range(size):
            px, py = x + 0.5, y + 0.5
            best = 1e9
            for k in range(10):
                ax, ay = pts[k]
                bx, by = pts[(k + 1) % 10]
                vx, vy = bx - ax, by - ay
                L2 = vx * vx + vy * vy
                t = 0.0 if L2 == 0 else clamp(((px - ax) * vx + (py - ay) * vy) / L2, 0, 1)
                dx, dy = px - (ax + t * vx), py - (ay + t * vy)
                best = min(best, dx * dx + dy * dy)
            dist = math.sqrt(best)
            a = clamp((size * 0.012) - dist + 0.5, 0, 1)
            if a > 0:
                im.over(x, y, 255, 214, 92, int(a * 255))
    n = im.save('_d_head.png')
    print(f'_d_head.png  {size}x{size}  {n} 字节  金环徽章 + 五角星')


# --------------------------------------------------------------- 旋转能量环
def make_core(frames=12, size=180):
    c = (size - 1) / 2.0
    for f in range(1, frames + 1):
        im = Img(size, size)
        ph = f / frames * 2 * math.pi
        # 核心：亮核 + 一圈很淡的等离子晕。
        # 半径全部按「**最外层不得超过 c + 安全边距**」排：c = (size-1)/2 = 89.5。
        # 早先弧半径给到 0.56*180 = 100.8、刻度到 0.62*180 = 111.6，全在画布外，
        # 出来是一堆贴着边被切掉的弧。现在最外刻度 0.487*180 = 87.7 < 89.5，全部画得下。
        # 亮核只占中间 0.12 —— 早先给到 0.30，半个盘面糊成一坨，环就没了。
        for y in range(size):
            for x in range(size):
                d = math.hypot(x - c, y - c)
                if d >= size * 0.30:
                    continue
                t = 1.0 - d / (size * 0.30)
                if d < size * 0.12:                       # 亮核
                    u = 1.0 - d / (size * 0.12)
                    im.over(x, y, int(lerp(150, 255, u)), int(lerp(225, 252, u)),
                            int(lerp(255, 235, u)), int((u ** 1.4) * 250))
                else:                                     # 淡晕
                    im.over(x, y, 90, 210, 255, int((t ** 2.6) * 70))
        # 三圈能量弧：半径 / 起止角 / 粗细 / 颜色 各不相同，帧号整体旋转。
        # ★ 中间那圈改成**暖橙**而不是浅蓝 —— 和青色辉光同一个色系时，
        #   弧和背景亮度挨着，截图里看着像「弧没画」。冷暖拉开才读得出是三道独立的弧。
        # ★★ span 必须是**弧度**，不是度！这里踩过坑：
        #   早先写的是 160 / 120 / 80（度），而下面 dd 是 atan2 出来的弧度，范围只有 ±π。
        #   于是 `if dd > span` 恒为假（角度门形同虚设，弧画满 360°），
        #   `dd < span*0.35` 恒为真（56 比 3.14 大得多），
        #   fade 退化成 dd/56，峰值 3.14/56 = 5.6% —— alpha 峰值只有 14/255。
        #   **在白底的图片预览上这条弧看着清清楚楚**（alpha 14 的青色叠白底 ≈ 接近白，
        #   和背景几乎同色），一贴到深色星空上就彻底隐形，排查时差点当成渲染 bug。
        #   半透明素材必须在真实底色上看，白底预览不可信。
        arcs = [
            (size * 0.335, 0.00, 5.0, math.radians(160), (120, 250, 255)),
            (size * 0.405, -1.1, 3.6, math.radians(120), (255, 186, 96)),
            (size * 0.455, -0.6, 2.4, math.radians(80), (255, 255, 255)),
        ]
        for rad, a0, th, span, col in arcs:
            x0 = int(c - rad - th - 2)
            x1 = int(c + rad + th + 2)
            y0 = int(c - rad - th - 2)
            y1 = int(c + rad + th + 2)
            for y in range(y0, y1 + 1):
                for x in range(x0, x1 + 1):
                    dx, dy = x + 0.5 - c, y + 0.5 - c
                    d = math.hypot(dx, dy)
                    band = clamp(th - abs(d - rad) + 0.5, 0, 1)
                    if band <= 0:
                        continue
                    ang = math.atan2(dy, dx)
                    # 角差归一到 (-pi, pi]
                    dd = (ang - (ph + a0) + math.pi) % (2 * math.pi) - math.pi
                    if dd > span or dd < 0:
                        continue
                    # 弧首尾渐隐
                    fade = min(1.0, (span - dd) / (span * 0.35) if dd > span * 0.65 else
                               dd / (span * 0.35) if dd < span * 0.35 else 1.0)
                    im.over(x, y, *col, int(255 * band * clamp(fade, 0, 1)))
        # 外圈刻度：每 6 度一小格，偶数格亮
        for k in range(60):
            ang = ph * 0.5 + k / 60 * 2 * math.pi
            r0, r1 = size * 0.468, size * 0.487
            lit = (k % 5 == (f - 1) % 5)
            col = (255, 210, 120) if lit else (70, 120, 170)
            al = 235 if lit else 95
            for s in range(0, 26):
                rr = lerp(r0, r1, s / 25)
                im.over(int(c + math.cos(ang) * rr), int(c + math.sin(ang) * rr),
                        *col, al)
        # 沿圆周跑的 4 颗能量珠（相位不同，帧间转位）
        for k in range(4):
            ang = ph * 1.4 + k * math.pi / 2
            rad = size * 0.405
            bx, by = c + math.cos(ang) * rad, c + math.sin(ang) * rad
            for dy in range(-2, 3):
                for dx in range(-2, 3):
                    d = math.hypot(dx, dy)
                    a = clamp(2.6 - d, 0, 1) * 255
                    im.over(int(bx) + dx, int(by) + dy, 255, 255, 255, int(a))
        n = im.save(f'_d_core_{f:02d}.png')
        print(f'_d_core_{f:02d}.png  {size}x{size}  {n} 字节  旋转能量环')


# --------------------------------------------------------------- 能量流动条
def make_flow(frames=8, w=264, h=14):
    for f in range(1, frames + 1):
        im = Img(w, h)
        # 槽底：深色半透明（**不能用接近白的 RGB**——早先用了 (210,235,255,a=20)，
        # 深色底上等于什么都没有，斜纹又压不住底，出来是一条几乎透明的灰带）
        for y in range(h):
            for x in range(w):
                t = y / (h - 1)
                im.set(x, y, int(lerp(10, 4, t)), int(lerp(28, 14, t)),
                       int(lerp(46, 24, t)), int(lerp(210, 175, t)))
        # 4 道斜纹随帧平移，斜率 0.9、宽 15、间距 66 —— 斜向条纹，别规则成栅栏
        shift = f / frames * 66.0
        for k in range(4):
            bx = k * 66.0 - shift
            for y in range(h):
                base = bx - (h - 1 - y) * 0.9
                for x in range(w):
                    dd = (x - base) % 264.0
                    if dd >= 15:
                        continue
                    u = dd / 15.0
                    fade_l = min(1.0, (x + 1) / 26.0)
                    fade_r = min(1.0, (w - x) / 26.0)
                    fade = min(fade_l, fade_r)
                    a = math.sin(u * math.pi) * 250 * fade
                    im.over(x, y, int(lerp(50, 175, u)), 255,
                            int(lerp(215, 130, u)), int(a))
        # 上下高光
        for x in range(w):
            im.over(x, 0, 150, 255, 255, 90)
            im.over(x, 1, 90, 200, 220, 45)
            im.over(x, h - 1, 0, 0, 0, 110)
        n = im.save(f'_d_flow_{f:02d}.png')
        print(f'_d_flow_{f:02d}.png  {w}x{h}  {n} 字节  斜纹平移')


# --------------------------------------------------------------- 三个图标
def icon(k, size=64):
    im = Img(size, size)
    rad = 14
    for y in range(size):
        for x in range(size):
            cov = rr_cov(0, 0, size, size, rad, x, y)
            if cov <= 0:
                continue
            t = y / (size - 1)
            base = [(30, 120, 90), (140, 70, 40), (60, 90, 160)][k - 1]
            im.set(x, y, int(base[0] * lerp(0.7, 1.0, t)), int(base[1] * lerp(0.7, 1.0, t)),
                   int(base[2] * lerp(0.7, 1.0, t)), int(215 * cov))
            ring = cov - rr_cov(1.2, 1.2, size - 2.4, size - 2.4, rad - 1, x, y)
            if ring > 0.01:
                im.over(x, y, 235, 245, 255, int(120 * ring))
    c = (size - 1) / 2.0

    def glyph(px, py, a, col=(240, 250, 255)):
        if 0 <= int(px) < size and 0 <= int(py) < size:
            im.over(int(px), int(py), *col, int(a * 255))

    if k == 1:
        # 向上火箭：三角形 + 尾焰
        for y in range(12, 40):
            t = (y - 12) / 27.0
            half = t * 13
            for x in range(int(c - half), int(c + half) + 1):
                a = (min(x - (c - half) + 0.5, (c + half) - x + 0.5))
                glyph(x, y, clamp(a, 0, 1))
        for y in range(40, 52):
            t = (y - 40) / 12.0
            half = (1 - t) * 6 + 1
            for x in range(int(c - half), int(c + half) + 1):
                glyph(x, y, clamp(1 - t, 0, 1) * 0.95, (255, 150, 60))
    elif k == 2:
        # 感叹号（警戒）
        for y in range(16, 40):
            t = (y - 16) / 24.0
            half = lerp(5.0, 2.2, t)
            for x in range(int(c - half), int(c + half) + 1):
                glyph(x, y, clamp(min(x - (c - half) + 0.5, (c + half) - x + 0.5), 0, 1))
        for y in range(45, 52):
            for x in range(int(c - 3), int(c + 3)):
                glyph(x, y, clamp(3.5 - abs(x - c), 0, 1))
    else:
        # 冷却环：四分之一空缺的圆环 + 两根缺口辐条
        for y in range(size):
            for x in range(size):
                d = math.hypot(x + 0.5 - c, y + 0.5 - c)
                band = clamp(4.0 - abs(d - 17) + 0.5, 0, 1)
                if band <= 0:
                    continue
                ang = math.atan2(y + 0.5 - c, x + 0.5 - c)
                if -0.15 < ang < 0.15:          # 顶部留缺口
                    continue
                glyph(x, y, band)
    n = im.save(f'_d_ico_{k}.png')
    print(f'_d_ico_{k}.png  {size}x{size}  {n} 字节')


if __name__ == '__main__':
    make_bg()
    make_glow()
    make_slot()
    make_panel()
    make_head()
    make_core()
    make_flow()
    for k in (1, 2, 3):
        icon(k)
    print('素材齐了：1+1+1+1+12+8+3 = 27 张')
