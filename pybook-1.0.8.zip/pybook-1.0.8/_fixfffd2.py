# -*- coding: utf-8 -*-
"""_fixfffd2.py — 清掉剩下的 U+FFFD。
第一轮修完 _calc_c.py / pybook_lib.c；这里处理剩下三处：
  _mt_verify.py   「算出来??比」→「算出来对比」（2 个坏字节）
  _wire_stats.py  「最小的那个?? ——」多余的 2 个，删掉
  mathplus.c      同上（_wire_stats.py 写进去的副本）"""
import glob

BAD = b'\xef\xbf\xbd'

FIXES = [
    ('_mt_verify.py',  '算出来'.encode() + BAD * 2 + '比'.encode(),
                      '算出来对比'.encode()),
    ('_wire_stats.py', '最小的那个'.encode() + BAD * 2, '最小的那个'.encode()),
    ('mathplus.c',     '最小的那个'.encode() + BAD * 2, '最小的那个'.encode()),
]

for path, old, new in FIXES:
    raw = open(path, 'rb').read()
    n = raw.count(old)
    if n == 0:
        print('  %-16s 不用改' % path)
        continue
    raw = raw.replace(old, new)
    open(path, 'wb').write(raw)
    print('  %-16s 改了 %d 处，剩余 %d' % (path, n, raw.count(BAD)))

print('\n全仓复查 _*.py / 主要 .c：')
bad = 0
for p in sorted(glob.glob('_*.py')) + ['mathplus.c', 'pybook_lib.c', 'pybook_lib.h',
                                        'pybk_front.py', 'pybk_code.py',
                                        '_vm_lib_calls.inc', 'pybook_rt.c',
                                        'pybook_tb.c', 'pybook_la.c']:
    n = open(p, 'rb').read().count(BAD)
    if n:
        print('  ★ %-20s %d 处' % (p, n))
        bad += n
print('  干净' if bad == 0 else '  仍有 %d 处' % bad)
