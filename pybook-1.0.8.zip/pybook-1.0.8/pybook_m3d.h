/* PYbook MyMove3D（m3.*）—— MC 风格体素建模库。
 *
 * 哲学与 mm.* 对齐：列表即模型。
 *   模型 = 列表的列表：每个子列表 = 一个 Y 高度层（从下到上）
 *   层内一行字符串 = 世界 Z，一格 = 世界 X（一格一个方块）
 *   token：. / _ 空气；其余走 贴图槽 → mm 调色板
 *
 * 两层结构（同 mathplus / bs）：
 *   核心层 m3_* : 纯 C 解析/统计，零依赖
 *   绑定层 rt_m3_* : Value 互转 + 调 hw.box 画进 3D_highway
 */

#ifndef PYBOOK_M3D_H
#define PYBOOK_M3D_H

#include <stddef.h>

/* ==================== 核心层 ==================== */

#define M3_MAX 32
#define M3_TEX_SLOTS 15

typedef struct {
    int w, h, d;                       /* 宽X 高Y 深Z */
    unsigned char kind[M3_MAX][M3_MAX][M3_MAX]; /* 0空 1色 2贴图 3玻璃 4夜光 */
    unsigned char rgb[M3_MAX][M3_MAX][M3_MAX][3];
    unsigned char tex[M3_MAX][M3_MAX][M3_MAX];
    unsigned char alpha[M3_MAX][M3_MAX][M3_MAX]; /* 0..255 */
} M3Model;

/* 解析 token：返回 0 空 1 色 2 贴图 -1 未知。色/贴图出参。 */
int m3_lookup_token(const char *tok, int *r, int *g, int *b, int *texslot);

int  m3_count(const M3Model *m);
void m3_bounds(const M3Model *m, int *w, int *h, int *d);

/* ==================== 绑定层（PYbook 命名空间 m3.） ==================== */
#if (defined(PB_M3D_BINDING) || defined(MP_RT_BINDING)) && !defined(PYBOOK_RT_H)
#include "pybook_rt.h"
#endif
#if defined(PYBOOK_RT_H) || defined(PB_M3D_BINDING) || defined(MP_RT_BINDING)

Value rt_m3_color(Value tok, Value r, Value g, Value b);
Value rt_m3_texture(Value tok, Value path);
Value rt_m3_glass(Value tok, Value r, Value g, Value b, Value a);
Value rt_m3_glow(Value tok, Value r, Value g, Value b);
Value rt_m3_metal(Value tok, Value r, Value g, Value b);
Value rt_m3_style(Value tok, Value pattern, Value r, Value g, Value b);
Value rt_m3_pack(Value dir);
Value rt_m3_uv(Value n);
Value rt_m3_draw(Value model, Value x, Value y, Value z, Value scale);
Value rt_m3_drawr(Value model, Value x, Value y, Value z, Value scale,
                  Value rx, Value ry, Value rz);
Value rt_m3_anim(Value frames, Value x, Value y, Value z, Value scale, Value fps);
Value rt_m3_animr(Value frames, Value x, Value y, Value z, Value scale, Value fps,
                  Value rx, Value ry, Value rz);
Value rt_m3_save(Value model, Value file);
Value rt_m3_load(Value file);
Value rt_m3_merge(Value a, Value b, Value dx, Value dy, Value dz);
Value rt_m3_dig(Value model, Value x, Value y, Value z);
Value rt_m3_put(Value model, Value x, Value y, Value z, Value tok);
Value rt_m3_bounds(Value model);
Value rt_m3_count(Value model);
/* 建筑样式生成器（返回模型） */
Value rt_m3_stair(Value w, Value steps, Value tok);
Value rt_m3_slab(Value w, Value d, Value tok);
Value rt_m3_wall(Value w, Value h, Value d, Value tok);
Value rt_m3_pillar(Value h, Value tok);
Value rt_m3_roof(Value w, Value d, Value tok);
Value rt_m3_fence(Value n, Value tok);

#endif
#endif /* PYBOOK_M3D_H */
