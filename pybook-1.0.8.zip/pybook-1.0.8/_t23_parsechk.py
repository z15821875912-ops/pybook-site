# -*- coding: utf-8 -*-
"""_t23_parsechk.py —— 只调前端解析器验证 T23 用例语法，不碰 pyvm.exe。

为什么单独写：此刻 pyvm.exe 正被另一条线占用（19:50 还在被 out_*.c 刷屏），
重建它就是当初那次事故的成因。可前端解析器是纯 Python、不依赖那个二进制，
所以至少能在不制造冲突的前提下把语法风险先排掉。

注意：解析通过 != 行为正确。它只证明「这段 PYbook 语法合法、标识符合法」。
真正验数值还得等 pyvm.exe 空出来再跑端到端。
"""
import io
import sys
import traceback

PATH = "tests/T23_cpu_dot_nmod4_ok.pybk"

try:
    import pybk_front
except Exception:
    traceback.print_exc()
    sys.exit("import pybk_front 失败")

with io.open(PATH, "r", encoding="utf-8") as f:
    src = f.read()

try:
    prog = pybk_front.parse(src)
except Exception:
    traceback.print_exc()
    sys.exit("前端解析失败 —— 语法有问题，别并进 cases.py")

print("前端解析通过")
print("  文件：%s（%d 行）" % (PATH, src.count("\n")))
# 确认它真的读到了内容，而不是「解析了个空程序也算过」
print("  Program 属性：%s" % ", ".join(sorted(k for k in vars(prog).keys())))

# ── 反向自检：故意改坏，解析器必须拒绝 ──────────────────────────────
# 没有这一步，上面的「通过」就可能只是个永远绿的空壳检查。
# 变异只取**这份用例真正依赖的语法规则**，不是随便找几条：
#   - }STOP 必须与 } 同行            （本用例结尾就靠它）
#   - 函数体必须有闭合 }              （造() 靠它）
#   - rm.around(n) -> x 的箭头形式   （造() 和全部探针都靠它）
# 注：$ 插值里塞算术表达式**故意不测** —— 解析器放行是设计而非缺陷
#     （见 tests/cases.py 的 T06_interp_paren_text：$ 只取标识符，余下当文本）。
MUTANTS = [
    ("}STOP 拆成两行（违反同行约束）", lambda s: s.replace("}STOP\n", "}\nSTOP\n")),
    ("闭括号写成 )STOP", lambda s: s.replace("}STOP\n", ")STOP\n")),
    ("删掉 func 的闭合 }", lambda s: s.replace("list.添加(外, 内)\n}\nret 外\n",
                                             "list.添加(外, 内)\nret 外\n", 1)),
    ("破坏 rm.around 的箭头形式", lambda s: s.replace("rm.around(行数) -> i {",
                                                     "rm.around(行数) i {", 1)),
]
print("\n反向自检（故意改坏，解析器必须拒绝）：")
all_rejected = True
for name, mut in MUTANTS:
    bad = mut(src)
    if bad == src:
        print("  ★变异『%s』没改成，变异本身失效，这个自检等于没跑★" % name)
        all_rejected = False
        continue
    try:
        pybk_front.parse(bad)
        print("  ★★ %s：解析器竟然放过了 —— 这条规则没有牙★★" % name)
        all_rejected = False
    except Exception:
        print("  %s：已按预期拒绝 ✓" % name)

if not all_rejected:
    sys.exit("反向自检没全过 —— 上面的『解析通过』不可信，先查清再并入 cases.py")
print("\n反向自检全过：解析器确实在按这几条规则干活，不是空壳检查。")
