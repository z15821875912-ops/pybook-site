/* _jitprobe.c — 用 CUDA 驱动 API 直接 JIT 一段最小合法 PTX，判断是环境还是我们的 PTX。
 * 不依赖 PYbook 任何东西。编译：gcc _jitprobe.c -o _jitprobe.exe -lkernel32 */
#include <windows.h>
#include <stdio.h>
#include <string.h>

typedef int (*fn_cuInit)(unsigned);
typedef int (*fn_cuDeviceGet)(int *, int);
typedef int (*fn_cuCtxCreate)(void **, unsigned, int);
typedef int (*fn_cuModuleLoadData)(void **, const void *);
typedef int (*fn_cuModuleGetFunction)(void **, void *, const char *);
typedef int (*fn_cuGetErrorString)(int, const char **);

static const char *PTX_MIN =
    ".version 6.0\n"
    ".target sm_61\n"
    ".address_size 64\n"
    ".visible .entry k()\n"
    "{\n"
    "    ret;\n"
    "}\n";

int main(void)
{
    HMODULE d = LoadLibraryA("nvcuda.dll");
    fn_cuInit cuInit; fn_cuDeviceGet cuDeviceGet; fn_cuCtxCreate cuCtxCreate;
    fn_cuModuleLoadData cuModuleLoadData; fn_cuModuleGetFunction cuModuleGetFunction;
    fn_cuGetErrorString cuGetErrorString;
    int rc, dev = 0, ord = 0;
    void *ctx = NULL, *mod = NULL, *fn = NULL;
    const char *es = NULL;

    if (!d) { printf("FAIL: LoadLibrary nvcuda.dll\n"); return 2; }
    cuInit = (fn_cuInit)GetProcAddress(d, "cuInit");
    cuDeviceGet = (fn_cuDeviceGet)GetProcAddress(d, "cuDeviceGet");
    cuCtxCreate = (fn_cuCtxCreate)GetProcAddress(d, "cuCtxCreate_v2");
    cuModuleLoadData = (fn_cuModuleLoadData)GetProcAddress(d, "cuModuleLoadData");
    cuModuleGetFunction = (fn_cuModuleGetFunction)GetProcAddress(d, "cuModuleGetFunction");
    cuGetErrorString = (fn_cuGetErrorString)GetProcAddress(d, "cuGetErrorString");
    if (!cuInit || !cuDeviceGet || !cuCtxCreate || !cuModuleLoadData || !cuModuleGetFunction) {
        printf("FAIL: GetProcAddress 缺符号\n"); return 2;
    }
    if ((rc = cuInit(0)) != 0) { printf("FAIL: cuInit=%d\n", rc); return 2; }
    if ((rc = cuDeviceGet(&dev, 0)) != 0 || dev < 0) { printf("FAIL: cuDeviceGet=%d\n", rc); return 2; }
    printf("cuInit OK, device=%d\n", dev);
    if ((rc = cuCtxCreate(&ctx, 0, dev)) != 0) { printf("FAIL: cuCtxCreate=%d\n", rc); return 2; }
    printf("ctx OK\n");

    rc = cuModuleLoadData(&mod, PTX_MIN);
    if (rc == 0) {
        printf("JIT 最小 PTX: OK\n");
        rc = cuModuleGetFunction(&fn, mod, "k");
        printf("取函数 k: %s\n", rc == 0 ? "OK" : "FAIL");
    } else {
        printf("JIT 最小 PTX: FAIL rc=%d", rc);
        if (cuGetErrorString) { cuGetErrorString(rc, &es); if (es) printf(" (%s)", es); }
        printf("\n");
        printf(">>> 连最小合法 PTX 都编不过 => 是驱动/环境状态，不是本项目的 PTX\n");
        return 1;
    }
    printf(">>> 最小 PTX 能 JIT => 驱动正常，问题在本项目的 PTX 内容\n");
    return 0;
}
