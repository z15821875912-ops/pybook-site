# -*- coding: utf-8 -*-
"""在若干 x 采样点上扫 y，找出横线笔画所在的行。
用法: python -B _hscan.py <bmp> x1 x2 x3 ... --y0:A --y1:B
"""
import sys, struct


def load(path):
    d = open(path, 'rb').read()
    off = struct.unpack_from('<I', d, 10)[0]
    w, h = struct.unpack_from('<ii', d, 18)
    flip = h > 0                       # 自底向上：raw 行号要倒过来才是显示坐标
    h = abs(h)
    bpp = struct.unpack_from('<H', d, 28)[0] // 8
    stride = ((w * bpp + 3) // 4) * 4
    return w, h, bpp, stride, off, d, flip


def px(d, stride, off, h, flip, x, y):
    row = (h - 1 - y) if flip else y
    i = off + row * stride + x * 3
    return (d[i + 2], d[i + 1], d[i])


def main():
    p = sys.argv[1]
    xs = []
    y0, y1 = 0, 10 ** 9
    rest = sys.argv[2:]
    i = 0
    while i < len(rest):
        a = rest[i]
        if a.startswith('--y'):
            t = a[len('--y'):]
            if t.startswith('y'):
                t = t[1:]
            y0, y1 = (int(v) for v in t.split(':'))
        else:
            xs.append(int(a))
        i += 1
    w, h, bpp, stride, off, d, flip = load(p)
    bg = px(d, stride, off, h, flip, 0, h - 1)
    print(f'{p} {w}x{h} {bpp * 8}bpp {"已翻转" if flip else "正向"}  bg={bg[0]:02X}{bg[1]:02X}{bg[2]:02X}')
    for y in range(y0, min(y1, h)):
        hits = []
        for x in xs:
            c = px(d, stride, off, h, flip, x, y)
            if abs(c[0] - bg[0]) + abs(c[1] - bg[1]) + abs(c[2] - bg[2]) > 24:
                hits.append((x, c))
        if hits:
            s = ' '.join(f'{x}:{c[0]:02X}{c[1]:02X}{c[2]:02X}' for x, c in hits[:6])
            print(f'  y={y:4d}  n={len(hits):3d}  {s}')


main()
