/* PYbook MyMove（twoM）库：列表即像素画。
 * 一行字符串 = 一排像素；一个词 = 一个像素的颜色；`.` 或 `_` = 透明。
 * mm.色(token, r, g, b)            注册/覆盖颜色 token
 * mm.draw_away(表, "名.png", 倍数)  把列表渲染落成 PNG（倍数：1 格 = N×N 真像素）
 * mm.贴(表, x, y, 倍数)             窗口模式即时贴（实现见 pybook_rt.c 的 rt_mm_blt）
 * PNG 落盘：手写编码器（zlib store 块 + CRC32/Adler32），零依赖离线。 */

#include "pybook_lib.h"

#ifdef _WIN32
#  define WIN32_LEAN_AND_MEAN
#  include <windows.h>       /* 中文路径：UTF-8 -> 宽字符 _wfopen */
#endif
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static void mm_die(const char *fmt, ...)
{
    va_list ap;
    fprintf(stderr, "运行时错误: mm.");
    va_start(ap, fmt);
    vfprintf(stderr, fmt, ap);
    va_end(ap);
    fputc('\n', stderr);
    exit(1);
}

/* ---- 调色板 ---- */

typedef struct { const char *tok; unsigned char r, g, b; } MmBuiltin;

static const MmBuiltin mm_builtin[] = {
    {"b1", 137, 207, 240}, {"b2", 66, 133, 244}, {"b3", 26, 61, 158},
    {"r1", 255, 154, 154}, {"r2", 229, 57, 53},  {"r3", 155, 22, 22},
    {"g1", 129, 199, 132}, {"g2", 67, 160, 71},  {"g3", 27, 94, 32},
    {"y1", 255, 235, 59},  {"y2", 198, 148, 0},
    {"o1", 255, 167, 38},  {"o2", 230, 81, 0},
    {"p1", 206, 147, 216}, {"p2", 123, 31, 162},
    {"w1", 250, 250, 250}, {"w2", 158, 158, 158},
    {"k1", 20, 20, 20},
    {"f1", 255, 204, 170},
    /* 单字符简谱（连写模式用）：中调 */
    {"b", 66, 133, 244}, {"r", 229, 57, 53},  {"g", 67, 160, 71},
    {"y", 255, 235, 59},  {"o", 255, 167, 38}, {"p", 123, 31, 162},
    {"w", 250, 250, 250}, {"k", 20, 20, 20},   {"f", 255, 204, 170},
};

typedef struct { char tok[16]; unsigned char r, g, b; } MmCustom;

static MmCustom mm_custom[256];
static int mm_ncustom = 0;

/* ============ 网格层：token 列表 ↔ token 二维网格 ============
 * 原来「连写 vs token 模式」的分词逻辑内联在 rt_mm_raster 一个人身上，
 * 这里抽成网格层给 转/描边/平铺/拼/存读 共用：判定口径只改一处。
 *
 * 关键细节一：短行右侧是「没有格子」(NULL)，不是空气。
 * 如果用空气补齐，存/读 往返会把 ["gg","ggg"] 变成 ["gg.","ggg"]，
 * 图像被透明格撑宽。emit 时按每行自然长度还原，往返才是无损的。
 *
 * 关键细节二：token_mode 必须一路带到底。
 * 新建的网格如果忘了继承，连写模式会把 "b1 b2" 拆成一串单字符，
 * 多字符 token 当场报废——所以 mm_grid_new/copy 的调用点都要显式继承。 */

typedef struct {
    char  **cells;        /* 行优先，长度 rows*w；NULL = 该行此处没有格子 */
    size_t  rows;
    size_t  w;            /* 最宽行的格数 */
    int     token_mode;   /* 原列表含空格 -> 一词一格 */
} MmGrid;

static char *mm_sdup(const char *s, size_t n)
{
    char *p = (char *)malloc(n + 1);
    if (!p)
        mm_die("内存不足");
    memcpy(p, s, n);
    p[n] = '\0';
    return p;
}

static void mm_grid_free(MmGrid *g)
{
    if (!g || !g->cells)
        return;
    for (size_t i = 0; i < g->rows * g->w; i++)
        free(g->cells[i]);          /* free(NULL) 合法 */
    free(g->cells);
    g->cells = NULL;
    g->rows = g->w = 0;
}

static MmGrid mm_grid_new(size_t rows, size_t w, int token_mode)
{
    MmGrid g;
    memset(&g, 0, sizeof g);
    g.rows = rows;
    g.w = w;
    g.token_mode = token_mode;
    if (rows && w) {
        g.cells = (char **)calloc(rows * w, sizeof(char *));
        if (!g.cells)
            mm_die("内存不足");
    }
    return g;
}

/* 取格：越界或空 = 没有格子 */
static const char *mm_at(const MmGrid *g, size_t r, size_t c)
{
    if (r >= g->rows || c >= g->w)
        return NULL;
    return g->cells[r * g->w + c];
}

/* 该格是不是「画了东西」（. 和 _ 是透明，算没画） */
static int mm_opaque(const MmGrid *g, size_t r, size_t c)
{
    const char *tk = mm_at(g, r, c);
    if (!tk || !tk[0])
        return 0;
    return strcmp(tk, ".") != 0 && strcmp(tk, "_") != 0;
}

static void mm_set(MmGrid *g, size_t r, size_t c, const char *tk)
{
    if (r >= g->rows || c >= g->w)
        return;
    char **slot = &g->cells[r * g->w + c];
    free(*slot);
    *slot = tk ? mm_sdup(tk, strlen(tk)) : NULL;
}

/* 列表 -> 网格。who 只进报错文案（"存"/"转"/…）。 */
static MmGrid mm_grid_parse(Value rows, const char *who)
{
    MmGrid g;
    memset(&g, 0, sizeof g);
    if (!IS_LIST(rows) || AS_LIST(rows) == NULL)
        mm_die("%s 需要列表（一行字符串一排像素）", who);
    RtList *L = AS_LIST(rows);
    if (L->len == 0 || L->len > 4096)
        mm_die("列表行数须为 1..4096");

    for (size_t i = 0; i < L->len; i++)
        if (strchr(rt_str_of(L->items[i]), ' ')) {
            g.token_mode = 1;
            break;
        }

    g.rows = L->len;
    for (size_t i = 0; i < g.rows; i++) {
        const char *row = rt_str_of(L->items[i]);
        size_t cnt = 0, j = 0;
        if (g.token_mode) {
            while (row[j]) {
                while (row[j] == ' ') j++;
                if (!row[j]) break;
                cnt++;
                while (row[j] && row[j] != ' ') j++;
            }
        } else {
            cnt = strlen(row);
        }
        if (cnt > g.w) g.w = cnt;
    }
    if (g.w == 0)
        mm_die("列表里没有任何像素（一行至少要一个 token，如 \"b1\"）");

    g.cells = (char **)calloc(g.rows * g.w, sizeof(char *));
    if (!g.cells)
        mm_die("内存不足");
    for (size_t i = 0; i < g.rows; i++) {
        const char *row = rt_str_of(L->items[i]);
        size_t col = 0, j = 0;
        if (!g.token_mode) {
            for (; row[j] && col < g.w; j++, col++)
                g.cells[i * g.w + col] = mm_sdup(row + j, 1);
        } else {
            while (row[j] && col < g.w) {
                while (row[j] == ' ') j++;
                if (!row[j]) break;
                size_t st = j;
                while (row[j] && row[j] != ' ') j++;
                g.cells[i * g.w + col] = mm_sdup(row + st, j - st);
                col++;
            }
        }
    }
    return g;
}

/* 网格 -> 列表（按原模式还原成字符串行） */
static Value mm_grid_emit(const MmGrid *g)
{
    Value out = rt_list_new();
    for (size_t i = 0; i < g->rows; i++) {
        size_t last = 0;
        for (size_t c = 0; c < g->w; c++)
            if (g->cells[i * g->w + c])
                last = c + 1;                    /* 丢掉右侧的「没有格子」 */
        if (last == 0) {
            rt_push(&out, rt_str(""));
            continue;
        }
        size_t need = 1;
        for (size_t c = 0; c < last; c++)
            need += strlen(g->cells[i * g->w + c]) + (g->token_mode ? 1 : 0);
        char *buf = (char *)malloc(need);
        if (!buf)
            mm_die("内存不足");
        size_t p = 0;
        for (size_t c = 0; c < last; c++) {
            const char *tk = g->cells[i * g->w + c];
            size_t l = strlen(tk);
            memcpy(buf + p, tk, l);
            p += l;
            if (g->token_mode && c + 1 < last)
                buf[p++] = ' ';
        }
        buf[p] = '\0';
        rt_push(&out, rt_str(buf));
        free(buf);
    }
    return out;
}

/* 整体搬一份网格（描边/渐变/反色的底子） */
static MmGrid mm_grid_copy(const MmGrid *g)
{
    MmGrid o = mm_grid_new(g->rows, g->w, g->token_mode);
    for (size_t r = 0; r < g->rows; r++)
        for (size_t c = 0; c < g->w; c++)
            if (g->cells[r * g->w + c])
                mm_set(&o, r, c, g->cells[r * g->w + c]);
    return o;
}

/* 注册/覆盖一个调色板条目；返回 0 成功，-1 表示 256 格已满 */
static int mm_palette_set(const char *tok, int r, int g, int b)
{
    MmCustom *slot = NULL;
    for (int i = 0; i < mm_ncustom; i++)
        if (strcmp(mm_custom[i].tok, tok) == 0) {
            slot = &mm_custom[i];
            break;
        }
    if (!slot) {
        if (mm_ncustom >= 256)
            return -1;
        slot = &mm_custom[mm_ncustom++];
        memset(slot->tok, 0, sizeof slot->tok);
        strncpy(slot->tok, tok, 15);
    }
    slot->r = (unsigned char)r;
    slot->g = (unsigned char)g;
    slot->b = (unsigned char)b;
    return 0;
}

/* 文件头的色标：源文件是 UTF-8，所以「色」在内存里就是这三个字节 */
static const char MM_CE[] = "色";

/* UTF-8 路径开文件（中文路径在 Windows 上要转宽字符） */
static FILE *mm_fopen(const char *name, const char *mode)
{
    FILE *fp = NULL;
#ifdef _WIN32
    wchar_t wname[1024];
    if (MultiByteToWideChar(CP_UTF8, 0, name, -1, wname, 1024) > 0)
        fp = _wfopen(wname, mode[0] == 'w' ? L"wb" : L"rb");
#endif
    if (!fp)
        fp = fopen(name, mode);
    return fp;
}

/* 返回 1=不透明（rgb 出参），0=透明，-1=未知 token */
int rt_mm_lookup(Value tokv, int *r, int *g, int *b)
{
    const char *t = rt_str_of(tokv);
    if (!strcmp(t, ".") || !strcmp(t, "_"))
        return 0;
    for (int i = 0; i < mm_ncustom; i++)
        if (strcmp(mm_custom[i].tok, t) == 0) {
            *r = mm_custom[i].r; *g = mm_custom[i].g; *b = mm_custom[i].b;
            return 1;
        }
    for (size_t i = 0; i < sizeof mm_builtin / sizeof mm_builtin[0]; i++)
        if (strcmp(mm_builtin[i].tok, t) == 0) {
            *r = mm_builtin[i].r; *g = mm_builtin[i].g; *b = mm_builtin[i].b;
            return 1;
        }
    return -1;
}

Value rt_mm_color(Value tok, Value rv, Value gv, Value bv)
{
    const char *t = rt_str_of(tok);
    if (!*t || strlen(t) >= 16)
        mm_die("色：token 长度须为 1..15");
    if (!strcmp(t, ".") || !strcmp(t, "_"))
        mm_die("色：. 和 _ 是保留的透明标记");
    long long r = rt_to_ll(rv), g = rt_to_ll(gv), b = rt_to_ll(bv);
    if (r < 0 || r > 255 || g < 0 || g > 255 || b < 0 || b > 255)
        mm_die("色：RGB 须在 0..255");
    if (mm_palette_set(t, (int)r, (int)g, (int)b) != 0)
        mm_die("色：自定义颜色已满（256 个）");
    return rt_none();
}

/* ---- 列表 → 像素缓冲 ----
 * 返回 malloc 的 RGBA 缓冲（项目约定分配不回收）；W / H 出尺寸。 */

unsigned char *rt_mm_raster(Value rows, long long scale, size_t *W, size_t *H)
{
    /* 校验顺序与原来一致（列表 -> 行数 -> 倍数 -> 有没有像素），别让老脚本
     * 撞出不同报错。三段前两条与 mm_grid_parse 重复，但幂等且只为保顺序。 */
    if (!IS_LIST(rows) || AS_LIST(rows) == NULL)
        mm_die("draw_away/贴 需要列表（一行字符串一排像素）");
    if (AS_LIST(rows)->len == 0 || AS_LIST(rows)->len > 4096)
        mm_die("列表行数须为 1..4096");
    if (scale < 1 || scale > 64)
        mm_die("倍数须为 1..64");

    MmGrid g = mm_grid_parse(rows, "draw_away/贴");

    size_t Wp = g.w * (size_t)scale, Hp = g.rows * (size_t)scale;
    unsigned char *px = (unsigned char *)calloc(Wp * Hp, 4);   /* 默认全透明 */
    if (!px) {
        mm_grid_free(&g);
        mm_die("draw_away 内存不足");
    }

    for (size_t i = 0; i < g.rows; i++)
        for (size_t j2 = 0; j2 < g.w; j2++) {
            const char *cell = g.cells[i * g.w + j2];
            if (!cell)
                continue;                    /* 短行右侧：没有格子 = 透明 */
            Value tv = rt_str(cell);
            int r, gg, b2;
            int kind = rt_mm_lookup(tv, &r, &gg, &b2);
            if (kind < 0) {
                if (g.token_mode)
                    mm_die("draw_away：第 %zu 行第 %zu 格的 token '%s' 不认识"
                           "（mm.色 可自定义；. 或 _ 是透明）",
                           i + 1, j2 + 1, cell);
                else
                    mm_die("draw_away：第 %zu 行第 %zu 格的字符 %s 不认识"
                           "（. 或 _ 是透明；mm.色 可自定义）",
                           i + 1, j2 + 1, cell);
            }
            if (kind != 1)
                continue;                    /* 透明格不用写，calloc 已经清了 */
            for (long long dy = 0; dy < scale; dy++)
                for (long long dx = 0; dx < scale; dx++) {
                    size_t x = j2 * (size_t)scale + (size_t)dx;
                    size_t y = i * (size_t)scale + (size_t)dy;
                    unsigned char *pxl = px + (y * Wp + x) * 4;
                    pxl[0] = (unsigned char)r;
                    pxl[1] = (unsigned char)gg;
                    pxl[2] = (unsigned char)b2;
                    pxl[3] = 255;
                }
        }
    mm_grid_free(&g);
    *W = Wp;
    *H = Hp;
    return px;
}

/* ---- PNG 编码器（store 模式，零依赖） ---- */

static unsigned long mm_crc_table[256];
static int mm_crc_made = 0;

static void mm_crc_init(void)
{
    for (unsigned long n = 0; n < 256; n++) {
        unsigned long c = n;
        for (int k = 0; k < 8; k++)
            c = (c & 1) ? 0xEDB88320UL ^ (c >> 1) : c >> 1;
        mm_crc_table[n] = c;
    }
    mm_crc_made = 1;
}

static unsigned long mm_crc(unsigned long crc, const unsigned char *buf, size_t n)
{
    if (!mm_crc_made)
        mm_crc_init();
    for (size_t i = 0; i < n; i++)
        crc = mm_crc_table[(crc ^ buf[i]) & 0xFF] ^ (crc >> 8);
    return crc;
}

static void mm_w32(FILE *fp, unsigned long v)     /* 大端 4 字节 */
{
    fputc((int)((v >> 24) & 0xFF), fp);
    fputc((int)((v >> 16) & 0xFF), fp);
    fputc((int)((v >> 8) & 0xFF), fp);
    fputc((int)(v & 0xFF), fp);
}

static void mm_chunk(FILE *fp, const char *type, const unsigned char *data, size_t n)
{
    mm_w32(fp, (unsigned long)n);
    fwrite(type, 1, 4, fp);
    if (n)
        fwrite(data, 1, n, fp);
    /* CRC 覆盖 type + data，且 mm_crc 是流式的：中途不能插入 ^0xFFFFFFFF，
       否则会把未终结的中间态异或掉，得到的 CRC 全错（图片查看器一律拒绝打开）。
       正确做法是一次性喂完 type+data，最后再异或收尾。 */
    unsigned long c = mm_crc(0xFFFFFFFFUL, (const unsigned char *)type, 4);
    if (n)
        c = mm_crc(c, data, n);
    mm_w32(fp, (c ^ 0xFFFFFFFFUL) & 0xFFFFFFFFUL);
}

/* ---- PNG 编码器（mm 与图.* 共用）----
 * 原先这一整段是 rt_mm_draw_away 里的内联代码。图.* 要拿自己的 RGBA 缓冲出图，
 * 于是抽成 mm_write_png：只认 RGBA 8888 缓冲，落一个 PNG，返回 1/0。
 * 不要把它复制到别的文件 —— CRC 那里是流式的，中途插一次 ^0xFFFFFFFF
 * 得到的 CRC 全错（图片查看器一律拒绝打开）。 */
int mm_write_png(const char *name, const unsigned char *rgba, size_t W, size_t H)
{
    /* 原始数据：每行前置过滤字节 0 */
    size_t raw_len = H * (W * 4 + 1);
    unsigned char *raw = (unsigned char *)malloc(raw_len);
    if (!raw) {
        mm_die("write_png 内存不足");
        return 0;
    }
    for (size_t y = 0; y < H; y++) {
        raw[y * (W * 4 + 1)] = 0;
        memcpy(raw + y * (W * 4 + 1) + 1, rgba + y * W * 4, W * 4);
    }

    FILE *fp = mm_fopen(name, "wb");
    if (!fp) {
        free(raw);
        mm_die("write_png：无法写 %s", name);
        return 0;
    }
    static const unsigned char sig[8] = {137, 80, 78, 71, 13, 10, 26, 10};
    fwrite(sig, 1, 8, fp);

    unsigned char ihdr[13];
    ihdr[0] = (unsigned char)((W >> 24) & 0xFF); ihdr[1] = (unsigned char)((W >> 16) & 0xFF);
    ihdr[2] = (unsigned char)((W >> 8) & 0xFF);  ihdr[3] = (unsigned char)(W & 0xFF);
    ihdr[4] = (unsigned char)((H >> 24) & 0xFF); ihdr[5] = (unsigned char)((H >> 16) & 0xFF);
    ihdr[6] = (unsigned char)((H >> 8) & 0xFF);  ihdr[7] = (unsigned char)(H & 0xFF);
    ihdr[8] = 8;   /* 位深 */
    ihdr[9] = 6;   /* RGBA */
    ihdr[10] = ihdr[11] = ihdr[12] = 0;
    mm_chunk(fp, "IHDR", ihdr, 13);

    /* zlib store 包装 */
    size_t zlen = raw_len + raw_len / 65535 * 5 + 12;
    unsigned char *z = (unsigned char *)malloc(zlen);
    if (!z) {
        fclose(fp);
        free(raw);
        mm_die("write_png 内存不足");
        return 0;
    }
    size_t zp = 0;
    z[zp++] = 0x78; z[zp++] = 0x01;
    size_t off = 0;
    while (off < raw_len) {
        size_t blk = raw_len - off;
        if (blk > 65535) blk = 65535;
        z[zp++] = (off + blk >= raw_len) ? 1 : 0;
        z[zp++] = (unsigned char)(blk & 0xFF);
        z[zp++] = (unsigned char)(blk >> 8);
        z[zp++] = (unsigned char)(~blk & 0xFF);
        z[zp++] = (unsigned char)((~blk >> 8) & 0xFF);
        memcpy(z + zp, raw + off, blk);
        zp += blk;
        off += blk;
    }
    unsigned long a = 1, b2 = 0;
    for (size_t k = 0; k < raw_len; k++) {
        a = (a + raw[k]) % 65521;
        b2 = (b2 + a) % 65521;
    }
    unsigned long adler = (b2 << 16) | a;
    z[zp++] = (unsigned char)((adler >> 24) & 0xFF);
    z[zp++] = (unsigned char)((adler >> 16) & 0xFF);
    z[zp++] = (unsigned char)((adler >> 8) & 0xFF);
    z[zp++] = (unsigned char)(adler & 0xFF);
    mm_chunk(fp, "IDAT", z, zp);

    mm_chunk(fp, "IEND", (const unsigned char *)"", 0);
    fclose(fp);
    free(z);
    free(raw);
    return 1;
}

Value rt_mm_draw_away(Value rows, Value file, Value scale)
{
    long long sc = rt_to_ll(scale);
    size_t W = 0, H = 0;
    unsigned char *px = rt_mm_raster(rows, sc, &W, &H);
    const char *name = rt_str_of(file);
    mm_write_png(name, px, W, H);
    return rt_str(name);
}

/* ---- 新增算子 ---- */

/* mm.存(表, "名.mmp")：列表 -> 文本落盘（连自定义调色板一起存，往返无损） */
Value rt_mm_save(Value rows, Value filev)
{
    MmGrid g = mm_grid_parse(rows, "存");
    const char *name = rt_str_of(filev);
    FILE *fp = mm_fopen(name, "wb");
    if (!fp) {
        mm_grid_free(&g);
        mm_die("存：无法写 %s", name);
    }
    fprintf(fp, "#mymove 1\n");
    for (int i = 0; i < mm_ncustom; i++)
        fprintf(fp, "#色 %s %u %u %u\n", mm_custom[i].tok,
                mm_custom[i].r, mm_custom[i].g, mm_custom[i].b);
    Value out = mm_grid_emit(&g);
    RtList *L = AS_LIST(out);
    for (size_t i = 0; i < L->len; i++)
        fprintf(fp, "%s\n", rt_str_of(L->items[i]));
    fclose(fp);
    mm_grid_free(&g);
    return rt_str(name);
}

/* mm.读("名.mmp")：文本 -> 列表（顺带把存的调色板注册回来） */
Value rt_mm_load(Value filev)
{
    const char *name = rt_str_of(filev);
    FILE *fp = mm_fopen(name, "rb");
    if (!fp)
        mm_die("读：无法打开 %s", name);
    Value out = rt_list_new();
    char line[65536];
    int saw = 0;
    while (fgets(line, sizeof line, fp)) {
        size_t l = strlen(line);
        if (l + 1 == sizeof line && line[l - 1] != '\n') {
            /* 没读到换行就是这行太长：继续读会把一行悄悄切成两行，
             * 那比报错更坏（画出来的东西和存进去的不一样）。 */
            fclose(fp);
            mm_die("读：%s 里有一行超过 %d 字节（token 模式的最宽行可能超）",
                   name, (int)(sizeof line - 2));
        }
        while (l && (line[l - 1] == '\n' || line[l - 1] == '\r'))
            line[--l] = '\0';
        if (line[0] == '#') {
            /* 头行 "#色 tok r g b"。色 是 UTF-8 三字节，比较必须逐字节来：
             * 写成 line[1] == '色' 会被当成多字符常量（恒为假），调色板就永远读不回来。 */
            if (strlen(line) >= 4 && line[1] == MM_CE[0]
                && line[2] == MM_CE[1] && line[3] == MM_CE[2]) {
                char tok[16];
                int r, g2, b2;
                if (sscanf(line + 2, "%15s %d %d %d", tok, &r, &g2, &b2) == 4) {
                    if (r < 0) r = 0;
                    if (r > 255) r = 255;
                    if (g2 < 0) g2 = 0;
                    if (g2 > 255) g2 = 255;
                    if (b2 < 0) b2 = 0;
                    if (b2 > 255) b2 = 255;
                    mm_palette_set(tok, r, g2, b2);
                }
            }
            continue;
        }
        rt_push(&out, rt_str(line));
        saw = 1;
    }
    fclose(fp);
    if (!saw)
        mm_die("读：%s 里没有画（只有头行或全空）", name);
    return out;
}

/* mm.转(表, 方式)：左右 / 上下 / 旋转180 / 顺时针90 / 逆时针90 */
Value rt_mm_xform(Value rows, Value howv)
{
    MmGrid g = mm_grid_parse(rows, "转");
    const char *how = rt_str_of(howv);
    MmGrid o;

    if (!strcmp(how, "左右")) {                  /* 水平镜像 */
        o = mm_grid_new(g.rows, g.w, g.token_mode);
        for (size_t r = 0; r < g.rows; r++)
            for (size_t c = 0; c < g.w; c++)
                mm_set(&o, r, g.w - 1 - c, g.cells[r * g.w + c]);
    } else if (!strcmp(how, "上下")) {           /* 垂直镜像 */
        o = mm_grid_new(g.rows, g.w, g.token_mode);
        for (size_t r = 0; r < g.rows; r++)
            for (size_t c = 0; c < g.w; c++)
                mm_set(&o, g.rows - 1 - r, c, g.cells[r * g.w + c]);
    } else if (!strcmp(how, "旋转180")) {
        o = mm_grid_new(g.rows, g.w, g.token_mode);
        for (size_t r = 0; r < g.rows; r++)
            for (size_t c = 0; c < g.w; c++)
                mm_set(&o, g.rows - 1 - r, g.w - 1 - c, g.cells[r * g.w + c]);
    } else if (!strcmp(how, "顺时针90")) {       /* 尺寸转置：新高=原宽，新宽=原高 */
        o = mm_grid_new(g.w, g.rows, g.token_mode);
        for (size_t r = 0; r < g.rows; r++)
            for (size_t c = 0; c < g.w; c++)
                mm_set(&o, c, g.rows - 1 - r, g.cells[r * g.w + c]);
    } else if (!strcmp(how, "逆时针90")) {
        o = mm_grid_new(g.w, g.rows, g.token_mode);
        for (size_t r = 0; r < g.rows; r++)
            for (size_t c = 0; c < g.w; c++)
                mm_set(&o, g.w - 1 - c, r, g.cells[r * g.w + c]);
    } else {
        mm_grid_free(&g);
        mm_die("转：不知道的变换「%s」。可选：左右 / 上下 / 旋转180 / 顺时针90 / 逆时针90",
               how);
        return rt_none();
    }
    Value out = mm_grid_emit(&o);
    mm_grid_free(&o);
    mm_grid_free(&g);
    return out;
}

/* mm.描边(表, token)：给不透明像素的外圈补一圈颜色（token 留空则用 k1 黑） */
Value rt_mm_outline(Value rows, Value tokv)
{
    MmGrid g = mm_grid_parse(rows, "描边");
    const char *tk = rt_str_of(tokv);
    if (!tk || !tk[0])
        tk = "k1";
    int cr, cg, cb;
    if (rt_mm_lookup(rt_str(tk), &cr, &cg, &cb) != 1) {
        mm_grid_free(&g);
        mm_die("描边：颜色 token「%s」不认识（. 和 _ 是透明，不能拿来当描边色）", tk);
        return rt_none();
    }
    MmGrid o = mm_grid_copy(&g);
    int added = 0;
    for (size_t r = 0; r < o.rows; r++)
        for (size_t c = 0; c < o.w; c++) {
            if (mm_opaque(&o, r, c))
                continue;
            /* mm_opaque 越界返回 0，所以边界不需要额外特判 */
            if (mm_opaque(&o, r - 1, c) || mm_opaque(&o, r + 1, c) ||
                mm_opaque(&o, r, c - 1) || mm_opaque(&o, r, c + 1)) {
                mm_set(&o, r, c, tk);
                added = 1;
            }
        }
    /* 描边色是 k1 这种多字符 token 时，连写模式会把 k1 拆成 k 和 1 两个像素，
     * emit 出去再渲染就报「字符 k 不认识」。所以真补了边且色名多字符时切 token 模式；
     * 一个边都没补（全实心）就原样返回，不平白改写模式。 */
    if (added && strlen(tk) > 1)
        o.token_mode = 1;
    Value out = mm_grid_emit(&o);
    mm_grid_free(&o);
    mm_grid_free(&g);
    return out;
}

/* mm.平铺(表, 横, 纵)：把一张画重复 nx*ny 次（背景填充、地面最常用） */
Value rt_mm_tile(Value rows, Value nxv, Value nyv)
{
    MmGrid g = mm_grid_parse(rows, "平铺");
    long long nx = rt_to_ll(nxv), ny = rt_to_ll(nyv);
    if (nx < 1) nx = 1;
    if (ny < 1) ny = 1;
    if (nx > 64 || ny > 64) {
        mm_grid_free(&g);
        mm_die("平铺：次数须为 1..64（要更大请分两步）");
        return rt_none();
    }
    MmGrid o = mm_grid_new(g.rows * (size_t)ny, g.w * (size_t)nx, g.token_mode);
    for (size_t r = 0; r < g.rows; r++)
        for (size_t c = 0; c < g.w; c++) {
            const char *cell = g.cells[r * g.w + c];
            if (!cell)
                continue;
            for (long long a = 0; a < ny; a++)
                for (long long b = 0; b < nx; b++)
                    mm_set(&o, r + (size_t)a * g.rows, c + (size_t)b * g.w, cell);
        }
    Value out = mm_grid_emit(&o);
    mm_grid_free(&o);
    mm_grid_free(&g);
    return out;
}

/* mm.拼(甲, 乙, 方式)：横（并排）/ 纵（上下）/ 叠（乙盖在甲上，乙透明处露甲） */
Value rt_mm_paste(Value av, Value bv, Value howv)
{
    MmGrid a = mm_grid_parse(av, "拼");
    MmGrid b = mm_grid_parse(bv, "拼");
    const char *how = rt_str_of(howv);
    MmGrid o;
    size_t rows, w;
    /* 两种模式不一致时取 token 模式：那种更保险，单字符格子装不下多字符 token */
    int mode = a.token_mode || b.token_mode;

    if (!strcmp(how, "横")) {
        rows = (a.rows > b.rows) ? a.rows : b.rows;
        w = a.w + b.w;
        o = mm_grid_new(rows, w, mode);
        for (size_t r = 0; r < a.rows; r++)
            for (size_t c = 0; c < a.w; c++)
                mm_set(&o, r, c, a.cells[r * a.w + c]);
        for (size_t r = 0; r < b.rows; r++)
            for (size_t c = 0; c < b.w; c++)
                mm_set(&o, r, a.w + c, b.cells[r * b.w + c]);
    } else if (!strcmp(how, "纵")) {
        rows = a.rows + b.rows;
        w = (a.w > b.w) ? a.w : b.w;
        o = mm_grid_new(rows, w, mode);
        for (size_t r = 0; r < a.rows; r++)
            for (size_t c = 0; c < a.w; c++)
                mm_set(&o, r, c, a.cells[r * a.w + c]);
        for (size_t r = 0; r < b.rows; r++)
            for (size_t c = 0; c < b.w; c++)
                mm_set(&o, a.rows + r, c, b.cells[r * b.w + c]);
    } else if (!strcmp(how, "叠")) {
        rows = (a.rows > b.rows) ? a.rows : b.rows;
        w = (a.w > b.w) ? a.w : b.w;
        o = mm_grid_new(rows, w, mode);
        for (size_t r = 0; r < a.rows; r++)
            for (size_t c = 0; c < a.w; c++)
                mm_set(&o, r, c, a.cells[r * a.w + c]);
        for (size_t r = 0; r < b.rows; r++)
            for (size_t c = 0; c < b.w; c++) {
                const char *cell = b.cells[r * b.w + c];
                if (cell && cell[0] && strcmp(cell, ".") != 0 && strcmp(cell, "_") != 0)
                    mm_set(&o, r, c, cell);     /* 只有乙「画了东西」才盖 */
            }
    } else {
        mm_grid_free(&a);
        mm_grid_free(&b);
        mm_die("拼：不知道的方式「%s」。可选：横 / 纵 / 叠", how);
        return rt_none();
    }
    Value out = mm_grid_emit(&o);
    mm_grid_free(&o);
    mm_grid_free(&a);
    mm_grid_free(&b);
    return out;
}

/* mm.渐变(表, 起token, 止token, 级数)：按横向位置把不透明像素刷成一条色带。
 * 会把 渐0..渐N-1 注册进调色板（同名覆盖，所以反复调用不会把调色板撑爆）。 */
Value rt_mm_grad(Value rows, Value c0v, Value c1v, Value nv)
{
    MmGrid g = mm_grid_parse(rows, "渐变");
    int r0, g0, b0, r1, g1, b1;
    if (rt_mm_lookup(c0v, &r0, &g0, &b0) != 1) {
        mm_grid_free(&g);
        mm_die("渐变：起始色 token「%s」不认识", rt_str_of(c0v));
        return rt_none();
    }
    if (rt_mm_lookup(c1v, &r1, &g1, &b1) != 1) {
        mm_grid_free(&g);
        mm_die("渐变：终止色 token「%s」不认识", rt_str_of(c1v));
        return rt_none();
    }
    long long steps = rt_to_ll(nv);
    if (steps <= 0) steps = 8;
    if (steps > 32) steps = 32;
    if (steps < 2) steps = 2;

    /* 先把整条色带注册好，中途失败也不留半截调色板 */
    char name[16];
    for (long long i = 0; i < steps; i++) {
        double t = (double)i / (double)(steps - 1);
        int rr = (int)(r0 + (r1 - r0) * t + 0.5);
        int gg = (int)(g0 + (g1 - g0) * t + 0.5);
        int bb = (int)(b0 + (b1 - b0) * t + 0.5);
        snprintf(name, sizeof name, "渐%lld", i);
        if (mm_palette_set(name, rr, gg, bb) != 0) {
            mm_grid_free(&g);
            mm_die("渐变：自定义颜色已满（256 个），装不下 %lld 级色带", steps);
            return rt_none();
        }
    }
    MmGrid o = mm_grid_copy(&g);
    for (size_t r = 0; r < o.rows; r++)
        for (size_t c = 0; c < o.w; c++) {
            if (!mm_opaque(&o, r, c))
                continue;
            double t = (o.w <= 1) ? 0.0 : (double)c / (double)(o.w - 1);
            long long idx = (long long)(t * (double)(steps - 1) + 0.5);
            if (idx < 0) idx = 0;
            if (idx > steps - 1) idx = steps - 1;
            snprintf(name, sizeof name, "渐%lld", idx);
            mm_set(&o, r, c, name);
        }
    /* 渐N 是多字符 token：连写模式一格只吃一个字符，emit 出去再读回来会碎掉，
     * 所以这里强制切 token 模式。 */
    o.token_mode = 1;
    Value out = mm_grid_emit(&o);
    mm_grid_free(&o);
    mm_grid_free(&g);
    return out;
}

/* mm.反色(表)：每个不透明 token 换成补色。
 * 关键：同色只生成一次新 token（一张 200 像素的同色画不能吃掉 200 个调色板格子）。 */
#define MM_INV_MAX 64
Value rt_mm_invert(Value rows)
{
    MmGrid g = mm_grid_parse(rows, "反色");
    MmGrid o = mm_grid_copy(&g);
    char srcs[MM_INV_MAX][16];
    char dsts[MM_INV_MAX][16];
    int nmap = 0;
    int fail = 0;
    char name[16];

    for (size_t r = 0; r < o.rows && !fail; r++)
        for (size_t c = 0; c < o.w && !fail; c++) {
            const char *cell = mm_at(&o, r, c);
            if (!cell || !cell[0] || !strcmp(cell, ".") || !strcmp(cell, "_"))
                continue;
            int rr, gg, bb;
            if (rt_mm_lookup(rt_str(cell), &rr, &gg, &bb) != 1)
                continue;                       /* 未知 token 原样留着，交给渲染时报错 */
            const char *mapped = NULL;
            for (int i = 0; i < nmap; i++)
                if (!strcmp(srcs[i], cell)) {
                    mapped = dsts[i];
                    break;
                }
            if (!mapped) {
                if (nmap >= MM_INV_MAX) {
                    fail = 2;
                    break;
                }
                snprintf(name, sizeof name, "反%d", nmap);
                if (mm_palette_set(name, 255 - rr, 255 - gg, 255 - bb) != 0) {
                    fail = 1;
                    break;
                }
                /* 必须按实际长度拷：memcpy(..., 15) 从 1 字节的 token 会读过界 */
                size_t sl = strlen(cell), nl = strlen(name);
                memcpy(srcs[nmap], cell, sl);
                srcs[nmap][sl] = '\0';
                memcpy(dsts[nmap], name, nl);
                dsts[nmap][nl] = '\0';
                mapped = dsts[nmap];
                nmap++;
            }
            mm_set(&o, r, c, mapped);
        }
    if (fail) {
        mm_grid_free(&o);
        mm_grid_free(&g);
        if (fail == 1)
            mm_die("反色：自定义颜色已满（256 个）");
        else
            mm_die("反色：一张画里的颜色种类超过 %d 种", MM_INV_MAX);
        return rt_none();
    }
    /* 反N 是多字符 token，必须切 token 模式，否则 emit 再读会碎 */
    o.token_mode = 1;
    Value out = mm_grid_emit(&o);
    mm_grid_free(&o);
    mm_grid_free(&g);
    return out;
}
