# -*- coding: utf-8 -*-
"""patch_p3.py — P3 剩余三件（修正版：hist 补丁归 hist 文件）。
① release.py 发布日志（已完成，幂等跳过）
② hist.py restore 红警告 + push 红绿统计
③ pybktl.py publish 发布日志
④ doctor.py --export/--compare 环境基准卡
幂等。"""

import io

def rd(p):
    return io.open(p, 'rb').read().decode('utf-8').replace('\r\n', '\n')

def wr(p, t):
    raw = io.open(p, 'rb').read().decode('utf-8')
    eol = '\r\n' if '\r\n' in raw else '\n'
    io.open(p, 'wb').write(t.replace('\n', eol).encode('utf-8'))

def sub1(t, old, new, tag):
    if new in t:
        print('  %s: 已有，跳过' % tag)
        return t
    assert old in t, tag + ' 锚点没找到'
    print('  %s: 已应用' % tag)
    return t.replace(old, new, 1)

# ============ ① release.py：发布日志 ============
P = 'tools/pybktl/release.py'
t = rd(P)
t = sub1(t, '''    logp = os.path.join(root, "发布日志.md")''',
         '''    logp = os.path.join(root, "发布日志.md")''', 'release 发布日志（幂等）')
wr(P, t)

# ============ ② hist.py：restore 红警告 + push 红绿统计 ============
P = 'tools/pybktl/hist.py'
t = rd(P)

old = '''def _restore(row, exact=False):
    # 安全第一：先把现状拍成快照，回滚永不丢东西
    _save(f"回滚到 {row['id']} 前的安全快照", auto=True)'''
new = '''def _restore(row, exact=False):
    if row.get("灯") == "红":
        out("⚠ 你正在回滚到 ●红 快照（当时的 .pybk 没通过静态检查）——确认是要回到那个状态")
    # 安全第一：先把现状拍成快照，回滚永不丢东西
    _save(f"回滚到 {row['id']} 前的安全快照", auto=True)'''
t = sub1(t, old, new, 'restore 红警告')

old = '''    authors = sorted({r["author"] for r in fresh})
    out(f"✓ 已推送 {len(fresh)} 条快照（{pushed_shas} 个内容块）→ {target}")
    out(f"  作者: {'、'.join(authors) or '—'}；共享历史现共 {len(shared) + len(fresh)} 条")
    return 0'''
new = '''    authors = sorted({r["author"] for r in fresh})
    lv = [r.get("灯", "无") for r in fresh]
    out(f"✓ 已推送 {len(fresh)} 条快照（{pushed_shas} 个内容块）→ {target}")
    out(f"  红绿: ●绿 {lv.count('绿')} / ●红 {lv.count('红')} ｜ 作者: {'、'.join(authors) or '—'}"
        f"｜共享历史现共 {len(shared) + len(fresh)} 条")
    return 0'''
t = sub1(t, old, new, 'push 红绿统计')
wr(P, t)

# ============ ③ pybktl.py：pkg publish 发布日志 ============
P = 'tools/pybktl/pybktl.py'
t = rd(P)

old = '''        out(f"✓ 已发布 {name} @{version} → {dest}")
        out(f"  registry: {reg}（索引已更新，共 {len(rows)} 个包）")'''
new = '''        out(f"✓ 已发布 {name} @{version} → {dest}")
        out(f"  registry: {reg}（索引已更新，共 {len(rows)} 个包）")
        author = os.environ.get("PYBOOK_AUTHOR") or os.environ.get("USERNAME") or "未知"
        logp = os.path.join(os.getcwd(), "发布日志.md")
        with open(logp, "a", encoding="utf-8") as lf:
            if not os.path.isfile(logp) or os.path.getsize(logp) == 0:
                lf.write("# 发布日志\\n\\n")
            import datetime as _dt
            now = _dt.datetime.now().strftime("%Y-%m-%d %H:%M")
            lf.write(f"- {now} {author}：{name} @{version}（{os.path.basename(dest)}）\\n")
        out("  已记入 发布日志.md")'''
t = sub1(t, old, new, 'pkg publish 发布日志')
wr(P, t)

# ============ ④ doctor.py：--export/--compare 环境基准卡 ============
P = 'tools/pybktl/doctor.py'
t = rd(P)

old = '''def run(args):
    root = os.getcwd()
    out("== PYbook 工作区诊所 ==")'''
new = '''def _env_card(root):
    """环境基准卡：版本 + 关键件存在性（JSON 导出，团队共享给新成员对比）。"""
    card = {}
    vp = os.path.join(root, "VERSION")
    if os.path.isfile(vp):
        card["VERSION"] = open(vp, encoding="utf-8").read().strip()
    for name in ("pyvm.exe", "SDL2.dll", "libwinpthread-1.dll",
                 "PYbookIDE.exe", "editor.exe",
                 "pybk_main.py", "pybk_front.py", "pybook_gpu.c", "pybook_la.c"):
        card[name] = os.path.isfile(os.path.join(root, name))
    return card


def cmd_export(args):
    import json as _j
    root = os.getcwd()
    card = _env_card(root)
    card["导出时间"] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
    open(args.export, "w", encoding="utf-8").write(_j.dumps(card, ensure_ascii=False, indent=2))
    out(f"✓ 环境基准卡已导出 → {args.export}")
    out("  团队共享这份 JSON；新成员 doctor --compare 这份文件 验收自己的环境")
    return 0


def cmd_compare(args):
    import json as _j
    if not os.path.isfile(args.compare):
        err(f"✗ 找不到基准卡: {args.compare}")
        return 1
    base = _j.loads(open(args.compare, encoding="utf-8").read())
    cur = _env_card(os.getcwd())
    diffs = []
    for k, v in base.items():
        if k == "导出时间":
            continue
        cv = cur.get(k, "<无此项>")
        if cv != v:
            diffs.append(f"  ✗ {k}: 基准={v}  你={cv}")
    if diffs:
        out(f"✗ 与环境基准卡不符 {len(diffs)} 处：")
        for d in diffs:
            out(d)
        return 1
    out("✓ 环境与基准卡一致")
    return 0


def _dispatch_doctor(args):
    if getattr(args, "export", None):
        return cmd_export(args)
    if getattr(args, "compare", None):
        return cmd_compare(args)
    return run(args)


def run(args):
    root = os.getcwd()
    out("== PYbook 工作区诊所 ==")'''
t = sub1(t, old, new, 'doctor 环境基准卡函数')

old = '''    pd = sub.add_parser("doctor", help="工作区小诊所：僵尸锁/僵尸进程/缓存堆积/版本漂移 体检+修复")
    pd.add_argument("--fix", action="store_true", help="自动修能安全修的（默认只报告）")
    pd.set_defaults(func=run)'''
new = '''    pd = sub.add_parser("doctor", help="工作区小诊所：僵尸锁/僵尸进程/缓存堆积/版本漂移 体检+修复")
    pd.add_argument("--fix", action="store_true", help="自动修能安全修的（默认只报告）")
    pd.add_argument("--export", metavar="文件", help="导出环境基准卡 JSON（团队共享）")
    pd.add_argument("--compare", metavar="基准.json", help="对比环境基准卡（新成员验收）")
    pd.set_defaults(func=_dispatch_doctor)'''
t = sub1(t, old, new, 'doctor 参数')

wr(P, t)
print('P3 全部完成')
