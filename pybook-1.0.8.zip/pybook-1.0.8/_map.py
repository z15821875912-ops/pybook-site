# -*- coding: utf-8 -*-
"""把区域采样成字符地图，快速看清线框结构。
字符: 空格=背景  #=暗线(网格/边框) + =亮线(主色/选中) a=文字像素 .=弱
用法: python -B _map.py <bmp> x0 y0 w h [stepx] [stepy]
"""
import sys, struct


def load(path):
    d = open(path, 'rb').read()
    off = struct.unpack_from('<I', d, 10)[0]
    w, h = struct.unpack_from('<ii', d, 18)
    flip = h > 0                       # 自底向上：raw 行号要倒过来才是显示坐标
    h = abs(h)
    bpp = struct.unpack_from('<H', d, 28)[0] // 8
    stride = ((w * bpp + 3) // 4) * 4
    return w, h, bpp, stride, off, d, flip


def main():
    p = sys.argv[1]
    x0, y0, rw, rh = (int(v) for v in sys.argv[2:6])
    sx = int(sys.argv[6]) if len(sys.argv) > 6 else 4
    sy = int(sys.argv[7]) if len(sys.argv) > 7 else 4
    w, h, bpp, stride, off, d, flip = load(p)

    def px(x, y):
        row = (h - 1 - y) if flip else y
        i = off + row * stride + x * 3
        return (d[i + 2], d[i + 1], d[i])

    bg = px(x0, y0)
    print(f'bg={bg[0]:02X}{bg[1]:02X}{bg[2]:02X}  区域 x{x0}..{x0 + rw} y{y0}..{y0 + rh} 步进 {sx}x{sy}')
    hdr = '     '
    hdr2 = '     '
    for cx in range(0, rw, sx * 2):
        hdr += str((x0 + cx) // 100 % 10) if (x0 + cx) % 100 < sx * 2 else ' '
    for cx in range(0, rw, sx * 2):
        hdr2 += str((x0 + cx) // 10 % 10) if (x0 + cx) % 100 < sx * 2 else ' '
    print(hdr)
    print(hdr2)
    for cy in range(0, rh, sy):
        row = f'{y0 + cy:4d} '
        for cx in range(0, rw, sx):
            r, g, b = px(min(x0 + cx, w - 1), min(y0 + cy, h - 1))
            if g > r + 24 and g > b + 24:
                ch = '+'
            elif g > r + 10 and g > b + 10:
                ch = ':'
            else:
                lum = r + g + b
                d0 = abs(r - bg[0]) + abs(g - bg[1]) + abs(b - bg[2])
                if d0 < 20:
                    ch = ' '
                elif lum < 120:
                    ch = '-'
                elif lum < 260:
                    ch = '.'
                elif lum < 560:
                    ch = '#'
                else:
                    ch = '@'
            row += ch
        print(row)


main()
