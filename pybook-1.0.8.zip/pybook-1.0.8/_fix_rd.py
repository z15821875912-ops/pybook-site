# -*- coding: utf-8 -*-
"""_fix_rd.py — 修 rd.* 的三个实测缺陷，并把随机源统一到 mp.rand_* 那套

实测坐实的三条：
  1. rd.float() 20 万次采样只有 32693 个不同取值、上限 0.999969482421875
     —— 根因是只调一次 rand()，MinGW 的 RAND_MAX 就是 32767（15 位而非 53 位）。
  2. 没有 rd.seed，测试写不出可复现的随机序列。
  3. mp.rand_seed(42) 对 rd.int 毫无影响 —— 两套互不相干的随机源。

改法：rd.* 全部改走 mathplus.c 的 xorshift128（mp_rand_u01）。
     那是核心层的无条件纯 C，mathplus.c 在三处构建里都参与链接。
参数、范围、语义一律不动（rd.int 仍含两端、rd.float 仍 [0,1)、rd.shuffle 仍原地），
只换随机源 + 修精度 + 补 rd.seed。
"""
import io

P = 'pybook_lib.c'
t = io.open(P, encoding='utf-8', newline='').read()
e = '\r\n' if '\r\n' in t else '\n'


def sub(old, new, tag):
    global t
    old_e = old.replace('\n', e)          # 按文件实际行尾归一化后再匹配
    new_e = new.replace('\n', e)
    assert old_e in t, '找不到：%s' % tag
    t = t.replace(old_e, new_e, 1)
    print('  已改 %s' % tag)


# ---- 1. include mathplus.h（放在 pybook_lib.h 之后）----
sub('#include "pybook_lib.h"\n',
    '#include "pybook_lib.h"\n#include "mathplus.h"   /* 随机源统一到 mp_rand_* */\n',
    'include mathplus.h')

# ---- 2. 换随机源 ----
OLD_SEED = '''static void rd_seed(void)
{
    if (!g_rd_seeded) {
        srand((unsigned)time(NULL));
        g_rd_seeded = 1;
    }
}'''
NEW_SEED = '''/* 随机源统一到 mathplus.c 的 xorshift128（mp_rand_u01）。
 * 原来 rd.* 走 C 的 rand() 且只播种一次 time(NULL)，实测有三个问题：
 *   1. rd.float() 只调一次 rand()，而 MinGW 的 RAND_MAX 就是 32767 ——
 *      20 万次采样只有 32693 个不同取值，最大只到 0.999969482421875，
 *      也就是 15 位有效精度而不是 double 的 53 位。
 *   2. 没有 rd.seed，测试写不出可复现的随机序列。
 *   3. mp.rand_* 走的是另一套 xorshift128，mp.rand_seed(42) 对 rd.int 毫无影响。
 * 现在一次播种，rd.* 与 mp.rand_* 一起变。 */
static void rd_seed(void)
{
    if (!g_rd_seeded) {
        mp_rand_seed((uint64_t)time(NULL));
        g_rd_seeded = 1;
    }
}

/* 显式播种。走同一个 xorshift128，所以 rd.seed(42) 之后
 * rd.* 与 mp.rand_* 都是同一条可复现序列。 */
Value rt_lib_rd_seed(Value s)
{
    if (!IS_INT(s) && !IS_BIGINT(s))
        lib_die("rd.seed 需要整数种子");
    mp_rand_seed((uint64_t)rt_to_ll(s));
    g_rd_seeded = 1;              /* 别让紧接着的 rd_seed() 又用时间覆盖掉 */
    return rt_none();
}'''
sub(OLD_SEED, NEW_SEED, 'rd_seed + rd.seed')

# ---- 3. rd_below：去掉取模偏差，改成 floor(u * range) ----
OLD_BELOW = '''/* [0, range) 的随机整数（range >= 1）；两次 rand 拼 62 位，降低低位偏差 */
static long long rd_below(long long range)
{
    long long r = ((long long)rand() << 31) | (long long)rand();
    return r % range;
}'''
NEW_BELOW = '''/* [0, range) 的随机整数（range >= 1）。
 * 原来是 ((rand()<<31)|rand()) % range —— 取模偏差，且 rand() 上限只有 32767。
 * 现在用满 53 位的 mp_rand_u01() 缩放：range <= 2^53 时偏差可忽略。 */
static long long rd_below(long long range)
{
    return (long long)(mp_rand_u01() * (double)range);
}'''
sub(OLD_BELOW, NEW_BELOW, 'rd_below')

# ---- 4. rd.float：满 53 位，而不是除以 RAND_MAX+1 ----
OLD_FLOAT = '''Value rt_lib_rd_float(void)
{
    rd_seed();
    return rt_float((double)rand() / ((double)RAND_MAX + 1.0));
}'''
NEW_FLOAT = '''/* [0,1) 随机浮点，满 53 位有效精度。
 * 原来是 rand() / (RAND_MAX + 1.0)，而 MinGW 的 RAND_MAX = 32767 ——
 * 取值上限只有 0.999969482421875，只有 32768 个不同取值。 */
Value rt_lib_rd_float(void)
{
    rd_seed();
    return rt_float(mp_rand_u01());
}'''
sub(OLD_FLOAT, NEW_FLOAT, 'rd.float 精度')

io.open(P, 'w', encoding='utf-8', newline='').write(t)
print('pybook_lib.c 完成')

# ---- 5. 头文件原型 ----
P2 = 'pybook_lib.h'
t2 = io.open(P2, encoding='utf-8', newline='').read()
e2 = '\r\n' if '\r\n' in t2 else '\n'
if 'rt_lib_rd_seed' in t2:
    print('pybook_lib.h 已有 rd.seed，跳过')
else:
    a = 'Value rt_lib_rd_shuffle(Value list);              /* 原地打乱（返回空盒） */'
    i = t2.index(a) + len(a)
    t2 = t2[:i] + e2 + 'Value rt_lib_rd_seed(Value s);                     /* 播种（rd.* 与 mp.rand_* 同源） */' + t2[i:]
    io.open(P2, 'w', encoding='utf-8', newline='').write(t2)
    print('pybook_lib.h 已加 rd.seed 原型')
