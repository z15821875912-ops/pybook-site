# -*- coding: utf-8 -*-
"""_fixchk.py — 动手改 C 之前，先在 Python 里把两处修法验到 1e-15。

1) Lanczos：原式漏了 exp(-(z+g-0.5))。验证加上之后 gamma/lgamma 对不对。
2) ζ 的有限和用 Neumaier 补偿求和，看能不能把 s→1 的 1.1e-13 压下去。
"""
import math

LG7 = [0.99999999999980993, 676.5203681218851, -1259.1392167224028,
       771.32342877765313, -176.61502916214059, 12.507343278686905,
       -0.13857109526572012, 9.9843695780195716e-6, 1.5056327351493116e-7]
PI = 3.14159265358979323846


def lanczos_x(z):
    x = LG7[0]
    for i in range(1, 9):
        x += LG7[i]/(z + i - 1.0)
    return x


def gamma_fixed(z):
    if z > 0.0:
        t = z + 7.0 - 0.5
        return math.sqrt(2.0*PI)*pow(t, z-0.5)*math.exp(-t)*lanczos_x(z)
    s = math.sin(PI*z)
    if s == 0.0:
        return float('nan')
    return PI/(s*gamma_fixed(1.0-z))


def lgamma_fixed(z):
    if z > 0.0:
        t = z + 7.0 - 0.5
        return 0.5*math.log(2.0*PI) + (z-0.5)*math.log(t) - t + math.log(lanczos_x(z))
    s = math.sin(PI*z)
    if s == 0.0:
        return float('inf')
    return math.log(PI/abs(s)) - lgamma_fixed(1.0-z)


print('%-10s %-24s %-24s %-11s %-11s' % ('x', 'math.gamma', '修好后(相对误差)', '', 'math.lgamma 对比'))
for x in (0.5, 1.0, 1.5, 2.0, 5.0, 10.0, 20.0, 100.0, 0.001, 0.1, -0.5, -1.5, -4.5):
    ref = math.gamma(x)
    got = gamma_fixed(x)
    rel = abs(got-ref)/abs(ref)
    print('%-10s %-24.16g %-24.16g %-11.2e' % (x, ref, got, rel))

print()
for x in (0.5, 1.0, 1.5, 5.0, 10.0, 100.0, 1000.0, 0.001, -0.5, -1.5):
    ref = math.lgamma(x)
    got = lgamma_fixed(x)
    print('lgamma(%-8s) 参考 %-22.16g 修好后 %-22.16g 绝对误差 %.2e'
          % (x, ref, got, abs(got-ref)))

# ---------- erf / erfc 走不完全 gamma，参考用 math.erf ----------
def ig_series(a, x):
    if x == 0.0:
        return 0.0                      # P(a,0)=0，直接短路（别靠 log(0)=-inf 蒙对）
    ap, s, d = a, 1.0/a, 1.0/a
    for n in range(1, 1001):
        ap += 1.0
        d *= x/ap
        s += d
        if abs(d) <= abs(s)*1e-16:
            break
    return s*math.exp(-x + a*math.log(x) - lgamma_fixed(a))


def ig_cfrac(a, x):
    tiny = 1e-300
    b = x + 1.0 - a
    c = 1.0/tiny
    d = 1.0/b
    h = d
    for i in range(1, 1001):
        an = -i*(i-a)
        b += 2.0
        d = an*d + b
        if abs(d) < tiny: d = tiny
        c = b + an/c
        if abs(c) < tiny: c = tiny
        d = 1.0/d
        de = d*c
        h *= de
        if abs(de-1.0) <= 1e-16:
            break
    return math.exp(-x + a*math.log(x) - lgamma_fixed(a))*h


def erf_fixed(x):
    p = ig_series(0.5, x*x) if x*x < 1.5 else 1.0 - ig_cfrac(0.5, x*x)
    return -p if x < 0.0 else p


def erfc_fixed(x):
    q = ig_series(0.5, x*x) if x*x < 1.5 else 1.0 - ig_cfrac(0.5, x*x)
    return (2.0-q) if x < 0.0 else q


print()
print('%-8s %-24s %-24s %-11s %-11s' % ('x', 'math.erf', '修好后', '相对误差', 'erfc 相对误差'))
for x in (0.0, 0.25, 0.5, 1.0, 1.5, 2.0, 3.0, 4.0, 6.0, -0.5, -2.0):
    ref = math.erf(x)
    got = erf_fixed(x)
    rc = math.erfc(x)
    gc = erfc_fixed(x)
    print('%-8s %-24.16g %-24.16g %-11.2e %-11.2e'
          % (x, ref, got, abs(got-ref)/max(abs(ref), 1e-300),
             abs(gc-rc)/max(abs(rc), 1e-300)))

# ---------- ζ：朴素求和 vs Neumaier 补偿求和 ----------
from fractions import Fraction
BF = [float(Fraction(1, 12)), float(Fraction(-1, 720)), float(Fraction(1, 30240)),
      float(Fraction(-1, 1209600)), float(Fraction(1, 47900160)),
      float(Fraction(-691, 1307674368000))]
REF = {1.01: 100.577943338496865522, 1.001: 1000.577288475901468701,
       1.0001: 10000.577222946438268991, 1.00001: 100000.577216393052367494,
       1.5: 2.612375348685488152, 2.0: 1.644934066848226406}


def zeta_emu(s, kahan=False, C=10.0):
    N = max(20, min(int(C/(s-1.0) + 16.0), 4000000))
    total = 0.0
    comp = 0.0
    for i in range(1, N):
        t = float(i)**(-s)
        if kahan:
            y = t - comp
            tt = total + y
            comp = (tt - total) - y
            total = tt
        else:
            total += t
    tn = N**(-s)
    total += 0.5*tn + tn*N/(s-1.0)
    ps = s
    for k in range(6):
        if k > 0:
            for i in range(2):
                ps *= (s + 2.0*k - 1.0 + i)
        total += BF[k]*ps*N**(-s-2.0*k-1.0)
    return total


print()
print('%-10s %-13s %-13s %-9s %-9s' % ('s', '朴素求和误差', '补偿求和误差', 'N', ''))
for s in (2.0, 1.5, 1.01, 1.001, 1.0001, 1.00001):
    ref = REF[s]
    a = abs(zeta_emu(s, False) - ref)/abs(ref)
    b = abs(zeta_emu(s, True) - ref)/abs(ref)
    print('%-10s %-13.2e %-13.2e' % (s, a, b))
