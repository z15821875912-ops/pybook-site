/* PYbook 标准库实现：te（文本）/ mt（数学）/ rd（随机）。
 * 接口见 pybook_lib.h；只依赖 pybook_rt 与 C99 标准库。 */

#include "pybook_lib.h"
#include "mathplus.h"   /* 随机源统一到 mp_rand_* */

#include <limits.h>
#include <math.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <windows.h>

/* ================= 内部工具 ================= */

/* 运行时错误出口：格式与 pybook_rt 的 rt_die 一致 */
static void lib_die(const char *fmt, ...)
{
    va_list ap;
    fprintf(stderr, "运行时错误: ");
    va_start(ap, fmt);
    vfprintf(stderr, fmt, ap);
    va_end(ap);
    fputc('\n', stderr);
    exit(1);
}

/* 参数类型检查：文本 / 整数 / 数字 */
static const char *lib_str(Value v, const char *who)
{
    if (!IS_STR(v))
        lib_die("%s 需要文本参数", who);
    return AS_STR(v);
}

static long long lib_ll(Value v, const char *who)
{
    if (IS_INT(v) || IS_BIGINT(v))
        return rt_to_ll(v);
    if (IS_BOOL(v))
        return (long long)AS_BOOL(v);
    lib_die("%s 需要整数参数", who);
    return 0;
}

static double lib_num(Value v, const char *who)
{
    if (IS_FLT(v))
        return AS_FLT(v);
    if (IS_INT(v) || IS_BIGINT(v))
        return (double)rt_to_ll(v);
    if (IS_BOOL(v))
        return (double)AS_BOOL(v);
    lib_die("%s 需要数字参数", who);
    return 0;
}

/* [a, b) 字节区间 → 字符串盒（临时缓冲拷给 rt_str 后即释放） */
static Value lib_val_range(const char *a, const char *b)
{
    size_t n = (size_t)(b - a);
    char *tmp = (char *)malloc(n + 1);
    if (tmp == NULL)
        lib_die("内存不足");
    memcpy(tmp, a, n);
    tmp[n] = '\0';
    Value v = rt_str(tmp);
    free(tmp);
    return v;
}

/* 可增长字节缓冲（scratch 用完即释放） */
typedef struct {
    char  *p;
    size_t len, cap;
} Buf;

static void buf_put(Buf *b, const char *s, size_t n)
{
    if (b->len + n + 1 > b->cap) {
        while (b->len + n + 1 > b->cap)
            b->cap = b->cap * 2 + 64;
        b->p = (char *)realloc(b->p, b->cap);
        if (b->p == NULL)
            lib_die("内存不足");
    }
    memcpy(b->p + b->len, s, n);
    b->len += n;
    b->p[b->len] = '\0';
}

static void buf_puts(Buf *b, const char *s)
{
    buf_put(b, s, strlen(s));
}

/* ---------- UTF-8 按字符计数与定位（首字节计数法） ---------- */

static long long utf8_count(const char *s)
{
    long long n = 0;
    while (*s) {
        if (((unsigned char)*s & 0xC0) != 0x80)
            n++;
        s++;
    }
    return n;
}

/* 从 s 向后跳过 chars 个字符，返回落点指针 */
static const char *utf8_at(const char *s, long long chars)
{
    long long n = 0;
    while (*s) {
        if (((unsigned char)*s & 0xC0) != 0x80) {
            if (n == chars)
                break;          /* 已落在第 chars 个字符的首字节 */
            n++;
        }
        s++;                    /* 后续字节（含上一字符的 continuation）一律跳过 */
    }
    return s;
}

/* ---------- 列表公共辅助 ---------- */

static long long lib_list_len(Value list, const char *who)
{
    if (!IS_LIST(list))
        lib_die("%s 需要列表参数", who);
    return AS_INT(rt_len(list));
}

static int lib_is_num(Value v)
{
    return IS_INT(v) || IS_BIGINT(v) || IS_FLT(v) || IS_BOOL(v);
}

/* ================= te 文本模块 ================= */

Value rt_lib_te_split(Value textv, Value sepv)
{
    const char *s   = lib_str(textv, "te.split 第 1 个参数");
    const char *sep = lib_str(sepv,  "te.split 第 2 个参数");
    size_t seplen = strlen(sep);
    if (seplen == 0)
        lib_die("te.split 的分隔符不能为空");
    Value out = rt_list_new();
    const char *p = s;
    for (;;) {
        const char *hit = strstr(p, sep);
        if (hit == NULL) {
            rt_push(&out, rt_str(p));
            break;
        }
        rt_push(&out, lib_val_range(p, hit));
        p = hit + seplen;
    }
    return out;
}

Value rt_lib_te_replace(Value textv, Value oldv, Value newv)
{
    const char *s   = lib_str(textv, "te.replace 第 1 个参数");
    const char *old = lib_str(oldv,  "te.replace 第 2 个参数");
    const char *nw  = lib_str(newv,  "te.replace 第 3 个参数");
    size_t oldlen = strlen(old);
    if (oldlen == 0)
        lib_die("te.replace 的旧串不能为空");
    Buf b = {NULL, 0, 0};
    const char *p = s;
    for (;;) {
        const char *hit = strstr(p, old);
        if (hit == NULL)
            break;
        buf_put(&b, p, (size_t)(hit - p));
        buf_puts(&b, nw);
        p = hit + oldlen;
    }
    buf_puts(&b, p);
    Value v = rt_str(b.p ? b.p : "");
    free(b.p);
    return v;
}

Value rt_lib_te_trim(Value textv)
{
    const char *s = lib_str(textv, "te.trim");
    const char *WS_SET = " \t\r\n\v\f";
    size_t lead = strspn(s, WS_SET);
    size_t len = strlen(s);
    while (len > lead && strchr(WS_SET, s[len - 1]) != NULL)
        len--;
    return lib_val_range(s + lead, s + len);
}

Value rt_lib_te_upper(Value textv)
{
    const char *s = lib_str(textv, "te.upper");
    char *tmp = (char *)malloc(strlen(s) + 1);
    if (tmp == NULL)
        lib_die("内存不足");
    for (size_t i = 0; s[i]; i++) {
        unsigned char c = (unsigned char)s[i];
        tmp[i] = (char)((c >= 'a' && c <= 'z') ? c - 'a' + 'A' : c);
    }
    tmp[strlen(s)] = '\0';
    Value v = rt_str(tmp);
    free(tmp);
    return v;
}

Value rt_lib_te_lower(Value textv)
{
    const char *s = lib_str(textv, "te.lower");
    char *tmp = (char *)malloc(strlen(s) + 1);
    if (tmp == NULL)
        lib_die("内存不足");
    for (size_t i = 0; s[i]; i++) {
        unsigned char c = (unsigned char)s[i];
        tmp[i] = (char)((c >= 'A' && c <= 'Z') ? c - 'A' + 'a' : c);
    }
    tmp[strlen(s)] = '\0';
    Value v = rt_str(tmp);
    free(tmp);
    return v;
}

Value rt_lib_te_has(Value textv, Value subv)
{
    const char *s   = lib_str(textv, "te.has 第 1 个参数");
    const char *sub = lib_str(subv,  "te.has 第 2 个参数");
    return rt_bool(strstr(s, sub) != NULL);
}

Value rt_lib_te_len(Value textv)
{
    const char *s = lib_str(textv, "te.len");
    return rt_int(utf8_count(s));
}

Value rt_lib_te_cut(Value textv, Value startv, Value stopv)
{
    const char *s   = lib_str(textv, "te.cut 第 1 个参数");
    long long start = lib_ll(startv, "te.cut 第 2 个参数");
    long long stop  = lib_ll(stopv,  "te.cut 第 3 个参数");
    long long total = utf8_count(s);
    if (start < 0 || stop < start || stop > total)
        lib_die("te.cut 范围越界：文本共 %lld 字，要求 [%lld, %lld)",
                total, start, stop);
    const char *a = utf8_at(s, start);
    const char *b = utf8_at(a, stop - start);
    return lib_val_range(a, b);
}

Value rt_lib_te_join(Value listv, Value sepv)
{
    long long n     = lib_list_len(listv, "te.join 第 1 个参数");
    const char *sep = lib_str(sepv, "te.join 第 2 个参数");
    Buf b = {NULL, 0, 0};
    for (long long i = 0; i < n; i++) {
        if (i > 0)
            buf_puts(&b, sep);
        buf_puts(&b, rt_str_of(rt_index(listv, rt_int(i))));
    }
    Value v = rt_str(b.p ? b.p : "");
    free(b.p);
    return v;
}

/* te.chr(码点) → 一个字符的文本（UTF-8 编码）。
   这是 PYbook 字符串**没有转义序列**的唯一出口：
   te.chr(10) 换行、te.chr(13) 回车 —— 源码里写 "\n" 只会得到两个字符。
   码点按标准 UTF-8 编码（1~4 字节），所以 te.chr(20013) 就是"中"。 */
Value rt_lib_te_chr(Value nv)
{
    long long cp = (long long)lib_num(nv, "te.chr 的码点");
    if (cp < 0 || cp > 0x10FFFF)
        lib_die("te.chr：码点要在 0~%lld 之间", (long long)0x10FFFF);
    if (cp >= 0xD800 && cp <= 0xDFFF)
        lib_die("te.chr：0xD800~0xDFFF 是 UTF-16 代理区，不是有效码点");
    char buf[5];
    int k;
    if (cp < 0x80) {
        buf[0] = (char)cp;
        k = 1;
    } else if (cp < 0x800) {
        buf[0] = (char)(0xC0 | (cp >> 6));
        buf[1] = (char)(0x80 | (cp & 0x3F));
        k = 2;
    } else if (cp < 0x10000) {
        buf[0] = (char)(0xE0 | (cp >> 12));
        buf[1] = (char)(0x80 | ((cp >> 6) & 0x3F));
        buf[2] = (char)(0x80 | (cp & 0x3F));
        k = 3;
    } else {
        buf[0] = (char)(0xF0 | (cp >> 18));
        buf[1] = (char)(0x80 | ((cp >> 12) & 0x3F));
        buf[2] = (char)(0x80 | ((cp >> 6) & 0x3F));
        buf[3] = (char)(0x80 | (cp & 0x3F));
        k = 4;
    }
    buf[k] = '\0';
    return rt_str(buf);
}

/* ================= mt 数学模块 ================= */

Value rt_lib_mt_sqrt(Value n)
{
    double x = lib_num(n, "mt.sqrt");
    if (x < 0)
        lib_die("mt.sqrt：负数没有平方根");
    return rt_float(sqrt(x));
}

Value rt_lib_mt_pow(Value basev, Value expv)
{
    double b = lib_num(basev, "mt.pow 第 1 个参数");
    double e = lib_num(expv,  "mt.pow 第 2 个参数");
    return rt_float(pow(b, e));
}

Value rt_lib_mt_abs(Value n)
{
    if (IS_INT(n)) {
        if (AS_INT(n) < 0) {
            if (AS_INT(n) == LLONG_MIN)
                lib_die("溢出");
            return rt_int(-AS_INT(n));
        }
        return rt_int(AS_INT(n));
    }
    if (IS_FLT(n))
        return rt_float(fabs(AS_FLT(n)));
    if (IS_BOOL(n))
        return rt_int(AS_BOOL(n));
    lib_die("mt.abs 需要数字参数");
    return rt_none();
}

static long long lib_round_to_ll(double x, const char *who)
{
    if (!(x > -9.3e18 && x < 9.3e18))
        lib_die("%s：结果超出整数范围", who);
    return (long long)x;
}

Value rt_lib_mt_ceil(Value n)
{
    return rt_int(lib_round_to_ll(ceil(lib_num(n, "mt.ceil")), "mt.ceil"));
}

Value rt_lib_mt_floor(Value n)
{
    return rt_int(lib_round_to_ll(floor(lib_num(n, "mt.floor")), "mt.floor"));
}

Value rt_lib_mt_mod(Value a, Value b)
{
    return rt_mod(a, b);              /* 复用运行时：Python 语义 + 除零检查 */
}

/* 数字列表的三种折叠：kind 0=max 1=min 2=prod，max/min 返回原元素 */
static Value lib_list_fold(Value listv, const char *who, int kind)
{
    long long n = lib_list_len(listv, who);
    if (n == 0) {
        if (kind == 3)
            return rt_int(0);            /* 空列表求和 = 0 */
        lib_die("%s：空列表", who);
    }
    Value acc = (kind == 3) ? rt_int(0) : rt_index(listv, rt_int(0));
    if (!lib_is_num(acc))
        lib_die("%s：列表元素必须全是数字", who);
    for (long long i = (kind == 3) ? 0 : 1; i < n; i++) {
        Value cur = rt_index(listv, rt_int(i));
        if (!lib_is_num(cur))
            lib_die("%s：列表元素必须全是数字", who);
        if (kind == 2) {
            acc = rt_mul(acc, cur);
        } else if (kind == 3) {
            acc = rt_add(acc, cur);
        } else {
            int cur_bigger = (AS_BOOL(rt_gt(cur, acc)) != 0);
            if (kind == 0 ? cur_bigger : !cur_bigger)
                acc = cur;
        }
    }
    return acc;
}

Value rt_lib_mt_max(Value list)  { return lib_list_fold(list, "mt.max", 0); }
Value rt_lib_mt_min(Value list)  { return lib_list_fold(list, "mt.min", 1); }
Value rt_lib_mt_prod(Value list) { return lib_list_fold(list, "mt.prod", 2); }

Value rt_lib_mt_sum(Value list)  { return lib_list_fold(list, "mt.sum", 3); }

Value rt_lib_mt_sin(Value a) { return rt_float(sin(lib_num(a, "mt.sin"))); }
Value rt_lib_mt_cos(Value a) { return rt_float(cos(lib_num(a, "mt.cos"))); }
Value rt_lib_mt_tan(Value a) { return rt_float(tan(lib_num(a, "mt.tan"))); }

Value rt_lib_mt_lerp(Value av, Value bv, Value tv)
{
    double a = lib_num(av, "mt.lerp 第 1 个参数");
    double b = lib_num(bv, "mt.lerp 第 2 个参数");
    double t = lib_num(tv, "mt.lerp 第 3 个参数");
    return rt_float(a + (b - a) * t);
}

Value rt_lib_mt_dist(Value x1v, Value y1v, Value x2v, Value y2v)
{
    double dx = lib_num(x2v, "mt.dist 的 x2") - lib_num(x1v, "mt.dist 的 x1");
    double dy = lib_num(y2v, "mt.dist 的 y2") - lib_num(y1v, "mt.dist 的 y1");
    return rt_float(sqrt(dx * dx + dy * dy));
}

Value rt_lib_mt_clamp(Value vv, Value lov, Value hiv)
{
    if (IS_INT(vv) && IS_INT(lov) && IS_INT(hiv)) {
        long long v = AS_INT(vv), lo = AS_INT(lov), hi = AS_INT(hiv);
        if (lo > hi)
            lib_die("mt.clamp：下限大于上限");
        return rt_int(v < lo ? lo : (v > hi ? hi : v));
    }
    {
        double v = lib_num(vv, "mt.clamp 的值");
        double lo = lib_num(lov, "mt.clamp 的下限");
        double hi = lib_num(hiv, "mt.clamp 的上限");
        if (lo > hi)
            lib_die("mt.clamp：下限大于上限");
        return rt_float(v < lo ? lo : (v > hi ? hi : v));
    }
}

Value rt_lib_mt_pi(void) { return rt_float(3.14159265358979); }

/* ================= rd 随机模块 ================= */

static int g_rd_seeded = 0;

/* 随机源统一到 mathplus.c 的 xorshift128（mp_rand_u01）。
 * 原来 rd.* 走 C 的 rand() 且只播种一次 time(NULL)，实测有三个问题：
 *   1. rd.float() 只调一次 rand()，而 MinGW 的 RAND_MAX 就是 32767 ——
 *      20 万次采样只有 32693 个不同取值，最大只到 0.999969482421875，
 *      也就是 15 位有效精度而不是 double 的 53 位。
 *   2. 没有 rd.seed，测试写不出可复现的随机序列。
 *   3. mp.rand_* 走的是另一套 xorshift128，mp.rand_seed(42) 对 rd.int 毫无影响。
 * 现在一次播种，rd.* 与 mp.rand_* 一起变。 */
static void rd_seed(void)
{
    if (!g_rd_seeded) {
        mp_rand_seed((uint64_t)time(NULL));
        g_rd_seeded = 1;
    }
}

/* 显式播种。走同一个 xorshift128，所以 rd.seed(42) 之后
 * rd.* 与 mp.rand_* 都是同一条可复现序列。 */
Value rt_lib_rd_seed(Value s)
{
    if (!IS_INT(s) && !IS_BIGINT(s))
        lib_die("rd.seed 需要整数种子");
    mp_rand_seed((uint64_t)rt_to_ll(s));
    g_rd_seeded = 1;              /* 别让紧接着的 rd_seed() 又用时间覆盖掉 */
    return rt_none();
}

/* [0, range) 的随机整数（range >= 1）。
 * 原来是 ((rand()<<31)|rand()) % range —— 取模偏差，且 rand() 上限只有 32767。
 * 现在用满 53 位的 mp_rand_u01() 缩放：range <= 2^53 时偏差可忽略。 */
static long long rd_below(long long range)
{
    return (long long)(mp_rand_u01() * (double)range);
}

Value rt_lib_rd_int(Value lov, Value hiv)
{
    long long lo = lib_ll(lov, "rd.int 第 1 个参数");
    long long hi = lib_ll(hiv, "rd.int 第 2 个参数");
    if (lo > hi)
        lib_die("rd.int 的起（%lld）不能大于止（%lld）", lo, hi);
    rd_seed();
    long long span = hi - lo;                            /* 负区间（如 -100..100）合法 */
    if (span > 100000000LL)
        lib_die("rd.int：范围过大");
    return rt_int(lo + rd_below(span + 1));   /* 含两端 */
}

/* [0,1) 随机浮点，满 53 位有效精度。
 * 原来是 rand() / (RAND_MAX + 1.0)，而 MinGW 的 RAND_MAX = 32767 ——
 * 取值上限只有 0.999969482421875，只有 32768 个不同取值。 */
Value rt_lib_rd_float(void)
{
    rd_seed();
    return rt_float(mp_rand_u01());
}

Value rt_lib_rd_pick(Value list)
{
    long long n = lib_list_len(list, "rd.pick");
    if (n == 0)
        lib_die("rd.pick：空列表");
    rd_seed();
    return rt_index(list, rt_int(rd_below(n)));
}

Value rt_lib_rd_shuffle(Value list)
{
    long long n = lib_list_len(list, "rd.shuffle");
    rd_seed();
    for (long long i = n - 1; i > 0; i--) {   /* Fisher-Yates 原地打乱 */
        long long j = rd_below(i + 1);
        if (i == j)
            continue;
        Value vi = rt_index(list, rt_int(i));
        Value vj = rt_index(list, rt_int(j));
        rt_setindex(&list, rt_int(i), vj);
        rt_setindex(&list, rt_int(j), vi);
    }
    return rt_none();
}

Value rt_lib_mt_atan2(Value y, Value x)
{
    return rt_float(atan2(lib_num(y, "mt.atan2 的 y"), lib_num(x, "mt.atan2 的 x")));
}

/* ================= mt 基础数学补齐（exp/log 族、反三角、双曲、符号与特判）=================
 * 起因是实测摸底：v2.0 的 mt.* 只有 sqrt/pow/abs/ceil/floor/mod/pi + sin/cos/tan/atan2，
 * **全库连 exp 和 log 都没有**，反三角只剩 atan2，双曲一个没有。
 * sin/cos/tan 有了但反过来求不出来、指数与对数两条最基本的非线性变换缺席，
 * softmax / log-loss / 数据标准化都得手写级数展开，这是实打实的缺口。
 *
 * 域外输入一律 rt_die 报三段式，不静默返回 NaN：宁可报错，也不要让一个 NaN
 * 顺着后面的运算一路污染下去，到最后看不出是哪一步出的问题（与 tb.cholesky 同一条原则）。
 */

/* 对数族定义域检查：x>0。lib_num 已先做过类型检查，这里只管定义域。
 * 刻意不静默返回 NaN —— 一个 NaN 顺着后面的运算流下去，最后根本看不出是哪一步出的问题。 */
static double lib_log_arg(double x, const char *who)
{
    if (!(x > 0.0))
        rt_die("%s 的定义域是 (0, +∞)，收到 %g\n"
               "  为什么：对数在非正数处没有实数定义，返回 NaN 只会把错误带到后面几步\n"
               "  怎么改：先确认入参为正；x 本身很小但 1+x 为正时，改用 mt.log1p（算的是 log(1+x)）",
               who, x);
    return x;
}

Value rt_lib_mt_exp(Value a)
{
    return rt_float(exp(lib_num(a, "mt.exp")));
}

Value rt_lib_mt_expm1(Value a)
{
    return rt_float(expm1(lib_num(a, "mt.expm1")));
}

Value rt_lib_mt_log(Value a)
{
    double x = lib_num(a, "mt.log");
    return rt_float(log(lib_log_arg(x, "mt.log")));
}

Value rt_lib_mt_log2(Value a)
{
    double x = lib_num(a, "mt.log2");
    return rt_float(log2(lib_log_arg(x, "mt.log2")));
}

Value rt_lib_mt_log10(Value a)
{
    double x = lib_num(a, "mt.log10");
    return rt_float(log10(lib_log_arg(x, "mt.log10")));
}

/* log1p 算 log(1+x)：x 极小时（1+x 在 double 里已经等于 1，直接算 log 会得 0）用这个 */
Value rt_lib_mt_log1p(Value a)
{
    double x = lib_num(a, "mt.log1p");
    if (!(x > -1.0))
        rt_die("mt.log1p 的定义域是 (-1, +∞)，收到 %g\n"
               "  为什么：log(1+x) 在 x<=-1 处没有实数定义\n"
               "  怎么改：确认 1+x 为正；x 很小是正常的，那正是该用 log1p 而不是 log 的场合", x);
    return rt_float(log1p(x));
}

/* 反三角：实数定义域都是 [-1,1] */
static double lib_unit(double x, const char *who)
{
    if (!(x >= -1.0 && x <= 1.0))
        rt_die("%s 的定义域是 [-1, 1]，收到 %g\n"
               "  为什么：这个角的正弦/余弦不可能超出 ±1，域外返回 NaN 是无意义的\n"
               "  怎么改：先确认入参；若本意是「两个数求夹角」，用 mt.atan2(y, x)", who, x);
    return x;
}

Value rt_lib_mt_asin(Value a)
{
    return rt_float(asin(lib_unit(lib_num(a, "mt.asin"), "mt.asin")));
}

Value rt_lib_mt_acos(Value a)
{
    return rt_float(acos(lib_unit(lib_num(a, "mt.acos"), "mt.acos")));
}

Value rt_lib_mt_atan(Value a)
{
    return rt_float(atan(lib_num(a, "mt.atan")));
}

/* 双曲及其反函数。acosh 要 >=1，atanh 要在 (-1,1) 内 */
Value rt_lib_mt_sinh(Value a) { return rt_float(sinh(lib_num(a, "mt.sinh"))); }
Value rt_lib_mt_cosh(Value a) { return rt_float(cosh(lib_num(a, "mt.cosh"))); }
Value rt_lib_mt_tanh(Value a) { return rt_float(tanh(lib_num(a, "mt.tanh"))); }
Value rt_lib_mt_asinh(Value a){ return rt_float(asinh(lib_num(a, "mt.asinh"))); }

Value rt_lib_mt_acosh(Value a)
{
    double x = lib_num(a, "mt.acosh");
    if (!(x >= 1.0))
        rt_die("mt.acosh 的定义域是 [1, +∞)，收到 %g\n"
               "  为什么：cosh 的值恒 >=1，小于 1 的输入没有实数解\n"
               "  怎么改：确认入参；计算 log(x + sqrt(x*x-1)) 时也要先保证 x>=1", x);
    return rt_float(acosh(x));
}

Value rt_lib_mt_atanh(Value a)
{
    double x = lib_num(a, "mt.atanh");
    if (!(x > -1.0 && x < 1.0))
        rt_die("mt.atanh 的定义域是 (-1, 1)，收到 %g\n"
               "  为什么：|tanh| 恒小于 1，域外发散\n"
               "  怎么改：确认入参；x 接近 ±1 时结果会非常大，属正常", x);
    return rt_float(atanh(x));
}

/* cbrt：立方根，负数也有意义；pow(x, 1/3) 对负数会得到 NaN（那是复数分支） */
Value rt_lib_mt_cbrt(Value a)
{
    return rt_float(cbrt(lib_num(a, "mt.cbrt")));
}

/* hypot：√(x²+y²)。直接写 mt.sqrt(x*x + y*y) 在 x、y 很大时会先溢出成 inf */
Value rt_lib_mt_hypot(Value a, Value b)
{
    return rt_float(hypot(lib_num(a, "mt.hypot 的 x"), lib_num(b, "mt.hypot 的 y")));
}

/* trunc 截断取整：跟 floor/ceil 一样返回整数，只是向零取 */
Value rt_lib_mt_trunc(Value n)
{
    return rt_int(lib_round_to_ll(trunc(lib_num(n, "mt.trunc")), "mt.trunc"));
}

/* sign：-1 / 0 / 1，0 单独挑出来——不能直接写 (x>0)-(x<0) 后套 float，
 * 因为那样 0 会变成 -0.0，显示出来很难看 */
Value rt_lib_mt_sign(Value n)
{
    double x = lib_num(n, "mt.sign");
    if (x > 0.0) return rt_int(1);
    if (x < 0.0) return rt_int(-1);
    return rt_int(0);
}

/* fmod 截断取余，与 mt.mod 不同：mt.mod 是 Python 语义（向 -∞ 取整，结果可负），
 * fmod 是 C 语义（向 0 截断，结果符号跟被除数同号）。两者用错会差一个整数量级。 */
Value rt_lib_mt_fmod(Value a, Value b)
{
    double x = lib_num(a, "mt.fmod 的被除数");
    double y = lib_num(b, "mt.fmod 的除数");
    if (y == 0.0)
        rt_die("mt.fmod 的除数不能为 0\n"
               "  为什么：除零没有定义，C 的 fmod 在这里返回 NaN\n"
               "  怎么改：先判断除数是否非零");
    return rt_float(fmod(x, y));
}

/* 特殊值判定：分母、判别式、优化过程里 NaN/Inf 是最常见的污染源，
 * 能查出来就别等它一路流到结果上去 */
Value rt_lib_mt_is_nan(Value n)
{
    return rt_bool(isnan(lib_num(n, "mt.is_nan")));
}

Value rt_lib_mt_is_inf(Value n)
{
return rt_bool(isinf(lib_num(n, "mt.is_inf")));
}

/* ================= 数值微积分与求根（需要函数值回调）=================
 * 这批函数是「库函数回调用户 lambda」的这一批用户。之前做不到：
 * mec lambda 的分发函数 rt_mec_apply 由编译器生成进 out.c，不在 pyvm.exe 里，
 * 库函数链接期根本找不到它。现在运行时存了一个分发函数指针
 * （rt_set_fn_dispatch / rt_call1），用户程序在 main() 开头装进来。
 *
 * 步长 / 区间数 / 容差都做成可选参数（LIB_CALLS 里写成 (最少,最多)），
 * 用户没给时 codegen 补空盒，这里把空盒当「用缺省值」。
 */

/* 缺省参数的取值：空盒 = 用户没给 */
static double opt_num(Value v, double deflt, const char *who)
{
    if (IS_NONE(v)) return deflt;
    return lib_num(v, who);
}

/* 回调 f(x) 并取结果必须是数字。f 不是数字就报错 —— 求导/积分里 f 返回列表
   或文本是调用方的类型错误，静默当 0 会让结果完全错但看不出原因。 */
static double cb_num(Value fnval, double x, const char *who)
{
    Value r = rt_call1(fnval, rt_float(x));
    if (IS_FLT(r)) return AS_FLT(r);
    if (IS_INT(r) || IS_BIGINT(r)) return (double)rt_to_ll(r);
    if (IS_BOOL(r)) return AS_BOOL(r) ? 1.0 : 0.0;
    rt_die("%s：被调的函数在 %g 处没有返回数字（拿到 %s）\n"
           "  为什么：求导/积分靠的是对函数值做差商，函数值不是数就没有差商\n"
           "  怎么改：确认 lambda 的最后一句是 ret 一个数字", who, x,
           rt_q_typename ? rt_q_typename(r) : "非数字");
    return 0.0;
}

/* 中心差分。h <= 0 时自动取一个合适的缺省步长 */
static double deriv_core(Value fnval, double x, double h, const char *who)
{
    if (!(h > 0.0))
        h = 1e-5 * (fabs(x) > 1.0 ? fabs(x) : 1.0);
    if (h < x * 1e-12 || h < 1e-300)    /* x 附近再小步长就等于 x 了 */
        rt_die("%s：步长 %g 对 x=%g 来说太小\n"
               "  为什么：x+h 舍入后还是 x，差商会变成 0\n"
               "  怎么改：换一个显式步长，比如 mt.deriv(f, x, 0.01)", who, h, x);
    return (cb_num(fnval, x + h, who) - cb_num(fnval, x - h, who)) / (2.0 * h);
}

/* mt.deriv(f, x[, h]) —— 数值导数 */
Value rt_lib_mt_deriv(Value fnval, Value xv, Value hv)
{
    return rt_float(deriv_core(fnval, lib_num(xv, "mt.deriv 的 x"),
                              opt_num(hv, 0.0, "mt.deriv 的步长"), "mt.deriv"));
}

/* mt.integrate(f, a, b[, n]) —— 复合 Simpson */
Value rt_lib_mt_integrate(Value fnval, Value av, Value bv, Value nv)
{
    double a = lib_num(av, "mt.integrate 的下限");
    double b = lib_num(bv, "mt.integrate 的上限");
    long long n = (long long)opt_num(nv, 100.0, "mt.integrate 的区间数");
    double h, s;
    long long i;
    if (!(b > a))
        rt_die("mt.integrate：上限要大于下限（收到 a=%g, b=%g）\n"
               "  为什么：反向区间的定积分是负的，本函数按 [下限,上限] 处理\n"
               "  怎么改：把两个端点对调，或者自己在结果前面加负号", a, b);
    if (n < 2)
        rt_die("mt.integrate：区间数至少要 2（收到 %lld）\n"
               "  为什么：Simpson 每个区间用 3 个点，至少要 1 个区间\n"
               "  怎么改：给一个 >= 2 的区间数", n);
    if (n % 2) n++;                     /* Simpson 要求偶数个区间，补一个 */
    h = (b - a) / (double)n;
    s = cb_num(fnval, a, "mt.integrate") + cb_num(fnval, b, "mt.integrate");
    for (i = 1; i < n; i++) {
        double w = (i % 2) ? 4.0 : 2.0;
        s += w * cb_num(fnval, a + h * (double)i, "mt.integrate");
    }
    return rt_float(s * h / 3.0);
}

/* mt.root_bisect(f, a, b[, tol]) —— 二分法，要求端点异号 */
Value rt_lib_mt_root_bisect(Value fnval, Value av, Value bv, Value tolv)
{
    double a = lib_num(av, "mt.root_bisect 的左端");
    double b = lib_num(bv, "mt.root_bisect 的右端");
    double tol = opt_num(tolv, 1e-12, "mt.root_bisect 的容差");
    double fa, fb, m;
    int guard;
    if (!(a < b)) {
        if (b < a) { double t = a; a = b; b = t; }
        else rt_die("mt.root_bisect：两个端点不能相同（都是 %g）\n"
                    "  为什么：区间长度是 0，二分无从下手\n"
                    "  怎么改：给一个真正跨越根的区间", a);
    }
    if (!(tol > 0.0))
        rt_die("mt.root_bisect：容差要大于 0（收到 %g）\n"
               "  怎么改：写一个正数，比如 1e-10", tol);
    fa = cb_num(fnval, a, "mt.root_bisect");
    fb = cb_num(fnval, b, "mt.root_bisect");
    if (fa * fb > 0.0)
        rt_die("mt.root_bisect：区间 [%g, %g] 上两端同号（f(%g)=%g, f(%g)=%g），里面没有变号点\n"
               "  为什么：连续函数要在区间内有根，两端必须异号；同号时二分法收敛到的是错的点\n"
               "  怎么改：扩大区间直到两端异号；或者函数在区间内有偶数个根时改用 mt.root_newton\n"
               "        并给一个更靠近根的初值", a, b, a, fa, b, fb);
    /* 上面的 while 语义在这里写成显式循环，避免 C 的 do-while 把 fb 更新漏掉 */
    for (guard = 0; guard < 4096; guard++) {
        m = 0.5 * (a + b);
        if (b - a < tol || m == a || m == b) break;
        fa = cb_num(fnval, a, "mt.root_bisect");
        if (fa * cb_num(fnval, m, "mt.root_bisect") <= 0.0) b = m;
        else a = m;
    }
    return rt_float(0.5 * (a + b));
}

/* 牛顿法的共用主体；dfopt 为空盒时用中心差分估导数 */
static double newton_core(Value fnval, Value dfopt, double x0,
                          double tol, long long maxiter, const char *who)
{
    double x = x0, fx, dx;
    long long k;
    for (k = 0; k < maxiter; k++) {
        fx = cb_num(fnval, x, who);
        if (fabs(fx) < tol) return x;
        dx = IS_NONE(dfopt) ? deriv_core(fnval, x, 0.0, who)
                            : cb_num(dfopt, x, who);
        if (dx == 0.0)
            rt_die("%s：在 x=%g 处导数为 0，牛顿法没法往下走\n"
                   "  为什么：x_{n+1} = x_n - f/f'，除数为 0\n"
                   "  怎么改：换一个初值，或先用 mt.root_bisect 定位到导数不为 0 的一段", who, x);
        x -= fx / dx;
        if (isinf(x) || isnan(x))
            rt_die("%s：从初值 %g 出发迭代发散了（算到了非数）\n"
                   "  为什么：牛顿法只在根附近收敛，初值太远就会跳飞\n"
                   "  怎么改：换一个更靠近根的初值，或改用 mt.root_bisect（要求两端异号但全局稳）", x0);
    }
    rt_die("%s：从 %g 迭代 %lld 次仍没收敛\n"
           "  为什么：牛顿法只在根附近收敛\n"
           "  怎么改：给更近的初值，或改用 mt.root_bisect", who, x0, maxiter);
    return x;
}

/* mt.root_newton(f, x0[, tol[, 最多步数]]) —— 导数用中心差分估 */
Value rt_lib_mt_root_newton(Value fnval, Value x0v, Value tolv, Value maxv)
{
    return rt_float(newton_core(fnval, rt_none(),
                                lib_num(x0v, "mt.root_newton 的初值"),
                                opt_num(tolv, 1e-12, "mt.root_newton 的容差"),
                                (long long)opt_num(maxv, 100.0, "mt.root_newton 的最多步数"),
                                "mt.root_newton"));
}

/* mt.root_newton_d(f, df, x0[, tol[, 最多步数]]) —— 用解析导数，更快更准 */
Value rt_lib_mt_root_newton_d(Value fnval, Value dfv, Value x0v,
                              Value tolv, Value maxv)
{
    return rt_float(newton_core(fnval, dfv,
                                lib_num(x0v, "mt.root_newton_d 的初值"),
                                opt_num(tolv, 1e-12, "mt.root_newton_d 的容差"),
                                (long long)opt_num(maxv, 100.0, "mt.root_newton_d 的最多步数"),
                                "mt.root_newton_d"));
}

/* mt.taylor(f, x, n) —— x 处的前 n 项泰勒展开系数（0..n-1 阶导数 / k!） */
Value rt_lib_mt_taylor(Value fnval, Value xv, Value nv)
{
    double x = lib_num(xv, "mt.taylor 的 x");
    long long n = (long long)lib_num(nv, "mt.taylor 的阶数"), k;
    double fact = 1.0;
    Value out = rt_list_new();
    if (n < 1)
        rt_die("mt.taylor：阶数至少要 1（收到 %lld）\n"
               "  为什么：0 阶就是函数值本身，不需要展开\n"
               "  怎么改：给一个 >= 1 的阶数", n);
    rt_push(&out, rt_float(cb_num(fnval, x, "mt.taylor")));
    for (k = 1; k < n; k++) {
        fact *= (double)k;
        rt_push(&out, rt_float(deriv_core(fnval, x, 0.0, "mt.taylor") / fact));
    }
    return out;
}

Value rt_lib_te_str(Value v)
{
    return rt_str(rt_str_of(v));   /* 数字/布尔/字符串统一转文本盒 */
}


/* ================= 特殊函数：gamma / lgamma / erf / erfc / zeta =================
 *
 * 这五个是真正「没有就写不出东西」的一档：正态分布的 CDF 要 erf，
 * 阶乘要 gamma，狄利克雷卷积、贝塞尔积分、Zeta 分布都要 gamma；
 * 解析数论和级数求和则离不开 zeta。它们都不是「C 标准库顺手就有」的东西
 * —— <math.h> 里只有 lgamma 一个，erf 在 MinGW 上要 C99 才给。
 *
 * 精度上刻意不做「够用就行」的近似：
 *   - gamma / lgamma 用 Lanczos g=7 的 9 项有理式，相对误差 ~1e-15；
 *     lgamma 走同一条级数取对数，而不是用 lgamma() 也不该信的老近似。
 *   - erf / erfc 走**不完全 gamma**（a=1/2）而不是那张误差 1.5e-7 的
 *     Abramowitz-Stegun 表 —— 7 位有效数字在拟合/统计里是会出事的。
 *   - zeta 用 Euler-Maclaurin，尾部展开到 6 项。
 * ------------------------------------------------------------------------- */

#define LIB_PI 3.14159265358979323846

/* Lanczos g=7 的 9 个系数（Gamma 函数的经典有理逼近） */
static const double LG7[9] = {
    0.99999999999980993, 676.5203681218851,   -1259.1392167224028,
    771.32342877765313,  -176.61502916214059, 12.507343278686905,
    -0.13857109526572012, 9.9843695780195716e-6, 1.5056327351493116e-7
};

/* 同一条级数的值：x = c0 + c1/(z) + c2/(z+1) + …（z > 0） */
static double lanczos_x(double z)
{
    double x = LG7[0];
    int    i;
    for (i = 1; i < 9; i++) x += LG7[i] / (z + i - 1.0);
    return x;
}

double lib_gamma(double z)                 /* Γ(z)，z 为负整数以外的任意实 */
{
    /* 那个 exp(-t) 是这条公式不可少的一半：
     *   Γ(z) = √(2π) · t^(z-1/2) · e^(-t) · A(z)，t = z + g - 1/2
     * 少了它，Γ(1) 会给出 1808 而不是 1（正好差一个 e^7.5）。 */
    if (z > 0.0) {
        double t = z + 7.0 - 0.5;
        return sqrt(2.0 * LIB_PI) * pow(t, z - 0.5) * exp(-t) * lanczos_x(z);
    }
    /* z <= 0：反射公式 Γ(z)Γ(1−z) = π/sin(πz) */
    {
        double s = sin(LIB_PI * z);
        if (s == 0.0) return 0.0 / 0.0;   /* 极点 */
        return LIB_PI / (s * lib_gamma(1.0 - z));
    }
}

double lib_lgamma(double z)                /* log|Γ(z)| */
{
    if (z > 0.0) {
        double t = z + 7.0 - 0.5;
        return 0.5 * log(2.0 * LIB_PI) + (z - 0.5) * log(t) - t + log(lanczos_x(z));
    }
    {
        double s = sin(LIB_PI * z);
        if (s == 0.0) return 1.0 / 0.0;   /* 极点 */
        return log(LIB_PI / fabs(s)) - lib_lgamma(1.0 - z);
    }
}

/* ---- 不完全 gamma：P(a,x) 用级数，Q(a,x) 用连分数（Numerical Recipes 的标准分法） ---- */

static double ig_series(double a, double x)
{
    double ap, sum, del;
    int    n;
    if (x == 0.0) return 0.0;       /* P(a,0)=0；不短路的话下面 log(0) 会炸 */
    ap = a; sum = 1.0 / a; del = sum;
    for (n = 1; n <= 1000; n++) {
        ap += 1.0;
        del *= x / ap;
        sum += del;
        if (fabs(del) <= fabs(sum) * 1e-16) break;
    }
    return sum * exp(-x + a * log(x) - lib_lgamma(a));
}

static double ig_cfrac(double a, double x)
{
    const double tiny = 1e-300;
    double b = x + 1.0 - a, c = 1.0 / tiny, d = 1.0 / b, h = d;
    int    i;
    for (i = 1; i <= 1000; i++) {
        double an = -(double)i * ((double)i - a);
        double del;
        b += 2.0;
        d = an * d + b; if (fabs(d) < tiny) d = tiny;
        c = b + an / c;  if (fabs(c) < tiny) c = tiny;
        d = 1.0 / d;
        del = d * c;
        h *= del;
        if (fabs(del - 1.0) <= 1e-16) break;
    }
    return exp(-x + a * log(x) - lib_lgamma(a)) * h;
}

double lib_gammap(double a, double x)       /* P(a,x) = γ(a,x)/Γ(a) */
{
    if (x < 0.0 || a <= 0.0) return 0.0 / 0.0;
    if (x < a + 1.0) return ig_series(a, x);
    return 1.0 - ig_cfrac(a, x);
}

/* erf / erfc —— 都是不完全 gamma 在 a=1/2 上的特例 */
double lib_erf(double x)
{
    double p = lib_gammap(0.5, x * x);
    return (x < 0.0) ? -p : p;
}

/* Q(a,x) = 1 - P(a,x)。大 x 下**必须用连分数直接算**：写成 1 - P(0.5,x²) 时，
 * P 被算成 1 - CF，再取一次补就是 1 - (1 - CF)，浮点里 CF 一旦小于 1e-17 就整个归零。
 * 实测那样写 erfc(6) 的相对误差是 4.65e16。 */
double lib_gammq(double a, double x)
{
    if (x < 0.0 || a <= 0.0) return 0.0 / 0.0;
    if (x < a + 1.0) return 1.0 - ig_series(a, x);   /* 这里 Q≈1，取补只丢绝对精度 */
    return ig_cfrac(a, x);
}

double lib_erfc(double x)
{
    double q = lib_gammq(0.5, x * x);
    return (x < 0.0) ? 2.0 - q : q;   /* erfc(-x) = 2 - erfc(x) */
}

Value rt_lib_mt_erf(Value x)
{
    return rt_float(lib_erf(lib_num(x, "mt.erf 的 x")));
}

Value rt_lib_mt_erfc(Value x)
{
    return rt_float(lib_erfc(lib_num(x, "mt.erfc 的 x")));
}

Value rt_lib_mt_gamma(Value x)
{
    return rt_float(lib_gamma(lib_num(x, "mt.gamma 的 x")));
}

Value rt_lib_mt_lgamma(Value x)
{
    return rt_float(lib_lgamma(lib_num(x, "mt.lgamma 的 x")));
}

/* Riemann ζ(s)：Euler-Maclaurin，尾部展开到 6 项。
 * s <= 1 是发散点，直接报「无定义」而不是给一个 ±inf 让用户自己猜。 */
double lib_zeta(double s)
{
    static const double BF[6] = {         /* B_{2k}/(2k)! */
        1.0 / 12.0, -1.0 / 720.0, 1.0 / 30240.0,
        -1.0 / 1209600.0, 1.0 / 47900160.0, -691.0 / 1307674368000.0
    };
    int    N, k, i;
    double sum = 0.0, t, ps;

    if (s <= 1.0) return 0.0 / 0.0;       /* 发散 */

    /* s 越靠近 1，N/(s−1) 那项越突出，级数要求越大的 N */
    N = (int)(10.0 / (s - 1.0) + 16.0);
    if (N < 20) N = 20;
    if (N > 4000000) N = 4000000;

    for (i = 1; i < N; i++) sum += pow((double)i, -s);

    t = pow((double)N, -s);
    sum += 0.5 * t + t * (double)N / (s - 1.0);

    /* 修正项：B_{2k+2}/(2k+2)! · (s)_(2k+1) · N^(−s−2k−1)
     * 上升阶乘从 (s)_1 = s 起步，每步乘 (s+2k−1)(s+2k) 递到 (s)_(2k+1)。
     * 原来写成 t·BF[k]·ps/N^(2k)，N 的幂整整差了 1（少乘一个 N），
     * 而且阶乘步进乘的是 (s+2k−2)(s+2k−1)，k=1 时得 s²(s+1) 而不是 s(s+1)(s+2)。
     * 两处一起让 ζ(2) 的相对误差停在 1.4e-4；改对之后是 1.9e-17。 */
    ps = s;
    for (k = 0; k < 6; k++) {
        if (k > 0)
            for (i = 0; i < 2; i++) ps *= (s + 2.0 * k - 1.0 + i);
        sum += BF[k] * ps * pow((double)N, -s - 2.0 * k - 1.0);
    }
    return sum;
}

Value rt_lib_mt_zeta(Value s)
{
    double sv = lib_num(s, "mt.zeta 的 s");
    if (sv <= 1.0)
        lib_die("mt.zeta：s=%g 处级数发散\n"
                "  为什么：ζ(s)=Σ n^(−s) 只有 s>1 才收敛，s=1 是调和级数\n"
                "  怎么改：换个 s>1；要做 s<1 的解析延拓请显式指定你要的是哪一个分支", sv);
    return rt_float(lib_zeta(sv));
}

/* ================= 一维极值：黄金分割搜索 =================
 * 为什么不直接牛顿：极值点处导数为 0，牛顿的分母为零、方向也乱。
 * 黄金分割对「单峰/单谷」函数无条件收敛，慢一点但**不依赖梯度**——
 * 用户手上往往只有一个 f，没有 f'。 */

#define GOLD_R 0.61803398874989484820      /* (√5−1)/2 */

static double golden_core(Value fnval, double a, double b,
                          int want_max, double tol, const char *who)
{
    int    it, maxit = 200;
    double c, d, fc, fd, best_x, best_f;

    if (!(a < b)) {
        double t = a; a = b; b = t;
    }
    c = b - GOLD_R * (b - a);
    d = a + GOLD_R * (b - a);
    fc = cb_num(fnval, c, who);
    fd = cb_num(fnval, d, who);
    best_x = (fc <= fd) ? c : d;
    best_f = (fc <= fd) ? fc : fd;

    for (it = 0; it < maxit && (b - a) > tol; it++) {
        if (want_max ? (fc < fd) : (fc > fd)) {
            a = c; c = d; fc = fd;
            d = a + GOLD_R * (b - a);
            fd = cb_num(fnval, d, who);
            if (want_max ? (fd > best_f) : (fd < best_f)) { best_f = fd; best_x = d; }
        } else {
            b = d; d = c; fd = fc;
            c = b - GOLD_R * (b - a);
            fc = cb_num(fnval, c, who);
            if (want_max ? (fc > best_f) : (fc < best_f)) { best_f = fc; best_x = c; }
        }
    }
    /* 中点通常比记住的那个内部点更好，两边都看一眼 */
    {
        double mid = 0.5 * (a + b);
        double fm  = cb_num(fnval, mid, who);
        if (want_max ? (fm > best_f) : (fm < best_f)) { best_f = fm; best_x = mid; }
    }
    return best_x;
}

/* mt.golden_min(f, a, b[, tol]) —— [a,b] 上找 f 的极小值点 */
Value rt_lib_mt_golden_min(Value fnval, Value av, Value bv, Value tolv)
{
    return rt_float(golden_core(fnval,
                                lib_num(av, "mt.golden_min 的左端点"),
                                lib_num(bv, "mt.golden_min 的右端点"),
                                0,
                                opt_num(tolv, 1e-10, "mt.golden_min 的容差"),
                                "mt.golden_min"));
}

/* mt.golden_max(f, a, b[, tol]) —— [a,b] 上找 f 的极大值点 */
Value rt_lib_mt_golden_max(Value fnval, Value av, Value bv, Value tolv)
{
    return rt_float(golden_core(fnval,
                                lib_num(av, "mt.golden_max 的左端点"),
                                lib_num(bv, "mt.golden_max 的右端点"),
                                1,
                                opt_num(tolv, 1e-10, "mt.golden_max 的容差"),
                                "mt.golden_max"));
}

/* ================= 插值与拟合 =================
 * 采样点(xs, ys) **必须严格递增**。这一点反复踩：二分查找找不到区间时会静默
 * 取端点插值，插出一段看着平滑、其实完全错误的曲线。所以这里显式报错，
 * 并把第一个逆序的下标算给你看。 */

static double *lib_unpack(Value v, long long *out_n, const char *who)
{
    long long n, i;
    double *a;
    if (!IS_LIST(v))
        lib_die("%s 需要列表参数", who);
    n = AS_INT(rt_len(v));      /* rt_len 返回的是盒子，必须 AS_INT 拆出来；
                                * 漏了这步 n 是垃圾值，malloc 直接失败 */
    if (n < 1) lib_die("%s：空列表", who);
    a = (double *)malloc((size_t)n * sizeof(double));
    if (!a) lib_die("%s 内存不足", who);
    for (i = 0; i < n; i++) a[i] = lib_num(rt_index(v, rt_int(i)), who);
    *out_n = n;
    return a;
}

static void lib_check_sorted(const double *x, long long n, const char *who)
{
    long long i;
    for (i = 1; i < n; i++)
        if (!(x[i] > x[i - 1]))
            lib_die("%s：采样点必须严格递增，第 %lld 个是 %g、上一个是 %g\n"
                    "  为什么：插值靠二分找区间；点序乱了会静默插到错误的段上，"
                    "出来的曲线看着平滑、其实是错的\n"
                    "  怎么改：先把 x 排好序再传进来（mp.sorted 那类），或按同一顺序重排 y",
                    who, i, x[i], x[i - 1]);
}

/* 找 x 落在哪一段：返回 i 使得 x[i] <= q < x[i+1]。
 * 越界的返回值由调用方决定是夹取还是外推（这里两种插值都选夹取，
 * 与 numpy.interp 一致；末段线性外推会把 99 处的查询算成 489）。
 *
 * 循环不变量：x[lo] <= q < x[hi]，所以 hi 初始化成 **n-1**（不是 n-2）。
 * hi 一开始写成 n-2（误当成末段下标）时，mid=n-2 那一次永远不会被取到，
 * 于是**最后一段永远返回 n-3**：查 2.75 落在 [2,3] 却被判成 [1,2]，
 * 线性插值在 x=[0,1,2,3] 上算 2.5 得到 5.5 而不是 6.5。 */
static long long lib_locate(const double *x, long long n, double q)
{
    long long lo = 0, hi = n - 1, mid;
    if (n < 2) return 0;
    if (q <= x[0])   return 0;
    if (q >= x[n - 1]) return n - 2;
    while (hi - lo > 1) {
        mid = (lo + hi) / 2;
        if (x[mid] <= q) lo = mid; else hi = mid;
    }
    return lo;
}

double mp_interp_linear_core(const double *x, const double *y, long long n, double q)
{
    long long i;
    double    t;
    if (n < 2) return y[0];        /* 一个点插不出线，直接给该点的值 */
    if (q <= x[0])     return y[0];            /* 越界夹取，不外推 */
    if (q >= x[n - 1]) return y[n - 1];
    i = lib_locate(x, n, q);
    t = (q - x[i]) / (x[i + 1] - x[i]);
    return y[i] + t * (y[i + 1] - y[i]);
}

/* Catmull-Rom 三次样条：过点、光滑、无需解方程组（比真样条便宜得多） */
double mp_interp_cubic_core(const double *x, const double *y, long long n, double q)
{
    long long i;
    double    t, h, p0, p1, m0, m1, h00, h10, h01, h11;
    if (n < 2) return y[0];
    if (q <= x[0])     return y[0];            /* 越界夹取，与线性插值一致 */
    if (q >= x[n - 1]) return y[n - 1];
    if (n == 2) return y[0] + (q - x[0]) / (x[1] - x[0]) * (y[1] - y[0]);
    i = lib_locate(x, n, q);
    h  = x[i + 1] - x[i];
    t  = (q - x[i]) / h;
    p0 = y[i];
    p1 = y[i + 1];
    /* 两端斜率：内部用中心差分，端点用单边差分。
     * m0 必须是**中心**差分 (y[i+1]−y[i−1])/(x[i+1]−x[i−1])；原来写成了
     * (y[i]−y[i−1])/(x[i]−x[i−1])，那是后向差分，跟下面 m1 的取法不自洽，
     * 结果内部段对二次函数也不精确（x=[0..3], y=x²，查 1.25 得 1.421875
     * 而不是 1.5625）。 */
    if (i == 0)
        m0 = (y[1] - y[0]) / (x[1] - x[0]);
    else
        m0 = (y[i + 1] - y[i - 1]) / (x[i + 1] - x[i - 1]);
    if (i + 1 >= n - 1)
        m1 = (y[n - 1] - y[n - 2]) / (x[n - 1] - x[n - 2]);
    else
        m1 = (y[i + 2] - y[i]) / (x[i + 2] - x[i]);
    h00 =  2 * t * t * t - 3 * t * t + 1;
    h10 =    t * t * t - 2 * t * t + t;
    h01 = -2 * t * t * t + 3 * t * t;
    h11 =    t * t * t -     t * t;
    return h00 * p0 + h10 * h * m0 + h01 * p1 + h11 * h * m1;
}

Value rt_lib_mp_interp_linear(Value xv, Value yv, Value qv)
{
    long long nx, ny;
    double    q = lib_num(qv, "mp.interp_linear 的查询点");
    double   *x = lib_unpack(xv, &nx, "mp.interp_linear 的 xs");
    double   *y = lib_unpack(yv, &ny, "mp.interp_linear 的 ys");
    double    r;
    if (nx != ny) {
        free(x); free(y);
        lib_die("mp.interp_linear：xs 长度 %lld 与 ys 长度 %lld 不一致", nx, ny);
    }
    lib_check_sorted(x, nx, "mp.interp_linear");
    r = mp_interp_linear_core(x, y, nx, q);
    free(x); free(y);
    return rt_float(r);
}

Value rt_lib_mp_interp_cubic(Value xv, Value yv, Value qv)
{
    long long nx, ny;
    double    q = lib_num(qv, "mp.interp_cubic 的查询点");
    double   *x = lib_unpack(xv, &nx, "mp.interp_cubic 的 xs");
    double   *y = lib_unpack(yv, &ny, "mp.interp_cubic 的 ys");
    double    r;
    if (nx != ny) {
        free(x); free(y);
        lib_die("mp.interp_cubic：xs 长度 %lld 与 ys 长度 %lld 不一致", nx, ny);
    }
    lib_check_sorted(x, nx, "mp.interp_cubic");
    r = mp_interp_cubic_core(x, y, nx, q);
    free(x); free(y);
    return rt_float(r);
}

/* 最小二乘直线：解正规方程（中心化后斜率 = Σ(x−x̄)(y−ȳ)/Σ(x−x̄)²）。
 * 中心化这一步不是为了好看：直接解 [[Σx²,Σx],[Σx,n]] 那个正规方程，
 * x 的量级一大就数值不稳（这是教科书上要中心化的原因，不是审美问题）。 */
Value rt_lib_mp_linfit(Value xv, Value yv)
{
    long long n, ny, i;
    double   *x = lib_unpack(xv, &n, "mp.linfit 的 x");
    double   *y = lib_unpack(yv, &ny, "mp.linfit 的 y");
    double    sx = 0, sy = 0, sxx = 0, sxy = 0, syy = 0, mx, my, k, b, r2, den;
    Value     out;

    if (ny != n) {
        free(x); free(y);
        lib_die("mp.linfit：x 长度 %lld 与 y 长度 %lld 不一致", n, ny);
    }
    if (n < 2) { free(x); free(y); lib_die("mp.linfit：至少要 2 个样本"); }

    for (i = 0; i < n; i++) { sx += x[i]; sy += y[i]; }
    mx = sx / (double)n;
    my = sy / (double)n;
    for (i = 0; i < n; i++) {
        double dx = x[i] - mx, dy = y[i] - my;
        sxx += dx * dx;
        sxy += dx * dy;
        syy += dy * dy;
    }
    den = sxx;
    if (den == 0.0) {
        free(x); free(y);
        lib_die("mp.linfit：所有 x 都一样，画不出直线\n"
                "  为什么：最小二乘要对 x 求导，x 没有变化就没有斜率可言\n"
                "  怎么改：给 x 一些分散的值；纯竖直的数据请改用别的模型");
    }
    k = sxy / den;
    b = my - k * mx;
    r2 = (syy > 0.0) ? (sxy * sxy) / (den * syy) : 1.0;
    out = rt_list_new();
    rt_push(&out, rt_float(k));
    rt_push(&out, rt_float(b));
    rt_push(&out, rt_float(r2));
    free(x); free(y);
    return out;
}

/* 最小二乘：解 min ‖A·x − b‖²，A 是 n×m 行主序（就地破坏），b 是 n（就地破坏）。
 * 列平衡 + Householder QR。返回 1 成功，0 表示秩亏（某列全零）。
 *
 * 不用正规方程的原因：VᵀV 把条件数平方了。实测 deg=6 还对得上 numpy（1.4e-13），
 * deg=8 就给出真值 2/4/8 倍的系数、拟合曲线残差差 56%。
 * 列平衡也不是可选项：mx 各次幂的列 2-范数差好几个数量级，不先归一 QR 也白搭。 */
static int lib_lstsq(double *a, double *b, long long n, int m, double *x)
{
    double *sc, *v;
    int     j, k, i;
    long long r;

    if (m < 1 || n < m) return 0;
    sc = (double *)calloc((size_t)m, sizeof(double));
    v  = (double *)malloc(sizeof(double) * (size_t)n);
    if (!sc || !v) { free(sc); free(v); return 0; }

    /* 1) 列平衡：第 j 列除以它的 2-范数（结果存 sc[j]，收尾要还原） */
    for (j = 0; j < m; j++) {
        double s = 0.0;
        for (r = 0; r < n; r++) { double t = a[(size_t)r * m + j]; s += t * t; }
        sc[j] = sqrt(s);
        if (!(sc[j] > 1e-300)) { free(sc); free(v); return 0; }   /* 该列全 0 -> 秩亏 */
        for (r = 0; r < n; r++) a[(size_t)r * m + j] /= sc[j];
    }

    /* 2) Householder 反射：逐列把 A[j..][j] 下面清零，b 跟着变换 */
    for (j = 0; j < m; j++) {
        double nrm = 0.0, alpha, vtv = 0.0;
        for (r = j; r < n; r++) { double t = a[(size_t)r * m + j]; nrm += t * t; }
        nrm = sqrt(nrm);
        if (!(nrm > 1e-300)) { free(sc); free(v); return 0; }
        alpha = (a[(size_t)j * m + j] > 0.0) ? -nrm : nrm;   /* 选符号避免相消 */
        for (r = j; r < n; r++) v[r - j] = a[(size_t)r * m + j];
        v[0] -= alpha;
        for (r = 0; r < n - j; r++) vtv += v[r] * v[r];
        if (vtv > 0.0) {
            double tau = 2.0 / vtv, dot;
            for (k = j; k < m; k++) {
                dot = 0.0;
                for (r = j; r < n; r++) dot += v[r - j] * a[(size_t)r * m + k];
                dot *= tau;
                for (r = j; r < n; r++) a[(size_t)r * m + k] -= dot * v[r - j];
            }
            dot = 0.0;
            for (r = j; r < n; r++) dot += v[r - j] * b[r];
            dot *= tau;
            for (r = j; r < n; r++) b[r] -= dot * v[r - j];
        }
    }

    /* 3) 回代解 R·x = Qᵀb（R 是上面得到的 m×m 上三角） */
    for (i = m - 1; i >= 0; i--) {
        double s = b[i];
        if (!(fabs(a[(size_t)i * m + i]) > 1e-300)) { free(sc); free(v); return 0; }
        for (k = i + 1; k < m; k++) s -= a[(size_t)i * m + k] * x[k];
        x[i] = s / a[(size_t)i * m + i];
    }

    /* 4) 还原列平衡 */
    for (j = 0; j < m; j++) x[j] /= sc[j];
    free(sc);
    free(v);
    return 1;
}

/* mp.polyfit(xs, ys, deg) —— 最小二乘多项式拟合，返回系数 [c0, c1, …, cdeg]（升幂） */
Value rt_lib_mp_polyfit(Value xv, Value yv, Value degv)
{
    long long n, ny, i, j;
    double   *x = lib_unpack(xv, &n, "mp.polyfit 的 x");
    double   *y = lib_unpack(yv, &ny, "mp.polyfit 的 y");
    int       deg = (int)lib_num(degv, "mp.polyfit 的次数");
    int       m = deg + 1;
    double   *A, *B, *cx, *mx, *my;
    double    sx = 0.0, sy = 0.0;       /* x̄ / ȳ：中心化要用，换算回原幂也要用 */
    Value     out;

    if (ny != n) {
        free(x); free(y);
        lib_die("mp.polyfit：x 长度 %lld 与 y 长度 %lld 不一致", n, ny);
    }
    if (deg < 0 || deg > 12) {
        free(x); free(y);
        lib_die("mp.polyfit：次数 %d 超出 0~12\n"
                "  为什么：高次多项式本身病态——即使解算用的是 QR，次数一高，"
                "系数也会对数据噪声极端敏感，不同实现给出的系数差好几个数量级\n"
                "  怎么改：换横轴单位缩小 x 的量级（拟合前先减掉均值），或分段低次拟合", deg);
    }
    if (n < m) {
        free(x); free(y);
        lib_die("mp.polyfit：%lld 个样本拟合 %d 次多项式不够（至少要 %d 个）", n, deg, m);
    }

    /* 同样先中心化：x 的量级一大，正规方程直接失稳 */
    mx = (double *)malloc(sizeof(double) * (size_t)n);
    my = (double *)malloc(sizeof(double) * (size_t)n);
    A  = (double *)calloc((size_t)n * m, sizeof(double));
    B  = (double *)calloc((size_t)n, sizeof(double));
    cx = (double *)calloc((size_t)m, sizeof(double));
    if (!mx || !my || !A || !B || !cx) {
        free(x); free(y); free(mx); free(my); free(A); free(B); free(cx);
        lib_die("mp.polyfit 内存不足");
    }
    for (i = 0; i < n; i++) { sx += x[i]; sy += y[i]; }
    sx /= (double)n; sy /= (double)n;
    for (i = 0; i < n; i++) { mx[i] = x[i] - sx; my[i] = y[i] - sy; }
    /* A[j][k] = Σ mx_i^(j+k)，所以 pw 必须在 **k** 循环里推进。
     * 原来只在 j 循环里推进，等于每一列都加上 Σ mx^j —— 所有列一模一样，
     * 矩阵秩 1，于是 deg>=1 的输入一律被判「正规方程奇异」。 */
    /* 设计矩阵：第 i 行是 (1, mx_i, mx_i², …)，第 i 个右端是 my_i。
     * 注意是 n×m 不是 m×m 的矩：QR 直接作用在这个矩阵上，不显式构造 VᵀV。 */
    for (i = 0; i < n; i++) {
        double pj = 1.0;
        for (j = 0; j < m; j++) { A[(size_t)i * m + j] = pj; pj *= mx[i]; }
        B[i] = my[i];
    }
    if (!lib_lstsq(A, B, n, m, cx)) {
        free(x); free(y); free(mx); free(my); free(A); free(B); free(cx);
        lib_die("mp.polyfit：设计矩阵秩亏，样本在横轴上退化（比如有重复的 x）\n"
                "  为什么：x 全都一样或只有有限几种取值时，多项式拟合不唯一\n"
                "  怎么改：让 x 有足够多的不同取值；次数也要小于不同 x 的个数");
    }
    /* cx 是 (x−x̄) 的幂的系数，要按「x 的幂」返回，否则用户拿去代回原 x 就全错。
     * Horner 换算：d(x) = ((…(cx_deg·(x−x̄) + cx_{deg−1})…)·(x−x̄) + cx_0) */
    {
        double d[13];
        int    jj, kk;
        for (jj = 0; jj <= deg; jj++) d[jj] = 0.0;
        d[0] = cx[deg];
        for (jj = deg - 1; jj >= 0; jj--) {
            for (kk = deg; kk >= 1; kk--)
                d[kk] = d[kk - 1] - sx * d[kk];
            d[0] = -sx * d[0] + cx[jj];
        }
        d[0] += sy;          /* 拟合的是 my = y − ȳ，别忘了把 ȳ 加回来；
                              * 漏掉的话拟合 x² 会得到 [−6, 0, 1] 而不是 [0, 0, 1] */
        out = rt_list_new();
        for (jj = 0; jj <= deg; jj++) rt_push(&out, rt_float(d[jj]));
    }
    free(x); free(y); free(mx); free(my); free(A); free(B); free(cx);
    return out;
}

/* ================= tm 时间模块 ================= */

Value rt_lib_tm_stop(Value dur, Value unit)
{
    double ms = lib_num(dur, "tm.stop 的时长") * 1000.0;
    if (IS_STR(unit)) {
        const char *u = AS_STR(unit) ? AS_STR(unit) : "";
        if (strcmp(u, "ms") == 0 || strcmp(u, "毫秒") == 0)
            ms = lib_num(dur, "tm.stop 的时长");
        else if (strcmp(u, "s") != 0 && strcmp(u, "秒") != 0)
            lib_die("tm.stop 的单位只能是 \"s\" 或 \"ms\"");
    } else if (!IS_NONE(unit)) {
        lib_die("tm.stop 的单位只能是 \"s\" 或 \"ms\"");
    }
    if (ms < 0)
        ms = 0;
    Sleep((DWORD)ms);
    return rt_none();
}

Value rt_lib_tm_now(void)
{
    static ULONGLONG t0 = 0;
    static int started = 0;
    if (!started) {
        t0 = GetTickCount64();
        started = 1;
    }
    return rt_int((long long)(GetTickCount64() - t0));
}

/* ================= 调色板（内置常量色表） ================= */

/* 调色板.颜色名 → 新建的 [r,g,b] 列表（每色一个）。配合 color(列表)
 * 重载使用；列表按内存约定分配后不回收。 */

static Value pal_rgb(int r, int g, int b)
{
    Value lst = rt_list_new();
    rt_push(&lst, rt_int(r));
    rt_push(&lst, rt_int(g));
    rt_push(&lst, rt_int(b));
    return lst;
}

Value rt_lib_pal_hong(void)  { return pal_rgb(255, 68, 68);   }   /* 红 */
Value rt_lib_pal_cheng(void) { return pal_rgb(255, 150, 40);  }   /* 橙 */
Value rt_lib_pal_huang(void) { return pal_rgb(255, 220, 60);  }   /* 黄 */
Value rt_lib_pal_lv(void)    { return pal_rgb(60, 200, 90);   }   /* 绿 */
Value rt_lib_pal_qing(void)  { return pal_rgb(60, 200, 200);  }   /* 青 */
Value rt_lib_pal_lan(void)   { return pal_rgb(70, 130, 255);  }   /* 蓝 */
Value rt_lib_pal_zi(void)    { return pal_rgb(170, 90, 220);  }   /* 紫 */
Value rt_lib_pal_bai(void)   { return pal_rgb(240, 240, 240); }   /* 白 */
Value rt_lib_pal_hei(void)   { return pal_rgb(20, 20, 24);    }   /* 黑 */
Value rt_lib_pal_hui(void)   { return pal_rgb(140, 140, 150); }   /* 灰 */
Value rt_lib_pal_fen(void)   { return pal_rgb(255, 140, 180); }   /* 粉 */
Value rt_lib_pal_jin(void)   { return pal_rgb(255, 200, 60);  }   /* 金 */

/* ================= mec 类型查询（Modernized_code） =================
 * mec.kind(值) → 类型名字符串。泛型容器的运行时类型锁定用它。
 * 顺序注意：BOOL 在 INT 之前判（真假别被当成整数）。 */
Value rt_mec_kind(Value v)
{
    if (IS_NONE(v))   return rt_str("空");
    if (IS_BOOL(v))   return rt_str("真假");
    if (IS_INT(v) || IS_BIGINT(v)) return rt_str("整数");
    if (IS_FLT(v))    return rt_str("小数");
    if (IS_STR(v))    return rt_str("文本");
    if (IS_LIST(v))   return rt_str("列表");
    if (IS_DICT(v))   return rt_str("字典");
    if (IS_OBJ(v))    return rt_str("对象");
    return rt_str("未知");
}

/* ================= 自测（-DLIB_SELF_TEST） =================
 * gcc -O2 -DLIB_SELF_TEST pybook_lib.c pybook_rt.c -o lib_test.exe -I. */

#ifdef LIB_SELF_TEST

#include <float.h>

static int g_pass = 0, g_fail = 0;

#define CHECK(cond, name)                              \
    do {                                               \
        if (cond) {                                    \
            g_pass++;                                  \
        } else {                                       \
            g_fail++;                                  \
            printf("[失败] %s\n", name);               \
        }                                              \
    } while (0)

static Value mklist(int n, ...)
{
    Value lst = rt_list_new();
    va_list ap;
    va_start(ap, n);
    for (int i = 0; i < n; i++)
        rt_push(&lst, va_arg(ap, Value));
    va_end(ap);
    return lst;
}

static int str_eq(Value v, const char *want)
{
    return IS_STR(v) && strcmp(AS_STR(v), want) == 0;
}

static double as_f(Value v) { return AS_FLT(v); }
static long long as_i(Value v) { return IS_INT(v) || IS_BIGINT(v) ? rt_to_ll(v) : (long long)AS_BOOL(v); }

int main(void)
{
    /* ---- te.split ---- */
    Value parts = rt_lib_te_split(rt_str("a,b,,c"), rt_str(","));
    CHECK(as_i(rt_len(parts)) == 4, "te.split: 4 段");
    CHECK(str_eq(rt_index(parts, rt_int(2)), ""), "te.split: 空段保留");
    Value one = rt_lib_te_split(rt_str("abc"), rt_str(","));
    CHECK(as_i(rt_len(one)) == 1 && str_eq(rt_index(one, rt_int(0)), "abc"),
          "te.split: 无分隔符 → 整串 1 段");

    /* ---- te.replace ---- */
    CHECK(str_eq(rt_lib_te_replace(rt_str("番茄炒番茄"), rt_str("番茄"),
                                   rt_str("土豆")), "土豆炒土豆"),
          "te.replace: 多处替换");
    CHECK(str_eq(rt_lib_te_replace(rt_str("abc"), rt_str("x"), rt_str("y")),
                 "abc"), "te.replace: 无命中原样");
    CHECK(str_eq(rt_lib_te_replace(rt_str("aaa"), rt_str("aa"), rt_str("b")),
                 "ba"), "te.replace: 顺序扫描不重叠");

    /* ---- te.trim ---- */
    CHECK(str_eq(rt_lib_te_trim(rt_str("  hi\r\n")), "hi"), "te.trim: 去两侧空白");
    CHECK(str_eq(rt_lib_te_trim(rt_str(" \t\v\f")), ""), "te.trim: 全空白 → 空");
    CHECK(str_eq(rt_lib_te_trim(rt_str(" a b ")), "a b"), "te.trim: 中间空白保留");

    /* ---- te.upper / te.lower ---- */
    CHECK(str_eq(rt_lib_te_upper(rt_str("aBc1中")), "ABC1中"), "te.upper: 混合文本");
    CHECK(str_eq(rt_lib_te_lower(rt_str("AbC1中")), "abc1中"), "te.lower: 混合文本");

    /* ---- te.has ---- */
    CHECK(rt_cond(rt_lib_te_has(rt_str("hello 世界"), rt_str("lo 世"))) != 0,
          "te.has: 命中");
    CHECK(rt_cond(rt_lib_te_has(rt_str("abc"), rt_str("z"))) == 0,
          "te.has: 未命中");
    CHECK(rt_cond(rt_lib_te_has(rt_str("abc"), rt_str(""))) != 0,
          "te.has: 空子串恒真");

    /* ---- te.len：UTF-8 按字符 ---- */
    CHECK(as_i(rt_lib_te_len(rt_str("hello"))) == 5, "te.len: ASCII");
    CHECK(as_i(rt_lib_te_len(rt_str("中文ab"))) == 4, "te.len: UTF-8 按字符");

    /* ---- te.cut ---- */
    CHECK(str_eq(rt_lib_te_cut(rt_str("你好世界"), rt_int(1), rt_int(3)), "好世"),
          "te.cut: 中段（UTF-8 按字符）");
    CHECK(str_eq(rt_lib_te_cut(rt_str("abc"), rt_int(0), rt_int(0)), ""),
          "te.cut: 空区间");
    CHECK(str_eq(rt_lib_te_cut(rt_str("abc"), rt_int(0), rt_int(3)), "abc"),
          "te.cut: 全范围");

    /* ---- te.join ---- */
    CHECK(str_eq(rt_lib_te_join(mklist(3, rt_str("x"), rt_str("y"), rt_str("z")),
                                rt_str("-")), "x-y-z"), "te.join: 字符串列表");
    CHECK(str_eq(rt_lib_te_join(mklist(3, rt_int(1), rt_float(2.5), rt_str("真")),
                                rt_str(",")), "1,2.5,真"), "te.join: 混合类型转文本");
    CHECK(str_eq(rt_lib_te_join(rt_list_new(), rt_str("+")), ""),
          "te.join: 空列表 → 空串");

    /* ---- te.chr ---- */
    CHECK(str_eq(rt_lib_te_chr(rt_int(10)), "\n"), "te.chr: 换行");
    CHECK(str_eq(rt_lib_te_chr(rt_int(13)), "\r"), "te.chr: 回车");
    CHECK(str_eq(rt_lib_te_chr(rt_int(65)), "A"), "te.chr: ASCII");
    CHECK(str_eq(rt_lib_te_chr(rt_int(0x4E2D)), "\xE4\xB8\xAD"), "te.chr: 中文码点→UTF-8");
    CHECK(str_eq(rt_lib_te_join(mklist(3, rt_str("a"), rt_str("b"), rt_str("c")),
                                rt_lib_te_chr(rt_int(10))), "a\nb\nc"),
          "te.chr: 当行分隔符用");

    /* ---- mt.sqrt / mt.pow ---- */
    CHECK(as_f(rt_lib_mt_sqrt(rt_int(144))) == 12.0, "mt.sqrt: 完全平方数");
    CHECK(as_f(rt_lib_mt_sqrt(rt_float(2.0))) > 1.4142135, "mt.sqrt: 浮点");
    CHECK(as_f(rt_lib_mt_pow(rt_int(2), rt_int(10))) == 1024.0, "mt.pow: 2^10");
    CHECK(as_f(rt_lib_mt_pow(rt_int(4), rt_float(0.5))) == 2.0, "mt.pow: 4^0.5=2");

    /* ---- mt.abs ---- */
    CHECK(as_i(rt_lib_mt_abs(rt_int(-7))) == 7 &&
          as_i(rt_lib_mt_abs(rt_int(7))) == 7, "mt.abs: 整数");
    CHECK(as_f(rt_lib_mt_abs(rt_float(-2.5))) == 2.5, "mt.abs: 浮点");
    CHECK(as_i(rt_lib_mt_abs(rt_int(0))) == 0, "mt.abs: 0→0");
    CHECK(as_i(rt_lib_mt_abs(rt_bool(1))) == 1, "mt.abs: 布尔按 0/1");

    /* ---- mt.ceil / mt.floor ---- */
    CHECK(as_i(rt_lib_mt_ceil(rt_float(1.2))) == 2, "mt.ceil: 1.2→2");
    CHECK(as_i(rt_lib_mt_ceil(rt_float(-1.2))) == -1, "mt.ceil: -1.2→-1");
    CHECK(as_i(rt_lib_mt_floor(rt_float(1.8))) == 1, "mt.floor: 1.8→1");
    CHECK(as_i(rt_lib_mt_floor(rt_float(-1.8))) == -2, "mt.floor: -1.8→-2");
    CHECK(as_i(rt_lib_mt_ceil(rt_int(5))) == 5, "mt.ceil: 整数原值");

    /* ---- mt.mod ---- */
    CHECK(as_i(rt_lib_mt_mod(rt_int(7), rt_int(3))) == 1, "mt.mod: 7%3=1");
    CHECK(as_i(rt_lib_mt_mod(rt_int(-7), rt_int(3))) == 2,
          "mt.mod: 负数符号跟除数");

    /* ---- mt.max / mt.min / mt.prod ---- */
    Value nums = mklist(4, rt_int(3), rt_int(-5), rt_float(9.5), rt_int(2));
    CHECK(as_f(rt_lib_mt_max(nums)) == 9.5, "mt.max: 混合数字");
    CHECK(as_i(rt_lib_mt_min(nums)) == -5, "mt.min: 负数");
    CHECK(as_i(rt_lib_mt_min(mklist(2, rt_int(100), rt_int(-100)))) == -100,
          "mt.min: 两元素");
    CHECK(as_i(rt_lib_mt_prod(mklist(3, rt_int(2), rt_int(3), rt_int(4)))) == 24,
          "mt.prod: 2*3*4");
    CHECK(as_f(rt_lib_mt_prod(mklist(2, rt_float(1.5), rt_int(4)))) == 6.0,
          "mt.prod: 浮点");

    /* ---- mt.sin / mt.cos / mt.tan / mt.pi ---- */
    CHECK(as_f(rt_lib_mt_sin(rt_int(0))) == 0.0, "mt.sin: 0→0");
    CHECK(as_f(rt_lib_mt_cos(rt_int(0))) == 1.0, "mt.cos: 0→1");
    CHECK(as_f(rt_lib_mt_tan(rt_int(0))) == 0.0, "mt.tan: 0→0");
    double pival = as_f(rt_lib_mt_pi());
    CHECK(pival > 3.14159265358 && pival < 3.14159265360, "mt.pi: 值正确");
    CHECK(IS_FLT(rt_lib_mt_pi()), "mt.pi: 浮点盒");

    /* ---- rd.int：范围、含两端、起=止 ---- */
    int in_range = 1, saw_lo = 0, saw_hi = 0;
    for (int i = 0; i < 2000; i++) {
        Value r = rt_lib_rd_int(rt_int(3), rt_int(7));
        if (as_i(r) < 3 || as_i(r) > 7)
            in_range = 0;
        if (as_i(r) == 3) saw_lo = 1;
        if (as_i(r) == 7) saw_hi = 1;
    }
    CHECK(in_range, "rd.int: 2000 次都在 [3,7]");
    CHECK(saw_lo && saw_hi, "rd.int: 两端都取到过（含两端）");
    CHECK(as_i(rt_lib_rd_int(rt_int(5), rt_int(5))) == 5, "rd.int: 起=止");

    /* ---- rd.float：范围 + 多样性 ---- */
    Value rf = rt_lib_rd_float();
    CHECK(IS_FLT(rf) && as_f(rf) >= 0.0 && as_f(rf) < 1.0,
          "rd.float: 在 [0,1)");
    int varied = 0;
    double first = as_f(rt_lib_rd_float());
    for (int i = 0; i < 50; i++)
        if (as_f(rt_lib_rd_float()) != first)
            varied = 1;
    CHECK(varied, "rd.float: 连续抽样有变化");

    /* ---- rd.pick ---- */
    Value pool = mklist(3, rt_int(10), rt_int(20), rt_int(30));
    int pick_ok = 1;
    for (int i = 0; i < 200; i++) {
        Value p = rt_lib_rd_pick(pool);
        if (as_i(p) != 10 && as_i(p) != 20 && as_i(p) != 30)
            pick_ok = 0;
    }
    CHECK(pick_ok, "rd.pick: 200 次都取自原列表");

    /* ---- rd.shuffle：集合不变 + 顺序变化 ---- */
    Value deck = mklist(6, rt_int(1), rt_int(2), rt_int(3),
                        rt_int(4), rt_int(5), rt_int(6));
    long long sum0 = 0;
    for (long long i = 0; i < 6; i++)
        sum0 += as_i(rt_index(deck, rt_int(i)));
    rt_lib_rd_shuffle(deck);
    long long sum1 = 0;
    int sorted_still = 1;
    for (long long i = 0; i < 6; i++) {
        Value e = rt_index(deck, rt_int(i));
        if (as_i(e) != i + 1)
            sorted_still = 0;
        sum1 += as_i(e);
    }
    CHECK(sum0 == 21 && sum1 == 21, "rd.shuffle: 元素集合不变（和=21）");
    CHECK(!sorted_still, "rd.shuffle: 顺序确实变了");

    /* ---- mt.lerp / mt.dist / mt.clamp ---- */
    CHECK(as_f(rt_lib_mt_lerp(rt_int(0), rt_int(10), rt_float(0.5))) == 5.0,
          "mt.lerp: 0→10 的一半是 5");
    CHECK(as_f(rt_lib_mt_dist(rt_int(0), rt_int(0), rt_int(3), rt_int(4))) == 5.0,
          "mt.dist: 3-4-5");
    CHECK(as_i(rt_lib_mt_clamp(rt_int(15), rt_int(0), rt_int(10))) == 10,
          "mt.clamp: 15 夹到上限 10");

    printf("库自测：通过 %d 项，失败 %d 项\n", g_pass, g_fail);
    if (g_fail == 0)
        printf("库自测全部通过\n");
    return g_fail == 0 ? 0 : 1;
}

#endif /* LIB_SELF_TEST */
