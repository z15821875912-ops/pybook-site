# -*- coding: utf-8 -*-
"""把两张同尺寸的截图拼成上下对照图（左上/右上角标风格名）。
用法: python -B _sidebyside.py <图A.png> <B.png> <输出.png> [标签A] [标签B]
"""
import sys
from PIL import Image, ImageDraw


def main():
    a, b, out = sys.argv[1], sys.argv[2], sys.argv[3]
    la = sys.argv[4] if len(sys.argv) > 4 else 'A'
    lb = sys.argv[5] if len(sys.argv) > 5 else 'B'
    ia, ib = Image.open(a).convert('RGB'), Image.open(b).convert('RGB')
    w = max(ia.width, ib.width)
    pad, band = 8, 26
    h = ia.height + ib.height + pad * 3 + band
    canvas = Image.new('RGB', (w + pad * 2, h), (11, 14, 20))
    d = ImageDraw.Draw(canvas)
    y = pad
    for img, lab in ((ia, la), (ib, lb)):
        d.rectangle([pad, y, pad + w, y + band], fill=(30, 38, 50))
        d.text((pad + 8, y + 7), lab, fill=(232, 237, 244))
        y += band
        canvas.paste(img, (pad, y))
        y += img.height + pad
    canvas.save(out)
    print('%s  %dx%d  <- %s + %s' % (out, canvas.width, canvas.height, a, b))


main()
