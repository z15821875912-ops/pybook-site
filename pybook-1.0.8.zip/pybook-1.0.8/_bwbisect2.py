# -*- coding: utf-8 -*-
"""_bwbisect2.py -- 第二轮二分：把第一轮定位到的失败块 v3 再逐条切开。

第一轮结果（实测，见 _bwbisect.py）：
    v1 最小骨架                         通过
    v2 + cvta.to.global                 通过
    v3 + 线程号/位移计算                 失败   <-- 罪魁在这段
    v4 + 循环 + generic add.s64         失败   （含 v3 的活）
    v5 + ld.global.v4 向量载入          通过   <-- 头号嫌疑被推翻
    v6 cvta+循环+向量载入                失败   （含 v3 的活）
    v7 完整 bw_read（对照组）            失败

也就是说 ld.global.v4.f32 完全没问题，卡住的是这段里的某一条：
    mov.u32    %r2, %ctaid.x;
    mul.lo.u32 %r2, %r2, %ntid.x;
    add.u32    %r2, %r2, %tid.x;
    mul.lo.u32 %r3, %nctaid.x, %ntid.x;
    shl.b32    %r4, %r3, 4;
    shl.b32    %r5, %r2, 4;
    cvt.s64.u32 %rd5, %r5;
    add.s64    %rd6, %rd1, %rd5;

这一轮一次加一条，看第几个变体开始失败。
教训（本会话已经栽了两次）：不要盯着代码猜，量一下就知道。
"""
import os

HEAD = """.version 6.5
.target sm_61
.address_size 64
"""

DECL = """    .reg .pred %p<4>;
    .reg .b32  %r<8>;
    .reg .b64  %rd<8>;
    .reg .f32  %f<8>;
"""

TAIL = """    ret;
}
"""

SIG = "( .param .u64 p_a, .param .u64 p_out, .param .u32 p_iter )"

# 共同的收尾：把 v3 那段之前必须有的取参部分固定住
PRE = """
    ld.param.u64 %rd1, [p_a];
    ld.param.u64 %rd2, [p_out];
    cvta.to.global.u64 %rd3, %rd1;
    cvta.to.global.u64 %rd4, %rd2;
"""

# 逐条累加
STEPS = [
    ("a", "mov.u32 %r2, %ctaid.x",              "    mov.u32  %r2, %ctaid.x;\n"),
    ("b", "mul.lo.u32 %r2,%r2,%ntid.x",         "    mul.lo.u32 %r2, %r2, %ntid.x;\n"),
    ("c", "add.u32 %r2,%r2,%tid.x",             "    add.u32  %r2, %r2, %tid.x;\n"),
    ("d", "mul.lo.u32 %r3,%nctaid.x,%ntid.x",   "    mul.lo.u32 %r3, %nctaid.x, %ntid.x;\n"),
    ("e", "shl.b32 %r4,%r3,4",                  "    shl.b32  %r4, %r3, 4;\n"),
    ("f", "shl.b32 %r5,%r2,4",                  "    shl.b32  %r5, %r2, 4;\n"),
    ("g", "cvt.s64.u32 %rd5,%r5",               "    cvt.s64.u32 %rd5, %r5;\n"),
    ("h", "add.s64 %rd6,%rd1,%rd5",             "    add.s64  %rd6, %rd1, %rd5;\n"),
]


def build(path, ascii_note, body):
    txt = (HEAD
           + "// bw bisect phase2: " + ascii_note + "\n"
           + "// ASCII comments only -- Chinese breaks the JIT with no message.\n"
           + ".visible .entry bw_read" + SIG + "\n{\n"
           + DECL + body + TAIL)
    with open(path, "w", encoding="ascii", newline="\n") as f:
        f.write(txt)
    return path


def main():
    made = []
    acc = PRE
    for tag, cn, line in STEPS:
        acc += line
        # 每一步都必须真的被用上，否则死代码会被优化掉，
        # 于是「这一步其实是好的」会被误判成「这一步炸了」。
        if tag == "h":
            # 到 h 为止 %rd6 才有值，用它来发载入，中间结果全部有出口
            body = acc + "\n    cvta.to.global.u64 %rd3, %rd6;\n"
        else:
            body = acc
        body += "    ld.global.f32 %f1, [%rd3];\n    st.global.f32 [%rd4], %f1;\n"
        name = "_ptx_BW_v3%s.ptx" % tag
        made.append(build(name, "cumulative through step " + tag, body))
        print("生成", name, "| 累加到", cn)
    print()
    print(" ".join(made))


if __name__ == "__main__":
    main()
