# -*- coding: utf-8 -*-
"""_wire_entries2.py — 17 个新入口接进前端三张表 + VM 分发表"""
import io

EOL = {}


def rd(p):
    return io.open(p, encoding='utf-8', newline='').read()


def wr(p, t):
    io.open(p, 'w', encoding='utf-8', newline='').write(t)


def ins(p, anchor, block, tag, mode='after'):
    t = rd(p)
    if tag in t:
        print('  %s: 已有 %s，跳过' % (p, tag))
        return
    if p not in EOL:
        EOL[p] = '\r\n' if '\r\n' in t else '\n'
    b = block.replace('\n', EOL[p])
    i = t.index(anchor) + (len(anchor) if mode == 'after' else 0)
    wr(p, t[:i] + b + t[i:])
    print('  %s: 已接线 %s' % (p, tag))


ENTRIES = [
    # 随机分布（mp.*，与 mp.rand_* / rd.* 同一个 xorshift128）
    ('mp.rand_exponential', 1, 'rt_lib_mp_rand_exponential'),
    ('mp.rand_poisson',     1, 'rt_lib_mp_rand_poisson'),
    ('mp.rand_geom',        1, 'rt_lib_mp_rand_geom'),
    ('mp.rand_binom',       2, 'rt_lib_mp_rand_binom'),
    ('mp.rand_gamma',       2, 'rt_lib_mp_rand_gamma'),
    ('mp.rand_beta',        2, 'rt_lib_mp_rand_beta'),
    ('mp.rand_lognormal',   2, 'rt_lib_mp_rand_lognormal'),
    ('mp.rand_logistic',    2, 'rt_lib_mp_rand_logistic'),
    # 统计补齐
    ('mp.median',    1, 'rt_lib_mp_median'),
    ('mp.mode',      1, 'rt_lib_mp_mode'),
    ('mp.quantile',  2, 'rt_lib_mp_quantile'),
    ('mp.percentile', 2, 'rt_lib_mp_percentile'),
    ('mp.cov',       2, 'rt_lib_mp_cov'),
    ('mp.corr',      2, 'rt_lib_mp_corr'),
    ('mp.cumsum',    1, 'rt_lib_mp_cumsum'),
    ('mp.diff',      1, 'rt_lib_mp_diff'),
    # 随机源统一后补播种
    ('rd.seed',      1, 'rt_lib_rd_seed'),
]

print('== pybk_front.py : LIB_CALLS ==')
ins('pybk_front.py',
    "    'mt.dist(x1, y1, x2, y2)': 4,\n" if "    'mt.dist(x1, y1, x2, y2)': 4,\n" in rd('pybk_front.py')
    else "    'tb.shuffle': 2, 'tb.onehot': 2, 'tb.batch': 3,\n",
    ("\n    # ---- 随机分布（与 mp.rand_*/rd.* 共用同一个 xorshift128）----\n"
     + ''.join("    '%s': %d,\n" % (n, a) for n, a, _ in ENTRIES if n.startswith('mp.rand_')))
    + "\n    # ---- 统计补齐（此前只有 mean/var/std/minmax/sum）----\n"
    + ''.join("    '%s': %d,\n" % (n, a) for n, a, _ in ENTRIES if n.startswith('mp.') and not n.startswith('mp.rand_'))
    + "    'rd.seed': 1,\n",
    "'mp.rand_exponential'")

print('== pybk_code.py : LIB_C_NAMES ==')
ins('pybk_code.py',
    "        'tb.dot': 'rt_tb_dot', 'tb.tr': 'rt_tb_tr',\n",
    ("        # 随机分布 + 统计补齐 + rd.seed（随机源统一后）\n"
     + ''.join("        '%s': '%s',\n" % (n, c) for n, _a, c in ENTRIES)),
    "'mp.rand_exponential'")

print('== _vm_lib_calls.inc ==')
t = rd('_vm_lib_calls.inc')
e = '\r\n' if '\r\n' in t else '\n'
if '"mp.rand_exponential"' in t:
    print('  _vm_lib_calls.inc: 已接线')
else:
    a = 'Value rt_lib_mp_rand_normal(Value, Value);' + e
    i = t.index(a) + len(a)
    decls = ''.join('Value %s(%s);%s' % (c, ', '.join(['Value'] * n), e)
                    for _k, n, c in ENTRIES)
    t = t[:i] + decls + t[i:]
    b = '    {"mp.rand_normal", 2, (void *)rt_lib_mp_rand_normal},' + e
    j = t.index(b) + len(b)
    rows = ''.join('    {"%s", %d, (void *)%s},%s' % (k, n, c, e)
                   for k, n, c in ENTRIES)
    t = t[:j] + rows + t[j:]
    wr('_vm_lib_calls.inc', t)
    print('  _vm_lib_calls.inc: 已接线 (%d 个)' % len(ENTRIES))

print('共 %d 个入口' % len(ENTRIES))
