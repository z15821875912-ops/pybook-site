# -*- coding: utf-8 -*-
"""_build_vm.py — 重编 pyvm.exe（顺手杀掉占着文件的进程、绕开锁）

原来那份命令行清单是旧的：漏了 pybook_net.c 和 -lws2_32/-lwininet，
一链就报 rt_net_listen 未定义。这里以 pybk_code.py 的运行时源列表为准。
"""
import os
import subprocess
import sys
import time

GCC = r'C:\Users\zhuli\mingw64\bin\x86_64-w64-mingw32-gcc.exe'

# 与 pybk_code.py 的 objs 列表一致（pyvm.c 自己补在最前）
SRCS = ['pybook_rt.c', 'pybook_lib.c', 'pybook_file.c', 'pybook_music.c',
        'pybook_net.c', 'pybook_hw3d.c', 'pybook_np.c', 'pybook_tb.c',
        'pybook_mt.c', 'pybook_json.c', 'pybook_csv.c', 'pybook_mm.c',
        'mathplus.c', 'pybook_bits.c', 'pybook_ui.c', 'pybook_m3d.c',
        'pybook_smoke.c', 'pybook_obj.c', 'pybook_wire.c', 'pybook_gpu.c',
        'pybook_la.c']
LIBS = ['-lwinmm', '-lws2_32', '-lwininet', '-lopengl32', '-lm']
# pyvm.c 走的是「不带 3D/GUI 那一坨」的瘦链接：pybook_hw3d/ui/m3d 需要 SDL，
# 先试瘦的，失败再回退全量。
THIN = ['pyvm.c'] + [s for s in SRCS
                     if s not in ('pybook_hw3d.c', 'pybook_ui.c', 'pybook_m3d.c')]


def kill_pyvm():
    subprocess.run(['taskkill', '/F', '/IM', 'pyvm.exe'],
                   capture_output=True, text=True)
    time.sleep(0.4)


def build(sources, libs):
    return subprocess.run([GCC, '-O3', '-march=native', '-I.',
                           '-DMP_RT_BINDING', '-DLA_RT_BINDING']
                          + sources + ['-o', 'pyvm_new.exe'] + libs,
                          capture_output=True, text=True, errors='replace')


kill_pyvm()
r = build(THIN, LIBS)
if r.returncode != 0:
    print('瘦链接失败，改用全量源列表重试：')
    print(r.stderr[-1500:])
    r = build(['pyvm.c'] + SRCS, LIBS + ['-lSDL2'])

if r.returncode != 0:
    print(r.stderr[-3000:])
    sys.exit(1)

os.replace('pyvm_new.exe', 'pyvm.exe')
print('BUILD OK  pyvm.exe  %d bytes  %s'
      % (os.path.getsize('pyvm.exe'),
         time.strftime('%H:%M:%S', time.localtime(os.path.getmtime('pyvm.exe')))))
if r.stderr.strip():
    print('（有告警/输出）\n' + r.stderr[:800])
