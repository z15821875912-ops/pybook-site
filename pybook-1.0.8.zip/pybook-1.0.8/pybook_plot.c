/* PYbook 图. 表. 库：表格 / 数据图 / 函数图像。
 *
 * 三块能力，一个文件：
 *   表.*  表格：框线渲染（数字右对齐/文本左对齐/自动列宽）、行列取、转置、
 *              切片、排序、上下左右拼接、分组汇总。纯文本，**支持中文**。
 *   图.*  数据图：折线/散点/柱状/条形/饼图/直方/热力 + 坐标轴/刻度/网格/图例。
 *   图.曲线 函数图像：内置一个表达式求值器（sin(x)/x、x^2、abs(x-1)…），
 *              按 x 区间自动定 y 轴范围后描出。
 *
 * 为什么离线渲染成 PNG 而不是开窗口：
 *   win/ui/hw 都在别的车道上，而离线出图有两个实在的好处 ——
 *   一是能拿独立工具（_png校验.py）逐块核 CRC 反过来验它，
 *   二是脚本里跑完就有文件，CI 和回归都不需要窗口。
 *
 * 画布用句柄而不是把像素塞进列表：800x600 的 RGBA 是 144 万个列表单元，
 *   解释器根本扛不住。句柄是一个整数，句柄表是进程内的定长数组。
 *
 * 复用 mm 的东西：颜色 token 走 rt_mm_lookup（mm 的调色板），
 *   PNG 编码器走 mm_write_png（在 pybook_mm.c，勿复制第二份，CRC 那里有坑）。
 *
 * 文字用 5x7 点阵（表 32..126 可打印 ASCII）。中文走表.*，不进像素画布 ——
 *   内嵌一个汉字点阵要几十 KB 源码，不值。
 *
 * 纯计算 + 落盘，不开设备：VM / C 双后端都能跑。唯一例外是 图.函数
 *   （回调用户 lambda），它依赖 rt_call_value 的分发器，只有 C 后端有。
 */

#include "pybook_lib.h"

#include <math.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* 框线字符：UTF-8 多字节，**不能**写成 '┌' —— C 的多字符常量只保留最后一个字节，
 * 那样表格框线会全是乱码（同 pybook_mm.c 里 "色" 的那个坑）。这里写死字节。 */
#define B_H  "\xe2\x94\x80"   /* ─ */
#define B_V  "\xe2\x94\x82"   /* │ */
#define B_TL "\xe2\x94\x8c"   /* ┌ */
#define B_TR "\xe2\x94\x90"   /* ┐ */
#define B_BL "\xe2\x94\x94"   /* └ */
#define B_BR "\xe2\x94\x98"   /* ┘ */
#define B_LT "\xe2\x94\x9c"   /* ├ */
#define B_RT "\xe2\x94\xa4"   /* ┤ */
#define B_TT "\xe2\x94\xac"   /* ┬ */
#define B_BT "\xe2\x94\xb4"   /* ┴ */
#define B_X  "\xe2\x94\xbc"   /* ┼ */

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

/* ================= 基础 ================= */

static void plt_die(const char *fmt, ...)
{
    va_list ap;
    fprintf(stderr, "运行时错误: 图./表.");
    va_start(ap, fmt);
    vfprintf(stderr, fmt, ap);
    va_end(ap);
    fputc('\n', stderr);
    exit(1);
}

/* 可增长缓冲（拼表格文本、拼路径） */
typedef struct { char *s; size_t len, cap; } Buf;

static void buf_need(Buf *b, size_t extra)
{
    if (b->len + extra + 1 > b->cap) {
        b->cap = b->cap ? b->cap : 128;
        while (b->len + extra + 1 > b->cap)
            b->cap *= 2;
        char *p = (char *)realloc(b->s, b->cap);
        if (!p)
            plt_die("内存不足");
        b->s = p;
    }
}

static void buf_put(Buf *b, const char *s, size_t n)
{
    buf_need(b, n);
    memcpy(b->s + b->len, s, n);
    b->len += n;
    b->s[b->len] = '\0';
}

static void buf_str(Buf *b, const char *s) { buf_put(b, s, strlen(s)); }

static void buf_ch(Buf *b, char c) { buf_put(b, &c, 1); }

static void buf_rep(Buf *b, char c, int n)
{
    for (int i = 0; i < n; i++)
        buf_ch(b, c);
}

/* 重复一个**多字节**字符串 n 次（框线横线是 UTF-8，不能走 buf_rep 的单字节版） */
static void buf_reps(Buf *b, const char *s, int n)
{
    for (int i = 0; i < n; i++)
        buf_str(b, s);
}

/* buf 里已经拼好的内容交成字符串盒（拷贝一份，buf 随即释放） */
static Value buf_val(Buf *b)
{
    Value v = rt_str(b->s ? b->s : "");
    free(b->s);
    b->s = NULL;
    b->len = b->cap = 0;
    return v;
}

/* ================= 颜色 ================= */

typedef struct { unsigned char r, g, b, a; } PtColor;

/* 图表配色板：色相均匀、深浅交替、明度够在白底和深底上都分得开 */
static const PtColor pt_palette[] = {
    { 66, 133, 244, 255}, { 52, 168,  83, 255}, { 234,  67,  53, 255},
    {251, 188,   5, 255}, {171,  71, 188, 255}, {  0, 172, 193, 255},
    {255, 112,  67, 255}, {124, 179,   0, 255}, {141, 110,  99, 255},
    {38, 198, 218, 255},
};
#define PT_NPALETTE ((int)(sizeof pt_palette / sizeof pt_palette[0]))

static int pt_clampi(int v, int lo, int hi) { return v < lo ? lo : (v > hi ? hi : v); }

static unsigned char pt_clampb(double v)
{
    if (!(v > 0.0)) return 0;          /* 也顺手吃掉 NaN */
    if (v > 255.0) return 255;
    return (unsigned char)(v + 0.5);
}

static double pt_num(Value v, const char *who)
{
    if (IS_FLT(v)) return AS_FLT(v);
    if (IS_INT(v) || IS_BIGINT(v)) return (double)rt_to_ll(v);
    if (IS_BOOL(v)) return AS_BOOL(v) ? 1.0 : 0.0;
    plt_die("%s 需要数字参数", who);
    return 0.0;
}

static long long pt_int(Value v, const char *who)
{
    if (IS_FLT(v)) return (long long)AS_FLT(v);
    return (long long)pt_num(v, who);
}

/* 可选数字：空盒（用户没给）-> 缺省值 */
static double pt_opt(Value v, double deflt, const char *who)
{
    return IS_NONE(v) ? deflt : pt_num(v, who);
}

/* 颜色可写：[r,g,b] / [r,g,b,a] / "r1"（mm 调色板 token） / "#rrggbb" / "蓝" 等名字 */
static PtColor pt_color(Value v, const char *who)
{
    PtColor c;
    if (IS_LIST(v)) {
        RtList *L = AS_LIST(v);
        if (L->len < 3)
            plt_die("%s：颜色列表至少要有 3 个数 [r,g,b]", who);
        c.r = pt_clampb(pt_num(L->items[0], who));
        c.g = pt_clampb(pt_num(L->items[1], who));
        c.b = pt_clampb(pt_num(L->items[2], who));
        c.a = (L->len >= 4) ? pt_clampb(pt_num(L->items[3], who)) : 255;
        return c;
    }
    if (IS_STR(v)) {
        const char *s = AS_STR(v);
        if (*s == '#') {
            unsigned int rr = 0, gg = 0, bb = 0;
            if (sscanf(s + 1, "%2x%2x%2x", &rr, &gg, &bb) != 3)
                plt_die("%s：#rrggbb 颜色写法不对：%s", who, s);
            c.r = (unsigned char)rr; c.g = (unsigned char)gg; c.b = (unsigned char)bb;
            c.a = 255;
            return c;
        }
        if (strcmp(s, "黑") == 0) { c.r = 32;  c.g = 32;  c.b = 32;  c.a = 255; return c; }
        if (strcmp(s, "白") == 0) { c.r = 250; c.g = 250; c.b = 250; c.a = 255; return c; }
        if (strcmp(s, "灰") == 0) { c.r = 150; c.g = 150; c.b = 150; c.a = 255; return c; }
        if (strcmp(s, "红") == 0) { c.r = 234; c.g = 67;  c.b = 53;  c.a = 255; return c; }
        if (strcmp(s, "绿") == 0) { c.r = 52;  c.g = 168; c.b = 83;  c.a = 255; return c; }
        if (strcmp(s, "蓝") == 0) { c.r = 66;  c.g = 133; c.b = 244; c.a = 255; return c; }
        if (strcmp(s, "黄") == 0) { c.r = 251; c.g = 188; c.b = 5;   c.a = 255; return c; }
        if (strcmp(s, "橙") == 0) { c.r = 255; c.g = 112; c.b = 67;  c.a = 255; return c; }
        if (strcmp(s, "紫") == 0) { c.r = 171; c.g = 71;  c.b = 188; c.a = 255; return c; }
        if (strcmp(s, "青") == 0) { c.r = 0;   c.g = 172; c.b = 193; c.a = 255; return c; }
        int rr, gg, bb;
        if (rt_mm_lookup(v, &rr, &gg, &bb) == 1) {
            c.r = (unsigned char)rr; c.g = (unsigned char)gg; c.b = (unsigned char)bb;
            c.a = 255;
            return c;
        }
        plt_die("%s：认不出的颜色 %s（可以写 [r,g,b] / \"#rrggbb\" / \"红\" / mm 的 token 如 r1）",
                who, s);
    }
    /* 没给就用调色板第 0 号 */
    return pt_palette[0];
}

static PtColor pt_opt_color(Value v, PtColor deflt, const char *who)
{
    return IS_NONE(v) ? deflt : pt_color(v, who);
}

/* ================= 画布 ================= */

typedef struct {
    int w, h;
    unsigned char *px;        /* RGBA 8888 */
    /* 坐标系：图.轴 设好之后，绘图区与值域就存在这里，
     * 后面所有图表算子直接拿来映射，不用每次再传一遍。 */
    int has_axis;
    int pl, pt_, pr, pb;      /* 绘图区像素矩形（含边） */
    double xmin, xmax, ymin, ymax;
    PtColor bg;               /* 底色：图.柱状 刷掉 x 刻度带子时要用 */
} PtCanvas;

#define PT_MAXCANVAS 64
static PtCanvas pt_cv[PT_MAXCANVAS];

static PtCanvas *pt_get(Value v, const char *who)
{
    long long id = pt_int(v, who);
    if (id < 1 || id > PT_MAXCANVAS || !pt_cv[id - 1].px)
        plt_die("%s：画布 %lld 不存在（合法 1..%d，且要先 图.画布 出来）",
                who, id, PT_MAXCANVAS);
    return &pt_cv[id - 1];
}

/* 取第 n 号画布的第 idx 个通道值，供 图.读像素 用 */
static Value pt_new_canvas(int w, int h, PtColor bg)
{
    w = pt_clampi(w, 1, 8000);
    h = pt_clampi(h, 1, 8000);
    for (int i = 0; i < PT_MAXCANVAS; i++) {
        if (pt_cv[i].px)
            continue;
        size_t n = (size_t)w * h * 4;
        unsigned char *p = (unsigned char *)malloc(n);
        if (!p)
            plt_die("画布内存不足（%dx%d）", w, h);
        for (size_t k = 0; k < n; k += 4) {
            p[k] = bg.r; p[k + 1] = bg.g; p[k + 2] = bg.b; p[k + 3] = bg.a;
        }
        pt_cv[i].w = w; pt_cv[i].h = h; pt_cv[i].px = p;
        pt_cv[i].has_axis = 0;
        pt_cv[i].pl = pt_cv[i].pt_ = pt_cv[i].pr = pt_cv[i].pb = 0;
        pt_cv[i].xmin = pt_cv[i].xmax = pt_cv[i].ymin = pt_cv[i].ymax = 0.0;
        pt_cv[i].bg = bg;
        return rt_int(i + 1);
    }
    plt_die("画布已满（最多 %d 个）", PT_MAXCANVAS);
    return rt_none();
}

/* ================= 绘图基元 ================= */

static void pt_px(PtCanvas *c, int x, int y, PtColor col, int solid)
{
    if (x < 0 || y < 0 || x >= c->w || y >= c->h)
        return;
    unsigned char *p = c->px + ((size_t)y * c->w + x) * 4;
    if (solid || col.a >= 255) {
        p[0] = col.r; p[1] = col.g; p[2] = col.b; p[3] = col.a;
    } else {
        int a = col.a;
        int ia = 255 - a;
        p[0] = (unsigned char)((col.r * a + p[0] * ia) / 255);
        p[1] = (unsigned char)((col.g * a + p[1] * ia) / 255);
        p[2] = (unsigned char)((col.b * a + p[2] * ia) / 255);
        p[3] = (unsigned char)(a + p[3] * ia / 255);
    }
}

static void pt_fill(PtCanvas *c, int x0, int y0, int x1, int y1, PtColor col)
{
    if (x0 > x1) { int t = x0; x0 = x1; x1 = t; }
    if (y0 > y1) { int t = y0; y0 = y1; y1 = t; }
    for (int y = y0; y <= y1; y++)
        for (int x = x0; x <= x1; x++)
            pt_px(c, x, y, col, 1);
}

static void pt_box(PtCanvas *c, int x0, int y0, int x1, int y1, PtColor col, int w)
{
    for (int t = 0; t < w; t++) {
        for (int x = x0 - t; x <= x1 + t; x++) {
            pt_px(c, x, y0 - t, col, 1);
            pt_px(c, x, y1 + t, col, 1);
        }
        for (int y = y0 - t; y <= y1 + t; y++) {
            pt_px(c, x0 - t, y, col, 1);
            pt_px(c, x1 + t, y, col, 1);
        }
    }
}

/* Bresenham；粗细 w>1 时按垂直于线段方向的方形笔头铺开 */
static void pt_line(PtCanvas *c, double ax, double ay, double bx, double by,
                    PtColor col, int w)
{
    long x0 = (long)floor(ax + 0.5), y0 = (long)floor(ay + 0.5);
    long x1 = (long)floor(bx + 0.5), y1 = (long)floor(by + 0.5);
    long dx = labs(x1 - x0), sx = x0 < x1 ? 1 : -1;
    long dy = -labs(y1 - y0), sy = y0 < y1 ? 1 : -1;
    long err = dx + dy, e2;
    int hw = (w > 1 ? w : 1) / 2;
    for (;;) {
        if (hw <= 0) pt_px(c, (int)x0, (int)y0, col, 1);
        else
            for (int oy = -hw; oy <= hw; oy++)
                for (int ox = -hw; ox <= hw; ox++)
                    pt_px(c, (int)(x0 + ox), (int)(y0 + oy), col, 1);
        if (x0 == x1 && y0 == y1)
            break;
        e2 = 2 * err;
        if (e2 >= dy) { err += dy; x0 += sx; }
        if (e2 <= dx) { err += dx; y0 += sy; }
    }
}

static void pt_disc(PtCanvas *c, double cx, double cy, double r, PtColor col, int fill)
{
    int ri = (int)ceil(r);
    int ir2 = (int)floor(r + 0.5);
    for (int y = -ri; y <= ri; y++)
        for (int x = -ri; x <= ri; x++) {
            double d = sqrt((double)x * x + (double)y * y);
            if (d <= r)
                pt_px(c, (int)cx + x, (int)cy + y, col, 1);
            else if (!fill && d <= r + 1.0 && d >= ir2 - 1)
                pt_px(c, (int)cx + x, (int)cy + y, col, 1);
        }
}

/* ---- 5x7 点阵字模（32..126 可打印 ASCII，每字 5 列，每列低 7 位有效）---- */
static const unsigned char pt_font[95][5] = {
{0x00,0x00,0x00,0x00,0x00},{0x00,0x00,0x5F,0x00,0x00},{0x00,0x07,0x00,0x07,0x00},
{0x14,0x7F,0x14,0x7F,0x14},{0x24,0x2A,0x7F,0x2A,0x12},{0x23,0x13,0x08,0x64,0x62},
{0x36,0x49,0x55,0x22,0x50},{0x00,0x05,0x03,0x00,0x00},{0x00,0x1C,0x22,0x41,0x00},
{0x00,0x41,0x22,0x1C,0x00},{0x08,0x2A,0x1C,0x2A,0x08},{0x08,0x08,0x3E,0x08,0x08},
{0x00,0x50,0x30,0x00,0x00},{0x08,0x08,0x08,0x08,0x08},{0x00,0x60,0x60,0x00,0x00},
{0x20,0x10,0x08,0x04,0x02},{0x3E,0x51,0x49,0x45,0x3E},{0x00,0x42,0x7F,0x40,0x00},
{0x42,0x61,0x51,0x49,0x46},{0x21,0x41,0x45,0x4B,0x31},{0x18,0x14,0x12,0x7F,0x10},
{0x27,0x45,0x45,0x45,0x39},{0x3C,0x4A,0x49,0x49,0x30},{0x01,0x71,0x09,0x05,0x03},
{0x36,0x49,0x49,0x49,0x36},{0x06,0x49,0x49,0x29,0x1E},{0x00,0x36,0x36,0x00,0x00},
{0x00,0x56,0x36,0x00,0x00},{0x00,0x08,0x14,0x22,0x41},{0x14,0x14,0x14,0x14,0x14},
{0x41,0x22,0x14,0x08,0x00},{0x02,0x01,0x51,0x09,0x06},{0x32,0x49,0x79,0x41,0x3E},
{0x7E,0x11,0x11,0x11,0x7E},{0x7F,0x49,0x49,0x49,0x36},{0x3E,0x41,0x41,0x41,0x22},
{0x7F,0x41,0x41,0x22,0x1C},{0x7F,0x49,0x49,0x49,0x41},{0x7F,0x09,0x09,0x01,0x01},
{0x3E,0x41,0x41,0x51,0x32},{0x7F,0x08,0x08,0x08,0x7F},{0x00,0x41,0x7F,0x41,0x00},
{0x20,0x40,0x41,0x3F,0x01},{0x7F,0x08,0x14,0x22,0x41},{0x7F,0x40,0x40,0x40,0x40},
{0x7F,0x02,0x04,0x02,0x7F},{0x7F,0x04,0x08,0x10,0x7F},{0x3E,0x41,0x41,0x41,0x3E},
{0x7F,0x09,0x09,0x09,0x06},{0x3E,0x41,0x51,0x21,0x5E},{0x7F,0x09,0x19,0x29,0x46},
{0x46,0x49,0x49,0x49,0x31},{0x01,0x01,0x7F,0x01,0x01},{0x3F,0x40,0x40,0x40,0x3F},
{0x1F,0x20,0x40,0x20,0x1F},{0x7F,0x20,0x18,0x20,0x7F},{0x63,0x14,0x08,0x14,0x63},
{0x03,0x04,0x78,0x04,0x03},{0x61,0x51,0x49,0x45,0x43},{0x00,0x00,0x7F,0x41,0x41},
{0x02,0x04,0x08,0x10,0x20},{0x41,0x41,0x7F,0x00,0x00},{0x04,0x02,0x01,0x02,0x04},
{0x40,0x40,0x40,0x40,0x40},{0x00,0x01,0x02,0x04,0x00},{0x20,0x54,0x54,0x54,0x78},
{0x7F,0x48,0x44,0x44,0x38},{0x38,0x44,0x44,0x44,0x20},{0x38,0x44,0x44,0x48,0x7F},
{0x38,0x54,0x54,0x54,0x18},{0x08,0x7E,0x09,0x01,0x02},{0x08,0x14,0x54,0x54,0x3C},
{0x7F,0x08,0x04,0x04,0x78},{0x00,0x44,0x7D,0x40,0x00},{0x20,0x40,0x44,0x3D,0x00},
{0x00,0x7F,0x10,0x28,0x44},{0x00,0x41,0x7F,0x40,0x00},{0x7C,0x04,0x18,0x04,0x78},
{0x7C,0x08,0x04,0x04,0x78},{0x38,0x44,0x44,0x44,0x38},{0x7C,0x14,0x14,0x14,0x08},
{0x08,0x14,0x14,0x18,0x7C},{0x7C,0x08,0x04,0x04,0x08},{0x48,0x54,0x54,0x54,0x20},
{0x04,0x3F,0x44,0x40,0x20},{0x3C,0x40,0x40,0x20,0x7C},{0x1C,0x20,0x40,0x20,0x1C},
{0x3C,0x40,0x30,0x40,0x3C},{0x44,0x28,0x10,0x28,0x44},{0x0C,0x50,0x50,0x50,0x3C},
{0x44,0x64,0x54,0x4C,0x44},{0x00,0x08,0x36,0x41,0x00},{0x00,0x00,0x7F,0x00,0x00},
{0x00,0x41,0x36,0x08,0x00},{0x08,0x08,0x2A,0x1C,0x08},
};

#define PT_GW 5      /* 字宽 */
#define PT_GH 7      /* 字高 */
#define PT_GAP 1     /* 列间距 */

static int pt_text_w(const char *s, int scale)
{
    int n = 0;
    for (const char *p = s; *p; p++)
        if ((*p & 0xC0) != 0x80)      /* 跳过 UTF-8 续字节，非 ASCII 按 1 格 */
            n++;
    if (n <= 0)
        return 0;
    return (n * (PT_GW + PT_GAP) - PT_GAP) * scale;
}

static void pt_text(PtCanvas *c, int x, int y, const char *s, PtColor col, int scale)
{
    if (scale < 1) scale = 1;
    int cx = x;
    for (const unsigned char *p = (const unsigned char *)s; *p; p++) {
        if ((*p & 0xC0) == 0x80)      /* UTF-8 续字节：没有点阵，按空格跳过 */
            continue;
        int ch = *p;
        if (ch < 32 || ch > 126)
            ch = 32;
        const unsigned char *g = pt_font[ch - 32];
        for (int col_i = 0; col_i < PT_GW; col_i++) {
            for (int row = 0; row < PT_GH; row++) {
                if (!(g[col_i] & (1 << row)))
                    continue;
                for (int sy = 0; sy < scale; sy++)
                    for (int sx = 0; sx < scale; sx++)
                        pt_px(c, cx + col_i * scale + sx, y + row * scale + sy, col, 1);
            }
        }
        cx += (PT_GW + PT_GAP) * scale;
    }
}

/* 居中画一行字；返回绘制宽度 */
static int pt_text_c(PtCanvas *c, int cx, int y, const char *s, PtColor col, int scale)
{
    int w = pt_text_w(s, scale);
    pt_text(c, cx - w / 2, y, s, col, scale);
    return w;
}

/* ================= 坐标映射 ================= */

/* 像素 y 向下、数值 y 向上，所以 y 要翻一下 */
static double pt_map_x(const PtCanvas *c, double v)
{
    if (!(c->xmax > c->xmin)) return c->pl;
    return c->pl + (v - c->xmin) / (c->xmax - c->xmin) * (c->pr - c->pl);
}

static double pt_map_y(const PtCanvas *c, double v)
{
    if (!(c->ymax > c->ymin)) return c->pb;
    return c->pb - (v - c->ymin) / (c->ymax - c->ymin) * (c->pb - c->pt_);
}

/* ================= 数值格式 ================= */

/* 图表刻度用的「短小数」：去掉多余的 0，整数就不带小数点 */
static void pt_fmt_num(char *out, size_t cap, double v, int sig)
{
    if (v == 0.0) { snprintf(out, cap, "0"); return; }
    double a = fabs(v);
    if (a >= 1e6 || a < 1e-4) {
        snprintf(out, cap, "%.3g", v);
        return;
    }
    int dec = sig - 1 - (int)floor(log10(a));
    if (dec < 0) dec = 0;
    if (dec > 10) dec = 10;
    snprintf(out, cap, "%.*f", dec, v);
    /* 去掉尾随 0 和尾随小数点 */
    char *dot = strchr(out, '.');
    if (dot) {
        char *e = out + strlen(out) - 1;
        while (e > dot && *e == '0') *e-- = '\0';
        if (*e == '.') *e = '\0';
    }
}

/* ================= 表达式求值器（函数图像用）=================
 * 文法（递归下降）：
 *   expr  := term (('+'|'-') term)*
 *   term  := powr (('*'|'/') powr)*
 *   powr  := unary ('^' powr)?          ^ 右结合
 *   unary := ('+'|'-')* atom
 *   atom  := 数字 | 自由变量 | 常量 | 函数 '(' expr ')' | '(' expr ')'
 * 自由变量：ASCII 标识符且后面不跟 '('，一律当成变量（不必叫 x），
 *   同一条曲线只准出现一个；中文变量名/π/√ 走 sym 那条路（见 pt_fn_prepare）。
 * 只认 ASCII 标识符；未知函数/括号不配对都在这里报带位置的错。 */

typedef struct {
    const char *p, *end;
    double x;
    char var[32];            /* 已认下的自由变量名（第二个不同名字 -> 报错） */
    char err[192];
} Parser;

static void pt_perr(Parser *ps, const char *msg)
{
    if (ps->err[0])
        return;
    snprintf(ps->err, sizeof ps->err, "表达式解析失败：%s", msg);
}

static void pt_skip(Parser *ps)
{
    while (ps->p < ps->end && (*ps->p == ' ' || *ps->p == '\t'))
        ps->p++;
}

static double pt_expr(Parser *ps);
static double pt_powr(Parser *ps);      /* unary 与 powr 互相递归 */

static double pt_atom(Parser *ps)
{
    pt_skip(ps);
    if (ps->p >= ps->end) { pt_perr(ps, "表达式提前结束"); return 0.0; }

    if (*ps->p == '(') {
        ps->p++;
        double v = pt_expr(ps);
        pt_skip(ps);
        if (ps->p < ps->end && *ps->p == ')') { ps->p++; return v; }
        pt_perr(ps, "括号没配对，缺 ')'");
        return 0.0;
    }

    if ((*ps->p >= '0' && *ps->p <= '9') || *ps->p == '.') {
        char *end = NULL;
        double v = strtod(ps->p, &end);
        if (end == ps->p) { pt_perr(ps, "数字写法不对"); return 0.0; }
        ps->p = end;
        return v;
    }

    if ((*ps->p >= 'a' && *ps->p <= 'z') || (*ps->p >= 'A' && *ps->p <= 'Z')) {
        char name[24];
        int n = 0;
        /* 首字符必须是字母，**后续可以带数字** —— 否则 atan2 / log10 / log2
         * 这些函数名会被截成 atan / log，后面的 (0,1) 变成「多余字符」，
         * 函数表里明明写着它们却永远调不到（x1 / x2 这类变量名同理）。 */
        while (ps->p < ps->end
               && ((*ps->p >= 'a' && *ps->p <= 'z')
                   || (*ps->p >= 'A' && *ps->p <= 'Z')
                   || (*ps->p >= '0' && *ps->p <= '9')
                   || *ps->p == '_'))
        {
            if (n < (int)sizeof name - 1) name[n++] = *ps->p;
            ps->p++;
        }
        name[n] = '\0';
        for (int i = 0; i < n; i++)
            if (name[i] >= 'A' && name[i] <= 'Z') name[i] = (char)(name[i] - 'A' + 'a');

        if (strcmp(name, "pi") == 0) return 3.14159265358979323846;
        if (strcmp(name, "e") == 0) return 2.71828182845904523536;

        /* 常量函数（不需要括号） */
        if (strcmp(name, "rand") == 0) return (double)rand() / (double)RAND_MAX;

        pt_skip(ps);
        if (ps->p >= ps->end || *ps->p != '(') {
            /* 后面没有 '(' —— 就不是函数调用，是一个自由变量。
             * 自变量不必限定叫 x：图.曲线("sin(t)*exp(-t^2)", 0, 8) 要能画。
             * 同一条曲线只准有一个自由变量，第二个不同的名字必须报出来
             * （静默取第一个会让 x*y 悄悄丢掉 y，用户看不出图错在哪）。 */
            if (ps->var[0] && strcmp(ps->var, name) != 0) {
                char msg[128];
                snprintf(msg, sizeof msg,
                         "一条曲线只能有一个自由变量，这里同时出现了 %s 和 %s",
                         ps->var, name);
                pt_perr(ps, msg);
                return 0.0;
            }
            if (!ps->var[0])
                snprintf(ps->var, sizeof ps->var, "%s", name);
            return ps->x;
        }
        ps->p++;
        double a = pt_expr(ps);
        pt_skip(ps);
        double b = 0.0;
        int two = 0;
        if (ps->p < ps->end && *ps->p == ',') {
            ps->p++;
            b = pt_expr(ps);
            two = 1;
            pt_skip(ps);
        }
        if (ps->p < ps->end && *ps->p == ')') ps->p++;
        else pt_perr(ps, "括号没配对，缺 ')'");

        if (strcmp(name, "sin") == 0) return sin(a);
        if (strcmp(name, "cos") == 0) return cos(a);
        if (strcmp(name, "tan") == 0) return tan(a);
        if (strcmp(name, "asin") == 0) return asin(a);
        if (strcmp(name, "acos") == 0) return acos(a);
        if (strcmp(name, "atan") == 0) return atan(a);
        if (strcmp(name, "atan2") == 0 && two) return atan2(a, b);
        /* sym 的函数表（SYM_FUNCS）多这三个，纯 ASCII 表达式不必为它绕到
         * sym 那条更慢的路上；补齐之后本地求值器的函数集是 sym 的超集，
         * pt_all_ascii 的分流才站得住（见 pt_fn_prepare）。 */
        if (strcmp(name, "sinh") == 0) return sinh(a);
        if (strcmp(name, "cosh") == 0) return cosh(a);
        if (strcmp(name, "tanh") == 0) return tanh(a);
        if (strcmp(name, "exp") == 0) return exp(a);
        if (strcmp(name, "log") == 0 || strcmp(name, "ln") == 0) return log(a);
        if (strcmp(name, "log10") == 0) return log10(a);
        if (strcmp(name, "log2") == 0) return log2(a);
        if (strcmp(name, "sqrt") == 0) return sqrt(a);
        if (strcmp(name, "abs") == 0) return fabs(a);
        if (strcmp(name, "sign") == 0) return a > 0 ? 1.0 : (a < 0 ? -1.0 : 0.0);
        if (strcmp(name, "floor") == 0) return floor(a);
        if (strcmp(name, "ceil") == 0) return ceil(a);
        if (strcmp(name, "round") == 0) return floor(a + 0.5);
        if (strcmp(name, "min") == 0 && two) return a < b ? a : b;
        if (strcmp(name, "max") == 0 && two) return a > b ? a : b;
        if (strcmp(name, "pow") == 0 && two) return pow(a, b);
        if (strcmp(name, "hypot") == 0 && two) return hypot(a, b);

        pt_perr(ps, "没有这个函数");
        return 0.0;
    }

    pt_perr(ps, "不认识的字符");
    return 0.0;
}

static double pt_unary(Parser *ps)
{
    pt_skip(ps);
    if (ps->p < ps->end && (*ps->p == '-' || *ps->p == '+')) {
        int neg = (*ps->p == '-');
        ps->p++;
        double v = pt_unary(ps);
        return neg ? -v : v;
    }
    return pt_powr(ps);
}

/* ^ 比一元负号紧：-3^2 = -(3^2) = -9（数学惯例）。
 * 递归下降要写成 unary := ('-'|'+') unary | powr，
 * 若写成 powr := unary ('^' powr)?，-3^2 会算成 (-3)^2 = 9，把符号吞进底数了。 */
static double pt_powr(Parser *ps)
{
    double a = pt_atom(ps);
    pt_skip(ps);
    if (ps->p < ps->end && *ps->p == '^') {
        ps->p++;
        double b = pt_unary(ps);          /* 右结合：2^3^2 = 512 */
        return pow(a, b);
    }
    return a;
}

static double pt_term(Parser *ps)
{
    /* 这里必须调 pt_unary 而不是 pt_powr：
     * expr -> term -> unary -> powr -> atom 是标准递归下降链，
     * 一元负号只在 unary 这一层。term 直接调 powr 的话，
     * 表达式开头的 '-' 就没人认了（"-3^2" 会报「不认识的字符」）。 */
    double a = pt_unary(ps);
    for (;;) {
        pt_skip(ps);
        if (ps->p >= ps->end)
            return a;
        char op = *ps->p;
        if (op != '*' && op != '/')
            return a;
        ps->p++;
        double b = pt_unary(ps);
        if (op == '*') a *= b;
        else {
            /* 除以零不是语法错，是这个 x 上的值没定义。
             * 这里必须返回 NaN 而不是 pt_perr：一旦写成错误，图.曲线 会在第一个
             * 除零采样点（x=1、x=0、tan 的 π/2…）把整张图中断掉，
             * 于是凡是带极点的函数都画不出来。NaN 会一路传到 pt_eval 的
             * isfinite 检查，由它统一报「非有限」——图.曲线 抬笔跳过该点，
             * 图.试值 则照常给用户报错。 */
            if (b == 0.0) return 0.0 / 0.0;
            a /= b;
        }
    }
}

static double pt_expr(Parser *ps)
{
    double a = pt_term(ps);
    for (;;) {
        pt_skip(ps);
        if (ps->p >= ps->end)
            return a;
        char op = *ps->p;
        if (op != '+' && op != '-')
            return a;
        ps->p++;
        double b = pt_term(ps);
        a = (op == '+') ? a + b : a - b;
    }
}

static double pt_eval(const char *s, double x, char *err, size_t errcap)
{
    /* 出错时才写 err 是不够的：调用方拿到的是栈上没初始化过的字节，
     * `if (err[0])` 读到垃圾就会把一次成功求值报成解析失败。
     * 这个坑之前靠「栈恰好被清零」蒙混过去，改一点调用栈用量就炸。 */
    if (errcap) err[0] = '\0';
    Parser ps;
    ps.p = s;
    ps.end = s + strlen(s);
    ps.x = x;
    ps.var[0] = '\0';
    ps.err[0] = '\0';
    double v = pt_expr(&ps);
    pt_skip(&ps);
    if (ps.err[0]) {
        snprintf(err, errcap, "%s", ps.err);
        return 0.0;
    }
    if (ps.p != ps.end) {
        snprintf(err, errcap, "表达式 \"%s\" 里有多余的字符 \"%s\"", s, ps.p);
        return 0.0;
    }
    if (!isfinite(v)) {
        /* 画函数图像时越界/除零是常态（比如 tan 在 π/2、1/x 在 0），不该中断整张图。
         * 除零是在 pt_term 里直接返回 NaN 走到这里的，不是解析错。 */
        snprintf(err, errcap, "在 x=%g 处算出非有限值（除零或越界，已跳过该点）", x);
        return v;
    }
    return v;
}

/* ================= 表达式求值：本地求值器 + sym 解析器 =================
 *
 * 图.试值 / 图.曲线 / 图.导数 / 图.切线 / 图.面积 背后要同时认两套写法：
 *   本地求值器 pt_eval   只吃 ASCII；函数表比 sym 宽（max/min/atan2/pow/
 *                       hypot/floor/ceil/round/sign/log2/log10/rand…），也轻。
 *   sym 的解析器          认中文变量名、π、√；函数表多 sinh/cosh/tanh。
 *
 * 分流规则：**纯 ASCII 的一律先走本地求值器，探不过才交给 sym。**
 *   探针 = 在 x=0 处解析一次，只把**语法错**当成「探不过」。
 *   「这个 x 上没定义」（除零、越界）在 err 里是另一句话（「非有限」），
 *   探针必须放它过去 —— 否则 1/x、tan 这类会在 x=0 探针处被误判成
 *   「本地引擎不认识」，整条曲线改走 sym 慢路。
 *   真正落到 sym 的是：含 >= 0x80 字节的表达式（中文变量名 / π / √），
 *   以及纯 ASCII 却本地解析不了的写法。
 * 为什么不全换成 sym：sym 的函数表只有 sin…abs 那十三个，换过去等于删功能
 *   （max/min/atan2/pow/hypot/floor/rand… 全没了，而且 sym 的解析器
 *   遇到这些名字会直接报错，probe 连都过不了）。
 *
 * sym 模式下不用另传变量名：sym_core_vars 取自由变量，正好一个就绑上。
 * 于是 图.曲线("sin(t)*exp(-t^2)", 0, 8) 直接能画，
 * 而 图.曲线("x*t", 0, 8) 会被明确拦下 —— 两个自由变量画不出单变量曲线。
 */

typedef struct {
    const char *src;
    char rewrote[512];      /* √x -> sqrt(x) 的改写结果；空串 = 没改写，src 仍有效 */
    int use_sym;            /* 0=本地求值器；1=sym 解析器 */
    char var[64];           /* sym 模式的自由变量；空 = 常数表达式 */
    char err[192];
} PtFn;

static int pt_all_ascii(const char *s)
{
    for (; *s; s++)
        if ((unsigned char)*s >= 0x80)
            return 0;
    return 1;
}

/* sym 把**没带括号**的 √x 整个当成一个变量名：sym.变量("√x") 给的是 ["√x"]。
 * 于是求值会安静地返回这个变量被绑上的值 —— 图.试值("√x", 9) 会答 9 而不是 3，
 * 图.试值 明明该报「没定义」，却给了一个看着挺合理的错数。
 * pybook_sym.h 里写的「√ 只作用于紧随的原子」在 √(...) 上成立，在 √x 上不成立。
 *
 * 这里把无括号的那一种就地改写成 sqrt(x)：只吃紧跟 √ 的那一段标识符/数字，
 * 一旦它后面还紧跟 '(' 就当函数调用（√sin(x)）不动，交给 sym 报错 ——
 * 那种写法补括号才说得清，替他猜是猜不出来的。
 * 放不写得下就整个放弃改写（下面的变量名检查会兜住，不会退化成安静给错数）。 */
static void pt_rewrite_sqrt(const char *src, char *out, size_t cap)
{
    size_t n = 0;
    out[0] = '\0';
    for (size_t i = 0; src[i]; ) {
        if ((unsigned char)src[i] == 0xE2 && (unsigned char)src[i + 1] == 0x88
            && (unsigned char)src[i + 2] == 0x9A) {
            size_t j = i + 3, k = j;
            while (src[k] == '_' || (src[k] >= '0' && src[k] <= '9')
                   || (src[k] >= 'A' && src[k] <= 'Z')
                   || (src[k] >= 'a' && src[k] <= 'z')
                   || (unsigned char)src[k] >= 0x80)
                k++;
            if (k > j && src[k] != '(') {          /* 不是函数调用才改写 */
                if (n + 5 + (k - j) + 1 >= cap) { out[0] = '\0'; return; }
                memcpy(out + n, "sqrt(", 5);
                n += 5;
                memcpy(out + n, src + j, k - j);
                n += k - j;
                out[n++] = ')';
                i = k;
                continue;
            }
        }
        if (n + 1 >= cap) { out[0] = '\0'; return; }
        out[n++] = src[i++];
    }
    out[n] = '\0';
}

/* 返回 1 可用；返回 0 时原因写在 f->err（调用方拿去直接报错）。
 * 只在「要采很多点」的入口调它（图.曲线 / 图.导数 / 图.面积）；
 * 图.试值 是一次性求值，顺路也调，多花一次探测可以忽略。 */
static int pt_fn_prepare(PtFn *f, const char *src)
{
    f->src = src;
    f->rewrote[0] = '\0';
    f->use_sym = 0;
    f->var[0] = '\0';
    f->err[0] = '\0';

    if (pt_all_ascii(src)) {
        char err[192];
        err[0] = '\0';
        pt_eval(src, 0.0, err, sizeof err);
        if (!err[0] || strstr(err, "非有限")) {
            f->use_sym = 0;
            return 1;
        }
        /* 纯 ASCII 却本地解析不了：交给 sym 再试一次，它的文法更宽，
         * 报错也更具体（下面 sym 那条路会把它的原文带出来）。 */
    }

    f->use_sym = 1;
    pt_rewrite_sqrt(src, f->rewrote, sizeof f->rewrote);
    if (f->rewrote[0])
        f->src = f->rewrote;
    char err[192];
    err[0] = '\0';
    char *vars = sym_core_vars(f->src, err, sizeof err);
    if (!vars) {
        snprintf(f->err, sizeof f->err, "%s", err[0] ? err : "表达式解析失败");
        return 0;
    }
    /* 兜底：变量名里还留着 √ 或 π，说明是无括号的 √x 被 sym 当成了一个变量。
     * 这时候绝不能绑上去求值 —— 那样只会安静地返回一个和根号毫无关系的数。 */
    if (strstr(vars, "\xe2\x88\x9a") || strstr(vars, "\xcf\x80")) {
        snprintf(f->err, sizeof f->err,
                 "\"%s\" 里的 √ 只有写成 √(...) 才算根号；把 √x 改成 √(x)（或 sqrt(x)）",
                 src);
        free(vars);
        return 0;
    }
    int nv = 1;
    for (const char *q = vars; *q; q++)
        if (*q == ',')
            nv++;
    if (nv > 1) {
        snprintf(f->err, sizeof f->err,
                 "一条曲线只能有一个自由变量，\"%s\" 里有 %d 个（%s）；"
                 "把其余变量先定成常数再画", src, nv, vars);
        free(vars);
        return 0;
    }
    if (vars[0]) {
        if (strlen(vars) >= sizeof f->var) {
            snprintf(f->err, sizeof f->err, "变量名太长：%s", vars);
            free(vars);
            return 0;
        }
        strcpy(f->var, vars);
    }
    free(vars);
    return 1;
}

/* f 在 x 处的值。返回非有限 = 这个 x 上没定义（除零/越界），不是错误。 */
static double pt_fn_eval(PtFn *f, double x)
{
    if (!f->use_sym)
        return pt_eval(f->src, x, f->err, sizeof f->err);

    char bind[128];
    if (f->var[0])
        snprintf(bind, sizeof bind, "%s=%.17g", f->var, x);
    else
        bind[0] = '\0';
    double v = 0.0;
    char err[192];
    /* 自由变量在 pt_fn_prepare 里已经全绑上了，所以这里求值失败只剩两种可能：
     * 除零、越界（log 参数 <= 0、sqrt 参数 < 0、负底数配非整数次幂…）。
     * 它们都是「这个 x 上没定义」，交成 NaN 让上层抬笔跳过；
     * 走 sym.求值 那一层会 rt_die 把整张图中断掉，那正是当初除零的坑。 */
    if (!sym_core_eval(f->src, bind, &v, err, sizeof err))
        return 0.0 / 0.0;
    if (!isfinite(v))
        return 0.0 / 0.0;
    return v;
}

/* ================= 图. 画布与基元 ================= */

/* 对外一律固定元数：VM 后端在 pybk_bc.py 里用
 * `len(实参) != LIB_CALLS[名]` 做**整数**比较，元数写成 (最少,最多) 元组就恒不等，
 * 可选参数函数在 VM 里一律编译失败。所以底层实现可以吃可选参数，
 * 但登记出去的入口必须是写死几个参数的。 */
Value rt_plot_canvas(Value wv, Value hv)
{
    return pt_new_canvas((int)pt_int(wv, "画布的宽"), (int)pt_int(hv, "画布的高"),
                         (PtColor){ 255, 255, 255, 255 });
}

Value rt_plot_canvasbg(Value wv, Value hv, Value bgv)
{
    return pt_new_canvas((int)pt_int(wv, "画布的宽"), (int)pt_int(hv, "画布的高"),
                         pt_color(bgv, "画布"));
}

Value rt_plot_clear(Value cv, Value bgv)
{
    PtCanvas *c = pt_get(cv, "清");
    PtColor bg = pt_opt_color(bgv, (PtColor){ 255, 255, 255, 255 }, "清");
    for (int y = 0; y < c->h; y++)
        for (int x = 0; x < c->w; x++)
            pt_px(c, x, y, bg, 1);
    c->has_axis = 0;
    return cv;
}

Value rt_plot_save(Value cv, Value fv)
{
    PtCanvas *c = pt_get(cv, "存");
    const char *name = rt_str_of(fv);
    mm_write_png(name, c->px, (size_t)c->w, (size_t)c->h);
    return rt_str(name);
}

Value rt_plot_size(Value cv)
{
    PtCanvas *c = pt_get(cv, "尺寸");
    Value out = rt_list_new();
    rt_push(&out, rt_int(c->w));
    rt_push(&out, rt_int(c->h));
    return out;
}

Value rt_plot_pixel(Value cv, Value xv, Value yv, Value colv)
{
    PtCanvas *c = pt_get(cv, "像素");
    pt_px(c, (int)pt_int(xv, "像素的 x"), (int)pt_int(yv, "像素的 y"),
          pt_color(colv, "像素"), 1);
    return rt_none();
}

Value rt_plot_at(Value cv, Value xv, Value yv)
{
    PtCanvas *c = pt_get(cv, "读像素");
    int x = (int)pt_int(xv, "读像素的 x"), y = (int)pt_int(yv, "读像素的 y");
    if (x < 0 || y < 0 || x >= c->w || y >= c->h)
        plt_die("读像素：(%d,%d) 越界，画布是 %dx%d", x, y, c->w, c->h);
    unsigned char *p = c->px + ((size_t)y * c->w + x) * 4;
    Value out = rt_list_new();
    rt_push(&out, rt_int(p[0]));
    rt_push(&out, rt_int(p[1]));
    rt_push(&out, rt_int(p[2]));
    rt_push(&out, rt_int(p[3]));
    return out;
}

Value rt_plot_line(Value cv, Value x0v, Value y0v, Value x1v, Value y1v,
                   Value colv, Value wv)
{
    PtCanvas *c = pt_get(cv, "线");
    PtColor col = pt_opt_color(colv, pt_palette[0], "线");
    pt_line(c, pt_num(x0v, "线"), pt_num(y0v, "线"), pt_num(x1v, "线"), pt_num(y1v, "线"),
            col, (int)pt_opt(wv, 1.0, "线的粗细"));
    return cv;
}

Value rt_plot_rect(Value cv, Value xv, Value yv, Value wv, Value hv,
                   Value colv, Value fillv)
{
    PtCanvas *c = pt_get(cv, "框");
    PtColor col = pt_opt_color(colv, pt_palette[0], "框");
    int x = (int)pt_int(xv, "框的 x"), y = (int)pt_int(yv, "框的 y");
    int w = (int)pt_int(wv, "框的宽"), h = (int)pt_int(hv, "框的高");
    if (rt_cond(fillv))
        pt_fill(c, x, y, x + w - 1, y + h - 1, col);
    else
        pt_box(c, x, y, x + w - 1, y + h - 1, col, 1);
    return cv;
}

Value rt_plot_circle(Value cv, Value xv, Value yv, Value rv, Value colv, Value fillv)
{
    PtCanvas *c = pt_get(cv, "圆");
    pt_disc(c, pt_num(xv, "圆心 x"), pt_num(yv, "圆心 y"), pt_num(rv, "半径"),
            pt_opt_color(colv, pt_palette[0], "圆"), rt_cond(fillv));
    return cv;
}

Value rt_plot_text(Value cv, Value xv, Value yv, Value tv, Value colv, Value scv)
{
    PtCanvas *c = pt_get(cv, "字");
    pt_text(c, (int)pt_int(xv, "字的 x"), (int)pt_int(yv, "字的 y"),
            rt_str_of(tv), pt_opt_color(colv, (PtColor){ 0, 0, 0, 255 }, "字"),
            (int)pt_opt(scv, 1.0, "字的缩放"));
    return cv;
}

/* ================= 图. 坐标轴 ================= */

/* 绘图区四边留白。**按画布大小缩放**：小画布上写死 52px 的左边距会吃掉半个图
 * （40x40 时绘图区会被撑到 [52,34,72,54]，整张图都在画布外）。
 * 图.轴 / 图.曲线 / 图.函数 共用这一份，保证同一张画布上三者留白一致。 */
static void pt_margins(PtCanvas *c, int has_title, int has_xlab,
                       int *pl, int *ptop, int *pr, int *pb)
{
    int left = 52, right = 20;
    int top = has_title ? 34 : 14;
    int bot = has_xlab ? 46 : 34;
    if (c->w < 240) { left = c->w / 5 + 8; right = c->w / 12; }
    if (c->h < 200) { top = has_title ? 22 : 8; bot = has_xlab ? 26 : 18; }
    if (left < 6) left = 6;
    if (right < 4) right = 4;
    if (left + right + 24 > c->w) { left = c->w / 3; right = 4; }
    if (top + bot + 24 > c->h) { top = c->h / 3; bot = c->h / 4; }

    *pl = left;
    *ptop = top;
    *pr = c->w - right;
    *pb = c->h - bot;
    /* 画布小到放不下时仍保证区域不反向（会被 pt_px 的边界检查裁掉，不会越界写） */
    if (*pr - *pl < 20) *pr = *pl + 20;
    if (*pb - *ptop < 20) *pb = *ptop + 20;
}

/* 好数步长：把区间切成 1 / 2 / 2.5 / 5 x 10^k 的步长。
 * 十等分出来的刻度常常是 4.6、0.495 这种数，读着像乱码。
 * 注意只改**刻度**，不改用户给的值域 —— 值域一动，图.折线/散点 的
 * 映射就跟着变，用户拿 图.轴 返回的绘图区做的断言会全部失效。 */
static double pt_nice_step(double range, int target)
{
    if (!(range > 0.0)) return 1.0;
    if (target < 1) target = 1;
    double raw = range / (double)target;
    if (!(raw > 0.0)) return 1.0;
    double mag = pow(10.0, floor(log10(raw)));
    double f = raw / mag;                 /* 落在 1..10 */
    double n = (f <= 1.0) ? 1.0 : (f <= 2.0) ? 2.0
             : (f <= 2.5) ? 2.5 : (f <= 5.0) ? 5.0 : 10.0;
    return n * mag;
}

/* 把值域和绘图区写进画布，再画网格/刻度/轴线/标注。
 * 抽出来是因为图.柱状 / 图.直方 在「画布上还没有坐标系」时要自己定域再画轴 ——
 * 它们的值域本来就能从数据算出来，不该逼用户先手调一次 图.轴。 */
static void pt_setup_axis(PtCanvas *c, double xmin, double xmax,
                          double ymin, double ymax,
                          const char *title, const char *xlab, const char *ylab)
{
    PtColor ink = { 60, 60, 66, 255 };
    PtColor grid = { 226, 228, 234, 255 };

    int pl, ptop, pr, pb;
    pt_margins(c, title[0] != 0, xlab[0] != 0, &pl, &ptop, &pr, &pb);

    c->pl = pl; c->pt_ = ptop; c->pr = pr; c->pb = pb;
    c->xmin = xmin; c->xmax = xmax; c->ymin = ymin; c->ymax = ymax;
    c->has_axis = 1;

    if (title[0])
        pt_text_c(c, (pl + pr) / 2, 10, title, ink, 2);

    /* y=0 那条轴线画实一点，其余刻度画淡网格 */
    int has_zero = (ymin <= 0.0 && ymax >= 0.0);
    double ystep = pt_nice_step(ymax - ymin, 10);
    for (int i = 0; i < 64; i++) {
        double v = ceil(ymin / ystep - 1e-9) * ystep + (double)i * ystep;
        if (v > ymax + ystep * 1e-9) break;
        int y = (int)floor(pt_map_y(c, v) + 0.5);
        if (y >= ptop && y <= pb) {
            if (has_zero && fabs(v) < (ymax - ymin) * 1e-9)
                pt_line(c, pl, y, pr, y, ink, 1);
            else
                pt_line(c, pl, y, pr, y, grid, 1);
            char buf[32];
            pt_fmt_num(buf, sizeof buf, v, 4);
            pt_text(c, pl - 8 - pt_text_w(buf, 1), y - 3, buf, ink, 1);
        }
    }
    double xstep = pt_nice_step(xmax - xmin, 10);
    for (int i = 0; i < 64; i++) {
        double v = ceil(xmin / xstep - 1e-9) * xstep + (double)i * xstep;
        if (v > xmax + xstep * 1e-9) break;
        int x = (int)floor(pt_map_x(c, v) + 0.5);
        if (x >= pl && x <= pr) {
            pt_line(c, x, ptop, x, pb, grid, 1);
            char buf[32];
            pt_fmt_num(buf, sizeof buf, v, 4);
            pt_text(c, x - pt_text_w(buf, 1) / 2, pb + 7, buf, ink, 1);
        }
    }

    /* 轴线：左边 + 下边 */
    pt_line(c, pl, ptop, pl, pb, ink, 1);
    pt_line(c, pl, pb, pr, pb, ink, 1);

    if (xlab[0])
        pt_text_c(c, (pl + pr) / 2, pb + 22, xlab, ink, 1);
    if (ylab[0]) {
        /* y 轴名竖排：逐字往下画 */
        int y = (ptop + pb) / 2 - pt_text_w(ylab, 1) / 2;
        pt_text(c, 8, y, ylab, ink, 1);
    }
}

/* 图.轴(画布, xmin, xmax, ymin, ymax[, 标题, x轴名, y轴名]) -> 绘图区 [左,上,右,下]
 * 四边留白按字高量出来，不写死：标题占 26、刻度值占 12、轴名占 14。 */
Value rt_plot_axis(Value cv, Value xminv, Value xmaxv, Value yminv, Value ymaxv,
                   Value titlev, Value xlabv, Value ylabv)
{
    PtCanvas *c = pt_get(cv, "轴");
    double xmin = pt_num(xminv, "轴的 x 下限"), xmax = pt_num(xmaxv, "轴的 x 上限");
    double ymin = pt_num(yminv, "轴的 y 下限"), ymax = pt_num(ymaxv, "轴的 y 上限");
    if (!(xmax > xmin)) plt_die("轴：x 上限要大于下限（收到 %g, %g）", xmin, xmax);
    if (!(ymax > ymin)) plt_die("轴：y 上限要大于下限（收到 %g, %g）", ymin, ymax);

    pt_setup_axis(c, xmin, xmax, ymin, ymax,
                  IS_NONE(titlev) ? "" : rt_str_of(titlev),
                  IS_NONE(xlabv) ? "" : rt_str_of(xlabv),
                  IS_NONE(ylabv) ? "" : rt_str_of(ylabv));

    Value out = rt_list_new();
    rt_push(&out, rt_int(c->pl));
    rt_push(&out, rt_int(c->pt_));
    rt_push(&out, rt_int(c->pr));
    rt_push(&out, rt_int(c->pb));
    return out;
}

static void pt_need_axis_h(PtCanvas *c, const char *who, const char *how)
{
    if (!c->has_axis)
        plt_die("%s：要先用 %s 定好坐标系（值域定了才画得准）", who, how);
}

static void pt_need_axis(PtCanvas *c, const char *who)
{
    pt_need_axis_h(c, who, "图.轴(画布, xmin, xmax, ymin, ymax)");
}

/* ================= 图. 数据图 ================= */

/* 把 PYbook 列表取成 double 数组；非数字 -> NaN（后续自动跳过） */
static double *pt_series(Value v, size_t *n, const char *who)
{
    if (!IS_LIST(v))
        plt_die("%s 需要列表", who);
    RtList *L = AS_LIST(v);
    size_t k = L->len;
    double *a = (double *)malloc((k ? k : 1) * sizeof(double));
    if (!a) plt_die("%s 内存不足", who);
    for (size_t i = 0; i < k; i++) {
        Value e = L->items[i];
        if (IS_FLT(e)) a[i] = AS_FLT(e);
        else if (IS_INT(e) || IS_BIGINT(e)) a[i] = (double)rt_to_ll(e);
        else if (IS_BOOL(e)) a[i] = AS_BOOL(e) ? 1.0 : 0.0;
        else a[i] = 0.0 / 0.0;
    }
    *n = k;
    return a;
}

Value rt_plot_line2(Value cv, Value xsv, Value ysv, Value colv, Value wv)
{
    PtCanvas *c = pt_get(cv, "折线");
    pt_need_axis(c, "折线");
    size_t nx = 0, ny = 0;
    double *xs = pt_series(xsv, &nx, "折线的 x");
    double *ys = pt_series(ysv, &ny, "折线的 y");
    PtColor col = pt_opt_color(colv, pt_palette[0], "折线");
    int w = (int)pt_opt(wv, 2.0, "折线的粗细");

    int pen_down = 0;
    double lx = 0.0, ly = 0.0;
    size_t m = nx < ny ? nx : ny;
    for (size_t i = 0; i < m; i++) {
        if (!isfinite(xs[i]) || !isfinite(ys[i])) { pen_down = 0; continue; }
        double px = pt_map_x(c, xs[i]), py = pt_map_y(c, ys[i]);
        if (pen_down)
            pt_line(c, px, py, lx, ly, col, w);
        lx = px; ly = py;
        pen_down = 1;
    }
    free(xs); free(ys);
    return cv;
}

Value rt_plot_scatter(Value cv, Value xsv, Value ysv, Value colv, Value rv)
{
    PtCanvas *c = pt_get(cv, "散点");
    pt_need_axis(c, "散点");
    size_t nx = 0, ny = 0;
    double *xs = pt_series(xsv, &nx, "散点的 x");
    double *ys = pt_series(ysv, &ny, "散点的 y");
    PtColor col = pt_opt_color(colv, pt_palette[0], "散点");
    double r = pt_opt(rv, 3.0, "散点的半径");
    size_t m = nx < ny ? nx : ny;
    for (size_t i = 0; i < m; i++)
        if (isfinite(xs[i]) && isfinite(ys[i]))
            pt_disc(c, pt_map_x(c, xs[i]), pt_map_y(c, ys[i]), r, col, 1);
    free(xs); free(ys);
    return cv;
}

Value rt_plot_bar(Value cv, Value cats, Value vals, Value colv)
{
    PtCanvas *c = pt_get(cv, "柱状");
    if (!IS_LIST(vals) || !IS_LIST(cats))
        plt_die("柱状：类目和数值都得是列表");
    RtList *CV = AS_LIST(cats), *VV = AS_LIST(vals);
    size_t m = CV->len < VV->len ? CV->len : VV->len;
    if (m == 0) plt_die("柱状：没有数据");

    double vmax = 0.0, vmin = 0.0;
    for (size_t i = 0; i < m; i++) {
        double v = pt_num(VV->items[i], "柱状的数值");
        if (v > vmax) vmax = v;
        if (v < vmin) vmin = v;
    }
    /* 0 基准线之外再留 8% 余量，柱子不顶到框。
     * 注意只有在**已经有坐标系**时才去读 c->ymin/ymax —— 没有坐标系时那几个
     * 字段是没初始化过的垃圾值，拿来当范围会让 pt_map_y 算出 NaN 再越界写崩。 */
    double pad = (vmax - vmin) * 0.08;
    if (pad <= 0) pad = (fabs(vmax) > 0 ? fabs(vmax) : 1.0) * 0.2;
    double lo = vmin - pad, hi = vmax + pad;
    if (c->has_axis) {
        if (c->ymin < lo) lo = c->ymin;
        if (c->ymax > hi) hi = c->ymax;
    }

    /* 画布上还没有坐标系就自己定域并画轴：柱状的值域本来就能从数据算出来，
     * 不该逼调用方先手调一次 图.轴。 */
    if (!c->has_axis)
        pt_setup_axis(c, 0.0, (double)m, lo, hi, "", "", "");

    int y0 = (int)floor(pt_map_y(c, 0.0) + 0.5);
    if (y0 < c->pt_) y0 = c->pt_;
    if (y0 > c->pb) y0 = c->pb;

    PtColor one = { 0, 0, 0, 0 };
    int use_one = !IS_NONE(colv) && !(IS_LIST(colv));
    if (use_one) one = pt_color(colv, "柱状");

    /* 类目占的是 x 轴刻度那条带子：先用底色刷掉 图.轴 画的数字刻度，
     * 否则类目和刻度值会叠在同一行糊成一团（两边都在 pb+7）。
     * 左右各多刷 6px：最外侧那个刻度值是「居中」画在 pl/pr 上的，
     * 会往外探出半个字。 */
    pt_fill(c, c->pl - 6, c->pb + 1, c->pr + 6, c->pb + 14, c->bg);
    double slot = (double)(c->pr - c->pl) / (double)m;
    int bw = (int)(slot * 0.62);
    if (bw < 1) bw = 1;
    for (size_t i = 0; i < m; i++) {
        double v = pt_num(VV->items[i], "柱状的数值");
        int cx = (int)(c->pl + slot * (i + 0.5));
        int x0 = cx - bw / 2, x1 = x0 + bw - 1;
        int yv = (int)floor(pt_map_y(c, v) + 0.5);
        PtColor col = use_one ? one : pt_palette[i % PT_NPALETTE];
        if (yv < y0) pt_fill(c, x0, yv, x1, y0, col);
        else         pt_fill(c, x0, y0, x1, yv, col);
        /* 柱底写**类目**（cats[i]），不是柱子高度 */
        const char *lab = rt_str_of(CV->items[i]);
        pt_text(c, cx - pt_text_w(lab, 1) / 2, c->pb + 7, lab,
                (PtColor){ 60, 60, 66, 255 }, 1);
    }
    return cv;
}

Value rt_plot_hist(Value cv, Value datav, Value binsv, Value colv)
{
    PtCanvas *c = pt_get(cv, "直方");
    size_t n = 0;
    double *d = pt_series(datav, &n, "直方的数据");
    long long nb = pt_opt(binsv, 0.0, "直方的箱数");
    if (n == 0) plt_die("直方：没有数据");
    if (nb < 1) nb = 10;
    if ((size_t)nb > n) nb = (long long)n;

    double lo = d[0], hi = d[0];
    size_t cnt = 0;
    for (size_t i = 0; i < n; i++) {
        if (!isfinite(d[i])) continue;
        if (d[i] < lo) lo = d[i];
        if (d[i] > hi) hi = d[i];
        cnt++;
    }
    if (cnt == 0) plt_die("直方：数据里没有一个有限值");
    if (hi == lo) { hi = lo + 1.0; }

    long long *hist = (long long *)calloc((size_t)nb, sizeof(long long));
    if (!hist) plt_die("直方 内存不足");
    for (size_t i = 0; i < n; i++) {
        if (!isfinite(d[i])) continue;
        long long b = (long long)((d[i] - lo) / (hi - lo) * (double)nb);
        if (b < 0) b = 0;
        if (b >= nb) b = nb - 1;
        hist[b]++;
    }
    long long hmax = 0;
    for (long long i = 0; i < nb; i++) if (hist[i] > hmax) hmax = hist[i];

    c->xmin = lo; c->xmax = hi;
    c->ymin = 0.0; c->ymax = (double)hmax * 1.08;
    /* 同 柱状：直方图的值域完全由数据决定，没有坐标系就自己定域并画轴 */
    if (!c->has_axis)
        pt_setup_axis(c, lo, hi, 0.0, (double)hmax * 1.08, "", "", "");
    PtColor ink = { 60, 60, 66, 255 };
    PtColor col = pt_opt_color(colv, pt_palette[0], "直方");
    int y0 = c->pb;
    double slot = (double)(c->pr - c->pl) / (double)nb;
    int bw = (int)(slot * 0.92);
    if (bw < 1) bw = 1;
    for (long long i = 0; i < nb; i++) {
        int x0 = (int)(c->pl + slot * i);
        int x1 = x0 + bw - 1;
        if (x1 >= c->pr) x1 = c->pr;
        int yv = (int)floor(pt_map_y(c, (double)hist[i]) + 0.5);
        if (yv < c->pt_) yv = c->pt_;
        if (hist[i] > 0) {
            pt_fill(c, x0, yv, x1, y0, col);
            pt_line(c, x0, yv, x1, yv, ink, 1);
        }
        char buf[32];
        snprintf(buf, sizeof buf, "%lld", hist[i]);
        pt_text(c, (x0 + x1) / 2 - pt_text_w(buf, 1) / 2, yv - 10, buf, ink, 1);
    }
    pt_line(c, c->pl, y0, c->pr, y0, ink, 1);
    free(hist);
    free(d);
    return cv;
}

Value rt_plot_pie(Value cv, Value cats, Value vals)
{
    PtCanvas *c = pt_get(cv, "饼图");
    if (!IS_LIST(vals) || !IS_LIST(cats))
        plt_die("饼图：类目和数值都得是列表");
    RtList *CV = AS_LIST(cats), *VV = AS_LIST(vals);
    size_t m = CV->len < VV->len ? CV->len : VV->len;
    if (m == 0) plt_die("饼图：没有数据");

    double total = 0.0;
    for (size_t i = 0; i < m; i++) {
        double v = pt_num(VV->items[i], "饼图的数值");
        if (v < 0) plt_die("饼图：第 %zu 个数值是负的 %g（饼只吃非负）", i + 1, v);
        total += v;
    }
    if (!(total > 0)) plt_die("饼图：所有数值加起来是 %g，没有可画的份额", total);

    const char *title = "";
    int cx = c->w / 2, cy = (c->h + 10) / 2;
    int r = (c->h < c->w ? c->h : c->w) / 2 - 34;
    if (r < 8) plt_die("饼图：画布太小（半径只剩 %d）", r);

    double ang = -M_PI / 2.0;                 /* 12 点方向起 */
    PtColor ink = { 255, 255, 255, 255 };

    for (size_t i = 0; i < m; i++) {
        double frac = pt_num(VV->items[i], "饼图的数值") / total;
        double a0 = ang, a1 = ang + frac * 2.0 * M_PI;
        PtColor col = pt_palette[i % PT_NPALETTE];

        /* 扇形填充：把 [a0,a1] 按 0.5 度取样，连成多边形再逐行扫描填充。
         * 比逐像素判角度省事，也不会在圆心附近留缝。
         * 顶点数是 steps+2（圆心 1 个 + 弧上 steps+1 个），少一个就写到界外去了。 */
        int steps = (int)((a1 - a0) / (M_PI / 360.0)) + 2;
        double *px = (double *)malloc((size_t)(steps + 2) * sizeof(double));
        double *py = (double *)malloc((size_t)(steps + 2) * sizeof(double));
        if (!px || !py) plt_die("饼图 内存不足");
        px[0] = cx; py[0] = cy;
        for (int k = 0; k <= steps; k++) {
            double a = a0 + (a1 - a0) * k / steps;
            px[k + 1] = cx + r * cos(a);
            py[k + 1] = cy + r * sin(a);
        }
        for (int y = cy - r; y <= cy + r; y++) {
            int xs0 = -1, xs1 = -1;
            /* k 要扫到 steps+1（末点）并用取模接回圆心，也就是**闭合**这条多边形。
             * 少扫一圈就等于少了一条「末点->圆心」的边：扫描线只能看到奇数个交点，
             * 填充退化成零星细线，小扇区看着就是「只有描边、里面是白的」。 */
            int vn = steps + 2;
            for (int k = 0; k < vn; k++) {
                int k2 = (k + 1) % vn;
                double yc = py[k];
                if ((yc <= y + 0.5) == (py[k2] <= y + 0.5))
                    continue;
                double t = (y + 0.5 - yc) / (py[k2] - yc);
                int xx = (int)(px[k] + t * (px[k2] - px[k]));
                if (xs0 < 0 || xx < xs0) xs0 = xx;
                if (xx > xs1) xs1 = xx;
            }
            if (xs0 >= 0)
                for (int x = xs0; x <= xs1; x++)
                    pt_px(c, x, y, col, 1);
        }
        free(px); free(py);

        /* 占比标注在扇形外侧 */
        double am = (a0 + a1) / 2.0;
        double lr = r * 0.66;
        char buf[40];
        snprintf(buf, sizeof buf, "%.0f%%", frac * 100.0);
        pt_text_c(c, (int)(cx + lr * cos(am)), (int)(cy + lr * sin(am)) - 3,
                  buf, ink, 1);
        ang = a1;
    }

    /* 图例放右侧 */
    int lx = cx + r + 24;
    if (lx + 90 < c->w) {
        for (size_t i = 0; i < m; i++) {
            int y = cy - (int)(m * 12) / 2 + (int)i * 12;
            pt_fill(c, lx, y, lx + 8, y + 8, pt_palette[i % PT_NPALETTE]);
            pt_text(c, lx + 13, y, rt_str_of(CV->items[i]),
                    (PtColor){ 40, 40, 46, 255 }, 1);
        }
    }
    if (title[0])
        pt_text_c(c, cx, 10, title, (PtColor){ 40, 40, 46, 255 }, 2);
    return cv;
}

Value rt_plot_legend(Value cv, Value xv, Value yv, Value itemsv)
{
    PtCanvas *c = pt_get(cv, "图例");
    if (!IS_LIST(itemsv)) plt_die("图例：需要一个 [(名字, 颜色), ...] 列表");
    RtList *L = AS_LIST(itemsv);
    int x = (int)pt_int(xv, "图例的 x"), y = (int)pt_int(yv, "图例的 y");
    PtColor ink = { 40, 40, 46, 255 };
    for (size_t i = 0; i < L->len; i++) {
        Value it = L->items[i];
        if (!IS_LIST(it) || AS_LIST(it)->len < 1)
            plt_die("图例：第 %zu 项不是 [名字, 颜色]", i + 1);
        RtList *pair = AS_LIST(it);
        const char *name = rt_str_of(pair->items[0]);
        PtColor col = (pair->len >= 2) ? pt_color(pair->items[1], "图例")
                                       : pt_palette[i % PT_NPALETTE];
        int yy = y + (int)i * 13;
        pt_fill(c, x, yy, x + 9, yy + 9, col);
        pt_text(c, x + 14, yy + 1, name, ink, 1);
    }
    return cv;
}

Value rt_plot_palette(void)
{
    Value out = rt_list_new();
    for (int i = 0; i < PT_NPALETTE; i++) {
        Value e = rt_list_new();
        rt_push(&e, rt_int(pt_palette[i].r));
        rt_push(&e, rt_int(pt_palette[i].g));
        rt_push(&e, rt_int(pt_palette[i].b));
        rt_push(&out, e);
    }
    return out;
}

/* ================= 图. 函数图像 ================= */

/* 采样描线：在 [a,b] 上等分采 n+1 个点，非有限处抬笔，断点后头一个样本补圆点。
 * 图.曲线 / 图.导数 / 图.切线 共用这一份 —— 断点和孤立点的语义必须一致，
 * 三个地方各写一遍，迟早会写出三个不一样行为。 */
static void pt_stroke(PtCanvas *c, PtFn *f, double a, double b, long long n,
                      PtColor col, int w)
{
    int pen = 0;
    double lx = 0.0, ly = 0.0;
    for (long long i = 0; i <= n; i++) {
        double x = a + (b - a) * (double)i / (double)n;
        f->err[0] = '\0';
        double y = pt_fn_eval(f, x);
        if (f->err[0] || !isfinite(y)) { pen = 0; continue; }
        double px = pt_map_x(c, x), py = pt_map_y(c, y);
        if (pen) pt_line(c, px, py, lx, ly, col, w);
        /* pen==0 说明这一段是断点后的头一个（或者唯一的一个）样本。
         * 光记不画的话，**孤立点会被整个丢掉**：像 x^x/(x-1) 在 x<0 上
         * 只有整数是真数，整段就只剩几个点，一个都看不见（看着像画坏了）。
         * 所以这里补画一个和线宽相称的圆点。 */
        else pt_disc(c, px, py, (double)w * 0.5 + 0.5, col, 1);
        lx = px; ly = py;
        pen = 1;
    }
}

/* 水平虚线（渐近线用）：8px 一段、画 4px */
static void pt_hdash(PtCanvas *c, int x0, int x1, int y, PtColor col, int w)
{
    if (x1 < x0) { int t = x0; x0 = x1; x1 = t; }
    for (int x = x0; x < x1; x += 8) {
        int xe = x + 4;
        if (xe > x1) xe = x1;
        pt_line(c, x, y, xe, y, col, w);
    }
}

/* 自适应辛普森：sym 积不出来时（返回空串）算 ∫f。
 * 递归到 |S2-S1| <= 1e-9*(1+|S2|) 为止；单点非有限就直接放弃这一段
 * （让调用方拿到 NaN，比拿一个悄悄偏了的数诚实）。 */
static double pt_num_integral(PtFn *f, double a, double b, double fa,
                              double fm, double fb, double whole, int depth)
{
    double m = 0.5 * (a + b);
    double lm = 0.5 * (a + m), rm = 0.5 * (m + b);
    double flm = pt_fn_eval(f, lm), frm = pt_fn_eval(f, rm);
    if (!isfinite(flm) || !isfinite(frm) || !isfinite(whole))
        return 0.0 / 0.0;
    double left  = (m - a) / 6.0 * (fa + 4.0 * flm + fm);
    double right = (b - m) / 6.0 * (fm + 4.0 * frm + fb);
    double s = left + right;
    if (depth <= 0 || fabs(s - whole) <= 1e-9 * (1.0 + fabs(s)))
        return s + (s - whole) / 15.0;         /* Richardson 外推，补回截断误差 */
    return pt_num_integral(f, a, m, fa, flm, fm, left, depth - 1)
         + pt_num_integral(f, m, b, fm, frm, fb, right, depth - 1);
}

static double pt_integrate(PtFn *f, double a, double b)
{
    /* a>b 时要把符号翻回来：sym 那条路算的是 F(b)-F(a)（b<a 就是负的），
     * 数值这条路若直接把端点换过来就永远返回正数，两条路会给出相反的符号。 */
    int flip = 0;
    if (b < a) { double t = a; a = b; b = t; flip = 1; }
    double fa = pt_fn_eval(f, a), fm = pt_fn_eval(f, 0.5 * (a + b)), fb = pt_fn_eval(f, b);
    if (!isfinite(fa) || !isfinite(fm) || !isfinite(fb))
        return 0.0 / 0.0;
    double whole = (b - a) / 6.0 * (fa + 4.0 * fm + fb);
    double v = pt_num_integral(f, a, b, fa, fm, fb, whole, 24);
    return flip ? -v : v;
}

/* 图.试值("sin(x)", 0.5) -> 单个函数值（求值器单独露出来，好断言） */
Value rt_plot_eval(Value ev, Value xv)
{
    const char *s = rt_str_of(ev);
    double x = pt_num(xv, "试值的 x");
    PtFn f;
    if (!pt_fn_prepare(&f, s))
        plt_die("图.试值：%s", f.err);
    double v = pt_fn_eval(&f, x);
    /* 「这个 x 上没定义」在两条求值路径上说法不一样：本地求值器把它写成
     * 「算出非有限值（…已跳过该点）」，sym 那条直接给 NaN、什么都不写。
     * 这里统一成一句话再报出去 —— 同一个错误给用户两种措辞，
     * 写文档和写测试的人都得记两份。 */
    if (f.err[0] && !strstr(f.err, "非有限"))
        plt_die("图.试值：%s", f.err);
    if (!isfinite(v))
        plt_die("图.试值：x=%g 处 \"%s\" 没定义（除零或越界）", x, s);
    return rt_float(v);
}

/* 图.曲线(画布, "表达式", xmin, xmax[, 色, 粗, 采样])
 * y 范围先自己扫一遍算出来，所以调用前不用知道 y 的范围。
 * 扫不到的点（非有限、定义域外）自动断开，不会把曲线连到天上。 */
Value rt_plot_fx(Value cv, Value ev, Value xminv, Value xmaxv,
                 Value colv, Value wv)
{
    PtCanvas *c = pt_get(cv, "曲线");
    const char *src = rt_str_of(ev);
    double xmin = pt_num(xminv, "曲线的 x 下限"), xmax = pt_num(xmaxv, "曲线的 x 上限");
    if (!(xmax > xmin)) plt_die("曲线：x 上限要大于下限（收到 %g, %g）", xmin, xmax);
    long long n = 800;

    /* 第一遍：算 y 范围。err 只在真正语法错时才致命。 */
    PtFn f;
    if (!pt_fn_prepare(&f, src))
        plt_die("曲线：%s", f.err);
    double ymin = 0.0 / 0.0, ymax = 0.0 / 0.0;
    for (long long i = 0; i <= n; i++) {
        double x = xmin + (xmax - xmin) * (double)i / (double)n;
        f.err[0] = '\0';
        double y = pt_fn_eval(&f, x);
        if (f.err[0] && !strstr(f.err, "非有限"))
            plt_die("曲线：%s", f.err);
        if (!isfinite(y)) continue;
        if (!isfinite(ymin) || y < ymin) ymin = y;
        if (!isfinite(ymax) || y > ymax) ymax = y;
    }
    if (!isfinite(ymin) || !isfinite(ymax))
        plt_die("曲线：\"%s\" 在 [%g, %g] 里一个有限值都没算出来", src, xmin, xmax);
    if (ymin == ymax) { ymin -= 1.0; ymax += 1.0; }
    double pad = (ymax - ymin) * 0.06;
    ymin -= pad; ymax += pad;

    /* 第二遍：真的画。坐标系直接落到画布上，不走 图.轴（那是给数据图用的）。 */
    pt_margins(c, 0, 1, &c->pl, &c->pt_, &c->pr, &c->pb);
    if (c->pr - c->pl < 20) c->pr = c->pl + 20;
    if (c->pb - c->pt_ < 20) c->pb = c->pt_ + 20;
    c->xmin = xmin; c->xmax = xmax; c->ymin = ymin; c->ymax = ymax;
    c->has_axis = 1;

    PtColor ink = { 60, 60, 66, 255 };
    PtColor grid = { 226, 228, 234, 255 };
    int has_y0 = (ymin <= 0.0 && ymax >= 0.0);
    /* 刻度必须和 图.轴 用同一套 pt_nice_step，不然同一份数据用「图.轴+折线」
     * 和用「图.曲线」画出来会是两副刻度（一副 10/20/30，一副 832.9/712.4）。
     * 这里只改刻度，不动上面扫出来的 ymin/ymax —— 值域一动曲线的映射就跟着变。 */
    double ystep2 = pt_nice_step(ymax - ymin, 8);
    for (int i = 0; i < 64; i++) {
        double v = ceil(ymin / ystep2 - 1e-9) * ystep2 + (double)i * ystep2;
        if (v > ymax + ystep2 * 1e-9) break;
        int y = (int)floor(pt_map_y(c, v) + 0.5);
        if (y < c->pt_ || y > c->pb) continue;
        if (has_y0 && fabs(v) < (ymax - ymin) * 1e-9) pt_line(c, c->pl, y, c->pr, y, ink, 1);
        else pt_line(c, c->pl, y, c->pr, y, grid, 1);
        char buf[32];
        pt_fmt_num(buf, sizeof buf, v, 4);
        pt_text(c, c->pl - 8 - pt_text_w(buf, 1), y - 3, buf, ink, 1);
    }
    double xstep2 = pt_nice_step(xmax - xmin, 8);
    for (int i = 0; i < 64; i++) {
        double v = ceil(xmin / xstep2 - 1e-9) * xstep2 + (double)i * xstep2;
        if (v > xmax + xstep2 * 1e-9) break;
        int x = (int)floor(pt_map_x(c, v) + 0.5);
        if (x < c->pl || x > c->pr) continue;
        pt_line(c, x, c->pt_, x, c->pb, grid, 1);
        char buf[32];
        pt_fmt_num(buf, sizeof buf, v, 4);
        pt_text(c, x - pt_text_w(buf, 1) / 2, c->pb + 7, buf, ink, 1);
    }
    /* x=0 那条竖线 */
    if (xmin <= 0.0 && xmax >= 0.0) {
        int x = (int)floor(pt_map_x(c, 0.0) + 0.5);
        if (x >= c->pl && x <= c->pr) pt_line(c, x, c->pt_, x, c->pb, ink, 1);
    }
    pt_line(c, c->pl, c->pt_, c->pl, c->pb, ink, 1);
    pt_line(c, c->pl, c->pb, c->pr, c->pb, ink, 1);
    pt_text_c(c, (c->pl + c->pr) / 2, c->pb + 20, src, ink, 1);

    PtColor col = pt_opt_color(colv, pt_palette[0], "曲线");
    int w = (int)pt_opt(wv, 2.0, "曲线的粗细");
    pt_stroke(c, &f, xmin, xmax, n, col, w);
    return cv;
}

/* ================= sym 接入：导数 / 切线 / 渐近线 / 面积 =================
 *
 * 这四个都在画布**已有的**坐标系里作画，绝不自己定值域。
 * 为什么不能照抄 图.曲线 的做法：图.曲线 顺手改掉 c->xmin/xmax/ymin/ymax
 * 并重画坐标轴，而导数的 y 范围常和原函数差一个数量级 —— 那样原曲线会被
 * 重新映射，整张图错位，用户看到的却还是一张「看起来正常」的图。
 * 所以这四个一律先要坐标系（pt_need_axis_h）。
 *
 * 求导/求极限/求积分都直接调 sym_core_*，不走 sym.求导 / sym.极限：
 * 那两层遇到「积不出来」「极限发散」是 rt_die 直接中止程序，
 * 而这两件事在这里正是要探的常态 —— exp(x)*sin(x) 就积不出，
 * 一侧趋于 +inf 另一侧就常常发散。
 */

/* 图.导数(画布, "f(x)", 变量[, 色, 粗]) -> 导函数的表达式串
 * 在画布已有的 x 值域上描 f'(x)，与原曲线同框。 */
Value rt_plot_deriv(Value cv, Value ev, Value varv, Value colv, Value wv)
{
    PtCanvas *c = pt_get(cv, "导数");
    const char *src = rt_str_of(ev);
    const char *var = rt_str_of(varv);
    pt_need_axis_h(c, "导数", "图.曲线 或 图.轴");

    char err[192];
    err[0] = '\0';
    char *d = sym_core_diff(src, var, err, sizeof err);
    if (!d)
        plt_die("导数：%s", err[0] ? err : "求导失败");

    PtFn f;
    /* f.err 是 PtFn 自己的缓冲，free(d) 动不到它 */
    if (!pt_fn_prepare(&f, d))
        plt_die("导数：%s", f.err);

    PtColor col = pt_opt_color(colv, pt_palette[1], "导数");
    int w = (int)pt_opt(wv, 2.0, "导数的粗细");
    pt_stroke(c, &f, c->xmin, c->xmax, 800, col, w);

    Value out = rt_str(d);
    free(d);
    return out;
}

/* 图.切线(画布, "f(x)", 变量, x0[, 色]) -> 斜率
 * 切线画满整个 x 值域（切线本来就贯穿全图，只画切点附近一小段看不出来），
 * 切点补一个圆点。 */
Value rt_plot_tangent(Value cv, Value ev, Value varv, Value x0v, Value colv)
{
    PtCanvas *c = pt_get(cv, "切线");
    const char *src = rt_str_of(ev);
    const char *var = rt_str_of(varv);
    pt_need_axis_h(c, "切线", "图.曲线 或 图.轴");
    double x0 = pt_num(x0v, "切点的横坐标");

    char err[192], bind[160];
    snprintf(bind, sizeof bind, "%s=%.17g", var, x0);
    double y0 = 0.0;
    err[0] = '\0';
    if (!sym_core_eval(src, bind, &y0, err, sizeof err))
        plt_die("切线：x=%g 处 \"%s\" 算不出值（%s）", x0, src,
                err[0] ? err : "除零或越界");

    char *d = sym_core_diff(src, var, err, sizeof err);
    if (!d)
        plt_die("切线：%s", err[0] ? err : "求导失败");
    double k = 0.0;
    err[0] = '\0';
    int ok = sym_core_eval(d, bind, &k, err, sizeof err);
    free(d);
    if (!ok)
        plt_die("切线：x=%g 处的导数算不出值（%s），切线画不出来", x0,
                err[0] ? err : "除零或越界");

    PtColor col = pt_opt_color(colv, pt_palette[3], "切线");
    pt_line(c, pt_map_x(c, c->xmin), pt_map_y(c, y0 + k * (c->xmin - x0)),
            pt_map_x(c, c->xmax), pt_map_y(c, y0 + k * (c->xmax - x0)), col, 2);
    pt_disc(c, pt_map_x(c, x0), pt_map_y(c, y0), 3.5, col, 1);
    return rt_float(k);
}

/* 图.渐近线(画布, "f(x)", 变量[, 色]) -> "y = 1" / "y = 1, y = -1" / ""
 * 只认水平的。竖直/斜渐近线要判断趋近方向，而 sym_core_limit 在无穷点上走
 * 的是数值外推、分不清 x→a 与 x→-a，判了容易给出错的结论，干脆不做。 */
Value rt_plot_asym(Value cv, Value ev, Value varv, Value colv)
{
    PtCanvas *c = pt_get(cv, "渐近线");
    const char *src = rt_str_of(ev);
    const char *var = rt_str_of(varv);
    pt_need_axis_h(c, "渐近线", "图.曲线 或 图.轴");
    PtColor col = pt_opt_color(colv, pt_palette[7], "渐近线");

    char out[192], txt[64];
    double found[2];
    int nfound = 0;
    size_t used = 0;
    out[0] = '\0';
    for (int s = 0; s < 2; s++) {
        char err[192];
        err[0] = '\0';
        char *r = sym_core_limit(src, var, s ? "-inf" : "inf", err, sizeof err);
        if (!r)
            continue;               /* 这一侧发散 / 收敛不下来：没有水平渐近线 */
        char *end = NULL;
        double k = strtod(r, &end);
        while (end && *end == ' ') end++;
        /* 两侧是同一个值时只报一次：exp(-x^2) 两头都趋于 0，
         * 报成 "y = 0, y = 0" 会让人以为找到了两条线 */
        if (end != r && end && *end == '\0' && isfinite(k)
            && fabs(k) < 1e15 && !(nfound && fabs(k - found[0]) <= 1e-12 * (1.0 + fabs(k))))
            found[nfound++] = k;
        free(r);
    }
    for (int i = 0; i < nfound; i++) {
        double k = found[i];
        if (fabs(k - trunc(k)) < 1e-12)
            snprintf(txt, sizeof txt, "y = %lld", (long long)trunc(k));
        else
            snprintf(txt, sizeof txt, "y = %.10g", k);
        used += (size_t)snprintf(out + used, sizeof out - used,
                                 used ? ", %s" : "%s", txt);
        /* 只有落在当前 y 值域里的渐近线才画：线在画布外，看不见也没意义 */
        if (k >= c->ymin && k <= c->ymax) {
            int y = (int)floor(pt_map_y(c, k) + 0.5);
            if (y >= c->pt_ && y <= c->pb)
                pt_hdash(c, c->pl, c->pr, y, col, 1);
        }
    }
    return rt_str(out);
}

/* 图.面积(画布, "f(x)", 变量, a, b[, 色]) -> ∫ₐᵇ f(x)dx（**带符号**）
 * 曲线在 x 轴下方时返回负数（这是定积分本身，不是几何面积）。
 * 面积先问 sym 能不能积：能就给精确值（有理数系数下是精确有理数），
 * 积不出退回自适应辛普森。两种情况都把 [a,b] 上曲线与 x 轴之间填上色。 */
Value rt_plot_area(Value cv, Value ev, Value varv, Value av, Value bv, Value colv)
{
    PtCanvas *c = pt_get(cv, "面积");
    const char *src = rt_str_of(ev);
    const char *var = rt_str_of(varv);
    pt_need_axis_h(c, "面积", "图.曲线 或 图.轴");
    double a = pt_num(av, "面积的下限"), b = pt_num(bv, "面积的上限");

    PtFn f;
    if (!pt_fn_prepare(&f, src))
        plt_die("面积：%s", f.err);

    double area = 0.0 / 0.0;
    int exact = 0;
    char err[192];
    err[0] = '\0';
    /* 积不出来时 sym 返回**空串**（不是 NULL），别把两种当一回事 */
    char *F = sym_core_integrate(src, var, err, sizeof err);
    if (F) {
        if (F[0]) {
            char b1[160], b2[160];
            snprintf(b1, sizeof b1, "%s=%.17g", var, a);
            snprintf(b2, sizeof b2, "%s=%.17g", var, b);
            double fa = 0.0, fb = 0.0;
            if (sym_core_eval(F, b1, &fa, err, sizeof err) &&
                sym_core_eval(F, b2, &fb, err, sizeof err)) {
                area = fb - fa;
                exact = 1;
            }
        }
        free(F);
    }
    if (!exact)
        area = pt_integrate(&f, a, b);
    if (!isfinite(area))
        plt_die("面积：[%g, %g] 上 \"%s\" 有一段没定义，积不出来", a, b, src);

    PtColor col = pt_opt_color(colv, pt_palette[4], "面积");
    int xa = (int)floor(pt_map_x(c, a) + 0.5);
    int xb = (int)floor(pt_map_x(c, b) + 0.5);
    if (xa > xb) { int t = xa; xa = xb; xb = t; }
    if (xa < c->pl) xa = c->pl;
    if (xb > c->pr) xb = c->pr;
    if (xb > xa) {
        long long n = (long long)(xb - xa) * 3;   /* 每像素至少采 3 次，填色不留缝 */
        if (n < 240) n = 240;
        int y0 = (int)floor(pt_map_y(c, 0.0) + 0.5);
        if (y0 < c->pt_) y0 = c->pt_;
        if (y0 > c->pb) y0 = c->pb;
        for (long long i = 0; i <= n; i++) {
            double x = a + (b - a) * (double)i / (double)n;
            int px = (int)floor(pt_map_x(c, x) + 0.5);
            if (px < xa || px > xb) continue;
            double y = pt_fn_eval(&f, x);
            if (!isfinite(y)) continue;
            int py = (int)floor(pt_map_y(c, y) + 0.5);
            if (py < c->pt_) py = c->pt_;
            if (py > c->pb) py = c->pb;
            pt_line(c, px, y0, px, py, col, 1);
        }
    }
    return rt_float(area);
}

/* 图.函数(画布, f, xmin, xmax[, 色, 粗, 采样])：回调用户的 lambda。
 * 依赖 rt_call_value 的分发器（用户程序 main() 开头装），只有 C 后端有。 */
Value rt_plot_fun(Value cv, Value fv, Value xminv, Value xmaxv,
                 Value colv, Value wv)
{
    PtCanvas *c = pt_get(cv, "函数");
    double xmin = pt_num(xminv, "函数的 x 下限"), xmax = pt_num(xmaxv, "函数的 x 上限");
    if (!(xmax > xmin)) plt_die("函数：x 上限要大于下限");
    long long n = 800;

    double *xs = (double *)malloc((size_t)(n + 1) * sizeof(double));
    double *ys = (double *)malloc((size_t)(n + 1) * sizeof(double));
    if (!xs || !ys) plt_die("函数 内存不足");
    double ymin = 0.0 / 0.0, ymax = 0.0 / 0.0;
    for (long long i = 0; i <= n; i++) {
        xs[i] = xmin + (xmax - xmin) * (double)i / (double)n;
        Value r = rt_call1(fv, rt_float(xs[i]));
        double y;
        if (IS_FLT(r)) y = AS_FLT(r);
        else if (IS_INT(r) || IS_BIGINT(r)) y = (double)rt_to_ll(r);
        else y = 0.0 / 0.0;
        ys[i] = y;
        if (!isfinite(y)) continue;
        if (!isfinite(ymin) || y < ymin) ymin = y;
        if (!isfinite(ymax) || y > ymax) ymax = y;
    }
    if (!isfinite(ymin) || !isfinite(ymax)) {
        free(xs); free(ys);
        plt_die("函数：被调的 f 在区间里一个有限值都没返回");
    }
    if (ymin == ymax) { ymin -= 1.0; ymax += 1.0; }
    double pad = (ymax - ymin) * 0.06;
    pt_margins(c, 0, 1, &c->pl, &c->pt_, &c->pr, &c->pb);
    c->xmin = xmin; c->xmax = xmax; c->ymin = ymin - pad; c->ymax = ymax + pad;
    c->has_axis = 1;
    PtColor col = pt_opt_color(colv, pt_palette[0], "函数");
    int w = (int)pt_opt(wv, 2.0, "函数的粗细");
    int pen = 0;
    double lx = 0, ly = 0;
    for (long long i = 0; i <= n; i++) {
        if (!isfinite(ys[i])) { pen = 0; continue; }
        double px = pt_map_x(c, xs[i]), py = pt_map_y(c, ys[i]);
        if (pen) pt_line(c, px, py, lx, ly, col, w);
        lx = px; ly = py;
        pen = 1;
    }
    free(xs); free(ys);
    return cv;
}

/* ================= 表. 表格 ================= */

/* 取某一行的第 c 格。行本身是列表；格越界/行不是列表都返回空盒。
 * 排序里拿到的是**行**而不是整张表，这时必须走这个、不能走 pt_tbl_cell
 * （后者会把行的第 0 格再当列表解一次，字符串被当指针读就段违例了）。 */
static Value pt_row_cell(Value rowv, size_t c)
{
    if (!IS_LIST(rowv))
        return rt_none();
    RtList *row = AS_LIST(rowv);
    return (c < row->len) ? row->items[c] : rt_none();
}

/* 表格 = 列表的列表。允许不齐（短行按「缺格」处理，不补值）。 */
static Value pt_tbl_check(Value t, const char *who)
{
    if (!IS_LIST(t))
        plt_die("%s 需要二维表（列表的列表）", who);
    RtList *R = AS_LIST(t);
    for (size_t i = 0; i < R->len; i++)
        if (!IS_LIST(R->items[i]))
            plt_die("%s：第 %zu 行不是列表", who, i + 1);
    return t;
}

static size_t pt_tbl_cols(Value t)
{
    RtList *R = AS_LIST(t);
    size_t m = 0;
    for (size_t i = 0; i < R->len; i++) {
        size_t n = AS_LIST(R->items[i])->len;
        if (n > m) m = n;
    }
    return m;
}

static Value pt_tbl_cell(Value t, size_t r, size_t c)
{
    RtList *R = AS_LIST(t);
    if (r >= R->len) return rt_none();
    return pt_row_cell(R->items[r], c);
}

/* 显示宽度：UTF-8 按字符数，CJK 记 2 列。表格对齐全靠它。 */
static int pt_disp_w(const char *s)
{
    int w = 0;
    for (const unsigned char *p = (const unsigned char *)s; *p; ) {
        unsigned cp = *p;
        int len = 1;
        if (cp >= 0xF0) { cp &= 0x07; len = 4; }
        else if (cp >= 0xE0) { cp &= 0x0F; len = 3; }
        else if (cp >= 0xC0) { cp &= 0x1F; len = 2; }
        else if (cp >= 0x80) { p++; continue; }
        for (int k = 1; k < len; k++)
            if ((p[k] & 0xC0) == 0x80)
                cp = (cp << 6) | (p[k] & 0x3F);
        p += len;
        /* CJK 统一表意、假名、全角、常用符号区 */
        if ((cp >= 0x1100 && cp <= 0x115F) || (cp >= 0x2E80 && cp <= 0xA4CF)
            || (cp >= 0xAC00 && cp <= 0xD7A3) || (cp >= 0xF900 && cp <= 0xFAFF)
            || (cp >= 0xFE30 && cp <= 0xFE6F) || (cp >= 0xFF00 && cp <= 0xFF60)
            || (cp >= 0xFFE0 && cp <= 0xFFE6))
            w += 2;
        else
            w += 1;
    }
    return w;
}

static int pt_is_num(Value v)
{
    return IS_FLT(v) || IS_INT(v) || IS_BIGINT(v) || IS_BOOL(v);
}

/* 表.画(数据[, 表头]) -> 框线文本。数字列右对齐，文本列左对齐，列宽取全表最大。 */
Value rt_tbl_render(Value tv, Value headv)
{
    pt_tbl_check(tv, "表.画");
    RtList *R = AS_LIST(tv);
    size_t ncol = pt_tbl_cols(tv);
    size_t nrow = R->len;

    /* Value 是整数盒，没有表头用 0/空盒当哨兵（不能用 NULL，那是指针）。
     * 传空列表 [] 等同于「没有表头」，否则会多渲染一行全空的表头。 */
    int has_head = !IS_NONE(headv) && IS_LIST(headv) && AS_LIST(headv)->len > 0;
    Value head = has_head ? headv : rt_none();
    if (has_head && AS_LIST(head)->len > ncol)
        ncol = AS_LIST(head)->len;
    if (ncol == 0)
        return rt_str("");

    /* 列宽：表头 + 所有格子取最大显示宽度 */
    int *w = (int *)calloc(ncol, sizeof(int));
    if (!w) plt_die("表.画 内存不足");
    for (size_t c = 0; c < ncol; c++) {
        if (has_head)
            w[c] = pt_disp_w(rt_str_of(AS_LIST(head)->items[c]));
        for (size_t r = 0; r < nrow; r++) {
            Value cell = pt_tbl_cell(tv, r, c);
            if (IS_NONE(cell)) continue;
            int x = pt_disp_w(rt_str_of(cell));
            if (x > w[c]) w[c] = x;
        }
    }
    /* 这一列全是数字 -> 右对齐 */
    int *num = (int *)calloc(ncol, sizeof(int));
    if (!num) plt_die("表.画 内存不足");
    for (size_t c = 0; c < ncol; c++) {
        int seen = 0, all = 1;
        if (has_head && c < AS_LIST(head)->len && pt_is_num(AS_LIST(head)->items[c]))
            { seen = 1; all = 1; }
        for (size_t r = 0; r < nrow && all; r++) {
            Value cell = pt_tbl_cell(tv, r, c);
            if (IS_NONE(cell)) continue;
            seen = 1;
            if (!pt_is_num(cell)) all = 0;
        }
        num[c] = (seen && all);
    }

    Buf b = { 0, 0, 0 };
    /* ┌─┬─┐ */
    buf_str(&b, B_TL);
    for (size_t c = 0; c < ncol; c++) {
        buf_reps(&b, B_H, w[c] + 2);
        buf_str(&b, (c + 1 == ncol) ? B_TR : B_TT);
    }
    buf_ch(&b, '\n');

    if (has_head) {
        buf_str(&b, B_V);
        for (size_t c = 0; c < ncol; c++) {
            const char *s = (c < AS_LIST(head)->len)
                          ? rt_str_of(AS_LIST(head)->items[c]) : "";
            int pad = w[c] - pt_disp_w(s);
            buf_ch(&b, ' ');
            if (num[c]) { buf_rep(&b, ' ', pad); buf_str(&b, s); }
            else { buf_str(&b, s); buf_rep(&b, ' ', pad); }
            buf_ch(&b, ' '); buf_str(&b, B_V);
        }
        buf_ch(&b, '\n');
        /* ├─┼─┤ */
        buf_str(&b, B_LT);
        for (size_t c = 0; c < ncol; c++) {
            buf_reps(&b, B_H, w[c] + 2);
            buf_str(&b, (c + 1 == ncol) ? B_RT : B_X);
        }
        buf_ch(&b, '\n');
    }

    for (size_t r = 0; r < nrow; r++) {
        buf_str(&b, B_V);
        for (size_t c = 0; c < ncol; c++) {
            Value cell = pt_tbl_cell(tv, r, c);
            const char *s = IS_NONE(cell) ? "" : rt_str_of(cell);
            int pad = w[c] - pt_disp_w(s);
            buf_ch(&b, ' ');
            if (num[c]) { buf_rep(&b, ' ', pad); buf_str(&b, s); }
            else { buf_str(&b, s); buf_rep(&b, ' ', pad); }
            buf_ch(&b, ' '); buf_str(&b, B_V);
        }
        buf_ch(&b, '\n');
    }

    /* └─┴─┘ */
    buf_str(&b, B_BL);
    for (size_t c = 0; c < ncol; c++) {
        buf_reps(&b, B_H, w[c] + 2);
        buf_str(&b, (c + 1 == ncol) ? B_BR : B_BT);
    }
    buf_ch(&b, '\n');

    free(w);
    free(num);
    return buf_val(&b);
}

Value rt_tbl_size(Value tv)
{
    pt_tbl_check(tv, "表.宽");
    Value out = rt_list_new();
    rt_push(&out, rt_int((long long)pt_tbl_cols(tv)));
    rt_push(&out, rt_int((long long)AS_LIST(tv)->len));
    return out;
}

Value rt_tbl_col(Value tv, Value cv)
{
    pt_tbl_check(tv, "表.列");
    RtList *R = AS_LIST(tv);
    size_t ncol = pt_tbl_cols(tv);
    long long idx;
    if (IS_STR(cv)) {
        /* 按表头名字找列：先看第 0 行是不是表头 */
        idx = -1;
        if (R->len > 0) {
            RtList *h = AS_LIST(R->items[0]);
            for (size_t i = 0; i < h->len; i++)
                if (strcmp(rt_str_of(h->items[i]), rt_str_of(cv)) == 0) { idx = (long long)i; break; }
        }
        if (idx < 0)
            plt_die("表.列：第 1 行里没有名叫 \"%s\" 的表头", rt_str_of(cv));
    } else {
        idx = pt_int(cv, "表.列的列号");
    }
    if (idx < 0) idx += (long long)ncol;
    if (idx < 0 || (size_t)idx >= ncol)
        plt_die("表.列：列号 %lld 越界（这张表有 %zu 列）", idx, ncol);
    Value out = rt_list_new();
    for (size_t r = 0; r < R->len; r++) {
        RtList *row = AS_LIST(R->items[r]);
        rt_push(&out, (size_t)idx < row->len ? row->items[idx] : rt_none());
    }
    return out;
}

Value rt_tbl_row(Value tv, Value rv)
{
    pt_tbl_check(tv, "表.行");
    RtList *R = AS_LIST(tv);
    long long idx = pt_int(rv, "表.行的行号");
    if (idx < 0) idx += (long long)R->len;
    if (idx < 0 || (size_t)idx >= R->len)
        plt_die("表.行：行号 %lld 越界（这张表有 %zu 行）", idx, R->len);
    return R->items[idx];
}

Value rt_tbl_cellat(Value tv, Value rv, Value cv)
{
    pt_tbl_check(tv, "表.格");
    RtList *R = AS_LIST(tv);
    long long ri = pt_int(rv, "表.格的行号");
    long long ci = pt_int(cv, "表.格的列号");
    if (ri < 0) ri += (long long)R->len;
    if (ci < 0) ci += (long long)pt_tbl_cols(tv);
    if (ri < 0 || (size_t)ri >= R->len)
        plt_die("表.格：行号 %lld 越界（%zu 行）", ri, R->len);
    RtList *row = AS_LIST(R->items[ri]);
    if (ci < 0 || (size_t)ci >= row->len)
        return rt_none();
    return row->items[ci];
}

Value rt_tbl_transpose(Value tv)
{
    pt_tbl_check(tv, "表.转");
    RtList *R = AS_LIST(tv);
    size_t ncol = pt_tbl_cols(tv);
    Value out = rt_list_new();
    for (size_t c = 0; c < ncol; c++) {
        Value col = rt_list_new();
        for (size_t r = 0; r < R->len; r++)
            rt_push(&col, pt_tbl_cell(tv, r, c));
        rt_push(&out, col);
    }
    return out;
}

Value rt_tbl_slice(Value tv, Value a0v, Value a1v)
{
    pt_tbl_check(tv, "表.选");
    RtList *R = AS_LIST(tv);
    long long n = (long long)R->len;
    long long a0 = pt_int(a0v, "表.选的起"), a1 = pt_int(a1v, "表.选的止");
    if (a0 < 0) a0 += n;
    if (a1 < 0) a1 += n;
    if (a0 < 0) a0 = 0;
    if (a1 > n) a1 = n;
    if (a0 > a1) { long long t = a0; a0 = a1; a1 = t; }
    Value out = rt_list_new();
    for (long long r = a0; r < a1; r++)
        rt_push(&out, R->items[r]);
    return out;
}

static int pt_cmp_cell(Value a, Value b)
{
    if (pt_is_num(a) && pt_is_num(b)) {
        double x = pt_num(a, "排"), y = pt_num(b, "排");
        return (x < y) ? -1 : (x > y ? 1 : 0);
    }
    return strcmp(rt_str_of(a), rt_str_of(b));
}

Value rt_tbl_sort(Value tv, Value cv, Value descv)
{
    pt_tbl_check(tv, "表.排");
    RtList *R = AS_LIST(tv);
    size_t n = R->len;
    size_t ncol = pt_tbl_cols(tv);
    long long key = pt_int(cv, "表.排的列号");
    if (key < 0) key += (long long)ncol;
    if (key < 0 || (size_t)key >= ncol)
        plt_die("表.排：列号 %lld 越界（%zu 列）", key, ncol);
    int desc = rt_cond(descv);

    /* 插入排序：行数都是几十量级，比 qsort 的比较函数省事也够快 */
    Value *rows = (Value *)malloc((n ? n : 1) * sizeof(Value));
    if (!rows) plt_die("表.排 内存不足");
    for (size_t i = 0; i < n; i++) rows[i] = R->items[i];
    for (size_t i = 1; i < n; i++) {
        Value keyv = rows[i];
        Value kv = pt_row_cell(keyv, (size_t)key);     /* 注意：是行，不是整表 */
        size_t j = i;
        while (j > 0) {
            int c = pt_cmp_cell(pt_row_cell(rows[j - 1], (size_t)key), kv);
            if (desc ? (c < 0) : (c > 0)) { rows[j] = rows[j - 1]; j--; }
            else break;
        }
        rows[j] = keyv;
    }
    Value out = rt_list_new();
    for (size_t i = 0; i < n; i++) rt_push(&out, rows[i]);
    free(rows);
    return out;
}

Value rt_tbl_concat(Value av, Value bv)
{
    pt_tbl_check(av, "表.并");
    pt_tbl_check(bv, "表.并");
    RtList *A = AS_LIST(av), *B = AS_LIST(bv);
    Value out = rt_list_new();
    for (size_t i = 0; i < A->len; i++) rt_push(&out, A->items[i]);
    for (size_t i = 0; i < B->len; i++) rt_push(&out, B->items[i]);
    return out;
}

Value rt_tbl_hconcat(Value av, Value bv)
{
    pt_tbl_check(av, "表.接");
    pt_tbl_check(bv, "表.接");
    RtList *A = AS_LIST(av), *B = AS_LIST(bv);
    size_t n = A->len > B->len ? A->len : B->len;
    Value out = rt_list_new();
    for (size_t r = 0; r < n; r++) {
        Value row = rt_list_new();
        if (r < A->len)
            for (size_t c = 0; c < AS_LIST(A->items[r])->len; c++)
                rt_push(&row, AS_LIST(A->items[r])->items[c]);
        if (r < B->len)
            for (size_t c = 0; c < AS_LIST(B->items[r])->len; c++)
                rt_push(&row, AS_LIST(B->items[r])->items[c]);
        rt_push(&out, row);
    }
    return out;
}

/* 表.统(数据, 分组列, 汇总列, "求和"|"均值"|"计数"|"最大"|"最小")
 * 分组列是文本，汇总列是数字。返回 [[组名, 结果], ...]，按组首次出现的顺序。 */
Value rt_tbl_stats(Value tv, Value gcv, Value scv, Value opv)
{
    pt_tbl_check(tv, "表.统");
    RtList *R = AS_LIST(tv);
    size_t ncol = pt_tbl_cols(tv);
    long long gi = pt_int(gcv, "表.统的分组列");
    long long si = IS_NONE(scv) ? gi : pt_int(scv, "表.统的汇总列");
    if (gi < 0) gi += (long long)ncol;
    if (si < 0) si += (long long)ncol;
    if (gi < 0 || (size_t)gi >= ncol)
        plt_die("表.统：分组列 %lld 越界（%zu 列）", gi, ncol);
    const char *op = IS_NONE(opv) ? "求和" : rt_str_of(opv);
    int is_avg = 0, is_cnt = 0, is_max = 0, is_min = 0;
    if (strcmp(op, "求和") == 0) { }
    else if (strcmp(op, "均值") == 0) is_avg = 1;
    else if (strcmp(op, "计数") == 0) is_cnt = 1;
    else if (strcmp(op, "最大") == 0) is_max = 1;
    else if (strcmp(op, "最小") == 0) is_min = 1;
    else plt_die("表.统：只认 求和/均值/计数/最大/最小，收到 \"%s\"", op);

    /* 累加器用**普通 C 数组**而不是「一格一格的 Value 子列表」。
     * 原来把 sum/max/min 各存成一个子列表、每来一行就 rt_push 一个新元素进去，
     * 结果 items[0] 永远是第一次的值（求和 120+150 读出来还是 120）——
     * 追加不是替换。组数少，线性找组就行。 */
    size_t cap = 8, ng = 0;
    char **gname = (char **)malloc(cap * sizeof(char *));
    double *sum = (double *)malloc(cap * sizeof(double));
    double *cnt = (double *)malloc(cap * sizeof(double));
    double *mx = (double *)malloc(cap * sizeof(double));
    double *mn = (double *)malloc(cap * sizeof(double));
    if (!gname || !sum || !cnt || !mx || !mn)
        plt_die("表.统 内存不足");

    for (size_t r = 0; r < R->len; r++) {
        Value g = pt_tbl_cell(tv, r, (size_t)gi);
        const char *gs = IS_NONE(g) ? "" : rt_str_of(g);
        size_t at = (size_t)-1;
        for (size_t k = 0; k < ng; k++)
            if (strcmp(gname[k], gs) == 0) { at = k; break; }
        if (at == (size_t)-1) {
            if (ng == cap) {
                cap *= 2;
                char **n1 = (char **)realloc(gname, cap * sizeof(char *));
                double *n2 = (double *)realloc(sum, cap * sizeof(double));
                double *n3 = (double *)realloc(cnt, cap * sizeof(double));
                double *n4 = (double *)realloc(mx, cap * sizeof(double));
                double *n5 = (double *)realloc(mn, cap * sizeof(double));
                if (!n1 || !n2 || !n3 || !n4 || !n5)
                    plt_die("表.统 内存不足");
                gname = n1; sum = n2; cnt = n3; mx = n4; mn = n5;
            }
            size_t n = strlen(gs);
            char *dup = (char *)malloc(n + 1);
            if (!dup) plt_die("表.统 内存不足");
            memcpy(dup, gs, n + 1);
            gname[ng] = dup;
            sum[ng] = 0.0; cnt[ng] = 0.0;
            mx[ng] = 0.0; mn[ng] = 0.0;
            at = ng++;
        }
        Value cell = pt_tbl_cell(tv, r, (size_t)si);
        double v = 0.0;
        if (!is_cnt) {
            if (!pt_is_num(cell))
                plt_die("表.统：第 %zu 行第 %lld 列不是数字，没法汇总", r + 1, si + 1);
            v = pt_num(cell, "表.统");
            sum[at] += v;
            if (cnt[at] == 0.0) { mx[at] = v; mn[at] = v; }
            else {
                if (v > mx[at]) mx[at] = v;
                if (v < mn[at]) mn[at] = v;
            }
        }
        cnt[at] += 1.0;
    }

    Value out = rt_list_new();
    for (size_t k = 0; k < ng; k++) {
        double res;
        if (is_cnt)          res = cnt[k];
        else if (is_max)     res = mx[k];
        else if (is_min)     res = mn[k];
        else                 res = (is_avg && cnt[k] > 0) ? sum[k] / cnt[k] : sum[k];
        Value row = rt_list_new();
        rt_push(&row, rt_str(gname[k]));
        rt_push(&row, rt_float(res));
        rt_push(&out, row);
        free(gname[k]);
    }
    free(gname); free(sum); free(cnt); free(mx); free(mn);
    return out;
}

/* 表.补(数据, 值)：短行的缺格补上（表.画 之前先补齐，整表才齐整） */
Value rt_tbl_fill(Value tv, Value valv)
{
    pt_tbl_check(tv, "表.补");
    RtList *R = AS_LIST(tv);
    size_t ncol = pt_tbl_cols(tv);
    Value out = rt_list_new();
    for (size_t r = 0; r < R->len; r++) {
        RtList *row = AS_LIST(R->items[r]);
        Value nr = rt_list_new();
        for (size_t c = 0; c < ncol; c++)
            rt_push(&nr, (c < row->len) ? row->items[c] : valv);
        rt_push(&out, nr);
    }
    return out;
}
