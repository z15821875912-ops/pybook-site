@echo off
chcp 65001 >nul 2>&1
setlocal EnableExtensions
set "BASE=%~dp0.."

:: 1) 优先调用官方启动器（发布打包_xxx\运行PYbookIDE.bat）
set "FOUND="
for /d %%d in ("%BASE%\发布打包_*") do (
  if exist "%%d\运行PYbookIDE.bat" set "FOUND=%%d\运行PYbookIDE.bat"
)
if defined FOUND (
  call "%FOUND%"
  exit /b %errorlevel%
)

:: 2) 回退：直接启动仓库根目录的 PYbookIDE.exe
if exist "%BASE%\PYbookIDE.exe" (
  start "" "%BASE%\PYbookIDE.exe"
  exit /b 0
)

echo [PYbook] 找不到 IDE 启动器（发布打包_*\运行PYbookIDE.bat 与 PYbookIDE.exe 均缺失）。
pause
exit /b 1
