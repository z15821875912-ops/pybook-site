# -*- coding: utf-8 -*-
"""_wire_math3.py — 特殊函数 / 一维极值 / 插值拟合 共 11 个入口接进四张表

    pybk_front.py    LIB_CALLS      名字 -> 参数个数（可选参数写成 (最少,最多)）
    pybk_code.py     LIB_C_NAMES    名字 -> C 函数名
    pybook_lib.h     原型           （.inc 自带原型，头文件是给人看的）
    _vm_lib_calls.inc 原型 + 分发表  VM 运行时查表用

家法照 _calc_c.py：原型按**最多**参数个数写，表项只登记**最少**个数，
用户给少的时候由 codegen 补空盒、各后端把空盒当缺省值。

**逐条幂等**：每条入口单独判存在再决定插不插，收尾再逐条复查一遍。
（上一版用前缀匹配挑条目，`mt.lgamma` 开头是 `mt.l`，被前缀规则静默漏掉了。）
"""

import io
import re
import sys

# (前端名, 最少, 最多, C 函数名)
ALL = [
    # ---- 特殊函数：gamma 族走 Lanczos，erf 族走不完全 gamma，zeta 走 Euler-Maclaurin ----
    ('mt.erf',         1, 1, 'rt_lib_mt_erf'),
    ('mt.erfc',        1, 1, 'rt_lib_mt_erfc'),
    ('mt.gamma',       1, 1, 'rt_lib_mt_gamma'),
    ('mt.lgamma',      1, 1, 'rt_lib_mt_lgamma'),
    ('mt.zeta',        1, 1, 'rt_lib_mt_zeta'),
    # ---- 一维极值：黄金分割（不依赖梯度，用户手上往往只有 f 没有 f'）----
    ('mt.golden_min',  2, 4, 'rt_lib_mt_golden_min'),
    ('mt.golden_max',  2, 4, 'rt_lib_mt_golden_max'),
    # ---- 插值与拟合 ----
    ('mp.interp_linear', 3, 3, 'rt_lib_mp_interp_linear'),
    ('mp.interp_cubic',  3, 3, 'rt_lib_mp_interp_cubic'),
    ('mp.linfit',        2, 2, 'rt_lib_mp_linfit'),
    ('mp.polyfit',       3, 3, 'rt_lib_mp_polyfit'),
]

# 分组只决定注释小标题的位置，成员**逐条列出**，不靠前缀猜
GROUPS = [
    ('\n    # ---- 特殊函数（gamma 族 / erf 族 / Riemann zeta）----\n',
     ['mt.erf', 'mt.erfc', 'mt.gamma', 'mt.lgamma', 'mt.zeta']),
    ('\n    # ---- 一维极值：黄金分割（不依赖梯度）----\n',
     ['mt.golden_min', 'mt.golden_max']),
    ('\n    # ---- 插值与拟合（采样点必须严格递增，否则显式报错）----\n',
     ['mp.interp_linear', 'mp.interp_cubic', 'mp.linfit', 'mp.polyfit']),
]
BY_NAME = {n: (lo, hi, c) for n, lo, hi, c in ALL}
NAMES = [n for n, _lo, _hi, _c in ALL]


def rd(p):
    return io.open(p, encoding='utf-8', newline='').read()


def wr(p, t):
    io.open(p, 'w', encoding='utf-8', newline='').write(t)


def ins_lines(p, anchor, marker_of, line_of, tag):
    """把还缺的那些行按顺序插到 anchor 行之后（只补缺的，顺序不变）。"""
    t = rd(p)
    e = '\r\n' if '\r\n' in t else '\n'
    a = anchor.replace('\n', e)
    if a not in t:
        raise SystemExit('%s: 锚点找不到\n%r' % (p, anchor))
    todo = [n for n in NAMES if marker_of(n) not in t]
    if not todo:
        print('  %s: 已齐全（%d 条）' % (p, len(ALL)))
        return 0
    blk = ''.join(line_of(n).replace('\n', e) for n in todo)
    i = t.index(a) + len(a)
    wr(p, t[:i] + blk + t[i:])
    print('  %s: 补上 %d 条 %s（行尾 %s）' % (p, len(todo), tag, 'CRLF' if e == '\r\n' else 'LF'))
    return len(todo)


def arity(n):
    lo, hi, _ = BY_NAME[n]
    return "%d" % lo if lo == hi else "(%d, %d)" % (lo, hi)


def cname(n):
    return BY_NAME[n][2]


# ---------------- 1. pybk_front.py : LIB_CALLS ----------------
print('== pybk_front.py : LIB_CALLS ==')
t = rd('pybk_front.py')
e = '\r\n' if '\r\n' in t else '\n'
anchor1 = "    'mt.taylor': (3, 3),\n"
i = t.index(anchor1.replace('\n', e)) + len(anchor1.replace('\n', e))
blocks = ''
for head, names in GROUPS:
    miss = [n for n in names if "'%s'" % n not in t]
    if miss:
        blocks += head.replace('\n', e)
        blocks += ''.join("    '%s': %s,\n" % (n, arity(n)) for n in miss)
if blocks:
    wr('pybk_front.py', t[:i] + blocks + t[i:])
    print('  补上 %d 条（行尾 %s）' % (blocks.count('\n') - len(GROUPS), 'CRLF' if e == '\r\n' else 'LF'))
else:
    print('  已齐全')

# ---------------- 2. pybk_code.py : LIB_C_NAMES ----------------
print('== pybk_code.py : LIB_C_NAMES ==')
ins_lines('pybk_code.py',
          "        'tb.dot': 'rt_tb_dot', 'tb.tr': 'rt_tb_tr',\n",
          lambda n: "'%s': '%s'" % (n, cname(n)),
          lambda n: "        '%s': '%s',\n" % (n, cname(n)),
          'LIB_C_NAMES')

# ---------------- 3. pybook_lib.h : 原型 ----------------
print('== pybook_lib.h : 原型 ==')
H_DECL = {
    'mt.erf':          'Value rt_lib_mt_erf(Value x);                     /* mt.erf(x) */',
    'mt.erfc':         'Value rt_lib_mt_erfc(Value x);                    /* mt.erfc(x) */',
    'mt.gamma':        'Value rt_lib_mt_gamma(Value x);                   /* mt.gamma(x)，Γ(x) */',
    'mt.lgamma':       'Value rt_lib_mt_lgamma(Value x);                  /* mt.lgamma(x)，ln|Γ(x)| */',
    'mt.zeta':         'Value rt_lib_mt_zeta(Value s);                    /* mt.zeta(s)，s>1 */',
    'mt.golden_min':   'Value rt_lib_mt_golden_min(Value f, Value a, Value b, Value tol);  /* mt.golden_min(f,a,b[,tol]) */',
    'mt.golden_max':   'Value rt_lib_mt_golden_max(Value f, Value a, Value b, Value tol);  /* mt.golden_max(f,a,b[,tol]) */',
    'mp.interp_linear': 'Value rt_lib_mp_interp_linear(Value xs, Value ys, Value q);  /* mp.interp_linear(xs,ys,q) */',
    'mp.interp_cubic':  'Value rt_lib_mp_interp_cubic(Value xs, Value ys, Value q);   /* mp.interp_cubic(xs,ys,q)，Catmull-Rom */',
    'mp.linfit':       'Value rt_lib_mp_linfit(Value xs, Value ys);        /* mp.linfit(xs,ys) -> [斜率,截距,r²] */',
    'mp.polyfit':      'Value rt_lib_mp_polyfit(Value xs, Value ys, Value deg);  /* mp.polyfit(xs,ys,deg) -> 升幂系数 */',
}
ins_lines('pybook_lib.h',
          "Value rt_lib_mt_taylor(Value f, Value x, Value n);"
          "                      /* mt.taylor(f,x,n) */\n",
          lambda n: H_DECL[n].split('(')[0].strip(),
          lambda n: H_DECL[n] + '\n',
          '原型')

# ---------------- 4. _vm_lib_calls.inc : 原型 + 分发表 ----------------
print('== _vm_lib_calls.inc : 原型 + 分发表 ==')
p = '_vm_lib_calls.inc'
t = rd(p)
e = '\r\n' if '\r\n' in t else '\n'
b1 = 'Value rt_lib_mt_taylor(Value, Value, Value);' + e
b2 = '    {"mt.taylor", 3, (void *)rt_lib_mt_taylor},' + e
if b1 not in t or b2 not in t:
    raise SystemExit('%s: 锚点找不到' % p)
todo_d = [n for n in NAMES if 'Value %s(' % cname(n) not in t]
todo_r = [n for n in NAMES if '{"%s",' % n not in t]
if todo_d:
    i = t.index(b1) + len(b1)
    decls = ''.join('Value %s(%s);%s' % (cname(n), ', '.join(['Value'] * BY_NAME[n][1]), e)
                    for n in todo_d)
    t = t[:i] + decls + t[i:]
if todo_r:
    j = t.index(b2) + len(b2)
    rows = ''.join('    {"%s", %d, (void *)%s},%s' % (n, BY_NAME[n][0], cname(n), e)
                   for n in todo_r)
    t = t[:j] + rows + t[j:]
if todo_d or todo_r:
    t = re.sub(r'(\d+) 个库调用',
               lambda m: '%d 个库调用' % (int(m.group(1)) + len(todo_r)), t, count=1)
    wr(p, t)
    print('  补上原型 %d 条 / 表项 %d 条（行尾 %s）'
          % (len(todo_d), len(todo_r), 'CRLF' if e == '\r\n' else 'LF'))
else:
    print('  已齐全')

# ---------------- 收尾复查：11 条必须四表齐全 ----------------
print('== 复查 ==')
front = rd('pybk_front.py')
code = rd('pybk_code.py')
hdr = rd('pybook_lib.h')
inc = rd('_vm_lib_calls.inc')
bad = []
for n, lo, hi, c in ALL:
    for f, s, mark in (('pybk_front.py', front, "'%s'" % n),
                       ('pybk_code.py', code, "'%s': '%s'" % (n, c)),
                       ('pybook_lib.h', hdr, c + '('),
                       ('_vm_lib_calls.inc', inc, '{"%s", %d,' % (n, lo)),
                       ('_vm_lib_calls.inc', inc, 'Value %s(' % c)):
        if mark not in s:
            bad.append('%s 缺 %s 的 %r' % (f, n, mark))
if bad:
    print('\n'.join(bad))
    sys.exit(1)
print('  %d 个入口 × 5 处标记，全部齐全' % len(ALL))
