# -*- coding: utf-8 -*-
"""_stashchk.py — 只读检查 stash@{0} 里有没有那 72 个缺失符号。
如果全有，正确做法就不是反向重建，而是一条命令从 stash 恢复。"""
import re
import subprocess

FILES = ['pybook_lib.c', 'pybook_rt.c', 'mathplus.c', 'pybook_tb.c',
         'pybook_np.c', 'pybook_lib.h', 'pyvm.c', 'pybook_mt.c']


def show(path):
    r = subprocess.run(['git', 'show', 'stash@{0}:%s' % path],
                       capture_output=True, text=True, encoding='utf-8',
                       errors='replace')
    return r.stdout if r.returncode == 0 else None


NEED = [
    'rt_lib_mt_exp', 'rt_lib_mt_deriv', 'rt_lib_mt_erf', 'rt_lib_mt_gamma',
    'rt_lib_mt_zeta', 'rt_lib_mt_golden_min', 'rt_lib_mp_interp_linear',
    'rt_lib_mp_polyfit', 'rt_lib_rd_seed', 'rt_lib_mp_median', 'rt_lib_mp_cov',
    'rt_lib_mp_corr', 'rt_lib_mp_rand_exponential',
    'rt_tensor_get', 'rt_tensor_from_list', 'rt_tensor_new', 'rt_tensor_set',
    'rt_tensor_slice', 'rt_tensor_to_list', 'rt_tensor_cast_v',
    'rt_tensor_prec_v', 'rt_tensor_new_p', 'rt_tensor_round',
    'rt_as_tensor', 'rt_is_tensor',
    'rt_tb_mat32', 'rt_tb_rand32', 'rt_tb_is_gpu', 'rt_tb_gpu_name',
]

blob = {}
for f in FILES:
    t = show(f)
    if t is None:
        print('stash@{0} 里没有 %s' % f)
        continue
    blob[f] = t
    print('%-18s %7d 字节' % (f, len(t)))

print()
print('缺失符号在 stash 里的落实情况：')
found, notfound = [], []
for s in NEED:
    hit = None
    for f, t in blob.items():
        # 定义 = 函数签名后面跟 {
        if re.search(r'\b%s\s*\([^;]*\)\s*\{' % re.escape(s), t):
            hit = f
            break
    if hit:
        found.append((s, hit))
    else:
        notfound.append(s)

print('  有定义 %d 个' % len(found))
for s, f in found:
    print('    ✓ %-26s %s' % (s, f))
print('  仍缺 %d 个：' % len(notfound))
for s in notfound:
    print('    ★ %s' % s)
