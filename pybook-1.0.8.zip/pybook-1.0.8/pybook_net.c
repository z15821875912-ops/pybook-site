/* PYbook 标准库：net 网络模块（TCP，行协议）。
 *
 * 实现：Winsock2。句柄是 INT（进程内句柄表的下标）；每个句柄在 C 侧持有
 * 接收缓冲区（char buf[] + 长度）——recv 先进缓冲、按 \n 切行、半行留在
 * 缓冲，绝不上交半行（防半包 bug 的硬要求）。
 *
 * 阻塞策略：句柄全部设非阻塞（ioctlsocket FIONBIO）；
 *   - net.accept / net.readline 在 C 里循环 非阻塞调用 + Sleep(1)，
 *     不需要线程；
 *   - net.recv 单次非阻塞尝试，没有完整新行返回 ""。
 *
 * 生命周期：WSAStartup 惰性初始化（第一次调 net.* 时），atexit 里 WSACleanup。
 * 编码：收发的字节按 UTF-8 原样进出字符串盒（与文件模块同约定）；
 *       连接地址是 UTF-8，经 MultiByteToWideChar 转 UTF-16 后 GetAddrInfoW。
 *
 * 语言层约定：net.send(句, 文本) 发一行——pybk_code 生成
 *   rt_net_write(句, rt_add(文本, rt_str("\n")))
 * 即 rt_net_write 本身只发原样字节（自测用它构造半包场景）。
 *
 * 自测：gcc -O2 -DNET_SELF_TEST pybook_net.c pybook_rt.c pybook_gpu.c \
 *            -o net_test.exe -lws2_32 -lwininet -I.
 *       （单进程内完成 服务端+客户端、半包、非阻塞计时 三组断言，共 106 项）
 *       pybook_gpu.c 不能少：pybook_rt.c 里的 gpu.* 包装要调它的 gpu_probe /
 *       gpu_die_unavailable，少了就 undefined reference。
 */

/* =============================================================================
 * 平台守卫
 *
 * 本模块目前只有 Windows 实现（Winsock2 + WinINet）。原先这里无条件
 * #include <winsock2.h>，而 Makefile 的非 Windows 分支只 filter-out 了
 * pybook_music.c —— pybook_net.c 仍在 SRC 里，于是 `make OS=linux` / `OS=macos`
 * 编译到本文件就炸（CI 的 ubuntu-latest / macos-latest 正是这么构建 pyvm 的）。
 *
 * 现在的规矩：**非 Windows 也提供同名桩函数**，让构建过去、让符号齐（_vm_lib_calls.inc
 * 声明了这 15 个），但每个桩都明确报错说清"只在 Windows 可用、为什么"，
 * 绝不静默返回空 —— 一个连不上却装作成功的网络函数比没有更坏。
 *
 * 要真跨平台：把下面 #else 分支换成 BSD socket 实现（socket/bind/listen/accept/
 * connect/send/recv/close + getaddrinfo + poll），函数签名一行都不用改。
 * ========================================================================== */
#if defined(_WIN32)
#include <winsock2.h>
#include <ws2tcpip.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <windows.h>
#include <wininet.h>

#include "pybook_rt.h"
#include "pybook_lib.h"

/* ---------- 运行时错误出口（与 pybook_rt 的 rt_die 格式一致） ---------- */

/* 走 rt_die，不自己 fprintf + exit：项目有一套 try / onerror 的长跳转错误链
 * （pybook_rt.c 的 g_err_top / rt_err_raise），只有 rt_die 才会被它们接住。
 * 原先这里直接 exit(1) —— 端口被占用这种运行期状况一点补救余地都没有。 */
static void net_die(const char *fmt, ...)
{
    va_list ap;
    char msg[768];
    va_start(ap, fmt);
    vsnprintf(msg, sizeof msg, fmt, ap);
    va_end(ap);
    rt_die("%s", msg);
}

/* ---------- 句柄表：SOCKET + 接收缓冲 ---------- */

#define NET_BUF_CAP     65536
#define NET_MAX_HANDLES 64

typedef struct {
    SOCKET sock;              /* INVALID_SOCKET = 空槽 */
    char   buf[NET_BUF_CAP];  /* 接收缓冲：半行留这里 */
    size_t len;               /* 缓冲内有效字节数 */
} NetHandle;

static NetHandle g_handles[NET_MAX_HANDLES];
static int g_wsa_ok = 0;
static int g_handles_init = 0;

/* 静态区零初始化的 0 不是 INVALID_SOCKET，首次使用前把空槽补成 INVALID_SOCKET */
static void net_handles_init(void)
{
    int i;
    if (g_handles_init)
        return;
    for (i = 0; i < NET_MAX_HANDLES; i++)
        g_handles[i].sock = INVALID_SOCKET;
    g_handles_init = 1;
}

static void net_cleanup(void)
{
    WSACleanup();
}

static void net_ensure_init(void)
{
    WSADATA d;
    if (g_wsa_ok)
        return;
    if (WSAStartup(MAKEWORD(2, 2), &d) != 0)
        net_die("net：WSAStartup 失败");
    atexit(net_cleanup);      /* 进程退出时 WSACleanup */
    g_wsa_ok = 1;
}

static NetHandle *net_handle(Value hv)
{
    long long h;
    net_handles_init();
    if (!IS_INT(hv))
        net_die("net：句柄需要整数");
    h = AS_INT(hv);
    if (h < 0 || h >= NET_MAX_HANDLES || g_handles[h].sock == INVALID_SOCKET)
        net_die("net：句柄 %lld 不存在或已关闭", h);
    return &g_handles[h];
}

static long long net_new_handle(SOCKET s)
{
    int i;
    net_handles_init();
    for (i = 0; i < NET_MAX_HANDLES; i++) {
        if (g_handles[i].sock == INVALID_SOCKET) {
            g_handles[i].sock = s;
            g_handles[i].len = 0;
            return i;
        }
    }
    net_die("net：句柄表已满（最多 %d 个连接）", NET_MAX_HANDLES);
    return -1;   /* 不可达 */
}

static void net_set_nonblock(SOCKET s)
{
    u_long mode = 1;
    ioctlsocket(s, FIONBIO, &mode);
}

static const char *net_str(Value v, const char *who)
{
    if (!IS_STR(v))
        net_die("%s 需要字符串", who);
    return IS_STR(v) ? (AS_STR(v) ? AS_STR(v) : "") : "";
}

static long long net_port(Value pv, const char *who)
{
    if (!IS_INT(pv))
        net_die("%s 需要整数端口", who);
    return AS_INT(pv);
}

/* ---------- 行缓冲：从句柄缓冲取一行 ---------- */

/* 从 h->buf 里取一行（到 \n 为止，不含 \n；行尾 \r 去掉）。
 * 取到返回该行字符串盒并把剩余字节前移；否则返回 NULL（缓冲不动）。 */
static Value net_take_line(NetHandle *h)
{
    size_t i;
    for (i = 0; i < h->len; i++) {
        if (h->buf[i] == '\n') {
            size_t linelen = i;
            size_t rest = h->len - i - 1;
            char *one;
            Value v;
            if (linelen > 0 && h->buf[linelen - 1] == '\r')
                linelen--;                 /* 兼容 \r\n */
            one = (char *)malloc(linelen + 1);
            if (!one)
                net_die("内存不足");
            memcpy(one, h->buf, linelen);
            one[linelen] = '\0';
            memmove(h->buf, h->buf + i + 1, rest);
            h->len = rest;
            v = rt_str(one);
            free(one);
            return v;
        }
    }
    return (Value)0;
}

/* ---------- 内部：非阻塞收进缓冲 ---------- */

/* 返回 1=收到新字节，0=暂无数据（WSAEWOULDBLOCK），-1=连接已断开 */
static int net_fill(NetHandle *h)
{
    char tmp[4096];
    int r = recv(h->sock, tmp, (int)sizeof tmp, 0);
    if (r > 0) {
        if (r > (int)(NET_BUF_CAP - h->len))     /* 缓冲满：保最新，丢最旧 */
            net_die("net：接收缓冲溢出（单行超过 %d 字节？）", NET_BUF_CAP);
        memcpy(h->buf + h->len, tmp, (size_t)r);
        h->len += (size_t)r;
        return 1;
    }
    if (r == 0)
        return -1;                               /* 对端正常关闭 */
    if (WSAGetLastError() == WSAEWOULDBLOCK)
        return 0;
    return -1;                                   /* 其他错误视为断开 */
}

/* ---------- 对外 API ---------- */

Value rt_net_listen(Value portv)
{
    net_ensure_init();
    {
        long long port = net_port(portv, "net.listen 的端口");
        SOCKET s = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
        struct sockaddr_in addr;
        BOOL reuse = TRUE;
        if (s == INVALID_SOCKET)
            net_die("net.listen：创建套接字失败（错误 %d）", WSAGetLastError());
        setsockopt(s, SOL_SOCKET, SO_REUSEADDR, (const char *)&reuse, sizeof reuse);
        ZeroMemory(&addr, sizeof addr);
        addr.sin_family = AF_INET;
        addr.sin_port = htons((u_short)port);
        addr.sin_addr.s_addr = htonl(INADDR_ANY);
        if (bind(s, (struct sockaddr *)&addr, sizeof addr) != 0) {
            int e = WSAGetLastError();
            closesocket(s);
            net_die("net.listen：绑定端口 %lld 失败（错误 %d，端口被占用？）", port, e);
        }
        if (listen(s, 8) != 0) {
            int e = WSAGetLastError();
            closesocket(s);
            net_die("net.listen：监听失败（错误 %d）", e);
        }
        net_set_nonblock(s);
        return rt_int(net_new_handle(s));
    }
}

Value rt_net_accept(Value lv)
{
    NetHandle *l;
    net_ensure_init();
    l = net_handle(lv);
    for (;;) {
        SOCKET c = accept(l->sock, NULL, NULL);
        if (c != INVALID_SOCKET) {
            net_set_nonblock(c);
            return rt_int(net_new_handle(c));
        }
        if (WSAGetLastError() == WSAEWOULDBLOCK) {
            Sleep(1);              /* 阻塞等连接：非阻塞轮询 + 睡 1ms */
            continue;
        }
        net_die("net.accept：%d", WSAGetLastError());
    }
}

Value rt_net_connect(Value addrv, Value portv)
{
    net_ensure_init();
    {
        const char *host = net_str(addrv, "net.connect 的地址");
        long long port = net_port(portv, "net.connect 的端口");
        wchar_t whost[256], wport[16];
        struct addrinfoW hints, *res = NULL;
        SOCKET s;
        if (!MultiByteToWideChar(CP_UTF8, 0, host, -1,
                                 whost, (int)(sizeof whost / sizeof whost[0])))
            net_die("net.connect：地址编码失败");
        swprintf(wport, (sizeof wport / sizeof wport[0]), L"%lld", port);
        ZeroMemory(&hints, sizeof hints);
        hints.ai_family = AF_INET;
        hints.ai_socktype = SOCK_STREAM;
        hints.ai_protocol = IPPROTO_TCP;
        if (GetAddrInfoW(whost, wport, &hints, &res) != 0 || res == NULL)
            net_die("net.connect：无法解析地址 %s", host);
        s = socket(res->ai_family, res->ai_socktype, res->ai_protocol);
        if (s == INVALID_SOCKET) {
            FreeAddrInfoW(res);
            net_die("net.connect：创建套接字失败（错误 %d）", WSAGetLastError());
        }
        if (connect(s, res->ai_addr, (int)res->ai_addrlen) != 0) {
            int e = WSAGetLastError();
            FreeAddrInfoW(res);
            closesocket(s);
            net_die("net.connect：连接 %s:%lld 失败（错误 %d）", host, port, e);
        }
        FreeAddrInfoW(res);
        net_set_nonblock(s);
        return rt_int(net_new_handle(s));
    }
}

Value rt_net_read(Value hv)
{
    NetHandle *h;
    net_ensure_init();
    h = net_handle(hv);
    for (;;) {
        Value line = net_take_line(h);
        if (line != 0)
            return line;                       /* 缓冲里有完整行 */
        {
            int r = net_fill(h);               /* 非阻塞收一次 */
            if (r == 1)
                continue;                      /* 有新字节，再找 \n */
            if (r == -1) {                     /* 连接断开 */
                if (h->len > 0) {              /* 剩半行：作为最后一行吐出 */
                    char *one = (char *)malloc(h->len + 1);
                    Value v;
                    if (!one)
                        net_die("内存不足");
                    memcpy(one, h->buf, h->len);
                    one[h->len] = '\0';
                    h->len = 0;
                    v = rt_str(one);
                    free(one);
                    return v;
                }
                return rt_str("断");
            }
            return rt_str("");                 /* 暂无完整新行 */
        }
    }
}

Value rt_net_read_block(Value hv)
{
    NetHandle *h;
    net_ensure_init();
    h = net_handle(hv);
    for (;;) {
        Value line = net_take_line(h);
        if (line != 0)
            return line;
        {
            int r = net_fill(h);
            if (r == 1)
                continue;
            if (r == -1) {                     /* 断开：吐残余或报"断" */
                if (h->len > 0) {
                    char *one = (char *)malloc(h->len + 1);
                    Value v;
                    if (!one)
                        net_die("内存不足");
                    memcpy(one, h->buf, h->len);
                    one[h->len] = '\0';
                    h->len = 0;
                    v = rt_str(one);
                    free(one);
                    return v;
                }
                return rt_str("断");
            }
            Sleep(1);                          /* 阻塞模式：轮询 + 睡 1ms */
        }
    }
}

Value rt_net_write(Value hv, Value textv)
{
    NetHandle *h;
    const char *data;
    size_t len, sent;
    net_ensure_init();
    h = net_handle(hv);
    data = net_str(textv, "net.send 的内容");
    len = strlen(data);
    sent = 0;
    while (sent < len) {
        int r = send(h->sock, data + sent, (int)(len - sent), 0);
        if (r == SOCKET_ERROR)
            net_die("net.send：发送失败（错误 %d）", WSAGetLastError());
        sent += (size_t)r;
    }
    return rt_none();
}

Value rt_net_close(Value hv)
{
    NetHandle *h;
    net_ensure_init();
    h = net_handle(hv);
    closesocket(h->sock);
    h->sock = INVALID_SOCKET;
    h->len = 0;
    return rt_none();
}

/* ================= HTTP 客户端（http.get / post / code / err / header / headers / config）========
 *
 * 通路：InternetOpenA → InternetConnectA → HttpOpenRequestA → HttpSendRequestA → 读正文。
 * 不用 InternetOpenUrlA，是因为它既不能带自定义请求头也不能逐段设超时 ——
 * 没有这两样就写不了真正的 API 客户端（Authorization 进不去，Content-Type 读不到，
 * 黑洞连接还会把程序挂死）。
 *
 * 失败纪律（和 mt.* / tb.cholesky 同一个标准：宁可当场报错，不装作成功）：
 *   - 传输层失败（域名解析不了 / 连不上 / 拒绝 / 超时 / TLS 失败 / 读到一半断了）
 *     → 报错，**可被 onerror / try 接住**，原因同时留在 http.err()
 *   - HTTP 层失败（404 / 500 …）→ 不算错误：正文照给，http.code() 是真状态码
 * 老版本这两种失败一律返回 ""、http.code() 一律 0，"服务器说 404" 和 "根本没连上"
 * 长得一模一样 —— 爬虫会把空页面当正常结果存盘（_爬虫迷你.pybk 就是这么写的）。
 */

typedef struct {
    char *host;
    char *path;
    DWORD port;
    int   https;
} HttpUrl;

/* 后面统一实现；这里先声明是因为公开面在上面、实现要用到服务端区的 http_trim_dup */
static char *http_trim_dup(const char *s, size_t n);
static int   http_split_url(const char *url, HttpUrl *u);
static void  http_url_clear(HttpUrl *u);
static Value http_xfer(const char *url, const char *method,
                       const char *body, const char *ctype);

/* 最近一次请求的结果 */
static int   g_http_code = 0;             /* HTTP 状态码；传输层失败 = -1；还没发过 = 0 */
static char  g_http_err[256] = "";        /* 传输层失败原因（成功时清空）*/
static char *g_http_head = NULL;          /* 响应头原文块（\r\n 分隔，末尾空行截断）*/

/* http.config 改的全局默认 */
static DWORD g_cfg_timeout = 15000;       /* 毫秒；连接 / 发送 / 接收 三段各一份 */
static char  g_cfg_agent[128] = "PYbook/1.0";
static char *g_cfg_hdrs = NULL;           /* 追加的默认请求头块，"K: V\r\n" 串 */

/* http.headers() 构造中的字典：rt_str / 字典增长会触发 GC，必须先挂根 */
static Value g_b_hd;
static int   g_client_init = 0;

static void http_client_init(void)
{
    if (g_client_init)
        return;
    rt_root_add(&g_b_hd);
    g_client_init = 1;
}

static void http_head_drop(void)
{
    if (g_http_head != NULL) {
        free(g_http_head);
        g_http_head = NULL;
    }
}

/* WinINet 错误码 → 人话。WinINet 直接把错误码塞进 GetLastError()。 */
static void http_set_err(DWORD e, const char *what)
{
    const char *why;
    switch (e) {
    case 12007: why = "域名解析不了（DNS 查不到这个主机，或网络断了）"; break;
    case 12114: why = "域名解析失败"; break;
    case 12029: why = "连接打不开（对方没在监听，或被防火墙挡了）"; break;
    case 12032: why = "对方拒绝连接（端口没开）"; break;
    case 12030: why = "连接被中止"; break;
    case 12031: why = "连接被重置（对方把连接掐了）"; break;
    case 12002:
    case 12152: why = "超时（对方没在时限内应答）"; break;
    case 12038:
    case 12039: why = "TLS/SSL 握手或证书校验失败"; break;
    case 67:    why = "本机没有网络连接"; break;
    default:    why = "WinINet 底层失败"; break;
    }
    snprintf(g_http_err, sizeof g_http_err, "%s：%s（WinINet %lu）",
             what, why, (unsigned long)e);
}

/* http.get(网址) → 正文。失败报错（可 onerror 接住）。 */
Value rt_http_get(Value urlv)
{
    const char *url = net_str(urlv, "http.get 的网址");
    return http_xfer(url, "GET", NULL, NULL);
}

/* http.post 的薄壳在下方 rt_http_post 原位（只换实现、不挪位置） */
/* 补一个 Content-Type 缺省：写 API 时忘了给类型比给错类型更常见，
   老版本就是在这里兜的默认，新通路要保持同样的行为。 */
#define HTTP_POST_CTYPE_DEFAULT "application/x-www-form-urlencoded"

/* http.code() → 状态码；传输层失败 = -1（和"还没发过"的 0、以及任何真状态码都不同）*/
Value rt_http_code(void)
{
    return rt_int(g_http_code);
}

/* http.err() → 上次传输层失败的原因；没有失败过 = "" */
Value rt_http_err(void)
{
    return rt_str(g_http_err);
}

/* 头名大小写不敏感（HTTP/1.1 里头名不区分大小写）。
   注意是**前缀**比：拿整行去和头名做全串比较，碰到 ':' 必然不等。 */
static int http_iprefix(const char *s, const char *prefix, size_t n)
{
    size_t i;
    for (i = 0; i < n; i++) {
        int a = s[i], b = prefix[i];
        if (a >= 'A' && a <= 'Z') a += 32;
        if (b >= 'A' && b <= 'Z') b += 32;
        if (a != b)
            return 0;
    }
    return 1;
}

/* 在响应头块里找一名（不含值），命中返回指针（在 ": " 之后） */
static const char *http_head_find(const char *head, const char *name)
{
    const char *p = head;
    size_t want = strlen(name);
    while (p != NULL && *p != '\0') {
        const char *eol = strstr(p, "\r\n");
        size_t n = (eol != NULL) ? (size_t)(eol - p) : strlen(p);
        if (n == 0)
            break;                                  /* 空行 = 头结束 */
        if (n > want && p[want] == ':' && http_iprefix(p, name, want)) {
            const char *v = p + want + 1;
            while (*v == ' ' || *v == '\t')
                v++;
            return v;
        }
        if (eol == NULL)
            break;
        p = eol + 2;
    }
    return NULL;
}

/* http.header("Content-Type") → 头的值；这次响应没这个头 = "" */
Value rt_http_header(Value nv)
{
    const char *name = net_str(nv, "http.header 的头名");
    const char *v;
    if (g_http_head == NULL)
        return rt_str("");
    v = http_head_find(g_http_head, name);
    if (v == NULL)
        return rt_str("");
    {
        const char *eol = strstr(v, "\r\n");
        size_t n = (eol != NULL) ? (size_t)(eol - v) : strlen(v);
        char *s = http_trim_dup(v, n);
        Value r = rt_str(s);
        free(s);
        return r;
    }
}

/* http.headers() → 全部响应头的小写键字典 */
Value rt_http_headers(void)
{
    const char *p = g_http_head;
    http_client_init();
    g_b_hd = rt_dict_new();               /* 挂根的槽换新再填 */
    if (p == NULL)
        return g_b_hd;
    while (*p != '\0') {
        const char *eol = strstr(p, "\r\n");
        size_t n = (eol != NULL) ? (size_t)(eol - p) : strlen(p);
        if (n == 0)
            break;                                  /* 空行 = 头结束 */
        /* 跳过状态行 "HTTP/1.1 200 OK" 和续行（行首空白） */
        if (!(n >= 5 && strncmp(p, "HTTP/", 5) == 0) &&
            p[0] != ' ' && p[0] != '\t') {
            char *line = http_trim_dup(p, n);
            char *colon = strchr(line, ':');
            if (colon != NULL) {
                char *k = http_trim_dup(line, (size_t)(colon - line));
                char *v = http_trim_dup(colon + 1, strlen(colon + 1));
                /* 键统一小写：HTTP 头名大小写不敏感，字典查起来省心 */
                char *q;
                for (q = k; *q; q++)
                    if (*q >= 'A' && *q <= 'Z')
                        *q = (char)(*q + 32);
                rt_dict_set(&g_b_hd, rt_str(k), rt_str(v));
                free(k);
                free(v);
            }
            free(line);
        }
        if (eol == NULL)
            break;
        p = eol + 2;
    }
    return g_b_hd;
}

/* http.config({...})：设后续请求的默认值。传空字典 = 复位默认。
 *   {"超时": 5,                       整数的秒（内部 ×1000 当毫秒）
 *    "Agent": "PYbook/1.0",           User-Agent
 *    "头": {"Authorization": "Bearer x", "X-Key": "..."}}  追加的请求头
 * 为什么用单独一通而不是 http.get(url, opts)：库调用元数是编译期定死的，
 * pyvm 的库表按名字查第一条命中（lib_lookup 线性扫），同名两条永远只会用到
 * 第一条 —— 加可选参数要同时改前后端和 VM 调度，不值当。 */
Value rt_http_config(Value ov)
{
    long long n, i;
    http_client_init();
    if (!IS_DICT(ov))
        net_die("http.config 需要一个字典，"
                "比如 {\"超时\": 5, \"Agent\": \"PYbook/1.0\", \"头\": {\"Key\": \"值\"}}");
    n = rt_dict_len_ll(ov);
    if (n == 0) {                                   /* 复位 */
        g_cfg_timeout = 15000;
        strcpy(g_cfg_agent, "PYbook/1.0");
        if (g_cfg_hdrs != NULL) {
            free(g_cfg_hdrs);
            g_cfg_hdrs = NULL;
        }
        return rt_none();
    }
    for (i = 0; i < n; i++) {
        Value k = rt_dict_key_at(ov, i);
        Value v = rt_dict_get(ov, k);
        char *ks = rt_str_of(k);
        if (ks == NULL) {
            net_die("http.config 的键要用字符串");
        } else if (strcmp(ks, "超时") == 0) {
            long long s = IS_INT(v) ? AS_INT(v) : 0;
            if (!IS_INT(v) || s <= 0)
                net_die("http.config 的「超时」要是正整数秒，收到 %s", rt_str_of(v));
            if (s > 600) s = 600;                    /* 10 分钟封顶，别写出永不返回 */
            g_cfg_timeout = (DWORD)(s * 1000);
        } else if (strcmp(ks, "Agent") == 0) {
            char *s = rt_str_of(v);
            if (s == NULL)
                net_die("http.config 的「Agent」要是字符串");
            strncpy(g_cfg_agent, s, sizeof g_cfg_agent - 1);
            g_cfg_agent[sizeof g_cfg_agent - 1] = '\0';
        } else if (strcmp(ks, "头") == 0) {
            long long m, j;
            size_t cap = 256, len = 0;
            if (!IS_DICT(v))
                net_die("http.config 的「头」要是字典，"
                        "比如 {\"Authorization\": \"Bearer 你的令牌\"}");
            if (g_cfg_hdrs != NULL) {
                free(g_cfg_hdrs);
                g_cfg_hdrs = NULL;
            }
            if (rt_dict_len_ll(v) == 0)
                continue;
            g_cfg_hdrs = (char *)malloc(cap);
            if (g_cfg_hdrs == NULL)
                net_die("内存不足");
            m = rt_dict_len_ll(v);
            for (j = 0; j < m; j++) {
                Value hk = rt_dict_key_at(v, j);
                Value hv = rt_dict_get(v, hk);
                char *hn = rt_str_of(hk);
                char *hvv = rt_str_of(hv);
                size_t need;
                if (hn == NULL || hvv == NULL)
                    net_die("http.config 的「头」里 %s 的名字和值都要是字符串", hn ? hn : "?");
                need = strlen(hn) + strlen(hvv) + 8;
                if (len + need > cap) {
                    char *nb;
                    while (len + need > cap)
                        cap *= 2;
                    nb = (char *)realloc(g_cfg_hdrs, cap);
                    if (nb == NULL)
                        net_die("内存不足");
                    g_cfg_hdrs = nb;
                }
                len += (size_t)snprintf(g_cfg_hdrs + len, cap - len,
                                        "%s: %s\r\n", hn, hvv);
            }
        } else {
            net_die("http.config 不认识的键「%s」，可用：超时 / Agent / 头", ks);
        }
    }
    return rt_none();
}

/* ================= HTTP 服务端（http.listen / serve / req / resp） =================
 * 四件套，和 http.get（客户端）同住一文件，C / VM 双管线可用：
 *   http.listen(端口)              → 监听句柄（同 net.listen，net.close 可关）
 *   http.serve(监听句柄)           → 阻塞等一个完整请求 → 会话句柄（>0）；垃圾请求
 *                                    被丢弃继续等，不砸死服务器
 *   http.req(会话句柄)             → 请求字典 {"方法","路径","参数","头","体"}；头的键已小写
 *   http.resp(会话,状态码,正文,"类型") → 发响应并关会话（Connection: close）
 * 会话里的字典挂 GC 根（rt_root_add）。头/体上限 1MB，读超时 10s。 */

#define HTTP_MAX_SESS   64
#define HTTP_MAX_HEAD   (64 * 1024)
#define HTTP_MAX_BODY   (1024 * 1024)
#define HTTP_TIMEOUT_MS 10000

typedef struct {
    SOCKET sock;              /* INVALID_SOCKET = 空槽 */
    Value  req;               /* 请求字典（挂 GC 根），resp 后置空 */
} HttpSess;

static HttpSess g_sess[HTTP_MAX_SESS];
static int g_sess_init = 0;

/* 请求组装三件套：serve 里要边分配边填（rt_str/dict 增长会触发 GC），
   必须挂在 GC 根上才活得到装进 g_sess[i].req 那一刻。全局槽一次挂根、
   每请求换新值，比给栈变量 rt_root_add（悬垂栈地址）安全。 */
static Value g_b_params;
static Value g_b_hdr;
static Value g_b_d;

static void http_sess_init(void)
{
    int i;
    if (g_sess_init)
        return;
    for (i = 0; i < HTTP_MAX_SESS; i++) {
        g_sess[i].sock = INVALID_SOCKET;
        g_sess[i].req = 0;
        rt_root_add(&g_sess[i].req);     /* 字典要在 serve→req 之间活过 GC */
    }
    rt_root_add(&g_b_params);
    rt_root_add(&g_b_hdr);
    rt_root_add(&g_b_d);
    g_sess_init = 1;
}

/* 会话槽校验：返回 NULL 表示句柄无效（调用方自行决定报错还是丢弃）
 *
 * 会话句柄对外是 1 基的（serve 返回槽号+1），0 保留给"没有会话"。
 * 槽 0 是完全合法的会话 —— 早先按 0 基发句柄时，头号请求会被 `if(会话 > 0)`
 * 判成失败静默丢掉，自带示例 _http服务.pybk 就中过这个招。 */
static HttpSess *http_sess(Value hv, const char *who)
{
    long long h;
    http_sess_init();
    if (!IS_INT(hv))
        net_die("%s 需要整数会话句柄", who);
    h = AS_INT(hv);
    if (h < 1 || h > HTTP_MAX_SESS || g_sess[h - 1].sock == INVALID_SOCKET)
        return NULL;
    return &g_sess[h - 1];
}

/* 阻塞收请求头到终止空行；返回 1=收齐 0=对端断/超时。
 * 头在 g_headbuf[0, *outlen)；*out_body_start 起是同包捎带来的体前段，
 * *out_total 是本次总共收到的字节数（体 carry = total - body_start）。 */
static char g_headbuf[HTTP_MAX_HEAD + 1];

static int http_recv_head(SOCKET s, size_t *outlen, size_t *out_body_start, size_t *out_total)
{
    size_t len = 0;
    for (;;) {
        size_t i;
        int r = recv(s, g_headbuf + len, (int)(HTTP_MAX_HEAD - len), 0);
        if (r <= 0)
            return 0;                    /* 断开 / 超时 / 错 */
        len += (size_t)r;
        g_headbuf[len] = '\0';
        for (i = 0; i + 3 < len; i++) {
            if (g_headbuf[i] == '\r' && g_headbuf[i + 1] == '\n'
                && g_headbuf[i + 2] == '\r' && g_headbuf[i + 3] == '\n') {
                g_headbuf[i] = '\0';     /* 掐掉终止空行（体从 i+4 起，留在缓冲里别丢） */
                *outlen = i;
                *out_body_start = i + 4;
                *out_total = len;
                return 1;
            }
        }
        if (len >= HTTP_MAX_HEAD)
            return 0;                    /* 头太大：当垃圾丢弃 */
    }
}

/* 小写化 + 去首尾空白的头名字拷贝（调用方 free） */
static char *http_lower_dup(const char *s, size_t n)
{
    char *p = (char *)malloc(n + 1);
    size_t a = 0, b = n;
    size_t k;
    if (!p)
        net_die("内存不足");
    while (a < b && (s[a] == ' ' || s[a] == '\t'))
        a++;
    while (b > a && (s[b - 1] == ' ' || s[b - 1] == '\t'))
        b--;
    for (k = a; k < b; k++)
        p[k - a] = (s[k] >= 'A' && s[k] <= 'Z') ? (char)(s[k] + 32) : s[k];
    p[b - a] = '\0';
    return p;
}

/* 去首尾空白、保留大小写（头的值 / 请求路径用：它们大小写敏感） */
static char *http_trim_dup(const char *s, size_t n)
{
    char *p;
    size_t a = 0, b = n, k;
    while (a < b && (s[a] == ' ' || s[a] == '\t'))
        a++;
    while (b > a && (s[b - 1] == ' ' || s[b - 1] == '\t'))
        b--;
    p = (char *)malloc(b - a + 1);
    if (!p)
        net_die("内存不足");
    for (k = a; k < b; k++)
        p[k - a] = s[k];
    p[b - a] = '\0';
    return p;
}

static int http_hexv(int c)
{
    if (c >= '0' && c <= '9')
        return c - '0';
    if (c >= 'a' && c <= 'f')
        return c - 'a' + 10;
    if (c >= 'A' && c <= 'F')
        return c - 'A' + 10;
    return -1;
}

/* URL 解码：%XX 十六进制还原，+ 还原成空格；其余原样（不校验 UTF-8 合法性） */
static char *http_url_decode(const char *s, size_t n)
{
    char *p = (char *)malloc(n + 1);
    size_t r = 0, w = 0;
    if (!p)
        net_die("内存不足");
    while (r < n) {
        if (s[r] == '%' && r + 2 < n &&
            http_hexv(s[r + 1]) >= 0 && http_hexv(s[r + 2]) >= 0) {
            p[w++] = (char)(http_hexv(s[r + 1]) * 16 + http_hexv(s[r + 2]));
            r += 3;
        } else if (s[r] == '+') {
            p[w++] = ' ';
            r++;
        } else {
            p[w++] = s[r];
            r++;
        }
    }
    p[w] = '\0';
    return p;
}

Value rt_http_listen(Value portv)
{
    return rt_net_listen(portv);         /* 监听句柄与 net.* 同一张表 */
}

Value rt_http_serve(Value lv)
{
    NetHandle *l;
    SOCKET c;
    size_t hlen = 0, blen = 0;
    size_t bstart = 0, total = 0, carry = 0;   /* 同包捎带来的体字节数 */
    char *body = NULL;
    char *method = NULL, *path = NULL;
    long long sh;

    net_ensure_init();
    http_sess_init();
    g_b_params = rt_dict_new();          /* 查询参数（无 query 就是空字典） */
    l = net_handle(lv);
    for (;;) {                           /* 垃圾请求：丢弃，回到 accept 继续等 */
        size_t i, line_start;
        int r;
        char *sp;
        c = accept(l->sock, NULL, NULL);
        if (c == INVALID_SOCKET) {
            if (WSAGetLastError() == WSAEWOULDBLOCK) {
                Sleep(1);
                continue;
            }
            net_die("http.serve：accept 失败（错误 %d）", WSAGetLastError());
        }
        {
            DWORD tmo = HTTP_TIMEOUT_MS;
            u_long blk = 0;
            /* Windows 的 accept 会继承监听套接字的非阻塞模式（和 BSD 不同）：
               监听是 net.listen 拨成非阻塞的，这里必须拨回阻塞，
               否则 recv 全部 WSAEWOULDBLOCK、请求被当断开丢弃。 */
            ioctlsocket(c, FIONBIO, &blk);
            setsockopt(c, SOL_SOCKET, SO_RCVTIMEO, (const char *)&tmo, sizeof tmo);
        }
        {
            if (!http_recv_head(c, &hlen, &bstart, &total)) {
                closesocket(c);
                continue;
            }
            carry = (total > bstart) ? (total - bstart) : 0;   /* 同包捎带来的体字节数 */
        }

        /* ---- 请求行：METHOD SP PATH [SP HTTP/x] ---- */
        for (i = 0; i < hlen; i++)
            if (g_headbuf[i] == '\r' || g_headbuf[i] == '\n')
                break;
        g_headbuf[i] = '\0';
        sp = strchr(g_headbuf, ' ');
        if (sp == NULL) {
            closesocket(c);
            continue;                    /* 请求行不合法 → 丢弃重等 */
        }
        *sp = '\0';
        method = http_trim_dup(g_headbuf, strlen(g_headbuf));
        {
            size_t q;
            for (q = 0; method[q]; q++)  /* 方法按惯例大写 */
                if (method[q] >= 'a' && method[q] <= 'z')
                    method[q] = (char)(method[q] - 32);
        }
        path = http_trim_dup(sp + 1, strlen(sp + 1));
        sp = strchr(path, ' ');
        if (sp != NULL)
            *sp = '\0';                  /* 掐掉 HTTP/x */

        /* ---- 查询字符串：路径?名=值&... → 路径（URL 解码）+ 参数（解码字典） ---- */
        {
            char *qm = strchr(path, '?');
            if (qm != NULL) {
                /* query 必须先拷出来：path 马上被解码替换并 free，
                   拿旧缓冲的指针解析 = use-after-free（实测第二组参数
                   读进分配器复用后的垃圾）。 */
                char *query = http_trim_dup(qm + 1, strlen(qm + 1));
                char *seg;
                char *dec;
                *qm = '\0';
                dec = http_url_decode(path, strlen(path));
                free(path);
                path = dec;
                seg = query;
                while (*seg != '\0') {
                    char *amp = strchr(seg, '&');
                    char *eq;
                    char *name, *val;
                    if (amp != NULL)
                        *amp = '\0';
                    eq = strchr(seg, '=');
                    if (eq != NULL) {
                        name = http_url_decode(seg, (size_t)(eq - seg));
                        val = http_url_decode(eq + 1, strlen(eq + 1));
                    } else {
                        name = http_url_decode(seg, strlen(seg));
                        val = http_url_decode("", 0);
                    }
                    rt_dict_set(&g_b_params, rt_str(name), rt_str(val));
                    free(name);
                    free(val);
                    if (amp == NULL)
                        break;
                    seg = amp + 1;
                }
                free(query);
            }
        }

        /* ---- 头：小写键 → 值（行 "Name: value"，到空行止）。
            有界扫描，绝不改写缓冲——旧版把行尾写 '\0'，strchr 从下一行
            一开始就被它挡住，第一条之后的头全部静默丢失。 ---- */
        g_b_hdr = rt_dict_new();
        line_start = i + 1;
        while (line_start < hlen) {
            size_t e = line_start, colon = 0, vs;
            int has_colon = 0, c2;
            while (e < hlen && g_headbuf[e] != '\r' && g_headbuf[e] != '\n')
                e++;
            for (c2 = (int)line_start; c2 < (int)e; c2++) {
                if (g_headbuf[c2] == ':') {
                    colon = (size_t)c2;
                    has_colon = 1;
                    break;
                }
            }
            if (has_colon && e > colon) {
                char *name = http_lower_dup(g_headbuf + line_start, colon - line_start);
                char *val;
                vs = colon + 1;
                while (vs < e && (g_headbuf[vs] == ' ' || g_headbuf[vs] == '\t'))
                    vs++;
                val = http_trim_dup(g_headbuf + vs, e - vs);
                rt_dict_set(&g_b_hdr, rt_str(name), rt_str(val));
                free(name);
                free(val);
            }
            while (e < hlen && (g_headbuf[e] == '\r' || g_headbuf[e] == '\n'))
                e++;
            line_start = e;
        }

        /* ---- 体：按 Content-Length（头键已小写，直接查表） ---- */
        if (rt_dict_has(g_b_hdr, rt_str("content-length"))) {
            const char *cl = AS_STR(rt_dict_get(g_b_hdr, rt_str("content-length")));
            long long want = _atoi64(cl);
            if (want > 0 && want <= HTTP_MAX_BODY) {
                body = (char *)malloc((size_t)want + 1);
                if (body != NULL) {
                    /* ① 先吃同包捎带的（recv_head 在终止空行后多收到的） */
                    carry = (carry > (size_t)want) ? (size_t)want : carry;
                    memcpy(body, g_headbuf + bstart, carry);
                    blen = carry;
                    /* ② 再从套接字收余下 */
                    while ((long long)blen < want) {
                        r = recv(c, body + blen, (int)(want - blen), 0);
                        if (r <= 0)
                            break;
                        blen += (size_t)r;
                    }
                    body[blen] = '\0';
                }
            }
        }

        /* ---- 组请求字典，占一个会话槽 ---- */
        g_b_d = rt_dict_new();
        rt_dict_set(&g_b_d, rt_str("方法"), rt_str(method));
        rt_dict_set(&g_b_d, rt_str("路径"), rt_str(path));
        rt_dict_set(&g_b_d, rt_str("参数"), g_b_params);
        rt_dict_set(&g_b_d, rt_str("头"), g_b_hdr);
        rt_dict_set(&g_b_d, rt_str("体"), rt_str(body ? body : ""));
        free(body);
        free(method);
        free(path);

        for (sh = 0; sh < HTTP_MAX_SESS; sh++) {
            if (g_sess[sh].sock == INVALID_SOCKET)
                break;
        }
        if (sh >= HTTP_MAX_SESS) {
            const char *busy = "HTTP/1.1 503 Busy\r\nContent-Length: 0\r\nConnection: close\r\n\r\n";
            send(c, busy, (int)strlen(busy), 0);
            closesocket(c);
            continue;
        }
        g_sess[sh].sock = c;
        g_sess[sh].req = g_b_d;
        return rt_int(sh + 1);       /* 对外 1 基：0 留给"没接到请求" */
    }
}

Value rt_http_req(Value sv)
{
    HttpSess *s = http_sess(sv, "http.req");
    if (s == NULL)
        net_die("http.req：会话不存在或已应答");
    return s->req;
}

Value rt_http_resp(Value sv, Value codev, Value bodyv, Value ctypev)
{
    HttpSess *s = http_sess(sv, "http.resp");
    long long code;
    const char *body, *ctype;
    char head[512];
    int hl, sent, total;
    static const struct { int c; const char *t; } REASONS[] = {
        {200, "OK"}, {201, "Created"}, {204, "No Content"},
        {301, "Moved Permanently"}, {302, "Found"},
        {400, "Bad Request"}, {403, "Forbidden"}, {404, "Not Found"},
        {405, "Method Not Allowed"}, {500, "Internal Server Error"},
        {502, "Bad Gateway"}, {503, "Service Unavailable"},
    };
    const char *reason = "OK";
    size_t k;

    if (s == NULL)
        net_die("http.resp：会话不存在或已应答");
    if (!IS_INT(codev))
        net_die("http.resp 的状态码需要整数");
    code = AS_INT(codev);
    body = net_str(bodyv, "http.resp 的正文");
    ctype = net_str(ctypev, "http.resp 的类型");
    if (ctype[0] == '\0')
        ctype = "text/html; charset=utf-8";
    for (k = 0; k < sizeof REASONS / sizeof REASONS[0]; k++)
        if (REASONS[k].c == (int)code)
            reason = REASONS[k].t;

    hl = snprintf(head, sizeof head,
                  "HTTP/1.1 %lld %s\r\n"
                  "Content-Type: %s\r\n"
                  "Content-Length: %zu\r\n"
                  "Connection: close\r\n"
                  "\r\n",
                  code, reason, ctype, strlen(body));
    total = 0;
    while (total < hl) {
        sent = send(s->sock, head + total, hl - total, 0);
        if (sent <= 0)
            break;
        total += sent;
    }
    if (total == hl) {
        size_t bl = strlen(body);
        total = 0;
        while ((size_t)total < bl) {
            sent = send(s->sock, body + total, (int)(bl - total), 0);
            if (sent <= 0)
                break;
            total += sent;
        }
    }
    closesocket(s->sock);
    s->sock = INVALID_SOCKET;
    s->req = 0;
    return rt_none();
}

/* 读光一个已发出的请求： realloc 缓冲 → NUL 结尾 char*（调用方 free） */
static char *http_read_all(HINTERNET req)
{
    size_t cap = 65536, len = 0;
    char *body = (char *)malloc(cap);
    char tmp[8192];
    DWORD n = 0;
    if (!body)
        net_die("内存不足");
    while (InternetReadFile(req, tmp, (DWORD)sizeof tmp, &n) && n > 0) {
        if (len + n + 1 > cap) {
            char *nb;
            cap = (len + n + 1) * 2;
            nb = (char *)realloc(body, cap);
            if (!nb) {
                free(body);
                net_die("内存不足");
            }
            body = nb;
        }
        memcpy(body + len, tmp, n);
        len += n;
    }
    body[len] = 0;
    return body;
}

/* http.post(网址, 体, "Content-Type")：POST 上去拿回正文（http/https 自动）。
 * 和 http.get 同族：状态码落 http.code()；传输层失败报错（可 onerror 接住）。 */
Value rt_http_post(Value urlv, Value bodyv, Value ctypev)
{
    const char *url = net_str(urlv, "http.post 的网址");
    const char *body = net_str(bodyv, "http.post 的体");
    const char *ctype = net_str(ctypev, "http.post 的类型");
    if (ctype[0] == '\0')
        ctype = HTTP_POST_CTYPE_DEFAULT;     /* 忘了给类型比给错类型更常见 */
    return http_xfer(url, "POST", body, ctype);
}

/* ---------- 客户端实现 ---------- */

/* http_split_url：拆 "https://主机[:端口]/路径"；成功返回 1 */
static int http_split_url(const char *url, HttpUrl *u)
{
    const char *hostp, *slash;
    char *colon;
    u->host = NULL;
    u->path = NULL;
    u->port = 0;
    u->https = 0;
    if (url == NULL || url[0] == '\0')
        return 0;
    {
        const char *p = strstr(url, "://");
        if (p != NULL) {
            u->https = (_strnicmp(url, "https", 5) == 0) ? 1 : 0;
            if (_strnicmp(url, "http", 4) != 0)
                return 0;                    /* 只认 http / https */
            hostp = p + 3;
        } else {
            hostp = url;                    /* 没写协议就当 http */
        }
    }
    while (*hostp == '/')
        hostp++;
    slash = strchr(hostp, '/');
    if (slash != NULL) {
        u->host = http_trim_dup(hostp, (size_t)(slash - hostp));
        u->path = http_trim_dup(slash, strlen(slash));
    } else {
        u->host = http_trim_dup(hostp, strlen(hostp));
        u->path = http_trim_dup("/", 1);
    }
    if (u->path[0] == '\0')
        u->path[0] = '/';
    colon = strchr(u->host, ':');            /* host:port */
    if (colon != NULL) {
        *colon = '\0';
        u->port = (DWORD)_atoi64(colon + 1);
        if (u->port == 0 || u->port > 65535)
            u->port = 0;                     /* 端口写坏了就退回默认，别静默连错地方 */
    }
    return u->host[0] != '\0';
}

static void http_url_clear(HttpUrl *u)
{
    if (u->host != NULL) { free(u->host); u->host = NULL; }
    if (u->path != NULL) { free(u->path); u->path = NULL; }
}

/* 把响应头原文抓下来（http.header / http.headers 的数据源）。
 *
 * 问长度这一趟 HttpQueryInfoA 按文档就返回 FALSE + ERROR_INSUFFICIENT_BUFFER(122)，
 * 但 lpdwBufferLength 照样填好了（实测 211 字节）—— 当成失败就 return，
 * 响应头会永远读不出来。第二趟带缓冲才是 ok=1。
 */
static void http_capture_head(HINTERNET req)
{
    DWORD n = 0, m;
    size_t i, w;
    http_head_drop();
    HttpQueryInfoA(req, HTTP_QUERY_RAW_HEADERS_CRLF, NULL, &n, NULL);
    if (n == 0)
        return;
    g_http_head = (char *)malloc((size_t)n + 2);
    if (g_http_head == NULL)
        return;
    m = n;
    if (!HttpQueryInfoA(req, HTTP_QUERY_RAW_HEADERS_CRLF, g_http_head, &m, NULL)) {
        free(g_http_head);
        g_http_head = NULL;
        return;
    }
    /* 老服务器（尤其 HTTP/1.0 栈）只发 LF。原地补齐成 CRLF，
       下面两个解析器就只认 CRLF 一种，不必到处判行尾。 */
    for (i = 0, w = 0; i < m; i++) {
        if (g_http_head[i] == '\n' && (i == 0 || g_http_head[i - 1] != '\r'))
            g_http_head[w++] = '\r';
        g_http_head[w++] = g_http_head[i];
    }
    g_http_head[w] = '\0';
}

/* 唯一的传输通路：GET / POST 共用。
 * 成功 → 正文（g_http_code / g_http_head 已填好）；
 * 失败 → 报错，原因留在 g_http_err 后抛出（可被 onerror / try 接住）。 */
static Value http_xfer(const char *url, const char *method,
                       const char *body, const char *ctype)
{
    HttpUrl u;
    HINTERNET ses = NULL, conn = NULL, req = NULL;
    char *hd = NULL;
    char *out = NULL;
    DWORD code = 0, clen = (DWORD)sizeof code, flags;
    size_t hcap = 256, hlen = 0;
    Value v;

    http_client_init();
    g_http_code = 0;
    g_http_err[0] = '\0';
    http_head_drop();

    if (!http_split_url(url, &u))
        net_die("http：网址看不懂「%s」"
                "（要写成 http://主机[:端口]/路径 或 https://主机[:端口]/路径）", url);

    ses = InternetOpenA(g_cfg_agent, INTERNET_OPEN_TYPE_PRECONFIG, 0, 0, 0);
    if (!ses) {
        http_set_err(GetLastError(), "打开网络会话失败");
        goto fail;
    }
    /* 三段超时各设一份。不设就是 WinINet 默认（连接 30s、接收 30s），
       一个黑洞地址能把程序挂死在看不出问题的地方 —— 而挂死和"慢"长得一样。 */
    InternetSetOption(ses, INTERNET_OPTION_CONNECT_TIMEOUT, &g_cfg_timeout, sizeof g_cfg_timeout);
    InternetSetOption(ses, INTERNET_OPTION_SEND_TIMEOUT,    &g_cfg_timeout, sizeof g_cfg_timeout);
    InternetSetOption(ses, INTERNET_OPTION_RECEIVE_TIMEOUT, &g_cfg_timeout, sizeof g_cfg_timeout);

    conn = InternetConnectA(ses, u.host,
                            u.port ? u.port : (u.https ? INTERNET_DEFAULT_HTTPS_PORT
                                                       : INTERNET_DEFAULT_HTTP_PORT),
                            NULL, NULL, INTERNET_SERVICE_HTTP, 0, 0);
    if (!conn) {
        http_set_err(GetLastError(), "连不上服务器");
        goto fail;
    }
    flags = u.https ? INTERNET_FLAG_SECURE
                    : (INTERNET_FLAG_RELOAD | INTERNET_FLAG_NO_CACHE_WRITE);
    req = HttpOpenRequestA(conn, method, u.path, "HTTP/1.1", NULL, NULL, flags, 0);
    if (!req) {
        http_set_err(GetLastError(), "请求打不开");
        goto fail;
    }
    /* 请求头 = http.config 的默认头 + Content-Type（有体才带） */
    hd = (char *)malloc(hcap);
    if (hd == NULL)
        net_die("内存不足");
    hd[0] = '\0';
    if (g_cfg_hdrs != NULL) {
        size_t n = strlen(g_cfg_hdrs);
        while (n + 2 > hcap) {
            char *nb = (char *)realloc(hd, hcap * 2);
            if (nb == NULL)
                net_die("内存不足");
            hd = nb;
            hcap *= 2;
        }
        memcpy(hd, g_cfg_hdrs, n);
        hd[n] = '\0';
        hlen = n;
    }
    if (body != NULL && ctype != NULL && ctype[0] != '\0') {
        int w = snprintf(hd + hlen, hcap - hlen, "Content-Type: %s\r\n", ctype);
        if (w < 0)
            net_die("Content-Type 太长");
        if ((size_t)w >= hcap - hlen) {
            size_t need = hlen + (size_t)w + 1;
            char *nb;
            while (need > hcap)
                hcap *= 2;
            nb = (char *)realloc(hd, hcap);
            if (nb == NULL)
                net_die("内存不足");
            hd = nb;
            w = snprintf(hd + hlen, hcap - hlen, "Content-Type: %s\r\n", ctype);
        }
        hlen += (size_t)w;
    }
    if (!HttpSendRequestA(req, (hlen > 0) ? hd : NULL,
                          (hlen > 0) ? (DWORD)hlen : 0,
                          (body != NULL && body[0] != '\0') ? (LPVOID)body : NULL,
                          (body != NULL && body[0] != '\0') ? (DWORD)strlen(body) : 0)) {
        http_set_err(GetLastError(), "请求发不出去");
        goto fail;
    }
    if (!HttpQueryInfoA(req, HTTP_QUERY_STATUS_CODE | HTTP_QUERY_FLAG_NUMBER,
                        &code, &clen, NULL)) {
        http_set_err(GetLastError(), "读不到状态码");
        goto fail;
    }
    g_http_code = (int)code;
    http_capture_head(req);
    out = http_read_all(req);                /* 正文读一半断了也照样给（半截页面），
                                               真断在传输上时 http.err 会说明白 */
    v = rt_str(out);
    free(out);
    free(hd);
    http_url_clear(&u);
    if (req) InternetCloseHandle(req);
    if (conn) InternetCloseHandle(conn);
    InternetCloseHandle(ses);
    return v;

fail:
    if (req) InternetCloseHandle(req);
    if (conn) InternetCloseHandle(conn);
    if (ses) InternetCloseHandle(ses);
    free(hd);
    free(out);
    http_url_clear(&u);
    g_http_code = -1;                        /* 和任何真状态码、和"还没发过"的 0 都不同 */
    net_die("%s（网址 %s）", g_http_err, url);
    return rt_none();                        /* net_die 不返回；留个尾巴给编译器 */
}

/* ================= 自测（-DNET_SELF_TEST） =================
 * gcc -O2 -DNET_SELF_TEST pybook_net.c pybook_rt.c -o net_test.exe -lws2_32 -I.
 * 单进程内：自听自连，覆盖 整行协议 / 半包 / 非阻塞计时 三组断言。 */

#ifdef NET_SELF_TEST

static int g_pass = 0, g_fail = 0;

#define CHECK(cond, name)                              \
    do {                                               \
        if (cond) {                                    \
            g_pass++;                                  \
        } else {                                       \
            g_fail++;                                  \
            printf("[失败] %s\n", name);               \
        }                                              \
    } while (0)

static int str_eq(Value v, const char *want)
{
    return IS_STR(v) && AS_STR(v) && strcmp(AS_STR(v), want) == 0;
}

int main(void)
{
    /* ---- 半包 / 非阻塞 / 整行：C 层直接驱动（rt_net_write 发原样字节） ---- */
    Value srv = rt_net_listen(rt_int(17777));
    Value cli = rt_net_connect(rt_str("127.0.0.1"), rt_int(17777));
    Value con = rt_net_accept(srv);
    DWORD t0;
    int i;
    Value line;

    /* 非阻塞：对端不发数据，recv 100 次全部 "" 且几乎不耗时 */
    t0 = GetTickCount();
    for (i = 0; i < 100; i++) {
        Value v = rt_net_read(con);
        CHECK(str_eq(v, ""), "net.recv 非阻塞：无数据返回空串");
    }
    CHECK(GetTickCount() - t0 < 200, "net.recv 100 次耗时 < 200ms（证明非阻塞）");

    /* 半包：先发 "abc"（无 \n），再发 "def\n" —— 两段拼成一行 */
    CHECK(rt_net_write(cli, rt_str("abc")) == rt_none(), "net.write: abc");
    line = rt_net_read(con);
    CHECK(str_eq(line, ""), "net.recv 半包：无 \\n 时不上交");
    (void)line;
    Sleep(30);
    rt_net_write(cli, rt_str("def\n"));
    line = rt_net_read(con);
    CHECK(str_eq(line, "abcdef"), "net.recv 半包：两段拼成完整一行 abcdef");

    /* 整行协议 + 阻塞读：服务端回一行，客户端阻塞收到 */
    rt_net_write(con, rt_str("hello client\n"));
    line = rt_net_read_block(cli);
    CHECK(str_eq(line, "hello client"), "net.readline 阻塞读一行");

    /* 关闭语义：对端 close 后，缓冲耗尽 → "断" */
    rt_net_close(cli);
    line = rt_net_read(con);
    CHECK(str_eq(line, "断"), "net.recv 对端关闭 → 断");
    rt_net_close(con);
    rt_net_close(srv);

    printf("net 自测：通过 %d 项，失败 %d 项\n", g_pass, g_fail);
    return g_fail ? 1 : 0;
}

#endif /* NET_SELF_TEST */

/* ===== 非 Windows：可链接的桩 ===== */

#else  /* !defined(_WIN32) */

#include <stdio.h>
#include <stdlib.h>

#include "pybook_rt.h"
#include "pybook_lib.h"

/* 平台名在预处理阶段定下来。
   踩过的坑：不能把 defined(__linux__) 直接写在函数调用参数里 ——
   defined() 只在 #if 指令中有效，展开到普通代码是未定义行为
   （gcc 报 "implicit declaration of function 'defined'"）。
   另一个坑：也别用 `#define X(a) \\` 的多行续行 —— 本文件是 CRLF，
   反斜杠后面跟的是 CR 不是换行，宏会在 CR 处断掉、根本没定义。 */
#if defined(__linux__)
#  define NET_PLATFORM_NAME "Linux"
#elif defined(__APPLE__)
#  define NET_PLATFORM_NAME "macOS"
#else
#  define NET_PLATFORM_NAME "非 Windows"
#endif

/* 桩函数为什么必须存在：_vm_lib_calls.inc 声明了这 18 个符号，VM 侧链接要它们，
   缺一个就是 undefined reference，报错对使用者毫无信息量。
   但也绝不能"安静地什么都不做"—— 一个连不上却装作成功的网络函数比没有更坏，
   所以统一在这里报三段式：为什么、怎么办。 */
static void net_stub_die(const char *fn)
{
    rt_die("%s 目前只支持 Windows（这个模块跑在 Winsock2 + WinINet 上）\n"
           "  为什么：当前构建目标是 " NET_PLATFORM_NAME "，没有 Winsock\n"
           "  怎么改：① 在 Windows 上跑；② 或者把本文件改成 BSD socket 实现"
           "（socket/bind/accept/connect/recv/send/close + getaddrinfo + poll），"
           "上面 18 个函数签名一行都不用改",
           fn);
}

Value rt_net_listen(Value portv)          { (void)portv;       net_stub_die("net.listen");   return rt_none(); }
Value rt_net_accept(Value lv)             { (void)lv;          net_stub_die("net.accept");   return rt_none(); }
Value rt_net_connect(Value a, Value b)    { (void)a; (void)b;  net_stub_die("net.connect");  return rt_none(); }
Value rt_net_read(Value hv)               { (void)hv;          net_stub_die("net.recv");     return rt_none(); }
Value rt_net_read_block(Value hv)         { (void)hv;          net_stub_die("net.readline"); return rt_none(); }
Value rt_net_write(Value hv, Value t)     { (void)hv; (void)t; net_stub_die("net.send");     return rt_none(); }
Value rt_net_close(Value hv)              { (void)hv;          net_stub_die("net.close");    return rt_none(); }

Value rt_http_get(Value urlv)             { (void)urlv;        net_stub_die("http.get");     return rt_none(); }
Value rt_http_code(void) { net_stub_die("http.code"); return rt_none(); }
Value rt_http_listen(Value portv)         { (void)portv;       net_stub_die("http.listen");  return rt_none(); }
Value rt_http_serve(Value lv)             { (void)lv;          net_stub_die("http.serve");   return rt_none(); }
Value rt_http_req(Value sv)               { (void)sv;          net_stub_die("http.req");     return rt_none(); }
Value rt_http_resp(Value s, Value c, Value b, Value t)
{
    (void)s; (void)c; (void)b; (void)t;
    net_stub_die("http.resp");
    return rt_none();
}
Value rt_http_post(Value u, Value b, Value c)
{
    (void)u; (void)b; (void)c;
    net_stub_die("http.post");
    return rt_none();
}
Value rt_http_err(void)          { net_stub_die("http.err");       return rt_none(); }
Value rt_http_header(Value nv)   { (void)nv;   net_stub_die("http.header");   return rt_none(); }
Value rt_http_headers(void)      { net_stub_die("http.headers"); return rt_none(); }
Value rt_http_config(Value ov)   { (void)ov;   net_stub_die("http.config");   return rt_none(); }

#endif  /* _WIN32 */
