/* _lacheck.c — 线性代数核心层的对拍 harness
 *
 * 用法：gcc _lacheck.c pybook_la.c -o _lacheck.exe -O2 -Wall
 *       .\_lacheck.exe > _la_dump.txt
 *       python -B _lachk.py
 *
 * 做法很土但很硬：本文件只负责把随机生成的输入矩阵**原样 dump 出来**，再把各算法
 * 算出的结果也 dump 出来；然后由 _lachk.py 读这份 dump，用 NumPy 拿**同一批输入**
 * 算参考值逐项比。
 *
 * 为什么不各写各的 RNG 让两边自己生成同一批数：只要有一边 RNG 写错，就会得到
 * 「两边都在算，但输入不同」的现象，排查成本极高。让 C 侧把输入吐出来，
 * 输入就只有一个真相源。
 *
 * 覆盖：方阵 / 矩形(高瘦、矮胖) / 对称 / 对称正定 / 秩亏。
 * 矩形和秩亏是重点——QR 的 Q 形状、SVD 在 m<n 时 U 与 Vt 的对调、最小二乘的
 * min-norm 分支，全都只在这两类输入上才被走到。
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "pybook_la.h"

/* xorshift64*，只要确定性，不要质量 */
static unsigned long long g_st = 0x9E3779B97F4A7C15ULL;
static double urand(void)
{
    g_st ^= g_st << 13; g_st ^= g_st >> 7; g_st ^= g_st << 17;
    return ((double)(g_st >> 11) * (1.0 / 9007199254740992.0)) * 2.0 - 1.0;
}

static void pm(const char *tag, const double *a, int r, int c)
{
    int i, j;
    printf("MAT %s %d %d\n", tag, r, c);
    for (i = 0; i < r; i++) {
        for (j = 0; j < c; j++) printf(" %.17g", a[(size_t)i * c + j]);
        printf("\n");
    }
}

static void pv(const char *tag, const double *a, int n)
{
    int i;
    printf("VEC %s %d\n", tag, n);
    for (i = 0; i < n; i++) printf(" %.17g", a[i]);
    printf("\n");
}

static void ps(const char *tag, double v)
{
    printf("SCALAR %s %.17g\n", tag, v);
}

static double *xalloc(size_t n)
{
    double *p = (double *)malloc((n ? n : 1) * sizeof(double));
    if (!p) { fprintf(stderr, "内存不足\n"); exit(2); }
    return p;
}

static void fill_rand(double *a, int m, int n)
{
    int i;
    for (i = 0; i < m * n; i++) a[i] = urand();
}

/* A <- (A + A^T)/2 */
static void make_sym(double *a, int n)
{
    int i, j;
    for (i = 0; i < n; i++)
        for (j = i + 1; j < n; j++) {
            double v = 0.5 * (a[(size_t)i * n + j] + a[(size_t)j * n + i]);
            a[(size_t)i * n + j] = v;
            a[(size_t)j * n + i] = v;
        }
}

/* A <- M M^T + n*I */
static void make_spd(double *a, double *tmp, int n)
{
    int i, j, k;
    fill_rand(tmp, n, n);
    for (i = 0; i < n; i++)
        for (j = 0; j < n; j++) {
            double s = 0.0;
            for (k = 0; k < n; k++) s += tmp[(size_t)i * n + k] * tmp[(size_t)j * n + k];
            a[(size_t)i * n + j] = s + ((i == j) ? (double)n : 0.0);
        }
}

/* A <- U*V^T（n*n，秩恰好为 r） */
static void make_lowrank(double *a, double *u, double *v, int n, int r)
{
    int i, j, k;
    fill_rand(u, n, r);
    fill_rand(v, n, r);
    for (i = 0; i < n; i++)
        for (j = 0; j < n; j++) {
            double s = 0.0;
            for (k = 0; k < r; k++) s += u[(size_t)i * r + k] * v[(size_t)j * r + k];
            a[(size_t)i * n + j] = s;
        }
}

/* ================= 通用案例：LU / QR / SVD / 最小二乘 ================= */

static void case_gen(const char *name, int m, int n)
{
    size_t na = (size_t)m * n, nmax = (size_t)((m > n ? m : n) * (m > n ? m : n) + 1);
    double *a  = xalloc(na);
    double *b  = xalloc(m);
    double *lu = xalloc(nmax);
    double *iv = xalloc(nmax);
    double *q  = xalloc(nmax);
    double *r  = xalloc(na);
    double *vv = xalloc(nmax);
    double *tp = xalloc(nmax);
    double *u  = xalloc(na);
    double *vt = xalloc(na);
    double *s  = xalloc(m > n ? m : n);
    int    *pi = (int *)malloc((size_t)(n ? n : 1) * sizeof(int));
    int i, ok, p, rk;
    if (!pi) { fprintf(stderr, "内存不足\n"); exit(2); }

    fill_rand(a, m, n);
    for (i = 0; i < m; i++) b[i] = urand();

    printf("CASE %s %d %d %d\n", name, m, n, n);
    pm("A", a, m, n);
    pv("B", b, m);

    if (m == n) {
        ok = la_lu(a, lu, pi, n);
        ps("LU_OK", (double)ok);
        pm("LU", lu, n, n);
        ps("DET", la_lu_det(lu, pi, n));
        ps("RANK", (double)la_rank(a, n, 0.0));
        if (ok) {
            memcpy(tp, b, (size_t)n * sizeof(double));
            la_lu_solve(lu, pi, tp, n, 1);
            pv("X", tp, n);
            la_lu_inv(lu, pi, iv, n);
            pm("INV", iv, n, n);
        }
    }

    p = la_qr(a, r, vv, tp, m, n);
    for (i = 0; i < m * m; i++) q[i] = ((i / m) == (i % m)) ? 1.0 : 0.0;
    la_qr_form_q(vv, tp, q, m, p);
    pm("Q", q, m, m);
    pm("R", r, m, n);

    la_svd(a, u, s, vt, m, n, 60);
    {   /* 标准约定：U 是 m*mn，VT 是 mn*n，S 是 mn 个，重建式 A = U·diag(S)·VT */
        int mn = m < n ? m : n;
        pm("U", u, m, mn);
        pv("S", s, mn);
        pm("VT", vt, mn, n);
    }

    {
        double *x = xalloc(n);
        rk = la_lstsq(a, b, x, m, n);
        pv("XLS", x, n);
        ps("RANK_LS", (double)rk);
        free(x);
    }

    free(a); free(b); free(lu); free(iv); free(q); free(r); free(vv);
    free(tp); free(u); free(vt); free(s); free(pi);
}

/* ================= 对称特征分解 ================= */

static void case_sym(int n)
{
    size_t nn = (size_t)n * n;
    double *a = xalloc(nn), *ev = xalloc(n), *ec = xalloc(nn);
    fill_rand(a, n, n);
    make_sym(a, n);
    printf("CASE sym %d %d %d\n", n, n, n);
    pm("A", a, n, n);
    ps("EIG_OK", (double)la_eig_sym(a, ev, ec, n, 60));
    pv("EIGVAL", ev, n);
    pm("EIGVEC", ec, n, n);
    free(a); free(ev); free(ec);
}

/* ================= 对称正定 Cholesky ================= */

static void case_spd(int n)
{
    size_t nn = (size_t)n * n;
    double *a = xalloc(nn), *l = xalloc(nn), *tmp = xalloc(nn);
    make_spd(a, tmp, n);
    printf("CASE spd %d %d %d\n", n, n, n);
    pm("A", a, n, n);
    ps("CHOL_OK", (double)la_cholesky(a, l, n));
    pm("L", l, n, n);
    free(a); free(l); free(tmp);
}

/* ================= 秩亏：秩必须被算出来，最小二乘给 min-norm ================= */

static void case_lowrank(int n, int r)
{
    size_t nn = (size_t)n * n;
    double *a = xalloc(nn), *u = xalloc((size_t)n * r), *v = xalloc((size_t)n * r);
    double *b = xalloc(n), *x = xalloc(n);
    int    rk, i;
    make_lowrank(a, u, v, n, r);
    for (i = 0; i < n; i++) b[i] = urand();
    printf("CASE lowrank %d %d %d\n", n, n, n);
    pm("A", a, n, n);
    pv("B", b, n);
    printf("SCALAR RANK %.17g\n", (double)la_rank(a, n, 0.0));
    rk = la_lstsq(a, b, x, n, n);
    pv("XLS", x, n);
    printf("SCALAR RANK_LS %.17g\n", (double)rk);
    free(a); free(u); free(v); free(b); free(x);
}

int main(int argc, char **argv)
{
    int sq[] = { 2, 3, 5, 8, 12, 20, 40 };
    int i;

    /* 输出自己写文件：经 PowerShell 的 > 重定向会得到 UTF-16LE，
     * Python 侧读回来直接 UnicodeDecodeError。 */
    if (argc > 1) {
        FILE *fp = freopen(argv[1], "wb", stdout);
        if (!fp) { fprintf(stderr, "打不开输出文件 %s\n", argv[1]); return 2; }
    }

    for (i = 0; i < (int)(sizeof(sq) / sizeof(sq[0])); i++)
        case_gen("square", sq[i], sq[i]);

    /* 高瘦 / 矮胖：这两类才走得到 QR 的 Q 是 m*m 以及 SVD 在 m<n 时的对调分支 */
    { int pr[][2] = { {12,4}, {4,12}, {25,7}, {7,25}, {40,40} };
      for (i = 0; i < 5; i++) case_gen("rect", pr[i][0], pr[i][1]); }

    for (i = 0; i < (int)(sizeof(sq) / sizeof(sq[0])); i++)
        case_sym(sq[i]);

    for (i = 0; i < (int)(sizeof(sq) / sizeof(sq[0])); i++)
        case_spd(sq[i]);

    { int lr[][2] = { {6,2}, {10,3}, {20,5} };
      for (i = 0; i < 3; i++) case_lowrank(lr[i][0], lr[i][1]); }

    return 0;
}