/* PYbook 自带正则引擎（零依赖，字节级 POSIX-ish ERE 子集）。
 * 与 pybook 运行时解耦：本文件不依赖 pybook_lib.h / rt_value，可独立编译测试。
 * 支持：字面量、.  *  +  ?  |  ()  [] (含 - 与 ^ 取反)  ^  $  转义 \d \w \s \D \W \S \. \* \+ \? \\ \n \t \r
 * 捕获组：( ) 最多 RE_MAXCAP 组，re_groups 取首个匹配的各组。
 * 已知 v1 限制：嵌套量词（如 a**）未定义；. 不匹配换行；\w 等为 ASCII 语义。
 */
#ifndef PYBOOK_RE_ENGINE_H
#define PYBOOK_RE_ENGINE_H

#include <string.h>
#include <stdio.h>

#define RE_MAXCAP   16
#define RE_MAXNODES 1024
#define RE_MAXPAT   2048

typedef struct { int so[RE_MAXCAP]; int eo[RE_MAXCAP]; } re_caps;

typedef enum {
    RE_CHAR, RE_ANY, RE_CLASS, RE_BOL, RE_EOL,
    RE_STAR, RE_PLUS, RE_QUEST, RE_ALT, RE_GROUP
} RE_Kind;

typedef struct RENode {
    RE_Kind kind;
    int c;                 /* RE_CHAR: 字节 */
    unsigned char cls[32]; /* RE_CLASS: 256-bit 成员位图 */
    int cls_neg;           /* RE_CLASS: 取反 */
    int gid;               /* RE_GROUP: 组号(1-based) */
    struct RENode *a;      /* 子节点（STAR/PLUS/QUEST 的操作数；ALT 左；GROUP 内部） */
    struct RENode *b;      /* ALT 右分支 */
    struct RENode *next;   /* 序列中的下一个节点 */
} RENode;

typedef struct {
    const char *pat;
    int   patlen;
    int   ngroups;
    RENode *root;
    RENode  pool[RE_MAXNODES];
    int     npool;
    char    err[128];
} re_prog;

/* ---------- 编译 ---------- */
int  re_compile(re_prog *pr, const char *pat, char *errbuf, int errlen);
/* 在 text[0,textlen) 中搜索最左匹配；成功返回 1，填 mstart/metend(偏移) 与 caps */
int  re_search(const re_prog *pr, const char *text, int textlen,
               int *mstart, int *mend, re_caps *caps);
/* 仅从偏移 0 锚定匹配 */
int  re_match_at(const re_prog *pr, const char *text, int textlen,
                 int *mend, re_caps *caps);

/* ===================== 实现 ===================== */
static void re_setbit(unsigned char *cls, int c) { cls[c >> 3] |= (unsigned char)(1u << (c & 7)); }
static int  re_getbit(const unsigned char *cls, int c) { return (cls[c >> 3] >> (c & 7)) & 1; }

static RENode *re_newnode(re_prog *pr, RE_Kind k)
{
    if (pr->npool >= RE_MAXNODES) {
        snprintf(pr->err, sizeof(pr->err), "正则pattern过长(节点上限%d)", RE_MAXNODES);
        return NULL;
    }
    RENode *n = &pr->pool[pr->npool++];
    memset(n, 0, sizeof *n);
    n->kind = k;
    return n;
}

static int re_unescape(char e, char *out)
{
    switch (e) {
        case 'n': *out = '\n'; return 1;
        case 't': *out = '\t'; return 1;
        case 'r': *out = '\r'; return 1;
        default:  *out = e;    return 1; /* \. \* \\ 等 → 字面 */
    }
}

/* 由 \d \w \s（及大写取反）构造字符类节点 */
static RENode *re_class_from_esc(re_prog *pr, char e)
{
    RENode *n = re_newnode(pr, RE_CLASS);
    if (!n) return NULL;
    memset(n->cls, 0, 32);
    int neg = (e == 'D' || e == 'W' || e == 'S');
    n->cls_neg = neg;
    if (e == 'd' || e == 'D') {
        for (int i = '0'; i <= '9'; i++) re_setbit(n->cls, i);
    } else if (e == 'w' || e == 'W') {
        for (int i = 'a'; i <= 'z'; i++) re_setbit(n->cls, i);
        for (int i = 'A'; i <= 'Z'; i++) re_setbit(n->cls, i);
        for (int i = '0'; i <= '9'; i++) re_setbit(n->cls, i);
        re_setbit(n->cls, '_');
    } else { /* s / S */
        re_setbit(n->cls, ' '); re_setbit(n->cls, '\t');
        re_setbit(n->cls, '\n'); re_setbit(n->cls, '\r'); re_setbit(n->cls, '\f');
    }
    return n;
}

typedef struct { const char *p; const char *end; re_prog *pr; } PState;

static RENode *re_parse_alt(PState *st);
static RENode *re_parse_class(PState *st);

static RENode *re_parse_atom(PState *st)
{
    if (st->p >= st->end) { snprintf(st->pr->err, sizeof(st->pr->err), "pattern意外结束"); return NULL; }
    char c = *st->p;
    if (c == '(') {
        st->p++;
        int gid = ++st->pr->ngroups;
        if (gid > RE_MAXCAP) { snprintf(st->pr->err, sizeof(st->pr->err), "捕获组超过%d", RE_MAXCAP); return NULL; }
        RENode *inner = re_parse_alt(st);
        if (!inner) return NULL;
        if (st->p >= st->end || *st->p != ')') { snprintf(st->pr->err, sizeof(st->pr->err), "缺少右括号 )"); return NULL; }
        st->p++;
        RENode *g = re_newnode(st->pr, RE_GROUP);
        if (!g) return NULL;
        g->gid = gid; g->a = inner;
        return g;
    }
    if (c == '[') return re_parse_class(st);
    if (c == '.') { st->p++; return re_newnode(st->pr, RE_ANY); }
    if (c == '^') { st->p++; return re_newnode(st->pr, RE_BOL); }
    if (c == '$') { st->p++; return re_newnode(st->pr, RE_EOL); }
    if (c == '\\') {
        st->p++;
        if (st->p >= st->end) { snprintf(st->pr->err, sizeof(st->pr->err), "转义意外结束"); return NULL; }
        char e = *st->p++;
        if (e == 'd' || e == 'w' || e == 's' || e == 'D' || e == 'W' || e == 'S')
            return re_class_from_esc(st->pr, e);
        char ch; re_unescape(e, &ch);
        RENode *n = re_newnode(st->pr, RE_CHAR); if (!n) return NULL; n->c = (unsigned char)ch; return n;
    }
    st->p++;
    RENode *n = re_newnode(st->pr, RE_CHAR); if (!n) return NULL; n->c = (unsigned char)c; return n;
}

static RENode *re_parse_postfix(PState *st)
{
    RENode *a = re_parse_atom(st);
    if (!a) return NULL;
    while (st->p < st->end && (*st->p == '*' || *st->p == '+' || *st->p == '?')) {
        RE_Kind k = (*st->p == '*') ? RE_STAR : (*st->p == '+') ? RE_PLUS : RE_QUEST;
        st->p++;
        RENode *n = re_newnode(st->pr, k);
        if (!n) return NULL;
        n->a = a; a = n;
    }
    return a;
}

static RENode *re_parse_concat(PState *st)
{
    RENode *head = NULL, *tail = NULL;
    while (st->p < st->end && *st->p != '|' && *st->p != ')') {
        RENode *a = re_parse_postfix(st);
        if (!a) return NULL;
        if (!head) { head = tail = a; }
        else { tail->next = a; tail = a; }
    }
    return head; /* 可能为空（空串匹配空） */
}

static RENode *re_parse_alt(PState *st)
{
    RENode *left = re_parse_concat(st);
    if (!left) return NULL;
    while (st->p < st->end && *st->p == '|') {
        st->p++;
        RENode *right = re_parse_alt(st);
        if (!right) return NULL;
        RENode *alt = re_newnode(st->pr, RE_ALT);
        if (!alt) return NULL;
        alt->a = left; alt->b = right;
        left = alt;
    }
    return left;
}

static RENode *re_parse_class(PState *st)
{
    st->p++; /* 跳过 [ */
    int neg = 0;
    if (st->p < st->end && *st->p == '^') { neg = 1; st->p++; }
    RENode *n = re_newnode(st->pr, RE_CLASS);
    if (!n) return NULL;
    n->cls_neg = neg;
    int closed = 0;
    while (st->p < st->end) {
        if (*st->p == ']') { st->p++; closed = 1; break; }
        char lo;
        if (*st->p == '\\') {
            st->p++;
            if (st->p >= st->end) { snprintf(st->pr->err, sizeof(st->pr->err), "字符类转义意外结束"); return NULL; }
            char tmp; re_unescape(*st->p, &lo); st->p++;
        } else { lo = *st->p++; }
        /* 区间？ */
        if (st->p < st->end && *st->p == '-' && (st->p + 1) < st->end && st->p[1] != ']') {
            st->p++;
            char hi;
            if (*st->p == '\\') {
                st->p++;
                if (st->p >= st->end) { snprintf(st->pr->err, sizeof(st->pr->err), "字符类转义意外结束"); return NULL; }
                char tmp; re_unescape(*st->p, &hi); st->p++;
            } else { hi = *st->p++; }
            if ((unsigned char)hi < (unsigned char)lo) { lo = hi; hi = lo; } /* 容错 */
            for (int x = (unsigned char)lo; x <= (unsigned char)hi; x++) re_setbit(n->cls, x);
        } else {
            re_setbit(n->cls, (unsigned char)lo);
        }
    }
    if (!closed) { snprintf(st->pr->err, sizeof(st->pr->err), "字符类缺少 ]"); return NULL; }
    return n;
}

int re_compile(re_prog *pr, const char *pat, char *errbuf, int errlen)
{
    memset(pr, 0, sizeof *pr);
    pr->pat = pat; pr->patlen = (int)strlen(pat);
    pr->ngroups = 0;
    if (pr->patlen >= RE_MAXPAT) { snprintf(pr->err, sizeof(pr->err), "pattern过长"); if (errbuf) snprintf(errbuf, errlen, "%s", pr->err); return -1; }
    PState st; st.p = pat; st.end = pat + pr->patlen; st.pr = pr;
    RENode *root = re_parse_alt(&st);
    if (!root) { if (errbuf) snprintf(errbuf, errlen, "%s", pr->err); return -1; }
    if (st.p != st.end) { /* 多出未消费字符（理论不应发生） */
        if (errbuf) snprintf(errbuf, errlen, "pattern解析残留"); return -1;
    }
    pr->root = root;
    return 0;
}

/* ---------- 匹配（递归回溯；next 串联序列） ---------- */
/* 匹配从 node 开始的序列，起始偏移 off。成功返回 1 并写 endoff。 */
static int re_match_node(const RENode *node, const char *text, int len, int off, re_caps *caps, int *endoff);

/* 把单个操作数匹配一次（不消费序列后续），写 eo。常见操作数：CHAR/ANY/CLASS/GROUP。 */
static int re_match_operand(const RENode *node, const char *text, int len, int off, re_caps *caps, int *eo)
{
    switch (node->kind) {
        case RE_CHAR: if (off < len && (unsigned char)text[off] == node->c) { *eo = off + 1; return 1; } return 0;
        case RE_ANY:  if (off < len && text[off] != '\n') { *eo = off + 1; return 1; } return 0;
        case RE_CLASS: if (off < len) { int m = re_getbit(node->cls, (unsigned char)text[off]); int ok = node->cls_neg ? !m : m; if (ok) { *eo = off + 1; return 1; } } return 0;
        case RE_BOL: if (off == 0) { *eo = off; return 1; } return 0;
        case RE_EOL: if (off == len) { *eo = off; return 1; } return 0;
        case RE_GROUP: {
            int save = caps->so[node->gid]; caps->so[node->gid] = off;
            int inner;
            int r = re_match_node(node->a, text, len, off, caps, &inner);
            if (r) caps->eo[node->gid] = inner; else caps->so[node->gid] = save;
            *eo = inner; return r;
        }
        default: /* 嵌套量词等罕见情形：退化为整段匹配（v1 限制） */
            return re_match_node(node, text, len, off, caps, eo);
    }
}

static int re_match_node(const RENode *node, const char *text, int len, int off, re_caps *caps, int *endoff)
{
    if (node == NULL) { *endoff = off; return 1; }
    int e2;
    switch (node->kind) {
        case RE_CHAR:
            if (off < len && (unsigned char)text[off] == node->c) return re_match_node(node->next, text, len, off + 1, caps, endoff);
            *endoff = off; return 0;
        case RE_ANY:
            if (off < len && text[off] != '\n') return re_match_node(node->next, text, len, off + 1, caps, endoff);
            *endoff = off; return 0;
        case RE_CLASS:
            if (off < len) {
                int m = re_getbit(node->cls, (unsigned char)text[off]);
                int ok = node->cls_neg ? !m : m;
                if (ok) return re_match_node(node->next, text, len, off + 1, caps, endoff);
            }
            *endoff = off; return 0;
        case RE_BOL:
            if (off == 0) return re_match_node(node->next, text, len, off, caps, endoff);
            *endoff = off; return 0;
        case RE_EOL:
            if (off == len) return re_match_node(node->next, text, len, off, caps, endoff);
            *endoff = off; return 0;
        case RE_STAR:
            /* 贪婪：先尽量多匹配操作数，再回退到更少/0 次 */
            if (re_match_operand(node->a, text, len, off, caps, &e2)) {
                if (e2 > off) {
                    if (re_match_node(node, text, len, e2, caps, endoff)) return 1; /* 多吃 */
                }
                /* 回退：停止此处，进入后续序列（1 次后停 / 零宽 1 次 / 0 次统一走下边） */
                if (re_match_node(node->next, text, len, e2, caps, endoff)) return 1;
            }
            return re_match_node(node->next, text, len, off, caps, endoff); /* 0 次 */
        case RE_PLUS: {
            /* 至少 1 次，贪婪：先尽量多匹配，再回退到恰好 1 次 */
            if (!re_match_operand(node->a, text, len, off, caps, &e2)) return 0;
            if (e2 > off) {
                if (re_match_node(node, text, len, e2, caps, endoff)) return 1; /* 贪婪更多 */
            }
            return re_match_node(node->next, text, len, e2, caps, endoff); /* 1 次即止，进后续 */
        }
        case RE_QUEST:
            if (re_match_operand(node->a, text, len, off, caps, &e2)) {
                if (e2 > off) { if (re_match_node(node->next, text, len, e2, caps, endoff)) return 1; }
                else { if (re_match_node(node->next, text, len, e2, caps, endoff)) return 1; }
            }
            return re_match_node(node->next, text, len, off, caps, endoff); /* 0 次 */
        case RE_ALT:
            if (re_match_node(node->a, text, len, off, caps, endoff)) return 1;
            return re_match_node(node->b, text, len, off, caps, endoff);
        case RE_GROUP: {
            int save = caps->so[node->gid]; caps->so[node->gid] = off;
            int inner;
            if (re_match_node(node->a, text, len, off, caps, &inner)) {
                caps->eo[node->gid] = inner;
                if (re_match_node(node->next, text, len, inner, caps, endoff)) return 1;
                caps->so[node->gid] = save; /* rest 失败回退 */
                *endoff = off; return 0;
            }
            caps->so[node->gid] = save; *endoff = off; return 0;
        }
    }
    *endoff = off; return 0;
}

int re_match_at(const re_prog *pr, const char *text, int textlen, int *mend, re_caps *caps)
{
    int e;
    if (re_match_node(pr->root, text, textlen, 0, caps, &e)) { *mend = e; return 1; }
    return 0;
}

int re_search(const re_prog *pr, const char *text, int textlen,
              int *mstart, int *mend, re_caps *caps)
{
    for (int i = 0; i <= textlen; i++) {
        re_caps lc;
        for (int g = 0; g < RE_MAXCAP; g++) { lc.so[g] = -1; lc.eo[g] = -1; }
        int e;
        if (re_match_node(pr->root, text, textlen, i, &lc, &e)) {
            *mstart = i; *mend = e;
            if (caps) for (int g = 0; g < RE_MAXCAP; g++) { caps->so[g] = lc.so[g]; caps->eo[g] = lc.eo[g]; }
            return 1;
        }
    }
    return 0;
}

#endif /* PYBOOK_RE_ENGINE_H */
