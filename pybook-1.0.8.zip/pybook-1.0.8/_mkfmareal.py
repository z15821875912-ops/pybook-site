# -*- coding: utf-8 -*-
"""
生成 _ptx_FMAREAL.ptx + _fmareal_const.h —— 「编译器折叠不掉」的 FMA 吞吐内核。

为什么旧内核测出来的数是假的（三个已被抓到的作弊手法）：
  手法1  8 条链长得一模一样，累加器还都从 0 起 -> 编译器可证明 fma(a,b,0)=0，
         8 条塌成 1 条，按 8 条算吞吐虚高 8 倍。
  手法2  改成每链独立乘数后，acc += 常数（等差数列）被化简成 acc = n*常数，
         循环体里一条 FMA 都不留。证据：nc=1 时 10 块与 160 块用时几乎相同
         （工作量 16 倍、时间不变），但迭代数拉高 10 倍用时涨 9.3 倍。
  手法3  想让每轮操作数都不同就得动态索引，而访存地址只准「寄存器 + 立即数」，
         只能展开 64 次，代价过大。

本文件的四条反作弊设计：
  D1  累加器初值从显存载入（out 缓冲区，宿主预先填伪随机数）。
     ptxas 编译期不知道初值 -> 「整条链折叠成一个常量」这条路直接死掉。
  D2  常量表 K[s][c] 共 S*NC 个两两互不相同（生成时断言）->
     堵死「8 条链相同 -> 合并成 1 条」。
  D3  K 全部取 0.9985~1.0015 附近的随机值，不构成等差/等比数列 ->
     堵死「等差数列化简成 n*常数」。仍可能被极端激进的仿射复合折叠，
     所以再加 D4 兜底。
  D4  宿主用 fmaf() 按完全相同的顺序重放同一序列，逐位对拍。
     只要 ptxas 少算一条 FMA，结果必然对不上 -> 数字直接作废而不是悄悄虚高。

参数：S=32（循环体内展开步数）、NC=16（独立 FMA 链数），循环体共 512 条 FMA。

PTX 铁律（全部是二分钉死的，见各 PTX 文件头）：
  - 注释必须纯 ASCII，中文会让 JIT 失败且不给提示
  - 浮点字面量必须 0f 前缀
  - .reg 数组是 0 编号（%f<24> 可用 %f1..%f23）
  - 地址只准「寄存器 + 立即数」

用法：python -B _mkfmareal.py
"""
import struct
import os

S = 32          # 循环体内展开步数
NC = 16         # 独立 FMA 链数
LOOP_FMA = S * NC

# 每线程的字节偏移 = 线程号 * NC * 4，必须是 2 的幂才能用移位算，
# 这样索引换算不占用任何额外的 32 位寄存器（见 emit_ptx 里的「量化铁律」）。
assert NC > 0 and (NC & (NC - 1)) == 0, "NC 必须是 2 的幂，否则改用乘法"
BYTES_PER_THREAD = NC * 4
assert BYTES_PER_THREAD & (BYTES_PER_THREAD - 1) == 0
SHIFT = BYTES_PER_THREAD.bit_length() - 1

# 浮点累加器编号从 FBASE 起，避开 %r / %rd 的编号段
FBASE = 16
assert FBASE + NC <= 32, "浮点寄存器段不够用了"


def f32hex(v):
    """float -> PTX 32 位浮点字面量（0f + 8 位十六进制）"""
    return "0f" + struct.pack(">f", v).hex().upper()


def gen():
    # --- 伪随机常量表 K[s][c]，两两互不相同 ---
    K = [[0.0] * NC for _ in range(S)]
    seen = set()
    seed = 20030611  # 固定种子，保证可复现
    for s in range(S):
        for c in range(NC):
            seed = (seed * 1103515245 + 12345) & 0x7FFFFFFF
            u = (seed >> 8) / 8388608.0          # [0,1)
            v = 0.9985 + 0.0030 * u              # [0.9985, 1.0015)
            # 编码成 float32 后可能撞车，撞了就再往后挪一位
            while True:
                key = struct.pack(">f", v)
                if key not in seen:
                    break
                v = v + 1e-7
            seen.add(key)
            K[s][c] = struct.unpack(">f", key)[0]

    # 自检1：K 表必须两两互不相同（否则链可被合并）
    assert len(seen) == S * NC, "K 表有重复值，链可能被合并"

    # 自检2：K 不得等于 1.0（否则退化成加法，语义弱化）
    one = struct.pack(">f", 1.0)
    assert one not in seen, "K 里混进了 1.0"

    # 自检3：K 必须全部有界，累加器才不会在 2^20 次迭代后溢出
    for s in range(S):
        for c in range(NC):
            assert 0.99 < K[s][c] < 1.01, "K 越界，数值会炸"

    # 每条链的加数 B[c]，也两两不同，进一步保证链不可合并
    B = [(c + 1) * (2.0 ** -7) for c in range(NC)]
    assert len(set(B)) == NC
    return K, B


def emit_ptx(K, B):
    L = []
    L.append(".version 6.5")
    L.append(".target sm_61")
    L.append(".address_size 64")
    L.append("//")
    L.append("// fma_pk -- UNFOLDABLE FP32 throughput yardstick.")
    L.append("//")
    L.append("// Anti-cheat design (see _mkfmareal.py for the full argument):")
    L.append("//   D1 acc initial values are LOADED FROM MEMORY -> ptxas cannot")
    L.append("//      constant-fold the whole chain away.")
    L.append("//   D2 K[s][c] are pairwise distinct -> no two chains are identical,")
    L.append("//      so no chain merging.")
    L.append("//   D3 K near 1.0 but random, not an arithmetic progression ->")
    L.append("//      no strength reduction to n*constant.")
    L.append("//   D4 the host replays the identical sequence with fmaf() and")
    L.append("//      compares bit for bit. One missing FMA = mismatch = reject.")
    L.append("//")
    L.append("// Loop body: %d FMAs (%d steps x %d chains). No memory traffic inside."
             % (LOOP_FMA, S, NC))
    L.append("//")
    L.append("// HARD RULE: comments must be ASCII ONLY. Chinese chars make the")
    L.append("// PTX JIT fail with no useful message.")
    L.append("//")
    L.append(".visible .entry fma_pk(")
    L.append("    .param .u64 p_init,")
    L.append("    .param .u64 p_out,")
    L.append("    .param .u32 p_iter")
    L.append(")")
    L.append("{")
    L.append("    // Register numbers are split into three disjoint ranges on purpose:")
    L.append("    //   32-bit ints %r1..%r7 / 64-bit ptrs %rd8..%rd15 / floats %f16..%f31.")
    L.append("    //   Whether %r<N> and %rd<N> alias the same physical register is")
    L.append("    //   inconsistently documented. Do not gamble: keep the numbers apart.")
    L.append("    .reg .pred %p<4>;")
    L.append("    .reg .b32  %r<8>;")
    L.append("    .reg .b64  %rd<16>;")
    L.append("    .reg .f32  %f<32>;")
    L.append("")
    L.append("    ld.param.u64 %rd8, [p_init];")
    L.append("    ld.param.u64 %rd9, [p_out];")
    L.append("    ld.param.u32 %r1, [p_iter];")
    L.append("    cvta.to.global.u64 %rd12, %rd8;")
    L.append("    cvta.to.global.u64 %rd13, %rd9;")
    L.append("")
    # RULE 3: %ctaid / %ntid / %tid must be mov'd into plain registers first.
    #
    # UNIT RULE (learned the hard way here): the first version had
    # `mov.u32 %r6, 16;` while %rd6 held the p_init global pointer, so all 16
    # ld.global read garbage. The JIT said nothing and nothing crashed -- the
    # numbers were just wrong. Hence the shift-based index math below, which
    # costs no extra register, plus the aliasing check in main().
    L.append("    mov.u32 %r2, %ctaid.x;")
    L.append("    mov.u32 %r3, %ntid.x;")
    L.append("    mov.u32 %r7, %tid.x;")
    L.append("    mul.lo.u32 %r2, %r2, %r3;")
    L.append("    add.u32 %r2, %r2, %r7;")
    L.append("    shl.b32 %%r2, %%r2, %d;" % SHIFT)   # x NC x 4 bytes
    L.append("    cvt.u64.u32 %rd10, %r2;")
    L.append("    add.s64 %rd14, %rd10, %rd13;")
    L.append("")

    # 载入初值（16 条链初值各不相同，来自显存）
    L.append("    // D1: init values come from memory, not from compile-time constants.")
    for c in range(NC):
        L.append("    ld.global.f32 %%f%d, [%%rd12+%d];" % (c + FBASE, c * 4))
    L.append("")
    L.append("    mov.u32 %r5, 0;")
    L.append("LOOP:")
    for s in range(S):
        for c in range(NC):
            L.append("    fma.rn.f32 %%f%d, %%f%d, %s, %s;   // s=%d c=%d"
                     % (c + FBASE, c + FBASE, f32hex(K[s][c]), f32hex(B[c]), s, c))
    L.append("")
    L.append("    add.u32 %r5, %r5, 1;")
    L.append("    setp.lt.u32 %p1, %r5, %r1;")
    L.append("    @%p1 bra LOOP;")
    L.append("")
    for c in range(NC):
        L.append("    st.global.f32 [%%rd14+%d], %%f%d;" % (c * 4, c + FBASE))
    L.append("    ret;")
    L.append("}")
    return "\n".join(L) + "\n"


def cfloat(v):
    """float -> C 浮点字面量（带 f 后缀）。

    不能直接吐 PTX 的 0fXXXXXXXX，那不是 C 语法。这里用 Python 的最短往返
    表示：编译回 float 之后位模式必然与原始 4 字节完全一致，宿主重放才对得上。
    """
    return repr(v) + "f"


def emit_header(K, B):
    L = []
    L.append("/* _fmareal_const.h -- AUTO-GENERATED by _mkfmareal.py. Do not edit. */")
    L.append("#ifndef FMAREAL_CONST_H")
    L.append("#define FMAREAL_CONST_H")
    L.append("")
    L.append("#define FM_S %d" % S)
    L.append("#define FM_NC %d" % NC)
    L.append("")
    L.append("static const float FMK[FM_S][FM_NC] = {")
    for s in range(S):
        L.append("    { " + ", ".join(cfloat(K[s][c]) for c in range(NC)) + " },")
    L.append("};")
    L.append("")
    L.append("static const float FMB[FM_NC] = { "
             + ", ".join(cfloat(B[c]) for c in range(NC)) + " };")
    L.append("")
    L.append("#endif")
    return "\n".join(L) + "\n"


def main():
    K, B = gen()

    # 自检4：PTX 源码必须纯 ASCII
    src = emit_ptx(K, B)
    try:
        src.encode("ascii")
    except UnicodeEncodeError as e:
        raise SystemExit("[错误] PTX 里有非 ASCII 字符，JIT 会静默失败: %s" % e)

    # 自检5：FMA 条数必须正好 LOOP_FMA 条（防止生成器漏发）
    n = src.count("fma.rn.f32")
    if n != LOOP_FMA:
        raise SystemExit("[错误] 循环体 FMA 条数 %d，应为 %d" % (n, LOOP_FMA))

    # 自检6：常量表在 PTX 里出现次数必须与头文件一致
    hdr = emit_header(K, B)
    for s in range(S):
        for c in range(NC):
            h = f32hex(K[s][c])
            if src.count(h + ",") < 1:
                raise SystemExit("[错误] K[%d][%d]=%s 没出现在 PTX 里" % (s, c, h))
    import re as _re0
    if _re0.search(r"\b0f[0-9A-Fa-f]{8}\b", hdr):
        raise SystemExit("[错误] 头文件里混进了 PTX 字面量，不是 C 语法")

    # 自检6b：每个 C 字面量必须精确还原成原始 4 字节位模式。
    # 宿主重放用的是这些 C 值，只要有一位对不上，「活儿真干了」的验证就是假的。
    for s in range(S):
        for c in range(NC):
            back = struct.pack(">f", float(cfloat(K[s][c])[:-1]))
            if back != struct.pack(">f", K[s][c]):
                raise SystemExit("[错误] C 字面量 %s 在第 (%d,%d) 处往返不精确"
                                 % (cfloat(K[s][c]), s, c))
    for c in range(NC):
        back = struct.pack(">f", float(cfloat(B[c])[:-1]))
        if back != struct.pack(">f", B[c]):
            raise SystemExit("[错误] B[%d] 往返不精确" % c)

    import re as _re
    nlit = len(_re.findall(r"[-+]?\d+\.\d+(?:[eE][-+]?\d+)?f", hdr))
    if nlit != S * NC + NC:
        raise SystemExit("[错误] 头文件浮点字面量个数 %d，应为 %d"
                         % (nlit, S * NC + NC))

    # 自检7：载入/存储条数必须各为 NC，且初值取自 p_init、结果写到 p_out。
    #       两者若共用一块显存就会自读自写竞争，验证结果不可信。
    if src.count("ld.global.f32") != NC:
        raise SystemExit("[错误] 载入条数 %d，应为 %d" % (src.count("ld.global.f32"), NC))
    if src.count("st.global.f32") != NC:
        raise SystemExit("[错误] 存储条数 %d，应为 %d" % (src.count("st.global.f32"), NC))
    if "[%rd12+" not in src or "[%rd14+" not in src:
        raise SystemExit("[错误] 初值与输出没分开走不同的指针")

    # 自检8（通用静态检查）：PTX 里 %r<N> / %rd<N> / %f<N> / %p<N> 指向同一个
    #        物理寄存器，类型视图撞名 = 静默写坏。这道检查就是为了挡住
    #        `mov.u32 %r6, 16;` 覆盖 `%rd6`（p_init 指针）那类 bug。
    import re
    def used(kind):
        return set(int(m) for m in re.findall(r"%%%s(\d+)" % kind, src))
    r32, r64, f32r = used("r"), used("rd"), used("f")
    clash = (r32 & r64)
    if clash:
        raise SystemExit("[错误] 寄存器视图撞名 %r 同时被当成 32/64 位用"
                         "（典型症状：一行 mov 把指针悄悄写坏）"
                         % sorted(clash))
    if f32r & (r32 | r64):
        raise SystemExit("[错误] 浮点视图与整数视图撞名 %r"
                         % sorted(f32r & (r32 | r64)))
    if r32 or r64:
        # .reg 声明的容量必须真的够用，且不能有越界
        decl_r = int(re.search(r"\.reg \.b32\s+%r<(\d+)>", src).group(1))
        decl_rd = int(re.search(r"\.reg \.b64\s+%rd<(\d+)>", src).group(1))
        decl_f = int(re.search(r"\.reg \.f32\s+%f<(\d+)>", src).group(1))
        if max(r32) >= decl_r or max(r64) >= decl_rd or max(f32r) >= decl_f:
            raise SystemExit("[错误] 寄存器越界 r<%d> rd<%d> f<%d>，"
                             "实际用到 r=%d rd=%d f=%d"
                             % (decl_r, decl_rd, decl_f,
                                max(r32), max(r64), max(f32r)))
    print("自检8 通过：32/64/f32 视图无撞名，越界检查通过"
          "（用到 r%d rd%d f%d）" % (max(r32), max(r64), max(f32r)))

    with open("_ptx_FMAREAL.ptx", "w", encoding="ascii", newline="\n") as fh:
        fh.write(src)
    with open("_fmareal_const.h", "w", encoding="ascii", newline="\n") as fh:
        fh.write(hdr)

    print("已生成 _ptx_FMAREAL.ptx  (%d 字节, 循环体 %d 条 FMA)"
          % (len(src), LOOP_FMA))
    print("已生成 _fmareal_const.h  (K %dx%d + B %d 个常量, 两两互异已断言)"
          % (S, NC, NC))
    print("K 范围 %.6f ~ %.6f" % (min(min(r) for r in K), max(max(r) for r in K)))


if __name__ == "__main__":
    main()
