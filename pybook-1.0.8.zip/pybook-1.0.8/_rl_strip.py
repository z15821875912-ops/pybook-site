# 把摆杆演示的关键帧拼成一张「学习过程」对照图
#
# 为什么要拼：单张截图看不出「在学」，六张按回合排开才看得出
# 左边那根杆是怎么从歪倒变成笔直的。
#
#   python -B _rl_strip.py [目录] [输出png]

import glob
import os
import sys

from PIL import Image, ImageDraw, ImageFont

SRC = sys.argv[1] if len(sys.argv) > 1 else 'shots_rl_demo'
OUT = sys.argv[2] if len(sys.argv) > 2 else 'shots_rl/摆杆学习过程.png'

PICK = [0, 2, 4, 6, 8, 10]          # rl_000 / 002 / 004 / 006 / 008 / 010
CAP = ['第 1 帧', '约 3800 帧', '约 7600 帧', '约 11400 帧', '约 15200 帧', '约 19000 帧']


def font(px):
    for f in (r'C:\Windows\Fonts\msyh.ttc', r'C:\Windows\Fonts\simhei.ttf'):
        try:
            return ImageFont.truetype(f, px)
        except OSError:
            pass
    return ImageFont.load_default()


files = sorted(glob.glob(os.path.join(SRC, '*.png')))
if not files:
    raise SystemExit('没有图：' + SRC)
imgs = []
for n, i in enumerate(PICK):
    if i < len(files):
        cap = CAP[n] if n < len(CAP) else files[i]
        imgs.append((cap, Image.open(files[i]).convert('RGB')))
if not imgs:
    raise SystemExit('图太少')

w, h = imgs[0][1].size
COLS = 3
GAP, CAPH, PAD = 10, 34, 14
rows = (len(imgs) + COLS - 1) // COLS
W = PAD * 2 + w * COLS + GAP * (COLS - 1)
H = PAD + 26 + rows * (CAPH + h) + GAP * (rows - 1) + PAD

sheet = Image.new('RGB', (W, H), (11, 16, 24))
d = ImageDraw.Draw(sheet)
f_c = font(17)
f_t = font(20)

for n, (cap, im) in enumerate(imgs):
    x = PAD + (n % COLS) * (w + GAP)
    y = PAD + 26 + CAPH + (n // COLS) * (CAPH + h + GAP)
    sheet.paste(im, (x, y))
    d.rectangle([x, y, x + w - 1, y + h - 1], outline=(46, 58, 76))
    d.text((x + 2, y + 6), cap, font=f_c, fill=(150, 166, 190))

d.text((PAD, PAD - 2), 'PYbook · REINFORCE 训 CartPole · 从随机策略到学会平衡',
       font=f_t, fill=(228, 240, 252))
sheet.save(OUT)
print('写入', OUT, sheet.size)
