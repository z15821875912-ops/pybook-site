# -*- coding: utf-8 -*-
"""_fix_lib3.py — polyfit 的两个 bug

1. 范德蒙德矩阵建错了：A[j][k] 本该是 Σ mx^(j+k)，代码里 pw 在 j 循环推进、
   k 循环里不变，等于 A[j][k] = Σ mx^j —— **所有列一样，秩 1**。
   结果是 deg>=1 的任何输入都报「正规方程奇异」。实测矩阵退化成
       5 5 5 / 0 0 0 / 10 10 10   （本该 5 0 10 / 0 10 0 / 10 0 34，行列式 700）
2. 解出来的是**中心化基底** (x−x̄) 的系数，却按「x 的幂」返回。
   x=[0..4] 拟合 x² 会给 [-2, 4, 1]（对应 (x−2) 的幂），用户拿去算
   -2 + 4x + x² 在 x=3 处得 19，真值 9 —— 静默给错答案。
   改成用 Horner 换算回原始 x 的幂。
"""
import io
import sys

P = 'pybook_lib.c'
t = io.open(P, encoding='utf-8', newline='').read()


def sub(tag, old, new):
    global t
    for eol in ('\r\n', '\n'):
        o, n = old.replace('\n', eol), new.replace('\n', eol)
        c = t.count(o)
        if c == 1:
            t = t.replace(o, n, 1)
            print('  [OK] %s（行尾 %s）' % (tag, 'CRLF' if eol == '\r\n' else 'LF'))
            return
        if c > 1:
            sys.exit('%s：子串出现 %d 次，不唯一' % (tag, c))
    sys.exit('%s：子串找不到' % tag)


# ---- bug 1：矩阵每列都加上 mx^(j+k)，不是 mx^j ----
sub('1 范德蒙德矩阵的 (j+k) 次幂',
    """    for (i = 0; i < n; i++) {
        double pw = 1.0;
        for (j = 0; j < m; j++) {
            for (k = 0; k < m; k++) A[(size_t)j * m + k] += pw;
            B[j] += pw * my[i];
            pw *= mx[i];
        }
    }""",
    """    /* A[j][k] = Σ mx_i^(j+k)，所以 pw 必须在 **k** 循环里推进。
     * 原来只在 j 循环里推进，等于每一列都加上 Σ mx^j —— 所有列一模一样，
     * 矩阵秩 1，于是 deg>=1 的输入一律被判「正规方程奇异」。 */
    for (i = 0; i < n; i++) {
        double pj = 1.0;                       /* mx_i^j */
        for (j = 0; j < m; j++) {
            double p = pj;                     /* mx_i^(j+k) */
            for (k = 0; k < m; k++) {
                A[(size_t)j * m + k] += p;
                p *= mx[i];
            }
            B[j] += pj * my[i];
            pj *= mx[i];
        }
    }""")

# ---- bug 2：中心化基底 -> 原始 x 的幂 ----
sub('2 系数换算回原始 x 的幂',
    """    out = rt_list_new();
    for (j = 0; j < m; j++) rt_push(&out, rt_float(cx[j]));
    free(x); free(y); free(mx); free(my); free(A); free(B); free(cx);
    return out;""",
    """    /* cx 是 (x−x̄) 的幂的系数，要按「x 的幂」返回，否则用户拿去代回原 x 就全错。
     * Horner 换算：d(x) = ((…(cx_deg·(x−x̄) + cx_{deg−1})…)·(x−x̄) + cx_0) */
    {
        double d[13];
        int    jj, kk;
        for (jj = 0; jj <= deg; jj++) d[jj] = 0.0;
        d[0] = cx[deg];
        for (jj = deg - 1; jj >= 0; jj--) {
            for (kk = deg; kk >= 1; kk--)
                d[kk] = d[kk - 1] - sx * d[kk];
            d[0] = -sx * d[0] + cx[jj];
        }
        out = rt_list_new();
        for (jj = 0; jj <= deg; jj++) rt_push(&out, rt_float(d[jj]));
    }
    free(x); free(y); free(mx); free(my); free(A); free(B); free(cx);
    return out;""")

# sx 现在要用到（换算时要 x̄），把它提出块作用域
sub('2b sx 提到外层',
    """    double   *A, *B, *cx, *mx, *my;
    Value     out;""",
    """    double   *A, *B, *cx, *mx, *my;
    double    sx = 0.0, sy = 0.0;       /* x̄ / ȳ：中心化要用，换算回原幂也要用 */
    Value     out;""")

sub('2c 中心化块用外层的 sx/sy',
    """    {   double sx = 0, sy = 0;
        for (i = 0; i < n; i++) { sx += x[i]; sy += y[i]; }
        sx /= (double)n; sy /= (double)n;
        for (i = 0; i < n; i++) { mx[i] = x[i] - sx; my[i] = y[i] - sy; }
    }""",
    """    for (i = 0; i < n; i++) { sx += x[i]; sy += y[i]; }
    sx /= (double)n; sy /= (double)n;
    for (i = 0; i < n; i++) { mx[i] = x[i] - sx; my[i] = y[i] - sy; }""")

# 换算缓冲区按 deg 上限 12 给 13 个（deg=12 -> 13 个系数），已在上面那处一起加

io.open(P, 'w', encoding='utf-8', newline='').write(t)
print('\npolyfit 两处已修')
