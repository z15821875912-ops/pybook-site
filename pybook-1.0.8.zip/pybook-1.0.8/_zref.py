# -*- coding: utf-8 -*-
"""_zref.py — 用 decimal + Hasse-Sondow 全局收敛级数造 ζ(s) 的高精度参考值。

ζ(s) = 1/(1 - 2^(1-s)) * Σ_{n>=0} 2^-(n+1) * Σ_{k=0}^{n} (-1)^k C(n,k)/(k+1)^s
几何收敛，n=80 项约 1e-24。比 N=10^7 的 Euler-Maclaurin 可靠（后者在 s→1 时
根本不收敛，实测 N 从 10 万加到 250 万误差一动不动）。
"""

from decimal import Decimal, getcontext
from fractions import Fraction
import math
import time

getcontext().prec = 60


def zeta_ref(s, nterms=90):
    sD = Decimal(repr(s))
    two = Decimal(2)
    total = Decimal(0)
    for n in range(nterms):
        inner = Decimal(0)
        binom = 1                       # C(n,0)
        for k in range(n + 1):
            if k:
                binom = binom * (n - k + 1) // k
            inner += Decimal(binom if (k % 2 == 0) else -binom) / (Decimal(k + 1) ** sD)
        total += inner / (two ** (n + 1))
    return total / (Decimal(1) - two ** (Decimal(1) - sD))


BF = [Fraction(1, 12), Fraction(-1, 720), Fraction(1, 30240),
      Fraction(-1, 1209600), Fraction(1, 47900160), Fraction(-691, 1307674368000)]
BFf = [float(x) for x in BF]


def zeta_c(s, C=10, K=6, cap=4000000):
    N = int(C/(s-1.0) + 16.0)
    N = max(20, min(N, cap))
    total = sum(float(i)**(-s) for i in range(1, N))
    t = N**(-s)
    total += 0.5*t + t*N/(s-1.0)
    ps = s
    for k in range(K):
        if k > 0:
            for i in range(2):
                ps *= (s + 2.0*k - 1.0 + i)
        total += BFf[k]*ps*N**(-s-2.0*k-1.0)
    return total, N


print('%-10s %-26s %-26s %-11s %-11s' % ('s', '参考值(Hasse, 60位)', '双精度E-M(C=10)', '相对误差', 'N'))
for s in (2.0, 4.0, 5.0, 1.5, 1.1, 1.01, 1.001, 1.0001, 1.00001, 20.0):
    ref = zeta_ref(s)
    v, N = zeta_c(s)
    rel = abs(Decimal(repr(v)) - ref) / abs(ref)
    print('%-10s %-26s %-26s %-11.2e %-11d' % (s, ('%.18f' % ref)[:26], repr(v), float(rel), N))

print()
print('参考值自检：ζ(2) 与 π²/6 差 =', float(abs(zeta_ref(2.0) - Decimal(repr(math.pi**2/6)))))
print('           ζ(4) 与 π⁴/90 差 =', float(abs(zeta_ref(4.0) - Decimal(repr(math.pi**4/90)))))
print()
print('把 K 加大能不能便宜地补 s→1 的精度？C=10：')
for K in (6, 10, 14, 18):
    v, N = zeta_c(1.0001, C=10, K=min(K, 6))
    ref = zeta_ref(1.0001)
    print('  K=%-3d 相对误差 %.2e' % (K, float(abs(Decimal(repr(v)) - ref) / abs(ref))))
