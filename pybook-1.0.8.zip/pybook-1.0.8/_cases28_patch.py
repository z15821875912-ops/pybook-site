# -*- coding: utf-8 -*-
"""_cases28_patch.py —— tests/cases.py 追加 T28（sym.极限 + sym.级数 端到端）。
幂等：锚点在位才写；写毕自检计数。行尾 LF。"""
import io, sys

P = 'tests/cases.py'
s = io.open(P, encoding='utf-8', newline='').read()

ANCHOR = "case(**{'id': 'T27_sym_solve_sys_arity_err'"
if s.count(ANCHOR) != 1:
    sys.stderr.write('FAIL [锚点] count=%d\n' % s.count(ANCHOR)); sys.exit(1)

NEW = r'''case(**{'id': 'T28_sym_limit_ok', 'kind': 'normal', 'src': '@ pybk>测试>sym极限\nGOING:{\nns.show(sym.极限("sin(x)/x", "x", "0"))\nns.show(sym.极限("(x^2-4)/(x-2)", "x", "2"))\nns.show(sym.极限("(1-cos(x))/x^2", "x", "0"))\nns.show(sym.极限("x^2", "x", "3"))\nns.show(sym.极限("(2x+1)/(x-3)", "x", "inf"))\n}STOP\n', 'out': '1\n4\n1/2\n9\n2\n', 'expect': '0/0 与 ∞/∞ 走洛必达（分子分母各自求导，两轮）；直接代入；无穷远数值外推', 'err': '', 'err_contains': [], 'exit': 0})
case(**{'id': 'T28_sym_limit_inf_ok', 'kind': 'normal', 'src': '@ pybk>测试>sym极限无穷\nGOING:{\nns.show(sym.极限("1/x^2", "x", "inf"))\nns.show(sym.极限("1/x", "x", "-inf"))\nns.show(sym.极限("x/2+1", "x", "pi"))\nns.show(sym.极限("sin(x)", "x", "pi"))\n}STOP\n', 'out': '0\n-1e-10\n2.570796327\n0\n', 'expect': '±inf 双侧可写；pi 当点（sin(pi)=1.2e-16 被 snap 回 0）；非整洁值留 %.10g', 'err': '', 'err_contains': [], 'exit': 0})
case(**{'id': 'T28_sym_limit_diverge_err', 'kind': 'error', 'src': '@ pybk>测试>sym极限发散\nGOING:{\nvg.d = sym.极限("1/x", "x", "0")\n}STOP', 'out': '', 'exit': 1, 'err_contains': ['sym.极限：极限不存在：x 趋近 0 时函数趋于无穷', '左右两侧要分开看', '程序异常退出，退出码 1'], 'expect': '5/0 出 inf 是真发散（两侧探数不收敛到一块儿），不滥用洛必达'})
case(**{'id': 'T28_sym_limit_flap_err', 'kind': 'error', 'src': '@ pybk>测试>sym极限乱抖\nGOING:{\nvg.d = sym.极限("x*sin(1/x)", "x", "0")\n}STOP', 'out': '', 'exit': 1, 'err_contains': ['sym.极限：把 x = 0 代进去，式子里抖出了 nan', '第一版看不出来', '程序异常退出，退出码 1'], 'expect': '0*inf 出 nan 是内部乱抖（真实极限 0 存在）——不硬给答案，明说看不出来'})
case(**{'id': 'T28_sym_limit_domain_err', 'kind': 'error', 'src': '@ pybk>测试>sym极限定义域\nGOING:{\nvg.d = sym.极限("log(x)", "x", "0")\n}STOP', 'out': '', 'exit': 1, 'err_contains': ['sym.极限：把 x = 0 代进去之后，函数在那附近没定义', '第一版看不出来', '程序异常退出，退出码 1'], 'expect': '定义域外（log(0)）→ 明说代入后没定义，不编答案'})
case(**{'id': 'T28_sym_limit_trap_err', 'kind': 'error', 'src': '@ pybk>测试>sym极限陷阱\nGOING:{\nvg.d = sym.极限("(1+x)^(1/x)", "x", "0")\n}STOP', 'out': '', 'exit': 1, 'err_contains': ['sym.极限：符号答案（1）和两侧数值对拍不一致', '第一版不敢认', '程序异常退出，退出码 1'], 'expect': 'pow(1,inf)=1 的 IEEE 陷阱：符号算出 1、数值对拍却是 e——对拍闸拦下不认'})
case(**{'id': 'T28_sym_limit_osc_err', 'kind': 'error', 'src': '@ pybk>测试>sym极限振荡\nGOING:{\nvg.d = sym.极限("x*sin(x)", "x", "inf")\n}STOP', 'out': '', 'exit': 1, 'err_contains': ['sym.极限：在无穷远处定不下来', '第一版只做数值外推，认输', '程序异常退出，退出码 1'], 'expect': '无穷远三点外推不收敛 → 明说数值近似认输，不谎称发散'})
case(**{'id': 'T28_sym_limit_badpt_err', 'kind': 'error', 'src': '@ pybk>测试>sym极限坏点\nGOING:{\nvg.d = sym.极限("x", "x", "abc")\n}STOP', 'out': '', 'exit': 1, 'err_contains': ['sym.极限：第三个参数（点）看不懂', '无穷写 inf', '程序异常退出，退出码 1'], 'expect': '点参数看不懂 → 报错并给合法写法（数字/pi/e/算式/inf）'})
case(**{'id': 'T28_sym_limit_multivar_err', 'kind': 'error', 'src': '@ pybk>测试>sym极限多变量\nGOING:{\nvg.d = sym.极限("x+y", "x", "0")\n}STOP', 'out': '', 'exit': 1, 'err_contains': ['sym.极限：公式里还有变量 y', 'sym.替换', '程序异常退出，退出码 1'], 'expect': '多变量 → 点名是哪个变量并指路 sym.替换'})
case(**{'id': 'T28_sym_limit_arity_err', 'kind': 'error', 'src': '@ pybk>测试>sym极限元数\nGOING:{\nvg.d = sym.极限("sin(x)/x", "x")\n}STOP', 'out': '', 'exit': 1, 'err_contains': ['第 3 行：sym.极限 需要 3 个参数，实际 2 个', '为什么：', '怎么改：'], 'expect': '元数写错 → 编译期拦'})
case(**{'id': 'T28_sym_series_ok', 'kind': 'normal', 'src': '@ pybk>测试>sym级数\nGOING:{\nns.show(sym.级数("sin(x)", "x", "0", 5))\nns.show(sym.级数("cos(x)", "x", "0", 4))\nns.show(sym.级数("exp(x)", "x", "0", 3))\nns.show(sym.级数("log(1+x)", "x", "0", 3))\nns.show(sym.级数("1/(1-x)", "x", "0", 3))\nns.show(sym.级数("sin(x)", "x", "0", 0))\nns.show(sym.级数("sin(x)", "x", "0", 1))\n}STOP\n', 'out': 'x - 1/6*x^3 + 1/120*x^5 + O(x^6)\n1 - 1/2*x^2 + 1/24*x^4 + O(x^5)\n1 + x + 1/2*x^2 + 1/6*x^3 + O(x^4)\nx - 1/2*x^2 + 1/3*x^3 + O(x^4)\n1 + x + x^2 + x^3 + O(x^4)\n0 + O(x)\nx + O(x^2)\n', 'expect': '系数 c_k=f^(k)/k! 走 Frac 精确化（1/6、1/120、1/24）；0 系数项不占位；负系数出 " - "；k=1 出 x 不出 x^1', 'err': '', 'err_contains': [], 'exit': 0})
case(**{'id': 'T28_sym_series_pt_ok', 'kind': 'normal', 'src': '@ pybk>测试>sym级数非零点\nGOING:{\nns.show(sym.级数("exp(x)", "x", "2", 2))\nns.show(sym.级数("1/(1-x)", "x", "2", 2))\nns.show(sym.级数("x^3", "x", "1", 3))\n}STOP\n', 'out': '7.389056099 + 7.389056099*(x - 2) + 3.694528049*(x - 2)^2 + O((x - 2)^3)\n-1 + (x - 2) - (x - 2)^2 + O((x - 2)^3)\n1 + 3*(x - 1) + 3*(x - 1)^2 + (x - 1)^3 + O((x - 1)^4)\n', 'expect': '非零点展开：底数换 (x - pt)；0 系数项跳过（x^3@1 的 0 阶项缺失但其余项连续）', 'err': '', 'err_contains': [], 'exit': 0})
case(**{'id': 'T28_sym_series_order_err', 'kind': 'error', 'src': '@ pybk>测试>sym级数阶数\nGOING:{\nvg.d = sym.级数("sin(x)", "x", "0", 13)\n}STOP', 'out': '', 'exit': 1, 'err_contains': ['sym.级数 的阶数要在 0 到 12 之间（收到 13）', '程序异常退出，退出码 1'], 'expect': '阶数超 12（与 sym.求解 的 12 次上限对齐，12! 还在 int64 内）→ 绑定层直接拦'})
case(**{'id': 'T28_sym_series_negorder_err', 'kind': 'error', 'src': '@ pybk>测试>sym级数负阶\nGOING:{\nvg.d = sym.级数("sin(x)", "x", "0", -1)\n}STOP', 'out': '', 'exit': 1, 'err_contains': ['sym.级数 的阶数要在 0 到 12 之间（收到 -1）', '程序异常退出，退出码 1'], 'expect': '负阶数 → 绑定层拦'})
case(**{'id': 'T28_sym_series_inf_err', 'kind': 'error', 'src': '@ pybk>测试>sym级数无穷点\nGOING:{\nvg.d = sym.级数("exp(x)", "x", "inf", 3)\n}STOP', 'out': '', 'exit': 1, 'err_contains': ['sym.级数 只支持有限的点（收到 inf）', '先把 x 换成 1/t', '程序异常退出，退出码 1'], 'expect': '无穷点不给展开（第一版边界）→ 报错并指路换元'})
case(**{'id': 'T28_sym_series_multivar_err', 'kind': 'error', 'src': '@ pybk>测试>sym级数多变量\nGOING:{\nvg.d = sym.级数("x+y", "x", "0", 3)\n}STOP', 'out': '', 'exit': 1, 'err_contains': ['sym.级数：公式里还有变量 y', 'sym.替换', '程序异常退出，退出码 1'], 'expect': '多变量 → 点名并指路 sym.替换'})
case(**{'id': 'T28_sym_series_pole_err', 'kind': 'error', 'src': '@ pybk>测试>sym级数奇点\nGOING:{\nvg.d = sym.级数("log(x)", "x", "0", 3)\n}STOP', 'out': '', 'exit': 1, 'err_contains': ['sym.级数：第 0 阶导数在 x = 0 处求值失败', '程序异常退出，退出码 1'], 'expect': '在奇点处展开（log(x)@0）→ 求值失败明确报出，不编系数'})
case(**{'id': 'T28_sym_series_arity_err', 'kind': 'error', 'src': '@ pybk>测试>sym级数元数\nGOING:{\nvg.d = sym.级数("sin(x)", "x", "0")\n}STOP', 'out': '', 'exit': 1, 'err_contains': ['第 3 行：sym.级数 需要 4 个参数，实际 3 个', '为什么：', '怎么改：'], 'expect': '元数写错 → 编译期拦'})
'''

lines = s.split('\n')
out_lines = []
inserted = False
for ln in lines:
    out_lines.append(ln)
    if not inserted and ANCHOR in ln:
        out_lines.append(NEW.rstrip('\n'))
        inserted = True
if not inserted:
    sys.stderr.write('FAIL [插入点] 没找到\n'); sys.exit(1)
s2 = '\n'.join(out_lines)
io.open(P, 'w', encoding='utf-8', newline='').write(s2)

# 自检
chk = io.open(P, encoding='utf-8', newline='').read()
n28 = chk.count("'id': 'T28_")
print('写入 %s' % P)
print('T28 用例数: %d' % n28)
raw = open(P, 'rb').read()
print('裸 CR %d' % raw.count(b'\r'))
if n28 != 17:
    sys.stderr.write('FAIL [T28 计数] %d\n' % n28); sys.exit(1)
if raw.count(b'\r') != 0:
    sys.stderr.write('行尾混杂!\n'); sys.exit(1)
print('=== _cases28_patch 全部通过 ===')
