# PYbook VM JIT（C 后端）设计 v1

> 状态：设计评审中（2026-10-11）。核心运行时 `pyvm.c` 尚未改动；本文件仅用于拍板后实施。

## 0. 探针结论（已验证）
`build_tmp/jit_spike/` 隔离探针已把最危险链路完全钉死：

- 系统 gcc `C:\Users\zhuli\mingw64\bin\x86_64-w64-mingw32-gcc.exe` 可把 pybook 运行时编成 DLL：
  `-O3 -march=native -I. -shared -DMP_RT_BINDING <runtime .c 全集> -o hot.dll -lwinmm -lm`
- `LoadLibraryA("hot.dll")` + `GetProcAddress(h,"jit_sum")` + `Value jit_sum(Value*,int)` 调用，
  `Value`(uint64 NaN-box) 往返正确：
  ```
  jit_sum(1000000) = 500000500000  (expect 500000500000)  OK
  ```
- 关键坑（已踩过）：
  1. **exe/host 命令也必须带 `-march=native`**——`pybook_tb.c` 用了 AVX 内联(`_mm256_setzero_pd`)，缺该 flag 链接期报 target mismatch。
  2. **沙箱自带 mingw 链接库不全**（缺 `crt2.o`/`libgcc` 等），必须用系统 `C:\Users\zhuli\mingw64`。
  3. 运行时 `.c` 全集：`pybook_rt.c pybook_lib.c pybook_csv.c pybook_json.c pybook_file.c pybook_mt.c pybook_mm.c pybook_np.c pybook_tb.c pybook_bits.c pybook_smoke.c pybook_music.c mathplus.c`

## 1. 调研发现（读 pyvm.c / pybk_code.py）
- **`CALL(0x30)`（pyvm.c:689）是天然拦截点**：实参已从操作数栈按序弹入 `slots[i-1]`，
  直接 `native(slots, nargs)` 取返回值 `push` 即可，**完全跳过 Frame 压栈**。
- **`Fn` 是内存结构体**（pyvm.c:138-144，仅 `name_idx/nparams/nslots/code_off/code_len`），
  可安全加 `void *jit_ptr` 与 `uint32_t hot` 两字段，**不破坏 `.pybc` 二进制加载格式**。
- **`pyvm.c` 只加载 `.pybc`（字节码）**，里面**没有源码/AST**。
  → JIT 只能从**字节码反推 C**，不能调 `pybk_code.py`（那要源码且生成整程序+`int main`，
  全局 `vg.*` 会变 DLL 内 C 全局，与解释器 slot 全局分叉）。
- **`pybk_code.py` 生成整程序**（gen_fn / `int main(void)` @3378；`vg.*`→C 全局 `RT_S_*`），
  确认「复用 C 后端做整模块 AOT」会与解释器全局状态冲突 → 排除。
- **结论**：v1 走「**字节码→C 重放**」最自洽，且把 JIT 限制在「无模块全局、无用户函数调用」的
  **叶子函数**，彻底规避共享状态分叉，同时覆盖用户最需要的张量/数值热循环。

## 2. v1 架构
1. **开关**：`pyvm` 加 `--jit[=阈值]`（默认阈值 = 16 次调用，第三轮由 200 改下来，见 §12）。**不传则纯解释器，零行为变化、零风险。**
2. **热计数**：`CALL` 里 `callee->hot++`；到阈值且模块 JIT 启用且函数「可 JIT」→ 触发编译（只编一次，置 `jit_ptr`）。
3. **可 JIT 判定（v1 叶子）**：函数字节码**不含** `CALL(0x30)` 到其它用户函数、**不含** `CALL_LIB(0x36)`、
   **不含**对模块级 `vg.*` 全局的读写（即只用参数/局部/常量/List/Dict/rt_* 数值与比较运算）。
   命中就编译，否则永远留给解释器。
4. **代码生成（字节码→C 重放，写在 `pyvm.c` 内或新文件 `pyvm_jit.c`）**：
   - 入口 `Value jit_<name>(Value *a, int n)`；内部 `Value S[nslots];` 参数填 `a[0..n)`、其余 `rt_none()`。
   - 常量在 JIT 期从字节码解码，直接内联 `rt_int/rt_float/rt_str(...)` 字面量（自包含，不需共享 `m.consts`）。
   - 逐 opcode 发 C：`ADD`→`push(rt_add(pop(),pop()))`；`LOAD s`→`push(S[s])`；`STORE s`→`S[s]=pop()`；
     跳转→把每个跳转目标映射成 `L<off>` 标签 + `if(cond) goto L<tgt>;`；`AROUND`→`for`；
     `SHOW_*`→`rt_show_*`；`LIST_*`/`DICT_*`/`INDEX`/`SETIDX`/`LEN` 同理。
   - 遇到不支持的 opcode（用户函数调用/CALL_LIB/类相关）即标记「不可 JIT」，回退解释器。
5. **编译**：生成 `.c` 用系统 gcc 编成 `build/.jit/<模块hash>_<fn>_<srchash>.dll`
   （带 `-march=native -shared -DMP_RT_BINDING` + 全部运行时 .c）。
   失败 → `jit_ptr=NULL`，解释器继续。**JIT 永不破坏正确性。**
6. **调用点路由**：`CALL` 里
   ```c
   if (callee->jit_ptr) {
       Value *jav = malloc(nargs * sizeof(Value));
       for (uint8_t i = nargs; i > 0; i--) jav[i-1] = pop();
       Value rv = ((JitFn)callee->jit_ptr)(jav, nargs);
       free(jav); push(rv); VM_NEXT();
   }
   ```
   否则走原解释路径（压新 Frame）。
7. **失效/缓存**：按 `(模块名, 函数名, 源码hash)` 缓存 DLL；**同一次运行只编一次**。
   `build/.jit/` 可由 `pybktl clean` 清；**不跨运行缓存**（避免陈旧 DLL）。
8. **兜底**：gcc 缺失 / 编译错 / `LoadLibrary` 失败 → 记一次 warning（`PYVM_JIT_VERBOSE=1` 可见），
   `jit_ptr` 留空，解释器照常跑。

## 3. 不做的（v1 之外，留待后续）
- 用户函数互调用 / `CALL_LIB` 的原生化（需 VM 回调桥 `vm_call_by_index`）。
- 模块级全局跨 JIT/解释边界共享（需把全局搬进运行时或共享内存）。
- 去优化（deopt）/ 栈上替换（OSR）：v1 只在**函数边界**切换，无 OSR。
- 多线程 JIT 队列：v1 同步编译（热函数首次越阈时编，之后直跳原生）。

## 4. 风险与对策
- 改的是核心运行时 `pyvm.c` → **硬保证「不传 `--jit` 即零行为变化」** + 全量回归
  （`tests/run_tests.py` 113 + `smokeroor.py` 8）必须全绿。
- 字节码→C 重放必须逐 opcode 与解释器语义**逐字一致**；用 `build_tmp/jit_spike` 同款
  和式 / 斐波那契 / 列表核做端到端对照（解释器结果 == 原生结果）。

## 5. 预期收益
- 叶子数值/张量热循环（求和、点乘、逐元素运算、fib、素数筛）从「解释 dispatch」变「直跳原生」，
  典型 3–10× 加速（取决于函数体内 opcode 数，函数越胖越值）。
- 非叶子 / 含 I/O / 含全局的函数完全不受影响，行为不变。

## 6. 实施分期（拍板后）
- **Phase A**：`pyvm.c` 加 `--jit` 开关 + `Fn.jit_ptr/hot` 字段 + `CALL` 里热计数与「如果已 jit 就跳原生」空壳（jit_ptr 永远 NULL）→ 全量回归零变化。
- **Phase B**：`pyvm_jit.c` 字节码→C 重放发射器（先覆盖 ADD/SUB/MUL/DIV/常量/LOAD/STORE/跳转/AROUND/比较/LIST/DICT/SHOW）。
- **Phase C**：gcc 调起 + DLL 落盘 + `LoadLibrary` 缓存 + 调用点接上；`PYVM_JIT_VERBOSE` 日志。
- **Phase D**：端到端对照测试（解释器 vs 原生 结果一致）+ 加 `pybktl`/文档说明 + 回归全绿。

---

## 7. 实施记录（2026-10-11，已全部完成）

### 用法
```
pyvm.exe --jit[=阈值] 文件.pybc
# 环境变量（均可省，有默认值）：
#   PYBOOK_JIT_GCC   gcc 路径（默认 C:/Users/zhuli/mingw64/bin/x86_64-w64-mingw32-gcc.exe）
#   PYBOOK_JIT_SRC   运行时源码目录（默认 C:/Users/zhuli/Desktop/pybook，含 pybook_rt.c 等）
#   PYVM_JIT_VERBOSE=1  打印 JIT 触发/编译/落盘日志
# 不传 --jit 时 pyvm 是纯解释器，行为与改动前逐字一致（零行为变化）。
```

### 实测结果（叶子函数 v1）
| 程序 | 解释器 | JIT（--jit） | 结论 |
|---|---|---|---|
| 求和(1000) 循环 2000 次 | 500500 | `[JIT] compiled+linked fn 1 (求和)` → 500500 | ✅ 字节码→C 重放 + 原生直跳正确 |
| 取绝对值(-7) 带 if 分支 | 7 | `[JIT] compiled+linked fn 1 (取绝对值)` → 7 | ✅ JUMP_IF_FALSE 分支正确 |
| 阶乘(5) 递归（含 CALL） | 120 | 无 compiled 日志（正确判定不可 JIT）→ 120 | ✅ 含调用函数安全回退解释器 |

### 验证过的边界
- `--jit=1` 立即编译、多次运行输出稳定、阈值生效。
- 递归/互调函数含 `CALL(0x30)`、`CALL_LIB(0x36)` 被正确排除 → 永走解释器，结果无误。
- 非 JIT 路径：`pyvm_test.exe` 自测全过；`smokeroor.py` 8/8 与基线一致；C 后端（run_tests 96/96）未改动故不受影响。

### 踩坑（已解决）
1. **`system()` 在 Windows 走 `cmd.exe /c "..."`，命令内嵌套双引号被 cmd 解析破坏** → 报「文件名、目录名或卷标语法不正确」。改用 `_spawnvp(_P_WAIT, gcc, argv)` 直接 spawn，不经过 shell，参数带空格也安全。
2. **生成 C 用了 `floor` 但缺 `<math.h>`** → 前导加 `#include <math.h>`。
3. **编 pyvm.exe 必须走系统 gcc**（`build_pyvm.bat` 默认优先用仓库捆绑的损坏 mingw，链接库不全）。
4. **运行时分配器是共享 CRT malloc 且运行期不 free**（见 pybook_rt.h:36）→ 原生函数返回的盒子跨 DLL 边界无 double-free，v1 安全。

### 当前限制（v1 内，符合设计）
- 仅编译「无用户函数调用(CALL)、无标准库调用(CALL_LIB)」的叶子函数。
- 不跨 JIT/解释边界共享模块级全局（叶子函数用自身槽位，天然规避）。
- @self 手动内存模式下跨边界盒子不进「已释放登记表」（per-copy），理论上有漏防护；叶子核不用该模式，暂不影响。
- 不跨运行缓存 DLL（每次启动重新编译，按 `build/.jit/jit_<fn>.{c,dll}` 落盘，可用 `pybktl clean` 清）。

---

## 8. Phase E：运行时 `.o` 缓存（2026-10-11，已完成）

### 为什么要改

v1 每次 JIT 都把 **13 个运行时 `.c` + 生成的 `jit_<fni>.c` 一次性丢给 gcc**
（`-shared`，无 `-c`），实测 **13.2~16.1 秒**。而 JIT 本身的运行收益只有
几倍，跑 5000 万次也就省 1.3 秒——**编译成本把收益吃得一点不剩**。

### 怎么改的（`pyvm.c` 的 `jit_maybe_compile`）

拆成三步，运行时那 13 个 `.c` 单独走缓存：

1. `build/.jit/rt/<name>.o` ← `<src>/<name>.c`，**只在 `.o` 缺失 / `.c` 更新 / `.o` 为空壳时才编**
   （`jit_obj_stale()`，比 `st_mtime` + `st_size`）
2. `build/.jit/rt/jit_<fni>.o` ← `build/.jit/jit_<fni>.c`，**每次都编**（内容随程序变）
3. `gcc -shared <14 个 .o> -o build/.jit/jit_<fni>.dll -lwinmm -lm`

编译选项：运行时 `.o` 用 `-O3`（只编一次，吃满优化），`jit_<fni>.c` 用 `-O2`
（每次重编，平衡时间）。都带 `-fPIC`（Windows PE 上无害，ELF 上链接进 DLL 必需）。

### 实测（5000 万次热循环 = 200 次调用 × 250000 循环，`数到` 叶子函数）

| 方式 | 改造前 | 改造后 |
|---|---|---|
| 解释器（纯运行） | 1.850 s | 1.850 s |
| C 后端 exe（纯运行） | 0.759 s | 0.759 s |
| JIT 冷启动（`.o` 为空） | 13.560 s | 16.875 s |
| **JIT 热启动（`.o` 命中）** | **13.157 s** | **1.122 s** |

`PYVM_JIT_VERBOSE=1` 日志确认缓存生效：
```
[JIT] 运行时 .o：新编 13 个 / 命中缓存 0 个     ← 冷
[JIT] 运行时 .o：新编 0 个 / 命中缓存 13 个     ← 热
```

**热启动省下 12.04 秒（11.7 倍）。** 结果三档全部一致（`总 50000000`）。

### 代价与结论

- 冷启动从 13.6 s 涨到 16.9 s（多 13 次 gcc spawn 开销 + `-O3` 比 `-O2` 慢）。
  换来的是热启动 13.2 s → 1.1 s。**冷启动只在改过运行时源码后才重来一次，划算。**
- 改造后 JIT 热启动 1.122 s vs C 后端 exe 0.759 s（纯运行口径）**仍是慢的**；
  但按用户实际路径比（`pybk_main.py` 首次 2.576 s / exe 缓存 1.057 s，
  对 `pyvm.exe --jit` 首次 16.9 s / 缓存 1.122 s），**两者基本持平**。
- `.o` 可由 `pybktl clean` 清；`build/.jit/rt/` 是新增目录。

### 使用提醒：两条上原生的路

**函数**靠热计数触发（`CALL(0x30)` 里的 `callee->hot++`）；**主程序 fn 0 永不被 CALL**，
改在 `run_module` 入口按静态指令量估算判定（第三轮加的，见 §12）：

```python
GOING:{ rm.around(20000000){ ... } }     # ✓ 估算过门限，加速 6.3×
func 数到(n){ rm.around(n){ ... } }      # ✓ 热计数触发，加速 4.2×
```

两条路互不冲突：主程序上了原生，它调的函数由生成代码直接调 `jit_<fni>`，不再过热阈。

### JIT 生成的代码比 C 后端还快（实测）

同一段逻辑直接跑原生函数（绕开 gcc 编译）：

| | 时间 |
|---|---|
| 解释器 | 2.288 s |
| **JIT 原生** | **0.539 s**（4.25×） |
| C 后端 exe | 0.775 s |

即 **JIT 版比 C 后端快 1.44×**。原因看生成的 C 就清楚：JIT 版循环是裸 `goto`，
唯一检查是 `sp>=JIT_MAXD`；C 后端还带着 `rt_gc_poll()` 与内存管理模式调用。
**反过来读：C 后端自身还有 1.44× 没拿到。**

### 回归

`pyvm_test.exe` 自测全过 · `smokeroor.py` 8/8 与基线一致 · `tests/run_tests.py` 全绿。

### 踩坑（已解决）

5. **拆 `-c` 后不能再带 `-shared`**——`-shared` 是链接期选项，单文件编译要 `-c` + `-fPIC`，
   否则 gcc 报 "cannot specify -o with -c ... with multiple files" 之类。
6. **`_spawnvp` 是同步的**，13 次 spawn 各约 100 ms，合计约 1.3 s——这正是冷启动变慢的原因，
   可接受（冷启动只发生一次）。

## 9. Phase F：批量编译 + 单次 gcc + DLL 缓存 + 内联快路（2026-10-13，已完成）

### 病根：「加入 JIT 后 VM 慢很多」的两条

1. **JIT 全灭（主因）**：`rt_names` 漏了后加的 `pybook_gpu.c`（以及被 `pybook_rt.c`
   引用的 `pybook_obj.c` / `pybook_wire.c`）→ 每个函数的 DLL 链接都 undefined reference
   → 全部静默回退解释器，白付编译费。基准实测 **44.2 s vs 解释器 6.7 s（6.6×）**。
2. **per-function 全量链接**：旧版每个热函数各编各的，N 个热函数 = N 次编译 +
   N 次把 13+ 个运行时 `.o` 全量链接（每次约 1 s+）。

### 怎么改的（`pyvm.c`，`jit_maybe_compile` → `jit_batch_compile`）

- **批量发射**：第一个函数越过热阈时，一次性发射所有用户函数（fn 0 主程序跳过）
  → 一个 `jit_batch.c` → 与 16 个运行时 `.o` 一次链接 → 一个 DLL，
  成本与函数个数无关；`rt_names` 补足 16 个（gpu/obj/wire 不再漏）。
- **编译+链接合并为一次 gcc 调用**：本机 gcc 进程启动固定约 1.2 s（杀软逐进程扫描，
  `gcc -dumpmachine` 就要 1.17 s），分两次调用就要付两次启动。合并后实测 3.5 s → 2.45 s。
- **内容寻址 DLL 缓存**：缓存键 = 生成 C 全文 + 各运行时 `.o` 身份（名/大小/mtime）
  + gcc 路径的 FNV-1a 64 位哈希，落盘 `build/.jit/cache/<hash>.dll`，
  只留最近 8 个（`jit_cache_sweep`）。同程序第二次运行**零 gcc**；
  改了运行时源码 mtime 变 → 自动换键重编，不存在陈旧 DLL。
  `PYVM_JIT_NOCACHE=1` 可强制重编。
- **内联整数快路**：生成的 C 里 `rt_add/rt_sub/rt_mul/rt_eq/rt_lt/...` 是跨 DLL 外部
  调用，循环体跑不出速度。前导加 `static inline jit_*` 快路（INT+INT 直算，
  溢出/非整数/张量/字符串一律落回 `rt_*`，语义逐字一致），热循环里不再有外部调用。

### 阈值校准（重要）

默认阈值 200 是 per-function 时代的遗产。**调用次数恰好 = 200 的程序，JIT 会在
最后一次调用才编译，原生代码一次都跑不到**（基准就这样：净亏一次编译费）。
批量架构下阈值语义变成「总闸」，按程序热度调：

| `--jit=` | 热缓存 | 冷缓存（首次） | vs 解释器 6.8~7.1 s |
|---|---|---|---|
| 200（默认） | 6.91 s | 13.6 s | 病态：编译发生在最后一次调用 |
| 64 | 3.30 s | — | 2.1× |
| 16 | 2.16 s | 3.87 s | **3.2×** |
| 8 | 1.90 s | — | **3.6×** |

（基准：6 个热叶子函数 × 200 次调用 × 100000 循环。阈值只影响第几次调用触发
总闸，不影响 DLL 内容——三种阈值共用同一份缓存条目。）

### 正确性验证

- **快路探针**（`build_tmp/jit_fastpath.pybk`）：整数/大数/浮点/字符串/混合比较/
  负数 mod / ±2^47 边界 / BIGINT 回退，解释器与 JIT 输出**逐字一致**（diff 空）。
- **溢出死亡路径**：JIT 函数内 `9223372036854775807 + 1` → 与解释器同退出码、
  同三段式报错（快路溢出落回 `rt_add` → `rt_die`，错误链完整）。
- **缓存三项**：跨程序不误命中 / 同程序复跑命中 / `touch` 运行时源码后自动换键。
- **无可 JIT 函数零开销**：`wire_tensor_vm.pybk --jit=4` 15/15，日志
  「无可 JIT 的叶子函数，纯解释器运行」，不碰 gcc。
- 回归：`pyvm_test.exe` 自测全过 · `smokeroor.py` 8/8 · `tests/run_tests.py` **124/124**。

### 顺手修的两处

- `pyvm.c` 头部自测构建注释是过时的：只列 `pyvm.c pybook_rt.c` 会 undefined
  （`_vm_lib_calls.inc` 引用全部库符号），且缺 `-march=native`（`pybook_tb.c` 的
  AVX2 微内核）。已改成完整命令。
- `pybk_build.py` 支持 `-r` 之后的 `--` 透传：`python pybk_build.py x.pybk -r -- --jit=16`。

### 踩坑（已解决）

7. **`uint64_t h` 撞名 `HMODULE h`**：批量函数里第 5 步的 LoadLibrary 句柄叫 `h`，
   哈希变量只能叫 `hk`。
8. **合并 `-shared` 后 `-fPIC` 仍要留**：一条 gcc 命令同时编译 `.c` 和链接，
   `.c` 编译侧还是需要 `-fPIC`（Windows PE 上无害，ELF 上必需）。
9. **`&&` 链里吞错误会伪装成「文件被删」**：`python pybk_build.py ... >/dev/null && ...`
   编译失败时后续 pyvm 从未运行，`$?` 报的是断点处退出码，重定向文件自然不存在——
   排查时先把错误放出来，别 `/dev/null`。

## 10. Phase G：文件头 `jit on|off [阈值]` 开关（2026-10-14，已完成）

### 为什么

v1 起 JIT 只能命令行 opt-in（`--jit`），「可用可不用」缺语言级表达。用户要求改成
程序自己声明用不用——与 `errorstopped` / `device` 同一族文件头指令。

### 怎么改的

- **`pybk_front.py`**：新保留字 `jit` + `parse_jit()`（整行扫过，模仿 `parse_device`）→
  `JitMode(on, threshold, line)` 节点，与 `MemoryMode`/`DeviceMode` 一样进 `mems`，
  自动前置到 GOING 开头。
- **`pybk_bc.py`**：`JitMode` 编译成新 opcode **`0x38 JIT [on u8][阈值 u16]`**
  （四字节布局同 `0x37 DEVICE`）；disasm 表同步。
- **`pyvm.c`**：`case_0x38` → `jit_set(on, thr)`。**为什么用语句而不是改 .pybc 头**：
  JIT 触发挂在 `CALL(0x30)` 上，主程序第一条语句执行时还没有任何调用，
  时序上永远赶得上；且不动模块格式，老 .pybc 完全兼容。
  文件头指令天然盖过启动期的 CLI/env（后落地），优先级链零额外代码。
- **优先级**：文件头 > 命令行（`--jit[=N]` / 新增 `--no-jit`）> 环境变量（`PYVM_JIT=N|off`）
  > 默认关。`g_jit_src` 记录来源备查。
- **`pybk_code.py`（C 后端）**：`JitMode` 只发一行 C 注释——JIT 是 VM 专属，C 后端无视。
- **自测构建兼容**：`g_jit_*` 全局在 `#ifndef PYVM_SELF_TEST` 里，`case_0x38` 的
  处理器体加编译期守卫（自测构建只消耗操作数、不动作），与 CALL 路径的既有模式一致。

### 验证（七场景矩阵，输出逐字一致）

| 场景 | 文件头 | 命令行 | 环境变量 | 预期 | 实测 |
|---|---|---|---|---|---|
| A | `on 8` | — | — | 开 | ✅ 2/2 上原生 |
| B | `on 8` | `--no-jit` | — | 开（头赢） | ✅ |
| C | `off` | `--jit=8` | — | 关（头赢） | ✅ 零编译 |
| D | — | `--jit=8` | — | 开 | ✅ |
| E | — | `--no-jit` | — | 关 | ✅ |
| F | — | — | `8` | 开 | ✅ |
| G | — | — | `off` | 关 | ✅ |

C 后端跑 `jit on 16` 程序 exit 0 结果一致；`jitbench --jit=16` 冷 3.91s 无回归；
`pyvm_test` 自测全过 · `smokeroor` 8/8 · `run_tests` 全绿。

### 踩坑（已解决）

10. **`JitMode` 漏 `@dataclass`**：AST 节点全靠装饰器生成 `__init__`，漏了要到运行期
    才炸（`JitMode() takes no arguments`）。补节点时装饰器和字段一起加。
11. **`g_jit_*` 在 `#ifndef PYVM_SELF_TEST` 里**：共享的解释器循环引用它们，
    自测构建直接 undefined。给 `case_0x38` 体加守卫，别把全局挪出 guard
    （CALL 路径的 JIT 钩子本来就是这么干的）。
12. **rt_names 第三例漏文件**：接替者 10-13 抽出 `pybook_la.c`（线性代数核心层，
    `la_lu` 等），mathplus.c 改调它——JIT 的运行时 `.o` 清单不加就 undefined
    （「JIT 全灭」家族病：gpu/obj/wire/la 四例了）。**清单与 build_pyvm.bat 锁定**，
    且绑定层要 `-DLA_RT_BINDING`（`pybook_la.h` 由 `PYBOOK_RT_H || LA_RT_BINDING` 开门）。

---

## 11. Phase H：CALL_LIB + 用户函数调用 原生化（2026-10-17，已完成）

### 病根

`jit_emit_fn` 的预扫里有一行一刀切：

```c
if (op == 0x30 || op == 0x36) return 0;    /* 用户函数调用 / 标准库调用 → 整个函数不编 */
```

于是 JIT 只能编「叶子函数」：**函数里只要出现一次 `mt.sqrt`、`list.添加`、`te.str`
或对另一个用户函数的调用，整个函数就永不编译**。递归、互调、数值/字符串/列表库
调用全部落空 —— 也就是绝大多数真实热循环。

### 实测：落空的代价有多大

先做隔离测（解释器口径，单次调用不触发 JIT，每项 200 万次内层循环）：

| 表达式 | ns/次 |
|---|---|
| `和 = 和 + at` | 47.5 |
| `和 = 和 + at / 1000.0` | 58.2 |
| `和 = 和 + mt.sqrt(at / 1000.0)` | **701.7** |
| `和 = 和 + mt.floor(at / 1000.0)` | **662.0** |
| `和 = 和 + mt.floor(mt.sqrt(at / 1000.0))` | **1490.4** |

而 `rt_lib_mt_sqrt` 的函数体只有三行：`lib_num` → `sqrt` → `rt_float`，
`rt_float` 还是 NaN-box 零分配。**一次 `mt.sqrt` 要 640 ns，函数体本身不到 5 ns。**

开销全在调用路径上：解释器 `case_0x36` 每次调用都要
`lib_lookup(名字, &元数)` —— 对 `_vm_lib_calls.inc` 那张 **351 项**的表做线性
`strcmp` 扫描。351 × strcmp ≈ 640 ns，数字对得上。

**所以 JIT 对 `mt.*` 一点用没有：贵的不是运算，是每次重新找函数。**

### 怎么改的

1. **CALL_LIB(0x36) → 经函数指针表间接调**
   字节码里存的是 PYbook 名字（`"mt.sqrt"`），C 函数名（`rt_lib_mt_sqrt`）只在
   `pybk_code.py` 的映射表里，`pyvm.c` 看不到；能看到的只有 `g_lib_calls` 里的
   **指针**。所以 DLL 侧留一张 `g_libp[]`，由 EXE 在 `LoadLibrary` 之后通过
   `jit_init(lib_lookup)` 按名灌进去，生成代码发一次 `((JitLibFn1)g_libp[0])(_a0)`。
   —— 既不用把绝对地址烤进生成代码（ASLR 下每进程都不同），也不用按名字线性扫
   （扫出来和解释器一样快，等于白 JIT）。
2. **CALL(0x30) → 同 DLL 内直调 `jit_<fni>`**
   批量发射本来就把所有函数拼进同一个 `.c`，被调的函数加前向声明即可；
   递归就是调自己。
3. **可编性求不动点**
   「这个函数能不能编」现在依赖「它调的函数能不能编」：按「不含调用」求基，
   反复剔除「调了还在解释器上的函数」，直到不动点。调用图无环时一趟到位；
   递归/互调也在不动点里自洽 —— 要么整组可编、要么整组剔除，不会只编一半
   （半吊子状态比全不解还难查）。**主程序 fn 0 与跨回解释器的调用仍然排除。**
4. **递归护栏 `JIT_ENTER` / `JRET`**
   解释器的帧开在堆上，JIT 的帧开在 C 栈上。原生递归深到爆栈拿到的是段错误，
   不是可读报错。生成代码里每进一层 `jit_depth++`，超 2000 层给三段式报错；
   原来所有 `return` 改成 `JRET`（先 `jit_depth--` 再返回）。

### 实测（CPU 空闲，200 次外层调用 × 50000 次内层循环 = 1000 万次，已扣进程启动基线）

| 场景 | 解释器 | Phase H 前 JIT | Phase H 后 JIT | vs 解释器 |
|---|---|---|---|---|
| 纯整数循环（本来就编得了） | 0.346 s | 0.043 s | 0.047 s | 7.36× |
| `mt.floor(mt.sqrt(...))` 累加 | 11.522 s | 13.590 s | **0.601 s** | **19.16×** |
| 内层调用户函数 | 1.585 s | 0.758 s | **0.234 s** | **6.78×** |
| 列表构建 | 0.393 s | 0.090 s | 0.109 s | 3.61× |

`mt.*` 那一行就是 Phase H 的全部价值：**13.590 s → 0.601 s（22.6×）**。
四个场景的 stdout 全部逐字一致。

### 正确性验证：`tests/jit_correctness.py`

同一个 `.pybc` 分别用解释器和 `--jit=4` 跑，**stdout / stderr / 退出码三项全等**
才算通过。**20/20 通过**：

- 算术快路 / 浮点 / 整数边界（负数 mod、±2^47）/ 字符串 / 列表 / 字典
- `mt.*`（sqrt/floor/abs/clamp）、`te.*`（upper/str）、`list.*`（sorted/max/count）
- 用户函数：简单调用 / 递归阶乘 / **fibonacci 递归** / **奇偶互调** / 混合全用
- **错误路径 4 条**：下标越界、除以零、`mt.sqrt` 收到字符串、以及**错误发生在
  被 JIT 化的子函数里** —— stderr 三段式与退出码和解释器一致
- 递归护栏（只跑 JIT 侧，见下）：`rc=1` + `运行时错误: JIT 原生递归太深（超过 2000 层）`

两个设计上的坑，记在这里免得下一个人再踩：

- **错误必须推迟到函数已经"热"了才发生**。热计数挂在 `CALL` 上，若第一次迭代就报错，
  函数永远到不了阈值 → 根本不会上原生 → 「两边一致」只是因为两边都在解释器上跑，
  等于没测到原生路径。用例里用外层轮号把失败推迟到第 11 轮。
- **脚本会断言「真的编上了」**（stderr 里有 `批量发射`）。JIT 编译失败是**静默回退**
  （设计上「JIT 永不破坏正确性」），不盯着这条就会把「静默没生效」读成「一致通过」。

### 踩坑（已解决）

13. **生成文本里的 `JitLibFn0..8` typedef 一开始只写在 pyvm.c 侧**，没发射进
    生成的 `.c` → gcc 报 `JitLibFn1 undeclared` → JIT 静默回退解释器 →
    基准显示「JIT 没加速」。**凡是生成代码要用的东西，要么在 prelude 里发出去，
    要么在两边都定义**；`JIT_MAXLIB` 就先踩了同样的坑（只定义了 pyvm.c 侧）。
14. **`jit_op_nops(0x30/0x36/0x37/0x38) == 3`**，而操作数解码原来只有
    `nops >= 2`（u16）、`nops == 1`（u8）——**nops==3 的那个 u8 一直没解出来**。
    改成 `nops == 1 || nops == 3` 时取 `code[p + nops - 1]`。
15. **基准口径被进程启动噪声淹没**：30 ms 的总耗时里 13 ms 是启动，测出来 JIT
    「慢 5 倍」。改成 1000 万次内层迭代 + 扣空程序启动基线 + 3 次取中位数，
    才看见真实的 7~19 倍。**小工作量的 JIT 基准一律测不出东西。**
16. **`err_deep_recursion` 这类用例在解释器侧跑不完**：解释器的帧在堆上，无限递归
    一路吃到 OOM，和 JIT 的段错误没法对照。这类用例只能只跑 JIT 侧（`JIT_ONLY`）。

### 仍然不做（留给后续）

- ~~**主程序 fn 0 仍不上原生**~~ —— 第三轮已做，见 §12。现在是「入口静态估算 +
  整段原生」，仍然不是 OSR。
- **门限是估的，不是量的**。静态扫不出 `while` 的真实轮数（按 1000 轮估）、
  也看不出条件分支的实际走向，所以「估算不足 2000 万条但实际很重」的程序仍会漏。
  真要根治得上 OSR（跑到一半再换栈），或者在解释器里攒够执行次数再回头重跑。
- **跨回解释器的调用**：JIT 函数调一个不可编的函数，仍整体判不可编。没做
  VM 回调桥（`vm_call_by_index`）。
- **模块级全局跨边界共享**：仍然是「函数读不到全局变量」这条既有设计兜着，
  不需要额外处理。
- **错误链 per-copy**：JIT 的 DLL 里有自己的一份 `pybook_rt.o`，其
  `g_err_top` 与 EXE 的不是同一份。好在 VM 后端**不编译 `onerror` / `try`**
  （`pybk_bc.py` 对二者是编译期拒绝），所以跑在 pyvm 上的程序根本没有错误恢复
  语义可以对齐，`rt_die` 在两侧都是 `exit(1)`。**一旦哪天 VM 后端支持了
  onerror/try，这条会立刻变成语义分叉**，届时必须让两侧共享错误链状态。


## 12. 第三轮：默认阈值下调 + fn 0（主程序）上原生

### 12.1 病根

两件事，一件是「阈值选错了」，一件是「有个洞根本没人管」。

**阈值 200 是病态值。** 它是 per-function 时代的遗产：那时候每个热函数各编各的，
阈值是「这个函数被调用多少次才值得单独为它开一次 gcc」。批量架构（一次 gcc 编出
整个模块的 DLL）落地之后，阈值语义变成了「总闸」——可它还留在 200，于是：

- 恰好被调用 200 次的程序，在**第 200 次调用发生的那一刻**才触发编译，
  原生代码一次都没跑着（§9 的实测：`jit on 200` ≈ 1.0×）。
- 就算侥幸编上了，前面 199 次解释执行的开销一分没省。

§9 当时就标了「阈值校准（重要）」并给了实测：`on 8` ≈ 3.6×、`on 16` ≈ 3.2×、
`on 64` ≈ 2.1×。这一轮把它落下去：**`g_jit_threshold` 由 200 改成 16**。

**fn 0 是个没人管的洞。** JIT 的触发点是 `CALL` 里的 `callee->hot++`，而主程序
（函数 0）**永不被 CALL**——它是被 `run_module` 直接调一次的。于是最常见的写法：

```python
GOING:{
    rm.around(20000000) { vg.和 = 和 + at }   # 一整个程序的重活都在这儿
    ns.show(和)
}STOP
```

无论 `--jit` 与否，都是纯解释器。这就是「一个函数只被调用一次、内部循环很大」
加速为零的原因，也是 §10 里「仍然不做」列的第一条。

### 12.2 做法：入口静态估算 + 整段原生

**不 OSR，也不需要。** 决策点固定在主程序入口——此刻它一条指令都还没执行，
槽位数组刚 `malloc` 出来、全是 `rt_none()`，不存在「解释器帧和原生栈各改了一半」
的问题。`run_module` 在把 `f0` 压进帧栈**之前**问一句 jit：

```c
    jit_entry(&m);
    if (m.fns[0].jit_ptr) {
        Value rv = ((JitFn)m.fns[0].jit_ptr)(f0.slots, 0);
        (void)rv; free(f0.slots); vm_finish(); return;
    }
```

槽位布局与解释器完全一致（生成代码的 `S[i]` 就是 `f0.slots[i]`），所以整个主程序
从入口一路跑到 `JRET`，中间没有一次状态搬运。

配套的三处改动：

1. **`jit_batch_compile` 的四个循环从 `fni = 1` 改成 `fni = 0`**（fn 0 进发射集）。
   但 `jit_scan_fn` / `jit_callees_ok` / `jit_emit_fn` 里那句
   `if (tf == 0 || tf >= m->nfns) return 0;` **必须留着**——主程序不是合法调用目标。
2. **发射器补上 0x37 DEVICE / 0x38 JIT 两条旋钮**。原来 `switch` 的 `default:`
   直接 `return 0`，于是**任何带文件头旋钮的主程序都编不了**（而旋钮恰恰是
   `jit on` 的载体）。0x37 发成 `rt_device_set(backend, threads)`，0x38 发成空操作
   （EXE 侧预读时已经 `jit_set` 过了；注意这两条的布局是 `[op][u8][u16]`，
   与通用的「u16 在前、u8 在后」解码相反，要单独取）。
3. **文件头 `jit` 旋钮在入口预读**。决策必须先于任何解释执行，而旋钮本该在主程序
   第一条语句执行，所以按字节码开头连续的旋钮指令（0x38/0x37/0x35）预扫一遍。
   旋钮书写顺序是自由的（`device cpu 4` 写在 `jit on` 前面很常见），只认首指令会漏。

### 12.3 门限：静态估算指令量，不是数字节

第一版门限写的是「主程序代码区 ≥ 160 字节」，实测当场翻车：

| 程序 | 代码区 | 循环次数 | 结果 |
|---|---|---|---|
| m0 | 170 字节 | 20 万 | 预编译 |
| m1 | **120 字节** | **2000 万** | **不预编译** ← 正好是本轮要治的那个洞 |

按字节数判是个伪相关：真正决定值不值的是「这个程序大概要执行多少条指令」。
换成一次扫描的估算：

```
总量 = 直线段指令数 + Σ(循环体指令数 × 轮数)
```

轮数能算就算：`rm.around(N)` 编译出来是 `CONST N` 紧跟 `AROUND_INIT`，
往前看三条字节就是那个字面量，于是循环次数是编译期常量。读不出来
（`while` / `for x in 表` / 次数来自变量）就按 1000 轮保守估。

门限 `JIT_MAIN_MIN_INSN = 20000000`：解释器约 15ns/条，2000 万条 ≈ 0.3s，
正好抵平一次**热缓存**编译（冷缓存 2.5s）。判错的代价只是「多编一次」或「少赚一次」，
不会算错——正确性由 `tests/jit_main.py` 逐字比对兜底。

`PYVM_JIT_VERBOSE=1` 打印判定过程：

```
[JIT] 主程序预判：估算 48000055 条指令（循环 48000000 轮）/ 门限 20000000，预编译
[JIT] fn 0 (main) -> 原生
```

### 12.4 退出时的挂起行

解释器在主程序 RET 时走 `vm_finish()`，会把「开了行但没换行」的尾巴刷出去
（`g_line_pending`）。原生路径没有解释器帧，所以生成代码里加了一个 DLL 级
`g_lp` 标志：SHOW 类指令置位、SHOW_END 清零，**只有 fn 0 的返回**用
`JMAINRET` 在退出前补刷（普通函数返回不该刷，解释器也不刷）。

实测下来 `pybk_bc.py` 编译出来的 `ns.show` 一定带 SHOW_END，所以这条目前是
**结构性等价**而不是热点路径上的补丁——但留着它比「碰巧一致」踏实。

### 12.5 实测（CPU 空闲，3 次取中位数，扣 16ms 进程启动基线）

主程序场景（都是「只调用一次、重活在主程序里」）：

| 场景 | 解释器 | JIT | 加速 | 输出一致 |
|---|---|---|---|---|
| m1 纯整数 2000 万次循环 | 2.32~2.38 s | 0.37~0.49 s | **4.9×~6.3×** | 是（md5 相同） |
| m2 300 万次循环 × 4 个 `mt.*` | 6.50~6.86 s | 0.089~0.090 s | **72×~76×** | 是（md5 相同） |
| m0 20 万次循环（估算不足门限） | 0.022~0.026 s | 0.019~0.021 s | 1.06×~1.41× | 是 —— 正确地留在解释器 |

两轮独立复测，m1 的 JIT 侧在 0.37~0.49 s 之间抖（解释器侧很稳），所以给区间不给单点。
m0 的「加速」在噪声量级——它压根没被编译，这就是门限在起作用。

m2 那 72× 就是 Phase H 的 `g_libp` 间接调用在主程序里生效：解释器每次
`CALL_LIB` 都要对 351 项的表做线性 `strcmp` 扫描（约 640ns），原生里是一次
间接调用。

### 12.6 正确性

- **`tests/jit_main.py`（新建）13/13**：13 个完整程序，比 stdout / stderr / 退出码三项全等。
  覆盖纯整数循环、`mt.*` 密集、列表、字典、分支、调用户函数、调递归函数、
  循环内报错、主程序末尾报错、`device` 旋钮、文件头 `jit on`、文件头 `jit off`
  盖过 `--jit`、门限负例。
- **`tests/jit_correctness.py` 20/20**（Phase H 那套，不受影响）。
- **A/B 42 个真实 `.pybk`**：① 不传 `--jit`，与本轮改动前的 exe 逐字一致；
  ② 同一个 exe 传 `--jit`，与解释器侧逐字一致。两项全过。

### 12.7 两个自己踩的坑

- **`0x37`/`0x38` 之前是 `default: return 0`。** 发射器的 `switch` 覆盖到 0x35 就断了，
  于是带文件头旋钮的主程序一律编不了。旋钮恰恰是 `jit on` 的载体，等于「开了 JIT
  的主程序反而不该上原生」——最该测的那条路恰好被这条静默 `return 0` 掐断。
  发射器少覆盖一个 opcode 的代价，是一整类程序的 JIT 静默失效。
- **测试断言自己写松了。** 第一版 `tests/jit_main.py` 只断言 stderr 里有
  `fn 0 -> 原生`，结果 `main_calls_fn` 这种「主程序估算不足、但它调的函数很热、
  顺带把 fn 0 也编了」的用例也过了——**主程序其实一直在解释器上跑**。
  「编出了指针」≠「真的跑了原生」。现在改成两个条件同时成立：
  预判结果是「预编译」**且**有 `fn 0 -> 原生`。这条比 Phase H 那次 typedef 静默
  回退更难发现：那次至少速度对不上，这次输出完全一致、只是没加速。
