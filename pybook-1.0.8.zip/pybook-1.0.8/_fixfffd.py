# -*- coding: utf-8 -*-
"""_fixfffd.py — 修掉 U+FFFD 坏字符。

根因：这几个脚本当初落盘时，有一个汉字在 GBK/UTF-8 边界上被写坏了（U+FFFD）。
不修源头的话，每次重放都会把坏字符重新写进 C 文件。

用**字节级**替换，避开「字面量在写文件时被吞」这个坑。"""
import io

BAD = b'\xef\xbf\xbd'
B3 = BAD * 3          # 一个汉字的 3 个 UTF-8 字节被逐字节替换 -> 3 个 U+FFFD

# (文件, 坏字节串上下文, 修好的字节串)
FIXES = [
    ('_calc_c.py',      'lambda」的'.encode() + B3 + '批用户'.encode(),
                       'lambda」的这一批用户'.encode()),
    ('pybook_lib.c',    'lambda」的'.encode() + B3 + '批用户'.encode(),
                       'lambda」的这一批用户'.encode()),
    ('_wire_stats.py',  '最小的那'.encode() + B3, '最小的那个'.encode()),
    ('mathplus.c',      '最小的那'.encode() + B3, '最小的那个'.encode()),
    ('_mt_verify.py',   '算出来'.encode() + B3 + '比'.encode(),
                       '算出来对比'.encode()),
]

for path, old, new in FIXES:
    raw = open(path, 'rb').read()
    n = raw.count(old)
    if n == 0:
        print('  %-16s 不用改（没匹配上）' % path)
        continue
    raw = raw.replace(old, new)
    open(path, 'wb').write(raw)
    left = raw.count(BAD)
    print('  %-16s 改了 %d 处，剩余 U+FFFD %d 个' % (path, n, left))

print()
print('复查：')
import glob
bad_total = 0
for p in sorted(glob.glob('_*.py')) + ['pybook_lib.c', 'pybook_lib.h', 'mathplus.c',
                                        'pybk_front.py', 'pybk_code.py',
                                        '_vm_lib_calls.inc']:
    n = open(p, 'rb').read().count(BAD)
    if n:
        print('  ★ %-20s 还有 %d 处' % (p, n))
        bad_total += n
print('  干净' if bad_total == 0 else '  仍有 %d 处' % bad_total)
