# -*- coding: utf-8 -*-
"""_audit2.py — 只读对账：四张表声明的入口里，哪些在源码里没有实现。
不改任何项目文件（只读源码 + 打印）。"""
import io
import os
import re
import glob

SRC = []
for pat in ('pybook_*.c', 'mathplus.c', 'pyvm.c'):
    SRC += [p for p in glob.glob(pat)
            if '发布打包' not in p and '_session_backup' not in p]
SRC = sorted(set(SRC))

# 把所有 .c 里定义（函数体开头）的符号抓出来
defined = set()
for p in SRC:
    t = io.open(p, encoding='utf-8', errors='replace').read()
    # 形如  Value rt_lib_xxx(...)  /  static double lib_xxx(...) 后跟 {
    for m in re.finditer(r'^(?:static\s+)?(?:Value|double|int|long long|char\s*\*|float)\s+'
                         r'\**(\w+)\s*\([^;{]*\)\s*\{', t, re.M):
        defined.add(m.group(1))

inc = io.open('_vm_lib_calls.inc', encoding='utf-8', newline='').read()
rows = re.findall(r'^\s*\{"([^"]+)",\s*\d+,\s*\(void\s*\*\)(\w+)\}', inc, re.M)

print('对账范围：仓库根的 %d 个 .c（不含 _session_backup / 发布打包_102）' % len(SRC))
print('_vm_lib_calls.inc 的分发表共 %d 条' % len(rows))
print()

missing = [(n, c) for n, c in rows if c not in defined]
present = [(n, c) for n, c in rows if c in defined]

print('=== 有实现：%d 条 ===' % len(present))
print('=== ★ 声明了但源码里没有实现：%d 条 ===' % len(missing))
print()
byp = {}
for n, c in missing:
    p = n.split('.')[0]
    byp.setdefault(p, []).append(n)
for p in sorted(byp):
    print('  %s 前缀 %d 个：%s' % (p, len(byp[p]), '  '.join(byp[p])))
print()
if missing:
    print('逐条：')
    for n, c in missing:
        print('  %-22s -> %s' % (n, c))
