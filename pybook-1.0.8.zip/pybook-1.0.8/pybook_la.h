#ifndef PYBOOK_LA_H
#define PYBOOK_LA_H

/* =============================================================================
 * [1] 线性代数核心层（纯 double*，行主序，0 基下标）
 *
 * 设计约束：
 *   - 不依赖 PYbook 运行时（不碰 Value / RtTensor / 打印 / 退出），
 *     这样能用 _lacheck.c 独立编译，对着 NumPy 逐项对拍。
 *   - 失败一律用返回码表达，错误文案在绑定层拼 —— 核心层不 printf、不 exit。
 *   - 全部 0 基下标、全部行主序。LAPACK 是 1 基 + 列主序，照抄会错得很难看，
 *     所以这里不照抄 LAPACK 的内存布局，只借它的算法。
 *
 * 反复出现的两个约定：
 *   - LU：部分主元（Doolittle）。lu 的严格下三角存乘子，上三角存 U，对角是 U 的对角。
 *     piv[k] = 第 k 步换到第 k 行的行号。解方程时必须**按 k 顺序**把 piv 应用到右端，
 *     这是 LAPACK 的 ipiv 语义，顺序反了就全错。
 *   - QR：Householder 反射。tau[k] == 0 表示第 k 步退化（那一列已经是 e_k 方向）。
 *     Q = H_0 H_1 ... H_{p-1}，A = Q R。
 * ========================================================================== */

#ifdef __cplusplus
extern "C" {
#endif

/* ---------- LU（部分主元） ---------- */

/* A: n*n 行主序，只读。lu: n*n 行主序，输出。piv: n 个 int，输出。
 * 返回 1 成功；返回 0 表示 A 奇异（某个主元恰为 0），此时 lu/piv 内容未定义。
 * 只判「恰为 0」是有意的：近奇异不是分解失败，那是 rank / cond 的事。 */
int  la_lu(const double *a, double *lu, int *piv, int n);

/* 从 LU 因子取行列式（含换行符号）。传入 la_lu 成功时的产物。 */
double la_lu_det(const double *lu, const int *piv, int n);

/* 解 L*U*x = P*b。b: n*nrhs 行主序（每行一个右端向量），就地覆写。
 * 返回 1 成功；0 表示 lu 不是合法 LU 因子。 */
int  la_lu_solve(const double *lu, const int *piv, double *b, int n, int nrhs);

/* 从 LU 因子求逆。out: n*n 行主序。返回 1 成功，0 奇异。 */
int  la_lu_inv(const double *lu, const int *piv, double *out, int n);

/* ---------- QR（Householder） ---------- */

/* A: m*n 行主序。r: m*n 行主序（上三角有效）。v: m*p（p=min(m,n)）行主序，
 * v[k..m-1] 是第 k 个反射的单位向量。tau: p 个。返回 p。
 * m >= n 与 m < n 都能用：R 是 m*n 上梯形。 */
int  la_qr(const double *a, double *r, double *v, double *tau, int m, int n);

/* 由反射向量还原 Q。q: m*m 行主序，q = H_0 H_1 ... H_{p-1}。
 * 调用前 q 必须先被填成单位阵。 */
void la_qr_form_q(const double *v, const double *tau, double *q, int m, int p);

/* ---------- Cholesky ---------- */

/* A 必须对称正定。A: n*n 行主序。L: n*n 行主序（存下三角，对角取正根）。
 * 返回 1 成功；返回 0 表示 A 不对称或不是正定（逐元素校验，不假设调用方给对称阵）。
 * 这是刻意保守：宁可报错，也不要用不成立的分解算出一个看着正常的数。 */
int  la_cholesky(const double *a, double *l, int n);

/* ---------- 对称矩阵特征值/特征向量（循环 Jacobi） ---------- */

/* A: n*n 行主序，必须对称（不对称会返回 0）。vals: n，升序输出。
 * vecs: n*n 行主序，**第 k 列**是 vals[k] 对应的特征向量。
 * 返回 1 成功；0 表示 A 不对称。 */
int  la_eig_sym(const double *a, double *vals, double *vecs, int n, int maxsweeps);

/* ---------- 最小二乘 ---------- */

/* min ||Ax - b||。a: m*n 行主序，b: m，x: n。
 * 走 SVD：数值最准，且欠定（m<n，给 min-norm 解）与秩亏（自动截断）是同一段代码。
 * 返回数值秩；返回 0 表示分配失败。 */
int  la_lstsq(const double *a, const double *b, double *x, int m, int n);

/* ---------- 奇异值分解（单边 Jacobi） ---------- */

/* A: m*n 行主序。U: m*min(m,n)。S: min(m,n)，降序。
 * Vt: n*min(m,n) 行主序，是 V 的转置（跟 LAPACK 约定一致，省得调用方再转一次）。
 * 返回 1 成功。 */
int  la_svd(const double *a, double *u, double *s, double *vt, int m, int n,
            int maxsweeps);

/* ---------- 一般实矩阵：实 Schur 分解 ---------- */

/* A: n*n 行主序（只读）。t: n*n 行主序，输出实 Schur 形式（上准三角：
 * 1×1 块是实特征值，2×2 块装一对共轭复特征值）。q: n*n 行主序，输出正交阵，
 * 使 A ≈ q·t·qᵀ。内部是「平衡 + Hessenberg 化 + 隐式 Francis 双移位 QR」。
 * maxits 是 QR 迭代步数上限。返回 1 成功，0 表示不收敛/内存不足。 */
int  la_schur(const double *a, double *t, double *q, int n, int maxits);

/* 从实 Schur 形式读特征值。wre/wim: n 个。实特征值虚部为 0；共轭复数对相邻排列
 * （前一个虚部为正）。判块靠超对角线是否非零——la_schur 收 2×2 块时两个实特征值
 * 会把超对角线显式清零，所以留着的 2×2 块一定是真复数对。 */
void la_schur_eigvals(const double *t, double *wre, double *wim, int n);

/* ---------- 数值秩 ---------- */

/* 用 LU + 相对容差判秩。tol <= 0 时用 n * eps * max|a_ij|。 */
int  la_rank(const double *a, int n, double tol);

/* =============================================================================
 * [2] 绑定层：仅当已包含 pybook_rt.h（即 PYBOOK_RT_H 已定义）或定义了
 *     LA_RT_BINDING 时声明/编译。
 *
 * 两个面共用上面同一份核心实现：
 *   tb.* —— 直接吃真张量，返回真张量/标量。
 *   mp.* —— 吃「扁平列表 + 行列数」（与 numpy 的 flatten 一致），内部先用
 *           la_from_flat() 包成张量再算，所以两边结果必然一致。
 * 精度传播沿用 tb.dot 的规矩：任一输入是 f32 就返回 f32，内部一律按 double
 * 算完再 rt_tensor_round 舍入。
 *
 * 为什么这些原型必须放在头文件里：C 后端编译用户程序时只靠头文件链认识
 * 符号（pybk_code.py 生成 out_*.c，链是 pybook_lib.h -> 本文件）。只在
 * _vm_lib_calls.inc 里写前置声明只服务 VM 后端，C 后端会报 implicit declaration。
 * ========================================================================== */
#if defined(PYBOOK_RT_H) || defined(LA_RT_BINDING)

/* ---- tb.* 张量面 ---- */
Value rt_lib_tb_lu(Value A);          /* tb.lu(A)          -> [L, piv]        */
Value rt_lib_tb_solve(Value A, Value B);/* tb.solve(A,B)     -> x（B 可 1-D/2-D）*/
Value rt_lib_tb_det(Value A);          /* tb.det(A)         -> 标量           */
Value rt_lib_tb_logdet(Value A);       /* tb.logdet(A)      -> 标量           */
Value rt_lib_tb_inv(Value A);          /* tb.inv(A)         -> A⁻¹            */
Value rt_lib_tb_cond(Value A);         /* tb.cond(A)        -> 1-范数条件数   */
Value rt_lib_tb_rank(Value A);         /* tb.rank(A)        -> 数值秩         */
Value rt_lib_tb_qr(Value A);           /* tb.qr(A)          -> [Q, R]         */
Value rt_lib_tb_lstsq(Value A, Value b);/* tb.lstsq(A,b)     -> min‖Ax-b‖ 解   */
Value rt_lib_tb_cholesky(Value A);     /* tb.cholesky(A)    -> L（A=L·Lᵀ）   */
Value rt_lib_tb_eig_sym(Value A);      /* tb.eig_sym(A)     -> [vals升序, V] */
Value rt_lib_tb_svd(Value A);          /* tb.svd(A)         -> [U, S, VT]    */

/* ---- mp.* 扁平列表面（内部包成张量再算） ---- */
Value rt_lib_mp_mat_lu(Value a, Value nv);       /* mp.mat_lu(a, n)          -> [L, piv]  */
Value rt_lib_mp_mat_solve(Value a, Value b, Value nv); /* mp.mat_solve(a, b, n) -> x      */
Value rt_lib_mp_mat_qr(Value a, Value rv, Value cv); /* mp.mat_qr(a, r, c)    -> [Q, R]   */
Value rt_lib_mp_mat_svd(Value a, Value rv, Value cv);/* mp.mat_svd(a, r, c) -> [U,S,VT]（第三项就是 VT，与 tb.svd 同约定）*/
Value rt_lib_mp_mat_eig_sym(Value a, Value nv);  /* mp.mat_eig_sym(a, n)     -> [vals, V] */
Value rt_lib_mp_mat_cholesky(Value a, Value nv); /* mp.mat_cholesky(a, n)    -> L         */
Value rt_lib_mp_mat_ls(Value a, Value b, Value mv, Value nv); /* mp.mat_ls    -> x         */
Value rt_lib_mp_mat_rank(Value a, Value nv);     /* mp.mat_rank(a, n)         -> 秩        */
Value rt_lib_mp_mat_cond(Value a, Value nv);     /* mp.mat_cond(a, n)         -> 条件数    */
Value rt_lib_mp_mat_logdet(Value a, Value nv);   /* mp.mat_logdet(a, n)       -> 标量      */
Value rt_lib_mp_to_tensor(Value a, Value rv, Value cv); /* mp.to_tensor(a,r,c) -> 张量 */

#endif /* PYBOOK_RT_H */

/* 互转是双向通的，不必再加反向函数：扁平列表 → 张量用 mp.to_tensor，
 * 张量 → 嵌套列表用运行时现成的 rt_tensor_to_list（pybook_rt.h:184）。 */

#ifdef __cplusplus
}
#endif
#endif /* PYBOOK_LA_H */