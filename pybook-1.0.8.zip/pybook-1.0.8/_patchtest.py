# -*- coding: utf-8 -*-
"""_patchtest.py —— 在**生成的** _cpubench_core.inc 上试候选修法，验证它真的能治。

只动 .inc（生成物），**不碰 pybook_tb.c 生产源码**：修不修由用户拍板，
这里只负责让「这个改法有效」这句话有实测支撑，而不是眼看代码觉得对。

被改的地方：pybook_tb.c 的「末余量 <4 列：标量收尾」里，
    double base/b1/b2/b3 = init ? 0 : O[...];
这四行在 p 循环体内。init==1 时 base 恒为 0，于是每一轮 p 都是覆盖写，
这个 kc 块只剩最后一个 p 的乘积。改成直接读 O[...] 即可：
调用方保证 init==1 时 O 刚清零，第一次读到的就是 0，之后读到的是已累计值。

改完立刻核对：4 处列尾巴 + 1 处行尾巴，共 5 处必须全部变成「直接读 O」。
少一处就退出报错，绝不放过半改状态。
"""
import io
import re
import shutil
import sys

SRC = "_cpubench_core.inc"
BAK = "_cpubench_core.inc.orig"
PAT = re.compile(r"(double\s+(?:base|b1|b2|b3)\s*=\s*)init \? 0 : (O\[)")

# 先还原到未改状态，保证脚本可重复执行
shutil.copyfile(BAK, SRC)
with io.open(SRC, "r", encoding="utf-8", newline="") as f:
    text = f.read()
crlf = "\r\n" in text
text = text.replace("\r\n", "\n")

n_before = len(PAT.findall(text))
if n_before != 5:
    sys.exit("锚点异常：找到 %d 处 `init ? 0 : O[`（应为 5 处）—— "
             "生产微内核结构变了，先看代码再改这个脚本" % n_before)

text2 = PAT.sub(r"\1\2", text)
n_after = len(re.findall(r"init \? 0 : O\[", text2))
if n_after != 0:
    sys.exit("还有 %d 处没改干净，拒绝写盘" % n_after)

if crlf:
    text2 = text2.replace("\n", "\r\n")
with io.open(SRC, "w", encoding="utf-8", newline="") as f:
    f.write(text2)

print("已改 %d 处（4 处列尾巴 base/b1/b2/b3 + 1 处行尾巴 base）" % n_before)
for ln in text2.replace("\r\n", "\n").split("\n"):
    if "double base =" in ln or "double b1 =" in ln or "double b2 =" in ln or "double b3 =" in ln:
        print("   ", ln.strip())
