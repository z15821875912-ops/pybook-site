﻿/* _jitlog.c —— PTX 编译通过/失败检查器（逐特性二分用）。
 *
 * 本来还想用它取驱动的 JIT 编译日志（cuModuleLoadDataEx + CUjit_options），
 * 但这台机器上（驱动 582.53 / CUDA 13）驱动拒绝一切非 NULL 的 options：
 *   全零结构体、bit0 max_registers、bit3|bit4 info_log、bit5|bit6 error_log，
 *   以及 error_log 放在 reserved[4] 前 / 后两种布局，全部回 "invalid argument"；
 * 只有 options=NULL 才被接受。机器上也没有 ptxas.exe 可用。
 * 所以拿不到「哪一行错了」这种日志，只能退回二分法：
 * 一次加一个特性，看从哪个开始编不过。二分几次就能定位到具体指令。
 *
 * 规则（踩过的坑）：先用一份肯定能编译的 PTX 来验工具本身，
 * 不然驱动回 "invalid argument" 时分不清是 options 写错还是 PTX 真坏。
 *
 * 用法：
 *     _jitlog.exe <ptx文件> [<ptx文件> ...]
 * 退出码：0 = 全部通过；1 = 有文件没编过；2 = 用法错
 *
 * 编译：
 *     C:\Users\zhuli\mingw64\bin\x86_64-w64-mingw32-gcc.exe _jitlog.c -o _jitlog.exe -O2
 */
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef int          CUresult;
typedef int          CUdevice;
typedef void        *CUcontext;
typedef void        *CUmodule;

static HMODULE g_dll;
static CUresult (*p_cuInit)(unsigned);
static CUresult (*p_cuDeviceGet)(CUdevice *, int);
static CUresult (*p_cuDevicePrimaryCtxRetain)(CUcontext *, CUdevice);
static CUresult (*p_cuCtxSetCurrent)(CUcontext);
static CUresult (*p_cuModuleLoadDataEx)(CUmodule *, const void *, void *);
static CUresult (*p_cuGetErrorString)(CUresult, const char **);

static const char *cu_err(CUresult r)
{
    const char *s = NULL;
    if (p_cuGetErrorString && p_cuGetErrorString(r, &s) == 0 && s) return s;
    return "未知 CUDA 错误";
}

static char g_ptx[1 << 20];
static CUcontext g_ctx;

static int try_one(const char *path)
{
    FILE *f;
    size_t n;
    CUmodule mod = NULL;
    CUresult r;

    f = fopen(path, "rb");
    if (!f) { printf("  [失败] %-22s 打不开\n", path); return 1; }
    n = fread(g_ptx, 1, sizeof(g_ptx) - 1, f);
    fclose(f);
    g_ptx[n] = '\0';

    /* options 传 NULL —— 这是这个驱动唯一认的写法，见文件头说明。 */
    r = p_cuModuleLoadDataEx(&mod, g_ptx, NULL);
    if (r == 0) {
        printf("  [通过] %-22s %zu 字节\n", path, n);
        return 0;
    }
    printf("  [失败] %-22s %s\n", path, cu_err(r));
    return 1;
}

int main(int argc, char **argv)
{
    int i, bad = 0;
    CUdevice dev;
    void *p;

    SetConsoleOutputCP(65001);
    if (argc < 2) { printf("用法：_jitlog.exe <ptx文件> [...]\n"); return 2; }

    g_dll = LoadLibraryA("nvcuda.dll");
    if (!g_dll) { printf("找不到 nvcuda.dll\n"); return 1; }
#define LOAD(nm, fn) do { p = (void *)GetProcAddress(g_dll, nm); \
    if (!p) { printf("缺 %s\n", nm); return 1; } memcpy(&(fn), &p, sizeof(fn)); } while (0)
    LOAD("cuInit", p_cuInit);
    LOAD("cuDeviceGet", p_cuDeviceGet);
    LOAD("cuDevicePrimaryCtxRetain", p_cuDevicePrimaryCtxRetain);
    LOAD("cuCtxSetCurrent", p_cuCtxSetCurrent);
    LOAD("cuModuleLoadDataEx", p_cuModuleLoadDataEx);
    LOAD("cuGetErrorString", p_cuGetErrorString);

    if (p_cuInit(0) != 0) { printf("cuInit 失败\n"); return 1; }
    if (p_cuDeviceGet(&dev, 0) != 0) { printf("cuDeviceGet 失败\n"); return 1; }
    if (p_cuDevicePrimaryCtxRetain(&g_ctx, dev) != 0) { printf("取主上下文失败\n"); return 1; }
    /* retain 只是拿住，不置为当前。忘了这一句会得到 "invalid device context"，
     * 看起来像 PTX 有问题，其实是工具自己的锅。 */
    if (p_cuCtxSetCurrent(g_ctx) != 0) { printf("置当前上下文失败\n"); return 1; }

    for (i = 1; i < argc; i++) bad |= try_one(argv[i]);
    printf("\n结论：%d 个文件里 %d 个没编过\n", argc - 1, bad);
    return bad;
}
