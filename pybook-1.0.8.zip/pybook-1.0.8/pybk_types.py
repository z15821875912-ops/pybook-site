# -*- coding: utf-8 -*-
"""
PYbook 软类型检查（可选类型注解，只警告、不阻塞编译）

设计边界（梯子不是房子）：
- 类型注解完全可选；没写注解的地方一律按「任意」处理，绝不报错。
- 只做「字面量 + 注解」级别的轻量推断，不做跨函数的全程序流分析。
- 推断不出类型（未知）直接跳过，绝不大惊小怪。
- 所有发现都作为「软类型警告」字符串返回；调用方决定展示方式，
  软类型检查永远不令编译失败（与硬语义错误区分开）。

用法：
    import pybk_types
    warns = pybk_types.soft_type_check(program)   # program 是 pybk_front.parse 的产物
"""

# 注解拼写 → 规范 kind（首层名；带参数的 列表(数字) 只取外层「列表」做比较）
_TYPE_ALIASES = {
    '数字': '数字', 'num': '数字', 'number': '数字', 'int': '数字', 'float': '数字',
    '字符串': '字符串', 'str': '字符串', 'string': '字符串',
    '布尔': '布尔', 'bool': '布尔',
    '列表': '列表', 'list': '列表',
    '字典': '字典', 'dict': '字典',
    '张量': '张量', 'tensor': '张量',
    '任意': '任意', 'any': '任意', '无': '任意',
    '空': '空', 'void': '空', 'none': '空',
}


def _kind_of(typestr):
    """把注解拼写归一成 kind；未知类型名（如自定义类名）保留原名作为「类类型」。"""
    if not typestr:
        return None
    base = typestr.split('(')[0].strip().lower()
    return _TYPE_ALIASES.get(base, base)


def _type_eq(declared, inferred):
    """声明类型 vs 推断类型 是否相容：任一为 任意 / 未知(None) 即相容。"""
    if declared is None or inferred is None:
        return True
    if declared == '任意' or inferred == '任意':
        return True
    return declared == inferred


def _disp(kind):
    return kind if kind else '未知类型'


def infer(expr, env):
    """对表达式做极简类型推断，返回 kind 或 None（未知）。

    env: 变量名 → kind（来自参数注解与局部 vg 注解）。"""
    if expr is None:
        return None
    t = type(expr).__name__
    if t == 'NumLit':
        return '数字'
    if t == 'StrLit':
        return '字符串'
    if t == 'BoolLit':
        return '布尔'
    if t == 'ListLit':
        return '列表'
    if t in ('DictLit', 'DictComp'):
        return '字典'
    if t == 'VarRef':
        return env.get(expr.name)
    if t == 'CtorExpr':
        return _kind_of(expr.class_name) if expr.class_name else None
    if t == 'BinOp':
        if expr.op == '**':
            return '张量'
        if expr.op in ('+', '-', '*', '/', '%', '//'):
            return '数字'
        if expr.op in ('==', '!=', '<', '>', '<=', '>='):
            return '布尔'
        return None
    if t == 'Unary':
        return '数字' if expr.op == '-' else '布尔'   # not
    if t == 'Ternary':
        return infer(expr.then, env)
    # Call / Index / Slice / Member / MethodCall 等：v1 不推断
    return None


def soft_type_check(program):
    """扫描整个 program，返回软类型警告字符串列表（每条含行号）。"""
    warns = []

    # 收集所有可调用：顶层函数 + 类方法/静态方法（方法名按方法名建表，v1 简化）
    funcs = {}
    for f in (program.fns or []):
        funcs[f.name] = (f.param_types or {}, f.return_type, f.params)
    for cls in (program.classes or []):
        for m in (getattr(cls, 'methods', None) or []):
            funcs[m.name] = (m.param_types or {}, m.return_type, m.params)
        for m in (getattr(cls, 'static_methods', None) or []):
            funcs[m.name] = (m.param_types or {}, m.return_type, m.params)

    # 函数 / 方法体
    for f in (program.fns or []):
        _check_fn(f, funcs, warns)
    for cls in (program.classes or []):
        for m in (getattr(cls, 'methods', None) or []):
            _check_fn(m, funcs, warns)
        for m in (getattr(cls, 'static_methods', None) or []):
            _check_fn(m, funcs, warns)

    # GOING 主块（顶层语句，无返回类型注解）
    go_env = {}
    for s in (program.go_body or []):
        if type(s).__name__ == 'VgAssign' and getattr(s, 'type_annot', None):
            go_env[s.name] = _kind_of(s.type_annot)
    _check_block(program.go_body or [], go_env, funcs, None, warns)
    return warns


def _check_fn(f, funcs, warns):
    param_types = f.param_types or {}
    return_type = f.return_type
    env = {}
    for p in f.params:
        env[p] = _kind_of(param_types.get(p))
    # 收集函数体内局部 vg.名:类型=... 的注解（仅函数直接语句层）
    for stmt in f.body:
        if type(stmt).__name__ == 'VgAssign' and getattr(stmt, 'type_annot', None):
            env[stmt.name] = _kind_of(stmt.type_annot)
    _check_block(f.body, env, funcs, return_type, warns)


def _check_block(stmts, env, funcs, return_type, warns):
    for stmt in stmts:
        _check_stmt(stmt, env, funcs, return_type, warns)


def _walk_calls(expr, env, funcs, warns):
    """递归走表达式，找到所有 Call 节点并核对其实参类型（含实参里嵌套的调用）。"""
    if expr is None:
        return
    t = type(expr).__name__
    if t == 'Call':
        fn = funcs.get(expr.name)
        if fn:
            pmap, _, params = fn
            for i, arg in enumerate(expr.args):
                if i >= len(params):
                    break
                decl_raw = pmap.get(params[i])
                decl = _kind_of(decl_raw)
                if decl is None:
                    continue
                inf = infer(arg, env)
                if not _type_eq(decl, inf):
                    warns.append("第 %d 行：软类型警告：调用 %s 的第 %d 个参数期望 %s，实际得到 %s"
                                 % (expr.line, expr.name, i + 1, decl_raw, _disp(inf)))
        for arg in expr.args:          # 递归检查实参里嵌套的调用
            _walk_calls(arg, env, funcs, warns)
    elif t == 'BinOp':
        _walk_calls(expr.left, env, funcs, warns)
        _walk_calls(expr.right, env, funcs, warns)
    elif t == 'Unary':
        _walk_calls(expr.operand, env, funcs, warns)
    elif t == 'Ternary':
        _walk_calls(expr.then, env, funcs, warns)
        _walk_calls(expr.els, env, funcs, warns)


def _check_stmt(stmt, env, funcs, return_type, warns):
    t = type(stmt).__name__
    if t == 'VgAssign':
        if getattr(stmt, 'type_annot', None):
            decl = _kind_of(stmt.type_annot)
            inf = infer(stmt.expr, env)
            if not _type_eq(decl, inf):
                warns.append("第 %d 行：软类型警告：变量 %s 声明为 %s，但赋值得到 %s"
                             % (stmt.line, stmt.name, stmt.type_annot, _disp(inf)))
        _walk_calls(stmt.expr, env, funcs, warns)   # 无论有无注解，都核对 RHS 里的调用实参
    elif t == 'Ret':
        if return_type is not None:
            decl = _kind_of(return_type)
            inf = infer(stmt.expr, env)
            if not _type_eq(decl, inf):
                warns.append("第 %d 行：软类型警告：函数返回声明为 %s，但 ret 得到 %s"
                             % (stmt.line, return_type, _disp(inf)))
        _walk_calls(stmt.expr, env, funcs, warns)
    elif t == 'Call':
        _walk_calls(stmt, env, funcs, warns)
    # v1 不做语句内嵌块（if/for/try 等）的深度遍历


# ============================================================
# errorstopped hard 模式：复杂度 / 风险闸门
# 纯结构指标 + 具体风险写法（用户原话："看到复杂度后你就等挂吧"）
# 仅 hard 模式调用；normal/simple 不跑（normal=pybook 原样，simple=最快最自由）
# ============================================================

_HARD_MAX_NEST = 4        # 块嵌套深度（func 体算第 0 层，每多一层 +1）
_HARD_MAX_PARAMS = 8      # 函数参数个数上限
_HARD_MAX_STMTS = 60      # 单函数语句数上限（含所有嵌套层）
_HARD_MAX_CYCLOMATIC = 10 # 圈复杂度上限（分支点 + 表达式 and/or/?: 数量）


def _blocks(stmt):
    """返回 stmt 内直接子块（用于嵌套深度与语句数递归）。"""
    t = type(stmt).__name__
    if t == 'VcChain':                        # if/elif/else：arms = [(cond, body), ...]
        return [b for (_, b) in stmt.arms]
    if t in ('CdBlock', 'Aging', 'Around', 'ForIn', 'Lambda', 'FnDef', 'MacroDef'):
        return [stmt.body]
    if t == 'TryCatch':
        return [stmt.body, stmt.handler]
    if t == 'OnError':                        # body 恒为 []，handler 是兜底块
        return [stmt.body, stmt.handler]
    return []


def _branch_count(stmt):
    """stmt 引入的分支数（圈复杂度累加项）。"""
    t = type(stmt).__name__
    if t == 'VcChain':
        return len(stmt.arms)
    if t in ('CdBlock', 'Aging', 'Around', 'ForIn', 'TryCatch', 'OnError'):
        return 1
    return 0


def _expr_cyclo(e):
    if e is None:
        return 0
    t = type(e).__name__
    if t == 'BinOp':
        if e.op in ('and', 'or'):
            return 1 + _expr_cyclo(e.left) + _expr_cyclo(e.right)
        return _expr_cyclo(e.left) + _expr_cyclo(e.right)
    if t == 'Ternary':
        return 1 + _expr_cyclo(e.then) + _expr_cyclo(e.els)
    if t in ('Call', 'MethodCall'):
        return sum(_expr_cyclo(a) for a in (e.args or []))
    return 0


def _stmt_expr_cyclo(stmt):
    t = type(stmt).__name__
    if t == 'VgAssign':
        return _expr_cyclo(stmt.expr)
    if t == 'Ret':
        return _expr_cyclo(stmt.expr)
    if t == 'Call':
        return _expr_cyclo(stmt)
    return 0


def _metrics(stmts, depth=0):
    """递归所有子块，返回 (max_nest, total_stmts, cyclomatic)。"""
    max_nest = depth
    total = 0
    cyc = 0
    for s in stmts:
        total += 1
        cyc += _branch_count(s)
        cyc += _stmt_expr_cyclo(s)
        for b in _blocks(s):
            nest, t, c = _metrics(b, depth + 1)
            max_nest = max(max_nest, nest)
            total += t
            cyc += c
    return max_nest, total, cyc


def _expr_calls(e, names):
    """收集表达式里出现的所有 Call/MethodCall 名字。"""
    if e is None:
        return
    t = type(e).__name__
    if t in ('Call', 'MethodCall'):
        names.add(getattr(e, 'name', None))
        for a in (e.args or []):
            _expr_calls(a, names)
    elif t == 'BinOp':
        _expr_calls(e.left, names)
        _expr_calls(e.right, names)
    elif t == 'Unary':
        _expr_calls(e.operand, names)
    elif t == 'Ternary':
        _expr_calls(e.then, names)
        _expr_calls(e.els, names)


def _recurses(stmts, name):
    """检测裸递归：函数体内出现名为 name 的调用（语句级或表达式内）。"""
    for s in stmts:
        t = type(s).__name__
        if t == 'Call' and getattr(s, 'name', None) == name:
            return True
        if t in ('VgAssign', 'Ret', 'IpAssign', 'MultiAssign'):
            names = set()
            if t == 'MultiAssign':
                for v in (getattr(s, 'values', None) or []):
                    _expr_calls(v, names)
            else:
                _expr_calls(getattr(s, 'expr', None), names)
            if name in names:
                return True
        for b in _blocks(s):
            if _recurses(b, name):
                return True
    return False


def _hard_fn(f, errs, label):
    """对单个函数/方法做 hard 闸门检查，错误累积进 errs。"""
    p = f.params or []
    if len(p) > _HARD_MAX_PARAMS:
        errs.append("第 %d 行：errorstopped hard 拦截：%s %s 参数过多（%d > %d）"
                    % (f.line, label, f.name, len(p), _HARD_MAX_PARAMS))
    nest, total, cyc = _metrics(f.body or [], 0)
    if nest > _HARD_MAX_NEST:
        errs.append("第 %d 行：errorstopped hard 拦截：%s %s 嵌套过深（%d > %d）"
                    % (f.line, label, f.name, nest, _HARD_MAX_NEST))
    if total > _HARD_MAX_STMTS:
        errs.append("第 %d 行：errorstopped hard 拦截：%s %s 过长（%d > %d 条语句）"
                    % (f.line, label, f.name, total, _HARD_MAX_STMTS))
    if cyc > _HARD_MAX_CYCLOMATIC:
        errs.append("第 %d 行：errorstopped hard 拦截：%s %s 圈复杂度过高（%d > %d）"
                    % (f.line, label, f.name, cyc, _HARD_MAX_CYCLOMATIC))
    if _recurses(f.body or [], f.name):
        errs.append("第 %d 行：errorstopped hard 拦截：%s %s 含裸递归（hard 模式禁递归，请改用循环或尾调用封装）"
                    % (f.line, label, f.name))


def hard_checks(program):
    """errorstopped hard 模式总入口：返回错误字符串列表（每条带行号）。
    遍历 顶层函数 + 类方法 + 类静态方法。"""
    errs = []
    allow = set(getattr(program, 'hard_allow', None) or [])
    for f in (program.fns or []):
        if f.name in allow:          # hard 豁免：名单内函数跳过全部闸门
            continue
        _hard_fn(f, errs, '函数')
    for cls in (program.classes or []):
        for m in (getattr(cls, 'methods', None) or []):
            if m.name not in allow:
                _hard_fn(m, errs, '方法')
        for m in (getattr(cls, 'static_methods', None) or []):
            if m.name not in allow:
                _hard_fn(m, errs, '静态方法')
    return errs
