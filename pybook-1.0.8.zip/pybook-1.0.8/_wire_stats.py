# -*- coding: utf-8 -*-
"""_wire_stats.py — 修随机子系统三个实测缺陷 + 补 8 个分布与 8 个统计

三个缺陷都是实测坐实的：
  1. rd.float() 20 万次采样只有 32693 个不同取值、最大只到 0.999969482421875
     —— 根因是只调一次 rand()，而 MinGW 的 RAND_MAX 就是 32767（15 位而非 53 位）。
  2. rd.* 无法播种（rd_seed() 只在首次调用时 srand(time)），写不出可复现的随机测试。
  3. rd.* 走 C rand()、mp.rand_* 走 mathplus.c 的 xorshift128 —— 两个互不相干的源，
     mp.rand_seed(42) 对 rd.int 毫无影响（实测确认）。

修法：rd.* 全部委托 mathplus.c 的 xorshift128（mp_rand_*）。那是核心层的无条件纯 C，
     统一源的同时保住 mathplus.c 的可独立编译性。
既有 rd.int/float/pick/shuffle 的参数、范围、语义一律不动，只换随机源。
统计核心层一律纯 double*（不碰 Value），否则会破坏 mathplus.c 的分层约定。
"""
import io

M_2PI = 6.2831853071795864769252867665590057683943387987502
M_2SQRTPI = 1.1283791670955125738961589031215451716881012586580

EOL = {}


def eol_of(p):
    if p not in EOL:
        t = io.open(p, encoding='utf-8', newline='').read()
        EOL[p] = '\r\n' if '\r\n' in t else '\n'
    return EOL[p]


def rd(p):
    return io.open(p, encoding='utf-8', newline='').read()


def wr(p, t):
    io.open(p, 'w', encoding='utf-8', newline='').write(t)


def put_at(p, pos, block):
    e = eol_of(p)
    wr(p, rd(p)[:pos] + block.replace('\n', e) + rd(p)[pos:])


def insert_after(p, anchor, block, tag):
    t = rd(p)
    if tag in t:
        print('  %s: 已有 %s，跳过' % (p, tag))
        return
    # 锚点也要按本文件的行尾归一。mathplus.c 是纯 CRLF，而锚点字面量写的是 \n，
    # 不归一就 t.index() 直接 ValueError（第一次重放就栽在这）。
    e = eol_of(p)
    a = anchor.replace('\n', e)
    if a not in t:
        if anchor not in t:
            raise SystemExit('%s: 锚点找不到\n%r' % (p, anchor))
        a = anchor
    put_at(p, t.index(a) + len(a), block)


def insert_before_marker(p, marker, block, tag):
    """插到 [2] 绑定层 那个注释块的 /* ==== 起始处之前（保证落在核心层作用域里）。"""
    t = rd(p)
    if tag in t:
        print('  %s: 已有 %s，跳过' % (p, tag))
        return
    i = t.index(marker)
    start = t.rindex('/* =', 0, i)
    put_at(p, start, block)
    print('  %s: 核心层已插入 %s' % (p, tag))


# ============================================================ 核心层：分布
DIST_C = r'''
/* ---------- 常见分布补齐（全部与 mp.rand_* 共用同一个 xorshift128）----------
 * 参数非法一律返回 -1 / -1.0 作哨兵：这些分布的取值域都 >= 0，
 * 所以 -1 不可能与合法结果撞上，由绑定层翻译成带三段式的报错。
 * 核心层不 printf 不 exit —— 保住 mathplus.c 的可独立编译性。 */

/* 标准正态：Box-Muller。u1 取不到 0（log(0) = -inf 会毁掉结果） */
static double mp_std_normal(void)
{
    double u1, u2;
    do { u1 = mp_rand_u01(); } while (u1 <= 0.0);
    u2 = mp_rand_u01();
    return sqrt(-2.0 * log(u1)) * cos(%.15g * u2);
}

double mp_rand_exponential(double rate)
{
    double u;
    if (!(rate > 0.0)) return -1.0;
    do { u = mp_rand_u01(); } while (u <= 0.0);
    return -log(u) / rate;
}

/* 泊松：λ<30 用 Knuth（小 λ 时这个才准），λ>=30 走正态近似 */
double mp_rand_poisson(double lam)
{
    double L, p;
    long long k = 0;
    if (lam < 0.0) return -1.0;
    if (lam < 30.0) {
        L = exp(-lam);
        p = 1.0;
        do {
            p *= mp_rand_u01();
            k++;
        } while (p > L && k < 100000000LL);
        return (double)(k - 1);
    }
    {
        double v = lam + sqrt(lam) * mp_std_normal();
        return v < 0.0 ? 0.0 : v;
    }
}

/* 几何：成功概率 p，返回首次成功所需的试验次数（>=1） */
int mp_rand_geom(double p)
{
    double u;
    if (!(p > 0.0 && p <= 1.0)) return -1;
    do { u = mp_rand_u01(); } while (u <= 0.0);
    return (int)(log(u) / log(1.0 - p)) + 1;
}

/* 二项 B(n,p)：n<40 逐次 Bernoulli（精确），否则正态近似并截断到 [0,n] */
double mp_rand_binom(int n, double p)
{
    long long i, k = 0;
    double mean, sd, v;
    if (n < 0 || p < 0.0 || p > 1.0) return -1.0;
    if (n < 40) {
        for (i = 0; i < n; i++)
            if (mp_rand_u01() < p) k++;
        return (double)k;
    }
    mean = n * p;
    sd = sqrt((double)n * p * (1.0 - p));
    if (sd <= 0.0) return mean;
    v = mean + sd * mp_std_normal();
    if (v < 0.0) v = 0.0;
    if (v > (double)n) v = (double)n;
    return v;
}

/* Gamma(k, θ)：Marsaglia-Tsang 压缩拒绝法；k<1 先用 k+1 抽样再取幂（Boost 变换） */
double mp_rand_gamma(double shape, double scale)
{
    double d, c, x, v, u, z;
    if (!(shape > 0.0) || !(scale > 0.0)) return -1.0;
    if (shape < 1.0) {
        double g = mp_rand_gamma(shape + 1.0, 1.0);
        double w;
        if (g < 0.0) return -1.0;          /* 递归里参数非法 */
        do { w = mp_rand_u01(); } while (w <= 0.0);
        return g * pow(w, 1.0 / shape) * scale;
    }
    d = shape - 1.0 / 3.0;
    c = 1.0 / sqrt(9.0 * d);
    for (;;) {
        z = mp_std_normal();
        x = d + z * z * sqrt(d);
        if (x <= 0.0) continue;
        v = 1.0 + z / c;
        if (v <= 0.0) continue;
        v = v * v * v;
        u = mp_rand_u01();
        if (u < 1.0 - 0.0331 * z * z * z * z) return d * v * scale;
        if (log(u) < 0.5 * z * z + d * (1.0 - v + log(v))) return d * v * scale;
    }
}

/* Beta(a,b)：Johnk 拒绝法 */
double mp_rand_beta(double a, double b)
{
    double x, y, s, u;
    if (!(a > 0.0) || !(b > 0.0)) return -1.0;
    for (;;) {
        x = pow(mp_rand_u01(), 1.0 / a);
        y = pow(mp_rand_u01(), 1.0 / b);
        s = x + y;
        if (s <= 0.0) continue;
        u = mp_rand_u01();
        if (u * s * s * s <= x * x * y) return x / s;
    }
}

/* 对数正态：ln X ~ N(mu, sigma^2) */
double mp_rand_lognormal(double mu, double sigma)
{
    if (sigma < 0.0) return -1.0;
    return exp(mu + sigma * mp_std_normal());
}

/* Logistic：位置 mu、尺度 s */
double mp_rand_logistic(double mu, double s)
{
    double u;
    if (!(s > 0.0)) return -1.0;
    do { u = mp_rand_u01(); } while (u <= 0.0);
    return mu + s * log(u / (1.0 - u));
}
''' % (M_2PI,)

# ============================================================ 核心层：统计
STAT_C = r'''
/* ---------- 统计补齐（此前只有 mean/var/std/minmax/sum）----------
 * 一律纯 double*、就地排序副本，不碰 Value —— 与本文件核心层的分层约定一致。
 * 输入非法时返回 NAN，由绑定层翻译成报错。 */

/* 插入排序：n 通常几百到几千，O(n^2) 的常数比 qsort 小得多，
   也不必考虑 qsort 比较函数里拿不到上下文的问题 */
static void st_sort_d(double *a, int n)
{
    int i, j;
    for (i = 1; i < n; i++) {
        double key = a[i];
        for (j = i - 1; j >= 0 && a[j] > key; j--)
            a[j + 1] = a[j];
        a[j + 1] = key;
    }
}

/* 返回一份升序副本（调用方 free）；n<1 返回 NULL */
static double *st_sorted(const double *a, int n)
{
    double *s;
    if (n < 1) return NULL;
    s = (double *)malloc((size_t)n * sizeof(double));
    if (!s) return NULL;
    memcpy(s, a, (size_t)n * sizeof(double));
    st_sort_d(s, n);
    return s;
}

/* 中位数。偶数个取中间两个的平均（与 numpy 一致） */
double mp_median(const double *a, int n)
{
    double *s = st_sorted(a, n), m;
    if (!s) return NAN;
    m = (n % 2) ? s[n / 2] : (s[n / 2 - 1] + s[n / 2]) / 2.0;
    free(s);
    return m;
}

/* 众数。并列时返回最小的那个 —— 保证结果确定，不依赖排序实现的稳定性 */
double mp_mode(const double *a, int n)
{
    double *s = st_sorted(a, n), best = 0.0;
    int i, bestn = 0;
    if (!s) return NAN;
    for (i = 0; i < n; ) {
        int j = i;
        while (j + 1 < n && s[j + 1] == s[i]) j++;
        if (j - i + 1 > bestn) {
            bestn = j - i + 1;
            best = s[i];
        }
        i = j + 1;
    }
    free(s);
    return best;
}

/* 分位数，线性插值法，与 numpy.percentile 的默认 linear 一致。
   q ∈ [0,1]；q<0 或 >1 返回 NAN */
double mp_quantile(const double *a, int n, double q)
{
    double *s, idx, frac;
    int pos;
    if (!(q >= 0.0 && q <= 1.0)) return NAN;
    s = st_sorted(a, n);
    if (!s) return NAN;
    idx = q * (double)(n - 1);
    pos = (int)idx;
    frac = idx - (double)pos;
    frac = (pos + 1 < n) ? s[pos] + frac * (s[pos + 1] - s[pos]) : s[n - 1];
    free(s);
    return frac;
}

/* 样本协方差（分母 n-1，与 numpy.cov 默认一致）。n<2 返回 NAN */
double mp_cov(const double *x, const double *y, int n)
{
    double mx = 0.0, my = 0.0, s = 0.0;
    int i;
    if (n < 2) return NAN;
    for (i = 0; i < n; i++) mx += x[i];
    for (i = 0; i < n; i++) my += y[i];
    mx /= (double)n;
    my /= (double)n;
    for (i = 0; i < n; i++) s += (x[i] - mx) * (y[i] - my);
    return s / (double)(n - 1);
}

/* 皮尔逊相关系数 = cov / (std_x * std_y)。
   某一边是常数时分母为 0，此时相关系数无定义，返回 NAN 让调用方报错，
   静默给 0 会让人以为「不相关」而其实是「没定义」 */
double mp_corr(const double *x, const double *y, int n)
{
    double mx = 0.0, my = 0.0, sxy = 0.0, sxx = 0.0, syy = 0.0, den;
    int i;
    if (n < 2) return NAN;
    for (i = 0; i < n; i++) mx += x[i];
    for (i = 0; i < n; i++) my += y[i];
    mx /= (double)n;
    my /= (double)n;
    for (i = 0; i < n; i++) {
        double dx = x[i] - mx, dy = y[i] - my;
        sxy += dx * dy;
        sxx += dx * dx;
        syy += dy * dy;
    }
    den = sqrt(sxx * syy);
    if (den <= 0.0) return NAN;
    return sxy / den;
}

/* 前缀和：out 需 n 个 */
void mp_cumsum(const double *a, int n, double *out)
{
    double s = 0.0;
    int i;
    for (i = 0; i < n; i++) {
        s += a[i];
        out[i] = s;
    }
}

/* 逐差分：out 需 n-1 个（n<2 时什么都不写） */
void mp_diff(const double *a, int n, double *out)
{
    int i;
    for (i = 1; i < n; i++) out[i - 1] = a[i] - a[i - 1];
}
'''

# ============================================================ 绑定层
MP_BIND_C = r'''
/* ---------------- 分布与统计的绑定层 ---------------- */

/* 核心层用 -1 / NAN 作哨兵表示参数非法，这里统一翻译成报错。
   这些分布取值域都 >= 0，-1 不可能与合法结果撞车。 */
static void dist_die(const char *who, const char *need)
{
    rt_die("%s 的参数不合法：要求 %s\n"
           "  为什么：参数越界的分布没有定义，硬算只会得到垃圾数\n"
           "  怎么改：按上面这个要求检查参数再传进来", who, need);
}

Value rt_lib_mp_rand_exponential(Value rate)
{
    double r = mp_rand_exponential(mp_num(rate, "mp.rand_exponential 的 λ"));
    if (r < 0.0) dist_die("mp.rand_exponential", "λ > 0");
    return rt_float(r);
}

Value rt_lib_mp_rand_poisson(Value lambda)
{
    double r = mp_rand_poisson(mp_num(lambda, "mp.rand_poisson 的 λ"));
    if (r < 0.0) dist_die("mp.rand_poisson", "λ >= 0");
    return rt_float(r);
}

Value rt_lib_mp_rand_geom(Value pv)
{
    int k = mp_rand_geom(mp_num(pv, "mp.rand_geom 的 p"));
    if (k < 0) dist_die("mp.rand_geom", "0 < p <= 1");
    return rt_int(k);
}

Value rt_lib_mp_rand_binom(Value nv, Value pv)
{
    long long n = mp_ll(nv, "mp.rand_binom 的 n");
    double p = mp_num(pv, "mp.rand_binom 的 p");
    double r;
    if (n < 0 || n > 1000000000LL)
        rt_die("mp.rand_binom 的 n 要在 [0, 1e9]，收到 %lld\n"
               "  为什么：n 是试验次数，必须是非负且可枚举的整数\n"
               "  怎么改：把 n 调小；n 很大时走正态近似更合适", n);
    r = mp_rand_binom((int)n, p);
    if (r < 0.0) dist_die("mp.rand_binom", "n >= 0 且 0 <= p <= 1");
    return rt_float(r);
}

Value rt_lib_mp_rand_gamma(Value kv, Value thv)
{
    double r = mp_rand_gamma(mp_num(kv, "mp.rand_gamma 的形状"),
                             mp_num(thv, "mp.rand_gamma 的尺度"));
    if (r < 0.0) dist_die("mp.rand_gamma", "形状 > 0 且尺度 > 0");
    return rt_float(r);
}

Value rt_lib_mp_rand_beta(Value av, Value bv)
{
    double r = mp_rand_beta(mp_num(av, "mp.rand_beta 的 a"),
                            mp_num(bv, "mp.rand_beta 的 b"));
    if (r < 0.0) dist_die("mp.rand_beta", "a > 0 且 b > 0");
    return rt_float(r);
}

Value rt_lib_mp_rand_lognormal(Value muv, Value sv)
{
    double s = mp_num(sv, "mp.rand_lognormal 的 sigma");
    double r;
    if (s < 0.0) dist_die("mp.rand_lognormal", "sigma >= 0");
    r = mp_rand_lognormal(mp_num(muv, "mp.rand_lognormal 的 mu"), s);
    return rt_float(r);
}

Value rt_lib_mp_rand_logistic(Value muv, Value sv)
{
    double r = mp_rand_logistic(mp_num(muv, "mp.rand_logistic 的 mu"),
                                mp_num(sv, "mp.rand_logistic 的 s"));
    if (r < 0.0 && mp_num(sv, "mp.rand_logistic 的 s") > 0.0) dist_die("mp.rand_logistic", "尺度 s > 0");
    return rt_float(r);
}

/* ---- 统计 ---- */

/* 解包成 double* 并顺带检查元素全是数字；调用方 free */
static double *stat_unpack(Value v, long long *n, const char *who)
{
    return mp_unpack(v, n, who);
}

Value rt_lib_mp_median(Value listv)
{
    long long n;
    double *a = stat_unpack(listv, &n, "mp.median");
    double r;
    if (n < 1) mp_die("mp.median：空列表");
    r = mp_median(a, (int)n);
    free(a);
    return rt_float(r);
}

Value rt_lib_mp_mode(Value listv)
{
    long long n;
    double *a = stat_unpack(listv, &n, "mp.mode");
    double r;
    if (n < 1) mp_die("mp.mode：空列表");
    r = mp_mode(a, (int)n);
    free(a);
    return rt_float(r);
}

Value rt_lib_mp_quantile(Value listv, Value qv)
{
    long long n;
    double q = mp_num(qv, "mp.quantile 的 q");
    double *a = stat_unpack(listv, &n, "mp.quantile");
    double r;
    if (!(q >= 0.0 && q <= 1.0)) {
        free(a);
        mp_die("mp.quantile 的 q 要在 [0,1]，收到 %g", q);
    }
    if (n < 1) { free(a); mp_die("mp.quantile：空列表"); }
    r = mp_quantile(a, (int)n, q);
    free(a);
    return rt_float(r);
}

Value rt_lib_mp_percentile(Value listv, Value pv)
{
    double p = mp_num(pv, "mp.percentile 的 p");
    return rt_lib_mp_quantile(listv, rt_float(p / 100.0));
}

Value rt_lib_mp_cov(Value xv, Value yv)
{
    long long nx, ny;
    double *x = mp_unpack(xv, &nx, "mp.cov 的 x");
    double *y = mp_unpack(yv, &ny, "mp.cov 的 y");
    double r;
    if (nx != ny) {
        free(x); free(y);
        mp_die("mp.cov：两个列表长度要相同（%lld 与 %lld）", nx, ny);
    }
    if (nx < 2) { free(x); free(y); mp_die("mp.cov：至少要 2 个样本"); }
    r = mp_cov(x, y, (int)nx);
    free(x); free(y);
    return rt_float(r);
}

Value rt_lib_mp_corr(Value xv, Value yv)
{
    long long nx, ny;
    double *x = mp_unpack(xv, &nx, "mp.corr 的 x");
    double *y = mp_unpack(yv, &ny, "mp.corr 的 y");
    double r;
    if (nx != ny) {
        free(x); free(y);
        mp_die("mp.corr：两个列表长度要相同（%lld 与 %lld）", nx, ny);
    }
    if (nx < 2) { free(x); free(y); mp_die("mp.corr：至少要 2 个样本"); }
    r = mp_corr(x, y, (int)nx);
    free(x); free(y);
    if (isnan(r))
        mp_die("mp.corr：某个变量是常数，相关系数无定义\n"
               "  为什么：标准差为 0 时分母为 0，不是「不相关」而是「没定义」\n"
               "  怎么改：先检查两个列表里有没有全员相同的");
    return rt_float(r);
}

Value rt_lib_mp_cumsum(Value listv)
{
    long long i, n;
    double *a = mp_unpack(listv, &n, "mp.cumsum");
    double *out = (double *)malloc((size_t)(n > 0 ? n : 1) * sizeof(double));
    Value r;
    if (!out) { free(a); mp_die("math+ 内存不足"); }
    mp_cumsum(a, (int)n, out);
    r = rt_list_new();
    for (i = 0; i < n; i++) rt_push(&r, rt_float(out[i]));
    free(a); free(out);
    return r;
}

Value rt_lib_mp_diff(Value listv)
{
    long long i, n;
    double *a = mp_unpack(listv, &n, "mp.diff");
    double *out = (double *)malloc((size_t)(n > 0 ? n : 1) * sizeof(double));
    Value r;
    if (!out) { free(a); mp_die("math+ 内存不足"); }
    mp_diff(a, (int)n, out);
    r = rt_list_new();
    for (i = 1; i < n; i++) rt_push(&r, rt_float(out[i - 1]));
    free(a); free(out);
    return r;
}
'''

MP_H_CORE = r"""
/* ---- 常见分布（与 mp.rand_* 同一个 xorshift128；参数非法返回 -1/-1.0 哨兵）---- */
double mp_rand_exponential(double rate);   /* 指数，λ>0 */
double mp_rand_poisson(double lambda);     /* 泊松，λ>=0 */
int    mp_rand_geom(double p);             /* 几何，p∈(0,1]，返回试验次数>=1 */
double mp_rand_binom(int n, double p);     /* 二项 B(n,p) */
double mp_rand_gamma(double shape, double scale);
double mp_rand_beta(double a, double b);
double mp_rand_lognormal(double mu, double sigma);
double mp_rand_logistic(double mu, double s);
"""

MP_H_STAT = r"""
/* ---- 统计补齐（纯 double*；输入非法返回 NAN）---- */
double mp_median(const double *a, int n);
double mp_mode(const double *a, int n);
double mp_quantile(const double *a, int n, double q);   /* q∈[0,1] */
double mp_cov(const double *x, const double *y, int n); /* 样本协方差 */
double mp_corr(const double *x, const double *y, int n);/* 皮尔逊相关 */
void   mp_cumsum(const double *a, int n, double *out);
void   mp_diff(const double *a, int n, double *out);
"""

MP_H_BIND = r"""
/* ---- 分布 ---- */
Value rt_lib_mp_rand_exponential(Value rate);
Value rt_lib_mp_rand_poisson(Value lambda);
Value rt_lib_mp_rand_geom(Value p);
Value rt_lib_mp_rand_binom(Value n, Value p);
Value rt_lib_mp_rand_gamma(Value k, Value th);
Value rt_lib_mp_rand_beta(Value a, Value b);
Value rt_lib_mp_rand_lognormal(Value mu, Value s);
Value rt_lib_mp_rand_logistic(Value mu, Value s);

/* ---- 统计 ---- */
Value rt_lib_mp_median(Value listv);
Value rt_lib_mp_mode(Value listv);
Value rt_lib_mp_quantile(Value listv, Value q);
Value rt_lib_mp_percentile(Value listv, Value p);
Value rt_lib_mp_cov(Value x, Value y);
Value rt_lib_mp_corr(Value x, Value y);
Value rt_lib_mp_cumsum(Value listv);
Value rt_lib_mp_diff(Value listv);
"""

MARK = '* [2] 绑定层'

print('== mathplus.c ==')
insert_before_marker('mathplus.c', MARK, DIST_C + STAT_C, 'mp_median')
insert_after('mathplus.c',
             '#if defined(PYBOOK_RT_H) || defined(MP_RT_BINDING)\n',
             MP_BIND_C, 'dist_die')

print('== mathplus.h ==')
insert_after('mathplus.h', 'double mp_rand_normal(double mean, double sd); /* Box-Muller */',
             MP_H_CORE, 'mp_rand_exponential')
insert_after('mathplus.h', 'double mp_median(const double *a, int n);',
             '', 'mp_median') if False else None
# 统计核心原型接在分布核心原型之后
insert_after('mathplus.h', 'double mp_rand_logistic(double mu, double s);',
             MP_H_STAT, 'double mp_median(')
insert_after('mathplus.h', 'Value rt_lib_mp_rand_normal(Value m, Value sd); /* mp.rand_normal(m,sd) */',
             MP_H_BIND, 'rt_lib_mp_median')

print('完成')
