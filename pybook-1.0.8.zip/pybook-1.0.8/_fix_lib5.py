# -*- coding: utf-8 -*-
"""_fix_lib5.py — polyfit 的求解器从「正规方程 + 高斯消元」换成「列平衡 + Householder QR」

为什么必须换（实测，不是推测）：
    正规方程解的是 VᵀV·c = Vᵀy，而 cond(VᵀV) = cond(V)²，高次时直接塌。
    实测 deg=6 还对（与 numpy 差 1.4e-13），deg=8 就给出 c₁=0.6 / c₂=0.08 /
    c₃=−0.008 —— 正好是真值的 2/4/8 倍，拟合曲线的残差比 numpy 差 56%。
    也就是说入口文档里写的「次数 0~12」是骗人的：8 就已经不能用。

QR + 列平衡把条件数拿回来。列平衡不是可选项：mx 的各次幂列的 2-范数差好几个
数量级（mx^6 与 mx^0），不先归一 QR 也没用。

lib_gauss 随之删掉（只有 polyfit 用它，留着会触发 -Wall 的 unused 告警）。
"""
import io
import sys

P = 'pybook_lib.c'
t = io.open(P, encoding='utf-8', newline='').read()


def sub(tag, old, new):
    global t
    for eol in ('\r\n', '\n'):
        o, n = old.replace('\n', eol), new.replace('\n', eol)
        c = t.count(o)
        if c == 1:
            t = t.replace(o, n, 1)
            print('  [OK] %s（行尾 %s）' % (tag, 'CRLF' if eol == '\r\n' else 'LF'))
            return
        if c > 1:
            sys.exit('%s：子串出现 %d 次，不唯一' % (tag, c))
    sys.exit('%s：子串找不到' % tag)


# ---- 1. 拿 lib_gauss 换成 lib_lstsq（QR） ----
sub('1 高斯消元 -> 列平衡 + Householder QR',
    """/* 高斯消元（带部分主元），就地解 A·x = b，A 是 m×m 行主序 */
static int lib_gauss(double *a, double *b, int m, double *x)
{
    int    i, j, k;
    double t;
    for (k = 0; k < m; k++) {
        int    piv = k;
        double best = fabs(a[(size_t)k * m + k]);
        for (i = k + 1; i < m; i++) {
            t = fabs(a[(size_t)i * m + k]);
            if (t > best) { best = t; piv = i; }
        }
        if (best < 1e-300) return 0;
        if (piv != k) {
            for (j = 0; j < m; j++) {
                t = a[(size_t)k * m + j];
                a[(size_t)k * m + j] = a[(size_t)piv * m + j];
                a[(size_t)piv * m + j] = t;
            }
            t = b[k]; b[k] = b[piv]; b[piv] = t;
        }
        for (i = k + 1; i < m; i++) {
            double f = a[(size_t)i * m + k] / a[(size_t)k * m + k];
            a[(size_t)i * m + k] = 0.0;
            for (j = k + 1; j < m; j++)
                a[(size_t)i * m + j] -= f * a[(size_t)k * m + j];
            b[i] -= f * b[k];
        }
    }
    for (i = m - 1; i >= 0; i--) {
        double s = b[i];
        for (j = i + 1; j < m; j++) s -= a[(size_t)i * m + j] * x[j];
        x[i] = s / a[(size_t)i * m + i];
    }
    return 1;
}""",
    """/* 最小二乘：解 min ‖A·x − b‖²，A 是 n×m 行主序（就地破坏），b 是 n（就地破坏）。
 * 列平衡 + Householder QR。返回 1 成功，0 表示秩亏（某列全零）。
 *
 * 不用正规方程的原因：VᵀV 把条件数平方了。实测 deg=6 还对得上 numpy（1.4e-13），
 * deg=8 就给出真值 2/4/8 倍的系数、拟合曲线残差差 56%。
 * 列平衡也不是可选项：mx 各次幂的列 2-范数差好几个数量级，不先归一 QR 也白搭。 */
static int lib_lstsq(double *a, double *b, long long n, int m, double *x)
{
    double *sc, *v;
    int     j, k, i;
    long long r;

    if (m < 1 || n < m) return 0;
    sc = (double *)calloc((size_t)m, sizeof(double));
    v  = (double *)malloc(sizeof(double) * (size_t)n);
    if (!sc || !v) { free(sc); free(v); return 0; }

    /* 1) 列平衡：第 j 列除以它的 2-范数（结果存 sc[j]，收尾要还原） */
    for (j = 0; j < m; j++) {
        double s = 0.0;
        for (r = 0; r < n; r++) { double t = a[(size_t)r * m + j]; s += t * t; }
        sc[j] = sqrt(s);
        if (!(sc[j] > 1e-300)) { free(sc); free(v); return 0; }   /* 该列全 0 -> 秩亏 */
        for (r = 0; r < n; r++) a[(size_t)r * m + j] /= sc[j];
    }

    /* 2) Householder 反射：逐列把 A[j..][j] 下面清零，b 跟着变换 */
    for (j = 0; j < m; j++) {
        double nrm = 0.0, alpha, vtv = 0.0;
        for (r = j; r < n; r++) { double t = a[(size_t)r * m + j]; nrm += t * t; }
        nrm = sqrt(nrm);
        if (!(nrm > 1e-300)) { free(sc); free(v); return 0; }
        alpha = (a[(size_t)j * m + j] > 0.0) ? -nrm : nrm;   /* 选符号避免相消 */
        for (r = j; r < n; r++) v[r - j] = a[(size_t)r * m + j];
        v[0] -= alpha;
        for (r = 0; r < n - j; r++) vtv += v[r] * v[r];
        if (vtv > 0.0) {
            double tau = 2.0 / vtv, dot;
            for (k = j; k < m; k++) {
                dot = 0.0;
                for (r = j; r < n; r++) dot += v[r - j] * a[(size_t)r * m + k];
                dot *= tau;
                for (r = j; r < n; r++) a[(size_t)r * m + k] -= dot * v[r - j];
            }
            dot = 0.0;
            for (r = j; r < n; r++) dot += v[r - j] * b[r];
            dot *= tau;
            for (r = j; r < n; r++) b[r] -= dot * v[r - j];
        }
    }

    /* 3) 回代解 R·x = Qᵀb（R 是上面得到的 m×m 上三角） */
    for (i = m - 1; i >= 0; i--) {
        double s = b[i];
        if (!(fabs(a[(size_t)i * m + i]) > 1e-300)) { free(sc); free(v); return 0; }
        for (k = i + 1; k < m; k++) s -= a[(size_t)i * m + k] * x[k];
        x[i] = s / a[(size_t)i * m + i];
    }

    /* 4) 还原列平衡 */
    for (j = 0; j < m; j++) x[j] /= sc[j];
    free(sc);
    free(v);
    return 1;
}""")

# ---- 2. 建矩阵：n×m（每行一个样本）而不是 m×m 的矩 ----
sub('2 设计矩阵改成 n×m 逐行填充',
    """    for (i = 0; i < n; i++) {
        double pj = 1.0;                       /* mx_i^j */
        for (j = 0; j < m; j++) {
            double p = pj;                     /* mx_i^(j+k) */
            for (k = 0; k < m; k++) {
                A[(size_t)j * m + k] += p;
                p *= mx[i];
            }
            B[j] += pj * my[i];
            pj *= mx[i];
        }
    }""",
    """    /* 设计矩阵：第 i 行是 (1, mx_i, mx_i², …)，第 i 个右端是 my_i。
     * 注意是 n×m 不是 m×m 的矩：QR 直接作用在这个矩阵上，不显式构造 VᵀV。 */
    for (i = 0; i < n; i++) {
        double pj = 1.0;
        for (j = 0; j < m; j++) { A[(size_t)i * m + j] = pj; pj *= mx[i]; }
        B[i] = my[i];
    }""")

# ---- 3. 分配尺寸跟着走 ----
sub('3 A 改成 n×m、B 改成 n',
    """    A  = (double *)calloc((size_t)m * m, sizeof(double));
    B  = (double *)calloc((size_t)m, sizeof(double));""",
    """    A  = (double *)calloc((size_t)n * m, sizeof(double));
    B  = (double *)calloc((size_t)n, sizeof(double));""")

# ---- 4. 求解调用换成 QR ----
sub('4 调用换成 lib_lstsq',
    """    if (!lib_gauss(A, B, m, cx)) {""",
    """    if (!lib_lstsq(A, B, n, m, cx)) {""")

# ---- 5. 秩亏的报错文案跟着换 ----
sub('5 秩亏的报错文案',
    """        lib_die("mp.polyfit：正规方程奇异，样本在横轴上退化（比如有重复的 x）\\n"
                "  为什么：x 全都一样或只有有限几种取值时，多项式拟合不唯一\\n"
                "  怎么改：让 x 有足够多的不同取值");""",
    """        lib_die("mp.polyfit：设计矩阵秩亏，样本在横轴上退化（比如有重复的 x）\\n"
                "  为什么：x 全都一样或只有有限几种取值时，多项式拟合不唯一\\n"
                "  怎么改：让 x 有足够多的不同取值；次数也要小于不同 x 的个数");""")

# ---- 6. 次数上限的理由变了（不再是「正规方程会不稳」，而是高次本身病态）----
sub('6 次数上限的文案',
    """        lib_die("mp.polyfit：次数 %d 超出 0~12\\n"
                "  为什么：范德蒙德正规方程的条件数随次数指数增长，再高就数值不稳了\\n"
                "  怎么改：换横轴单位缩小 x 的量级（拟合前先减掉均值），或分段低次拟合", deg);""",
    """        lib_die("mp.polyfit：次数 %d 超出 0~12\\n"
                "  为什么：高次多项式本身病态——即使解算用的是 QR，次数一高，"
                "系数也会对数据噪声极端敏感，不同实现给出的系数差好几个数量级\\n"
                "  怎么改：换横轴单位缩小 x 的量级（拟合前先减掉均值），或分段低次拟合", deg);""")

io.open(P, 'w', encoding='utf-8', newline='').write(t)
print('\npolyfit 求解器已换成 QR')
