/* --------------------------------------------------------------------
 * kernel 本体全部从 .ptx 纯文本文件读（见 load_ptx_file）。
 * 曾经这里还内嵌着 PTX_NAIVE / PTX_1X4 / PTX_4X4 三份 C 字符串，已删除：
 * 文件版与 C 字符串版一旦不一致，会出现「改的文件没生效、测的是旧 kernel」
 * 这种极难查的现象。现在 .ptx 文件是唯一真相源。
 */
/* _gputile.c —— sgemm 分块 kernel 的开发 harness（正确性优先，一版一版加）
 *
 * 编译：gcc _gputile.c -o _gputile.exe -O2
 * 用法：_gputile.exe 朴素|4x4 <N> [重复次数]
 *
 * 这个文件是「把 kernel 打磨到能赢 OpenBLAS」这条路的迭代台，
 * 独立于 pybook_gpu.c：改 kernel 时不用碰生产代码，编译 2 秒就能验。
 *
 * ── 为什么上一次的 4x4 没成（三个真 bug，不是玄学）──
 *   1. A 的地址从「A 基址 + k*4」重算，漏了 row0*K*4 行偏移 → 读的其实是 A[0][k]。
 *   2. 边界检查拿「已经乘过 4 的 row0」去和 M 比 → 判断成 row0*4 >= M → 越界。
 *   3. %rd4 被复用成 B 列临时地址，把边界要用的值冲掉了。
 *   根子在于它用「单游标 + 偏移寄存器」访问，而 PTX 的访存地址只允许
 *   「寄存器 + 立即数」，寄存器+寄存器是**非法**的。同一份代码里既写了这条坑的
 *   警告，又在自己的多行 A 载入上违反了它。
 *   本文件的设计原则：**每行/每列一个独立游标，游标只做 +4 / +步长；
 *   下标类寄存器（col0/row0）全程只读、永不复用。**
 */
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>   /* fail() 用 va_list —— 漏了这行 va_start 会展开成垃圾，直接堆损坏 */
#include <math.h>

/* ───────── CUDA driver API 的最小 typedef ───────── */
typedef int CUresult;
typedef int CUdevice;
typedef void *CUcontext;
typedef void *CUmodule;
typedef void *CUfunction;
typedef unsigned long long CUdeviceptr;
#define CU_DEVICE_ATTRIBUTE_CC_MAJOR 75
#define CU_DEVICE_ATTRIBUTE_CC_MINOR 76

static HMODULE g_dll;
static CUresult (*p_cuInit)(unsigned);
static CUresult (*p_cuDriverGetVersion)(int *);
static CUresult (*p_cuDeviceGetCount)(int *);
static CUresult (*p_cuDeviceGet)(CUdevice *, int);
static CUresult (*p_cuDeviceGetName)(char *, int, CUdevice);
static CUresult (*p_cuDeviceGetAttribute)(int *, int, CUdevice);
static CUresult (*p_cuDevicePrimaryCtxRetain)(CUcontext *, CUdevice);
static CUresult (*p_cuCtxSetCurrent)(CUcontext);
static CUresult (*p_cuCtxSynchronize)(void);
static CUresult (*p_cuModuleLoadData)(CUmodule *, const void *);
static CUresult (*p_cuModuleGetFunction)(CUfunction *, CUmodule *, const char *);
static CUresult (*p_cuMemAlloc_v2)(CUdeviceptr *, size_t);
static CUresult (*p_cuMemFree_v2)(CUdeviceptr);
static CUresult (*p_cuMemcpyHtoD_v2)(CUdeviceptr, const void *, size_t);
static CUresult (*p_cuMemcpyDtoH_v2)(void *, CUdeviceptr, size_t);
static CUresult (*p_cuLaunchKernel)(CUfunction, unsigned, unsigned, unsigned,
                                    unsigned, unsigned, unsigned,
                                    unsigned, void *, void **, void **);
static CUresult (*p_cuGetErrorString)(CUresult, const char **);

static CUcontext g_ctx;
static char g_err[256];

static const char *cu_err(CUresult r)
{
    const char *s = NULL;
    if (p_cuGetErrorString && p_cuGetErrorString(r, &s) == 0 && s)
        return s;
    return "未知 CUDA 错误";
}

static int fail(const char *fmt, ...)
{
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(g_err, sizeof g_err, fmt, ap);
    va_end(ap);
    return 0;
}

/* ───────── 手写 PTX ─────────
 * 铁律（踩过的）：字符串里只准用 // 行注释，且必须 ASCII。
 * PTX 只认 %ctaid 是块编号 / %tid 是块内线程编号；
 * 访存地址只准「寄存器 + 立即数」，寄存器 + 寄存器非法。
 */

/* ---- 朴素版（每线程 1 个输出），作为对照组，也当正确性基准 ---- */
/* ---- 1x4 分块（每线程 1 行 4 列，16x16 块覆盖 16 行 x 64 列）----
 * 这是**二分法的最小失败单元**：4x4 只多了「A 的 3 个额外行游标」这一件事。
 * 1x4 过了 -> B 的多列载入、C 的写回、col0/row0 索引都是对的，问题锁定在 A 的多行；
 * 1x4 也错 -> 问题在更基础的地方（参数 / 线程索引 / B 多列）。
 *
 * 寄存器（沿用同一套约定：下标 %r8/%r9 全程只读，游标只做加法）：
 *   %rd1 A  %rd2 B  %rd3 C
 *   %rd4  A 游标          %rd8..%rd11 B 四列游标
 *   %rd12 B 步进 K*N*4    %rd13 C 行基址
 *   %r1 M %r2 N %r3 K   %r4 tx %r5 ty %r6 ctaid.x %r7 ctaid.y
 *   %r8 col0 %r9 row0（只读）  %r10 临时  %r14 k
 *   %f4..%f7 四个累加器  %f8 一个 A 值  %f9..%f12 四个 B 值
 */
/* ---- 4x4 分块：每线程算 4 行 x 4 列，16x16 线程的块覆盖 64x64 ----
 *
 * 寄存器分配表（改之前先看这张表；「只读、绝不复用」是设计约束）：
 *   %rd1  A 基址        %rd2  B 基址        %rd3  C 基址
 *   %rd4  A 行0 游标    %rd5  A 行1 游标    %rd6  A 行2 游标    %rd7  A 行3 游标
 *   %rd8  B 列0 游标    %rd9  B 列1 游标    %rd10 B 列2 游标    %rd11 B 列3 游标
 *   %rd12 B 步进 K*N*4  %rd13 C 行0        %rd14 C 行1        %rd15 C 行2   %rd16 C 行3
 *   %rd17..%rd19 临时
 *   %r1 M   %r2 N   %r3 K
 *   %r4 tx  %r5 ty  %r6 ctaid.x  %r7 ctaid.y
 *   %r8  col0（元素下标，全程只读）   %r9  row0（元素下标，全程只读）
 *   %r10..%r13 边界判定临时   %r14  k 循环计数
 *   %f16..%f31 16 个累加器   %f32..%f35 A 的 4 个值   %f36..%f39 B 的 4 个值
 *
 * 边界：块覆盖 64x64，M/N 未必是 64 的倍数（3216 = 64*50.25），
 * 所以末块会越界 -> 8 个 predicate（4 行 + 4 列），逐元素 predicated store。
 */
/* ───────── 运行时 ───────── */
static CUfunction g_fn;
static int g_tile = 4;
static CUdeviceptr g_dA, g_dB, g_dC;
static size_t g_cap;

static double now(void)
{
    LARGE_INTEGER f, c;
    QueryPerformanceFrequency(&f);
    QueryPerformanceCounter(&c);
    return (double)c.QuadPart / (double)f.QuadPart;
}

/* kernel 从 .ptx 纯文本文件读，不从 C 字符串常量读。
 * 原因：C 字符串里一层 \" 一层 \n，转义或缩进被动一点就废掉一轮编译，
 * 而且出错的报错信息毫无指向性（ptxas 一个字都不说）。直接编辑纯文本 PTX，
 * 改完 diff 一眼能看懂。生产代码 pybook_gpu.c 仍然是内嵌字符串，零外部依赖。 */
static char g_ptx[65536];

static int load_ptx_file(const char *path)
{
    FILE *f = fopen(path, "rb");
    size_t n;
    if (!f) return fail("打不开 PTX 文件 %s", path);
    n = fread(g_ptx, 1, sizeof(g_ptx) - 1, f);
    fclose(f);
    g_ptx[n] = '\0';
    if (n < 100) return fail("PTX 文件 %s 太短（%zu 字节），像是空的", path, n);
    return 1;
}

static int init(const char *ptx, const char *name)
{
    void *p;
    CUdevice dev;
    CUmodule mod = NULL;
    CUresult r;
    int maj = 0, min = 0, cc;

    g_dll = LoadLibraryA("nvcuda.dll");
    if (!g_dll) return fail("找不到 nvcuda.dll");
#define LOAD(n, f) do { p = (void *)GetProcAddress(g_dll, n); \
    if (!p) return fail("缺 %s", n); \
    memcpy(&(f), &p, sizeof(f)); } while (0)
    LOAD("cuInit", p_cuInit);
    LOAD("cuDriverGetVersion", p_cuDriverGetVersion);
    LOAD("cuDeviceGetCount", p_cuDeviceGetCount);
    LOAD("cuDeviceGet", p_cuDeviceGet);
    LOAD("cuDeviceGetName", p_cuDeviceGetName);
    LOAD("cuDeviceGetAttribute", p_cuDeviceGetAttribute);
    LOAD("cuDevicePrimaryCtxRetain", p_cuDevicePrimaryCtxRetain);
    LOAD("cuCtxSetCurrent", p_cuCtxSetCurrent);
    LOAD("cuCtxSynchronize", p_cuCtxSynchronize);
    LOAD("cuModuleLoadData", p_cuModuleLoadData);
    LOAD("cuModuleGetFunction", p_cuModuleGetFunction);
    LOAD("cuMemFree_v2", p_cuMemFree_v2);
    LOAD("cuMemcpyHtoD_v2", p_cuMemcpyHtoD_v2);
    LOAD("cuMemcpyDtoH_v2", p_cuMemcpyDtoH_v2);
    LOAD("cuLaunchKernel", p_cuLaunchKernel);
    LOAD("cuGetErrorString", p_cuGetErrorString);
    p = (void *)GetProcAddress(g_dll, "cuMemAlloc_v2");
    memcpy(&p_cuMemAlloc_v2, &p, sizeof(p));
#undef LOAD
    if (!p_cuMemAlloc_v2) return fail("缺 cuMemAlloc_v2");
    if (p_cuInit(0) != 0) return fail("cuInit 失败");
    if (p_cuDeviceGet(&dev, 0) != 0) return fail("取不到 0 号设备");
    p_cuDeviceGetName(g_err, 64, dev);
    p_cuDeviceGetAttribute(&maj, CU_DEVICE_ATTRIBUTE_CC_MAJOR, dev);
    p_cuDeviceGetAttribute(&min, CU_DEVICE_ATTRIBUTE_CC_MINOR, dev);
    cc = maj * 10 + min;
    if (p_cuDevicePrimaryCtxRetain(&g_ctx, dev) != 0) return fail("建不了 context");
    if (p_cuCtxSetCurrent(g_ctx) != 0) return fail("切不过 context");

    /* 注意：绝不能把 PTX 丢进 snprintf —— 里面的 %r1 / %f16 会被当格式符吃掉。
     * 开发机固定 sm_61，整串直接用。 */
    r = p_cuModuleLoadData(&mod, ptx);
    if (r != 0) return fail("PTX 被拒（CC=%d）：%s", cc, cu_err(r));
    r = p_cuModuleGetFunction(&g_fn, mod, name);
    if (r != 0) return fail("取不到入口 %s：%s", name, cu_err(r));
    return 1;
}
static int ensure(size_t bytes)
{
    if (bytes <= g_cap) return 1;
    if (g_cap) { p_cuMemFree_v2(g_dA); p_cuMemFree_v2(g_dB); p_cuMemFree_v2(g_dC); g_cap = 0; }
    if (p_cuMemAlloc_v2(&g_dA, bytes) != 0) return fail("显存分配失败");
    if (p_cuMemAlloc_v2(&g_dB, bytes) != 0) return fail("显存分配失败");
    if (p_cuMemAlloc_v2(&g_dC, bytes) != 0) return fail("显存分配失败");
    g_cap = bytes;
    return 1;
}

static unsigned g_seed = 12345u;
static double frand(void)
{
    g_seed = g_seed * 1103515245u + 12345u;
    return (double)((g_seed >> 9) & 0xFFFF) / 65536.0 - 0.5;
}

/* tile = 1 表示朴素版，4 表示 4x4 */
static void launch_cfg(int tile, int M, int N,
                       unsigned *gx, unsigned *gy, unsigned *bx, unsigned *by)
{
    /* 每个 tile 的网格形状不同，写错就会「编译通过、结果全错」，而且现象很像 kernel 本身有 bug。
     *   朴素(1)  : 每线程 1 个输出, block 16x16, grid = ceil(N/16) x ceil(M/16)
     *   1x4 (2)  : 每线程 1 行 4 列, block 16x16, col0 = ctaid.x*64 + tid.x*4
     *              -> x 方向一个 block 铺 64 列; 行方向 block 16x16 铺 16 行
     *   4x4 (3)  : 每线程 4 行 4 列, block 16x16, grid = ceil(N/64) x ceil(M/64)
     * 之前 tile=2 落进了 else 分支按 4x4 发，gy 少算 4 倍，列看着"对"纯属巧合。 */
    if (tile == 1) {
        *bx = 16; *by = 16;
        *gx = (unsigned)((N + 15) / 16); *gy = (unsigned)((M + 15) / 16);
    } else if (tile == 2) {
        *bx = 16; *by = 16;
        *gx = (unsigned)((N + 63) / 64); *gy = (unsigned)((M + 15) / 16);
    } else if (tile == 6) {
        *bx = 16; *by = 16;
        *gx = (unsigned)((N + 127) / 128); *gy = (unsigned)((M + 127) / 128);
    } else {
        *bx = 16; *by = 16;
        *gx = (unsigned)((N + 63) / 64); *gy = (unsigned)((M + 63) / 64);
    }
}

static int bench(int M, int N, int K, int tile, int rep)
{
    size_t ka = (size_t)M * K, kb = (size_t)K * N, kc = (size_t)M * N;
    /* 注意：只留 f32 缓冲。曾经这里还开了三个 double* 缓冲却按 4 字节/元素 malloc，
     * 写入时直接踩穿堆（0xC0000005）。参考计算在 host 上按 float 提升成 double 做，
     * 不需要额外的 double 数组。 */
    float  *fA = malloc(ka * sizeof(float));
    float  *fB = malloc(kb * sizeof(float));
    float  *fC = malloc(kc * sizeof(float));
    double  t0, t1, best = 1e30, e0 = 0;
    size_t  i, step;
    int     it, bad = 0, r, q, p;
    CUresult cr;

    if (!fA || !fB || !fC) { printf("host 内存不足\n"); return 0; }
    for (i = 0; i < ka; i++) fA[i] = (float)frand();
    for (i = 0; i < kb; i++) fB[i] = (float)frand();
    memset(fC, 0, kc * sizeof(float));

    if (!ensure(ka * sizeof(float))) { printf("显存不足\n"); return 0; }
    p_cuMemcpyHtoD_v2(g_dA, fA, ka * sizeof(float));
    p_cuMemcpyHtoD_v2(g_dB, fB, kb * sizeof(float));

    for (it = 0; it < rep; it++) {
        int m = M, n = N, k = K;
        void *params[] = { &g_dA, &g_dB, &g_dC, &m, &n, &k };
        unsigned gx, gy, bx, by;
        launch_cfg(tile, M, N, &gx, &gy, &bx, &by);

        t0 = now();
        cr = p_cuLaunchKernel(g_fn, gx, gy, 1, bx, by, 1, 0, NULL, params, NULL);
        if (cr != 0) { printf("launch 失败：%s\n", cu_err(cr)); return 0; }
        cr = p_cuCtxSynchronize();
        if (cr != 0) { printf("kernel 出错：%s\n", cu_err(cr)); return 0; }
        t1 = now();
        if (t1 - t0 < best) best = t1 - t0;
    }
    p_cuMemcpyDtoH_v2(fC, g_dC, kc * sizeof(float));

    /* 分量后向误差：|算错-精确| / Σ|a·b|。不用相对误差——输出接近 0 时那玩意会爆。 */
    step = kc > 200000 ? kc / 200000 : 1;
    for (i = 0; i < kc; i += step) {
        double acc = 0.0, mag = 0.0;
        r = (int)(i / (size_t)N);
        q = (int)(i % (size_t)N);
        for (p = 0; p < K; p++) {
            double a = (double)fA[(size_t)r * K + p];
            double b = (double)fB[(size_t)p * N + q];
            acc += a * b;
            mag += fabs(a * b);
        }
        {
            double d = fabs((double)fC[i] - acc);
            double rel = mag > 0 ? d / mag : d;
            if (rel > e0) e0 = rel;
            if (rel > 1e-5) bad++;
        }
    }
    printf("  %s N=%-5d 块=%-3s  %8.1f GFLOPS  后向误差 %.3e  %s\n",
           tile == 1 ? "朴素" : tile == 2 ? "1x4 " : tile == 5 ? "共享" : tile == 6 ? "8x8 " : "4x4 ",
           N, "16x16", 
           2.0 * M * N * K / best / 1e9, e0, bad ? "★有错★" : "OK");
    free(fA); free(fB); free(fC);
    return bad == 0;
}

/* probe 的新实现（替换 _gputile.c 里那段旧的 probe）
 *
 * 定位用（**不碰 PTX**，只改 host 侧喂的数据 —— 往 PTX 里插诊断段会把编译搞挂，
 * 而且插在 `bra KLOOP` 之后还是死代码，白折腾一轮）：
 *   A[r][k] = r*K + k + 1        B[k][c] = c + 1
 * 于是 C[r][c] = (c+1) * (r*K*K + K(K-1)/2 + K)，K=64 时 C[1][0] 应为 6176、C[1][4] 应为 30880。
 * 若只累加了 k=0，会得到 (r*64+1)*(c+1) = 65 / 325 —— 与正确值差两个数量级，
 * 「k 循环只跑一次」和「列映射错」这两种可能立刻分开。
 * 再统计每行算对了多少列，定位覆盖度（是不是只有 tx=0 的线程写了）。
 */
static void probe(const char *tag)
{
    int M = 64, N = 64, K = 64;
    float *A = malloc((size_t)M * K * sizeof(float));
    float *B = malloc((size_t)K * N * sizeof(float));
    float *C = malloc((size_t)M * N * sizeof(float));
    int m = M, n = N, kk = K;
    void *params[6];
    int r, c, k, rows_ok = 0;

    for (r = 0; r < M; r++)
        for (k = 0; k < K; k++) A[(size_t)r * K + k] = (float)(r * K + k + 1);
    for (k = 0; k < K; k++)
        for (c = 0; c < N; c++) B[(size_t)k * N + c] = (float)(c + 1);
    memset(C, 0, (size_t)M * N * sizeof(float));

    ensure((size_t)M * K * sizeof(float));
    p_cuMemcpyHtoD_v2(g_dA, A, (size_t)M * K * sizeof(float));
    p_cuMemcpyHtoD_v2(g_dB, B, (size_t)K * N * sizeof(float));
    params[0] = &g_dA; params[1] = &g_dB; params[2] = &g_dC;
    params[3] = &m; params[4] = &n; params[5] = &kk;

    /* 上传回读校验：kernel 结果再离谱，先得确认「显存里确实是 host 端那份数据」。
     * 这一步以前没做，结果在 kernel 里绕了三轮。 */
    {
        float *chk = malloc((size_t)M * K * sizeof(float));
        int bad = 0;
        p_cuMemcpyDtoH_v2(chk, g_dA, (size_t)M * K * sizeof(float));
        for (r = 0; r < 4; r++)
            printf("    host A[%d][0..4] =", r);
        printf("\n              ");
        for (k = 0; k < 5; k++) printf("%6.0f", (double)A[k]);
        printf("\n              ");
        for (k = 0; k < 5; k++) printf("%6.0f", (double)chk[k]);
        printf("\n    host B[0][0..4] =");
        for (c = 0; c < 5; c++) printf("%6.0f", (double)B[c]);
        printf("\n    host B[1][0..4] =");
        for (c = 0; c < 5; c++) printf("%6.0f", (double)B[(size_t)1 * N + c]);
        printf("\n");
        for (r = 0; r < M; r++)
            for (k = 0; k < K; k++)
                if (chk[(size_t)r * K + k] != A[(size_t)r * K + k]) bad++;
        printf("    显存回读与 host 不一致的元素: %d / %d\n", bad, M * K);
        free(chk);
    }
    {
        unsigned gx, gy, bx, by;
        launch_cfg(g_tile, M, N, &gx, &gy, &bx, &by);
        printf("    发射 grid=%ux%u block=%ux%u\n", gx, gy, bx, by);
        p_cuLaunchKernel(g_fn, gx, gy, 1, bx, by, 1, 0, NULL, params, NULL);
        if (p_cuCtxSynchronize() != 0) { printf("  probe：kernel 出错\n"); return; }
    }
    p_cuMemcpyDtoH_v2(C, g_dC, (size_t)M * N * sizeof(float));

    printf("  [%s] A[r][k]=r*%d+k+1, B[k][c]=c+1  =>  C[r][c]=(c+1)*(r*%d+2080)\n",
           tag, K, K * K);
    for (r = 0; r < 3; r++) {
        double base = (double)(r * K * K + 2080);
        printf("    行%d 实得:", r);
        for (c = 0; c < 6; c++) printf("%10.0f", (double)C[(size_t)r * N + c]);
        printf("\n    行%d 应为:", r);
        for (c = 0; c < 6; c++) printf("%10.0f", base * (c + 1));
        printf("\n");
    }
    for (r = 0; r < 8; r++) {
        double base = (double)(r * K * K + 2080);
        int good = 0, first_bad = -1;
        for (c = 0; c < N; c++) {
            if (fabs((double)C[(size_t)r * N + c] - base * (c + 1)) < 1.0) good++;
            else if (first_bad < 0) first_bad = c;
        }
        printf("    行%d 算对 %2d/%d 列", r, good, N);
        if (first_bad >= 0) printf("，第一个错列 c=%d（实得 %.0f，应为 %.0f）",
                                   first_bad, (double)C[(size_t)r * N + first_bad],
                                   base * (first_bad + 1));
        printf("\n");
        if (good) rows_ok++;
    }
    printf("    => 前 8 行里有算对的: %d 行\n", rows_ok);
    free(A); free(B); free(C);
}

int main(int argc, char **argv)
{
    const char *which = argc > 1 ? argv[1] : "4x4";
    int ns[] = {64, 128, 256, 512, 1024, 2048, 3216};
    int i, ok = 1, tile;

    fprintf(stderr, "[dbg] argc=%d which=%s\n", argc, which ? which : "(null)");
    fflush(stderr);
    if (!strcmp(which, "naive"))    tile = 1;
    else if (!strcmp(which, "1x4")) tile = 2;
    else if (!strcmp(which, "shared")) tile = 5;
    else if (!strcmp(which, "8x8")) tile = 6;
    else                            tile = 4;
    g_tile = tile;
    fprintf(stderr, "[dbg] tile=%d\n", tile);
    fflush(stderr);
    {
        char path[128];
        sprintf(path, "_ptx_PTX_%s.ptx", tile == 1 ? "NAIVE" : tile == 2 ? "1X4" : tile == 5 ? "SHARED" : tile == 6 ? "8X8" : "4X4");
        if (!load_ptx_file(path)) { printf("读 PTX 失败：%s\n", g_err); return 1; }
        fprintf(stderr, "[dbg] 载入 %s (%zu 字节)\n", path, strlen(g_ptx));
        fflush(stderr);
        {
            /* 刻意不做「文件失败就退回 C 字符串」的兜底：那会把「文件版 PTX 有问题」
             * 悄悄变成「测了一个早就废弃的旧 kernel」，现象极具误导性。直接报错。 */
            if (!init(g_ptx, tile == 5 ? "sgemm_shared" : tile == 6 ? "sgemm_8x8" : "sgemm")) {
                printf("初始化失败（%s 编译不过）：%s\n", path, g_err);
                return 1;
            }
            printf("[dbg] %s 编译通过（%zu 字节）\n", path, strlen(g_ptx));
        }
        fflush(stdout);
    }
    fprintf(stderr, "[dbg] init ok\n");
    fflush(stderr);
    probe(which);
    printf("设备：%s   kernel=%s\n", g_err, which);
    for (i = 0; i < (int)(sizeof(ns) / sizeof(ns[0])); i++)
        if (!bench(ns[i], ns[i], ns[i], tile, 3))
            ok = 0;
    /* 非方阵 */
    if (!bench(64, 128, 256, tile, 2)) ok = 0;
    if (!bench(256, 64, 128, tile, 2)) ok = 0;
    /* 边缘尺寸：4 的倍数但不是 64 的倍数，专门踩 M/N 的尾巴
     * （行/列钳位加载 + 谓词存储）。这些全对，边界逻辑才算验过。 */
    if (!bench(68,  68,  68,  tile, 2)) ok = 0;
    if (!bench(100, 132, 68,  tile, 2)) ok = 0;
    if (!bench(260, 68,  132, tile, 2)) ok = 0;
    if (!bench(4,   4,   4,   tile, 2)) ok = 0;
    printf("%s\n", ok ? "全部通过" : "★有失败★");
        return ok ? 0 : 1;
}



