/* _probe_glui3.c —— 端到端验证「3D 渲进 SDL 纹理 → UI 画在上面」这条路。
 *
 * 【探针 1 的结论】
 *   同一个 SDL_Window 上，默认 ACCELERATED 选 direct3d 后端，
 *   GL 后缓冲和 SDL_Renderer 后缓冲是两个独立的东西：GL 画成蓝色之后
 *   SDL_RenderReadPixels 仍读回 SDL 自己的红色。直接叠加是死的。
 *
 * 【本探针要验的那条最优路】
 *   1. 强制 SDL_Renderer 用 OpenGL 后端，窗口带 SDL_WINDOW_OPENGL
 *   2. SDL 拥有纹理（SDL_CreateTexture），用 SDL_GL_BindTexture 拿到它的 GL 名
 *      —— 注意真实签名是 SDL_GL_BindTexture(SDL_Texture*, float*, float*)，
 *         和「把 GL 纹理包给 SDL」是反的，这一点想反了整条路就写错了
 *   3. hw3d 把这个 GL 名字当 FBO 的颜色附着，整场 3D 渲进去
 *   4. SDL_RenderCopy(纹理) 当背景 → UI 照常 SDL_RenderDraw 画在上面
 *   5. SDL_RenderPresent
 *
 *   成立的前提（一个都不能想当然）：
 *   (a) SDL 的 opengl renderer 复用我们已有的 GL context？—— 不复用就传不过去
 *   (b) SDL 创建的纹理能不能当 FBO 颜色附着？—— 能，纹理是 GL 的
 *   (c) 交错帧不脏：GL 渲 FBO → SDL 画 UI → present → 下一帧 GL 再渲
 *   (d) SDL_RenderReadPixels 还能不能读回来（验收件全靠它）
 *   (e) present 之后 GL 状态还干净吗
 */
#include <SDL2/SDL.h>
#include <SDL2/SDL_opengl.h>
#include <stdio.h>
#include <stdint.h>

static PFNGLGENFRAMEBUFFERSPROC        pGenFramebuffers;
static PFNGLBINDFRAMEBUFFERPROC        pBindFramebuffer;
static PFNGLFRAMEBUFFERTEXTURE2DPROC   pFramebufferTexture2D;
static PFNGLCHECKFRAMEBUFFERSTATUSPROC pCheckFramebufferStatus;

static void load_gl(void)
{
    pGenFramebuffers        = (PFNGLGENFRAMEBUFFERSPROC)SDL_GL_GetProcAddress("glGenFramebuffers");
    pBindFramebuffer        = (PFNGLBINDFRAMEBUFFERPROC)SDL_GL_GetProcAddress("glBindFramebuffer");
    pFramebufferTexture2D   = (PFNGLFRAMEBUFFERTEXTURE2DPROC)SDL_GL_GetProcAddress("glFramebufferTexture2D");
    pCheckFramebufferStatus = (PFNGLCHECKFRAMEBUFFERSTATUSPROC)SDL_GL_GetProcAddress("glCheckFramebufferStatus");
}

static int fails = 0;
static void chk(const char *what, int cond)
{
    printf("  [%s] %s\n", cond ? " OK " : "FAIL", what);
    if (!cond) fails++;
}

int main(void)
{
    SDL_SetMainReady();
    if (SDL_Init(SDL_INIT_VIDEO) != 0) { printf("SDL_Init: %s\n", SDL_GetError()); return 1; }
    SDL_SetHint(SDL_HINT_RENDER_DRIVER, "opengl");

    const int W = 640, H = 480;
    SDL_Window *win = SDL_CreateWindow("probe3", SDL_WINDOWPOS_CENTERED,
                                       SDL_WINDOWPOS_CENTERED, W, H,
                                       SDL_WINDOW_SHOWN | SDL_WINDOW_OPENGL);
    if (!win) { printf("建窗失败: %s\n", SDL_GetError()); return 1; }
    SDL_GL_SetAttribute(SDL_GL_DOUBLEBUFFER, 1);
    SDL_GL_SetAttribute(SDL_GL_DEPTH_SIZE, 24);
    SDL_GLContext ctx = SDL_GL_CreateContext(win);
    if (!ctx) { printf("GL context 失败: %s\n", SDL_GetError()); return 1; }
    load_gl();

    SDL_Renderer *ren = SDL_CreateRenderer(win, -1, SDL_RENDERER_ACCELERATED);
    if (!ren) { printf("SDL_CreateRenderer 失败: %s\n", SDL_GetError()); return 1; }
    SDL_RendererInfo ri;
    SDL_GetRendererInfo(ren, &ri);
    printf("renderer 后端 = %s\n", ri.name);

    printf("\n=== (a) SDL 的 opengl renderer 复用我们已有的 GL context 吗 ===\n");
    printf("  我们建的 = %p，SDL 看到的 = %p\n", (void *)ctx, (void *)SDL_GL_GetCurrentContext());
    chk("同一个 GL context（否则纹理传不过去）", SDL_GL_GetCurrentContext() == (void *)ctx);
    chk("后端确实是 opengl（不然 BindTexture 不可用）", strstr(ri.name, "opengl") != NULL);

    printf("\n=== (b) SDL 的纹理能不能当 FBO 颜色附着 ===\n");
    SDL_Texture *stex = SDL_CreateTexture(ren, SDL_PIXELFORMAT_ARGB8888,
                                          SDL_TEXTUREACCESS_STATIC, W, H);
    chk("SDL_CreateTexture", stex != NULL);
    float fw = 0.0f, fh = 0.0f;
    chk("SDL_GL_BindTexture 拿到 GL 纹理名",
        stex && SDL_GL_BindTexture(stex, &fw, &fh) == 0);
    GLuint tex = (GLuint)(uintptr_t)(*(uint32_t *)&fw);
    printf("  GL 纹理名 = %u，尺寸 %.0fx%.0f\n", (unsigned)tex, (double)fw, (double)fh);

    GLuint fbo = 0;
    pGenFramebuffers(1, &fbo);
    pBindFramebuffer(GL_FRAMEBUFFER, fbo);
    pFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, tex, 0);
    GLenum st = pCheckFramebufferStatus(GL_FRAMEBUFFER);
    chk("FBO 挂在 SDL 的纹理上且完整", st == GL_FRAMEBUFFER_COMPLETE);

    /* 3D 渲进 FBO：全屏绿 */
    glViewport(0, 0, W, H);
    glClearColor(0.15f, 0.75f, 0.35f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT);
    glFlush();
    chk("往 FBO 里清屏，GL 无错", glGetError() == GL_NO_ERROR);

    printf("\n=== (c) SDL 把那张纹理当背景贴上来 ===\n");
    pBindFramebuffer(GL_FRAMEBUFFER, 0);
    SDL_SetRenderDrawColor(ren, 0, 0, 0, 255);
    SDL_RenderClear(ren);
    SDL_SetTextureBlendMode(stex, SDL_BLENDMODE_NONE);
    SDL_RenderCopy(ren, stex, NULL, NULL);
    SDL_RenderPresent(ren);

    unsigned char *px = (unsigned char *)malloc(W * H * 4);
    chk("SDL_RenderReadPixels 读得回来（验收件全靠它）",
        SDL_RenderReadPixels(ren, NULL, SDL_PIXELFORMAT_RGBA32, px, W * 4) == 0);
    printf("  左上角像素 = %02X %02X %02X（期望接近 26 BF 59，也就是那抹绿）\n",
           px[0], px[1], px[2]);
    int green = (px[1] > px[0] + 40 && px[1] > px[2] + 40);
    chk("3D 的颜色真的穿过纹理上了屏", green);

    printf("\n=== (d) UI 画在纹理之上（这正是要验证的重点）===\n");
    SDL_SetRenderDrawColor(ren, 220, 60, 60, 255);
    SDL_RenderFillRect(ren, &(SDL_Rect){80, 80, 180, 100});
    SDL_RenderPresent(ren);
    SDL_RenderReadPixels(ren, NULL, SDL_PIXELFORMAT_RGBA32, px, W * 4);
    int i = ((120 * W) + 160) * 4;
    printf("  UI 方块处像素 = %02X %02X %02X（期望接近 DC 3C 3C）\n", px[i], px[i+1], px[i+2]);
    chk("UI 方块压在 3D 之上（而不是被 3D 盖掉）",
        px[i] > px[i+2] + 40);
    int j = ((400 * W) + 500) * 4;
    printf("  没被 UI 覆盖处像素 = %02X %02X %02X（应仍是那抹绿）\n", px[j], px[j+1], px[j+2]);
    chk("3D 背景没被 UI 清掉", px[j + 1] > px[j + 0] + 40);

    printf("\n=== (e) 交错帧不脏：GL 再渲一次 FBO，SDL 再画一次 ===\n");
    for (int f = 0; f < 5; f++) {
        pBindFramebuffer(GL_FRAMEBUFFER, fbo);
        glViewport(0, 0, W, H);
        glClearColor(0.9f, 0.2f + 0.1f * f, 0.1f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT);
        pBindFramebuffer(GL_FRAMEBUFFER, 0);
        SDL_SetRenderDrawColor(ren, 30, 40, 50, 160);
        SDL_RenderFillRect(ren, &(SDL_Rect){0, 0, W, 20});
        SDL_RenderPresent(ren);
    }
    chk("5 轮交错后 GL 仍干净", glGetError() == GL_NO_ERROR);
    chk("5 轮交错后 SDL 仍可用",
        SDL_RenderReadPixels(ren, NULL, SDL_PIXELFORMAT_RGBA32, px, W * 4) == 0);

    free(px);
    if (stex) SDL_GL_UnbindTexture(stex);
    SDL_DestroyRenderer(ren);
    SDL_GL_DeleteContext(ctx);
    SDL_DestroyWindow(win);
    SDL_Quit();
    printf("\n===== 结论：%s（失败 %d 项）=====\n", fails == 0 ? "这条走得通" : "有路走不通", fails);
    return fails == 0 ? 0 : 1;
}
