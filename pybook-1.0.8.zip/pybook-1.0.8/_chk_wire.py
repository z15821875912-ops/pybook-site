# -*- coding: utf-8 -*-
"""_chk_wire.py — 四张表逐条计数（出现次数必须正好 1），顺便看有没有重复的小标题"""
import io
import re

FILES = {
    'pybk_front.py': ["'mt.erf'", "'mt.erfc'", "'mt.gamma'", "'mt.lgamma'", "'mt.zeta'",
                      "'mt.golden_min'", "'mt.golden_max'",
                      "'mp.interp_linear'", "'mp.interp_cubic'", "'mp.linfit'", "'mp.polyfit'"],
    'pybk_code.py':  ["'mt.erf': 'rt_lib_mt_erf'", "'mt.erfc': 'rt_lib_mt_erfc'",
                      "'mt.gamma': 'rt_lib_mt_gamma'", "'mt.lgamma': 'rt_lib_mt_lgamma'",
                      "'mt.zeta': 'rt_lib_mt_zeta'", "'mt.golden_min': 'rt_lib_mt_golden_min'",
                      "'mt.golden_max': 'rt_lib_mt_golden_max'",
                      "'mp.interp_linear': 'rt_lib_mp_interp_linear'",
                      "'mp.interp_cubic': 'rt_lib_mp_interp_cubic'",
                      "'mp.linfit': 'rt_lib_mp_linfit'", "'mp.polyfit': 'rt_lib_mp_polyfit'"],
    'pybook_lib.h':  ['rt_lib_mt_erf(', 'rt_lib_mt_erfc(', 'rt_lib_mt_gamma(', 'rt_lib_mt_lgamma(',
                      'rt_lib_mt_zeta(', 'rt_lib_mt_golden_min(', 'rt_lib_mt_golden_max(',
                      'rt_lib_mp_interp_linear(', 'rt_lib_mp_interp_cubic(',
                      'rt_lib_mp_linfit(', 'rt_lib_mp_polyfit('],
    '_vm_lib_calls.inc': ['{"mt.erf", 1,', '{"mt.erfc", 1,', '{"mt.gamma", 1,', '{"mt.lgamma", 1,',
                          '{"mt.zeta", 1,', '{"mt.golden_min", 2,', '{"mt.golden_max", 2,',
                          '{"mp.interp_linear", 3,', '{"mp.interp_cubic", 3,',
                          '{"mp.linfit", 2,', '{"mp.polyfit", 3,'],
}

bad = 0
for p, marks in FILES.items():
    t = io.open(p, encoding='utf-8', newline='').read()
    dup = [m for m in marks if t.count(m) != 1]
    print('%-20s %2d 条标记，异常 %d 条 %s' % (p, len(marks), len(dup), dup))
    bad += len(dup)

# 小标题重复检查：这轮插了 3 个 # ---- ---- 块
for p in ('pybk_front.py', 'pybk_code.py', 'pybook_lib.h'):
    t = io.open(p, encoding='utf-8', newline='').read()
    for head in ('特殊函数', '一维极值', '插值与拟合'):
        c = t.count(head)
        if c != 1:
            print('  !! %s 标题「%s」出现 %d 次' % (p, head, c))
            bad += 1

t = io.open('_vm_lib_calls.inc', encoding='utf-8', newline='').read()
m = re.search(r'(\d+) 个库调用', t)
print('_vm_lib_calls.inc 表头计数：%s（实际表项 %d）'
      % (m.group(1), len(re.findall(r'^\s*\{"', t, re.M))))
print('OK' if bad == 0 else 'FAIL %d' % bad)
