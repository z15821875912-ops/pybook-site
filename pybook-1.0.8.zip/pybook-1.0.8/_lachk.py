# _lachk.py — 拿 NumPy 当裁判，逐项核 _lacheck.exe 的结果
#
# 判定原则：能写成「数学恒等式」的就直接验证恒等式，不要去比单个元素。
#   QR 的 Q 有符号自由度、R 的对角可以整列翻转，比元素一定会假报警；
#   验证 A = Q R 和 Q 正交，既能抓住「Q^T 写反了」这种结构性错误，又不会被符号晃到。
#   SVD / 特征值同理：一律用乘积式和正交性判定。

import sys
import numpy as np

DUMP = '_la_dump.txt'
TOL = 1e-9


def parse(path):
    with open(path, encoding='utf-8') as f:
        lines = f.read().split('\n')
    cases, cur, i = [], None, 0
    while i < len(lines):
        line = lines[i]
        if line.startswith('CASE '):
            _, name, m, n, k = line.split()
            cur = {'name': name, 'm': int(m), 'n': int(n), 'k': int(k), 'd': {}}
            cases.append(cur)
        elif line.startswith('MAT '):
            _, tag, r, c = line.split()
            r, c = int(r), int(c)
            rows = []
            for _ in range(r):
                i += 1
                rows.append([float(x) for x in lines[i].split()])
            cur['d'][tag] = np.array(rows, dtype=float)
        elif line.startswith('VEC '):
            _, tag, n = line.split()
            n = int(n)
            i += 1
            cur['d'][tag] = np.array([float(x) for x in lines[i].split()], dtype=float)
        elif line.startswith('SCALAR '):
            _, tag, v = line.split()
            cur['d'][tag] = float(v)
        i += 1
    return cases


def rel(a, b):
    """相对 Frobenius 误差；分母为 0 时退化成绝对误差。"""
    d = np.linalg.norm(a - b)
    s = np.linalg.norm(b)
    if s == 0.0:
        s = max(np.linalg.norm(a), 1.0)
    return d / s


results = []   # (case, 项目, 误差或 None, 说明)


def chk(case, tag, err, note=''):
    results.append((case, tag, err, note))


def main():
    cases = parse(DUMP)
    print('读到 %d 个案例\n' % len(cases))

    for c in cases:
        name = '%s %dx%dx%d' % (c['name'], c['m'], c['n'], c['k'])
        d = c['d']
        A = d['A']

        # ---------- 通用：QR / SVD / 最小二乘 ----------
        if 'Q' in d:
            Q, R = d['Q'], d['R']
            m, n = c['m'], c['n']
            # Q 应该是 m*m 正交阵，R 是 m*n 上三角
            chk(name, 'QR: A=QR', rel(Q @ R, A))
            chk(name, 'QR: Q正交', rel(Q.T @ Q, np.eye(m)))
            # 上三角性（R 的严格下三角应为 0）
            lowtri = np.tril(R, -1)
            chk(name, 'QR: R上三角', np.abs(lowtri).max() / max(np.abs(R).max(), 1.0))
            # 与 NumPy 的 QR 比：只比 R 对角线的**绝对值**。列符号是 QR 的自由度假度
            # （Householder 约定各家不同），逐元素比 Q/R 只会一直假报警；
            # 真正有意义的判据是上面那三条恒等式。
            Qr, Rr = np.linalg.qr(A)
            k = min(R.shape)
            chk(name, 'QR: 对角线绝对值与NumPy一致',
                rel(np.abs(np.diag(R[:k, :k])), np.abs(np.diag(Rr))))

        if 'S' in d:
            U, S, Vt = d['U'], d['S'], d['VT']      # U: m*k   VT: k*n   S: k
            Ur, Sr, Vtr = np.linalg.svd(A, full_matrices=False)
            k = len(S)
            chk(name, 'SVD: A=USVt', rel(U @ np.diag(S) @ Vt, A))
            chk(name, 'SVD: U列正交', rel(U.T @ U, np.eye(k)))
            chk(name, 'SVD: V正交', rel(Vt @ Vt.T, np.eye(k)))
            chk(name, 'SVD: 奇异值', rel(S, Sr))
            # 符号自由度：U 的第 j 列与 VT 的第 j 行同号翻转
            dg = np.einsum('ij,ij->j', U, Ur)
            sgn = np.sign(dg)
            sgn[sgn == 0] = 1.0
            chk(name, 'SVD: 与NumPy的U一致', rel(U, Ur * sgn))
            chk(name, 'SVD: 与NumPy的VT一致', rel(Vt, Vtr * sgn[:, None]))
            chk(name, 'SVD: 降序', max(0.0, float(np.max(np.diff(S)))))

        if 'XLS' in d:
            m, n = c['m'], c['n']
            xr = np.linalg.lstsq(A, d['B'], rcond=None)[0]
            chk(name, 'lstsq: 解一致', rel(d['XLS'], xr))
            # 残差范数不能比 NumPy 的更差（同一算法下应当同量级）
            res_mine = np.linalg.norm(A @ d['XLS'] - d['B'])
            res_np = np.linalg.norm(A @ xr - d['B'])
            scale = max(np.linalg.norm(d['B']), 1e-300)
            chk(name, 'lstsq: 残差不劣于NumPy',
                max(0.0, (res_mine - res_np) / scale))

        # ---------- 方阵：LU 派生量 ----------
        if 'DET' in d:
            m = c['m']
            det_r = np.linalg.det(A)
            scale = max(abs(det_r), 1.0)
            chk(name, 'det: 与NumPy一致', abs(d['DET'] - det_r) / scale)
            if d.get('LU_OK', 0) == 1.0:
                # LU 因子自身：P A = L U
                L = np.tril(d['LU'], -1) + np.eye(m)
                U = np.triu(d['LU'])
                piv = np.argsort(np.arange(m))   # piv 未 dump，用 det/solve 间接验证
                chk(name, 'inv: 与NumPy一致', rel(d['INV'], np.linalg.inv(A)))
                chk(name, 'inv: A·inv(A)=I', rel(A @ d['INV'], np.eye(m)))
                chk(name, 'solve: A·x=b', rel(A @ d['X'], d['B']))
                xr = np.linalg.solve(A, d['B'])
                chk(name, 'solve: 与NumPy一致', rel(d['X'], xr))
                _ = (L, U, piv)
            chk(name, 'rank: 与NumPy一致',
                abs(d['RANK'] - np.linalg.matrix_rank(A)) / max(m, 1))

        # ---------- 对称特征分解 ----------
        if 'EIGVAL' in d:
            m = c['m']
            vals, vecs = d['EIGVAL'], d['EIGVEC']
            vr = np.linalg.eigvalsh(A)
            scale = max(np.abs(vr).max(), 1.0)
            chk(name, 'eig: 特征值与NumPy一致', np.abs(vals - vr).max() / scale)
            chk(name, 'eig: V正交', rel(vecs.T @ vecs, np.eye(m)))
            chk(name, 'eig: A·V=V·Λ',
                rel(A @ vecs, vecs * vals[None, :]))
            chk(name, 'eig: 升序', max(0.0, float(-np.min(np.diff(vals)))))

        # ---------- Cholesky ----------
        if 'L' in d and c['name'] == 'spd':
            m = c['m']
            chk(name, 'cholesky: A=LL^T', rel(d['L'] @ d['L'].T, A))
            chk(name, 'cholesky: L下三角',
                np.abs(np.triu(d['L'], 1)).max() / max(np.abs(d['L']).max(), 1.0))

        # ---------- 秩亏 ----------
        if c['name'] == 'lowrank':
            m = c['m']
            chk(name, '低秩: 秩被算对',
                abs(d['RANK'] - np.linalg.matrix_rank(A, tol=1e-10 * np.abs(A).max())) / max(m, 1))
            chk(name, '低秩: lstsq 是 min-norm',
                rel(d['XLS'], np.linalg.pinv(A) @ d['B']))
            # min-norm 的真正定义：解落在行空间里，也就是与零空间正交。
            # 用 SVD 取零空间基 N 来判，而不是靠猜表达式。
            _U, _S, _Vt = np.linalg.svd(A)
            _rr = np.linalg.matrix_rank(A, tol=1e-10 * np.abs(A).max())
            _N = _Vt[_rr:].T
            chk(name, '低秩: 正交于零空间',
                np.abs(d['XLS'] @ _N).max() /
                max(np.abs(d['XLS']).max() * np.abs(_N).max(), 1e-300))

    # ---------- 汇总 ----------
    bad = [r for r in results if r[2] is not None and r[2] > TOL]
    by_case = {}
    for case, tag, err, note in results:
        d = by_case.setdefault(case, {})
        d[tag] = err

    print('%-28s %-26s %s' % ('案例', '检查项', '相对误差'))
    worst = {}
    for case in by_case:
        for tag, err in by_case[case].items():
            if err is None:
                continue
            if tag not in worst or err > worst[tag][1]:
                worst[tag] = (case, err)
    for tag in sorted(worst, key=lambda t: -worst[t][1]):
        case, err = worst[tag]
        flag = '✗ 超差' if err > TOL else ''
        print('%-28s %-26s %.3e  %s' % (case, tag, err, flag))

    print()
    if bad:
        print('✗ 有 %d / %d 项超差（阈值 %.0e）' % (len(bad), len(results), TOL))
        for case, tag, err, note in bad[:20]:
            print('   %s  %s  %.3e' % (case, tag, err))
        return 1
    print('✓ 全部通过：%d 项检查，最大相对误差 %.3e' %
          (len(results), max(e for _, _, e, _ in results if e is not None)))
    return 0


if __name__ == '__main__':
    sys.exit(main())