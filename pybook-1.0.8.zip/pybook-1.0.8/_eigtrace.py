# -*- coding: utf-8 -*-
"""盯着一块 3x3 看它到底卡在哪：子对角元下不下来了，还是窗口根本不变小。

用法：python -B _eigtrace.py
"""
import numpy as np
import _eigref as R

rng = np.random.default_rng(7)
# 复现 _eigconv 里 n=3 trial=0 的那块矩阵
for n in (1, 2):
    for trial in range(3):
        rng.standard_normal((n, n))
A = rng.standard_normal((3, 3))
print("A =\n", A)
print("真特征值 =", np.sort_complex(np.linalg.eigvals(A)))

t, q = R.hessenberg(A)
n = 3
u = 2
its = 0
zero_shift = False
print()
print("%4s %5s %12s %12s %12s %12s" % ("步", "窗口", "|t[1,0]|", "|t[2,1]|", "t[1,1]", "t[2,2]"))
while u > 0 and its < 400:
    while True:
        sub = abs(t[u, u - 1])
        nrm = abs(t[u - 1, u - 1]) + abs(t[u, u])
        if sub > np.finfo(float).eps * (nrm + sub):
            break
        t[u, u - 1] = 0.0
        u -= 1
        if u == 0:
            break
    if u == 0:
        break
    l = u - 1
    while l > 0 and t[l, l - 1] != 0.0:
        l -= 1
    if u - l == 1:
        R.rot2x2(t, q, n, u - 1, u)
        u -= 2
        continue
    if its % 10 == 0:
        print("%4d [%d,%d] %12.6e %12.6e %12.6e %12.6e" %
              (its, l, u, abs(t[1, 0]), abs(t[2, 1]), t[1, 1], t[2, 2]))
    if R.francis(t, q, n, l, u, zero_shift):
        zero_shift = not zero_shift
    its += 1
print("\n结束 u=%d its=%d" % (u, its))
print("T =\n", t)
print("‖A − QTQᵀ‖ =", np.abs(A - q @ t @ q.T).max())