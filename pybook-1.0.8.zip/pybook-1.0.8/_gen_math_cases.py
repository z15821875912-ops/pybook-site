# -*- coding: utf-8 -*-
"""_gen_math_cases.py — 把 _mt_*.pybk 编码进 tests/cases.py

30 个数值已由 _mt_verify.py 逐项对过 Python 的 math（21 项逐位相同，
9 项相对误差 <=1e-14，0 项不合格），这里只负责把输出锁成精确比对串。
"""
import io, os, subprocess, sys

PY = sys.executable

SPEC = [
    ('_mt_t1.pybk',       'T19_math_basic_ok',      'normal',
     '基础数学补齐的 30 个值：exp/log 族、反三角、双曲、cbrt/hypot/trunc/sign、'
     'fmod 与 mod 的语义差异、is_nan/is_inf（对拍 Python math：21 项逐位相同，'
     '9 项相对误差 <=1e-14）'),
    ('_mt_e1_log0.pybk',  'T19_math_log0_err',      'error',
     'mt.log(0) → 定义域报错（不静默返回 NaN：NaN 会顺着后面几步流下去）',
     ['运行时错误: 第 3 行: mt.log 的定义域是 (0, +∞)', '为什么：', '怎么改：',
      '程序异常退出，退出码 1']),
    ('_mt_e2_logneg.pybk', 'T19_math_logneg_err',   'error',
     'mt.log(-2.5) → 定义域报错，并指出 x 极小时应改用 mt.log1p',
     ['运行时错误: 第 3 行: mt.log 的定义域是 (0, +∞)，收到 -2.5', '为什么：', '怎么改：',
      '程序异常退出，退出码 1']),
    ('_mt_e3_asin.pybk',  'T19_math_asin_range_err', 'error',
     'mt.asin(1.5) → 定义域报错，并把「本意是求夹角」的出口指向 mt.atan2',
     ['运行时错误: 第 3 行: mt.asin 的定义域是 [-1, 1]，收到 1.5', 'mt.atan2', '为什么：', '怎么改：',
      '程序异常退出，退出码 1']),
    ('_mt_e4_acosh.pybk', 'T19_math_acosh_range_err', 'error',
     'mt.acosh(0.5) → 定义域报错（cosh 的值恒 >=1）',
     ['运行时错误: 第 3 行: mt.acosh 的定义域是 [1, +∞)，收到 0.5', '为什么：', '怎么改：',
      '程序异常退出，退出码 1']),
    ('_mt_e5_fmod.pybk',  'T19_math_fmod_zero_err', 'error',
     'mt.fmod(x, 0) → 除零报错（C 的 fmod 在这里会返回 NaN，拦下来）',
     ['运行时错误: 第 3 行: mt.fmod 的除数不能为 0', '为什么：', '怎么改：',
      '程序异常退出，退出码 1']),
    ('_mt_e6_notnum.pybk', 'T19_math_notnum_err',   'error',
     'mt.log("abc") → 类型错误。这一条没有行号前缀：mt.* 全族走 lib_num→lib_die，'
     '与 mt.sin/mt.sqrt 既有行为一致（定义域检查才用 rt_die 带行号三段式）',
     ['mt.log 需要数字参数', '程序异常退出，退出码 1']),
]


def run(src):
    env = {k: v for k, v in os.environ.items() if k != 'COLUMNS'}
    env['PYBOOK_NO_CACHE'] = '1'
    p = subprocess.run([PY, 'pybk_main.py', src], env=env,
                       capture_output=True, text=True, encoding='utf-8',
                       errors='replace', timeout=180)
    return (p.stdout.replace('\r\n', '\n'), p.stderr.replace('\r\n', '\n'),
            p.returncode)


lines = []
for srcf, cid, kind, expect, *rest in [(s[0], s[1], s[2], s[3], *s[4:]) for s in SPEC]:
    contains = rest[0] if rest else []
    src = io.open(srcf, encoding='utf-8', newline='').read()
    out, err, rc = run(srcf)
    d = "'id': %s, 'kind': %s, 'src': %s" % (repr(cid), repr(kind), repr(src))
    if kind == 'normal':
        if rc != 0:
            raise SystemExit('用例 %s 退出码 %d\n%s' % (cid, rc, err))
        d += ", 'out': %s, 'err': %s, 'err_contains': []" % (repr(out), repr(err))
    else:
        d += ", 'out': %s, 'exit': %d" % (repr(out), rc)
        d += ", 'err_contains': [%s]" % ', '.join(repr(s) for s in contains)
    d += ", 'expect': %s" % repr(expect)
    if kind == 'error':
        lines.append('# %s 实际 stderr 首行: %s' % (cid, repr(err.split('\n')[0])))
    lines.append('case(**{%s})' % d)

block = ('\n# ── 基础数学补齐（mt.*：v2.0 只有 sin/cos/tan/atan2，连 exp 和 log 都没有）──\n'
         + '\n'.join(lines) + '\n')

with io.open('tests/cases.py', 'a', encoding='utf-8', newline='\n') as f:
    f.write(block)
print('已追加 %d 个用例' % len(SPEC))
