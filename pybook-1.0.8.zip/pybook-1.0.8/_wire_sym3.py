# -*- coding: utf-8 -*-
"""四端注册 sym.解方程组（270 -> 271）。幂等 count==1。"""
import io, sys

def apply(s, label, old, new):
    n = s.count(old)
    if n != 1:
        sys.stderr.write('FAIL [%s] count=%d\n' % (label, n)); sys.exit(1)
    s = s.replace(old, new, 1)
    print('ok  ' + label)
    return s

# 1) 前端：LIB_CALLS 形参数
p = 'pybk_front.py'
s = io.open(p, encoding='utf-8', newline='').read()
s = apply(s, 'F1 front LIB_CALLS',
    "    'sym.格式': 2,        # (表达式, 模式)：plain/latex/unicode 渲染\n",
    "    'sym.格式': 2,        # (表达式, 模式)：plain/latex/unicode 渲染\n"
    "    'sym.解方程组': 2,    # (方程串, 变量串)：线性方程组精确解\n")
io.open(p, 'w', encoding='utf-8', newline='').write(s)

# 2) 后端：LIB_C_NAMES
p = 'pybk_code.py'
s = io.open(p, encoding='utf-8', newline='').read()
s = apply(s, 'F2 code LIB_C_NAMES',
    "        'sym.格式': 'rt_lib_sym_format',\n",
    "        'sym.格式': 'rt_lib_sym_format',\n"
    "        'sym.解方程组': 'rt_lib_sym_solve_sys',\n")
io.open(p, 'w', encoding='utf-8', newline='').write(s)

# 3) VM 表：声明 + 表行 + 计数 + 头注
p = '_vm_lib_calls.inc'
s = io.open(p, encoding='utf-8', newline='').read()
s = apply(s, 'F3 inc 声明',
    'Value rt_lib_sym_format(Value, Value);\n',
    'Value rt_lib_sym_format(Value, Value);\n'
    'Value rt_lib_sym_solve_sys(Value, Value);\n')
s = apply(s, 'F4 inc 表行',
    '    {"sym.格式", 2, (void *)rt_lib_sym_format},\n',
    '    {"sym.格式", 2, (void *)rt_lib_sym_format},\n'
    '    {"sym.解方程组", 2, (void *)rt_lib_sym_solve_sys},\n')
s = apply(s, 'F5 inc 计数',
    '#define G_LIB_CALLS_N 270\n',
    '#define G_LIB_CALLS_N 271\n')
s = apply(s, 'F6 inc 头注',
    '/* 由 LIB_CALLS + LIB_C_NAMES 生成：270 个库调用（VM 用；m3/hw/ui/mec 整前缀不含） */\n',
    '/* 由 LIB_CALLS + LIB_C_NAMES 生成：271 个库调用（VM 用；m3/hw/ui/mec 整前缀不含） */\n')
io.open(p, 'w', encoding='utf-8', newline='').write(s)

# 4) 存在性校验
c = io.open('pybk_front.py', encoding='utf-8', newline='').read()
d = io.open('pybk_code.py', encoding='utf-8', newline='').read()
e = io.open('_vm_lib_calls.inc', encoding='utf-8', newline='').read()
for label, cond in [
    ('front 注册', "'sym.解方程组': 2," in c),
    ('code 映射', "'sym.解方程组': 'rt_lib_sym_solve_sys'," in d),
    ('inc 声明', 'Value rt_lib_sym_solve_sys(Value, Value);' in e),
    ('inc 表行', '{"sym.解方程组", 2, (void *)rt_lib_sym_solve_sys},' in e),
    ('inc 计数 271', '#define G_LIB_CALLS_N 271' in e),
    ('inc 头注 271', '271 个库调用' in e),
]:
    print(('PASS ' if cond else 'FAIL ') + label)
    if not cond: sys.exit(1)

# 行尾检查
for f in ('pybk_front.py', 'pybk_code.py', '_vm_lib_calls.inc'):
    raw = open(f, 'rb').read()
    cr = raw.count(b'\r')
    print('%s: %d 行, 裸 CR %d' % (f, raw.count(b'\n'), cr))
    if cr != 0: sys.stderr.write('行尾混杂!\n'); sys.exit(1)
print('=== _wire_sym3 全部通过 ===')
