# -*- coding: utf-8 -*-
"""_fffddump.py — 把残留的 U+FFFD 连着上下文打出来（用 repr + 字节偏移）"""
import glob

BAD = b'\xef\xbf\xbd'
for p in sorted(glob.glob('_*.py')) + ['mathplus.c', 'pybook_lib.c']:
    raw = open(p, 'rb').read()
    pos = 0
    while True:
        i = raw.find(BAD, pos)
        if i < 0:
            break
        ctx = raw[max(0, i - 24):i + 30]
        print('%s @%d  %r' % (p, i, ctx.decode('utf-8', 'replace')))
        pos = i + 3
