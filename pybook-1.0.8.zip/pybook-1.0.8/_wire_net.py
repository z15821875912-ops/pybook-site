# -*- coding: utf-8 -*-
"""_wire_net.py — net.*（7）+ http.*（6：get/code/listen/serve/req/resp）接进 VM 分发表
照 _wire_entries2.py 的家法：文本锚点插入 + 已接线即跳过。前端两张表 net/http 原本就有，
这里只补 _vm_lib_calls.inc（原型 + 表项 + 计数）。"""

import io

P = '_vm_lib_calls.inc'

NEW_PROTOS = [
    'Value rt_net_listen(Value);',
    'Value rt_net_accept(Value);',
    'Value rt_net_connect(Value, Value);',
    'Value rt_net_read(Value);',
    'Value rt_net_read_block(Value);',
    'Value rt_net_write(Value, Value);',
    'Value rt_net_close(Value);',
    'Value rt_http_get(Value);',
    'Value rt_http_code(void);',
    'Value rt_http_listen(Value);',
    'Value rt_http_serve(Value);',
    'Value rt_http_req(Value);',
    'Value rt_http_resp(Value, Value, Value, Value);',
]

NEW_ENTRIES = [
    ('net.listen', 1, 'rt_net_listen'),
    ('net.accept', 1, 'rt_net_accept'),
    ('net.connect', 2, 'rt_net_connect'),
    ('net.recv', 1, 'rt_net_read'),
    ('net.readline', 1, 'rt_net_read_block'),
    ('net.send', 2, 'rt_net_write'),
    ('net.close', 1, 'rt_net_close'),
    ('http.get', 1, 'rt_http_get'),
    ('http.code', 0, 'rt_http_code'),
    ('http.listen', 1, 'rt_http_listen'),
    ('http.serve', 1, 'rt_http_serve'),
    ('http.req', 1, 'rt_http_req'),
    ('http.resp', 4, 'rt_http_resp'),
]

t = io.open(P, encoding='utf-8', newline='').read()
if 'rt_http_resp' in t:
    print('已接线过，跳过')
    raise SystemExit

# 原型：插在数组定义行之前
anchor = 'static const struct { const char *name; int arity; void *fn; } g_lib_calls[] = {'
i = t.index(anchor)
block = '\n'.join(NEW_PROTOS) + '\n'
t = t[:i] + block + t[i:]

# 表项：插在数组收尾 '};' 之前（取数组定义后第一个独立 '};' 行）
i = t.index(anchor) + len(anchor)
j = t.index('\n};', i)
lines = '\n'.join('    {"%s", %d, (void *)%s},' % e for e in NEW_ENTRIES)
t = t[:j + 1] + lines + t[j + 1:]

# 计数：243 → +13
old_n = t.index('#define G_LIB_CALLS_N ')
end = t.index('\n', old_n)
n = int(t[old_n:t.index('\n', old_n)].split()[-1])
t = t[:old_n] + '#define G_LIB_CALLS_N %d' % (n + len(NEW_ENTRIES)) + t[end:]

io.open(P, 'w', encoding='utf-8', newline='').write(t)
print('已接线 %d 个（计数 %d → %d）' % (len(NEW_ENTRIES), n, n + len(NEW_ENTRIES)))
