﻿# _embed_ptx.py -- 把一个 PTX 文件转成 C 字符串字面量，替换 pybook_gpu.c 里对应的块。
#
# 绝不手敲转义：PTX 里有 %r1 / %f16 / \n 三样东西，手敲必错，
# 而且错了 JIT 只回一句没有信息量的报错。
#
# 用法：
#     python -B _embed_ptx.py <ptx文件> <pybook_gpu.c里的块名>
# 例：
#     python -B _embed_ptx.py _ptx_PTX_8X8.ptx PTX_BODY_8X8
#
# 之前这个工具把源文件和块名都写死成 _ptx_PTX_4X4.ptx / PTX_BODY，
# 而 pybook_gpu.c 里的块早已改名成 PTX_BODY_4X4 / PTX_BODY_SHARED / PTX_BODY_8X8 ——
# 工具跟着源码一起烂掉了。现在改成参数传入。
import io
import re
import sys

if len(sys.argv) != 3:
    sys.stderr.write(__doc__)
    sys.exit(2)

SRC, VAR = sys.argv[1], sys.argv[2]
DST = 'pybook_gpu.c'

raw = io.open(SRC, encoding='utf-8').read().split('\n')

# 去掉 .version / .target / .address_size（pybook_gpu.c 用 snprintf 现场拼版本头）
# 和整段 // 注释（说明写进 C 注释，不塞进字符串）
body = []
for line in raw:
    s = line.strip()
    if s.startswith('.version') or s.startswith('.target') or s.startswith('.address_size'):
        continue
    if s.startswith('//'):
        continue
    body.append(line)

while body and not body[0].strip():
    body.pop(0)
while body and not body[-1].strip():
    body.pop()

if not body[0].lstrip().startswith('.visible'):
    raise SystemExit('第一行不是 .visible，实际是：%r' % body[0])

bad = [(i + 1, l) for i, l in enumerate(body) if any(ord(c) > 127 for c in l)]
if bad:
    raise SystemExit('第 %d 行含非 ASCII 字符：%r（PTX 注释必须是纯 ASCII）'
                     % (bad[0][0], bad[0][1]))


def c_escape(s):
    return s.replace('\\', '\\\\').replace('"', '\\"')


lines = ['static const char *%s =' % VAR]
for i, line in enumerate(body):
    tail = '\\n"' if i < len(body) - 1 else '";'
    lines.append('    "%s%s' % (c_escape(line), tail))
new_block = '\n'.join(lines)

text = io.open(DST, encoding='utf-8', newline='').read()
eol = '\r\n' if '\r\n' in text else '\n'
if eol == '\r\n':
    new_block = new_block.replace('\n', '\r\n')

anchor = 'static const char *%s =' % VAR
if text.count(anchor) != 1:
    raise SystemExit('%s 在 %s 里出现 %d 次，预期恰好 1 次'
                     % (anchor, DST, text.count(anchor)))
start = text.index(anchor)

# 块尾定位：这份源码里每行 PTX 都写成 "....\n"，最后一行不跟 \n，
# 所以收尾是 `\n    "}";`（引号在分号前面），**不是** `\n";` 也不是 `\n    "};`。
# 之前工具按 `\n";` 找，对 4x4 / shared / 8x8 三个块全都 ValueError，
# 也就是说它从来没成功跑过。
eol = '\r\n' if '\r\n' in text else '\n'
end_at = -1
mark_len = 0
for m in ('\n    "}";', eol + '    "}";'):
    i = text.find(m, start)
    if i >= 0 and (end_at < 0 or i < end_at):
        end_at, mark_len = i, len(m)
if end_at < 0:
    raise SystemExit('%s 找不到块尾标记 \'\\n    "}";\'' % VAR)
# 注意 end 要跳过整个标记（含前导换行和缩进），不是只跳 '"}";'
end = end_at + mark_len
if text[end:end + 1] not in ('', '\n', '\r'):
    raise SystemExit('块尾后面不是行尾，而是 %r' % text[end:end + 20])

out = text[:start] + new_block + text[end:]

# 校验一：把新块里的每一段 C 字符串解析出来拼回去，必须与源 PTX 逐字节相同。
# 少了这一步，「转义错了」这种事故只有在 JIT 报错时才暴露，
# 而 JIT 只会说一句没有信息量的话。
# （注意不能拿 out[start:...] 来比，那是恒真的——拼接方式保证了它等于 new_block。）
# 也不能按固定偏移截取：字面量行与行之间是**真实**的换行加缩进加引号，
# 只有正则逐段抓才能还原出字符串内容。
segs = re.findall(r'"((?:[^"\\]|\\.)*)"', new_block, re.S)
got = ''.join(segs).replace('\\n', '\n').replace('\\"', '"').replace('\\\\', '\\')
want = '\n'.join(body)
if got != want:
    gl, wl = got.split('\n'), want.split('\n')
    for i in range(max(len(gl), len(wl))):
        a = gl[i] if i < len(gl) else '<缺行>'
        b = wl[i] if i < len(wl) else '<缺行>'
        if a != b:
            raise SystemExit('转义校验失败：第 %d 行解回来是 %r，源是 %r'
                             % (i + 1, a[:80], b[:80]))
    raise SystemExit('转义校验失败：解回来 %d 行，源 %d 行' % (len(gl), len(wl)))

# 校验二：块尾之后的原内容必须一字未动（防止定位把后面的代码吃掉）
if out[start + len(new_block):] != text[end:]:
    raise SystemExit('拼接后块尾之后的内容变了，说明块尾定位越界')

io.open(DST, 'w', encoding='utf-8', newline='').write(out)
print('替换完成：%s <- %s，%d 行 PTX，行尾 %s'
      % (VAR, SRC, len(body), 'CRLF' if eol == '\r\n' else 'LF'))
print('  校验一：字面量解回来与源 PTX 逐字节相同')
print('  校验二：块尾之后的原内容一字未动')
print('  首行: %s' % body[0])
print('  末行: %s' % body[-1])
