# -*- coding: utf-8 -*-
"""一键自检：把仓库里所有 .pybk 示例都跑一遍 --check，有编不过的就红。

为什么需要它：
    别人最容易攻击的一点就是"官方示例自己都编不过"。
    这种话要么是真的，要么一句话就能证伪 —— 前提是你有一条命令能跑。
    加了这个脚本之后，示例漂移会在第一次运行时就暴露，而不是等用户在 B 站评论区告诉你。

用法：
    python tools/自检_示例可编译.py            # 检查默认的几个目录
    python tools/自检_示例可编译.py --all      # 全仓库扫（含根目录的示例）
    python tools/自检_示例可编译.py 基准 games  # 只查指定目录

退出码：0 = 全过；1 = 有编不过的。
"""
import io
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
PY = sys.executable
MAIN = os.path.join(ROOT, 'pybk_main.py')

# 默认查这些目录（根目录的示例用 --all 才查，避免把别人的试验文件也算进来）
DEFAULT_DIRS = ['基准', 'games', 'learn', '星核特效']
# 这些前缀的文件是临时试验/测试副本，不算"官方示例"
SKIP_PREFIX = ('_t_', '_probe_', '_b', '_bench')


def collect(dirs):
    out = []
    for d in dirs:
        base = os.path.join(ROOT, d)
        if not os.path.isdir(base):
            continue
        for cur, _, files in os.walk(base):
            if '__pycache__' in cur:
                continue
            for f in files:
                if not f.endswith('.pybk'):
                    continue
                if f.startswith(SKIP_PREFIX):
                    continue
                out.append(os.path.join(cur, f))
    return sorted(out)


def main():
    args = [a for a in sys.argv[1:]]
    all_mode = '--all' in args
    dirs = [a for a in args if not a.startswith('--')] or (
        ['.'] if all_mode else DEFAULT_DIRS)

    files = collect(dirs)
    if not files:
        print('没有找到 .pybk 文件（目录参数：%s）' % ' '.join(dirs))
        return 1

    print('自检：%d 个 .pybk\n' % len(files))
    bad = []
    for path in files:
        rel = os.path.relpath(path, ROOT)
        p = subprocess.run([PY, MAIN, '--check', rel], cwd=ROOT,
                           stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        out = p.stdout.decode('utf-8', 'replace').strip()
        if p.returncode == 0:
            print('  [通过] %s' % rel)
        else:
            print('  [失败] %s\n         %s' % (rel, out.replace('\n', '\n         ')))
            bad.append((rel, out))

    print('\n%d 通过 / %d 失败' % (len(files) - len(bad), len(bad)))
    if bad:
        print('\n编不过的：')
        for rel, out in bad:
            print('  %s\n    %s' % (rel, out.split('\n')[0]))
        return 1
    print('全绿 —— 示例没有漂移。')
    return 0


sys.exit(main())
