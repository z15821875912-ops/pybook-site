# -*- coding: utf-8 -*-
"""pybktl release —— PYbook 的加强版发布打包（版本号 + 变更盖章 + 清洁 zip）。

一门语言发版要动三处：PYBOOK_VERSION 常量、CHANGELOG 章节、README 版本行——
手改必漏（1.0.7 发布日 --version 还打着 1.0.6）。本命令一次做全：

    pybktl release [--major|--minor|--patch] [--note "描述"]
                   [--out 目录] [--dry-run] [--skip-bump]

  ① 版本号：读 pybk_main.py 的 PYBOOK_VERSION，按位升级后写回
  ② 盖章：CHANGELOG 顶部同版本节的（待发布）换成日期；README「当前版本」行同步
  ③ 打包：白名单收集（工具链 + IDE + 运行时 DLL + 文档 + 示例/测试/基准），
     排除工作区杂物（_* / *.bak / *.log / __pycache__ / exe_cache / rt_cache /
     shots* / .git / build_tmp…），包内写 清单.txt
  ④ 报告：旧→新版本、zip 体积、条目数、没打包的工作区杂物统计（仓库卫生）

白名单原则：宁可少带（用户找我要），不带垃圾（1.7GB 工作区里 229 个临时件）。
"""
import argparse
import datetime
import glob
import os
import re
import zipfile


def out(msg=""):
    print(msg)


def err(msg):
    print(msg)
    return msg

# ---------- 收集规则 ----------

ROOT_FILES = [
    # 工具链（语言本体）
    "pybk_main.py", "pybk_front.py", "pybk_code.py", "pybk_bc.py",
    "pybk_build.py", "ide.py", "main.py", "smokeroor.py",
    "mathplus.c", "mathplus.h",
    # IDE / 编辑器
    "PYbookIDE.exe", "editor.exe", "ide_icon.ico",
    "ide启动器.c", "编辑器.c", "PYbook游戏机.bat", "运行PYbookIDE.bat",
    # 运行时 DLL / VM
    "SDL2.dll", "libgcc_s_seh-1.dll", "libwinpthread-1.dll", "pyvm.exe",
    # 文档
    "PYBOOK_AI.md", "README.md", "README_MATHPLUS.md", "CHANGELOG.md",
    "语法手册.md", "LICENSE", "llms.txt", "GPU_DESIGN.md",
]

ROOT_GLOBS = ["*.pybk", "*.bat"]          # 根级示例与启动器（_ 前缀被排除规则过滤）

DIRS = ["games", "tests", "tools", "learn", "基准", "scenes", "mm_tests", "模板"]

EXCLUDE_NAME = re.compile(
    r"^(_|out_.+\.c$|app_.+\.exe$)|(__pycache__|\.pyc$|\.bak|\.log$|~$)")
EXCLUDE_DIRS = {
    "__pycache__", ".git", "exe_cache", "rt_cache", "build_tmp",
    "_session_backup", "ucrt64", "发布打包_102", "exe", "shots",
}


def _is_junk(name):
    # search 不是 match：后缀规则（\.log$ / ~$ / \.pyc$）要能命中串尾
    return bool(EXCLUDE_NAME.search(name))


def read_version(root):
    """版本单一来源：根目录 VERSION 文件（另一会话 1.0.14 起的约定）；
    没有就回退读 pybk_main.py 的 PYBOOK_VERSION 常量（老布局）。"""
    vp = os.path.join(root, "VERSION")
    if os.path.isfile(vp):
        return open(vp, encoding="utf-8").read().strip()
    src = open(os.path.join(root, "pybk_main.py"), encoding="utf-8").read()
    m = re.search(r"PYBOOK_VERSION\s*=\s*'([\d.]+)'", src)
    if not m:
        raise SystemExit("✗ 找不到 VERSION 文件，也找不到 PYBOOK_VERSION 常量")
    return m.group(1)


def bump(ver, part):
    a, b, c = (ver.split(".") + ["0", "0"])[:3]
    a, b, c = int(a), int(b), int(c)
    if part == "major":
        return f"{a + 1}.0.0"
    if part == "minor":
        return f"{a}.{b + 1}.0"
    return f"{a}.{b}.{c + 1}"


def write_version(root, ver):
    vp = os.path.join(root, "VERSION")
    if os.path.isfile(vp):
        open(vp, "w", encoding="utf-8", newline="").write(ver + "\n")
        return
    p = os.path.join(root, "pybk_main.py")
    src = open(p, encoding="utf-8").read()
    src = re.sub(r"(PYBOOK_VERSION\s*=\s*')[\d.]+(')", r"\g<1>%s\g<2>" % ver, src, count=1)
    open(p, "w", encoding="utf-8", newline="").write(src)


def stamp_changelog(root, ver, note, today):
    p = os.path.join(root, "CHANGELOG.md")
    if not os.path.isfile(p):
        return "· 无 CHANGELOG.md，跳过盖章"
    t = open(p, encoding="utf-8").read()
    m = re.search(r"^## %s[^\n]*$" % re.escape(ver), t, re.M)
    if m:
        line = m.group(0)
        if "待发布" in line:
            t = t.replace(line, line.replace("（待发布）", "（%s）" % today), 1)
            open(p, "w", encoding="utf-8", newline="").write(t)
            return "✓ 已给 %s 章节盖发布日期 %s" % (ver, today)
        return "· %s 章节已发布过，不动" % ver
    head = f"## {ver} —— {note}（{today}）\n\n> 由 pybktl release 自动建档。\n\n"
    i = t.find("\n## ")
    if i < 0:
        t = t.rstrip() + "\n\n" + head
    else:
        t = t[:i + 1] + head + t[i + 1:]
    open(p, "w", encoding="utf-8", newline="").write(t)
    return "✓ 已新建 %s 章节" % ver


def sync_readme(root, ver):
    p = os.path.join(root, "README.md")
    if not os.path.isfile(p):
        return
    t = open(p, encoding="utf-8").read()
    t2, n = re.subn(r"当前版本 \*\*[\d.]+\*\*", "当前版本 **%s**" % ver, t, count=1)
    if n:
        open(p, "w", encoding="utf-8", newline="").write(t2)
        out(f"✓ README 版本行 → {ver}")


def collect(root):
    """返回 (打包相对路径列表, 排除的杂物统计 [ (名, 大小) ])。"""
    files, junk = [], []

    for name in ROOT_FILES:
        p = os.path.join(root, name)
        if os.path.isfile(p):
            files.append(name)

    for pat in ROOT_GLOBS:
        for p in glob.glob(os.path.join(root, pat)):
            name = os.path.basename(p)
            if _is_junk(name):
                junk.append((name, os.path.getsize(p)))
                continue
            if os.path.isfile(p) and name not in files:
                files.append(name)

    for d in DIRS:
        dp = os.path.join(root, d)
        if not os.path.isdir(dp):
            continue
        for dirpath, dirnames, filenames in os.walk(dp):
            dirnames[:] = [x for x in dirnames
                           if not _is_junk(x) and x not in EXCLUDE_DIRS]
            for fn in filenames:
                if _is_junk(fn):
                    continue
                rel = os.path.relpath(os.path.join(dirpath, fn), root)
                files.append(rel.replace(os.sep, "/"))

    # 根级杂物统计（仓库卫生报告用）
    for name in os.listdir(root):
        p = os.path.join(root, name)
        if os.path.isfile(p) and _is_junk(name):
            try:
                junk.append((name, os.path.getsize(p)))
            except OSError:
                pass
    files = sorted(set(files))
    return files, junk


def cmd_release(args):
    root = os.getcwd()
    if not os.path.isfile(os.path.join(root, "pybk_main.py")):
        err("✗ 请在 PYbook 仓库根目录运行（找不到 pybk_main.py）")
        return 1

    old = read_version(root)
    ver = old if args.skip_bump else bump(old, args.part)
    today = datetime.date.today().isoformat()
    out(f"· 版本：{old} → {ver}" + ("（--skip-bump，仅打包）" if args.skip_bump else ""))

    files, junk = collect(root)
    if not files:
        err("✗ 白名单一个文件都没收到，检查 collect 规则")
        return 1

    if args.dry_run:
        out(f"[dry-run] 将打包 {len(files)} 个条目：")
        for f in files[:40]:
            out("   " + f)
        if len(files) > 40:
            out(f"   … 以及另外 {len(files) - 40} 个")
        out(f"[dry-run] 版本将 {old} → {ver}；CHANGELOG/README 将同步")
        return 0

    write_version(root, ver)
    out(f"✓ pybk_main.py PYBOOK_VERSION = {ver}")
    out(stamp_changelog(root, ver, args.note or "功能加强", today))
    sync_readme(root, ver)

    outdir = args.out or "."
    os.makedirs(outdir, exist_ok=True)
    zippath = os.path.join(outdir, f"pybook-{ver}.zip")
    total = 0
    with zipfile.ZipFile(zippath, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        manifest = [f"PYbook {ver} 发布包（pybktl release 生成 {today}）",
                    f"条目 {len(files)} 个", ""]
        for rel in files:
            src = os.path.join(root, rel)
            if not os.path.isfile(src):
                continue
            z.write(src, rel)
            total += os.path.getsize(src)
            manifest.append(rel)
        junk_note = (f"{len(junk)} 个 / {sum(s for _, s in junk) / 1e6:.1f} MB"
                     if junk else "无")
        manifest += ["", f"工作区杂物（未打包）：{junk_note}"]
        z.writestr("清单.txt", "\n".join(manifest))

    zsize = os.path.getsize(zippath)

    logp = os.path.join(root, "发布日志.md")
    author = os.environ.get("PYBOOK_AUTHOR") or os.environ.get("USERNAME") or "未知"
    with open(logp, "a", encoding="utf-8") as lf:
        if not os.path.isfile(logp) or os.path.getsize(logp) == 0:
            lf.write("# 发布日志\n\n")
        lf.write(f"- {today} {author}：pybook-{ver}.zip（{len(files)} 个文件，"
                 f"{zsize / 1e6:.1f} MB）—— {note or '无说明'}\n")
    out("✓ 已记入 发布日志.md")

    out(f"✓ 打包完成：{zippath}")
    out(f"  条目 {len(files)} 个 ｜ 原始 {total / 1e6:.1f} MB → 压缩 {zsize / 1e6:.1f} MB")
    if junk:
        jsize = sum(s for _, s in junk)
        out(f"  未打包的工作区杂物：{len(junk)} 个 / {jsize / 1e6:.1f} MB（仓库卫生提示）")
    return 0


def build_subparser(sub):
    pr = sub.add_parser("release", help="加强版发布：版本号三处同步 + CHANGELOG 盖章 + 清洁 zip 打包")
    pr.add_argument("--major", dest="part", action="store_const", const="major")
    pr.add_argument("--minor", dest="part", action="store_const", const="minor")
    pr.add_argument("--patch", dest="part", action="store_const", const="patch", default="patch")
    pr.add_argument("--note", default="", help="CHANGELOG 新章节标题描述")
    pr.add_argument("--out", default=".", help="zip 输出目录（默认当前目录）")
    pr.add_argument("--dry-run", action="store_true", help="只列清单不写任何文件")
    pr.add_argument("--skip-bump", action="store_true", help="不升版本号，仅按当前版本打包")
    pr.set_defaults(func=cmd_release)
