# LookAround

**文件夹级开发日志循环** —— 监控文件改动（含内容 diff）、自动记录每次 `run`/`build`/`check`/`smoke` 的输出与运行时错误（**错误翻成人话**）、待办清单、日志筛选、团队协作报告。

零依赖（纯标准库）、零侵入（不改被监控的代码）、关掉即不留痕（只留两个 md 文件）。

---

## 怎么用

LookAround 是在**目标文件夹**里开启的，所以先 `cd` 到你的项目：

```bash
# 方式一：把本目录加进 PATH，然后
cd 你的项目文件夹
lookaround                      # 开启（前台监控，Ctrl+C 停止）

# 方式二：不加 PATH，直接用绝对路径
cd 你的项目文件夹
python C:/Users/zhuli/Desktop/lookaround/pybktl.py lookaround
```

开启后，这个文件夹里所有 `pybktl run / build / check / smoke` 都会被自动记录，文件改动也会自动进日志。

### 常用命令（在目标文件夹里执行）

| 命令 | 作用 |
|---|---|
| `pybktl todo add "要做的事"` | 加待办（watcher 不用重启，中途也能加） |
| `pybktl todo list` | 待办清单（含完成状态） |
| `pybktl todo show 2` | 看某条待办详情 + 它的关联运行 |
| `pybktl run x.pybk --todo 2` | 运行时把这次运行**关联到待办 #2** |
| `pybktl lookaround log --type run --tail 20` | 看最后 20 条运行记录 |
| `pybktl lookaround log --file a.pybk` | 只看涉及某文件的事件 |
| `pybktl lookaround log --since 2026-10-05` | 按时间筛选 |
| `pybktl lookaround report --by 张三` | 团队协作报告 |
| `pybktl lookaround report --out 报告.md` | 报告写成文件（可直接共享给团队） |

---

## 它记什么

- **文件改动**：新建 / 修改 / 删除 + 文本文件的内容 diff（超 200KB 或 300 行自动截断）
- **每次运行**：命令、退出码、完整输出；失败时错误**翻成人话**（英文原文附在后面供深挖）
- **待办**：`add` / `done` / `rm` / `list` / `show`
- **忽略名单**：文件夹里放 `.lookaroundignore`（每行一条 glob，`#` 开头为注释）屏蔽 `.pybc`、临时文件等噪点

## 贴心细节（均已实测）

| 能力 | 说明 |
|---|---|
| **强杀防呆** | 标记里存 watcher 的 PID；你 `kill` 之后残留标记会被**自动识别清理**，不会误判"循环还开着" |
| **日志轮转** | md 超过 2000 行自动轮转为 `lookaround.1.md`，不会无限膨胀（阈值可用环境变量 `LOOKAROUND_MAX_LINES` 调） |
| **错误聚合** | 报告里同一逻辑错误**聚合成一条并统计次数**（自动剥离 gcc 临时文件名，避免同一错误被拆成多条） |
| **待办↔运行跳转** | `run --todo N` 建立关联，`todo show N` 从待办直接跳到它的运行现场 |
| **控制台直达** | `pybktl run` 等命令旁路输出，不干扰程序本身的 stdout |

---

## 文件说明

| 文件 | 作用 |
|---|---|
| `pybktl.py` | 工具链本体，LookAround 是它的一个子命令 |
| `lookaround.py` | LookAround 核心，也可独立运行 `python lookaround.py` |
| `lookaround.cmd` | 双击启动器（需与 `pybktl.py` 同目录） |
| `实测产物/` | 一次完整实测留下的日志、待办、团队报告与测试程序，可直接翻阅效果 |

> 原件仍在工具链目录（`WorkBuddy/.../pybktl/`），因为 `pybktl.py` 需要 `import lookaround`；**桌面这份是自包含副本**，可直接使用。
> 整合包版本见 `C:/Users/zhuli/Desktop/pybook_integrated_bundle.zip`（`pybktl/` 内含同样三个文件）。

## 环境要求

Python 3.8+，**零第三方依赖**。
