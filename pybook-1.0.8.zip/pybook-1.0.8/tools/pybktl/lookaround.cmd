@echo off
REM LookAround 启动器：在任意文件夹里 cd 进来后敲 `lookaround` 即可开启日志循环。
REM 用法：把本文件所在目录加进 PATH，或直接在该目录里运行 `lookaround`。
python "%~dp0pybktl.py" lookaround %*
