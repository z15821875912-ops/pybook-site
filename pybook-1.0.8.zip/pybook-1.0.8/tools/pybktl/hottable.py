"""HotTable —— 文件热度台账 / 「该先改哪个文件」排队表。

和 LookAround 同形态：`pybktl hottable watch` 在任意文件夹里开着就一直盯着，
但它记的不是流水账，而是**结构化事件**（`hottable.jsonl`，一行一条 JSON），
因为热度表要做聚合，解析 Markdown 太脆。

记三类事件：
- `change`  文件 创建/修改/删除（含大小、行数、相对根目录的路径）
- `run`     在该文件夹跑 run/build/check/smoke 的结果（成功/失败、退出码、耗时、错误摘要）
- `note`    手动记一笔（watcher 开关等）

打分原则：**每一个分量都在表里单独列出来**，不是一个黑盒数字。
你看到某文件热度 87，就能逐列看出这 87 是哪几项加出来的。

  热度 = 30×近期改动 + 25×失败压力 + 20×运行压力 + 15×改动密度 + 10×代码体量

  近期改动 = Σ 0.5^(距今小时/24)      24 小时半衰期，刚改的算满，三天前的只剩 1/8
  失败压力 = Σ 0.5^(距今小时/24) × (1 + 2×失败率)   反复失败的权重翻倍
  运行压力 = Σ 0.5^(距今小时/24)      你一直在跑它，说明它是热点入口
  改动密度 = 近期改动 ÷ 存活小时       改得又猛又不稳 = 半成品
  代码体量 = log10(行数+1)            大文件天然更容易出事

用法：
  pybktl hottable              热度排行榜（前 20）
  pybktl hottable 摆杆.pybk     单文件详情表（各分量拆开看）
  pybktl hottable --top 50     看前 50
  pybktl hottable --since 3d   只统计最近 3 天（支持 12h / 3d / 2026-10-18）
  pybktl hottable --json       机器可读
  pybktl hottable watch        前台盯盘，Ctrl+C 停

设计取舍：
- 零依赖（纯标准库，轮询式监控，和 LookAround 同一套）。
- 独立于 LookAround：`.hottable` 标记 + `hottable.jsonl` 存储，两边可各开各的。
  代价是同时开两个 watcher 会各扫一遍目录树（都是每秒一次，通常无所谓）。
- watcher 不记「运行」——运行由 pybktl 的 run/build/check/smoke 主动写，
  和 LookAround 里 watcher 与运行进程解耦是同一个道理。
"""

import json
import math
import os
import re
import fnmatch
import subprocess
import sys
import time
import unicodedata
from datetime import datetime

# 从 lookaround 借两样现成的，别写两份：PID 存活探测（同一套标记文件语义）、
# 错误翻人话（和 LookAround 日志里显示的完全一致）、路径忽略匹配
from lookaround import _pid_alive, _humanize_error, _is_ignored

MARKER = ".hottable"             # 开启标记（存 watcher PID）
STORE = "hottable.jsonl"         # 事件台账（一行一条 JSON）
MAX_EVENTS = int(os.environ.get("HOTTABLE_MAX_EVENTS", "50000"))
POLL_S = float(os.environ.get("HOTTABLE_POLL", "10"))  # 轮询间隔（秒）

# 默认忽略：构建产物 / 别人的副本 / 出图。
# 为什么要默认而不是留空：pybook 根目录实测 16535 个文件，全树 stat 一遍要 5.0 秒。
# 排除 build_tmp(9860) + 发布打包_102(4122) 后只剩 1855 个，扫描降到 0.67 秒；
# 配合默认 10 秒轮询，长期占用约 6.7% 单核。
# 想全都要就 `hottable watch --all`；想改就在 .hottableignore 里追加（可覆盖默认值）。
DEFAULT_IGNORE = (
    "build_tmp/", "发布打包_102/", "_session_backup/", "_pm_demo/", "_team/",
    "objtest/", "ucrt64/", "_归档/", "共享历史/",
    "shots_*/", "shots*/",
    "*.exe", "*.o", "*.obj", "*.pyc", "*.pdb", "*.ilk",
    "out_*.c",            # gcc 编译临时文件（pybktl build 在 cwd 里现生成现删）
    "*.tmp", "tmp_*",
    "*.revbak", "*.bak", "*.orig", "*~",   # 编辑器/回滚残留，会和真文件同步被改，计两次热度
)
IGNORE_FILE = ".hottableignore"  # 用户追加的忽略规则（每行一条 glob，# 注释）

_HALF_LIFE_PLACEHOLDER = None


# ---------------------------------------------------------------------------
# 忽略规则（默认集 + .hottableignore）
# ---------------------------------------------------------------------------
def _load_ignore(root, use_defaults=True):
    """默认忽略 + .hottableignore 里追加的规则。use_defaults=False 时只要用户写的。"""
    pats = list(DEFAULT_IGNORE) if use_defaults else []
    try:
        with open(os.path.join(root, IGNORE_FILE), "r", encoding="utf-8") as f:
            for ln in f:
                s = ln.strip()
                if s and not s.startswith("#"):
                    pats.append(s)
    except OSError:
        pass
    return pats


def _dir_ignored(name, pats):
    """目录名是否命中忽略规则（用于 os.walk 剪枝，比逐文件判快得多）。"""
    for pat in pats:
        p = pat.rstrip("/")
        if not p:
            continue
        if fnmatch.fnmatch(name, p) or name == p:
            return True
    return False

HALF_LIFE_H = 24.0                # 时间衰减半衰期（小时）

# 热度分量：(打分键, 权重, 展示名)。**打分键 = stats 里的分量键**，
# 归一化后的键统一是 该键 + "_norm"（注意不是 "_n"——chg_n/run_n 已经是「次数」，
# 早期版本归一值写回同名把计数覆盖了，表格里「改动 0.5000038」就是这么来的）。
COMPONENTS = (
    ("chg",     30.0, "近期改动"),   # Σ 0.5^(距今小时/24)
    ("fail_s",  25.0, "失败压力"),   # Σ 衰减 × (1 + 2×失败率)
    ("run",     20.0, "运行压力"),   # Σ 0.5^(距今小时/24)
    ("churn_s", 15.0, "改动密度"),   # 近期改动 ÷ 存活小时
    ("loc_s",   10.0, "代码体量"),   # log10(行数+1)
)
WEIGHTS = {k: w for k, w, _ in COMPONENTS}
WEIGHT_LABELS = {k: lab for k, _, lab in COMPONENTS}

_SKIP_DIRS = ("exe_cache", "rt_cache", "__pycache__", ".git", "node_modules")

# ---- 批量噪声治理（查询时做，所以对已有台账也立刻生效）----
#
# 为什么必须有：实测一轮 `pybktl test --all` 回归会挨个碰 230 个 tests/*.pybk。
# 每个文件各记一条 change，于是「一次自动化运行」变成 230 个文件各拿 16 分热度，
# 整张榜前 12 有 5 个是测试用例，真正在被开发的文件反而被挤下去。
#
# 怎么判「自动化」：改动在时间上扎堆（60 秒内）且涉及 >=8 个不同文件 = 一次批量运行。
# 这种批次**不计入任何单文件热度**，但会作为一条 `batch` 留在表里，藏不住东西。
BATCH_GAP_S = 60.0        # 相邻改动间隔小于它就算同一批
BATCH_MIN_FILES = 8       # 一批里涉及这么多不同文件就判定为自动化批量
BURST_WINDOW_S = 300.0    # 同一文件的多次改动跨这么长时间也算一次「爆发」


# ---------------------------------------------------------------------------
# 位置解析（和 LookAround 同构：向上找标记 + 强杀残留自动清理）
# ---------------------------------------------------------------------------
def _watcher_pid(root):
    try:
        with open(os.path.join(root, MARKER), "r") as f:
            return int(f.read().strip() or "0") or None
    except (OSError, ValueError):
        return None


def find_hottable_root(start=None, reap=True, explicit=None):
    """定位台账所在文件夹。

    优先级：explicit（`--root`） > 环境变量 HOTTABLE_ROOT > 从 start/cwd 逐级向上找。
    reap=True 时自动清理「标记在但进程已死」的残留。找不到返回 None。

    为什么要有 explicit / 环境变量：`find_*_root` 只向上找，所以在 pybook 之外的
    任何目录敲 `pybktl hottable` 都找不到台账。「谁都能访问」就得给一个绝对入口。"""
    for c in (explicit, os.environ.get("HOTTABLE_ROOT")):
        if not c:
            continue
        d = os.path.abspath(c)
        if os.path.isdir(d):
            return d
    candidates = []
    if start:
        candidates.append(os.path.abspath(start))
    candidates.append(os.path.abspath(os.getcwd()))
    for c in candidates:
        d = c
        while True:
            mp = os.path.join(d, MARKER)
            if os.path.exists(mp):
                alive = False
                if reap:
                    pid = _watcher_pid(d)
                    alive = (pid is not None) and _pid_alive(pid)
                if not reap or alive:
                    return d
                try:
                    os.remove(mp)
                except OSError:
                    pass
            parent = os.path.dirname(d)
            if parent == d:
                break
            d = parent
    return None


# ---------------------------------------------------------------------------
# 事件写入
# ---------------------------------------------------------------------------
def _ts():
    return time.strftime("%Y-%m-%d %H:%M:%S")


def _store_path(root):
    return os.path.join(root, STORE)


def _rel(root, path):
    """绝对/相对路径 -> 相对 root 的 posix 风格路径（跨平台一致）。"""
    try:
        return os.path.relpath(os.path.abspath(path), root).replace("\\", "/")
    except ValueError:
        return str(path).replace("\\", "/")


def _trim_store(path):
    """台账超过 MAX_EVENTS 行时保留最后 MAX_EVENTS 行（启动时调一次即可）。"""
    try:
        if MAX_EVENTS <= 0 or not os.path.exists(path):
            return
        with open(path, "r", encoding="utf-8") as f:
            lines = f.readlines()
        if len(lines) <= MAX_EVENTS:
            return
        with open(path, "w", encoding="utf-8") as f:
            f.writelines(lines[-MAX_EVENTS:])
    except OSError:
        pass


def record(root, kind, **fields):
    """往台账追加一条事件。返回写入与否。"""
    ev = {"ts": time.time(), "kind": kind}
    ev.update(fields)
    try:
        with open(_store_path(root), "a", encoding="utf-8") as f:
            f.write(json.dumps(ev, ensure_ascii=False) + "\n")
        return True
    except OSError:
        return False


def _count_lines(path):
    """文本文件行数；二进制/读不到返回 None。"""
    try:
        if os.path.getsize(path) > 2 * 1024 * 1024:
            return None
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            return sum(1 for _ in f)
    except OSError:
        return None


def log_change(root, path, event, size=None):
    """记录一次文件改动（event: created / modified / deleted）。"""
    rel = _rel(root, path)
    lines = None if event == "deleted" else _count_lines(path)
    record(root, "change", path=rel, ev=event, size=size, lines=lines)


def log_run(root, script, rc, stdout="", stderr="", cmd="", dur=None, todo_id=None):
    """记录一次运行（成功/失败 + 错误摘要）。

    错误只留「人话」首条，不存全文——台账是给聚合用的，不是给翻日志的。"""
    rel = _rel(root, script)
    ok = (rc == 0)
    err = None
    if not ok:
        raw = (stderr or "").strip() or (stdout or "").strip()
        if raw:
            human, _ = _humanize_error(raw)
            if human:
                # 剥掉 gcc 临时文件名（out_xxxx.c），否则同一逻辑错误会散成多条
                err = re.sub(r"（位置：[^）]*）", "", human[0][2:].strip())[:300]
            else:
                err = raw.splitlines()[-1][:300]
    record(root, "run", path=rel, ok=ok, rc=rc, dur=dur,
           cmd=cmd, err=err, todo=todo_id)


def log_note(root, text):
    record(root, "note", text=text)


# ---------------------------------------------------------------------------
# 读取 + 打分
# ---------------------------------------------------------------------------
def load_events(root, since=None):
    """读取台账事件（可按时间过滤）。坏行直接跳过（台账可能被手工改过）。"""
    p = _store_path(root)
    evs = []
    if not os.path.exists(p):
        return evs
    try:
        with open(p, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    e = json.loads(line)
                except ValueError:
                    continue
                if isinstance(e, dict) and "ts" in e and "kind" in e:
                    evs.append(e)
    except OSError:
        pass
    if since is not None:
        evs = [e for e in evs if e["ts"] >= since]
    evs.sort(key=lambda e: e["ts"])
    return evs


def parse_since(s):
    """解析 --since：12h / 3d / 2026-10-18 / 2026-10-18 10:30:00。返回时间戳或 None。"""
    s = (s or "").strip()
    if not s:
        return None
    m = re.fullmatch(r"(\d+)\s*([hdm])", s, re.I)
    if m:
        n = int(m.group(1))
        mult = {"h": 3600, "d": 86400, "m": 60}[m.group(2).lower()]
        return time.time() - n * mult
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%Y-%m-%d"):
        try:
            return datetime.strptime(s, fmt).timestamp()
        except ValueError:
            continue
    return None


def _decay(ts, now, half=HALF_LIFE_H):
    """时间衰减：距今 dt 小时 → 0.5^(dt/half)。半衰期 24h。"""
    dt_h = max(0.0, (now - ts) / 3600.0)
    return 0.5 ** (dt_h / half)


def cluster_events(events, gap_s=BATCH_GAP_S):
    """把时间上扎堆的改动聚成「批」。返回 (批次列表, 未入批的改动列表)。

    批次 = [(首时间, [(ts, path, ev), ...]), ...]。按时间顺序贪心成批：
    下一条与本批最后一条相差超过 gap_s 就开新批。

    为什么在**查询时**做而不是 watcher 写入时：① 对已有台账立刻生效，不用重跑；
    ② watcher 那时不知道「这批是不是回归跑出来的」，硬猜会误判。
    """
    changes = sorted((e for e in events if e.get("kind") == "change" and e.get("path")),
                     key=lambda e: e["ts"])
    batches, rest = [], []
    cur = []
    for e in changes:
        if cur and (e["ts"] - cur[-1]["ts"]) > gap_s:
            batches.append(cur)
            cur = []
        cur.append(e)
    if cur:
        batches.append(cur)
    return batches, rest


def is_automation_batch(batch):
    """这批改动是不是一次自动化运行（碰了太多不同文件）。"""
    return len({e["path"] for e in batch}) >= BATCH_MIN_FILES


def collapse_bursts(batch):
    """把同一文件的多次改动压成一条（带次数）。返回 [(path, ev, [ts...]), ...]。

    同一文件挤在一起改 = 编辑器自动保存 / 反复保存 / 脚本反复重写，
    不是「改了这么多次」，所以不该按次数线性计热度。"""
    by = {}
    for e in batch:
        by.setdefault((e["path"], e.get("ev", "?")), []).append(e["ts"])
    out = []
    for (path, ev), tss in by.items():
        tss.sort()
        cur = [tss[0]]
        for t in tss[1:]:
            if (t - cur[-1]) <= BURST_WINDOW_S:
                cur.append(t)
            else:
                out.append((path, ev, cur))
                cur = [t]
        out.append((path, ev, cur))
    return out


def score(events, now=None, root=None):
    """把事件流聚合成 {文件: 分量字典}，并算好归一化后的热度。

    返回 (rows, stats, batches)；rows 已按热度降序排好，batches 是被判为自动化批次的列表。
    每行：path / 热度 / 各分量原值与归一值 / 计数 / 首末时间。"""
    now = now or time.time()
    agg = {}

    def slot(path):
        return agg.setdefault(path, {
            "path": path, "chg": 0.0, "run": 0.0, "fail": 0.0,
            "chg_n": 0, "run_n": 0, "fail_n": 0,
            "first": None, "last": None,
        })

    # ---- 1. 改动：先成批，自动化批次整批不计入热度 ----
    batches, _ = cluster_events(events)
    auto_batches = []
    for b in batches:
        if is_automation_batch(b):
            auto_batches.append(b)
            continue
        for path, ev, tss in collapse_bursts(b):
            if ev == "deleted":
                for ts in tss:                 # 删除也算改动，逐条记
                    s = slot(path)
                    s["chg"] += _decay(ts, now)
                    s["chg_n"] += 1
                    s["first"] = ts if s["first"] is None else min(s["first"], ts)
                    s["last"] = ts if s["last"] is None else max(s["last"], ts)
                continue
            # 一次爆发记 1 次改动，但用 log2(次数+1) 记权重：连着保存 20 次
            # 不该比保存 1 次热 20 倍，也不该完全抹平
            s = slot(path)
            s["chg"] += math.log2(len(tss) + 1) * _decay(tss[-1], now)
            s["chg_n"] += 1
            s["burst_max"] = max(s.get("burst_max", 0), len(tss))
            s["first"] = tss[0] if s["first"] is None else min(s["first"], tss[0])
            s["last"] = tss[-1] if s["last"] is None else max(s["last"], tss[-1])

    # ---- 2. 运行：成批逻辑不适用，逐条记 ----
    for e in events:
        if e.get("kind") != "run" or not e.get("path"):
            continue
        s = slot(e["path"])
        d = _decay(e["ts"], now)
        s["run"] += d
        s["run_n"] += 1
        if not e.get("ok", True):
            s["fail"] += d
            s["fail_n"] += 1
        s["first"] = e["ts"] if s["first"] is None else min(s["first"], e["ts"])
        s["last"] = e["ts"] if s["last"] is None else max(s["last"], e["ts"])

    rows = []
    for s in agg.values():
        failrate = (s["fail_n"] / s["run_n"]) if s["run_n"] else 0.0
        # 失败压力：反复失败的额外加权
        fail_s = s["fail"] * (1.0 + 2.0 * failrate)
        # 改动密度：近期改动 ÷ 存活小时（最少 1h），衡量「改得又猛又不稳」
        span_h = max(1.0, ((s["last"] or 0) - (s["first"] or 0)) / 3600.0)
        churn_s = s["chg"] / span_h
        # 体量：取磁盘上当前行数（文件已删则用最后事件记录的行数）
        loc = None
        if root:
            fp = os.path.join(root, s["path"].replace("/", os.sep))
            loc = _count_lines(fp)
        if loc is None:
            loc = 0
        loc_s = math.log10(loc + 1)
        s.update(failrate=failrate, fail_s=fail_s, churn_s=churn_s,
                 loc=loc, loc_s=loc_s, span_h=span_h)
        rows.append(s)

    # 归一化：各分量除以本组最大值（全 0 时该项记 0）
    for key, _w, _lab in COMPONENTS:
        mx = max((r[key] for r in rows), default=0.0)
        for r in rows:
            r[key + "_norm"] = (r[key] / mx) if mx > 0 else 0.0

    for r in rows:
        r["heat"] = sum(WEIGHTS[k] * r[k + "_norm"] for k, _w, _lab in COMPONENTS)
    rows.sort(key=lambda r: -r["heat"])
    batches = [{"ts": b[0]["ts"], "end": b[-1]["ts"], "n": len(b),
                "files": sorted({e["path"] for e in b})}
               for b in auto_batches]
    stats = {"files": len(rows), "events": len(events),
             "batches": len(batches),
             "suppressed": sum(b["n"] for b in batches),
             "since": min((e["ts"] for e in events), default=None),
             "last": max((e["ts"] for e in events), default=None)}
    return rows, stats, batches


# ---------------------------------------------------------------------------
# 终端表格渲染（中文按两列宽算）
# ---------------------------------------------------------------------------
def _dw(s):
    """字符串的终端显示宽度（东亚全角算 2）。"""
    return sum(2 if unicodedata.east_asian_width(c) in ("W", "F") else 1
               for c in str(s))


def _pad(s, w, right=False):
    s = str(s)
    gap = max(0, w - _dw(s))
    return (" " * gap + s) if right else (s + " " * gap)


def _fmt_ts(ts):
    return datetime.fromtimestamp(ts).strftime("%m-%d %H:%M") if ts else "-"


def _fmt_age(ts, now):
    if not ts:
        return "-"
    dt_h = max(0.0, (now - ts) / 3600.0)
    if dt_h < 1:
        return "%d 分钟前" % max(1, int(dt_h * 60))
    if dt_h < 48:
        return "%.0f 小时前" % dt_h
    return "%.1f 天前" % (dt_h / 24.0)


def render_table(root, rows, stats, now, title, note="", batches=None):
    """渲染排行榜表格（字符串）。"""
    out = ["# HotTable · %s" % title, ""]
    out.append("- 目录：`%s`" % root)
    out.append("- 统计范围：%s ~ %s（%d 条事件 / %d 个文件）" % (
        _fmt_ts(stats["since"]), _fmt_ts(stats["last"]), stats["events"], stats["files"]))
    if stats.get("batches"):
        out.append("- **已判定 %d 次自动化批量，共抑制 %d 条改动**（扎堆在 %g 秒内且涉及 >=%d 个文件，"
                   "不计入单文件热度，见下方「批量改动」）" % (
                       stats["batches"], stats["suppressed"], BATCH_GAP_S, BATCH_MIN_FILES))
    out.append("- 打分：热度 = %s" % " + ".join(
        "%g×%s" % (w, lab) for k, w, lab in COMPONENTS))
    out.append("- 衰减半衰期：%g 小时（`0.5^(距今小时/%g)`）" % (HALF_LIFE_H, HALF_LIFE_H))
    if note:
        out += ["", note]
    out.append("")

    head = ["#", "热度", "文件", "改动", "运行", "失败", "失败率", "行数", "最后动"]
    widths = [4, 7, 34, 6, 6, 6, 8, 8, 11]
    aligns = ["r", "r", "l", "r", "r", "r", "r", "r", "l"]
    out.append(" | ".join(_pad(h, w, a == "r")
                          for h, w, a in zip(head, widths, aligns)))
    out.append("-+-".join("-" * w for w in widths))
    for i, r in enumerate(rows, 1):
        cells = [
            str(i),
            "%.1f" % r["heat"],
            r["path"],
            str(r["chg_n"]),
            str(r["run_n"]),
            str(r["fail_n"]),
            ("%.0f%%" % (r["failrate"] * 100)) if r["run_n"] else "-",
            str(r["loc"]),
            _fmt_age(r["last"], now),
        ]
        out.append(" | ".join(_pad(c, w, a == "r")
                              for c, w, a in zip(cells, widths, aligns)))
    out.append("")

    if batches:
        out.append("## 批量改动（已从上面排除，不计入单文件热度）")
        out.append("")
        out.append("| 时间 | 持续 | 动了几个文件 | 头几个文件 |")
        out.append("|---|---|---|---|")
        for b in batches[-8:]:
            dur = b["end"] - b["ts"]
            names = "、".join(os.path.basename(f) for f in b["files"][:4])
            if b["n"] > 4:
                names += " …"
            out.append("| %s | %.0f 秒 | %d | %s |" % (
                _fmt_ts(b["ts"]), dur, b["n"], names))
        out.append("")
    return "\n".join(out)


def render_detail(root, row, events, now, batches=None):
    """渲染单文件详情表：分量拆开 + 该文件的事件时间线。"""
    if row is None:
        return None
    out = ["# HotTable · 单文件热度明细", "",
           "- 文件：`%s`" % row["path"],
           "- 目录：`%s`" % root,
           "- **热度 = %.1f**" % row["heat"], ""]

    out.append("## 热度分量（每一项都归一到本组最大值 = 1）")
    out.append("")
    out.append("| 分量 | 权重 | 原始值 | 归一值 | 得分 |")
    out.append("|---|---|---|---|---|")
    for key, w, lab in COMPONENTS:
        if key == "fail_s":
            desc = "%d 次失败 ×(1+2×失败率)" % row["fail_n"]
        elif key == "churn_s":
            desc = "÷ 存活 %.1f 小时" % row["span_h"]
        elif key == "loc_s":
            desc = "%d 行" % row["loc"]
        else:
            burst = row.get("burst_max", 1)
            base = "%d 次（带 %g 小时半衰期）" % (
                row["chg_n"] if key == "chg" else row["run_n"], HALF_LIFE_H)
            if key == "chg" and burst > 1:
                desc = "%s，合并了 %d 次连着保存，按 log2(%d+1)=%.2f 记权重" % (
                    base, burst, burst, math.log2(burst + 1))
                out.append("| %s | %g | %.2f（%s） | %.2f | %.1f |" % (
                    lab, w, row[key], desc, row[key + "_norm"], w * row[key + "_norm"]))
                continue
            desc = base
        out.append("| %s | %g | %.2f（%s） | %.2f | %.1f |" % (
            lab, w, row[key], desc, row[key + "_norm"], w * row[key + "_norm"]))
    out.append("| **合计** | **100** | | | **%.1f** |" % row["heat"])
    out.append("")

    out.append("## 原始计数")
    out.append("")
    out.append("- 改动 %d 次 · 运行 %d 次 · 失败 %d 次（失败率 %.0f%%）" % (
        row["chg_n"], row["run_n"], row["fail_n"], row["failrate"] * 100))
    out.append("- 首次记录：%s（%s）" % (_fmt_ts(row["first"]), _fmt_age(row["first"], now)))
    out.append("- 最后变动：%s（%s）" % (_fmt_ts(row["last"]), _fmt_age(row["last"], now)))
    out.append("")

    rel = row["path"]
    mine = [e for e in events if e.get("path") == rel]
    in_batch = [b for b in (batches or []) if rel in b["files"]]
    if in_batch:
        out.append("> ⚠ 本文件出现在 %d 次**自动化批量改动**里（已不计入上面的热度）。"
                   "那多半是回归/构建顺手碰的，不是有人在改它。" % len(in_batch))
        out.append("")
    out.append("## 事件时间线（最近 30 条，共 %d 条）" % len(mine))
    out.append("")
    if not mine:
        out.append("（无）")
    else:
        for e in mine[-30:]:
            t = _fmt_ts(e["ts"])
            if e["kind"] == "change":
                out.append("- `%s` %s %s%s" % (
                    t, e.get("ev", "?"), rel,
                    ("（%s 行）" % e["lines"]) if e.get("lines") else ""))
            elif e["kind"] == "run":
                mark = "✅" if e.get("ok") else "❌"
                tail = ("　" + e["err"]) if e.get("err") else ""
                dur = ("　%.2fs" % e["dur"]) if e.get("dur") else ""
                out.append("- `%s` %s 运行 %s（rc=%s）%s%s" % (
                    t, mark, rel, e.get("rc", "?"), dur, tail))
            else:
                out.append("- `%s` %s" % (t, e.get("text", "")))
    out.append("")
    return "\n".join(out)


def status(root):
    """台账健康检查：开着没有、开了多久、攒了多少事件、上次变动距今多久。"""
    pid = _watcher_pid(root)
    alive = bool(pid) and _pid_alive(pid)
    store = _store_path(root)
    n, last, first = 0, None, None
    if os.path.exists(store):
        try:
            with open(store, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    n += 1
                    try:
                        t = json.loads(line).get("ts")
                    except ValueError:
                        t = None
                    if t:
                        first = t if first is None else min(first, t)
                        last = t if last is None else max(last, t)
        except OSError:
            pass
    L = ["# HotTable 状态", "",
         "- 目录：`%s`" % root,
         "- 台账：`%s`（%d 条事件）" % (store, n),
         "- 轮询间隔：%.1f 秒（改：环境变量 HOTTABLE_POLL）" % POLL_S,
         "- 忽略规则：默认 %d 条 + %s" % (
             len(DEFAULT_IGNORE),
             IGNORE_FILE if os.path.exists(os.path.join(root, IGNORE_FILE)) else "无额外"),
         ""]
    if alive:
        L.append("- 状态：**开着**（watcher PID %d）" % pid)
    elif pid:
        L.append("- 状态：**没开**（残留标记 PID %d，进程已死；下次查询会自动清理）" % pid)
    else:
        L.append("- 状态：**没开**（用 `pybktl hottable watch` 开）")
    if first:
        L.append("- 记录区间：%s ~ %s" % (_fmt_ts(first), _fmt_ts(last)))
        L.append("- 最后一条事件：%s（%s）" % (
            _fmt_ts(last), _fmt_age(last, time.time())))
    L.append("")
    return "\n".join(L)


def view(root, targets=None, top=20, since=None, want_json=False):
    """主查询入口。返回要打印的字符串。

    targets 非空 → 这些文件的明细表；否则 → 热度排行榜前 top 名。"""
    now = time.time()
    events = load_events(root, since=since)
    if not events:
        return ("该文件夹还没有 HotTable 事件：请先 `cd` 到目标文件夹执行 "
                "`pybktl hottable watch`，并在此期间跑几次 `pybktl run`。")
    rows, stats, batches = score(events, now=now, root=root)

    # 目标筛选：支持 basename 片段匹配，方便直接敲文件名
    picked = []
    if targets:
        for t in targets:
            t = t.replace("\\", "/")
            hit = [r for r in rows
                   if r["path"] == t or r["path"].endswith("/" + t) or t in r["path"]]
            if not hit:
                # 文件可能只在自动化批量里出现过（热度被抑制掉了）——
                # 这时候回「没找到」是错的，得说清楚它到底在哪出现过
                inhit = [b for b in batches
                         if any(f == t or f.endswith("/" + t) or t in f
                                for f in b["files"])]
                if inhit:
                    return ("`%s` 的改动全部落在 %d 次**自动化批量改动**里，已被排除出热度榜：\n\n%s"
                            % (t, len(inhit),
                               "\n".join("  %s  动了 %d 个文件（跨 %.0f 秒）" % (
                                   _fmt_ts(b["ts"]), b["n"], b["end"] - b["ts"])
                                   for b in inhit[-8:])))
                return ("未在台账里找到 `%s` 相关记录。\n\n当前有记录的文件（前 30）：\n%s"
                        % (t, "\n".join("  %-50s 热度 %.1f" % (r["path"], r["heat"])
                                         for r in rows[:30])))
            picked.append(max(hit, key=lambda r: r["heat"]))
        if want_json:
            return json.dumps({"root": root, "stats": stats, "batches": batches,
                               "files": [_jsonable(r) for r in picked]},
                              ensure_ascii=False, indent=2)
        return "\n".join(render_detail(root, r, events, now, batches) or "" for r in picked)

    picked = rows[:max(1, top)]
    if want_json:
        return json.dumps({"root": root, "stats": stats, "batches": batches,
                           "files": [_jsonable(r) for r in picked]},
                          ensure_ascii=False, indent=2)
    return render_table(root, picked, stats, now,
                        "热度排行（前 %d / 共 %d 个文件）" % (len(picked), len(rows)),
                        batches=batches)


def _jsonable(r):
    d = dict(r)
    d["first"] = _fmt_ts(r["first"])
    d["last"] = _fmt_ts(r["last"])
    return d


# ---------------------------------------------------------------------------
# watcher（前台盯盘，Ctrl+C 停）
# ---------------------------------------------------------------------------
def _snapshot(root, pats=None):
    """扫描 root 下所有普通文件的 (size, mtime)。

    排除隐藏文件、台账自身、缓存目录、忽略规则命中的目录与文件。
    目录在 os.walk 里直接剪枝——1.6 万文件的树上逐文件判规则会很慢。"""
    if pats is None:
        pats = _load_ignore(root)
    snap = {}
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames
                       if not d.startswith('.')
                       and d not in _SKIP_DIRS
                       and not _dir_ignored(d, pats)]
        base_rel = os.path.relpath(dirpath, root).replace("\\", "/")
        base_rel = "" if base_rel == "." else base_rel + "/"
        for fn in filenames:
            if fn.startswith('.') or fn == STORE:
                continue
            fp = os.path.join(dirpath, fn)
            rel = base_rel + fn
            if pats and _is_ignored(rel, pats):
                continue
            try:
                st = os.stat(fp)
                snap[fp] = (st.st_size, st.st_mtime)
            except OSError:
                pass
    return snap


def start_watcher(use_defaults=True):
    """前台热度台账循环：监控 cwd，Ctrl+C 停止。

    use_defaults=False 时只用 .hottableignore 里写的规则（`--all` 走这条）。"""
    root = os.path.abspath(os.getcwd())
    _trim_store(_store_path(root))
    pats = _load_ignore(root, use_defaults=use_defaults)
    with open(os.path.join(root, MARKER), "w") as f:
        f.write(str(os.getpid()))
    log_note(root, "HotTable 开启：目录 `%s`" % root)
    print("HotTable 已开启，监控：%s" % root)
    print("台账：%s" % os.path.join(root, STORE))
    print("随时 `pybktl hottable` 看热度排行；`pybktl hottable <文件>` 看单项明细。")
    print("轮询间隔 %.1f 秒（环境变量 HOTTABLE_POLL 可改）；忽略规则 %d 条%s。"
          % (POLL_S, len(pats), "" if use_defaults else "（--all：不含默认集）"))
    print("Ctrl+C 停止。")

    snap = _snapshot(root, pats)
    print("已建立基线：%d 个文件在盯。" % len(snap))
    try:
        while True:
            time.sleep(POLL_S)
            new = _snapshot(root, pats)
            for path, info in new.items():
                if path not in snap:
                    log_change(root, path, "created", size=info[0])
                elif snap[path] != info:
                    log_change(root, path, "modified", size=info[0])
            for path in snap:
                if path not in new:
                    log_change(root, path, "deleted")
            snap = new
    except KeyboardInterrupt:
        try:
            os.remove(os.path.join(root, MARKER))
        except OSError:
            pass
        log_note(root, "HotTable 已停止")
        print("\nHotTable 已停止。台账见：%s" % os.path.join(root, STORE))


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "watch":
        start_watcher()
    else:
        _root = find_hottable_root(os.getcwd())
        if not _root:
            print("该文件夹未开启 HotTable：请先 `cd` 到目标文件夹执行 `pybktl hottable watch`。")
            sys.exit(1)
        print(view(_root, targets=sys.argv[1:] or None))
