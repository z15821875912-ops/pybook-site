# -*- coding: utf-8 -*-
"""hist —— PYbook 团队协作历史：快照 / 回滚 / 追溯（git 免训版）。

为什么不是 git：PYbook 的用户是初学者和 AI，git 的暂存区/分支/rebase 是另一门
语言。这里只提供团队协作真正需要的三件事，全部文件化、全部说人话：

    pybktl hist save [说明]        快照当前（只存改动过的文件，去重）
    pybktl hist log [-n 10]        历史（时间 / 作者 / 说明 / 改动数）
    pybktl hist show <id>          某次快照的细节
    pybktl hist diff <id>          现在 vs 快照（相同/已改/新增/已删）
    pybktl hist restore <id>       回滚（回滚前自动先给现状拍安全快照——永不丢）
    pybktl hist undo               回到上一次快照
    pybktl hist gc [--keep 30]     清理老快照

协作记录：每次快照带作者（PYBOOK_AUTHOR 环境变量 > USERNAME > 未知）和说明，
log 按 --author/--file 过滤——「这文件谁最后动过、为什么」一查便知。

存储：.pybook/hist/ 下 blobs/<sha256>（内容去重）+ 索引.jsonl（一行一次快照）。
快照范围：*.pybk + pybook.md + pybook.lock + VERSION + 根级 *.md（项目文件；
工具链和缓存刻意不在内——那是 pybktl release 的事）。
"""
import argparse
import datetime
import hashlib
import os
import shutil

HIST_DIR = os.path.join(".pybook", "hist")
SCOPE_GLOBS = ("*.pybk",)
SCOPE_FILES = ("pybook.md", "pybook.lock", "VERSION")


def out(m=""):
    print(m)


def err(m):
    print(m)


def _root():
    return os.getcwd()


def _hist():
    return os.path.join(_root(), HIST_DIR)


def _author():
    return (os.environ.get("PYBOOK_AUTHOR")
            or os.environ.get("USERNAME") or "未知")


def _sha(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def _scope_files():
    """快照范围：根级 *.pybk + *.md（设计文档也是团队资产）+ 固定清单文件。"""
    files = []
    for p in glob_root("*.pybk"):
        files.append(p)
    for p in glob_root("*.md"):
        files.append(p)
    for name in SCOPE_FILES:
        if os.path.isfile(name):
            files.append(name)
    return sorted(set(files))


def glob_root(pat):
    import glob as g
    return [p for p in g.glob(pat) if os.path.isfile(p)]


def _index_path():
    return os.path.join(_hist(), "索引.jsonl")


def _read_index():
    p = _index_path()
    rows = []
    if os.path.isfile(p):
        import json
        for line in open(p, encoding="utf-8"):
            line = line.strip()
            if line:
                import json as j
                rows.append(j.loads(line))
    return rows


def _append_index(row):
    import json
    os.makedirs(_hist(), exist_ok=True)
    with open(_index_path(), "a", encoding="utf-8") as f:
        f.write(json.dumps(row, ensure_ascii=False) + "\n")


def _write_index(rows):
    import json
    os.makedirs(_hist(), exist_ok=True)
    with open(_index_path(), "w", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")


def _blob_path(sha):
    return os.path.join(_hist(), "blobs", sha)


def _store_blob(path):
    """把文件内容存进 blobs（同内容去重），返回 sha。"""
    sha = _sha(path)
    bp = _blob_path(sha)
    if not os.path.isfile(bp):
        os.makedirs(os.path.dirname(bp), exist_ok=True)
        shutil.copy(path, bp)
    return sha


def _current_state():
    """当前范围文件 → {相对路径: sha}；顺带把内容进 blobs。"""
    state = {}
    for p in _scope_files():
        state[p.replace(os.sep, "/")] = _store_blob(p)
    return state


def _diff_states(a, b):
    """a→b 的变化：added(新增文件)/removed/changed。a,b 都是 {路径: sha}。"""
    added = sorted(k for k in b if k not in a)
    removed = sorted(k for k in a if k not in b)
    changed = sorted(k for k in a if k in b and a[k] != b[k])
    return added, removed, changed


def _find_compiler():
    """从 cwd 一路向上找 pybk_main.py（红绿灯要用它跑 --check-json）。"""
    d = os.getcwd()
    while d:
        cand = os.path.join(d, 'pybk_main.py')
        if os.path.isfile(cand):
            return cand
        parent = os.path.dirname(d)
        if parent == d:
            break
        d = parent
    return None


def _light(pybk_files):
    """红绿灯：改动的 .pybk 过一遍静态检查。返回 '绿'/'红'/None（找不到编译器不亮灯）。
    库豁免：只犯「GOING 块」错误的视为库文件，放行。"""
    import subprocess as sp
    mainpy = _find_compiler()
    if not mainpy or not pybk_files:
        return None
    import sys as _s
    ok = True
    for f in pybk_files:
        try:
            r = sp.run([_s.executable, mainpy, '--check-json', f],
                       capture_output=True, text=True, encoding='utf-8',
                       errors='replace', timeout=60)
        except Exception:
            return None
        line = (r.stdout or '').strip().splitlines()[-1] if (r.stdout or '').strip() else ''
        bad = r.returncode != 0 or ('"ok": false' in line.replace(' ', ''))
        if bad and 'GOING 块' not in line:
            ok = False
    return '绿' if ok else '红'


def _active_claims():
    """30 分钟内有效的软锁登记。"""
    import json
    p = os.path.join('.pybook', '编辑中.jsonl')
    rows = []
    if os.path.isfile(p):
        import time as _t
        now = _t.time()
        for line in open(p, encoding='utf-8'):
            line = line.strip()
            if not line:
                continue
            try:
                r = json.loads(line)
            except Exception:
                continue
            if now - r.get('ts', 0) < 1800:
                rows.append(r)
    return rows


def _claim_conflicts(files):
    """我正要快照的文件里，有没有别人 30 分钟内登记过「我在改」？"""
    me = _author()
    hits = []
    for r in _active_claims():
        if r.get('author') == me:
            continue
        for f in files:
            if f in r.get('files', []) or f in r.get('files', {}):
                import time as _t
                mins = int((_t.time() - r.get('ts', 0)) / 60)
                hits.append(f"{r.get('author')} {mins} 分钟前也在改 {f}")
    return hits


def _save(root_note, auto=False):
    os.makedirs(_hist(), exist_ok=True)
    rows = _read_index()
    prev = rows[-1]["files"] if rows else {}
    cur = _current_state()
    added, removed, changed = _diff_states(prev, cur)
    if not (added or removed or changed):
        out("· 与上一次快照完全一致，无需新快照")
        return
    for h in _claim_conflicts(list(cur.keys())):
        out(f"⚠ 软锁提醒: {h}——先和对方打个招呼再覆盖")
    pybk_changed = [f for f in changed + added if f.endswith('.pybk')]
    light = _light(pybk_changed)
    now = datetime.datetime.now()
    sid = now.strftime("%Y%m%d_%H%M%S") + ("" if not auto else "_auto")
    exist = {r["id"] for r in rows}
    seq = 1
    while sid in exist:                      # 同秒多次快照：追加序号保唯一
        seq += 1
        sid = now.strftime("%Y%m%d_%H%M%S") + f"_{seq}" + ("_auto" if False else "")
    for sha in list(cur.values()):
        bp = _blob_path(sha)
        if not os.path.isfile(bp):
            src = None
            for rel in cur:
                if cur[rel] == sha and os.path.isfile(rel):
                    src = rel
                    break
            if src:
                os.makedirs(os.path.dirname(bp), exist_ok=True)
                shutil.copy(src, bp)
    note = root_note or ("、".join(changed[:3] + added[:2]) or "无文件变化")
    row = {"id": sid, "time": now.strftime("%Y-%m-%d %H:%M:%S"),
           "author": _author(), "note": (root_note or note)[:80],
           "added": added, "removed": removed, "changed": changed,
           "files": cur, "灯": light or "无"}
    _append_index(row)
    parts = []
    if changed:
        parts.append(f"改 {len(changed)}")
    if added:
        parts.append(f"增 {len(added)}")
    if removed:
        parts.append(f"删 {len(removed)}")
    lamp = {'绿': '●绿', '红': '●红'}.get(light or '', '○')
    out(f"✓ 快照 {sid}  {lamp}  作者 {_author()}  （{' / '.join(parts) or '无变化'}）")
    if changed:
        out("  改动: " + "、".join(changed[:5]) + ("…" if len(changed) > 5 else ""))


def _find_row(sid):
    rows = _read_index()
    for r in reversed(rows):
        if r["id"] == sid or r["id"].startswith(sid) or r["id"].endswith(sid):
            return r
    return None


def _remote_path():
    p = os.path.join(".pybook", "远端.txt")
    return open(p, encoding="utf-8").read().strip() if os.path.isfile(p) else ""


def cmd_save(args):
    import argparse as _ap
    _save(args.note)
    if args.push:
        remote = _remote_path()
        if remote:
            cmd_push(_ap.Namespace(path=remote))
        else:
            out("  （--push 需要远端：先 hist push <共享目录> 记住它）")
    return 0


def cmd_log(args):
    rows = _read_index()
    if args.author:
        rows = [r for r in rows if r["author"] == args.author]
    if args.file:
        rows = [r for r in rows
                if args.file in r.get("changed", []) or args.file in r.get("added", [])
                or args.file in r.get("removed", []) or args.file in r.get("files", {})]
    if not rows:
        out("· 还没有历史。pybktl hist save 先拍一次。")
        return 0
    rows = rows[-args.n:]
    out(f"历史 {len(rows)} 条（作者: {_author()}，范围: .pybk/清单/锁/VERSION）：")
    for r in rows:
        n = len(r.get("changed", [])) + len(r.get("added", [])) + len(r.get("removed", []))
        lamp = {'绿': '●绿', '红': '●红'}.get(r.get('灯', ''), '○')
        out(f"  {r['id']}  {lamp}  {r['time']}  {r['author']:<8} 改动{n:>2}  {r['note'][:40]}")
    out("  回滚: pybktl hist restore <id> ｜ 详情: hist show <id>")
    return 0


def cmd_show(args):
    r = _find_row(args.id)
    if not r:
        err(f"✗ 没有这个快照: {args.id}")
        return 1
    out(f"快照 {r['id']}  {r['time']}  作者 {r['author']}")
    out(f"说明: {r['note']}")
    a, rm, ch = r.get("added", []), r.get("removed", []), r.get("changed", [])
    if ch:
        out("改动: " + "、".join(ch))
    if a:
        out("新增: " + "、".join(a))
    if rm:
        out("删除: " + "、".join(rm))
    out(f"文件共 {len(r.get('files', {}))} 个")
    return 0


def cmd_diff(args):
    r = _find_row(args.id)
    if not r:
        err(f"✗ 没有这个快照: {args.id}")
        return 1
    cur = _current_state()
    a, rm, ch = _diff_states(r["files"], cur)
    same = len(r["files"]) - len([k for k in r["files"] if k in ch or k in rm])
    out(f"快照 {r['id']} → 现在：")
    for k in ch:
        out(f"  已改 {k}")
    for k in a:
        out(f"  新增 {k}")
    for k in rm:
        out(f"  已删 {k}")
    out(f"（相同 {same} 个）")
    return 0


def _restore(row, exact=False):
    if row.get("灯") == "红":
        out("⚠ 你正在回滚到 ●红 快照（当时的 .pybk 没通过静态检查）——确认是要回到那个状态")
    # 安全第一：先把现状拍成快照，回滚永不丢东西
    _save(f"回滚到 {row['id']} 前的安全快照", auto=True)
    files = row.get("files", {})
    n = 0
    for rel, sha in files.items():
        bp = _blob_path(sha)
        if not os.path.isfile(bp):
            err(f"  ⚠ blob 缺失，跳过 {rel}")
            continue
        os.makedirs(os.path.dirname(rel) or ".", exist_ok=True)
        shutil.copy(bp, rel)
        n += 1
    if exact:
        cur = _current_state()
        for k in cur:
            if k not in files and os.path.isfile(k):
                os.remove(k)
                n += 1
    out(f"✓ 已回滚到 {row['id']}（{r_time(row)}，作者 {row['author']}）——恢复 {n} 个文件")
    out(f"  回滚前的现状已存为安全快照，后悔可 hist log 找回")


def r_time(row):
    return row["time"]


def cmd_restore(args):
    r = _find_row(args.id)
    if not r:
        err(f"✗ 没有这个快照: {args.id}")
        return 1
    _restore(r, exact=args.exact)
    return 0


def cmd_undo(args):
    rows = _read_index()
    if not rows:
        err("✗ 还没有历史")
        return 1
    _restore(rows[-1], exact=False)
    return 0


def cmd_gc(args):
    rows = _read_index()
    keep_n = args.keep
    if len(rows) <= keep_n:
        out(f"· 只有 {len(rows)} 条历史（上限 {keep_n}），无需清理")
        return 0
    drop, keep = rows[:-keep_n], rows[-keep_n:]
    used = set()
    for r in keep:
        used.update(r.get("files", {}).values())
    removed = 0
    for r in drop:
        for sha in r.get("files", {}).values():
            bp = _blob_path(sha)
            if sha not in used and os.path.isfile(bp):
                os.remove(bp)
                removed += 1
    _write_index(keep)
    out(f"✓ 清理 {len(drop)} 条老快照（释放 {removed} 个 blob），保留最近 {keep_n} 条")
    return 0


def build_subparser(sub):
    ph = sub.add_parser("hist", help="团队协作历史：快照 / 回滚 / 追溯（git 免训版）")
    hsub = ph.add_subparsers(dest="hist_action")

    hs = hsub.add_parser("save", help="拍快照（只存改动，带作者和说明）")
    hs.add_argument("note", nargs="?", default="", help="一句话说明（谁为什么改）")
    hs.add_argument("--push", action="store_true",
                    help="快照后自动推送到记住的共享历史（远端由 hist push <目录> 记录）")

    hl = hsub.add_parser("log", help="历史列表")
    hl.add_argument("-n", type=int, default=15, help="显示条数（默认 15）")
    hl.add_argument("--author", help="按作者过滤")
    hl.add_argument("--file", help="按文件过滤（谁动过这个文件）")

    hsh = hsub.add_parser("show", help="某次快照详情")
    hsh.add_argument("id", help="快照 id（可只写前几位）")

    hd = hsub.add_parser("diff", help="现在 vs 快照")
    hd.add_argument("id", help="快照 id")

    hr = hsub.add_parser("restore", help="回滚到某次快照（现状自动先存安全快照）")
    hr.add_argument("id", help="快照 id")
    hr.add_argument("--exact", action="store_true", help="严格模式：删掉快照里没有的多余文件")

    hu = hsub.add_parser("undo", help="回到上一次快照")

    hg = hsub.add_parser("gc", help="清理老快照")
    hg.add_argument("--keep", type=int, default=30, help="保留最近多少条（默认 30）")

    hp = hsub.add_parser("push", help="推送本地新快照到共享历史目录（团队）")
    hp.add_argument("path", help="共享历史目录（共享盘/git 仓库均可）")

    hpl = hsub.add_parser("pull", help="从共享历史目录拉取新快照")
    hpl.add_argument("path", help="共享历史目录")

    hc = hsub.add_parser("claim", help="登记「我正在改这些文件」（软锁 30 分钟）")
    hc.add_argument("files", nargs="+", help="要登记的文件")

    hcs = hsub.add_parser("claims", help="查看当前有效软锁")

    hdj = hsub.add_parser("decide", help="团队决策记录（写一行进 决定.md）")
    hdj.add_argument("note", help="一句话决定（含原因更好）")

    ph.set_defaults(func=_dispatch)


def _dispatch(args):
    table = {"save": cmd_save, "log": cmd_log, "show": cmd_show,
             "diff": cmd_diff, "restore": cmd_restore, "undo": cmd_undo,
             "gc": cmd_gc, "push": cmd_push, "pull": cmd_pull,
             "claim": cmd_claim, "claims": cmd_claims, "decide": cmd_decide}
    fn = table.get(args.hist_action)
    if fn is None:
        err("用法: pybktl hist save|log|show|diff|restore|undo|gc")
        return 2
    return fn(args)


def cmd_push(args):
    """把本地新快照推到共享历史目录（索引 + blobs 增量合并，按 id 去重）。"""
    target = args.path
    os.makedirs(target, exist_ok=True)
    local = _read_index()
    tidx = os.path.join(target, "索引.jsonl")
    shared = []
    if os.path.isfile(tidx):
        import json
        for line in open(tidx, encoding="utf-8"):
            line = line.strip()
            if line:
                shared.append(json.loads(line))
    have = {r["id"] for r in shared}
    fresh = [r for r in local if r["id"] not in have]
    tblobs = os.path.join(target, "blobs")
    pushed_shas = 0
    for r in fresh:
        for sha in r.get("files", {}).values():
            src = _blob_path(sha)
            dst = os.path.join(tblobs, sha)
            if os.path.isfile(src) and not os.path.isfile(dst):
                os.makedirs(tblobs, exist_ok=True)
                shutil.copy(src, dst)
                pushed_shas += 1
    import json
    with open(tidx, "a", encoding="utf-8") as f:
        for r in fresh:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    authors = sorted({r["author"] for r in fresh})
    lv = [r.get("灯", "无") for r in fresh]
    os.makedirs(".pybook", exist_ok=True)
    open(os.path.join(".pybook", "远端.txt"), "w", encoding="utf-8").write(target)
    out(f"✓ 已推送 {len(fresh)} 条快照（{pushed_shas} 个内容块）→ {target}")
    out(f"  红绿: ●绿 {lv.count('绿')} / ●红 {lv.count('红')} ｜ 作者: {'、'.join(authors) or '—'}"
        f"｜共享历史现共 {len(shared) + len(fresh)} 条")
    return 0


def cmd_pull(args):
    """从共享历史目录拉取新快照（只增不删；restore 永远先存安全快照，不吞工作）。"""
    import json
    target = args.path
    tidx = os.path.join(target, "索引.jsonl")
    if not os.path.isfile(tidx):
        err(f"✗ 共享历史不存在: {tidx}")
        return 1
    shared = []
    for line in open(tidx, encoding="utf-8"):
        line = line.strip()
        if line:
            shared.append(json.loads(line))
    local = _read_index()
    have = {r["id"] for r in local}
    incoming = [r for r in shared if r["id"] not in have]
    os.makedirs(os.path.join(_hist(), "blobs"), exist_ok=True)
    for r in incoming:
        for sha in r.get("files", {}).values():
            src = os.path.join(target, "blobs", sha)
            dst = _blob_path(sha)
            if os.path.isfile(src) and not os.path.isfile(dst):
                shutil.copy(src, dst)
    _write_index(local + incoming)
    out(f"✓ 已拉取 {len(incoming)} 条快照（共享共 {len(shared)} 条）")
    if incoming:
        authors = sorted({r["author"] for r in incoming})
        out("  作者: " + "、".join(authors))
        latest = incoming[-1]
        diffs = []
        for f, sha in latest.get("files", {}).items():
            if os.path.isfile(f) and _sha(f) != sha:
                diffs.append(f)
        if diffs:
            out("  ⚠ 注意: " + "、".join(diffs[:5]) +
                " 与拉到的最新快照不同（你本地也有新改动）——restore 前先 hist diff 对比，"
                "restore 本身会自动存安全快照，不会吞你的工作")
        out("  回滚: pybktl hist restore <id>")
    return 0


def cmd_claim(args):
    """登记「我正在改这些文件」（软锁，30 分钟自动过期）。"""
    import json
    import time as _t
    files = []
    for f in args.files:
        f = f.replace(os.sep, "/")
        if os.path.isfile(f) and f not in files:
            files.append(f)
    if not files:
        err("用法: pybktl hist claim 文件.pybk [更多文件…]")
        return 2
    os.makedirs(".pybook", exist_ok=True)
    p = os.path.join(".pybook", "编辑中.jsonl")
    with open(p, "a", encoding="utf-8") as f:
        f.write(json.dumps({"author": _author(), "ts": _t.time(), "files": files},
                           ensure_ascii=False) + "\n")
    out(f"✓ 已登记（30 分钟有效）: {', '.join(files)} ｜ 作者 {_author()}")
    for h in _claim_conflicts(files):
        out(f"⚠ {h}")
    return 0


def cmd_claims(args):
    rows = _active_claims()
    if not rows:
        out("· 当前没有有效软锁（登记 30 分钟自动过期）")
        return 0
    import time as _t
    me = _author()
    out(f"有效软锁 {len(rows)} 条：")
    for r in rows:
        mins = int((_t.time() - r.get("ts", 0)) / 60)
        who = r.get("author") + ("（你）" if r.get("author") == me else "")
        out(f"  - {who}  {mins} 分钟前  {', '.join(r.get('files', []))}")
    return 0


def cmd_decide(args):
    """团队决策记录：一行一条，写进 决定.md（日期 + 作者 + 决定）。"""
    note = (args.note or "").strip()
    if not note:
        err('用法: pybktl hist decide "一句话决定（含原因更好）"')
        return 2
    p = os.path.join(_root(), "决定.md")
    line = f"- {datetime.date.today().isoformat()} {_author()}：{note}\n"
    with open(p, "a", encoding="utf-8") as f:
        if not os.path.isfile(p) or os.path.getsize(p) == 0:
            f.write("# 团队决策记录\n\n")
        f.write(line)
    out(f"✓ 已记入 {p}: {line.strip()}")
    return 0
