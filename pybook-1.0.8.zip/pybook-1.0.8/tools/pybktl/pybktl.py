#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
pybktl —— PYbook 外部工具链（零侵入版）
======================================
设计约束：不修改 pybk_main.py / pybk_code.py / pybk_front.py / pybk_build.py 任何字节。
本工具只是「包在编译器外面的壳」：通过子进程调用 PYbook 已有的 CLI，
把 kaula 那种 pkg / workspace / fmt / smoke 的体验补到 PYbook 上。

PYbook 真实 CLI 契约（已核实）：
  pybk_main.py             <文件.pybk>           → 前端→C→gcc→原生 exe 并运行（弹 SDL 窗）
  pybk_main.py --check-json <文件.pybk>           → 静态校验，输出 {"ok","line","message"}
  pybk_build.py            <文件.pybk> [out.pybc] → 编译为字节码 .pybc（不依赖 gcc）
  pybk_build.py            <文件.pybk> -r         → 编译后立即用 pyvm.exe 运行
  smokeroor.py                                → 跑 tests/smoke/ 全套，比对 .expect
  （无头）设环境变量 PYBOOK_SHOT_DIR          → hw 程序自动存 BMP 帧（仅 3D）

子命令：
  pybktl init                  在当前目录生成 pybook.md 清单（已存在则跳过）
  pybktl check <文件.pybk>     静态校验（友好化 --check-json + 错误指纹）
  pybktl build <文件.pybk>     编译为 .pybc 字节码产物（离线，不运行）
  pybktl run   <文件>         运行（默认原生管线；--vm 走字节码 pyvm；2D 会弹窗）
  pybktl fmt   <文件.pybk>     块级缩进整理（默认预览，--in-place 落盘，--check 落盘后复检）
  pybktl pkg add  <名> <路径>  往 pybook.md「依赖」段加一条（路径可带 @版本）
  pybktl pkg lock             生成 pybook.lock：锁定各依赖的 sha256（可复现构建）
  pybktl pkg sync             把依赖 .pybk 同步到各成员目录旁（有锁则先校验）
  pybktl pkg list             看依赖清单 + 锁定状态
  pybktl pkg pack   <目录>    把目录打成 .pybp 包（zip：包清单.md + .pybk 源码）
  pybktl pkg publish <目录>   发布到本地 registry（默认 ~/.pybook/registry）
  pybktl pkg install <名>     从 registry 装包到 libs/<名>/ 并登记依赖（带版本）
  pybktl ws build / ws check   按 pybook.md「工作区」段批量 build / check
  pybktl smoke <文件.pybk>     无头冒烟：跑一遍看崩不崩；若旁有 .expect 则比对；
                                --shot-dir <dir> 设 PYBOOK_SHOT_DIR（3D 无头出图验收）
                                --all 则委托 smokeroor.py 跑整套 tests/smoke/
  pybktl lookaround            在当前文件夹开启日志循环（监控文件改动 + 自动记录运行/错误）
  pybktl lookaround log        查看/筛选日志（--file/--type/--since/--tail）
  pybktl lookaround report     生成团队协作报告（--out 写入文件）
  pybktl hottable watch       在当前文件夹开启热度台账（记改动 + 运行，24h 半衰期打分）
  pybktl hottable             看热度排行榜（前 20，告诉你该先改哪个文件）
  pybktl hottable <文件>       看该项热度明细：每个分量各值多少、热度是怎么加出来的
  pybktl hottable --since 3d  只统计最近 3 天（支持 12h / 3d / YYYY-MM-DD）
  pybktl todo add/done/rm/list/show   文件夹级待办清单（配合 lookaround 使用）
  pybktl repair <文件.pybk>    概念神「修」：静态检查→汇报错误→问你改不改→改错区（可 -y 自动）
                                    （也可 pybktl run --repair <文件> 运行前先修）
  pybktl test <文件|目录>     测试框架：发现 func 测试_*/test_* 用例，逐条编译运行，出可读报告（--junit 出 XML）

编译器定位优先级（可移植，无硬编码绝对路径）：
  1. 环境变量 PYBOOK_HOME
  2. 当前目录 pybook.md 的「## 编译器」段 home: 路径
  3. 从本工具自身位置向上找 pybk_main.py（工具随包发布，在 <pybook>/tools/pybktl/ 下）
  4. 从当前工作目录向上找 pybk_main.py
"""

import argparse
import datetime
import glob
import hashlib
import io
import json
import os
import re
import shutil
import subprocess
import time
import sys
import zipfile

# 让同目录的 lookaround.py 可被 import（工具随包发布，lookaround.py 就在一旁）
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lookaround  # LookAround 日志循环：文件夹改动 / run·build·check·smoke 运行 / 错误翻中文
import hottable    # HotTable 热度台账：同样的事件，换成结构化存储 + 透明打分，告诉你该先改哪个文件
import repair        # 概念神「修」：检查→汇报→问你改不改→改错区
import release        # 加强版发布：版本号三处同步 + CHANGELOG 盖章 + 清洁 zip
import hist           # 团队协作历史：快照 / 回滚 / 追溯（git 免训版）
import task           # 团队任务流转：认领人 / 截止日 / 状态（任务.md）
import doctor         # 工作区小诊所：僵尸锁/僵尸进程/缓存/版本漂移
import apppack        # 应用打包：程序+运行时+素材 → 发玩家
import report         # 团队协作报告：快照+任务+发布 聚合
import airegress      # AI 栈回归基线：验收程序双后端一键跑

MANIFEST = "pybook.md"
INDENT = "    "  # 4 空格
SMOKEROOR_TIMEOUT = 120  # smokeroor 单用例超时（秒）
LOCKFILE = "pybook.lock"   # 依赖锁：各依赖锁定时的 sha256 快照（可复现构建的落点）
PKG_EXT = ".pybp"          # PYbook Package：zip（包清单.md + .pybk 源码）
# 本地 registry：publish 往这里放 .pybp 并维护 索引.md，install 从这里取。
# 文件分发先行（registry 目录可直接进 git / 共享盘），远程 registry 留 v1 外。
DEFAULT_REGISTRY = os.path.join(os.path.expanduser("~"), ".pybook", "registry")
# 版本后缀：@1.2.0 / @v1.2 / @1.2.0-beta.1；路径尾部形如 @2.pybk 的不误伤
# （.pybk 不是 \d+，整体不匹配 → 不当版本剥）
_VER_RE = re.compile(r"\s*@(v?\d+(?:\.\d+){0,3}(?:[-+][0-9A-Za-z.\-]+)?)\s*$")


# ---------------------------------------------------------------------------
# 基础工具
# ---------------------------------------------------------------------------
def _winpath(p):
    """把 Git Bash / MSYS 传来的 POSIX 风格路径（/c/foo）转成 Windows 路径（C:/foo）。
    普通 Windows 终端下输入本就是 C:\\foo，这里无副作用。"""
    p = os.path.expanduser(p)
    m = re.match(r"^/([a-zA-Z])/(.*)$", p.replace("\\", "/"))
    if m:
        p = m.group(1) + ":/" + m.group(2)
    return os.path.abspath(p)


def out(msg=""):
    print(msg, flush=True)


def err(msg):
    print(msg, file=sys.stderr, flush=True)


def _manifest_home(md_path):
    try:
        for line in open(md_path, encoding="utf-8"):
            m = re.match(r"\s*home:\s*(.+)", line)
            if m:
                return m.group(1).strip()
    except Exception:
        pass
    return None


# ---------------------------------------------------------------------------
# 编译器 / 工具定位
# ---------------------------------------------------------------------------
def _self_dir():
    """本工具所在目录（工具随包发布：<pybook>/tools/pybktl/）。"""
    return os.path.dirname(os.path.abspath(__file__))


def _search_up_for(name, start):
    """从 start 目录向上逐级查找名为 name 的文件，返回其所在目录；找不到返回 None。
    这就是"自带定位"：pybk_main.py 一般就在包根，所以从 tools/pybktl/ 上跳两级即可。"""
    d = os.path.abspath(start)
    while True:
        if os.path.isfile(os.path.join(d, name)):
            return d
        nd = os.path.dirname(d)
        if nd == d:
            return None
        d = nd


def home_dir():
    """按优先级返回 PYbook 根目录（含 pybk_main.py 的目录）。
    全部走环境变量 / 清单 / 相对向上查找，不含任何硬编码的绝对路径。"""
    home = os.environ.get("PYBOOK_HOME")
    if not home:
        md = os.path.join(os.getcwd(), MANIFEST)
        if os.path.isfile(md):
            home = _manifest_home(md)
    if not home:
        home = _search_up_for("pybk_main.py", _self_dir())   # 工具就在包内
    if not home:
        home = _search_up_for("pybk_main.py", os.getcwd())   # 用户自己的项目目录
    if not home:
        err("找不到 PYbook 编译器（pybk_main.py）。请设置 PYBOOK_HOME，")
        err("或在当前目录的 " + MANIFEST + " 里写 `home: <pybook目录>`。")
        sys.exit(2)
    return _winpath(home)


def _find_script(name):
    """在 HOME 下找某个 PYbook 脚本（pybk_main.py / pybk_build.py / smokeroor.py / pyvm.exe）。"""
    home = home_dir()
    cand = os.path.join(home, name)
    if os.path.isfile(cand):
        return cand
    # 退化：向上递归找
    d = os.getcwd()
    while True:
        if os.path.isfile(os.path.join(d, name)):
            return os.path.join(d, name)
        nd = os.path.dirname(d)
        if nd == d:
            break
        d = nd
    err(f"找不到 {name}（HOME={home}）。请用 PYBOOK_HOME 指定，或在 pybook.md 写 home:。")
    sys.exit(2)


def locate_main():
    return _find_script("pybk_main.py")


def locate_build():
    return _find_script("pybk_build.py")


def locate_smokeroor():
    return _find_script("smokeroor.py")


def locate_vm():
    return _find_script("pyvm.exe")


def _find_gcc_dir():
    """探测 gcc 所在的 bin 目录，加到子进程 PATH 里（可移植，无硬编码路径）。
    优先级：PYBOOK_GCC 环境变量 → PATH 上的 gcc → 包目录旁常见的 mingw/ucrt64/bin。
    找不到返回 None（pybk_main 内部 _find_gcc 还有自己的兜底逻辑）。"""
    candidates = [os.environ.get("PYBOOK_GCC"), shutil.which("gcc")]
    try:
        root = home_dir()
    except SystemExit:
        root = None
    bases = [b for b in [root, os.path.dirname(root) if root else None] if b]
    for base in bases:
        for sub in ("mingw64/bin", "mingw32/bin", "ucrt64/bin", "bin"):
            candidates.append(os.path.join(base, sub, "gcc.exe"))
    for c in candidates:
        if c and os.path.isfile(c):
            return os.path.dirname(c)
    return None


_CHILD_ENV = None


def child_env(extra=None):
    """复刻 ide.py 的运行环境：UTF-8 编码 + 把 gcc bin 加进 PATH。
    额外 env（如 PYBOOK_SHOT_DIR）通过 extra 传入。"""
    global _CHILD_ENV
    if _CHILD_ENV is None:
        e = os.environ.copy()
        e["PYTHONIOENCODING"] = "utf-8"
        e["PYTHONUTF8"] = "1"
        gdir = _find_gcc_dir()
        if gdir and gdir not in e.get("PATH", ""):
            e["PATH"] = gdir + os.pathsep + e.get("PATH", "")
        _CHILD_ENV = e
    e = dict(_CHILD_ENV)
    if extra:
        e.update(extra)
    return e


def run_tool(script, *args, cwd=None, timeout=None, env=None):
    """子进程调用某个 PYbook 脚本。cwd 默认文件所在目录（方便 引用() 解析）。
    script 可以是 .py（用 python 跑）或 .exe（直接跑）。"""
    script = _winpath(script)
    if script.lower().endswith(".exe"):
        cmd = [script, *args]
    else:
        cmd = [sys.executable, script, *args]
    if cwd is None:
        # 关键：PYbook 的运行时 .c/.h 用裸名按 cwd 解析，IDE 也是用 cwd=HOME 跑的。
        # 所以统一把 cwd 设为 HOME（pybk_main/pybk_build 都依赖此约定）。
        cwd = home_dir()
    cwd = _winpath(cwd)
    if not os.path.isdir(cwd):
        cwd = None
    try:
        p = subprocess.run(
            cmd, capture_output=True, text=True,
            encoding="utf-8", errors="replace",
            cwd=cwd, env=env or child_env(), timeout=timeout,
        )
        return p.returncode, p.stdout, p.stderr
    except subprocess.TimeoutExpired as ex:
        return -1, (ex.stdout or ""), (ex.stderr or "") + "\n(超时)"


def fingerprint(message):
    """把报错归一化成稳定指纹（去行号、去数字、去标识符），对应 Smokeroor 思路。
    同类错误（只是行号/变量名不同）会落到同一指纹，方便 AI 改-验循环。"""
    norm = re.sub(r"第\s*\d+\s*行", "", message)
    norm = re.sub(r"\d+(\.\d+)?", "N", norm)
    norm = re.sub(r"[A-Za-z_][A-Za-z0-9_]*", "X", norm)
    norm = re.sub(r"[一-鿿]+", "C", norm)
    return hashlib.sha1(norm.strip().encode("utf-8")).hexdigest()[:8]


# ---------------------------------------------------------------------------
# 清单（pybook.md）解析
# ---------------------------------------------------------------------------
def parse_manifest(path):
    """读 pybook.md 清单。段：编译器 / 项目 / 工程 / 依赖 / 工作区。

    v1.2 起「## 工程」段与 PYBOOK.toml 对齐（entry/include/target/cache/
    separate，中英文键都认）——pybook.md 是唯一事实源，TOML 只读兼容。
    依赖条目支持版本后缀：`- 名 => 路径 @1.2.0`（deps 元素为三元组）。
    """
    data = {"home": None, "deps": [], "members": [],
            "name": "", "version": "", "desc": "",
            "entry": "", "includes": [], "target": "app.exe",
            "cache": False, "separate": False}
    if not os.path.isfile(path):
        return data
    section = None
    for line in open(path, encoding="utf-8"):
        s = line.strip()
        if s.startswith("## "):
            section = s[3:].strip()
            continue
        if section == "编译器":
            m = re.match(r"home:\s*(.+)", s)
            if m:
                data["home"] = m.group(1).strip()
        elif section == "项目":
            m = re.match(r"(name|名称|version|版本|desc|描述)\s*[:：]\s*(.+)", s)
            if m:
                key, val = m.group(1), m.group(2).strip()
                if key in ("name", "名称"):
                    data["name"] = val
                elif key in ("version", "版本"):
                    data["version"] = val
                elif key in ("desc", "描述"):
                    data["desc"] = val
        elif section == "工程":
            m = re.match(r"(entry|入口|include|包含|target|目标|cache|缓存|separate|拆解编译)\s*[:：]\s*(.+)", s)
            if m:
                key, val = m.group(1), m.group(2).strip()
                if key in ("entry", "入口"):
                    data["entry"] = val
                elif key in ("include", "包含"):
                    data["includes"].append(val)
                elif key in ("target", "目标"):
                    data["target"] = val
                elif key in ("cache", "缓存"):
                    data["cache"] = val.lower() in ("true", "1", "yes", "是", "开")
                elif key in ("separate", "拆解编译"):
                    data["separate"] = val.lower() in ("true", "1", "yes", "是", "开")
        elif section == "依赖":
            if s.startswith("-"):
                body = s[1:].strip()
                dep_ver = ""
                m = _VER_RE.search(body)
                if m:
                    dep_ver = m.group(1)
                    body = body[:m.start()].rstrip()
                if "=>" in body:
                    name, _, p = body.partition("=>")
                    data["deps"].append((name.strip(), p.strip(), dep_ver))
                else:
                    base = os.path.splitext(os.path.basename(body))[0]
                    data["deps"].append((base, body.strip(), dep_ver))
        elif section == "工作区":
            if s.startswith("-"):
                data["members"].append(s[1:].strip())
    return data


def parse_manifest_text(text):
    """和 parse_manifest 同款规则，但输入是字符串——解包后的包清单.md 用。
    只填 deps（名 => 路径 @版本；路径在包内无意义，install 按名从 registry 取）。"""
    data = {"deps": []}
    section = None
    for line in text.splitlines():
        s = line.strip()
        if s.startswith("## "):
            section = s[3:].strip()
            continue
        if section == "依赖" and s.startswith("- ") and "（无）" not in s:
            body = s[2:].strip()
            m = re.match(r"^(.+?)\s*=>\s*(.+?)(?:\s*@([\w.]+))?$", body)
            if m:
                data["deps"].append((m.group(1).strip(), m.group(2).strip(), m.group(3) or ""))
            else:
                m2 = re.match(r"^(.+?)\s*@([\w.]+)$", body)
                if m2:
                    data["deps"].append((m2.group(1).strip(), "(registry)", m2.group(2)))
                else:
                    data["deps"].append((body, "(registry)", ""))
    return data


def _section_insert_index(lines, section):
    """确保 pybook.md 里有某个 ## 段，返回「该段内容末尾、下一段之前」的插入行号。
    lines 会被原地修改（必要时在文件尾新建该段）。"""
    idx = None
    for i, ln in enumerate(lines):
        if ln.strip() == f"## {section}":
            idx = i
            break
    if idx is None:
        if lines and lines[-1].strip():
            lines.append("")
        lines.append(f"## {section}")
        lines.append("")
        idx = len(lines) - 2  # 段头所在行
    # 找段尾：到下一个 ## 段或文件尾
    end = idx + 1
    while end < len(lines) and not lines[end].strip().startswith("## "):
        end += 1
    # 在段内最后一条非空内容之后插入
    insert = end
    for j in range(end - 1, idx, -1):
        if lines[j].strip():
            insert = j + 1
            break
    return insert


def _ensure_manifest_section(manifest, section):
    """兼容旧签名：返回 (行列表, 段起始索引或None)。"""
    lines = []
    if os.path.isfile(manifest):
        lines = open(manifest, encoding="utf-8").read().split("\n")
    idx = None
    for i, ln in enumerate(lines):
        if ln.strip() == f"## {section}":
            idx = i
            break
    if idx is None:
        if lines and lines[-1].strip():
            lines.append("")
        lines.append(f"## {section}")
        lines.append("")
        idx = len(lines) - 1
    return lines, idx


# ---------------------------------------------------------------------------
# 格式化（块级缩进，v1 启发式）
# ---------------------------------------------------------------------------
def fmt_text(text):
    """块级缩进整理。规则：以 { 开启一层缩进，以 } 收一层。
    简化假设：一行一条语句；括号不出现在字符串/注释内。
    v1.1 修正：# 注释起始到行尾不参与括号计数（此前文档注释里的示例
    lambda(x) { ... } 会把深度带偏，注释被缩进搞乱）。"""
    out_lines = []
    depth = 0
    for raw in text.split("\n"):
        line = raw.rstrip()
        if line.strip() == "":
            out_lines.append("")
            continue
        opens = closes = 0
        instr = False
        quote = ""
        for ch in line:
            if instr:
                if ch == quote:
                    instr = False
            else:
                if ch == "#":
                    break              # 注释开始：本行剩余内容不参与括号计数
                if ch in "\"'":
                    instr = True
                    quote = ch
                elif ch == "{":
                    opens += 1
                elif ch == "}":
                    closes += 1
        if closes > 0:
            depth = max(0, depth - closes)
        out_lines.append(INDENT * depth + line.strip())
        if opens > 0:
            depth += opens
    result = "\n".join(out_lines)
    if not result.endswith("\n"):
        result += "\n"
    return result


# ---------------------------------------------------------------------------
# .expect 解析与匹配（与 Smokeroor 同格式，保证一致）
# ---------------------------------------------------------------------------
def load_expect(pybk_path):
    """读 <file>.expect → (期望退出码|None, 正向关键字[], 反向关键字[])。
    格式：第1行=期望退出码（整数，可空）；其余行=正向关键字（任一命中即过），
    行首 '!' = 反向断言（不应出现）；'re:' 前缀 = 正则。"""
    p = pybk_path + ".expect"
    if not os.path.isfile(p):
        return None, [], []
    pos, neg = [], []
    rc = None
    with open(p, encoding="utf-8") as f:
        for line in f:
            line = line.rstrip("\n")
            if not line.strip():
                continue
            if rc is None:
                try:
                    rc = int(line.strip())
                    continue
                except ValueError:
                    pass
            if line.startswith("!"):
                neg.append(line[1:].strip())
            else:
                pos.append(line.strip())
    return rc, pos, neg


def match_expect(expected_rc, actual_rc, out_text, pos, neg, strict=False):
    """按 Smokeroor 的 .expect 格式比对：退出码匹配 + 任一正向关键字命中 + 无反向关键字。
    返回 (ok, 原因)。"""
    rc_ok = (expected_rc is None) or (expected_rc == actual_rc)
    hay = out_text if strict else (out_text or "").lower()

    def hit(key):
        if key.startswith("re:"):
            pat = key[3:]
            try:
                return re.search(pat, out_text, 0 if strict else re.IGNORECASE) is not None
            except re.error:
                return pat in out_text
        needle = key if strict else key.lower()
        return needle in hay

    pos_ok = (not pos) or any(hit(k) for k in pos)
    neg_ok = all(not hit(k) for k in neg)
    ok = rc_ok and pos_ok and neg_ok
    reason = ""
    if not rc_ok:
        reason = f"退出码期望 {expected_rc}，实际 {actual_rc}"
    elif not pos_ok:
        reason = "没看到期望关键字：" + " / ".join(pos) if pos else "（无正向关键字）"
    elif not neg_ok:
        reason = "出现了不该有的：" + " / ".join(neg)
    return ok, reason


# ---------------------------------------------------------------------------
# 子命令实现
# ---------------------------------------------------------------------------
def _manifest_from_toml(toml_path, home):
    """把旧 PYBOOK.toml 搬进 pybook.md（init 的一次性迁移路径）。
    TOML 裸键只允许 ASCII，故读 [project] 段的英文键（中文键兼容）。失败返回 None。"""
    try:
        import tomllib
        with open(toml_path, "rb") as f:
            raw = tomllib.load(f)
    except Exception:
        return None
    sec = raw.get("project", raw.get("工程", raw))
    lines = [
        "# PYbook 项目清单（由 PYBOOK.toml 迁移生成，pybktl 读取此文件）",
        "# 格式就是 markdown，人和 AI 都能直接读写。",
        "",
        "## 项目",
        f"name: {sec.get('name') or sec.get('名称') or '未命名项目'}",
        f"version: {sec.get('version') or sec.get('版本') or '0.1.0'}",
        f"desc: {sec.get('description') or sec.get('描述') or '一句话描述这个项目'}",
        "",
        "## 工程",
    ]
    entry = sec.get("entry") or sec.get("入口")
    if entry:
        lines.append(f"entry: {entry}")
    inc = sec.get("include") or sec.get("包含") or []
    if isinstance(inc, str):
        inc = [inc]
    for d in inc:
        lines.append(f"include: {d}")
    target = sec.get("target") or sec.get("目标")
    if target:
        lines.append(f"target: {target}")
    if "cache" in sec or "缓存" in sec:
        lines.append(f"cache: {'true' if (sec.get('cache') or sec.get('缓存')) else 'false'}")
    if "separate" in sec or "拆解编译" in sec:
        lines.append(f"separate: {'true' if (sec.get('separate') or sec.get('拆解编译')) else 'false'}")
    lines += [
        "",
        "## 编译器",
        f"home: {home}",
        "",
        "## 依赖",
        "# - 物理引擎 => ../libs/physics.pybk @1.0.0",
        "",
        "## 工作区",
    ]
    return "\n".join(lines) + "\n"


def _dep_add(manifest, name, path, ver=""):
    """往 pybook.md「依赖」段加一条。同名已登记（不论版本）→ 原位更新：
    install 升级版本是「改」不是「再加一条」，清单不会堆重复行。
    返回 (是否新增, 条目文本)。pkg add 与 pkg install 共用。"""
    lines = (open(manifest, encoding="utf-8").read().split("\n")
             if os.path.isfile(manifest) else [])
    ins = _section_insert_index(lines, "依赖")
    entry = f"- {name} => {path}" + (f" @{ver}" if ver else "")
    for i, l in enumerate(lines):
        ls = l.strip()
        if ls.startswith(f"- {name} ") or ls == f"- {name}":
            if ls == entry.strip():
                return False, entry          # 完全相同：跳过
            lines[i] = entry                 # 同名升级：原位替换
            open(manifest, "w", encoding="utf-8").write("\n".join(lines))
            return True, entry
    lines.insert(ins, entry)
    open(manifest, "w", encoding="utf-8").write("\n".join(lines))
    return True, entry


def cmd_init(args):
    manifest = os.path.join(os.getcwd(), MANIFEST)
    if os.path.isfile(manifest):
        out(f"· 已存在 {MANIFEST}，跳过。")
        return 0
    home = (os.environ.get("PYBOOK_HOME")
            or _manifest_home(manifest)
            or _search_up_for("pybk_main.py", _self_dir())
            or "<PYbook 根目录>")
    # 旧工程迁移：有 PYBOOK.toml 但没有 pybook.md 时，按 TOML 生成清单。
    # pybook.md 是唯一事实源；TOML 保留只读兼容，init 负责一次性搬运。
    legacy = os.path.join(os.getcwd(), "PYBOOK.toml")
    if os.path.isfile(legacy):
        body = _manifest_from_toml(legacy, home)
        if body is not None:
            open(manifest, "w", encoding="utf-8").write(body)
            out(f"✓ 已从 PYBOOK.toml 迁移生成 {MANIFEST}（TOML 保留作只读兼容）")
            if getattr(args, "team", False):
                _scaffold_team_project(manifest, home)
            return 0
        out("· PYBOOK.toml 解析失败，改用空白模板。")
    tmpl = (
        "# PYbook 项目清单（pybktl 读取此文件）\n"
        "# 格式就是 markdown，人和 AI 都能直接读写。\n\n"
        "## 项目\n"
        "name: 未命名项目\n"
        "version: 0.1.0\n"
        "desc: 一句话描述这个项目\n\n"
        "## 工程\n"
        "entry: src/main.pybk\n"
        "include: src\n"
        "# target: app.exe        # 编译目标名\n"
        "# cache: false           # 产物缓存（增量构建）\n"
        "# separate: false        # 分模块独立编译\n\n"
        "## 编译器\n"
        f"home: {home}\n\n"
        "## 依赖\n"
        "# - 物理引擎 => ../libs/physics.pybk @1.0.0\n\n"
        "## 工作区\n"
        "# - games/披萨塔/main.pybk\n"
        "# - learn/pybook-3d-highway/自学验证.pybk\n"
    )
    open(manifest, "w", encoding="utf-8").write(tmpl)
    out(f"✓ 已生成 {MANIFEST}（编译器 home 指向 {home}）")
    out("  编辑「依赖」「工作区」「工程」段后，用 pkg/ws 子命令批量管理。")
    if getattr(args, "team", False):
        _scaffold_team_project(manifest, home)
    return 0


def _scaffold_team_project(manifest, home):
    """init --team：在清单基础上生成最小可构建的团队骨架。"""
    root = os.path.dirname(os.path.abspath(manifest))
    os.makedirs(os.path.join(root, "src"), exist_ok=True)
    os.makedirs(os.path.join(root, "tests"), exist_ok=True)
    main_py = os.path.join(root, "src", "main.pybk")
    if not os.path.isfile(main_py):
        open(main_py, "w", encoding="utf-8").write(
            "@ 项目>主程序\n"
            "GOING:{\n"
            "  vg.名 = \"新项目\"\n"
            "  ns.show(欢迎来到 $名 — v0.1.0)\n"
            "}STOP\n"
        )
    test_py = os.path.join(root, "tests", "测试_冒烟.pybk")
    if not os.path.isfile(test_py):
        open(test_py, "w", encoding="utf-8").write(
            "@ 测试>冒烟\n"
            "func 测试_启动(){\n"
            "  测试.断言相等(1 + 1, 2)\n"
            "  测试.断言真(真)\n"
            "}\n"
        )
    readme = os.path.join(root, "README.md")
    if not os.path.isfile(readme):
        open(readme, "w", encoding="utf-8").write(
            "# 未命名项目\n\n"
            "> 版本：见 pybook.md 的 `## 项目` 段（用 `pybktl version` 查看）。\n\n"
            "## 构建\n\n"
            "```\n"
            "pybktl build src/main.pybk      # 产出 build/main.pybc\n"
            "pybktl test tests/              # 跑 测试_* 用例\n"
            "pybktl version                 # 打印项目版本\n"
            "```\n"
        )
    gi = os.path.join(root, ".gitignore")
    gi_text = "build/\n*.pybc\n*.meta.json\n__pycache__/\n"
    if not os.path.isfile(gi):
        open(gi, "w", encoding="utf-8").write(gi_text)
    elif "build/" not in open(gi, encoding="utf-8").read():
        with open(gi, "a", encoding="utf-8") as f:
            f.write("\n" + gi_text)
    out("✓ 已生成团队骨架：src/main.pybk · tests/测试_冒烟.pybk · README.md · .gitignore")
    out("  现在可以：pybktl build src/main.pybk   然后   pybktl test tests/")


def _parse_check_json(stdout):
    data = None
    for ln in reversed(stdout.strip().splitlines()):
        try:
            data = json.loads(ln)
            break
        except Exception:
            continue
    return data


def _log_lookaround(script, cmd, rc, stdout, stderr, todo_id=None, dur=None):
    """若 script 所在（或上级）文件夹开启了日志循环，把本次运行记进两处台账。

    - LookAround → lookaround.md（人读的流水账 + diff）
    - HotTable   → hottable.jsonl（机器读的事件流，供热度打分）
    两边各有各的标记文件，互不依赖：哪个开着就记哪个，都没开就是零副作用。"""
    root = lookaround.find_lookaround_root(os.path.dirname(os.path.abspath(script)))
    if root:
        lookaround.log_run(root, script, cmd, rc, stdout, stderr, todo_id=todo_id)
    hroot = hottable.find_hottable_root(os.path.dirname(os.path.abspath(script)))
    if hroot:
        hottable.log_run(hroot, script, rc, stdout=stdout, stderr=stderr,
                         cmd=cmd, dur=dur, todo_id=todo_id)


def cmd_check(args):
    main = locate_main()
    rc, stdout, stderr = run_tool(main, "--check-json", _winpath(args.file))
    data = _parse_check_json(stdout)
    sf = os.path.abspath(_winpath(args.file))
    cmd = "pybktl check " + os.path.basename(args.file)
    if data and data.get("ok"):
        out(f"✓ {args.file}  编译通过（静态：语法 + 语义，未 gcc 未运行）")
        _log_lookaround(sf, cmd, rc, stdout, stderr)
        return 0
    if data:
        line = data.get("line")
        msg = data.get("message", "")
        fp = fingerprint(msg)
        loc = ""
        if line and f"第 {line} 行" not in msg:
            loc = f"第 {line} 行"
        head = " ".join(filter(None, [f"✗ {args.file}", loc, f"[指纹 {fp}]"]))
        err(f"{head}  {msg}")
    else:
        err(stderr.strip() or stdout.strip() or "未知错误（编译器未输出 JSON）")
    _log_lookaround(sf, cmd, rc, stdout, stderr)
    return 1


# ---------------------------------------------------------------- 可读性 lint（团队代码规范）
# 直接复用 pybk_front.parse() 走真实 AST，不修改编译器任何字节。
_LINT_STMT_FIELDS = {
    "FnDef": ["body"],
    "Lambda": ["body"],
    "Around": ["body"],
    "ForIn": ["body"],
    "Aging": ["body"],
    "CdBlock": ["body"],
    "VcChain": ["arms"],
    "TryCatch": ["body", "handler"],
    "OnError": ["body", "handler"],
    "HmFrame": ["body"],
    "HmLive": ["body"],
    "HmPageStmt": ["body"],
    "HmBlockDef": ["body"],
}
_LINT_GENERIC = {"a", "b", "c", "x", "y", "z", "m", "n", "test", "测试", "函数",
                 "类", "func", "tmp", "temp", "foo", "bar", "临时", "test1", "调试", "未命名"}
_LINT_GENERIC_RE = re.compile(r"^(函数|测试|test|func|类|方法|临时|tmp|temp)[\d_]*$", re.I)


def _lint_is_placeholder(name):
    if not name:
        return True
    if name in _LINT_GENERIC:
        return True
    if _LINT_GENERIC_RE.match(name):
        return True
    if len(name) == 1 and name.isascii() and name.isalnum():
        return True
    return False


def _lint_all_nodes(node):
    out = []
    def walk(n):
        if n is None or isinstance(n, (int, float, str, bool)):
            return
        if isinstance(n, (list, tuple)):
            for x in n:
                walk(x)
            return
        if hasattr(n, "__dict__"):
            out.append(n)
            for v in vars(n).values():
                walk(v)
    walk(node)
    return out


def _lint_max_line(node):
    return max((n.line for n in _lint_all_nodes(node)
                if isinstance(getattr(n, "line", None), int)), default=0)


def _lint_stmt_lists(node):
    """返回 node 内部各嵌套语句块（list[stmt]）。"""
    res = []
    fields = _LINT_STMT_FIELDS.get(type(node).__name__)
    if not fields:
        return res
    for f in fields:
        v = getattr(node, f, None)
        if f == "arms":  # VcChain: [(cond, body), ...]
            for arm in (v or []):
                if isinstance(arm, (list, tuple)) and len(arm) >= 2:
                    res.append(arm[1])
        elif isinstance(v, list):
            res.append(v)
    return res


def _lint_nesting(stmts, depth):
    m = depth
    for st in (stmts or []):
        for sl in _lint_stmt_lists(st):
            m = max(m, _lint_nesting(sl, depth + 1))
    return m


def _lint_text_of(node):
    """收集节点子树里所有字符串字面量（含 NsShow.parts 元组），用于调试残留启发式。"""
    parts = []
    def walk(o):
        if isinstance(o, str):
            parts.append(o)
        elif isinstance(o, (list, tuple)):
            for x in o:
                walk(x)
        elif hasattr(o, "__dict__"):
            for v in vars(o).values():
                walk(v)
    walk(node)
    return " ".join(parts)


def cmd_lint(args):
    """可读性 lint：命名 / 函数长度 / 嵌套深度 / 调试残留 / 空函数 / TODO 标记。"""
    root = home_dir()
    if not root:
        err("找不到 PYbook 根目录（无法加载前端解析器）。请在 pybook 仓库内或设 PYBOOK_HOME。")
        return 2
    if root not in sys.path:
        sys.path.insert(0, root)
    try:
        import pybk_front
    except Exception as e:
        err(f"无法加载 pybk_front：{e}")
        return 2

    max_lines, max_depth = args.max_lines, args.max_depth
    paths = args.paths or ["."]
    files = []
    for p in paths:
        if os.path.isdir(p):
            for dp, _, fns in os.walk(p):
                if os.path.basename(dp) in ("build", "node_modules", "__pycache__"):
                    continue
                for fn in fns:
                    if fn.endswith(".pybk"):
                        files.append(os.path.join(dp, fn))
        elif os.path.isfile(p) and p.endswith(".pybk"):
            files.append(p)
    if not files:
        out("没有找到 .pybk 文件。")
        return 0

    total_e = total_w = total_i = 0
    rc = 0
    for f in files:
        src = open(f, encoding="utf-8-sig").read()
        try:
            prog = pybk_front.parse(src)
        except Exception as e:
            # 主程序文件要求恰好一个 GOING 块；纯库/测试文件没有 GOING，回退到 parse_module
            if "GOING" in str(e):
                try:
                    prog = pybk_front.parse_module(src)
                except Exception as e2:
                    err(f"✗ {f}  解析失败（先 pybktl check）：{e2}")
                    total_e += 1
                    rc = 1
                    continue
            else:
                err(f"✗ {f}  解析失败（先 pybktl check）：{e}")
                total_e += 1
                rc = 1
                continue
        vios = []  # (sev, line, msg)
        if not prog.go_body and not prog.fns and not prog.classes:
            vios.append(("W", 1, "文件既无 GOING 主程序块、也无任何顶层函数/类，可能是空文件"))
        defs = list(prog.fns) + list(prog.macros or [])
        for cd in (prog.classes or []):
            defs.append(cd)
            for m in getattr(cd, "methods", []) or []:
                defs.append(m)
            for m in getattr(cd, "static_methods", []) or []:
                defs.append(m)
        for d in defs:
            nm = getattr(d, "name", "")
            dl = getattr(d, "line", 1)
            if _lint_is_placeholder(nm):
                vios.append(("E", dl, f"命名「{nm}」是占位名，应表达意图（动词/名词/中文均可，别用 a/test/函数1）"))
            span = _lint_max_line(d) - dl
            if span > max_lines:
                vios.append(("W", dl, f"「{nm}」过长（约 {span} 行 > {max_lines}），建议拆函数"))
            if hasattr(d, "body"):
                depth = _lint_nesting(getattr(d, "body") or [], 1)
                if depth > max_depth:
                    vios.append(("W", dl, f"「{nm}」嵌套过深（{depth} 层 > {max_depth}），建议抽函数降层"))
                if not getattr(d, "body"):
                    vios.append(("W", dl, f"「{nm}」函数体为空（可能是未完成桩）"))
        for n in _lint_all_nodes(prog):
            if type(n).__name__ == "NsShow":
                txt = _lint_text_of(n)
                low = txt.lower()
                if "调试" in txt or "debug" in low or "print" in low:
                    vios.append(("W", getattr(n, "line", 1), f"疑似遗留调试输出：ns.show(…{txt[:20]}…)，发布前清理"))
        for i, line in enumerate(src.splitlines(), 1):
            if re.search(r"\b(TODO|FIXME|XXX)\b", line, re.I):
                vios.append(("I", i, "发现 " + line.strip()[:60]))
        if not vios:
            out(f"✓ {f}  可读性 OK")
            continue
        ne = sum(1 for v in vios if v[0] == "E")
        nw = sum(1 for v in vios if v[0] == "W")
        ni = sum(1 for v in vios if v[0] == "I")
        total_e += ne; total_w += nw; total_i += ni
        out(f"--- {f}  ({ne} 错误 / {nw} 警告 / {ni} 提示) ---")
        sym = {"E": "✗", "W": "⚠", "I": "ℹ"}
        for sev, ln, msg in vios:
            out(f"  {sym[sev]} [{sev}] 第 {ln} 行  {msg}")
        if ne > 0:
            rc = 1
    out(f"可读性 lint 完成：{len(files)} 文件，{total_e} 错误 / {total_w} 警告 / {total_i} 提示")
    if args.strict and (total_e > 0 or total_w > 0):
        rc = 1
    return rc


def cmd_build(args):
    build = locate_build()
    src = _winpath(args.file)
    if not os.path.isfile(src):
        err(f"找不到文件: {src}")
        return 2
    if args.out:
        out_path = args.out
    else:
        # 隔离构建目录：产物统一进 build/（ASCII 路径，避开中文路径导致 gcc 乱码；也保持源码树干净）
        bdir = os.path.join(os.getcwd(), "build")
        os.makedirs(bdir, exist_ok=True)
        out_path = os.path.join(bdir, os.path.splitext(os.path.basename(src))[0] + ".pybc")
    out_path = _winpath(out_path)
    rc, stdout, stderr = run_tool(build, src, out_path)
    sf = os.path.abspath(src)
    cmd = "pybktl build " + os.path.basename(src)
    if rc != 0:
        err(stderr.strip() or stdout.strip() or "编译失败")
        _log_lookaround(sf, cmd, rc, stdout, stderr)
        return rc
    out(f"✓ 已编译: {src}")
    out(f"  → 产物: {out_path}  ({os.path.getsize(out_path)} 字节)")
    # 版本戳：把项目版本/名称写进产物同名的 .meta.json（团队产品自带版本元数据）
    try:
        import hashlib, datetime, json as _json
        mf = parse_manifest(os.path.join(os.getcwd(), MANIFEST))
        if mf.get("version") or mf.get("name"):
            meta = {
                "name": mf.get("name") or "",
                "version": mf.get("version") or "",
                "desc": mf.get("desc") or "",
                "artifact": os.path.basename(out_path),
                "size": os.path.getsize(out_path),
                "sha256": hashlib.sha256(open(out_path, "rb").read()).hexdigest(),
                "built_at": datetime.datetime.now().isoformat(timespec="seconds"),
            }
            mp = out_path + ".meta.json"
            with open(mp, "w", encoding="utf-8") as _f:
                _json.dump(meta, _f, ensure_ascii=False, indent=2)
            out(f"  → 版本戳: {os.path.basename(mp)}  (v{meta['version']})")
    except Exception as _e:
        out(f"  （版本戳跳过：{_e}）")
    if stdout.strip():
        out("  ---- 反汇编摘要 ----")
        out(stdout.strip())
    out("  （可用 `pybktl run --vm <同名.pybc>` 执行此字节码产物）")
    _log_lookaround(sf, cmd, rc, stdout, stderr)
    return 0


def cmd_run(args):
    f = _winpath(args.file)
    if not os.path.isfile(f):
        err(f"找不到文件: {f}")
        return 2
    if getattr(args, "repair", False):
        # 概念神「修」：运行前先静态检查，有错就汇报并问你改不改，改完再跑
        clean, _ = repair.run_repair(f, auto=False)
        if not clean:
            out("⚠ repair 未全部修完，仍尝试运行（可能失败）。")
    extra = {}
    if args.shot_dir:
        sd = _winpath(args.shot_dir)
        os.makedirs(sd, exist_ok=True)
        extra["PYBOOK_SHOT_DIR"] = sd
    # HotTable：耗时也是热度信号（「跑一次 13 秒」和「0.2 秒」完全是两回事），
    # 所以这里顺带量一下时钟，写进结构化台账。
    _t_run = time.time()
    if args.vm or f.lower().endswith(".pybc"):
        if f.lower().endswith(".pybc"):
            if not os.path.isfile(locate_vm()):
                err("找不到 pyvm.exe（字节码运行时）。请用原生管线：pybktl run <文件.pybk>")
                return 2
            rc, stdout, stderr = run_tool(locate_vm(), f, env=child_env(extra))
        else:
            build = locate_build()
            rc, stdout, stderr = run_tool(build, f, "-r", env=child_env(extra))
    else:
        main = locate_main()
        rc, stdout, stderr = run_tool(main, f, env=child_env(extra))

    # LookAround：若本文件夹开启了日志循环，把这次运行（含运行时错误）追加进 lookaround.md
    _la_cmd = "pybktl run " + os.path.basename(f) + (" --vm" if (args.vm or f.lower().endswith('.pybc')) else "")
    _log_lookaround(f, _la_cmd, rc, stdout, stderr, todo_id=getattr(args, "todo", None),
                    dur=round(time.time() - _t_run, 3))
    if stdout.strip():
        out(stdout.strip())
    if stderr.strip():
        err(stderr.strip())
    if rc != 0:
        return rc
    if args.shot_dir:
        sd = _winpath(args.shot_dir)
        shots = [x for x in os.listdir(sd)] if os.path.isdir(sd) else []
        out(f"  （无头出图：在 {sd} 产出 {len(shots)} 张帧）")
    return 0


def cmd_fmt(args):
    args.file = _winpath(args.file)
    if not os.path.isfile(args.file):
        err(f"找不到文件: {args.file}")
        return 2
    src = open(args.file, encoding="utf-8-sig").read()
    new = fmt_text(src)
    if args.in_place:
        if new != src:
            open(args.file, "w", encoding="utf-8").write(new)
            out(f"✓ 已格式化（落盘）: {args.file}")
        else:
            out(f"· 无需改动: {args.file}")
            return 0
        if args.check:
            # 落盘后复检：确保格式化没把语法搞坏
            rc, _, _ = run_tool(locate_main(), "--check-json", args.file)
            if rc != 0:
                err("⚠ 警告：格式化后静态校验未通过！已回滚。")
                open(args.file, "w", encoding="utf-8").write(src)
                return 1
            out("✓ 落盘后复检通过")
        return 0
    # 预览模式
    old_lines = src.split("\n")
    new_lines = new.split("\n")
    changed = sum(1 for a, b in zip(old_lines, new_lines) if a.rstrip() != b.rstrip())
    out(new)
    out(f"--- 预览：{changed} 行缩进有变化（加 --in-place 落盘；--check 可落盘后复检）---")
    return 0


# ---------------------------------------------------------------------------
# 包管理 v1：锁文件 / .pybp 打包 / 本地 registry（文件分发先行）
# ---------------------------------------------------------------------------
def parse_lock(path):
    """读 pybook.lock，返回 {依赖名: (版本, 源路径, sha256)}。"""
    locks = {}
    if not os.path.isfile(path):
        return locks
    for line in open(path, encoding="utf-8"):
        s = line.strip()
        if not s.startswith("|"):
            continue
        cells = [c.strip() for c in s.strip("|").split("|")]
        if len(cells) != 5 or cells[0] in ("依赖", "") or set(cells[0]) <= set("-: "):
            continue  # 表头 / 分隔行
        name, ver, p, sha, _size = cells
        locks[name] = (ver, p, sha)
    return locks


def _sha256_file(ap):
    h = hashlib.sha256()
    with open(ap, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def _registry_dir(args):
    """本地 registry 目录：--registry > PYBOOK_REGISTRY > ~/.pybook/registry。"""
    reg = (getattr(args, "registry", None)
           or os.environ.get("PYBOOK_REGISTRY")
           or DEFAULT_REGISTRY)
    return _winpath(reg)


def _read_registry_index(reg):
    """读 registry 的 索引.md，返回 [(包名, 版本, 文件名, sha256, 字节, 时间),...]。"""
    rows = []
    path = os.path.join(reg, "索引.md")
    if not os.path.isfile(path):
        return rows
    for line in open(path, encoding="utf-8"):
        s = line.strip()
        if not s.startswith("|"):
            continue
        cells = [c.strip() for c in s.strip("|").split("|")]
        if len(cells) != 6 or cells[0] in ("包名", "") or set(cells[0]) <= set("-: "):
            continue
        rows.append(tuple(cells))
    return rows


def _write_registry_index(path, rows):
    lines = [
        "# PYbook 本地包索引（registry index）",
        "# 由 `pybktl pkg publish` 维护：包名 → 版本 → 文件。人/AI 可读，git 可直接分发。",
        "",
        "| 包名 | 版本 | 文件 | sha256 | 字节 | 发布时间 |",
        "|---|---|---|---|---|---|",
    ]
    for r in rows:
        lines.append("| " + " | ".join(r) + " |")
    open(path, "w", encoding="utf-8").write("\n".join(lines) + "\n")


def _pkg_name_version(srcdir, args):
    """包名/版本：--as/--version > 目录里 pybook.md 的「## 项目」段 > 目录名/0.1.0。"""
    name = os.path.basename(os.path.abspath(srcdir)) or "未命名包"
    version = "0.1.0"
    dir_md = os.path.join(srcdir, MANIFEST)
    if os.path.isfile(dir_md):
        md = parse_manifest(dir_md)
        name = md.get("name") or name
        version = md.get("version") or version
    if getattr(args, "as_name", None):
        name = args.as_name
    if getattr(args, "version", None):
        version = args.version
    return name, version


def _quality_gate(srcdir, force=False):
    """发布质量门：包内每个 .pybk 过一遍静态检查，有错拒绝打包。
    返回错误数；--force 时只警告不拒绝。"""
    import subprocess as _sp
    bad = []
    for dirpath, _dirs, fns in os.walk(srcdir):
        for fn in sorted(fns):
            if not fn.endswith('.pybk'):
                continue
            full = os.path.join(dirpath, fn)
            r = _sp.run([_sys_exec(), locate_main(), '--check-json', full], capture_output=True,
                        text=True, encoding='utf-8', errors='replace', timeout=120)
            line = (r.stdout or '').strip().splitlines()[-1] if (r.stdout or '').strip() else ''
            if r.returncode != 0 or (line.startswith('{') and '\"ok\": false' in line.replace(' ', '')):
                msg = line if line else (r.stderr or '未知错误').strip()[:160]
                # 库豁免：包里的 .pybk 是「库」，没有 GOING 块是合法的——
                # --check 按程序模式验会报「必须包含恰好一个 GOING 块」，
                # 只犯这一条的视为库文件放行，其余错误照拦。
                if 'GOING 块' in msg and '找不到文件' not in msg:
                    continue
                bad.append((os.path.relpath(full, srcdir), msg))
    if bad and not force:
        err('✗ 质量门：包内有编译不过的 .pybk（--force 可跳过）：')
        for rel, msg in bad:
            err(f'  - {rel}: {msg[:120]}')
        raise SystemExit(1)
    if bad:
        for rel, _m in bad:
            err(f'⚠ 质量门跳过错误（--force）: {rel}')
    return len(bad)


def _sys_exec():
    import sys as _s
    return _s.executable


def _pack_zip(srcdir, name, version, out_path):
    """把目录打成 .pybp（zip：包清单.md + 全部 .pybk，保持相对路径）。
    返回包文件 sha256；目录里没有 .pybk 抛 FileNotFoundError。"""
    files = []
    for dirpath, _dirs, fns in os.walk(srcdir):
        for fn in sorted(fns):
            if fn.endswith(".pybk"):
                full = os.path.join(dirpath, fn)
                rel = os.path.relpath(full, srcdir).replace("\\", "/")
                files.append((rel, full))
    if not files:
        raise FileNotFoundError(f"目录里没有 .pybk 文件: {srcdir}")
    # 传递依赖：包目录自己的 pybook.md「## 依赖」段原样带走（install 时按名解析）
    carried = []
    dir_md = os.path.join(srcdir, MANIFEST)
    if os.path.isfile(dir_md):
        for _n, _p, _v in parse_manifest(dir_md).get("deps", []):
            carried.append(f"- {_n} => (registry) @{_v}" if _v else f"- {_n} => (registry)")
    carried_text = "".join(f"{c}\n" for c in carried) or "- （无）\n"
    manifest_text = (
        f"# PYbook 包：{name}\n\n"
        "## 包信息\n"
        f"name: {name}\n"
        f"version: {version}\n"
        f"packed_at: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
        f"files: {len(files)}\n\n"
        "## 文件\n"
        + "".join(f"- {rel}\n" for rel, _ in files)
        + "\n## 依赖\n"
        + carried_text
    )
    with zipfile.ZipFile(out_path, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("包清单.md", manifest_text)
        for rel, full in files:
            zf.write(full, rel)
    return _sha256_file(out_path)


def _safe_extract(zf, dest):
    """解压并防 zip slip：条目解析后必须还在 dest 里。"""
    dest_abs = os.path.abspath(dest)
    for info in zf.infolist():
        target = os.path.abspath(os.path.join(dest, info.filename))
        if target != dest_abs and not target.startswith(dest_abs + os.sep):
            raise ValueError(f"包内有越界条目，已拒绝: {info.filename}")
    zf.extractall(dest)


def _ver_key(v):
    """版本排序键：1.2.0 < 1.10.0；预发布（带 -/+ 后缀）排同版本 stable 之后。"""
    core = re.split(r"[-+]", v.lstrip("v"))[0]
    parts = [int(x) if x.isdigit() else 0 for x in core.split(".")]
    while len(parts) < 4:
        parts.append(0)
    return tuple(parts) + (1 if re.search(r"[-+]", v) else 0,)


def _pkg_info_from_file(pybp):
    """直接从 .pybp 文件读 (包名, 版本, sha256)——文件分发用，不过 registry。"""
    with zipfile.ZipFile(pybp) as zf:
        try:
            text = zf.read("包清单.md").decode("utf-8")
        except KeyError:
            raise ValueError("不是有效的 .pybp：缺 包清单.md")
    name = version = ""
    for line in text.split("\n"):
        m = re.match(r"(name|version)\s*[:：]\s*(.+)", line.strip())
        if m:
            if m.group(1) == "name":
                name = m.group(2).strip()
            else:
                version = m.group(2).strip()
    if not name or not version:
        raise ValueError("包清单.md 里缺 name/version")
    return name, version, _sha256_file(pybp)


def _pkg_install(args):
    """装包：解压到 libs/<包名>/，并把包内每个 .pybk 登记成一条带版本的依赖。
    来源两种：registry 里的包名（可 @版本），或直接一个 .pybp 文件路径。"""
    what = (args.name or "").strip()
    if not what:
        err("用法: pybktl pkg install <包名[@版本] | 路径.pybp> [--registry 路径]")
        return 2
    root = os.getcwd()
    if what.lower().endswith(PKG_EXT) and os.path.isfile(_winpath(what)):
        # 文件分发：人家直接把 .pybp 发给你，不过 registry
        src = _winpath(what)
        try:
            name, version, _sha = _pkg_info_from_file(src)
        except (zipfile.BadZipFile, OSError, ValueError) as e:
            err(f"✗ 读包失败: {e}")
            return 1
    else:
        want_name, want_ver = what, ""
        m = _VER_RE.search(what)
        if m:
            want_ver = m.group(1)
            want_name = what[:m.start()].rstrip()
        reg = _registry_dir(args)
        rows = _read_registry_index(reg)
        cands = [r for r in rows if r[0] == want_name]
        if want_ver:
            cands = [r for r in cands if r[1] == want_ver]
        if not cands:
            err(f"✗ registry 里找不到包：{want_name}" + (f" @{want_ver}" if want_ver else ""))
            err(f"  （registry: {reg}；看 registry 里的 索引.md，或直接给 .pybp 文件路径）")
            return 1
        name, version, fname, sha = max(cands, key=lambda r: _ver_key(r[1]))[:4]
        src = os.path.join(reg, fname)
        if not os.path.isfile(src):
            err(f"✗ 包文件缺失: {src}")
            return 1
        got = _sha256_file(src)
        if got != sha:
            err(f"✗ 包文件校验和不符（索引记 {sha[:12]}…，实际 {got[:12]}…）：{src}")
            return 1
    # 文件直装路径没有 registry 索引可查 → 用包内清单核对 sha（完整性）
    dest = os.path.join(root, "libs", name)
    os.makedirs(dest, exist_ok=True)
    try:
        with zipfile.ZipFile(src) as zf:
            _safe_extract(zf, dest)
            pkg_md = None
            for cand in ("包清单.md", "pybook.md"):
                try:
                    pkg_md = zf.read(cand).decode("utf-8")
                    break
                except KeyError:
                    continue
    except (zipfile.BadZipFile, OSError, ValueError) as e:
        err(f"✗ 解包失败: {e}")
        return 1
    # 包内每个 .pybk 登记成一条带版本依赖（vendor 模型：pkg sync 再分发到成员旁）
    added, added_files = 0, []
    for dirpath, _dirs, files in os.walk(dest):
        for fn in sorted(files):
            if not fn.endswith(".pybk"):
                continue
            full = os.path.join(dirpath, fn)
            rel = os.path.relpath(full, root).replace("\\", "/")
            _dep_add(os.path.join(root, MANIFEST), fn[:-5], rel, version)
            added += 1
            added_files.append(rel)
    out(f"✓ 已安装 {name} @{version} → libs/{name}/（{added} 个模块）")

    # 加强③：冲突预检——新包的函数名和项目已有函数撞名时，
    # 引用合并会在编译期报「重复定义」；提前到这里大声警告。
    import re as _re
    def _func_names(path):
        try:
            return set(_re.findall(r"^\s*func\s+([^\s(]+)", open(path, encoding="utf-8-sig").read(), _re.M))
        except OSError:
            return set()
    newnames = set()
    for rel in added_files:
        newnames |= _func_names(os.path.join(root, rel))
    oldnames = set()
    for p in glob.glob(os.path.join(root, "*.pybk")):
        if os.path.abspath(p) not in {os.path.abspath(os.path.join(root, r)) for r in added_files}:
            oldnames |= _func_names(p)
    clash = sorted(newnames & oldnames)
    if clash:
        out("⚠ 函数名冲突预检：以下名字项目里已存在，引用合并时会报重复定义——先改名：")
        for c in clash:
            out(f"  - {c}")

    # 加强①：直接 vendor 一份到项目根——引用("名") 立即可用，不用再跑 sync。
    # 守卫：根里已有同名文件（比如用户自己的 main.pybk）绝不覆盖——
    # 包模块不许反客为主；更新走显式的 pkg sync。
    copied = 0
    for rel in added_files:
        srcf = os.path.join(root, rel)
        dst = os.path.join(root, os.path.basename(rel))
        if os.path.isfile(srcf) and not os.path.isfile(dst):
            shutil.copy(srcf, dst)
            copied += 1
    if copied:
        out(f"  已同步 {copied} 个模块到项目根：引用(\"名\") 现在就能用")

    # 加强②：传递依赖——包清单.md 的「## 依赖」段（- 名 => 路径 @版本）自动安装
    if pkg_md:
        pm = parse_manifest_text(pkg_md)
        for dn, _dp, dv in pm.get("deps", []):
            already = os.path.isdir(os.path.join(root, "libs", dn))
            out(f"  传递依赖: {dn}" + (f" @{dv}" if dv else "") +
                ("（已装，跳过）" if already else ""))
            if not already:
                sub = argparse.Namespace(name=f"{dn}@{dv}" if dv else dn,
                                         registry=getattr(args, "registry", None),
                                         out=None, force=getattr(args, "force", False))
                _pkg_install(sub)

    out("  完成。更新依赖版本：pkg install 名@新版本；锁定：pkg lock")
    return 0


def cmd_pkg(args):
    manifest = os.path.join(os.getcwd(), MANIFEST)
    act = args.pkg_action
    if act == "add":
        raw = (args.path or "").strip()
        ver = ""
        m = _VER_RE.search(raw)
        if m:
            ver = m.group(1)
            raw = raw[:m.start()].rstrip()
        if not args.name or not raw:
            err("用法: pybktl pkg add <名> <路径> [@版本]")
            return 2
        added, entry = _dep_add(manifest, args.name, raw, ver)
        out(("✓ 已加入依赖: " if added else "· 已存在: ") + entry)
        return 0
    if act == "lock":
        data = parse_manifest(manifest)
        if not data["deps"]:
            out("· 清单里没有依赖，无需锁定。")
            return 0
        root = os.getcwd()
        rows = []
        for name, p, ver in data["deps"]:
            ap = p if os.path.isabs(p) else os.path.join(root, p)
            if not os.path.isfile(ap):
                err(f"✗ 依赖源不存在: {p}（{name}）")
                return 1
            rows.append((name, ver or "-", p, _sha256_file(ap),
                         str(os.path.getsize(ap))))
        now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        lines = [
            "# PYbook 依赖锁（pybook.lock）",
            "# 由 `pybktl pkg lock` 生成：记录每个依赖锁定时的校验和，勿手改。",
            "# `pkg sync` 会逐条核对；源文件变了会报错（--force 可跳过）。",
            "",
            "## 锁定信息",
            f"manifest: {MANIFEST}",
            f"locked_at: {now}",
            f"count: {len(rows)}",
            "",
            "## 锁定条目",
            "| 依赖 | 版本 | 源路径 | sha256 | 字节 |",
            "|---|---|---|---|---|",
        ]
        for r in rows:
            lines.append("| " + " | ".join(r) + " |")
        open(os.path.join(root, LOCKFILE), "w", encoding="utf-8").write(
            "\n".join(lines) + "\n")
        out(f"✓ 已锁定 {len(rows)} 个依赖 → {LOCKFILE}")
        for name, ver, p, sha, size in rows:
            out(f"  - {name} {ver}  {sha[:12]}…  ({size} 字节)")
        out("  提示：把 pybook.lock 提交进 git，全组构建结果即可复现。")
        return 0
    if act == "sync":
        data = parse_manifest(manifest)
        if not data["deps"]:
            out("· 清单里没有依赖，跳过。")
            return 0
        root = os.getcwd()
        locks = parse_lock(os.path.join(root, LOCKFILE))
        if locks and not getattr(args, "force", False):
            drift = []
            for name, p, ver in data["deps"]:
                if name not in locks:
                    drift.append(f"{name}: 锁里没有（lock 之后新增的依赖？重跑 pkg lock）")
                    continue
                _lv, _lp, lsha = locks[name]
                ap = p if os.path.isabs(p) else os.path.join(root, p)
                if not os.path.isfile(ap):
                    drift.append(f"{name}: 源文件不存在 {p}")
                    continue
                sha = _sha256_file(ap)
                if sha != lsha:
                    drift.append(f"{name}: 校验和不符（锁 {lsha[:12]}… / 现 {sha[:12]}…）")
            if drift:
                err("✗ 依赖与 pybook.lock 不符，已停止同步：")
                for d in drift:
                    err(f"  - {d}")
                err("  确认改动无误就重跑 `pkg lock` 更新锁；想强行同步加 --force。")
                return 1
            out(f"· 锁校验通过（{len(locks)} 条）")
        targets = set()
        for m in data["members"]:
            targets.add(os.path.dirname(os.path.abspath(m)) or ".")
        targets.add(os.getcwd())
        copied = 0
        for name, p, ver in data["deps"]:
            ap = p if os.path.isabs(p) else os.path.join(root, p)
            if not os.path.isfile(ap):
                err(f"✗ 依赖源不存在: {p}")
                continue
            base = os.path.basename(p)
            for t in targets:
                os.makedirs(t, exist_ok=True)
                shutil.copy(ap, os.path.join(t, base))
                copied += 1
        out(f"✓ 同步完成：{len(data['deps'])} 个依赖 × {len(targets)} 个目标目录 = {copied} 次复制")
        out("  （依赖已放到各成员目录旁，引用(\"模块\") 现在能解析）")
        return 0
    if act == "list":
        data = parse_manifest(manifest)
        locks = parse_lock(os.path.join(os.getcwd(), LOCKFILE))
        if not data["deps"]:
            out("· 清单里没有依赖。")
            return 0
        out(f"依赖 {len(data['deps'])} 条（锁：{'有' if locks else '无'}）：")
        for name, p, ver in data["deps"]:
            if name not in locks:
                tag = "– 未锁定"
            else:
                _lv, _lp, lsha = locks[name]
                ap = p if os.path.isabs(p) else os.path.join(os.getcwd(), p)
                ok = os.path.isfile(ap) and _sha256_file(ap) == lsha
                tag = "✓ 已锁定" if ok else "✗ 与锁不符"
            out(f"  - {name}{(' @' + ver) if ver else ''}  => {p}   {tag}")
        try:
            reg = _registry_dir(args)
            rows2 = _read_registry_index(reg)
            latest = {}
            for r2 in rows2:
                if r2[0] not in latest or _ver_key(r2[1]) > _ver_key(latest[r2[0]]):
                    latest[r2[0]] = r2[1]
            stale = [(n, v, latest[n]) for n, _p, v in data["deps"]
                     if n in latest and v and _ver_key(v) < _ver_key(latest[n])]
            if stale:
                out("⚠ 包过时提醒：")
                for n, v, lv in stale:
                    out(f"  - {n} 当前 @{v}，registry 已有 @{lv}（pkg install {n}@{lv} 升级）")
        except Exception:
            pass
        return 0
    if act == "pack":
        srcdir = _winpath(args.name or ".")
        if not os.path.isdir(srcdir):
            err(f"✗ 目录不存在: {srcdir}")
            return 1
        _quality_gate(srcdir, force=getattr(args, "force", False))
        name, version = _pkg_name_version(srcdir, args)
        out_path = (_winpath(args.out) if getattr(args, "out", None)
                    else os.path.join(os.getcwd(), f"{name}-{version}{PKG_EXT}"))
        try:
            sha = _pack_zip(srcdir, name, version, out_path)
        except (OSError, FileNotFoundError) as e:
            err(f"✗ 打包失败: {e}")
            return 1
        out(f"✓ 已打包 → {out_path}")
        out(f"  包：{name} @{version}（{os.path.getsize(out_path)} 字节，sha256 {sha[:12]}…）")
        out(f"  发布：pybktl pkg publish {args.name}")
        out("        （或手动把 .pybp 文件分发出去，对方 pkg install 该文件即可）")
        return 0
    if act == "publish":
        srcdir = _winpath(args.name or ".")
        if not os.path.isdir(srcdir):
            err(f"✗ 目录不存在: {srcdir}")
            return 1
        _quality_gate(srcdir, force=getattr(args, "force", False))
        reg = _registry_dir(args)
        os.makedirs(reg, exist_ok=True)
        name, version = _pkg_name_version(srcdir, args)
        dest = os.path.join(reg, f"{name}-{version}{PKG_EXT}")
        try:
            sha = _pack_zip(srcdir, name, version, dest)
        except (OSError, FileNotFoundError) as e:
            err(f"✗ 打包失败: {e}")
            return 1
        # 同名同版本整行替换（重发即覆盖）；其余原样保留
        rows = [r for r in _read_registry_index(reg)
                if not (r[0] == name and r[1] == version)]
        now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        rows.append((name, version, os.path.basename(dest), sha,
                     str(os.path.getsize(dest)), now))
        _write_registry_index(os.path.join(reg, "索引.md"), rows)
        out(f"✓ 已发布 {name} @{version} → {dest}")
        out(f"  registry: {reg}（索引已更新，共 {len(rows)} 个包）")
        author = os.environ.get("PYBOOK_AUTHOR") or os.environ.get("USERNAME") or "未知"
        logp = os.path.join(os.getcwd(), "发布日志.md")
        with open(logp, "a", encoding="utf-8") as lf:
            if not os.path.isfile(logp) or os.path.getsize(logp) == 0:
                lf.write("# 发布日志\n\n")
            import datetime as _dt
            now = _dt.datetime.now().strftime("%Y-%m-%d %H:%M")
            lf.write(f"- {now} {author}：{name} @{version}（{os.path.basename(dest)}）\n")
        out("  已记入 发布日志.md")
        out("  分发：把 registry 目录提交到 git / 放共享盘，别人 "
            f"`pkg install {name} --registry <路径>` 即用。")
        return 0
    if act == "search":
        reg = _registry_dir(args)
        rows = _read_registry_index(reg)
        kw = (args.name or "").lower()
        hits = [r for r in rows if not kw or kw in r[0].lower()]
        if not hits:
            out(f"· registry 里没有匹配的包（{reg}，共 {len(rows)} 个）")
            return 0
        out(f"registry {reg}（{len(rows)} 个包，匹配 {len(hits)}）：")
        for name, version, fname, sha, size, when in hits:
            out(f"  - {name} @{version}  {size} 字节  {when}")
        out("  安装：pybktl pkg install 名字[@版本]")
        return 0
    if act == "uninstall":
        data = parse_manifest(manifest)
        name = (args.name or "").strip()
        import shutil as _sh
        libdir = os.path.join(os.getcwd(), "libs", name)
        removed = []
        if os.path.isdir(libdir):
            for dirpath, _dirs, files in os.walk(libdir):
                for fn in files:
                    if fn.endswith(".pybk"):
                        rootcopy = os.path.join(os.getcwd(), fn)
                        if os.path.isfile(rootcopy):
                            os.remove(rootcopy)
            _sh.rmtree(libdir, ignore_errors=True)
            removed.append(f"libs/{name}/")
        keep = [d for d in data["deps"] if d[0] != name]
        if len(keep) != len(data["deps"]):
            lines = io_lines(os.path.join(os.getcwd(), MANIFEST))
            outl = [l for l in lines if not (l.strip().startswith(f"- {name} ") or l.strip() == f"- {name}")]
            io.open(os.path.join(os.getcwd(), MANIFEST), "w", encoding="utf-8", newline="").write("\n".join(outl))
            removed.append("清单条目")
        if removed:
            out(f"✓ 已卸载 {name}：" + "、".join(removed))
            return 0
        err(f"✗ 没找到已安装的包：{name}")
        return 1
    if act == "install":
        return _pkg_install(args)
    return 1


def io_lines(path):
    if os.path.isfile(path):
        return io_open_lines(path)
    return []


def io_open_lines(path):
    import io as _io
    return _io.open(path, encoding="utf-8").read().split("\n")


def cmd_ws(args):
    manifest = os.path.join(os.getcwd(), MANIFEST)
    data = parse_manifest(manifest)
    if not data["members"]:
        err("· 清单「工作区」段没有成员。先 pybktl pkg add 或直接编辑 pybook.md。")
        return 2
    ok = fail = 0
    for m in data["members"]:
        m = _winpath(m)
        if not os.path.isfile(m):
            err(f"✗ 成员不存在: {m}")
            fail += 1
            continue
        if args.ws_action == "build":
            bdir = os.path.join(os.getcwd(), "build")
            os.makedirs(bdir, exist_ok=True)
            out_pybc = os.path.join(bdir, os.path.splitext(os.path.basename(m))[0] + ".pybc")
            rc, stdout, stderr = run_tool(locate_build(), m, out_pybc)
            if rc == 0:
                out(f"✓ {m}  → .pybc")
                ok += 1
            else:
                err(f"✗ {m}  {stderr.strip() or stdout.strip()}")
                fail += 1
        else:  # check
            rc, stdout, stderr = run_tool(locate_main(), "--check-json", m)
            d = _parse_check_json(stdout)
            if d and d.get("ok"):
                out(f"✓ {m}")
                ok += 1
            else:
                msg = (d or {}).get("message", stderr.strip() or "未知错误")
                err(f"✗ {m}  {msg}")
                fail += 1
    out(f"--- 工作区 {args.ws_action}: {ok} 通过 / {fail} 失败 ---")
    return 1 if fail else 0


# ---------------------------------------------------------------------------
# 3门神总闸：静态门 + 运行门 + 回归门
# ---------------------------------------------------------------------------
def _read_text(path):
    try:
        with open(path, encoding="utf-8-sig", errors="replace") as f:
            return f.read()
    except Exception:
        return ""


def _door_static(path):
    """静态门：--check 通过（含字面量类型/取值检查）。"""
    main = locate_main()
    rc, so, se = run_tool(main, "--check-json", _winpath(path))
    d = _parse_check_json(so)
    if d and d.get("ok"):
        return ("pass", "静态校验通过（语法+语义+字面量类型/取值）")
    msg = (d or {}).get("message") or (se or so).strip() or "未知错误"
    return ("fail", msg)


def _door_runtime(path, mode):
    """运行门：源码是否挂了 try-catch/onerror 网 + （full 模式）有界运行看崩不崩。"""
    src = _read_text(path)
    has_net = bool(re.search(r"\b(try|catch|onerror)\b", src))
    net = "已挂运行门(try/catch/onerror)" if has_net else "未挂运行门(try/catch/onerror)：运行期错误会直接崩"
    if mode != "full":
        return ("pass" if has_net else "warn", net)
    rc, so, se = run_tool(locate_main(), _winpath(path), timeout=15, env=child_env())
    combined = (so or "") + (se or "")
    if rc == -1:
        run = ("warn", "运行超时(>15s)，可能交互/死循环，需人工验")
    elif rc != 0:
        run = ("fail", "运行期崩溃: " + combined.strip()[-300:])
    else:
        run = ("pass", "运行无异常退出")
    level = "pass" if (has_net and run[0] == "pass") else ("fail" if run[0] == "fail" else "warn")
    return (level, net + "；" + run[1])


def _door_regress(path, mode, all_=False):
    """回归门：smokeroor 冒烟/回归。单文件若有 .expect 则比对；--all 跑全套。"""
    if all_:
        sr = locate_smokeroor()
        rc, so, se = run_tool(sr, timeout=SMOKEROOR_TIMEOUT * 5)
        if rc == 0:
            return ("pass", "smokeroor 全套通过")
        return ("fail", (so or se).strip()[-300:] or "smokeroor 有失败")
    exp_rc, pos, neg = load_expect(path)
    if exp_rc is not None or pos or neg:
        rc, so, se = run_tool(locate_main(), _winpath(path), timeout=30, env=child_env())
        ok, reason = match_expect(exp_rc, rc, (so or "") + (se or ""), pos, neg)
        return (("pass", "冒烟比对通过(.expect 命中)") if ok else ("fail", reason))
    return ("warn", "无对应冒烟用例（用 `pybktl guard --all` 跑全套回归）")


def guard_file(path, mode="full", all_=False):
    path = _winpath(path)
    if not os.path.isfile(path):
        return None, [("fail", "找不到文件: " + path)]
    doors = [
        ("静态门", _door_static(path)),
        ("运行门", _door_runtime(path, mode)),
        ("回归门", _door_regress(path, mode, all_)),
    ]
    return path, doors


def cmd_guard(args):
    all_ = args.all
    if all_ and not args.file:
        sr = locate_smokeroor()
        rc, so, se = run_tool(sr, timeout=SMOKEROOR_TIMEOUT * 5)
        if so.strip():
            out(so.strip())
        if se.strip():
            err(se.strip())
        return rc
    if not args.file:
        err("用法: pybktl guard <文件.pybk> [--all] [--auto]")
        return 2
    mode = "auto" if args.auto else "full"
    path, doors = guard_file(args.file, mode=mode, all_=all_)
    if path is None:
        return 2
    sym = {"pass": "\u2713", "warn": "\u26a0", "fail": "\u2717"}
    out("\U0001F531 3门神总闸：" + os.path.basename(path))
    worst = "pass"
    for name, (lvl, msg) in doors:
        out("  [%s] %s：%s" % (sym[lvl], name, msg))
        if lvl == "fail":
            worst = "fail"
        elif lvl == "warn" and worst != "fail":
            worst = "warn"
    if worst == "fail":
        out("结果：有门神未过，先修再发布。")
        return 1
    if worst == "warn":
        out("结果：通过，但运行门/回归门有提醒项，留意。")
        return 0
    out("结果：三道门神全过。")
    return 0


# ---------------------------------------------------------------------------
# 概念神「修」：检查 → 汇报 → 问你改不改 → 改错区（详见 repair.py）
# ---------------------------------------------------------------------------
def cmd_repair(args):
    """概念神「修」：pybk_main --check-json 报的错，逐条问你改不改，能安全修的就改。"""
    path = _winpath(os.path.abspath(args.file))
    if not os.path.isfile(path):
        err(f"找不到文件: {path}")
        return 2
    clean, n = repair.run_repair(path, auto=getattr(args, "yes", False))
    if clean:
        out("✓ 修复完成：%s 现在能编译通过%s"
            % (os.path.basename(path), ("（自动修改 %d 处）" % n) if n else ""))
        return 0
    out("⚠ 仍有错误需手动处理，或你选择跳过。")
    return 1


def cmd_smoke(args):
    # --all：委托给项目自带的 smokeroor.py 跑整套
    if args.all:
        sr = locate_smokeroor()
        rc, stdout, stderr = run_tool(sr, *(["--json"] if args.json else []),
                                      timeout=SMOKEROOR_TIMEOUT * 5)
        _log_lookaround(sr, "pybktl smoke --all", rc, stdout, stderr)
        if stdout.strip():
            out(stdout.strip())
        if stderr.strip():
            err(stderr.strip())
        return rc

    f = _winpath(args.file)
    if not os.path.isfile(f):
        err(f"找不到文件: {f}")
        return 2

    extra = {}
    if args.shot_dir:
        sd = _winpath(args.shot_dir)
        os.makedirs(sd, exist_ok=True)
        extra["PYBOOK_SHOT_DIR"] = sd

    # 冒烟 = 真正运行一遍（原生管线），超时兜底
    rc, stdout, stderr = run_tool(locate_main(), f, timeout=args.timeout, env=child_env(extra))
    combined = (stdout or "") + (stderr or "")
    _log_lookaround(f, "pybktl smoke " + os.path.basename(f), rc, stdout, stderr)

    # 若旁边有 .expect，按 Smokeroor 格式比对
    exp_rc, pos, neg = load_expect(f)
    if exp_rc is not None or pos or neg:
        ok, reason = match_expect(exp_rc, rc, combined, pos, neg)
        if ok:
            out(f"✓ {f}  冒烟通过（.expect 命中）")
        else:
            err(f"✗ {f}  冒烟失败：{reason}")
            err(combined.strip()[-500:] if combined.strip() else "(无输出)")
            _try_smokeroor(f)
            return 1
    else:
        if rc == -1:
            err(f"✗ {f}  无头冒烟超时（>{args.timeout}s），可能卡死/死循环")
            _try_smokeroor(f)
            return 2
        if rc != 0:
            err(f"✗ {f}  无头冒烟失败 (rc={rc})")
            if stderr.strip():
                err(stderr.strip())
            if "Traceback" in combined or "pybook_rt.c" in combined or "gcc" in combined.lower():
                err("  （提示：疑似 gcc/mingw 不可用或运行时 .c 未找到；"
                    "请在装好 mingw 的机器上运行，或确认 PYBOOK_HOME 指向完整 pybook 目录）")
            fp = fingerprint(combined)
            err(f"  [指纹 {fp}]")
            _try_smokeroor(f)
            return 1
        out(f"✓ {f}  无头冒烟通过（rc=0）")

    if args.shot_dir:
        sd = _winpath(args.shot_dir)
        shots = [x for x in os.listdir(sd)] if os.path.isdir(sd) else []
        if shots:
            out(f"  （无头出图：在 {sd} 产出 {len(shots)} 张帧，3D 渲染管线已跑通）")
        else:
            out(f"  （提示：未发现帧。PYBOOK_SHOT_DIR 仅对 3D(hw) 程序生效；2D 无头不存帧）")
    return 0


def _try_smokeroor(filepath):
    """若 Smokeroor 产出过错误指纹库，尝试读取并判已知/未知。"""
    cand = os.path.join(os.path.dirname(os.path.abspath(filepath)), "smokeroor_errors.json")
    if not os.path.isfile(cand):
        cand = os.path.join(home_dir(), "smokeroor_errors.json")
    if not os.path.isfile(cand):
        return
    try:
        db = json.load(open(cand, encoding="utf-8"))
        known = db.get("known", []) if isinstance(db, dict) else []
        out(f"  （Smokeroor 指纹库命中 {len(known)} 条已知错误）")
    except Exception:
        pass


# ---------------------------------------------------------------------------
# 测试框架：pybktl test —— 发现 测试_*/test_* 用例，逐条跑，出可读报告 + 可选 junit
# ---------------------------------------------------------------------------
_TEST_RE = re.compile(r'^\s*func\s+([^\s(]+)\s*\(', re.MULTILINE)
_SUMMARY_RE = re.compile(r'查：\s*(\d+)\s*通过[，,]\s*(\d+)\s*失败')
_FAILNAME_RE = re.compile(r'查失败:\s*(\S+)')


def _discover_tests(src):
    """从源码里找出所有测试函数：名字以 测试 / test 开头的 func。"""
    out = []
    seen = set()
    for m in _TEST_RE.finditer(src):
        nm = m.group(1)
        if nm.lower().startswith('测试') or nm.lower().startswith('test'):
            if nm not in seen:
                seen.add(nm)
                out.append(nm)
    return out


def _make_harness(src, test_name):
    """生成只跑单个测试函数的 harness：保留原函数/引用/顶层 vg，只把 GOING 体换成调用它。
    无 GOING 则追加一个。这样每个用例各自编译运行，隔离全局状态。"""
    call = '    %s()\n' % test_name
    m = re.search(r'\bGOING\b\s*:?\s*\{', src)
    if m:
        start = m.end() - 1            # '{' 的位置
        depth, i, end = 0, start, None
        while i < len(src):
            ch = src[i]
            if ch == '{':
                depth += 1
            elif ch == '}':
                depth -= 1
                if depth == 0:
                    end = i
                    break
            i += 1
        if end is not None:
            return src[:start + 1] + '\n' + call + src[end:]
    # 没找到合法 GOING：在文件尾补一个
    return src.rstrip() + '\n\nGOING:{\n' + call + '}STOP\n'


def _run_one_test(pybk_main, harness_path):
    """跑单个 harness，解析 查：X 通过，Y 失败。返回 (failures, passes, detail_lines, raw_err)。"""
    rc, so, se = run_tool(pybk_main, _winpath(harness_path), timeout=120, env=child_env())
    combined = (so or '') + (se or '')
    m = _SUMMARY_RE.search(combined)
    fails = None
    passes = None
    detail = _FAILNAME_RE.findall(combined)
    if m:
        passes = int(m.group(1))
        fails = int(m.group(2))
    elif '程序异常退出' in combined or '运行时错误' in combined or rc != 0:
        fails = None  # 崩溃/编译错 → 视为失败（detail 里带原因）
    else:
        fails = 0     # 无 查 行且无报错：0 断言通过
    return fails, passes, detail, combined


def cmd_test(args):
    """pybktl test <文件|目录> [--junit out.xml]：跑 测试_*/test_* 用例。"""
    main = locate_main()
    target = _winpath(args.path)
    files = []
    if os.path.isdir(target):
        for root, _d, fs in os.walk(target):
            for fn in fs:
                if fn.endswith('.pybk'):
                    files.append(os.path.join(root, fn))
    elif os.path.isfile(target):
        files.append(target)
    else:
        err(f"找不到: {target}")
        return 2
    files.sort()

    results = []   # (file, test_name, failures, detail, raw)
    for fp in files:
        try:
            src = open(fp, encoding='utf-8-sig', errors='replace').read()
        except Exception as e:
            err(f"读不了 {fp}: {e}")
            continue
        tests = _discover_tests(src)
        if not tests:
            continue
        d = os.path.dirname(os.path.abspath(fp))
        stem = os.path.splitext(os.path.basename(fp))[0]
        for t in tests:
            hpath = os.path.join(d, '_pybktl_t_%s_%s.pybk' % (stem, t))
            try:
                open(hpath, 'w', encoding='utf-8').write(_make_harness(src, t))
                fails, passes, detail, raw = _run_one_test(main, hpath)
            finally:
                if os.path.isfile(hpath):
                    try:
                        os.remove(hpath)
                    except Exception:
                        pass
            results.append((fp, t, fails, passes, detail, raw))

    if not results:
        out("PYbook 测试：没发现 测试_*/test_* 用例（func 名以 测试 或 test 开头即算用例）。")
        return 0

    n_pass = n_fail = 0
    out("PYbook 测试：%d 个用例" % len(results))
    out("")
    for fp, t, fails, passes, detail, raw in results:
        short = os.path.relpath(fp, os.getcwd())
        if fails == 0:
            n_pass += 1
            tag = "\u2713"
            if passes:
                extra = "（%d 断言通过）" % passes
            else:
                extra = "（无断言）"
            out("  [%s] %s :: %s %s" % (tag, short, t, extra))
        else:
            n_fail += 1
            tag = "\u2717"
            why = ""
            if fails is None:
                # 崩溃/编译错：抓第一行有意义的报错
                line = next((l.strip() for l in raw.splitlines()
                             if '第' in l or '错误' in l or 'Error' in l), raw.strip().splitlines()[0] if raw.strip() else "")
                why = "崩溃：" + (line or "未知错误")
            else:
                why = "失败 %d" % fails + ("：" + "、".join(detail) if detail else "")
            out("  [%s] %s :: %s  %s" % (tag, short, t, why))
    out("")
    out("--- 合计：通过 %d / %d，失败 %d ---" % (n_pass, len(results), n_fail))

    if getattr(args, "junit", None):
        _write_junit(args.junit, results)
        out("  （junit 报告已写：%s）" % args.junit)

    return 1 if n_fail else 0


def _write_junit(path, results):
    parts = ['<?xml version="1.0" encoding="utf-8"?>', '<testsuites>']
    fails = sum(1 for r in results if r[2] != 0)
    parts.append('  <testsuite name="pybk" tests="%d" failures="%d">' % (len(results), fails))
    for fp, t, failure, passes, detail, raw in results:
        cls = os.path.relpath(fp, os.getcwd())
        parts.append('    <testcase name="%s" classname="%s">' % (_xmlesc(t), _xmlesc(cls)))
        if failure != 0:
            msg = "失败 %s" % failure if failure is not None else "崩溃"
            if detail:
                msg += "：" + "、".join(detail)
            parts.append('      <failure message="%s">%s</failure>' % (_xmlesc(msg), _xmlesc(raw.strip()[:2000])))
        parts.append('    </testcase>')
    parts.append('  </testsuite>')
    parts.append('</testsuites>')
    try:
        open(_winpath(path), 'w', encoding='utf-8').write('\n'.join(parts) + '\n')
    except Exception as e:
        err("写 junit 失败: %s" % e)


def _xmlesc(s):
    return (s or '').replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;').replace('"', '&quot;')


# ---------------------------------------------------------------------------
# LookAround 日志循环（文件夹级开发日志：文件改动 / run·build·check·smoke 运行 / 错误翻中文）
# ---------------------------------------------------------------------------
def cmd_version(args):
    """打印项目版本（pybook.md 的 ## 项目 段）。空版本返回非 0，便于 CI 做版本门禁。"""
    m = parse_manifest(os.path.join(os.getcwd(), MANIFEST))
    name = m.get("name") or "(未命名)"
    ver = (m.get("version") or "").strip()
    if not ver:
        err("✗ 未设置版本：请在 pybook.md 的「## 项目」段写 version: x.y.z")
        return 1
    import re as _re
    if not _re.match(r"^\d+\.\d+\.\d+", ver):
        out(f"⚠ 版本「{ver}」不是 x.y.z 形式，建议改成语义化版本")
    if m.get("desc"):
        out(f"{name}  v{ver}  —  {m['desc']}")
    else:
        out(f"{name}  v{ver}")
    return 0


def cmd_lookaround(args):
    """开启文件夹日志循环（前台监控，Ctrl+C 停止）。详见 lookaround.py。"""
    lookaround.start_watcher()


def cmd_lookaround_log(args):
    """查看/筛选 lookaround.md 日志。"""
    root, text = lookaround.view_log(file=args.file, since=args.since,
                                     until=args.until, etype=args.type, tail=args.tail)
    print(text)
    return 0 if root is not None else 1


def _project_header(root):
    """从 root 的 pybook.md 读 ## 项目 段，拼一行报告抬头；无则空串。"""
    mf = parse_manifest(os.path.join(root, MANIFEST))
    name, ver = mf.get("name") or "", mf.get("version") or ""
    if not (name or ver):
        return ""
    bits = []
    if name:
        bits.append(name)
    if ver:
        bits.append("v" + ver)
    line = "项目：" + "  ".join(bits)
    if mf.get("desc"):
        line += "  —  " + mf["desc"]
    return line


def cmd_lookaround_report(args):
    """生成团队协作报告：改动/运行/错误汇总 + 待办完成情况。"""
    root = lookaround.find_lookaround_root(os.getcwd())
    if not root:
        print("该文件夹未开启 LookAround 日志循环：请先 `cd` 到目标文件夹执行 `pybktl lookaround`。")
        return 1
    text = lookaround.build_report(root, since=args.since, until=args.until, by=args.by)
    header = _project_header(root)
    if header:
        text = header + "\n" + text
    if args.out:
        out_path = os.path.join(root, args.out)
        with open(out_path, "w", encoding="utf-8") as f:
            f.write(text)
        out("✓ 报告已写入：%s" % out_path)
    else:
        print(text)
    return 0


def cmd_hottable(args):
    """热度表：默认给排行榜，指定文件则给该项明细表（每一列都能看出热度是怎么来的）。

    用 `hottable watch` / `hottable status` 保留前两个位置参数当动词——
    这样 `hottable 摆杆.pybk` 这种「敲个文件名就看明细」的手感才成立
    （真要查一个恰好叫 watch 的文件，写全路径 `hottable 目录/watch` 即可）。"""
    if args.targets and args.targets[0] in ("watch", "status"):
        return cmd_hottable_watch(args) if args.targets[0] == "watch" \
            else cmd_hottable_status(args)
    root = hottable.find_hottable_root(os.getcwd(), explicit=getattr(args, "root", None))
    if not root:
        print("找不到 HotTable 台账。任选一种：\n"
              "  · `cd` 到已开启的文件夹里再查\n"
              "  · `pybktl hottable --root <目录>`\n"
              "  · 设环境变量 HOTTABLE_ROOT=<目录>\n"
              "台账没开的话，先在目标文件夹跑 `pybktl hottable watch`。")
        return 1
    since_ts = hottable.parse_since(args.since)
    if args.since and since_ts is None:
        print("无法解析 --since %r（支持 12h / 3d / 2026-10-18 / '2026-10-18 10:30:00'）"
              % args.since)
        return 2
    print(hottable.view(root, targets=args.targets or None,
                        top=args.top, since=since_ts, want_json=args.json))
    return 0


def cmd_hottable_watch(args):
    """开启热度台账循环（前台监控，Ctrl+C 停止）。详见 hottable.py。"""
    hottable.start_watcher(use_defaults=not getattr(args, "all", False))
    return 0


def cmd_hottable_status(args):
    """台账是否开着、开着多久、攒了多少事件——「一直开着」得能查。"""
    root = hottable.find_hottable_root(os.getcwd(), explicit=getattr(args, "root", None))
    if not root:
        print("找不到 HotTable 台账（`--root <目录>` 或设 HOTTABLE_ROOT 可以指定）。")
        return 1
    txt = hottable.status(root)
    print(txt)
    return 0 if "开着" in txt else 1


def cmd_todo(args):
    """LookAround 待办清单：独立进程通过 .lookaround 标记定位根目录，可在 watcher 运行过程中途加入。"""
    root = lookaround.find_lookaround_root(os.getcwd())
    if not root:
        print("该文件夹未开启 LookAround 日志循环：请先 `cd` 到目标文件夹执行 `pybktl lookaround`。")
        return 1
    c = args.todo_cmd
    if c == "add":
        text = " ".join(args.text)
        nid = lookaround.add_todo(root, text)
        print("已加入待办 #%d：%s" % (nid, text))
    elif c == "done":
        ok = lookaround.done_todo(root, args.idx)
        print("已标记完成 #%d" % args.idx if ok else "未找到待办 #%d" % args.idx)
    elif c == "rm":
        ok = lookaround.rm_todo(root, args.idx)
        print("已删除 #%d" % args.idx if ok else "未找到待办 #%d" % args.idx)
    elif c == "list":
        print(lookaround.list_todo(root))
    elif c == "show":
        txt = lookaround.show_todo(root, args.idx)
        print(txt if txt else "未找到待办 #%d" % args.idx)
    return 0


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------
def build_parser():
    p = argparse.ArgumentParser(prog="pybktl", description="PYbook 外部工具链（零侵入）")
    sub = p.add_subparsers(dest="command", required=True)

    pi = sub.add_parser("init", help="在当前目录生成 pybook.md 清单（含 ## 项目/工程 版本段）")
    pi.add_argument("--team", action="store_true", help="额外生成团队骨架：src/main.pybk · tests/测试_冒烟.pybk · README.md · .gitignore")
    pi.set_defaults(func=cmd_init)

    pv = sub.add_parser("version", help="打印项目版本（pybook.md 的 ## 项目 段），CI 版本门禁用")
    pv.set_defaults(func=cmd_version)

    pc = sub.add_parser("check", help="静态校验 .pybk（友好化报错 + 错误指纹）")
    pc.add_argument("file")
    pc.set_defaults(func=cmd_check)

    pl = sub.add_parser("lint", help="可读性 lint：命名/长度/嵌套/调试残留/TODO（团队代码规范）")
    pl.add_argument("paths", nargs="*", help="文件或目录（默认递归当前目录，排除 build/）")
    pl.add_argument("--strict", action="store_true", help="警告也当作失败（CI 更严格）")
    pl.add_argument("--max-lines", type=int, default=60, help="单函数行长上限（默认 60）")
    pl.add_argument("--max-depth", type=int, default=4, help="嵌套深度上限（默认 4）")
    pl.set_defaults(func=cmd_lint)

    pb = sub.add_parser("build", help="编译为 .pybc 字节码产物（离线，不运行）")
    pb.add_argument("file")
    pb.add_argument("out", nargs="?", help="输出 .pybc 路径（默认 同名.pybc）")
    pb.set_defaults(func=cmd_build)

    pr = sub.add_parser("run", help="运行：默认原生管线，--vm 走字节码，2D 会弹窗")
    pr.add_argument("file")
    pr.add_argument("--vm", action="store_true", help="用 pyvm.exe 跑字节码（Ctrl+F5 管线）")
    pr.add_argument("--repair", action="store_true",
                    help="运行前先静态检查；有错就汇报并问你是否改，改完再跑（概念神「修」）")
    pr.add_argument("--todo", type=int, help="把本次运行关联到某条待办（配合 `todo show <编号>` 跳转查看）")
    pr.add_argument("--shot-dir", help="设 PYBOOK_SHOT_DIR（3D 无头出图验收）")
    pr.set_defaults(func=cmd_run)

    pf = sub.add_parser("fmt", help="块级缩进整理（默认预览）")
    pf.add_argument("file")
    pf.add_argument("--in-place", action="store_true", help="直接落盘")
    pf.add_argument("--check", action="store_true",
                    help="落盘后自动复检静态校验，失败则回滚")
    pf.set_defaults(func=cmd_fmt)

    pp = sub.add_parser("pkg", help="依赖管理 / 包管理（版本化依赖·锁·打包·本地 registry）")
    pp.add_argument("pkg_action",
                    choices=["add", "lock", "sync", "list", "pack", "publish", "install",
                             "search", "uninstall"])
    pp.add_argument("name", nargs="?",
                    help="add/install 的名字；pack/publish 的源目录")
    pp.add_argument("path", nargs="?", help="add 时的依赖路径（可带 @版本）")
    pp.add_argument("-o", "--out", help="pack 时的输出 .pybp 路径")
    pp.add_argument("--as", dest="as_name", help="pack/publish 时的中文包名")
    pp.add_argument("--version", help="pack/publish 时的包版本")
    pp.add_argument("--registry",
                    help="publish/install 的本地 registry 目录"
                         "（默认 ~/.pybook/registry，可用 PYBOOK_REGISTRY 覆盖）")
    pp.add_argument("--force", action="store_true", help="sync 跳过锁校验；pack/publish 跳过质量门")
    pp.set_defaults(func=cmd_pkg)

    pw = sub.add_parser("ws", help="工作区批量")
    pw.add_argument("ws_action", choices=["build", "check"])
    pw.set_defaults(func=cmd_ws)

    ps = sub.add_parser("smoke", help="无头冒烟 / 跑 Smokeroor 套件")
    ps.add_argument("file", nargs="?", help="单个 .pybk（与 --all 互斥）")
    ps.add_argument("--all", action="store_true", help="委托 smokeroor.py 跑 tests/smoke/ 全套")
    ps.add_argument("--shot-dir", help="设 PYBOOK_SHOT_DIR（3D 无头出图验收）")
    ps.add_argument("--timeout", type=int, default=30, help="单文件超时秒数")
    ps.add_argument("--json", action="store_true", help="--all 时让 smokeroor 输出 JSON")
    ps.set_defaults(func=cmd_smoke)

    release.build_subparser(sub)      # 加强版发布打包（版本号 + 盖章 + 清洁 zip）
    hist.build_subparser(sub)         # 快照 / 回滚 / 追溯
    task.build_subparser(sub)         # 团队任务流转（认领人 / 截止 / 状态）
    doctor.build_subparser(sub)       # 工作区小诊所
    apppack.build_subparser(sub)      # 应用打包（发玩家）
    report.build_subparser(sub)       # 团队协作报告
    airegress.build_subparser(sub)    # AI 栈回归基线（双后端一键验收）

    pg = sub.add_parser("guard", help="3门神总闸：静态(--check)+运行(try-catch网/有界运行)+回归(smokeroor)")
    pg.add_argument("file", nargs="?", help="单个 .pybk（与 --all 可并存）")
    pg.add_argument("--all", action="store_true", help="回归门跑 smokeroor 全套")
    pg.add_argument("--auto", action="store_true", help="轻量模式（lookaround 自动调用）：跳过实际运行，只做静态+存在性+单文件冒烟")
    pg.set_defaults(func=cmd_guard)

    prr = sub.add_parser("repair",
                        help="概念神「修」：检查→汇报→问你改不改→改错区（也可 run --repair）")
    prr.add_argument("file")
    prr.add_argument("-y", "--yes", action="store_true",
                     help="无需逐条确认，能安全修的自动改（非交互/批量用，等价于 run --repair 的自动分支）")
    prr.set_defaults(func=cmd_repair)

    pt = sub.add_parser("test", help="测试框架：跑 测试_*/test_* 用例，出可读报告 + 可选 junit")
    pt.add_argument("path", help="单个 .pybk 文件，或含 .pybk 的目录（递归发现用例）")
    pt.add_argument("--junit", help="把结果写成 junit XML（CI 吃这个格式）")
    pt.set_defaults(func=cmd_test)

    pla = sub.add_parser("lookaround",
                         help="在当前文件夹开启日志循环：监控文件改动，并自动记录 run/build/check/smoke 运行与运行时错误到 lookaround.md")
    pla.set_defaults(func=cmd_lookaround)
    plos = pla.add_subparsers(dest="look_cmd")
    plog = plos.add_parser("log", help="查看/筛选 lookaround.md 日志")
    plog.add_argument("--file", help="只显示涉及该文件的事件")
    plog.add_argument("--since", help="起始时间，格式 YYYY-MM-DD[ HH:MM:SS]")
    plog.add_argument("--until", help="结束时间，格式 YYYY-MM-DD[ HH:MM:SS]")
    plog.add_argument("--type", choices=["change", "run", "todo", "error"],
                     help="按事件类型筛选：change=文件改动 / run=运行 / todo=待办 / error=运行时错误")
    plog.add_argument("--tail", type=int, default=0, help="只显示最后 N 条事件")
    plog.set_defaults(func=cmd_lookaround_log)
    prep = plos.add_parser("report", help="生成团队协作报告（改动/运行/错误汇总 + 待办完成情况）")
    prep.add_argument("--since", help="统计起始时间，格式 YYYY-MM-DD[ HH:MM:SS]")
    prep.add_argument("--until", help="统计结束时间，格式 YYYY-MM-DD[ HH:MM:SS]")
    prep.add_argument("--by", default="", help="报告人（团队协作署名）")
    prep.add_argument("--out", help="把报告写入该文件（默认打印到屏幕）")
    prep.set_defaults(func=cmd_lookaround_report)

    ph = sub.add_parser(
        "hottable",
        help="文件热度表：告诉你「该先改哪个」。开着盯盘时自动记改动与运行，"
             "不带参数给排行榜，带文件名给该项明细（每一列都能看出热度怎么来的）")
    ph.add_argument("targets", nargs="*",
                    help="要看的文件（支持片段匹配，如 `hottable 摆杆`）；不给则看排行榜")
    ph.add_argument("--top", type=int, default=20, help="排行榜取前 N 名（默认 20）")
    ph.add_argument("--since", help="只统计这段时间内：12h / 3d / 2026-10-18 / '2026-10-18 10:30:00'")
    ph.add_argument("--json", action="store_true", help="输出 JSON（给脚本/别的前端吃）")
    ph.add_argument("--root", help="台账所在目录（不在该目录里查时用；也可用环境变量 HOTTABLE_ROOT）")
    ph.add_argument("--all", action="store_true",
                    help="`watch` 时不套用默认忽略集，全树都盯（慢，默认别用）")
    ph.set_defaults(func=cmd_hottable)

    ptd = sub.add_parser("todo",                         help="LookAround 待办清单：中途可随时 add/done/rm/list（需先在该文件夹开启 lookaround）")
    ptd_sub = ptd.add_subparsers(dest="todo_cmd", required=True)
    ptd_a = ptd_sub.add_parser("add", help="新增待办（支持多词，用空格分隔）")
    ptd_a.add_argument("text", nargs="+", help="待办内容")
    ptd_d = ptd_sub.add_parser("done", help="标记某条待办完成")
    ptd_d.add_argument("idx", type=int, help="待办编号 #id")
    ptd_r = ptd_sub.add_parser("rm", help="删除某条待办")
    ptd_r.add_argument("idx", type=int, help="待办编号 #id")
    ptd_l = ptd_sub.add_parser("list", help="列出全部待办（含完成状态）")
    ptd_s = ptd_sub.add_parser("show", help="查看某条待办详情 + 它的关联运行（待办↔运行跳转）")
    ptd_s.add_argument("idx", type=int, help="待办编号 #id")
    ptd.set_defaults(func=cmd_todo)
    return p


def main():
    parser = build_parser()
    args = parser.parse_args()
    # smoke --all 不需要 file
    if getattr(args, "command", None) == "smoke" and args.all and not args.file:
        pass
    sys.exit(args.func(args))


if __name__ == "__main__":
    main()
