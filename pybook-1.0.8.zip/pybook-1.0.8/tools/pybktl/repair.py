# -*- coding: utf-8 -*-
"""
repair —— PYbook 概念神「修」：检查 → 汇报 → 问你改不改 → 改错区

设计哲学（和 lookaround / guard 是同一家的「概念神」）：
  pybktl 只当「包在编译器外面的壳」，不碰 pybk_main.py 一个字节。repair 通过
  `pybk_main.py --check-json` 拿到 {ok, line, message}，然后：

    1. 汇报错误（行号 + 中文报错 + 错误指纹，和 cmd_check 同款）；
    2. 问你「是否修改第 N 行？」；
    3. 你回 y，它就按「能安全自动修」的规则改掉错误那一行（或错区）；
       你回 n / q，就停下交给你手动改。

  真正厉害的点就是第 2、3 步这个「问一句再下手」的闭环：编译器报的是
  「第 N 行 缺了 )」，repair 不是默默改，而是先让你看、再让你拍板。

  自动修复只覆盖「机械、可逆、零歧义」的几类（避免乱改语义）：
    A. 字符串未闭合    → 在错行补上缺失的引号
    B. 缺少右括号/方括号 → 在「留下未配对该括号的那一行」行尾补 )
    C. 块缺少收尾的 }   → 在文件末尾补 } 或 }STOP（GOING 块）
    D. 拼错的标准库前缀 → 把 List. / Mt. 这种近似拼写，换成最接近的已知模块（list./mt.）

  其余错误（参数个数、未定义变量、保留字当名…）需要理解语义，repair 不瞎猜，
  直接提示你手动改第 N 行，绝不越俎代庖。

安全守则：
  - 只增不删：补引号 / 补括号 / 换前缀，绝不删你任何代码；
  - 每次只改一行（块缺 } 是补到文件尾，也只加不删）；
  - 改之前必打印 diff（原 → 新），改之后立刻复检，若错误没消停下，防死循环；
  - 最多 50 轮，超出即停。
"""

import difflib
import os
import re

# 已知的标准库模块前缀（编译器关键字表里那一串）。拼错时从这里找最近邻。
KNOWN_MODULES = [
    "mm", "te", "mt", "rd", "mu", "np", "tb", "mp", "ui", "hw", "bs", "js",
    "csv", "web", "file", "list", "tm", "net", "m3", "smoke", "mec", "ffi",
    "音", "查", "调色板",
]
# 合法但「不是标准库前缀」的头部（ns./vg./lb. 这些是语言内置写法），绝不把它们当错字改。
VALID_HEADS = set(KNOWN_MODULES) | {"ns", "vg", "cd", "fv", "hm", "win", "gold",
                                    "out", "lb", "kw", "mc", "音", "查", "调色板"}

_MAX_ROUNDS = 50


def _ask(prompt):
    """交互提问；非交互（无 tty / 管道 EOF）时返回 'q'，避免卡死。"""
    try:
        return input(prompt)
    except EOFError:
        return "q"


def _fp(message):
    """轻量错误指纹（去行号/数字/标识符），方便同一类错误归并。"""
    norm = re.sub(r"第\s*\d+\s*行", "", message or "")
    norm = re.sub(r"\d+(\.\d+)?", "N", norm)
    norm = re.sub(r"[A-Za-z_][A-Za-z0-9_]*", "X", norm)
    norm = re.sub(r"[一-鿿]+", "C", norm)
    import hashlib
    return hashlib.sha1(norm.strip().encode("utf-8")).hexdigest()[:8]


# ---------------------------------------------------------------------------
# 行内括号/引号计数（忽略字符串与 # 注释，足够覆盖 99% 的初学者代码）
# ---------------------------------------------------------------------------
def _scan_line(line):
    """返回该行内各类括号的 (开, 闭) 计数，跳过 '...' / "..." 字符串与末尾注释。"""
    opens = closes = 0
    opens_b = closes_b = 0
    opens_s = closes_s = 0
    instr = False
    quote = ""
    i = 0
    while i < len(line):
        ch = line[i]
        if instr:
            if ch == "\\":           # 转义字符跳过下一个
                i += 2
                continue
            if ch == quote:
                instr = False
            i += 1
            continue
        if ch == "#":               # 注释：本行剩余不参与计数
            break
        if ch in "\"'":
            instr = True
            quote = ch
        elif ch == "(":
            opens += 1
        elif ch == ")":
            closes += 1
        elif ch == "[":
            opens_s += 1
        elif ch == "]":
            closes_s += 1
        elif ch == "{":
            opens_b += 1
        elif ch == "}":
            closes_b += 1
        i += 1
    return (opens, closes, opens_s, closes_s, opens_b, closes_b)


def _unbalanced_quote(line):
    """若某类引号奇数个（未闭合），返回该引号字符；否则 None。"""
    for q in ('"', "'"):
        cnt = 0
        instr = False
        for ch in line:
            if instr:
                if ch == "\\":
                    continue
                if ch == q:
                    instr = False
                continue
            if ch == q:
                cnt += 1
                instr = True
        if cnt % 2 == 1:
            return q
    return None


# ---------------------------------------------------------------------------
# 修复提议：给定「错误行号(0基)/错误行文本/报错/全文」，返回
#   (要修改的行号(0基), 修改后的该行文本, 人类可读说明)  或  None（无法安全修）
# ---------------------------------------------------------------------------
def propose_fix(err_idx, err_line, message, lines):
    msg = message or ""

    # ---- A. 字符串未闭合 ----
    if "字符串未闭合" in msg:
        q = _unbalanced_quote(err_line)
        if q:
            return (err_idx, err_line + q,
                    "在错行末尾补上缺失的 %s 引号，闭合字符串" % q)
        # 引号在字符串里跨了行、行内看不出来：补到该行尾也无济于事，交手动
        return None

    # ---- B. 缺少右括号 / 方括号（开括号可能在上一行）----
    if "期望 ')'" in msg or "缺少右括号 )" in msg or "缺少右括号" in msg:
        # 从错误行向上找「净留下未闭合 ( 的那一行」，在行尾补 )
        for j in range(err_idx, -1, -1):
            o, c, os_, cs, _, _ = _scan_line(lines[j])
            if (o - c) > 0 or (os_ - cs) > 0:
                add = ")" * (o - c) + "]" * (os_ - cs)
                return (j, lines[j] + add,
                        "第 %d 行留下了未闭合的括号，行尾补 %s" % (j + 1, add))
        return None

    # ---- C. 块缺少收尾的 } （通常在文件末尾）----
    if "块缺少收尾的 }" in msg or "期望 '}'" in msg or "缺少右括号 }" in msg:
        # GOING 块用 }STOP 收尾；其余用 }
        going = sum(1 for l in lines if "GOING:{" in l)
        stop = sum(1 for l in lines if "}STOP" in l)
        closer = "}STOP" if going > stop else "}"
        last = len(lines) - 1
        if last < 0:
            return None
        if lines[last].strip() == "":
            # 文件以空行结尾：直接在空行写收尾
            return (last, closer,
                    "文件末尾补上收尾的 %s（GOING/函数块缺收尾）" % closer)
        # 最后一行有内容：另起一行补收尾，避免跟在语句后面（如 vg.x=1}STOP）
        return (last, lines[last] + "\n" + closer,
                "文件末尾另起一行补上收尾的 %s（GOING/函数块缺收尾）" % closer)

    # ---- D. 拼错的标准库前缀（List.添加 → list.添加）----
    # 大小写错（List→list / Mt→mt）最常见；case-insensitive 匹配，纯大小写错必中，
    # 其余拼写错要求更严（cutoff 0.85）避免误伤正常变量名。
    lower_to_orig = {m.lower(): m for m in KNOWN_MODULES}
    for m in re.finditer(r"([A-Za-z_\u4e00-\u9fff][\w\u4e00-\u9fff]*)\."
                         r"([A-Za-z_\u4e00-\u9fff]\w*)", err_line):
        head = m.group(1)
        if head in VALID_HEADS:
            continue
        hl = head.lower()
        if hl in lower_to_orig:
            replacement = lower_to_orig[hl]   # 纯大小写错：List→list
        else:
            cands = difflib.get_close_matches(hl, list(lower_to_orig.keys()), n=1, cutoff=0.85)
            replacement = lower_to_orig[cands[0]] if cands else None
        if replacement and replacement != head:
            new_line = err_line[:m.start(1)] + replacement + err_line[m.end(1):]
            return (err_idx, new_line,
                    "把拼错的前缀 %s. 改成已知标准库 %s." % (head, replacement))
    return None


# ---------------------------------------------------------------------------
# 主循环：检查 → 汇报 → 问 → 改 → 复检
# 返回 (是否最终通过, 共自动修改了几处)
# ---------------------------------------------------------------------------
def _get_tl():
    """拿到「宿主 pybktl 模块对象」，复用它的 run_tool / locate_main / out / err。
    不重新 import pybktl（那会把脚本当第二个模块实例再跑一遍顶层代码，
    产生重复的 argparse 与副作用）。优先取已加载的 pybktl，否则取 __main__。"""
    import sys
    m = sys.modules.get("pybktl")
    if m is not None:
        return m
    return sys.modules.get("__main__")


def run_repair(path, auto=False):
    """path: .pybk 绝对路径。auto=True 时对每个能安全修的错误直接改（测试/CI 用）。"""
    # 复用宿主 pybktl 的子进程调用约定：找编译器 + check-json
    tl = _get_tl()
    main = tl.locate_main()

    n_fixed = 0
    last_sig = None
    for _ in range(_MAX_ROUNDS):
        rc, so, se = tl.run_tool(main, "--check-json", path)
        d = tl._parse_check_json(so)
        if d and d.get("ok"):
            tl.out("✓ 编译通过（静态：语法 + 语义）")
            return True, n_fixed
        if not d:
            tl.err((se or so).strip() or "未知错误（编译器未输出 JSON）")
            return False, n_fixed

        line = d.get("line")
        msg = d.get("message", "")
        fp = _fp(msg)
        tl.err("✗ 第 %s 行  [指纹 %s]" % (line, fp))
        for piece in msg.split("\n"):
            tl.err("    " + piece)

        raw = open(path, encoding="utf-8-sig").read()
        lines = [l.rstrip("\r") for l in raw.split("\n")]
        li = (int(line) - 1) if line else (len(lines) - 1)
        li = max(0, min(li, len(lines) - 1))

        fix = propose_fix(li, lines[li], msg, lines)
        if fix is None:
            tl.err("  ⚠ 该错误需要理解语义，repair 不擅自动手——请手动改第 %s 行。" % line)
            if auto:
                tl.err("  (auto 模式：无人确认，停止以免卡死)")
                return False, n_fixed
            ans = _ask("  是否跳过此错误继续？（y=跳过/q=退出） ").strip().lower()
            if ans == "q":
                return False, n_fixed
            # y 或任意：跳过；但跳过同一个错会死循环 → 直接退出等手动改
            tl.err("  已停止，请手动修复后再次运行 pybktl repair。")
            return False, n_fixed

        edit_idx, new_text, desc = fix
        tl.out("  建议修改：%s" % desc)
        tl.out("    原: %s" % lines[edit_idx])
        tl.out("    新: %s" % new_text)

        if auto:
            apply = True
        else:
            ans = _ask("  应用此修改？（y/n/q） ").strip().lower()
            if ans == "q":
                return False, n_fixed
            apply = (ans == "y")
        if not apply:
            tl.err("  已跳过该修复，repair 停止（如需继续请手动改后重跑）。")
            return False, n_fixed

        lines[edit_idx] = new_text
        open(path, "w", encoding="utf-8-sig").write("\n".join(lines))
        n_fixed += 1
        tl.out("  ✓ 已修改第 %d 行" % (edit_idx + 1))

        # 防死循环：同样的错修完还在 → 停
        sig = (line, _fp(msg))
        if sig == last_sig:
            tl.err("  ⚠ 修改后该错误仍未消除，停止自动修复，请手动检查第 %s 行。" % line)
            return False, n_fixed
        last_sig = sig

    tl.err("  ⚠ 超过 %d 轮仍有错误，停止自动修复。" % _MAX_ROUNDS)
    return False, n_fixed
