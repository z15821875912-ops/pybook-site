# -*- coding: utf-8 -*-
"""apppack —— 把写好的 PYbook 程序打成一个「发给玩家」的文件夹。

    pybktl apppack main.pybk [--name 名字] [--assets 素材目录…] [--out 目录]
                             [--exe 已构建的exe]

两种模式：
  默认（VM 字节码）：main.pybc + pyvm.exe + 启动.bat —— 不依赖 gcc，
      终端/网页/计算类程序今日即可用（win() 窗口类不支持 VM，见下）
  --exe 已构建的exe：原生模式。先用 IDE/pybk_main 跑一次（会顺带编出 exe），
      再把 exe 路径交给 apppack —— 打包 exe + SDL2 等 DLL + 素材，
      win() 窗口游戏用这条。.pybk 源码不需要进包（已编译进 exe）。

关键洞察：引用("x") 在编译时就合并（字节码合并进 .pybc，原生合并进 C）——
所以打包件是自包含的，不需要拖引用闭包的 .pybk 文件；需要跟包的只有
程序运行时 file.read 的素材（--assets 负责）。
"""
import argparse
import datetime
import os
import shutil

DLLS_NATIVE = ["SDL2.dll", "libgcc_s_seh-1.dll", "libwinpthread-1.dll"]


def out(m=""):
    print(m)


def err(m):
    print(m)


def _win(p):
    return os.path.abspath(p)


def _root_dir():
    # apppack.py 在 <仓库>/tools/pybktl/ 下 —— 上跳三层才是仓库根
    return os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def cmd_apppack(args):
    main = _win(args.main)
    if not os.path.isfile(main):
        err(f"✗ 找不到主程序: {main}")
        return 1
    name = args.name or os.path.splitext(os.path.basename(main))[0]
    dist = _win(args.out) if args.out else os.path.join(os.getcwd(), f"{name}-分发")
    if os.path.isdir(dist) and not args.force:
        err(f"✗ 输出目录已存在: {dist}（--force 覆盖）")
        return 1
    if os.path.isdir(dist):
        shutil.rmtree(dist, ignore_errors=True)
    os.makedirs(dist, exist_ok=True)

    copied = []

    def put(src, arcname=None):
        if src and os.path.isfile(src):
            dst = os.path.join(dist, arcname or os.path.basename(src))
            shutil.copy(src, dst)
            copied.append((dst, os.path.getsize(dst)))
            return True
        return False

    # ---------- 主产物 ----------
    if args.exe:
        if not put(_win(args.exe), f"{name}.exe"):
            err(f"✗ 找不到 exe: {args.exe}")
            return 1
        mode = "原生 exe"
        for dll in DLLS_NATIVE:
            dllp = os.path.join(_root_dir(), dll)
            if not put(dllp):
                alt = os.path.join(_root_dir(), "发布打包_102", dll)
                if put(alt):
                    continue
                err(f"⚠ 缺 {dll}（玩家机器若自带可不带；找不到就不打包）")
    else:
        # VM 字节码模式：pybk_build 官方入口（.pybc 已合并全部 引用，自包含）
        import subprocess as sp
        import sys as _s
        root_py = _root_dir()
        build = os.path.join(root_py, "pybk_build.py")
        bc = os.path.join(dist, f"{name}.pybc")
        r = sp.run([_s.executable, build, main, bc],
                   capture_output=True, text=True, encoding="utf-8",
                   errors="replace", timeout=180, cwd=os.path.dirname(main))
        if r.returncode != 0 or not os.path.isfile(bc):
            lines = (r.stderr or r.stdout or "未知错误").strip().splitlines()
            err("✗ 字节码编译失败: " + (lines[-1] if lines else "未知"))
            err("  （VM 模式不支持 win() 窗口/ffi——窗口程序请先用 IDE 构建出 exe，走 --exe 原生模式）")
            return 1
        copied.append((bc, os.path.getsize(bc)))
        vm = os.path.join(root_py, "pyvm.exe")
        if not put(vm):
            err("✗ 找不到 pyvm.exe（打包缺运行时）")
            return 1
        mode = "VM 字节码"
        bat = os.path.join(dist, f"启动{name}.bat")
        with open(bat, "w", encoding="gbk", errors="replace") as f:
            f.write(f"@echo off\r\ncd /d %~dp0\r\npyvm.exe {name}.pybc\r\n")
        copied.append((bat, os.path.getsize(bat)))

    # ---------- 素材 ----------
    for adir in (args.assets or []):
        ad = _win(adir)
        if not os.path.isdir(ad):
            err(f"⚠ 素材目录不存在，跳过: {adir}")
            continue
        base = os.path.basename(ad.rstrip("\\/"))
        for dp, _d, fns in os.walk(ad):
            for fn in sorted(fns):
                full = os.path.join(dp, fn)
                rel = os.path.relpath(full, ad).replace("\\", "/")
                dst = os.path.join(dist, base, rel)
                os.makedirs(os.path.dirname(dst), exist_ok=True)
                shutil.copy(full, dst)
                copied.append((dst, os.path.getsize(full)))

    # ---------- 玩家须知 ----------
    today = datetime.date.today().isoformat()
    howto = (f"双击 启动{name}.bat" if mode == "VM 字节码"
             else f"双击 {name}.exe")
    txt = (f"{name}（PYbook 应用，{mode}）\n"
           f"打包日期: {today}\n"
           f"\n怎么玩/怎么用:\n  {howto}\n"
           f"\n包内容: {len(copied)} 个文件\n"
           + "".join(f"  - {os.path.basename(p)}\n" for p, _s in copied))
    open(os.path.join(dist, "玩家须知.txt"), "w", encoding="utf-8").write(txt)

    total = sum(s for _p, s in copied)
    out(f"✓ 应用打包完成（{mode}）：{dist}")
    out(f"  {len(copied)} 个文件 / {total / 1e6:.1f} MB —— 整个文件夹发给玩家即可")
    return 0


def build_subparser(sub):
    pa = sub.add_parser("apppack", help="应用打包：程序+运行时+素材 → 一个发给玩家的文件夹")
    pa.add_argument("main", help="主程序 .pybk")
    pa.add_argument("--name", help="应用名（默认取主程序文件名）")
    pa.add_argument("--assets", action="append", default=[],
                    help="素材目录（可多次 --assets）")
    pa.add_argument("--out", help="输出目录（默认 <名字>-分发）")
    pa.add_argument("--exe", help="原生模式：已构建好的 exe 路径（win() 窗口程序用）")
    pa.add_argument("--force", action="store_true", help="输出目录已存在时覆盖")
    pa.set_defaults(func=cmd_apppack)
