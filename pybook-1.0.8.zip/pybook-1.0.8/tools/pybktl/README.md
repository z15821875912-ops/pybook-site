# pybktl —— PYbook 外部工具链（零侵入）

把 kaula 那种 `kaulac` 的包管理 / 工作区 / 格式化 / 冒烟体验，包到 PYbook 外面。
**完全不修改 `pybk_main.py` / `pybk_code.py` / `pybk_front.py` / `pybk_build.py` 一个字节**——
本工具只是通过子进程调用 PYbook 已有的 CLI，把外层流水线补上。

## 为什么能零侵入

PYbook 的入口已经是干净的 CLI，本工具只做「定位编译器 → 拼命令 → 解析输出 → 友好呈现」：

| PYbook 本体能力 | 真实契约（已核实） |
|---|---|
| 原生编译+运行（F5） | `python pybk_main.py <文件.pybk>` → 前端→C→gcc→原生 exe 并运行（弹 SDL 窗） |
| 静态校验 | `python pybk_main.py --check-json <文件.pybk>` → `{"ok","line","message"}` |
| 字节码产物（Ctrl+F5） | `python pybk_build.py <文件.pybk> [out.pybc]` → 编译为 `.pybc`（不依赖 gcc） |
| 字节码运行 | `pyvm.exe <文件.pybc>` |
| 项目级冒烟套件 | `python smokeroor.py [--learn|--filter|--json]` 跑 `tests/smoke/`，比对 `.expect` |
| 3D 无头出图 | 设环境变量 `PYBOOK_SHOT_DIR` → `hw` 程序自动存 BMP 帧（仅 3D） |

> PYbook 有**两条执行管线**：原生（C/gcc，日常 F5）和字节码（pyvm，Ctrl+F5）。
> pybktl 的 `check`/`run`/`smoke` 走原生管线；`build`/`run --vm` 走字节码管线。
>
> ⚠️ **双管线警告（v1.1 升级为醒目提示）**：`check` 与 `build` 分属两套独立编译器，
> 语义差距可能**很大**而不只是"不同" —— 实测 `check ✓` 的文件 `build` 报错是常态。
> **新语言特性（`lambda` / `mec.*` / 各类新扩展）只活在 C 管线**，字节码管线会持续滞后。
> 拿到 `check ✓ build ✗` 时先怀疑管线滞后，不是工具坏了。

## 用法

不需要安装，直接用 Python 跑（建议用 PYbook 同款 Python）：

```bash
python pybktl.py --help
python pybktl.py init                       # 在当前目录生成 pybook.md 清单
python pybktl.py check  程序.pybk            # 静态校验，友好化报错 + 错误指纹
python pybktl.py build  程序.pybk            # 编译为 .pybc 字节码产物（离线）
python pybktl.py run    程序.pybk            # 运行（原生管线，弹窗；--vm 走字节码）
python pybktl.py run    程序.pybk --shot-dir out/   # 3D 无头出图验收
python pybktl.py fmt    程序.pybk            # 块级缩进整理（默认预览）
python pybktl.py fmt    程序.pybk --in-place --check  # 落盘并自动复检（失败回滚）
python pybktl.py pkg add 物理引擎 ../libs/physics.pybk
python pybktl.py pkg sync                   # 把依赖 .pybk 同步到各成员目录旁
python pybktl.py ws check                   # 按清单「工作区」段批量 check
python pybktl.py smoke  程序.pybk            # 无头冒烟：真跑一遍，若旁有 .expect 则比对
python pybktl.py smoke  --all               # 委托 smokeroor.py 跑整套 tests/smoke/
python pybktl.py repair 程序.pybk            # 概念神「修」：检查→汇报→问你改不改→改错区
python pybktl.py repair 程序.pybk -y         # 同上，但能安全修的自动改（非交互/批量）
python pybktl.py run    程序.pybk --repair   # 运行前先修：有错就汇报并问你改，改完再跑
```

编译器定位优先级（**无硬编码路径**）：`PYBOOK_HOME` 环境变量 → 当前目录 `pybook.md` 的 `home:` → 从工具自身位置向上找 `pybk_main.py`（工具随包发布，天然能找到包根）→ 从当前目录向上找 `pybk_main.py`。
运行环境复刻 `ide.py`：`PYTHONUTF8=1` + `PYTHONIOENCODING=utf-8`，并把 mingw bin 加进 PATH；子进程 **cwd 固定为 HOME**（PYbook 运行时 `.c/.h` 按 cwd 裸名解析，IDE 也是如此）。

## 子命令一览

| 命令 | 作用 |
|---|---|
| `init` | 在当前目录生成 `pybook.md` 清单模板 |
| `check <文件>` | 静态校验，友好化报错 + 稳定错误指纹（去行号/数字/标识符后 sha1） |
| `build <文件> [out.pybc]` | 编译为 `.pybc` 字节码产物（离线、不运行），可用 `run --vm` 执行 |
| `run <文件> [--vm] [--shot-dir D]` | 运行；默认原生管线（`pybk_main`），`--vm` 走字节码；`--shot-dir` 触发 3D 无头出图 |
| `fmt <文件> [--in-place] [--check]` | 块级缩进整理；`--in-place` 落盘，`--check` 落盘后复检、失败回滚 |
| `pkg add <名> <路径>` | 往 `pybook.md`「依赖」段插入一条 |
| `pkg sync` | 把依赖 `.pybk` 复制到各工作区成员目录旁（让 `引用()` 能解析） |
| `ws build` / `ws check` | 按「工作区」段批量 build / check |
| `smoke <文件> [--shot-dir D] [--timeout N]` | 无头冒烟：真跑一遍看崩不崩；若 `文件.expect` 存在则按 Smokeroor 格式比对 |
| `smoke --all [--json]` | 委托 `smokeroor.py` 跑整套 `tests/smoke/` |
| `lookaround` | 在当前文件夹开启**日志循环**：监控文件改动，并自动记录 run/build/check/smoke 运行与运行时错误到 `lookaround.md`（Ctrl+C 停止） |
| `lookaround log [--file F] [--type run] [--since D] [--tail N]` | 查看/筛选日志 |
| `lookaround report [--out 报告.md]` | 生成团队协作报告（改动/运行/错误汇总 + 待办完成情况） |
| `todo add/done/rm/list/show <文本/编号>` | 文件夹级待办清单（可中途加入，并关联到某次运行） |
| `repair <文件> [-y]` | 概念神「修」：静态检查→汇报错误→问你改不改→改错区（`-y` 自动改，等价 `run --repair` 自动分支） |
| `test <文件\|目录> [--junit out.xml]` | 测试框架：发现 `测试_*`/`test_*` 用例，逐条编译运行，出可读报告 + 可选 JUnit XML |

## 项目清单 `pybook.md`

用 markdown 当清单（人和 AI 都能读写）。复制 `pybook.md.example` 改名即可：

```markdown
## 编译器
home: <解压后的 pybook 根目录，含 pybk_main.py>

## 依赖
- 物理引擎 => ../libs/physics.pybk

## 工作区
- games/披萨塔/main.pybk
- learn/pybook-3d-highway/自学验证.pybk
```

`pkg add` 会把条目插入到对应 `## 段` 内（不是文件末尾）；`ws` 按「工作区」段批量操作。

## 错误指纹

`check` / `smoke` 给每个报错算一个稳定指纹（去行号、去数字、去标识符后 sha1 前 8 位）。
同类错误（只是行号/变量名不同）落到同一指纹——正好喂你的 Smokeroor / AI 改-验循环。

## 已知边界（v1 实测结论）

- `fmt` 是启发式块缩进：假设「一行一条语句、括号不在字符串/注释里」。**v1.1 修正**：
  `#` 注释起始到行尾不参与括号计数（v1 会把文档注释里的示例 `lambda(x) { ... }` 的
  大括号计入深度，注释被缩进搞乱）。依然建议先用预览确认；`--in-place --check`
  会在落盘后自动复检，格式化若把语法搞坏会自动回滚。
- `smoke` 对**会自己退出的程序**最准（如 `tests/smoke/` 用例）。游戏主循环不退出会触发 `--timeout` 超时判失败——这是冒烟的预期行为；真要验收渲染管线用 `--shot-dir` 看是否产出帧。
- 2D `win()` 没有无头窗口开关；无头只覆盖 3D（`hw`）通过 `PYBOOK_SHOT_DIR` 存帧。
- `check` 与 `build` 编译器不同源，结论可能严重不一致（见顶部 ⚠️ 双管线警告）：
  实测 `pybktl check games/mec.pybk` ✓ 而 `build` 报「未声明的函数 list.空」。

## LookAround 文件夹日志循环（随包内置）

`tools/pybktl/` 还带了 **LookAround** —— 一个零依赖（纯标准库）的「文件夹级开发日志循环」。
在任意 PYbook 项目目录里 `cd` 进去后开监控，它就会自动：

- 记录所有**文件改动**（含内容 diff，回看可知具体改了哪几行）；
- 把 `pybktl run/build/check/smoke` 的运行、退出码、输出、运行时错误写进 `lookaround.md`；
- 把 gcc / Python 报错**翻成中文人话**（同一逻辑错误聚合成一条并统计次数，自动剥离 gcc 临时文件名）；
- 维护 `todo` 待办清单（可中途 `add/done/rm`，并用 `run --todo N` 关联到某次运行）；
- 一键生成**团队协作报告**（`lookaround report --out 报告.md`）。

完整用法见同目录 `LOOKAROUND.md`。常用：

```bash
python pybktl.py lookaround            # 开启（前台监控，Ctrl+C 停止；写 .lookaround 标记）
python pybktl.py lookaround log --type run --tail 20
python pybktl.py lookaround report --out 报告.md
python pybktl.py todo add "要做的事"
python pybktl.py run 程序.pybk --todo 1   # 把这次运行关联到待办 #1
```

> 只在「开启监控的文件夹」里跑 `pybktl` 命令才会记录；没开监控时**零副作用**（不碰任何文件）。

## 概念神「修」—— 检查 → 汇报 → 问你改不改 → 改错区

`repair` 是和 `lookaround` / `guard` 同一家的「概念神」：pybktl 只当编译器外壳，
不碰 `pybk_main.py` 一个字节。它靠 `pybk_main.py --check-json` 拿到
`{ok, line, message}`，然后做一件事——**编译器报「第 N 行 缺了 )」，repair 不是默默改，
而是先让你看、再让你拍板**：

```
$ python pybktl.py repair 程序.pybk
✗ 第 3 行  [指纹 26ef8fee]
    第 3 行：期望 ')'，实际是 '}'
      为什么：这里该写合法的名字或关键字，但来了个 `}`
      怎么改：对照 PYBOOK_AI.md 语法速查；保留字不能当名字用
  建议修改：第 2 行留下了未闭合的括号，行尾补 )
    原:     vg.x = (1 + 2
    新:     vg.x = (1 + 2)
  应用此修改？（y/n/q） y
  ✓ 已修改第 2 行
✓ 编译通过（静态：语法 + 语义）
✓ 修复完成：程序.pybk 现在能编译通过（自动修改 1 处）
```

交互：**`y`=改、`n`=跳过并停止、`q`=退出**。也可用 `repair -y` / `run --repair`
走「能安全修的自动改」分支（测试/CI/无头环境），或 `repair` 时管道 EOF 会自动当 `q` 退出，绝不卡死。

### 能安全修的 4 类（只增不删，且可逆）

| 类 | 触发 | 动作 |
|---|---|---|
| A. 字符串未闭合 | `第 N 行：字符串未闭合` | 在错行末尾补上缺失的引号 |
| B. 缺右括号 / 方括号 | `期望 ')'` / `缺少右括号 )` | 从错行向上找「留下未配对该括号的那一行」，行尾补 `)` / `]` |
| C. 块缺收尾 `}` | `块缺少收尾的 }` | 在文件末尾（另起一行）补 `}STOP`（GOING 块）或 `}` |
| D. 拼错的标准库前缀 | `方法 'X' 不存在（对象类型未知）` | 把 `List.添加` 这种近似拼写换成最近的已知模块 `list.添加`（含大小写错 `List→list`） |

> **设计边界（梯子不是房子）**：repair **只动机械、可逆、零歧义**的几类；
> 参数个数错、未定义变量、保留字当名这类需要理解语义的错，它**不瞎猜**，
> 直接提示你手动改第 N 行，绝不越俎代庖。安全守则：只增不删、每次只改一行（块缺 `}` 也只加不删）、
> 改前打印 diff、改后立刻复检、同错修完还在就停（最多 50 轮防死循环）。

## 测试框架 `test` —— 写完功能就写用例，改一处崩一片立刻看见

**解决什么**：大工程里"改一处崩一片"最痛。PYbook 自带 `查(条件, "名字")` 断言（运行结束退出码=失败数），
`test` 把它包成「按约定发现用例 + 逐条编译运行 + 可读报告 + JUnit」的最小可用框架。

**用例约定**：`func` 名以 `测试_` 或 `test_` 开头即算一个用例。断言用 `测试.*` 标准库（中文 API，写出来就像文档）：

```
func 加(a, b) { ret a + b }

func 测试_加法() {
    测试.断言相等(加(2, 2), 4)      # 期望 == 实际
    测试.断言真(加(1, 1) == 2)
}

func 测试_抛错() {
    测试.断言抛出(1 / 0)            # 表达式应抛错，没抛反而判失败
}
```

**断言全家桶**：`测试.断言相等 / 断言不等 / 断言真 / 断言假 / 断言抛出`。
数值近似用组合：`测试.断言真(mt.abs(期望 - 实际) <= 容差)`。

**跑**：

```
python pybktl.py test 程序.pybk                 # 单文件
python pybktl.py test games/披萨塔/             # 目录（递归发现用例）
python pybktl.py test . --junit ci.xml          # 整个项目 + 出 JUnit 给 CI
```

**实现要点（可解释、零侵入）**：
- 发现用例用正则扫 `func (测试|test)\w*`，不依赖完整解析，文件有错也不影响别的用例。
- 每条用例生成一个临时 harness（原文件保留，只把 `GOING` 体换成调用该用例），单独 `pybk_main` 编译运行 → 全局状态隔离。
- 解析运行输出里的 `查：X 通过，Y 失败` 得到通过/失败数；`查失败: 名字` 列出具体挂掉的断言。
- harness 跑完即删，不留垃圾。
- 退出码 1 = 有失败（CI 直接看退出码）。

> 与 `--check-json` 的软类型警告互补：软类型在**写代码时**拦"类型明显不对"，`test` 在**跑起来时**拦"行为不对"。
