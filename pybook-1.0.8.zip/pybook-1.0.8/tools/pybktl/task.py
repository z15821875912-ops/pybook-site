# -*- coding: utf-8 -*-
"""task —— 团队任务流转：认领人 / 截止日 / 状态（人可直接读改的 任务.md）。

    pybktl task add "任务描述" [--owner 张三] [--due 2026-10-20]
    pybktl task list [--owner 张三] [--all]      未完默认；--all 含已完成
    pybktl task done <编号>                       编号 = list 里的序号

存储 = 项目根的 任务.md，一行一条、人能直接读改（共享盘/git 都可见）：

    - [ ] 2026-10-16 张三：Boss 二阶段台词（截止 2026-10-20）
    - [x] 2026-10-15 李四：修碰撞穿墙

作者默认 PYBOOK_AUTHOR > USERNAME。done 的编号按「未完成任务」的显示顺序。
"""
import argparse
import datetime
import os
import re

TASK_MD = "任务.md"


def out(m=""):
    print(m)


def err(m):
    print(m)


def _author():
    return (os.environ.get("PYBOOK_AUTHOR")
            or os.environ.get("USERNAME") or "未知")


def _today():
    return datetime.date.today().isoformat()


def _read():
    if os.path.isfile(TASK_MD):
        return open(TASK_MD, encoding="utf-8").read().split("\n")
    return ["# 团队任务", ""]


def _write(lines):
    open(TASK_MD, "w", encoding="utf-8", newline="").write("\n".join(lines))


def _open_indexes(lines):
    """未完成任务的行号列表（显示顺序 = 编号顺序）。"""
    return [i for i, l in enumerate(lines) if l.strip().startswith("- [ ]")]


def cmd_add(args):
    text = " ".join(args.text or []).strip()
    if not text:
        err('用法: pybktl task add "任务描述" [--owner 张三] [--due 2026-10-20]')
        return 2
    owner = args.owner or _author()
    parts = f"- [ ] {_today()} {owner}：{text}"
    if args.due:
        parts += f"（截止 {args.due}）"
    lines = _read()
    idx = _section_insert(lines)
    lines.insert(idx, parts)
    _write(lines)
    n = len(_open_indexes(lines))
    out(f"✓ 任务 #{n} 已登记给 {owner}：{text}" + (f"（截止 {args.due}）" if args.due else ""))
    return 0


def _section_insert(lines):
    """任务条目插在标题后（没有标题就建档）。"""
    for i, l in enumerate(lines):
        if l.strip().startswith("#"):
            return i + 2 if i + 2 <= len(lines) else len(lines)
    return len(lines)


def cmd_list(args):
    lines = _read()
    open_idx = _open_indexes(lines)
    shown = 0
    for n, i in enumerate(open_idx, 1):
        owner = ""
        m = re.search(r"(\d{4}-\d{2}-\d{2})\s+(\S+)：", lines[i])
        if m:
            owner = m.group(2)
        if args.owner and owner != args.owner:
            continue
        shown += 1
        out(f"  #{n}  {lines[i].strip()[6:]}")
    if args.all:
        out("  -- 已完成 --")
        for l in lines:
            if l.strip().startswith("- [x]"):
                out(f"  ✓ {l.strip()[6:]}")
    if not shown and not args.all:
        out("· 没有未完成任务（--all 看已完成）")
        return 0
    out(f"（未完 {len(open_idx)} 条；完成：pybktl task done <编号>）")
    return 0


def cmd_done(args):
    lines = _read()
    open_idx = _open_indexes(lines)
    n = args.idx
    if n < 1 or n > len(open_idx):
        err(f"✗ 没有第 {n} 号未完成任务（当前 {len(open_idx)} 条）")
        return 1
    i = open_idx[n - 1]
    lines[i] = lines[i].replace("- [ ]", "- [x]", 1)
    _write(lines)
    out(f"✓ 已完成 #{n}：{lines[i].strip()[6:]}")
    return 0


def run(args):
    table = {"add": cmd_add, "list": cmd_list, "done": cmd_done}
    fn = table.get(args.task_cmd)
    if fn is None:
        err("用法: pybktl task add|list|done")
        return 2
    return fn(args)


def build_subparser(sub):
    pt = sub.add_parser("task", help="团队任务流转：认领人 / 截止日 / 状态（任务.md 人能直接读改）")
    tsub = pt.add_subparsers(dest="task_cmd", required=True)

    ta = tsub.add_parser("add", help="登记任务")
    ta.add_argument("text", nargs="+", help="任务描述")
    ta.add_argument("--owner", help="认领人（默认 PYBOOK_AUTHOR/用户名）")
    ta.add_argument("--due", help="截止日期 YYYY-MM-DD")

    tl = tsub.add_parser("list", help="任务列表（默认未完）")
    tl.add_argument("--owner", help="按认领人过滤")
    tl.add_argument("--all", action="store_true", help="含已完成")

    td = tsub.add_parser("done", help="标记完成")
    td.add_argument("idx", type=int, help="list 里的编号")

    pt.set_defaults(func=run)
