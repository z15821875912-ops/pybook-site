# -*- coding: utf-8 -*-
"""airegress —— PYbook AI 栈回归基线：一键跑全部验收程序（原生+VM 双后端）。

每项验收都是自计数的 .pybk（过=N 崩=M），不靠人眼看输出：
  卷积对拍.pybk        5 项  C 层 conv/pool vs 手算锚点 vs 纯 PYbook 卷积库
  算子对拍.pybk       10 项  池化dx/BN/LN/dropout 独立锚点+有限差分
  卷积库演示.pybk      9 项  纯 PYbook 卷积库全 API
  神经网络演示.pybk    E2E   XOR 训练（判对 4/4；VM 不支持类构造，自动跳过）
  _卷积验收/卷积预言机.pybk 7 项  纯 PYbook 卷积/池化锚点

用途：改编译器（sym）、动 rt/lib、上 GPU/F16 之前跑一遍留档基线，
      改完再跑一遍对档——三处不一致就是回归。

用法：
    pybktl airegress                 双后端全跑，出汇总
    pybktl airegress --native-only   只跑原生（快）
    pybktl airegress --save          存档到 _验收基线/（时间戳 + 最新.md）
"""
import datetime
import os
import re
import subprocess
import sys

HIST_HINT = "（GPU/F16 施工图见 _GPU与AMP接力.md；编译器发现见 _语法新发现.md）"

# (显示名, 路径, 期望通过项数 or None=只查无错, VM可跑, 特判子串)
CASES = [
    ("卷积对拍", "卷积对拍.pybk", 5, True, None),
    ("算子对拍", "算子对拍.pybk", 10, True, None),
    ("卷积库演示", "卷积库演示.pybk", 9, True, None),
    ("卷积预言机", os.path.join("_卷积验收", "卷积预言机.pybk"), 7, True, None),
    ("神经网络演示", "神经网络演示.pybk", None, False, "判对: 4"),
]

FAIL_MARKS = ("[错]", "!!", "运行时错误", "编译失败", "虚拟机错误", "Traceback")
COUNT_RE = re.compile(r"过=(\d+)\s+崩=(\d+)")


def out(m=""):
    print(m)


def err(m):
    print(m)


def _run(cmd, root, timeout):
    try:
        p = subprocess.run(cmd, cwd=root, capture_output=True,
                           text=True, encoding="utf-8", errors="replace",
                           timeout=timeout)
        return p.returncode, (p.stdout or "") + (p.stderr or "")
    except subprocess.TimeoutExpired:
        return -1, "超时"
    except Exception as e:
        return -2, str(e)


def _judge(text, expect):
    """返回 (是否通过, 过数, 崩数或None, 证据行)"""
    for mark in FAIL_MARKS:
        if mark in text:
            line = [ln for ln in text.splitlines() if mark in ln]
            return False, None, None, line[0][:100] if line else mark
    m = COUNT_RE.search(text)
    if expect is not None:
        if not m:
            return False, None, None, "未找到 过=N 崩=M 计数行"
        passes, fails = int(m.group(1)), int(m.group(2))
        if fails != 0 or passes != expect:
            return False, passes, fails, f"过={passes} 崩={fails}（期望 过={expect} 崩=0）"
        return True, passes, fails, f"过={passes} 崩=0"
    if m:
        passes, fails = int(m.group(1)), int(m.group(2))
        if fails != 0:
            return False, passes, fails, f"过={passes} 崩={fails}"
        return True, passes, fails, f"过={passes} 崩=0"
    return True, None, None, "无错误标记（无计数行）"


def cmd_airegress(args):
    root = os.getcwd()
    if not os.path.isfile(os.path.join(root, "pybk_main.py")):
        err("✗ 请在 PYbook 仓库根目录运行（找不到 pybk_main.py）")
        return 1

    pyvm = os.path.join(root, "pyvm.exe")
    have_vm = os.path.isfile(pyvm)
    if not have_vm and not args.native_only:
        out("· 未找到 pyvm.exe，VM 后端跳过（build_pyvm.bat 可重建）")

    rows = []
    bad = 0
    for name, path, expect, vm_ok, special in CASES:
        full = os.path.join(root, path)
        if not os.path.isfile(full):
            err(f"✗ {name}: 找不到 {path}")
            rows.append((name, "缺失", "-", "-", "-"))
            bad += 1
            continue

        # 原生
        code, text = _run([sys.executable, "pybk_main.py", path], root, 600)
        ok, p_, f_, ev = _judge(text, expect)
        if special and ok:
            ok = special in text
            ev = special + (" ✓" if ok else " ✗ 未出现")
        nat = "✓" if ok else "✗"
        if not ok:
            bad += 1
        rows.append((name, f"原生{nat}", str(p_ if p_ is not None else "-"),
                     str(f_ if f_ is not None else "-"), ev if not ok else ""))
        out(f"· {name}  原生{nat}  {ev if not ok else ''}")

        # VM
        if args.native_only:
            continue
        if not vm_ok:
            rows[-1] = (rows[-1][0], rows[-1][1], rows[-1][2], rows[-1][3],
                        "VM跳过（类构造不支持）")
            out(f"· {name}  VM ——（类构造 VM 不支持，已知缺口）")
            continue
        if not have_vm:
            rows[-1] = (rows[-1][0], rows[-1][1], rows[-1][2], rows[-1][3],
                        "VM跳过（无 pyvm.exe）")
            continue
        bc = os.path.splitext(path)[0] + ".pybc"
        bcode, btext = _run([sys.executable, "pybk_build.py", path], root, 300)
        if bcode != 0 or not os.path.isfile(os.path.join(root, bc)):
            line = [ln for ln in btext.splitlines() if "未声明" in ln or "错误" in ln]
            err(f"✗ {name}: VM 编译失败 {line[0][:80] if line else ''}")
            rows[-1] = (rows[-1][0], rows[-1][1], rows[-1][2], rows[-1][3],
                        "VM编译失败")
            bad += 1
            continue
        vcode, vtext = _run([os.path.join(root, "pyvm.exe"), bc], root, 600)
        vok, vp_, vf_, vev = _judge(vtext, expect)
        if special and vok:
            vok = special in vtext
            vev = special + (" ✓" if vok else " ✗ 未出现")
        vmc = "✓" if vok else "✗"
        if not vok:
            bad += 1
        out(f"· {name}  VM{vmc}  {vev if not vok else ''}")
        rows[-1] = (rows[-1][0], rows[-1][1] + f" VM{vmc}",
                    rows[-1][2], rows[-1][3], vev if not vok else "")

    out("")
    out(f" airegress 汇总：异常项 {bad}")
    for name, nat, p_, f_, note in rows:
        out(f"   {name:<8} {nat}  {('  ' + note) if note else ''}")
    out(HIST_HINT)

    if args.save:
        d = os.path.join(root, "_验收基线")
        os.makedirs(d, exist_ok=True)
        stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        body = [f"# AI 栈回归基线 {stamp}", "",
                f"异常项：{bad}", "",
                "| 资产 | 原生/VM | 过 | 崩 | 备注 |",
                "|---|---|---|---|---|"]
        for name, nat, p_, f_, note in rows:
            body.append(f"| {name} | {nat} | {p_} | {f_} | {note} |")
        text = "\n".join(body) + "\n"
        with open(os.path.join(d, f"airegress_{stamp}.md"), "w",
                  encoding="utf-8") as fh:
            fh.write(text)
        with open(os.path.join(d, "最新.md"), "w", encoding="utf-8") as fh:
            fh.write(text)
        out(f"· 基线已存档：_验收基线/airegress_{stamp}.md（最新.md 已更新）")

    return 0 if bad == 0 else 1


def build_subparser(sub):
    pa = sub.add_parser("airegress",
                        help="AI 栈回归基线：全部验收程序双后端一键跑 + 可存档")
    pa.add_argument("--native-only", action="store_true",
                    help="只跑原生后端（跳过 VM）")
    pa.add_argument("--save", action="store_true",
                    help="结果存档到 _验收基线/（时间戳文件 + 最新.md）")
    pa.set_defaults(func=cmd_airegress)
