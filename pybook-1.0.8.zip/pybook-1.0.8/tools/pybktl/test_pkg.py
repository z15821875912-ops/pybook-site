#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""pybktl 包管理 v1 自测套件
============================
覆盖：清单统一（init 模板 / TOML 迁移采用 / parse_manifest 读「## 工程」）
     → 版本化依赖（pkg add @版本）→ 锁文件（pkg lock / sync 校验 / 漂移报错）
     → 打包发布装包（pack / publish / install，registry 与文件两条分发路径）
     → pybk_project 读侧对齐。

全部在临时目录里跑，不碰仓库；纯标准库。用法：

    python tools/pybktl/test_pkg.py
"""
import contextlib
import hashlib
import io as _io
import os
import shutil
import subprocess
import sys
import tempfile
import zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import pybktl  # noqa: E402

PYBKTL = os.path.join(HERE, "pybktl.py")
REPO = os.path.dirname(os.path.dirname(HERE))  # <pybook>/
sys.path.insert(0, REPO)

FAILS = []
PASSES = [0]


def check(cond, label, extra=""):
    if cond:
        PASSES[0] += 1
        print(f"  ✓ {label}")
    else:
        FAILS.append(label)
        print(f"  ✗ {label}")
        if extra:
            print(extra)


class A:
    """假冒的 argparse namespace。"""

    def __init__(self, **kw):
        self.__dict__.update(kw)


def run_cmd(fn, args, label, want=0):
    """调 cmd_*，吞掉输出；rc 不符合 want 记失败并 dump 输出。返回 (rc, 输出)。"""
    buf = _io.StringIO()
    with contextlib.redirect_stdout(buf), contextlib.redirect_stderr(buf):
        rc = fn(args)
    check(rc == want, f"{label}（rc={rc}，期望 {want}）",
          "" if rc == want else buf.getvalue())
    return rc, buf.getvalue()


def section(title):
    print(f"\n== {title} " + "=" * max(2, 46 - len(title)))


# ---------------------------------------------------------------------------
def t_init_and_parse(tmp):
    section("清单统一：init 模板 / TOML 迁移采用 / parse_manifest")
    os.chdir(tmp)
    # --- 空白模板 ---
    run_cmd(pybktl.cmd_init, A(team=False), "init 生成 pybook.md")
    md = os.path.join(tmp, "pybook.md")
    check(os.path.isfile(md), "pybook.md 已生成")
    body = open(md, encoding="utf-8").read()
    for sec in ("## 项目", "## 工程", "## 编译器", "## 依赖", "## 工作区"):
        check(sec in body, f"模板含「{sec}」段")
    m = pybktl.parse_manifest(md)
    check(m["entry"] == "src/main.pybk" and m["includes"] == ["src"],
          "parse_manifest 读「## 工程」entry/include", str(m))
    check(m["target"] == "app.exe" and m["cache"] is False
          and m["separate"] is False, "工程段缺省值正确", str(m))
    # 幂等：再 init 跳过
    run_cmd(pybktl.cmd_init, A(team=False), "init 幂等（已存在则跳过）")

    # --- TOML 迁移采用 ---
    d2 = os.path.join(tmp, "tomlcase")
    os.makedirs(d2, exist_ok=True)
    open(os.path.join(d2, "PYBOOK.toml"), "w", encoding="utf-8").write(
        '[project]\nentry = "主.pybk"\ninclude = ["工具", "libs"]\n'
        'target = "demo.exe"\ncache = true\nseparate = true\n'
        'name = "迁移测试"\nversion = "9.9.9"\n')
    os.chdir(d2)
    rc, out = run_cmd(pybktl.cmd_init, A(team=False), "init 从 PYBOOK.toml 迁移生成")
    check("迁移" in out, "输出提示迁移")
    gen = open(os.path.join(d2, "pybook.md"), encoding="utf-8").read()
    m2 = pybktl.parse_manifest(os.path.join(d2, "pybook.md"))
    check(m2["entry"] == "主.pybk" and m2["includes"] == ["工具", "libs"],
          "迁移后 entry/include 正确", str(m2))
    check(m2["target"] == "demo.exe" and m2["cache"] is True
          and m2["separate"] is True, "迁移后 target/cache/separate 正确", str(m2))
    check(m2["version"] == "9.9.9", "迁移后版本正确", str(m2))

    # --- pybk_project 读侧对齐 ---
    os.chdir(REPO)
    import pybk_project
    mf = pybk_project.load_manifest_md(os.path.join(d2, "pybook.md"))
    check(mf["entry"] == "主.pybk" and mf["target"] == "demo.exe"
          and mf["cache"] is True and mf["separate"] is True,
          "pybk_project.load_manifest_md 读全工程字段", str(mf))
    os.chdir(tmp)


# ---------------------------------------------------------------------------
def t_add_lock_sync(tmp):
    section("版本化依赖 + lockfile：add@版本 / lock / sync 校验 / 漂移报错")
    proj = os.path.join(tmp, "lockcase")
    lib = os.path.join(proj, "libs")
    mem = os.path.join(proj, "members")
    os.makedirs(lib, exist_ok=True)
    os.makedirs(mem, exist_ok=True)
    src = os.path.join(lib, "物理.pybk")
    open(src, "w", encoding="utf-8").write("@ 物理>库\nfunc 重力(){ ret 9.8 }\nSTOP\n")
    open(os.path.join(mem, "main.pybk"), "w", encoding="utf-8").write(
        "@ 主\nGOING:{ ns.show(1) }STOP\n")
    os.chdir(proj)
    open("pybook.md", "w", encoding="utf-8").write(
        "# 清单\n\n## 项目\nname: 锁测试\nversion: 0.1.0\n\n## 工程\nentry: members/main.pybk\n\n"
        "## 工作区\n- members/main.pybk\n")

    # add 带 @版本 + 幂等
    run_cmd(pybktl.cmd_pkg, A(pkg_action="add", name="物理", path="libs/物理.pybk @1.2.0"),
            "pkg add 带 @版本")
    run_cmd(pybktl.cmd_pkg, A(pkg_action="add", name="物理", path="libs/物理.pybk @1.2.0"),
            "pkg add 幂等（重复添加跳过）")
    m = pybktl.parse_manifest(os.path.join(proj, "pybook.md"))
    check(m["deps"] == [("物理", "libs/物理.pybk", "1.2.0")],
          "parse_manifest 解析出版本化依赖三元组", str(m["deps"]))
    lines = [l for l in open("pybook.md", encoding="utf-8").read().split("\n")
             if l.startswith("- ") and "=>" in l]
    check(len(lines) == 1, "重复 add 不产生第二行", str(lines))

    # lock
    run_cmd(pybktl.cmd_pkg, A(pkg_action="lock"), "pkg lock 生成 pybook.lock")
    check(os.path.isfile(os.path.join(proj, "pybook.lock")), "pybook.lock 已生成")
    locks = pybktl.parse_lock(os.path.join(proj, "pybook.lock"))
    want_sha = hashlib.sha256(open(src, "rb").read()).hexdigest()
    check(locks.get("物理", ("", "", ""))[2] == want_sha,
          "锁里 sha256 与文件一致", str(locks))
    check(locks.get("物理", ("",))[0] == "1.2.0", "锁里带版本号", str(locks))

    # sync 有锁且一致 → 过；并真复制到成员目录旁
    run_cmd(pybktl.cmd_pkg, A(pkg_action="sync", force=False),
            "pkg sync 锁校验通过并复制")
    check(os.path.isfile(os.path.join(mem, "物理.pybk")),
          "依赖已 vendor 到成员目录旁")

    # list 看状态
    rc, out = run_cmd(pybktl.cmd_pkg, A(pkg_action="list"), "pkg list 显示锁定状态")
    check("✓ 已锁定" in out, "list 标出已锁定", out)

    # 篡改源文件 → sync 必须拒绝
    open(src, "a", encoding="utf-8").write("func 额外(){ ret 1 }\n")
    rc, out = run_cmd(pybktl.cmd_pkg, A(pkg_action="sync", force=False),
                      "pkg sync 检出依赖漂移（rc=1）", want=1)
    check("校验和不符" in out, "漂移信息含「校验和不符」", out)
    # --force 强行同步
    run_cmd(pybktl.cmd_pkg, A(pkg_action="sync", force=True),
            "pkg sync --force 跳过锁校验")
    # 重新 lock 后又一致
    run_cmd(pybktl.cmd_pkg, A(pkg_action="lock"), "改动后重跑 pkg lock")
    rc, out = run_cmd(pybktl.cmd_pkg, A(pkg_action="list"), "pkg list 恢复已锁定")
    check("✓ 已锁定" in out, "重锁后 list 恢复", out)


# ---------------------------------------------------------------------------
def t_pack_publish_install(tmp):
    section("打包 / 发布 / 安装：.pybp + 本地 registry + 文件分发")
    reg = os.path.join(tmp, "registry")
    os.environ["PYBOOK_REGISTRY"] = reg
    libdir = os.path.join(tmp, "物理引擎")
    os.makedirs(os.path.join(libdir, "sub"), exist_ok=True)
    open(os.path.join(libdir, "pybook.md"), "w", encoding="utf-8").write(
        "# 包清单\n\n## 项目\nname: 物理引擎\nversion: 1.0.0\n")
    open(os.path.join(libdir, "物理.pybk"), "w", encoding="utf-8").write(
        "@ 物理>库\nfunc 重力(){ ret 9.8 }\nSTOP\n")
    open(os.path.join(libdir, "sub", "碰撞.pybk"), "w", encoding="utf-8").write(
        "@ 碰撞>库\nfunc 弹(){ ret 0.5 }\nSTOP\n")

    # pack
    proj = os.path.join(tmp, "packcase")
    os.makedirs(proj, exist_ok=True)
    os.chdir(proj)
    open("pybook.md", "w", encoding="utf-8").write("# 清单\n\n## 项目\nname: 打包测试\nversion: 0.1.0\n")
    pybp = os.path.join(proj, "物理引擎-1.0.0.pybp")
    run_cmd(pybktl.cmd_pkg, A(pkg_action="pack", name=libdir, out=pybp, as_name=None, version=None),
            "pkg pack 打成 .pybp")
    check(os.path.isfile(pybp), ".pybp 文件存在")
    with zipfile.ZipFile(pybp) as zf:
        names = zf.namelist()
        check("包清单.md" in names and "物理.pybk" in names
              and "sub/碰撞.pybk" in names, "包内含 包清单.md + 全部 .pybk", str(names))
        pkg_md = zf.read("包清单.md").decode("utf-8")
        check("name: 物理引擎" in pkg_md and "version: 1.0.0" in pkg_md,
              "包清单.md 记 包名/版本（中文包名）")

    # publish（版本 1.0.0）
    run_cmd(pybktl.cmd_pkg,
            A(pkg_action="publish", name=libdir, as_name=None, version=None, registry=None),
            "pkg publish 发布到本地 registry")
    check(os.path.isfile(os.path.join(reg, "索引.md")), "registry 索引.md 已生成")
    check(os.path.isfile(os.path.join(reg, "物理引擎-1.0.0.pybp")), "registry 里有 .pybp")
    idx1 = pybktl._read_registry_index(reg)
    check(len(idx1) == 1 and idx1[0][0] == "物理引擎" and idx1[0][1] == "1.0.0",
          "索引一条记录（包名/版本）", str(idx1))
    # 重发同版本 → 不翻倍
    run_cmd(pybktl.cmd_pkg,
            A(pkg_action="publish", name=libdir, as_name=None, version=None, registry=None),
            "重发同版本（覆盖不翻倍）")
    check(len(pybktl._read_registry_index(reg)) == 1, "索引仍为 1 条")
    # 发 2.0.0 → 两条
    open(os.path.join(libdir, "pybook.md"), "w", encoding="utf-8").write(
        "# 包清单\n\n## 项目\nname: 物理引擎\nversion: 2.0.0\n")
    open(os.path.join(libdir, "物理.pybk"), "a", encoding="utf-8").write("func 新(){ ret 1 }\n")
    run_cmd(pybktl.cmd_pkg,
            A(pkg_action="publish", name=libdir, as_name=None, version=None, registry=None),
            "发布 2.0.0")
    idx2 = pybktl._read_registry_index(reg)
    check(len(idx2) == 2, "索引累计 2 条", str(idx2))

    # install 不带版本 → 取最高（2.0.0）
    proj2 = os.path.join(tmp, "installcase")
    os.makedirs(proj2, exist_ok=True)
    os.chdir(proj2)
    open("pybook.md", "w", encoding="utf-8").write("# 清单\n\n## 项目\nname: 安装测试\nversion: 0.1.0\n")
    run_cmd(pybktl.cmd_pkg, A(pkg_action="install", name="物理引擎", registry=None),
            "pkg install 装最高版本")
    check(os.path.isfile(os.path.join(proj2, "libs", "物理引擎", "物理.pybk")),
          "包已解压到 libs/物理引擎/")
    check(os.path.isfile(os.path.join(proj2, "libs", "物理引擎", "sub", "碰撞.pybk")),
          "子目录结构保留")
    m = pybktl.parse_manifest(os.path.join(proj2, "pybook.md"))
    vers = {d[2] for d in m["deps"]}
    names = {d[0] for d in m["deps"]}
    check(vers == {"2.0.0"}, "依赖登记带 @2.0.0", str(m["deps"]))
    check(names == {"物理", "碰撞"}, "包内每个模块一条依赖", str(m["deps"]))
    # 再 install 一次 → 不重复登记
    run_cmd(pybktl.cmd_pkg, A(pkg_action="install", name="物理引擎", registry=None),
            "重复 install 幂等")
    m = pybktl.parse_manifest(os.path.join(proj2, "pybook.md"))
    check(len(m["deps"]) == 2, "重复 install 不产生重复依赖", str(m["deps"]))

    # install @1.0.0 指定版本
    proj3 = os.path.join(tmp, "installcase2")
    os.makedirs(proj3, exist_ok=True)
    os.chdir(proj3)
    open("pybook.md", "w", encoding="utf-8").write("# 清单\n\n## 项目\nname: 安装测试2\nversion: 0.1.0\n")
    run_cmd(pybktl.cmd_pkg, A(pkg_action="install", name="物理引擎@1.0.0", registry=None),
            "pkg install 指定 @1.0.0")
    m = pybktl.parse_manifest(os.path.join(proj3, "pybook.md"))
    check({d[2] for d in m["deps"]} == {"1.0.0"}, "装的是 1.0.0", str(m["deps"]))
    check(not os.path.isfile(os.path.join(proj3, "libs", "物理引擎", "物理.pybk"))
          or "新" not in open(os.path.join(proj3, "libs", "物理引擎", "物理.pybk"),
                             encoding="utf-8").read(),
          "1.0.0 内容正确（无 2.0.0 的新函数）")

    # 文件分发：直接 install 一个 .pybp 文件
    proj4 = os.path.join(tmp, "filecase")
    os.makedirs(proj4, exist_ok=True)
    os.chdir(proj4)
    open("pybook.md", "w", encoding="utf-8").write("# 清单\n\n## 项目\nname: 文件分发\nversion: 0.1.0\n")
    run_cmd(pybktl.cmd_pkg, A(pkg_action="install", name=pybp, registry=None),
            "pkg install 直接吃 .pybp 文件（不过 registry）")
    check(os.path.isfile(os.path.join(proj4, "libs", "物理引擎", "物理.pybk")),
          "文件分发也解压到 libs/")
    m = pybktl.parse_manifest(os.path.join(proj4, "pybook.md"))
    check({d[2] for d in m["deps"]} == {"1.0.0"}, "文件分发登记 @1.0.0", str(m["deps"]))

    # install 不存在的包 → rc=1
    run_cmd(pybktl.cmd_pkg, A(pkg_action="install", name="不存在的包", registry=None),
            "install 不存在的包报错（rc=1）", want=1)


# ---------------------------------------------------------------------------
def t_cli_wiring():
    section("CLI 接线：--help / pkg --help 露出新子命令")
    env = dict(os.environ, PYTHONUTF8="1")
    for argsin in (["--help"], ["pkg", "--help"]):
        r = subprocess.run([sys.executable, PYBKTL] + argsin,
                           capture_output=True, text=True, encoding="utf-8",
                           timeout=60, env=env, cwd=HERE)
        check(r.returncode == 0, f"pybktl.py {' '.join(argsin)} 退出 0")
    r = subprocess.run([sys.executable, PYBKTL, "pkg", "--help"],
                       capture_output=True, text=True, encoding="utf-8",
                       timeout=60, env=env, cwd=HERE)
    for kw in ("lock", "pack", "publish", "install", "list", "--registry", "--force"):
        check(kw in r.stdout, f"pkg --help 含 {kw}")


def main():
    tmp = tempfile.mkdtemp(prefix="pybktl_pkg_")
    cwd0 = os.getcwd()
    try:
        t_init_and_parse(tmp)
        t_add_lock_sync(tmp)
        t_pack_publish_install(tmp)
        t_cli_wiring()
    finally:
        os.chdir(cwd0)
        shutil.rmtree(tmp, ignore_errors=True)
        os.environ.pop("PYBOOK_REGISTRY", None)
    print("\n" + "=" * 52)
    if FAILS:
        print(f"✗ {len(FAILS)} 项失败 / 共 {PASSES[0] + len(FAILS)} 项：")
        for f in FAILS:
            print("  - " + f)
        sys.exit(1)
    print(f"✓ 全部通过（{PASSES[0]} 项）")


if __name__ == "__main__":
    main()
