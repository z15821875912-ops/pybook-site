# -*- coding: utf-8 -*-
"""doctor —— PYbook 工作区小诊所：小问题自动发现 + --fix 自动修复。

每一项都来自真实踩过的坑：
  ① .git/index.lock 僵尸锁（崩溃的 git 留下，35 分钟卡死全仓库 git 操作）
  ② 僵尸进程（pyvm.exe / app_*.exe 占着端口和 exe 文件）
  ③ exe_cache 堆积（60 个 × 650KB ≈ 37MB）
  ④ 根级孤儿（out_*.c / app_*.exe 编译残渣）
  ⑤ 版本漂移（VERSION / pybook.md / README 三处版本号不一致——发布日大坑）
  ⑥ 根级杂物（_* / *.log / *.bak 仓库卫生）

用法：
    pybktl doctor            体检（只报告）
    pybktl doctor --fix      报告 + 自动修能安全修的
"""
import datetime
import glob
import os
import re
import subprocess

HIST_HINT = "（历史快照可用 pybktl hist save / restore 管理）"


def out(m=""):
    print(m)


def err(m):
    print(m)


def _pid_running(pid):
    try:
        p = subprocess.run(["tasklist", "/FI", f"PID eq {pid}"],
                           capture_output=True, text=True, encoding="gbk", errors="replace", timeout=15)
        return str(pid) in (p.stdout or "")
    except Exception:
        return False


def _git_running():
    try:
        p = subprocess.run(["tasklist"], capture_output=True, text=True, encoding="gbk", errors="replace", timeout=15)
        return "git.exe" in (p.stdout or "")
    except Exception:
        return False


def _dir_size(path):
    total = 0
    for dp, _d, fns in os.walk(path):
        for fn in fns:
            try:
                total += os.path.getsize(os.path.join(dp, fn))
            except OSError:
                pass
    return total


def check_lock(root, fix):
    lock = os.path.join(root, ".git", "index.lock")
    if not os.path.isfile(lock):
        return
    if _git_running():
        out("[跳过] .git/index.lock 存在，但有 git 进程在跑——等它结束")
        return
    import time
    age_min = (time.time() - os.path.getmtime(lock)) / 60
    if age_min < 2:
        out(f"[跳过] index.lock 刚出现（{age_min:.0f} 分钟）——可能是活操作")
        return
    out(f"✗ 僵尸锁：.git/index.lock 已挂 {age_min:.0f} 分钟且无 git 进程——全仓库 git 操作被卡死")
    if fix:
        os.remove(lock)
        out("  ✓ 已清除（标准 git 僵尸锁恢复；若 git 又报锁，说明真有进程在跑）")
    else:
        out("  修复：删掉它即可（无 git 进程时安全）；pybktl doctor --fix 自动做")


def check_zombies(fix):
    import subprocess as sp
    rows = sp.run(["tasklist"], capture_output=True, text=True, encoding="gbk", errors="replace", timeout=15).stdout or ""
    zombies = []
    for line in rows.splitlines():
        low = line.lower()
        if low.startswith("pyvm.exe") or low.startswith("app_"):
            parts = line.split()
            if len(parts) >= 2 and parts[1].isdigit():
                zombies.append((parts[0], parts[1]))
    if not zombies:
        return
    out(f"✗ 僵尸进程 {len(zombies)} 个：占着端口和 exe 文件（上次运行没退干净）")
    for name, pid in zombies:
        out(f"  - {name}  PID {pid}")
    if fix:
        for name, pid in zombies:
            sp.run(["taskkill", "/PID", pid, "/F"], capture_output=True, timeout=15)
        out("  ✓ 已全部结束")
    else:
        out("  修复：taskkill /PID <pid> /F；pybktl doctor --fix 自动做")


def check_exe_cache(root, fix):
    cache = os.path.join(root, "exe_cache")
    if not os.path.isdir(cache):
        return
    files = sorted(
        (os.path.getmtime(os.path.join(cache, f)), os.path.join(cache, f), os.path.getsize(os.path.join(cache, f)))
        for f in os.listdir(cache) if f.endswith(".exe"))
    total = sum(s for _, _, s in files)
    if total < 20 * 1024 * 1024:
        return
    out(f"✗ exe_cache 堆积：{len(files)} 个 / {total / 1e6:.0f} MB")
    if fix:
        keep = 20
        for _mt, p, _s in files[:-keep] if len(files) > keep else []:
            try:
                os.remove(p)
            except OSError:
                pass
        left = sum(os.path.getsize(os.path.join(cache, f)) for f in os.listdir(cache) if f.endswith(".exe"))
        out(f"  ✓ 已修剪到最近 {min(len(files), keep)} 个（现 {left / 1e6:.0f} MB）")
    else:
        out("  修复：pybktl doctor --fix 修剪到最近 20 个")


def check_orphans(root, fix):
    orphans = sorted(glob.glob(os.path.join(root, "out_*.c")) + glob.glob(os.path.join(root, "app_*.exe")))
    if not orphans:
        return
    size = sum(os.path.getsize(p) for p in orphans if os.path.isfile(p))
    out(f"✗ 根级编译残渣 {len(orphans)} 个 / {size / 1e6:.1f} MB（out_*.c / app_*.exe）")
    if fix:
        for p in orphans:
            try:
                os.remove(p)
            except OSError:
                pass
        out("  ✓ 已清除")
    else:
        out("  修复：pybktl doctor --fix 清除")


def check_version_drift(root):
    vers = {}
    vp = os.path.join(root, "VERSION")
    if os.path.isfile(vp):
        vers["VERSION"] = open(vp, encoding="utf-8").read().strip()
    mp = os.path.join(root, "pybk_main.py")
    if os.path.isfile(mp):
        import re as _re
        m = _re.search(r"PYBOOK_VERSION\s*=\s*'([\d.]+)'", open(mp, encoding="utf-8").read())
        if m:
            vers["pybk_main.py"] = m.group(1)
    rp = os.path.join(root, "README.md")
    if os.path.isfile(rp):
        m = _re.search(r"当前版本 \*\*([\d.]+)\*\*", open(rp, encoding="utf-8").read())
        if m:
            vers["README"] = m.group(1)
    uniq = set(vers.values())
    if len(uniq) > 1:
        out(f"✗ 版本漂移：{('；'.join(k + '=' + v for k, v in vers.items()))}")
        out("  修复：pybktl release --skip-bump 会以 VERSION 为准同步全部（或手改一致）")
    elif vers:
        out(f"· 版本一致：{list(uniq)[0]}")


def check_junk(root):
    import re as _re
    pat = _re.compile(r"^_|\.log$|\.bak")
    junk = [f for f in os.listdir(root)
            if os.path.isfile(os.path.join(root, f)) and pat.search(f)]
    if len(junk) > 50:
        out(f"⚠ 根级杂物 {len(junk)} 个（_* / *.log / *.bak）——pybktl release 打包时会自动排除，")
        out("  但建议定期归档清理；正式清理前先 pybktl hist save 拍个快照")


def _env_card(root):
    """环境基准卡：版本 + 关键件存在性（JSON 导出，团队共享给新成员对比）。"""
    card = {}
    vp = os.path.join(root, "VERSION")
    if os.path.isfile(vp):
        card["VERSION"] = open(vp, encoding="utf-8").read().strip()
    for name in ("pyvm.exe", "SDL2.dll", "libwinpthread-1.dll",
                 "PYbookIDE.exe", "editor.exe",
                 "pybk_main.py", "pybk_front.py", "pybook_gpu.c", "pybook_la.c"):
        card[name] = os.path.isfile(os.path.join(root, name))
    return card


def cmd_export(args):
    import json as _j
    root = os.getcwd()
    card = _env_card(root)
    card["导出时间"] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
    open(args.export, "w", encoding="utf-8").write(_j.dumps(card, ensure_ascii=False, indent=2))
    out(f"✓ 环境基准卡已导出 → {args.export}")
    out("  团队共享这份 JSON；新成员 doctor --compare 这份文件 验收自己的环境")
    return 0


def cmd_compare(args):
    import json as _j
    if not os.path.isfile(args.compare):
        err(f"✗ 找不到基准卡: {args.compare}")
        return 1
    base = _j.loads(open(args.compare, encoding="utf-8").read())
    cur = _env_card(os.getcwd())
    diffs = []
    for k, v in base.items():
        if k == "导出时间":
            continue
        cv = cur.get(k, "<无此项>")
        if cv != v:
            diffs.append(f"  ✗ {k}: 基准={v}  你={cv}")
    if diffs:
        out(f"✗ 与环境基准卡不符 {len(diffs)} 处：")
        for d in diffs:
            out(d)
        return 1
    out("✓ 环境与基准卡一致")
    return 0


def _dispatch_doctor(args):
    if getattr(args, "export", None):
        return cmd_export(args)
    if getattr(args, "compare", None):
        return cmd_compare(args)
    return run(args)


def run(args):
    root = os.getcwd()
    out("== PYbook 工作区诊所 ==")
    check_lock(root, args.fix)
    check_zombies(args.fix)
    check_orphans(root, args.fix)
    check_exe_cache(root, args.fix)
    check_version_drift(root)
    check_junk(root)
    out("== 完毕。历史与回滚：" + HIST_HINT)
    return 0


def build_subparser(sub):
    pd = sub.add_parser("doctor", help="工作区小诊所：僵尸锁/僵尸进程/缓存堆积/版本漂移 体检+修复")
    pd.add_argument("--fix", action="store_true", help="自动修能安全修的（默认只报告）")
    pd.add_argument("--export", metavar="文件", help="导出环境基准卡 JSON（团队共享）")
    pd.add_argument("--compare", metavar="基准.json", help="对比环境基准卡（新成员验收）")
    pd.set_defaults(func=_dispatch_doctor)
