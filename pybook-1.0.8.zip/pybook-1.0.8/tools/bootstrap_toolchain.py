#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Bootstrap the PYbook native toolchain (MinGW-w64 + SDL2) for building pyvm.

The repository intentionally does NOT ship the ~420MB toolchain in git.
Instead this script locates or fetches what the build needs:

  1. Bundled toolchain already on disk (发布打包_102/mingw64)         -> use it.
  2. A system C compiler on PATH (x86_64-w64-mingw32-gcc/gcc/clang) -> use it.
  3. Otherwise download a prebuilt bundle from PYBOOK_TOOLCHAIN_URL and extract
     it into the repo root (recreating 发布打包_102/mingw64 and ucrt64/).

On non-Windows we only verify a system compiler exists (install via apt/brew).

Usage:
    python tools/bootstrap_toolchain.py
Environment:
    PYBOOK_TOOLCHAIN_URL   override the download URL (default: release asset)
"""
import os
import sys
import shutil
import subprocess
import urllib.request
import zipfile

REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DEFAULT_URL = ("https://github.com/z15821875912-ops/pybook/releases/latest/"
               "download/pybook-toolchain-windows.zip")

BUNDLED_GCC = os.path.join(REPO_ROOT, "发布打包_102", "mingw64",
                           "bin", "x86_64-w64-mingw32-gcc.exe")


def log(msg):
    print("[bootstrap] " + msg)


def have_bundled():
    return os.path.isfile(BUNDLED_GCC)


def have_system_cc():
    for exe in ("x86_64-w64-mingw32-gcc", "gcc", "clang"):
        if shutil.which(exe):
            return exe
    return None


def extract_zip(archive, dest):
    # Prefer platform tools (fast), fall back to stdlib zipfile.
    if sys.platform == "win32":
        try:
            subprocess.run(
                ["powershell", "-NoProfile", "-Command",
                 "Expand-Archive -Force -Path '%s' -DestinationPath '%s'"
                 % (archive, dest)],
                check=True)
            return True
        except Exception as e:  # noqa: BLE001
            log("PowerShell Expand-Archive failed (%s); trying zipfile" % e)
    if shutil.which("unzip"):
        try:
            subprocess.run(["unzip", "-o", archive, "-d", dest], check=True)
            return True
        except Exception as e:  # noqa: BLE001
            log("unzip failed (%s); trying zipfile" % e)
    try:
        with zipfile.ZipFile(archive) as z:
            z.extractall(dest)
        return True
    except Exception as e:  # noqa: BLE001
        log("zipfile extraction failed: %s" % e)
        return False


def download(url, dest_path):
    log("downloading toolchain bundle from %s" % url)
    try:
        urllib.request.urlretrieve(url, dest_path)
        return True
    except Exception as e:  # noqa: BLE001
        log("download failed: %s" % e)
        return False


def main():
    is_win = sys.platform == "win32"

    if is_win and have_bundled():
        log("using bundled toolchain: 发布打包_102/mingw64")
        return 0
    cc = have_system_cc()
    if cc:
        log("using system compiler: %s" % cc)
        return 0

    if not is_win:
        log("no C compiler found. Install one and retry:")
        log("  Debian/Ubuntu: sudo apt install gcc")
        log("  macOS:         brew install gcc")
        return 1

    # Windows, no compiler available: try to download.
    url = os.environ.get("PYBOOK_TOOLCHAIN_URL", DEFAULT_URL)
    os.makedirs(os.path.join(REPO_ROOT, "build_tmp"), exist_ok=True)
    archive = os.path.join(REPO_ROOT, "build_tmp", "toolchain.zip")
    if not download(url, archive):
        log("could not fetch toolchain automatically.")
        log("Options:")
        log("  a) publish the asset and set PYBOOK_TOOLCHAIN_URL, then re-run `make deps`")
        log("  b) install MSYS2 and `pacman -S mingw-w64-x86_64-gcc`, or `winget install mingw`")
        log("  c) place MinGW-w64 manually at 发布打包_102/mingw64")
        return 1

    log("extracting to repo root (recreates 发布打包_102/mingw64, ucrt64/) ...")
    if not extract_zip(archive, REPO_ROOT):
        log("extraction failed; see messages above.")
        return 1
    if have_bundled():
        log("toolchain ready at 发布打包_102/mingw64")
        return 0
    log("extraction finished but gcc still not found at expected path.")
    return 1


if __name__ == "__main__":
    sys.exit(main())
