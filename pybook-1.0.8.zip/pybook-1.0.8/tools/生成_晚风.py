# -*- coding: utf-8 -*-
"""MyMusic：为 PYbook 创作一首曲子并生成乐谱源码（音.奏 用）。

与 mm 画画完全对称的路线：
    mm：Python 算像素 -> 列表 -> mm.draw_away -> PNG
    音：Python 作曲   -> 列表 -> 音.奏       -> WAV

曲子：《晚风》  A 小调 / 96 BPM / 16 小节 / 40.0 秒 / 10 条音轨

编曲
    旋律   A 小调五声（A C D E G），D4..E5，纯正弦，慢速留白
    和声垫 Am-F-C-G 循环，自定义 t* 名走三角波，八分音符分解琶音
    贝斯   根音/五度交替，低八度正弦，每拍半有休止
    鼓     底鼓 K(55Hz正弦) / 军鼓 S(196Hz三角) / 踩镲 H(噪声)

两个必须绕着库的设计走的地方

1) 没有音量旋钮。rt_mu_奏 只在混完之后做一次 0.7/peak 全局归一，
   混音是线性相加。所以「让一件乐器更响」= 其它所有乐器一起被压低。
   唯一的增益手段是复制音轨：噪声波形种子只取决于「音符内样本序号 + 频率」，
   同一位置两个同频 H 音符逐位相同，相加即精确 ×2。
   倍数由 _songbal2.py 的三维扫描定出来（目标：贝斯30% 低中16% 中30% 镲8%）。

2) 没有包络。每个音符从头到尾恒幅延音，等于风琴。
   所以打击乐必须用 0.06~0.15 拍这样的极短时值，否则会变成「嗡」而不是「击」。
   实测：加 5ms 淡入只改变总能量 0.9%、>2kHz 段 0.27dB，音符起始跳变可忽略。
"""
import os
import sys

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

ROOT = r"C:\Users\zhuli\Desktop\pybook"
BPM = 96
BEAT = 60.0 / BPM
WAV = "晚风.wav"

# 扫描定出来的鼓组倍数（见 _songbal2.py）
KICK_BOOST = 2
SNARE_BOOST = 2
HAT_BOOST = 3

KICK_D = 0.15       # 底鼓 ~94ms
SNARE_D = 0.15      # 军鼓 ~94ms
HAT_D = 0.06        # 踩镲 ~37ms

SEMI = {"C": 0, "D": 2, "E": 4, "F": 5, "G": 7, "A": 9, "B": 11}


def freq_of(name):
    """科学音名 -> 频率，公式与 pybook_music.c:311 的 mu_parse_note 一致"""
    letter, octv = name[0], int(name[1:])
    midi = (octv + 1) * 12 + SEMI[letter]
    return 440.0 * (2.0 ** ((midi - 69) / 12.0))


def note(name, dur):
    return name if dur == 1 else "%s:%g" % (name, dur)


def rest(dur):
    return "." if dur == 1 else ".:%g" % dur


# ============ 旋律：16 小节 x 4 拍 ============
MELODY = [
    [("E5", 2), ("A4", 1), ("G4", 1)],
    [("A4", 1), ("G4", 1), ("E4", 1), ("D4", 1)],
    [("D4", 2), ("E4", 1), ("G4", 1)],
    [("A4", 3), (None, 1)],
    [("C5", 1), ("E5", 1), ("D5", 1), ("C5", 1)],
    [("E5", 2), ("C5", 1), ("A4", 1)],
    [("D5", 1), ("C5", 1), ("A4", 1), ("G4", 1)],
    [("A4", 4)],
    [("E5", 1), ("D5", 0.5), ("C5", 0.5), ("D5", 2)],
    [("C5", 1), ("A4", 1), ("G4", 1), ("E4", 1)],
    [("D4", 1), ("E4", 1), ("G4", 1), ("A4", 1)],
    [("C5", 4)],
    [("E5", 2), ("A4", 1), ("C5", 1)],
    [("G4", 2), ("E4", 1), ("D4", 1)],
    [("E4", 2), ("D4", 2)],
    [("A4", 4)],
]

# ============ 和声垫：Am-F-C-G，每和弦 2 小节 ============
CHORD = {"Am": ["A3", "C4", "E4"], "F": ["F3", "A3", "C4"],
         "C": ["C4", "E4", "G4"], "G": ["G3", "B3", "D4"]}
PROG = ["Am", "F", "C", "G", "Am", "F", "G", "Am"]
ARPEGGIO = [0, 1, 2, 1, 2, 0, 1, 2]


def pad_tokens():
    out = []
    for ch in PROG:
        tones = CHORD[ch]
        for rep in range(2):
            if rep == 1 and ch in ("G", "Am"):
                # 后半程改成更疏的整拍，制造「风停一下」
                for i in (0, 1, 2, 0):
                    out.append(note("t" + tones[i], 1))
            else:
                for i in ARPEGGIO:
                    out.append(note("t" + tones[i], 0.5))
    return out


# ============ 贝斯 ============
BASS_ROOT = {"Am": "A2", "F": "F2", "C": "C2", "G": "G2"}
BASS_FIFTH = {"Am": "E2", "F": "C3", "C": "G2", "G": "D3"}


def bass_tokens():
    out = []
    for ch in PROG:
        r, f = BASS_ROOT[ch], BASS_FIFTH[ch]
        for _ in range(2):
            out += [note(r, 1.5), rest(0.5), note(f, 1), note(r, 1)]
    return out


# ============ 鼓：三件分轨，各自独立可调 ============
def kick_tokens():
    out = []
    for _ in PROG:
        for _m in range(2):
            for b in range(4):
                if b % 2 == 0:
                    out += [note("K", KICK_D), rest(1 - KICK_D)]
                else:
                    out.append(rest(1))
    return out


def snare_tokens():
    out = []
    for _ in PROG:
        for _m in range(2):
            for b in range(4):
                if b % 2 == 1:
                    out += [note("S", SNARE_D), rest(1 - SNARE_D)]
                else:
                    out.append(rest(1))
    return out


def hat_tokens():
    out = []
    for _ in PROG:
        for _m in range(2):
            for _e in range(8):
                out += [note("H", HAT_D), rest(0.5 - HAT_D)]
    return out


# ============ 组装 ============
MEL_ROW = [rest(d) if nm is None else note(nm, d) for m in MELODY for nm, d in m]
PAD_ROW = pad_tokens()
BASS_ROW = bass_tokens()
KICK_ROW, SNARE_ROW, HAT_ROW = kick_tokens(), snare_tokens(), hat_tokens()

TRACKS = [
    ("旋律 正弦", MEL_ROW, 1),
    ("和声垫 三角", PAD_ROW, 1),
    ("贝斯 正弦", BASS_ROW, 1),
    ("底鼓 55Hz", KICK_ROW, KICK_BOOST),
    ("军鼓 196Hz", SNARE_ROW, SNARE_BOOST),
    ("踩镲 噪声", HAT_ROW, HAT_BOOST),
]


def beats(toks):
    return sum(float(t.split(":", 1)[1]) if ":" in t else 1.0 for t in toks)


def rows_of():
    """展开成真正的音轨列表（复制轨用于提增益）"""
    out = []
    for label, toks, boost in TRACKS:
        for k in range(boost):
            out.append((label if k == 0 else "%s x%d" % (label, k + 1), toks))
    return out


rows = rows_of()
for label, toks in rows:
    assert abs(beats(toks) - 64) < 1e-9, (label, beats(toks))

# ---- 注册音色 ----
REG = [("K", 55.00, 0, "底鼓 低频正弦"),
       ("S", 196.00, 1, "军鼓 中频三角"),
       ("H", 7000.00, 2, "踩镲 宽带噪声")]
for name in sorted(set(t[1:].split(":", 1)[0] for t in PAD_ROW if t.startswith("t"))):
    REG.append(("t" + name, freq_of(name), 1, "和声垫 三角波版本"))

L = []
L.append("@ 晚风>音.奏>列表即乐谱>1")
L.append("")
L.append("# 《晚风》 A 小调 / %d BPM / 16 小节 / 40 秒" % BPM)
L.append("# 列表即乐谱：每个元素是一条音轨，空格分隔 token，音符:时值(拍)，. 为休止")
L.append("GOING:{")
L.append("# ---- 注册音色：0正弦 / 1三角 / 2噪声 ----")
for name, f, w, why in REG:
    L.append("vg.丢 = 音.音(\"%s\", %.2f, %d)%s# %s" % (name, f, w, " " * max(1, 16 - len(name)), why))
L.append("")
L.append("# ---- 乐谱：每行一条音轨；重复行是加法混音的增益手段 ----")
L.append("vg.乐谱 = [")
for i, (label, toks) in enumerate(rows):
    tail = "," if i < len(rows) - 1 else ""
    L.append("    \"%s\"%s# %s" % (" ".join(toks), tail, label))
L.append("]")
L.append("")
L.append("vg.文件 = 音.奏(乐谱, \"%s\", %d)" % (WAV, BPM))
L.append("ns.show(已生成 $文件)")
L.append("}STOP")

out = os.path.join(ROOT, "_song.pybk")
with open(out, "w", encoding="utf-8") as f:
    f.write("\n".join(L) + "\n")

print("=== 《晚风》%d 条音轨 ===" % len(rows))
for label, toks in rows:
    print("  %-14s %3d 拍  %4d token  %5d 字符" % (label, beats(toks), len(toks), len(" ".join(toks))))
print("时长 %.1f 秒   源文件 %d 字节" % (64 * BEAT, os.path.getsize(out)))