# -*- coding: utf-8 -*-
"""PYbook 游戏库评测套件 —— 无头出图 + 退出码判定。

用法：
    python tools/评测_游戏库.py              # 跑全部
    python tools/评测_游戏库.py --shots      # 额外转 PNG 看画面

设计要点（踩坑记录）：
1. 3D 无头出图靠环境变量 PYBOOK_SHOT_DIR；不设就不出图。
2. 限帧必须用 `rm.aging.while(hw.end())` + 块内 `if(帧 > N) { 断 }`。
   `rm.aging.while` 是 repeat-until（条件为真才退出），写 `帧 < 20`
   会在第一帧就退出，表现为「帧数 0」但不报错。
3. `func` 必须写在 GOING 之前。
4. `hw.preset(槽位, 名字)` —— 槽位在前，这是最容易写反的一个。
5. 必须显式设 hw.fov / hw.near / hw.far / hw.fog / hw.camera，
   否则相机默认在原点，实物全在视野外，出一张纯黑图。
6. 2D 窗口没有无头开关，只有 3D(hw) 能 PYBOOK_SHOT_DIR；
   2D 零件改用 codegen 检查（看是否映射到 rt_game_*）。
"""
import glob
import os
import shutil
import subprocess
import sys
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
os.chdir(ROOT)
sys.stdout.reconfigure(encoding="utf-8", errors="replace")

HDR = ('@ ev>%s>1\n\nON 3D_highway\nGOING:{\n'
       'hw.open(640, 480, "ev")\nhw.fov(60)\nhw.near(0.1)\nhw.far(600)\n'
       'hw.fog(200, 500)\nhw.camera(0, 1.5, -7, 90, 0)\n'
       'hw.clearcolor(18, 20, 34)\nhw.light(0.35, 0.55, -0.75, 0.9)\n')
SETUP = ("vg.帧 = 0\nrm.aging.while(hw.end()) {\n"
         "    if(帧 > 20) {\n        断\n    }\n")
TAIL = "    帧 = 帧 + 1\n    hw.frame()\n}\nns.show(帧数 $帧)\n}STOP\n"

HW_CASES = {
    "几何图元": "    vg.丢 = hw.box(-2, 0, 0, 1, 1, 1, 220, 80, 70)\n"
                "    vg.丢 = hw.sphere(0, 0.5, 0, 0.5, 190, 200, 90)\n"
                "    vg.丢 = hw.cyl(2, 0, 0, 0.5, 1, 0.5, 12, 70, 130, 220)\n",
    "阴影贴图": "    hw.shadow(1)\n    hw.shadowres(2048)\n    hw.shadowarea(14)\n"
                "    vg.丢 = hw.box(-1.6, 0, 0, 1, 1, 1, 200, 80, 70)\n"
                "    vg.丢 = hw.box(1.6, 0, 0.5, 1, 1, 1, 70, 130, 220)\n",
    "GLSL着色器": "    if(帧 == 2) {\n        vg.好 = hw.preset(1, \"lambert\")\n    }\n"
                  "    if(帧 == 8) {\n        vg.好 = hw.preset(2, \"toon\")\n    }\n"
                  "    if(帧 == 14) {\n        vg.好 = hw.preset(3, \"checker\")\n    }\n"
                  "    vg.丢 = hw.box(-2, 0, 0, 1, 1, 1, 200, 90, 80)\n"
                  "    vg.丢 = hw.box(2, 0, 0, 1, 1, 1, 120, 150, 240)\n",
    "后处理": "    if(帧 == 2) {\n        hw.post(1)\n    }\n"
              "    vg.丢 = hw.box(-1.6, 0, 0, 1, 1, 1, 210, 90, 80)\n"
              "    vg.丢 = hw.box(2.2, 0, 0, 1, 1, 1, 100, 160, 240)\n",
    "变换栈": "    vg.丢 = hw.push(0, 0, 0, 0, 0, 0)\n"
             "    vg.丢 = hw.box(0, 0, 0, 1, 1, 1, 220, 120, 60)\n"
             "    vg.丢 = hw.pop()\n",
}

PERF_SRC = '''@ ev>perf>load>1

ON 3D_highway
func 跑(个数) {
    vg.帧 = 0
    vg.t0 = tm.now()
    rm.aging.while(hw.end()) {
        if(帧 > 59) {
            断
        }
        for i in np.range(0, 个数, 1) {
            vg.丢 = hw.box(i * 2 - 个数, 0, 0, 1, 1, 1, 180, 180, 190)
        }
        帧 = 帧 + 1
        hw.frame()
    }
    vg.花 = tm.now() - t0
    ns.show(个数 $个数  六十帧毫秒 $花)
    ret 0
}
GOING:{
hw.open(640, 480, "perf")
hw.fov(60)
hw.near(0.1)
hw.far(600)
hw.fog(200, 500)
hw.camera(0, 1.5, -7, 90, 0)
hw.clearcolor(18, 20, 34)
跑(%d)
}STOP
'''

GAME_CASES = {
    "查断言": "chk",
    "smoke体检": "smoke",
    "dirkeys": "dk",
}

GAME_SRC = {
    "查断言": '''@ ev>test>assert>1

GOING:{
vg.甲 = 3
vg.乙 = 4
查(甲 + 乙 == 7, "加法")
查(甲 * 乙 == 12, "乘法")
查(true, "恒真")
查(甲 < 乙, "比较")
ns.show(断言全部通过)
}STOP
''',
    "smoke体检": '''@ ev>smoke>health>1

GOING:{
vg.模式 = smoke.mode()
vg.堆 = smoke.heap()
vg.根 = smoke.roots()
vg.内存 = smoke.mem()
vg.泄漏 = smoke.leak()
vg.错误 = smoke.errors()
vg.期望 = smoke.expect(1, 1)
vg.必须 = smoke.require(2, 2)
ns.show(模式 $模式  堆 $堆  根 $根  内存 $内存  泄漏 $泄漏  错误 $错误)
}STOP
''',
    "dirkeys": '''@ ev>input>dirkeys>1

GOING:{
vg.方向 = dirkeys()
vg.个数 = 长度(方向)
ns.show(dirkeys 长度 $个数)
查(个数 == 2, "dirkeys 应返回 2 元素列表")
}STOP
''',
}


def run(path, shot_dir=None, timeout=300):
    env = dict(os.environ)
    env.update({"PYBOOK_NO_CACHE": "1", "PYTHONIOENCODING": "utf-8"})
    if shot_dir:
        shutil.rmtree(shot_dir, ignore_errors=True)
        env.update({"PYBOOK_SHOT_DIR": shot_dir,
                    "PYBOOK_SHOT_EVERY": "10", "PYBOOK_SHOT_MAX": "2"})
    t0 = time.perf_counter()
    try:
        p = subprocess.run([sys.executable, "-B", "pybk_main.py", path],
                           capture_output=True, text=True, encoding="utf-8",
                           errors="replace", env=env, cwd=ROOT, timeout=timeout)
        out = (p.stdout or "") + (p.stderr or "")
        rc = p.returncode
    except subprocess.TimeoutExpired:
        out, rc = "TIMEOUT", -9
    dt = time.perf_counter() - t0
    lines = [l.strip() for l in out.strip().split("\n") if l.strip()
             and not l.startswith("[shot]")]
    info = (lines[-1] if (rc == 0 and lines)
            else (lines[0] if lines else "(无输出)"))
    return rc, dt, info


def main():
    print("=" * 66)
    print("PYbook 游戏库评测 —— 无头出图 + 退出码")
    print("=" * 66)

    print("\n[A] hw.* 渲染能力（3D 无头出图）")
    print("-" * 66)
    ok = 0
    for name, body in HW_CASES.items():
        path = os.path.join(ROOT, "_evhw.pybk")
        with open(path, "w", encoding="utf-8") as f:
            f.write((HDR % name) + SETUP + body + TAIL)
        shot = os.path.join(ROOT, "_evshots_hw")
        rc, dt, info = run(path, shot)
        shots = len(glob.glob(shot + r"\*.bmp"))
        tag = "OK  " if rc == 0 else "FAIL"
        ok += (rc == 0)
        print("  %s %-12s %5.2fs  出图%d  %s" % (tag, name, dt, shots, info[:60]))
    print("  -> %d/%d 通过" % (ok, len(HW_CASES)))

    print("\n[B] 帧率分档（60 帧/档）")
    print("-" * 66)
    print("  %-10s %-10s %-12s %s" % ("盒数", "60帧ms", "每帧ms", "折算FPS"))
    for n in (500, 4000, 16000):
        path = os.path.join(ROOT, "_evperf.pybk")
        with open(path, "w", encoding="utf-8") as f:
            f.write(PERF_SRC % n)
        rc, dt, info = run(path)
        if rc != 0:
            print("  %-10d FAIL %s" % (n, info[:50]))
            continue
        try:
            ms = int(info.split()[-1])
            per = ms / 60.0
            print("  %-10d %-10d %-12.2f %.0f" % (n, ms, per, 1000.0 / per))
        except Exception:
            print("  %-10d 解析失败: %s" % (n, info[:50]))

    print("\n[C] 2D 游戏零件 / smoke / 断言")
    print("-" * 66)
    for name, key in GAME_CASES.items():
        path = os.path.join(ROOT, "_evg.pybk")
        with open(path, "w", encoding="utf-8") as f:
            f.write(GAME_SRC[name])
        rc, dt, info = run(path, timeout=120)
        tag = "OK  " if rc == 0 else "FAIL"
        print("  %s %-12s %5.2fs  %s" % (tag, name, dt, info[:62]))

    if "--shots" in sys.argv:
        print("\n[D] 转 PNG")
        code = ("from PIL import Image\nimport glob\n"
                "n=0\nfor f in glob.glob('_evshots_hw/*.bmp'):\n"
                "    Image.open(f).convert('RGB').save(f[:-4]+'.png'); n+=1\n"
                "print('converted', n)\n")
        with open(os.path.join(ROOT, "_evpng.py"), "w", encoding="utf-8") as f:
            f.write(code)
        subprocess.run([sys.executable, "-B", "_evpng.py"], cwd=ROOT)


if __name__ == "__main__":
    main()
