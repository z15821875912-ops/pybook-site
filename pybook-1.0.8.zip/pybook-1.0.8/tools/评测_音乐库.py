# -*- coding: utf-8 -*-
'''音乐库（音.*）评测套件。

核心手法：在 Python 里逐样本复刻 pybook_music.c 的 mu_raster
（float32 累加顺序、噪声 LCG、0.7/peak 全局归一、(short) 截断），
与 C 实际输出逐位比对 —— 先证明「复刻 == 实现」，
后续所有单轨分析（音高、节奏、逐音符频率）才可信。

依次检查：
  1. WAV 头字段与时长
  2. 逐样本复刻一致性
  3. 峰值 / 削波 / 直流
  4. 分频段能量 vs 设计目标
  5. 乐谱里声明的音高是否真的出现在频谱
  6. 底鼓/军鼓/踩镲的节奏点，以及旋律逐音符的主导频率
'''
# -*- coding: utf-8 -*-
"""校验《晚风》：WAV 合法性 + 逐样本复刻 mu_raster + 分频段分析。

思路：不只验「文件能打开」，而是在 Python 里逐样本复刻 pybook_music.c 的
mu_raster（含 float32 累加、0.7/peak 归一、(short) 截断），
与 C 实际输出比对：
  - 若逐位吻合 -> 说明我对引擎的理解完全正确，可以放心做单轨分析
  - 若不吻合   -> 差在哪一段，比笼统的「听起来对不对」有信息量得多
吻合之后，再拆开看每条音轨各自的频谱与节奏。
"""
import sys, os, array, math
import numpy as np

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
ROOT = r"C:\Users\zhuli\Desktop\pybook"
os.chdir(ROOT)
SR = 44100
BPM = 96
TAU = 2.0 * math.pi


def read_wav(p):
    raw = open(p, "rb").read()
    assert raw[0:4] == b"RIFF" and raw[8:12] == b"WAVE", "RIFF/WAVE 头损坏"
    assert raw[12:16] == b"fmt " and raw[36:40] == b"data", "fmt/data 块缺失"
    fmt_len = int.from_bytes(raw[16:20], "little")
    ch = int.from_bytes(raw[22:24], "little")
    sr = int.from_bytes(raw[24:28], "little")
    bits = int.from_bytes(raw[34:36], "little")
    dlen = int.from_bytes(raw[40:44], "little")
    riff = int.from_bytes(raw[4:8], "little")
    a = np.frombuffer(raw[44:44 + dlen], dtype="<i2").astype(np.int32)
    return dict(raw=raw, riff=riff, fmt_len=fmt_len, ch=ch, sr=sr, bits=bits,
                dlen=dlen, pcm=a, size=len(raw))


SEMI = {"C": 0, "D": 2, "E": 4, "F": 5, "G": 7, "A": 9, "B": 11}
CUSTOM = {}


def parse(tok):
    """复刻 mu_parse_note：自定义优先，其次科学音名"""
    if tok in CUSTOM:
        return CUSTOM[tok]
    letter = tok[0]
    semi = SEMI[letter]
    p = 1
    if len(tok) > 1 and tok[1] == "#":
        semi += 1; p = 2
    elif len(tok) > 1 and tok[1] == "b":
        semi -= 1; p = 2
    octv = int(tok[p:])
    midi = (octv + 1) * 12 + semi
    return 440.0 * 2.0 ** ((midi - 69) / 12.0), 0


def raster(rows, beat_ms):
    """逐样本复刻 mu_raster（float32 累加）"""
    spb = beat_ms / 1000.0 * SR
    beats = []
    for row in rows:
        b = 0.0
        for tok in row.split(" "):
            if not tok:
                continue
            if ":" in tok:
                b += max(float(tok.split(":", 1)[1]), 1e-9)
            else:
                b += 1.0
        beats.append(b)
    total = int(max(beats) * spb) + 1
    mix = np.zeros(total, dtype=np.float32)
    for row in rows:
        cursor = 0.0
        for tok in row.split(" "):
            if not tok:
                continue
            dur = 1.0
            if ":" in tok:
                n, d = tok.split(":", 1)
                tok = n
                dur = float(d)
                if dur <= 0:
                    dur = 1.0
            if tok in (".", "_", "r", "R"):
                cursor += dur * spb
                continue
            fr, wv = parse(tok)
            ns = int(dur * spb)
            idx = np.arange(cursor, cursor + ns)
            idx = idx[idx < total].astype(np.int64)
            if len(idx) == 0:
                cursor += dur * spb
                continue
            k = np.arange(len(idx))
            ph = TAU * fr * ((cursor + k)) / SR
            if wv == 1:
                v = (2.0 / TAU) * np.arcsin(np.sin(ph))
            elif wv == 2:
                seed = (np.uint32(fr * 977 + k * 31 + wv * 7).astype(np.uint64))
                seed = ((seed * np.uint64(1664525)) + np.uint64(1013904223)).astype(np.uint32)
                v = (((seed >> 8) & 0xFFFF).astype(np.float64) / 32768.0) - 1.0
            else:
                v = np.sin(ph)
            np.add.at(mix, idx, v.astype(np.float32))
            cursor += dur * spb
    return mix


def normalize(mix):
    peak = np.abs(mix).max()
    g = np.float32(0.7) / np.float32(peak) if peak > 0 else np.float32(0)
    v = (mix * g).astype(np.float32)
    v = np.clip(v, -1.0, 1.0)
    return np.trunc(v * np.float32(32767.0)).astype(np.int16)


def hz_of(name):
    letter = name[0]
    p = 1
    semi = SEMI[letter]
    if len(name) > 1 and name[1] == "#":
        semi += 1; p = 2
    elif len(name) > 1 and name[1] == "b":
        semi -= 1; p = 2
    midi = (int(name[p:]) + 1) * 12 + semi
    return 440.0 * 2.0 ** ((midi - 69) / 12.0)



import re

WAVF = "晚风.wav"
BPM = 96
SPB = 60.0 / BPM          # 一拍秒数
BEAT_MS = 60000.0 / BPM

src = open("晚风.pybk", encoding="utf-8").read()
rows = re.findall(r'"([^"]*)"', re.search(r"vg\.乐谱 = \[(.*?)\]", src, re.S).group(1))
for name, f, w in re.findall(r'音\.音\("([^"]+)",\s*([\d.]+),\s*(\d)\)', src):
    CUSTOM[name] = (float(f), int(w))
labels = re.findall(r'"[^"]*"\s*,?\s*#\s*(.+)$', src, re.M)
print("乐谱 %d 条音轨；音色 %d 个" % (len(rows), len(CUSTOM)))

ok = True


def chk(cond, msg):
    global ok
    ok = ok and bool(cond)
    print("  [%s] %s" % ("OK" if cond else "!!", msg))


# ---------- 1 + 2 + 3 ----------
info = read_wav(WAVF)
print("\n=== 1. WAV 头 ===")
print("  大小 %d 字节" % info["size"])
chk(info["raw"][0:4] == b"RIFF" and info["raw"][8:12] == b"WAVE", "RIFF/WAVE 签名正确")
chk(info["raw"][12:16] == b"fmt " and info["raw"][36:40] == b"data", "fmt / data 块齐全")
chk(info["riff"] == info["dlen"] + 36, "RIFF 长度字段自洽 (%d = data %d + 36)" % (info["riff"], info["dlen"]))
chk(info["riff"] + 8 == info["size"], "RIFF 长度 + 8 == 实际文件大小")
chk(info["ch"] == 1 and info["bits"] == 16 and info["sr"] == 44100, "单声道 / 16bit / 44100Hz")
dur = len(info["pcm"]) / info["sr"]
print("  帧数 %d  时长 %.3f 秒（设计 40.000）" % (len(info["pcm"]), dur))
chk(abs(dur - 40.0) < 0.001, "时长 40.000 秒")

print("\n=== 2. 逐样本复刻（Python mu_raster vs C 输出）===")
mine = normalize(raster(rows, BEAT_MS))
n = min(len(mine), len(info["pcm"]))
diff = np.abs(mine[:n].astype(np.int64) - info["pcm"][:n].astype(np.int64))
print("  比对样本 %d 个，最大绝对差 %d，完全相同 %d 个" % (n, diff.max(), int((diff == 0).sum())))
chk(len(mine) == len(info["pcm"]) and diff.max() == 0, "1764001 个样本逐位一致 —— 渲染结果 == 乐谱声明")

print("\n=== 3. 幅度 ===")
peak = int(np.abs(info["pcm"]).max())
rms = float(np.sqrt((info["pcm"].astype(np.float64) ** 2).mean()))
clip = int((np.abs(info["pcm"]) >= 32700).sum())
dc = float(info["pcm"].mean())
print("  峰值 %d (%.1f%%)   RMS %.0f (%.1f%%)   削波 %d   直流 %.2f" %
      (peak, 100 * peak / 32767, rms, 100 * rms / 32767, clip, dc))
chk(peak == 22936, "峰值 22936 = 70.0%（rt_mu_away 的 0.7/peak 归一生效）")
chk(clip == 0, "无削波")
chk(abs(dc) < 50, "直流偏移可忽略")

# ---------- 4. 分频段平衡 ----------
print("\n=== 4. 分频段能量 vs 设计目标 ===")
x = info["pcm"].astype(np.float64) / 32767.0
X = np.abs(np.fft.rfft(x)) ** 2
fq = np.fft.rfftfreq(len(x), 1.0 / SR)
tot = X.sum()
TARGET = [("贝斯 20-110", 20, 110, 27, 34), ("低中 110-300", 110, 300, 14, 20),
          ("中频 300-1k", 300, 1000, 26, 36), ("泛音 1k-4k", 1000, 4000, 10, 17),
          ("踩镲 >4k", 4000, 20000, 6, 11)]
for lab, lo, hi, tlo, thi in TARGET:
    v = 100 * X[(fq >= lo) & (fq < hi)].sum() / tot
    print("  %-14s %6.2f%%   目标 %d~%d%%  %s" % (lab, v, tlo, thi, "OK" if tlo <= v <= thi else "!!"))
    chk(tlo <= v <= thi, "%s 落在目标区间" % lab)

# ---------- 5. 音高集合 ----------
print("\n=== 5. 乐谱音高 -> 实际频谱 ===")
# 有音高的音色：注册频率应当真的出现一条谱线。
# 噪声波（wave==2）例外：mu_raster 里 fr 只当 LCG 的种子，压根不产生 7000Hz 谱线，
# 它是宽带能量 —— 所以踩镲只验频段能量，不验谱线。
tonal, noisy = set(), set()
for r in rows:
    for tok in r.split(" "):
        if not tok:
            continue
        nm = tok.split(":")[0]
        if nm in (".", "_", "r"):
            continue
        if nm in CUSTOM:
            (noisy if CUSTOM[nm][1] == 2 else tonal).add(CUSTOM[nm][0])
        else:
            tonal.add(parse(nm)[0])
tonal, noisy = sorted(tonal), sorted(noisy)
W = 1 << 17
acc = np.zeros(W // 2 + 1)
wins = 0
for s in range(0, len(x) - W, W // 3):
    acc += np.abs(np.fft.rfft(x[s:s + W] * np.hanning(W))) ** 2
    wins += 1
acc /= wins
fw = np.fft.rfftfreq(W, 1.0 / SR)
binw = SR / W
missing = []
for f in tonal:
    k = int(round(f / binw))
    rel = acc[max(0, k - 3):k + 4].max() / acc.max()
    if rel <= 2e-5:
        missing.append(f)
    print("  %8.2f Hz  相对 %6.1f dB  %s" % (f, 10 * math.log10(rel + 1e-30), "OK" if rel > 2e-5 else "!!"))
print("  噪声乐器 %d 个（频率仅作种子，不产生谱线）：%s" % (len(noisy), ", ".join("%.0f Hz" % f for f in noisy)))
hf = 100 * X[(fq >= 4000)].sum() / tot
print("  >4kHz 宽带能量 %.2f%%（踩镲的实际存在形式）%s" % (hf, "OK" if hf > 4 else "!!"))
chk(not missing, "乐谱里 %d 个有音高的音全部出现在频谱中" % len(tonal))
chk(hf > 4, "踩镲宽带能量存在")

# ---------- 6. 节奏点 ----------
print("\n=== 6. 节奏核对 ===")


def track_sig(idxs):
    T = np.zeros(len(x))
    for i in idxs:
        a = np.asarray(raster([rows[i]], BEAT_MS), dtype=np.float64)
        T[:len(a)] += a
    return T


def onsets(T):
    hop = int(SR * 0.002); win = int(SR * 0.015)
    e = np.sqrt(np.convolve(T * T, np.ones(win) / win, mode="same"))[::hop]
    base, top = np.percentile(e, 15), np.percentile(e, 99.5)
    thr = base + 0.30 * (top - base)
    res = []
    for i in range(2, len(e) - 2):
        if e[i] > thr and e[i] == max(e[i - 2:i + 3]):
            t = i * hop / SR
            if not res or t - res[-1] > 0.08:
                res.append(t)
    return res


# 轨序：0旋律 1垫 2贝斯 3底鼓 4底鼓x2 5军鼓 6军鼓x2 7镲 8镲x2 9镲x3
kick = onsets(track_sig([3, 4]))
snare = onsets(track_sig([5, 6]))
hat = onsets(track_sig([7, 8, 9]))
kb = np.array(kick) * BPM / 60
sb = np.array(snare) * BPM / 60
hb = np.array(hat) * BPM / 60
print("  底鼓  %3d 下（理论 32）  落在 1、3 拍 %s" %
      (len(kick), "100%" if np.mean(np.abs(kb % 2.0) < 0.03) > 0.95 else "!!"))
print("  军鼓  %3d 下（理论 32）  落在 2、4 拍 %s" %
      (len(snare), "100%" if np.mean(np.abs((sb % 2.0) - 1.0) < 0.03) > 0.95 else "!!"))
print("  踩镲  %3d 下（理论 128） 落在八分音符网格 %s" %
      (len(hat), "100%" if np.mean(np.abs(hb % 0.5) < 0.03) > 0.95 else "!!"))
chk(len(kick) == 32 and np.mean(np.abs(kb % 2.0) < 0.03) > 0.95, "底鼓 32 下且全在 1、3 拍")
chk(len(snare) == 32 and np.mean(np.abs((sb % 2.0) - 1.0) < 0.03) > 0.95, "军鼓 32 下且全在 2、4 拍")
chk(len(hat) == 128 and np.mean(np.abs(hb % 0.5) < 0.03) > 0.95, "踩镲 128 下且全在八分音符网格")

# 旋律不用起音检测（恒幅延音没有攻击点，检测必出假阳性），
# 改为「每个音符的中段，主导频率是否等于该音符的音高」
print("\n  --- 旋律：逐音符核对主导频率 ---")
mel_sig = track_sig([0])
want = []
pos = 0.0
for tok in rows[0].split(" "):
    if not tok:
        continue
    nm = tok.split(":", 1)[0]
    dur = float(tok.split(":", 1)[1]) if ":" in tok else 1.0
    if nm != ".":
        want.append((pos, dur, parse(nm)[0]))
    pos += dur
print("  乐谱写入 %d 个音符" % len(want))
bad = []
for (b, d, f) in want:
    t0 = (b + 0.28 * d) * SPB
    t1 = (b + 0.72 * d) * SPB
    seg = mel_sig[int(t0 * SR):int(t1 * SR)]
    if len(seg) < 1024:
        bad.append((b, f, 0)); continue
    n = 1 << 15
    if len(seg) < n:
        seg = np.pad(seg, (0, n - len(seg)))
    S = np.abs(np.fft.rfft(seg[:n] * np.hanning(n))) ** 2
    fr_ = np.fft.rfftfreq(n, 1.0 / SR)
    m = (fr_ >= 250) & (fr_ <= 900)
    got = fr_[m][int(np.argmax(S[m]))]
    err = 1200 * math.log2(got / f) if f > 0 else 9999
    if abs(err) > 25:
        bad.append((b, f, got))
    print("    拍 %5.1f  时值 %.1f  期望 %7.2f Hz  实测 %7.2f Hz  偏差 %+5.1f 音分  %s"
          % (b, d, f, got, err, "OK" if abs(err) <= 25 else "!!"))
chk(not bad, "旋律 %d 个音符的主导频率全部正确（偏差 <= 25 音分）" % len(want))

print("\n=== 结论：%s ===" % ("全部通过 ✅" if ok else "有未通过项 ⚠"))