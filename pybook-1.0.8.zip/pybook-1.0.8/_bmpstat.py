# -*- coding: utf-8 -*-
"""BMP 像素体检：判断「引擎真画东西了」还是「一整张纯背景」。

之前踩过的坑：把**空帧**的截图当成「渲染失败」去查三轮。空帧本来就该是
纯背景色，光看「颜色数=1」什么都证明不了。所以这里必须同时报：

  颜色数       —— 一共有多少种不同颜色（纯色图 = 1）
  非背景像素   —— 扣除四角众数后，剩下多少像素
  内容包围盒   —— 东西画在画面哪一块（居中/贴边/角落）
  逐行覆盖     —— 有内容的行数，用来区分「一条线」和「一坨实体」

用法： python -B _bmpstat.py shots_test/fx_000.bmp [更多文件...]
"""
import struct
import sys
from collections import Counter


def load_bmp(path):
    with open(path, "rb") as f:
        data = f.read()
    if data[:2] != b"BM":
        raise SystemExit("%s 不是 BMP" % path)
    off = struct.unpack_from("<I", data, 10)[0]
    hdr = struct.unpack_from("<I", data, 14)[0]
    w, h = struct.unpack_from("<ii", data, 18)
    bpp = struct.unpack_from("<H", data, 28)[0]
    comp = struct.unpack_from("<I", data, 30)[0]
    if hdr < 40 or bpp not in (24, 32) or comp != 0:
        raise SystemExit("%s 不支持：BMP头=%d bpp=%d 压缩=%d" % (path, hdr, bpp, comp))
    top_down = h < 0
    h = abs(h)
    step = bpp // 8
    row_raw = w * step
    row_pad = (4 - row_raw % 4) % 4

    rows = []
    for y in range(h):
        sy = y if top_down else (h - 1 - y)   # 统一成「屏幕坐标向上」
        base = off + sy * (row_raw + row_pad)
        line = []
        for x in range(w):
            p = base + x * step
            b, g, r = data[p], data[p + 1], data[p + 2]
            line.append((r, g, b))
        rows.append(line)
    return w, h, rows


def report(path):
    w, h, rows = load_bmp(path)
    flat = [px for line in rows for px in line]
    cnt = Counter(flat)
    bg, bg_n = cnt.most_common(1)[0]

    xs, ys = [], []
    for y in range(h):
        for x in range(w):
            if rows[y][x] != bg:
                xs.append(x)
                ys.append(y)
    ink = len(xs)

    print("== %s  %dx%d  共 %d 像素" % (path, w, h, w * h))
    print("   不同颜色数 = %d" % len(cnt))
    print("   背景(众数) = (%d,%d,%d)  占 %.2f%%" % (bg[0], bg[1], bg[2], 100.0 * bg_n / len(flat)))
    print("   非背景像素 = %d  (%.3f%%)" % (ink, 100.0 * ink / len(flat)))
    if ink == 0:
        print("   >>> 纯背景，一帧都没画东西进去\n")
        return False

    x0, x1, y0, y1 = min(xs), max(xs), min(ys), max(ys)
    print("   内容包围盒 = x[%d..%d] y[%d..%d]  宽%d 高%d" % (x0, x1, y0, y1, x1 - x0 + 1, y1 - y0 + 1))
    print("   画面占比   = 宽 %.1f%% 高 %.1f%%" % (100.0 * (x1 - x0 + 1) / w, 100.0 * (y1 - y0 + 1) / h))

    row_ink = [sum(1 for x in range(w) if rows[y][x] != bg) for y in range(h)]
    hit_rows = sum(1 for n in row_ink if n)
    print("   有内容的行 = %d/%d" % (hit_rows, h))
    print("   最密的前 5 行像素数 = %s" % sorted(row_ink, reverse=True)[:5])

    print("   前 8 大颜色 = %s" % [("%s x%d" % (str(c), n)) for c, n in cnt.most_common(8)])
    print()
    return True


if __name__ == "__main__":
    if len(sys.argv) < 2:
        raise SystemExit(__doc__)
    ok = [report(p) for p in sys.argv[1:]]
    raise SystemExit(0 if all(ok) else 1)
