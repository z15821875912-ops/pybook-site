# -*- coding: utf-8 -*-
"""把 Francis 步内部的 P 显式构造出来，对拍三件事：
   1) P 是不是真的正交
   2) la_francis 应用完的 t 是不是就等于 P·T·P
   3) q 累积是不是就等于 Q·P
差在哪一项，就是 bug 在哪。

用法：python -B _eiginner.py
"""
import numpy as np
import _eigref as R

np.set_printoptions(precision=8, suppress=False, linewidth=200)

A = np.array([
    [0.104849, 0.33491, 0.700101],
    [-0.149776, 0.629897, 0.941049],
    [0.195691, -0.555375, -0.961234],
])
n = 3
t0, q0 = R.hessenberg(A)
print("Hessenberg 后 ‖A − QHQᵀ‖ =", np.abs(A - q0 @ t0 @ q0.T).max())
print("T =\n", t0)

l, u = 0, 2
s = u - l + 1
a, b, c, d = t0[u - 1, u - 1], t0[u - 1, u], t0[u, u - 1], t0[u, u]
p = a + d
qq = a * d - b * c
print("\n移位 p=%g  q=%g" % (p, qq))

m = t0[l:l + s, l:l + s]
col = m[:, 0].copy()
col2 = m @ col - p * col
col2[0] += qq
print("x =", col2)

xn = np.linalg.norm(col2[1:])
alpha = -xn if col2[0] > 0 else xn
v = col2.copy()
v[0] -= alpha
beta = 2.0 / (v @ v)
print("v =", v, " beta =", beta)

vv = np.zeros(n)
vv[0:s] = v
P = np.eye(n) - beta * np.outer(vv, vv)
print("\n‖PᵀP − I‖ =", np.abs(P.T @ P - np.eye(n)).max())
print("det(P) =", np.linalg.det(P))
print("P =\n", P)

PTP = P @ t0 @ P
print("\n(P·T·P)[2,0] =", PTP[2, 0], "   ← 隐式 Q 定理说这里应该≈0")
print("P·T·P =\n", PTP)

t1, q1 = t0.copy(), q0.copy()
R.francis(t1, q1, n, l, u)
print("\nfrancis 应用完的 T =\n", t1)
print("‖t1 − P·T·P‖ =", np.abs(t1 - PTP).max())
print("‖q1 − Q·P‖   =", np.abs(q1 - q0 @ P).max())
print("‖A − q1·t1·q1ᵀ‖ =", np.abs(A - q1 @ t1 @ q1.T).max())