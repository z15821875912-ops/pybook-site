"""PYbook 字节码编译后端：pybk_front.parse() 的 AST -> .pybc 字节码。

只编译，不运行：虚拟机是同事的 C 代码。不修改 pybk_front.py。
仅用 Python 标准库。

对合同中未定死语义的两处约定（VM 同事请对齐）：
- MAGIC u16：操作数是 magic 参数串（逗号连接，如 'b,c=0,200,255'）的常量池索引。
- 函数表里的代码偏移：相对代码区起点（不是相对文件头）。

已知边界：前端文法没有列表字面量和 lock/del 语句，所以 LIST_NEW 一族
（规则9）与 GOLD/DEL 指令经 parse() 不可达；这里仍完整支持指令编码与反汇编。
样例中的 vg_ro / [1,2,3] 前端无法解析，自测用了等价的合法写法（见文件尾）。

另外，游戏调用（win/key/hit/...）与 ffi.*/c.* 底层窗口接口需要窗口或编译期展开成 C，
VM（终端模式）不支持——编译期会给出明确提示「仅 C 后端可用」，而非误报。
"""

import struct
import dataclasses
import os

from pybk_front import (
    parse, PybkError, expand_macros,
    Program, FnDef, NumLit, StrLit, BoolLit, VarRef, BinOp, Unary, Call, Ternary, Comp,
    InputExpr, Ret, VgAssign, IpAssign, NsShow, Around, Aging, CdBlock, Lambda,
    VcChain, ListLit, DictLit, SetLit, Index, AssignIndex, GoldDel, MemoryMode, DeviceMode, JitMode, HmStmt,
    NumLit,
    ForIn, HmDraw, HmLive, HmFrame, HmPlay, GoStmt, WhileStmt, BreakStmt, ContinueStmt,
    TryCatch, OnError, Throw,
    LIB_PREFIXES,
    LIB_CALLS,
    GAME_CALLS,
)

MAGIC = b'PYBC'
VERSION = 1

# 常量池类型：1=int64 2=float64 3=字符串 4=空（none）
T_INT, T_FLOAT, T_STR, T_NONE = 1, 2, 3, 4

# ---- 指令表：opcode -> (助记符, 操作数规格串) ----
# 规格：'' 无操作数；'U' u16；'B' u8；'I' i32
OPS = {
    0x00: ('NOP', ''),
    0x01: ('HALT', ''),
    0x02: ('CONST', 'U'),
    0x03: ('LOAD', 'U'),
    0x04: ('STORE', 'U'),
    0x05: ('DUP', ''),
    0x06: ('POP', ''),
    0x10: ('ADD', ''), 0x11: ('SUB', ''), 0x12: ('MUL', ''),
    0x13: ('DIV', ''), 0x14: ('FDIV', ''), 0x15: ('MOD', ''),
    0x16: ('NEG', ''), 0x17: ('NOT', ''),
    0x18: ('EQ', ''), 0x19: ('NE', ''), 0x1A: ('LT', ''),
    0x1B: ('GT', ''), 0x1C: ('LE', ''), 0x1D: ('GE', ''),
    0x1E: ('JUMP', 'I'),
    0x1F: ('JUMP_IF_FALSE', 'I'),
    0x20: ('JUMP_IF_TRUE', 'I'),
    0x21: ('SHOW_TEXT', 'U'),
    0x22: ('SHOW_VALUE', ''),
    0x23: ('MAGIC', 'U'),
    0x24: ('SHOW_END', ''),
    0x25: ('LIST_NEW', ''),
    0x26: ('LIST_APPEND', ''),
    0x27: ('LEN', ''),
    0x28: ('INDEX', ''),
    0x29: ('SETIDX', ''),
    0x2A: ('INPUT', 'U'),
    0x2B: ('AROUND_INIT', 'UU'),
    0x2C: ('AROUND_STEP', 'UUI'),
    0x2D: ('DICT_NEW', ''),
    0x2E: ('DICT_SET', ''),
    0x30: ('CALL', 'UB'),
    0x40: ('CALL_LIB', 'UB'),
    0x41: ('DUP', ''),
    0x42: ('DICT_NEW', ''),
    0x31: ('RET', ''),
    0x32: ('RET_NONE', ''),
    0x33: ('GOLD', 'U'),
    0x34: ('DEL', 'U'),
    0x35: ('SETMEM', 'B'),
    0x36: ('CALL_LIB', 'UB'),   # 库名常量索引 u16 + 实参个数 u8
    0x37: ('DEVICE', 'BU'),    # 文件头 device 旋钮：后端 u8(0auto/1cpu) + 工作线程数 u16（0=按机器核数）
    0x38: ('JIT', 'BU'),       # 文件头 jit 旋钮：开/关 u8 + 热阈 u16（0=用默认 16）
    0x39: ('CALL_DYN', 'B'),   # 动态调用：栈 [...,函数值,实参...] → 函数值是名字符串（lambda 值）
    # ---- 异常（任务2）----
    # TRY_BEGIN IIUUU：catch 落点(相对 i32) / 类型不符落点(相对 i32) / 类型过滤常量(u16) / e 槽(u16) / t 槽(u16)
    0x3A: ('TRY_BEGIN', 'IIUUU'),
    0x3B: ('TRY_POP', ''),     # 正常走完：弹掉这一层 try
    0x3C: ('TRY_HANDLER', 'I'),# catch 块体开始：再登记一层（块体里出错 → 跳本指令的落点）
    0x3D: ('THROW', ''),       # 弹栈顶两个值（类型、消息）→ 抛错
    0x3E: ('THROW_RETHROW', ''), # 重抛当前错误（catch 里裸 throw）
    0x3F: ('ERR_TYPE', ''),     # 压当前错误类型（内置 错误类型()）
    0x40: ('LINE', 'U'),        # 设当前行号（运行时报错带「第 N 行:」，与 C 后端一致）
}

_BINOP = {'+': 0x10, '-': 0x11, '*': 0x12, '/': 0x13,
          '//': 0x14, '%': 0x15,
          '==': 0x18, '!=': 0x19, '<': 0x1A, '>': 0x1B,
          '<=': 0x1C, '>=': 0x1D}

INT64_MIN, INT64_MAX = -2 ** 63, 2 ** 63 - 1


class CompileError(Exception):
    """编译期语义错误，信息带行号。"""


def _chk_u16(v, what, line):
    if not 0 <= v <= 0xFFFF:
        raise CompileError(f"第 {line} 行：{what} 超出 u16 范围：{v}")
    return v


def _chk_u8(v, what, line):
    if not 0 <= v <= 0xFF:
        raise CompileError(f"第 {line} 行：{what} 超出 u8 范围：{v}")
    return v


def _walk_lams(node, out):
    """递归走 AST 收集 Lambda 节点并按先序编号（node.n = 1,2,3...）。

    与 C 后端 pybk_code._mec_walk_lams 同一套编号规则：同一个程序在两个后端
    编译出来的 lambda 函数名必须一样（__mec_lam_N），否则「同名不同义」很难查。"""
    if isinstance(node, Lambda):
        node.n = len(out) + 1
        out.append(node)
    if isinstance(node, (list, tuple)):
        for x in node:
            _walk_lams(x, out)
    elif isinstance(node, dict):
        for x in node.values():
            _walk_lams(x, out)
    elif node is not None and hasattr(node, '__dataclass_fields__'):
        for k in node.__dataclass_fields__:
            _walk_lams(getattr(node, k, None), out)


# ---------------------------------------------------------------- 函数代码生成

class _FnGen:
    def __init__(self, comp, name, params):
        self.comp = comp                  # 取常量池用
        self.name = name
        self.params = list(params)
        self.slots = {}                   # 变量名 -> 槽号
        self.nslot = 0                    # 单调槽计数器：同名再分配（如循环复用变量名）
        for p in self.params:             # 不会让 len(slots) 增长，槽号必须走计数器
            self.slots[p] = self.nslot
            self.nslot += 1
        self.loops = []                   # 内层在尾：每层 around 的 at 槽号
        self.loopstack = []               # 循环上下文栈：break/continue 的跳转目标在这里登记
        self.buf = bytearray()
        self.fixups = []                  # (操作数在 buf 中的偏移, 目标 label)
        self.wide_fixups = []             # (操作数在 buf 中的偏移, 目标 label, 相对基址)

    # ---- 槽位 ----

    def new_slot(self, name):
        if self.nslot >= 0x10000:
            raise CompileError(f"函数 {self.name!r}：槽位数超过 u16 上限")
        s = self.nslot
        self.nslot += 1
        self.slots[name] = s
        return s

    def resolve(self, name, line):
        fv = getattr(self, 'forvars', [])
        for vname, slot in reversed(fv):  # 最内层 for-in 变量遮蔽外层同名
            if vname == name:
                return slot
        if name == 'at' and self.loops:   # 最内层 around 的 at 遮蔽同名变量
            return self.loops[-1]
        if name in self.slots:
            return self.slots[name]
        raise CompileError(f"第 {line} 行：未声明的变量 {name!r}")

    # ---- 发射 ----

    def here(self):
        return len(self.buf)

    def emit(self, op, spec=''):
        self.buf.append(op)
        for ch in spec:
            if ch == 'U':
                self.buf += b'\x00\x00'
            elif ch == 'I':
                self.buf += b'\x00\x00\x00\x00'
            elif ch == 'B':
                self.buf.append(0)

    def set_u16(self, op_pos, operand_pos, v, line):
        _chk_u16(v, '操作数', line)
        struct.pack_into('<H', self.buf, op_pos + operand_pos, v)

    def jump(self, op):
        """发射跳转（偏移占位），返回 fixup 句柄。"""
        pos = len(self.buf)
        self.emit(op, 'I')
        self.fixups.append([pos + 1, None])
        return len(self.fixups) - 1

    def place(self):
        """当前地址作为 label，返回句柄给 patch 用。"""
        return len(self.buf)

    def patch(self, handle, label):
        self.fixups[handle][1] = label

    def wide_fixup(self, patch_pos, base):
        """登记一个「相对基址不是操作数尾」的跳转回填。

        多操作数指令（TRY_BEGIN）里，几个 i32 的相对基址都是**整条指令之后**，
        不能用 fixups 那套「操作数尾」的口径。"""
        self.wide_fixups.append([patch_pos, None, base])
        return len(self.wide_fixups) - 1

    def patch_wide(self, handle, label):
        self.wide_fixups[handle][1] = label

    def resolve_fixups(self):
        for op_pos, label in self.fixups:
            struct.pack_into('<i', self.buf, op_pos,
                             label - (op_pos + 4))   # 偏移相对下一条指令
        for patch_pos, label, base in self.wide_fixups:
            struct.pack_into('<i', self.buf, patch_pos, label - base)


# ---------------------------------------------------------------- 编译器

class _Compiler:
    def __init__(self, prog: Program, clib_names=None):
        self.prog = prog
        self.clib_names = set(clib_names or ())   # 同目录 C 库的函数名（VM 不支持，报错时给指引）
        self.catch_depth = 0                 # catch 块嵌套深度（裸 throw 只能在 catch 里用）
        self.consts = []                  # (类型, 值)
        self.cidx = {}                    # (类型, 值) -> 索引（去重）
        # 函数 0 = GOING 主程序，之后每个 fv 按出现顺序
        self.fns = [_FnGen(self, 'main', [])]
        self.fn_bodies = [prog.go_body]   # 与 self.fns 平行的函数体（lambda 的体也在里面）
        self.fn_arity = {}                # 函数名 -> 参数个数
        self.fn_index = {}
        for f in prog.fns:
            if f.name in self.fn_index or f.name == 'main':
                raise CompileError(f"第 {f.line} 行：重复的函数定义 {f.name!r}")
            if f.name in ('长度', '添加'):
                raise CompileError(f"第 {f.line} 行：函数名 {f.name!r} 是内置函数，不能定义")
            self.fn_index[f.name] = len(self.fns)
            self.fn_arity[f.name] = len(f.params)
            self.fns.append(_FnGen(self, f.name, f.params))
            self.fn_bodies.append(f.body)
        # mec lambda 预扫描：收集并编号，降级成顶层函数 __mec_lam_N。
        # 与 C 后端同名同义：lambda 的值是函数名字符串，真正的调用靠运行时分发器。
        self.mec_lams = []
        _walk_lams(prog, self.mec_lams)
        for L in self.mec_lams:
            name = f'__mec_lam_{L.n}'
            if name in self.fn_index:
                raise CompileError(f"第 {L.line} 行：lambda 生成的函数名 {name!r} 与已有函数冲突")
            self.fn_index[name] = len(self.fns)
            self.fn_arity[name] = len(L.params)
            self.fns.append(_FnGen(self, name, L.params))
            self.fn_bodies.append(L.body)

    # ---- 常量池 ----

    def const(self, typ, val):
        key = (typ, val)
        if key in self.cidx:
            return self.cidx[key]
        if len(self.consts) >= 0x10000:
            raise CompileError("常量池超过 65536 项")
        idx = len(self.consts)
        self.consts.append(key)
        self.cidx[key] = idx
        return idx

    # ---- 语句 ----

    def compile_stmts(self, fg, stmts):
        # 规则7：本层的 when 块全部摘出，按 priority 升序稳定排序提到最前
        cds = sorted((s for s in stmts if isinstance(s, CdBlock)),
                     key=lambda c: c.priority)
        rest = [s for s in stmts if not isinstance(s, CdBlock)]
        for cd in cds:
            self._line(fg, cd)
            self.compile_stmt(fg, cd)
        for s in rest:
            self._line(fg, s)
            self.compile_stmt(fg, s)

    def _line(self, fg, s):
        """每条语句前记行号：运行时报错带「第 N 行:」（与 C 后端 g_cur_line 一致）。"""
        行 = getattr(s, 'line', None)
        if not 行:
            return
        if 行 > 0xFFFF:
            行 = 0xFFFF
        fg.emit(0x40, 'U')
        fg.set_u16(len(fg.buf) - 3, 1, int(行), 行)

    def compile_stmt(self, fg, s):
        if isinstance(s, VgAssign):
            self.compile_expr(fg, s.expr)
            fg.emit(0x04, 'U')
            fg.set_u16(len(fg.buf) - 3, 1, fg.slots[s.name], s.line)
        elif isinstance(s, IpAssign):
            fg.emit(0x2A, 'U')
            fg.set_u16(len(fg.buf) - 3, 1, self.const(T_STR, s.prompt), s.line)
            fg.emit(0x04, 'U')
            fg.set_u16(len(fg.buf) - 3, 1, fg.slots[s.name], s.line)
        elif isinstance(s, NsShow):
            self.compile_ns(fg, s)
        elif isinstance(s, Around):
            self.compile_around(fg, s)
        elif isinstance(s, ForIn):
            self.compile_forin(fg, s)
        elif isinstance(s, (HmDraw, HmFrame, HmPlay, HmLive, GoStmt)):
            raise CompileError(f"第 {s.line} 行：web 网页语句只在原生模式里支持（VM 是终端模式）")
        elif isinstance(s, Aging):
            self.compile_aging(fg, s)
        elif isinstance(s, WhileStmt):
            self.compile_while(fg, s)
        elif isinstance(s, BreakStmt):
            self.compile_break(fg, s)
        elif isinstance(s, ContinueStmt):
            self.compile_continue(fg, s)
        elif isinstance(s, CdBlock):
            self.compile_stmts(fg, s.body)
        elif isinstance(s, TryCatch):
            self.compile_trycatch(fg, s)
        elif isinstance(s, OnError):
            # onerror 包住 GOING 里它之后的全部语句（前端已重排进 s.body）
            self.compile_trycatch(fg, TryCatch(s.body, s.var, s.handler, s.line))
        elif isinstance(s, Throw):
            self.compile_throw(fg, s)
        elif isinstance(s, VcChain):
            self.compile_vc(fg, s)
        elif isinstance(s, AssignIndex):
            slot = fg.resolve(s.name, s.line)
            fg.emit(0x03, 'U')                       # 压 base 变量槽（SETIDX 弹 v,idx,base）
            fg.set_u16(len(fg.buf) - 3, 1, slot, s.line)
            self.compile_expr(fg, s.index)
            self.compile_expr(fg, s.expr)
            fg.emit(0x29)
        elif isinstance(s, GoldDel):
            slot = fg.resolve(s.name, s.line)
            fg.emit(0x33 if s.kind == 'gold' else 0x34, 'U')
            fg.set_u16(len(fg.buf) - 3, 1, slot, s.line)
        elif isinstance(s, MemoryMode):
            fg.emit(0x35, 'B')
            fg.buf[-1] = s.mode
        elif isinstance(s, DeviceMode):
            # 布局：[op][backend u8][threads u16]；emit 后 pos = op 的下标
            fg.emit(0x37, 'BU')
            pos = len(fg.buf) - 4
            fg.buf[pos + 1] = s.backend
            fg.set_u16(pos, 2, s.threads, s.line)
        elif isinstance(s, JitMode):
            # 布局：[op][on u8][阈值 u16]；同 DeviceMode 的四字节布局
            fg.emit(0x38, 'BU')
            pos = len(fg.buf) - 4
            fg.buf[pos + 1] = 1 if s.on else 0
            fg.set_u16(pos, 2, s.threshold, s.line)
        elif isinstance(s, HmStmt):
            raise CompileError(f"第 {s.line} 行：hm 网页语句暂不支持 VM 模式，请用原生模式（F5）")
        elif isinstance(s, Ret):
            if fg.name == 'main':
                raise CompileError(f"第 {s.line} 行：ret 不能出现在 GOING 主程序里")
            if s.expr is not None:
                self.compile_expr(fg, s.expr)
                fg.emit(0x31)
            else:
                fg.emit(0x32)
        elif isinstance(s, Call):
            self.compile_expr(fg, s)
            fg.emit(0x06)                              # 语句级调用，丢弃返回值
        elif type(s).__name__ == 'OnError':
            # 错误链（rt_err_push / g_err_top 的长跳转）目前只有 C 后端生成了跳转目标，
            # 字节码里没有对应指令。照实说，别只丢一个节点名。
            raise CompileError(
                f"第 {getattr(s, 'line', 0)} 行：onerror 兜底块仅 C 后端（原生模式 F5）支持，"
                f"VM 后端（终端模式）不支持。"
                f"怎么改：用原生模式编译，或把这段用 if 判据 + http.err() 自己兜。"
                f"（onerror 是 net/http 这类运行期失败唯一的补救口子，"
                f"VM 侧要容错只能显式判 http.err()）")
        else:
            raise CompileError(f"第 {getattr(s, 'line', 0)} 行：不可编译的语句 {type(s).__name__}")

    def compile_ns(self, fg, s: NsShow):
        if s.magic:
            fg.emit(0x23, 'U')
            fg.set_u16(len(fg.buf) - 3, 1,
                       self.const(T_STR, ','.join(s.magic)), s.line)
        for kind, val in s.parts:
            if kind == 'TEXT':
                fg.emit(0x21, 'U')
                fg.set_u16(len(fg.buf) - 3, 1, self.const(T_STR, val), s.line)
            elif kind == 'EXPR':                       # 完整表达式插值
                self.compile_expr(fg, val)
                fg.emit(0x22)
            else:                                      # VAR 单变量插值
                slot = fg.resolve(val, s.line)
                fg.emit(0x03, 'U')
                fg.set_u16(len(fg.buf) - 3, 1, slot, s.line)
                fg.emit(0x22)
        fg.emit(0x24)

    # ---- 循环：while / break / continue ----

    def _push_loop(self, fg):
        """登记一层循环。break/continue 的跳转目标在退出这层时统一回填。"""
        fr = {'breaks': [], 'conts': []}
        fg.loopstack.append(fr)
        return fr

    def compile_while(self, fg, s: WhileStmt):
        """while(条件){...}：条件为真就继续下一轮。

        生成的形状和 C 后端一致（for(;;){ 条件; if(!cond) break; 体 }）：
        条件在**每轮开头**求值一次，所以 continue 回到的是条件判断处，
        不是循环体开头——两者在「continue 之前改过循环变量」时结果不同。

        break/continue 用相对跳转实现，不需要新指令：
        编译期就知道该往哪跳，运行时只要一个 JUMP。
        """
        top = fg.place()
        self.compile_expr(fg, s.cond)
        jf = fg.jump(0x1F)                  # 条件为假 → 出口
        fr = self._push_loop(fg)
        self.compile_stmts(fg, s.body)
        fg.loopstack.pop()
        back = fg.jump(0x1E)                # → 条件
        fg.patch(back, top)
        end = fg.place()
        fg.patch(jf, end)
        for h in fr['breaks']:
            fg.patch(h, end)                # break：跳出这一层
        for h in fr['conts']:
            fg.patch(h, top)                # continue：回到条件判断

    def compile_break(self, fg, s: BreakStmt):
        """break：跳出最内层循环。目标地址在退出该层时才确定，先占一个跳转。"""
        if not fg.loopstack:
            raise CompileError(f"第 {s.line} 行：break 不在循环里")
        fg.loopstack[-1]['breaks'].append(fg.jump(0x1E))

    def compile_continue(self, fg, s: ContinueStmt):
        """continue：跳到最内层循环的下一轮（重新求值循环条件）。"""
        if not fg.loopstack:
            raise CompileError(f"第 {s.line} 行：continue 不在循环里")
        fg.loopstack[-1]['conts'].append(fg.jump(0x1E))

    # ---- 异常：try / catch / finally / throw ----

    def compile_trycatch(self, fg, s: TryCatch):
        """try/catch/finally → 字节码（VM 后端）。

        生成的形状和 C 后端一致（finally 抄两份，因为出错只能落到固定一处）：

          TRY_BEGIN catch_rel, mismatch_rel, filter, e_slot, t_slot
          <主体>
          TRY_POP
          JUMP fin_normal
        catch_body:            ; 出错落点：类型对上了才跳进来
          TRY_HANDLER rethrow_rel
          <catch 体>
          TRY_POP
          JUMP fin_normal
        fin_rethrow:           ; 类型对不上 / catch 体里又出错 → 走这儿
          <finally>
          THROW_RETHROW
        fin_normal:
          <finally>
          JUMP end
        end:

        VM 侧：TRY_BEGIN 登记一层错误点并 setjmp；出错时按类型过滤决定跳
        catch_body（并把消息/类型写进 e/t 槽）还是 mismatch（类型对不上，
        原样往外抛）。catch 体里再出错由 TRY_HANDLER 那一层接住。
        """
        fin = s.fin or []
        has_catch = bool(s.handler)
        # catch 的变量用隐藏槽 + forvars 遮蔽（跟 for-in 一个路子）：
        # 免得 catch e 撞了外层同名变量的槽。
        e_slot = t_slot = 0xFFFF
        shadow = []
        if s.var:
            e_slot = fg.new_slot(f'@catch:{s.var}')
            shadow.append((s.var, e_slot))
        if s.var2:
            t_slot = fg.new_slot(f'@catch:{s.var2}')
            shadow.append((s.var2, t_slot))
        filter_idx = self.const(T_STR, s.etype) if s.etype else 0xFFFF

        base = len(fg.buf)
        fg.emit(0x3A, 'IIUUU')                 # 1 + 4 + 4 + 2 + 2 + 2 = 15 字节
        instr_end = base + 15
        h_catch = fg.wide_fixup(base + 1, instr_end)
        h_mism = fg.wide_fixup(base + 5, instr_end)
        fg.set_u16(base, 9, filter_idx, s.line)
        fg.set_u16(base, 11, e_slot, s.line)
        fg.set_u16(base, 13, t_slot, s.line)

        self.compile_stmts(fg, s.body)
        fg.emit(0x3B)                          # TRY_POP：正常走完，弹掉这层
        j_fin_normal = fg.jump(0x1E)

        catch_body = fg.place()
        j_rethrow = j_catch_end = None
        if has_catch:
            j_rethrow = fg.jump(0x3C)             # TRY_HANDLER：catch 块体里出错 → 跳 rethrow
            # VM 出错时压了 [类型, 消息]（消息在栈顶）：先写 e 槽、再写 t 槽
            if s.var:
                fg.emit(0x04, 'U')
                fg.set_u16(len(fg.buf) - 3, 1, e_slot, s.line)
            if s.var2:
                fg.emit(0x04, 'U')
                fg.set_u16(len(fg.buf) - 3, 1, t_slot, s.line)
            if not hasattr(fg, 'forvars'):
                fg.forvars = []
            fg.forvars.extend(shadow)
            self.catch_depth += 1
            self.compile_stmts(fg, s.handler)
            self.catch_depth -= 1
            for nm, sl in shadow:
                for i in range(len(fg.forvars) - 1, -1, -1):
                    if fg.forvars[i] == (nm, sl):
                        fg.forvars.pop(i)
                        break
            fg.emit(0x3B)                          # TRY_POP：弹掉 catch 体那一层
            j_catch_end = fg.jump(0x1E)             # → fin_normal

        fin_rethrow = fg.place()
        self.compile_stmts(fg, fin)            # finally（出错路）
        fg.emit(0x3E)                          # THROW_RETHROW：原样往外抛

        fin_normal = fg.place()
        fg.patch(j_fin_normal, fin_normal)
        if j_catch_end is not None:
            fg.patch(j_catch_end, fin_normal)
        self.compile_stmts(fg, fin)            # finally（正常路）
        j_end = fg.jump(0x1E)                  # end 标签在跳转之后（否则跳自己 = 死循环）
        end = fg.place()
        fg.patch(j_end, end)
        # 没有 catch 时出错也要走重抛路：不能被「空的 catch 体」吞掉
        fg.patch_wide(h_catch, catch_body if has_catch else fin_rethrow)
        fg.patch_wide(h_mism, fin_rethrow)
        if j_rethrow is not None:
            fg.patch(j_rethrow, fin_rethrow)

    def compile_throw(self, fg, s: Throw):
        """throw / throw "消息" / throw "消息", "类型"。

        不带参数的 throw 是**重抛**：把手上正在接的那个错原样抛给外层，
        只能写在 catch 里（别处没有「手上的错」）。"""
        if s.msg is None:
            if self.catch_depth <= 0:
                raise CompileError(f"第 {s.line} 行：throw（不带参数）是重抛，只能写在 catch 里；"
                                   f"要抛新的错就写 throw \"消息\"")
            fg.emit(0x3E)                       # THROW_RETHROW
            return
        # 栈序：先压类型、再压消息（THROW 先弹消息）
        if s.etype is not None:
            self.compile_expr(fg, s.etype)
        else:
            fg.emit(0x02, 'U')
            fg.set_u16(len(fg.buf) - 3, 1, self.const(T_STR, '运行时'), s.line)
        self.compile_expr(fg, s.msg)
        fg.emit(0x3D)                           # THROW

    def compile_around(self, fg, s: Around):
        varname = getattr(s, 'var', 'at')
        self.compile_expr(fg, s.times)
        self._hid = getattr(self, '_hid', 0)
        at = fg.new_slot(varname)              # 循环变量名 = 计数槽（VM 每轮写它）
        cnt = fg.new_slot(f'@cnt{self._hid}')
        self._hid += 1
        fg.loops.append(at)
        fg.emit(0x2B, 'UU')
        base = len(fg.buf) - 5
        fg.set_u16(base, 1, at, s.line)
        fg.set_u16(base, 3, cnt, s.line)
        body = fg.place()
        fr = self._push_loop(fg)
        self.compile_stmts(fg, s.body)
        fg.loopstack.pop()
        step = fg.place()                    # AROUND_STEP 的地址（continue 的落点）
        fg.emit(0x2C, 'UUI')
        base = len(fg.buf) - 9
        fg.set_u16(base, 1, at, s.line)
        fg.set_u16(base, 3, cnt, s.line)
        # 偏移域在 base+5，相对下一条指令回跳到循环体首
        fg.fixups.append([base + 5, body])
        fg.loops.pop()
        end = fg.place()                     # AROUND_STEP 之后（break 的落点）
        for h in fr['breaks']:
            fg.patch(h, end)
        for h in fr['conts']:
            fg.patch(h, step)

    def compile_forin(self, fg, s: ForIn):
        """for x in 列表 { ... }：列表存进隐藏槽，次数走 LEN，
        每轮 at 当下标用 INDEX 取元素存进本轮专属槽（遮蔽外层同名）。"""
        hid = getattr(self, '_hid', 0)
        self._hid = hid + 1
        lst = fg.new_slot(f'@lst{hid}')
        at = fg.new_slot(f'@at{hid}')
        cnt = fg.new_slot(f'@cnt{hid}')
        varslot = fg.new_slot(f'@for{hid}:{s.var}')
        self.compile_expr(fg, s.iter)
        fg.emit(0x04, 'U')
        fg.set_u16(len(fg.buf) - 3, 1, lst, s.line)
        fg.emit(0x03, 'U')
        fg.set_u16(len(fg.buf) - 3, 1, lst, s.line)
        fg.emit(0x27)                              # LEN → 次数压栈
        fg.loops.append(at)
        fg.emit(0x2B, 'UU')
        base = len(fg.buf) - 5
        fg.set_u16(base, 1, at, s.line)
        fg.set_u16(base, 3, cnt, s.line)
        body = fg.place()
        if not hasattr(fg, 'forvars'):
            fg.forvars = []
        fg.forvars.append((s.var, varslot))
        fg.emit(0x03, 'U')
        fg.set_u16(len(fg.buf) - 3, 1, lst, s.line)
        fg.emit(0x03, 'U')
        fg.set_u16(len(fg.buf) - 3, 1, at, s.line)
        fg.emit(0x28)                              # INDEX：列表[at] → 元素
        fg.emit(0x04, 'U')
        fg.set_u16(len(fg.buf) - 3, 1, varslot, s.line)
        fr = self._push_loop(fg)
        self.compile_stmts(fg, s.body)
        fg.forvars.pop()
        fg.loopstack.pop()
        step = fg.place()                    # AROUND_STEP 的地址（continue 的落点）
        fg.emit(0x2C, 'UUI')
        base = len(fg.buf) - 9
        fg.set_u16(base, 1, at, s.line)
        fg.set_u16(base, 3, cnt, s.line)
        fg.fixups.append([base + 5, body])
        fg.loops.pop()
        end = fg.place()                     # AROUND_STEP 之后（break 的落点）
        for h in fr['breaks']:
            fg.patch(h, end)
        for h in fr['conts']:
            fg.patch(h, step)

    def compile_aging(self, fg, s: Aging):
        top = fg.place()
        self.compile_expr(fg, s.cond)
        jf = fg.jump(0x20)
        self.compile_stmts(fg, s.body)
        back = fg.jump(0x1E)
        fg.patch(back, top)
        fg.patch(jf, fg.place())

    def compile_vc(self, fg, s: VcChain):
        ends = []
        for cond, body in s.arms:
            if cond is not None:
                self.compile_expr(fg, cond)
                jf = fg.jump(0x1F)
                self.compile_stmts(fg, body)
                ends.append(fg.jump(0x1E))
                fg.patch(jf, fg.place())
            else:                          # else 臂必为最后一臂
                self.compile_stmts(fg, body)
        for h in ends:
            fg.patch(h, fg.place())

    def compile_comp(self, fg, s):
        """列表推导 [expr for x in iter if cond]：纯逻辑，VM 可完整支持。

        复用 around 循环机（AROUND_INIT/STEP）遍历 iter，每轮把元素绑到 x，
        求值 expr 并（按 cond）LIST_APPEND 到新建结果表；结果表作为表达式值留栈。"""
        hid = getattr(self, '_hid', 0); self._hid = hid + 1
        out = fg.new_slot(f'@comp{hid}')        # 结果表槽
        it = fg.new_slot(f'@comp_it{hid}')      # 被遍历表槽
        at = fg.new_slot(f'@at{hid}')           # 下标计数槽
        cnt = fg.new_slot(f'@cnt{hid}')         # 次数槽
        varslot = fg.new_slot(f'@for{hid}:{s.var}')  # 元素槽（x 在推导体内绑定到此）
        # 结果表 = 空表
        fg.emit(0x25)                          # LIST_NEW：压空表
        fg.emit(0x04, 'U'); fg.set_u16(len(fg.buf) - 3, 1, out, s.line)  # 存入 out
        # 求值 iter 表，存入 it
        self.compile_expr(fg, s.iter)          # 压 iter 表
        fg.emit(0x04, 'U'); fg.set_u16(len(fg.buf) - 3, 1, it, s.line)   # 存入 it
        # 压次数（LEN）并启动 around 循环
        fg.emit(0x03, 'U'); fg.set_u16(len(fg.buf) - 3, 1, it, s.line)   # 压 it 表
        fg.emit(0x27)                          # LEN：表 -> 次数
        fg.loops.append(at)
        fg.emit(0x2B, 'UU')
        base = len(fg.buf) - 5
        fg.set_u16(base, 1, at, s.line)
        fg.set_u16(base, 3, cnt, s.line)
        body = fg.place()
        # 元素 = it[at] -> varslot
        fg.emit(0x03, 'U'); fg.set_u16(len(fg.buf) - 3, 1, it, s.line)
        fg.emit(0x03, 'U'); fg.set_u16(len(fg.buf) - 3, 1, at, s.line)
        fg.emit(0x28)                          # INDEX：压元素
        fg.emit(0x04, 'U'); fg.set_u16(len(fg.buf) - 3, 1, varslot, s.line)  # 存 varslot
        # expr 求值并（按 cond）追加
        if not hasattr(fg, 'forvars'):
            fg.forvars = []
        fg.forvars.append((s.var, varslot))
        if s.cond is not None:
            fg.emit(0x03, 'U'); fg.set_u16(len(fg.buf) - 3, 1, out, s.line)  # 压结果表 L0
            self.compile_expr(fg, s.expr)          # 压 expr 值 V -> [L0, V]
            self.compile_expr(fg, s.cond)          # 压 cond -> [L0, V, C]
            jf = fg.jump(0x1F)                     # 弹 cond；假则跳 skip（丢弃 V、L0）
            fg.emit(0x26)                          # LIST_APPEND：表.压(V)，栈 [表]
            fg.emit(0x06)                          # POP 表，栈清零
            jend = fg.jump(0x1E)
            fg.patch(jf, fg.place())
            fg.emit(0x06)                          # skip：POP V
            fg.emit(0x06)                          # skip：POP 表
            fg.patch(jend, fg.place())
        else:
            fg.emit(0x03, 'U'); fg.set_u16(len(fg.buf) - 3, 1, out, s.line)  # 压结果表 L0
            self.compile_expr(fg, s.expr)          # 压 expr 值 V -> [L0, V]
            fg.emit(0x26)                          # LIST_APPEND：表.压(V)，栈 [表]
            fg.emit(0x06)                          # POP 表，栈清零
        fg.forvars.pop()
        fg.emit(0x2C, 'UUI')
        base = len(fg.buf) - 9
        fg.set_u16(base, 1, at, s.line)
        fg.set_u16(base, 3, cnt, s.line)
        fg.fixups.append([base + 5, body])
        fg.loops.pop()
        # 表达式结果 = 结果表（压栈）
        fg.emit(0x03, 'U'); fg.set_u16(len(fg.buf) - 3, 1, out, s.line)

    # ---- 表达式 ----

    def compile_expr(self, fg, e):
        if isinstance(e, NumLit):
            if isinstance(e.value, float):
                idx = self.const(T_FLOAT, e.value)
            else:
                if not INT64_MIN <= e.value <= INT64_MAX:
                    raise CompileError(f"第 {e.line} 行：整数 {e.value} 超出 int64 范围")
                idx = self.const(T_INT, e.value)
            fg.emit(0x02, 'U')
            fg.set_u16(len(fg.buf) - 3, 1, idx, e.line)
        elif isinstance(e, StrLit):
            fg.emit(0x02, 'U')
            fg.set_u16(len(fg.buf) - 3, 1, self.const(T_STR, e.value), e.line)
        elif isinstance(e, BoolLit):
            fg.emit(0x02, 'U')
            fg.set_u16(len(fg.buf) - 3, 1,
                       self.const(T_INT, 1 if e.value else 0), e.line)
        elif isinstance(e, VarRef):
            fg.emit(0x03, 'U')
            fg.set_u16(len(fg.buf) - 3, 1, fg.resolve(e.name, e.line), e.line)
        elif isinstance(e, Unary):
            self.compile_expr(fg, e.operand)
            fg.emit(0x16 if e.op == '-' else 0x17)
        elif isinstance(e, BinOp):
            if e.op == 'and':              # 规则3：短路且返回操作数本身
                self.compile_expr(fg, e.left)
                fg.emit(0x05)              # DUP
                j = fg.jump(0x1F)          # 假则留着左操作数直接出去
                fg.emit(0x06)              # POP 弹掉副本
                self.compile_expr(fg, e.right)
                fg.patch(j, fg.place())
            elif e.op == 'or':
                self.compile_expr(fg, e.left)
                fg.emit(0x05)
                j = fg.jump(0x20)
                fg.emit(0x06)
                self.compile_expr(fg, e.right)
                fg.patch(j, fg.place())
            elif e.op in ('in', 'not_in'):
                # in / not in → CALL_LIB rt_in / rt_not_in（集合=字典，rt_in 有 IS_DICT 分支）
                fn = 'rt_in' if e.op == 'in' else 'rt_not_in'
                self.compile_expr(fg, e.left)
                self.compile_expr(fg, e.right)
                namei = self.const(T_STR, fn)
                _chk_u16(namei, '库名常量索引', getattr(e, 'line', 0))
                fg.emit(0x36, 'UB')
                base = len(fg.buf) - 4
                fg.set_u16(base, 1, namei, getattr(e, 'line', 0))
                struct.pack_into('<B', fg.buf, base + 3, 2)
            else:
                self.compile_expr(fg, e.left)
                self.compile_expr(fg, e.right)
                fg.emit(_BINOP[e.op])
        elif isinstance(e, Ternary):
            # 条件 ? 成立 : 不成立：纯表达式，结果值留在栈上
            self.compile_expr(fg, e.cond)
            jf = fg.jump(0x1F)              # 条件为假跳到 else 分支
            self.compile_expr(fg, e.then)
            jend = fg.jump(0x1E)            # 跳过 else
            fg.patch(jf, fg.place())        # else 分支起点
            self.compile_expr(fg, e.els)
            fg.patch(jend, fg.place())      # 整体结束点
        elif isinstance(e, Comp):
            self.compile_comp(fg, e)
        elif isinstance(e, Call):
            self.compile_call(fg, e)
        elif isinstance(e, InputExpr):
            fg.emit(0x2A, 'U')
            fg.set_u16(len(fg.buf) - 3, 1, self.const(T_STR, e.prompt), e.line)
        elif isinstance(e, ListLit):
            fg.emit(0x25)
            for it in e.items:
                self.compile_expr(fg, it)
                fg.emit(0x26)
        elif isinstance(e, DictLit):
            fg.emit(0x2D)                     # DICT_NEW
            for k, v in e.pairs:
                self.compile_expr(fg, k)
                self.compile_expr(fg, v)
                fg.emit(0x2E)                 # DICT_SET：[...,键,值] → [...,字典]
        elif isinstance(e, SetLit):
            # 集合 = 无值字典（键=元素、值=1）。VM 栈式：DICT_NEW 后
            # 逐元素 [压字典副本? 不需要——DICT_SET 直接改栈顶字典]
            fg.emit(0x2D)                       # DICT_NEW：压入空字典
            for it in e.items:
                self.compile_expr(fg, it)
                self.compile_expr(fg, NumLit(1, getattr(e, 'line', 0)))
                fg.emit(0x2E)                   # DICT_SET：[...,字典,键,值] → [...,字典]
        elif isinstance(e, DictLit):
            fg.emit(0x42)                       # DICT_NEW：压入空字典
            for k2, v2 in e.pairs:
                fg.emit(0x41)                   # DUP：复制字典供 SETIDX 消费
                self.compile_expr(fg, k2)
                self.compile_expr(fg, v2)
                fg.emit(0x29)                   # SETIDX
            return
        elif isinstance(e, Index):
            self.compile_expr(fg, e.base)
            self.compile_expr(fg, e.index)
            fg.emit(0x28)
        elif isinstance(e, Lambda):
            # lambda 降级成顶层函数 __mec_lam_N，值是函数名字符串（与 C 后端同契约）：
            # 真正的调用走运行时的函数分发表（rt_call_value → 装进运行时的分发器）。
            if not getattr(e, 'n', 0):
                raise CompileError(f"第 {getattr(e, 'line', 0)} 行：lambda 没有编号")
            fg.emit(0x02, 'U')
            fg.set_u16(len(fg.buf) - 3, 1,
                       self.const(T_STR, f'__mec_lam_{e.n}'), e.line)
        else:
            raise CompileError(f"第 {getattr(e, 'line', 0)} 行：不可编译的表达式 {type(e).__name__}")

    def compile_call(self, fg, c: Call):
        if c.name == '空' and not c.args:
            # 空 字面量：常量池里放一个 none 盒（与 C 后端的 rt_none() 同义）
            fg.emit(0x02, 'U')
            fg.set_u16(len(fg.buf) - 3, 1, self.const(T_NONE, None), c.line)
            return
        # ffi.* / c.* 是编译期展开成 C 调用的底层窗口接口，VM（终端模式）没有对应实现
        if c.name.startswith('ffi.') or c.name.startswith('c.'):
            raise CompileError(
                f"第 {c.line} 行：ffi 调用 {c.name}() 仅 C 后端（原生模式 F5）支持，"
                f"VM 后端（终端模式）不支持。请改用原生模式编译。")
        # 双后端分工：VM 后端（终端模式）按「函数」而非「前缀」判定可用性。
        # 判据：是否绑定 OS 资源（窗口 / 设备 / socket / 编译器）。详见 ARCHITECTURE.md
        # 「双后端分工原则」。
        #   - net / http 已链进 pyvm.exe（_wire_net.py 接线，2026-10）→ VM 放行，
        #     含 HTTP 服务端四件套（listen/serve/req/resp）。
        #   - m3/ui 这几个 .c 根本没链进 pyvm.exe → 整前缀不可用。
        #   - 音.* / mm.* 内部是分裂的：离屏渲染 / 纯数据类（音.奏 / 音.音 /
        #     mm.draw_away / mm.色 / mm.color）物理已链进 pyvm.exe，放行给 VM；
        #     实时播放 / 窗口类（音.正弦 / 三角 / 快 / 放 / 谱、mm.贴 / mm.动 等）
        #     必须走 C 后端，编译期即拒（与 web / game / ffi 一致：编译期就拦，
        #     而不是跑到一半才崩）。
        _VM_BLOCK_PREFIXES = ('m3', 'ui')
        _VM_BLOCK_FUNCS = {
            # 音.* 实时播放 / 设备类（waveOut，阻塞式）
            '音.正弦', '音.三角', '音.快', '音.放', '音.停', '音.谱', '音.演',
            # mm.* 窗口模式（需要 SDL 窗口，g_sdl_ren == NULL 即死）
            'mm.贴', 'mm.blt', 'mm.动', 'mm.anim',
            '图.函数', 'plt.fun',
            # 图.函数 回调用户 lambda：依赖 rt_call_value 的分发器，
            # 用户程序 main() 开头才装，VM 里没有 -> 编译期就拦
        }
        _c_prefix = c.name.split('.')[0] if '.' in c.name else ''
        if _c_prefix in _VM_BLOCK_PREFIXES:
            raise CompileError(
                f"第 {c.line} 行：库 {c.name}() 仅 C 后端（原生模式 F5）支持，"
                f"VM 后端（终端模式）不支持。请改用原生模式编译。")
        if c.name in _VM_BLOCK_FUNCS:
            raise CompileError(
                f"第 {c.line} 行：库 {c.name}() 是实时播放/窗口类，"
                f"仅 C 后端（原生模式 F5）支持，VM 后端（终端模式）不支持。"
                f"请改用原生模式编译。")
        if c.name in LIB_CALLS:
            # 标准库调用 → CALL_LIB：库名进常量池，实参按书写序压栈
            want = LIB_CALLS[c.name]
            isopt = isinstance(want, tuple)
            if isopt:
                # (最少,最多) 形式的入口：少给的补空盒（C 层认这个当「没给」），
                # 实际调用按「最多」传参 —— 与 C 后端同一套规则。
                lo, hi = want
                if not (lo <= len(c.args) <= hi):
                    raise CompileError(
                        f"第 {c.line} 行：{c.name} 需要 {lo}~{hi} 个实参，"
                        f"给了 {len(c.args)} 个")
                nargs = hi
            else:
                if len(c.args) != want:
                    raise CompileError(
                        f"第 {c.line} 行：{c.name} 需要 {want} 个实参，"
                        f"给了 {len(c.args)} 个")
                nargs = want
            namei = self.const(T_STR, c.name)
            for a in c.args:
                self.compile_expr(fg, a)
            for _ in range(nargs - len(c.args)):
                fg.emit(0x02, 'U')
                fg.set_u16(len(fg.buf) - 3, 1, self.const(T_NONE, None), c.line)
            _chk_u16(namei, '库名常量索引', c.line)
            _chk_u8(nargs, '参数个数', c.line)
            fg.emit(0x36, 'UB')
            base = len(fg.buf) - 4
            fg.set_u16(base, 1, namei, c.line)
            struct.pack_into('<B', fg.buf, base + 3, nargs)
            return
        if '.' in c.name and c.name.split('.')[0] in LIB_PREFIXES:
            for a in c.args:               # 实参按书写顺序压栈
                self.compile_expr(fg, a)
            fg.emit(0x40, 'UB')
            base = len(fg.buf) - 4
            ni = self.const(3, c.name)     # 库调用全名进字符串常量池
            fg.set_u16(base, 1, ni, c.line)
            _chk_u8(len(c.args), '参数个数', c.line)
            struct.pack_into('<B', fg.buf, base + 3, len(c.args))
            return
        if c.name == '长度':
            if len(c.args) != 1:
                raise CompileError(f"第 {c.line} 行：list.长度 恰好要 1 个实参")
            self.compile_expr(fg, c.args[0])
            fg.emit(0x27)
            return
        if c.name == '添加':
            if len(c.args) != 2 or not isinstance(c.args[0], VarRef):
                raise CompileError(f"第 {c.line} 行：list.添加 的写法是 list.添加(列表名, 值)")
            fg.emit(0x03, 'U')
            fg.set_u16(len(fg.buf) - 3, 1,
                       fg.resolve(c.args[0].name, c.line), c.line)
            self.compile_expr(fg, c.args[1])
            fg.emit(0x26)
            return
        if c.name == '错误类型':                  # 内置：错误类型()：当前错误类型
            if len(c.args) != 0:
                raise CompileError(f"第 {c.line} 行：错误类型 不需要参数")
            fg.emit(0x3F)                        # ERR_TYPE：压当前错误类型
            return
        if c.name in GAME_CALLS:
            # 游戏调用需要窗口 / 游戏循环，VM（终端模式）不支持；C 后端原生模式才支持
            want = GAME_CALLS[c.name]
            need = '不需要实参' if want == 0 else f'需要 {want} 个实参'
            raise CompileError(
                f"第 {c.line} 行：游戏调用 {c.name}()（{need}）仅 C 后端（原生模式 F5）支持，"
                f"VM 后端（终端模式）不支持。请改用原生模式编译。")
        if c.name not in self.fn_index:
            if c.name in fg.slots:
                # 变量当函数调用（lambda 值）：函数值 + 实参 → CALL_DYN，
                # 由运行时的分发器按名字找函数并调用（C 后端走 rt_mec_apply，同一契约）。
                fg.emit(0x03, 'U')
                fg.set_u16(len(fg.buf) - 3, 1, fg.resolve(c.name, c.line), c.line)
                for a in c.args:               # 实参按书写顺序压栈
                    self.compile_expr(fg, a)
                fg.emit(0x39, 'B')
                fg.buf[-1] = len(c.args)
                return
            if c.name in self.clib_names:
                raise CompileError(
                    f"第 {c.line} 行：{c.name} 是同目录 C 库里的函数，只在 C 后端（原生模式 F5）可用\n"
                    f"  为什么：VM 是解释器，没有 C 运行时，链不进 .c 库\n"
                    f"  怎么改：改用原生模式编译；或把这个功能用 PYbook 自己实现一遍")
            raise CompileError(f"第 {c.line} 行：未声明的函数 list.{c.name}")
        idx = self.fn_index[c.name]
        want = self.fn_arity[c.name]
        if len(c.args) != want:
            raise CompileError(
                f"第 {c.line} 行：函数 {c.name!r} 要 {want} 个实参，给了 {len(c.args)} 个")
        for a in c.args:                   # 实参按书写顺序压栈
            self.compile_expr(fg, a)
        fg.emit(0x30, 'UB')
        base = len(fg.buf) - 4
        fg.set_u16(base, 1, idx, c.line)
        _chk_u8(len(c.args), '参数个数', c.line)
        struct.pack_into('<B', fg.buf, base + 3, len(c.args))

    # ---- 入口 ----

    def run(self) -> bytes:
        for fg in self.fns:                # 函数名先进池，索引才能进函数表
            self.const(T_STR, fg.name)
        for i, f in enumerate(self.fns):
            body = self.fn_bodies[i]
            self._declare_all(f, body)
            self.compile_stmts(f, body)
            if i == 0:
                f.emit(0x01)               # 主程序结尾 HALT
            else:
                f.emit(0x32)               # fv 兜底 RET_NONE
            f.resolve_fixups()

        out = bytearray(MAGIC)
        out += struct.pack('<III', VERSION, len(self.consts), len(self.fns))
        for typ, val in self.consts:
            if typ == T_INT:
                out.append(T_INT)
                out += struct.pack('<q', val)
            elif typ == T_FLOAT:
                out.append(T_FLOAT)
                out += struct.pack('<d', val)
            elif typ == T_NONE:
                out.append(T_NONE)          # 空：无载荷
            else:
                enc = val.encode('utf-8')
                out.append(T_STR)
                out += struct.pack('<I', len(enc)) + enc
        # 代码偏移相对代码区起点
        offs = []
        o = 0
        for fg in self.fns:
            offs.append(o)
            o += len(fg.buf)
        for i, fg in enumerate(self.fns):
            out += struct.pack('<I', self.cidx[(T_STR, fg.name)])
            out += struct.pack('<HHII', len(fg.params), fg.nslot,
                               offs[i], len(fg.buf))
        out += b''.join(bytes(fg.buf) for fg in self.fns)
        return bytes(out)

    def _declare_all(self, fg, stmts):
        """预遍历：把函数内所有赋值过的名字按首现顺序分槽。"""
        def walk(stmts):
            for s in stmts:
                if isinstance(s, VgAssign) and s.name not in fg.slots:
                    fg.new_slot(s.name)
                elif isinstance(s, IpAssign) and s.name not in fg.slots:
                    fg.new_slot(s.name)
                elif isinstance(s, Around):
                    walk(s.body)
                elif isinstance(s, ForIn):
                    walk(s.body)
                elif isinstance(s, Aging):
                    walk(s.body)
                elif isinstance(s, WhileStmt):
                    walk(s.body)
                elif isinstance(s, CdBlock):
                    walk(s.body)
                elif isinstance(s, VcChain):
                    for _c, b in s.arms:
                        walk(b)
                elif isinstance(s, (TryCatch, OnError)):
                    walk(s.body)
                    walk(s.handler)
                    if getattr(s, 'fin', None):
                        walk(s.fin)
        walk(stmts)


def compile_source(src: str, base_dir: str = '.') -> bytes:
    prog = parse(src)
    # 合并 引用() 导入：与主文件同目录解析（可被 PYBK_IMPORT_DIR 覆盖，便于 IDE 内联检查）
    if getattr(prog, 'imports', None):
        import os as _os
        from pybk_code import _load_imports
        base = _os.environ.get('PYBK_IMPORT_DIR') or base_dir or _os.getcwd()
        fns, inits, classes, macros = _load_imports(prog, base, ['<主文件>'])
        prog.fns = fns + (prog.fns or [])
        prog.go_body = inits + (prog.go_body or [])
        prog.classes = classes + (prog.classes or [])
        prog.macros = macros + (prog.macros or [])
    if getattr(prog, 'macros', None):     # 宏：编译期内联展开（须在 _Compiler 之前）
        expand_macros(prog)
    # 同目录 C 库的函数名：VM 跑不了它们，但报错时要说清楚（而不是丢一句
    # 「未声明的函数 list.xxx」让人去 list 里找）
    clib_names = ()
    try:
        import pybk_clib as _clib
        _base = os.environ.get('PYBK_IMPORT_DIR') or base_dir or os.getcwd()
        _clibs = _clib.discover(_base)
        if _clibs:
            _tbl, _conf = _clib.collect(_clibs)
            clib_names = sorted(_tbl)
    except Exception:
        clib_names = ()
    return _Compiler(prog, clib_names).run()


# ---------------------------------------------------------------- 反汇编

def _parse_pybc(data: bytes):
    if data[:4] != MAGIC:
        raise CompileError("魔数不是 PYBC")
    version, n, f = struct.unpack_from('<III', data, 4)
    if version != VERSION:
        raise CompileError(f"不支持的版本 {version}")
    pos = 16
    consts = []
    for _ in range(n):
        typ = data[pos]
        pos += 1
        if typ == T_INT:
            consts.append((T_INT, struct.unpack_from('<q', data, pos)[0]))
            pos += 8
        elif typ == T_FLOAT:
            consts.append((T_FLOAT, struct.unpack_from('<d', data, pos)[0]))
            pos += 8
        elif typ == T_STR:
            ln = struct.unpack_from('<I', data, pos)[0]
            pos += 4
            consts.append((T_STR, data[pos:pos + ln].decode('utf-8')))
            pos += ln
        elif typ == T_NONE:
            consts.append((T_NONE, None))
        else:
            raise CompileError(f"常量池类型 {typ} 未知")
    funcs = []
    for _ in range(f):
        name_i, argc, nslot, off, size = struct.unpack_from('<IHHII', data, pos)
        pos += 16
        funcs.append((name_i, argc, nslot, off, size))
    code = data[pos:]
    return version, consts, funcs, code


def disasm(data: bytes) -> str:
    version, consts, funcs, code = _parse_pybc(data)
    lines = [f".pybc  版本={version}  常量={len(consts)}  函数={len(funcs)}",
             "常量池:"]
    for i, (typ, val) in enumerate(consts):
        tn = {T_INT: 'int', T_FLOAT: 'float', T_STR: 'str', T_NONE: 'none'}[typ]
        lines.append(f"  [{i}] {tn} {val!r}")
    lines.append("函数表:")
    for i, (name_i, argc, nslot, off, size) in enumerate(funcs):
        lines.append(f"  fn{i} {consts[name_i][1]!r} 参数={argc} 槽位={nslot} "
                     f"代码=[{off}..{off + size})")
    starts = set()
    pc = 0
    while pc < len(code):
        op = code[pc]
        if op not in OPS:
            raise CompileError(f"代码区偏移 {pc}：未知操作码 0x{op:02X}")
        spec = OPS[op][1]
        size = 1 + sum(2 if c == 'U' else (4 if c == 'I' else 2 if c == 'U' else 1 if c == 'B' else 0) for c in spec)
        starts.add(pc)
        pc += size
    for i, (name_i, argc, nslot, off, size) in enumerate(funcs):
        lines.append(f"--- fn{i} {consts[name_i][1]!r} ---")
        pc = off
        end = off + size
        while pc < end:
            op = code[pc]
            name, spec = OPS[op]
            args = []
            p = pc + 1
            for c in spec:
                if c == 'U':
                    args.append(str(struct.unpack_from('<H', code, p)[0]))
                    p += 2
                elif c == 'B':
                    args.append(str(code[p]))
                    p += 1
                else:
                    args.append(str(struct.unpack_from('<i', code, p)[0]))
                    p += 4
            note = ''
            if name == 'CONST':
                note = f"  ; {consts[int(args[0])][1]!r}"
            elif name in ('SHOW_TEXT', 'MAGIC', 'INPUT'):
                note = f"  ; {consts[int(args[0])][1]!r}"
            elif spec == 'I' or (spec == 'UUI'):
                target = p + struct.unpack_from('<i', code, p - 4)[0]
                args[-1] = f"-> {target}"
            lines.append(f"  {pc:4d}: {name}"
                         + (' ' + ' '.join(args) if args else '') + note)
            pc = p
    return '\n'.join(lines)


# ---------------------------------------------------------------- 自测

if __name__ == '__main__':
    import sys
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass

    # 说明：样例原文里的 vg_ro.单 = [1,2,3] 前端文法不支持（vg_ro 不是关键字、
    # AST 也没有列表节点），在不动 pybk_front.py 的前提下用 vg.单 = 3 等价替换，
    # 使 list.长度(单) == 3 依旧成立。
    SAMPLE = '''@ 测>样例>一
func 加倍(n) { ret n * 2 }
GOING:{
vg.单 = 3
rm.around(3) { ns.show(第 $at 圈) }
if(list.长度(单) == 3) { ns.show(长度对) }
vg.答案 = list.加倍(21)
ns.show(答案=$答案)
}STOP
'''
    data = compile_source(SAMPLE)
    assert data[:4] == b'PYBC'
    version, consts, funcs, code = _parse_pybc(data)
    assert version == 1 and len(funcs) == 2
    assert consts[funcs[0][0]][1] == 'main' and consts[funcs[1][0]][1] == '加倍'

    # 常量去重：整数 3 出现在 vg 赋值、around 次数、== 比较里，池里只应有 1 项
    assert sum(1 for t, v in consts if t == T_INT and v == 3) == 1

    # 指令流完整性：解码正好覆盖代码区，所有跳转目标都落在指令边界上
    starts = set()
    pc = 0
    jump_tgts = []
    while pc < len(code):
        op = code[pc]
        assert op in OPS, f"未知操作码 0x{op:02X} @ {pc}"
        spec = OPS[op][1]
        size = 1 + sum(2 if c == 'U' else (4 if c == 'I' else 2 if c == 'U' else 1 if c == 'B' else 0) for c in spec)
        starts.add(pc)
        if spec in ('I', 'UUI'):
            off = struct.unpack_from('<i', code, pc + 1 + 4 * (spec == 'UUI'))[0]
            jump_tgts.append(pc + size + off)
        pc += size
    assert pc == len(code)
    assert all(t in starts for t in jump_tgts), "跳转目标没有落在指令边界"

    # 主程序以 HALT 结尾；func 以 RET_NONE 兜底
    assert code[funcs[0][3] + funcs[0][4] - 1] == 0x01
    assert code[funcs[1][3] + funcs[1][4] - 1] == 0x32

    print(disasm(data))

    # ---- 语义错误必须带行号 ----
    def _err(src):
        try:
            compile_source(src)
        except (CompileError, PybkError) as e:
            assert '第 ' in str(e), str(e)
            return str(e)
        raise AssertionError('应当报错却没有：' + src)

    assert 'ret' in _err('@ a>b>c\nGOING:{\nret 1\n}STOP\n')
    assert '重复' in _err('@ a>b>c\nfunc f(x){}\nfunc f(y){}\nGOING:{}STOP\n')
    assert '未声明' in _err('@ a>b>c\nGOING:{\nvg.a = b\n}STOP\n')
    assert '内置' in _err('@ a>b>c\nfunc 长度(x){ ret x }\nGOING:{}STOP\n')
    print()
    print("自测通过：格式/去重/跳转边界/HALT 与 RET_NONE 兜底/语义错误均核对无误。")
