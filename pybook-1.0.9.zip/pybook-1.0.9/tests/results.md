# PYbook v2 自动比对结果

- 用例总数：277　通过：277　失败：0　跳过：0　耗时 499.2s
- 运行方式：`C:\Users\zhuli\AppData\Local\Programs\Python\Python311\python.exe pybk_main.py tests/<用例>.pybk`（cwd=仓库根，剔除 COLUMNS）

## 汇总

| 用例 | 类型 | 结果 | 预期说明 |
|---|---|---|---|
| T01_comment_ok | normal | ✅ | 各位置注释均被忽略，只输出一行 注释OK |
| E01_no_at | error | ✅ | 缺 @ 行 → 第 1 行报错（实际会带 Python traceback，见 bug B1） |
| E02_empty_file | error | ✅ | 空程序 → 在 EOF 行报错（行号会算上文件尾注释，见 bug B1/B5；实际带 Python traceback） |
| E03_no_going | error | ✅ | 只有 @ 行缺 GOING → 在 EOF 行报错（见 bug B1/B5；实际带 Python traceback） |
| E04_after_stop | error | ✅ | GOING 之后再写语句 → 第 5 行报错（实际会带 Python traceback，见 bug B1） |
| E05_stop_line | error | ✅ | STOP 不与 } 同行 → 报错，但行号指向 EOF 行而非 STOP 所在第 5 行（bug B1/B5） |
| E06_missing_brace | error | ✅ | 缺收尾 } → 在 EOF 行报错（见 bug B1/B5；实际带 Python traceback） |
| T02_vars_ok | normal | ✅ | 整数/浮点/字符串/布尔字面量(true/false)/显示 true/false；重复赋值可改变类型（写 true/false 会报未声明，见 bug B8） |
| T02_uninit_none | normal | ✅ | 先赋值后声明语义：读到尚未赋值的变量得 空，之后读到 9 |
| T02_dynamic_ro | explore | ✅ | 观察：vg 也能装列表、vg_ro 也能装标量并可重新赋值（ro 前缀只是约定） |
| T03_list_ok | normal | ✅ | 列表字面量/下标读写/负下标/空列表/长度/添加/混合嵌套显示（布尔显示 true） |
| T03_index_oob | error | ✅ | 下标越界 → 运行时错误: 下标：下标越界，退出码 1 |
| T03_index_neg_oob | error | ✅ | 负下标越过头部 → 运行时错误: 下标：下标越界 |
| T03_index_float_read | error | ✅ | 浮点下标读 → 运行时错误: 下标：下标必须是整数 |
| T03_index_float_write | error | ✅ | 浮点下标写 → 运行时错误: 下标赋值：下标必须是整数 |
| T03_setindex_oob | error | ✅ | 下标写越界 → 运行时错误: 下标赋值：下标越界 |
| T03_list_plus_err | error | ✅ | 列表不支持 + 拼接 → 明确报错（设计如此） |
| T03_list_cmp_err | error | ✅ | 列表 == 深度相等（内容不同判假）；列表 < 直接报错（新语义） |
| T04_len_err | error | ✅ | 长度 用于整数 → 运行时错误 |
| T04_len_args | error | ✅ | 长度 无参 → 编译期 第 3 行: 长度 需要 1 个参数 |
| T05_add_ret_none | normal | ✅ | list.添加 返回空盒，且确实修改了原列表 |
| T05_add_form_err | error | ✅ | 添加 第一个参数不是变量名 → 编译期报错 |
| T05_add_undeclared | error | ✅ | 添加 未声明的列表 → 编译期报 未声明 |
| T06_show_ok | normal | ✅ | 文本/变量/表达式插值、空 show 输出空行、循环内 $at+1、$s+$s 拼接 |
| T06_dollar_empty | error | ✅ | $ 后无名字 → 第 3 行报错（实际会带 Python traceback，见 bug B1） |
| T06_show_unclosed | error | ✅ | ns.show 缺右括号 → 第 3 行报错（带三段式建议） |
| T06_interp_paren_text | explore | ✅ | 观察：$ 只取到标识符 f，紧跟的 (1) 被当作调用实参（不是普通文本）→ f 既非函数也未声明，编译期报未定义 |
| T06_interp_call | explore | ✅ | 观察：插值里 $list.函数(实参) 实际能调用函数（与“插值不能用小括号”的说明不符） |
| T07_magic_ok | normal | ✅ | b/i/u/d/c/bk 依次输出对应 ANSI 转义序列，行尾重置 |
| T07_align_ok | normal | ✅ | fl/fm/fr 与 l/m/r 对齐一致：左 0、居中 (80-字节数)//2、右 80-字节数 个空格 |
| T07_magic_font_err | error | ✅ | 字体类样式 f → 运行时错误: 不支持的样式 f（终端做不到，设计如此） |
| T07_magic_alias_err | error | ✅ | / 后不是 magic → 第 3 行报错（实际会带 Python traceback，见 bug B1） |
| T07_magic_color_partial | error | ✅ | 颜色缺分量 → 第 3 行报错（带三段式） |
| T08_around_ok | normal | ✅ | 计数循环累加 0+1+2+3=6；嵌套循环内层 at 从 0 起、遮蔽外层；$at $at 之间的空格保留为文本 |
| T08_around_edge | normal | ✅ | 0 次不执行；值为整数的浮点次数 2.0 按 2 次执行 |
| T08_around_float_err | error | ✅ | 2.5 次应报错；注意实际前缀是英文 runtime error: 而非“运行时错误:”（bug B4） |
| T08_at_outside | error | ✅ | 循环外用 at → 编译期 第 3 行: 变量 'at' 未声明 |
| T09_aging_ok | normal | ✅ | 条件不满足就一直跑：输出 0/1/2 后条件满足停止 |
| T09_aging_zero | normal | ✅ | 条件一开始就满足 → 循环体一次都不执行 |
| T10_vc_ok | normal | ✅ | if/elif/else 命中正确分支；else  与 else 等价；空列表为假（条件用 true 字面量） |
| T10_vc_minus_solo | error | ✅ | else 单独开头 → 第 3 行报错（实际会带 Python traceback，见 bug B1） |
| T10_vc_plus_mid | error | ✅ | 链中间再写 if → 两个独立 if 块都执行，输出 一/二（新语法下不再报错） |
| T11_when_ok | normal | ✅ | when 块按数字升序稳定提到本层最前，同级保持书写顺序，其余语句顺序不变 |
| T11_when_float | error | ✅ | when 优先级写成 1.5 → 第 5 行报错（实际会带 Python traceback，见 bug B1） |
| T12_fn_ok | normal | ✅ | 两参函数、递归阶乘、裸 ret 返回空盒（多参调用放在普通赋值里；插值里写多参调用见 E13） |
| T12_fn_dup | error | ✅ | 重复定义函数 → 第 5 行报错（带三段式） |
| T12_fn_undef | error | ✅ | 调用未定义函数 → 第 3 行报错 |
| T12_fn_args | error | ✅ | 实参个数不符 → 第 6 行（调用所在行）报错 |
| T12_fn_forward | normal | ✅ | 函数互相前向调用（已支持）：先() 调用后定义的 后()，输出 1 |
| T12_ret_in_going | error | ✅ | ret 写进 GOING → 第 3 行报错 |
| T12_fn_scope | explore | ✅ | 观察：函数内看不到 GOING 的变量（每个函数独立作用域） |
| T13_lock_read_ok | normal | ✅ | lock 锁定后仍可读取（不报错，正常输出 5） |
| T13_lock_assign_err | error | ✅ | 锁后再赋值 → 运行时错误: 变量已锁定 |
| T13_del_read_err | error | ✅ | 删后再读 → 运行时错误: 用已删除变量 |
| T13_del_assign_err | error | ✅ | 删后再赋值 → 运行时错误: 用已删除变量 |
| T13_lock_undeclared | error | ✅ | lock 未声明变量 → 编译期报 未声明 |
| T13_lock_setindex | normal | ✅ | 锁后下标写 → 运行时错误: 变量已锁定（路径已统一拦截） |
| T13_lock_push | explore | ✅ | 观察：锁后 list.添加 现在也被拦截（与下标写一致），报 变量已锁定 |
| T14_arith_ok | normal | ✅ | 四则/取模/整除（Python 语义负数向下）、优先级、/ 得浮点、%.15g 去尾零 |
| T14_cmp_ok | normal | ✅ | 六种比较、字符串按字节比较、浮点与整数比较 |
| T14_logic_ok | normal | ✅ | and/or 返回操作数本身（短路取值）；not 返回真/false |
| T14_shortcircuit | normal | ✅ | 短路：false and / true or 不执行右侧（右侧若执行会除零崩溃） |
| T14_strcat_ok | normal | ✅ | 字符串 + 拼接 |
| T14_strnum_err | error | ✅ | 字符串 + 数字 → 运行时错误: 类型不可相加 |
| T14_divzero_int | error | ✅ | 整除零 → 运行时错误: 除以零 |
| T14_divzero_fdiv | error | ✅ | // 除零 → 运行时错误: 除以零 |
| T14_divzero_mod | error | ✅ | % 除零 → 运行时错误: 除以零 |
| T14_divzero_float | error | ✅ | 浮点除零 → 运行时错误: 除以零 |
| T14_neg_err | error | ✅ | 一元负号对整数/浮点正常；对字符串 → 运行时错误 |
| T14_chain_cmp | explore | ✅ | 观察：链式比较按 (1<x)<3 解释、布尔当 0/1 参与 → 0 时整体为真（与 Python 不同） |
| T15_lit_max_ok | normal | ✅ | 64 位最大整数字面量正常显示 |
| T15_lit_over | error | ✅ | 超大整数字面量 → 编译期 第 3 行报错 |
| T15_runtime_overflow | error | ✅ | 运行期加法溢出 → 运行时错误: 溢出 |
| T15_neg_min_literal | explore | ✅ | 观察：负号是独立运算符，-9223372036854775808 的字面量部分越界 → 无法书写 LLONG_MIN |
| T16_input_ok | normal | ✅ | 字符串输入、整数输入参与运算；提示符原样输出不换行 |
| T16_input_float | normal | ✅ | 小数输入解析为浮点，3.5*2=7 显示为 7 |
| T16_input_empty | normal | ✅ | 空行输入 → 空字符串，长度 0 |
| E07_paren_unbalanced | error | ✅ | 括号不配对 → 第 4 行（} 所在行）报错（实际会带 Python traceback，见 bug B1） |
| E08_deep_nest | error | ✅ | 300 层嵌套括号 → 前端 Python 递归爆栈，报 maximum recursion depth exceeded（无行号，见 bug B2） |
| E10_illegal_char | error | ✅ | 非法字符 ？ → 第 3 行报错（实际会带 Python traceback，见 bug B1） |
| E11_unterminated_str | error | ✅ | 字符串未闭合 → 第 3 行报错（带三段式建议） |
| E09_long_line | error | ✅ | 70000 字符的超长一行显示 → 运行时错误: 一行太长（运行时 64KB 行缓冲上限） |
| E12_dollar_adjacent | explore | ✅ | 观察：$at$at 的内部 $ 被去掉后拼成 atat 一个名字 → 报“变量 'atat' 未声明”，名字是拼接出来的（bug B6） |
| E13_interp_comma | explore | ✅ | 插值遇逗号 → 第 6 行报错（带三段式建议，不再误导为 变量未声明） |
| E14_trailing_comment | explore | ✅ | 观察：EOF 锚定的报错行号把文件尾注释全部计入（bug B5 的直接演示） |
| E15_bool_cjk_literal | explore | ✅ | 观察：布尔字面量只能写 true/false；写 true 被当成未声明变量，报错误导（bug B8） |
| T17_mem_normal_ok | normal | ✅ | 文件级 @normal：del 只打逻辑删除标志，不再使用则正常结束（输出 1 与 结束） |
| T17_mem_self_del_ok | normal | ✅ | 文件级 @self：del 真正释放列表/字符串，删后不再使用则正常结束（输出 结束） |
| T17_mem_self_use_err | error | ✅ | @self 删除后再读取 → 运行时错误: 用已删除变量 |
| T17_mem_1_use_err | error | ✅ | @1（=自动托管/normal）删除后再读取 → 运行时错误: 用已删除变量 |
| T17_mem_normal_use_err | error | ✅ | @normal 删除后再读取 → 与 @1 用例逐字节相同的错误输出（两者等价） |
| T17_mem_2_eq_self | error | ✅ | @2（=完全手动/self）删除后再读取 → 与 @self 完全相同的运行时错误 |
| T17_mem_3_unimpl | normal | ✅ | @3（引用计数）现已实现：空 GOING 块正常结束，退出码 0 |
| T17_mem_switch_self_normal | normal | ✅ | 语句级声明+切换：先 @self 真删列表，再 @normal 切回自动托管，后续 del 只打标志，正常结束（输出 结束） |
| T17_lock_del_together | error | ✅ | lock 与 del 同用互不干扰：双标志后先触发 用已删除变量 |
| T17_mem_in_fn | normal | ✅ | 函数内声明 Memoryment：全局开关从声明处生效，函数内删除、函数外切回 @normal 均正常（输出 1 与 结束） |
| P0_01_mem | error | ✅ | Memoryment 模式越界（合法档位随语言演进，用一个绝不会分配的 99 占位）→ 带三段式 |
| P0_02_web | error | ✅ | web. 后跟非法组件名 → 带三段式 |
| P0_03_go | error | ✅ | go 方向非法（中文方位以外的字）→ 带三段式 |
| P0_04_key | error | ✅ | key 键名非字符串字面量 → 带三段式 |
| P0_05_keyname | error | ✅ | key 键名不在支持列表 → 带三段式 |
| P0_06_lib | error | ✅ | 库前缀下无此函数 → 带三段式 |
| P0_07_hw | error | ✅ | hw.* 未 ON 3D_highway → 带三段式 |
| P0_08_magicp | error | ✅ | magic 颜色缺一段 → 带三段式 |
| P0_09_magice | error | ✅ | magic 为空 → 带三段式 |
| P0_10_tmstop | error | ✅ | tm.stop 参数个数错 → 带三段式 |
| P0_11_webtop | error | ✅ | web.块 写在 GOING 内 → 带三段式 |
| P0_12_macrodup | error | ✅ | 宏重名定义 → 带三段式（codegen 期） |
| P0_13_macroconf | error | ✅ | 宏与函数同名 → 带三段式（codegen 期） |
| P0_14_macroargs | error | ✅ | 宏实参个数不符 → 带三段式（codegen 期） |
| P0_15_classundef | error | ✅ | 实例化未定义的类 → 带三段式 |
| P0_16_classattr | error | ✅ | 构造器用了类没有的属性 → 带三段式 |
| P0_17_dollar | error | ✅ | 插值 $ 后跟无法解析的字符 → 带三段式 |
| P0_18_device_cpu_ok | normal | ✅ | device cpu 4：正常编译运行，输出不受线程数影响 |
| P0_19_device_auto_ok | normal | ✅ | device auto：等价 cpu，线程数交给机器定 |
| P0_20_device_gpu_ok | normal | ✅ | device gpu：编译期不再拒（本机有卡），运行时探测到 GPU，tb.gpu() 为真 |
| P0_21_device_tier_err | error | ✅ | 未知档位 cuda → 带三段式 |
| P0_22_device_auto_threads_err | error | ✅ | auto/gpu 不许带线程数 → 带三段式 |
| P0_23_device_threads_range_err | error | ✅ | 线程数越界（0）→ 带三段式 |
| P0_24_device_extra_token_err | error | ✅ | 一行写了两个数字 → 带三段式 |
| P0_25_device_missing_err | error | ✅ | 只写 device 不写档位 → 带三段式 |
| P0_26_f32_prec_roundtrip | normal | ✅ | tensor.cast/prec：默认 f64，可转 f32 再转回，值无损 |
| P0_27_gpu_nocard_dies | error | ✅ | device gpu 但探测不到卡 → 运行时报错，绝不静默退回 CPU |
| P0_28_auto_nocard_cpu | normal | ✅ | device auto 无卡 → 走 CPU；且 CPU 路径的 tb.dot 也保持 f32（与 GPU 路径同语义） |
| P0_29_gpu_route_e2e | normal | ✅ | device gpu 端到端：128³ 走 4x4 路由、300x132x300（N>=256 且 K 非 8 倍数）走 shared 路由；数据 %3 压值域保 f32 精确，期望值 = (i%3)xΣ((k+偏)%3) |
| P0_30_gpu_8x8_e2e | normal | ✅ | device gpu 端到端：N=1280（>=1280）走 8x8 寄存器分块路由，M=8 瘦长形（M 无对齐要求，尾行谓词兜住）；数据 %3 压值域保 f32 精确，期望值 = (i%3)xΣ((k+1)%3) = (i%3)x64 |
| T18_la_solve_ok | normal | ✅ | 线性代数张量面：行列式/logdet/条件数/秩/solve 的精确值 + A·inv≈I 的残差断言 |
| T18_la_qr_ok | normal | ✅ | QR：A=QR 逐项还原、QᵀQ≈I、R 严格上三角（R 的列符号自由，故只验恒等式不逐元素比 Q） |
| T18_la_chol_eig_ok | normal | ✅ | Cholesky 的 A=LLᵀ 还原 + 对称特征值升序、A·V=V·λ、特征值之和等于迹 |
| T18_la_svd_lstsq_ok | normal | ✅ | SVD 输出形状 U m×min、VT min×n、奇异值降序；最小二乘给精确解且三个残差为零 |
| T18_la_mp_flat_ok | normal | ✅ | mp.* 扁平列表面与 tb.* 张量面同源：mat_det/mat_solve/mat_rank/mat_qr/mat_svd/mat_ls/to_tensor |
| T18_la_singular_err | error | ✅ | 奇异矩阵求逆 → 带三段式的运行时错误，并指向 tb.rank/tb.lstsq 的出路 |
| T18_la_nonsquare_err | error | ✅ | 非方阵求行列式 → 带三段式的运行时错误，并指向 tb.qr/tb.svd 的出路 |
| T18_la_notspd_err | error | ✅ | 非正定矩阵做 Cholesky → 带三段式的运行时错误（刻意保守，不用不成立的分解算出看着正常的数） |
| T18_la_nonsym_err | error | ✅ | 非对称矩阵求特征值 → 带三段式的运行时错误，并指向对称化或 tb.svd |
| T18_la_notensor_err | error | ✅ | 把普通列表当矩阵传进去 → 带三段式的运行时错误，并给出造张量的正确写法 |
| T18_la_rhs_len_err | error | ✅ | 右端向量长度与系数矩阵阶数不符 → 报错并把目标长度算给你看 |
| T18_la_flat_len_err | error | ✅ | mp.* 扁平列表长度与行列数之积不符 → math+ 自己的维度校验（mat_det 走的是 mathplus.c 那条老路） |
| T19_math_basic_ok | normal | ✅ | 基础数学补齐的 30 个值：exp/log 族、反三角、双曲、cbrt/hypot/trunc/sign、fmod 与 mod 的语义差异、is_nan/is_inf（对拍 Python math：21 项逐位相同，9 项相对误差 <=1e-14） |
| T19_math_log0_err | error | ✅ | mt.log(0) → 定义域报错（不静默返回 NaN：NaN 会顺着后面几步流下去） |
| T19_math_logneg_err | error | ✅ | mt.log(-2.5) → 定义域报错，并指出 x 极小时应改用 mt.log1p |
| T19_math_asin_range_err | error | ✅ | mt.asin(1.5) → 定义域报错，并把「本意是求夹角」的出口指向 mt.atan2 |
| T19_math_acosh_range_err | error | ✅ | mt.acosh(0.5) → 定义域报错（cosh 的值恒 >=1） |
| T19_math_fmod_zero_err | error | ✅ | mt.fmod(x, 0) → 除零报错（C 的 fmod 在这里会返回 NaN，拦下来） |
| T19_math_notnum_err | error | ✅ | mt.log("abc") → 类型错误。这一条没有行号前缀：mt.* 全族走 lib_num→lib_die，与 mt.sin/mt.sqrt 既有行为一致（定义域检查才用 rt_die 带行号三段式） |
| T20_rd_seed_ok | normal | ✅ | 随机源统一后的三件事：rd.seed 可复现、rd.* 与 mp.rand_* 同源、rd.float 的分辨率从 32693 个不同取值变成 200000 个（满 53 位） |
| T20_stat_ok | normal | ✅ | median/mode/quantile/percentile 逐项对拍 numpy（线性插值、并列取最小众数） |
| T20_stat2_ok | normal | ✅ | cumsum/diff/cov/corr 对拍 numpy（cov 用样本协方差分母 n-1；corr 遇到常数变量报「无定义」而不是静默给 0） |
| T20_corr_const_err | error | ✅ | corr 的一个变量是常数 → 报错「无定义」，不静默返回 0 |
| T20_stat_len_err | error | ✅ | cov/corr 两个列表长度不同 → 报错并把两个长度都算给你看 |
| T20_quantile_range_err | error | ✅ | quantile 的 q 不在 [0,1] → 报错并给出合法区间 |
| T20_binom_range_err | error | ✅ | 二项分布 p 越界 → 报错（核心层哨兵被绑定层翻译成三段式） |
| T20_gamma_range_err | error | ✅ | 伽马分布形状为负 → 报错 |
| T20_logistic_range_err | error | ✅ | logistic 尺度为 0 → 报错。注意 logistic 是唯一可以为负的分布，所以绑定层不能靠「返回值<0」反推参数非法，必须显式校验 |
| T21_calc_ok | normal | ✅ | 库函数回调用户 lambda：中心差分求导（默认步长与显式步长）、复合 Simpson 积分、二分/牛顿求根（数值导数与解析导数）、泰勒系数；同时验证 mec.apply 原有的分发表没被动过 |
| T21_bisect_same_sign_err | error | ✅ | 二分法两端同号 → 报错并把两端的函数值算给你看（同号时二分会收敛到错的点，静默返回一个数会让人以为求成功了） |
| T21_newton_stall_err | error | ✅ | 牛顿法在导数为 0 处卡住 → 报错并说明除数为 0 |
| T21_deriv_step_err | error | ✅ | 步长相对 x 太小（x+h 舍入后还是 x）→ 报错并给出可用的替代步长 |
| T21_callback_type_err | error | ✅ | 回调的函数返回的不是数字 → 报错（静默当 0 会让结果全错却看不出原因） |
| T21_calc_arity_err | error | ✅ | 可选参数入口的参数个数越界 → **编译期**报错写成 2~3 的区间（新机制）。注意它走的是前端 PybkError（编译失败）这条路，stderr 里没有运行时的尾行 |
| T21_integrate_range_err | error | ✅ | 积分上限小于下限 → 报错（本函数按 [下限,上限] 处理，不做反向） |
| T22_special_ok | normal | ✅ | 特殊函数：gamma/lgamma/erf/erfc/zeta 全部走语言内接近() 容差断言（1e-12），覆盖 erf 奇函数性、erfc 的 erfc(-x)=2-erfc(x)、zeta(2)=π²/6、zeta(4)=π⁴/90 |
| T22_optimize_ok | normal | ✅ | 黄金分割：抛物线/倒抛物线/正弦的极值点都落在真值上；端点写反结果一致；容差变大结果变粗（说明可选参数 tol 真的起作用）；零宽区间不崩。位置断言用「无常量抵消」的函数（净峰/净谷，1e-8 钉得死）；带抵消的 dome/quad 只断言**函数值**精确最优（1e-12）——因为 10-(x-3)^2 在 |x-3|<3e-8 时 f 全舍入成同一个 10.0，位置分辨率被函数自身卡在 ~3e-8，这是值比较法的天花板，不是实现的问题（实测 _math_bench/_golden_check.c：位置 2.66e-08，函数值误差 0） |
| T22_interp_ok | normal | ✅ | 插值：线性/三次在末段与越界处都正确（末段曾因二分查找上界写错而整段算错，越界曾外推成 489）；不等距点也对；linfit 给 [斜率, 截距, r²] |
| T22_polyfit_ok | normal | ✅ | polyfit 返回**原始 x 的幂**的系数（不是中心化基底的）：横轴平移到 10~13 拟合 x²，常数项仍应为 0；一次拟合斜率 6、截距 -6 |
| T22_zeta_div_err | error | ✅ | mt.zeta(s<=1) → 级数发散，报三段式而不是给一个 ±inf 让用户自己猜 |
| T22_interp_unsorted_err | error | ✅ | 采样点乱序 → 显式报错并指出**第一个逆序下标**（点序乱了二分会静默插到错误的段上） |
| T22_polyfit_deg_err | error | ✅ | mp.polyfit 次数越界 → 三段式报错并解释高次拟合的病态性 |
| T22_polyfit_sample_err | error | ✅ | mp.polyfit 样本数少于次数+1 → 三段式报错 |
| T22_linfit_flat_err | error | ✅ | mp.linfit 的 x 全一样 → 报「画不出直线」而不是静默给 0 |
| T22_notlist_err | error | ✅ | 插值/拟合的采样点不是列表 → 明确报错（漏掉 AS_INT(rt_len) 时这里会变成 "内存不足"，是 list 拆包失败的典型症状） |
| T23_cpu_dot_nmod4_ok | normal | ✅ | CPU 路径 M>=4 且 N%4!=0：tb.dot 的最后 1 列必须正确（列尾巴曾把每个 kc 块只留最后一个 k 的乘积，静默错 1 列） |
| T24_http_state_initial_ok | normal | ✅ | 一次都没发过时：code=0（还没发过）、err=""（没失败过）、header=""、headers={} —— 四者互不冒充 |
| T24_get_arity_err | error | ✅ | http.get 元数写错 → 编译期拦。要传超时/请求头请用 http.config，不要给 http.get 加第二参（库调用元数是编译期定死的） |
| T24_config_notdict_err | error | ✅ | http.config 传的不是字典 → 报错并把可用的键名摆出来（超时的单位是秒） |
| T24_config_unknown_key_err | error | ✅ | 键名拼错（超时秒 / 超时）→ 直接点名并列出合法键。静默忽略会让"我明明设了超时"变成查不到原因的挂死 |
| T24_config_bad_timeout_err | error | ✅ | 超时给 0 → 报错（0 会被原样塞进 WinINet，等于"永远等下去"，正是要根治的黑洞连接） |
| T24_config_bad_headers_err | error | ✅ | 「头」给的是字符串而不是字典 → 报错。头必须是名字→值一对，字符串写没法校验拼写 |
| T24_header_arg_err | error | ✅ | http.header 传整数 → 报错（头名是字符串） |
| T24_conn_refused_err | error | ✅ | 连不上的端口 → 报错并说清是"连不上"而不是"404"，带 WinINet 原始错误码便于查。老版本这里返回空串，调用方分不出失败 |
| T25_sym_core_ok | normal | ✅ | sym 九入口全链路：解析/求导（乘法法则+链式）/积分（分部+线性内函数+非初等返空串）/化简/展开/求值/替换/相等，中文变量名同理 |
| T25_sym_vars_ok | normal | ✅ | sym.变量 收集自由变量（去重、中文名），无变量时给空表 |
| T25_sym_integ_empty_ok | normal | ✅ | 不会积的公式返回空串（与报错区分：程序继续跑），调用方可以自己判空 |
| T25_sym_abs_diff_err | error | ✅ | abs 在 0 处不可导 → 明确报错并建议分段写，不静默给错结果 |
| T25_sym_parse_err | error | ✅ | 坏公式 → 三段式报错（位置+为什么+怎么改），不是一句看不懂 |
| T25_sym_fullwidth_err | error | ✅ | 全角括号/逗号 → 点名是全角符号并列出半角写法，不把（）当变量名咽下去 |
| T25_sym_type_err | error | ✅ | 第一个参数不是字符串 → 报错并给例子（sym 是字符串进字符串出，不猜类型） |
| T25_sym_div0_err | error | ✅ | 求值除零 → 报错（不是给个 inf 让下游莫名其妙） |
| T25_sym_const_var_err | error | ✅ | 对 pi 求导 → 报错说清 pi/e 是常量不能当变量 |
| T25_sym_unbound_err | error | ✅ | 求值缺绑定 → 报错点名缺哪个变量，并提示用 sym.变量 先看要哪些 |
| T25_sym_arity_err | error | ✅ | 元数写错 → 编译期拦（库调用元数定死，不留给运行时炸） |
| T26_sym_solve_ok | normal | ✅ | sym.求解：一次/二次闭式、乘积先展开再收系数、五次（含复根只报实根）、无理根 10 位、重根报单根、四次数值求根（Durand-Kerner+Newton），一律升序 |
| T26_sym_solve_move_ok | normal | ✅ | 右边不一定是 0（先左减右再解）；等号整个省略时按 =0 处理，两种写法结果一致 |
| T26_sym_solve_edge_ok | normal | ✅ | 0 次方程（与变量无关）不炸：恒等式/无解给明确文字，程序继续跑 |
| T26_sym_solve_nonpoly_err | error | ✅ | 非多项式 → 报错并指路（先展开/化简，或改用求值），不静默给错根 |
| T26_sym_solve_othervar_err | error | ✅ | 出现别的变量 → 点名是哪个变量，并提示先用 sym.替换 代成数字 |
| T26_sym_solve_complex_err | error | ✅ | 判别式<0 → 明说没有实数解、根是一对复数，不返回空串也不编一个根 |
| T26_sym_solve_badeq_err | error | ✅ | 等号某一边是空的 → 报错并给正确写法示例 |
| T26_sym_solve_arity_err | error | ✅ | 元数写错 → 编译期拦（库调用元数定死，不留给运行时炸） |
| T26_sym_format_latex_ok | normal | ✅ | latex 模式：\cdot 乘号、\frac 真分式、幂恒花括号、\pi、\ln、\arcsin、abs 用 \left|\right| |
| T26_sym_format_uni_ok | normal | ✅ | unicode 模式：整数指数转上标、· 乘号、π；非整数指数回落 x^(1/2) 不硬转 |
| T26_sym_format_plain_ok | normal | ✅ | plain/空模式与 sym.解析 逐字一致（默认风格零回归）；uni 是 unicode 的简写别名 |
| T26_sym_format_badmode_err | error | ✅ | 坏模式 → 报错列出合法取值并回显收到的值，不静默回落 |
| T27_sym_integ_rational_ok | normal | ✅ | 有理函数积分：分母按有理根分解→部分分式→汇入表驱动（单根/重根/一个最简二次），长除先走，log 不带 abs（CAS 惯例）；每项末端数值对拍防张冠李戴，对不上认输返空串 |
| T27_sym_solve_sys_ok | normal | ✅ | sym.解方程组：精确有理数高斯-约当消元；方程数须等于变量数；支持分数解/中文变量名/中文分号/缺等号当=0/项乱序；秩不满给「有无穷多组解」并列自由变量 |
| T27_sym_solve_sys_nonlinear_err | error | ✅ | 非线性方程（变量乘变量）→ 点名哪条不线性、说清第一版边界 |
| T27_sym_solve_sys_count_err | error | ✅ | 方程数与变量数不等 → 明确报错并指路（单方程用 sym.求解） |
| T27_sym_solve_sys_incon_err | error | ✅ | 矛盾方程组（加起来推出 0=1）→ 明确报「无解」不编一个解 |
| T27_sym_solve_sys_nonrat_err | error | ✅ | π/e 当系数 → 明确报错（精确有理数路径不猜小数） |
| T27_sym_solve_sys_badvar_err | error | ✅ | 方程里出现变量串外的变量 → 点名是哪个变量并回显变量串 |
| T27_sym_solve_sys_empty_vars_err | error | ✅ | 变量串空 → 报错并给示例写法 |
| T27_sym_solve_sys_empty_eqs_err | error | ✅ | 方程串空 → 报错并给示例写法 |
| T27_sym_solve_sys_arity_err | error | ✅ | 元数写错 → 编译期拦（库调用元数定死） |
| T28_sym_limit_ok | normal | ✅ | 0/0 与 ∞/∞ 走洛必达（分子分母各自求导，两轮）；直接代入；无穷远数值外推 |
| T28_sym_limit_inf_ok | normal | ✅ | ±inf 双侧可写；pi 当点（sin(pi)=1.2e-16 被 snap 回 0）；1/x@-inf 外推 -1e-10 也 snap 回 0（极限值本就是 0，负号不携带信息）；非整洁值留 %.10g |
| T28_sym_limit_diverge_err | error | ✅ | 5/0 出 inf 是真发散（两侧探数不收敛到一块儿），不滥用洛必达 |
| T28_sym_limit_flap_err | error | ✅ | 0*inf 出 nan 是内部乱抖（真实极限 0 存在）——不硬给答案，明说看不出来 |
| T28_sym_limit_domain_err | error | ✅ | 定义域外（log(0)）→ 明说代入后没定义，不编答案 |
| T28_sym_limit_trap_err | error | ✅ | pow(1,inf)=1 的 IEEE 陷阱：符号算出 1、数值对拍却是 e——对拍闸拦下不认 |
| T28_sym_limit_osc_err | error | ✅ | 无穷远三点外推不收敛 → 明说数值近似认输，不谎称发散 |
| T28_sym_limit_badpt_err | error | ✅ | 点参数看不懂 → 报错并给合法写法（数字/pi/e/算式/inf） |
| T28_sym_limit_multivar_err | error | ✅ | 多变量 → 点名是哪个变量并指路 sym.替换 |
| T28_sym_limit_arity_err | error | ✅ | 元数写错 → 编译期拦 |
| T28_sym_series_ok | normal | ✅ | 系数 c_k=f^(k)/k! 走 Frac 精确化（1/6、1/120、1/24）；0 系数项不占位；负系数出 " - "；k=1 出 x 不出 x^1 |
| T28_sym_series_pt_ok | normal | ✅ | 非零点展开：底数换 (x - pt)；0 系数项跳过（x^3@1 的 0 阶项缺失但其余项连续） |
| T28_sym_series_order_err | error | ✅ | 阶数超 12（与 sym.求解 的 12 次上限对齐，12! 还在 int64 内）→ 绑定层直接拦 |
| T28_sym_series_negorder_err | error | ✅ | 负阶数 → 绑定层拦 |
| T28_sym_series_inf_err | error | ✅ | 无穷点不给展开（第一版边界）→ 报错并指路换元 |
| T28_sym_series_multivar_err | error | ✅ | 多变量 → 点名并指路 sym.替换 |
| T28_sym_series_pole_err | error | ✅ | 在奇点处展开（log(x)@0）→ 求值失败明确报出，不编系数 |
| T28_sym_series_arity_err | error | ✅ | 元数写错 → 编译期拦 |
| T22_special_edge_ok | normal | ✅ | 特殊函数边界：gamma/lgamma 在 0<z<1.1e-16（原来返回 inf）和 z>=142.4（中间幂溢出也返回 inf）两段现在都给出正确值；lgamma 在小 z 不再因除数左结合丢掉 1e-8 级精度 |
| T22_np_math_ok | normal | ✅ | np.* 批量超越函数：erf/erfc/gamma/lgamma 的批量值与 mt.* 逐个调用一致，外加 exp 族 / 三角 / cbrt / abs / floor / ceil / round / sign / pow |
| T29_while_ok | normal | ✅ | while(条件){...} 与 continue/继续：条件每轮开头求值一次（假条件一次都不进）；continue 跳到下一轮（不是跳出循环）；break 只跳一层；嵌套 while 里 break 只出内层；continue 在 rm.around 里同样有效。六个值全部精确比对 |
| T29_continue_outside_err | error | ✅ | continue/继续 写在循环外 → 三段式报错（和 break 一样，不静默当普通语句） |
| T30_none_lambda_ok | normal | ✅ | 空 字面量：赋给变量、跟空比较、放进列表都成立；lambda 当值用：赋给变量后可以直接调用，函数值还能再套一层调用 |
| T31_try_catch_ok | normal | ✅ | try/catch：主体里抛的运行时错被 catch 接住，程序继续往下走 |
| T32_finally_ok | normal | ✅ | finally 三条路都跑：① 正常走完 ② catch 接住了错 ③ 没有 catch、错往外抛（finally 仍先跑一遍） |
| T33_throw_ok | normal | ✅ | throw "消息" 抛一个可捕获的错；throw "消息", "类型" 另带类型标签，catch e, t 同时拿到消息和类型 |
| T34_err_type_filter_ok | normal | ✅ | catch e:类型 只接该类型的错；类型对不上就原样往外抛（消息和类型都不变） |
| T35_rethrow_ok | normal | ✅ | catch 里裸 throw = 重抛：把手上那个错原样抛给外层，消息和类型都不改 |
| T36_finally_on_handler_throw_ok | normal | ✅ | catch 里再抛新错时，finally 仍然要跑一遍（新错替代原错往外传） |
| T37_scope_unwind_ok | normal | ✅ | try 里的 for-in 出错：longjmp 跳过了 rt_scope_leave，作用域栈要还原，catch 之后变量还好使 |
| T38_err_type_builtin_ok | normal | ✅ | 内置运行时错自带类型标签（除零 / 下标 / 类型 / 锁定 / 删除 / 键 …），catch e, t 直接读得到 |
| T39_err_type_builtin_fn_ok | normal | ✅ | 错误类型() 内置函数：catch 块里随时能问「现在这个错是啥类型」 |
| E31_throw_outside_catch_err | error | ✅ | 裸 throw（重抛）写在 catch 外 → 编译期拦（别处没有「手上的错」可抛） |
| E32_try_no_catch_finally_err | error | ✅ | try 后面既没 catch 也没 finally → 编译期拦 |
| E33_finally_alone_err | error | ✅ | finally 单独出现（没跟 try/catch）→ 编译期拦 |
| E34_catch_type_bad_err | error | ✅ | catch e:类型 里类型写成了数字 → 编译期拦（类型要写名字或字符串） |
| T40_pkg_ns_ok | normal | ✅ | 两个子目录模块各有同名函数 加 → 自动分到 助手_加 / 工具_加，不再报「重复定义」；模块内部自调用（内部() 里写 加(1,2)）由编译器改写成 助手_加 |
| T41_pkg_nested_ok | normal | ✅ | lib/助手.pybk 里的 引用("兄弟") 相对**它自己所在目录**解析（找 lib/兄弟.pybk，不是主文件旁边的 兄弟.pybk）；类名也带命名空间前缀 → lb.助手_数据表(...) |
| T42_pkg_flat_ok | normal | ✅ | 根目录下的模块维持老行为（平铺：加 / lb.表格 不带前缀），子目录模块才带前缀 —— 既有工程一个字都不用改 |
| T43_pkg_macro_ok | normal | ✅ | 宏也带命名空间前缀：模块里写 宏 打招呼(...)，调用方写 带宏_打招呼(...) |
| T44_pkg_suffix_ok | normal | ✅ | 引用("名.pybk") 带不带后缀都行（老实现会拼成 名.pybk.pybk 找不到文件） |
| E40_pkg_missing_err | error | ✅ | 引用不存在的子目录模块 → 报错要带上实际查找路径 |
| T45_pkg_state_ok | normal | ✅ | 子目录模块的顶层 vg 变量也带命名空间前缀（带状态_计数）；模块内部对这些变量的引用同步改写（双倍 = 计数 * 2 → 带状态_双倍 = 带状态_计数 * 2） |
| T46_lang_zh_ok | normal | ✅ | language 中文 → 关键字（变量/命名空间/显示）与前缀可用中文写法，程序照常运行、输出不变 |
| T47_lang_en_ok | normal | ✅ | 显式写 language english → 与默认（不写）行为逐字一致 |
| T48_lang_zh_mixed | normal | ✅ | 中文模式里英文写法照旧可用（便于渐进迁移与混写） |
| T49_lang_zh_module | normal | ✅ | 主文件写 language 中文 → 被 引用 的模块继承中文词汇（模块里能写 函数/返回），不用每个模块都写一遍指令 |
| E41_lang_bad_value_err | error | ✅ | language 档位不认识 → 报在指令自己那一行，并给出两档怎么写 |
| E42_lang_in_going_err | error | ✅ | language 写在 GOING 里 → 报错（语言是文件级旋钮，不能中途改） |
| E43_lang_zh_kw_in_en_err | error | ✅ | 英文模式下写中文关键字 → 报错要指路「加一行 language 中文」，而不是让人瞎猜 |
| E44_lang_conflict_err | error | ✅ | 同一文件写了两个不同档位 → 报错（语言是文件级旋钮，只写一次） |
| E45_lang_zh_prefix_in_en_err | error | ✅ | 英文模式下写中文前缀 → 报错要指路「加一行 language 中文」 |
| T50_clib_ok | normal | ✅ | .c/.h 扔进主程序同目录 → 裸名直接调（int / double / char* / void 四种返回都通），不用写 ffi.声明 / ffi.包含 / ffi.链接 |
| T51_clib_str_ok | normal | ✅ | const char* 参数按字符串转（自动脱 const 匹配 char*），空串安全；char* 返回值自动装箱成 PYbook 字符串 |
| E50_clib_arity_err | error | ✅ | C 库函数参数个数对不上 → 编译期拦，并说清签名是从原型自动解析的 |
| E51_clib_missing_err | error | ✅ | C 库函数名拼错 → 报错里直接列出同目录 C 库有哪些函数（别让人瞎猜） |
| T52_lang_zh_phrase_ok | normal | ✅ | 中文模式里 not in 能连写成一个词「不属于」（词法层拆成 非+属于 两个关键字），不必像英文那样写成 not in 两个词 |
| E52_lang_zh_glue_err | error | ✅ | 中文关键字后面直接跟名字（返回数）→ 报错要点破「加空格」，别让人以为中文关键字坏了 |
| T53_scalar_break_ok | normal | ✅ | 圈里 break：跳出时圈末回写不能被跳过（x = 0+1+..+6 = 21，不能少算最后一轮） |
| T54_scalar_float_pre_ok | normal | ✅ | 圈前旧值是浮点：自读取值必须按浮点算（1.5×2×2×2×2 = 24，不能截成 1 算成 16） |
| T55_scalar_boxread_ok | normal | ✅ | 圈里读另一个候选变量：读方要看到当轮的新值（b = 1+2+3+4+5 = 15，不能读到圈前的旧值） |
| T56_scalar_parloop_ok | normal | ✅ | 同一函数里两个并列循环用同一个变量：不能出现 S_ 重复定义（x = 3 + 40 = 43） |
| E53_scalar_overflow_err | error | ✅ | 整数溢出：标量路径的原生加法必须跟 rt_add 一样报错，不能静默回绕 |
| T57_scalar_zero_ok | normal | ✅ | 0 圈：既不读圈前旧值也不装回（x 保持 7） |
