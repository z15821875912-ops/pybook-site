"""VM 后端（终端模式）vs C 后端（原生模式）逐字对拍。

两个后端跑同一个 .pybk，stdout 与退出码必须一字不差。
只放「两个后端都该支持」的程序：VM 明确不支持的（窗口/游戏/网页/ffi/m3/ui 等）
在 pybk_bc.py 里编译期就拒了，不进对拍。

跑法：python -B tests/vm_parity.py
"""
import os
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.stdout.reconfigure(encoding='utf-8')
os.chdir(ROOT)
OUT = os.path.join('build_tmp', 'probe', 'vm_parity')
os.makedirs(OUT, exist_ok=True)
EXE = 'pyvm.exe' if os.name == 'nt' else './pyvm'


def hdr(tag):
    return '@ 测>VM对拍>%s\n' % tag


CASES = []


def case(tag, body, files=None):
    """files 非空 → 多文件用例（包系统）：主文件与附属模块一起放进
    OUT/pkg_<tag>/，这样 引用("lib/助手") 的相对路径正好指向附属模块。"""
    CASES.append((tag, hdr(tag) + body, files))


# ---- 空 字面量 ----
case('空', """GOING:{
vg.e = 空
ns.show("空值=$e")
if(e == 空) { ns.show("相等") }
}STOP
""")

# ---- lambda 当值用 ----
case('lambda值', """GOING:{
vg.平方 = lambda(x) { ret x * x }
vg.r = 平方(3)
ns.show("平方(3)=$r")
vg.r2 = 平方(平方(2))
ns.show("嵌套=$r2")
}STOP
""")

# ---- lambda 回调给库函数（mt.deriv / mt.taylor）----
case('lambda回调', """GOING:{
vg.平方 = lambda(x) { ret x * x }
vg.d = mt.deriv(平方, 2.0)
ns.show("导数=$d")
vg.t = mt.taylor(平方, 1.0, 3)
ns.show("泰勒=$t")
}STOP
""")

# ---- while + continue + break ----
case('while', """GOING:{
vg.i = 0
vg.累加 = 0
while(i < 5) {
vg.累加 = 累加 + i
vg.i = i + 1
if(i == 3) { continue }
if(i == 6) { break }
}
ns.show("累加=$累加")
}STOP
""")

# ---- while 嵌套：break 只跳一层 ----
case('嵌套break', """GOING:{
vg.外 = 0
vg.内 = 0
while(外 < 3) {
vg.外 = 外 + 1
vg.内 = 0
while(内 < 5) {
vg.内 = 内 + 1
if(内 == 3) { break }
}
}
ns.show("外=$外 内=$内")
}STOP
""")

# ---- rm.around 里的 break / continue ----
case('around跳出', """GOING:{
vg.j = 0
rm.around(5) {
vg.j = j + 1
if(j == 2) { continue }
if(j == 4) { break }
}
ns.show("around=$j")
}STOP
""")

# ---- for x in 列表 里的 break / continue ----
case('forin跳出', """GOING:{
vg.表 = [1, 2, 3, 4, 5]
vg.和 = 0
vg.次数 = 0
for x in 表 {
vg.次数 = 次数 + 1
if(x == 2) { continue }
if(x == 4) { break }
vg.和 = 和 + x
}
ns.show("和=$和 次数=$次数")
}STOP
""")

# ---- 可选参数入口：少给也要补空盒 ----
case('可选参数', """GOING:{
vg.平方 = lambda(x) { ret x * x }
vg.d1 = mt.deriv(平方, 3.0)
vg.d2 = mt.deriv(平方, 3.0, 0.001)
ns.show("d1=$d1")
ns.show("d2=$d2")
}STOP
""")

# ---- 对抗：lambda 嵌在函数里 / 双参 / 嵌套跳出 / 空值当参数 ----
case('对抗', """func 取平方(x) {
vg.内嵌 = lambda(y) { ret y * y }
ret 内嵌(x)
}
func 双参(a, b) {
ret a * 10 + b
}
func 加空(v) {
ret v
}
func 回空值() {
ret 空
}
GOING:{
vg.甲 = lambda(x) { ret x + 1 }
vg.乙 = lambda(x) { ret x * 2 }
vg.和 = 乙(3)
ns.show("lambda当值=$和")
vg.和2 = 甲(乙(3))
ns.show("lambda套lambda=$和2")
vg.内 = 取平方(5)
ns.show("函数里的lambda=$内")
vg.双 = 双参(3, 4)
ns.show("双参函数=$双")
vg.双l = lambda(a, b) { ret a - b }
vg.差 = 双l(10, 4)
ns.show("双参lambda=$差")
vg.层 = 0
vg.i = 0
while(i < 3) {
vg.j = 0
for x in [1, 2, 3] {
vg.j = j + 1
if(x == 2) { continue }
if(j == 3) { break }
vg.层 = 层 + 1
}
vg.i = i + 1
}
ns.show("双层跳出=$层")
vg.空传 = 加空(空)
ns.show("空当参数=$空传")
vg.回空 = 回空值()
ns.show("返回空=$回空")
vg.空比 = 0
if(空 == 空) {
vg.空比 = 1
}
ns.show("空相等=$空比")
}STOP
""")

# ---- 既有能力顺带回归：函数/递归/列表推导 ----
case('既有能力', """func 阶乘(n) {
if(n <= 1) { ret 1 }
ret n * 阶乘(n - 1)
}
GOING:{
vg.f = 阶乘(6)
ns.show("阶乘=$f")
vg.表 = [1, 2, 3, 4]
vg.偶 = [x * 2 for x in 表 if x > 1]
ns.show("偶=$偶")
}STOP
""")


# ---- 异常：try/catch 接住运行时错 ----
case('trycatch', """GOING:{
try {
    vg.a = 1 / 0
} catch e {
    ns.show("接住=$e")
}
ns.show("继续")
}STOP
""")

# ---- 异常：finally 三条路都跑 ----
case('finally', """GOING:{
try {
    ns.show("A")
} finally {
    ns.show("B")
}
try {
    vg.x = 1 / 0
} catch e {
    ns.show("C")
} finally {
    ns.show("D")
}
try {
    try {
        vg.y = 1 / 0
    } finally {
        ns.show("E")
    }
} catch e {
    ns.show("F")
}
ns.show("G")
}STOP
""")

# ---- 异常：throw 抛新错 + 类型标签 ----
case('throw', """GOING:{
try {
    throw "自己抛的"
} catch e {
    ns.show("接到=", te.包含(e, "自己抛的"))
}
try {
    throw "带类型", "甲类"
} catch e, t {
    ns.show("类型=", t)
}
ns.show("完")
}STOP
""")

# ---- 异常：按类型捕获 / 类型不符往外抛 / 重抛 ----
case('错误类型', """GOING:{
try {
    throw "甲", "甲类"
} catch e:甲类 {
    ns.show("接住甲")
}
try {
    try {
        throw "乙", "乙类"
    } catch e:甲类 {
        ns.show("不该到")
    }
} catch e, t {
    ns.show("外层=", t)
}
try {
    try {
        throw "原始", "原类"
    } catch e {
        throw
    }
} catch e, t {
    ns.show("重抛=", t, te.包含(e, "原始"))
}
try {
    try {
        throw "内层"
    } catch e {
        throw "新错"
    } finally {
        ns.show("F")
    }
} catch e {
    ns.show("外=", te.包含(e, "新错"))
}
ns.show("完")
}STOP
""")


# ---- 包系统：子目录模块带命名空间（同名函数不再撞名）----
case('包系统', """引用("lib/助手")
引用("lib/工具")
GOING:{
vg.a = 助手_加(2,3)
vg.b = 工具_加(2,3)
ns.show("助手=$a 工具=$b")
}STOP
""", files={
    'lib/助手.pybk': 'func 加(a,b) {\n    ret a + b\n}\n',
    'lib/工具.pybk': 'func 加(a,b) {\n    ret a * b\n}\n',
})


def run(cmd, **kw):
    env = dict(os.environ)
    env['PYTHONUTF8'] = '1'
    env['PYTHONIOENCODING'] = 'utf-8'
    return subprocess.run(cmd, capture_output=True, text=True, encoding='utf-8',
                          errors='replace', env=env, cwd=ROOT, timeout=300, **kw)


def c_backend(path):
    p = run([sys.executable, 'pybk_main.py', path])
    return p.returncode, p.stdout, p.stderr


def vm_backend(path, tag):
    pybc = os.path.join(OUT, 'vp_%s.pybc' % tag)
    p = run([sys.executable, 'pybk_build.py', path, pybc])
    if p.returncode != 0:
        return None, p.stdout, p.stderr
    q = run([EXE, pybc])
    return q.returncode, q.stdout, q.stderr


def main():
    ok = 0
    bad = []
    print('用例                 C后端  VM后端  判定')
    for tag, src, files in CASES:
        if files:
            d = os.path.join(OUT, 'pkg_%s' % tag)
            os.makedirs(d, exist_ok=True)
            for rel, content in files.items():
                p = os.path.join(d, *rel.replace('\\', '/').split('/'))
                os.makedirs(os.path.dirname(p), exist_ok=True)
                with open(p, 'w', encoding='utf-8', newline='\n') as f:
                    f.write(content)
            path = os.path.join(d, 'main.pybk')
        else:
            path = os.path.join(OUT, 'vp_%s.pybk' % tag)
        with open(path, 'w', encoding='utf-8') as f:
            f.write(src)
        crc, cout, cerr = c_backend(path)
        vrc, vout, verr = vm_backend(path, tag)
        if vrc is None:
            bad.append((tag, 'VM 编译失败', verr[-300:]))
            print('%-18s %-6s %-7s %s' % (tag, crc, '编译失败', '❌'))
            continue
        # C 后端 gcc 编译期报错也会写 stderr；这里只比 stdout 与退出码
        if cout == vout and crc == vrc:
            ok += 1
            print('%-18s %-6s %-7s ✅' % (tag, crc, vrc))
        else:
            detail = ('C: rc=%s out=%r\n    VM: rc=%s out=%r' %
                      (crc, cout[-300:], vrc, vout[-300:]))
            bad.append((tag, '输出不一致', detail))
            print('%-18s %-6s %-7s ❌' % (tag, crc, vrc))
    print()
    for tag, why, detail in bad:
        print('--- %s：%s' % (tag, why))
        print(detail)
    print('VM↔C 逐字一致：%d/%d' % (ok, len(CASES)))
    return 0 if not bad else 1


if __name__ == '__main__':
    sys.exit(main())
