# -*- coding: utf-8 -*-
"""PYbook v2 编译器测试 Runner。

用法（在工作目录 C:\\Users\\zhuli\\Desktop\\pybook 下，或任意目录均可，脚本自己定位根目录）：
    python tests\\run_tests.py            # 生成全部 .pybk 并逐个运行、比对
    python tests\\run_tests.py --only T03_list_ok,T10_vc_ok   # 只跑指定用例
    python tests\\run_tests.py --list      # 只列出用例不运行

流程：把 cases.py 里的每个用例物化成 tests\\<id>.pybk（尾部追加 "# 预期" 注释块），
然后逐个执行
    <python> pybk_main.py tests\\<id>.pybk   （cwd = 仓库根，剔除 COLUMNS 环境变量）
比对语义：out / err 全串精确比对；err_contains 是大小写不敏感的「必须包含」子串列表。
带三段式的报错用例用 err_contains 锁「首行原文（含行号）+ 有没有三段式」，不锁措辞
——报错建议是会反复改写的，用 err 锁死会每改一句就坏一片，真回归被噪音淹没。

并与预期 stdout / stderr / 退出码严格比对，结果写入 tests\\results.md。
"""
import argparse
import glob
import os
import shutil
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
from cases import CASES  # noqa: E402

PY = sys.executable


def _sanitize(comment: str) -> str:
    """注解注释里的 ASCII 括号转全角：注释虽不产生 Token，但未闭合的
    ns.show( 会用 scan_raw 在【原始源码】里找下一个 )，ASCII 括号会提前截住它。"""
    for a, b in (("(", "（"), (")", "）"), ("{", "｛"), ("}", "｝"),
                 ("[", "［"), ("]", "］")):
        comment = comment.replace(a, b)
    return comment


def _atomic_replace(tmp_path, path, tries=6):
    """原子替换，带重试。

    Windows 上 os.replace 到一个正被别的进程打开的文件会抛
    PermissionError [WinError 5]（IDE / 索引器 / 看门狗都可能瞬时持有）。
    实测 2026-10-24 的全量回归就是在 materialize 阶段被这个打断的：
    用例文件本身可读可写可删，纯粹是瞬时占用。
    → 退避重试，而不是让整轮回归挂在第一例上。"""
    last = None
    for i in range(tries):
        try:
            os.replace(tmp_path, path)
            return
        except PermissionError as e:
            last = e
            if i + 1 < tries:
                time.sleep(0.15 * (i + 1))
    raise last


def materialize(case):
    """把用例写成 .pybk，尾部追加纯注释的预期块（注释不产生 Token）。

    带 files 的用例（包系统那种多文件用例）：主文件与附属模块一起放进
    build_tmp/pkgtests/<id>/，这样 引用("lib/助手") 的相对路径正好指向附属模块。

    err / err_contains 里的 {EOF} 会被替换成生成文件的 EOF 行号——
    因为前端按物理行计数，文件尾注释会把“到文件尾才发现的错误”的行号推大
    （这正是 bug B5 的行为，测试直接把它固定下来）。"""
    src = case["src"]
    body = src if src.endswith("\n") else src + "\n"
    lines = [
        "",
        "# " + "=" * 64,
        "# 用例 " + case["id"] + " 预期：" + _sanitize(case.get("expect", "")),
        "# 退出码: " + str(case.get("exit", 0)),
    ]
    if "out" in case:
        lines.append("# stdout（转义显示）: " + _sanitize(ascii(case["out"])))
    if "err" in case:
        lines.append("# stderr（转义显示）: " + _sanitize(ascii(case["err"])))
    for s in case.get("err_contains", []):
        lines.append("# stderr 须包含: " + _sanitize(ascii(s)))
    eof_line = body.count("\n") + len(lines) + 1   # 最后一行之后即 EOF 所在行

    files = case.get("files")
    if files:
        pkgdir = os.path.join(ROOT, "build_tmp", "pkgtests", case["id"])
        os.makedirs(pkgdir, exist_ok=True)
        for rel, content in files.items():
            p = os.path.join(pkgdir, *rel.replace("\\", "/").split("/"))
            d = os.path.dirname(p)
            if d:
                os.makedirs(d, exist_ok=True)
            tmp_p = p + f".tmp{os.getpid()}"
            with open(tmp_p, "w", encoding="utf-8", newline="\n") as f:
                f.write(content if content.endswith("\n") else content + "\n")
            os.replace(tmp_p, p)
        path = os.path.join(pkgdir, "main.pybk")
        main_rel = os.path.relpath(path, ROOT).replace("\\", "/")
    else:
        path = os.path.join(HERE, case["id"] + ".pybk")
        main_rel = "tests/" + case["id"] + ".pybk"

    # 原子写：先写临时文件再 os.replace。
    # 两个测试进程同时跑时，直接 open(path, "w") 会把对方进程正在读的
    # 用例文件截断，对方那一例读到半截源码 → 编译失败（实测约 1/25 轮偶发）。
    tmp_path = path + f".tmp{os.getpid()}"
    with open(tmp_path, "w", encoding="utf-8", newline="\n") as f:
        f.write(body)
        f.write("\n".join(_sanitize(x).replace("{EOF}", str(eof_line)) for x in lines) + "\n")
    _atomic_replace(tmp_path, path)

    adjusted = dict(case)
    adjusted["_main"] = main_rel
    if "err" in case:
        adjusted["err"] = case["err"].replace("{EOF}", str(eof_line))
    if "err_contains" in case:
        adjusted["err_contains"] = [s.replace("{EOF}", str(eof_line))
                                    for s in case["err_contains"]]
    return adjusted


def run_case(case):
    env = {k: v for k, v in os.environ.items() if k != "COLUMNS"}
    # 关掉 exe 缓存：测试要的是「源码 → 结果」可复现，不该被上次跑剩的缓存影响；
    # 而且缓存修剪在安全删除受限的环境里会把整个进程打死（见 pybk_code.NO_EXE_CACHE）。
    env["PYBOOK_NO_CACHE"] = "1"
    # 用例可以自带环境变量（目前主要是 PYBOOK_GPU_DISABLE，用来在有卡的机器上
    # 验「device gpu 探测不到卡必须报错」这条语义）。
    env.update(case.get("env", {}))
    # OSError 也要接住：exe 被并发跑的测试收走（sweep）、或杀毒软件短暂锁住时，
    # subprocess.run 会抛 FileNotFoundError / PermissionError，不是用例本身的错。
    last = None
    for attempt in range(3):
        try:
            return subprocess.run(
                [PY, "pybk_main.py", case.get("_main") or ("tests/" + case["id"] + ".pybk")],
                cwd=ROOT, env=env,
                input=case.get("stdin"),
                stdin=None if case.get("stdin") else subprocess.DEVNULL,
                capture_output=True, text=True, encoding="utf-8", errors="replace",
                timeout=120,
            )
        except subprocess.TimeoutExpired:
            raise
        except OSError as e:
            last = e
            time.sleep(0.4 * (attempt + 1))
    raise last


def check(case, p):
    """返回 (通过?, 问题列表)。stdout/stderr 统一按 \n 比对。"""
    problems = []
    out = p.stdout.replace("\r\n", "\n")
    err = p.stderr.replace("\r\n", "\n")
    if "out" in case and out != case["out"]:
        problems.append("stdout 不一致\n  期望: " + ascii(case["out"])
                        + "\n  实际: " + ascii(out))
    if "err" in case and err != case["err"]:
        problems.append("stderr 不一致\n  期望: " + ascii(case["err"])
                        + "\n  实际: " + ascii(err))
    for s in case.get("err_contains", []):
        if s.lower() not in err.lower():
            problems.append("stderr 缺少子串: " + ascii(s) + "\n  实际: " + ascii(err))
    want_exit = case.get("exit", 0)
    if p.returncode != want_exit:
        problems.append(f"退出码不一致 期望 {want_exit} 实际 {p.returncode}")
    return (not problems), problems


def fmt_expected(case) -> str:
    bits = [f"退出码={case.get('exit', 0)}"]
    if "out" in case:
        bits.append("stdout=" + ascii(case["out"]))
    if "err" in case:
        bits.append("stderr=" + ascii(case["err"]))
    if case.get("err_contains"):
        bits.append("stderr包含=" + " && ".join(ascii(s) for s in case["err_contains"]))
    return "  ".join(bits)


def sweep_intermediates():
    """把跑测试留下的 out_*.c / app_*.exe 收进 build_tmp/，别堆在仓库根。

    编译器故意不自己删这两样（安全删除受限的环境里 os.remove 会 fail-closed，
    把程序打死并把报错喷到 stderr，污染精确比对）。这里用 shutil.move（改名，
    不是删除）一次性收走，既保住 stderr 干净，也不让仓库根越跑越脏。

    只收「比现在老 120 秒以上」的：另一条测试进程正在跑时，它的 exe 才刚生成
    几秒，这时候把它收走会让对方那条用例失败（实测偶发）。上一轮留下的
    旧文件下一轮就会被收掉，不影响清理效果。
    """
    dst = os.path.join(ROOT, "build_tmp")
    cutoff = time.time() - 120
    moved = 0
    for pat in ("out_*.c", "app_*.exe"):
        for p in glob.glob(os.path.join(ROOT, pat)):
            try:
                if os.path.getmtime(p) > cutoff:
                    continue
                os.makedirs(dst, exist_ok=True)
                shutil.move(p, os.path.join(dst, os.path.basename(p)))
                moved += 1
            except OSError:
                pass
    return moved


def has_nvidia_gpu():
    """这台机器有没有可用的 NVIDIA GPU（device gpu 的前提）。

    跟 C 运行时用同一条路：LoadLibrary("nvcuda.dll") + cuInit + cuDeviceGetCount。
    只用于决定「needs: gpu 的用例要不要跑」，判错的后果最多是跳过一个用例，
    不会掩盖任何真失败。
    """
    if os.environ.get("PYBOOK_TEST_NO_GPU"):
        return False
    try:
        import ctypes
        dll = ctypes.WinDLL("nvcuda.dll")
    except OSError:
        return False
    try:
        if dll.cuInit(0) != 0:
            return False
        n = ctypes.c_int(0)
        return dll.cuDeviceGetCount(ctypes.byref(n)) == 0 and n.value > 0
    except (AttributeError, OSError):
        return False


def skip_reason(case):
    """返回跳过原因；None = 这条要跑。"""
    need = case.get("needs")
    if need == "gpu" and not has_nvidia_gpu():
        return "本机没有可用的 NVIDIA GPU"
    return None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--only", default="", help="逗号分隔的用例 id")
    ap.add_argument("--list", action="store_true")
    args = ap.parse_args()

    only = {s.strip() for s in args.only.split(",") if s.strip()}
    todo = [c for c in CASES if not only or c["id"] in only]
    if args.list:
        for c in todo:
            print(f"{c['id']:26s} [{c['kind']:7s}] {c.get('expect','')}")
        print(f"共 {len(todo)} 例")
        return 0

    results_tmp = []
    for c in todo:
        results_tmp.append(materialize(c))

    results = []
    t0 = time.time()
    for i, c in enumerate(results_tmp, 1):
        why = skip_reason(c)
        if why:
            results.append((c, None, [why]))
            print(f"[{i:>2}/{len(todo)}] 跳过  {c['id']}  （{why}）", flush=True)
            continue
        try:
            p = run_case(c)
            ok, problems = check(c, p)
        except subprocess.TimeoutExpired:
            ok, problems = False, ["运行超时（>120s）"]
        results.append((c, ok, problems))
        print(f"[{i:>2}/{len(todo)}] {'通过' if ok else '失败'}  {c['id']}", flush=True)

    elapsed = time.time() - t0
    passed = sum(1 for _c, ok, _p in results if ok)
    skipped = sum(1 for _c, ok, _p in results if ok is None)
    failed = [r for r in results if r[1] is False]

    with open(os.path.join(HERE, "results.md"), "w", encoding="utf-8", newline="\n") as f:
        f.write("# PYbook v2 自动比对结果\n\n")
        f.write(f"- 用例总数：{len(results)}　通过：{passed}　失败：{len(failed)}　跳过：{skipped}　耗时 {elapsed:.1f}s\n")
        f.write("- 运行方式：`%s pybk_main.py tests/<用例>.pybk`（cwd=仓库根，剔除 COLUMNS）\n\n" % PY)
        f.write("## 汇总\n\n| 用例 | 类型 | 结果 | 预期说明 |\n|---|---|---|---|\n")
        for c, ok, _p in results:
            mark = "⏭️" if ok is None else ("✅" if ok else "❌")
            f.write(f"| {c['id']} | {c['kind']} | {mark} | {c.get('expect','')} |\n")
        if skipped:
            f.write("\n## 跳过\n\n")
            for c, ok, problems in results:
                if ok is None:
                    f.write(f"- `{c['id']}`：{problems[0]}\n")
        if failed:
            f.write("\n## 失败详情\n\n")
            for c, _ok, problems in failed:
                f.write(f"### {c['id']}\n\n- 预期：{fmt_expected(c)}\n")
                for p in problems:
                    f.write(f"- {p}\n")
                f.write("\n")

    print(f"\n合计 {len(results)} 例：通过 {passed}，失败 {len(failed)}，跳过 {skipped}，耗时 {elapsed:.1f}s")
    if failed:
        print("失败用例：", ", ".join(c["id"] for c, _o, _p in failed))
        print("详情见 tests\\results.md")
    swept = sweep_intermediates()
    if swept:
        print(f"已把 {swept} 个中间产物收进 build_tmp/（out_*.c / app_*.exe）")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
