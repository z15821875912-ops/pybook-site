# _patch_convk_block.py —— 让内核台 _convk.c 按 PTX 头注释里的真实 blockDim 启动。
#
# 为什么要改：launch 写死了 blockDim(16,16)。生成器一改 BX/BY，
# 台子启动的线程数就跟内核对不上 —— 内核里 oh_base = ctaid.y*TILE_OH + tid.y*TSY，
# 只启动 16 行线程时，TILE_OH=64 的配置就只算了前一半的行：
# 表现为「快得离谱 + 后半段输出全是 0」，很容易被误判成「这个配置更快」。
# 头注释里本来就写着 "block = 16x32 = 512 threads"，直接读。
import io, os

P = "_convk.c"
d = io.open(P, encoding="utf-8", newline="").read()
changed = []

old = """    int TO = 8;                       /* 每线程几个输出通道（内核参数） */
    int TILE_OH = 32, TILE_OW = 32;   /* 一块覆盖多少输出行/列 */
"""
new = """    int TO = 8;                       /* 每线程几个输出通道（内核参数） */
    int TILE_OH = 32, TILE_OW = 32;   /* 一块覆盖多少输出行/列 */
    int BLK_X = 16, BLK_Y = 16;       /* blockDim（必须跟内核一致，否则少算活） */
"""
if d.count(old) != 1:
    raise SystemExit("锚点 ① 命中 %d 次" % d.count(old))
d = d.replace(old, new)
changed.append("BLK 变量")

old = """        int bx = 0, by = 0, to = 0, toh = 0, tow = 0;
        if (parse_tile(ptx, &bx, &by, &to, &toh, &tow)) {
            TO = to; TILE_OH = toh; TILE_OW = tow;
            printf("分块：block %dx%d，每线程 %d 通道，一块覆盖 %d oh x %d ow\\n",
                   bx, by, TO, TILE_OH, TILE_OW);
        } else {
            printf("分块：读不到头注释，用默认 TO=%d tile %dx%d\\n", TO, TILE_OH, TILE_OW);
        }
"""
new = """        int bx = 0, by = 0, to = 0, toh = 0, tow = 0;
        if (parse_tile(ptx, &bx, &by, &to, &toh, &tow)) {
            TO = to; TILE_OH = toh; TILE_OW = tow; BLK_X = bx; BLK_Y = by;
            printf("分块：block %dx%d，每线程 %d 通道，一块覆盖 %d oh x %d ow\\n",
                   bx, by, TO, TILE_OH, TILE_OW);
        } else {
            printf("分块：读不到头注释，用默认 TO=%d tile %dx%d block %dx%d\\n",
                   TO, TILE_OH, TILE_OW, BLK_X, BLK_Y);
        }
"""
if d.count(old) != 1:
    raise SystemExit("锚点 ② 命中 %d 次" % d.count(old))
d = d.replace(old, new)
changed.append("读 blockDim")

old = """                CK(p_cuLaunchKernel(fn, gx, gy, gz, 16, 16, 1, 0, NULL, params, NULL));"""
new = """                CK(p_cuLaunchKernel(fn, gx, gy, gz, (unsigned)BLK_X, (unsigned)BLK_Y, 1,
                                    0, NULL, params, NULL));"""
if d.count(old) != 1:
    raise SystemExit("锚点 ③ 命中 %d 次" % d.count(old))
d = d.replace(old, new)
changed.append("launch blockDim")

tmp = P + ".tmpfix"
with io.open(tmp, "w", encoding="utf-8", newline="") as f:
    f.write(d)
os.replace(tmp, P)
print("_convk.c 改了：%s" % (", ".join(changed)))
