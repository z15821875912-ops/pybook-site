/* _poolchk.c —— 池化（maxpool / avgpool）生产入口的正确性对拍
 *
 * 池化这组之前从来没编译通过：模块里只有 maxpool、没有 avgpool，
 * gpu_pool_ready() 恒为 0，所以池化一直走 CPU。这台专门验「现在能上卡了、
 * 而且算得对」。
 *
 * 接口：gpu_pool_f32(x, out, xN, outN, W, OH, OW, KH, KW, S, is_avg)
 *   x   : (H, W) row-major
 *   out : (OH, OW) row-major
 *
 * 编译：gcc _poolchk.c pybook_gpu.c -o _poolchk.exe -O2 -I. -lwinmm -lm
 */
#include "pybook_gpu.h"
#include "pybook_rt.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <windows.h>

void rt_die(const char *fmt, ...) { (void)fmt; fputs("rt_die(stub)\n", stderr); exit(2); }
Value rt_str(const char *s) { (void)s; Value v; memset(&v, 0, sizeof v); return v; }

static unsigned g_seed = 20240924u;
static double frand(void)
{
    g_seed = g_seed * 1103515245u + 12345u;
    return (double)((g_seed >> 9) & 0xFFFF) / 65536.0 - 0.5;
}

int main(void)
{
    /* H  W  KH KW S */
    static const int def[][5] = {
        {  28,  28, 2, 2, 2 },
        {  32,  32, 3, 3, 1 },
        {  64,  64, 2, 2, 2 },
        {  13,  17, 3, 3, 1 },
        {  56,  56, 4, 4, 4 },
        {  9,   9, 3, 3, 1 },
        {  64,  32, 3, 3, 2 },
        {  15,  15, 5, 5, 1 },
    };
    int nsh = (int)(sizeof(def) / sizeof(def[0]));
    int i, bad = 0;

    if (!gpu_available()) { printf("GPU 不可用：%s\n", gpu_device_name()); return 1; }
    printf("设备：%s\n\n", gpu_device_name());
    printf("%-22s | %-7s | %10s | %10s | %s\n",
           "形状 H W KH KW S", "池化", "最大相对差", "超差个数", "结论");
    printf("------------------------+---------+------------+------------+--------\n");

    for (i = 0; i < nsh; i++) {
        int H = def[i][0], W = def[i][1], KH = def[i][2], KW = def[i][3], S = def[i][4];
        int OH = (H - KH) / S + 1, OW = (W - KW) / S + 1;
        size_t nx = (size_t)H * W, no = (size_t)OH * OW;
        double *x = (double *)malloc(nx * sizeof(double));
        double *y = (double *)malloc(no * sizeof(double));
        double *ref = (double *)malloc(no * sizeof(double));
        size_t j;
        int oh, ow, kh, kw, a;
        double maxrel = 0;
        int over = 0;

        if (!x || !y || !ref) { printf("host 内存不足\n"); return 1; }
        for (j = 0; j < nx; j++) x[j] = (double)(float)frand();   /* 生产路径是 f32 */

        for (a = 0; a < 2; a++) {      /* 0 = maxpool, 1 = avgpool */
            int is_avg = a;
            for (oh = 0; oh < OH; oh++)
                for (ow = 0; ow < OW; ow++) {
                    double s = 0, best = x[(size_t)(oh * S) * W + (ow * S)];
                    for (kh = 0; kh < KH; kh++)
                        for (kw = 0; kw < KW; kw++) {
                            double v = x[(size_t)(oh * S + kh) * W + (ow * S + kw)];
                            if (v > best) best = v;
                            s += v;
                        }
                    ref[(size_t)oh * OW + ow] = is_avg ? s / ((double)KH * KW) : best;
                }
            memset(y, 0, no * sizeof(double));
            if (!gpu_pool_f32(x, y, (int)nx, (int)no, W, OH, OW, KH, KW, S, is_avg)) {
                printf("gpu_pool_f32 失败：%s\n", gpu_last_error());
                return 1;
            }
            maxrel = 0;
            for (j = 0; j < no; j++) {
                double mag = 0, d = fabs(y[j] - ref[j]), rel;
                for (kh = 0; kh < KH; kh++)
                    for (kw = 0; kw < KW; kw++)
                        mag += fabs(x[(size_t)((j / (size_t)OW) * S + kh) * W
                                    + ((j % (size_t)OW) * S + kw)]);
                rel = (mag > 0) ? d / mag : d;
                if (rel > maxrel) maxrel = rel;
                if (rel > 1e-5) over++;
            }
            printf("%3dx%-3d %dx%d S%d | %-7s | %10.2e | %10d | %s\n",
                   H, W, KH, KW, S, is_avg ? "avgpool" : "maxpool",
                   maxrel, over, over ? "错!" : "对");
            if (over) bad++;
        }
        free(x); free(y); free(ref);
    }
    printf("\n超差项：%d / %d\n", bad, nsh * 2);
    return 0;
}
