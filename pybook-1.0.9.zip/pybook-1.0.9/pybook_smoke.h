/* Smokeroor：实战型安全检查（smoke.*，全英文 API）
 * 一句话：一条命令体检安全机制，红绿灯告诉你哪里不安全。
 * 所有函数都是"只读查询"，不调用就零开销；不修改任何状态。
 * 实现见 pybook_smoke.c；查询底层状态走 pybook_rt.h 的 rt_q_* 接口。 */
#ifndef PYBOOK_SMOKE_H
#define PYBOOK_SMOKE_H

#include "pybook_rt.h"

/* ---- A. 变量级 ---- */
Value rt_smoke_check(Value v);        /* ["OK"] 或 ["DELETED"|"LOCKED"|"DANGLING"] */
Value rt_smoke_deleted(Value v);      /* 1/0：已 del 或悬垂别名 */
Value rt_smoke_locked(Value v);       /* 1/0：被 del/gold 锁定 */
Value rt_smoke_type(Value v);         /* 类型名：INT/FLT/STR/LIST/DICT/OBJ/... */

/* ---- B. 内存级 ---- */
Value rt_smoke_mem(void);             /* [存活单元, 近似字节, 模式] */
Value rt_smoke_leak(void);            /* 强制 GC，返回回收的单元数（差大=疑似泄漏）*/
Value rt_smoke_dangling(void);        /* @self 登记表 [条数, 容量] */
Value rt_smoke_roots(void);           /* GC 根数 */
Value rt_smoke_heap(void);            /* 体检摘要 [错误数, 悬垂, 根数, 模式, 字节] */
Value rt_smoke_gc_stats(void);        /* 知命可观测：返回 dict（live/bytes/pause_ms/promoted/各意图存活数） */
Value rt_smoke_frame_end(void);       /* 知命帧边界对齐：引擎帧末调用，立即触发相位回收 */

/* ---- C. 运行时健康 ---- */
Value rt_smoke_errors(void);          /* rt_die 触发次数 */
Value rt_smoke_mode(void);            /* 模式名 normal/self/refcount/arena/gc/gen */
Value rt_smoke_selftest(void);        /* [错误数, 悬垂数, 根数, 模式]（摘要，非全量自检）*/

/* ---- D. 断言（冒烟测试用）---- */
Value rt_smoke_expect(Value cond, Value msg);   /* 软：假则打 ✗ 并计数，不中断 */
Value rt_smoke_require(Value cond, Value msg);  /* 硬：假则 rt_die 立即中断 */

/* 断言统计（runner 可读） */
long long rt_smoke_expect_fails(void);

#endif /* PYBOOK_SMOKE_H */
