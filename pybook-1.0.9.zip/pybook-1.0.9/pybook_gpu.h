/* pybook_gpu.h —— PYbook GPU 后端（NVIDIA CUDA，动态加载）
 *
 * 设计要点（都是踩过坑之后定的，别随便改）：
 *   · 不链 cuda.lib、不 include cuda.h。LoadLibrary("nvcuda.dll") + GetProcAddress
 *     取函数指针 —— 没装 NVIDIA 驱动的机器照样编译、照样链接、照样跑 CPU 通路，
 *     保住 PYbook「单 exe 拷走就能跑」的定位。
 *   · kernel 以手写 PTX 字符串内嵌，驱动自己编译。不需要 nvcc / NVRTC /
 *     CUDA Toolkit —— 整个 GPU 通路零构建期依赖。
 *   · 显存 API 必须取 *_v2 版本化符号（cuMemAlloc_v2 等），用旧名会一路报
 *     CUDA 201 invalid device context，很有迷惑性（context 明明是好的）。
 *
 * 手写 PTX 的四个坑（详见 _ptx_tiled.inc 顶部）：
 *   1. PTX 只认 // 行注释且只收 ASCII；C 风格的块注释一旦混进 PTX 字符串，
 *      整份编译失败，ptxas 一个字都不说，只回 CUDA 218。
 *   2. %ntid.x 不能直接当 mul 的操作数，要先 mov 进普通 .b32 寄存器。
 *   3. mul.wide.u32 的第二个操作数不能直接用立即数 —— 会静默算错，不报错。
 *   4. %ctaid 是块编号，%tid 才是块内线程编号；全局坐标自己算。
 */
#ifndef PYBOOK_GPU_H
#define PYBOOK_GPU_H

#ifdef __cplusplus
extern "C" {
#endif

/* 懒探测：首次调用时真正去问驱动。没卡/没驱动/驱动太老都返回 0。 */
int         gpu_probe(void);
int         gpu_available(void);
const char *gpu_device_name(void);      /* 没卡时给一句说明，不返回 NULL */
int         gpu_driver_version(void);    /* cuDriverGetVersion 的原值，0 = 未探测 */
const char *gpu_last_error(void);        /* 最近一次 gpu_sgemm_f32 失败的原因 */

/* device gpu 但探测失败时的三段式报错（由 pybook_rt.c 的 rt_device_set 调） */
void        gpu_die_unavailable(void);

/* sgemm：A(MxK) * B(KxN) -> C(MxN)，卡上按 float32 算。
 * 三个指针都是 double* —— PYbook 张量统一用 double 缓冲存，转 float32 无损
 * （调用方保证三个张量都是 TENSOR_F32）。
 * 要求 N 和 K 都能被 4 整除（float4 载入要 16 字节对齐）；M 不限，
 * 边界由 kernel 内部钳位加载 + 谓词存储处理。成功返回 1，失败返回 0
 * （原因见 gpu_last_error，调用方负责报错/回退）。 */
int         gpu_sgemm_f32(const double *A, const double *B, double *C,
                          int M, int N, int K);

/* 路由计划（只读，不改任何状态）：给定 M/N/K，问会选哪个 sgemm kernel。
 * kernel_id: 0=sgemm 1=sgemm_shared 2=sgemm_8x8；-1 = 设备信息不全（退回旧阈值）。
 * blocks/waves = 选中那个 kernel 的块数与波数（波数 = 块数 / (SM数 × 每SM驻留数)）。
 * 返回 1 = 有路由计划；0 = 退回旧阈值。供测试与诊断用。 */
int         gpu_route_plan(int M, int N, int K, int *kernel_id, int *blocks, int *waves);

/* 够不够格走 GPU：小于这个规模，搬运+启动开销会盖过并行收益（实测 16x16x16=4096） */
#define GPU_DOT_MIN_MAC   65536L

/* conv2d 内核是否编译成功（没成功时调用方应降级 CPU，不堵通路） */
int         gpu_conv_ready(void);

/* 池化内核（max+avg 两个都在）是否编译成功；不在则调用方降级 CPU */
int         gpu_pool_ready(void);

/* 池化上卡：x 摊平 (H, W)、out 写回 (OH, OW)；is_avg 选 avgpool/maxpool。
 * 成功返回 1，失败返回 0（gpu_last_error）。 */
int         gpu_pool_f32(const double *x, double *out, int xN, int outN,
                         int W, int OH, int OW, int KH, int KW, int S,
                         int is_avg);

/* conv2d：单精度直接卷积（互相关，pad=0）。
 * x 按 (I*H, W) 摊平、k 按 (O, I*KH*KW)、out 写回 (O*OH, OW)，指针都是 double*
 * （F32 张量缓冲，值可被 float32 精确表示）。标量载入内核，无对齐要求。
 * 成功返回 1，失败返回 0（原因见 gpu_last_error；调用方决定回退还是报错）。 */
/* 上一次 conv2d 内核耗时（毫秒）；没量过是 -1 */
double      gpu_last_kernel_ms(void);

int         gpu_conv2d_f32(const double *x, const double *k, double *out,
                           int H, int W, int I, int O, int KH, int KW,
                           int OH, int OW, int S, int N);

/* conv2d 上卡门槛：O·OH·OW·I·kh·kw 达到才值得过卡（与 GPU_DOT_MIN_MAC 同哲学） */
#define GPU_CONV_MIN_MAC  65536L

#ifdef __cplusplus
}
#endif
#endif /* PYBOOK_GPU_H */