# -*- coding: utf-8 -*-
# _embed_shared_patch.py —— 把 shared tiling kernel 嵌进 pybook_gpu.c（第一跳落地）
#
# 做法（关键决策）：以 build_tmp 旁的 _ptx_PTX_*.ptx 文件为唯一真相源，
# 整体替换 pybook_gpu.c 里的 C 字符串 PTX_BODY。理由：文件版已在 1060 上
# 全尺寸对拍验证过（_gputile.exe 跑的就是它），C 字符串版与文件版一旦
# 不一致，就会出现「改的文件没生效、测的是旧 kernel」——这个坑 _gputile.c
# 的头部注释里记着，不能再踩。
#
# 补丁清单（每处断言 count==1）：
#   1. PTX_BODY -> PTX_BODY_4X4（内容整体替换为 4X4.ptx 文件版，剥掉 .version 头三行）
#   2. 新增 PTX_BODY_SHARED（SHARED.ptx 文件版，同样剥头）
#   3. compile_sgemm：一个模块两个 entry（sgemm + sgemm_shared），
#      shared 取不到就降级全走 4x4（g_fn_sh=NULL），不堵死 GPU 通路
#   4. g_fn_sh 声明
#   5. launch 路由：N >= 256 走 shared，否则 4x4（实测分界：N>=256 六个用例全赢，
#      N<256 四个全输——bar.sync 串行化 + 低 occupancy 在小矩阵上是净亏）
#   6. img[8192] -> img[32768]（两个 kernel 合计约 20KB，8KB 必溢出）
#   7. 头部 C 注释块更新为双 kernel 描述
import io, re, sys

SRC = "pybook_gpu.c"
s = io.open(SRC, encoding="utf-8").read()

def rep(label, old, new):
    n = s.count(old)
    if n != 1:
        sys.stderr.write("FAIL [%s] count=%d\n" % (label, n))
        sys.exit(1)
    globals()["s"] = s.replace(old, new, 1)
    print("ok  " + label)

# ---------- 读两个 .ptx 真相源，剥掉 .version/.target/.address_size 头 ----------
def load_ptx(path):
    t = io.open(path, encoding="ascii").read()
    lines = t.split("\n")
    assert lines[0].startswith(".version"), lines[0]
    assert lines[1].startswith(".target"), lines[1]
    assert lines[2].startswith(".address_size"), lines[2]
    body = "\n".join(lines[3:]).lstrip("\n")
    if not body.endswith("\n"):
        body += "\n"
    return body

ptx_4x4 = load_ptx("_ptx_PTX_4X4.ptx")
ptx_sh = load_ptx("_ptx_PTX_SHARED.ptx")

# ---------- 核对现有 C 字符串版与 4X4.ptx 是否一致（不一致就以文件版为准，打印说明） ----------
m = re.search(r'static const char \*PTX_BODY =\n(.*?)\n\s*"\}";\n', s, re.S)
if not m:
    sys.stderr.write("FAIL: 找不到 PTX_BODY 定义\n"); sys.exit(1)
lits = re.findall(r'"((?:[^"\\]|\\.)*)"', m.group(1))
old_ptx = "".join(lits).replace("\\n", "\n").replace('\\"', '"').replace("\\\\", "\\")
if old_ptx.strip() != ptx_4x4.strip():
    print("note: C 字符串版与 _ptx_PTX_4X4.ptx 不一致，以文件版为准整体替换")
else:
    print("note: C 字符串版与 _ptx_PTX_4X4.ptx 一致")

# ---------- PTX 文本 -> C 字符串字面量 ----------
def to_cstr(ptx, varname):
    lines = ptx.split("\n")
    if lines and lines[-1] == "":
        lines = lines[:-1]
    out = ['static const char *%s =' % varname]
    for i, ln in enumerate(lines):
        esc = ln.replace("\\", "\\\\").replace('"', '\\"')
        if i == len(lines) - 1:
            out.append('    "%s";' % esc)
        else:
            out.append('    "%s\\n"' % esc)
    return "\n".join(out)

c_4x4 = to_cstr(ptx_4x4, "PTX_BODY_4X4")
c_sh = to_cstr(ptx_sh, "PTX_BODY_SHARED")

# ---------- 补丁 1+2：替换 PTX_BODY 定义为两个变量 ----------
old_block = m.group(0)
new_block = c_4x4 + "\n\n" + c_sh + "\n"
rep("PTX_BODY -> PTX_BODY_4X4 + 新增 PTX_BODY_SHARED", old_block, new_block)

# ---------- 补丁 3：compile_sgemm 双 entry ----------
old_cs = """static CUfunction compile_sgemm(void)
{
    char       img[8192];
    char       head[128];
    CUmodule   mod = NULL;
    CUfunction fn = NULL;
    CUresult   r = 0;
    size_t     i;

    for (i = 0; i < sizeof(PTX_VERSIONS) / sizeof(PTX_VERSIONS[0]); i++) {
        snprintf(head, sizeof head,
                 ".version %s\\n.target sm_%d\\n.address_size 64\\n\\n",
                 PTX_VERSIONS[i], g_cc);
        snprintf(img, sizeof img, "%s%s", head, PTX_BODY);
        r = p_cuModuleLoadData(&mod, img);
        if (r != 0)
            continue;                       /* 这个 .version 不行，换下一个 */
        r = p_cuModuleGetFunction(&fn, mod, "sgemm");
        if (r != 0) {
            snprintf(g_why, sizeof g_why, "PTX 编过了但取不到 sgemm 入口：%s",
                     cu_err(r));
            return NULL;
        }
        return fn;
    }
    snprintf(g_why, sizeof g_why,
             "手写 PTX 被驱动拒了（这张卡 CC=%d、驱动 %d，"
             ".version 8.7~6.0 全试过）：%s", g_cc, g_driver, cu_err(r));
    return NULL;
}"""
new_cs = """/* 一个模块装两个 entry：
 *   sgemm          —— 4x4 寄存器分块（小矩阵用，无 bar.sync、occupancy 高）
 *   sgemm_shared   —— shared memory tiling（N>=256 用，global 访存降 16 倍）
 * shared 取不到不致命：g_fn_sh 置 NULL，路由永远走 4x4（等于没这个优化）。
 * 模块加载后不保存 mod：驱动持有到卸载，function 指针一直有效（与旧版同）。 */
static CUfunction compile_sgemm(void)
{
    char       img[32768];
    char       head[128];
    CUmodule   mod = NULL;
    CUfunction fn = NULL;
    CUresult   r = 0;
    size_t     i;
    int        wr;

    for (i = 0; i < sizeof(PTX_VERSIONS) / sizeof(PTX_VERSIONS[0]); i++) {
        snprintf(head, sizeof head,
                 ".version %s\\n.target sm_%d\\n.address_size 64\\n\\n",
                 PTX_VERSIONS[i], g_cc);
        wr = snprintf(img, sizeof img, "%s%s\\n%s", head, PTX_BODY_4X4, PTX_BODY_SHARED);
        if (wr < 0 || (size_t)wr >= sizeof img)
            continue;                       /* 放不下，换下一个 .version 重试 */
        r = p_cuModuleLoadData(&mod, img);
        if (r != 0)
            continue;                       /* 这个 .version 不行，换下一个 */
        r = p_cuModuleGetFunction(&fn, mod, "sgemm");
        if (r != 0) {
            snprintf(g_why, sizeof g_why, "PTX 编过了但取不到 sgemm 入口：%s",
                     cu_err(r));
            return NULL;
        }
        g_fn_sh = NULL;
        if (p_cuModuleGetFunction(&g_fn_sh, mod, "sgemm_shared") != 0)
            g_fn_sh = NULL;                 /* 降级：全走 4x4，不堵死 GPU 通路 */
        return fn;
    }
    snprintf(g_why, sizeof g_why,
             "手写 PTX 被驱动拒了（这张卡 CC=%d、驱动 %d，"
             ".version 8.7~6.0 全试过）：%s", g_cc, g_driver, cu_err(r));
    return NULL;
}"""
rep("compile_sgemm 双 entry + img 扩容", old_cs, new_cs)

# ---------- 补丁 4：g_fn_sh 声明 ----------
rep("g_fn_sh 声明",
    "static CUfunction  g_fn;                        /* sgemm 入口 */",
    "static CUfunction  g_fn;                        /* sgemm 入口（4x4，小矩阵） */\n"
    "static CUfunction  g_fn_sh;                     /* sgemm_shared 入口（大矩阵，可为 NULL） */")

# ---------- 补丁 5：launch 路由 ----------
rep("launch 按 N 路由",
    """        void    *params[] = { &g_dA, &g_dB, &g_dC, &m, &n, &k };
        unsigned gx = (unsigned)((N + 63) / 64);   /* x 维扫 N（列），block 16x16 铺 64 列 */
        unsigned gy = (unsigned)((M + 63) / 64);   /* y 维扫 M（行），block 16x16 铺 64 行 */
        r = p_cuCtxSetCurrent(g_ctx);
        if (r != 0) { gpu_fail("切不回 CUDA context：%s", cu_err(r)); goto out; }
        r = p_cuLaunchKernel(g_fn, gx, gy, 1, 16, 16, 1, 0, NULL, params, NULL);""",
    """        void    *params[] = { &g_dA, &g_dB, &g_dC, &m, &n, &k };
        unsigned gx = (unsigned)((N + 63) / 64);   /* x 维扫 N（列），block 16x16 铺 64 列 */
        unsigned gy = (unsigned)((M + 63) / 64);   /* y 维扫 M（行），block 16x16 铺 64 行 */
        /* 尺寸路由（1060 实测分界）：N>=256 走 shared tiling（大矩阵带宽敏感，
         * global 访存降 16 倍，+36~61%）；N<256 走 4x4（小矩阵延迟敏感，
         * bar.sync 串行化 + 低 occupancy 在它们是净亏，最差 -45%）。
         * 两个 entry 的 launch 配置完全相同（block 16x16、grid 64 步进）。 */
        CUfunction f = (N >= GPU_SHARED_MIN_N && g_fn_sh) ? g_fn_sh : g_fn;
        r = p_cuCtxSetCurrent(g_ctx);
        if (r != 0) { gpu_fail("切不回 CUDA context：%s", cu_err(r)); goto out; }
        r = p_cuLaunchKernel(f, gx, gy, 1, 16, 16, 1, 0, NULL, params, NULL);""")

# ---------- 补丁 7：头部注释块更新 ----------
rep("头部注释双 kernel 描述",
    """ * 探针实测（_gputest.c，GTX 1060 6GB / CC 6.1 / 驱动 13000）：
 *   LoadLibrary + 21 个入口 + 手写 PTX 编译 + sgemm 全尺寸对拍，全通；
 *   朴素 kernel 端到端在 128~2048 所有尺寸都快过 PYbook 自带的 AVX2 多线程内核。""",
    """ * 探针实测（_gputile.c / _gputest.c，GTX 1060 6GB / CC 6.1 / 驱动 13000）：
 *   LoadLibrary + 21 个入口 + 手写 PTX 编译 + sgemm 全尺寸对拍，全通；
 *   朴素 kernel 端到端在 128~2048 所有尺寸都快过 PYbook 自带的 AVX2 多线程内核。
 *
 * 两个 kernel（2026-10-14 第一跳：shared memory tiling）：
 *   sgemm        4x4 寄存器分块 + float4 直取 global，N<256  用（无 bar.sync）
 *   sgemm_shared 4x4 + BM64 BN64 BK8 shared tiling，N>=256 用
 *                 （256 线程协作把 A/B tile 搬进 shared，每元素 global 只取 1 次，
 *                  访存/计算比 0.5 -> 8 FMA/byte；1060 实测 N=2048：1008 -> 1627 GFLOPS，
 *                  利用率 23% -> 37%）
 *   分界依据：N>=256 六个用例全赢（+22~61%），N<256 四个全输（bar.sync 串行化
 *   + 低 occupancy 在小矩阵上是净亏，最差 -45%）。launch 配置两者完全相同。""")

# ---------- 补丁 8：路由阈值宏 ----------
rep("GPU_SHARED_MIN_N 宏",
    """int gpu_sgemm_f32(const double *A, const double *B, double *C,""",
    """/* shared tiling kernel 的启用阈值：N >= 此值才值得付 bar.sync + 低 occupancy
 * 的代价（1060 实测分界：N>=256 六用例全赢 +22~61%，N<256 四用例全输最差 -45%，
 * 详见文件头注释与 GPU_DESIGN.md）。 */
#define GPU_SHARED_MIN_N 256

int gpu_sgemm_f32(const double *A, const double *B, double *C,""")

io.open(SRC, "w", encoding="utf-8", newline="").write(s)
print("written:", SRC)
