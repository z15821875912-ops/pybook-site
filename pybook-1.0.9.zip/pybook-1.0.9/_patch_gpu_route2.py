# _patch_gpu_route2.py —— 第四跳补丁第二阶段：
#   1) g_sms_route：路由用的 SM 数，可被 PYBOOK_GPU_FAKE_SMS 覆盖，
#      用来在只有一张 1060 的机器上模拟「大卡」并验证路由行为。
#      真实 SM 数仍用于自标定（标定必须按真实机器算，否则常数是错的）。
#   2) PYBOOK_GPU_VERBOSE=1 时打印标定结果（c/s、是否被采纳）。
#
# 纪律同 _patch_gpu_route.py：锚点唯一、原子替换、幂等。
import io, os, sys


def crlf(s):
    return s.replace("\r\n", "\n").replace("\n", "\r\n")


def read(path):
    with io.open(path, "r", encoding="utf-8", newline="") as f:
        return f.read()


def write_atomic(path, text):
    tmp = path + ".tmpfix"
    with io.open(tmp, "w", encoding="utf-8", newline="") as f:
        f.write(text)
    os.replace(tmp, path)


def sub(text, old, new, tag):
    old = crlf(old)
    new = crlf(new)
    n = text.count(old)
    if n != 1:
        print("锚点 %s 出现 %d 次（要求恰好 1 次）—— 补丁中止，不写盘" % (tag, n))
        sys.exit(1)
    return text.replace(old, new)


src = read("pybook_gpu.c")
changed = []

if "g_sms_route" in src:
    print("第二阶段补丁已在（g_sms_route 存在），跳过。")
else:
    # B1: 新增 g_sms_route 全局
    b1 = "static int         g_calibrated = 0;               /* 1=已在本机标定过时间常数 */\n"
    b1_new = b1 + """static int         g_sms_route = 0;               /* 路由用的 SM 数（可被环境变量覆盖） */
"""
    src = sub(src, b1, b1_new, "B1 g_sms_route 全局")
    changed.append("B1")

    # B2: 探测时算 g_sms_route（含 FAKE 覆盖）
    b2 = """        if (g_sms < 1) g_sms = 0;
        if (g_max_threads_sm < 1) g_max_threads_sm = 0;
"""
    b2_new = b2 + """        if (g_max_threads_sm < 1) g_max_threads_sm = 0;
        /* 路由用的 SM 数：默认就是真实值；PYBOOK_GPU_FAKE_SMS 可以覆盖，
         * 用来在只有一张 1060 的机器上模拟大卡、验证路由会不会选错。
         * 注意它只影响**选型**，不影响自标定（标定必须按真实机器算）。 */
        g_sms_route = g_sms;
        {
            const char *fs = getenv("PYBOOK_GPU_FAKE_SMS");
            if (fs) {
                int v = atoi(fs);
                if (v > 0) g_sms_route = v;
            }
        }
"""
    src = sub(src, b2, b2_new, "B2 FAKE_SMS 覆盖")
    changed.append("B2")

    # B3: 路由里用 g_sms_route
    b3 = """    if (g_sms < 1)
        return -1;
"""
    b3_new = """    if (g_sms_route < 1)
        return -1;
"""
    src = sub(src, b3, b3_new, "B3 路由用 g_sms_route")
    changed.append("B3")

    b3b = """        slots  = (long long)g_sms * (long long)(g_kg[i].bpsm > 0 ? g_kg[i].bpsm : 1);
        waves  = (blocks + slots - 1) / slots;
        if (waves < 1) waves = 1;
        t = (double)waves * ((double)K * g_kg[i].c_ms + g_kg[i].s_ms);
"""
    b3b_new = """        slots  = (long long)g_sms_route * (long long)(g_kg[i].bpsm > 0 ? g_kg[i].bpsm : 1);
        waves  = (blocks + slots - 1) / slots;
        if (waves < 1) waves = 1;
        t = (double)waves * ((double)K * g_kg[i].c_ms + g_kg[i].s_ms);
"""
    src = sub(src, b3b, b3b_new, "B3b 路由波数用 g_sms_route")
    changed.append("B3b")

    b3c = """        long long slots = (long long)g_sms *
                          (long long)(g_kg[ki].bpsm > 0 ? g_kg[ki].bpsm : 1);
"""
    b3c_new = """        long long slots = (long long)g_sms_route *
                          (long long)(g_kg[ki].bpsm > 0 ? g_kg[ki].bpsm : 1);
"""
    src = sub(src, b3c, b3c_new, "B3c plan 用 g_sms_route")
    changed.append("B3c")

    # B4: 标定结果可见（verbose）
    b4 = """        if (c > 0 && c < GPU_C_FALLBACK[ki][0] * 5.0 &&
            c > GPU_C_FALLBACK[ki][0] * 0.2 && s > -0.05 && s < 0.05) {
            g_kg[ki].c_ms = c;
            g_kg[ki].s_ms = s;
            g_calibrated = 1;
        }
"""
    b4_new = """        if (c > 0 && c < GPU_C_FALLBACK[ki][0] * 5.0 &&
            c > GPU_C_FALLBACK[ki][0] * 0.2 && s > -0.05 && s < 0.05) {
            g_kg[ki].c_ms = c;
            g_kg[ki].s_ms = s;
            g_calibrated = 1;
            if (getenv("PYBOOK_GPU_VERBOSE"))
                printf("[gpu] 标定 %-13s c=%.6f ms/K  s=%.5f ms  （静态兜底 c=%.6f s=%.5f）\\n",
                       g_kg[ki].name, c, s,
                       GPU_C_FALLBACK[ki][0], GPU_C_FALLBACK[ki][1]);
        } else if (getenv("PYBOOK_GPU_VERBOSE")) {
            printf("[gpu] 标定 %-13s 被闸门拦下（c=%.6f s=%.5f），保留静态值\\n",
                   g_kg[ki].name, c, s);
        }
"""
    src = sub(src, b4, b4_new, "B4 标定可见")
    changed.append("B4")

    write_atomic("pybook_gpu.c", src)
    print("第二阶段补丁完成：", ",".join(changed))
