/* _gpucheck4.c —— 第四跳（设备感知路由）生产入口验证
 *
 * 验三件事：
 *   1. 路由计划：gpu_route_plan 对各种形状给出的选择是否合理（打印出来人工核对），
 *      并和「实测最优」对照（实测表在 _gpucal_out.csv，由 _gpucal.c 产出）。
 *   2. 正确性：走生产入口 gpu_sgemm_f32 的结果必须和 CPU 参考一致（f32 容差）。
 *   3. 速度：端到端墙钟（含 H2D+D2H），对比老路由（N 阈值）会慢多少。
 *
 * 用法：
 *   _gpucheck4.exe            正常跑
 *   PYBOOK_GPU_FAKE_SMS=128   把路由当成 128 SM 的卡（模拟大卡）
 *   PYBOOK_GPU_VERBOSE=1      打印自标定结果
 *
 * 编译：
 *   gcc _gpucheck4.c pybook_gpu.c -o _gpucheck4.exe -O2 -I. -lwinmm -lm
 */
#include "pybook_gpu.h"
#include "pybook_rt.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <windows.h>

void rt_die(const char *fmt, ...) { (void)fmt; fputs("rt_die(stub)\n", stderr); exit(2); }
Value rt_str(const char *s) { (void)s; Value v; memset(&v, 0, sizeof v); return v; }

static unsigned g_seed = 777u;
static double frand(void)
{
    g_seed = g_seed * 1103515245u + 12345u;
    return (double)((g_seed >> 9) & 0xFFFF) / 65536.0 - 0.5;
}

static double now_s(void)
{
    static LARGE_INTEGER freq = {0};
    LARGE_INTEGER t;
    if (freq.QuadPart == 0) QueryPerformanceFrequency(&freq);
    QueryPerformanceCounter(&t);
    return (double)t.QuadPart / (double)freq.QuadPart;
}

static const char *KNAME[3] = { "sgemm(4x4)", "sgemm_shared", "sgemm_8x8" };

/* 老路由（第三跳之前写死的那套）：用来对照新路由快多少 */
static const char *old_route(int N)
{
    if (N >= 1280) return "sgemm_8x8";
    if (N >= 224)  return "sgemm_shared";
    return "sgemm(4x4)";
}

typedef struct { int M, N, K; } Shape;

int main(void)
{
    static const Shape shapes[] = {
        { 256, 256, 256 }, { 320, 320, 320 }, { 384, 384, 384 },
        { 448, 448, 448 }, { 512, 512, 512 }, { 640, 640, 640 },
        { 768, 768, 768 }, { 896, 896, 896 }, { 1024, 1024, 1024 },
        { 1152, 1152, 1152 }, { 1280, 1280, 1280 }, { 1536, 1536, 1536 },
        { 2048, 2048, 2048 },
        { 64, 1024, 1024 }, { 64, 2048, 2048 }, { 128, 512, 512 },
        { 300, 132, 300 }, { 8, 1280, 64 }, { 2048, 512, 512 },
    };
    int nsh = (int)(sizeof(shapes) / sizeof(shapes[0]));
    int i, bad = 0;

    printf("设备：%s   驱动 %d\n", gpu_device_name(), gpu_driver_version());
    if (!gpu_available()) { printf("GPU 不可用：%s\n", gpu_device_name()); return 1; }

    printf("\n%-22s | %-14s %8s %6s | %-14s | %8s | %s\n",
           "形状", "新路由选", "块数", "波数", "老路由选", "ms", "正确性");
    printf("-----------------------+----------------+----------+------"
           "+----------------+----------+--------\n");

    for (i = 0; i < nsh; i++) {
        int    M = shapes[i].M, N = shapes[i].N, K = shapes[i].K;
        size_t ka = (size_t)M * K, kb = (size_t)K * N, kc = (size_t)M * N;
        double *A, *B, *C, *R;
        double  t0, t1, best = 1e30, gflops;
        int     ki = -1, blocks = 0, waves = 0, it, j, badrel = 0;
        double  maxrel = 0;

        A = (double *)malloc(ka * sizeof(double));
        B = (double *)malloc(kb * sizeof(double));
        C = (double *)malloc(kc * sizeof(double));
        R = (double *)malloc(kc * sizeof(double));
        if (!A || !B || !C || !R) { printf("host 内存不足\n"); return 1; }
        for (j = 0; j < (int)ka; j++) A[j] = frand();
        for (j = 0; j < (int)kb; j++) B[j] = frand();

        for (it = 0; it < 3; it++) {
            double tt;
            t0 = now_s();
            if (!gpu_sgemm_f32(A, B, C, M, N, K)) {
                printf("gpu_sgemm_f32 失败：%s\n", gpu_last_error());
                return 1;
            }
            t1 = now_s();
            tt = t1 - t0;
            if (tt < best) best = tt;
        }

        /* CPU 参考（抽样） */
        for (j = 0; j < (int)kc; j += (kc > 4096 ? kc / 4096 : 1)) {
            double acc = 0, mag = 0, d;
            int r = j / N, c = j % N, p;
            for (p = 0; p < K; p++) {
                double a = A[(size_t)r * K + p], b = B[(size_t)p * N + c];
                acc += a * b; mag += fabs(a * b);
            }
            d = fabs(C[j] - acc);
            {
                double rel = (mag > 0) ? d / mag : d;
                if (rel > maxrel) maxrel = rel;
                if (rel > 1e-5) badrel++;
            }
        }
        if (badrel) bad++;

        gpu_route_plan(M, N, K, &ki, &blocks, &waves);
        gflops = 2.0 * (double)M * (double)N * (double)K / (best * 1e-3) / 1e9;

        printf("%5dx%-6dx%-8d | %-14s %8d %6d | %-14s | %8.3f | %s %6.1f GFLOPS%s\n",
               M, N, K,
               ki >= 0 ? KNAME[ki] : "(退回旧阈值)",
               blocks, waves,
               old_route(N), best * 1000.0,
               badrel ? "错!" : "对", gflops,
               badrel ? "" : "");
        fflush(stdout);
        free(A); free(B); free(C); free(R);
    }
    printf("\n正确性：%d/%d 个形状超差\n", bad, nsh);
    return bad ? 1 : 0;
}
