# _patch_gen_preds2.py —— 生成器的谓词寄存器也不够用。
#
# 现象：TSY*TSX > 4 时（TSY=4/TSX=2 等）生成的 PTX 仍然 218。
# 原因：STORE 段有两组谓词 —— 空间 AND（%p40+i）和「通道 AND 空间」（%p44+i）。
#       TSY*TSX=8 时后者要占到 %p51，而声明只有 %p<48> → 越界。
# 修法：最终 AND 挪到 %p48 起，声明按 48 + TSY*TSX 算。
import io, os

P = "build_tmp/probe/_gen_conv_ptx.py"
d = io.open(P, encoding="utf-8", newline="").read()

old = 'e("    .reg .pred %p<48>;")'
new = 'e("    .reg .pred %%p<%d>;" % (48 + TSY * TSX))'
if d.count(old) != 1:
    raise SystemExit("锚点 声明 命中 %d 次" % d.count(old))
d = d.replace(old, new)

old = 'e("    and.pred %%p%d, %%p%d, %%p%d;" % (44 + i, 8 + o, 40 + i))'
new = 'e("    and.pred %%p%d, %%p%d, %%p%d;" % (48 + i, 8 + o, 40 + i))'
if d.count(old) != 1:
    raise SystemExit("锚点 AND 命中 %d 次" % d.count(old))
d = d.replace(old, new)

old = "          % (44 + i, reg, o * TSY * TSX + i))"
new = "          % (48 + i, reg, o * TSY * TSX + i))"
if d.count(old) != 1:
    raise SystemExit("锚点 store 命中 %d 次" % d.count(old))
d = d.replace(old, new)

tmp = P + ".tmpfix"
with io.open(tmp, "w", encoding="utf-8", newline="") as f:
    f.write(d)
os.replace(tmp, P)
print("谓词分配：通道 %p8- / 空间 %p40- / 最终 %p48-，声明 48+TSY*TSX")
