/* PYbook numpybk（np. 前缀）：数组运算原生库。
 * v1 定位：一维数值列表的向量化运算（游戏数学够用）——
 * 全部直接操作 RtList，C 级速度；整数保整数，浮点自动提升。
 * 函数：zeros / range / add / sub / mul / scale / dot / norm /
 *       normalize / max / min / sum / mean / sin / cos / sqrt */

#include "pybook_lib.h"
#include "pybook_mt.h"

#include <math.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>

#define NP_PAR_MIN (1 << 16)   /* 6.5 万元素起并行 */

/* ================= 内部 ================= */

static void np_die(const char *fmt, ...)
{
    va_list ap;
    fprintf(stderr, "运行时错误: ");
    va_start(ap, fmt);
    vfprintf(stderr, fmt, ap);
    va_end(ap);
    fputc('\n', stderr);
    exit(1);
}

static RtList *as_arr(Value v, const char *who)
{
    if (!IS_LIST(v) || AS_LIST(v) == NULL)
        np_die("%s 需要列表（np 库操作数值数组）", who);
    return AS_LIST(v);
}

static RtList *as_arr2(Value a, Value b, const char *who)
{
    RtList *A = as_arr(a, who), *B = as_arr(b, who);
    if (A->len != B->len)
        np_die("%s 两个数组长度不一致（%zu vs %zu）", who, A->len, B->len);
    (void)A;
    return B;
}

static double el(Value v)
{
    if (IS_FLT(v))  return AS_FLT(v);
    if (IS_INT(v) || IS_BIGINT(v)) return (double)rt_to_ll(v);
    if (IS_BOOL(v)) return (double)AS_BOOL(v);
    np_die("np 数组元素必须是数字");
    return 0;
}

static double num_arg(Value v, const char *who)
{
    if (IS_FLT(v))  return AS_FLT(v);
    if (IS_INT(v) || IS_BIGINT(v)) return (double)rt_to_ll(v);
    if (IS_BOOL(v)) return (double)AS_BOOL(v);
    np_die("%s 需要数字参数", who);
    return 0;
}

static int is_int_el(Value v)
{
    return IS_INT(v) || IS_BIGINT(v) || IS_BOOL(v);
}

static Value new_arr(size_t n)
{
    Value lst = rt_list_new();
    RtList *L = AS_LIST(lst);
    for (size_t i = 0; i < n; i++)
        rt_push(&lst, rt_int(0));
    (void)L;
    return lst;
}

/* 元素级二元运算：双整保整，否则浮点 */
typedef struct { RtList *A, *B, *O; int all_int; } NpBinCtx;

#define BINOP(NAME, OP, WHO)                                        \
static void NAME##_chunk(int cid, long long a, long long b, void *ud) \
{                                                                   \
    NpBinCtx *x = ud;                                               \
    (void)cid;                                                      \
    if (x->all_int)                                                 \
        for (long long i = a; i < b; i++)                           \
            x->O->items[i] = rt_int(rt_to_ll(x->A->items[i])        \
                                    OP rt_to_ll(x->B->items[i]));   \
    else                                                            \
        for (long long i = a; i < b; i++)                           \
            x->O->items[i] = rt_float(el(x->A->items[i])            \
                                      OP el(x->B->items[i]));       \
}                                                                   \
static Value NAME(Value a, Value b)                                 \
{                                                                   \
    RtList *A = as_arr(a, WHO), *B = as_arr2(a, b, WHO);            \
    Value out = new_arr(A->len);                                    \
    RtList *O = AS_LIST(out);                                       \
    int all_int = 1;                                                \
    for (size_t i = 0; i < A->len; i++)                             \
        if (!is_int_el(A->items[i]) || !is_int_el(B->items[i])) {   \
            all_int = 0;                                            \
            break;                                                  \
        }                                                           \
    if (A->len >= NP_PAR_MIN) {                                     \
        NpBinCtx x = { A, B, O, all_int };                          \
        mt_parallel((long long)A->len, NAME##_chunk, &x);           \
        return out;                                                 \
    }                                                               \
    for (size_t i = 0; i < A->len; i++) {                           \
        if (all_int) {                                              \
            long long x = rt_to_ll(A->items[i]) OP rt_to_ll(B->items[i]); \
            O->items[i] = rt_int(x);                                \
        } else {                                                    \
            O->items[i] = rt_float(el(A->items[i]) OP el(B->items[i])); \
        }                                                           \
    }                                                               \
    return out;                                                     \
}

BINOP(np_add_impl, +, "np.add")
BINOP(np_sub_impl, -, "np.sub")
BINOP(np_mul_impl, *, "np.mul")

/* ================= 对外接口 ================= */

Value rt_np_zeros(Value n)
{
    long long len = (long long)num_arg(n, "np.zeros 的长度");
    if (len < 0 || len > 10000000)
        np_die("np.zeros 长度超范围（0..1000万）");
    return new_arr((size_t)len);
}

Value rt_np_range(Value lov, Value hiv, Value stepv)
{
    double lo = num_arg(lov, "np.range 的起点");
    double hi = num_arg(hiv, "np.range 的终点");
    double st = num_arg(stepv, "np.range 的步长");
    if (st == 0.0)
        np_die("np.range 步长不能为 0");
    int ints = is_int_el(lov) && is_int_el(hiv) && is_int_el(stepv);
    Value out = rt_list_new();
    long long guard = 0;
    if (st > 0)
        for (double x = lo; x < hi && guard++ < 10000000; x += st) {
            if (ints && st == (double)(long long)st && lo == (double)(long long)lo)
                rt_push(&out, rt_int((long long)x));
            else
                rt_push(&out, rt_float(x));
        }
    else
        for (double x = lo; x > hi && guard++ < 10000000; x += st) {
            if (ints && st == (double)(long long)st && lo == (double)(long long)lo)
                rt_push(&out, rt_int((long long)x));
            else
                rt_push(&out, rt_float(x));
        }
    return out;
}

Value rt_np_add(Value a, Value b) { return np_add_impl(a, b); }
Value rt_np_sub(Value a, Value b) { return np_sub_impl(a, b); }
Value rt_np_mul(Value a, Value b) { return np_mul_impl(a, b); }

typedef struct { RtList *A, *O; int ints; double k; long long ki; } NpScCtx;

static void np_scale_chunk(int cid, long long a, long long b, void *ud)
{
    NpScCtx *x = ud;
    (void)cid;
    if (x->ints)
        for (long long i = a; i < b; i++)
            x->O->items[i] = rt_int(rt_to_ll(x->A->items[i]) * x->ki);
    else
        for (long long i = a; i < b; i++)
            x->O->items[i] = rt_float(el(x->A->items[i]) * x->k);
}

Value rt_np_scale(Value a, Value k)
{
    RtList *A = as_arr(a, "np.scale");
    Value out = new_arr(A->len);
    RtList *O = AS_LIST(out);
    int ints = is_int_el(k);
    for (size_t i = 0; i < A->len; i++)
        ints = ints && is_int_el(A->items[i]);
    if (A->len >= NP_PAR_MIN) {
        NpScCtx x = { A, O, ints, el(k), rt_to_ll(k) };
        mt_parallel((long long)A->len, np_scale_chunk, &x);
        return out;
    }
    for (size_t i = 0; i < A->len; i++) {
        if (ints)
            O->items[i] = rt_int(rt_to_ll(A->items[i]) * rt_to_ll(k));
        else
            O->items[i] = rt_float(el(A->items[i]) * el(k));
    }
    return out;
}

Value rt_np_dot(Value a, Value b)
{
    RtList *A = as_arr(a, "np.dot"), *B = as_arr2(a, b, "np.dot");
    int ints = 1;
    double acc_f = 0;
    long long acc_i = 0;
    for (size_t i = 0; i < A->len; i++)
        if (!is_int_el(A->items[i]) || !is_int_el(B->items[i])) {
            ints = 0;
            break;
        }
    if (ints) {
        for (size_t i = 0; i < A->len; i++)
            acc_i += rt_to_ll(A->items[i]) * rt_to_ll(B->items[i]);
        return rt_int(acc_i);
    }
    for (size_t i = 0; i < A->len; i++)
        acc_f += el(A->items[i]) * el(B->items[i]);
    return rt_float(acc_f);
}

Value rt_np_norm(Value a)
{
    RtList *A = as_arr(a, "np.norm");
    double s = 0;
    for (size_t i = 0; i < A->len; i++) {
        double x = el(A->items[i]);
        s += x * x;
    }
    return rt_float(sqrt(s));
}

Value rt_np_normalize(Value a)
{
    RtList *A = as_arr(a, "np.normalize");
    double s = 0;
    for (size_t i = 0; i < A->len; i++) {
        double x = el(A->items[i]);
        s += x * x;
    }
    double n = sqrt(s);
    if (n < 1e-12)
        np_die("np.normalize 零向量没有方向");
    Value out = new_arr(A->len);
    RtList *O = AS_LIST(out);
    for (size_t i = 0; i < A->len; i++)
        O->items[i] = rt_float(el(A->items[i]) / n);
    return out;
}

Value rt_np_max(Value a)
{
    RtList *A = as_arr(a, "np.max");
    if (A->len == 0)
        np_die("np.max 空数组没有最大值");
    Value m = A->items[0];
    for (size_t i = 1; i < A->len; i++)
        if (rt_cond(rt_gt(A->items[i], m)))
            m = A->items[i];
    return m;
}

Value rt_np_min(Value a)
{
    RtList *A = as_arr(a, "np.min");
    if (A->len == 0)
        np_die("np.min 空数组没有最小值");
    Value m = A->items[0];
    for (size_t i = 1; i < A->len; i++)
        if (rt_cond(rt_lt(A->items[i], m)))
            m = A->items[i];
    return m;
}

typedef struct { RtList *A; RtList *O; long long *iparts; double *dparts; } NpSumCtx;

static void np_sum_chunk(int cid, long long a, long long b, void *ud)
{
    NpSumCtx *x = ud;
    if (x->iparts) {
        long long s = 0;
        for (long long i = a; i < b; i++)
            s += rt_to_ll(x->A->items[i]);
        x->iparts[cid] = s;
    } else {
        double s = 0;
        for (long long i = a; i < b; i++)
            s += el(x->A->items[i]);
        x->dparts[cid] = s;
    }
}

Value rt_np_sum(Value a)
{
    RtList *A = as_arr(a, "np.sum");
    int ints = 1;
    for (size_t i = 0; i < A->len; i++)
        if (!is_int_el(A->items[i])) {
            ints = 0;
            break;
        }
    if (ints) {
        if (A->len >= NP_PAR_MIN) {
            long long parts[MT_CHUNKS] = {0};
            NpSumCtx x = { A, NULL, parts, NULL };
            int chunks = mt_parallel((long long)A->len, np_sum_chunk, &x);
            long long s = 0;
            for (int i = 0; i < chunks; i++)
                s += parts[i];
            return rt_int(s);
        }
        long long s = 0;
        for (size_t i = 0; i < A->len; i++)
            s += rt_to_ll(A->items[i]);
        return rt_int(s);
    }
    if (A->len >= NP_PAR_MIN) {
        double parts[MT_CHUNKS] = {0};
        NpSumCtx x = { A, NULL, NULL, parts };
        int chunks = mt_parallel((long long)A->len, np_sum_chunk, &x);
        double s = 0;
        for (int i = 0; i < chunks; i++)
            s += parts[i];
        return rt_float(s);
    }
    double s = 0;
    for (size_t i = 0; i < A->len; i++)
        s += el(A->items[i]);
    return rt_float(s);
}

Value rt_np_mean(Value a)
{
    RtList *A = as_arr(a, "np.mean");
    if (A->len == 0)
        np_die("np.mean 空数组没有平均值");
    double s = 0;
    if (A->len >= NP_PAR_MIN) {
        double parts[MT_CHUNKS] = {0};
        NpSumCtx x = { A, NULL, NULL, parts };
        int chunks = mt_parallel((long long)A->len, np_sum_chunk, &x);
        for (int i = 0; i < chunks; i++)
            s += parts[i];
        return rt_float(s / (double)A->len);
    }
    for (size_t i = 0; i < A->len; i++)
        s += el(A->items[i]);
    return rt_float(s / (double)A->len);
}

/* 元素级数学：sin / cos / sqrt（全浮点输出） */
typedef struct { RtList *A, *O; } NpM1Ctx;

#define MATH1(NAME, EXPR, WHO)                                     \
static void NAME##_chunk(int cid, long long a, long long b, void *ud) \
{                                                                   \
    NpM1Ctx *x = ud;                                                \
    (void)cid;                                                      \
    for (long long i = a; i < b; i++) {                             \
        double v = el(x->A->items[i]);                              \
        x->O->items[i] = rt_float(EXPR);                            \
    }                                                               \
}                                                                   \
static Value NAME(Value a)                                          \
{                                                                   \
    RtList *A = as_arr(a, WHO);                                     \
    Value out = new_arr(A->len);                                    \
    RtList *O = AS_LIST(out);                                       \
    if (A->len >= NP_PAR_MIN) {                                     \
        NpM1Ctx x = { A, O };                                       \
        mt_parallel((long long)A->len, NAME##_chunk, &x);           \
        return out;                                                 \
    }                                                               \
    for (size_t i = 0; i < A->len; i++) {                           \
        double v = el(A->items[i]);                                 \
        O->items[i] = rt_float(EXPR);                               \
    }                                                               \
    return out;                                                     \
}

MATH1(m_sin, sin(v),   "np.sin")
MATH1(m_cos, cos(v),   "np.cos")
MATH1(m_sqrt, sqrt(v), "np.sqrt")

/* ---- 元素级超越函数批量版 ----
 *
 * 为什么要补这一批：np.* 原来只有 sin/cos/sqrt 三个逐元素函数，
 * exp/log/erf/gamma 这些一个都没有。用户想做「给一组样本取 erf」
 * 只能写 PYbook 循环，而每条语句都要走一遍运行时函数调用
 * （实测 mt.erf 在 PYbook 循环里 ~78 ns/次，其中语言层开销只有 ~10 ns，
 *  剩下的全是 erf 自己的算法成本）。
 * 走 np.* 则是 C 级循环：省掉语言层开销，长度够了还自动多核并行。
 *
 * 特殊函数（erf/erfc/gamma/lgamma）走的是 pybook_lib.c 里同一套核心实现，
 * 所以 np.erf(x) 和 mt.erf(x) 的数值完全一致（同一个 lib_erf）。
 *
 * np.round 用的是 C 的 round()：**.5 远离零**，不是 Python 的银行家舍入
 * （round(0.5)=1、round(1.5)=2、round(-0.5)=-1）。 */
MATH1(m_exp,    exp(v),    "np.exp")
MATH1(m_log,    log(v),    "np.log")
MATH1(m_log2,   log2(v),   "np.log2")
MATH1(m_log10,  log10(v),  "np.log10")
MATH1(m_expm1,  expm1(v),  "np.expm1")
MATH1(m_log1p,  log1p(v),  "np.log1p")
MATH1(m_tan,    tan(v),    "np.tan")
MATH1(m_atan,   atan(v),   "np.atan")
MATH1(m_cbrt,   cbrt(v),   "np.cbrt")
MATH1(m_erf,    lib_erf(v),    "np.erf")
MATH1(m_erfc,   lib_erfc(v),   "np.erfc")
MATH1(m_gamma,  lib_gamma(v),  "np.gamma")
MATH1(m_lgamma, lib_lgamma(v), "np.lgamma")
MATH1(m_abs,    fabs(v),   "np.abs")
MATH1(m_floor,  floor(v),  "np.floor")
MATH1(m_ceil,   ceil(v),   "np.ceil")
MATH1(m_round,  round(v),  "np.round")
MATH1(m_sign,   (v > 0.0 ? 1.0 : (v < 0.0 ? -1.0 : 0.0)), "np.sign")

/* 元素级二元函数：两个数组逐元素调用同一个数学函数（两个数组长度必须一样） */
#define MATH2(NAME, EXPR, WHO)                                       \
static void NAME##_chunk(int cid, long long a, long long b, void *ud) \
{                                                                     \
    NpBinCtx *x = ud;                                                 \
    (void)cid;                                                        \
    for (long long i = a; i < b; i++) {                               \
        double pa = el(x->A->items[i]);                               \
        double pb = el(x->B->items[i]);                               \
        x->O->items[i] = rt_float(EXPR);                              \
    }                                                                 \
}                                                                     \
static Value NAME(Value a, Value b)                                   \
{                                                                     \
    RtList *A = as_arr(a, WHO), *B = as_arr2(a, b, WHO);              \
    Value out = new_arr(A->len);                                      \
    RtList *O = AS_LIST(out);                                         \
    if (A->len >= NP_PAR_MIN) {                                       \
        NpBinCtx x = { A, B, O, 0 };                                  \
        mt_parallel((long long)A->len, NAME##_chunk, &x);             \
        return out;                                                   \
    }                                                                 \
    for (size_t i = 0; i < A->len; i++) {                             \
        double pa = el(A->items[i]);                                  \
        double pb = el(B->items[i]);                                  \
        O->items[i] = rt_float(EXPR);                                 \
    }                                                                 \
    return out;                                                       \
}

MATH2(m_pow, pow(pa, pb), "np.pow")

Value rt_np_sin(Value a)   { return m_sin(a); }
Value rt_np_cos(Value a)   { return m_cos(a); }
Value rt_np_sqrt(Value a)  { return m_sqrt(a); }
Value rt_np_exp(Value a)   { return m_exp(a); }
Value rt_np_log(Value a)   { return m_log(a); }
Value rt_np_log2(Value a)  { return m_log2(a); }
Value rt_np_log10(Value a) { return m_log10(a); }
Value rt_np_expm1(Value a) { return m_expm1(a); }
Value rt_np_log1p(Value a) { return m_log1p(a); }
Value rt_np_tan(Value a)   { return m_tan(a); }
Value rt_np_atan(Value a)  { return m_atan(a); }
Value rt_np_cbrt(Value a)  { return m_cbrt(a); }
Value rt_np_erf(Value a)   { return m_erf(a); }
Value rt_np_erfc(Value a)  { return m_erfc(a); }
Value rt_np_gamma(Value a) { return m_gamma(a); }
Value rt_np_lgamma(Value a){ return m_lgamma(a); }
Value rt_np_abs(Value a)   { return m_abs(a); }
Value rt_np_floor(Value a) { return m_floor(a); }
Value rt_np_ceil(Value a)  { return m_ceil(a); }
Value rt_np_round(Value a) { return m_round(a); }
Value rt_np_sign(Value a)  { return m_sign(a); }
Value rt_np_pow(Value a, Value b) { return m_pow(a, b); }

