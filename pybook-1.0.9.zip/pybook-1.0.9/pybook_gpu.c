/* pybook_gpu.c —— PYbook GPU 后端（NVIDIA CUDA driver API，动态加载）
 *
 * 这个文件不 include cuda.h，所有入口都是自己 typedef 的函数指针；
 * 也不链接 cuda.lib，nvcuda.dll 是运行时 LoadLibrary 进来的。
 * 所以「没装 NVIDIA 驱动的机器」依然能编译、能链接、能跑 —— 只是探测返回 0。
 *
 * 探针实测（_gputile.c / _gputest.c，GTX 1060 6GB / CC 6.1 / 驱动 13000）：
 *   LoadLibrary + 21 个入口 + 手写 PTX 编译 + sgemm 全尺寸对拍，全通；
 *   朴素 kernel 端到端在 128~2048 所有尺寸都快过 PYbook 自带的 AVX2 多线程内核。
 *
 * 三个 kernel（2026-10-14 第一跳 shared tiling + 第二跳 8x8 寄存器分块）：
 *   sgemm        4x4 寄存器分块 + float4 直取 global，N<256  用（无 bar.sync）
 *   sgemm_shared 4x4 + BM64 BN64 BK8 shared tiling，256<=N<1280 用
 *                 （256 线程协作把 A/B tile 搬进 shared，每元素 global 只取 1 次，
 *                  访存/计算比 0.5 -> 8 FMA/byte）
 *   sgemm_8x8    8x8 + BM128 BN128 BK8 shared tiling + **载入预取**，N>=1280 用
 *                 （每线程计算量翻倍、global 访存再减半到 16 FMA/byte）
 *
 * sgemm_8x8 的第三跳：把每个 K-tile 的 8 条 ld.global 提到 512 条 FMA **之前**发出，
 * 算完再写共享内存。原写法是「载入 -> st.shared -> bar.sync -> 512 FMA」，
 * 全局载入延迟（Pascal 上几百个时钟）完全串在计算前面，每个 K-tile 都在干等。
 * 改成「发出载入 -> 512 FMA -> bar.sync -> 写共享 -> bar.sync」后，
 * 载入延迟被同一批 warp 的计算盖住。共享内存大小不变、每轮屏障数不变（仍是 2 个），
 * 只多用 8 个寄存器（B 段预取独占 %f84..%f87）。载入同时换成 ld.global.nc
 * 只读缓存路径。PTX 由 _mk8x8v2.py 从冻结的 _ptx_PTX_8X8_orig.ptx 生成，
 * 再由 _embed_ptx.py 内嵌进来；回退只需把 orig 拷回去重新生成+内嵌。
 *
 *   1060 实测（_gpucmp，新旧两个文件各自重复三次，64 轮取中位数）：
 *     N=3216  41.5 -> 32.2 ms  快 22.4%
 *     N=4096  80.7 -> 63.4 ms  快 21.8%
 *   为什么不早做：roofline 量出来 sgemm_8x8 离 FP32 算力上限还有距离，
 *   而它的算术强度比转折强度低 55 倍，所以瓶颈是「每条 FMA 周围的杂指令和
 *   载入延迟」，不是访存总量 —— 一开始还误判成「要少搬数据」，是那次
 *   假带宽数据（13.8 TB/s）把人带偏的。
 *
 *   2026-10-17 更正（_gppeak 实测，见 _gppeak.c / _mkfmareal.py）：
 *   以前这里写「只到算力上限的 ~45%」，那个 45% 是拿**已经作废的** fma_peak
 *   当分母算的，不作数。重建了一个编译器折叠不掉、且宿主逐位对拍通过的
 *   FMA 内核（10240 个结果逐位全中，最大相对误差 0.000e+00），真上限是
 *   **4.73 TFLOPS**（10 SM x 128 FP32 x 2 x 实测 1847 MHz）。
 *   同轮交替实测 sgemm_8x8 @N=3216 = 2.59 TFLOPS，**只到 59.8%**（另一轮 64.5%）。
 *   另外 CC 6.1 是**每 SM 128 个 FP32 单元**（64 是 P100 的数），
 *   这一点由实测仲裁：若按 64 算，实测值会是理论上限的 172%，物理上不可能。
 *
 *   那 40% 的缺口在哪：驱动报告 sgemm_8x8 每线程占 **128 个寄存器**
 *   -> 每 SM 只能驻留 2 块 = 16 warp（满载是 48 warp）。瓶颈是 occupancy，
 *   不是访存、不是 bank 冲突。注意共享内存只有 8192 字节/块，压根不是约束；
 *   寄存器才是。8x8 的 64 个累加器本身就撑不起低寄存器。
 *
 *   分界依据（1060 实测，六轮交替测量取中位数，单次测量会被动态升频骗）：
 *   N>=1280 时 8x8 赢 shared（1280 +18% / 1536 +11% / 2048 +15% / 3216 +25%）
 *   ——拐点是波尾量化：tile 128 的 grid 要到 ~100 个 block（10 SM x 2 并行 x 5 波）
 *   才不吃短尾波，1024 只有 64 block（3.2 波）实测反而 -5%；
 *   256<=N<1280 时 shared 赢（8x8 在 N<=1024 块数不够，最差 -41%）；
 *   N<256 时 4x4 赢（bar.sync 串行化 + 低 occupancy 在小矩阵上净亏，最差 -45%）。
 *   launch 配置：block 恒 16x16，grid 步进 8x8 是 128、其余 64。
 *
 * 三个必须记住的设计约束：
 *   1. 不链 cuda.lib、不 include cuda.h。保住「单 exe 拷走就能跑」。
 *   2. kernel 是手写 PTX 字符串，驱动自己 JIT。零构建期依赖（不要 nvcc / NVRTC）。
 *   3. 显存接口必须取 *_v2 版本化符号，否则一路报 CUDA 201 invalid device context。
 *      （当时 context 明明是好的，这条报错极具误导性。）
 */
#include "pybook_gpu.h"
#include "pybook_rt.h"

#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>

/* ─────────────── CUDA driver API 的最小 typedef ───────────────
 * 全部自己声明，一个 CUDA 头文件都不引入。 */
typedef int CUresult;
typedef int CUdevice;
typedef void *CUcontext;
typedef void *CUmodule;
typedef void *CUfunction;
typedef unsigned long long CUdeviceptr;

#define CU_DEVICE_ATTRIBUTE_CC_MAJOR 75
#define CU_DEVICE_ATTRIBUTE_CC_MINOR 76
/* 第四跳要用的两个属性号。**实测核对过**，不是照文档背的：
 * 1060 上 16 读到 10（SM 数）、39 读到 2048（每 SM 最大线程），都对得上。
 * 记错属性号的后果很阴：读出 0 或 4004000 这种数，路由会静默走错分支。 */
#define CU_DEVICE_ATTRIBUTE_MULTIPROCESSOR_COUNT 16
#define CU_DEVICE_ATTRIBUTE_MAX_THREADS_PER_MULTIPROCESSOR 39

static HMODULE g_dll = NULL;
static CUresult (*p_cuInit)(unsigned);
static CUresult (*p_cuDriverGetVersion)(int *);
static CUresult (*p_cuDeviceGetCount)(int *);
static CUresult (*p_cuDeviceGet)(CUdevice *, int);
static CUresult (*p_cuDeviceGetName)(char *, int, CUdevice);
static CUresult (*p_cuDeviceTotalMem)(size_t *, CUdevice);
static CUresult (*p_cuDeviceGetAttribute)(int *, int, CUdevice);
static CUresult (*p_cuDevicePrimaryCtxRetain)(CUcontext *, CUdevice);
static CUresult (*p_cuCtxSetCurrent)(CUcontext);
static CUresult (*p_cuCtxSynchronize)(void);
static CUresult (*p_cuModuleLoadData)(CUmodule *, const void *);
static CUresult (*p_cuModuleGetFunction)(CUfunction *, CUmodule, const char *);
static CUresult (*p_cuMemAlloc_v2)(CUdeviceptr *, size_t);
static CUresult (*p_cuMemFree_v2)(CUdeviceptr);
static CUresult (*p_cuMemAllocHost_v2)(CUdeviceptr *, size_t);
static CUresult (*p_cuMemFreeHost)(CUdeviceptr);
static CUresult (*p_cuMemcpyHtoD_v2)(CUdeviceptr, const void *, size_t);
static CUresult (*p_cuMemcpyDtoH_v2)(void *, CUdeviceptr, size_t);
/* 异步版：重叠搬运用（CUDA 4.0+ 都有，缺了就退回同步版） */
static CUresult (*p_cuMemcpyHtoDAsync_v2)(CUdeviceptr, const void *, size_t, void *);
static CUresult (*p_cuMemcpyDtoHAsync_v2)(void *, CUdeviceptr, size_t, void *);
static CUresult (*p_cuMemcpyDtoH_v2)(void *, CUdeviceptr, size_t);
static CUresult (*p_cuLaunchKernel)(CUfunction, unsigned, unsigned, unsigned,
                                    unsigned, unsigned, unsigned,
                                    unsigned, void *, void **, void **);
static CUresult (*p_cuGetErrorString)(CUresult, const char **);
/* 以下是第四跳才用到的可选入口：缺了不致命，
 * 对应的功能会退到静态兜底（见 gpu_setup_kernels / gpu_calibrate）。 */
static CUresult (*p_cuFuncGetAttribute)(int *, int, CUfunction);
static CUresult (*p_cuOccupancyMaxActiveBlocks)(int *, CUfunction, int, size_t);
static CUresult (*p_cuEventCreate)(void **, unsigned);
static CUresult (*p_cuEventRecord)(void *, void *);
static CUresult (*p_cuEventSynchronize)(void *);
static CUresult (*p_cuEventElapsedTime)(float *, void *, void *);
static CUresult (*p_cuEventDestroy)(void *);

/* ─────────────── 手写 PTX：sgemm，每线程算 4x4（float4 向量化） ───────────────
 *
 * 这一版的性能全靠一件事：把访存量压下来。朴素版（每线程 1 个输出）每次 FMA 要从
 * 显存取 2 个标量，访存/计算比 0.125 FMA/字节，只能跑到 1060 峰值的 3%。
 * 现在每轮取 8 个 float4（128 字节）喂 64 次 FMA，比值 0.5，N=3216 实测
 * 1014~1178 GFLOPS（朴素版 161，OpenBLAS 12 线程 408）。
 *
 * 手写 PTX 的坑（都踩过，不是听说的）：
 *   1. PTX 只认 // 行注释、且只收 ASCII。中文注释、块注释都会让整份编译失败，
 *      ptxas 一个字都不说，只回 CUDA 218。
 *   2. mul.wide.u32 的第二个操作数不能直接用立即数 —— 静默算错，不报错。
 *      统一走 cvt.u64.u32 + shl.b64。
 *   3. %ctaid 是块编号、%tid 才是块内线程编号，全局坐标要自己算 blockIdx*blockDim+tid。
 *   4. 访存地址只准「64 位寄存器 + 立即数」，寄存器 + 寄存器非法。
 *   5. float4 载入要求 16 字节对齐，所以 M/N/K 必须是 4 的倍数；
 *      列的越界钳位要钳到 N-4（钳到 N-1 会错位，那不是 4 的倍数）。
 *   6. C 的基址必须把 col0 加进去。漏加会让每个 block 都写 C[r][0..3]，
 *      最后跑的 block 赢 —— 现象是读到 B 的第 60~63 列，极难往地址计算上联想。
 *
 * 参数与索引约定（A: MxK 行主序、B: KxN 行主序、C: MxN 行主序）：
 *   %r1=M %r2=N %r3=K
 *   %r8 = row0（行号）  %r12 = col0（列号）  %r13 = k 计数器（步长 4）
 *   %f0..%f15 = 4x4 累加器   %rd9..%rd12 = C 的四行指针
 */
static const char *PTX_BODY_4X4 =
    "// 4x4 register tiling with vectorized float4 global loads.\n"
    "// One thread computes a 4x4 block of C.\n"
    "//   A[row0+i][k..k+3] is one float4  (A is row-major, k is contiguous)\n"
    "//   B[k+kk][col0..col0+3] is one float4 per k  (B rows are N apart)\n"
    "// so 8 float4 loads feed 64 FMAs = 0.5 FMA/byte, vs 0.125 for the naive kernel.\n"
    "// Block is 16x16 threads -> 64x64 output tile; grid = ceil(M/64) x ceil(N/64).\n"
    "//\n"
    "// Rules that must not be broken (each one cost a debugging round):\n"
    "//   1) PTX comments must be ASCII only.\n"
    "//   2) Addresses may be \"64-bit register + immediate\" only.\n"
    "//   3) Every address inside the loop is recomputed/advanced from k, never\n"
    "//      left as a stale offset register.\n"
    "//   4) float4 loads need 16-byte alignment, so M/N/K must be multiples of 4\n"
    "//      and the column clamp must be to N-4 (never N-1, which is misaligned).\n"
    ".visible .entry sgemm(\n"
    "    .param .u64 p0,\n"
    "    .param .u64 p1,\n"
    "    .param .u64 p2,\n"
    "    .param .u32 p3,\n"
    "    .param .u32 p4,\n"
    "    .param .u32 p5\n"
    ")\n"
    "{\n"
    "    .reg .pred %p<26>;\n"
    "    .reg .b32  %r<28>;\n"
    "    .reg .b64  %rd<24>;\n"
    "    .reg .f32  %f<48>;\n"
    "\n"
    "    ld.param.u64 %rd1, [p0];\n"
    "    ld.param.u64 %rd2, [p1];\n"
    "    ld.param.u64 %rd3, [p2];\n"
    "    ld.param.u32  %r1, [p3];\n"
    "    ld.param.u32  %r2, [p4];\n"
    "    ld.param.u32  %r3, [p5];\n"
    "\n"
    "    mov.u32 %r4, %tid.x;\n"
    "    mov.u32 %r5, %tid.y;\n"
    "    mov.u32 %r6, %ctaid.x;\n"
    "    mov.u32 %r7, %ctaid.y;\n"
    "\n"
    "    shl.b32 %r8,  %r7, 6;\n"
    "    shl.b32 %r9,  %r5, 2;\n"
    "    add.s32 %r8,  %r8, %r9;\n"
    "    shl.b32 %r10, %r6, 6;\n"
    "    shl.b32 %r11, %r4, 2;\n"
    "    add.s32 %r12, %r10, %r11;\n"
    "\n"
    "    setp.ge.u32 %p1, %r8,  %r1;\n"
    "    @%p1 bra DONE;\n"
    "    setp.ge.u32 %p2, %r12, %r2;\n"
    "    @%p2 bra DONE;\n"
    "\n"
    "    cvt.u64.u32 %rd15, %r3;\n"
    "    shl.b64 %rd15, %rd15, 2;\n"
    "    cvt.u64.u32 %rd16, %r2;\n"
    "    shl.b64 %rd16, %rd16, 2;\n"
    "\n"
    "    add.s32 %r16, %r8, 1;\n"
    "    add.s32 %r17, %r8, 2;\n"
    "    add.s32 %r18, %r8, 3;\n"
    "    sub.s32 %r19, %r1, 1;\n"
    "    min.s32 %r20, %r8,  %r19;\n"
    "    min.s32 %r21, %r16, %r19;\n"
    "    min.s32 %r22, %r17, %r19;\n"
    "    min.s32 %r23, %r18, %r19;\n"
    "\n"
    "    mul.wide.u32 %rd4, %r20, %r3;\n"
    "    shl.b64 %rd4, %rd4, 2;\n"
    "    add.s64 %rd4, %rd4, %rd1;\n"
    "    mul.wide.u32 %rd5, %r21, %r3;\n"
    "    shl.b64 %rd5, %rd5, 2;\n"
    "    add.s64 %rd5, %rd5, %rd1;\n"
    "    mul.wide.u32 %rd6, %r22, %r3;\n"
    "    shl.b64 %rd6, %rd6, 2;\n"
    "    add.s64 %rd6, %rd6, %rd1;\n"
    "    mul.wide.u32 %rd7, %r23, %r3;\n"
    "    shl.b64 %rd7, %rd7, 2;\n"
    "    add.s64 %rd7, %rd7, %rd1;\n"
    "\n"
    "    mul.wide.u32 %rd9, %r8, %r2;\n"
    "    cvt.u64.u32   %rd10, %r12;\n"
    "    add.s64       %rd9, %rd9, %rd10;\n"
    "    shl.b64       %rd9, %rd9, 2;\n"
    "    add.s64       %rd9, %rd9, %rd3;\n"
    "    add.s64 %rd10, %rd9,  %rd16;\n"
    "    add.s64 %rd11, %rd10, %rd16;\n"
    "    add.s64 %rd12, %rd11, %rd16;\n"
    "\n"
    "    sub.s32 %r24, %r2, 4;\n"
    "    min.s32 %r25, %r12, %r24;\n"
    "    cvt.u64.u32 %rd19, %r25;\n"
    "    shl.b64 %rd19, %rd19, 2;\n"
    "    add.s64 %rd19, %rd19, %rd2;\n"
    "\n"
    "    mov.f32 %f0,  0f00000000;\n"
    "    mov.f32 %f1,  0f00000000;\n"
    "    mov.f32 %f2,  0f00000000;\n"
    "    mov.f32 %f3,  0f00000000;\n"
    "    mov.f32 %f4,  0f00000000;\n"
    "    mov.f32 %f5,  0f00000000;\n"
    "    mov.f32 %f6,  0f00000000;\n"
    "    mov.f32 %f7,  0f00000000;\n"
    "    mov.f32 %f8,  0f00000000;\n"
    "    mov.f32 %f9,  0f00000000;\n"
    "    mov.f32 %f10, 0f00000000;\n"
    "    mov.f32 %f11, 0f00000000;\n"
    "    mov.f32 %f12, 0f00000000;\n"
    "    mov.f32 %f13, 0f00000000;\n"
    "    mov.f32 %f14, 0f00000000;\n"
    "    mov.f32 %f15, 0f00000000;\n"
    "    mov.u32 %r13, 0;\n"
    "\n"
    "LOOP:\n"
    "    setp.ge.u32 %p9, %r13, %r3;\n"
    "    @%p9 bra STORE;\n"
    "\n"
    "    ld.global.v4.f32 {%f16, %f17, %f18, %f19}, [%rd4];\n"
    "    ld.global.v4.f32 {%f20, %f21, %f22, %f23}, [%rd5];\n"
    "    ld.global.v4.f32 {%f24, %f25, %f26, %f27}, [%rd6];\n"
    "    ld.global.v4.f32 {%f28, %f29, %f30, %f31}, [%rd7];\n"
    "\n"
    "    mul.wide.u32 %rd8, %r13, %r2;\n"
    "    shl.b64 %rd8, %rd8, 2;\n"
    "    add.s64 %rd8, %rd8, %rd19;\n"
    "    ld.global.v4.f32 {%f32, %f33, %f34, %f35}, [%rd8];\n"
    "    add.s64 %rd8, %rd8, %rd16;\n"
    "    ld.global.v4.f32 {%f36, %f37, %f38, %f39}, [%rd8];\n"
    "    add.s64 %rd8, %rd8, %rd16;\n"
    "    ld.global.v4.f32 {%f40, %f41, %f42, %f43}, [%rd8];\n"
    "    add.s64 %rd8, %rd8, %rd16;\n"
    "    ld.global.v4.f32 {%f44, %f45, %f46, %f47}, [%rd8];\n"
    "\n"
    "    fma.rn.f32 %f0,  %f16, %f32, %f0;\n"
    "    fma.rn.f32 %f1,  %f16, %f33, %f1;\n"
    "    fma.rn.f32 %f2,  %f16, %f34, %f2;\n"
    "    fma.rn.f32 %f3,  %f16, %f35, %f3;\n"
    "    fma.rn.f32 %f4,  %f20, %f32, %f4;\n"
    "    fma.rn.f32 %f5,  %f20, %f33, %f5;\n"
    "    fma.rn.f32 %f6,  %f20, %f34, %f6;\n"
    "    fma.rn.f32 %f7,  %f20, %f35, %f7;\n"
    "    fma.rn.f32 %f8,  %f24, %f32, %f8;\n"
    "    fma.rn.f32 %f9,  %f24, %f33, %f9;\n"
    "    fma.rn.f32 %f10, %f24, %f34, %f10;\n"
    "    fma.rn.f32 %f11, %f24, %f35, %f11;\n"
    "    fma.rn.f32 %f12, %f28, %f32, %f12;\n"
    "    fma.rn.f32 %f13, %f28, %f33, %f13;\n"
    "    fma.rn.f32 %f14, %f28, %f34, %f14;\n"
    "    fma.rn.f32 %f15, %f28, %f35, %f15;\n"
    "\n"
    "    fma.rn.f32 %f0,  %f17, %f36, %f0;\n"
    "    fma.rn.f32 %f1,  %f17, %f37, %f1;\n"
    "    fma.rn.f32 %f2,  %f17, %f38, %f2;\n"
    "    fma.rn.f32 %f3,  %f17, %f39, %f3;\n"
    "    fma.rn.f32 %f4,  %f21, %f36, %f4;\n"
    "    fma.rn.f32 %f5,  %f21, %f37, %f5;\n"
    "    fma.rn.f32 %f6,  %f21, %f38, %f6;\n"
    "    fma.rn.f32 %f7,  %f21, %f39, %f7;\n"
    "    fma.rn.f32 %f8,  %f25, %f36, %f8;\n"
    "    fma.rn.f32 %f9,  %f25, %f37, %f9;\n"
    "    fma.rn.f32 %f10, %f25, %f38, %f10;\n"
    "    fma.rn.f32 %f11, %f25, %f39, %f11;\n"
    "    fma.rn.f32 %f12, %f29, %f36, %f12;\n"
    "    fma.rn.f32 %f13, %f29, %f37, %f13;\n"
    "    fma.rn.f32 %f14, %f29, %f38, %f14;\n"
    "    fma.rn.f32 %f15, %f29, %f39, %f15;\n"
    "\n"
    "    fma.rn.f32 %f0,  %f18, %f40, %f0;\n"
    "    fma.rn.f32 %f1,  %f18, %f41, %f1;\n"
    "    fma.rn.f32 %f2,  %f18, %f42, %f2;\n"
    "    fma.rn.f32 %f3,  %f18, %f43, %f3;\n"
    "    fma.rn.f32 %f4,  %f22, %f40, %f4;\n"
    "    fma.rn.f32 %f5,  %f22, %f41, %f5;\n"
    "    fma.rn.f32 %f6,  %f22, %f42, %f6;\n"
    "    fma.rn.f32 %f7,  %f22, %f43, %f7;\n"
    "    fma.rn.f32 %f8,  %f26, %f40, %f8;\n"
    "    fma.rn.f32 %f9,  %f26, %f41, %f9;\n"
    "    fma.rn.f32 %f10, %f26, %f42, %f10;\n"
    "    fma.rn.f32 %f11, %f26, %f43, %f11;\n"
    "    fma.rn.f32 %f12, %f30, %f40, %f12;\n"
    "    fma.rn.f32 %f13, %f30, %f41, %f13;\n"
    "    fma.rn.f32 %f14, %f30, %f42, %f14;\n"
    "    fma.rn.f32 %f15, %f30, %f43, %f15;\n"
    "\n"
    "    fma.rn.f32 %f0,  %f19, %f44, %f0;\n"
    "    fma.rn.f32 %f1,  %f19, %f45, %f1;\n"
    "    fma.rn.f32 %f2,  %f19, %f46, %f2;\n"
    "    fma.rn.f32 %f3,  %f19, %f47, %f3;\n"
    "    fma.rn.f32 %f4,  %f23, %f44, %f4;\n"
    "    fma.rn.f32 %f5,  %f23, %f45, %f5;\n"
    "    fma.rn.f32 %f6,  %f23, %f46, %f6;\n"
    "    fma.rn.f32 %f7,  %f23, %f47, %f7;\n"
    "    fma.rn.f32 %f8,  %f27, %f44, %f8;\n"
    "    fma.rn.f32 %f9,  %f27, %f45, %f9;\n"
    "    fma.rn.f32 %f10, %f27, %f46, %f10;\n"
    "    fma.rn.f32 %f11, %f27, %f47, %f11;\n"
    "    fma.rn.f32 %f12, %f31, %f44, %f12;\n"
    "    fma.rn.f32 %f13, %f31, %f45, %f13;\n"
    "    fma.rn.f32 %f14, %f31, %f46, %f14;\n"
    "    fma.rn.f32 %f15, %f31, %f47, %f15;\n"
    "\n"
    "    add.s64 %rd4, %rd4, 16;\n"
    "    add.s64 %rd5, %rd5, 16;\n"
    "    add.s64 %rd6, %rd6, 16;\n"
    "    add.s64 %rd7, %rd7, 16;\n"
    "    add.u32 %r13, %r13, 4;\n"
    "    bra LOOP;\n"
    "\n"
    "STORE:\n"
    "    setp.lt.u32 %p4, %r8,  %r1;\n"
    "    setp.lt.u32 %p1, %r16, %r1;\n"
    "    setp.lt.u32 %p2, %r17, %r1;\n"
    "    setp.lt.u32 %p3, %r18, %r1;\n"
    "    setp.lt.u32 %p5, %r12, %r2;\n"
    "    add.s32 %r26, %r12, 1;\n"
    "    setp.lt.u32 %p6, %r26, %r2;\n"
    "    add.s32 %r26, %r12, 2;\n"
    "    setp.lt.u32 %p7, %r26, %r2;\n"
    "    add.s32 %r26, %r12, 3;\n"
    "    setp.lt.u32 %p8, %r26, %r2;\n"
    "\n"
    "    and.pred %p9,  %p4, %p5;\n"
    "    @%p9 st.global.f32 [%rd9+0],  %f0;\n"
    "    and.pred %p10, %p4, %p6;\n"
    "    @%p10 st.global.f32 [%rd9+4],  %f1;\n"
    "    and.pred %p11, %p4, %p7;\n"
    "    @%p11 st.global.f32 [%rd9+8],  %f2;\n"
    "    and.pred %p12, %p4, %p8;\n"
    "    @%p12 st.global.f32 [%rd9+12], %f3;\n"
    "\n"
    "    and.pred %p13, %p1, %p5;\n"
    "    @%p13 st.global.f32 [%rd10+0],  %f4;\n"
    "    and.pred %p14, %p1, %p6;\n"
    "    @%p14 st.global.f32 [%rd10+4],  %f5;\n"
    "    and.pred %p15, %p1, %p7;\n"
    "    @%p15 st.global.f32 [%rd10+8],  %f6;\n"
    "    and.pred %p16, %p1, %p8;\n"
    "    @%p16 st.global.f32 [%rd10+12], %f7;\n"
    "\n"
    "    and.pred %p17, %p2, %p5;\n"
    "    @%p17 st.global.f32 [%rd11+0],  %f8;\n"
    "    and.pred %p18, %p2, %p6;\n"
    "    @%p18 st.global.f32 [%rd11+4],  %f9;\n"
    "    and.pred %p19, %p2, %p7;\n"
    "    @%p19 st.global.f32 [%rd11+8],  %f10;\n"
    "    and.pred %p20, %p2, %p8;\n"
    "    @%p20 st.global.f32 [%rd11+12], %f11;\n"
    "\n"
    "    and.pred %p21, %p3, %p5;\n"
    "    @%p21 st.global.f32 [%rd12+0],  %f12;\n"
    "    and.pred %p22, %p3, %p6;\n"
    "    @%p22 st.global.f32 [%rd12+4],  %f13;\n"
    "    and.pred %p23, %p3, %p7;\n"
    "    @%p23 st.global.f32 [%rd12+8],  %f14;\n"
    "    and.pred %p24, %p3, %p8;\n"
    "    @%p24 st.global.f32 [%rd12+12], %f15;\n"
    "\n"
    "DONE:\n"
    "    ret;\n"
    "}";

static const char *PTX_BODY_SHARED =
    "// shared memory tiling sgemm: BM=64 BN=64 BK=8, block 16x16 threads,\n"
    "// each thread computes 4x4 of C (same register layout as the 4x4 version).\n"
    "// Per K-tile: 256 threads cooperatively stage A(64x8) and B(8x64) into\n"
    "// shared (2+2 scalars per thread, predicated for M/N/K tails), bar.sync,\n"
    "// then 16 v4 shared loads feed 128 FMAs.\n"
    "// Global traffic drops 16x: every element is fetched from global once per\n"
    "// block instead of once per row-thread/col-thread (0.5 -> 8 FMA/byte).\n"
    "//\n"
    "// Rules that must not be broken (each cost a debugging round before):\n"
    "//   1) PTX comments must be ASCII only.\n"
    "//   2) Addresses may be '64-bit register + immediate' only.\n"
    "//   3) mul.wide.u32 second operand must be a register, never an immediate.\n"
    "//   4) No early exit before the first bar.sync: every one of the 256\n"
    "//      threads must reach it. Out-of-range blocks run the full path with\n"
    "//      zeroed shared tiles and predicated-off stores.\n"
    ".visible .entry sgemm_shared(\n"
    "    .param .u64 p0,\n"
    "    .param .u64 p1,\n"
    "    .param .u64 p2,\n"
    "    .param .u32 p3,\n"
    "    .param .u32 p4,\n"
    "    .param .u32 p5\n"
    ")\n"
    "{\n"
    "    .reg .pred %p<26>;\n"
    "    .reg .b32  %r<28>;\n"
    "    .reg .b64  %rd<24>;\n"
    "    .reg .f32  %f<82>;\n"
    "    .shared .align 16 .f32 sA[512];\n"
    "    .shared .align 16 .f32 sB[512];\n"
    "\n"
    "    ld.param.u64 %rd1, [p0];\n"
    "    ld.param.u64 %rd2, [p1];\n"
    "    ld.param.u64 %rd3, [p2];\n"
    "    ld.param.u32  %r1, [p3];\n"
    "    ld.param.u32  %r2, [p4];\n"
    "    ld.param.u32  %r3, [p5];\n"
    "\n"
    "    mov.u32 %r4, %tid.x;\n"
    "    mov.u32 %r5, %tid.y;\n"
    "    mov.u32 %r6, %ctaid.x;\n"
    "    mov.u32 %r7, %ctaid.y;\n"
    "\n"
    "    shl.b32 %r8,  %r7, 6;\n"
    "    shl.b32 %r9,  %r5, 2;\n"
    "    add.s32 %r8,  %r8, %r9;\n"
    "    shl.b32 %r12, %r6, 6;\n"
    "    shl.b32 %r11, %r4, 2;\n"
    "    add.s32 %r12, %r12, %r11;\n"
    "    shl.b32 %r9,  %r7, 6;\n"
    "    shl.b32 %r11, %r6, 6;\n"
    "\n"
    "    mul.lo.u32 %r10, %r5, 16;\n"
    "    add.u32 %r10, %r10, %r4;\n"
    "\n"
    "    shl.b32 %r24, %r5, 2;\n"
    "    add.s32 %r25, %r24, 1;\n"
    "    add.s32 %r26, %r24, 2;\n"
    "    add.s32 %r27, %r24, 3;\n"
    "\n"
    "    add.s32 %r16, %r8, 1;\n"
    "    add.s32 %r17, %r8, 2;\n"
    "    add.s32 %r18, %r8, 3;\n"
    "\n"
    "    cvt.u64.u32 %rd15, %r2;\n"
    "    shl.b64 %rd15, %rd15, 2;\n"
    "    mov.u64 %rd13, sA;\n"
    "    mov.u64 %rd14, sB;\n"
    "\n"
    "    mov.f32 %f0,  0f00000000;\n"
    "    mov.f32 %f1, 0f00000000;\n"
    "    mov.f32 %f2, 0f00000000;\n"
    "    mov.f32 %f3, 0f00000000;\n"
    "    mov.f32 %f4, 0f00000000;\n"
    "    mov.f32 %f5, 0f00000000;\n"
    "    mov.f32 %f6, 0f00000000;\n"
    "    mov.f32 %f7, 0f00000000;\n"
    "    mov.f32 %f8, 0f00000000;\n"
    "    mov.f32 %f9, 0f00000000;\n"
    "    mov.f32 %f10, 0f00000000;\n"
    "    mov.f32 %f11, 0f00000000;\n"
    "    mov.f32 %f12, 0f00000000;\n"
    "    mov.f32 %f13, 0f00000000;\n"
    "    mov.f32 %f14, 0f00000000;\n"
    "    mov.f32 %f15, 0f00000000;\n"
    "    mov.u32 %r13, 0;\n"
    "\n"
    "KLOOP:\n"
    "    setp.ge.u32 %p9, %r13, %r3;\n"
    "    @%p9 bra STORE;\n"
    "\n"
    "    // ---- stage A tile (64 rows x 8 cols) into sA ----\n"
    "    shl.b32 %r19, %r10, 1;\n"
    "    shr.u32 %r20, %r19, 3;\n"
    "    and.b32 %r21, %r19, 7;\n"
    "    add.s32 %r22, %r9, %r20;\n"
    "    add.s32 %r23, %r13, %r21;\n"
    "    setp.lt.u32 %p10, %r22, %r1;\n"
    "    setp.lt.u32 %p11, %r23, %r3;\n"
    "    and.pred %p12, %p10, %p11;\n"
    "    mul.wide.u32 %rd4, %r22, %r3;\n"
    "    cvt.u64.u32   %rd16, %r23;\n"
    "    add.s64 %rd4, %rd4, %rd16;\n"
    "    shl.b64 %rd4, %rd4, 2;\n"
    "    add.s64 %rd4, %rd4, %rd1;\n"
    "    @%p12 ld.global.f32 %f80, [%rd4];\n"
    "    @!%p12 mov.f32 %f80, 0f00000000;\n"
    "    cvt.u64.u32 %rd6, %r19;\n"
    "    shl.b64 %rd6, %rd6, 2;\n"
    "    add.u64 %rd6, %rd6, %rd13;\n"
    "    st.shared.f32 [%rd6], %f80;\n"
    "    add.s32 %r23, %r23, 1;\n"
    "    setp.lt.u32 %p11, %r23, %r3;\n"
    "    and.pred %p12, %p10, %p11;\n"
    "    @%p12 ld.global.f32 %f81, [%rd4+4];\n"
    "    @!%p12 mov.f32 %f81, 0f00000000;\n"
    "    st.shared.f32 [%rd6+4], %f81;\n"
    "\n"
    "    // ---- stage B tile (8 rows x 64 cols) into sB ----\n"
    "    shr.u32 %r20, %r19, 6;\n"
    "    and.b32 %r21, %r19, 63;\n"
    "    add.s32 %r22, %r13, %r20;\n"
    "    add.s32 %r23, %r11, %r21;\n"
    "    setp.lt.u32 %p10, %r22, %r3;\n"
    "    setp.lt.u32 %p11, %r23, %r2;\n"
    "    and.pred %p12, %p10, %p11;\n"
    "    mul.wide.u32 %rd5, %r22, %r2;\n"
    "    cvt.u64.u32   %rd16, %r23;\n"
    "    add.s64 %rd5, %rd5, %rd16;\n"
    "    shl.b64 %rd5, %rd5, 2;\n"
    "    add.s64 %rd5, %rd5, %rd2;\n"
    "    @%p12 ld.global.f32 %f80, [%rd5];\n"
    "    @!%p12 mov.f32 %f80, 0f00000000;\n"
    "    cvt.u64.u32 %rd7, %r19;\n"
    "    shl.b64 %rd7, %rd7, 2;\n"
    "    add.u64 %rd7, %rd7, %rd14;\n"
    "    st.shared.f32 [%rd7], %f80;\n"
    "    add.s32 %r23, %r23, 1;\n"
    "    setp.lt.u32 %p11, %r23, %r2;\n"
    "    and.pred %p12, %p10, %p11;\n"
    "    @%p12 ld.global.f32 %f81, [%rd5+4];\n"
    "    @!%p12 mov.f32 %f81, 0f00000000;\n"
    "    st.shared.f32 [%rd7+4], %f81;\n"
    "\n"
    "    bar.sync 0;\n"
    "\n"
    "    // ---- prefetch A rows (4 rows x 8 kk = 8 v4) from sA ----\n"
    "    cvt.u64.u32 %rd16, %r24;\n"
    "    shl.b64 %rd16, %rd16, 5;\n"
    "    add.u64 %rd16, %rd16, %rd13;\n"
    "    ld.shared.v4.f32 {%f16, %f17, %f18, %f19}, [%rd16];\n"
    "    ld.shared.v4.f32 {%f20, %f21, %f22, %f23}, [%rd16+16];\n"
    "    cvt.u64.u32 %rd16, %r25;\n"
    "    shl.b64 %rd16, %rd16, 5;\n"
    "    add.u64 %rd16, %rd16, %rd13;\n"
    "    ld.shared.v4.f32 {%f24, %f25, %f26, %f27}, [%rd16];\n"
    "    ld.shared.v4.f32 {%f28, %f29, %f30, %f31}, [%rd16+16];\n"
    "    cvt.u64.u32 %rd16, %r26;\n"
    "    shl.b64 %rd16, %rd16, 5;\n"
    "    add.u64 %rd16, %rd16, %rd13;\n"
    "    ld.shared.v4.f32 {%f32, %f33, %f34, %f35}, [%rd16];\n"
    "    ld.shared.v4.f32 {%f36, %f37, %f38, %f39}, [%rd16+16];\n"
    "    cvt.u64.u32 %rd16, %r27;\n"
    "    shl.b64 %rd16, %rd16, 5;\n"
    "    add.u64 %rd16, %rd16, %rd13;\n"
    "    ld.shared.v4.f32 {%f40, %f41, %f42, %f43}, [%rd16];\n"
    "    ld.shared.v4.f32 {%f44, %f45, %f46, %f47}, [%rd16+16];\n"
    "\n"
    "    // ---- prefetch B rows (8 kk x 4 cols = 8 v4) from sB ----\n"
    "    cvt.u64.u32 %rd17, %r4;\n"
    "    shl.b64 %rd17, %rd17, 4;\n"
    "    add.u64 %rd17, %rd17, %rd14;\n"
    "    ld.shared.v4.f32 {%f48, %f49, %f50, %f51}, [%rd17+0];\n"
    "    ld.shared.v4.f32 {%f52, %f53, %f54, %f55}, [%rd17+256];\n"
    "    ld.shared.v4.f32 {%f56, %f57, %f58, %f59}, [%rd17+512];\n"
    "    ld.shared.v4.f32 {%f60, %f61, %f62, %f63}, [%rd17+768];\n"
    "    ld.shared.v4.f32 {%f64, %f65, %f66, %f67}, [%rd17+1024];\n"
    "    ld.shared.v4.f32 {%f68, %f69, %f70, %f71}, [%rd17+1280];\n"
    "    ld.shared.v4.f32 {%f72, %f73, %f74, %f75}, [%rd17+1536];\n"
    "    ld.shared.v4.f32 {%f76, %f77, %f78, %f79}, [%rd17+1792];\n"
    "\n"
    "    // ---- 128 FMAs: C[i][j] += A[i][kk] * B[kk][j] ----\n"
    "    fma.rn.f32 %f0, %f16, %f48, %f0;\n"
    "    fma.rn.f32 %f1, %f16, %f49, %f1;\n"
    "    fma.rn.f32 %f2, %f16, %f50, %f2;\n"
    "    fma.rn.f32 %f3, %f16, %f51, %f3;\n"
    "    fma.rn.f32 %f4, %f24, %f48, %f4;\n"
    "    fma.rn.f32 %f5, %f24, %f49, %f5;\n"
    "    fma.rn.f32 %f6, %f24, %f50, %f6;\n"
    "    fma.rn.f32 %f7, %f24, %f51, %f7;\n"
    "    fma.rn.f32 %f8, %f32, %f48, %f8;\n"
    "    fma.rn.f32 %f9, %f32, %f49, %f9;\n"
    "    fma.rn.f32 %f10, %f32, %f50, %f10;\n"
    "    fma.rn.f32 %f11, %f32, %f51, %f11;\n"
    "    fma.rn.f32 %f12, %f40, %f48, %f12;\n"
    "    fma.rn.f32 %f13, %f40, %f49, %f13;\n"
    "    fma.rn.f32 %f14, %f40, %f50, %f14;\n"
    "    fma.rn.f32 %f15, %f40, %f51, %f15;\n"
    "    fma.rn.f32 %f0, %f17, %f52, %f0;\n"
    "    fma.rn.f32 %f1, %f17, %f53, %f1;\n"
    "    fma.rn.f32 %f2, %f17, %f54, %f2;\n"
    "    fma.rn.f32 %f3, %f17, %f55, %f3;\n"
    "    fma.rn.f32 %f4, %f25, %f52, %f4;\n"
    "    fma.rn.f32 %f5, %f25, %f53, %f5;\n"
    "    fma.rn.f32 %f6, %f25, %f54, %f6;\n"
    "    fma.rn.f32 %f7, %f25, %f55, %f7;\n"
    "    fma.rn.f32 %f8, %f33, %f52, %f8;\n"
    "    fma.rn.f32 %f9, %f33, %f53, %f9;\n"
    "    fma.rn.f32 %f10, %f33, %f54, %f10;\n"
    "    fma.rn.f32 %f11, %f33, %f55, %f11;\n"
    "    fma.rn.f32 %f12, %f41, %f52, %f12;\n"
    "    fma.rn.f32 %f13, %f41, %f53, %f13;\n"
    "    fma.rn.f32 %f14, %f41, %f54, %f14;\n"
    "    fma.rn.f32 %f15, %f41, %f55, %f15;\n"
    "    fma.rn.f32 %f0, %f18, %f56, %f0;\n"
    "    fma.rn.f32 %f1, %f18, %f57, %f1;\n"
    "    fma.rn.f32 %f2, %f18, %f58, %f2;\n"
    "    fma.rn.f32 %f3, %f18, %f59, %f3;\n"
    "    fma.rn.f32 %f4, %f26, %f56, %f4;\n"
    "    fma.rn.f32 %f5, %f26, %f57, %f5;\n"
    "    fma.rn.f32 %f6, %f26, %f58, %f6;\n"
    "    fma.rn.f32 %f7, %f26, %f59, %f7;\n"
    "    fma.rn.f32 %f8, %f34, %f56, %f8;\n"
    "    fma.rn.f32 %f9, %f34, %f57, %f9;\n"
    "    fma.rn.f32 %f10, %f34, %f58, %f10;\n"
    "    fma.rn.f32 %f11, %f34, %f59, %f11;\n"
    "    fma.rn.f32 %f12, %f42, %f56, %f12;\n"
    "    fma.rn.f32 %f13, %f42, %f57, %f13;\n"
    "    fma.rn.f32 %f14, %f42, %f58, %f14;\n"
    "    fma.rn.f32 %f15, %f42, %f59, %f15;\n"
    "    fma.rn.f32 %f0, %f19, %f60, %f0;\n"
    "    fma.rn.f32 %f1, %f19, %f61, %f1;\n"
    "    fma.rn.f32 %f2, %f19, %f62, %f2;\n"
    "    fma.rn.f32 %f3, %f19, %f63, %f3;\n"
    "    fma.rn.f32 %f4, %f27, %f60, %f4;\n"
    "    fma.rn.f32 %f5, %f27, %f61, %f5;\n"
    "    fma.rn.f32 %f6, %f27, %f62, %f6;\n"
    "    fma.rn.f32 %f7, %f27, %f63, %f7;\n"
    "    fma.rn.f32 %f8, %f35, %f60, %f8;\n"
    "    fma.rn.f32 %f9, %f35, %f61, %f9;\n"
    "    fma.rn.f32 %f10, %f35, %f62, %f10;\n"
    "    fma.rn.f32 %f11, %f35, %f63, %f11;\n"
    "    fma.rn.f32 %f12, %f43, %f60, %f12;\n"
    "    fma.rn.f32 %f13, %f43, %f61, %f13;\n"
    "    fma.rn.f32 %f14, %f43, %f62, %f14;\n"
    "    fma.rn.f32 %f15, %f43, %f63, %f15;\n"
    "    fma.rn.f32 %f0, %f20, %f64, %f0;\n"
    "    fma.rn.f32 %f1, %f20, %f65, %f1;\n"
    "    fma.rn.f32 %f2, %f20, %f66, %f2;\n"
    "    fma.rn.f32 %f3, %f20, %f67, %f3;\n"
    "    fma.rn.f32 %f4, %f28, %f64, %f4;\n"
    "    fma.rn.f32 %f5, %f28, %f65, %f5;\n"
    "    fma.rn.f32 %f6, %f28, %f66, %f6;\n"
    "    fma.rn.f32 %f7, %f28, %f67, %f7;\n"
    "    fma.rn.f32 %f8, %f36, %f64, %f8;\n"
    "    fma.rn.f32 %f9, %f36, %f65, %f9;\n"
    "    fma.rn.f32 %f10, %f36, %f66, %f10;\n"
    "    fma.rn.f32 %f11, %f36, %f67, %f11;\n"
    "    fma.rn.f32 %f12, %f44, %f64, %f12;\n"
    "    fma.rn.f32 %f13, %f44, %f65, %f13;\n"
    "    fma.rn.f32 %f14, %f44, %f66, %f14;\n"
    "    fma.rn.f32 %f15, %f44, %f67, %f15;\n"
    "    fma.rn.f32 %f0, %f21, %f68, %f0;\n"
    "    fma.rn.f32 %f1, %f21, %f69, %f1;\n"
    "    fma.rn.f32 %f2, %f21, %f70, %f2;\n"
    "    fma.rn.f32 %f3, %f21, %f71, %f3;\n"
    "    fma.rn.f32 %f4, %f29, %f68, %f4;\n"
    "    fma.rn.f32 %f5, %f29, %f69, %f5;\n"
    "    fma.rn.f32 %f6, %f29, %f70, %f6;\n"
    "    fma.rn.f32 %f7, %f29, %f71, %f7;\n"
    "    fma.rn.f32 %f8, %f37, %f68, %f8;\n"
    "    fma.rn.f32 %f9, %f37, %f69, %f9;\n"
    "    fma.rn.f32 %f10, %f37, %f70, %f10;\n"
    "    fma.rn.f32 %f11, %f37, %f71, %f11;\n"
    "    fma.rn.f32 %f12, %f45, %f68, %f12;\n"
    "    fma.rn.f32 %f13, %f45, %f69, %f13;\n"
    "    fma.rn.f32 %f14, %f45, %f70, %f14;\n"
    "    fma.rn.f32 %f15, %f45, %f71, %f15;\n"
    "    fma.rn.f32 %f0, %f22, %f72, %f0;\n"
    "    fma.rn.f32 %f1, %f22, %f73, %f1;\n"
    "    fma.rn.f32 %f2, %f22, %f74, %f2;\n"
    "    fma.rn.f32 %f3, %f22, %f75, %f3;\n"
    "    fma.rn.f32 %f4, %f30, %f72, %f4;\n"
    "    fma.rn.f32 %f5, %f30, %f73, %f5;\n"
    "    fma.rn.f32 %f6, %f30, %f74, %f6;\n"
    "    fma.rn.f32 %f7, %f30, %f75, %f7;\n"
    "    fma.rn.f32 %f8, %f38, %f72, %f8;\n"
    "    fma.rn.f32 %f9, %f38, %f73, %f9;\n"
    "    fma.rn.f32 %f10, %f38, %f74, %f10;\n"
    "    fma.rn.f32 %f11, %f38, %f75, %f11;\n"
    "    fma.rn.f32 %f12, %f46, %f72, %f12;\n"
    "    fma.rn.f32 %f13, %f46, %f73, %f13;\n"
    "    fma.rn.f32 %f14, %f46, %f74, %f14;\n"
    "    fma.rn.f32 %f15, %f46, %f75, %f15;\n"
    "    fma.rn.f32 %f0, %f23, %f76, %f0;\n"
    "    fma.rn.f32 %f1, %f23, %f77, %f1;\n"
    "    fma.rn.f32 %f2, %f23, %f78, %f2;\n"
    "    fma.rn.f32 %f3, %f23, %f79, %f3;\n"
    "    fma.rn.f32 %f4, %f31, %f76, %f4;\n"
    "    fma.rn.f32 %f5, %f31, %f77, %f5;\n"
    "    fma.rn.f32 %f6, %f31, %f78, %f6;\n"
    "    fma.rn.f32 %f7, %f31, %f79, %f7;\n"
    "    fma.rn.f32 %f8, %f39, %f76, %f8;\n"
    "    fma.rn.f32 %f9, %f39, %f77, %f9;\n"
    "    fma.rn.f32 %f10, %f39, %f78, %f10;\n"
    "    fma.rn.f32 %f11, %f39, %f79, %f11;\n"
    "    fma.rn.f32 %f12, %f47, %f76, %f12;\n"
    "    fma.rn.f32 %f13, %f47, %f77, %f13;\n"
    "    fma.rn.f32 %f14, %f47, %f78, %f14;\n"
    "    fma.rn.f32 %f15, %f47, %f79, %f15;\n"
    "\n"
    "    bar.sync 0;\n"
    "    add.u32 %r13, %r13, 8;\n"
    "    bra KLOOP;\n"
    "\n"
    "STORE:\n"
    "    mul.wide.u32 %rd9, %r8, %r2;\n"
    "    cvt.u64.u32   %rd10, %r12;\n"
    "    add.s64       %rd9, %rd9, %rd10;\n"
    "    shl.b64       %rd9, %rd9, 2;\n"
    "    add.s64       %rd9, %rd9, %rd3;\n"
    "    add.s64 %rd10, %rd9,  %rd15;\n"
    "    add.s64 %rd11, %rd10, %rd15;\n"
    "    add.s64 %rd12, %rd11, %rd15;\n"
    "\n"
    "    setp.lt.u32 %p4, %r8,  %r1;\n"
    "    setp.lt.u32 %p1, %r16, %r1;\n"
    "    setp.lt.u32 %p2, %r17, %r1;\n"
    "    setp.lt.u32 %p3, %r18, %r1;\n"
    "    setp.lt.u32 %p5, %r12, %r2;\n"
    "    add.s32 %r26, %r12, 1;\n"
    "    setp.lt.u32 %p6, %r26, %r2;\n"
    "    add.s32 %r26, %r12, 2;\n"
    "    setp.lt.u32 %p7, %r26, %r2;\n"
    "    add.s32 %r26, %r12, 3;\n"
    "    setp.lt.u32 %p8, %r26, %r2;\n"
    "\n"
    "    and.pred %p9, %p4, %p5;\n"
    "    @%p9 st.global.f32 [%rd9+0], %f0;\n"
    "    and.pred %p10, %p4, %p6;\n"
    "    @%p10 st.global.f32 [%rd9+4], %f1;\n"
    "    and.pred %p11, %p4, %p7;\n"
    "    @%p11 st.global.f32 [%rd9+8], %f2;\n"
    "    and.pred %p12, %p4, %p8;\n"
    "    @%p12 st.global.f32 [%rd9+12], %f3;\n"
    "\n"
    "    and.pred %p13, %p1, %p5;\n"
    "    @%p13 st.global.f32 [%rd10+0], %f4;\n"
    "    and.pred %p14, %p1, %p6;\n"
    "    @%p14 st.global.f32 [%rd10+4], %f5;\n"
    "    and.pred %p15, %p1, %p7;\n"
    "    @%p15 st.global.f32 [%rd10+8], %f6;\n"
    "    and.pred %p16, %p1, %p8;\n"
    "    @%p16 st.global.f32 [%rd10+12], %f7;\n"
    "\n"
    "    and.pred %p17, %p2, %p5;\n"
    "    @%p17 st.global.f32 [%rd11+0], %f8;\n"
    "    and.pred %p18, %p2, %p6;\n"
    "    @%p18 st.global.f32 [%rd11+4], %f9;\n"
    "    and.pred %p19, %p2, %p7;\n"
    "    @%p19 st.global.f32 [%rd11+8], %f10;\n"
    "    and.pred %p20, %p2, %p8;\n"
    "    @%p20 st.global.f32 [%rd11+12], %f11;\n"
    "\n"
    "    and.pred %p21, %p3, %p5;\n"
    "    @%p21 st.global.f32 [%rd12+0], %f12;\n"
    "    and.pred %p22, %p3, %p6;\n"
    "    @%p22 st.global.f32 [%rd12+4], %f13;\n"
    "    and.pred %p23, %p3, %p7;\n"
    "    @%p23 st.global.f32 [%rd12+8], %f14;\n"
    "    and.pred %p24, %p3, %p8;\n"
    "    @%p24 st.global.f32 [%rd12+12], %f15;\n"
    "\n"
    "DONE:\n"
    "    ret;\n"
    "}";

/* ============================================================================
 * conv2d —— 单精度直接卷积（互相关，pad=0），每线程算一个输出格。
 * 三维网格：x=输出列 / y=输出行 / z=输出通道，block 恒 16x16。
 *   out[o, i, j] = Σ_ic Σ_a,b x[ic, i*S+a, j*S+b] · k[o, (ic*KH+a)*KW+b]
 * 布局：x 摊平 (I*H, W)、k 摊平 (O, I*KH*KW)、out 摊平 (O*OH, OW)。
 * 标量载入：无对齐要求；越界不可能发生（i<OH ⇒ i*S+KH-1 < H 由构造保证），
 *   不需要 min() 钳位。地址算术全程 32 位（元素数 < 2^31，tb 尺寸上限保证），
 *   访存前 cvt.u64.u32 + shl.b64 2 转字节。四坑全守：tid/ctaid 先 mov、
 *   常数先 mov 进寄存器再乘、PTX 串内零注释、全 ASCII。独立成模块，
 *   不挤 sgemm 的 64K 镜像；编不过取不到都降级 NULL，conv 留 CPU。 */
static const char *PTX_BODY_CONV2D =
    ".visible .entry conv2d(\n"
    "    .param .u64 p_x,\n"
    "    .param .u64 p_w,\n"
    "    .param .u64 p_o,\n"
    "    .param .u32 p_I,\n"
    "    .param .u32 p_H,\n"
    "    .param .u32 p_W,\n"
    "    .param .u32 p_O,\n"
    "    .param .u32 p_KH,\n"
    "    .param .u32 p_KW,\n"
    "    .param .u32 p_S,\n"
    "    .param .u32 p_OH,\n"
    "    .param .u32 p_OW,\n"
    "    .param .u32 p_OPAD\n"
    ")\n"
    "{\n"
    "    .reg .pred %p<40>;\n"
    "    .reg .b32  %r<32>;\n"
    "    .reg .b64  %rd<28>;\n"
    "    .reg .f32  %f<84>;\n"
    "\n"
    "    ld.param.u64 %rd1, [p_x];\n"
    "    ld.param.u64 %rd2, [p_w];\n"
    "    ld.param.u64 %rd3, [p_o];\n"
    "    ld.param.u32 %r2, [p_I];\n"
    "    ld.param.u32 %r3, [p_H];\n"
    "    ld.param.u32 %r4, [p_W];\n"
    "    ld.param.u32 %r5, [p_O];\n"
    "    ld.param.u32 %r6, [p_KH];\n"
    "    ld.param.u32 %r7, [p_KW];\n"
    "    ld.param.u32 %r8, [p_S];\n"
    "    ld.param.u32 %r9, [p_OH];\n"
    "    ld.param.u32 %r10, [p_OW];\n"
    "    ld.param.u32 %r11, [p_OPAD];\n"
    "\n"
    "    // nOgrp = ceil(O/16); z axis splits into (batch n, output channel group)\n"
    "    add.u32 %r1, %r5, 15;\n"
    "    shr.u32 %r1, %r1, 4;\n"
    "    mov.u32 %r28, %ctaid.z;\n"
    "    div.u32 %r12, %r28, %r1;\n"
    "    rem.u32 %r13, %r28, %r1;\n"
    "\n"
    "    // ow_base = ctaid.x*32 + tid.x*2 ; oh_base = ctaid.y*32 + tid.y*2\n"
    "    mov.u32 %r28, %ctaid.x;\n"
    "    shl.b32 %r29, %r28, 5;\n"
    "    mov.u32 %r28, %tid.x;\n"
    "    mul.lo.u32 %r30, %r28, 2;\n"
    "    add.u32 %r14, %r29, %r30;\n"
    "    mov.u32 %r28, %ctaid.y;\n"
    "    shl.b32 %r29, %r28, 5;\n"
    "    mov.u32 %r28, %tid.y;\n"
    "    mul.lo.u32 %r30, %r28, 2;\n"
    "    add.u32 %r15, %r29, %r30;\n"
    "\n"
    "    // oc_base = group index * 16\n"
    "    mul.lo.u32 %r16, %r13, 16;\n"
    "\n"
    "    // element strides\n"
    "    mul.lo.u32 %r17, %r2, %r3;\n"
    "    mul.lo.u32 %r17, %r17, %r4;\n"
    "    mul.lo.u32 %r20, %r8, %r4;\n"
    "\n"
    "    // x start element = n*I*H*W + oh_base*S*W + ow_base*S\n"
    "    mul.lo.u32 %r28, %r12, %r17;\n"
    "    mul.lo.u32 %r29, %r15, %r20;\n"
    "    add.u32 %r28, %r28, %r29;\n"
    "    mul.lo.u32 %r29, %r14, %r8;\n"
    "    add.u32 %r21, %r28, %r29;\n"
    "\n"
    "    // column / row byte offsets for one output column / row\n"
    "    cvt.u64.u32 %rd26, %r8;\n"
    "    shl.b64 %rd26, %rd26, 2;\n"
    "    cvt.u64.u32 %rd27, %r20;\n"
    "    shl.b64 %rd27, %rd27, 2;\n"
    "    // x addresses: one per spatial position, all advanced by 1 element per kw\n"
    "    cvt.u64.u32 %rd22, %r21;\n"
    "    shl.b64 %rd22, %rd22, 2;\n"
    "    add.s64 %rd22, %rd22, %rd1;\n"
    "    cvt.u64.u32 %rd23, %r21;\n"
    "    shl.b64 %rd23, %rd23, 2;\n"
    "    add.s64 %rd23, %rd23, %rd1;\n"
    "    cvt.u64.u32 %rd24, %r21;\n"
    "    shl.b64 %rd24, %rd24, 2;\n"
    "    add.s64 %rd24, %rd24, %rd1;\n"
    "    cvt.u64.u32 %rd25, %r21;\n"
    "    shl.b64 %rd25, %rd25, 2;\n"
    "    add.s64 %rd25, %rd25, %rd1;\n"
    "    add.s64 %rd23, %rd23, %rd26;\n"
    "    add.s64 %rd24, %rd24, %rd27;\n"
    "    add.s64 %rd25, %rd25, %rd26;\n"
    "    add.s64 %rd25, %rd25, %rd27;\n"
    "\n"
    "    // weight address: wt + (ic*KH*KW + kh*KW + kw)*OPAD + oc_base\n"
    "    cvt.u64.u32 %rd8, %r16;\n"
    "    shl.b64 %rd8, %rd8, 2;\n"
    "    add.s64 %rd8, %rd8, %rd2;\n"
    "\n"
    "    // byte strides\n"
    "    mul.lo.u32 %r28, %r3, %r4;\n"
    "    mul.lo.u32 %r28, %r28, 4;\n"
    "    cvt.u64.u32 %rd11, %r28;\n"
    "    mul.lo.u32 %r28, %r4, 4;\n"
    "    cvt.u64.u32 %rd12, %r28;\n"
    "    mul.lo.u32 %r28, %r11, 4;\n"
    "    cvt.u64.u32 %rd13, %r28;\n"
    "    mul.lo.u32 %r28, %r7, 4;\n"
    "    cvt.u64.u32 %rd16, %r28;\n"
    "    mul.lo.u32 %r28, %r6, %r4;\n"
    "    mul.lo.u32 %r28, %r28, 4;\n"
    "    cvt.u64.u32 %rd17, %r28;\n"
    "    mul.lo.u32 %r28, %r10, 4;\n"
    "    cvt.u64.u32 %rd18, %r28;\n"
    "    mul.lo.u32 %r24, %r9, %r10;\n"
    "    mul.lo.u32 %r28, %r24, 4;\n"
    "    cvt.u64.u32 %rd19, %r28;\n"
    "\n"
    "    // zero the accumulators\n"
    "    mov.f32 %f0, 0f00000000;\n"
    "    mov.f32 %f1, 0f00000000;\n"
    "    mov.f32 %f2, 0f00000000;\n"
    "    mov.f32 %f3, 0f00000000;\n"
    "    mov.f32 %f4, 0f00000000;\n"
    "    mov.f32 %f5, 0f00000000;\n"
    "    mov.f32 %f6, 0f00000000;\n"
    "    mov.f32 %f7, 0f00000000;\n"
    "    mov.f32 %f8, 0f00000000;\n"
    "    mov.f32 %f9, 0f00000000;\n"
    "    mov.f32 %f10, 0f00000000;\n"
    "    mov.f32 %f11, 0f00000000;\n"
    "    mov.f32 %f12, 0f00000000;\n"
    "    mov.f32 %f13, 0f00000000;\n"
    "    mov.f32 %f14, 0f00000000;\n"
    "    mov.f32 %f15, 0f00000000;\n"
    "    mov.f32 %f16, 0f00000000;\n"
    "    mov.f32 %f17, 0f00000000;\n"
    "    mov.f32 %f18, 0f00000000;\n"
    "    mov.f32 %f19, 0f00000000;\n"
    "    mov.f32 %f20, 0f00000000;\n"
    "    mov.f32 %f21, 0f00000000;\n"
    "    mov.f32 %f22, 0f00000000;\n"
    "    mov.f32 %f23, 0f00000000;\n"
    "    mov.f32 %f24, 0f00000000;\n"
    "    mov.f32 %f25, 0f00000000;\n"
    "    mov.f32 %f26, 0f00000000;\n"
    "    mov.f32 %f27, 0f00000000;\n"
    "    mov.f32 %f28, 0f00000000;\n"
    "    mov.f32 %f29, 0f00000000;\n"
    "    mov.f32 %f30, 0f00000000;\n"
    "    mov.f32 %f31, 0f00000000;\n"
    "    mov.f32 %f32, 0f00000000;\n"
    "    mov.f32 %f33, 0f00000000;\n"
    "    mov.f32 %f34, 0f00000000;\n"
    "    mov.f32 %f35, 0f00000000;\n"
    "    mov.f32 %f36, 0f00000000;\n"
    "    mov.f32 %f37, 0f00000000;\n"
    "    mov.f32 %f38, 0f00000000;\n"
    "    mov.f32 %f39, 0f00000000;\n"
    "    mov.f32 %f40, 0f00000000;\n"
    "    mov.f32 %f41, 0f00000000;\n"
    "    mov.f32 %f42, 0f00000000;\n"
    "    mov.f32 %f43, 0f00000000;\n"
    "    mov.f32 %f44, 0f00000000;\n"
    "    mov.f32 %f45, 0f00000000;\n"
    "    mov.f32 %f46, 0f00000000;\n"
    "    mov.f32 %f47, 0f00000000;\n"
    "    mov.f32 %f48, 0f00000000;\n"
    "    mov.f32 %f49, 0f00000000;\n"
    "    mov.f32 %f50, 0f00000000;\n"
    "    mov.f32 %f51, 0f00000000;\n"
    "    mov.f32 %f52, 0f00000000;\n"
    "    mov.f32 %f53, 0f00000000;\n"
    "    mov.f32 %f54, 0f00000000;\n"
    "    mov.f32 %f55, 0f00000000;\n"
    "    mov.f32 %f56, 0f00000000;\n"
    "    mov.f32 %f57, 0f00000000;\n"
    "    mov.f32 %f58, 0f00000000;\n"
    "    mov.f32 %f59, 0f00000000;\n"
    "    mov.f32 %f60, 0f00000000;\n"
    "    mov.f32 %f61, 0f00000000;\n"
    "    mov.f32 %f62, 0f00000000;\n"
    "    mov.f32 %f63, 0f00000000;\n"
    "\n"
    "    mov.u32 %r25, 0;\n"
    "ICLOOP:\n"
    "    setp.ge.u32 %p1, %r25, %r2;\n"
    "    @%p1 bra STORE;\n"
    "    mov.u32 %r26, 0;\n"
    "    mov.u32 %r27, 0;\n"
    "KHLOOP:\n"
    "KWLOOP:\n"
    "    setp.ge.u32 %p3, %r27, %r7;\n"
    "    @%p3 bra KHDONE;\n"
    "\n"
    "    ld.global.nc.v4.f32 {%f64, %f65, %f66, %f67}, [%rd8+0];\n"
    "    ld.global.nc.v4.f32 {%f68, %f69, %f70, %f71}, [%rd8+16];\n"
    "    ld.global.nc.v4.f32 {%f72, %f73, %f74, %f75}, [%rd8+32];\n"
    "    ld.global.nc.v4.f32 {%f76, %f77, %f78, %f79}, [%rd8+48];\n"
    "    ld.global.nc.f32 %f80, [%rd22];\n"
    "    ld.global.nc.f32 %f81, [%rd23];\n"
    "    ld.global.nc.f32 %f82, [%rd24];\n"
    "    ld.global.nc.f32 %f83, [%rd25];\n"
    "\n"
    "    fma.rn.f32 %f0, %f64, %f80, %f0;\n"
    "    fma.rn.f32 %f1, %f64, %f81, %f1;\n"
    "    fma.rn.f32 %f2, %f64, %f82, %f2;\n"
    "    fma.rn.f32 %f3, %f64, %f83, %f3;\n"
    "    fma.rn.f32 %f4, %f65, %f80, %f4;\n"
    "    fma.rn.f32 %f5, %f65, %f81, %f5;\n"
    "    fma.rn.f32 %f6, %f65, %f82, %f6;\n"
    "    fma.rn.f32 %f7, %f65, %f83, %f7;\n"
    "    fma.rn.f32 %f8, %f66, %f80, %f8;\n"
    "    fma.rn.f32 %f9, %f66, %f81, %f9;\n"
    "    fma.rn.f32 %f10, %f66, %f82, %f10;\n"
    "    fma.rn.f32 %f11, %f66, %f83, %f11;\n"
    "    fma.rn.f32 %f12, %f67, %f80, %f12;\n"
    "    fma.rn.f32 %f13, %f67, %f81, %f13;\n"
    "    fma.rn.f32 %f14, %f67, %f82, %f14;\n"
    "    fma.rn.f32 %f15, %f67, %f83, %f15;\n"
    "    fma.rn.f32 %f16, %f68, %f80, %f16;\n"
    "    fma.rn.f32 %f17, %f68, %f81, %f17;\n"
    "    fma.rn.f32 %f18, %f68, %f82, %f18;\n"
    "    fma.rn.f32 %f19, %f68, %f83, %f19;\n"
    "    fma.rn.f32 %f20, %f69, %f80, %f20;\n"
    "    fma.rn.f32 %f21, %f69, %f81, %f21;\n"
    "    fma.rn.f32 %f22, %f69, %f82, %f22;\n"
    "    fma.rn.f32 %f23, %f69, %f83, %f23;\n"
    "    fma.rn.f32 %f24, %f70, %f80, %f24;\n"
    "    fma.rn.f32 %f25, %f70, %f81, %f25;\n"
    "    fma.rn.f32 %f26, %f70, %f82, %f26;\n"
    "    fma.rn.f32 %f27, %f70, %f83, %f27;\n"
    "    fma.rn.f32 %f28, %f71, %f80, %f28;\n"
    "    fma.rn.f32 %f29, %f71, %f81, %f29;\n"
    "    fma.rn.f32 %f30, %f71, %f82, %f30;\n"
    "    fma.rn.f32 %f31, %f71, %f83, %f31;\n"
    "    fma.rn.f32 %f32, %f72, %f80, %f32;\n"
    "    fma.rn.f32 %f33, %f72, %f81, %f33;\n"
    "    fma.rn.f32 %f34, %f72, %f82, %f34;\n"
    "    fma.rn.f32 %f35, %f72, %f83, %f35;\n"
    "    fma.rn.f32 %f36, %f73, %f80, %f36;\n"
    "    fma.rn.f32 %f37, %f73, %f81, %f37;\n"
    "    fma.rn.f32 %f38, %f73, %f82, %f38;\n"
    "    fma.rn.f32 %f39, %f73, %f83, %f39;\n"
    "    fma.rn.f32 %f40, %f74, %f80, %f40;\n"
    "    fma.rn.f32 %f41, %f74, %f81, %f41;\n"
    "    fma.rn.f32 %f42, %f74, %f82, %f42;\n"
    "    fma.rn.f32 %f43, %f74, %f83, %f43;\n"
    "    fma.rn.f32 %f44, %f75, %f80, %f44;\n"
    "    fma.rn.f32 %f45, %f75, %f81, %f45;\n"
    "    fma.rn.f32 %f46, %f75, %f82, %f46;\n"
    "    fma.rn.f32 %f47, %f75, %f83, %f47;\n"
    "    fma.rn.f32 %f48, %f76, %f80, %f48;\n"
    "    fma.rn.f32 %f49, %f76, %f81, %f49;\n"
    "    fma.rn.f32 %f50, %f76, %f82, %f50;\n"
    "    fma.rn.f32 %f51, %f76, %f83, %f51;\n"
    "    fma.rn.f32 %f52, %f77, %f80, %f52;\n"
    "    fma.rn.f32 %f53, %f77, %f81, %f53;\n"
    "    fma.rn.f32 %f54, %f77, %f82, %f54;\n"
    "    fma.rn.f32 %f55, %f77, %f83, %f55;\n"
    "    fma.rn.f32 %f56, %f78, %f80, %f56;\n"
    "    fma.rn.f32 %f57, %f78, %f81, %f57;\n"
    "    fma.rn.f32 %f58, %f78, %f82, %f58;\n"
    "    fma.rn.f32 %f59, %f78, %f83, %f59;\n"
    "    fma.rn.f32 %f60, %f79, %f80, %f60;\n"
    "    fma.rn.f32 %f61, %f79, %f81, %f61;\n"
    "    fma.rn.f32 %f62, %f79, %f82, %f62;\n"
    "    fma.rn.f32 %f63, %f79, %f83, %f63;\n"
    "\n"
    "    add.s64 %rd8, %rd8, %rd13;\n"
    "    add.s64 %rd22, %rd22, 4;\n"
    "    add.s64 %rd23, %rd23, 4;\n"
    "    add.s64 %rd24, %rd24, 4;\n"
    "    add.s64 %rd25, %rd25, 4;\n"
    "    add.u32 %r27, %r27, 1;\n"
    "    bra KWLOOP;\n"
    "\n"
    "KHDONE:\n"
    "    sub.s64 %rd22, %rd22, %rd16;\n"
    "    sub.s64 %rd23, %rd23, %rd16;\n"
    "    sub.s64 %rd24, %rd24, %rd16;\n"
    "    sub.s64 %rd25, %rd25, %rd16;\n"
    "    add.s64 %rd22, %rd22, %rd12;\n"
    "    add.s64 %rd23, %rd23, %rd12;\n"
    "    add.s64 %rd24, %rd24, %rd12;\n"
    "    add.s64 %rd25, %rd25, %rd12;\n"
    "    add.u32 %r26, %r26, 1;\n"
    "    setp.ge.u32 %p2, %r26, %r6;\n"
    "    @%p2 bra ICNEXT;\n"
    "    mov.u32 %r27, 0;\n"
    "    bra KHLOOP;\n"
    "\n"
    "ICNEXT:\n"
    "    sub.s64 %rd22, %rd22, %rd17;\n"
    "    sub.s64 %rd23, %rd23, %rd17;\n"
    "    sub.s64 %rd24, %rd24, %rd17;\n"
    "    sub.s64 %rd25, %rd25, %rd17;\n"
    "    add.s64 %rd22, %rd22, %rd11;\n"
    "    add.s64 %rd23, %rd23, %rd11;\n"
    "    add.s64 %rd24, %rd24, %rd11;\n"
    "    add.s64 %rd25, %rd25, %rd11;\n"
    "    add.u32 %r25, %r25, 1;\n"
    "    bra ICLOOP;\n"
    "\n"
    "STORE:\n"
    "    // spatial predicates\n"
    "    setp.lt.u32 %p4, %r15, %r9;\n"
    "    add.u32 %r28, %r15, 1;\n"
    "    setp.lt.u32 %p5, %r28, %r9;\n"
    "    setp.lt.u32 %p6, %r14, %r10;\n"
    "    add.u32 %r28, %r14, 1;\n"
    "    setp.lt.u32 %p7, %r28, %r10;\n"
    "    and.pred %p24, %p4, %p6;\n"
    "    and.pred %p25, %p4, %p7;\n"
    "    and.pred %p26, %p5, %p6;\n"
    "    and.pred %p27, %p5, %p7;\n"
    "    // channel predicates: oc_base+o < O\n"
    "    add.u32 %r28, %r16, 0;\n"
    "    setp.lt.u32 %p8, %r28, %r5;\n"
    "    add.u32 %r28, %r16, 1;\n"
    "    setp.lt.u32 %p9, %r28, %r5;\n"
    "    add.u32 %r28, %r16, 2;\n"
    "    setp.lt.u32 %p10, %r28, %r5;\n"
    "    add.u32 %r28, %r16, 3;\n"
    "    setp.lt.u32 %p11, %r28, %r5;\n"
    "    add.u32 %r28, %r16, 4;\n"
    "    setp.lt.u32 %p12, %r28, %r5;\n"
    "    add.u32 %r28, %r16, 5;\n"
    "    setp.lt.u32 %p13, %r28, %r5;\n"
    "    add.u32 %r28, %r16, 6;\n"
    "    setp.lt.u32 %p14, %r28, %r5;\n"
    "    add.u32 %r28, %r16, 7;\n"
    "    setp.lt.u32 %p15, %r28, %r5;\n"
    "    add.u32 %r28, %r16, 8;\n"
    "    setp.lt.u32 %p16, %r28, %r5;\n"
    "    add.u32 %r28, %r16, 9;\n"
    "    setp.lt.u32 %p17, %r28, %r5;\n"
    "    add.u32 %r28, %r16, 10;\n"
    "    setp.lt.u32 %p18, %r28, %r5;\n"
    "    add.u32 %r28, %r16, 11;\n"
    "    setp.lt.u32 %p19, %r28, %r5;\n"
    "    add.u32 %r28, %r16, 12;\n"
    "    setp.lt.u32 %p20, %r28, %r5;\n"
    "    add.u32 %r28, %r16, 13;\n"
    "    setp.lt.u32 %p21, %r28, %r5;\n"
    "    add.u32 %r28, %r16, 14;\n"
    "    setp.lt.u32 %p22, %r28, %r5;\n"
    "    add.u32 %r28, %r16, 15;\n"
    "    setp.lt.u32 %p23, %r28, %r5;\n"
    "\n"
    "    // out base = ((n*O + oc_base)*OH + oh_base)*OW + ow_base\n"
    "    mul.lo.u32 %r22, %r15, %r10;\n"
    "    add.u32 %r22, %r22, %r14;\n"
    "    mul.lo.u32 %r23, %r12, %r5;\n"
    "    add.u32 %r23, %r23, %r16;\n"
    "    mul.lo.u32 %r23, %r23, %r24;\n"
    "    add.u32 %r30, %r22, %r23;\n"
    "    cvt.u64.u32 %rd9, %r30;\n"
    "    shl.b64 %rd9, %rd9, 2;\n"
    "    add.s64 %rd9, %rd9, %rd3;\n"
    "\n"
    "    // oc = 0\n"
    "    and.pred %p28, %p8, %p24;\n"
    "    and.pred %p29, %p8, %p25;\n"
    "    and.pred %p30, %p8, %p26;\n"
    "    and.pred %p31, %p8, %p27;\n"
    "    add.s64 %rd10, %rd9, 4;\n"
    "    add.s64 %rd20, %rd9, %rd18;\n"
    "    add.s64 %rd21, %rd20, 4;\n"
    "    @%p28 st.global.f32 [%rd9], %f0;\n"
    "    @%p29 st.global.f32 [%rd10], %f1;\n"
    "    @%p30 st.global.f32 [%rd20], %f2;\n"
    "    @%p31 st.global.f32 [%rd21], %f3;\n"
    "    add.s64 %rd9, %rd9, %rd19;\n"
    "    // oc = 1\n"
    "    and.pred %p28, %p9, %p24;\n"
    "    and.pred %p29, %p9, %p25;\n"
    "    and.pred %p30, %p9, %p26;\n"
    "    and.pred %p31, %p9, %p27;\n"
    "    add.s64 %rd10, %rd9, 4;\n"
    "    add.s64 %rd20, %rd9, %rd18;\n"
    "    add.s64 %rd21, %rd20, 4;\n"
    "    @%p28 st.global.f32 [%rd9], %f4;\n"
    "    @%p29 st.global.f32 [%rd10], %f5;\n"
    "    @%p30 st.global.f32 [%rd20], %f6;\n"
    "    @%p31 st.global.f32 [%rd21], %f7;\n"
    "    add.s64 %rd9, %rd9, %rd19;\n"
    "    // oc = 2\n"
    "    and.pred %p28, %p10, %p24;\n"
    "    and.pred %p29, %p10, %p25;\n"
    "    and.pred %p30, %p10, %p26;\n"
    "    and.pred %p31, %p10, %p27;\n"
    "    add.s64 %rd10, %rd9, 4;\n"
    "    add.s64 %rd20, %rd9, %rd18;\n"
    "    add.s64 %rd21, %rd20, 4;\n"
    "    @%p28 st.global.f32 [%rd9], %f8;\n"
    "    @%p29 st.global.f32 [%rd10], %f9;\n"
    "    @%p30 st.global.f32 [%rd20], %f10;\n"
    "    @%p31 st.global.f32 [%rd21], %f11;\n"
    "    add.s64 %rd9, %rd9, %rd19;\n"
    "    // oc = 3\n"
    "    and.pred %p28, %p11, %p24;\n"
    "    and.pred %p29, %p11, %p25;\n"
    "    and.pred %p30, %p11, %p26;\n"
    "    and.pred %p31, %p11, %p27;\n"
    "    add.s64 %rd10, %rd9, 4;\n"
    "    add.s64 %rd20, %rd9, %rd18;\n"
    "    add.s64 %rd21, %rd20, 4;\n"
    "    @%p28 st.global.f32 [%rd9], %f12;\n"
    "    @%p29 st.global.f32 [%rd10], %f13;\n"
    "    @%p30 st.global.f32 [%rd20], %f14;\n"
    "    @%p31 st.global.f32 [%rd21], %f15;\n"
    "    add.s64 %rd9, %rd9, %rd19;\n"
    "    // oc = 4\n"
    "    and.pred %p28, %p12, %p24;\n"
    "    and.pred %p29, %p12, %p25;\n"
    "    and.pred %p30, %p12, %p26;\n"
    "    and.pred %p31, %p12, %p27;\n"
    "    add.s64 %rd10, %rd9, 4;\n"
    "    add.s64 %rd20, %rd9, %rd18;\n"
    "    add.s64 %rd21, %rd20, 4;\n"
    "    @%p28 st.global.f32 [%rd9], %f16;\n"
    "    @%p29 st.global.f32 [%rd10], %f17;\n"
    "    @%p30 st.global.f32 [%rd20], %f18;\n"
    "    @%p31 st.global.f32 [%rd21], %f19;\n"
    "    add.s64 %rd9, %rd9, %rd19;\n"
    "    // oc = 5\n"
    "    and.pred %p28, %p13, %p24;\n"
    "    and.pred %p29, %p13, %p25;\n"
    "    and.pred %p30, %p13, %p26;\n"
    "    and.pred %p31, %p13, %p27;\n"
    "    add.s64 %rd10, %rd9, 4;\n"
    "    add.s64 %rd20, %rd9, %rd18;\n"
    "    add.s64 %rd21, %rd20, 4;\n"
    "    @%p28 st.global.f32 [%rd9], %f20;\n"
    "    @%p29 st.global.f32 [%rd10], %f21;\n"
    "    @%p30 st.global.f32 [%rd20], %f22;\n"
    "    @%p31 st.global.f32 [%rd21], %f23;\n"
    "    add.s64 %rd9, %rd9, %rd19;\n"
    "    // oc = 6\n"
    "    and.pred %p28, %p14, %p24;\n"
    "    and.pred %p29, %p14, %p25;\n"
    "    and.pred %p30, %p14, %p26;\n"
    "    and.pred %p31, %p14, %p27;\n"
    "    add.s64 %rd10, %rd9, 4;\n"
    "    add.s64 %rd20, %rd9, %rd18;\n"
    "    add.s64 %rd21, %rd20, 4;\n"
    "    @%p28 st.global.f32 [%rd9], %f24;\n"
    "    @%p29 st.global.f32 [%rd10], %f25;\n"
    "    @%p30 st.global.f32 [%rd20], %f26;\n"
    "    @%p31 st.global.f32 [%rd21], %f27;\n"
    "    add.s64 %rd9, %rd9, %rd19;\n"
    "    // oc = 7\n"
    "    and.pred %p28, %p15, %p24;\n"
    "    and.pred %p29, %p15, %p25;\n"
    "    and.pred %p30, %p15, %p26;\n"
    "    and.pred %p31, %p15, %p27;\n"
    "    add.s64 %rd10, %rd9, 4;\n"
    "    add.s64 %rd20, %rd9, %rd18;\n"
    "    add.s64 %rd21, %rd20, 4;\n"
    "    @%p28 st.global.f32 [%rd9], %f28;\n"
    "    @%p29 st.global.f32 [%rd10], %f29;\n"
    "    @%p30 st.global.f32 [%rd20], %f30;\n"
    "    @%p31 st.global.f32 [%rd21], %f31;\n"
    "    add.s64 %rd9, %rd9, %rd19;\n"
    "    // oc = 8\n"
    "    and.pred %p28, %p16, %p24;\n"
    "    and.pred %p29, %p16, %p25;\n"
    "    and.pred %p30, %p16, %p26;\n"
    "    and.pred %p31, %p16, %p27;\n"
    "    add.s64 %rd10, %rd9, 4;\n"
    "    add.s64 %rd20, %rd9, %rd18;\n"
    "    add.s64 %rd21, %rd20, 4;\n"
    "    @%p28 st.global.f32 [%rd9], %f32;\n"
    "    @%p29 st.global.f32 [%rd10], %f33;\n"
    "    @%p30 st.global.f32 [%rd20], %f34;\n"
    "    @%p31 st.global.f32 [%rd21], %f35;\n"
    "    add.s64 %rd9, %rd9, %rd19;\n"
    "    // oc = 9\n"
    "    and.pred %p28, %p17, %p24;\n"
    "    and.pred %p29, %p17, %p25;\n"
    "    and.pred %p30, %p17, %p26;\n"
    "    and.pred %p31, %p17, %p27;\n"
    "    add.s64 %rd10, %rd9, 4;\n"
    "    add.s64 %rd20, %rd9, %rd18;\n"
    "    add.s64 %rd21, %rd20, 4;\n"
    "    @%p28 st.global.f32 [%rd9], %f36;\n"
    "    @%p29 st.global.f32 [%rd10], %f37;\n"
    "    @%p30 st.global.f32 [%rd20], %f38;\n"
    "    @%p31 st.global.f32 [%rd21], %f39;\n"
    "    add.s64 %rd9, %rd9, %rd19;\n"
    "    // oc = 10\n"
    "    and.pred %p28, %p18, %p24;\n"
    "    and.pred %p29, %p18, %p25;\n"
    "    and.pred %p30, %p18, %p26;\n"
    "    and.pred %p31, %p18, %p27;\n"
    "    add.s64 %rd10, %rd9, 4;\n"
    "    add.s64 %rd20, %rd9, %rd18;\n"
    "    add.s64 %rd21, %rd20, 4;\n"
    "    @%p28 st.global.f32 [%rd9], %f40;\n"
    "    @%p29 st.global.f32 [%rd10], %f41;\n"
    "    @%p30 st.global.f32 [%rd20], %f42;\n"
    "    @%p31 st.global.f32 [%rd21], %f43;\n"
    "    add.s64 %rd9, %rd9, %rd19;\n"
    "    // oc = 11\n"
    "    and.pred %p28, %p19, %p24;\n"
    "    and.pred %p29, %p19, %p25;\n"
    "    and.pred %p30, %p19, %p26;\n"
    "    and.pred %p31, %p19, %p27;\n"
    "    add.s64 %rd10, %rd9, 4;\n"
    "    add.s64 %rd20, %rd9, %rd18;\n"
    "    add.s64 %rd21, %rd20, 4;\n"
    "    @%p28 st.global.f32 [%rd9], %f44;\n"
    "    @%p29 st.global.f32 [%rd10], %f45;\n"
    "    @%p30 st.global.f32 [%rd20], %f46;\n"
    "    @%p31 st.global.f32 [%rd21], %f47;\n"
    "    add.s64 %rd9, %rd9, %rd19;\n"
    "    // oc = 12\n"
    "    and.pred %p28, %p20, %p24;\n"
    "    and.pred %p29, %p20, %p25;\n"
    "    and.pred %p30, %p20, %p26;\n"
    "    and.pred %p31, %p20, %p27;\n"
    "    add.s64 %rd10, %rd9, 4;\n"
    "    add.s64 %rd20, %rd9, %rd18;\n"
    "    add.s64 %rd21, %rd20, 4;\n"
    "    @%p28 st.global.f32 [%rd9], %f48;\n"
    "    @%p29 st.global.f32 [%rd10], %f49;\n"
    "    @%p30 st.global.f32 [%rd20], %f50;\n"
    "    @%p31 st.global.f32 [%rd21], %f51;\n"
    "    add.s64 %rd9, %rd9, %rd19;\n"
    "    // oc = 13\n"
    "    and.pred %p28, %p21, %p24;\n"
    "    and.pred %p29, %p21, %p25;\n"
    "    and.pred %p30, %p21, %p26;\n"
    "    and.pred %p31, %p21, %p27;\n"
    "    add.s64 %rd10, %rd9, 4;\n"
    "    add.s64 %rd20, %rd9, %rd18;\n"
    "    add.s64 %rd21, %rd20, 4;\n"
    "    @%p28 st.global.f32 [%rd9], %f52;\n"
    "    @%p29 st.global.f32 [%rd10], %f53;\n"
    "    @%p30 st.global.f32 [%rd20], %f54;\n"
    "    @%p31 st.global.f32 [%rd21], %f55;\n"
    "    add.s64 %rd9, %rd9, %rd19;\n"
    "    // oc = 14\n"
    "    and.pred %p28, %p22, %p24;\n"
    "    and.pred %p29, %p22, %p25;\n"
    "    and.pred %p30, %p22, %p26;\n"
    "    and.pred %p31, %p22, %p27;\n"
    "    add.s64 %rd10, %rd9, 4;\n"
    "    add.s64 %rd20, %rd9, %rd18;\n"
    "    add.s64 %rd21, %rd20, 4;\n"
    "    @%p28 st.global.f32 [%rd9], %f56;\n"
    "    @%p29 st.global.f32 [%rd10], %f57;\n"
    "    @%p30 st.global.f32 [%rd20], %f58;\n"
    "    @%p31 st.global.f32 [%rd21], %f59;\n"
    "    add.s64 %rd9, %rd9, %rd19;\n"
    "    // oc = 15\n"
    "    and.pred %p28, %p23, %p24;\n"
    "    and.pred %p29, %p23, %p25;\n"
    "    and.pred %p30, %p23, %p26;\n"
    "    and.pred %p31, %p23, %p27;\n"
    "    add.s64 %rd10, %rd9, 4;\n"
    "    add.s64 %rd20, %rd9, %rd18;\n"
    "    add.s64 %rd21, %rd20, 4;\n"
    "    @%p28 st.global.f32 [%rd9], %f60;\n"
    "    @%p29 st.global.f32 [%rd10], %f61;\n"
    "    @%p30 st.global.f32 [%rd20], %f62;\n"
    "    @%p31 st.global.f32 [%rd21], %f63;\n"
    "\n"
    "    ret;\n"
    "}\n"
    "";

/* ============================================================================
 * conv2d_shr —— 上面那个 conv2d 的快版（第六跳）。
 *
 * 两处改动，都是本机实测逼出来的，不是拍脑袋：
 *
 * (1) 权重搬进 shared memory（**按 ic 分组搬**）。
 *     原来每轮 (ic,kh,kw) 从全局读 4 条 ld.global.nc.v4 取权重（16 个 oc）。
 *     消融实验（build_tmp/probe/_mkvariant.py）：把权重换成 ld.shared 读同一块
 *     垃圾值，0.269 -> 0.198 ms；把权重载入整个去掉，0.200 ms —— 两者几乎
 *     一样，说明「权重这条全局访存路径」就是瓶颈，搬进共享内存之后基本免费。
 *     搬法：先把本块那 16 个 oc 的权重搬进共享内存，再在计算循环里用
 *     ld.shared 广播读（同一地址，全 warp 广播，无冲突）。
 *     共享布局 smem[kk*16 + j]（j = 块内通道）；全局布局 wt[kk*OPAD + oc]。
 *     块内只取 16 个通道，偏移量恰好是 (kk*16 + j)*4，块内是连续 16 个 float。
 *
 *     共享内存 24 KB 放得下 384 个 kk = 24 KB，按 ic 分组：
 *       每组 G = 384/(KH*KW) 个 ic（宿主算好当参数传进来），
 *       整组一次 staging + 两次 bar.sync，组内共享读指针连续推进。
 *     **所以任意 I 都能用**（不是「I*KH*KW<=384」才有份）。
 *     试过「按 ic 逐个搬」：每个 ic 两次屏障 + 暴露的全局载入延迟，
 *     实测慢 23%（0.237 vs 0.192 ms）—— 分组才是对的粒度。
 *
 * (2) 换列映射：thread t 负责输出列 (t, t+16)，不再是 (2t, 2t+1)。
 *     原来同一行 16 个线程读的是元素 0,2,4,...,30 —— 一条 32 字节扇区只用
 *     一半，扇区利用率 50%；改成连续 16 个元素就是 2 条满扇区。写回同样受益。
 *     tile 覆盖范围不变（一块还是 16 oc x 32 oh x 32 ow），越界读兜底区的
 *     需求也不变（最大输入列一模一样）。
 *
 * 实测（本机 GTX 1060 / CC 6.1，主负载 2x56x56 I32 O64 3x3 S1）：
 *     0.270 ms -> 0.192 ms，快 28.9%；占 FP32 峰值 16.9% -> 23.6%。
 *     寄存器 113 -> 109。
 *
 * 限制：KH*KW > 384（核超大）时 G = 0，由宿主侧分流回老内核 conv2d。
 */
static const char *PTX_BODY_CONV2D_SHR =
    "// block = 16 x 16 = 256 threads; one block covers 16 oc x 32 oh x 32 ow.\n"
    "// variant: grouped staging in shared memory + remap\n"
    "\n"
    ".visible .entry conv2d_shr(\n"
    "    .param .u64 p_x,\n"
    "    .param .u64 p_w,\n"
    "    .param .u64 p_o,\n"
    "    .param .u32 p_I,\n"
    "    .param .u32 p_H,\n"
    "    .param .u32 p_W,\n"
    "    .param .u32 p_O,\n"
    "    .param .u32 p_KH,\n"
    "    .param .u32 p_KW,\n"
    "    .param .u32 p_S,\n"
    "    .param .u32 p_OH,\n"
    "    .param .u32 p_OW,\n"
    "    .param .u32 p_OPAD,\n"
    "    .param .u32 p_G\n"
    ")\n"
    "{\n"
    "    .reg .pred %p<40>;\n"
    "    .reg .b32  %r<32>;\n"
    "    .reg .b64  %rd<28>;\n"
    "    .reg .f32  %f<84>;\n"
    "    .shared .align 16 .f32 sW[6144];\n"
    "\n"
    "    ld.param.u64 %rd1, [p_x];\n"
    "    ld.param.u64 %rd2, [p_w];\n"
    "    ld.param.u64 %rd3, [p_o];\n"
    "    ld.param.u32 %r2, [p_I];\n"
    "    ld.param.u32 %r3, [p_H];\n"
    "    ld.param.u32 %r4, [p_W];\n"
    "    ld.param.u32 %r5, [p_O];\n"
    "    ld.param.u32 %r6, [p_KH];\n"
    "    ld.param.u32 %r7, [p_KW];\n"
    "    ld.param.u32 %r8, [p_S];\n"
    "    ld.param.u32 %r9, [p_OH];\n"
    "    ld.param.u32 %r10, [p_OW];\n"
    "    ld.param.u32 %r11, [p_OPAD];\n"
    "\n"
    "    // nOgrp = ceil(O/16); z axis splits into (batch n, output channel group)\n"
    "    add.u32 %r1, %r5, 15;\n"
    "    shr.u32 %r1, %r1, 4;\n"
    "    mov.u32 %r28, %ctaid.z;\n"
    "    div.u32 %r12, %r28, %r1;\n"
    "    rem.u32 %r13, %r28, %r1;\n"
    "\n"
    "    // ow_base = ctaid.x*32 + tid.x*2 ; oh_base = ctaid.y*32 + tid.y*2\n"
    "    mov.u32 %r28, %ctaid.x;\n"
    "    shl.b32 %r29, %r28, 5;\n"
    "    mov.u32 %r28, %tid.x;\n"
    "    add.u32 %r14, %r29, %r28;\n"
    "    mov.u32 %r28, %ctaid.y;\n"
    "    shl.b32 %r29, %r28, 5;\n"
    "    mov.u32 %r28, %tid.y;\n"
    "    mul.lo.u32 %r30, %r28, 2;\n"
    "    add.u32 %r15, %r29, %r30;\n"
    "\n"
    "    // oc_base = group index * 16\n"
    "    mul.lo.u32 %r16, %r13, 16;\n"
    "\n"
    "    // element strides\n"
    "    mul.lo.u32 %r17, %r2, %r3;\n"
    "    mul.lo.u32 %r17, %r17, %r4;\n"
    "    mul.lo.u32 %r20, %r8, %r4;\n"
    "\n"
    "    // x start element = n*I*H*W + oh_base*S*W + ow_base*S\n"
    "    mul.lo.u32 %r28, %r12, %r17;\n"
    "    mul.lo.u32 %r29, %r15, %r20;\n"
    "    add.u32 %r28, %r28, %r29;\n"
    "    mul.lo.u32 %r29, %r14, %r8;\n"
    "    add.u32 %r21, %r28, %r29;\n"
    "\n"
    "    // column / row byte offsets for one output column / row\n"
    "    cvt.u64.u32 %rd26, %r8;\n"
    "    shl.b64 %rd26, %rd26, 2;\n"
    "    cvt.u64.u32 %rd27, %r20;\n"
    "    shl.b64 %rd27, %rd27, 2;\n"
    "    // x addresses: one per spatial position, all advanced by 1 element per kw\n"
    "    cvt.u64.u32 %rd22, %r21;\n"
    "    shl.b64 %rd22, %rd22, 2;\n"
    "    add.s64 %rd22, %rd22, %rd1;\n"
    "    cvt.u64.u32 %rd23, %r21;\n"
    "    shl.b64 %rd23, %rd23, 2;\n"
    "    add.s64 %rd23, %rd23, %rd1;\n"
    "    cvt.u64.u32 %rd24, %r21;\n"
    "    shl.b64 %rd24, %rd24, 2;\n"
    "    add.s64 %rd24, %rd24, %rd1;\n"
    "    cvt.u64.u32 %rd25, %r21;\n"
    "    shl.b64 %rd25, %rd25, 2;\n"
    "    add.s64 %rd25, %rd25, %rd1;\n"
    "    shl.b64 %rd7, %rd26, 4;\n"
    "    add.s64 %rd23, %rd23, %rd7;\n"
    "    add.s64 %rd24, %rd24, %rd27;\n"
    "    add.s64 %rd25, %rd23, %rd27;\n"
    "\n"
    "    // weight address: wt + (ic*KH*KW + kh*KW + kw)*OPAD + oc_base\n"
    "    cvt.u64.u32 %rd8, %r16;\n"
    "    shl.b64 %rd8, %rd8, 2;\n"
    "    add.s64 %rd8, %rd8, %rd2;\n"
    "\n"
    "    // byte strides\n"
    "    mul.lo.u32 %r28, %r3, %r4;\n"
    "    mul.lo.u32 %r28, %r28, 4;\n"
    "    cvt.u64.u32 %rd11, %r28;\n"
    "    mul.lo.u32 %r28, %r4, 4;\n"
    "    cvt.u64.u32 %rd12, %r28;\n"
    "    mul.lo.u32 %r28, %r11, 4;\n"
    "    cvt.u64.u32 %rd13, %r28;\n"
    "    mul.lo.u32 %r28, %r7, 4;\n"
    "    cvt.u64.u32 %rd16, %r28;\n"
    "    mul.lo.u32 %r28, %r6, %r4;\n"
    "    mul.lo.u32 %r28, %r28, 4;\n"
    "    cvt.u64.u32 %rd17, %r28;\n"
    "    mul.lo.u32 %r28, %r10, 4;\n"
    "    cvt.u64.u32 %rd18, %r28;\n"
    "    mul.lo.u32 %r24, %r9, %r10;\n"
    "    mul.lo.u32 %r28, %r24, 4;\n"
    "    cvt.u64.u32 %rd19, %r28;\n"
    "\n"
    "    // ---- grouped staging setup ----\n"
    "    ld.param.u32 %r13, [p_G];           // ic per group (host computed 384/(KH*KW))\n"
    "    mul.lo.u32 %r28, %r6, %r7;\n"
    "    mul.lo.u32 %r28, %r28, %r11;        // KH*KW*OPAD\n"
    "    shl.b32 %r28, %r28, 2;              // bytes: per-ic step of the weight pointer\n"
    "    cvt.u64.u32 %rd4, %r28;\n"
    "    mov.u64 %rd0, sW;                   // shared tile base\n"
    "    mov.u32 %r18, %tid.x;\n"
    "    mov.u32 %r0, %tid.y;\n"
    "    shl.b32 %r0, %r0, 4;\n"
    "    add.u32 %r18, %r18, %r0;            // linear thread id 0..255\n"
    "    mov.u32 %r30, 0;                    // ic index inside the group\n"
    "    // zero the accumulators\n"
    "    mov.f32 %f0, 0f00000000;\n"
    "    mov.f32 %f1, 0f00000000;\n"
    "    mov.f32 %f2, 0f00000000;\n"
    "    mov.f32 %f3, 0f00000000;\n"
    "    mov.f32 %f4, 0f00000000;\n"
    "    mov.f32 %f5, 0f00000000;\n"
    "    mov.f32 %f6, 0f00000000;\n"
    "    mov.f32 %f7, 0f00000000;\n"
    "    mov.f32 %f8, 0f00000000;\n"
    "    mov.f32 %f9, 0f00000000;\n"
    "    mov.f32 %f10, 0f00000000;\n"
    "    mov.f32 %f11, 0f00000000;\n"
    "    mov.f32 %f12, 0f00000000;\n"
    "    mov.f32 %f13, 0f00000000;\n"
    "    mov.f32 %f14, 0f00000000;\n"
    "    mov.f32 %f15, 0f00000000;\n"
    "    mov.f32 %f16, 0f00000000;\n"
    "    mov.f32 %f17, 0f00000000;\n"
    "    mov.f32 %f18, 0f00000000;\n"
    "    mov.f32 %f19, 0f00000000;\n"
    "    mov.f32 %f20, 0f00000000;\n"
    "    mov.f32 %f21, 0f00000000;\n"
    "    mov.f32 %f22, 0f00000000;\n"
    "    mov.f32 %f23, 0f00000000;\n"
    "    mov.f32 %f24, 0f00000000;\n"
    "    mov.f32 %f25, 0f00000000;\n"
    "    mov.f32 %f26, 0f00000000;\n"
    "    mov.f32 %f27, 0f00000000;\n"
    "    mov.f32 %f28, 0f00000000;\n"
    "    mov.f32 %f29, 0f00000000;\n"
    "    mov.f32 %f30, 0f00000000;\n"
    "    mov.f32 %f31, 0f00000000;\n"
    "    mov.f32 %f32, 0f00000000;\n"
    "    mov.f32 %f33, 0f00000000;\n"
    "    mov.f32 %f34, 0f00000000;\n"
    "    mov.f32 %f35, 0f00000000;\n"
    "    mov.f32 %f36, 0f00000000;\n"
    "    mov.f32 %f37, 0f00000000;\n"
    "    mov.f32 %f38, 0f00000000;\n"
    "    mov.f32 %f39, 0f00000000;\n"
    "    mov.f32 %f40, 0f00000000;\n"
    "    mov.f32 %f41, 0f00000000;\n"
    "    mov.f32 %f42, 0f00000000;\n"
    "    mov.f32 %f43, 0f00000000;\n"
    "    mov.f32 %f44, 0f00000000;\n"
    "    mov.f32 %f45, 0f00000000;\n"
    "    mov.f32 %f46, 0f00000000;\n"
    "    mov.f32 %f47, 0f00000000;\n"
    "    mov.f32 %f48, 0f00000000;\n"
    "    mov.f32 %f49, 0f00000000;\n"
    "    mov.f32 %f50, 0f00000000;\n"
    "    mov.f32 %f51, 0f00000000;\n"
    "    mov.f32 %f52, 0f00000000;\n"
    "    mov.f32 %f53, 0f00000000;\n"
    "    mov.f32 %f54, 0f00000000;\n"
    "    mov.f32 %f55, 0f00000000;\n"
    "    mov.f32 %f56, 0f00000000;\n"
    "    mov.f32 %f57, 0f00000000;\n"
    "    mov.f32 %f58, 0f00000000;\n"
    "    mov.f32 %f59, 0f00000000;\n"
    "    mov.f32 %f60, 0f00000000;\n"
    "    mov.f32 %f61, 0f00000000;\n"
    "    mov.f32 %f62, 0f00000000;\n"
    "    mov.f32 %f63, 0f00000000;\n"
    "\n"
    "    mov.u32 %r25, 0;\n"
    "ICLOOP:\n"
    "    setp.ge.u32 %p1, %r25, %r2;\n"
    "    @%p1 bra STORE;\n"
    "    setp.eq.u32 %p32, %r30, 0;         // group head?\n"
    "    @%p32 bra GSTAGE;\n"
    "    bra GCOMPUTE;\n"
    "GSTAGE:\n"
    "    bar.sync 0;                         // previous group finished reading the tile\n"
    "    sub.u32 %r28, %r2, %r25;            // ic left\n"
    "    setp.gt.u32 %p33, %r28, %r13;        // more than G left?\n"
    "    @%p33 mov.u32 %r28, %r13;           // group size = min(G, ic left)\n"
    "    mul.lo.u32 %r19, %r28, %r6;\n"
    "    mul.lo.u32 %r19, %r19, %r7;\n"
    "    shl.b32 %r19, %r19, 2;              // chunks = group size * KH*KW*4\n"
    "    mov.u32 %r0, %r18;                  // c = linear thread id\n"
    "PSTAGE:\n"
    "    setp.ge.u32 %p30, %r0, %r19;\n"
    "    @%p30 bra PSTAGEDONE;\n"
    "    shr.u32 %r28, %r0, 2;               // kk inside the group\n"
    "    mul.lo.u32 %r28, %r28, %r11;        // kk*OPAD\n"
    "    shl.b32 %r28, %r28, 2;              // bytes\n"
    "    and.b32 %r29, %r0, 3;\n"
    "    shl.b32 %r29, %r29, 4;              // (c&3)*16\n"
    "    add.u32 %r28, %r28, %r29;\n"
    "    cvt.u64.u32 %rd14, %r28;\n"
    "    add.s64 %rd14, %rd14, %rd8;         // + running global base\n"
    "    ld.global.nc.v4.f32 {%f64, %f65, %f66, %f67}, [%rd14];\n"
    "    cvt.u64.u32 %rd15, %r0;\n"
    "    shl.b64 %rd15, %rd15, 4;            // c*16\n"
    "    add.u64 %rd15, %rd15, %rd0;         // + sW\n"
    "    st.shared.v4.f32 [%rd15], {%f64, %f65, %f66, %f67};\n"
    "    add.u32 %r0, %r0, 256;\n"
    "    bra PSTAGE;\n"
    "PSTAGEDONE:\n"
    "    bar.sync 0;                         // tile ready\n"
    "    mov.u64 %rd20, %rd0;                // shared read pointer to the tile start\n"
    "GCOMPUTE:\n"
    "    mov.u32 %r26, 0;\n"
    "    mov.u32 %r27, 0;\n"
    "KHLOOP:\n"
    "KWLOOP:\n"
    "    setp.ge.u32 %p3, %r27, %r7;\n"
    "    @%p3 bra KHDONE;\n"
    "\n"
    "    ld.shared.v4.f32 {%f64, %f65, %f66, %f67}, [%rd20+0];\n"
    "    ld.shared.v4.f32 {%f68, %f69, %f70, %f71}, [%rd20+16];\n"
    "    ld.shared.v4.f32 {%f72, %f73, %f74, %f75}, [%rd20+32];\n"
    "    ld.shared.v4.f32 {%f76, %f77, %f78, %f79}, [%rd20+48];\n"
    "    ld.global.nc.f32 %f80, [%rd22];\n"
    "    ld.global.nc.f32 %f81, [%rd23];\n"
    "    ld.global.nc.f32 %f82, [%rd24];\n"
    "    ld.global.nc.f32 %f83, [%rd25];\n"
    "\n"
    "    fma.rn.f32 %f0, %f64, %f80, %f0;\n"
    "    fma.rn.f32 %f1, %f64, %f81, %f1;\n"
    "    fma.rn.f32 %f2, %f64, %f82, %f2;\n"
    "    fma.rn.f32 %f3, %f64, %f83, %f3;\n"
    "    fma.rn.f32 %f4, %f65, %f80, %f4;\n"
    "    fma.rn.f32 %f5, %f65, %f81, %f5;\n"
    "    fma.rn.f32 %f6, %f65, %f82, %f6;\n"
    "    fma.rn.f32 %f7, %f65, %f83, %f7;\n"
    "    fma.rn.f32 %f8, %f66, %f80, %f8;\n"
    "    fma.rn.f32 %f9, %f66, %f81, %f9;\n"
    "    fma.rn.f32 %f10, %f66, %f82, %f10;\n"
    "    fma.rn.f32 %f11, %f66, %f83, %f11;\n"
    "    fma.rn.f32 %f12, %f67, %f80, %f12;\n"
    "    fma.rn.f32 %f13, %f67, %f81, %f13;\n"
    "    fma.rn.f32 %f14, %f67, %f82, %f14;\n"
    "    fma.rn.f32 %f15, %f67, %f83, %f15;\n"
    "    fma.rn.f32 %f16, %f68, %f80, %f16;\n"
    "    fma.rn.f32 %f17, %f68, %f81, %f17;\n"
    "    fma.rn.f32 %f18, %f68, %f82, %f18;\n"
    "    fma.rn.f32 %f19, %f68, %f83, %f19;\n"
    "    fma.rn.f32 %f20, %f69, %f80, %f20;\n"
    "    fma.rn.f32 %f21, %f69, %f81, %f21;\n"
    "    fma.rn.f32 %f22, %f69, %f82, %f22;\n"
    "    fma.rn.f32 %f23, %f69, %f83, %f23;\n"
    "    fma.rn.f32 %f24, %f70, %f80, %f24;\n"
    "    fma.rn.f32 %f25, %f70, %f81, %f25;\n"
    "    fma.rn.f32 %f26, %f70, %f82, %f26;\n"
    "    fma.rn.f32 %f27, %f70, %f83, %f27;\n"
    "    fma.rn.f32 %f28, %f71, %f80, %f28;\n"
    "    fma.rn.f32 %f29, %f71, %f81, %f29;\n"
    "    fma.rn.f32 %f30, %f71, %f82, %f30;\n"
    "    fma.rn.f32 %f31, %f71, %f83, %f31;\n"
    "    fma.rn.f32 %f32, %f72, %f80, %f32;\n"
    "    fma.rn.f32 %f33, %f72, %f81, %f33;\n"
    "    fma.rn.f32 %f34, %f72, %f82, %f34;\n"
    "    fma.rn.f32 %f35, %f72, %f83, %f35;\n"
    "    fma.rn.f32 %f36, %f73, %f80, %f36;\n"
    "    fma.rn.f32 %f37, %f73, %f81, %f37;\n"
    "    fma.rn.f32 %f38, %f73, %f82, %f38;\n"
    "    fma.rn.f32 %f39, %f73, %f83, %f39;\n"
    "    fma.rn.f32 %f40, %f74, %f80, %f40;\n"
    "    fma.rn.f32 %f41, %f74, %f81, %f41;\n"
    "    fma.rn.f32 %f42, %f74, %f82, %f42;\n"
    "    fma.rn.f32 %f43, %f74, %f83, %f43;\n"
    "    fma.rn.f32 %f44, %f75, %f80, %f44;\n"
    "    fma.rn.f32 %f45, %f75, %f81, %f45;\n"
    "    fma.rn.f32 %f46, %f75, %f82, %f46;\n"
    "    fma.rn.f32 %f47, %f75, %f83, %f47;\n"
    "    fma.rn.f32 %f48, %f76, %f80, %f48;\n"
    "    fma.rn.f32 %f49, %f76, %f81, %f49;\n"
    "    fma.rn.f32 %f50, %f76, %f82, %f50;\n"
    "    fma.rn.f32 %f51, %f76, %f83, %f51;\n"
    "    fma.rn.f32 %f52, %f77, %f80, %f52;\n"
    "    fma.rn.f32 %f53, %f77, %f81, %f53;\n"
    "    fma.rn.f32 %f54, %f77, %f82, %f54;\n"
    "    fma.rn.f32 %f55, %f77, %f83, %f55;\n"
    "    fma.rn.f32 %f56, %f78, %f80, %f56;\n"
    "    fma.rn.f32 %f57, %f78, %f81, %f57;\n"
    "    fma.rn.f32 %f58, %f78, %f82, %f58;\n"
    "    fma.rn.f32 %f59, %f78, %f83, %f59;\n"
    "    fma.rn.f32 %f60, %f79, %f80, %f60;\n"
    "    fma.rn.f32 %f61, %f79, %f81, %f61;\n"
    "    fma.rn.f32 %f62, %f79, %f82, %f62;\n"
    "    fma.rn.f32 %f63, %f79, %f83, %f63;\n"
    "\n"
    "    add.s64 %rd20, %rd20, 64;\n"
    "    add.s64 %rd22, %rd22, 4;\n"
    "    add.s64 %rd23, %rd23, 4;\n"
    "    add.s64 %rd24, %rd24, 4;\n"
    "    add.s64 %rd25, %rd25, 4;\n"
    "    add.u32 %r27, %r27, 1;\n"
    "    bra KWLOOP;\n"
    "\n"
    "KHDONE:\n"
    "    sub.s64 %rd22, %rd22, %rd16;\n"
    "    sub.s64 %rd23, %rd23, %rd16;\n"
    "    sub.s64 %rd24, %rd24, %rd16;\n"
    "    sub.s64 %rd25, %rd25, %rd16;\n"
    "    add.s64 %rd22, %rd22, %rd12;\n"
    "    add.s64 %rd23, %rd23, %rd12;\n"
    "    add.s64 %rd24, %rd24, %rd12;\n"
    "    add.s64 %rd25, %rd25, %rd12;\n"
    "    add.u32 %r26, %r26, 1;\n"
    "    setp.ge.u32 %p2, %r26, %r6;\n"
    "    @%p2 bra ICNEXT;\n"
    "    mov.u32 %r27, 0;\n"
    "    bra KHLOOP;\n"
    "\n"
    "ICNEXT:\n"
    "    sub.s64 %rd22, %rd22, %rd17;\n"
    "    sub.s64 %rd23, %rd23, %rd17;\n"
    "    sub.s64 %rd24, %rd24, %rd17;\n"
    "    sub.s64 %rd25, %rd25, %rd17;\n"
    "    add.s64 %rd22, %rd22, %rd11;\n"
    "    add.s64 %rd23, %rd23, %rd11;\n"
    "    add.s64 %rd24, %rd24, %rd11;\n"
    "    add.s64 %rd25, %rd25, %rd11;\n"
    "    add.s64 %rd8, %rd8, %rd4;         // weight pointer steps one ic\n"
    "    add.u32 %r25, %r25, 1;            // global ic counter\n"
    "    add.u32 %r30, %r30, 1;            // ic inside the group\n"
    "    setp.ge.u32 %p34, %r30, %r13;     // group full?\n"
    "    @%p34 mov.u32 %r30, 0;            // back to the group head\n"
    "    bra ICLOOP;\n"
    "\n"
    "STORE:\n"
    "    // spatial predicates\n"
    "    setp.lt.u32 %p4, %r15, %r9;\n"
    "    add.u32 %r28, %r15, 1;\n"
    "    setp.lt.u32 %p5, %r28, %r9;\n"
    "    setp.lt.u32 %p6, %r14, %r10;\n"
    "    add.u32 %r28, %r14, 16;\n"
    "    setp.lt.u32 %p7, %r28, %r10;\n"
    "    and.pred %p24, %p4, %p6;\n"
    "    and.pred %p25, %p4, %p7;\n"
    "    and.pred %p26, %p5, %p6;\n"
    "    and.pred %p27, %p5, %p7;\n"
    "    // channel predicates: oc_base+o < O\n"
    "    add.u32 %r28, %r16, 0;\n"
    "    setp.lt.u32 %p8, %r28, %r5;\n"
    "    add.u32 %r28, %r16, 1;\n"
    "    setp.lt.u32 %p9, %r28, %r5;\n"
    "    add.u32 %r28, %r16, 2;\n"
    "    setp.lt.u32 %p10, %r28, %r5;\n"
    "    add.u32 %r28, %r16, 3;\n"
    "    setp.lt.u32 %p11, %r28, %r5;\n"
    "    add.u32 %r28, %r16, 4;\n"
    "    setp.lt.u32 %p12, %r28, %r5;\n"
    "    add.u32 %r28, %r16, 5;\n"
    "    setp.lt.u32 %p13, %r28, %r5;\n"
    "    add.u32 %r28, %r16, 6;\n"
    "    setp.lt.u32 %p14, %r28, %r5;\n"
    "    add.u32 %r28, %r16, 7;\n"
    "    setp.lt.u32 %p15, %r28, %r5;\n"
    "    add.u32 %r28, %r16, 8;\n"
    "    setp.lt.u32 %p16, %r28, %r5;\n"
    "    add.u32 %r28, %r16, 9;\n"
    "    setp.lt.u32 %p17, %r28, %r5;\n"
    "    add.u32 %r28, %r16, 10;\n"
    "    setp.lt.u32 %p18, %r28, %r5;\n"
    "    add.u32 %r28, %r16, 11;\n"
    "    setp.lt.u32 %p19, %r28, %r5;\n"
    "    add.u32 %r28, %r16, 12;\n"
    "    setp.lt.u32 %p20, %r28, %r5;\n"
    "    add.u32 %r28, %r16, 13;\n"
    "    setp.lt.u32 %p21, %r28, %r5;\n"
    "    add.u32 %r28, %r16, 14;\n"
    "    setp.lt.u32 %p22, %r28, %r5;\n"
    "    add.u32 %r28, %r16, 15;\n"
    "    setp.lt.u32 %p23, %r28, %r5;\n"
    "\n"
    "    // out base = ((n*O + oc_base)*OH + oh_base)*OW + ow_base\n"
    "    mul.lo.u32 %r22, %r15, %r10;\n"
    "    add.u32 %r22, %r22, %r14;\n"
    "    mul.lo.u32 %r23, %r12, %r5;\n"
    "    add.u32 %r23, %r23, %r16;\n"
    "    mul.lo.u32 %r23, %r23, %r24;\n"
    "    add.u32 %r30, %r22, %r23;\n"
    "    cvt.u64.u32 %rd9, %r30;\n"
    "    shl.b64 %rd9, %rd9, 2;\n"
    "    add.s64 %rd9, %rd9, %rd3;\n"
    "\n"
    "    // oc = 0\n"
    "    and.pred %p28, %p8, %p24;\n"
    "    and.pred %p29, %p8, %p25;\n"
    "    and.pred %p30, %p8, %p26;\n"
    "    and.pred %p31, %p8, %p27;\n"
    "    add.s64 %rd10, %rd9, 64;\n"
    "    add.s64 %rd20, %rd9, %rd18;\n"
    "    add.s64 %rd21, %rd20, 64;\n"
    "    @%p28 st.global.f32 [%rd9], %f0;\n"
    "    @%p29 st.global.f32 [%rd10], %f1;\n"
    "    @%p30 st.global.f32 [%rd20], %f2;\n"
    "    @%p31 st.global.f32 [%rd21], %f3;\n"
    "    add.s64 %rd9, %rd9, %rd19;\n"
    "    // oc = 1\n"
    "    and.pred %p28, %p9, %p24;\n"
    "    and.pred %p29, %p9, %p25;\n"
    "    and.pred %p30, %p9, %p26;\n"
    "    and.pred %p31, %p9, %p27;\n"
    "    add.s64 %rd10, %rd9, 64;\n"
    "    add.s64 %rd20, %rd9, %rd18;\n"
    "    add.s64 %rd21, %rd20, 64;\n"
    "    @%p28 st.global.f32 [%rd9], %f4;\n"
    "    @%p29 st.global.f32 [%rd10], %f5;\n"
    "    @%p30 st.global.f32 [%rd20], %f6;\n"
    "    @%p31 st.global.f32 [%rd21], %f7;\n"
    "    add.s64 %rd9, %rd9, %rd19;\n"
    "    // oc = 2\n"
    "    and.pred %p28, %p10, %p24;\n"
    "    and.pred %p29, %p10, %p25;\n"
    "    and.pred %p30, %p10, %p26;\n"
    "    and.pred %p31, %p10, %p27;\n"
    "    add.s64 %rd10, %rd9, 64;\n"
    "    add.s64 %rd20, %rd9, %rd18;\n"
    "    add.s64 %rd21, %rd20, 64;\n"
    "    @%p28 st.global.f32 [%rd9], %f8;\n"
    "    @%p29 st.global.f32 [%rd10], %f9;\n"
    "    @%p30 st.global.f32 [%rd20], %f10;\n"
    "    @%p31 st.global.f32 [%rd21], %f11;\n"
    "    add.s64 %rd9, %rd9, %rd19;\n"
    "    // oc = 3\n"
    "    and.pred %p28, %p11, %p24;\n"
    "    and.pred %p29, %p11, %p25;\n"
    "    and.pred %p30, %p11, %p26;\n"
    "    and.pred %p31, %p11, %p27;\n"
    "    add.s64 %rd10, %rd9, 64;\n"
    "    add.s64 %rd20, %rd9, %rd18;\n"
    "    add.s64 %rd21, %rd20, 64;\n"
    "    @%p28 st.global.f32 [%rd9], %f12;\n"
    "    @%p29 st.global.f32 [%rd10], %f13;\n"
    "    @%p30 st.global.f32 [%rd20], %f14;\n"
    "    @%p31 st.global.f32 [%rd21], %f15;\n"
    "    add.s64 %rd9, %rd9, %rd19;\n"
    "    // oc = 4\n"
    "    and.pred %p28, %p12, %p24;\n"
    "    and.pred %p29, %p12, %p25;\n"
    "    and.pred %p30, %p12, %p26;\n"
    "    and.pred %p31, %p12, %p27;\n"
    "    add.s64 %rd10, %rd9, 64;\n"
    "    add.s64 %rd20, %rd9, %rd18;\n"
    "    add.s64 %rd21, %rd20, 64;\n"
    "    @%p28 st.global.f32 [%rd9], %f16;\n"
    "    @%p29 st.global.f32 [%rd10], %f17;\n"
    "    @%p30 st.global.f32 [%rd20], %f18;\n"
    "    @%p31 st.global.f32 [%rd21], %f19;\n"
    "    add.s64 %rd9, %rd9, %rd19;\n"
    "    // oc = 5\n"
    "    and.pred %p28, %p13, %p24;\n"
    "    and.pred %p29, %p13, %p25;\n"
    "    and.pred %p30, %p13, %p26;\n"
    "    and.pred %p31, %p13, %p27;\n"
    "    add.s64 %rd10, %rd9, 64;\n"
    "    add.s64 %rd20, %rd9, %rd18;\n"
    "    add.s64 %rd21, %rd20, 64;\n"
    "    @%p28 st.global.f32 [%rd9], %f20;\n"
    "    @%p29 st.global.f32 [%rd10], %f21;\n"
    "    @%p30 st.global.f32 [%rd20], %f22;\n"
    "    @%p31 st.global.f32 [%rd21], %f23;\n"
    "    add.s64 %rd9, %rd9, %rd19;\n"
    "    // oc = 6\n"
    "    and.pred %p28, %p14, %p24;\n"
    "    and.pred %p29, %p14, %p25;\n"
    "    and.pred %p30, %p14, %p26;\n"
    "    and.pred %p31, %p14, %p27;\n"
    "    add.s64 %rd10, %rd9, 64;\n"
    "    add.s64 %rd20, %rd9, %rd18;\n"
    "    add.s64 %rd21, %rd20, 64;\n"
    "    @%p28 st.global.f32 [%rd9], %f24;\n"
    "    @%p29 st.global.f32 [%rd10], %f25;\n"
    "    @%p30 st.global.f32 [%rd20], %f26;\n"
    "    @%p31 st.global.f32 [%rd21], %f27;\n"
    "    add.s64 %rd9, %rd9, %rd19;\n"
    "    // oc = 7\n"
    "    and.pred %p28, %p15, %p24;\n"
    "    and.pred %p29, %p15, %p25;\n"
    "    and.pred %p30, %p15, %p26;\n"
    "    and.pred %p31, %p15, %p27;\n"
    "    add.s64 %rd10, %rd9, 64;\n"
    "    add.s64 %rd20, %rd9, %rd18;\n"
    "    add.s64 %rd21, %rd20, 64;\n"
    "    @%p28 st.global.f32 [%rd9], %f28;\n"
    "    @%p29 st.global.f32 [%rd10], %f29;\n"
    "    @%p30 st.global.f32 [%rd20], %f30;\n"
    "    @%p31 st.global.f32 [%rd21], %f31;\n"
    "    add.s64 %rd9, %rd9, %rd19;\n"
    "    // oc = 8\n"
    "    and.pred %p28, %p16, %p24;\n"
    "    and.pred %p29, %p16, %p25;\n"
    "    and.pred %p30, %p16, %p26;\n"
    "    and.pred %p31, %p16, %p27;\n"
    "    add.s64 %rd10, %rd9, 64;\n"
    "    add.s64 %rd20, %rd9, %rd18;\n"
    "    add.s64 %rd21, %rd20, 64;\n"
    "    @%p28 st.global.f32 [%rd9], %f32;\n"
    "    @%p29 st.global.f32 [%rd10], %f33;\n"
    "    @%p30 st.global.f32 [%rd20], %f34;\n"
    "    @%p31 st.global.f32 [%rd21], %f35;\n"
    "    add.s64 %rd9, %rd9, %rd19;\n"
    "    // oc = 9\n"
    "    and.pred %p28, %p17, %p24;\n"
    "    and.pred %p29, %p17, %p25;\n"
    "    and.pred %p30, %p17, %p26;\n"
    "    and.pred %p31, %p17, %p27;\n"
    "    add.s64 %rd10, %rd9, 64;\n"
    "    add.s64 %rd20, %rd9, %rd18;\n"
    "    add.s64 %rd21, %rd20, 64;\n"
    "    @%p28 st.global.f32 [%rd9], %f36;\n"
    "    @%p29 st.global.f32 [%rd10], %f37;\n"
    "    @%p30 st.global.f32 [%rd20], %f38;\n"
    "    @%p31 st.global.f32 [%rd21], %f39;\n"
    "    add.s64 %rd9, %rd9, %rd19;\n"
    "    // oc = 10\n"
    "    and.pred %p28, %p18, %p24;\n"
    "    and.pred %p29, %p18, %p25;\n"
    "    and.pred %p30, %p18, %p26;\n"
    "    and.pred %p31, %p18, %p27;\n"
    "    add.s64 %rd10, %rd9, 64;\n"
    "    add.s64 %rd20, %rd9, %rd18;\n"
    "    add.s64 %rd21, %rd20, 64;\n"
    "    @%p28 st.global.f32 [%rd9], %f40;\n"
    "    @%p29 st.global.f32 [%rd10], %f41;\n"
    "    @%p30 st.global.f32 [%rd20], %f42;\n"
    "    @%p31 st.global.f32 [%rd21], %f43;\n"
    "    add.s64 %rd9, %rd9, %rd19;\n"
    "    // oc = 11\n"
    "    and.pred %p28, %p19, %p24;\n"
    "    and.pred %p29, %p19, %p25;\n"
    "    and.pred %p30, %p19, %p26;\n"
    "    and.pred %p31, %p19, %p27;\n"
    "    add.s64 %rd10, %rd9, 64;\n"
    "    add.s64 %rd20, %rd9, %rd18;\n"
    "    add.s64 %rd21, %rd20, 64;\n"
    "    @%p28 st.global.f32 [%rd9], %f44;\n"
    "    @%p29 st.global.f32 [%rd10], %f45;\n"
    "    @%p30 st.global.f32 [%rd20], %f46;\n"
    "    @%p31 st.global.f32 [%rd21], %f47;\n"
    "    add.s64 %rd9, %rd9, %rd19;\n"
    "    // oc = 12\n"
    "    and.pred %p28, %p20, %p24;\n"
    "    and.pred %p29, %p20, %p25;\n"
    "    and.pred %p30, %p20, %p26;\n"
    "    and.pred %p31, %p20, %p27;\n"
    "    add.s64 %rd10, %rd9, 64;\n"
    "    add.s64 %rd20, %rd9, %rd18;\n"
    "    add.s64 %rd21, %rd20, 64;\n"
    "    @%p28 st.global.f32 [%rd9], %f48;\n"
    "    @%p29 st.global.f32 [%rd10], %f49;\n"
    "    @%p30 st.global.f32 [%rd20], %f50;\n"
    "    @%p31 st.global.f32 [%rd21], %f51;\n"
    "    add.s64 %rd9, %rd9, %rd19;\n"
    "    // oc = 13\n"
    "    and.pred %p28, %p21, %p24;\n"
    "    and.pred %p29, %p21, %p25;\n"
    "    and.pred %p30, %p21, %p26;\n"
    "    and.pred %p31, %p21, %p27;\n"
    "    add.s64 %rd10, %rd9, 64;\n"
    "    add.s64 %rd20, %rd9, %rd18;\n"
    "    add.s64 %rd21, %rd20, 64;\n"
    "    @%p28 st.global.f32 [%rd9], %f52;\n"
    "    @%p29 st.global.f32 [%rd10], %f53;\n"
    "    @%p30 st.global.f32 [%rd20], %f54;\n"
    "    @%p31 st.global.f32 [%rd21], %f55;\n"
    "    add.s64 %rd9, %rd9, %rd19;\n"
    "    // oc = 14\n"
    "    and.pred %p28, %p22, %p24;\n"
    "    and.pred %p29, %p22, %p25;\n"
    "    and.pred %p30, %p22, %p26;\n"
    "    and.pred %p31, %p22, %p27;\n"
    "    add.s64 %rd10, %rd9, 64;\n"
    "    add.s64 %rd20, %rd9, %rd18;\n"
    "    add.s64 %rd21, %rd20, 64;\n"
    "    @%p28 st.global.f32 [%rd9], %f56;\n"
    "    @%p29 st.global.f32 [%rd10], %f57;\n"
    "    @%p30 st.global.f32 [%rd20], %f58;\n"
    "    @%p31 st.global.f32 [%rd21], %f59;\n"
    "    add.s64 %rd9, %rd9, %rd19;\n"
    "    // oc = 15\n"
    "    and.pred %p28, %p23, %p24;\n"
    "    and.pred %p29, %p23, %p25;\n"
    "    and.pred %p30, %p23, %p26;\n"
    "    and.pred %p31, %p23, %p27;\n"
    "    add.s64 %rd10, %rd9, 64;\n"
    "    add.s64 %rd20, %rd9, %rd18;\n"
    "    add.s64 %rd21, %rd20, 64;\n"
    "    @%p28 st.global.f32 [%rd9], %f60;\n"
    "    @%p29 st.global.f32 [%rd10], %f61;\n"
    "    @%p30 st.global.f32 [%rd20], %f62;\n"
    "    @%p31 st.global.f32 [%rd21], %f63;\n"
    "\n"
    "    ret;\n"
    "}\n"
    "";

static const char *PTX_BODY_POOL =
    ".visible .entry maxpool(\n"
    "    .param .u64 p0,\n"
    "    .param .u64 p1,\n"
    "    .param .u32 p2,\n"
    "    .param .u32 p3,\n"
    "    .param .u32 p4,\n"
    "    .param .u32 p5,\n"
    "    .param .u32 p6,\n"
    "    .param .u32 p7,\n"
    "    .param .f32 p8\n"
    ")\n"
    "{\n"
    "    .reg .pred %p<8>;\n"
    "    .reg .b32  %r<32>;\n"
    "    .reg .b64  %rd<8>;\n"
    "    .reg .f32  %f<10>;\n"
    "    ld.param.u64 %rd1, [p0];\n"
    "    ld.param.u64 %rd2, [p1];\n"
    "    ld.param.u32 %r1, [p2];\n"
    "    ld.param.u32 %r6, [p3];\n"
    "    ld.param.u32 %r7, [p4];\n"
    "    ld.param.u32 %r4, [p5];\n"
    "    ld.param.u32 %r5, [p6];\n"
    "    ld.param.u32 %r8, [p7];\n"
    "    ld.param.f32 %f8, [p8];\n"
    "    mov.u32 %r16, 16;\n"
    "    mov.u32 %r9, %ctaid.x;\n"
    "    mov.u32 %r10, %tid.x;\n"
    "    mul.lo.u32 %r11, %r9, %r16;\n"
    "    add.u32 %r11, %r11, %r10;\n"
    "    mov.u32 %r9, %ctaid.y;\n"
    "    mov.u32 %r10, %tid.y;\n"
    "    mul.lo.u32 %r12, %r9, %r16;\n"
    "    add.u32 %r12, %r12, %r10;\n"
    "    setp.ge.u32 %p1, %r12, %r6;\n"
    "    @%p1 bra DONE;\n"
    "    setp.ge.u32 %p2, %r11, %r7;\n"
    "    @%p2 bra DONE;\n"
    "    mul.lo.u32 %r18, %r12, %r8;\n"
    "    mul.lo.u32 %r19, %r11, %r8;\n"
    "    mul.lo.u32 %r20, %r18, %r1;\n"
    "    add.u32 %r20, %r20, %r19;\n"
    "    cvt.u64.u32 %rd4, %r20;\n"
    "    shl.b64 %rd4, %rd4, 2;\n"
    "    add.s64 %rd4, %rd4, %rd1;\n"
    "    ld.global.f32 %f1, [%rd4];\n"
    "    mov.u32 %r14, 0;\n"
    "ALOOP:\n"
    "    setp.ge.u32 %p3, %r14, %r4;\n"
    "    @%p3 bra ADONE;\n"
    "    mov.u32 %r15, 0;\n"
    "BLOOP:\n"
    "    setp.ge.u32 %p4, %r15, %r5;\n"
    "    @%p4 bra BDONE;\n"
    "    add.u32 %r21, %r18, %r14;\n"
    "    mul.lo.u32 %r21, %r21, %r1;\n"
    "    add.u32 %r21, %r21, %r19;\n"
    "    add.u32 %r21, %r21, %r15;\n"
    "    cvt.u64.u32 %rd5, %r21;\n"
    "    shl.b64 %rd5, %rd5, 2;\n"
    "    add.s64 %rd5, %rd5, %rd1;\n"
    "    ld.global.f32 %f2, [%rd5];\n"
    "    max.f32 %f1, %f1, %f2;\n"
    "    add.u32 %r15, %r15, 1;\n"
    "    bra BLOOP;\n"
    "BDONE:\n"
    "    add.u32 %r14, %r14, 1;\n"
    "    bra ALOOP;\n"
    "ADONE:\n"
    "    mul.lo.u32 %r21, %r12, %r7;\n"
    "    add.u32 %r21, %r21, %r11;\n"
    "    cvt.u64.u32 %rd6, %r21;\n"
    "    shl.b64 %rd6, %rd6, 2;\n"
    "    add.s64 %rd6, %rd6, %rd2;\n"
    "    st.global.f32 [%rd6], %f1;\n"
    "DONE:\n"
    "    ret;\n"
    "}\n"
    "\n"
    ".visible .entry avgpool(\n"
    "    .param .u64 p0,\n"
    "    .param .u64 p1,\n"
    "    .param .u32 p2,\n"
    "    .param .u32 p3,\n"
    "    .param .u32 p4,\n"
    "    .param .u32 p5,\n"
    "    .param .u32 p6,\n"
    "    .param .u32 p7,\n"
    "    .param .f32 p8\n"
    ")\n"
    "{\n"
    "    .reg .pred %p<8>;\n"
    "    .reg .b32  %r<32>;\n"
    "    .reg .b64  %rd<8>;\n"
    "    .reg .f32  %f<10>;\n"
    "    ld.param.u64 %rd1, [p0];\n"
    "    ld.param.u64 %rd2, [p1];\n"
    "    ld.param.u32 %r1, [p2];\n"
    "    ld.param.u32 %r6, [p3];\n"
    "    ld.param.u32 %r7, [p4];\n"
    "    ld.param.u32 %r4, [p5];\n"
    "    ld.param.u32 %r5, [p6];\n"
    "    ld.param.u32 %r8, [p7];\n"
    "    ld.param.f32 %f8, [p8];\n"
    "    mov.u32 %r16, 16;\n"
    "    mov.u32 %r9, %ctaid.x;\n"
    "    mov.u32 %r10, %tid.x;\n"
    "    mul.lo.u32 %r11, %r9, %r16;\n"
    "    add.u32 %r11, %r11, %r10;\n"
    "    mov.u32 %r9, %ctaid.y;\n"
    "    mov.u32 %r10, %tid.y;\n"
    "    mul.lo.u32 %r12, %r9, %r16;\n"
    "    add.u32 %r12, %r12, %r10;\n"
    "    setp.ge.u32 %p1, %r12, %r6;\n"
    "    @%p1 bra DONE;\n"
    "    setp.ge.u32 %p2, %r11, %r7;\n"
    "    @%p2 bra DONE;\n"
    "    mul.lo.u32 %r18, %r12, %r8;\n"
    "    mul.lo.u32 %r19, %r11, %r8;\n"
    "    mul.lo.u32 %r20, %r18, %r1;\n"
    "    add.u32 %r20, %r20, %r19;\n"
    "    cvt.u64.u32 %rd4, %r20;\n"
    "    shl.b64 %rd4, %rd4, 2;\n"
    "    add.s64 %rd4, %rd4, %rd1;\n"
    "    mov.f32 %f1, 0f00000000;\n"
    "    mov.u32 %r14, 0;\n"
    "ALOOP:\n"
    "    setp.ge.u32 %p3, %r14, %r4;\n"
    "    @%p3 bra ADONE;\n"
    "    mov.u32 %r15, 0;\n"
    "BLOOP:\n"
    "    setp.ge.u32 %p4, %r15, %r5;\n"
    "    @%p4 bra BDONE;\n"
    "    add.u32 %r21, %r18, %r14;\n"
    "    mul.lo.u32 %r21, %r21, %r1;\n"
    "    add.u32 %r21, %r21, %r19;\n"
    "    add.u32 %r21, %r21, %r15;\n"
    "    cvt.u64.u32 %rd5, %r21;\n"
    "    shl.b64 %rd5, %rd5, 2;\n"
    "    add.s64 %rd5, %rd5, %rd1;\n"
    "    ld.global.f32 %f2, [%rd5];\n"
    "    add.f32 %f1, %f1, %f2;\n"
    "    add.u32 %r15, %r15, 1;\n"
    "    bra BLOOP;\n"
    "BDONE:\n"
    "    add.u32 %r14, %r14, 1;\n"
    "    bra ALOOP;\n"
    "ADONE:\n"
    "    mul.f32 %f1, %f1, %f8;\n"
    "    mul.lo.u32 %r21, %r12, %r7;\n"
    "    add.u32 %r21, %r21, %r11;\n"
    "    cvt.u64.u32 %rd6, %r21;\n"
    "    shl.b64 %rd6, %rd6, 2;\n"
    "    add.s64 %rd6, %rd6, %rd2;\n"
    "    st.global.f32 [%rd6], %f1;\n"
    "DONE:\n"
    "    ret;\n"
    "}";

static const char *PTX_VERSIONS[] = {
    "8.7", "8.0", "7.8", "7.0", "6.5", "6.0",
};

/* ─────────────── 探测/运行状态 ─────────────── */
static int         g_probed = 0;
static int         g_ready = 0;
static int         g_driver = 0;
static int         g_cc = 0;                    /* major*10+minor */
static int         g_sms = 0;                  /* SM 数（问驱动问的） */
static int         g_max_threads_sm = 0;           /* 每 SM 最大线程数 */
static int         g_calibrated = 0;               /* 1=已在本机标定过时间常数 */
static int         g_sms_route = 0;               /* 路由用的 SM 数（可被环境变量覆盖） */
static CUfunction  g_fn;                        /* sgemm 入口（4x4，小矩阵） */
static CUfunction  g_fn_conv;                   /* conv2d 入口（NULL = 降级 CPU） */
static CUfunction  g_fn_conv_shr;               /* conv2d_shr 入口（权重进共享内存；NULL = 用 g_fn_conv） */
static CUfunction  g_fn_maxpool;                /* maxpool 入口（NULL = 降级 CPU） */
static CUfunction  g_fn_avgpool;                /* avgpool 入口（NULL = 降级 CPU） */
static CUfunction  g_fn_sh;                     /* sgemm_shared 入口（中矩阵，可为 NULL） */
static CUfunction  g_fn_8x8;                    /* sgemm_8x8 入口（大矩阵，可为 NULL） */
static CUcontext   g_ctx;
static CUdeviceptr g_dA, g_dB, g_dC;            /* 显存缓冲（按需扩容复用） */
static size_t      g_cap;                       /* 显存缓冲容量（字节） */
static size_t      g_totalmem;                  /* 显存总量，扩容前先问一句 */
static CUdeviceptr g_hA, g_hB, g_hC;            /* host 暂存区 */
static size_t      g_hcap;                      /* host 暂存区容量（字节） */
static int         g_pinned = 0;                /* 1=页锁定 0=普通堆内存 */
static char        g_name[160];
static char        g_why[256] = "尚未探测";
static char        g_err[256];                  /* 最近一次调用的失败原因 */
static SRWLOCK     g_lock = SRWLOCK_INIT;       /* 显存+暂存区共用，必须串行 */
/* 第四跳的模型段在文件后面，这里先声明（gpu_probe 里要用） */
static void gpu_setup_kernels(void);
static void gpu_calibrate(void);

/* 上一次 conv2d 内核自己跑了多久（毫秒）。只在 PYBOOK_GPU_TRACE=1 时量，
 * 平时是 -1（没量过）。验收台用它把「内核」和「端到端」两个口径分开算。 */
static double g_last_kernel_ms = -1.0;

static const char *cu_err(CUresult r)
{
    const char *s = NULL;
    if (p_cuGetErrorString && p_cuGetErrorString(r, &s) == 0 && s)
        return s;
    return "未知 CUDA 错误";
}

/* 统一记失败原因并返回 0，让所有失败分支都是 return gpu_fail(...) */
static int gpu_fail(const char *fmt, ...)
{
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(g_err, sizeof g_err, fmt, ap);
    va_end(ap);
    return 0;
}

/* ─────────────── 动态加载 ─────────────── */
static int load_syms(void)
{
    void *p;
    g_dll = LoadLibraryA("nvcuda.dll");
    if (!g_dll) {
        snprintf(g_why, sizeof g_why,
                 "找不到 nvcuda.dll（NVIDIA 驱动没装，或装的不是 NVIDIA 卡）");
        return 0;
    }
#define LOAD(n, f)                                                     \
    do {                                                               \
        p = (void *)GetProcAddress(g_dll, n);                          \
        if (!p) {                                                      \
            snprintf(g_why, sizeof g_why,                               \
                     "驱动没导出 %s（CUDA 入口不全，驱动太老）", n);    \
            return 0;                                                  \
        }                                                              \
        memcpy(&(f), &p, sizeof(f));                                   \
    } while (0)
#define LOAD_V2(base, v2, f)                                          \
    do {                                                               \
        p = (void *)GetProcAddress(g_dll, v2);                         \
        if (!p) p = (void *)GetProcAddress(g_dll, base);               \
        if (!p) {                                                      \
            snprintf(g_why, sizeof g_why, "驱动没导出 %s", v2);        \
            return 0;                                                  \
        }                                                              \
        memcpy(&(f), &p, sizeof(f));                                   \
    } while (0)
/* 可选入口：缺了就置 NULL，不报错（LOAD 缺符号会直接失败） */
#define LOAD_OPT(n, f)                                                   \
    do {                                                                 \
        p = (void *)GetProcAddress(g_dll, n);                            \
        memcpy(&(f), &p, sizeof(f));                                     \
    } while (0)

    LOAD("cuInit", p_cuInit);
    LOAD("cuDriverGetVersion", p_cuDriverGetVersion);
    LOAD("cuDeviceGetCount", p_cuDeviceGetCount);
    LOAD("cuDeviceGet", p_cuDeviceGet);
    LOAD("cuDeviceGetName", p_cuDeviceGetName);
    LOAD("cuDeviceTotalMem", p_cuDeviceTotalMem);
    LOAD("cuDeviceGetAttribute", p_cuDeviceGetAttribute);
    LOAD("cuDevicePrimaryCtxRetain", p_cuDevicePrimaryCtxRetain);
    LOAD("cuCtxSetCurrent", p_cuCtxSetCurrent);
    LOAD("cuCtxSynchronize", p_cuCtxSynchronize);
    LOAD("cuModuleLoadData", p_cuModuleLoadData);
    LOAD("cuModuleGetFunction", p_cuModuleGetFunction);
    LOAD_V2("cuMemAlloc", "cuMemAlloc_v2", p_cuMemAlloc_v2);
    LOAD_V2("cuMemFree", "cuMemFree_v2", p_cuMemFree_v2);
    LOAD_V2("cuMemcpyHtoD", "cuMemcpyHtoD_v2", p_cuMemcpyHtoD_v2);
    LOAD_V2("cuMemcpyDtoH", "cuMemcpyDtoH_v2", p_cuMemcpyDtoH_v2);
    LOAD_OPT("cuMemcpyHtoDAsync_v2", p_cuMemcpyHtoDAsync_v2);
    LOAD_OPT("cuMemcpyDtoHAsync_v2", p_cuMemcpyDtoHAsync_v2);
    LOAD_V2("cuMemcpyDtoH", "cuMemcpyDtoH_v2", p_cuMemcpyDtoH_v2);
    LOAD("cuLaunchKernel", p_cuLaunchKernel);
    LOAD("cuGetErrorString", p_cuGetErrorString);
    LOAD_OPT("cuFuncGetAttribute", p_cuFuncGetAttribute);
    LOAD_OPT("cuOccupancyMaxActiveBlocksPerMultiprocessor", p_cuOccupancyMaxActiveBlocks);
    LOAD_OPT("cuEventCreate", p_cuEventCreate);
    LOAD_OPT("cuEventRecord", p_cuEventRecord);
    LOAD_OPT("cuEventSynchronize", p_cuEventSynchronize);
    LOAD_OPT("cuEventElapsedTime", p_cuEventElapsedTime);
    LOAD_OPT("cuEventDestroy", p_cuEventDestroy);
#undef LOAD_OPT
    /* 页锁定 host 内存：拿不到不算致命，退回普通堆内存（慢一截但能跑） */
    LOAD_V2("cuMemAllocHost", "cuMemAllocHost_v2", p_cuMemAllocHost_v2);
    LOAD("cuMemFreeHost", p_cuMemFreeHost);
#undef LOAD
#undef LOAD_V2
    return 1;
}

/* 用当前卡的真实 CC 当 target —— 不写死 sm_61（那只是这台机器的卡）。
 * 产出的 PTX 由驱动 JIT 到实际架构，换卡不用重编 PYbook。 */
static const char *PTX_BODY_8X8 =
    ".visible .entry sgemm_8x8(\n"
    "    .param .u64 p0,\n"
    "    .param .u64 p1,\n"
    "    .param .u64 p2,\n"
    "    .param .u32 p3,\n"
    "    .param .u32 p4,\n"
    "    .param .u32 p5\n"
    ")\n"
    "{\n"
    "    .reg .pred %p<128>;\n"
    "    .reg .b32  %r<28>;\n"
    "    .reg .b64  %rd<24>;\n"
    "    .reg .f32  %f<88>;\n"
    "    .shared .align 16 .f32 sA[1024];\n"
    "    .shared .align 16 .f32 sB[1024];\n"
    "\n"
    "    ld.param.u64 %rd1, [p0];\n"
    "    ld.param.u64 %rd2, [p1];\n"
    "    ld.param.u64 %rd3, [p2];\n"
    "    ld.param.u32  %r1, [p3];\n"
    "    ld.param.u32  %r2, [p4];\n"
    "    ld.param.u32  %r3, [p5];\n"
    "\n"
    "    mov.u32 %r4, %tid.x;\n"
    "    mov.u32 %r5, %tid.y;\n"
    "    mov.u32 %r6, %ctaid.x;\n"
    "    mov.u32 %r7, %ctaid.y;\n"
    "\n"
    "    shl.b32 %r8,  %r7, 7;\n"
    "    shl.b32 %r9,  %r5, 3;\n"
    "    add.s32 %r8,  %r8, %r9;\n"
    "    shl.b32 %r12, %r6, 7;\n"
    "    shl.b32 %r11, %r4, 3;\n"
    "    add.s32 %r12, %r12, %r11;\n"
    "    shl.b32 %r9,  %r7, 7;\n"
    "    shl.b32 %r11, %r6, 7;\n"
    "\n"
    "    mul.lo.u32 %r10, %r5, 16;\n"
    "    add.u32 %r10, %r10, %r4;\n"
    "\n"
    "    shl.b32 %r24, %r5, 3;\n"
    "    add.s32 %r14, %r8, 4;\n"
    "    add.s32 %r15, %r8, 5;\n"
    "    add.s32 %r16, %r8, 6;\n"
    "    add.s32 %r17, %r8, 7;\n"
    "\n"
    "    cvt.u64.u32 %rd15, %r2;\n"
    "    shl.b64 %rd15, %rd15, 2;\n"
    "    mov.u64 %rd13, sA;\n"
    "    mov.u64 %rd14, sB;\n"
    "    cvt.u64.u32 %rd16, %r24;\n"
    "    shl.b64 %rd16, %rd16, 5;\n"
    "    add.u64 %rd16, %rd16, %rd13;\n"
    "    cvt.u64.u32 %rd17, %r4;\n"
    "    shl.b64 %rd17, %rd17, 5;\n"
    "    add.u64 %rd17, %rd17, %rd14;\n"
    "\n"
    "    mov.f32 %f0, 0f00000000;\n"
    "    mov.f32 %f1, 0f00000000;\n"
    "    mov.f32 %f2, 0f00000000;\n"
    "    mov.f32 %f3, 0f00000000;\n"
    "    mov.f32 %f4, 0f00000000;\n"
    "    mov.f32 %f5, 0f00000000;\n"
    "    mov.f32 %f6, 0f00000000;\n"
    "    mov.f32 %f7, 0f00000000;\n"
    "    mov.f32 %f8, 0f00000000;\n"
    "    mov.f32 %f9, 0f00000000;\n"
    "    mov.f32 %f10, 0f00000000;\n"
    "    mov.f32 %f11, 0f00000000;\n"
    "    mov.f32 %f12, 0f00000000;\n"
    "    mov.f32 %f13, 0f00000000;\n"
    "    mov.f32 %f14, 0f00000000;\n"
    "    mov.f32 %f15, 0f00000000;\n"
    "    mov.f32 %f16, 0f00000000;\n"
    "    mov.f32 %f17, 0f00000000;\n"
    "    mov.f32 %f18, 0f00000000;\n"
    "    mov.f32 %f19, 0f00000000;\n"
    "    mov.f32 %f20, 0f00000000;\n"
    "    mov.f32 %f21, 0f00000000;\n"
    "    mov.f32 %f22, 0f00000000;\n"
    "    mov.f32 %f23, 0f00000000;\n"
    "    mov.f32 %f24, 0f00000000;\n"
    "    mov.f32 %f25, 0f00000000;\n"
    "    mov.f32 %f26, 0f00000000;\n"
    "    mov.f32 %f27, 0f00000000;\n"
    "    mov.f32 %f28, 0f00000000;\n"
    "    mov.f32 %f29, 0f00000000;\n"
    "    mov.f32 %f30, 0f00000000;\n"
    "    mov.f32 %f31, 0f00000000;\n"
    "    mov.f32 %f32, 0f00000000;\n"
    "    mov.f32 %f33, 0f00000000;\n"
    "    mov.f32 %f34, 0f00000000;\n"
    "    mov.f32 %f35, 0f00000000;\n"
    "    mov.f32 %f36, 0f00000000;\n"
    "    mov.f32 %f37, 0f00000000;\n"
    "    mov.f32 %f38, 0f00000000;\n"
    "    mov.f32 %f39, 0f00000000;\n"
    "    mov.f32 %f40, 0f00000000;\n"
    "    mov.f32 %f41, 0f00000000;\n"
    "    mov.f32 %f42, 0f00000000;\n"
    "    mov.f32 %f43, 0f00000000;\n"
    "    mov.f32 %f44, 0f00000000;\n"
    "    mov.f32 %f45, 0f00000000;\n"
    "    mov.f32 %f46, 0f00000000;\n"
    "    mov.f32 %f47, 0f00000000;\n"
    "    mov.f32 %f48, 0f00000000;\n"
    "    mov.f32 %f49, 0f00000000;\n"
    "    mov.f32 %f50, 0f00000000;\n"
    "    mov.f32 %f51, 0f00000000;\n"
    "    mov.f32 %f52, 0f00000000;\n"
    "    mov.f32 %f53, 0f00000000;\n"
    "    mov.f32 %f54, 0f00000000;\n"
    "    mov.f32 %f55, 0f00000000;\n"
    "    mov.f32 %f56, 0f00000000;\n"
    "    mov.f32 %f57, 0f00000000;\n"
    "    mov.f32 %f58, 0f00000000;\n"
    "    mov.f32 %f59, 0f00000000;\n"
    "    mov.f32 %f60, 0f00000000;\n"
    "    mov.f32 %f61, 0f00000000;\n"
    "    mov.f32 %f62, 0f00000000;\n"
    "    mov.f32 %f63, 0f00000000;\n"
    "    mov.u32 %r13, 0;\n"
    "\n"
    "\n"
    "PROLOGUE:\n"
    "\n"
    "    shl.b32 %r19, %r10, 2;\n"
    "    shr.u32 %r20, %r19, 3;\n"
    "    and.b32 %r21, %r19, 7;\n"
    "    add.s32 %r22, %r9, %r20;\n"
    "    add.s32 %r23, %r13, %r21;\n"
    "    setp.lt.u32 %p10, %r22, %r1;\n"
    "    mul.wide.u32 %rd4, %r22, %r3;\n"
    "    cvt.u64.u32   %rd18, %r23;\n"
    "    add.s64 %rd4, %rd4, %rd18;\n"
    "    shl.b64 %rd4, %rd4, 2;\n"
    "    add.s64 %rd4, %rd4, %rd1;\n"
    "    cvt.u64.u32 %rd6, %r19;\n"
    "    shl.b64 %rd6, %rd6, 2;\n"
    "    add.u64 %rd6, %rd6, %rd13;\n"
    "    setp.lt.u32 %p11, %r23, %r3;\n"
    "    and.pred %p12, %p10, %p11;\n"
    "    @%p12 ld.global.nc.f32 %f80, [%rd4+0];\n"
    "    @!%p12 mov.f32 %f80, 0f00000000;\n"
    "    st.shared.f32 [%rd6+0], %f80;\n"
    "    add.s32 %r23, %r23, 1;\n"
    "    setp.lt.u32 %p11, %r23, %r3;\n"
    "    and.pred %p12, %p10, %p11;\n"
    "    @%p12 ld.global.nc.f32 %f81, [%rd4+4];\n"
    "    @!%p12 mov.f32 %f81, 0f00000000;\n"
    "    st.shared.f32 [%rd6+4], %f81;\n"
    "    add.s32 %r23, %r23, 1;\n"
    "    setp.lt.u32 %p11, %r23, %r3;\n"
    "    and.pred %p12, %p10, %p11;\n"
    "    @%p12 ld.global.nc.f32 %f82, [%rd4+8];\n"
    "    @!%p12 mov.f32 %f82, 0f00000000;\n"
    "    st.shared.f32 [%rd6+8], %f82;\n"
    "    add.s32 %r23, %r23, 1;\n"
    "    setp.lt.u32 %p11, %r23, %r3;\n"
    "    and.pred %p12, %p10, %p11;\n"
    "    @%p12 ld.global.nc.f32 %f83, [%rd4+12];\n"
    "    @!%p12 mov.f32 %f83, 0f00000000;\n"
    "    st.shared.f32 [%rd6+12], %f83;\n"
    "\n"
    "    shr.u32 %r20, %r19, 7;\n"
    "    and.b32 %r21, %r19, 127;\n"
    "    add.s32 %r22, %r13, %r20;\n"
    "    add.s32 %r23, %r11, %r21;\n"
    "    setp.lt.u32 %p10, %r22, %r3;\n"
    "    mul.wide.u32 %rd5, %r22, %r2;\n"
    "    cvt.u64.u32   %rd18, %r23;\n"
    "    add.s64 %rd5, %rd5, %rd18;\n"
    "    shl.b64 %rd5, %rd5, 2;\n"
    "    add.s64 %rd5, %rd5, %rd2;\n"
    "    cvt.u64.u32 %rd7, %r19;\n"
    "    shl.b64 %rd7, %rd7, 2;\n"
    "    add.u64 %rd7, %rd7, %rd14;\n"
    "    setp.lt.u32 %p11, %r23, %r2;\n"
    "    and.pred %p12, %p10, %p11;\n"
    "    @%p12 ld.global.nc.f32 %f84, [%rd5+0];\n"
    "    @!%p12 mov.f32 %f84, 0f00000000;\n"
    "    st.shared.f32 [%rd7+0], %f84;\n"
    "    add.s32 %r23, %r23, 1;\n"
    "    setp.lt.u32 %p11, %r23, %r2;\n"
    "    and.pred %p12, %p10, %p11;\n"
    "    @%p12 ld.global.nc.f32 %f85, [%rd5+4];\n"
    "    @!%p12 mov.f32 %f85, 0f00000000;\n"
    "    st.shared.f32 [%rd7+4], %f85;\n"
    "    add.s32 %r23, %r23, 1;\n"
    "    setp.lt.u32 %p11, %r23, %r2;\n"
    "    and.pred %p12, %p10, %p11;\n"
    "    @%p12 ld.global.nc.f32 %f86, [%rd5+8];\n"
    "    @!%p12 mov.f32 %f86, 0f00000000;\n"
    "    st.shared.f32 [%rd7+8], %f86;\n"
    "    add.s32 %r23, %r23, 1;\n"
    "    setp.lt.u32 %p11, %r23, %r2;\n"
    "    and.pred %p12, %p10, %p11;\n"
    "    @%p12 ld.global.nc.f32 %f87, [%rd5+12];\n"
    "    @!%p12 mov.f32 %f87, 0f00000000;\n"
    "    st.shared.f32 [%rd7+12], %f87;\n"
    "\n"
    "    bar.sync 0;\n"
    "\n"
    "KLOOP:\n"
    "    setp.ge.u32 %p9, %r13, %r3;\n"
    "    @%p9 bra STORE;\n"
    "    add.u32 %r13, %r13, 8;   // moved here so the loads below target k+8\n"
    "\n"
    "    shl.b32 %r19, %r10, 2;\n"
    "    shr.u32 %r20, %r19, 3;\n"
    "    and.b32 %r21, %r19, 7;\n"
    "    add.s32 %r22, %r9, %r20;\n"
    "    add.s32 %r23, %r13, %r21;\n"
    "    setp.lt.u32 %p10, %r22, %r1;\n"
    "    mul.wide.u32 %rd4, %r22, %r3;\n"
    "    cvt.u64.u32   %rd18, %r23;\n"
    "    add.s64 %rd4, %rd4, %rd18;\n"
    "    shl.b64 %rd4, %rd4, 2;\n"
    "    add.s64 %rd4, %rd4, %rd1;\n"
    "    cvt.u64.u32 %rd6, %r19;\n"
    "    shl.b64 %rd6, %rd6, 2;\n"
    "    add.u64 %rd6, %rd6, %rd13;\n"
    "    setp.lt.u32 %p11, %r23, %r3;\n"
    "    and.pred %p12, %p10, %p11;\n"
    "    @%p12 ld.global.nc.f32 %f80, [%rd4+0];\n"
    "    @!%p12 mov.f32 %f80, 0f00000000;\n"
    "    add.s32 %r23, %r23, 1;\n"
    "    setp.lt.u32 %p11, %r23, %r3;\n"
    "    and.pred %p12, %p10, %p11;\n"
    "    @%p12 ld.global.nc.f32 %f81, [%rd4+4];\n"
    "    @!%p12 mov.f32 %f81, 0f00000000;\n"
    "    add.s32 %r23, %r23, 1;\n"
    "    setp.lt.u32 %p11, %r23, %r3;\n"
    "    and.pred %p12, %p10, %p11;\n"
    "    @%p12 ld.global.nc.f32 %f82, [%rd4+8];\n"
    "    @!%p12 mov.f32 %f82, 0f00000000;\n"
    "    add.s32 %r23, %r23, 1;\n"
    "    setp.lt.u32 %p11, %r23, %r3;\n"
    "    and.pred %p12, %p10, %p11;\n"
    "    @%p12 ld.global.nc.f32 %f83, [%rd4+12];\n"
    "    @!%p12 mov.f32 %f83, 0f00000000;\n"
    "\n"
    "    shr.u32 %r20, %r19, 7;\n"
    "    and.b32 %r21, %r19, 127;\n"
    "    add.s32 %r22, %r13, %r20;\n"
    "    add.s32 %r23, %r11, %r21;\n"
    "    setp.lt.u32 %p10, %r22, %r3;\n"
    "    mul.wide.u32 %rd5, %r22, %r2;\n"
    "    cvt.u64.u32   %rd18, %r23;\n"
    "    add.s64 %rd5, %rd5, %rd18;\n"
    "    shl.b64 %rd5, %rd5, 2;\n"
    "    add.s64 %rd5, %rd5, %rd2;\n"
    "    cvt.u64.u32 %rd7, %r19;\n"
    "    shl.b64 %rd7, %rd7, 2;\n"
    "    add.u64 %rd7, %rd7, %rd14;\n"
    "    setp.lt.u32 %p11, %r23, %r2;\n"
    "    and.pred %p12, %p10, %p11;\n"
    "    @%p12 ld.global.nc.f32 %f84, [%rd5+0];\n"
    "    @!%p12 mov.f32 %f84, 0f00000000;\n"
    "    add.s32 %r23, %r23, 1;\n"
    "    setp.lt.u32 %p11, %r23, %r2;\n"
    "    and.pred %p12, %p10, %p11;\n"
    "    @%p12 ld.global.nc.f32 %f85, [%rd5+4];\n"
    "    @!%p12 mov.f32 %f85, 0f00000000;\n"
    "    add.s32 %r23, %r23, 1;\n"
    "    setp.lt.u32 %p11, %r23, %r2;\n"
    "    and.pred %p12, %p10, %p11;\n"
    "    @%p12 ld.global.nc.f32 %f86, [%rd5+8];\n"
    "    @!%p12 mov.f32 %f86, 0f00000000;\n"
    "    add.s32 %r23, %r23, 1;\n"
    "    setp.lt.u32 %p11, %r23, %r2;\n"
    "    and.pred %p12, %p10, %p11;\n"
    "    @%p12 ld.global.nc.f32 %f87, [%rd5+12];\n"
    "    @!%p12 mov.f32 %f87, 0f00000000;\n"
    "\n"
    "\n"
    "    ld.shared.f32 %f64, [%rd16+0];\n"
    "    ld.shared.f32 %f65, [%rd16+32];\n"
    "    ld.shared.f32 %f66, [%rd16+64];\n"
    "    ld.shared.f32 %f67, [%rd16+96];\n"
    "    ld.shared.f32 %f68, [%rd16+128];\n"
    "    ld.shared.f32 %f69, [%rd16+160];\n"
    "    ld.shared.f32 %f70, [%rd16+192];\n"
    "    ld.shared.f32 %f71, [%rd16+224];\n"
    "    ld.shared.v4.f32 {%f72, %f73, %f74, %f75}, [%rd17+0];\n"
    "    ld.shared.v4.f32 {%f76, %f77, %f78, %f79}, [%rd17+16];\n"
    "    fma.rn.f32 %f0, %f64, %f72, %f0;\n"
    "    fma.rn.f32 %f1, %f64, %f73, %f1;\n"
    "    fma.rn.f32 %f2, %f64, %f74, %f2;\n"
    "    fma.rn.f32 %f3, %f64, %f75, %f3;\n"
    "    fma.rn.f32 %f4, %f64, %f76, %f4;\n"
    "    fma.rn.f32 %f5, %f64, %f77, %f5;\n"
    "    fma.rn.f32 %f6, %f64, %f78, %f6;\n"
    "    fma.rn.f32 %f7, %f64, %f79, %f7;\n"
    "    fma.rn.f32 %f8, %f65, %f72, %f8;\n"
    "    fma.rn.f32 %f9, %f65, %f73, %f9;\n"
    "    fma.rn.f32 %f10, %f65, %f74, %f10;\n"
    "    fma.rn.f32 %f11, %f65, %f75, %f11;\n"
    "    fma.rn.f32 %f12, %f65, %f76, %f12;\n"
    "    fma.rn.f32 %f13, %f65, %f77, %f13;\n"
    "    fma.rn.f32 %f14, %f65, %f78, %f14;\n"
    "    fma.rn.f32 %f15, %f65, %f79, %f15;\n"
    "    fma.rn.f32 %f16, %f66, %f72, %f16;\n"
    "    fma.rn.f32 %f17, %f66, %f73, %f17;\n"
    "    fma.rn.f32 %f18, %f66, %f74, %f18;\n"
    "    fma.rn.f32 %f19, %f66, %f75, %f19;\n"
    "    fma.rn.f32 %f20, %f66, %f76, %f20;\n"
    "    fma.rn.f32 %f21, %f66, %f77, %f21;\n"
    "    fma.rn.f32 %f22, %f66, %f78, %f22;\n"
    "    fma.rn.f32 %f23, %f66, %f79, %f23;\n"
    "    fma.rn.f32 %f24, %f67, %f72, %f24;\n"
    "    fma.rn.f32 %f25, %f67, %f73, %f25;\n"
    "    fma.rn.f32 %f26, %f67, %f74, %f26;\n"
    "    fma.rn.f32 %f27, %f67, %f75, %f27;\n"
    "    fma.rn.f32 %f28, %f67, %f76, %f28;\n"
    "    fma.rn.f32 %f29, %f67, %f77, %f29;\n"
    "    fma.rn.f32 %f30, %f67, %f78, %f30;\n"
    "    fma.rn.f32 %f31, %f67, %f79, %f31;\n"
    "    fma.rn.f32 %f32, %f68, %f72, %f32;\n"
    "    fma.rn.f32 %f33, %f68, %f73, %f33;\n"
    "    fma.rn.f32 %f34, %f68, %f74, %f34;\n"
    "    fma.rn.f32 %f35, %f68, %f75, %f35;\n"
    "    fma.rn.f32 %f36, %f68, %f76, %f36;\n"
    "    fma.rn.f32 %f37, %f68, %f77, %f37;\n"
    "    fma.rn.f32 %f38, %f68, %f78, %f38;\n"
    "    fma.rn.f32 %f39, %f68, %f79, %f39;\n"
    "    fma.rn.f32 %f40, %f69, %f72, %f40;\n"
    "    fma.rn.f32 %f41, %f69, %f73, %f41;\n"
    "    fma.rn.f32 %f42, %f69, %f74, %f42;\n"
    "    fma.rn.f32 %f43, %f69, %f75, %f43;\n"
    "    fma.rn.f32 %f44, %f69, %f76, %f44;\n"
    "    fma.rn.f32 %f45, %f69, %f77, %f45;\n"
    "    fma.rn.f32 %f46, %f69, %f78, %f46;\n"
    "    fma.rn.f32 %f47, %f69, %f79, %f47;\n"
    "    fma.rn.f32 %f48, %f70, %f72, %f48;\n"
    "    fma.rn.f32 %f49, %f70, %f73, %f49;\n"
    "    fma.rn.f32 %f50, %f70, %f74, %f50;\n"
    "    fma.rn.f32 %f51, %f70, %f75, %f51;\n"
    "    fma.rn.f32 %f52, %f70, %f76, %f52;\n"
    "    fma.rn.f32 %f53, %f70, %f77, %f53;\n"
    "    fma.rn.f32 %f54, %f70, %f78, %f54;\n"
    "    fma.rn.f32 %f55, %f70, %f79, %f55;\n"
    "    fma.rn.f32 %f56, %f71, %f72, %f56;\n"
    "    fma.rn.f32 %f57, %f71, %f73, %f57;\n"
    "    fma.rn.f32 %f58, %f71, %f74, %f58;\n"
    "    fma.rn.f32 %f59, %f71, %f75, %f59;\n"
    "    fma.rn.f32 %f60, %f71, %f76, %f60;\n"
    "    fma.rn.f32 %f61, %f71, %f77, %f61;\n"
    "    fma.rn.f32 %f62, %f71, %f78, %f62;\n"
    "    fma.rn.f32 %f63, %f71, %f79, %f63;\n"
    "    ld.shared.f32 %f64, [%rd16+4];\n"
    "    ld.shared.f32 %f65, [%rd16+36];\n"
    "    ld.shared.f32 %f66, [%rd16+68];\n"
    "    ld.shared.f32 %f67, [%rd16+100];\n"
    "    ld.shared.f32 %f68, [%rd16+132];\n"
    "    ld.shared.f32 %f69, [%rd16+164];\n"
    "    ld.shared.f32 %f70, [%rd16+196];\n"
    "    ld.shared.f32 %f71, [%rd16+228];\n"
    "    ld.shared.v4.f32 {%f72, %f73, %f74, %f75}, [%rd17+512];\n"
    "    ld.shared.v4.f32 {%f76, %f77, %f78, %f79}, [%rd17+528];\n"
    "    fma.rn.f32 %f0, %f64, %f72, %f0;\n"
    "    fma.rn.f32 %f1, %f64, %f73, %f1;\n"
    "    fma.rn.f32 %f2, %f64, %f74, %f2;\n"
    "    fma.rn.f32 %f3, %f64, %f75, %f3;\n"
    "    fma.rn.f32 %f4, %f64, %f76, %f4;\n"
    "    fma.rn.f32 %f5, %f64, %f77, %f5;\n"
    "    fma.rn.f32 %f6, %f64, %f78, %f6;\n"
    "    fma.rn.f32 %f7, %f64, %f79, %f7;\n"
    "    fma.rn.f32 %f8, %f65, %f72, %f8;\n"
    "    fma.rn.f32 %f9, %f65, %f73, %f9;\n"
    "    fma.rn.f32 %f10, %f65, %f74, %f10;\n"
    "    fma.rn.f32 %f11, %f65, %f75, %f11;\n"
    "    fma.rn.f32 %f12, %f65, %f76, %f12;\n"
    "    fma.rn.f32 %f13, %f65, %f77, %f13;\n"
    "    fma.rn.f32 %f14, %f65, %f78, %f14;\n"
    "    fma.rn.f32 %f15, %f65, %f79, %f15;\n"
    "    fma.rn.f32 %f16, %f66, %f72, %f16;\n"
    "    fma.rn.f32 %f17, %f66, %f73, %f17;\n"
    "    fma.rn.f32 %f18, %f66, %f74, %f18;\n"
    "    fma.rn.f32 %f19, %f66, %f75, %f19;\n"
    "    fma.rn.f32 %f20, %f66, %f76, %f20;\n"
    "    fma.rn.f32 %f21, %f66, %f77, %f21;\n"
    "    fma.rn.f32 %f22, %f66, %f78, %f22;\n"
    "    fma.rn.f32 %f23, %f66, %f79, %f23;\n"
    "    fma.rn.f32 %f24, %f67, %f72, %f24;\n"
    "    fma.rn.f32 %f25, %f67, %f73, %f25;\n"
    "    fma.rn.f32 %f26, %f67, %f74, %f26;\n"
    "    fma.rn.f32 %f27, %f67, %f75, %f27;\n"
    "    fma.rn.f32 %f28, %f67, %f76, %f28;\n"
    "    fma.rn.f32 %f29, %f67, %f77, %f29;\n"
    "    fma.rn.f32 %f30, %f67, %f78, %f30;\n"
    "    fma.rn.f32 %f31, %f67, %f79, %f31;\n"
    "    fma.rn.f32 %f32, %f68, %f72, %f32;\n"
    "    fma.rn.f32 %f33, %f68, %f73, %f33;\n"
    "    fma.rn.f32 %f34, %f68, %f74, %f34;\n"
    "    fma.rn.f32 %f35, %f68, %f75, %f35;\n"
    "    fma.rn.f32 %f36, %f68, %f76, %f36;\n"
    "    fma.rn.f32 %f37, %f68, %f77, %f37;\n"
    "    fma.rn.f32 %f38, %f68, %f78, %f38;\n"
    "    fma.rn.f32 %f39, %f68, %f79, %f39;\n"
    "    fma.rn.f32 %f40, %f69, %f72, %f40;\n"
    "    fma.rn.f32 %f41, %f69, %f73, %f41;\n"
    "    fma.rn.f32 %f42, %f69, %f74, %f42;\n"
    "    fma.rn.f32 %f43, %f69, %f75, %f43;\n"
    "    fma.rn.f32 %f44, %f69, %f76, %f44;\n"
    "    fma.rn.f32 %f45, %f69, %f77, %f45;\n"
    "    fma.rn.f32 %f46, %f69, %f78, %f46;\n"
    "    fma.rn.f32 %f47, %f69, %f79, %f47;\n"
    "    fma.rn.f32 %f48, %f70, %f72, %f48;\n"
    "    fma.rn.f32 %f49, %f70, %f73, %f49;\n"
    "    fma.rn.f32 %f50, %f70, %f74, %f50;\n"
    "    fma.rn.f32 %f51, %f70, %f75, %f51;\n"
    "    fma.rn.f32 %f52, %f70, %f76, %f52;\n"
    "    fma.rn.f32 %f53, %f70, %f77, %f53;\n"
    "    fma.rn.f32 %f54, %f70, %f78, %f54;\n"
    "    fma.rn.f32 %f55, %f70, %f79, %f55;\n"
    "    fma.rn.f32 %f56, %f71, %f72, %f56;\n"
    "    fma.rn.f32 %f57, %f71, %f73, %f57;\n"
    "    fma.rn.f32 %f58, %f71, %f74, %f58;\n"
    "    fma.rn.f32 %f59, %f71, %f75, %f59;\n"
    "    fma.rn.f32 %f60, %f71, %f76, %f60;\n"
    "    fma.rn.f32 %f61, %f71, %f77, %f61;\n"
    "    fma.rn.f32 %f62, %f71, %f78, %f62;\n"
    "    fma.rn.f32 %f63, %f71, %f79, %f63;\n"
    "    ld.shared.f32 %f64, [%rd16+8];\n"
    "    ld.shared.f32 %f65, [%rd16+40];\n"
    "    ld.shared.f32 %f66, [%rd16+72];\n"
    "    ld.shared.f32 %f67, [%rd16+104];\n"
    "    ld.shared.f32 %f68, [%rd16+136];\n"
    "    ld.shared.f32 %f69, [%rd16+168];\n"
    "    ld.shared.f32 %f70, [%rd16+200];\n"
    "    ld.shared.f32 %f71, [%rd16+232];\n"
    "    ld.shared.v4.f32 {%f72, %f73, %f74, %f75}, [%rd17+1024];\n"
    "    ld.shared.v4.f32 {%f76, %f77, %f78, %f79}, [%rd17+1040];\n"
    "    fma.rn.f32 %f0, %f64, %f72, %f0;\n"
    "    fma.rn.f32 %f1, %f64, %f73, %f1;\n"
    "    fma.rn.f32 %f2, %f64, %f74, %f2;\n"
    "    fma.rn.f32 %f3, %f64, %f75, %f3;\n"
    "    fma.rn.f32 %f4, %f64, %f76, %f4;\n"
    "    fma.rn.f32 %f5, %f64, %f77, %f5;\n"
    "    fma.rn.f32 %f6, %f64, %f78, %f6;\n"
    "    fma.rn.f32 %f7, %f64, %f79, %f7;\n"
    "    fma.rn.f32 %f8, %f65, %f72, %f8;\n"
    "    fma.rn.f32 %f9, %f65, %f73, %f9;\n"
    "    fma.rn.f32 %f10, %f65, %f74, %f10;\n"
    "    fma.rn.f32 %f11, %f65, %f75, %f11;\n"
    "    fma.rn.f32 %f12, %f65, %f76, %f12;\n"
    "    fma.rn.f32 %f13, %f65, %f77, %f13;\n"
    "    fma.rn.f32 %f14, %f65, %f78, %f14;\n"
    "    fma.rn.f32 %f15, %f65, %f79, %f15;\n"
    "    fma.rn.f32 %f16, %f66, %f72, %f16;\n"
    "    fma.rn.f32 %f17, %f66, %f73, %f17;\n"
    "    fma.rn.f32 %f18, %f66, %f74, %f18;\n"
    "    fma.rn.f32 %f19, %f66, %f75, %f19;\n"
    "    fma.rn.f32 %f20, %f66, %f76, %f20;\n"
    "    fma.rn.f32 %f21, %f66, %f77, %f21;\n"
    "    fma.rn.f32 %f22, %f66, %f78, %f22;\n"
    "    fma.rn.f32 %f23, %f66, %f79, %f23;\n"
    "    fma.rn.f32 %f24, %f67, %f72, %f24;\n"
    "    fma.rn.f32 %f25, %f67, %f73, %f25;\n"
    "    fma.rn.f32 %f26, %f67, %f74, %f26;\n"
    "    fma.rn.f32 %f27, %f67, %f75, %f27;\n"
    "    fma.rn.f32 %f28, %f67, %f76, %f28;\n"
    "    fma.rn.f32 %f29, %f67, %f77, %f29;\n"
    "    fma.rn.f32 %f30, %f67, %f78, %f30;\n"
    "    fma.rn.f32 %f31, %f67, %f79, %f31;\n"
    "    fma.rn.f32 %f32, %f68, %f72, %f32;\n"
    "    fma.rn.f32 %f33, %f68, %f73, %f33;\n"
    "    fma.rn.f32 %f34, %f68, %f74, %f34;\n"
    "    fma.rn.f32 %f35, %f68, %f75, %f35;\n"
    "    fma.rn.f32 %f36, %f68, %f76, %f36;\n"
    "    fma.rn.f32 %f37, %f68, %f77, %f37;\n"
    "    fma.rn.f32 %f38, %f68, %f78, %f38;\n"
    "    fma.rn.f32 %f39, %f68, %f79, %f39;\n"
    "    fma.rn.f32 %f40, %f69, %f72, %f40;\n"
    "    fma.rn.f32 %f41, %f69, %f73, %f41;\n"
    "    fma.rn.f32 %f42, %f69, %f74, %f42;\n"
    "    fma.rn.f32 %f43, %f69, %f75, %f43;\n"
    "    fma.rn.f32 %f44, %f69, %f76, %f44;\n"
    "    fma.rn.f32 %f45, %f69, %f77, %f45;\n"
    "    fma.rn.f32 %f46, %f69, %f78, %f46;\n"
    "    fma.rn.f32 %f47, %f69, %f79, %f47;\n"
    "    fma.rn.f32 %f48, %f70, %f72, %f48;\n"
    "    fma.rn.f32 %f49, %f70, %f73, %f49;\n"
    "    fma.rn.f32 %f50, %f70, %f74, %f50;\n"
    "    fma.rn.f32 %f51, %f70, %f75, %f51;\n"
    "    fma.rn.f32 %f52, %f70, %f76, %f52;\n"
    "    fma.rn.f32 %f53, %f70, %f77, %f53;\n"
    "    fma.rn.f32 %f54, %f70, %f78, %f54;\n"
    "    fma.rn.f32 %f55, %f70, %f79, %f55;\n"
    "    fma.rn.f32 %f56, %f71, %f72, %f56;\n"
    "    fma.rn.f32 %f57, %f71, %f73, %f57;\n"
    "    fma.rn.f32 %f58, %f71, %f74, %f58;\n"
    "    fma.rn.f32 %f59, %f71, %f75, %f59;\n"
    "    fma.rn.f32 %f60, %f71, %f76, %f60;\n"
    "    fma.rn.f32 %f61, %f71, %f77, %f61;\n"
    "    fma.rn.f32 %f62, %f71, %f78, %f62;\n"
    "    fma.rn.f32 %f63, %f71, %f79, %f63;\n"
    "    ld.shared.f32 %f64, [%rd16+12];\n"
    "    ld.shared.f32 %f65, [%rd16+44];\n"
    "    ld.shared.f32 %f66, [%rd16+76];\n"
    "    ld.shared.f32 %f67, [%rd16+108];\n"
    "    ld.shared.f32 %f68, [%rd16+140];\n"
    "    ld.shared.f32 %f69, [%rd16+172];\n"
    "    ld.shared.f32 %f70, [%rd16+204];\n"
    "    ld.shared.f32 %f71, [%rd16+236];\n"
    "    ld.shared.v4.f32 {%f72, %f73, %f74, %f75}, [%rd17+1536];\n"
    "    ld.shared.v4.f32 {%f76, %f77, %f78, %f79}, [%rd17+1552];\n"
    "    fma.rn.f32 %f0, %f64, %f72, %f0;\n"
    "    fma.rn.f32 %f1, %f64, %f73, %f1;\n"
    "    fma.rn.f32 %f2, %f64, %f74, %f2;\n"
    "    fma.rn.f32 %f3, %f64, %f75, %f3;\n"
    "    fma.rn.f32 %f4, %f64, %f76, %f4;\n"
    "    fma.rn.f32 %f5, %f64, %f77, %f5;\n"
    "    fma.rn.f32 %f6, %f64, %f78, %f6;\n"
    "    fma.rn.f32 %f7, %f64, %f79, %f7;\n"
    "    fma.rn.f32 %f8, %f65, %f72, %f8;\n"
    "    fma.rn.f32 %f9, %f65, %f73, %f9;\n"
    "    fma.rn.f32 %f10, %f65, %f74, %f10;\n"
    "    fma.rn.f32 %f11, %f65, %f75, %f11;\n"
    "    fma.rn.f32 %f12, %f65, %f76, %f12;\n"
    "    fma.rn.f32 %f13, %f65, %f77, %f13;\n"
    "    fma.rn.f32 %f14, %f65, %f78, %f14;\n"
    "    fma.rn.f32 %f15, %f65, %f79, %f15;\n"
    "    fma.rn.f32 %f16, %f66, %f72, %f16;\n"
    "    fma.rn.f32 %f17, %f66, %f73, %f17;\n"
    "    fma.rn.f32 %f18, %f66, %f74, %f18;\n"
    "    fma.rn.f32 %f19, %f66, %f75, %f19;\n"
    "    fma.rn.f32 %f20, %f66, %f76, %f20;\n"
    "    fma.rn.f32 %f21, %f66, %f77, %f21;\n"
    "    fma.rn.f32 %f22, %f66, %f78, %f22;\n"
    "    fma.rn.f32 %f23, %f66, %f79, %f23;\n"
    "    fma.rn.f32 %f24, %f67, %f72, %f24;\n"
    "    fma.rn.f32 %f25, %f67, %f73, %f25;\n"
    "    fma.rn.f32 %f26, %f67, %f74, %f26;\n"
    "    fma.rn.f32 %f27, %f67, %f75, %f27;\n"
    "    fma.rn.f32 %f28, %f67, %f76, %f28;\n"
    "    fma.rn.f32 %f29, %f67, %f77, %f29;\n"
    "    fma.rn.f32 %f30, %f67, %f78, %f30;\n"
    "    fma.rn.f32 %f31, %f67, %f79, %f31;\n"
    "    fma.rn.f32 %f32, %f68, %f72, %f32;\n"
    "    fma.rn.f32 %f33, %f68, %f73, %f33;\n"
    "    fma.rn.f32 %f34, %f68, %f74, %f34;\n"
    "    fma.rn.f32 %f35, %f68, %f75, %f35;\n"
    "    fma.rn.f32 %f36, %f68, %f76, %f36;\n"
    "    fma.rn.f32 %f37, %f68, %f77, %f37;\n"
    "    fma.rn.f32 %f38, %f68, %f78, %f38;\n"
    "    fma.rn.f32 %f39, %f68, %f79, %f39;\n"
    "    fma.rn.f32 %f40, %f69, %f72, %f40;\n"
    "    fma.rn.f32 %f41, %f69, %f73, %f41;\n"
    "    fma.rn.f32 %f42, %f69, %f74, %f42;\n"
    "    fma.rn.f32 %f43, %f69, %f75, %f43;\n"
    "    fma.rn.f32 %f44, %f69, %f76, %f44;\n"
    "    fma.rn.f32 %f45, %f69, %f77, %f45;\n"
    "    fma.rn.f32 %f46, %f69, %f78, %f46;\n"
    "    fma.rn.f32 %f47, %f69, %f79, %f47;\n"
    "    fma.rn.f32 %f48, %f70, %f72, %f48;\n"
    "    fma.rn.f32 %f49, %f70, %f73, %f49;\n"
    "    fma.rn.f32 %f50, %f70, %f74, %f50;\n"
    "    fma.rn.f32 %f51, %f70, %f75, %f51;\n"
    "    fma.rn.f32 %f52, %f70, %f76, %f52;\n"
    "    fma.rn.f32 %f53, %f70, %f77, %f53;\n"
    "    fma.rn.f32 %f54, %f70, %f78, %f54;\n"
    "    fma.rn.f32 %f55, %f70, %f79, %f55;\n"
    "    fma.rn.f32 %f56, %f71, %f72, %f56;\n"
    "    fma.rn.f32 %f57, %f71, %f73, %f57;\n"
    "    fma.rn.f32 %f58, %f71, %f74, %f58;\n"
    "    fma.rn.f32 %f59, %f71, %f75, %f59;\n"
    "    fma.rn.f32 %f60, %f71, %f76, %f60;\n"
    "    fma.rn.f32 %f61, %f71, %f77, %f61;\n"
    "    fma.rn.f32 %f62, %f71, %f78, %f62;\n"
    "    fma.rn.f32 %f63, %f71, %f79, %f63;\n"
    "    ld.shared.f32 %f64, [%rd16+16];\n"
    "    ld.shared.f32 %f65, [%rd16+48];\n"
    "    ld.shared.f32 %f66, [%rd16+80];\n"
    "    ld.shared.f32 %f67, [%rd16+112];\n"
    "    ld.shared.f32 %f68, [%rd16+144];\n"
    "    ld.shared.f32 %f69, [%rd16+176];\n"
    "    ld.shared.f32 %f70, [%rd16+208];\n"
    "    ld.shared.f32 %f71, [%rd16+240];\n"
    "    ld.shared.v4.f32 {%f72, %f73, %f74, %f75}, [%rd17+2048];\n"
    "    ld.shared.v4.f32 {%f76, %f77, %f78, %f79}, [%rd17+2064];\n"
    "    fma.rn.f32 %f0, %f64, %f72, %f0;\n"
    "    fma.rn.f32 %f1, %f64, %f73, %f1;\n"
    "    fma.rn.f32 %f2, %f64, %f74, %f2;\n"
    "    fma.rn.f32 %f3, %f64, %f75, %f3;\n"
    "    fma.rn.f32 %f4, %f64, %f76, %f4;\n"
    "    fma.rn.f32 %f5, %f64, %f77, %f5;\n"
    "    fma.rn.f32 %f6, %f64, %f78, %f6;\n"
    "    fma.rn.f32 %f7, %f64, %f79, %f7;\n"
    "    fma.rn.f32 %f8, %f65, %f72, %f8;\n"
    "    fma.rn.f32 %f9, %f65, %f73, %f9;\n"
    "    fma.rn.f32 %f10, %f65, %f74, %f10;\n"
    "    fma.rn.f32 %f11, %f65, %f75, %f11;\n"
    "    fma.rn.f32 %f12, %f65, %f76, %f12;\n"
    "    fma.rn.f32 %f13, %f65, %f77, %f13;\n"
    "    fma.rn.f32 %f14, %f65, %f78, %f14;\n"
    "    fma.rn.f32 %f15, %f65, %f79, %f15;\n"
    "    fma.rn.f32 %f16, %f66, %f72, %f16;\n"
    "    fma.rn.f32 %f17, %f66, %f73, %f17;\n"
    "    fma.rn.f32 %f18, %f66, %f74, %f18;\n"
    "    fma.rn.f32 %f19, %f66, %f75, %f19;\n"
    "    fma.rn.f32 %f20, %f66, %f76, %f20;\n"
    "    fma.rn.f32 %f21, %f66, %f77, %f21;\n"
    "    fma.rn.f32 %f22, %f66, %f78, %f22;\n"
    "    fma.rn.f32 %f23, %f66, %f79, %f23;\n"
    "    fma.rn.f32 %f24, %f67, %f72, %f24;\n"
    "    fma.rn.f32 %f25, %f67, %f73, %f25;\n"
    "    fma.rn.f32 %f26, %f67, %f74, %f26;\n"
    "    fma.rn.f32 %f27, %f67, %f75, %f27;\n"
    "    fma.rn.f32 %f28, %f67, %f76, %f28;\n"
    "    fma.rn.f32 %f29, %f67, %f77, %f29;\n"
    "    fma.rn.f32 %f30, %f67, %f78, %f30;\n"
    "    fma.rn.f32 %f31, %f67, %f79, %f31;\n"
    "    fma.rn.f32 %f32, %f68, %f72, %f32;\n"
    "    fma.rn.f32 %f33, %f68, %f73, %f33;\n"
    "    fma.rn.f32 %f34, %f68, %f74, %f34;\n"
    "    fma.rn.f32 %f35, %f68, %f75, %f35;\n"
    "    fma.rn.f32 %f36, %f68, %f76, %f36;\n"
    "    fma.rn.f32 %f37, %f68, %f77, %f37;\n"
    "    fma.rn.f32 %f38, %f68, %f78, %f38;\n"
    "    fma.rn.f32 %f39, %f68, %f79, %f39;\n"
    "    fma.rn.f32 %f40, %f69, %f72, %f40;\n"
    "    fma.rn.f32 %f41, %f69, %f73, %f41;\n"
    "    fma.rn.f32 %f42, %f69, %f74, %f42;\n"
    "    fma.rn.f32 %f43, %f69, %f75, %f43;\n"
    "    fma.rn.f32 %f44, %f69, %f76, %f44;\n"
    "    fma.rn.f32 %f45, %f69, %f77, %f45;\n"
    "    fma.rn.f32 %f46, %f69, %f78, %f46;\n"
    "    fma.rn.f32 %f47, %f69, %f79, %f47;\n"
    "    fma.rn.f32 %f48, %f70, %f72, %f48;\n"
    "    fma.rn.f32 %f49, %f70, %f73, %f49;\n"
    "    fma.rn.f32 %f50, %f70, %f74, %f50;\n"
    "    fma.rn.f32 %f51, %f70, %f75, %f51;\n"
    "    fma.rn.f32 %f52, %f70, %f76, %f52;\n"
    "    fma.rn.f32 %f53, %f70, %f77, %f53;\n"
    "    fma.rn.f32 %f54, %f70, %f78, %f54;\n"
    "    fma.rn.f32 %f55, %f70, %f79, %f55;\n"
    "    fma.rn.f32 %f56, %f71, %f72, %f56;\n"
    "    fma.rn.f32 %f57, %f71, %f73, %f57;\n"
    "    fma.rn.f32 %f58, %f71, %f74, %f58;\n"
    "    fma.rn.f32 %f59, %f71, %f75, %f59;\n"
    "    fma.rn.f32 %f60, %f71, %f76, %f60;\n"
    "    fma.rn.f32 %f61, %f71, %f77, %f61;\n"
    "    fma.rn.f32 %f62, %f71, %f78, %f62;\n"
    "    fma.rn.f32 %f63, %f71, %f79, %f63;\n"
    "    ld.shared.f32 %f64, [%rd16+20];\n"
    "    ld.shared.f32 %f65, [%rd16+52];\n"
    "    ld.shared.f32 %f66, [%rd16+84];\n"
    "    ld.shared.f32 %f67, [%rd16+116];\n"
    "    ld.shared.f32 %f68, [%rd16+148];\n"
    "    ld.shared.f32 %f69, [%rd16+180];\n"
    "    ld.shared.f32 %f70, [%rd16+212];\n"
    "    ld.shared.f32 %f71, [%rd16+244];\n"
    "    ld.shared.v4.f32 {%f72, %f73, %f74, %f75}, [%rd17+2560];\n"
    "    ld.shared.v4.f32 {%f76, %f77, %f78, %f79}, [%rd17+2576];\n"
    "    fma.rn.f32 %f0, %f64, %f72, %f0;\n"
    "    fma.rn.f32 %f1, %f64, %f73, %f1;\n"
    "    fma.rn.f32 %f2, %f64, %f74, %f2;\n"
    "    fma.rn.f32 %f3, %f64, %f75, %f3;\n"
    "    fma.rn.f32 %f4, %f64, %f76, %f4;\n"
    "    fma.rn.f32 %f5, %f64, %f77, %f5;\n"
    "    fma.rn.f32 %f6, %f64, %f78, %f6;\n"
    "    fma.rn.f32 %f7, %f64, %f79, %f7;\n"
    "    fma.rn.f32 %f8, %f65, %f72, %f8;\n"
    "    fma.rn.f32 %f9, %f65, %f73, %f9;\n"
    "    fma.rn.f32 %f10, %f65, %f74, %f10;\n"
    "    fma.rn.f32 %f11, %f65, %f75, %f11;\n"
    "    fma.rn.f32 %f12, %f65, %f76, %f12;\n"
    "    fma.rn.f32 %f13, %f65, %f77, %f13;\n"
    "    fma.rn.f32 %f14, %f65, %f78, %f14;\n"
    "    fma.rn.f32 %f15, %f65, %f79, %f15;\n"
    "    fma.rn.f32 %f16, %f66, %f72, %f16;\n"
    "    fma.rn.f32 %f17, %f66, %f73, %f17;\n"
    "    fma.rn.f32 %f18, %f66, %f74, %f18;\n"
    "    fma.rn.f32 %f19, %f66, %f75, %f19;\n"
    "    fma.rn.f32 %f20, %f66, %f76, %f20;\n"
    "    fma.rn.f32 %f21, %f66, %f77, %f21;\n"
    "    fma.rn.f32 %f22, %f66, %f78, %f22;\n"
    "    fma.rn.f32 %f23, %f66, %f79, %f23;\n"
    "    fma.rn.f32 %f24, %f67, %f72, %f24;\n"
    "    fma.rn.f32 %f25, %f67, %f73, %f25;\n"
    "    fma.rn.f32 %f26, %f67, %f74, %f26;\n"
    "    fma.rn.f32 %f27, %f67, %f75, %f27;\n"
    "    fma.rn.f32 %f28, %f67, %f76, %f28;\n"
    "    fma.rn.f32 %f29, %f67, %f77, %f29;\n"
    "    fma.rn.f32 %f30, %f67, %f78, %f30;\n"
    "    fma.rn.f32 %f31, %f67, %f79, %f31;\n"
    "    fma.rn.f32 %f32, %f68, %f72, %f32;\n"
    "    fma.rn.f32 %f33, %f68, %f73, %f33;\n"
    "    fma.rn.f32 %f34, %f68, %f74, %f34;\n"
    "    fma.rn.f32 %f35, %f68, %f75, %f35;\n"
    "    fma.rn.f32 %f36, %f68, %f76, %f36;\n"
    "    fma.rn.f32 %f37, %f68, %f77, %f37;\n"
    "    fma.rn.f32 %f38, %f68, %f78, %f38;\n"
    "    fma.rn.f32 %f39, %f68, %f79, %f39;\n"
    "    fma.rn.f32 %f40, %f69, %f72, %f40;\n"
    "    fma.rn.f32 %f41, %f69, %f73, %f41;\n"
    "    fma.rn.f32 %f42, %f69, %f74, %f42;\n"
    "    fma.rn.f32 %f43, %f69, %f75, %f43;\n"
    "    fma.rn.f32 %f44, %f69, %f76, %f44;\n"
    "    fma.rn.f32 %f45, %f69, %f77, %f45;\n"
    "    fma.rn.f32 %f46, %f69, %f78, %f46;\n"
    "    fma.rn.f32 %f47, %f69, %f79, %f47;\n"
    "    fma.rn.f32 %f48, %f70, %f72, %f48;\n"
    "    fma.rn.f32 %f49, %f70, %f73, %f49;\n"
    "    fma.rn.f32 %f50, %f70, %f74, %f50;\n"
    "    fma.rn.f32 %f51, %f70, %f75, %f51;\n"
    "    fma.rn.f32 %f52, %f70, %f76, %f52;\n"
    "    fma.rn.f32 %f53, %f70, %f77, %f53;\n"
    "    fma.rn.f32 %f54, %f70, %f78, %f54;\n"
    "    fma.rn.f32 %f55, %f70, %f79, %f55;\n"
    "    fma.rn.f32 %f56, %f71, %f72, %f56;\n"
    "    fma.rn.f32 %f57, %f71, %f73, %f57;\n"
    "    fma.rn.f32 %f58, %f71, %f74, %f58;\n"
    "    fma.rn.f32 %f59, %f71, %f75, %f59;\n"
    "    fma.rn.f32 %f60, %f71, %f76, %f60;\n"
    "    fma.rn.f32 %f61, %f71, %f77, %f61;\n"
    "    fma.rn.f32 %f62, %f71, %f78, %f62;\n"
    "    fma.rn.f32 %f63, %f71, %f79, %f63;\n"
    "    ld.shared.f32 %f64, [%rd16+24];\n"
    "    ld.shared.f32 %f65, [%rd16+56];\n"
    "    ld.shared.f32 %f66, [%rd16+88];\n"
    "    ld.shared.f32 %f67, [%rd16+120];\n"
    "    ld.shared.f32 %f68, [%rd16+152];\n"
    "    ld.shared.f32 %f69, [%rd16+184];\n"
    "    ld.shared.f32 %f70, [%rd16+216];\n"
    "    ld.shared.f32 %f71, [%rd16+248];\n"
    "    ld.shared.v4.f32 {%f72, %f73, %f74, %f75}, [%rd17+3072];\n"
    "    ld.shared.v4.f32 {%f76, %f77, %f78, %f79}, [%rd17+3088];\n"
    "    fma.rn.f32 %f0, %f64, %f72, %f0;\n"
    "    fma.rn.f32 %f1, %f64, %f73, %f1;\n"
    "    fma.rn.f32 %f2, %f64, %f74, %f2;\n"
    "    fma.rn.f32 %f3, %f64, %f75, %f3;\n"
    "    fma.rn.f32 %f4, %f64, %f76, %f4;\n"
    "    fma.rn.f32 %f5, %f64, %f77, %f5;\n"
    "    fma.rn.f32 %f6, %f64, %f78, %f6;\n"
    "    fma.rn.f32 %f7, %f64, %f79, %f7;\n"
    "    fma.rn.f32 %f8, %f65, %f72, %f8;\n"
    "    fma.rn.f32 %f9, %f65, %f73, %f9;\n"
    "    fma.rn.f32 %f10, %f65, %f74, %f10;\n"
    "    fma.rn.f32 %f11, %f65, %f75, %f11;\n"
    "    fma.rn.f32 %f12, %f65, %f76, %f12;\n"
    "    fma.rn.f32 %f13, %f65, %f77, %f13;\n"
    "    fma.rn.f32 %f14, %f65, %f78, %f14;\n"
    "    fma.rn.f32 %f15, %f65, %f79, %f15;\n"
    "    fma.rn.f32 %f16, %f66, %f72, %f16;\n"
    "    fma.rn.f32 %f17, %f66, %f73, %f17;\n"
    "    fma.rn.f32 %f18, %f66, %f74, %f18;\n"
    "    fma.rn.f32 %f19, %f66, %f75, %f19;\n"
    "    fma.rn.f32 %f20, %f66, %f76, %f20;\n"
    "    fma.rn.f32 %f21, %f66, %f77, %f21;\n"
    "    fma.rn.f32 %f22, %f66, %f78, %f22;\n"
    "    fma.rn.f32 %f23, %f66, %f79, %f23;\n"
    "    fma.rn.f32 %f24, %f67, %f72, %f24;\n"
    "    fma.rn.f32 %f25, %f67, %f73, %f25;\n"
    "    fma.rn.f32 %f26, %f67, %f74, %f26;\n"
    "    fma.rn.f32 %f27, %f67, %f75, %f27;\n"
    "    fma.rn.f32 %f28, %f67, %f76, %f28;\n"
    "    fma.rn.f32 %f29, %f67, %f77, %f29;\n"
    "    fma.rn.f32 %f30, %f67, %f78, %f30;\n"
    "    fma.rn.f32 %f31, %f67, %f79, %f31;\n"
    "    fma.rn.f32 %f32, %f68, %f72, %f32;\n"
    "    fma.rn.f32 %f33, %f68, %f73, %f33;\n"
    "    fma.rn.f32 %f34, %f68, %f74, %f34;\n"
    "    fma.rn.f32 %f35, %f68, %f75, %f35;\n"
    "    fma.rn.f32 %f36, %f68, %f76, %f36;\n"
    "    fma.rn.f32 %f37, %f68, %f77, %f37;\n"
    "    fma.rn.f32 %f38, %f68, %f78, %f38;\n"
    "    fma.rn.f32 %f39, %f68, %f79, %f39;\n"
    "    fma.rn.f32 %f40, %f69, %f72, %f40;\n"
    "    fma.rn.f32 %f41, %f69, %f73, %f41;\n"
    "    fma.rn.f32 %f42, %f69, %f74, %f42;\n"
    "    fma.rn.f32 %f43, %f69, %f75, %f43;\n"
    "    fma.rn.f32 %f44, %f69, %f76, %f44;\n"
    "    fma.rn.f32 %f45, %f69, %f77, %f45;\n"
    "    fma.rn.f32 %f46, %f69, %f78, %f46;\n"
    "    fma.rn.f32 %f47, %f69, %f79, %f47;\n"
    "    fma.rn.f32 %f48, %f70, %f72, %f48;\n"
    "    fma.rn.f32 %f49, %f70, %f73, %f49;\n"
    "    fma.rn.f32 %f50, %f70, %f74, %f50;\n"
    "    fma.rn.f32 %f51, %f70, %f75, %f51;\n"
    "    fma.rn.f32 %f52, %f70, %f76, %f52;\n"
    "    fma.rn.f32 %f53, %f70, %f77, %f53;\n"
    "    fma.rn.f32 %f54, %f70, %f78, %f54;\n"
    "    fma.rn.f32 %f55, %f70, %f79, %f55;\n"
    "    fma.rn.f32 %f56, %f71, %f72, %f56;\n"
    "    fma.rn.f32 %f57, %f71, %f73, %f57;\n"
    "    fma.rn.f32 %f58, %f71, %f74, %f58;\n"
    "    fma.rn.f32 %f59, %f71, %f75, %f59;\n"
    "    fma.rn.f32 %f60, %f71, %f76, %f60;\n"
    "    fma.rn.f32 %f61, %f71, %f77, %f61;\n"
    "    fma.rn.f32 %f62, %f71, %f78, %f62;\n"
    "    fma.rn.f32 %f63, %f71, %f79, %f63;\n"
    "    ld.shared.f32 %f64, [%rd16+28];\n"
    "    ld.shared.f32 %f65, [%rd16+60];\n"
    "    ld.shared.f32 %f66, [%rd16+92];\n"
    "    ld.shared.f32 %f67, [%rd16+124];\n"
    "    ld.shared.f32 %f68, [%rd16+156];\n"
    "    ld.shared.f32 %f69, [%rd16+188];\n"
    "    ld.shared.f32 %f70, [%rd16+220];\n"
    "    ld.shared.f32 %f71, [%rd16+252];\n"
    "    ld.shared.v4.f32 {%f72, %f73, %f74, %f75}, [%rd17+3584];\n"
    "    ld.shared.v4.f32 {%f76, %f77, %f78, %f79}, [%rd17+3600];\n"
    "    fma.rn.f32 %f0, %f64, %f72, %f0;\n"
    "    fma.rn.f32 %f1, %f64, %f73, %f1;\n"
    "    fma.rn.f32 %f2, %f64, %f74, %f2;\n"
    "    fma.rn.f32 %f3, %f64, %f75, %f3;\n"
    "    fma.rn.f32 %f4, %f64, %f76, %f4;\n"
    "    fma.rn.f32 %f5, %f64, %f77, %f5;\n"
    "    fma.rn.f32 %f6, %f64, %f78, %f6;\n"
    "    fma.rn.f32 %f7, %f64, %f79, %f7;\n"
    "    fma.rn.f32 %f8, %f65, %f72, %f8;\n"
    "    fma.rn.f32 %f9, %f65, %f73, %f9;\n"
    "    fma.rn.f32 %f10, %f65, %f74, %f10;\n"
    "    fma.rn.f32 %f11, %f65, %f75, %f11;\n"
    "    fma.rn.f32 %f12, %f65, %f76, %f12;\n"
    "    fma.rn.f32 %f13, %f65, %f77, %f13;\n"
    "    fma.rn.f32 %f14, %f65, %f78, %f14;\n"
    "    fma.rn.f32 %f15, %f65, %f79, %f15;\n"
    "    fma.rn.f32 %f16, %f66, %f72, %f16;\n"
    "    fma.rn.f32 %f17, %f66, %f73, %f17;\n"
    "    fma.rn.f32 %f18, %f66, %f74, %f18;\n"
    "    fma.rn.f32 %f19, %f66, %f75, %f19;\n"
    "    fma.rn.f32 %f20, %f66, %f76, %f20;\n"
    "    fma.rn.f32 %f21, %f66, %f77, %f21;\n"
    "    fma.rn.f32 %f22, %f66, %f78, %f22;\n"
    "    fma.rn.f32 %f23, %f66, %f79, %f23;\n"
    "    fma.rn.f32 %f24, %f67, %f72, %f24;\n"
    "    fma.rn.f32 %f25, %f67, %f73, %f25;\n"
    "    fma.rn.f32 %f26, %f67, %f74, %f26;\n"
    "    fma.rn.f32 %f27, %f67, %f75, %f27;\n"
    "    fma.rn.f32 %f28, %f67, %f76, %f28;\n"
    "    fma.rn.f32 %f29, %f67, %f77, %f29;\n"
    "    fma.rn.f32 %f30, %f67, %f78, %f30;\n"
    "    fma.rn.f32 %f31, %f67, %f79, %f31;\n"
    "    fma.rn.f32 %f32, %f68, %f72, %f32;\n"
    "    fma.rn.f32 %f33, %f68, %f73, %f33;\n"
    "    fma.rn.f32 %f34, %f68, %f74, %f34;\n"
    "    fma.rn.f32 %f35, %f68, %f75, %f35;\n"
    "    fma.rn.f32 %f36, %f68, %f76, %f36;\n"
    "    fma.rn.f32 %f37, %f68, %f77, %f37;\n"
    "    fma.rn.f32 %f38, %f68, %f78, %f38;\n"
    "    fma.rn.f32 %f39, %f68, %f79, %f39;\n"
    "    fma.rn.f32 %f40, %f69, %f72, %f40;\n"
    "    fma.rn.f32 %f41, %f69, %f73, %f41;\n"
    "    fma.rn.f32 %f42, %f69, %f74, %f42;\n"
    "    fma.rn.f32 %f43, %f69, %f75, %f43;\n"
    "    fma.rn.f32 %f44, %f69, %f76, %f44;\n"
    "    fma.rn.f32 %f45, %f69, %f77, %f45;\n"
    "    fma.rn.f32 %f46, %f69, %f78, %f46;\n"
    "    fma.rn.f32 %f47, %f69, %f79, %f47;\n"
    "    fma.rn.f32 %f48, %f70, %f72, %f48;\n"
    "    fma.rn.f32 %f49, %f70, %f73, %f49;\n"
    "    fma.rn.f32 %f50, %f70, %f74, %f50;\n"
    "    fma.rn.f32 %f51, %f70, %f75, %f51;\n"
    "    fma.rn.f32 %f52, %f70, %f76, %f52;\n"
    "    fma.rn.f32 %f53, %f70, %f77, %f53;\n"
    "    fma.rn.f32 %f54, %f70, %f78, %f54;\n"
    "    fma.rn.f32 %f55, %f70, %f79, %f55;\n"
    "    fma.rn.f32 %f56, %f71, %f72, %f56;\n"
    "    fma.rn.f32 %f57, %f71, %f73, %f57;\n"
    "    fma.rn.f32 %f58, %f71, %f74, %f58;\n"
    "    fma.rn.f32 %f59, %f71, %f75, %f59;\n"
    "    fma.rn.f32 %f60, %f71, %f76, %f60;\n"
    "    fma.rn.f32 %f61, %f71, %f77, %f61;\n"
    "    fma.rn.f32 %f62, %f71, %f78, %f62;\n"
    "    fma.rn.f32 %f63, %f71, %f79, %f63;\n"
    "\n"
    "    bar.sync 0;\n"
    "\n"
    "    st.shared.f32 [%rd6+0], %f80;\n"
    "    st.shared.f32 [%rd6+4], %f81;\n"
    "    st.shared.f32 [%rd6+8], %f82;\n"
    "    st.shared.f32 [%rd6+12], %f83;\n"
    "    st.shared.f32 [%rd7+0], %f84;\n"
    "    st.shared.f32 [%rd7+4], %f85;\n"
    "    st.shared.f32 [%rd7+8], %f86;\n"
    "    st.shared.f32 [%rd7+12], %f87;\n"
    "    bar.sync 0;\n"
    "    bra KLOOP;\n"
    "\n"
    "STORE:\n"
    "    mul.wide.u32 %rd9, %r8, %r2;\n"
    "    cvt.u64.u32   %rd10, %r12;\n"
    "    add.s64       %rd9, %rd9, %rd10;\n"
    "    shl.b64       %rd9, %rd9, 2;\n"
    "    add.s64       %rd9, %rd9, %rd3;\n"
    "    add.s64 %rd10, %rd9,  %rd15;\n"
    "    add.s64 %rd11, %rd10, %rd15;\n"
    "    add.s64 %rd12, %rd11, %rd15;\n"
    "    add.s64 %rd18, %rd12, %rd15;\n"
    "    add.s64 %rd19, %rd18, %rd15;\n"
    "    add.s64 %rd20, %rd19, %rd15;\n"
    "    add.s64 %rd21, %rd20, %rd15;\n"
    "    add.s64 %rd22, %rd21, %rd15;\n"
    "\n"
    "    add.s32 %r18, %r8, 1;\n"
    "    add.s32 %r19, %r8, 2;\n"
    "    add.s32 %r20, %r8, 3;\n"
    "    setp.lt.u32 %p1, %r8, %r1;\n"
    "    setp.lt.u32 %p2, %r18, %r1;\n"
    "    setp.lt.u32 %p3, %r19, %r1;\n"
    "    setp.lt.u32 %p4, %r20, %r1;\n"
    "    setp.lt.u32 %p5, %r14, %r1;\n"
    "    setp.lt.u32 %p6, %r15, %r1;\n"
    "    setp.lt.u32 %p7, %r16, %r1;\n"
    "    setp.lt.u32 %p8, %r17, %r1;\n"
    "\n"
    "    add.s32 %r21, %r12, 1;\n"
    "    add.s32 %r22, %r12, 2;\n"
    "    add.s32 %r23, %r12, 3;\n"
    "    add.s32 %r24, %r12, 4;\n"
    "    add.s32 %r25, %r12, 5;\n"
    "    add.s32 %r26, %r12, 6;\n"
    "    add.s32 %r27, %r12, 7;\n"
    "    setp.lt.u32 %p40, %r12, %r2;\n"
    "    setp.lt.u32 %p41, %r21, %r2;\n"
    "    setp.lt.u32 %p42, %r22, %r2;\n"
    "    setp.lt.u32 %p43, %r23, %r2;\n"
    "    setp.lt.u32 %p44, %r24, %r2;\n"
    "    setp.lt.u32 %p45, %r25, %r2;\n"
    "    setp.lt.u32 %p46, %r26, %r2;\n"
    "    setp.lt.u32 %p47, %r27, %r2;\n"
    "\n"
    "    and.pred %p48, %p1, %p40;\n"
    "    @%p48 st.global.f32 [%rd9+0], %f0;\n"
    "    and.pred %p49, %p1, %p41;\n"
    "    @%p49 st.global.f32 [%rd9+4], %f1;\n"
    "    and.pred %p50, %p1, %p42;\n"
    "    @%p50 st.global.f32 [%rd9+8], %f2;\n"
    "    and.pred %p51, %p1, %p43;\n"
    "    @%p51 st.global.f32 [%rd9+12], %f3;\n"
    "    and.pred %p52, %p1, %p44;\n"
    "    @%p52 st.global.f32 [%rd9+16], %f4;\n"
    "    and.pred %p53, %p1, %p45;\n"
    "    @%p53 st.global.f32 [%rd9+20], %f5;\n"
    "    and.pred %p54, %p1, %p46;\n"
    "    @%p54 st.global.f32 [%rd9+24], %f6;\n"
    "    and.pred %p55, %p1, %p47;\n"
    "    @%p55 st.global.f32 [%rd9+28], %f7;\n"
    "\n"
    "    and.pred %p56, %p2, %p40;\n"
    "    @%p56 st.global.f32 [%rd10+0], %f8;\n"
    "    and.pred %p57, %p2, %p41;\n"
    "    @%p57 st.global.f32 [%rd10+4], %f9;\n"
    "    and.pred %p58, %p2, %p42;\n"
    "    @%p58 st.global.f32 [%rd10+8], %f10;\n"
    "    and.pred %p59, %p2, %p43;\n"
    "    @%p59 st.global.f32 [%rd10+12], %f11;\n"
    "    and.pred %p60, %p2, %p44;\n"
    "    @%p60 st.global.f32 [%rd10+16], %f12;\n"
    "    and.pred %p61, %p2, %p45;\n"
    "    @%p61 st.global.f32 [%rd10+20], %f13;\n"
    "    and.pred %p62, %p2, %p46;\n"
    "    @%p62 st.global.f32 [%rd10+24], %f14;\n"
    "    and.pred %p63, %p2, %p47;\n"
    "    @%p63 st.global.f32 [%rd10+28], %f15;\n"
    "\n"
    "    and.pred %p64, %p3, %p40;\n"
    "    @%p64 st.global.f32 [%rd11+0], %f16;\n"
    "    and.pred %p65, %p3, %p41;\n"
    "    @%p65 st.global.f32 [%rd11+4], %f17;\n"
    "    and.pred %p66, %p3, %p42;\n"
    "    @%p66 st.global.f32 [%rd11+8], %f18;\n"
    "    and.pred %p67, %p3, %p43;\n"
    "    @%p67 st.global.f32 [%rd11+12], %f19;\n"
    "    and.pred %p68, %p3, %p44;\n"
    "    @%p68 st.global.f32 [%rd11+16], %f20;\n"
    "    and.pred %p69, %p3, %p45;\n"
    "    @%p69 st.global.f32 [%rd11+20], %f21;\n"
    "    and.pred %p70, %p3, %p46;\n"
    "    @%p70 st.global.f32 [%rd11+24], %f22;\n"
    "    and.pred %p71, %p3, %p47;\n"
    "    @%p71 st.global.f32 [%rd11+28], %f23;\n"
    "\n"
    "    and.pred %p72, %p4, %p40;\n"
    "    @%p72 st.global.f32 [%rd12+0], %f24;\n"
    "    and.pred %p73, %p4, %p41;\n"
    "    @%p73 st.global.f32 [%rd12+4], %f25;\n"
    "    and.pred %p74, %p4, %p42;\n"
    "    @%p74 st.global.f32 [%rd12+8], %f26;\n"
    "    and.pred %p75, %p4, %p43;\n"
    "    @%p75 st.global.f32 [%rd12+12], %f27;\n"
    "    and.pred %p76, %p4, %p44;\n"
    "    @%p76 st.global.f32 [%rd12+16], %f28;\n"
    "    and.pred %p77, %p4, %p45;\n"
    "    @%p77 st.global.f32 [%rd12+20], %f29;\n"
    "    and.pred %p78, %p4, %p46;\n"
    "    @%p78 st.global.f32 [%rd12+24], %f30;\n"
    "    and.pred %p79, %p4, %p47;\n"
    "    @%p79 st.global.f32 [%rd12+28], %f31;\n"
    "\n"
    "    and.pred %p80, %p5, %p40;\n"
    "    @%p80 st.global.f32 [%rd18+0], %f32;\n"
    "    and.pred %p81, %p5, %p41;\n"
    "    @%p81 st.global.f32 [%rd18+4], %f33;\n"
    "    and.pred %p82, %p5, %p42;\n"
    "    @%p82 st.global.f32 [%rd18+8], %f34;\n"
    "    and.pred %p83, %p5, %p43;\n"
    "    @%p83 st.global.f32 [%rd18+12], %f35;\n"
    "    and.pred %p84, %p5, %p44;\n"
    "    @%p84 st.global.f32 [%rd18+16], %f36;\n"
    "    and.pred %p85, %p5, %p45;\n"
    "    @%p85 st.global.f32 [%rd18+20], %f37;\n"
    "    and.pred %p86, %p5, %p46;\n"
    "    @%p86 st.global.f32 [%rd18+24], %f38;\n"
    "    and.pred %p87, %p5, %p47;\n"
    "    @%p87 st.global.f32 [%rd18+28], %f39;\n"
    "\n"
    "    and.pred %p88, %p6, %p40;\n"
    "    @%p88 st.global.f32 [%rd19+0], %f40;\n"
    "    and.pred %p89, %p6, %p41;\n"
    "    @%p89 st.global.f32 [%rd19+4], %f41;\n"
    "    and.pred %p90, %p6, %p42;\n"
    "    @%p90 st.global.f32 [%rd19+8], %f42;\n"
    "    and.pred %p91, %p6, %p43;\n"
    "    @%p91 st.global.f32 [%rd19+12], %f43;\n"
    "    and.pred %p92, %p6, %p44;\n"
    "    @%p92 st.global.f32 [%rd19+16], %f44;\n"
    "    and.pred %p93, %p6, %p45;\n"
    "    @%p93 st.global.f32 [%rd19+20], %f45;\n"
    "    and.pred %p94, %p6, %p46;\n"
    "    @%p94 st.global.f32 [%rd19+24], %f46;\n"
    "    and.pred %p95, %p6, %p47;\n"
    "    @%p95 st.global.f32 [%rd19+28], %f47;\n"
    "\n"
    "    and.pred %p96, %p7, %p40;\n"
    "    @%p96 st.global.f32 [%rd20+0], %f48;\n"
    "    and.pred %p97, %p7, %p41;\n"
    "    @%p97 st.global.f32 [%rd20+4], %f49;\n"
    "    and.pred %p98, %p7, %p42;\n"
    "    @%p98 st.global.f32 [%rd20+8], %f50;\n"
    "    and.pred %p99, %p7, %p43;\n"
    "    @%p99 st.global.f32 [%rd20+12], %f51;\n"
    "    and.pred %p100, %p7, %p44;\n"
    "    @%p100 st.global.f32 [%rd20+16], %f52;\n"
    "    and.pred %p101, %p7, %p45;\n"
    "    @%p101 st.global.f32 [%rd20+20], %f53;\n"
    "    and.pred %p102, %p7, %p46;\n"
    "    @%p102 st.global.f32 [%rd20+24], %f54;\n"
    "    and.pred %p103, %p7, %p47;\n"
    "    @%p103 st.global.f32 [%rd20+28], %f55;\n"
    "\n"
    "    and.pred %p104, %p8, %p40;\n"
    "    @%p104 st.global.f32 [%rd21+0], %f56;\n"
    "    and.pred %p105, %p8, %p41;\n"
    "    @%p105 st.global.f32 [%rd21+4], %f57;\n"
    "    and.pred %p106, %p8, %p42;\n"
    "    @%p106 st.global.f32 [%rd21+8], %f58;\n"
    "    and.pred %p107, %p8, %p43;\n"
    "    @%p107 st.global.f32 [%rd21+12], %f59;\n"
    "    and.pred %p108, %p8, %p44;\n"
    "    @%p108 st.global.f32 [%rd21+16], %f60;\n"
    "    and.pred %p109, %p8, %p45;\n"
    "    @%p109 st.global.f32 [%rd21+20], %f61;\n"
    "    and.pred %p110, %p8, %p46;\n"
    "    @%p110 st.global.f32 [%rd21+24], %f62;\n"
    "    and.pred %p111, %p8, %p47;\n"
    "    @%p111 st.global.f32 [%rd21+28], %f63;\n"
    "\n"
    "DONE:\n"
    "    ret;\n"
    "}";

/* 一个模块装三个 entry：
 *   sgemm          —— 4x4 寄存器分块（N<256，无 bar.sync、occupancy 高）
 *   sgemm_shared   —— 4x4 + shared tiling，tile 64x64（256<=N<512）
 *   sgemm_8x8      —— 8x8 + shared tiling，tile 128x128 + K-tile 载入预取
 *                     （N>=1280，每线程计算量翻倍、global 访存再减半；
 *                      载入提前到 512 条 FMA 之前发出，见文件头「第三跳」说明。
 *                      1060 实测 N=3216：41.5 -> 32.2 ms，快 22.4%）
 * 后两个取不到不致命：对应指针置 NULL，路由跳过（等于没这个优化）。
 * 模块加载后不保存 mod：驱动持有到卸载，function 指针一直有效（与旧版同）。 */
static CUfunction compile_sgemm(void)
{
    char       img[65536];
    char       head[128];
    CUmodule   mod = NULL;
    CUfunction fn = NULL;
    CUresult   r = 0;
    size_t     i;
    int        wr;

    for (i = 0; i < sizeof(PTX_VERSIONS) / sizeof(PTX_VERSIONS[0]); i++) {
        snprintf(head, sizeof head,
                 ".version %s\n.target sm_%d\n.address_size 64\n\n",
                 PTX_VERSIONS[i], g_cc);
        wr = snprintf(img, sizeof img, "%s%s\n%s\n%s", head,
                      PTX_BODY_4X4, PTX_BODY_SHARED, PTX_BODY_8X8);
        if (wr < 0 || (size_t)wr >= sizeof img)
            continue;                       /* 放不下，换下一个 .version 重试 */
        {   /* 调试钩子：把真正喂给驱动的 PTX 落盘，排查「编不过」时不再盲猜 */
            const char *dp = getenv("PYVM_PTX_DUMP");
            if (dp) {
                FILE *pf = fopen(dp, "wb");
                if (pf) { fwrite(img, 1, (size_t)wr, pf); fclose(pf); }
            }
        }
        r = p_cuModuleLoadData(&mod, img);
        if (r != 0)
            continue;                       /* 这个 .version 不行，换下一个 */
        r = p_cuModuleGetFunction(&fn, mod, "sgemm");
        if (r != 0) {
            snprintf(g_why, sizeof g_why, "PTX 编过了但取不到 sgemm 入口：%s",
                     cu_err(r));
            return NULL;
        }
        g_fn_sh = NULL;
        if (p_cuModuleGetFunction(&g_fn_sh, mod, "sgemm_shared") != 0)
            g_fn_sh = NULL;                 /* 降级：跳过 shared，不堵死 GPU 通路 */
        g_fn_8x8 = NULL;
        if (p_cuModuleGetFunction(&g_fn_8x8, mod, "sgemm_8x8") != 0)
            g_fn_8x8 = NULL;                /* 降级：跳过 8x8，不堵死 GPU 通路 */
        return fn;
    }
    snprintf(g_why, sizeof g_why,
             "手写 PTX 被驱动拒了（这张卡 CC=%d、驱动 %d，"
             ".version 8.7~6.0 全试过）：%s", g_cc, g_driver, cu_err(r));
    return NULL;
}

/* conv2d + 池化模块：与 sgemm 分开装（不挤 64K 镜像），失败降级 NULL。
 * 注意：这里的失败不算 GPU 通路故障——sgemm 还在，conv/pool 留在 CPU 而已。 */
static CUfunction compile_conv(void)
{
    char       img[65536];
    char       head[128];
    CUmodule   mod = NULL;
    CUfunction fn = NULL;
    CUresult   r = 0;
    size_t     i;
    int        wr;

    for (i = 0; i < sizeof(PTX_VERSIONS) / sizeof(PTX_VERSIONS[0]); i++) {
        snprintf(head, sizeof head,
                 ".version %s\n.target sm_%d\n.address_size 64\n\n",
                 PTX_VERSIONS[i], g_cc);
        wr = snprintf(img, sizeof img, "%s%s\n%s\n%s", head,
                      PTX_BODY_CONV2D, PTX_BODY_CONV2D_SHR, PTX_BODY_POOL);
        if (wr < 0 || (size_t)wr >= sizeof img)
            continue;
        r = p_cuModuleLoadData(&mod, img);
        if (r != 0)
            continue;
        r = p_cuModuleGetFunction(&fn, mod, "conv2d");
        if (r != 0) {
            snprintf(g_why, sizeof g_why, "PTX 编过了但取不到 conv2d 入口：%s",
                     cu_err(r));
            return NULL;
        }
        g_fn_conv_shr = NULL;
        if (p_cuModuleGetFunction(&g_fn_conv_shr, mod, "conv2d_shr") != 0)
            g_fn_conv_shr = NULL;        /* 降级：共享内存版取不到就只用老内核 */
        g_fn_maxpool = NULL;
        if (p_cuModuleGetFunction(&g_fn_maxpool, mod, "maxpool") != 0)
            g_fn_maxpool = NULL;            /* 降级：跳过池化，不堵 conv */
        g_fn_avgpool = NULL;
        if (p_cuModuleGetFunction(&g_fn_avgpool, mod, "avgpool") != 0)
            g_fn_avgpool = NULL;            /* 降级：跳过池化，不堵 conv */
        return fn;
    }
    snprintf(g_why, sizeof g_why, "conv2d PTX 被驱动拒了（CC=%d）：%s",
             g_cc, cu_err(r));
    return NULL;
}

/* tb 层问：池化内核在不在（两个都在才上卡，半套不如全走 CPU） */
int gpu_pool_ready(void)
{
    gpu_probe();
    return (g_fn_maxpool && g_fn_avgpool) ? 1 : 0;
}

/* tb 层问：conv 内核在不在（决定降级 CPU 还是上卡） */
int gpu_conv_ready(void)
{
    gpu_probe();
    return g_fn_conv != NULL;
}

int gpu_probe(void)
{
    if (g_probed)
        return g_ready;
    g_probed = 1;
    g_ready = 0;
    /* 调试/测试钩子：强制当作「这台机器没有 GPU」。
     * 没有它就没法在有卡的机器上验「device gpu 探测不到必须报错」这条语义 ——
     * 而那恰恰是 device gpu 最不能错的地方（静默退回 CPU 等于骗人）。 */
    if (getenv("PYBOOK_GPU_DISABLE")) {
        snprintf(g_why, sizeof g_why,
                 "PYBOOK_GPU_DISABLE=1（按环境变量强制当作没有 GPU，调试用）");
        return 0;
    }
    if (!load_syms())
        return 0;
    if (p_cuInit(0) != 0) {
        snprintf(g_why, sizeof g_why, "cuInit 失败（驱动没能初始化）");
        return 0;
    }
    p_cuDriverGetVersion(&g_driver);
    {
        int ndev = 0;
        CUdevice dev;
        int maj = 0, min = 0;
        if (p_cuDeviceGetCount(&ndev) != 0 || ndev <= 0) {
            snprintf(g_why, sizeof g_why, "CUDA 一块卡都没看到");
            return 0;
        }
        if (p_cuDeviceGet(&dev, 0) != 0) {
            snprintf(g_why, sizeof g_why, "取不到第 0 号 CUDA 设备");
            return 0;
        }
        p_cuDeviceGetName(g_name, sizeof g_name, dev);
        p_cuDeviceTotalMem(&g_totalmem, dev);
        p_cuDeviceGetAttribute(&maj, CU_DEVICE_ATTRIBUTE_CC_MAJOR, dev);
        p_cuDeviceGetAttribute(&min, CU_DEVICE_ATTRIBUTE_CC_MINOR, dev);
        g_cc = maj * 10 + min;
        /* 第四跳：路由要用 SM 数与每 SM 最大线程数。
         * 拿不到就置 0，路由会自动退回老阈值（宁可老办法也不能瞎选）。 */
        g_sms = 0;
        g_max_threads_sm = 0;
        p_cuDeviceGetAttribute(&g_sms, CU_DEVICE_ATTRIBUTE_MULTIPROCESSOR_COUNT, dev);
        p_cuDeviceGetAttribute(&g_max_threads_sm,
                               CU_DEVICE_ATTRIBUTE_MAX_THREADS_PER_MULTIPROCESSOR, dev);
        if (g_sms < 1) g_sms = 0;
        if (g_max_threads_sm < 1) g_max_threads_sm = 0;
        if (g_max_threads_sm < 1) g_max_threads_sm = 0;
        /* 路由用的 SM 数：默认就是真实值；PYBOOK_GPU_FAKE_SMS 可以覆盖，
         * 用来在只有一张 1060 的机器上模拟大卡、验证路由会不会选错。
         * 注意它只影响**选型**，不影响自标定（标定必须按真实机器算）。 */
        g_sms_route = g_sms;
        {
            const char *fs = getenv("PYBOOK_GPU_FAKE_SMS");
            if (fs) {
                int v = atoi(fs);
                if (v > 0) g_sms_route = v;
            }
        }
        if (maj < 5) {
            snprintf(g_why, sizeof g_why,
                     "这张卡太老（CC %d.%d，PYbook 的 GPU 通路要 CC 5.0+）",
                     maj, min);
            return 0;
        }
        if (p_cuDevicePrimaryCtxRetain(&g_ctx, dev) != 0) {
            snprintf(g_why, sizeof g_why, "建不了 CUDA context");
            return 0;
        }
    }
    if (p_cuCtxSetCurrent(g_ctx) != 0) {
        snprintf(g_why, sizeof g_why, "CUDA context 切不过去");
        return 0;
    }
    g_fn = compile_sgemm();
    if (!g_fn)
        return 0;
    g_fn_conv = compile_conv();     /* 失败只降级 conv，不影响 sgemm 通路 */
    gpu_setup_kernels();             /* 第四跳：建 kernel 表 + 问每 SM 驻留数 */
    gpu_calibrate();                 /* 第四跳：在这张卡上现测时间常数 */
    g_ready = 1;
    g_why[0] = '\0';
    return 1;
}

int gpu_available(void)      { return gpu_probe(); }
int gpu_driver_version(void) { gpu_probe(); return g_driver; }
const char *gpu_device_name(void)
{
    if (gpu_probe())
        return g_name;
    return g_why[0] ? g_why : "未知原因";
}
const char *gpu_last_error(void) { return g_err[0] ? g_err : "（无）"; }

void gpu_die_unavailable(void)
{
    gpu_probe();
    rt_die("device gpu：这台机器上没有可用的 GPU 后端（%s）\n"
           "  为什么：GPU 通路走的是 NVIDIA CUDA，运行时动态加载 nvcuda.dll，"
           "再让驱动自己编译手写 PTX。探测结果是「%s」。\n"
           "  怎么改：改文件头写 device cpu（可带线程数，如 device cpu 8），"
           "或 device auto（有卡就用、没有就用 CPU）；"
           "想真上卡就装/修好 NVIDIA 驱动后重跑。",
           g_why[0] ? g_why : "未知原因", g_why[0] ? g_why : "未知原因");
}

/* ─────────────── 缓冲 ───────────────
 * 显存按「最大要装多少字节」扩容复用，不每次 malloc。
 * host 暂存区同理：cuMemcpyHtoD 从 pageable 内存走要过驱动内部的分页暂存，
 * 实测比页锁定慢好几倍，而大矩阵搬运本来就是大头，所以值得单独申请。 */
static int ensure_bufs(size_t bytes)
{
    CUresult r;
    if (bytes <= g_cap)
        return 1;
    if (bytes > g_totalmem - g_totalmem / 4)
        return gpu_fail("要 %zu 字节显存，但这张卡总共才 %zu 字节",
                        bytes, g_totalmem);
    if (g_cap) {
        p_cuMemFree_v2(g_dA); p_cuMemFree_v2(g_dB); p_cuMemFree_v2(g_dC);
        g_dA = g_dB = g_dC = 0;
        g_cap = 0;
    }
    r = p_cuMemAlloc_v2(&g_dA, bytes);
    if (r != 0) return gpu_fail("显存分配失败（%zu 字节 × 3）：%s", bytes, cu_err(r));
    r = p_cuMemAlloc_v2(&g_dB, bytes);
    if (r != 0) { p_cuMemFree_v2(g_dA); g_dA = 0; return gpu_fail("显存分配失败：%s", cu_err(r)); }
    r = p_cuMemAlloc_v2(&g_dC, bytes);
    if (r != 0) { p_cuMemFree_v2(g_dA); p_cuMemFree_v2(g_dB); g_dA = g_dB = 0;
                  return gpu_fail("显存分配失败：%s", cu_err(r)); }
    g_cap = bytes;
    return 1;
}

static void drop_host_bufs(void)
{
    if (g_pinned) {
        if (g_hA) p_cuMemFreeHost(g_hA);
        if (g_hB) p_cuMemFreeHost(g_hB);
        if (g_hC) p_cuMemFreeHost(g_hC);
    } else {
        free((void *)g_hA); free((void *)g_hB); free((void *)g_hC);
    }
    g_hA = g_hB = g_hC = 0;
    g_hcap = 0;
    g_pinned = 0;
}

static int ensure_host_bufs(size_t bytes)
{
    CUresult r;
    if (g_hcap && bytes <= g_hcap)
        return 1;
    if (g_hcap)
        drop_host_bufs();
    if (p_cuMemAllocHost_v2 && p_cuMemFreeHost) {
        r = p_cuMemAllocHost_v2(&g_hA, bytes);
        if (r == 0) r = p_cuMemAllocHost_v2(&g_hB, bytes);
        if (r == 0) r = p_cuMemAllocHost_v2(&g_hC, bytes);
        if (r == 0) { g_hcap = bytes; g_pinned = 1; return 1; }
        drop_host_bufs();
    }
    /* 拿不到页锁定不算失败：退回普通堆内存，正确性不变，只是慢。 */
    g_hA = (CUdeviceptr)malloc(bytes);
    g_hB = (CUdeviceptr)malloc(bytes);
    g_hC = (CUdeviceptr)malloc(bytes);
    if (!g_hA || !g_hB || !g_hC) {
        drop_host_bufs();
        return gpu_fail("host 暂存内存不足（要 %zu 字节 × 3）", bytes);
    }
    g_hcap = bytes;
    return 1;
}

/* ─────────────── sgemm ───────────────
 * A(MxK) * B(KxN) -> C(MxN)，卡上按 float32 算。
 *
 * 参数类型注意：host 侧三个指针全是 double*，因为 PYbook 张量统一用 double
 * 缓冲存。这里转 float32 是无损的 —— 调用方必须保证三个张量都是 TENSOR_F32
 * （每个值都能被 float32 精确表示），这一点由 tensor 的 prec 字段保证。
 *
 * 要求 N/K 都能被 4 整除（float4 的 16 字节对齐）；M 不限，
 * 尺寸不合直接返回 0，由调用方回退 CPU —— 这里不猜、不猜错。
 */
/* shared tiling kernel 的启用阈值：N >= 此值才值得付 bar.sync + 低 occupancy
 * 的代价。1060 实测（GTX 1060 6GB / sm_61；CUDA event 计时，21~31 轮交替取中位数，
 * 每轮轮转 kernel 顺序，三个 kernel 同源同数据对拍，工具 _gpucmp.c）：
 *   N   4x4(ms)  shared(ms)   谁赢
 *   96    0.013    0.015      4x4 +15%
 *   128   0.016    0.019      4x4 +19%
 *   160   0.019    0.023      4x4 +21%
 *   192   0.020    0.024      4x4 +20%   <- 最后一个 4x4 赢的点
 *   208   0.036    0.032     shared -15%  <- 第一个 shared 赢的点（紧贴边界）
 *   224   0.043    0.037     shared -16%
 *   240   0.046    0.041     shared -13%
 *   256   0.049    0.042     shared -16%
 * 分界点很干净，且正好卡在 block 数跳变上：step=64 时 ceil(192/64)=3 -> 9 个 block，
 * ceil(208/64)=4 -> 16 个 block。4x4 在 9 block 时只占 1060 十个 SM 的一半都不到，
 * 一进 16 block 反而摊薄；shared 不挑 block 数，到一定尺寸就稳赢。
 * 所以阈值取 224：**224/240/256 三点复打两遍全赢（-13~-16.5%），<=192 四点全输，
 * 208 虽然也赢但紧贴边界，不拿它当阈值。** 详见 GPU_DESIGN.md。 */
#define GPU_SHARED_MIN_N 224
/* 8x8 kernel 的启用阈值：tile 是 128x128，grid 要到 ~100 个 block 才不吃短尾波
 * （1060：10 SM x 2 并行 block x 5 波）。拐点是实测+波尾量化双证据：
 * N=1024 只有 64 block（3.2 波），六轮交替测量 8x8 反而 -5%；
 * N=1280 恰好 100 block（5 整波），四轮全赢 +18%；之后 1536 +11% / 2048 +15% /
 * 3216 +25%。注意：单轮测量会被 GPU 动态升频骗（上轮单测曾记 512 +24%，六轮
 * 交替复测只有 -2%），阈值以多轮中位数为准。 */
#define GPU_8X8_MIN_N 1280

/* ─────────────── 第四跳：设备感知 + 形状感知的 sgemm kernel 选型 ───────────────
 *
 * 病根：老路由把阈值按 N 写死（224 / 1280），而那两个数是** GTX 1060（10 个 SM）**
 * 测出来的。同一套阈值换到 SM 数不同的卡上就全错，三条病：
 *   1. 阈值 1280 是**第三跳（8x8 载入预取，快 22%）之前**的老数据，落后一整跳。
 *      1060 上实测 N∈[448,1280) 就该走 8x8，老路由还在走 shared，慢 22~45%。
 *   2. 阈值只看 N 不看 M：瘦长形（M 很小）时 8x8 的块数被 ceil(M/128) 砍掉，
 *      块数不够铺机器，老路由照样选 8x8（实测 64x1024x1024 该走 shared）。
 *   3. 阈值里**完全没有「这张卡有几个 SM」**：块数不够铺满大卡时没有任何补救，
 *      于是大卡上大片 SM 闲着 —— 这就是「别的卡只有 10~20%」的来源。
 *
 * 方案：选型换成**时间模型**，所有量都是设备相对的：
 *      块数   blocks = ceil(M/tile) * ceil(N/tile)
 *      波数   waves  = ceil(blocks / (SM数 * 每SM常驻block数))
 *      预测   t(k)   = waves * (K * c_k + s_k)
 *      取 t 最小的那个 kernel。
 *   c_k / s_k = 「每 K 单位每 block 的毫秒」与「每 block 固定开销」，
 *   由**本机自标定**解出来（gpu_calibrate：探测时现测 256/512/1024 三个方形尺寸）。
 *   SM 数问驱动（cuDeviceGetAttribute），每 SM 驻留数问驱动
 *   （cuOccupancyMaxActiveBlocksPerMultiprocessor，问不到就按寄存器数估）。
 *   所以换卡不用改代码，路由自己会重算。
 *
 * 标定方法与验收（脚本 _gpuroutefit.py，数据 _gpucal_out.csv）：
 *   相对误差加权最小二乘拟合，在 1060 上 20 个实测形状里选出的 kernel
 *   与实测最优**全部一致**，最大损失 1.0%；老阈值同期最差损失 45%。
 *
 * 已知边界（别把它当万能钥匙）：
 *   · c/s 是按方形、大 K 标的；M 很小或 K 很小时模型偏差会变大。
 *   · 模型只决定「选哪个 kernel」，**不改变「机器能不能被填满」**。
 *     大卡上中等尺寸矩阵的块数天生不够（GPU_DESIGN.md 第四跳有定量分析），
 *     那要靠 split-K 或更小 tile 的新 kernel，路由救不了。
 */
#define GPU_NKERN 3

typedef struct {
    const char *name;
    CUfunction  fn;
    unsigned    tile;      /* tile 边长（grid 步进也是它） */
    int         bpsm;      /* 每 SM 常驻 block 数 */
    double      c_ms;      /* 每 K 单位每 block 的毫秒 */
    double      s_ms;      /* 每 block 的固定开销（毫秒） */
} GpuKern;

/* 1060 实测标定值（GTX 1060 6GB / CC 6.1）。自标定成功时会被本机实测值替换。 */
static GpuKern g_kg[GPU_NKERN] = {
    { "sgemm",        NULL,  64, 3, 0.000233, -0.00968 },
    { "sgemm_shared", NULL,  64, 4, 0.000182, -0.00275 },
    { "sgemm_8x8",    NULL, 128, 2, 0.000243, -0.00539 },
};
/* 静态兜底值：自标定失败时按这张表恢复 */
static const double GPU_C_FALLBACK[GPU_NKERN][2] = {
    { 0.000233, -0.00968 },
    { 0.000182, -0.00275 },
    { 0.000243, -0.00539 },
};

/* 建表 + 问每 SM 能驻留几个 block */
static void gpu_setup_kernels(void)
{
    int i, occ = 0, regs = 0, thr = 16 * 16;

    g_kg[0].fn = g_fn;
    g_kg[1].fn = g_fn_sh;
    g_kg[2].fn = g_fn_8x8;

    for (i = 0; i < GPU_NKERN; i++) {
        if (!g_kg[i].fn) { g_kg[i].bpsm = 1; continue; }
        if (p_cuOccupancyMaxActiveBlocks &&
            p_cuOccupancyMaxActiveBlocks(&occ, g_kg[i].fn, thr, 0) == 0 && occ > 0) {
            g_kg[i].bpsm = occ;      /* 驱动直接答「每 SM 几个 block」，最准 */
            continue;
        }
        /* 兜底：按寄存器数算。每 SM 寄存器文件 65536 是所有 CC>=3.0 的硬事实，
         * 实测与驱动回答一致（8x8 128 寄存器 -> 2，shared 64 -> 4，4x4 71 -> 3）。 */
        occ = 3;
        if (p_cuFuncGetAttribute &&
            p_cuFuncGetAttribute(&regs, 4 /*NUM_REGS*/, g_kg[i].fn) == 0 && regs > 0) {
            occ = 65536 / (regs * thr);
            if (occ < 1) occ = 1;
        }
        if (g_max_threads_sm > 0) {
            int t = g_max_threads_sm / thr;
            if (t > 0 && t < occ) occ = t;
        }
        g_kg[i].bpsm = occ;
    }
}

/* 选 kernel：预测时间最短者胜。返回表内下标；
 * 设备信息不全（g_sms 没问出来）时返回 -1，由调用方退回老阈值。 */
static int gpu_pick_kernel(int M, int N, int K)
{
    int    i, best = -1;
    double bt = 0;

    if (g_sms_route < 1)
        return -1;
    for (i = 0; i < GPU_NKERN; i++) {
        long long blocks, slots, waves;
        double   t;
        int      tile = (int)g_kg[i].tile;
        if (!g_kg[i].fn)
            continue;
        blocks = (long long)((M + tile - 1) / tile) *
                 (long long)((N + tile - 1) / tile);
        slots  = (long long)g_sms_route * (long long)(g_kg[i].bpsm > 0 ? g_kg[i].bpsm : 1);
        waves  = (blocks + slots - 1) / slots;
        if (waves < 1) waves = 1;
        t = (double)waves * ((double)K * g_kg[i].c_ms + g_kg[i].s_ms);
        if (best < 0 || t < bt) { best = i; bt = t; }
    }
    return best;
}

/* 测一个 kernel 在 NxNxN 上的耗时（CUDA event，多发几轮取最小摊掉启动开销）。
 * 口径与标定脚本 _gpucal.c 一致，换卡后标出来的常数才可比。 */
static int gpu_calib_time(int ki, int N, int K, CUdeviceptr dA, CUdeviceptr dB,
                          CUdeviceptr dC, double *out_ms)
{
    CUfunction f = g_kg[ki].fn;
    unsigned   tile = g_kg[ki].tile;
    unsigned   gx, gy;
    int        m = N, n = N, k = K;
    void      *params[] = { &dA, &dB, &dC, &m, &n, &k };
    void      *ev0 = NULL, *ev1 = NULL;
    double     best = 0;
    int        inner, rep, i;

    if (!f || !p_cuEventCreate || !p_cuEventRecord || !p_cuEventSynchronize ||
        !p_cuEventElapsedTime || !p_cuEventDestroy)
        return 0;
    if (p_cuEventCreate(&ev0, 0) != 0)
        return 0;
    if (p_cuEventCreate(&ev1, 0) != 0) { p_cuEventDestroy(ev0); return 0; }

    gx = (unsigned)((N + tile - 1) / tile);
    gy = gx;
    /* inner 取法与标定 harness 一致：连发摊掉每发启动开销 */
    inner = (int)(2000000.0 / (double)((size_t)N * N + 1));
    if (inner < 3) inner = 3;
    if (inner > 200) inner = 200;

    for (rep = 0; rep < 2; rep++) {
        float el = 0;
        if (p_cuLaunchKernel(f, gx, gy, 1, 16, 16, 1, 0, NULL, params, NULL) != 0)
            break;
        if (p_cuCtxSynchronize() != 0)
            break;
        if (p_cuEventRecord(ev0, NULL) != 0) break;
        for (i = 0; i < inner; i++) {
            if (p_cuLaunchKernel(f, gx, gy, 1, 16, 16, 1, 0, NULL, params, NULL) != 0)
                break;
        }
        if (p_cuEventRecord(ev1, NULL) != 0) break;
        if (p_cuEventSynchronize(ev1) != 0) break;
        if (p_cuEventElapsedTime(&el, ev0, ev1) != 0 || el <= 0) break;
        if (rep == 0 || el < best) best = el;   /* 取最小：最接近机器空闲时的真实速度 */
    }
    p_cuEventDestroy(ev0);
    p_cuEventDestroy(ev1);
    if (best <= 0)
        return 0;
    *out_ms = (double)best / (double)inner;
    return 1;
}

/* ─────────────── 开机自标定：在这张卡上现测三个 kernel 的时间常数 ───────────────
 * 模型里的 c/s 是 1060 上标定的，换卡不准（每 SM 算力、共享带宽、寄存器上限
 * 都不同）。这里在探测时现测 256/512/1024 三个方形尺寸，用与标定脚本同样的
 * 相对误差加权最小二乘解出 c/s，替换静态值。
 * **任何一步失败都不许影响探测**：全部兜底成「保留静态值」。 */
static void gpu_calibrate(void)
{
    static const int sizes[3] = { 256, 512, 1024 };
    CUdeviceptr dA = 0, dB = 0, dC = 0;
    float       *h = NULL;
    size_t       bytes = (size_t)1024 * 1024 * sizeof(float);
    int          i, ki;

    if (getenv("PYBOOK_GPU_NOCAL"))
        return;                             /* 调试用：跳过自标定 */
    if (g_sms < 1)
        return;
    if (!p_cuEventCreate || !p_cuEventRecord || !p_cuEventSynchronize ||
        !p_cuEventElapsedTime || !p_cuEventDestroy)
        return;
    if (!g_kg[0].fn && !g_kg[1].fn && !g_kg[2].fn)
        return;

    if (p_cuMemAlloc_v2(&dA, bytes) != 0) return;
    if (p_cuMemAlloc_v2(&dB, bytes) != 0) { p_cuMemFree_v2(dA); return; }
    if (p_cuMemAlloc_v2(&dC, bytes) != 0) {
        p_cuMemFree_v2(dA); p_cuMemFree_v2(dB); return;
    }
    h = (float *)malloc(bytes);
    if (!h) goto done;
    for (i = 0; i < 1024 * 1024; i++) h[i] = 1.0f;   /* 数据不影响耗时，但别留 NaN */
    if (p_cuMemcpyHtoD_v2(dA, h, bytes) != 0) goto done;
    if (p_cuMemcpyHtoD_v2(dB, h, bytes) != 0) goto done;

    for (ki = 0; ki < GPU_NKERN; ki++) {
        double a00 = 0, a01 = 0, a11 = 0, b0 = 0, b1 = 0;
        double det, c, s;
        int    got = 0, bad = 0;
        if (!g_kg[ki].fn)
            continue;
        for (i = 0; i < 3; i++) {
            double   ms, w, x0, x1;
            long long waves, slots, blocks;
            int      tile = (int)g_kg[ki].tile;
            if (!gpu_calib_time(ki, sizes[i], sizes[i], dA, dB, dC, &ms)) {
                bad = 1; break;
            }
            blocks = (long long)((sizes[i] + tile - 1) / tile) *
                     (long long)((sizes[i] + tile - 1) / tile);
            slots  = (long long)g_sms * (long long)(g_kg[ki].bpsm > 0 ? g_kg[ki].bpsm : 1);
            waves  = (blocks + slots - 1) / slots;
            if (waves < 1) waves = 1;
            w  = 1.0 / (ms * ms);              /* 相对误差加权 */
            x0 = (double)waves * sizes[i];
            x1 = (double)waves;
            a00 += w * x0 * x0; a01 += w * x0 * x1; a11 += w * x1 * x1;
            b0  += w * x0 * ms;  b1  += w * x1 * ms;
            got++;
        }
        if (bad || got < 2)
            continue;
        det = a00 * a11 - a01 * a01;
        if (det == 0)
            continue;
        c = (b0 * a11 - b1 * a01) / det;
        s = (a00 * b1 - a01 * b0) / det;
        /* 合理性闸门：离谱就丢弃，保留静态值（宁可不准也不能选错） */
        if (c > 0 && c < GPU_C_FALLBACK[ki][0] * 5.0 &&
            c > GPU_C_FALLBACK[ki][0] * 0.2 && s > -0.05 && s < 0.05) {
            g_kg[ki].c_ms = c;
            g_kg[ki].s_ms = s;
            g_calibrated = 1;
            if (getenv("PYBOOK_GPU_VERBOSE"))
                printf("[gpu] 标定 %-13s c=%.6f ms/K  s=%.5f ms  （静态兜底 c=%.6f s=%.5f）\n",
                       g_kg[ki].name, c, s,
                       GPU_C_FALLBACK[ki][0], GPU_C_FALLBACK[ki][1]);
        } else if (getenv("PYBOOK_GPU_VERBOSE")) {
            printf("[gpu] 标定 %-13s 被闸门拦下（c=%.6f s=%.5f），保留静态值\n",
                   g_kg[ki].name, c, s);
        }
    }
done:
    free(h);
    p_cuMemFree_v2(dA);
    p_cuMemFree_v2(dB);
    p_cuMemFree_v2(dC);
}

/* 路由计划（只读，供测试与诊断）：给 M/N/K，问会选哪个 kernel。
 * kernel_id: 0=sgemm 1=sgemm_shared 2=sgemm_8x8，-1 = 设备信息不全、退回老阈值。
 * blocks/waves 是选中那个 kernel 的块数与波数。 */
int gpu_route_plan(int M, int N, int K, int *kernel_id, int *blocks, int *waves)
{
    int ki = gpu_pick_kernel(M, N, K);
    if (kernel_id) *kernel_id = ki;
    if (blocks)   *blocks = 0;
    if (waves)    *waves = 0;
    if (ki < 0)
        return 0;
    if (blocks) {
        int tile = (int)g_kg[ki].tile;
        *blocks = ((M + tile - 1) / tile) * ((N + tile - 1) / tile);
    }
    if (waves) {
        int tile = (int)g_kg[ki].tile;
        long long b = (long long)((M + tile - 1) / tile) * ((N + tile - 1) / tile);
        long long slots = (long long)g_sms_route *
                          (long long)(g_kg[ki].bpsm > 0 ? g_kg[ki].bpsm : 1);
        long long w = (b + slots - 1) / slots;
        *waves = (int)(w < 1 ? 1 : w);
    }
    return 1;
}

/* ─────────────── 主机侧转换与 PCIe 搬运重叠 ───────────────
 *
 * 为什么要分段：主机侧 double->float 转换是访存受限的（1060 实测 4M 个元素
 * 约 3~5 ms，memcpy 同流量只要 3.4 ms），而 PCIe 搬运又要再花一份时间。
 * 串行做就是 两份时间相加；页锁定内存上的异步拷贝发完就返回，于是把数据
 * 切成段，「转第 i 段」和「搬第 i-1 段」能重叠，端到端约等于 max(两者)。
 *
 * 为什么不用多线程：实测这台机器 4 线程只比单线程快 1.25 倍（内存带宽就
 * 20 GB/s），线程开销反而吃掉了收益 —— 分段重叠更划算，也不引入线程池。
 *
 * 分段粒度：1 MB（262144 个 float）起步，向上取整到 4 的倍数（16 字节对齐）。
 */
#define GPU_CAST_CHUNK_MIN (1u << 18)

/* 把 src 的 n 个 double 转成 float 写进页锁定暂存区 stage，同时搬到显存 dst。
 * 返回 1 成功；0 失败（原因见 gpu_last_error）。 */
static int gpu_h2d_cast(const double *src, CUdeviceptr dst, size_t n, float *stage)
{
    size_t   chunk, done;
    CUresult r;

    if (n == 0)
        return 1;
    chunk = (n + 7) / 8;
    if (chunk < GPU_CAST_CHUNK_MIN)
        chunk = GPU_CAST_CHUNK_MIN;
    chunk = (chunk + 3) & ~(size_t)3;

    for (done = 0; done < n; done += chunk) {
        size_t cnt = (done + chunk <= n) ? chunk : (n - done);
        size_t i;
        for (i = 0; i < cnt; i++)
            stage[done + i] = (float)src[done + i];
        if (p_cuMemcpyHtoDAsync_v2)
            r = p_cuMemcpyHtoDAsync_v2(dst + (CUdeviceptr)(done * sizeof(float)),
                                       (void *)(stage + done),
                                       cnt * sizeof(float), NULL);
        else
            r = p_cuMemcpyHtoD_v2(dst + (CUdeviceptr)(done * sizeof(float)),
                                  (void *)(stage + done), cnt * sizeof(float));
        if (r != 0) {
            gpu_fail("上卡失败：%s", cu_err(r));
            return 0;
        }
    }
    return 1;
}

/* 从显存取回 n 个 float 到页锁定暂存区 stage，同时转成 double 写进 dst。
 * 异步取回第 i 段的同时处理第 i-1 段；最后一段等完再转。
 * 用两个 event 乒乓（每段建销一个 event 太贵，event 创建本身要几十微秒）。 */
static int gpu_d2h_cast(CUdeviceptr src, const float *stage, double *dst, size_t n)
{
    size_t   chunk, done;
    CUresult r;
    void    *ev0 = NULL, *ev1 = NULL;
    int      use_async = 0;
    int      idx;

    if (n == 0)
        return 1;
    chunk = (n + 7) / 8;
    if (chunk < GPU_CAST_CHUNK_MIN)
        chunk = GPU_CAST_CHUNK_MIN;
    chunk = (chunk + 3) & ~(size_t)3;

    if (p_cuMemcpyDtoHAsync_v2 && p_cuEventCreate && p_cuEventRecord &&
        p_cuEventSynchronize && p_cuEventDestroy) {
        if (p_cuEventCreate(&ev0, 0) == 0 && p_cuEventCreate(&ev1, 0) == 0)
            use_async = 1;
        else {
            if (ev0) { p_cuEventDestroy(ev0); ev0 = NULL; }
            if (ev1) { p_cuEventDestroy(ev1); ev1 = NULL; }
        }
    }

    for (done = 0, idx = 0; done < n; done += chunk, idx++) {
        size_t cnt = (done + chunk <= n) ? chunk : (n - done);
        size_t i;
        if (use_async) {
            void *ev_now = (idx & 1) ? ev1 : ev0;     /* 乒乓 */
            void *ev_old = (idx & 1) ? ev0 : ev1;
            int   have_old = (done > 0);
            r = p_cuMemcpyDtoHAsync_v2((void *)(stage + done),
                                       src + (CUdeviceptr)(done * sizeof(float)),
                                       cnt * sizeof(float), NULL);
            if (r != 0) { gpu_fail("下卡失败：%s", cu_err(r)); goto fail; }
            if (p_cuEventRecord(ev_now, NULL) != 0) {
                gpu_fail("下卡事件记录失败");
                goto fail;
            }
            if (have_old) {
                size_t prev = done - chunk;
                size_t pcnt = (prev + chunk <= n) ? chunk : (n - prev);
                if (p_cuEventSynchronize(ev_old) != 0) {
                    gpu_fail("下卡同步失败");
                    goto fail;
                }
                for (i = 0; i < pcnt; i++)
                    dst[prev + i] = (double)stage[prev + i];
            }
        } else {
            /* 没有异步入口：退回同步取回（不重叠，但结果一样） */
            r = p_cuMemcpyDtoH_v2((void *)(stage + done),
                                  src + (CUdeviceptr)(done * sizeof(float)),
                                  cnt * sizeof(float));
            if (r != 0) { gpu_fail("下卡失败：%s", cu_err(r)); goto fail; }
            for (i = 0; i < cnt; i++)
                dst[done + i] = (double)stage[done + i];
        }
    }
    if (use_async) {
        /* 最后一段：等它到齐再转（最后一段用的是 idx 为偶数还是奇数决定的事件） */
        size_t rest = n % chunk;
        size_t prev = rest ? (n - rest) : (n - chunk);
        size_t pcnt = n - prev;
        size_t i;
        int    last_idx = (int)((n + chunk - 1) / chunk) - 1;
        void  *ev_last = (last_idx & 1) ? ev1 : ev0;
        if (p_cuEventSynchronize(ev_last) != 0) {
            gpu_fail("下卡同步失败");
            goto fail;
        }
        for (i = 0; i < pcnt; i++)
            dst[prev + i] = (double)stage[prev + i];
    }
    if (ev0) p_cuEventDestroy(ev0);
    if (ev1) p_cuEventDestroy(ev1);
    return 1;
fail:
    if (ev0) p_cuEventDestroy(ev0);
    if (ev1) p_cuEventDestroy(ev1);
    return 0;
}

int gpu_sgemm_f32(const double *A, const double *B, double *C,
                  int M, int N, int K)
{
    size_t   ka = (size_t)M * (size_t)K;
    size_t   kb = (size_t)K * (size_t)N;
    size_t   kc = (size_t)M * (size_t)N;
    size_t   need;
    CUresult r;
    int      m, n, k;
    int      ok = 0;

    g_err[0] = '\0';
    if (!gpu_probe())
        return gpu_fail("GPU 没探测成功：%s", g_why);
    if (M < 1 || N < 4 || K < 4 || (N & 3) || (K & 3))
        return gpu_fail("尺寸 %dx%dx%d：N/K 必须是 4 的倍数（float4 要求 16 字节对齐）",
                        M, N, K);

    need = ka * sizeof(float);
    if (kb * sizeof(float) > need) need = kb * sizeof(float);
    if (kc * sizeof(float) > need) need = kc * sizeof(float);

    AcquireSRWLockExclusive(&g_lock);
    if (!ensure_bufs(need))        goto out;
    if (!ensure_host_bufs(need))   goto out;

    /* 上卡：分段把 double 转成 float 写进页锁定暂存区，同时异步搬到显存。
     * 分段是为了让「第 i 段的转换」和「第 i-1 段的 DMA」在时间上重叠 ——
     * 页锁定内存上的异步拷贝发完就返回，DMA 在后台跑。
     * 不分段的话就是 转换(9ms) + 搬运(3ms) 串行，分段后约等于 max(两者)。 */
    if (!gpu_h2d_cast(A, g_dA, ka, (float *)g_hA)) goto out;
    if (!gpu_h2d_cast(B, g_dB, kb, (float *)g_hB)) goto out;

    m = M; n = N; k = K;
    {
        void    *params[] = { &g_dA, &g_dB, &g_dC, &m, &n, &k };
        /* 第四跳：路由改成「预测时间最短者胜」，量纲是设备相对的。
         * 块数 = ceil(M/tile)*ceil(N/tile)（M 和 N 都进，不再只看 N），
         * 波数 = ceil(块数 / (SM数 * 每SM常驻block数))，
         * 时间 = 波数 * (K * c_k + s_k)，c/s 是本卡自标定出来的。
         * 设备信息不全（g_sms 没问出来）时才退回下面那两个老阈值。 */
        CUfunction f = g_fn;
        unsigned    step = 64;
        int         ki = gpu_pick_kernel(M, N, K);
        if (ki >= 0) {
            f    = g_kg[ki].fn;
            step = g_kg[ki].tile;
        } else if (N >= GPU_8X8_MIN_N && g_fn_8x8) {
            f = g_fn_8x8; step = 128;
        } else if (N >= GPU_SHARED_MIN_N && g_fn_sh) {
            f = g_fn_sh;  step = 64;
        }
        unsigned gx = (unsigned)((N + step - 1) / step);
        unsigned gy = (unsigned)((M + step - 1) / step);
        r = p_cuCtxSetCurrent(g_ctx);
        if (r != 0) { gpu_fail("切不回 CUDA context：%s", cu_err(r)); goto out; }
        r = p_cuLaunchKernel(f, gx, gy, 1, 16, 16, 1, 0, NULL, params, NULL);
        if (r != 0) { gpu_fail("kernel 启动失败：%s", cu_err(r)); goto out; }
        r = p_cuCtxSynchronize();
        if (r != 0) { gpu_fail("kernel 执行出错：%s", cu_err(r)); goto out; }
    }
    /* 下卡：同样分段。异步取回第 i 段时，同步第 i-1 段并把它转成 double 写回，
     * 于是「取回」和「转换」也重叠了。 */
    if (!gpu_d2h_cast(g_dC, (const float *)g_hC, C, kc)) goto out;
    ok = 1;
out:
    if (!ok && !g_err[0])
        snprintf(g_err, sizeof g_err, "未知原因");
    ReleaseSRWLockExclusive(&g_lock);
    return ok;
}

/* 池化上卡：x 摊平 (H, W)、out 写回 (OH, OW)。is_avg 选 avgpool/maxpool 内核。
 * 三缓冲池与 sgemm/conv 共用（need 取两者最大，持锁全程）。 */
int gpu_pool_f32(const double *x, double *out, int xN, int outN,
                 int W, int OH, int OW, int KH, int KW, int S, int is_avg)
{
    size_t   kx = (size_t)xN;
    size_t   ko = (size_t)outN;
    size_t   need;
    CUresult r;
    int      ok = 0;

    g_err[0] = '\0';
    if (!gpu_probe())
        return gpu_fail("GPU 没探测成功：%s", g_why);
    if (!g_fn_maxpool || !g_fn_avgpool)
        return gpu_fail("池化内核没编译出来（这单该降级 CPU，不该走到这）");

    need = kx * sizeof(float);
    if (ko * sizeof(float) > need) need = ko * sizeof(float);

    AcquireSRWLockExclusive(&g_lock);
    if (!ensure_bufs(need))        goto out;
    if (!ensure_host_bufs(need))   goto out;

    /* x 上卡：分段转换 + 异步搬运（与 sgemm 同款） */
    if (!gpu_h2d_cast(x, g_dA, kx, (float *)g_hA)) goto out;

    {
        float   inv = 1.0f / (float)(KH * KW);   /* avgpool 用 */
        void *params[] = { &g_dA, &g_dC, &W, &OH, &OW, &KH, &KW, &S, &inv };
        unsigned gx = (unsigned)((OW + 15) / 16);
        unsigned gy = (unsigned)((OH + 15) / 16);
        CUfunction f = is_avg ? g_fn_avgpool : g_fn_maxpool;
        r = p_cuCtxSetCurrent(g_ctx);
        if (r != 0) { gpu_fail("切不回 CUDA context：%s", cu_err(r)); goto out; }
        r = p_cuLaunchKernel(f, gx, gy, 1, 16, 16, 1, 0, NULL, params, NULL);
        if (r != 0) { gpu_fail("pool kernel 启动失败：%s", cu_err(r)); goto out; }
        r = p_cuCtxSynchronize();
        if (r != 0) { gpu_fail("pool kernel 执行出错：%s", cu_err(r)); goto out; }
    }
    /* out 取回：分段搬运 + 转 double（同样重叠） */
    if (!gpu_d2h_cast(g_dC, (const float *)g_hC, out, ko)) goto out;
    ok = 1;
out:
    if (!ok && !g_err[0])
        snprintf(g_err, sizeof g_err, "未知原因");
    ReleaseSRWLockExclusive(&g_lock);
    return ok;
}

/* 上一次 conv2d 内核耗时（毫秒）；没量过（比如没开 PYBOOK_GPU_TRACE）是 -1 */
double gpu_last_kernel_ms(void)
{
    return g_last_kernel_ms;
}

/* conv2d 上卡：x/k 是 double 缓冲（F32 张量，值可被 float32 精确表示）。
 * 布局 x=(N,I,H,W) k=(O,I,KH,KW)；权重在宿主侧转置成 (I*KH*KW, OPAD)，oc 在最内维
 * ——核里要用 128 位向量载入权重，所以 OPAD 取 16 的倍数（顺带保证 16 字节对齐）。
 * out 写回 (N,O,OH,OW)。三缓冲池与 sgemm/conv 共用（need 取三者最大，持锁全程）。 */
int gpu_conv2d_f32(const double *x, const double *k, double *out,
                   int H, int W, int I, int O, int KH, int KW,
                   int OH, int OW, int S, int N)
{
    int      opad = (O + 15) / 16 * 16;               /* 权重行宽：16 的倍数，128 位载入要 16 字节对齐 */
    size_t   nx = (size_t)N * I * H * W;
    size_t   nk = (size_t)I * KH * KW * (size_t)opad;  /* 转置后的权重 */
    size_t   ko = (size_t)N * O * OH * OW;
    size_t   pad = (size_t)(32 * S * W + 32 * S + 64);/* 越界读兜底：核里不加谓词，靠这段 0 填 */
    size_t   need;
    CUresult r;
    int      ok = 0;
    CUfunction fn_conv = g_fn_conv;
    int      gcount = 1;                  /* 共享内存版：每组几个 ic */
    int      trace = getenv("PYBOOK_GPU_TRACE") != NULL;

    g_err[0] = '\0';
    if (!gpu_probe())
        return gpu_fail("GPU 没探测成功：%s", g_why);
    if (!g_fn_conv)
        return gpu_fail("conv2d 内核没编译出来（这单该降级 CPU，不该走到这）");

    need = (nx + pad) * sizeof(float);
    if (nk * sizeof(float) > need) need = nk * sizeof(float);
    if (ko * sizeof(float) > need) need = ko * sizeof(float);

    AcquireSRWLockExclusive(&g_lock);
    if (!ensure_bufs(need))        goto out;
    if (!ensure_host_bufs(need))   goto out;

    /* x 上卡：分段转换 + 异步搬运（与 sgemm 同款，让 double->float 和 PCIe 重叠） */
    if (!gpu_h2d_cast(x, g_dA, nx, (float *)g_hA)) goto out;
    /* 越界读兜底区：核里一块覆盖 32x32 个输出位置，最后一张图的读会越过图像末尾。
     * 这段只要「显存够大」就不会越界读（读到什么都不影响结果：那些 lane 不写回），
     * 但仍补一份 0，跟内核对拍台的行为保持一致。 */
    {
        float *px = (float *)g_hA;
        size_t i;
        for (i = 0; i < pad; i++) px[nx + i] = 0.0f;
        r = p_cuMemcpyHtoD_v2(g_dA + (CUdeviceptr)(nx * sizeof(float)),
                              (void *)(px + nx), pad * sizeof(float));
        if (r != 0) { gpu_fail("x 兜底区上卡失败：%s", cu_err(r)); goto out; }
    }
    /* 权重：宿主侧转置成 [kk][oc]（oc 在内维），核里才能用 128 位向量载入 */
    {
        float *pk = (float *)g_hB;
        size_t i, oc, kk;
        for (i = 0; i < nk; i++) pk[i] = 0.0f;
        for (oc = 0; oc < (size_t)O; oc++)
            for (kk = 0; kk < (size_t)I * KH * KW; kk++)
                pk[kk * (size_t)opad + oc] =
                    (float)k[oc * (size_t)I * (size_t)KH * (size_t)KW + kk];
        r = p_cuMemcpyHtoD_v2(g_dB, (void *)g_hB, nk * sizeof(float));
        if (r != 0) { gpu_fail("k 上卡失败：%s", cu_err(r)); goto out; }
    }
    /* 选内核：conv2d_shr（权重分组搬进共享内存 + 换列映射）快 28.9%
     * （实测 0.270 -> 0.192 ms，占 FP32 峰值 16.9% -> 23.6%）。
     * 共享内存一次放得下 384 个 kk（24 KB），按 ic 分组搬：
     * 每组 G = 384/(KH*KW) 个 ic，整组一次 staging + 两次 bar.sync，
     * 组内共享读指针连续推进（kk 在组内连续）。**所以任意 I 都能用**。
     * 只有 KH*KW > 384（核超大）才走老内核 conv2d。
     * G 由宿主算好当参数传进去（内核里不做整数除法）。 */
    fn_conv = g_fn_conv;
    gcount = 384 / (KH * KW);
    if (gcount < 1) gcount = 1;
    if (g_fn_conv_shr && (long)KH * (long)KW <= 384)
        fn_conv = g_fn_conv_shr;
    {
        /* 两个内核的参数个数不同：老内核 13 个，共享内存版多一个 p_G。
           cuLaunchKernel 按内核声明的参数个数取，所以要给对应的数组。 */
        void *params13[] = { &g_dA, &g_dB, &g_dC, &I, &H, &W, &O,
                            &KH, &KW, &S, &OH, &OW, &opad };
        void *params14[] = { &g_dA, &g_dB, &g_dC, &I, &H, &W, &O,
                            &KH, &KW, &S, &OH, &OW, &opad, &gcount };
        void **params = (fn_conv == g_fn_conv_shr) ? params14 : params13;
        unsigned gx = (unsigned)((OW + 31) / 32);
        unsigned gy = (unsigned)((OH + 31) / 32);
        unsigned gz = (unsigned)(N * ((O + 15) / 16));
        r = p_cuCtxSetCurrent(g_ctx);
        if (r != 0) { gpu_fail("切不回 CUDA context：%s", cu_err(r)); goto out; }
        /* 只在追踪模式下量内核本身的时间：端到端里混着转换和搬运，
           不单独量就没法分清「内核慢」还是「搬运慢」。缺 event 入口就跳过。
           注意 ev0 必须记在 kernel 启动「之前」、ev1 记在「之后」——
           两个都记在之后就只能量到两个 record 之间的空档（那不是内核时间）。 */
        {
            void *ev0 = NULL, *ev1 = NULL;
            int   use_ev = trace && p_cuEventCreate && p_cuEventRecord &&
                           p_cuEventSynchronize && p_cuEventElapsedTime &&
                           p_cuEventDestroy;
            if (use_ev) {
                if (p_cuEventCreate(&ev0, 0) != 0 || p_cuEventCreate(&ev1, 0) != 0) {
                    if (ev0) { p_cuEventDestroy(ev0); ev0 = NULL; }
                    if (ev1) { p_cuEventDestroy(ev1); ev1 = NULL; }
                    use_ev = 0;
                }
            }
            if (use_ev)
                p_cuEventRecord(ev0, NULL);
            r = p_cuLaunchKernel(fn_conv, gx, gy, gz, 16, 16, 1,
                                 0, NULL, params, NULL);
            if (r != 0) { gpu_fail("conv kernel 启动失败：%s", cu_err(r)); goto out; }
            if (use_ev) {
                float el = 0;
                p_cuEventRecord(ev1, NULL);
                p_cuEventSynchronize(ev1);
                if (p_cuEventElapsedTime(&el, ev0, ev1) == 0) {
                    g_last_kernel_ms = (double)el;
                    fprintf(stderr,
                            "[gpu] conv2d kernel %.3f ms  网格 %ux%ux%u  %s\n",
                            (double)el, gx, gy, gz,
                            fn_conv == g_fn_conv ? "conv2d" : "conv2d_shr");
                }
                p_cuEventDestroy(ev0);
                p_cuEventDestroy(ev1);
            }
        }
        r = p_cuCtxSynchronize();
        if (r != 0) { gpu_fail("conv kernel 执行出错：%s", cu_err(r)); goto out; }
    }
    /* out 取回：分段搬运 + 转 double（同样重叠） */
    if (!gpu_d2h_cast(g_dC, (const float *)g_hC, out, ko)) goto out;
    ok = 1;
out:
    if (!ok && !g_err[0])
        snprintf(g_err, sizeof g_err, "未知原因");
    ReleaseSRWLockExclusive(&g_lock);
    return ok;
}
