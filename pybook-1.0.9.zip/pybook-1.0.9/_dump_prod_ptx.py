# _dump_prod_ptx.py —— 从生产 pybook_gpu.c 里把 PTX_BODY_CONV2D / PTX_BODY_POOL 抽出来，
# 拼成一份带 .version/.target 的完整 PTX，交给内核台单独验。
# 用途：把「内核错」和「宿主侧错」分开——同一份 PTX，内核台过了就是宿主侧的问题。
import io, re, sys

src = io.open("pybook_gpu.c", encoding="utf-8", newline="").read()


def body(name):
    m = re.search(r"static const char \*%s =\s*(.*?);\r?\n" % name, src, re.S)
    if not m:
        raise SystemExit("找不到 %s" % name)
    chunk = m.group(1)
    lits = re.findall(r'"((?:[^"\\]|\\.)*)"', chunk)
    out = []
    for s in lits:
        out.append(s.replace("\\n", "\n").replace('\\"', '"').replace("\\\\", "\\"))
    return "".join(out)


conv = body("PTX_BODY_CONV2D")
pool = body("PTX_BODY_POOL")

# 内核台（_convk.exe）靠头注释读真实分块；生产 PTX 里没有这行注释，
# 台子会退回默认 TO=8 → 网格/OPAD 算错 → 越界或「部分形状错」。
# 这里按生产配置补上（TO=16 通道/线程，TSY=TSX=2，block 16x16 → 一块覆盖 32 oh x 32 ow）。
TILE = "// block = 16 x 16 = 256 threads; one block covers 16 oc x 32 oh x 32 ow.\n"

vers = re.findall(r'"([0-9]+\.[0-9]+)"', re.search(
    r"static const char \*PTX_VERSIONS\[\] = \{(.*?)\};", src, re.S).group(1))
ver = vers[0] if vers else "8.7"

txt = ".version %s\n.target sm_61\n.address_size 64\n\n%s\n%s\n%s" % (ver, TILE, conv, pool)
io.open("build_tmp/probe/_prod_combined.ptx", "w", encoding="utf-8", newline="\n").write(txt)
print("抽取完成：conv %d 字节 / pool %d 字节 / version %s / 合计 %d 字节"
      % (len(conv), len(pool), ver, len(txt)))
