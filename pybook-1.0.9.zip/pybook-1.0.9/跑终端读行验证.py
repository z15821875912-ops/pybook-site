"""跑「终端读行验证.pybk」：把样例输入用管道喂给 stdin。

为什么要有这个运行器：
  1) PowerShell 5.1 **不支持** `<` 输入重定向；
  2) `cmd /c "python pybk_main.py 终端读行验证.pybk < 输入.txt"` 会按 codepage 处理
     命令行里的中文文件名，容易被弄坏；
  所以直接用 subprocess 把字节灌进 stdin，绕开编码问题。

被验的路径：stdin 不是控制台 → `te.读行` 走**管道分支**（读文件）。
控制台分支（真人在键盘上敲）没法用文件喂，那部分靠 C 层探针验过：
GetNumberOfConsoleInputEvents 空缓冲返回 0（这就是「不阻塞」的闸）、
ReadConsoleInput 在空缓冲上会阻塞（所以必须先查事件数）、
退格 / 回车 / UTF-16 中文 / 忽略 keyup 的解码逻辑逐条单测过。

跑法：python 跑终端读行验证.py
"""
import os
import subprocess
import sys
import tempfile

ROOT = os.path.dirname(os.path.abspath(__file__))
SCRIPT = '终端读行验证.pybk'

# 样例输入故意覆盖三个坑：
#   1) 第二行是 CRLF（\r\n）→ 读出来的行末尾不能多一个不可见字符；
#   2) 最后一行**没有换行符** → 也必须读得出来（不能永远等 \n）；
#   3) 前面几行是中文 → UTF-8 解码要正确。
SAMPLE = '第一行\n第二行有回车\r\n第三行\n最后一行没有换行符'


def main():
    if not os.path.isfile(os.path.join(ROOT, SCRIPT)):
        print('找不到 %s（要在仓库根目录跑）' % SCRIPT)
        return 2

    env = dict(os.environ)
    env['PYTHONUTF8'] = '1'
    env['PYTHONIOENCODING'] = 'utf-8'

    with tempfile.NamedTemporaryFile(suffix='.txt', delete=False) as tf:
        tf.write(SAMPLE.encode('utf-8'))
        tmp = tf.name
    try:
        p = subprocess.run([sys.executable, 'pybk_main.py', SCRIPT],
                           cwd=ROOT, env=env, input=SAMPLE.encode('utf-8'),
                           stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    finally:
        try:
            os.unlink(tmp)
        except OSError:
            pass
    out = p.stdout.decode('utf-8', 'replace')
    print(out)
    print('--- 退出码 = %d' % p.returncode)
    return p.returncode


if __name__ == '__main__':
    sys.exit(main())
