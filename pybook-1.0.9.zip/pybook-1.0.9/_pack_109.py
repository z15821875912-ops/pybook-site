# -*- coding: utf-8 -*-
"""打 PYbook 1.0.9 发布包。
本轮把 1.0.8 之后的全部成果（张量一等类型 / 知命 mode7 进化 BCD / 中英 API 别名 /
正则 re / GPU sgemm / 虚拟机加速+编译期拒绝+三元列表推导 / 报错三段式 / 大项目管理 /
软类型+测试框架 / errorstopped / VM JIT）打成一个厚版。
相较 1.0.8 模板，新增跳过 13G 的 _扫地待清_2026-10-24 与 objtest，
MUST 增加 re/gpu/sym/la 运行时，checks 增加 1.0.9 各特性字节串锚点。
"""
import os
import sys
import zipfile
import fnmatch

SRC = r'C:\Users\zhuli\Desktop\pybook'
DST = r'C:\Users\zhuli\Desktop\pybook官网\pybook-1.0.9.zip'
TOP = 'pybook-1.0.9'

# 精确跳过的目录
SKIP_DIRS = {'.git', '__pycache__', 'rt_cache', 'node_modules',
             '.trae-html-share-packages', '发布打包_102',
             '_stdlib_v2', 'build_tmp',
             'exe_cache',                 # C 后端编译缓存（.o + 一堆 .exe），85MB
             '基准', '_rel_test', 'build', 'games',
             '_扫地待清_2026-10-24',      # 13G 扫地暂存，绝不能进包
             'objtest'}                   # 29M 测试产物
# 模式跳过的目录（截图 / 备份 之类，命名带前缀）
SKIP_DIR_PATTERNS = ['shots*', '_backup*', '_session_backup', '_team', '_归档', '共享历史', '_扫地*']

SKIP_FILES = [
    'app_*.exe',
    '_*.exe',               # 探针产物：_uishot.exe / _shot.exe / _bench_*_c.exe
    '_run_ui_demo',
    '_run_ui_sm',
    'pybook-*.zip',
    'out_*.c',
    'out_*.exe',
    '*.o',
    '*.bin',                # cifar/mnist 数据集等，不该进发布包
    '*.tar', '*.tar.gz', '*.gz',
    'cifar*', 'mnist*',
    '_glsl_smoke_report.txt',
    '_ortho_smoke_report.txt',
    '.DS_Store',
    'Thumbs.db',
    'E3旋律.wav',
    'ItBoTime_旋律.wav',
    'ItBoTime_贝斯.wav',
]


def skip_dir(name):
    if name in SKIP_DIRS:
        return True
    return any(fnmatch.fnmatch(name, p) for p in SKIP_DIR_PATTERNS)


def skip(name):
    return any(fnmatch.fnmatch(name, p) for p in SKIP_FILES)


kept = skipped_n = 0
skipped_bytes = 0

if os.path.exists(DST):
    os.remove(DST)

with zipfile.ZipFile(DST, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for root, dirs, files in os.walk(SRC):
        dirs[:] = [d for d in dirs if not skip_dir(d)]
        for f in files:
            full = os.path.join(root, f)
            rel = os.path.relpath(full, SRC).replace('\\', '/')
            if skip(f):
                skipped_n += 1
                try:
                    skipped_bytes += os.path.getsize(full)
                except OSError:
                    pass
                continue
            z.write(full, TOP + '/' + rel)
            kept += 1

mb = os.path.getsize(DST) / 1024 / 1024
print('打进包的文件   : %d' % kept)
print('剔除的文件     : %d（%.1f MB）' % (skipped_n, skipped_bytes / 1024 / 1024))
print('pybook-1.0.9.zip: %.1f MB' % mb)

if mb > 95:
    sys.stderr.write('\n** 超过 95MB，GitHub push 会失败！需要再剔除东西。**\n')
    sys.exit(1)

# ---------- 验收：关键文件必须在，且本版新东西真在包里 ----------
MUST = [
    'pybk_front.py', 'pybk_code.py', 'pybk_bc.py', 'pybk_main.py', 'pybk_build.py',
    'pybook_rt.c', 'pybook_lib.h', 'pybook_json.c', 'pybook_plot.c',
    'pybook_ui.c', 'pybook_tb.c', 'pybook_hw3d.c',
    'pybook_re.c', 'pybook_re_engine.h',        # 1.0.9 正则
    'pybook_gpu.c', 'pybook_sym.c', 'pybook_la.c',  # 1.0.9 GPU / 符号 / 线性代数
    'CHANGELOG.md', 'PYBOOK_AI.md', 'PYbookIDE.exe',
    'SDL2.dll', 'ucrt64/include/SDL2/SDL.h',
    '3D演示.pybk', '示例_GUI表单.pybk',
]
z = zipfile.ZipFile(DST)
names = set(z.namelist())
missing = [m for m in MUST if (TOP + '/' + m) not in names]
print('\n关键文件检查：', '全在 ✓' if not missing else '**缺 %s**' % missing)

checks = [
    # —— 1.0.9 新特性 ——
    ('pybook_re.c', b'rt_lib_re_match', '正则 C 实现 rt_lib_re_match'),
    ('pybk_front.py', "'re.匹配'", '正则前端注册 re.匹配'),
    ('pybk_main.py', '--determinism-check', '知命 确定性检查 CLI'),
    ('pybook_rt.c', b'rt_phase_end', '知命 帧边界对齐 rt_phase_end'),
    ('pybook_rt.c', b'rt_smoke_gc_stats', '知命 GC 可观测 rt_smoke_gc_stats'),
    ('pybk_front.py', 'LIB_ALIASES', '中英 API 别名 LIB_ALIASES'),
    ('pybook_gpu.c', b'conv2d_shr', 'GPU conv2d_shr 内核'),
    ('CHANGELOG.md', '1.0.9', 'CHANGELOG 1.0.9'),
    # —— 1.0.8 新特性（仍有效）——
    ('pybk_front.py', "'图.导数': 5", '图表库接sym 前端注册 图.导数'),
    ('pybook_plot.c', b'rt_plot_deriv', 'C 实现 rt_plot_deriv'),
    ('pybook_tb.c', b'rt_tb_dot', 'tb 矩阵乘 rt_tb_dot（张量底图）'),
    # —— 1.0.7 新特性（仍有效）——
    ('pybook_rt.c', b'rt_tensor_slice', '张量切片 rt_tensor_slice'),
    ('pybook_rt.c', b'rt_tensor_set', '张量赋值 rt_tensor_set'),
    ('_vm_lib_calls.inc', b'rt_tensor_slice', 'VM 注册 rt_tensor_slice'),
    ('pybk_front.py', 'parse_macro', '前端宏解析 parse_macro'),
    ('pybk_front.py', 'class ClassDef', '类系统 ClassDef'),
    # —— 1.0.5 既有能力（仍有效）——
    ('pybook_ui.c', b'rt_ui_begin', 'GUI 引擎 rt_ui_begin'),
    ('pybk_front.py', "'ui.slider': 3", '前端注册 ui.slider'),
    ('pybook_rt.c', b'game_take_text', '中文输入法文本收集'),
    # —— 版本与台账 ——
    ('PYBOOK_AI.md', 'Memoryment', 'PYBOOK_AI 含内存管理 Memoryment 章节'),
]
bad = []
for path, needle, label in checks:
    data = z.read(TOP + '/' + path)
    nd = needle.encode('utf-8') if isinstance(needle, str) else needle
    if nd not in data:
        bad.append(label)
print('包内新特性检查：', '全部命中 ✓' if not bad else '**没命中: %s**' % bad)

# 确认没把 gcc/mingw 编译器打进去；运行期 DLL 应当进包。
RUNTIME_DLLS = ('libgcc_s_seh-1.dll', 'libwinpthread-1.dll', 'libstdc++-6.dll')
gh = [n for n in names
      if ('gcc' in n.lower() or 'mingw' in n.lower())
      and not n.endswith(RUNTIME_DLLS)]
print('包内 gcc/mingw 编译器命中数：%d %s' % (len(gh), '（符合预期：不含编译器）' if not gh else gh[:5]))

print('\n结论：', '打包成功' if (not missing and not bad and mb <= 95 and not gh) else '**有问题**')
