# _patch_gen_rds.py —— 生成器的 %rd 寄存器数量写死成 28，TSY*TSX 变大就越界。
#
# 现象：TO=16/TSY=4/TSX=2（8 个空间位置）生成的 PTX 直接 218（PTX JIT 失败）。
# 原因：8 个 x 指针要用 %rd22..%rd29，而声明只有 %rd<28>（最大 %rd27）→ 越界。
# 修法：按 22 + TSY*TSX + 8 计算，多留 8 个 64 位寄存器做余量。
import io, os

P = "build_tmp/probe/_gen_conv_ptx.py"
d = io.open(P, encoding="utf-8", newline="").read()

old = 'e("    .reg .b64  %rd<28>;")'
new = 'e("    .reg .b64  %%rd<%d>;" % (22 + TSY * TSX + 8))'
if old not in d:
    if new in d:
        print("已是新版，跳过")
    else:
        raise SystemExit("锚点没找到")
else:
    if d.count(old) != 1:
        raise SystemExit("锚点命中 %d 次" % d.count(old))
    d = d.replace(old, new)
    tmp = P + ".tmpfix"
    with io.open(tmp, "w", encoding="utf-8", newline="") as f:
        f.write(d)
    os.replace(tmp, P)
    print("生成器 %rd 数量改为随 TSY*TSX 走")
