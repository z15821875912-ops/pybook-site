# _patch_gpu_overlap2.py —— 把 LOAD_OPT 宏的定义挪到 load_syms 开头（它被用在了定义之前）
import io, os, sys


def crlf(s):
    return s.replace("\r\n", "\n").replace("\n", "\r\n")


def read(path):
    with io.open(path, "r", encoding="utf-8", newline="") as f:
        return f.read()


def write_atomic(path, text):
    tmp = path + ".tmpfix"
    with io.open(tmp, "w", encoding="utf-8", newline="") as f:
        f.write(text)
    os.replace(tmp, path)


def sub(text, old, new, tag):
    old = crlf(old)
    new = crlf(new)
    n = text.count(old)
    if n != 1:
        print("锚点 %s 出现 %d 次 —— 补丁中止，不写盘" % (tag, n))
        sys.exit(1)
    return text.replace(old, new)


src = read("pybook_gpu.c")

if "#define LOAD_OPT(n, f)" in src.split("#define LOAD_OPT(n, f)")[0]:
    print("LOAD_OPT 已在前面，跳过。")
else:
    # 把定义从 cuGetErrorString 后面挪到 LOAD_V2 宏定义后面
    old_def = """    /* 可选入口：缺了就置 NULL，不报错（LOAD 会因为缺符号直接失败） */
#define LOAD_OPT(n, f)                                                   \\
    do {                                                                 \\
        p = (void *)GetProcAddress(g_dll, n);                            \\
        memcpy(&(f), &p, sizeof(f));                                     \\
    } while (0)
"""
    src = sub(src, old_def, "", "D1 删掉旧定义")

    anchor = """#define LOAD_V2(base, v2, f)                                          \\
    do {                                                               \\
        p = (void *)GetProcAddress(g_dll, v2);                         \\
        if (!p) p = (void *)GetProcAddress(g_dll, base);               \\
        if (!p) {                                                      \\
            snprintf(g_why, sizeof g_why, "驱动没导出 %s", v2);        \\
            return 0;                                                  \\
        }                                                              \\
        memcpy(&(f), &p, sizeof(f));                                   \\
    } while (0)
"""
    new_anchor = anchor + """/* 可选入口：缺了就置 NULL，不报错（LOAD 缺符号会直接失败） */
#define LOAD_OPT(n, f)                                                   \\
    do {                                                                 \\
        p = (void *)GetProcAddress(g_dll, n);                            \\
        memcpy(&(f), &p, sizeof(f));                                     \\
    } while (0)
"""
    src = sub(src, anchor, new_anchor, "D2 挪到函数开头")

    write_atomic("pybook_gpu.c", src)
    print("LOAD_OPT 位置修正完成。")
