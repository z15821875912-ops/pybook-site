"""反向验证 —— 退回 chat 实现，对应断言必须转红。

方法论：正向全绿只能证明「没报错」，不能证明「断言真的在盯那个东西」。
所以每一条关键机制都故意破坏一次，E2E 必须**失败**；如果照样全绿，
说明这条断言是假通过（像 sym 那种「跑通就算过」）。

四个突变：
  1) 转发时不补行尾   → 接收端拼不出整行 → 「一条都收不到」
  2) 不校验 HMAC      → 篡改密文/篡改校验码被当成合法消息显示
  3) 不防重放         → 重放的旧消息被再显示一次
  4) 校验码改回旧字节串（标签用十六进制 ASCII） → C 与独立实现对不上，全军覆没

跑法：python build_tmp\\probe\\_反向验证.py
每个突变跑一次 E2E（约 30 秒），最后一定把 pybook_net.c 还原。
"""
import os
import re
import subprocess
import sys

ROOT = os.path.dirname(os.path.abspath(__file__))
NET = os.path.join(ROOT, 'pybook_net.c')
E2E = os.path.join(ROOT, '聊天互通验证.py')

with open(NET, 'rb') as f:
    ORIG = f.read()
ORIG_TEXT = ORIG.decode('utf-8')

MUTATIONS = [
    ('转发不补行尾（回到「连上了却什么都收不到」）', [
        ('                        chat_out_append(o, fwd, strlen(fwd));\r\n',
         '                        chat_out_append(o, line, strlen(line));\r\n'),
    ]),
    ('不校验 HMAC（篡改密文/篡改校验码不再拒收）', [
        ('    if (!cr_equal(mac, want, 16))\r\n',
         '    if (0)\r\n'),
    ]),
    ('不防重放（重放的旧消息不再拒收）', [
        ('                if (ctr <= s->seen[idx].seq)\r\n',
         '                if (ctr < s->seen[idx].seq)\r\n'),
    ]),
    ('校验码改回旧字节串（标签用十六进制 ASCII）', [
        ('    unsigned char *buf = (unsigned char *)malloc(1 + 16 + 12 + ctlen);\r\n',
         '    unsigned char *buf = (unsigned char *)malloc(1 + 32 + 12 + ctlen + 1);\r\n'),
        ('    memcpy(buf + n, tag, 16); n += 16;\r\n',
         '    { char th[33]; cr_hex(tag, 16, th); memcpy(buf + n, th, 32); n += 32; }\r\n'),
    ]),
]


def write_net(text):
    tmp = NET + '.tmpfix'
    with open(tmp, 'wb') as f:
        f.write(text.encode('utf-8'))
    os.replace(tmp, NET)


def run_e2e():
    env = dict(os.environ)
    env['PYTHONUTF8'] = '1'
    env['PYTHONIOENCODING'] = 'utf-8'
    p = subprocess.run([sys.executable, E2E], cwd=ROOT, env=env,
                       capture_output=True, text=True, encoding='utf-8',
                       errors='replace', timeout=300)
    out = p.stdout or ''
    m = re.search(r'结果: (\d+)/(\d+) 通过', out)
    summary = m.group(0) if m else '（没拿到结果行）'
    fails = []
    for line in out.splitlines():
        if line.startswith('FAIL'):
            fails.append(line[5:].strip())
    return p.returncode, summary, fails, out


def main():
    ok_all = True
    try:
        for name, edits in MUTATIONS:
            text = ORIG_TEXT
            for old, new in edits:
                c = text.count(old)
                assert c == 1, '突变锚点「%s」出现 %d 次' % (old.strip()[:40], c)
                text = text.replace(old, new, 1)
            write_net(text)
            rc, summary, fails, out = run_e2e()
            red = (rc != 0)
            print('[突变] %s' % name)
            print('        E2E 结果: %s，退出码 %d → %s'
                  % (summary, rc, '转红（符合预期）' if red else '仍然全绿（！）'))
            for f in fails[:6]:
                print('        FAIL: %s' % f)
            if not red:
                ok_all = False
                print('        !! 这个突变没被任何断言抓到 —— 对应断言是假通过')
            print()
    finally:
        write_net(ORIG_TEXT)
        print('已还原 pybook_net.c')
    print('反向验证%s' % ('通过：每个突变都让断言转红' if ok_all else '失败：有突变没被抓到'))
    return 0 if ok_all else 1


if __name__ == '__main__':
    sys.exit(main())
