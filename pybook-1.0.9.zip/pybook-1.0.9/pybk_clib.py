# -*- coding: utf-8 -*-
"""同目录 C 库：自动发现 + 函数原型解析。

用法（PYbook 侧零配置）：

    我的程序.pybk
    我的库.c
    我的库.h

→ 程序里直接写 `我的库加(1, 2)`，不用写 ffi.声明 / ffi.包含 / ffi.链接。

设计要点
--------
1. **同文件夹 = 主程序（.pybk）所在目录**。不是 cwd —— IDE 从别处跑、
   回归用例从 build_tmp/ 跑时，cwd 都不是程序所在处。
2. **裸名调用**：C 的符号名就是 PYbook 的调用名。不加命名空间前缀，
   因为 C 符号没法凭空加前缀（要加就得生成 wrapper，多一层间接）。
   所以用户自己的 C 函数名要避开 PYbook 内建名（rt_*/mt_* 那些是内部实现）。
3. **原型从 .h 和 .c 里自动解析**，不用手写 ffi.声明。
   .h 里的声明优先（那是权威签名），.c 里的定义用来补齐没写 .h 的情况，
   同时解决「A.c 调用 B.c 里定义在后面的函数」这种隐式声明问题。
4. **类型走现成的 FFI 桥**（rt_ffi_int / rt_ffi_flt / rt_ffi_str / rt_ffi_ptr /
   rt_ffi_str_ret），所以支持 int / 浮点 / char* / void* / void 这几类值，
   不支持结构体传值（PYbook 没有对应的值类型）。

排除规则（避免把 PYbook 自己当成「用户库」）
------------------------------------------
- PYbook 运行时 C 文件：pybook_*.c / mathplus.c / pyvm*.c / rt_debug.c /
  编辑器.c / ide启动器.c
- 下划线开头的文件（仓库约定：草稿，不是交付物）
- out_*.c（生成物）、app_*.exe 同理
"""
import os
import re

# PYbook 自己的 C 文件（不算用户扔进来的库）
RUNTIME_C_NAMES = {
    'mathplus.c', 'pyvm.c', 'pyvm_preI_src.c', 'rt_debug.c',
    '编辑器.c', 'ide启动器.c', 'smokeroor.c',
}
RUNTIME_C_PREFIX = ('pybook_',)

# 不能作为 C 标识符的词（排除 if/for/return 这类被正则误当成返回类型）
C_KEYWORDS = {
    'if', 'else', 'for', 'while', 'do', 'switch', 'case', 'default',
    'return', 'goto', 'break', 'continue', 'sizeof', 'typedef', 'struct',
    'union', 'enum', 'const', 'static', 'extern', 'inline', 'register',
    'volatile', 'restrict', '_Static_assert', 'static_assert', 'new', 'delete',
    'class', 'template', 'typename', 'operator', 'namespace', 'using', 'public',
    'private', 'protected', 'virtual', 'friend', 'this', 'throw', 'catch',
}

# 函数原型 / 定义
#   lead   返回类型（可含 * 和 const）
#   name   函数名
#   params 参数表（不含嵌套括号 → 函数指针参数直接跳过）
#   tail   ';' 说明是声明，'{' 说明是定义
_FN_RE = re.compile(
    r'(?:^|[\n;{}])'
    r'(?P<lead>[A-Za-z_][A-Za-z0-9_ \t]*?(?:\*\s*)?)'
    r'[ \t]+(?P<name>[A-Za-z_]\w*)[ \t]*'
    r'\((?P<params>[^;{}()]*)\)[ \t]*(?P<tail>[;{])'
)

_COMMENT_RE = re.compile(r'/\*.*?\*/|//[^\n]*', re.S)
_STR_RE = re.compile(r'"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'')
_PREP_RE = re.compile(r'^[ \t]*#(?:[^\n\\]*\\\n)*[^\n]*', re.M)


def _strip(src: str) -> str:
    """去注释、去字符串字面量、去预处理指令行。"""
    src = _COMMENT_RE.sub(' ', src)
    src = _STR_RE.sub('""', src)
    src = _PREP_RE.sub('', src)
    return src


def _classify(t: str):
    """C 类型 → 转换类（int/flt/str/ptr/void）。规则与 ffi.声明 一致。"""
    t = re.sub(r'\s+', ' ', t.strip())
    t = t.replace('[]', ' * ')          # 数组参数在 C 里就是指针
    t = re.sub(r'\s*\*\s*', ' * ', t).strip()
    tl = t.lower()
    if 'struct' in tl or 'union' in tl or 'enum' in tl:
        return None                     # 结构体传值没有对应的 PYbook 值类型
    if tl == 'void':
        return 'void'
    if t.endswith('*'):
        base = t[:-1].strip().replace('const', '').strip()
        return ('str' if base == 'char' else 'ptr')
    if re.search(r'\b(double|float)\b', tl):
        return 'flt'
    return 'int'


_TYPE_WORD_RE = re.compile(r'^(double|float|int|long|short|char|void|unsigned|signed|size_t|bool)$')


def _parse_params(params: str):
    """参数表 → [(类, 归一类型)]。解析不了返回 None（该函数不暴露）。"""
    params = params.strip()
    if not params or params == 'void':
        return []
    out = []
    for p in params.split(','):
        p = p.strip()
        if not p:
            return None
        # 数组参数在 C 里就是指针：int a[] → int a*
        p = re.sub(r'\[\s*\]', '*', p)
        toks = p.replace('*', ' * ').split()
        if not toks:
            return None
        # 末token 是标识符且不是类型词 → 它是参数名，其余才是类型
        # （星号可能夹在中间：int a* / const char * s / void * p）
        name_idx = None
        for i in range(len(toks) - 1, -1, -1):
            t = toks[i]
            if t == '*':
                continue
            if (re.fullmatch(r'[A-Za-z_]\w*', t)
                    and not _TYPE_WORD_RE.match(t)
                    and not t.endswith('_t')):
                name_idx = i
            break
        if name_idx is not None and len(toks) >= 2:
            ptype = ' '.join(toks[:name_idx] + toks[name_idx + 1:])
        else:
            ptype = ' '.join(toks)
        ptype = re.sub(r'\s*\*\s*', ' * ', ptype).strip()
        ptype = re.sub(r'\s+', ' ', ptype)
        if not ptype:
            return None
        cls = _classify(ptype)
        if cls is None:
            return None
        out.append((cls, ptype))
    return out


def parse_source(src: str, want_defs: bool = True):
    """从一段 C 源码里解析出函数原型。

    返回 [(名字, 返回类, 返回类型, [(参数类, 参数类型)], 是不是定义)]。
    """
    text = _strip(src)
    found = []
    for m in _FN_RE.finditer(text):
        lead = re.sub(r'\s+', ' ', m.group('lead')).strip()
        name = m.group('name')
        if not lead or name in C_KEYWORDS:
            continue
        # 返回类型里出现关键字 → 不是函数原型（if/return/typedef 之类）
        lead_toks = [t for t in lead.split() if t != '*']
        if not lead_toks:
            continue
        if any(t in C_KEYWORDS for t in lead_toks):
            continue
        if 'static' in lead_toks:
            continue                     # 内部链接，不暴露
        if 'inline' in lead_toks:
            continue                     # inline 语义下没有外部符号，链不上
        ret_t = re.sub(r'\s*\*\s*', ' * ', lead).strip()
        ret_cls = _classify(ret_t)
        if ret_cls is None:
            continue
        params = _parse_params(m.group('params'))
        if params is None:
            continue
        is_def = (m.group('tail') == '{')
        if is_def and not want_defs:
            continue
        found.append((name, ret_cls, ret_t, params, is_def))
    return found


class Clib:
    """一个自动发现到的 C 库（一个 .c 文件 + 它声明的原型）。"""

    def __init__(self, c_path, decls, headers):
        self.c_path = c_path
        self.decls = decls      # {名字: (返回类, 返回类型, [(参数类,参数类型)])}
        self.headers = headers  # 同名 .h（用于生成时 -I 和 #include 提示）


def candidate_files(main_dir: str):
    """候选文件（只看名字，不读内容）→ (用户 .c 列表, 同目录 .h 列表)。

    discover() 和 exe 缓存指纹都用它，保证两边看到的文件集合一致。
    """
    cs, hs = [], []
    if not main_dir or not os.path.isdir(main_dir):
        return cs, hs
    try:
        names = sorted(os.listdir(main_dir))
    except OSError:
        return cs, hs
    for n in names:
        p = os.path.join(main_dir, n)
        if not os.path.isfile(p):
            continue
        if n.endswith('.h'):
            hs.append(p)
            continue
        if not n.endswith('.c'):
            continue
        if n in RUNTIME_C_NAMES or n.startswith(RUNTIME_C_PREFIX):
            continue
        if n.startswith('_') or n.startswith('out_'):
            continue                     # 草稿工具 / 生成物
        if n.lower().endswith('.prei_src.c'):
            continue
        cs.append(p)
    return cs, hs


_INC_RE = re.compile(r'#\s*include\s*"([^"]+)"')


def _local_headers(c_path, hdir):
    """这个 .c 用到的本地头文件：同名 .h + 它 #include "..." 的本地 .h。

    只认引号形式（系统头 <stdio.h> 不管）；找不到的文件忽略。
    不收「同目录所有 .h」——那会把 pybook_rt.h 之类运行时头的内部函数
    当成用户库暴露出去。
    """
    out = []
    base = os.path.splitext(os.path.basename(c_path))[0]
    same = os.path.join(hdir, base + '.h')
    if os.path.isfile(same):
        out.append(same)
    try:
        with open(c_path, encoding='utf-8-sig', errors='replace') as f:
            src = f.read()
    except OSError:
        return out
    for inc in _INC_RE.findall(src):
        if os.path.isabs(inc):
            p = inc
        else:
            p = os.path.join(hdir, inc.replace('/', os.sep))
        if os.path.isfile(p) and p not in out:
            out.append(p)
    return out


def discover(main_dir: str):
    """扫主程序所在目录，找出用户 C 库文件。返回 [Clib]（按文件名排序，稳）。"""
    cs, _hs = candidate_files(main_dir)
    if not cs:
        return []
    hdir = os.path.dirname(cs[0]) or '.'
    clibs = []
    for p in cs:
        try:
            with open(p, encoding='utf-8-sig', errors='replace') as f:
                src = f.read()
        except OSError:
            continue
        headers = _local_headers(p, hdir)
        # 头文件里的声明是权威签名
        hdr_decls = {}
        for hp in headers:
            try:
                with open(hp, encoding='utf-8-sig', errors='replace') as f:
                    hsrc = f.read()
            except OSError:
                continue
            for nm, rc, rt, ps, _d in parse_source(hsrc):
                hdr_decls.setdefault(nm, (rc, rt, ps))
        decls = {}
        # .c 里的定义（补 .h 里没写的）
        for nm, rc, rt, ps, _is_def in parse_source(src):
            if nm not in hdr_decls:
                decls[nm] = (rc, rt, ps)
        # .h 里的声明优先
        for k, v in hdr_decls.items():
            decls[k] = v
        clibs.append(Clib(p, decls, headers))
    return clibs


def collect(clibs):
    """合并多个 Clib 的原型表 → ({名字: (返回类,返回类型,参数表)}, 冲突列表)。"""
    table = {}
    conflicts = []
    for c in clibs:
        for nm, (rc, rt, ps) in c.decls.items():
            if nm in table:
                if table[nm] != (rc, rt, ps):
                    conflicts.append((nm, table[nm], (rc, rt, ps)))
                continue
            table[nm] = (rc, rt, ps)
    return table, conflicts


def proto_text(name, ret_t, params):
    """生成 C 原型文本（发射到生成的 .c 头部）。"""
    return f'{ret_t} {name}(' + ', '.join(t for _c, t in params) + ');'
