/* _convk.c —— 手写 conv2d 内核的独立对拍 + 性能台（不经过生产代码）
 *
 * 干嘛用：新写的 PTX 内核先在这里跑通、跟 CPU 参考对拍、量出占 FP32 峰值的比例，
 *         确认没问题了再接进 pybook_gpu.c。免得内核有 bug 时去猜是内核还是宿主侧。
 *
 * 用法：_convk.exe <kernel.ptx> [形状个数]
 * 形状：N H W I O KH KW S
 * 编译：gcc _convk.c -o _convk.exe -O2 -I. -lwinmm -lm
 */
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

typedef int CUresult;
typedef int CUdevice;
typedef void *CUmodule;
typedef void *CUfunction;
typedef void *CUcontext;

static CUresult (*p_cuInit)(unsigned);
static CUresult (*p_cuModuleLoadData)(CUmodule *, const void *);
static CUresult (*p_cuModuleGetFunction)(CUfunction *, CUmodule, const char *);
static CUresult (*p_cuGetErrorString)(CUresult, const char **);
static CUresult (*p_cuDeviceGet)(CUdevice *, int);
static CUresult (*p_cuDevicePrimaryCtxRetain)(CUcontext *, CUdevice);
static CUresult (*p_cuCtxSetCurrent)(CUcontext);
static CUresult (*p_cuMemAlloc_v2)(unsigned long long *, size_t);
static CUresult (*p_cuMemFree_v2)(unsigned long long);
static CUresult (*p_cuMemcpyHtoD_v2)(unsigned long long, const void *, size_t);
static CUresult (*p_cuMemcpyDtoH_v2)(void *, unsigned long long, size_t);
static CUresult (*p_cuLaunchKernel)(CUfunction, unsigned, unsigned, unsigned,
                                    unsigned, unsigned, unsigned, unsigned,
                                    void *, void **, void **);
static CUresult (*p_cuCtxSynchronize)(void);
static CUresult (*p_cuDeviceGetName)(char *, int, CUdevice);
static CUresult (*p_cuDeviceGetAttribute)(int *, int, CUdevice);
static CUresult (*p_cuFuncGetAttribute)(int *, int, CUfunction);

#define CK(x) do { CUresult _r = (x); if (_r) { const char *e = 0;                     \
        p_cuGetErrorString(_r, &e);                                                     \
        printf("CUDA 错误 %d: %s (%s:%d)\n", _r, e ? e : "?", __FILE__, __LINE__);      \
        exit(2); } } while (0)

#define PEAK_TFLOPS 4.73        /* GTX 1060 6GB / CC 6.1 实测 FP32 峰值 */

static unsigned g_seed = 4242u;
static double frand(void)
{
    g_seed = g_seed * 1103515245u + 12345u;
    return (double)((g_seed >> 9) & 0xFFFF) / 65536.0 - 0.5;
}

static double now_s(void)
{
    static LARGE_INTEGER freq = {0};
    LARGE_INTEGER t;
    if (freq.QuadPart == 0) QueryPerformanceFrequency(&freq);
    QueryPerformanceCounter(&t);
    return (double)t.QuadPart / (double)freq.QuadPart;
}

/* CPU 参考：x=(N,I,H,W) k=(O,I,KH,KW) out=(N,O,OH,OW) */
static void cpu_conv(const double *x, const double *k, double *out,
                     int N, int H, int W, int I, int O,
                     int KH, int KW, int OH, int OW, int S)
{
    int n, oc, oh, ow, ii, ih, iw;
    for (n = 0; n < N; n++)
        for (oc = 0; oc < O; oc++)
            for (oh = 0; oh < OH; oh++)
                for (ow = 0; ow < OW; ow++) {
                    double s = 0.0;
                    for (ii = 0; ii < I; ii++)
                        for (ih = 0; ih < KH; ih++)
                            for (iw = 0; iw < KW; iw++)
                                s += x[(((size_t)n * I + ii) * H + (oh * S + ih)) * W
                                       + (ow * S + iw)]
                                   * k[(((size_t)oc * I + ii) * KH + ih) * KW + iw];
                    out[(((size_t)n * O + oc) * OH + oh) * OW + ow] = s;
                }
}

/* 从 PTX 头注释里读出真实分块尺寸：
 *   "// block = 16x16 = 256 threads; one block covers 16 oc x 32 oh x 32 ow."
 * 台子跟生成器同源，扫参时不会因为写死的 32 而算错网格。
 * 读不到返回 0，调用方退回默认值。 */
static int parse_tile(const char *ptx, int *bx, int *by, int *to, int *toh, int *tow)
{
    const char *p = strstr(ptx, "// block = ");
    int a = 0, b = 0, c = 0, e = 0, f = 0, g = 0;
    if (!p) return 0;
    if (sscanf(p, "// block = %d x %d = %d threads; one block covers %d oc x %d oh x %d ow.",
               &a, &b, &c, &e, &f, &g) != 6) return 0;
    if (a < 1 || b < 1 || e < 1 || f < 1 || g < 1) return 0;
    *bx = a; *by = b; *to = e; *toh = f; *tow = g;
    return 1;
}

int main(int argc, char **argv)
{
    static const int def[][8] = {
        /* N  H    W    I  O  KH KW S */
        {  1,  28,  28,  1,  8,  3, 3, 1 },
        {  1,  32,  32,  3, 16,  3, 3, 1 },
        {  1,  32,  32,  1,  1,  3, 3, 1 },
        {  1,  17,  23,  5, 11,  3, 3, 1 },
        {  1,  64,  64, 16, 32,  3, 3, 1 },
        {  2,  56,  56, 32, 64,  3, 3, 1 },
        {  8,  28,  28,  1,  8,  3, 3, 1 },
        {  1,  64,  64,  3, 16,  3, 3, 2 },
        {  1,  33,  33,  7, 13,  5, 5, 1 },
        {  1,  16,  16, 64, 64,  1, 1, 1 },
        {  1,   8,   8,  1,  8,  3, 3, 1 },
        {  1,   8,   8,  2,  8,  3, 3, 1 },
        {  1,   8,   8,  3,  8,  3, 3, 1 },
    };
    HMODULE d;
    void *p;
    CUmodule mod = NULL;
    CUfunction fn = NULL;
    CUcontext ctx = NULL;
    CUdevice dev;
    char name[256];
    int nsh = (int)(sizeof(def) / sizeof(def[0]));
    int i, bad = 0;
    FILE *f;
    static char ptx[262144];
    size_t pn;
    int maxreg = 0;
    int TO = 8;                       /* 每线程几个输出通道（内核参数） */
    int TILE_OH = 32, TILE_OW = 32;   /* 一块覆盖多少输出行/列 */
    int BLK_X = 16, BLK_Y = 16;       /* blockDim（必须跟内核一致，否则少算活） */
    {
        const char *ev = getenv("PYBOOK_CONV_TO");
        if (ev && *ev) TO = atoi(ev);
    }

    if (argc < 2) { printf("用法: _convk.exe <kernel.ptx>\n"); return 1; }
    if (argc > 2) nsh = atoi(argv[2]);

    d = LoadLibraryA("nvcuda.dll");
    if (!d) { printf("no nvcuda.dll\n"); return 1; }
#define GP(n) p = (void *)GetProcAddress(d, #n); memcpy(&p_##n, &p, sizeof p);
    GP(cuInit) GP(cuModuleLoadData) GP(cuModuleGetFunction) GP(cuGetErrorString)
    GP(cuDeviceGet) GP(cuDevicePrimaryCtxRetain) GP(cuCtxSetCurrent) GP(cuMemAlloc_v2)
    GP(cuMemFree_v2) GP(cuMemcpyHtoD_v2) GP(cuMemcpyDtoH_v2) GP(cuLaunchKernel)
    GP(cuCtxSynchronize) GP(cuDeviceGetName) GP(cuDeviceGetAttribute)
    GP(cuFuncGetAttribute)
#undef GP

    CK(p_cuInit(0));
    CK(p_cuDeviceGet(&dev, 0));
    CK(p_cuDevicePrimaryCtxRetain(&ctx, dev));
    CK(p_cuCtxSetCurrent(ctx));
    p_cuDeviceGetName(name, sizeof name, dev);
    printf("设备：%s\n", name);
    {   /* CC */
        int cc = 0;
        p_cuDeviceGetAttribute(&cc, 75, dev);
        printf("CC=%d.%d\n", cc / 10, cc % 10);
    }

    f = fopen(argv[1], "rb");
    if (!f) { printf("打不开 %s\n", argv[1]); return 1; }
    pn = fread(ptx, 1, sizeof ptx - 1, f);
    fclose(f);
    ptx[pn] = 0;
    CK(p_cuModuleLoadData(&mod, ptx));
    CK(p_cuModuleGetFunction(&fn, mod, "conv2d"));
    p_cuFuncGetAttribute(&maxreg, 4 /*CU_FUNC_ATTRIBUTE_NUM_REGS*/, fn);
    {
        /* 头注释里有真实分块：block = BXxBY，覆盖 TO oc x TILE_OH oh x TILE_OW ow。
         * 台子跟生成器同源 —— 写死 32 的话一改参数就算错网格（表现为「部分形状错」）。 */
        int bx = 0, by = 0, to = 0, toh = 0, tow = 0;
        if (parse_tile(ptx, &bx, &by, &to, &toh, &tow)) {
            TO = to; TILE_OH = toh; TILE_OW = tow; BLK_X = bx; BLK_Y = by;
            printf("分块：block %dx%d，每线程 %d 通道，一块覆盖 %d oh x %d ow\n",
                   bx, by, TO, TILE_OH, TILE_OW);
        } else {
            printf("分块：读不到头注释，用默认 TO=%d tile %dx%d block %dx%d\n",
                   TO, TILE_OH, TILE_OW, BLK_X, BLK_Y);
        }
    }
    printf("内核 conv2d 载入 OK，占用寄存器 %d\n\n", maxreg);

    printf("%-28s | %10s | %8s | %8s | %s\n",
           "形状 N H W I O KH KW S", "ms", "TFLOPS", "占峰值", "正确性");
    printf("----------------------------+----------+----------+---------+--------\n");

    for (i = 0; i < nsh; i++) {
        int N = def[i][0], H = def[i][1], W = def[i][2], I = def[i][3];
        int O = def[i][4], KH = def[i][5], KW = def[i][6], S = def[i][7];
        int OH = (H - KH) / S + 1, OW = (W - KW) / S + 1;
        int OPAD = (O + TO - 1) / TO * TO;
        size_t nx = (size_t)N * I * H * W, nk = (size_t)O * I * KH * KW;
        size_t no = (size_t)N * O * OH * OW;
        size_t nwk = (size_t)I * KH * KW * OPAD;
        size_t pad = (size_t)((size_t)TILE_OH * S * W + (size_t)TILE_OW * S + 64);
        /* 越界读兜底：一块覆盖 TILE_OH 行 x TILE_OW 列输出位置，
           最坏越过图像末尾 TILE_OH*S 行（每行 W 个元素）+ TILE_OW*S 个元素。
           注意行/列不能写反：方块 tile 看不出来，非方块 tile 会读到下一张图的数据，
           表现为「部分形状结果错」。 */
        double *x = (double *)malloc(nx * sizeof(double));
        double *k = (double *)malloc(nk * sizeof(double));
        double *y = (double *)malloc(no * sizeof(double));
        double *ref = (double *)malloc(no * sizeof(double));
        float *fx = (float *)malloc((nx + pad) * sizeof(float));
        float *fw = (float *)malloc(nwk * sizeof(float));
        float *fy = (float *)malloc(no * sizeof(float));
        unsigned long long d_x = 0, d_w = 0, d_o = 0;
        size_t j;
        double t0, t1, best = 1e30, tf, flops;
        int rep, over = 0;
        double maxrel = 0;
        unsigned gx, gy, gz;

        if (!x || !k || !y || !ref || !fx || !fw || !fy) { printf("host 内存不足\n"); return 1; }
        for (j = 0; j < nx; j++) x[j] = frand();
        for (j = 0; j < nk; j++) k[j] = frand();
        for (j = 0; j < nx; j++) fx[j] = (float)x[j];
        for (j = 0; j < pad; j++) fx[nx + j] = 0.0f;
        /* 权重转置：wt[k*OPAD + oc] = k[oc*(I*KH*KW) + k] */
        memset(fw, 0, nwk * sizeof(float));
        for (j = 0; j < (size_t)O; j++) {
            size_t kk;
            for (kk = 0; kk < (size_t)I * KH * KW; kk++)
                fw[kk * OPAD + j] = (float)k[j * (size_t)I * KH * KW + kk];
        }
        memset(fy, 0, no * sizeof(float));
        /* 参考用「f32 舍入后的输入」做 double 累加：这样差值只反映核内累加精度，
           不会把 f32 舍入本身算成错。 */
        {
            double *xr = (double *)malloc(nx * sizeof(double));
            double *kr = (double *)malloc(nk * sizeof(double));
            size_t kk, oc2;
            for (kk = 0; kk < nx; kk++) xr[kk] = (double)fx[kk];
            for (oc2 = 0; oc2 < (size_t)O; oc2++)
                for (kk = 0; kk < (size_t)I * KH * KW; kk++)
                    kr[oc2 * (size_t)I * KH * KW + kk] =
                        (double)fw[kk * OPAD + oc2];
            cpu_conv(xr, kr, ref, N, H, W, I, O, KH, KW, OH, OW, S);
            free(xr); free(kr);
        }

        CK(p_cuMemAlloc_v2(&d_x, (nx + pad) * sizeof(float)));
        CK(p_cuMemAlloc_v2(&d_w, nwk * sizeof(float)));
        CK(p_cuMemAlloc_v2(&d_o, no * sizeof(float)));
        CK(p_cuMemcpyHtoD_v2(d_x, fx, (nx + pad) * sizeof(float)));
        CK(p_cuMemcpyHtoD_v2(d_w, fw, nwk * sizeof(float)));
        CK(p_cuMemcpyHtoD_v2(d_o, fy, no * sizeof(float)));

        gx = (unsigned)((OW + TILE_OW - 1) / TILE_OW);
        gy = (unsigned)((OH + TILE_OH - 1) / TILE_OH);
        gz = (unsigned)(N * ((O + TO - 1) / TO));
        {
            int I_ = I, H_ = H, W_ = W, O_ = O, KH_ = KH, KW_ = KW, S_ = S;
            int OH_ = OH, OW_ = OW, OPAD_ = OPAD;
            void *params[] = { &d_x, &d_w, &d_o, &I_, &H_, &W_, &O_,
                               &KH_, &KW_, &S_, &OH_, &OW_, &OPAD_ };
            for (rep = 0; rep < 3; rep++) {
                double tt;
                int it;
                t0 = now_s();
                for (it = 0; it < 20; it++)
                    CK(p_cuLaunchKernel(fn, gx, gy, gz, (unsigned)BLK_X, (unsigned)BLK_Y, 1,
                                    0, NULL, params, NULL));
                CK(p_cuCtxSynchronize());
                t1 = now_s();
                tt = (t1 - t0) / 20.0;      /* 摊掉启动开销 */
                if (tt < best) best = tt;
            }
            CK(p_cuMemcpyDtoH_v2(fy, d_o, no * sizeof(float)));
        }

        for (j = 0; j < no; j++) {
            double d = fabs((double)fy[j] - ref[j]);
            double mag = 0;
            int oc = (int)(j / ((size_t)OH * OW)) % O;
            int rem = (int)(j % ((size_t)OH * OW));
            int oh = rem / OW, ow = rem % OW;
            int ii, ih, iw, nn = (int)(j / ((size_t)O * OH * OW));
            for (ii = 0; ii < I; ii++)
                for (ih = 0; ih < KH; ih++)
                    for (iw = 0; iw < KW; iw++)
                        mag += fabs(x[(((size_t)nn * I + ii) * H + (oh * S + ih)) * W
                                      + (ow * S + iw)]
                                   * k[(((size_t)oc * I + ii) * KH + ih) * KW + iw]);
            {
                double rel = (mag > 0) ? d / mag : d;
                if (rel > maxrel) maxrel = rel;
                if (rel > 1e-5) {
                    over++;
                    if (over <= 8)
                        printf("      错: n=%d oc=%d oh=%d ow=%d  got=%.6g ref=%.6g\n",
                               nn, oc, oh, ow, (double)fy[j], ref[j]);
                }
            }
        }
        if (over) bad++;

        flops = 2.0 * (double)N * (double)O * (double)OH * (double)OW
              * (double)I * (double)KH * (double)KW;
        tf = flops / best / 1e12;
        printf("%3d %3dx%-3d I%-2d O%-2d %dx%d S%d | %10.3f | %8.3f | %7.1f%% | %s (maxrel %.2e, 块 %ux%ux%u)\n",
               N, H, W, I, O, KH, KW, S, best * 1000.0, tf, tf / PEAK_TFLOPS * 100.0,
               over ? "错!" : "对", maxrel, gx, gy, gz);
        fflush(stdout);
        p_cuMemFree_v2(d_x); p_cuMemFree_v2(d_w); p_cuMemFree_v2(d_o);
        free(x); free(k); free(y); free(ref); free(fx); free(fw); free(fy);
    }
    printf("\n超差形状：%d / %d\n", bad, nsh);
    return bad ? 1 : 0;
}
