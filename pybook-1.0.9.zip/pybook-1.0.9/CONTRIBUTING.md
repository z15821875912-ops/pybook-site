# 参与 PYbook 开发（贡献指南）

面向**中大型团队协作**：本文件说明如何从零把 PYbook 跑起来、怎么测试、以及提交 / 发版的约定。
读架构先看 [ARCHITECTURE.md](ARCHITECTURE.md)，加标准库看 [PYBOOK_库作者指南.md](PYBOOK_库作者指南.md)。

> ⚠️ **动手之前先看 [PYBOOK_潜规则手册.md](PYBOOK_潜规则手册.md)**。
> 那里面是「只有摔过跤才知道」的规矩：PTX 为什么会报 218、为什么性能数字会骗人、
> 为什么补丁脚本必须幂等、为什么删文件不能用 `Remove-Item`、
> 以及一份动手前 / 收工前的自查清单。**本文件讲「怎么做」，手册讲「别这么干」。**
> 手册里每条都带出处，可以自己翻原始证据。

## 1. 环境前置（一次性）

- **C 编译器**：需支持 AVX2（`-march=native`）。
  - **Windows**：仓库自带 MinGW-w64（`发布打包_102/mingw64`，零安装）；或自行 `winget install mingw` / 装 MinGW-w64 并加入 PATH。
  - **Linux**：`sudo apt install gcc` / `dnf install gcc`。
  - **macOS**：`brew install gcc`。
- **Python**：3.10+（VM 后端与测试使用）。
- **hw3d 3D 功能**：额外需要 SDL2（仓库 `ucrt64/` 已带；仅 C 后端 3D 需要，VM 后端不影响）。

## 2. 构建 VM 运行时（pyvm）

任意改动 `pybook_*.c` / `mathplus.c` 后都必须重建 pyvm：

```bat
build_pyvm.bat          # Windows（自动探测 gcc：自带工具链 → PATH → 常见路径）
```
```bash
make                    # Windows / MinGW
make OS=linux          # Linux / macOS（自动去掉 pybook_music.c，不链 -lwinmm）
```

产物 `pyvm`（`.exe`）生成在当前目录，`python pybk_main.py 程序.pybk` 立即生效。

## 3. 跑起来

```bash
python pybk_main.py 示例.pybk              # C 后端：首次调 gcc 编原生 exe
python pybk_main.py --check 示例.pybk      # 仅语法/语义检查（写代码、AI 改代码最常用）
python pybk_main.py --version              # 打印版本（读 VERSION 文件）
```

## 4. 测试（改完必跑）

```bash
python tests/run_tests.py                 # 全量回归
python tests/run_tests.py --only T03_list_ok,T10_vc_ok   # 只跑指定用例
python tests/run_tests.py --list          # 只列用例不运行
```

CI 会在每次 push / PR 自动构建 pyvm 并跑全量回归。本地请在发 PR 前先跑一遍。

## 5. 版本号（单一真相源）

- **`VERSION` 文件是当前版本唯一来源**，`pybk_main.py --version` 读它；改版本只改这一个文件。
- 严禁在 README / 代码里硬编码版本号（已由 VERSION 派生）。
- 发版流程：① 在 `CHANGELOG.md` 顶部加 `## X.Y.Z` 节，说明加了什么；② 更新 `VERSION`；③ 打 git tag `vX.Y.Z`；④ 推送后 CI 自动构建。
- 当前开发版写在 `VERSION`（如 `1.0.14`）；最新已发布版本见 `CHANGELOG.md` 与官网。

## 6. 分支与提交约定

- 主分支 `master`；功能走 `feature/xxx`、修复走 `fix/xxx`，**PR 合入前需过 CI 且至少一人 review**。
- 提交信息用中文，首行一句话说明意图（参考历史：`可读性+团队可建性：可移植构建与文档`、`止血两处…`）。
- **每个 PR 聚焦一件事**；改了运行时 / C 后端务必附回归测试，或说明为何无法加。

## 7. 加一个标准库模块

见 [PYBOOK_库作者指南.md](PYBOOK_库作者指南.md)——注册前缀 / `LIB_C_NAMES` / 运行时 `.c` / VM `_vm_lib_calls.inc` 四处联动。

## 8. 代码风格

- 编译器 / 运行时为 C（C11），注释用中文。
- **性能热点必须写清调优依据的注释**：例如 `pybook_tb.c` 的 matmul 块尺寸 `KC=NC=MC=48` 是经过扫描调出来的，注释里写明了「为什么不能改大」，避免后人误改回 128 导致 1000³ 从 ~20ms 退化到 ~27ms。
- Python 编译器层（`pybk_*.py`）保持函数单一职责；重大改动先在 `build_tmp/` 写探针验证，再合入主干。
- 不要提交构建产物（`*.exe` / `*.pybc` / `*.o` 等已被 `.gitignore` 覆盖）。

## 9. 提交前对一遍潜规则手册

[PYBOOK_潜规则手册.md](PYBOOK_潜规则手册.md) 第 7 节有「动手前 / 收工前」两张自查清单，
提交前照着过一遍。至少确认这四条：

- 验收台覆盖了边界形状，且**反向验证过**（故意改坏一处，断言要转红）；
- 性能数字标了口径（kernel-only 还是端到端），且** sanity check 过百分比**；
- 改了 `pybook_*.c` 的，VM 已重建、`tests/run_tests.py` 全绿；
- 新踩的坑写进了手册或 `GPU_DESIGN.md`——**坑不写下来，下一个人还会再摔一遍**。
