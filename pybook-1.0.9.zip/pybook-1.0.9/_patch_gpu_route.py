# _patch_gpu_route.py —— 给 pybook_gpu.c 打「第四跳：设备感知路由」补丁
#
# 纪律：
#   · 每个锚点先断言 count == 1，全过才写盘
#   · .tmpfix + os.replace() 原子替换
#   · 幂等：已打过就整段跳过（靠「新内容在不在」判断，不是靠「锚点在不在」）
#   · pybook_gpu.c 是 CRLF：新内容一律写成 LF 再转 CRLF，绝不把文件改成 LF
import io, os, sys

SRC = "pybook_gpu.c"
HDR = "pybook_gpu.h"


def crlf(s):
    return s.replace("\r\n", "\n").replace("\n", "\r\n")


def read(path):
    with io.open(path, "r", encoding="utf-8", newline="") as f:
        return f.read()


def write_atomic(path, text):
    tmp = path + ".tmpfix"
    with io.open(tmp, "w", encoding="utf-8", newline="") as f:
        f.write(text)
    os.replace(tmp, path)


def sub(text, old, new, tag):
    """锚点必须唯一出现；不唯一或缺失都直接报错退出（不写盘）。
    old/new 都按 CRLF 归一化：pybook_gpu.c 是 CRLF 文件，脚本里写 LF 也能匹配。"""
    old = crlf(old)
    new = crlf(new)
    n = text.count(old)
    if n != 1:
        print("锚点 %s 出现 %d 次（要求恰好 1 次）—— 补丁中止，不写盘" % (tag, n))
        sys.exit(1)
    return text.replace(old, new)


src = read(SRC)
hdr = read(HDR)
changed = []

# ── 0) 幂等检查：已经在新代码里就整段跳过 ───────────────────────────────
if "第四跳：设备感知" in src:
    print("pybook_gpu.c 已经打过第四跳补丁，跳过。")
else:
    # ── A1: 可选入口的 typedef ──────────────────────────────────────────
    a1 = "static CUresult (*p_cuGetErrorString)(CUresult, const char **);\n"
    a1_new = a1 + """/* 以下是第四跳才用到的可选入口：缺了不致命，
 * 对应的功能会退到静态兜底（见 gpu_setup_kernels / gpu_calibrate）。 */
static CUresult (*p_cuFuncGetAttribute)(int *, int, CUfunction);
static CUresult (*p_cuOccupancyMaxActiveBlocks)(int *, CUfunction, int, size_t);
static CUresult (*p_cuEventCreate)(void **, unsigned);
static CUresult (*p_cuEventRecord)(void *, void *);
static CUresult (*p_cuEventSynchronize)(void *);
static CUresult (*p_cuEventElapsedTime)(float *, void *, void *);
static CUresult (*p_cuEventDestroy)(void *);
"""
    src = sub(src, a1, crlf(a1_new), "A1 可选入口 typedef")
    changed.append("A1")

    # ── A2: 可选入口的装载 ─────────────────────────────────────────────
    a2 = '    LOAD("cuGetErrorString", p_cuGetErrorString);\n'
    a2_new = a2 + """    /* 可选入口：缺了就置 NULL，不报错（LOAD 会因为缺符号直接失败） */
#define LOAD_OPT(n, f)                                                   \\
    do {                                                                 \\
        p = (void *)GetProcAddress(g_dll, n);                            \\
        memcpy(&(f), &p, sizeof(f));                                     \\
    } while (0)
    LOAD_OPT("cuFuncGetAttribute", p_cuFuncGetAttribute);
    LOAD_OPT("cuOccupancyMaxActiveBlocksPerMultiprocessor", p_cuOccupancyMaxActiveBlocks);
    LOAD_OPT("cuEventCreate", p_cuEventCreate);
    LOAD_OPT("cuEventRecord", p_cuEventRecord);
    LOAD_OPT("cuEventSynchronize", p_cuEventSynchronize);
    LOAD_OPT("cuEventElapsedTime", p_cuEventElapsedTime);
    LOAD_OPT("cuEventDestroy", p_cuEventDestroy);
#undef LOAD_OPT
"""
    src = sub(src, a2, crlf(a2_new), "A2 可选入口装载")
    changed.append("A2")

    # ── A3: device attribute 常量 ──────────────────────────────────────
    a3 = "#define CU_DEVICE_ATTRIBUTE_CC_MINOR 76\n"
    a3_new = a3 + """/* 第四跳要用的两个属性号。**实测核对过**，不是照文档背的：
 * 1060 上 16 读到 10（SM 数）、39 读到 2048（每 SM 最大线程），都对得上。
 * 记错属性号的后果很阴：读出 0 或 4004000 这种数，路由会静默走错分支。 */
#define CU_DEVICE_ATTRIBUTE_MULTIPROCESSOR_COUNT 16
#define CU_DEVICE_ATTRIBUTE_MAX_THREADS_PER_MULTIPROCESSOR 39
"""
    src = sub(src, a3, crlf(a3_new), "A3 attribute 常量")
    changed.append("A3")

    # ── A4: 全局状态 + 前向声明 ────────────────────────────────────────
    a4 = "static int         g_cc = 0;                    /* major*10+minor */\n"
    a4_new = a4 + """static int         g_sms = 0;                  /* SM 数（问驱动问的） */
static int         g_max_threads_sm = 0;           /* 每 SM 最大线程数 */
static int         g_calibrated = 0;               /* 1=已在本机标定过时间常数 */
"""
    src = sub(src, a4, crlf(a4_new), "A4 全局状态")
    changed.append("A4")

    # ── A5: 探测时读设备属性 ───────────────────────────────────────────
    a5 = "        g_cc = maj * 10 + min;\n"
    a5_new = a5 + """        /* 第四跳：路由要用 SM 数与每 SM 最大线程数。
         * 拿不到就置 0，路由会自动退回老阈值（宁可老办法也不能瞎选）。 */
        g_sms = 0;
        g_max_threads_sm = 0;
        p_cuDeviceGetAttribute(&g_sms, CU_DEVICE_ATTRIBUTE_MULTIPROCESSOR_COUNT, dev);
        p_cuDeviceGetAttribute(&g_max_threads_sm,
                               CU_DEVICE_ATTRIBUTE_MAX_THREADS_PER_MULTIPROCESSOR, dev);
        if (g_sms < 1) g_sms = 0;
        if (g_max_threads_sm < 1) g_max_threads_sm = 0;
"""
    src = sub(src, a5, crlf(a5_new), "A5 探测读属性")
    changed.append("A5")

    # ── A6: 探测完 kernel 后建表 + 自标定 ─────────────────────────────
    a6 = "    g_fn_conv = compile_conv();     /* 失败只降级 conv，不影响 sgemm 通路 */\n"
    a6_new = a6 + """    gpu_setup_kernels();             /* 第四跳：建 kernel 表 + 问每 SM 驻留数 */
    gpu_calibrate();                 /* 第四跳：在这张卡上现测时间常数 */
"""
    src = sub(src, a6, crlf(a6_new), "A6 建表与自标定")
    changed.append("A6")

    # ── A7: 路由块整体换掉 ─────────────────────────────────────────────
    a7 = """        /* 三 kernel 尺寸路由。阈值来自 _gpucmp.c 的多轮交替实测
         * （GTX 1060 6GB，CUDA event 计时，21~31 轮取中位数，详见 GPU_DESIGN.md）：
         *   N>=1280 : sgemm_8x8（tile 128x128）
         *   N>=224  : sgemm_shared（tile 64x64）
         *   其他    : sgemm（4x4，无 bar.sync）
         * grid 步进随 tile：8x8 是 128，其余 64。block 恒 16x16。 */
        CUfunction f = g_fn;
        unsigned    step = 64;
        if (N >= GPU_8X8_MIN_N && g_fn_8x8)        { f = g_fn_8x8; step = 128; }
        else if (N >= GPU_SHARED_MIN_N && g_fn_sh) { f = g_fn_sh;  step = 64;  }
"""
    a7_new = """        /* 第四跳：路由改成「预测时间最短者胜」，量纲是设备相对的。
         * 块数 = ceil(M/tile)*ceil(N/tile)（M 和 N 都进，不再只看 N），
         * 波数 = ceil(块数 / (SM数 * 每SM常驻block数))，
         * 时间 = 波数 * (K * c_k + s_k)，c/s 是本卡自标定出来的。
         * 设备信息不全（g_sms 没问出来）时才退回下面那两个老阈值。 */
        CUfunction f = g_fn;
        unsigned    step = 64;
        int         ki = gpu_pick_kernel(M, N, K);
        if (ki >= 0) {
            f    = g_kg[ki].fn;
            step = g_kg[ki].tile;
        } else if (N >= GPU_8X8_MIN_N && g_fn_8x8) {
            f = g_fn_8x8; step = 128;
        } else if (N >= GPU_SHARED_MIN_N && g_fn_sh) {
            f = g_fn_sh;  step = 64;
        }
"""
    src = sub(src, a7, crlf(a7_new), "A7 路由块")
    changed.append("A7")

    # ── A8: 插入第四跳模型整段（放在 gpu_sgemm_f32 之前） ───────────────
    a8 = "int gpu_sgemm_f32(const double *A, const double *B, double *C,\n"
    a8_new = r'''/* ─────────────── 第四跳：设备感知 + 形状感知的 sgemm kernel 选型 ───────────────
 *
 * 病根：老路由把阈值按 N 写死（224 / 1280），而那两个数是** GTX 1060（10 个 SM）**
 * 测出来的。同一套阈值换到 SM 数不同的卡上就全错，三条病：
 *   1. 阈值 1280 是**第三跳（8x8 载入预取，快 22%）之前**的老数据，落后一整跳。
 *      1060 上实测 N∈[448,1280) 就该走 8x8，老路由还在走 shared，慢 22~45%。
 *   2. 阈值只看 N 不看 M：瘦长形（M 很小）时 8x8 的块数被 ceil(M/128) 砍掉，
 *      块数不够铺机器，老路由照样选 8x8（实测 64x1024x1024 该走 shared）。
 *   3. 阈值里**完全没有「这张卡有几个 SM」**：块数不够铺满大卡时没有任何补救，
 *      于是大卡上大片 SM 闲着 —— 这就是「别的卡只有 10~20%」的来源。
 *
 * 方案：选型换成**时间模型**，所有量都是设备相对的：
 *      块数   blocks = ceil(M/tile) * ceil(N/tile)
 *      波数   waves  = ceil(blocks / (SM数 * 每SM常驻block数))
 *      预测   t(k)   = waves * (K * c_k + s_k)
 *      取 t 最小的那个 kernel。
 *   c_k / s_k = 「每 K 单位每 block 的毫秒」与「每 block 固定开销」，
 *   由**本机自标定**解出来（gpu_calibrate：探测时现测 256/512/1024 三个方形尺寸）。
 *   SM 数问驱动（cuDeviceGetAttribute），每 SM 驻留数问驱动
 *   （cuOccupancyMaxActiveBlocksPerMultiprocessor，问不到就按寄存器数估）。
 *   所以换卡不用改代码，路由自己会重算。
 *
 * 标定方法与验收（脚本 _gpuroutefit.py，数据 _gpucal_out.csv）：
 *   相对误差加权最小二乘拟合，在 1060 上 20 个实测形状里选出的 kernel
 *   与实测最优**全部一致**，最大损失 1.0%；老阈值同期最差损失 45%。
 *
 * 已知边界（别把它当万能钥匙）：
 *   · c/s 是按方形、大 K 标的；M 很小或 K 很小时模型偏差会变大。
 *   · 模型只决定「选哪个 kernel」，**不改变「机器能不能被填满」**。
 *     大卡上中等尺寸矩阵的块数天生不够（GPU_DESIGN.md 第四跳有定量分析），
 *     那要靠 split-K 或更小 tile 的新 kernel，路由救不了。
 */
#define GPU_NKERN 3

typedef struct {
    const char *name;
    CUfunction  fn;
    unsigned    tile;      /* tile 边长（grid 步进也是它） */
    int         bpsm;      /* 每 SM 常驻 block 数 */
    double      c_ms;      /* 每 K 单位每 block 的毫秒 */
    double      s_ms;      /* 每 block 的固定开销（毫秒） */
} GpuKern;

/* 1060 实测标定值（GTX 1060 6GB / CC 6.1）。自标定成功时会被本机实测值替换。 */
static GpuKern g_kg[GPU_NKERN] = {
    { "sgemm",        NULL,  64, 3, 0.000233, -0.00968 },
    { "sgemm_shared", NULL,  64, 4, 0.000182, -0.00275 },
    { "sgemm_8x8",    NULL, 128, 2, 0.000243, -0.00539 },
};
/* 静态兜底值：自标定失败时按这张表恢复 */
static const double GPU_C_FALLBACK[GPU_NKERN][2] = {
    { 0.000233, -0.00968 },
    { 0.000182, -0.00275 },
    { 0.000243, -0.00539 },
};

/* 建表 + 问每 SM 能驻留几个 block */
static void gpu_setup_kernels(void)
{
    int i, occ = 0, regs = 0, thr = 16 * 16;

    g_kg[0].fn = g_fn;
    g_kg[1].fn = g_fn_sh;
    g_kg[2].fn = g_fn_8x8;

    for (i = 0; i < GPU_NKERN; i++) {
        if (!g_kg[i].fn) { g_kg[i].bpsm = 1; continue; }
        if (p_cuOccupancyMaxActiveBlocks &&
            p_cuOccupancyMaxActiveBlocks(&occ, g_kg[i].fn, thr, 0) == 0 && occ > 0) {
            g_kg[i].bpsm = occ;      /* 驱动直接答「每 SM 几个 block」，最准 */
            continue;
        }
        /* 兜底：按寄存器数算。每 SM 寄存器文件 65536 是所有 CC>=3.0 的硬事实，
         * 实测与驱动回答一致（8x8 128 寄存器 -> 2，shared 64 -> 4，4x4 71 -> 3）。 */
        occ = 3;
        if (p_cuFuncGetAttribute &&
            p_cuFuncGetAttribute(&regs, 4 /*NUM_REGS*/, g_kg[i].fn) == 0 && regs > 0) {
            occ = 65536 / (regs * thr);
            if (occ < 1) occ = 1;
        }
        if (g_max_threads_sm > 0) {
            int t = g_max_threads_sm / thr;
            if (t > 0 && t < occ) occ = t;
        }
        g_kg[i].bpsm = occ;
    }
}

/* 选 kernel：预测时间最短者胜。返回表内下标；
 * 设备信息不全（g_sms 没问出来）时返回 -1，由调用方退回老阈值。 */
static int gpu_pick_kernel(int M, int N, int K)
{
    int    i, best = -1;
    double bt = 0;

    if (g_sms < 1)
        return -1;
    for (i = 0; i < GPU_NKERN; i++) {
        long long blocks, slots, waves;
        double   t;
        int      tile = (int)g_kg[i].tile;
        if (!g_kg[i].fn)
            continue;
        blocks = (long long)((M + tile - 1) / tile) *
                 (long long)((N + tile - 1) / tile);
        slots  = (long long)g_sms * (long long)(g_kg[i].bpsm > 0 ? g_kg[i].bpsm : 1);
        waves  = (blocks + slots - 1) / slots;
        if (waves < 1) waves = 1;
        t = (double)waves * ((double)K * g_kg[i].c_ms + g_kg[i].s_ms);
        if (best < 0 || t < bt) { best = i; bt = t; }
    }
    return best;
}

/* 测一个 kernel 在 NxNxN 上的耗时（CUDA event，多发几轮取最小摊掉启动开销）。
 * 口径与标定脚本 _gpucal.c 一致，换卡后标出来的常数才可比。 */
static int gpu_calib_time(int ki, int N, int K, CUdeviceptr dA, CUdeviceptr dB,
                          CUdeviceptr dC, double *out_ms)
{
    CUfunction f = g_kg[ki].fn;
    unsigned   tile = g_kg[ki].tile;
    unsigned   gx, gy;
    int        m = N, n = N, k = K;
    void      *params[] = { &dA, &dB, &dC, &m, &n, &k };
    void      *ev0 = NULL, *ev1 = NULL;
    double     best = 0;
    int        inner, rep, i;

    if (!f || !p_cuEventCreate || !p_cuEventRecord || !p_cuEventSynchronize ||
        !p_cuEventElapsedTime || !p_cuEventDestroy)
        return 0;
    if (p_cuEventCreate(&ev0, 0) != 0)
        return 0;
    if (p_cuEventCreate(&ev1, 0) != 0) { p_cuEventDestroy(ev0); return 0; }

    gx = (unsigned)((N + tile - 1) / tile);
    gy = gx;
    /* inner 取法与标定 harness 一致：连发摊掉每发启动开销 */
    inner = (int)(2000000.0 / (double)((size_t)N * N + 1));
    if (inner < 3) inner = 3;
    if (inner > 200) inner = 200;

    for (rep = 0; rep < 2; rep++) {
        float el = 0;
        if (p_cuLaunchKernel(f, gx, gy, 1, 16, 16, 1, 0, NULL, params, NULL) != 0)
            break;
        if (p_cuCtxSynchronize() != 0)
            break;
        if (p_cuEventRecord(ev0, NULL) != 0) break;
        for (i = 0; i < inner; i++) {
            if (p_cuLaunchKernel(f, gx, gy, 1, 16, 16, 1, 0, NULL, params, NULL) != 0)
                break;
        }
        if (p_cuEventRecord(ev1, NULL) != 0) break;
        if (p_cuEventSynchronize(ev1) != 0) break;
        if (p_cuEventElapsedTime(&el, ev0, ev1) != 0 || el <= 0) break;
        if (rep == 0 || el < best) best = el;   /* 取最小：最接近机器空闲时的真实速度 */
    }
    p_cuEventDestroy(ev0);
    p_cuEventDestroy(ev1);
    if (best <= 0)
        return 0;
    *out_ms = (double)best / (double)inner;
    return 1;
}

/* ─────────────── 开机自标定：在这张卡上现测三个 kernel 的时间常数 ───────────────
 * 模型里的 c/s 是 1060 上标定的，换卡不准（每 SM 算力、共享带宽、寄存器上限
 * 都不同）。这里在探测时现测 256/512/1024 三个方形尺寸，用与标定脚本同样的
 * 相对误差加权最小二乘解出 c/s，替换静态值。
 * **任何一步失败都不许影响探测**：全部兜底成「保留静态值」。 */
static void gpu_calibrate(void)
{
    static const int sizes[3] = { 256, 512, 1024 };
    CUdeviceptr dA = 0, dB = 0, dC = 0;
    float       *h = NULL;
    size_t       bytes = (size_t)1024 * 1024 * sizeof(float);
    int          i, ki;

    if (getenv("PYBOOK_GPU_NOCAL"))
        return;                             /* 调试用：跳过自标定 */
    if (g_sms < 1)
        return;
    if (!p_cuEventCreate || !p_cuEventRecord || !p_cuEventSynchronize ||
        !p_cuEventElapsedTime || !p_cuEventDestroy)
        return;
    if (!g_kg[0].fn && !g_kg[1].fn && !g_kg[2].fn)
        return;

    if (p_cuMemAlloc_v2(&dA, bytes) != 0) return;
    if (p_cuMemAlloc_v2(&dB, bytes) != 0) { p_cuMemFree_v2(dA); return; }
    if (p_cuMemAlloc_v2(&dC, bytes) != 0) {
        p_cuMemFree_v2(dA); p_cuMemFree_v2(dB); return;
    }
    h = (float *)malloc(bytes);
    if (!h) goto done;
    for (i = 0; i < 1024 * 1024; i++) h[i] = 1.0f;   /* 数据不影响耗时，但别留 NaN */
    if (p_cuMemcpyHtoD_v2(dA, h, bytes) != 0) goto done;
    if (p_cuMemcpyHtoD_v2(dB, h, bytes) != 0) goto done;

    for (ki = 0; ki < GPU_NKERN; ki++) {
        double a00 = 0, a01 = 0, a11 = 0, b0 = 0, b1 = 0;
        double det, c, s;
        int    got = 0, bad = 0;
        if (!g_kg[ki].fn)
            continue;
        for (i = 0; i < 3; i++) {
            double   ms, w, x0, x1;
            long long waves, slots, blocks;
            int      tile = (int)g_kg[ki].tile;
            if (!gpu_calib_time(ki, sizes[i], sizes[i], dA, dB, dC, &ms)) {
                bad = 1; break;
            }
            blocks = (long long)((sizes[i] + tile - 1) / tile) *
                     (long long)((sizes[i] + tile - 1) / tile);
            slots  = (long long)g_sms * (long long)(g_kg[ki].bpsm > 0 ? g_kg[ki].bpsm : 1);
            waves  = (blocks + slots - 1) / slots;
            if (waves < 1) waves = 1;
            w  = 1.0 / (ms * ms);              /* 相对误差加权 */
            x0 = (double)waves * sizes[i];
            x1 = (double)waves;
            a00 += w * x0 * x0; a01 += w * x0 * x1; a11 += w * x1 * x1;
            b0  += w * x0 * ms;  b1  += w * x1 * ms;
            got++;
        }
        if (bad || got < 2)
            continue;
        det = a00 * a11 - a01 * a01;
        if (det == 0)
            continue;
        c = (b0 * a11 - b1 * a01) / det;
        s = (a00 * b1 - a01 * b0) / det;
        /* 合理性闸门：离谱就丢弃，保留静态值（宁可不准也不能选错） */
        if (c > 0 && c < GPU_C_FALLBACK[ki][0] * 5.0 &&
            c > GPU_C_FALLBACK[ki][0] * 0.2 && s > -0.05 && s < 0.05) {
            g_kg[ki].c_ms = c;
            g_kg[ki].s_ms = s;
            g_calibrated = 1;
        }
    }
done:
    free(h);
    p_cuMemFree_v2(dA);
    p_cuMemFree_v2(dB);
    p_cuMemFree_v2(dC);
}

/* 路由计划（只读，供测试与诊断）：给 M/N/K，问会选哪个 kernel。
 * kernel_id: 0=sgemm 1=sgemm_shared 2=sgemm_8x8，-1 = 设备信息不全、退回老阈值。
 * blocks/waves 是选中那个 kernel 的块数与波数。 */
int gpu_route_plan(int M, int N, int K, int *kernel_id, int *blocks, int *waves)
{
    int ki = gpu_pick_kernel(M, N, K);
    if (kernel_id) *kernel_id = ki;
    if (blocks)   *blocks = 0;
    if (waves)    *waves = 0;
    if (ki < 0)
        return 0;
    if (blocks) {
        int tile = (int)g_kg[ki].tile;
        *blocks = ((M + tile - 1) / tile) * ((N + tile - 1) / tile);
    }
    if (waves) {
        int tile = (int)g_kg[ki].tile;
        long long b = (long long)((M + tile - 1) / tile) * ((N + tile - 1) / tile);
        long long slots = (long long)g_sms *
                          (long long)(g_kg[ki].bpsm > 0 ? g_kg[ki].bpsm : 1);
        long long w = (b + slots - 1) / slots;
        *waves = (int)(w < 1 ? 1 : w);
    }
    return 1;
}

''' + a8
    src = sub(src, a8, crlf(a8_new), "A8 第四跳模型整段")
    changed.append("A8")

    # ── A9: 前向声明（gpu_probe 在模型段之前要用这两个函数） ───────────
    a9 = "static SRWLOCK     g_lock = SRWLOCK_INIT;       /* 显存+暂存区共用，必须串行 */\n"
    a9_new = a9 + """/* 第四跳的模型段在文件后面，这里先声明（gpu_probe 里要用） */
static void gpu_setup_kernels(void);
static void gpu_calibrate(void);
"""
    src = sub(src, a9, crlf(a9_new), "A9 前向声明")
    changed.append("A9")

    write_atomic(SRC, src)
    print("pybook_gpu.c 补丁完成：", ",".join(changed))

# ── 头文件：加 gpu_route_plan 声明 ───────────────────────────────────
if "gpu_route_plan" in hdr:
    print("pybook_gpu.h 已有 gpu_route_plan，跳过。")
else:
    h1 = """int         gpu_sgemm_f32(const double *A, const double *B, double *C,
                          int M, int N, int K);
"""
    h1_new = h1 + """
/* 路由计划（只读，不改任何状态）：给定 M/N/K，问会选哪个 sgemm kernel。
 * kernel_id: 0=sgemm 1=sgemm_shared 2=sgemm_8x8；-1 = 设备信息不全（退回旧阈值）。
 * blocks/waves = 选中那个 kernel 的块数与波数（波数 = 块数 / (SM数 × 每SM驻留数)）。
 * 返回 1 = 有路由计划；0 = 退回旧阈值。供测试与诊断用。 */
int         gpu_route_plan(int M, int N, int K, int *kernel_id, int *blocks, int *waves);
"""
    hdr = sub(hdr, h1, crlf(h1_new), "H1 gpu_route_plan 声明")
    write_atomic(HDR, hdr)
    print("pybook_gpu.h 补丁完成：H1")
