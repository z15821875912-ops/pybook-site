# _patch_conv_prod.py —— 把新 conv2d 内核 + 修好的 pool 内核接进生产代码
#
# 动的东西：
#   pybook_gpu.c : PTX_BODY_CONV2D / PTX_BODY_POOL 换新；compile_conv 缓冲加大；
#                  gpu_conv2d_f32 重写（权重转置 + 越界 padding + 13 参数 + 新 grid + 输出尺寸）；
#                  gpu_pool_f32 补第 9 个参数（1/(KH*KW)）+ 换成分段重叠搬运
#   pybook_tb.c  : gpu_conv_try 的输出张量形状（原来漏了批次维，且和 CPU 路径形状不一致）
#
# 幂等：靠「新内容在不在」判断，不是靠锚点在不在（插入型改动里锚点会一直存在）。
# 行尾：pybook_gpu.c / pybook_tb.c 都是 CRLF，写回时按 CRLF 处理。
import io, os, sys

GPU = "pybook_gpu.c"
TB = "pybook_tb.c"
FRAG_CONV = "build_tmp/probe/_conv_final.cfrag"
FRAG_POOL = "build_tmp/probe/_pool_final.cfrag"


def read(path):
    return io.open(path, encoding="utf-8", newline="").read()


def write_atomic(path, text):
    tmp = path + ".tmpfix"
    with io.open(tmp, "w", encoding="utf-8", newline="") as f:
        f.write(text)
    os.replace(tmp, path)


def replace_once(text, old, new, tag):
    n = text.count(old)
    if n != 1:
        raise SystemExit("锚点 %s 命中 %d 次（应为 1）" % (tag, n))
    return text.replace(old, new)


def replace_span(text, start_marker, end_marker, new, tag):
    """把 [start_marker, end_marker] 之间的内容整段换掉（含 start，不含 end）。"""
    i = text.find(start_marker)
    if i < 0:
        raise SystemExit("找不到起点 %s" % tag)
    j = text.find(end_marker, i)
    if j < 0:
        raise SystemExit("找不到终点 %s" % tag)
    return text[:i] + new + text[j:]


def replace_to_end(text, start_marker, new, tag):
    """从 start_marker 一直换到文件末尾。"""
    i = text.find(start_marker)
    if i < 0:
        raise SystemExit("找不到起点 %s" % tag)
    return text[:i] + new


def crlf(s):
    return s.replace("\r\n", "\n").replace("\n", "\r\n")


frag_conv = io.open(FRAG_CONV, encoding="utf-8", newline="").read()
frag_pool = io.open(FRAG_POOL, encoding="utf-8", newline="").read()

# ── pybook_gpu.c ────────────────────────────────────────────────────────
g = read(GPU)
changed = []

if "p_OPAD" not in g:
    g = replace_span(g,
                     "static const char *PTX_BODY_CONV2D =",
                     "static const char *PTX_BODY_POOL =",
                     crlf(frag_conv) + "\r\n", "conv body")
    changed.append("conv body")
else:
    print("跳过：conv body 已是新版")

if ".visible .entry avgpool" not in g:
    g = replace_span(g,
                     "static const char *PTX_BODY_POOL =",
                     "static const char *PTX_VERSIONS[] = {",
                     crlf(frag_pool) + "\r\n", "pool body")
    changed.append("pool body")
else:
    print("跳过：pool body 已是新版")

if "char       img[32768];" in g:
    g = replace_once(g, "char       img[32768];", "char       img[65536];", "compile_conv buf")
    changed.append("compile_conv buf")

# gpu_conv2d_f32 是本文件最后一个函数：它前面是 gpu_pool_f32，所以区间只能换到文件末尾。
if "gpu_h2d_cast(x, g_dA, nx" not in g:
    new_conv = crlf('''/* conv2d 上卡：x/k 是 double 缓冲（F32 张量，值可被 float32 精确表示）。
 * 布局 x=(N,I,H,W) k=(O,I,KH,KW)；权重在宿主侧转置成 (I*KH*KW, OPAD)，oc 在最内维
 * ——核里要用 128 位向量载入权重，所以 OPAD 取 16 的倍数（顺带保证 16 字节对齐）。
 * out 写回 (N,O,OH,OW)。三缓冲池与 sgemm/conv 共用（need 取三者最大，持锁全程）。 */
int gpu_conv2d_f32(const double *x, const double *k, double *out,
                   int H, int W, int I, int O, int KH, int KW,
                   int OH, int OW, int S, int N)
{
    int      opad = (O + 15) / 16 * 16;               /* 权重行宽：16 的倍数，128 位载入要 16 字节对齐 */
    size_t   nx = (size_t)N * I * H * W;
    size_t   nk = (size_t)I * KH * KW * (size_t)opad;  /* 转置后的权重 */
    size_t   ko = (size_t)N * O * OH * OW;
    size_t   pad = (size_t)(32 * S * W + 32 * S + 64);/* 越界读兜底：核里不加谓词，靠这段 0 填 */
    size_t   need;
    CUresult r;
    int      ok = 0;

    g_err[0] = '\\0';
    if (!gpu_probe())
        return gpu_fail("GPU 没探测成功：%s", g_why);
    if (!g_fn_conv)
        return gpu_fail("conv2d 内核没编译出来（这单该降级 CPU，不该走到这）");

    need = (nx + pad) * sizeof(float);
    if (nk * sizeof(float) > need) need = nk * sizeof(float);
    if (ko * sizeof(float) > need) need = ko * sizeof(float);

    AcquireSRWLockExclusive(&g_lock);
    if (!ensure_bufs(need))        goto out;
    if (!ensure_host_bufs(need))   goto out;

    /* x 上卡：分段转换 + 异步搬运（与 sgemm 同款，让 double->float 和 PCIe 重叠） */
    if (!gpu_h2d_cast(x, g_dA, nx, (float *)g_hA)) goto out;
    /* 越界读兜底区：核里一块覆盖 32x32 个输出位置，最后一张图的读会越过图像末尾。
     * 这段只要「显存够大」就不会越界读（读到什么都不影响结果：那些 lane 不写回），
     * 但仍补一份 0，跟内核对拍台的行为保持一致。 */
    {
        float *px = (float *)g_hA;
        size_t i;
        for (i = 0; i < pad; i++) px[nx + i] = 0.0f;
        r = p_cuMemcpyHtoD_v2(g_dA + (CUdeviceptr)(nx * sizeof(float)),
                              (void *)(px + nx), pad * sizeof(float));
        if (r != 0) { gpu_fail("x 兜底区上卡失败：%s", cu_err(r)); goto out; }
    }
    /* 权重：宿主侧转置成 [kk][oc]（oc 在内维），核里才能用 128 位向量载入 */
    {
        float *pk = (float *)g_hB;
        size_t i, oc, kk;
        for (i = 0; i < nk; i++) pk[i] = 0.0f;
        for (oc = 0; oc < (size_t)O; oc++)
            for (kk = 0; kk < (size_t)I * KH * KW; kk++)
                pk[kk * (size_t)opad + oc] =
                    (float)k[oc * (size_t)I * (size_t)KH * (size_t)KW + kk];
        r = p_cuMemcpyHtoD_v2(g_dB, (void *)g_hB, nk * sizeof(float));
        if (r != 0) { gpu_fail("k 上卡失败：%s", cu_err(r)); goto out; }
    }
    {
        void *params[] = { &g_dA, &g_dB, &g_dC, &I, &H, &W, &O,
                           &KH, &KW, &S, &OH, &OW, &opad };
        unsigned gx = (unsigned)((OW + 31) / 32);
        unsigned gy = (unsigned)((OH + 31) / 32);
        unsigned gz = (unsigned)(N * ((O + 15) / 16));
        r = p_cuCtxSetCurrent(g_ctx);
        if (r != 0) { gpu_fail("切不回 CUDA context：%s", cu_err(r)); goto out; }
        r = p_cuLaunchKernel(g_fn_conv, gx, gy, gz, 16, 16, 1,
                             0, NULL, params, NULL);
        if (r != 0) { gpu_fail("conv kernel 启动失败：%s", cu_err(r)); goto out; }
        r = p_cuCtxSynchronize();
        if (r != 0) { gpu_fail("conv kernel 执行出错：%s", cu_err(r)); goto out; }
    }
    /* out 取回：分段搬运 + 转 double（同样重叠） */
    if (!gpu_d2h_cast(g_dC, (const float *)g_hC, out, ko)) goto out;
    ok = 1;
out:
    if (!ok && !g_err[0])
        snprintf(g_err, sizeof g_err, "未知原因");
    ReleaseSRWLockExclusive(&g_lock);
    return ok;
}
''')
    g = replace_to_end(g, "/* conv2d 上卡：x/k 是 double 缓冲", new_conv, "gpu_conv2d_f32")
    changed.append("gpu_conv2d_f32")
else:
    print("跳过：gpu_conv2d_f32 已是新版")

# pool：补第 9 个参数（1/(KH*KW)，avgpool 用），并把搬运换成分段重叠那套
if "&inv" not in g:
    old = crlf('''    {
        float *px = (float *)g_hA;
        size_t i;
        for (i = 0; i < kx; i++) px[i] = (float)x[i];
    }
    r = p_cuMemcpyHtoD_v2(g_dA, (void *)g_hA, kx * sizeof(float));
    if (r != 0) { gpu_fail("x 上卡失败：%s", cu_err(r)); goto out; }
''')
    new = crlf('''    /* x 上卡：分段转换 + 异步搬运（与 sgemm 同款） */
    if (!gpu_h2d_cast(x, g_dA, kx, (float *)g_hA)) goto out;
''')
    g = replace_once(g, old, new, "pool x 上卡")
    old = crlf('''    {
        void *params[] = { &g_dA, &g_dC, &W, &OH, &OW, &KH, &KW, &S };
''')
    new = crlf('''    {
        float   inv = 1.0f / (float)(KH * KW);   /* avgpool 用 */
        void *params[] = { &g_dA, &g_dC, &W, &OH, &OW, &KH, &KW, &S, &inv };
''')
    g = replace_once(g, old, new, "pool params")
    old = crlf('''    r = p_cuMemcpyDtoH_v2((void *)g_hC, g_dC, ko * sizeof(float));
    if (r != 0) { gpu_fail("out 下卡失败：%s", cu_err(r)); goto out; }
    {
        const float *pc = (const float *)g_hC;
        size_t i;
        for (i = 0; i < ko; i++) out[i] = (double)pc[i];
    }
''')
    new = crlf('''    /* out 取回：分段搬运 + 转 double（同样重叠） */
    if (!gpu_d2h_cast(g_dC, (const float *)g_hC, out, ko)) goto out;
''')
    g = replace_once(g, old, new, "pool out 下卡")
    changed.append("pool host")
else:
    print("跳过：pool 宿主侧已是新版")

if changed:
    write_atomic(GPU, g)
print("pybook_gpu.c 改了：%s" % (", ".join(changed) if changed else "无"))

# ── pybook_tb.c ─────────────────────────────────────────────────────────
t = read(TB)
changed = []

if "int       d[4];" not in t:
    old = crlf('''static int gpu_conv_try(Value x, Value k, Value *outp, const TbConv *c)
{
    RtTensor *tx = tens_of(x, "tb.conv2d"), *tk = tens_of(k, "tb.conv2d");
    RtTensor *to;
    int       d[2];
''')
    new = crlf('''static int gpu_conv_try(Value x, Value k, Value *outp, const TbConv *c)
{
    RtTensor *tx = tens_of(x, "tb.conv2d"), *tk = tens_of(k, "tb.conv2d");
    RtTensor *to;
    int       d[4];
''')
    t = replace_once(t, old, new, "gpu_conv_try d[]")
    changed.append("gpu_conv_try d[]")
else:
    print("跳过：gpu_conv_try 的 d[] 已是新版")

if "rt_tensor_new(4, d);" not in t:
    old = crlf('''    d[0] = c->O * c->OH;
    d[1] = c->OW;
    outp[0] = new_mat_p(d[0], d[1], TENSOR_F32);
    to = rt_as_tensor(outp[0]);''')
    new = crlf('''    /* 输出形状必须跟 CPU 路径完全一致：4 维输入给 4 维、3 维给 3 维、2 维给 2 维。
       （原来一律给 2 维 (O*OH, OW)：批次 > 1 时缓冲只有该要的 1/N，4 维输入的
         形状还跟 CPU 路径对不上，两条路给出的张量不是一回事。） */
    if (tx->ndim == 4) {
        d[0] = c->N; d[1] = c->O; d[2] = c->OH; d[3] = c->OW;
        outp[0] = rt_tensor_new(4, d);
    } else if (tx->ndim == 3) {
        d[0] = c->N; d[1] = c->O * c->OH; d[2] = c->OW;
        outp[0] = rt_tensor_new(3, d);
    } else {
        d[0] = c->O * c->OH;
        d[1] = c->OW;
        outp[0] = rt_tensor_new(2, d);
    }
    to = rt_as_tensor(outp[0]);''')
    t = replace_once(t, old, new, "gpu_conv_try out")
    changed.append("gpu_conv_try out")
else:
    print("跳过：gpu_conv_try 已是新版")
if changed:
    write_atomic(TB, t)
print("pybook_tb.c 改了：%s" % (", ".join(changed) if changed else "无"))
