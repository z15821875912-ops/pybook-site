"""从 RFC 8439 原文**机器提取** ChaCha20 测试向量，生成 pybook_crypto_vec.h。

为什么必须机器提取（这个项目里踩过两次坑）：
  1) 手抄 §2.4.2 的期望值时，把 114 字节明文对应成了 128 字节密文，
     差点把「实现是对的」误判成「实现有 bug」；
  2) 手抄 A.2 #3 的密钥多了一个字符（65 位而不是 64 位），cr_unhex 返回 -1
     我又没检查，于是拿上一轮残留的旧密钥继续算，输出一个「看起来有差别」的密文。

铁律：
  * 向量只能从原文提取，不许手抄；
  * 长度必须有自检（抄错时长度先炸，而不是等到算出来才发现不对）；
  * 解码函数的返回值**必须**检查（自测里的 HV() 宏就是干这个的）。

跑法：python 加密向量生成.py
      （需要能访问 https://www.rfc-editor.org/rfc/rfc8439.txt）
      生成后可以这样验：
        gcc -O2 -DLIB_SELF_TEST pybook_crypto.c -o crypto_test.exe -I. -lbcrypt
        crypto_test.exe
"""
import re
import sys
import urllib.request

RFC_URL = "https://www.rfc-editor.org/rfc/rfc8439.txt"
OUT = 'pybook_crypto_vec.h'

DUMP_RE = re.compile(r'^\s+(\d{3})\s+((?:[0-9a-f]{2} ){1,16})')

HEADER = """/* 自动生成，勿手改。
 *
 * 来源：RFC 8439（ChaCha20 and Poly1305 for IETF Protocols）原文，
 *       由仓库根目录的「加密向量生成.py」从原文**机器提取**。
 *
 * 为什么必须是机器提取（踩过两次坑）：
 *   1) 手抄 §2.4.2 的期望值时把 114 字节明文对应成 128 字节密文，
 *      差点把「好实现」误判成「坏实现」；
 *   2) 手抄 A.2 #3 的密钥多了一个字符（65 位而不是 64 位），cr_unhex 返回 -1
 *      却没检查，于是拿残留的旧密钥继续算，输出一个「看起来有差别」的密文。
 *
 * 重新生成：python 加密向量生成.py（需要能访问 rfc-editor.org）
 */
#ifndef PYBOOK_CRYPTO_VEC_H
#define PYBOOK_CRYPTO_VEC_H
"""


def fetch():
    req = urllib.request.Request(RFC_URL, headers={'User-Agent': 'pybook-crypto-test/1.0'})
    with urllib.request.urlopen(req, timeout=30) as r:
        return r.read().decode('utf-8', 'replace')


def grab(text, marker, occurrence=1):
    """抓 marker 之后的十六进制转储，返回 bytes。"""
    pos = -1
    for _ in range(occurrence):
        pos = text.index(marker, pos + 1)
    out = bytearray()
    for line in text[pos + len(marker):].split('\n'):
        m = DUMP_RE.match(line)
        if m:
            out += bytes.fromhex(m.group(2).replace(' ', ''))
        elif out:
            break
    return bytes(out)


def counter_of(text, pattern):
    m = re.search(pattern, text)
    return int(m.group(1)) if m else None


def main():
    txt = fetch()
    vecs = {}
    ctr = {}

    # ---------- §2.4.2 太阳镜例子 ----------
    # 密钥是连续序列（00:01:…:1f），随机数也短，这里写死 —— 连续序列抄不错；
    # 而且这条向量本来就通过着。
    vecs['SUN_KEY'] = bytes(range(32))
    vecs['SUN_NONCE'] = bytes([0, 0, 0, 0, 0, 0, 0, 0x4a, 0, 0, 0, 0])
    vecs['SUN_PLAIN'] = grab(txt, 'Plaintext Sunscreen:', 1)
    vecs['SUN_CT'] = grab(txt, 'Ciphertext Sunscreen:', 1)
    ctr['SUN'] = 1

    # ---------- A.1 四个块函数向量 ----------
    i_a1 = txt.rindex('A.1.  The ChaCha20 Block Functions')
    i_a2 = txt.rindex('A.2.  ChaCha20 Encryption')
    a1 = txt[i_a1:i_a2]
    segs = re.split(r'Test Vector #(\d):', a1)
    # segs = [前言, '1', 正文1, '2', 正文2, ...] → 奇数下标是编号，偶数是正文
    for i in range(1, len(segs), 2):
        n = segs[i]
        body = segs[i + 1]
        vecs['A1_%s_KEY' % n] = grab(body, 'Key:', 1)
        vecs['A1_%s_NONCE' % n] = grab(body, 'Nonce:', 1)
        vecs['A1_%s_KS' % n] = grab(body, 'Keystream:', 1)
        c = counter_of(body, r'Block Counter\s*=\s*(\d+)')
        if c is None:
            print('A.1 #%s 找不到 Block Counter' % n)
            sys.exit(1)
        ctr['A1_%s' % n] = c

    # ---------- A.2 #3：多块、跨块计数器递增 ----------
    i_a3 = txt.rindex('A.3.  Poly1305 Message Authentication Code')
    a2 = txt[i_a2:i_a3]
    seg = a2[a2.index('Test Vector #3:'):]
    vecs['A23_KEY'] = grab(seg, 'Key:', 1)
    vecs['A23_NONCE'] = grab(seg, 'Nonce:', 1)
    vecs['A23_PLAIN'] = grab(seg, 'Plaintext:', 1)
    vecs['A23_CT'] = grab(seg, 'Ciphertext:', 1)
    c = counter_of(seg, r'Initial Block Counter\s*=\s*(\d+)')
    if c is None:
        print('A.2 #3 找不到 Initial Block Counter')
        sys.exit(1)
    ctr['A23'] = c

    # ---------- 长度自检（抄错时这里就会炸） ----------
    expect = {
        'SUN_KEY': 32, 'SUN_NONCE': 12, 'SUN_PLAIN': 114, 'SUN_CT': 114,
        'A1_1_KEY': 32, 'A1_1_NONCE': 12, 'A1_1_KS': 64,
        'A1_2_KEY': 32, 'A1_2_NONCE': 12, 'A1_2_KS': 64,
        'A1_3_KEY': 32, 'A1_3_NONCE': 12, 'A1_3_KS': 64,
        'A1_4_KEY': 32, 'A1_4_NONCE': 12, 'A1_4_KS': 64,
        'A1_5_KEY': 32, 'A1_5_NONCE': 12, 'A1_5_KS': 64,
        'A23_KEY': 32, 'A23_NONCE': 12, 'A23_PLAIN': 127, 'A23_CT': 127,
    }
    bad = False
    for k, n in expect.items():
        got = len(vecs.get(k, b''))
        if got != n:
            print('长度不对 %-10s 期望 %d 实得 %d' % (k, n, got))
            bad = True
    if bad:
        sys.exit(1)

    with open(OUT, 'w', encoding='utf-8', newline='\n') as f:
        f.write(HEADER)
        f.write('\n')
        for k in sorted(vecs):
            f.write('#define VEC_%-12s "%s"\n' % (k, vecs[k].hex()))
        f.write('\n')
        for k in sorted(ctr):
            f.write('#define CTR_%-12s %d\n' % (k, ctr[k]))
        f.write('\n#endif\n')
    print('已生成', OUT)
    for k in sorted(vecs):
        print('  %-12s %3d 字节  %s' % (k, len(vecs[k]), vecs[k].hex()[:40]))
    for k in sorted(ctr):
        print('  计数器 %-10s = %d' % (k, ctr[k]))


if __name__ == '__main__':
    main()
