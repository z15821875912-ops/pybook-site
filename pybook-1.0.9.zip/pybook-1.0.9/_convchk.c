/* _convchk.c —— conv2d 生产入口的正确性对拍 + 性能测量
 *
 * 两件事：
 *   1. 正确性：gpu_conv2d_f32 的结果必须与 CPU 参考一致（f32 容差）。
 *      CPU 参考按 PYbook 的实际布局：
 *        x   = (N, I, H, W)
 *        k   = (O, I, KH, KW)
 *        out = (N, O, OH, OW)
 *   2. 性能：FLOPs = 2*N*O*OH*OW*I*KH*KW，除以耗时得 TFLOPS，
 *      再除以本卡 FP32 峰值（4.73 TFLOPS @ GTX 1060）得利用率。
 *
 * 用法：_convchk.exe [形状个数]
 * 形状：N H W I O KH KW S
 * 编译：gcc _convchk.c pybook_gpu.c -o _convchk.exe -O2 -I. -lwinmm -lm
 */
#include "pybook_gpu.h"
#include "pybook_rt.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <windows.h>

void rt_die(const char *fmt, ...) { (void)fmt; fputs("rt_die(stub)\n", stderr); exit(2); }
Value rt_str(const char *s) { (void)s; Value v; memset(&v, 0, sizeof v); return v; }

#define PEAK_TFLOPS 4.73        /* GTX 1060 6GB / CC 6.1 实测 FP32 峰值 */

static unsigned g_seed = 4242u;
static double frand(void)
{
    g_seed = g_seed * 1103515245u + 12345u;
    return (double)((g_seed >> 9) & 0xFFFF) / 65536.0 - 0.5;
}

static double now_s(void)
{
    static LARGE_INTEGER freq = {0};
    LARGE_INTEGER t;
    if (freq.QuadPart == 0) QueryPerformanceFrequency(&freq);
    QueryPerformanceCounter(&t);
    return (double)t.QuadPart / (double)freq.QuadPart;
}

static void cpu_conv(const double *x, const double *k, double *out,
                     int N, int H, int W, int I, int O,
                     int KH, int KW, int OH, int OW, int S)
{
    int n, oc, oh, ow, ii, ih, iw;
    for (n = 0; n < N; n++)
        for (oc = 0; oc < O; oc++)
            for (oh = 0; oh < OH; oh++)
                for (ow = 0; ow < OW; ow++) {
                    double s = 0.0;
                    for (ii = 0; ii < I; ii++)
                        for (ih = 0; ih < KH; ih++)
                            for (iw = 0; iw < KW; iw++)
                                s += x[(((size_t)n * I + ii) * H + (oh * S + ih)) * W
                                       + (ow * S + iw)]
                                   * k[(((size_t)oc * I + ii) * KH + ih) * KW + iw];
                    out[(((size_t)n * O + oc) * OH + oh) * OW + ow] = s;
                }
}

int main(int argc, char **argv)
{
    /* 默认几组：单图小、批量、单图大 */
    static const int def[][8] = {
        /* N  H    W    I  O  KH KW S */
        {  1,  28,  28,  1,  8,  3, 3, 1 },
        {  1,  32,  32,  3, 16,  3, 3, 1 },
        {  1, 384, 384,  4,  4,  8, 8, 2 },
        {  8,  28,  28,  1,  8,  3, 3, 1 },
        { 64,  32,  32,  3, 16,  3, 3, 1 },
        {  1,  64,  64, 16, 32,  3, 3, 1 },
        /* 边界形状：O 不是 16 的倍数 / 奇数尺寸 / 5x5 核 / 1x1 核 / 大步长 */
        {  2,  56,  56, 32, 64,  3, 3, 1 },
        {  1,  17,  23,  3,  7,  3, 3, 1 },
        {  3,  13,  13,  5, 11,  5, 5, 1 },
        {  1,  32,  32,  8, 16,  1, 1, 1 },
        {  2,  64,  64,  4,  9,  3, 3, 2 },
        {  1,  28,  28,  1,  1,  3, 3, 1 },
        /* KK = I*KH*KW = 576 > 384：共享内存放不下，走老内核 conv2d（回退路径） */
        {  1,  32,  32, 64, 32,  3, 3, 1 },
    };
    int nsh = (int)(sizeof(def) / sizeof(def[0]));
    int i, bad = 0;

    if (!gpu_available()) { printf("GPU 不可用：%s\n", gpu_device_name()); return 1; }
    printf("设备：%s   驱动 %d\n\n", gpu_device_name(), gpu_driver_version());
    printf("%-28s | %10s | %10s | %9s | %9s | %s\n",
           "形状 N H W I O KH KW S", "端到端ms", "内核ms", "端到端%", "内核%", "正确性");
    printf("----------------------------+----------+----------+---------+---------+--------\n");

    for (i = 0; i < nsh; i++) {
        int N = def[i][0], H = def[i][1], W = def[i][2], I = def[i][3];
        int O = def[i][4], KH = def[i][5], KW = def[i][6], S = def[i][7];
        int OH = (H - KH) / S + 1, OW = (W - KW) / S + 1;
        size_t nx = (size_t)N * I * H * W, nk = (size_t)O * I * KH * KW;
        size_t no = (size_t)N * O * OH * OW;
        double *x = (double *)malloc(nx * sizeof(double));
        double *k = (double *)malloc(nk * sizeof(double));
        double *y = (double *)malloc(no * sizeof(double));
        double *ref = (double *)malloc(no * sizeof(double));
        size_t j;
        double t0, t1, best = 1e30, tf, flops, kms = 0, ktf;
        int    rep, over = 0, rep2;
        double maxrel = 0;

        if (!x || !k || !y || !ref) { printf("host 内存不足\n"); return 1; }
        for (j = 0; j < nx; j++) x[j] = frand();
        for (j = 0; j < nk; j++) k[j] = frand();
        /* 关键：生产路径会把 double 输入先舍入成 float32 再上卡，
           所以 CPU 参考必须用「同样舍入过」的输入，否则量到的是输入量化误差，
           不是内核算错了（反向验证：得能区分「谁算的」）。 */
        for (j = 0; j < nx; j++) x[j] = (double)(float)x[j];
        for (j = 0; j < nk; j++) k[j] = (double)(float)k[j];
        memset(y, 0, no * sizeof(double));
        cpu_conv(x, k, ref, N, H, W, I, O, KH, KW, OH, OW, S);

        /* 第一遍：不开追踪，量「端到端」（含主机侧转换 + PCIe + 内核 + 取回）。
           追踪钩子自己也要建/销 event，会往端到端里塞几十微秒，不能混进来。 */
        putenv("PYBOOK_GPU_TRACE");
        for (rep = 0; rep < 3; rep++) {
            double tt;
            t0 = now_s();
            if (!gpu_conv2d_f32(x, k, y, H, W, I, O, KH, KW, OH, OW, S, N)) {
                printf("gpu_conv2d_f32 失败：%s\n", gpu_last_error());
                return 1;
            }
            t1 = now_s();
            tt = t1 - t0;
            if (tt < best) best = tt;
        }
        /* 第二遍：挂上追踪，让生产路径自己量内核那段时间 */
        putenv("PYBOOK_GPU_TRACE=1");
        if (!gpu_conv2d_f32(x, k, y, H, W, I, O, KH, KW, OH, OW, S, N)) {
            printf("gpu_conv2d_f32 失败：%s\n", gpu_last_error());
            return 1;
        }
        kms = gpu_last_kernel_ms();
        putenv("PYBOOK_GPU_TRACE");

        for (j = 0; j < no; j += (no > 20000 ? no / 20000 : 1)) {
            double d = fabs(y[j] - ref[j]);
            double mag = 0;
            int oc = (int)(j / ((size_t)OH * OW)) % O;
            int rem = (int)(j % ((size_t)OH * OW));
            int oh = rem / OW, ow = rem % OW;
            int ii, ih, iw, nn = (int)(j / ((size_t)O * OH * OW));
            for (ii = 0; ii < I; ii++)
                for (ih = 0; ih < KH; ih++)
                    for (iw = 0; iw < KW; iw++)
                        /* 分母要用「每项乘积的绝对值之和」：只给 x 取绝对值的话，
                           k 的正负会互相抵消，累加出接近 0 的分母，
                           把 1e-8 量级的 f32 噪声放大成 1e-4 的假错。 */
                        mag += fabs(x[(((size_t)nn * I + ii) * H + (oh * S + ih)) * W
                                      + (ow * S + iw)]
                                   * k[(((size_t)oc * I + ii) * KH + ih) * KW + iw]);
            {
                double rel = (mag > 0) ? d / mag : d;
                if (rel > maxrel) maxrel = rel;
                if (rel > 1e-5) {
                    over++;
                    if (over <= 10)
                        printf("      错: n=%d oc=%d oh=%d ow=%d got=%.6g ref=%.6g\n",
                               nn, oc, oh, ow, y[j], ref[j]);
                }
            }        }
        if (over) bad++;

        flops = 2.0 * (double)N * (double)O * (double)OH * (double)OW
              * (double)I * (double)KH * (double)KW;
        tf = flops / best / 1e12;                 /* best 是秒 */
        ktf = (kms > 0) ? flops / (kms * 1e-3) / 1e12 : 0.0;
        printf("%3d %3dx%-3d I%-2d O%-2d %dx%d S%d | %10.3f | %10.3f | %8.1f%% | %8.1f%% | %s (maxrel %.2e)\n",
               N, H, W, I, O, KH, KW, S, best * 1000.0, kms,
               tf / PEAK_TFLOPS * 100.0, ktf / PEAK_TFLOPS * 100.0,
               over ? "错!" : "对", maxrel);
        fflush(stdout);
        free(x); free(k); free(y); free(ref);
        (void)rep2;
    }
    printf("\n超差形状：%d / %d\n", bad, nsh);
    return 0;
}
