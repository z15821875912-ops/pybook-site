﻿# _gpuroutefit.py —— 从标定 CSV 拟合 sgemm 路由模型，并验证「选谁」是否复现实测最优
#
# 模型变体（都只用 1060 实测数据拟合常数）：
#   V1: t = waves * (K*c + s)
#   V2: t = waves * K*c + s              （启动开销只算一次）
#   V3: t = waves * (K*c + s) * tailfix  （尾波不满，按并发度补偿）
#
# 拟合目标：**相对误差**加权（w = 1/obs^2）——
# 不加权的话大 N 点的绝对误差会淹没小 N 点，模型的排序能力就废了。
#
# 为什么用「时间」而不是「效率」：三个 kernel 算的是同一个 C，
# 谁的预测时间短谁就赢，直接可比。
import math, io

SM = 10
KERNELS = {
    #  name : (tile, blocks_per_sm)
    "4x4": (64, 3),
    "sh":  (64, 4),
    "8x8": (128, 2),
}

rows = []
with open("_gpucal_out.csv", "rb") as fb:
    head = fb.read(4)
enc = "utf-16" if head[:2] in (b"\xff\xfe", b"\xfe\xff") else "utf-8"
with io.open("_gpucal_out.csv", "r", encoding=enc, errors="replace") as f:
    for line in f:
        l = line.strip()
        if not l or l.startswith("#") or l.startswith("kernel"):
            continue
        p = l.split(",")
        if len(p) < 11:
            continue
        rows.append(dict(kern=p[0], M=int(p[1]), N=int(p[2]), K=int(p[3]),
                         ms=float(p[7]), tf=float(p[8]), pct=float(p[9])))


def wave_info(kern, M, N):
    """返回 (波数, 每波满槽 block 数, 尾波 block 数)"""
    T, bpsm = KERNELS[kern]
    blocks = ((M + T - 1) // T) * ((N + T - 1) // T)
    slots = SM * bpsm
    waves = max(1, math.ceil(blocks / slots))
    last = blocks - (waves - 1) * slots
    return waves, slots, last


def predict(kern, M, N, K, c, s, variant):
    waves, slots, last = wave_info(kern, M, N)
    if variant == 1:
        return waves * (K * c + s)
    if variant == 2:
        return waves * K * c + s
    if variant == 3:
        # 尾波不满时，每个 SM 上的 block 数变少 -> 并发不够 -> 每个 block 更慢
        _, bpsm = KERNELS[kern]
        conc_last = max(1.0, math.ceil(last / SM))
        pen = min(2.0, bpsm / conc_last)
        return ((waves - 1) + pen) * (K * c + s)
    raise ValueError(variant)


def fit(kern, variant, square_only=True):
    """相对误差加权的最小二乘，解 2x2 正规方程。"""
    a00 = a01 = a11 = b0 = b1 = 0.0
    for r in rows:
        if r["kern"] != kern:
            continue
        if square_only and not (r["M"] == r["N"] == r["K"]):
            continue
        y = r["ms"]
        w = 1.0 / (y * y)
        waves, slots, last = wave_info(kern, r["M"], r["N"])
        if variant == 1:
            x = [waves * r["K"], waves]
        elif variant == 2:
            x = [waves * r["K"], 1.0]
        else:
            _, bpsm = KERNELS[kern]
            conc_last = max(1.0, math.ceil(last / SM))
            pen = min(2.0, bpsm / conc_last)
            x = [(waves - 1 + pen) * r["K"], (waves - 1 + pen)]
        a00 += w * x[0] * x[0]; a01 += w * x[0] * x[1]; a11 += w * x[1] * x[1]
        b0 += w * x[0] * y;          b1 += w * x[1] * y
    det = a00 * a11 - a01 * a01
    if det == 0:
        return None
    c = (b0 * a11 - b1 * a01) / det
    s = (a00 * b1 - a01 * b0) / det
    return c, s


shapes, seen = [], set()
for r in rows:
    key = (r["M"], r["N"], r["K"])
    if key not in seen:
        seen.add(key)
        shapes.append(key)


def evaluate(variant, square_only=True):
    fitted = {k: fit(k, variant, square_only) for k in KERNELS}
    bad, losses = 0, []
    detail = []
    for (M, N, K) in shapes:
        picks = {}
        for k in KERNELS:
            c, s = fitted[k]
            picks[k] = predict(k, M, N, K, c, s, variant)
        pick = min(picks, key=lambda k: picks[k])
        obs = {}
        for row in rows:
            if (row["M"], row["N"], row["K"]) == (M, N, K):
                obs[row["kern"]] = row["ms"]
        real = min(obs, key=lambda k: obs[k])
        loss = (obs[pick] / obs[real] - 1.0) * 100
        losses.append(loss)
        if pick != real and loss > 3.0:
            bad += 1
        detail.append((M, N, K, pick, real, loss, obs))
    return fitted, bad, losses, detail


for variant in (1, 2, 3):
    fitted, bad, losses, detail = evaluate(variant)
    print("=" * 92)
    print("V%d  fit:" % variant)
    for k in KERNELS:
        c, s = fitted[k]
        errs = []
        for row in rows:
            if row["kern"] != k:
                continue
            p = predict(k, row["M"], row["N"], row["K"], c, s, variant)
            errs.append(abs(p / row["ms"] - 1.0) * 100)
        errs.sort()
        print("   %-4s c=%.6f ms/K  s=%.5f ms   |pred/obs| median %.1f%%  max %.1f%%"
              % (k, c, s, errs[len(errs)//2], max(errs)))
    losses.sort()
    print("   wrong pick(>3%%): %d / %d   worst loss %+.1f%%  median loss %+.1f%%"
          % (bad, len(shapes), max(losses), losses[len(losses)//2]))
    for (M, N, K, pick, real, loss, obs) in detail:
        if pick != real and loss > 1.0:
            print("      MISS %5dx%-5dx%-5d model=%s real=%s loss=%+.1f%%  %s"
                  % (M, N, K, pick, real, loss,
                     "  ".join("%s=%.4f" % (kk, obs[kk]) for kk in sorted(obs))))

print()
print("=" * 92)
print("V3 detail table")
fitted, bad, losses, detail = evaluate(3)
for (M, N, K, pick, real, loss, obs) in detail:
    print("%5dx%-5dx%-5d | %4s %4s | %+6.1f%% | %s"
          % (M, N, K, pick, real, loss,
             "  ".join("%s=%.4f" % (kk, obs[kk]) for kk in sorted(obs))))
