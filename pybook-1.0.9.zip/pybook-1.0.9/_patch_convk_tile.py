# _patch_convk_tile.py —— 让内核台 _convk.c 从 PTX 头注释里读真实分块尺寸。
#
# 为什么要改：原来台子把 tile 写死成 32×32、TO 写死成环境变量给的 8。
# 生成器一改参数（TO/TSY/TSX/BX/BY），网格和权重行宽就跟着变，
# 台子算出来的 gx/gy/gz 跟内核对不上 → 表现为「部分形状结果错」，
# 很容易被误判成「这个参数组合不可用」。
#
# 修法：PTX 的头注释里本来就写着
#   "// block = 16x16 = 256 threads; one block covers 16 oc x 32 oh x 32 ow."
# 直接从这段话里解析出 BX/BY/TO/TILE_OH/TILE_OW，解析不到才退回旧默认值。
# 这样台子跟生成器永远同源，扫参才有意义。
import io, os

P = "_convk.c"

d = io.open(P, encoding="utf-8", newline="").read()
changed = []

# ① 加一个解析函数
if "static int parse_tile" not in d:
    anchor = "int main(int argc, char **argv)\n{"
    if d.count(anchor) != 1:
        raise SystemExit("锚点 main 命中 %d 次" % d.count(anchor))
    helper = '''/* 从 PTX 头注释里读出真实分块尺寸：
 *   "// block = 16x16 = 256 threads; one block covers 16 oc x 32 oh x 32 ow."
 * 台子跟生成器同源，扫参时不会因为写死的 32 而算错网格。
 * 读不到返回 0，调用方退回默认值。 */
static int parse_tile(const char *ptx, int *bx, int *by, int *to, int *toh, int *tow)
{
    const char *p = strstr(ptx, "// block = ");
    int a = 0, b = 0, c = 0, e = 0, f = 0, g = 0;
    if (!p) return 0;
    if (sscanf(p, "// block = %d x %d = %d threads; one block covers %d oc x %d oh x %d ow.",
               &a, &b, &c, &e, &f, &g) != 6) return 0;
    if (a < 1 || b < 1 || e < 1 || f < 1 || g < 1) return 0;
    *bx = a; *by = b; *to = e; *toh = f; *tow = g;
    return 1;
}

'''
    d = d.replace(anchor, helper + anchor)
    changed.append("parse_tile")

# ② TO 改成从 PTX 读（环境变量只当兜底）
old = """    int TO = 8;                       /* 每线程几个输出通道（内核参数） */
    {
        const char *ev = getenv("PYBOOK_CONV_TO");
        if (ev && *ev) TO = atoi(ev);
    }
"""
new = """    int TO = 8;                       /* 每线程几个输出通道（内核参数） */
    int TILE_OH = 32, TILE_OW = 32;   /* 一块覆盖多少输出行/列 */
    {
        const char *ev = getenv("PYBOOK_CONV_TO");
        if (ev && *ev) TO = atoi(ev);
    }
"""
if d.count(old) != 1:
    raise SystemExit("锚点 ② 命中 %d 次" % d.count(old))
d = d.replace(old, new)
changed.append("TO 开关")

# ③ 读完 PTX 之后用头注释覆盖 TO / tile
old = """    p_cuFuncGetAttribute(&maxreg, 4 /*CU_FUNC_ATTRIBUTE_NUM_REGS*/, fn);
    printf("内核 conv2d 载入 OK，占用寄存器 %d\\n\\n", maxreg);
"""
new = """    p_cuFuncGetAttribute(&maxreg, 4 /*CU_FUNC_ATTRIBUTE_NUM_REGS*/, fn);
    {
        /* 头注释里有真实分块：block = BXxBY，覆盖 TO oc x TILE_OH oh x TILE_OW ow。
         * 台子跟生成器同源 —— 写死 32 的话一改参数就算错网格（表现为「部分形状错」）。 */
        int bx = 0, by = 0, to = 0, toh = 0, tow = 0;
        if (parse_tile(ptx, &bx, &by, &to, &toh, &tow)) {
            TO = to; TILE_OH = toh; TILE_OW = tow;
            printf("分块：block %dx%d，每线程 %d 通道，一块覆盖 %d oh x %d ow\\n",
                   bx, by, TO, TILE_OH, TILE_OW);
        } else {
            printf("分块：读不到头注释，用默认 TO=%d tile %dx%d\\n", TO, TILE_OH, TILE_OW);
        }
    }
    printf("内核 conv2d 载入 OK，占用寄存器 %d\\n\\n", maxreg);
"""
if d.count(old) != 1:
    raise SystemExit("锚点 ③ 命中 %d 次" % d.count(old))
d = d.replace(old, new)
changed.append("读分块")

# ④ pad / grid 用真实 tile
old = """        size_t pad = (size_t)(32 * S * W + 32 * S + 64);   /* 越界读兜底 */"""
new = """        size_t pad = (size_t)((size_t)TILE_OW * S * W + (size_t)TILE_OH * S + 64);
        /* 越界读兜底：一块覆盖 TILE_OH x TILE_OW 个输出位置，
           最坏会越过图像末尾 TILE_OH*S 行 + TILE_OW*S 个元素。 */"""
if d.count(old) != 1:
    raise SystemExit("锚点 ④ 命中 %d 次" % d.count(old))
d = d.replace(old, new)
changed.append("pad")

old = """        gx = (unsigned)((OW + 31) / 32);
        gy = (unsigned)((OH + 31) / 32);"""
new = """        gx = (unsigned)((OW + TILE_OW - 1) / TILE_OW);
        gy = (unsigned)((OH + TILE_OH - 1) / TILE_OH);"""
if d.count(old) != 1:
    raise SystemExit("锚点 ⑤ 命中 %d 次" % d.count(old))
d = d.replace(old, new)
changed.append("grid")

tmp = P + ".tmpfix"
with io.open(tmp, "w", encoding="utf-8", newline="") as f:
    f.write(d)
os.replace(tmp, P)
print("_convk.c 改了：%s" % (", ".join(changed)))
