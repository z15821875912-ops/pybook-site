"""MainCentre —— PYbook 团队入驻 / 权限闸门（零依赖，纯标准库）。

在任意文件夹跑 `pybktl maincentre start`（团长开启）：
- 团长 = 开启者，拥有全部权限：审批文件 / 设开发者密码 / 派身份 / 开自由模式；
- 团长可留下开发者密码 + 对应身份（角色）；他人 `join <密码>` 即获得团长给它的身份；
- 文件进文件夹需团长审批（团长可开自由模式自动放行）；
- 临时进入者（未登录者，没输密码）干啥都进审批队列；
- 用完 `pybktl maincentre stop` 关机（杀 watcher + 撤标记；团队配置 state.json 保留，下次 start 直接复话）。

状态落盘（与 watcher 解耦，和 lookaround/hottable 同套路）：
- `.maincentre`      开启标记（隐藏，start 创建、stop 删除；里面存 watcher PID 供强杀防呆）
- `.maincentre.d/`   治理状态目录：state.json（团长/密码哈希/角色映射/审批/审计）+ watch.log
"""

import os
import sys
import time
import json
import signal
import hashlib
import getpass
import socket
import subprocess
from datetime import datetime

MARKER = ".maincentre"          # 开启标记（隐藏）
STATEDIR = ".maincentre.d"      # 治理状态目录（隐藏）
POLL_S = 5                      # watcher 轮询秒数
IGNORE_DIRS = {".git", "build", "__pycache__", STATEDIR, "node_modules",
               "exe_cache", "shots", "_backup", "_session_backup", "_team",
               "_归档", "共享历史", "out"}
IGNORE_FILES = {MARKER, "pyvm.exe"}

ROLE_GUEST = "未登录者"          # 没输密码的临时进入者
ROLE_CMD = "团长"               # commander


# ---------------------------------------------------------------------------
# 基础工具
# ---------------------------------------------------------------------------
def _now():
    return time.strftime("%Y-%m-%d %H:%M:%S")


_IDENTITY_OVERRIDE = None       # 由 pybktl 的 `maincentre --as <名字>` 设置：显式声明操作者身份
_AUTH = None                     # 由 pybktl 的 `maincentre --auth <团长令牌>` 设置：团长凭证（不靠 OS 账号）


def _identity():
    """当前操作者身份。默认 OS 级 user@host；若命令行给了 --as（_IDENTITY_OVERRIDE）则用它。

    加 --as 是为了让同一台机器、同一个 OS 账号下的多个 AI / 会话（OS 身份相同）
    也能各自区分身份、各自走审批（否则别人的 AI 会因 user@host 相同被当成团长）。
    """
    if _IDENTITY_OVERRIDE:
        return _IDENTITY_OVERRIDE
    try:
        return "%s@%s" % (getpass.getuser(), socket.gethostname())
    except Exception:
        return "unknown@unknown"


def _hash(pw, salt):
    return hashlib.sha256(("%s:%s" % (pw, salt)).encode("utf-8")).hexdigest()


def _state_path(root):
    return os.path.join(root, STATEDIR, "state.json")


def _log_path(root):
    return os.path.join(root, STATEDIR, "watch.log")


def _load_state(root):
    p = _state_path(root)
    if not os.path.exists(p):
        return None
    try:
        with open(p, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return None


def _save_state(root, st):
    d = os.path.join(root, STATEDIR)
    os.makedirs(d, exist_ok=True)
    with open(_state_path(root), "w", encoding="utf-8") as f:
        json.dump(st, f, ensure_ascii=False, indent=2)


def _write_token_file(root, cmdpw):
    """把团长令牌明文落盘到 .maincentre.d/commander_token.txt，方便团长本人查看。

    注意：这是「给本人看的便利文件」，不是安全边界——同一 OS 账号下的别的 AI 若被你
    告知此文件/令牌，它就能当团长。本工具的目的是「避免开发者 AI 因账号相同而误当团长」，
    不是防恶意进程。要收紧就别把令牌给它。
    """
    try:
        with open(os.path.join(root, STATEDIR, "commander_token.txt"), "w", encoding="utf-8") as f:
            f.write("# MainCentre 团长令牌（仅团长本人/团长 AI 看，切勿交给开发者 AI）\n")
            f.write("%s\n" % cmdpw)
    except OSError:
        pass


def _audit(root, who, action, detail=""):
    st = _load_state(root) or {}
    st.setdefault("audit", [])
    st["audit"].append({"at": _now(), "who": who, "action": action, "detail": detail})
    if len(st["audit"]) > 500:
        st["audit"] = st["audit"][-500:]
    _save_state(root, st)
    # 顺便写一份人读日志
    try:
        with open(os.path.join(root, STATEDIR, "maincentre.log"), "a", encoding="utf-8") as f:
            f.write("[%s] %s | %s | %s\n" % (_now(), who, action, detail))
    except OSError:
        pass


# ---------------------------------------------------------------------------
# 位置解析（沿目录向上找 .maincentre 标记；标记在但进程已死则自动清理）
# ---------------------------------------------------------------------------
def _pid_alive(pid):
    if pid <= 0:
        return False
    if os.name == "nt":
        try:
            import ctypes
            h = ctypes.windll.kernel32.OpenProcess(0x1000, False, pid)  # QUERY_LIMITED
            if h:
                ctypes.windll.kernel32.CloseHandle(h)
                return True
            return False
        except Exception:
            return True
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def _watcher_pid(root):
    try:
        with open(os.path.join(root, MARKER), "r") as f:
            return int((f.read().strip() or "0")) or None
    except (OSError, ValueError):
        return None


def find_root(start=None, reap=False):
    """向上找最近的 .maincentre 目录。

    闸门靠 state.json 驱动，不依赖 watcher 常驻——所以「标记在」即视为「开着」，
    即便 watcher 进程已不在（被回收/重启），status/request/approve 等仍靠现场
    reconcile 工作。reap 默认关；start 内部会自行处理「残留标记」再复话。
    """
    cands = []
    if start:
        cands.append(os.path.abspath(start))
    cands.append(os.path.abspath(os.getcwd()))
    for c in cands:
        d = c
        while True:
            mp = os.path.join(d, MARKER)
            if os.path.exists(mp):
                return d
            parent = os.path.dirname(d)
            if parent == d:
                break
            d = parent
    return None


# ---------------------------------------------------------------------------
# 角色 / 权限
# ---------------------------------------------------------------------------
def _is_commander(st):
    """团长身份只靠「团长令牌」证明，绝不看 OS 账号。

    同机多 AI 用同一个 OS 账号（都是 zhuli@msi）时，只有持令牌者才是团长；
    没令牌的、或只拿了开发者密码的，统统不是团长。这样开发者 AI 才不会因账号相同
    被误判成团长。
    """
    if not st:
        return False
    tok = _AUTH
    if not tok:
        return False
    ch = st.get("commander_pw_hash")
    if not ch:
        return False
    return _hash(tok, st.get("salt", "")) == ch


def _current_role(st):
    """当前操作者在本文件夹里的身份。"""
    if _is_commander(st):
        return ROLE_CMD
    me = _identity()
    for m in st.get("members", []):
        if m.get("id") == me:
            return m.get("role") or "开发者"
    return ROLE_GUEST


# ---------------------------------------------------------------------------
# 文件扫描（供 watcher 用）
# ---------------------------------------------------------------------------
def _scan_files(root):
    out = set()
    for dp, dns, fns in os.walk(root):
        dns[:] = [d for d in dns if d not in IGNORE_DIRS and not d.startswith(".")]
        for fn in fns:
            if fn in IGNORE_FILES or fn.startswith("."):
                continue
            rel = os.path.relpath(os.path.join(dp, fn), root)
            out.add(rel.replace(os.sep, "/"))
    return out


def _reconcile(root, st):
    """把文件夹里「还没在审批表里的文件」补进审批表（pending，自由模式则直接 approved）。

    这样即使 watcher 没在跑，跑 status / request / approve 时也会现场把新文件补成待审，
    闸门不依赖常驻进程也能用。返回是否有变动。"""
    files = _scan_files(root)
    approvals = st.setdefault("approvals", {})
    changed = False
    free = st.get("free_mode")
    for rel in files:
        if rel in approvals:
            continue
        approvals[rel] = {"status": "approved" if free else "pending",
                          "by": "自由模式" if free else "扫描", "at": _now()}
        changed = True
    return changed


def _require_root():
    root = find_root()
    if not root:
        sys.stderr.write("该文件夹未开启 MainCentre：请先 `pybktl maincentre start`（团长开启）。\n")
        return None
    return root


# ---------------------------------------------------------------------------
# 命令：团长开启
# ---------------------------------------------------------------------------
def cmd_start(args):
    root = os.path.abspath(os.getcwd())
    # 已在运行？
    if os.path.exists(os.path.join(root, MARKER)):
        pid = _watcher_pid(root)
        if pid and _pid_alive(pid):
            st = _load_state(root)
            if st and _is_commander(st):
                print("MainCentre 已在本文件夹开启，团长就是您（%s）。" % _identity())
            else:
                print("MainCentre 已在本文件夹开启，团长是 %s。" % (st.get("commander_id") if st else "未知"))
            return 0
        else:
            # 残留标记，清理后重开
            try:
                os.remove(os.path.join(root, MARKER))
            except OSError:
                pass

    # 全新 vs 复话：已有团队配置则保留（团长/密码/角色/成员），只重拉 watcher
    existing = _load_state(root)
    if existing:
        # 旧配置可能没有团长令牌：自动补一个并打印，避免把自己锁在门外
        migrated = False
        if not existing.get("commander_pw_hash"):
            cmdpw = os.urandom(8).hex()
            existing["commander_pw_hash"] = _hash(cmdpw, existing.get("salt", ""))
            _save_state(root, existing)
            _write_token_file(root, cmdpw)
            migrated = True
            print("⚠️ 旧配置无团长令牌，已自动生成（务必保存）：%s" % cmdpw)
        # 复话必须持令牌（迁移那次免验证，否则我们自己都进不去）
        if not migrated and not _is_commander(existing):
            print("该文件夹的 MainCentre 已存在，需用团长令牌复话：")
            print("  pybktl maincentre start --auth <团长令牌>")
            return 1
        st = existing
        print("从已有团队配置复话（团长：%s）。" % st["commander_id"])
    else:
        os.makedirs(os.path.join(root, STATEDIR), exist_ok=True)
        salt = os.urandom(8).hex()
        cmdpw = os.urandom(8).hex()          # 团长令牌（随机，仅本次打印 + 落盘到 .maincentre.d/commander_token.txt）
        st = {
            "version": 1,
            "commander_id": _identity(),
            "started_at": _now(),
            "salt": salt,
            "commander_pw_hash": _hash(cmdpw, salt),
            "dev_password_hash": None,
            "roles": {},            # sha(pw:salt) -> role
            "members": [],          # [{id, role, name, joined}]
            "free_mode": False,
            "approvals": {},        # rel_path -> {status, by, at}
            "audit": [],
        }
        _write_token_file(root, cmdpw)
        print("🔑 团长令牌（审批/关机/设密码必须带 --auth）：%s" % cmdpw)

    # 基线：当前所有文件标记为已通过（只补「还没在审批表」的，不覆盖已有审批状态）
    for rel in _scan_files(root):
        if rel not in st.setdefault("approvals", {}):
            st["approvals"][rel] = {"status": "approved", "by": "基线", "at": _now()}
    _save_state(root, st)
    _audit(root, st["commander_id"], "start", "团长开启/复话 MainCentre")

    # 写标记（先占位，spawn 后写真 PID）
    marker = os.path.join(root, MARKER)
    with open(marker, "w") as f:
        f.write("0")

    # 拉起后台 watcher
    pybktl = os.path.join(os.path.dirname(os.path.abspath(__file__)), "pybktl.py")
    cmd = [sys.executable, pybktl, "maincentre", "_watch", root]
    flags = 0
    if os.name == "nt":
        flags = 0x00000008 | 0x08000000  # DETACHED_PROCESS | CREATE_NO_WINDOW
    logf = open(_log_path(root), "a", encoding="utf-8")
    try:
        proc = subprocess.Popen(cmd, stdout=logf, stderr=logf,
                                stdin=subprocess.DEVNULL, creationflags=flags)
        pid = proc.pid
    except Exception as e:
        logf.close()
        os.remove(marker)
        sys.stderr.write("拉起后台 watcher 失败：%s\n" % e)
        return 1
    with open(marker, "w") as f:
        f.write(str(pid))
    logf.close()

    print("MainCentre 已开启（团长：%s）。" % st["commander_id"])
    print("  - 后台 watcher PID=%d 在盯文件夹，新文件会进审批队列。" % pid)
    print("  - 团长操作（approve/stop/setpwd/grant/freemode/setcmdpwd）必须带 --auth <团长令牌>。")
    print("  - 团长可：setpwd 留开发者密码 / grant 派身份 / approve 审批 / freemode 开关自由模式。")
    print("  - 他人：join <密码> --as <名字> 获得身份；request <文件> 提交审批。")
    print("  - 用完 `pybktl maincentre stop --auth <令牌>` 关机。")
    return 0


# ---------------------------------------------------------------------------
# 命令：关机
# ---------------------------------------------------------------------------
def cmd_stop(args):
    root = find_root()
    if not root:
        print("该文件夹未开启 MainCentre，无需关机。")
        return 0
    pid = _watcher_pid(root)
    if pid:
        killed = False
        try:
            os.kill(pid, signal.SIGTERM)
            killed = True
        except Exception:
            pass
        if not killed:
            try:
                subprocess.run(["taskkill", "/PID", str(pid), "/F", "/T"],
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            except Exception:
                pass
    try:
        os.remove(os.path.join(root, MARKER))
    except OSError:
        pass
    st = _load_state(root)
    who = st.get("commander_id") if st else _identity()
    _audit(root, who, "stop", "团长关机 MainCentre")
    print("已关机：watcher 已停止、开启标记已撤。团队配置（state.json）保留，下次 start 直接复话。")
    return 0


# ---------------------------------------------------------------------------
# 命令：团长设开发者密码（可带默认身份）
# ---------------------------------------------------------------------------
def cmd_setpwd(args):
    root = _require_root()
    if not root:
        return 1
    st = _load_state(root)
    if not _is_commander(st):
        sys.stderr.write("只有团长能设开发者密码（您当前身份：%s）。\n" % _current_role(st))
        return 1
    role = args.role or "开发者"
    h = _hash(args.password, st["salt"])
    st["dev_password_hash"] = h
    st["roles"][h] = role
    _save_state(root, st)
    _audit(root, _identity(), "setpwd", "设开发者密码（默认身份=%s）" % role)
    print("已留下开发者密码，默认身份=%s。他人用 `join <密码>` 即可获得该身份。" % role)
    return 0


# ---------------------------------------------------------------------------
# 命令：团长轮换自身令牌（--auth 旧令牌 + <新令牌>）
# ---------------------------------------------------------------------------
def cmd_setcmdpwd(args):
    root = _require_root()
    if not root:
        return 1
    st = _load_state(root)
    if not _is_commander(st):
        sys.stderr.write("只有团长能换团长令牌（您当前身份：%s）。需先 --auth <旧令牌>。\n" % _current_role(st))
        return 1
    cmdpw = args.password
    st["commander_pw_hash"] = _hash(cmdpw, st["salt"])
    _save_state(root, st)
    _write_token_file(root, cmdpw)
    _audit(root, st["commander_id"], "setcmdpwd", "团长轮换令牌")
    print("已轮换团长令牌（审批/关机请改用新令牌）：%s" % cmdpw)
    return 0


# ---------------------------------------------------------------------------
# 命令：团长派身份（密码 -> 角色）
# ---------------------------------------------------------------------------
def cmd_grant(args):
    root = _require_root()
    if not root:
        return 1
    st = _load_state(root)
    if not _is_commander(st):
        sys.stderr.write("只有团长能派身份（您当前身份：%s）。\n" % _current_role(st))
        return 1
    h = _hash(args.password, st["salt"])
    st["roles"][h] = args.role
    _save_state(root, st)
    _audit(root, _identity(), "grant", "派身份 %s 给某密码" % args.role)
    print("已把身份「%s」绑定到该密码。" % args.role)
    return 0


# ---------------------------------------------------------------------------
# 命令：他人输入密码获得身份
# ---------------------------------------------------------------------------
def cmd_join(args):
    root = _require_root()
    if not root:
        return 1
    st = _load_state(root)
    h = _hash(args.password, st["salt"])
    role = st.get("roles", {}).get(h)
    if not role:
        print("密码不匹配，您作为【%s】进入（干啥都需团长审批）。" % ROLE_GUEST)
        return 0
    me = _identity()
    members = st.setdefault("members", [])
    found = False
    for m in members:
        if m.get("id") == me:
            m["role"] = role
            m["name"] = args.name or m.get("name") or me
            found = True
            break
    if not found:
        members.append({"id": me, "role": role, "name": args.name or me, "joined": _now()})
    _save_state(root, st)
    _audit(root, me, "join", "凭密码获得身份 %s" % role)
    print("身份核验通过，您现在是【%s】（%s）。" % (role, args.name or me))
    return 0


# ---------------------------------------------------------------------------
# 命令：提交文件进文件夹（审批）
# ---------------------------------------------------------------------------
def cmd_request(args):
    root = _require_root()
    if not root:
        return 1
    st = _load_state(root)
    if _reconcile(root, st):
        _save_state(root, st)
    rel = os.path.relpath(os.path.abspath(args.file), root).replace(os.sep, "/")
    role = _current_role(st)
    approvals = st.setdefault("approvals", {})
    if rel in approvals and approvals[rel]["status"] == "approved":
        print("文件 %s 已是通过状态，无需重复提交。" % rel)
        return 0
    if _is_commander(st):
        # 团长干啥都行：直接通过
        approvals[rel] = {"status": "approved", "by": ROLE_CMD, "at": _now()}
        _save_state(root, st)
        _audit(root, _identity(), "request", "团长直接放行 %s" % rel)
        print("团长身份，文件 %s 直接通过。" % rel)
    else:
        approvals[rel] = {"status": "pending", "by": role, "at": _now()}
        _save_state(root, st)
        _audit(root, _identity(), "request", "%s 提交 %s 待审批" % (role, rel))
        print("已把文件 %s 提交审批（身份：%s）。团长 `approve %s` 即可放行。" % (rel, role, rel))
    return 0


# ---------------------------------------------------------------------------
# 命令：团长审批 / 驳回
# ---------------------------------------------------------------------------
def cmd_approve(args):
    root = _require_root()
    if not root:
        return 1
    st = _load_state(root)
    if not _is_commander(st):
        sys.stderr.write("只有团长能审批（您当前身份：%s）。\n" % _current_role(st))
        return 1
    if _reconcile(root, st):
        _save_state(root, st)
    for f in args.file:
        rel = f.replace(os.sep, "/")
        st.setdefault("approvals", {})[rel] = {"status": "approved", "by": ROLE_CMD, "at": _now()}
        _audit(root, _identity(), "approve", "放行 %s" % rel)
        print("已放行：%s" % rel)
    _save_state(root, st)
    return 0


def cmd_reject(args):
    root = _require_root()
    if not root:
        return 1
    st = _load_state(root)
    if not _is_commander(st):
        sys.stderr.write("只有团长能驳回（您当前身份：%s）。\n" % _current_role(st))
        return 1
    if _reconcile(root, st):
        _save_state(root, st)
    for f in args.file:
        rel = f.replace(os.sep, "/")
        st.setdefault("approvals", {})[rel] = {"status": "rejected", "by": ROLE_CMD, "at": _now()}
        _audit(root, _identity(), "reject", "驳回 %s" % rel)
        print("已驳回：%s" % rel)
    _save_state(root, st)
    return 0


# ---------------------------------------------------------------------------
# 命令：自由模式
# ---------------------------------------------------------------------------
def cmd_freemode(args):
    root = _require_root()
    if not root:
        return 1
    st = _load_state(root)
    if not _is_commander(st):
        sys.stderr.write("只有团长能切自由模式（您当前身份：%s）。\n" % _current_role(st))
        return 1
    on = args.mode.lower() in ("on", "1", "true", "开", "yes")
    st["free_mode"] = on
    _save_state(root, st)
    _audit(root, _identity(), "freemode", "自由模式=%s" % on)
    print("自由模式已%s：新文件%s自动放行。" % ("开启" if on else "关闭",
          "将" if on else "仍需团长审批"))
    return 0


# ---------------------------------------------------------------------------
# 命令：状态
# ---------------------------------------------------------------------------
def cmd_status(args):
    root = find_root()
    if not root:
        print("该文件夹未开启 MainCentre。团长先跑 `pybktl maincentre start`。")
        return 0
    st = _load_state(root)
    if _reconcile(root, st):
        _save_state(root, st)
    print("== MainCentre 状态（%s）==" % root)
    print("团长：%s" % st.get("commander_id"))
    print("自由模式：%s" % ("开" if st.get("free_mode") else "关"))
    print("开发者密码：%s" % ("已设" if st.get("dev_password_hash") else "未设"))
    print("已派身份数：%d" % len(st.get("roles", {})))
    print("入驻成员：%s" % (", ".join("%s(%s)" % (m.get("name"), m.get("role"))
                                        for m in st.get("members", [])) or "（无）"))
    print("您当前身份：%s" % _current_role(st))
    approvals = st.get("approvals", {})
    pending = [k for k, v in approvals.items() if v.get("status") == "pending"]
    rejected = [k for k, v in approvals.items() if v.get("status") == "rejected"]
    approved = [k for k, v in approvals.items() if v.get("status") == "approved"]
    print("文件审批：通过 %d / 待审 %d / 驳回 %d" % (len(approved), len(pending), len(rejected)))
    if pending:
        print("待团长审批：")
        for k in pending:
            print("   - %s（提交人：%s）" % (k, approvals[k].get("by")))
    return 0


# ---------------------------------------------------------------------------
# 内部：后台轮询（由 start 拉起，不要手动调）
# ---------------------------------------------------------------------------
def cmd_watch(args):
    root = args.root
    while True:
        try:
            st = _load_state(root)
            if st is None:
                break  # state 没了，退出
            files = _scan_files(root)
            approvals = st.setdefault("approvals", {})
            changed = False
            free = st.get("free_mode")
            for rel in files:
                if rel in approvals:
                    continue
                if free:
                    approvals[rel] = {"status": "approved", "by": "自由模式", "at": _now()}
                else:
                    approvals[rel] = {"status": "pending", "by": "watcher", "at": _now()}
                changed = True
            if changed:
                _save_state(root, st)
            time.sleep(POLL_S)
        except KeyboardInterrupt:
            break
        except Exception:
            time.sleep(POLL_S)
    return 0
