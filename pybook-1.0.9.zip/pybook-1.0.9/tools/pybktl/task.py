# -*- coding: utf-8 -*-
"""task —— 团队任务流转 v2：指派/认领/优先级/改派/评论/过期提醒（人可直接读改的 任务.md）。

大团队版命令面：
    pybktl task add "描述" [--owner 张三] [--due 2026-10-30] [--p1]      登记（--p1 紧急）
    pybktl task list [--owner 张三] [--all] [--p1] [--overdue]           列表（多维过滤+过期标记）
    pybktl task done <编号>                                              完成
    pybktl task take <编号>                                              认领（owner 改成自己）
    pybktl task give <编号> 张三                                         指派/改派
    pybktl task pri <编号> p1|p2|p3                                      调优先级
    pybktl task note <编号> "进展说明"                                    追加评论（↳ 行，锚定任务）
    pybktl task rm <编号>                                                删除（含评论一并删）
    pybktl task who                                                      谁手上有什么（按人聚合+P1/过期统计）

编号规则：FIFO 稳定编号（先登记的编号小）；每次 list 按未完成顺序重算。

存储 = 项目根的 任务.md，一行一条、人能直接读改（共享盘/git 都可见）：

    - [ ] 2026-10-24 张三 [P1]（截止 2026-10-30）：Boss 二阶段台词
      ↳ 10-25 李四：台词初稿已过半
    - [x] 2026-10-23 李四：修碰撞穿墙

作者默认 PYBOOK_AUTHOR > USERNAME。编号按「未完成任务」显示顺序（每次 list 重算）。
"""
import argparse
import datetime
import json
import os
import re

TASK_MD = "任务.md"
_PRI_TAG = {"p1": "[P1]", "p2": "[P2]", "p3": "[P3]"}


def out(m=""):
    print(m)


def err(m):
    print(m)


def _author():
    """操作者身份，优先级：PYBOOK_AUTHOR > maincentre 登录身份 > OS 用户名。

    maincentre 打通：.maincentre.d/身份.json 存着 join 得到的身份
    （maincentre --as 也写它），task 全命令自动采用——
    "你在 maincentre 是谁" = "你在任务里是谁"。"""
    env = os.environ.get("PYBOOK_AUTHOR")
    if env:
        return env
    try:
        mc = os.path.join(".maincentre.d", "身份.json")
        if os.path.isfile(mc):
            with open(mc, encoding="utf-8") as fh:
                who = json.load(fh).get("当前")
            if who:
                return who
    except Exception:
        pass
    return os.environ.get("USERNAME") or "未知"


def _today():
    return datetime.date.today().isoformat()


def _read():
    if os.path.isfile(TASK_MD):
        return open(TASK_MD, encoding="utf-8").read().split("\n")
    return ["# 团队任务", ""]


def _write(lines):
    open(TASK_MD, "w", encoding="utf-8", newline="").write("\n".join(lines))


def _open_indexes(lines):
    """未完成任务的行号列表（显示顺序 = 编号顺序）。"""
    return [i for i, l in enumerate(lines) if l.strip().startswith("- [ ]")]


def _parse_meta(line):
    """从任务行里抠出 (日期, 认领人, 优先级, 截止)。"""
    # 认领人段允许插优先级标记：`王五 [P1]：` —— 名字=冒号前的第一个词
    m = re.search(r"(\d{4}-\d{2}-\d{2})\s+([^：\[]+?)\s*(?:\[P[123]\])?\s*：", line)
    date, owner = (m.group(1), m.group(2)) if m else ("", "")
    pri = ""
    mp = re.search(r"\[?(P[123])\]?", line)
    if mp:
        pri = mp.group(1)
    due = ""
    md = re.search(r"（截止 (\d{4}-\d{2}-\d{2})）", line)
    if md:
        due = md.group(1)
    return date, owner, pri, due


def _is_overdue(line):
    _, _, _, due = _parse_meta(line)
    if not due:
        return False
    try:
        return datetime.date.fromisoformat(due) < datetime.date.today()
    except ValueError:
        return False


def _rebuild_line(line, owner=None, pri=None, due_keep=True):
    """就地改任务行的认领人/优先级，其余文本保留。"""
    date, old_owner, old_pri, due = _parse_meta(line)
    new_owner = owner if owner is not None else old_owner
    new_pri = pri if pri is not None else old_pri
    # 去掉旧 [Px] 标记与旧「认领人：」段，按规范顺序重组
    body = re.sub(r"\s*\[P[123]\]", "", line)
    body = re.sub(r"^\s*- \[.\]\s*", "", body)
    body = re.sub(r"^\d{4}-\d{2}-\d{2}\s+", "", body)
    body = re.sub(r"^[^：]{1,40}(\s*\[P[123]\])?：", "", body, count=1)
    head = f"- [ ] {_today()} {new_owner}"
    if new_pri:
        tag = new_pri if new_pri.startswith("[") else f"[{new_pri}]"
        head += f" {tag}"
    head += "："
    return head + body.strip()


def _note_lines_after(lines, idx):
    """任务行的评论行（↳ 开头）到下一个任务行为止。"""
    out = []
    for j in range(idx + 1, len(lines)):
        if lines[j].strip().startswith("- [") or lines[j].strip().startswith("#"):
            break
        if lines[j].strip().startswith("↳"):
            out.append(j)
        elif lines[j].strip() == "":
            continue
        else:
            break
    return out


def _fmt_line(line, idx_no, total_open):
    """列表展示：加过期标记。"""
    mark = " ⚠过期" if _is_overdue(line) else ""
    return f"  #{idx_no}  {line.strip()[6:]}{mark}"


def cmd_add(args):
    text = " ".join(args.text or []).strip()
    if not text:
        err('用法: pybktl task add "任务描述" [--owner 张三] [--due 2026-10-30] [--p1]')
        return 2
    owner = args.owner or _author()
    pri = _PRI_TAG.get(args.pri, "") if args.pri else ""
    parts = f"- [ ] {_today()} {owner} {pri}：{text}".replace(" ：", "：")
    if args.due:
        parts += f"（截止 {args.due}）"
    lines = _read()
    idx = _section_insert(lines)
    lines.insert(idx, parts)
    _write(lines)
    n = len(_open_indexes(lines))
    out(f"✓ 任务 #{n} 已登记给 {owner}" + (f" {pri}" if pri else "") + f"：{text}"
        + (f"（截止 {args.due}）" if args.due else ""))
    return 0


def _section_insert(lines):
    """任务条目插到任务区末尾（FIFO：先登记的编号小，顺序稳定）。

    任务区 = 最后一条任务/评论行之后；没标题就建档。"""
    last = None
    for i, l in enumerate(lines):
        t = l.strip()
        if t.startswith("- [") or t.startswith("↳"):
            last = i
    if last is not None:
        return last + 1
    for i, l in enumerate(lines):
        if l.strip().startswith("#"):
            return i + 2 if i + 2 <= len(lines) else len(lines)
    return len(lines)


def cmd_list(args):
    lines = _read()
    open_idx = _open_indexes(lines)
    shown = 0
    for n, i in enumerate(open_idx, 1):
        _, owner, pri, _d = _parse_meta(lines[i])
        if args.owner and owner != args.owner:
            continue
        if args.p1 and pri != "P1":
            continue
        if args.overdue and not _is_overdue(lines[i]):
            continue
        shown += 1
        out(_fmt_line(lines[i], n, len(open_idx)))
        for j in _note_lines_after(lines, i):
            out(f"      {lines[j].strip()}")
    if args.all:
        out("  -- 已完成 --")
        for l in lines:
            if l.strip().startswith("- [x]"):
                out(f"  ✓ {l.strip()[6:]}")
    if not shown and not args.all:
        out("· 没有未完成任务（--all 看已完成）")
        return 0
    over = sum(1 for i in open_idx if _is_overdue(lines[i]))
    tail = f"（未完 {len(open_idx)} 条"
    if over:
        tail += f"，⚠ {over} 条过期"
    tail += "；完成 done / 认领 take / 指派 give / 评论 note）"
    out(tail)
    return 0


def _pick(args):
    """done/take/give/pri/note/rm 共用的编号解析。返回 (行号, 任务行) 或 (None, None)。"""
    lines = _read()
    open_idx = _open_indexes(lines)
    n = args.idx
    if n < 1 or n > len(open_idx):
        err(f"✗ 没有第 {n} 号未完成任务（当前 {len(open_idx)} 条）")
        return None, None, None
    return lines, open_idx[n - 1], n


def cmd_done(args):
    lines, i, n = _pick(args)
    if lines is None:
        return 1
    lines[i] = lines[i].replace("- [ ]", "- [x]", 1)
    _write(lines)
    out(f"✓ 已完成 #{n}：{lines[i].strip()[6:]}")
    return 0


def cmd_take(args):
    lines, i, n = _pick(args)
    if lines is None:
        return 1
    me = args.owner or _author()
    lines[i] = _rebuild_line(lines[i], owner=me)
    _write(lines)
    out(f"✓ #{n} 已认领 → {me}：{lines[i].strip()[6:]}")
    return 0


def cmd_give(args):
    lines, i, n = _pick(args)
    if lines is None:
        return 1
    if not args.who:
        err("用法: pybktl task give <编号> 张三")
        return 2
    lines[i] = _rebuild_line(lines[i], owner=args.who)
    _write(lines)
    out(f"✓ #{n} 已指派给 {args.who}：{lines[i].strip()[6:]}")
    return 0


def cmd_pri(args):
    lines, i, n = _pick(args)
    if lines is None:
        return 1
    if args.level not in _PRI_TAG:
        err("用法: pybktl task pri <编号> p1|p2|p3（p1 最紧）")
        return 2
    lines[i] = _rebuild_line(lines[i], pri=_PRI_TAG[args.level])
    _write(lines)
    out(f"✓ #{n} 优先级 → {_PRI_TAG[args.level]}：{lines[i].strip()[6:]}")
    return 0


def cmd_note(args):
    lines, i, n = _pick(args)
    if lines is None:
        return 1
    text = " ".join(args.text or []).strip()
    if not text:
        err('用法: pybktl task note <编号> "进展说明"')
        return 2
    # 插到该任务的评论区末尾（下一个任务行/标题/EOF 之前）
    note_idx = i + 1
    notes = _note_lines_after(lines, i)
    if notes:
        note_idx = notes[-1] + 1
    me = _author()
    lines.insert(note_idx, f"  ↳ {datetime.date.today().isoformat()[5:]} {me}：{text}")
    _write(lines)
    out(f"✓ #{n} 已记录：{text}")
    return 0


def cmd_rm(args):
    lines, i, n = _pick(args)
    if lines is None:
        return 1
    gone = lines[i].strip()[6:]
    notes = _note_lines_after(lines, i)
    for j in reversed(notes):
        del lines[j]
    del lines[i]
    _write(lines)
    out(f"✗ 已删除 #{n}：{gone}")
    return 0



def _deps_of(line):
    """行内 [D:编号,编号] 依赖标记 -> 编号列表。"""
    m = re.search(r"\[D:([0-9,\s]+)\]", line)
    if not m:
        return []
    return [int(x) for x in m.group(1).split(',') if x.strip()]


def _mile_of(line):
    m = re.search(r"\[M:([^\]]+)\]", line)
    return m.group(1).strip() if m else ""


def cmd_dep(args):
    """task dep <编号> <依赖编号,...>：声明前置任务（行内 [D:..] 标记）。"""
    lines, i, n = _pick(args)
    if lines is None:
        return 1
    raw = args.deps if isinstance(args.deps, str) else ",".join(str(x) for x in args.deps)
    deps = []
    for tok in raw.replace(",", " ").split():
        try:
            v = int(tok)
        except ValueError:
            continue
        if v != n and v not in deps:
            deps.append(v)
    if not deps:
        err("用法: pybktl task dep <编号> <依赖编号>[,依赖编号...]（不能依赖自己）")
        return 2
    line = re.sub(r"\s*\[D:[0-9,\s]+\]", "", lines[i])
    lines[i] = line.rstrip() + " [D:" + ",".join(str(d) for d in deps) + "]"
    _write(lines)
    out(f"✓ #{n} 依赖 → {deps}（前置完成前不建议开工）")
    return 0


def cmd_mile(args):
    if isinstance(args.idx, str) and args.idx.isdigit():
        args.idx = int(args.idx)
    """task mile <编号> <里程碑名> / mile list。"""
    if args.idx == "list" or args.idx is None:
        lines = _read()
        open_idx = _open_indexes(lines)
        miles = {}
        for i in open_idx:
            m = _mile_of(lines[i])
            if m:
                miles.setdefault(m, []).append(lines[i])
        if not miles:
            out("· 没有里程碑任务（mile <编号> <名字>）")
            return 0
        for m in sorted(miles, key=str):
            out(f"  ◆ {m}（{len(miles[m])} 条）")
            for l in miles[m]:
                out("      · " + l.strip()[6:])
        return 0
    lines, i, n = _pick(args)
    if lines is None:
        return 1
    if not args.name:
        err("用法: pybktl task mile <编号> <里程碑名> | mile list")
        return 2
    line = re.sub(r"\s*\[M:[^\]]+\]", "", lines[i])
    lines[i] = line.rstrip() + " [M:" + args.name + "]"
    _write(lines)
    out(f"✓ #{n} 已挂到里程碑 ◆{args.name}")
    return 0


def cmd_ready(args):
    """task ready：依赖已全部满足（可开工）的任务。"""
    lines = _read()
    open_idx = _open_indexes(lines)
    total = len(open_idx)
    ready_n = blocked_n = 0
    for n, i in enumerate(open_idx, 1):
        deps = _deps_of(lines[i])
        if not deps:
            continue
        unmet = [d for d in deps if 1 <= d <= total and d != n]
        if unmet:
            blocked_n += 1
            out(f"  #{n} 等待 {unmet}：{lines[i].strip()[6:]}")
        else:
            ready_n += 1
            out(f"  #{n} 可开工：{lines[i].strip()[6:]}")
    if ready_n + blocked_n == 0:
        out("· 没有声明依赖的任务（task dep <编号> <依赖编号>）")
        return 0
    out(f"（可开工 {ready_n} / 被阻 {blocked_n}）")
    return 0


def cmd_who(args):
    lines = _read()
    open_idx = _open_indexes(lines)
    people = {}
    for i in open_idx:
        _, owner, pri, _d = _parse_meta(lines[i])
        people.setdefault(owner, []).append(lines[i])
    if not people:
        out("· 没有在途任务")
        return 0
    for who in sorted(people, key=lambda w: -len(people[w])):
        p1 = sum(1 for l in people[who] if "[P1]" in l)
        over = sum(1 for l in people[who] if _is_overdue(l))
        head = f"{who}（{len(people[who])} 条"
        if p1:
            head += f"，P1×{p1}"
        if over:
            head += f"，⚠过期×{over}"
        head += "）"
        out(f"  {head}")
        for l in people[who]:
            out("      · " + l.strip()[6:] + ("  ⚠" if _is_overdue(l) else ""))
    return 0


def run(args):
    table = {"add": cmd_add, "list": cmd_list, "done": cmd_done,
             "take": cmd_take, "give": cmd_give, "pri": cmd_pri,
             "note": cmd_note, "rm": cmd_rm, "who": cmd_who,
             "dep": cmd_dep, "mile": cmd_mile, "ready": cmd_ready}
    fn = table.get(args.task_cmd)
    if fn is None:
        err("用法: pybktl task add|list|done|take|give|pri|note|rm|who")
        return 2
    return fn(args)


def build_subparser(sub):
    pt = sub.add_parser("task", help="团队任务流转 v2：指派/认领/优先级/评论/过期提醒")
    tsub = pt.add_subparsers(dest="task_cmd", required=True)

    ta = tsub.add_parser("add", help="登记任务")
    ta.add_argument("text", nargs="+", help="任务描述")
    ta.add_argument("--owner", help="指派给谁（默认 PYBOOK_AUTHOR/用户名）")
    ta.add_argument("--due", help="截止日期 YYYY-MM-DD")
    ta.add_argument("--p1", dest="pri", action="store_const", const="p1", help="紧急（P1）")
    ta.add_argument("--p2", dest="pri", action="store_const", const="p2", help="P2")
    ta.add_argument("--p3", dest="pri", action="store_const", const="p3", help="P3")

    tl = tsub.add_parser("list", help="任务列表（默认未完）")
    tl.add_argument("--owner", help="按认领人过滤")
    tl.add_argument("--all", action="store_true", help="含已完成")
    tl.add_argument("--p1", action="store_true", help="只看 P1")
    tl.add_argument("--overdue", action="store_true", help="只看过期")

    td = tsub.add_parser("done", help="标记完成")
    td.add_argument("idx", type=int, help="list 里的编号")
    tk = tsub.add_parser("take", help="认领（owner 改成自己）")
    tk.add_argument("idx", type=int)
    tk.add_argument("--owner", help="代他人认领")
    tg = tsub.add_parser("give", help="指派/改派")
    tg.add_argument("idx", type=int)
    tg.add_argument("who", help="被指派人")
    tp = tsub.add_parser("pri", help="调优先级")
    tp.add_argument("idx", type=int)
    tp.add_argument("level", help="p1|p2|p3")
    tn = tsub.add_parser("note", help="追加进展评论")
    tn.add_argument("idx", type=int)
    tn.add_argument("text", nargs="+")
    tr = tsub.add_parser("rm", help="删除任务（含评论）")
    tr.add_argument("idx", type=int)
    tw = tsub.add_parser("who", help="谁手上有什么（按人聚合）")

    tdep = tsub.add_parser("dep", help="声明前置任务（依赖）")
    tdep.add_argument("idx", type=int)
    tdep.add_argument("deps", help="依赖编号，逗号分隔")
    tmil = tsub.add_parser("mile", help="挂里程碑 / mile list 看全景")
    tmil.add_argument("idx", nargs="?")
    tmil.add_argument("name", nargs="?")
    tread = tsub.add_parser("ready", help="哪些任务可开工（前置已完成）")
    pt.set_defaults(func=run)
