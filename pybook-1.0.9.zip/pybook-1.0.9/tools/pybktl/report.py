# -*- coding: utf-8 -*-
"""report —— 团队协作日报/周报：把 hist 历史 + 任务 + 发布日志 聚合成一份 markdown。

    pybktl report [--days 7] [--out 团队报告.md]

数据源（都在项目里，人也能直接翻）：
  .pybook/hist/索引.jsonl   快照（谁改了什么、红绿）
  任务.md                   任务（谁领的、完成没）
  发布日志.md               发布（谁发了什么版本）
"""
import argparse
import datetime
import json
import os
import re


def out(m=""):
    print(m)


def _author_default():
    return os.environ.get("PYBOOK_AUTHOR") or os.environ.get("USERNAME") or "未知"


def _within(iso_date, days):
    try:
        d = datetime.datetime.fromisoformat(iso_date[:10]).date()
    except Exception:
        return True
    return (datetime.date.today() - d).days <= days


def _hist_section(days, out_lines):
    idx = os.path.join(".pybook", "hist", "索引.jsonl")
    rows = []
    if os.path.isfile(idx):
        for line in open(idx, encoding="utf-8"):
            line = line.strip()
            if line:
                try:
                    rows.append(json.loads(line))
                except Exception:
                    continue
    rows = [r for r in rows if _within(r.get("time", ""), days)]
    out_lines.append(f"## 快照（{len(rows)} 次）")
    if not rows:
        out_lines.append("（期间无快照）")
        return {}, 0, 0
    by_author = {}
    for r in rows:
        by_author[r.get("author", "?")] = by_author.get(r.get("author", "?"), 0) + 1
    out_lines.append("| 作者 | 快照数 |")
    out_lines.append("|---|---|")
    for a, c in sorted(by_author.items(), key=lambda kv: -kv[1]):
        out_lines.append(f"| {a} | {c} |")
    touched = {}
    for r in rows:
        for f in list(r.get("changed", [])) + list(r.get("added", [])):
            touched[f] = touched.get(f, 0) + 1
    top = sorted(touched.items(), key=lambda kv: -kv[1])[:5]
    if top:
        out_lines.append("")
        out_lines.append("最常改动：" + "、".join(f"{f}（{c} 次）" for f, c in top))
    red = sum(1 for r in rows if r.get("灯") == "红")
    if red:
        out_lines.append(f"⚠ 其中有 {red} 次 ●红 快照（未过静态检查）")
    return by_author, len(rows), red


def _task_section(days, out_lines):
    """任务段 v2：复用 task.py 的解析（单一事实源）——P1/过期/评论/按人负载全进报告。"""
    import task as task_mod
    if not os.path.isfile(task_mod.TASK_MD):
        out_lines.append("§§ 任务（无 " + task_mod.TASK_MD + "）")
        return
    lines = task_mod._read()
    open_idx = task_mod._open_indexes(lines)
    opened = done = 0
    by_owner = {}
    p1_open = 0
    overdue_open = []
    for i in open_idx:
        line = lines[i]
        _, owner, pri, _d = task_mod._parse_meta(line)
        opened += 1
        by_owner.setdefault(owner, []).append(line)
        if pri == "P1":
            p1_open += 1
        if task_mod._is_overdue(line):
            overdue_open.append(line.strip()[6:])
    for l in lines:
        if l.strip().startswith("- [x]"):
            done += 1
    head = f"## 任务（在途 {opened} / 历史完成 {done}"
    if p1_open:
        head += f"，在途 P1×{p1_open}"
    head += "）"
    out_lines.append(head)
    if overdue_open:
        out_lines.append(f"⚠ 过期 {len(overdue_open)} 条：")
        for t in overdue_open[:5]:
            out_lines.append(f"  - {t}")
    if not by_owner:
        return
    out_lines.append("")
    out_lines.append("| 认领人 | 在途 | P1 | 过期 |")
    out_lines.append("|---|---|---|---|")
    for owner, ls in sorted(by_owner.items(), key=lambda kv: -len(kv[1])):
        p1 = sum(1 for l in ls if "[P1]" in l)
        over = sum(1 for l in ls if task_mod._is_overdue(l))
        out_lines.append(f"| {owner} | {len(ls)} | {p1} | {over} |")


def _pub_section(days, out_lines):
    if not os.path.isfile("发布日志.md"):
        out_lines.append("## 发布（无 发布日志.md）")
        return
    rows = []
    for line in open("发布日志.md", encoding="utf-8"):
        m = re.match(r"- (\d{4}-\d{2}-\d{2})[^\s]*\s+(\S+)：(.+)", line.strip())
        if m and _within(m.group(1), days):
            rows.append((m.group(1), m.group(2), m.group(3)))
    out_lines.append(f"## 发布（{len(rows)} 次）")
    for date, author, what in rows:
        out_lines.append(f"- {date} {author}：{what}")


def run(args):
    days = args.days
    lines = [f"# 团队报告（近 {days} 天 · {datetime.date.today().isoformat()}）", ""]
    _hist_section(days, lines)
    lines.append("")
    _task_section(days, lines)
    lines.append("")
    _pub_section(days, lines)

    text = "\n".join(lines) + "\n"
    outp = args.out or f"团队报告-{datetime.date.today().isoformat()}.md"
    open(outp, "w", encoding="utf-8", newline="").write(text)
    out(f"✓ 团队报告已生成 → {outp}")
    out("  （数据源：.pybook/hist + 任务.md + 发布日志.md——发群里就是站会材料）")
    return 0


def build_subparser(sub):
    pr = sub.add_parser("report", help="团队协作报告：快照+任务+发布 聚合成一份 markdown")
    pr.add_argument("--days", type=int, default=7, help="统计最近几天（默认 7）")
    pr.add_argument("--out", help="输出文件（默认 团队报告-日期.md）")
    pr.set_defaults(func=run)
