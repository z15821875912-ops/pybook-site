"""chat 协议的**独立** Python 实现（参考用，不参与 PYbook 编译）。

为什么要有它：C 端自己加密自己解密，全绿也证明不了「协议是对的」——
它只证明「C 和 C 一致」。这里用 Python 另写一份**独立**实现，
先用 RFC 8439 官方向量自校准（自校准不过就直接报错，不许继续），
再拿它和 C 端互相对话：Python 发的 C 解得开，C 发的 Python 解得开。

协议（与 pybook_net.c 里的 chat 库一一对应）：
    SK   = PBKDF2-HMAC-SHA256(口令, "pybook-chat|" + 房间, 100000, 32)
    标签  = HMAC-SHA256(SK, "room|" + 房间)[:16]
    随机数 = 8 字节连接 id + 4 字节大端计数器
    明文  = 昵称 + "\n" + 正文
    密文  = ChaCha20(SK, 随机数, 0, 明文)
    校验  = HMAC-SHA256(SK, 类型||标签||随机数||密文)[:16]
    行    = "<类型> <标签hex> <随机数hex> <密文hex> <校验hex>"
"""
import hashlib
import hmac
import struct

PBKDF2_ITERS = 100000


# ---------------------------------------------------------------- ChaCha20
def _qr(x, a, b, c, d):
    x[a] = (x[a] + x[b]) & 0xFFFFFFFF
    x[d] ^= x[a]
    x[d] = ((x[d] << 16) | (x[d] >> 16)) & 0xFFFFFFFF
    x[c] = (x[c] + x[d]) & 0xFFFFFFFF
    x[b] ^= x[c]
    x[b] = ((x[b] << 12) | (x[b] >> 20)) & 0xFFFFFFFF
    x[a] = (x[a] + x[b]) & 0xFFFFFFFF
    x[d] ^= x[a]
    x[d] = ((x[d] << 8) | (x[d] >> 24)) & 0xFFFFFFFF
    x[c] = (x[c] + x[d]) & 0xFFFFFFFF
    x[b] ^= x[c]
    x[b] = ((x[b] << 7) | (x[b] >> 25)) & 0xFFFFFFFF


def chacha20(key, nonce, counter, data):
    """RFC 8439 ChaCha20：key 32 字节、nonce 12 字节、counter 32 位。"""
    state = [0x61707865, 0x3320646E, 0x79622D32, 0x6B206574]
    state += list(struct.unpack('<8I', key))
    state += [counter & 0xFFFFFFFF]
    state += list(struct.unpack('<3I', nonce))
    out = bytearray()
    for off in range(0, len(data), 64):
        x = list(state)
        for _ in range(10):
            _qr(x, 0, 4, 8, 12); _qr(x, 1, 5, 9, 13)
            _qr(x, 2, 6, 10, 14); _qr(x, 3, 7, 11, 15)
            _qr(x, 0, 5, 10, 15); _qr(x, 1, 6, 11, 12)
            _qr(x, 2, 7, 8, 13); _qr(x, 3, 4, 9, 14)
        x = [(a + b) & 0xFFFFFFFF for a, b in zip(x, state)]
        blk = struct.pack('<16I', *x)
        chunk = data[off:off + 64]
        out += bytes(a ^ b for a, b in zip(chunk, blk))
        state[12] = (state[12] + 1) & 0xFFFFFFFF
    return bytes(out)


def selfcheck():
    """用 RFC 8439 的官方向量自校准：不过就不许继续。"""
    # §2.4.2 太阳镜例子
    key = bytes(range(32))
    nonce = bytes([0, 0, 0, 0, 0, 0, 0, 0x4a, 0, 0, 0, 0])
    pt = (b"Ladies and Gentlemen of the class of '99: If I could offer you "
          b"only one tip for the future, sunscreen would be it.")
    want = bytes.fromhex(
        '6e2e359a2568f98041ba0728dd0d6981e97e7aec1d4360c20a27afccfd9fae0b'
        'f91b65c5524733ab8f593dabcd62b3571639d624e65152ab8f530c359f0861d80'
        '7ca0dbf500d6a6156a38e088a22b65e52bc514d16ccf806818ce91ab77937365af'
        '90bbf74a35be6b40b8eedf2785e42874d')
    got = chacha20(key, nonce, 1, pt)
    assert got == want, 'ChaCha20 自校准失败（RFC 8439 §2.4.2）'
    # A.1 #1：全零密钥/随机数、计数器 0
    ks = chacha20(bytes(32), bytes(12), 0, bytes(64))
    assert ks.hex().startswith('76b8e0ada0f13d90405d6ae55386bd28'), 'ChaCha20 自校准失败（A.1 #1）'
    # PBKDF2-HMAC-SHA256：RFC 7914 §11
    dk = hashlib.pbkdf2_hmac('sha256', b'password', b'salt', 1, 32)
    assert dk.hex() == '120fb6cffcf8b32c43e7225256c4f837a86548c92ccc35480805987cb70be17b', \
        'PBKDF2 自校准失败'
    return True


# ---------------------------------------------------------------- 协议
def derive_key(passwd, room, iters=PBKDF2_ITERS):
    return hashlib.pbkdf2_hmac('sha256', passwd.encode('utf-8'),
                               ('pybook-chat|' + room).encode('utf-8'),
                               iters, 32)


def room_tag(key, room):
    return hmac.new(key, ('room|' + room).encode('utf-8'), hashlib.sha256).digest()[:16]


def make_line(key, tag, typ, conn_id, counter, nickname, body):
    nonce = conn_id + struct.pack('>I', counter)
    plain = nickname.encode('utf-8') + b'\n' + body.encode('utf-8')
    ct = chacha20(key, nonce, 0, plain)
    mac = hmac.new(key, typ.encode('ascii') + tag + nonce + ct, hashlib.sha256).digest()[:16]
    return '%s %s %s %s %s' % (typ, tag.hex(), nonce.hex(), ct.hex(), mac.hex())


def parse_line(line):
    parts = line.split(' ')
    if len(parts) != 5:
        raise ValueError('行格式不对: %r' % line)
    typ, tag, nonce, ct, mac = parts
    return {
        'type': typ,
        'tag': bytes.fromhex(tag),
        'nonce': bytes.fromhex(nonce),
        'ct': bytes.fromhex(ct),
        'mac': bytes.fromhex(mac),
    }


def open_plain(key, nonce, ct):
    """解密并拆成 [昵称, 正文]。"""
    raw = chacha20(key, nonce, 0, ct)
    if b'\n' not in raw:
        raise ValueError('明文里没有分隔符')
    nick, body = raw.split(b'\n', 1)
    return nick.decode('utf-8'), body.decode('utf-8')


def verify_mac(key, tag, typ, nonce, ct, mac):
    want = hmac.new(key, typ.encode('ascii') + tag + nonce + ct, hashlib.sha256).digest()[:16]
    return hmac.compare_digest(want, mac)


if __name__ == '__main__':
    selfcheck()
    print('Python 独立实现自校准通过（ChaCha20 RFC 8439 §2.4.2 / A.1 #1、PBKDF2 RFC 7914）')
