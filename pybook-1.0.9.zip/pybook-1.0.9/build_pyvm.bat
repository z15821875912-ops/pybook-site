@echo off
REM Build the PYbook bytecode VM (pyvm.exe).
REM Portable gcc discovery order:
REM   1) bundled MinGW-w64 shipped in this repo (�������_102\mingw64\bin)
REM   2) gcc on PATH
REM   3) common install locations (mingw64 / msys2)
REM
REM Notes:
REM  - mathplus.c binding macros (rt_lib_mp_*) only take effect when PYBOOK_RT_H
REM    and MP_RT_BINDING are defined; keep -DMP_RT_BINDING or mp.* is undefined.
REM  - pybook_music.c uses waveOut/mciSendString (Win32) -> link -lwinmm (Windows).
REM  - hw3d (SDL2) is only needed by the C backend for 3D, not by the VM build.
REM  - -march=native is required so the AVX2 matmul micro-kernel is emitted.

setlocal enabledelayedexpansion
cd /d "%~dp0"

set "GCC="
REM 1) bundled MinGW-w64 shipped with the repo
if exist "%~dp0�������_102\mingw64\bin\x86_64-w64-mingw32-gcc.exe" (
    set "GCC=%~dp0�������_102\mingw64\bin\x86_64-w64-mingw32-gcc.exe"
)
REM 2) gcc on PATH
if not defined GCC (
    where gcc >nul 2>&1
    if !errorlevel!==0 set "GCC=gcc"
)
REM 3) common install locations
if not defined GCC (
    for %%P in (
        "C:\mingw64\bin\x86_64-w64-mingw32-gcc.exe"
        "C:\msys64\mingw64\bin\gcc.exe"
        "%USERPROFILE%\mingw64\bin\x86_64-w64-mingw32-gcc.exe"
        "%USERPROFILE%\msys64\mingw64\bin\gcc.exe"
    ) do (
        if not defined GCC if exist %%~P set "GCC=%%~P"
    )
)
if not defined GCC (
    echo [FAIL] gcc not found. Install MinGW-w64 and add to PATH, or use the bundled �������_102/mingw64.
    exit /b 1
)
echo [INFO] using gcc: %GCC%

"%GCC%" -O3 -march=native -I. ^
    pyvm.c pybook_rt.c pybook_lib.c pybook_csv.c pybook_json.c pybook_file.c ^
    pybook_mt.c pybook_gpu.c pybook_la.c pybook_mm.c pybook_obj.c pybook_wire.c pybook_np.c pybook_tb.c pybook_bits.c ^
    pybook_smoke.c pybook_music.c pybook_net.c pybook_plot.c ^
    -DMP_RT_BINDING -DLA_RT_BINDING mathplus.c ^
    -DSYM_RT_BINDING pybook_sym.c ^
    pybook_crypto.c ^
    -o pyvm.exe -lwinmm -lws2_32 -lwininet -lbcrypt -lm

if %errorlevel%==0 (
    echo [OK] pyvm.exe build succeeded
) else (
    echo [FAIL] build failed, code %errorlevel%
)
endlocal
