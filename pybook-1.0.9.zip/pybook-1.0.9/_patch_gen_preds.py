# _patch_gen_preds.py —— 修 conv 内核生成器的谓词寄存器冲突。
#
# 为什么要修：原生成器把「通道谓词」放在 %p8..%p(8+TO-1)、「空间谓词」放在
# %p24..%p27、「通道 AND 空间」放在 %p28..%p31。TO=16 时三段不撞，
# 但 TO=32 时通道谓词要占 %p8..%p39 —— 正好把 %p24..%p31 压掉，
# 于是 TO=32 生成出来的 PTX 谓词互相覆盖（结果错，而且从 PTX 文本上看不出来）。
#
# 修法：三段彻底分开 —— 通道 %p8..%p(8+TO-1)（最多到 %p39）、空间 %p40..%p43、
# 最终 %p44..%p47，谓词寄存器总数声明成 %p<48>。
import io, os

P = "build_tmp/probe/_gen_conv_ptx.py"

d = io.open(P, encoding="utf-8", newline="").read()

REPL = [
    ('e("    .reg .pred %p<40>;")',
     'e("    .reg .pred %p<48>;")'),
    ('e("    and.pred %p24, %p4, %p6;")',
     'e("    and.pred %p40, %p4, %p6;")'),
    ('e("    and.pred %p25, %p4, %p7;")',
     'e("    and.pred %p41, %p4, %p7;")'),
    ('e("    and.pred %p26, %p5, %p6;")',
     'e("    and.pred %p42, %p5, %p6;")'),
    ('e("    and.pred %p27, %p5, %p7;")',
     'e("    and.pred %p43, %p5, %p7;")'),
    ('e("    and.pred %%p%d, %%p%d, %%p%d;" % (28 + i, 8 + o, 24 + i))',
     'e("    and.pred %%p%d, %%p%d, %%p%d;" % (44 + i, 8 + o, 40 + i))'),
    ('          % (28 + i, reg, o * TSY * TSX + i))',
     '          % (44 + i, reg, o * TSY * TSX + i))'),
]

for old, new in REPL:
    n = d.count(old)
    if n != 1:
        raise SystemExit("锚点命中 %d 次（应为 1）：%s" % (n, old[:70]))
    d = d.replace(old, new)

tmp = P + ".tmpfix"
with io.open(tmp, "w", encoding="utf-8", newline="") as f:
    f.write(d)
os.replace(tmp, P)
print("生成器谓词已重排：通道 %p8-%p(8+TO-1) / 空间 %p40-%p43 / 最终 %p44-%p47")
