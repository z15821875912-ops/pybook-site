import json
import os
import sys

import pybk_types
from pybk_front import PybkError, parse
from pybk_code import compile_and_run, compile_and_run_once, PybkCodegenError

# 产品版本号：单一真相源是仓库根目录的 VERSION 文件，改版本只改那一个文件。
# （回退值 1.0.14 仅当 VERSION 缺失时生效。）
def _read_version():
    try:
        with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'VERSION'),
                  encoding='utf-8') as _vf:
            return _vf.read().strip()
    except Exception:
        return '1.0.14'

PYBOOK_VERSION = _read_version()


def die(msg):
    print(msg, file=sys.stderr)
    sys.exit(1)


def _print_warnings(warnings):
    if warnings:
        print("软类型警告：")
        for w in warnings:
            print("  " + w)


def _resolve_mode(program_mode, arg_mode, env_mode):
    """errorstopped 严格度优先级：文件头 errorstopped > --mode > PYBOOK_MODE > normal。"""
    if program_mode in ('hard', 'normal', 'simple'):
        return program_mode
    if arg_mode in ('hard', 'normal', 'simple'):
        return arg_mode
    if env_mode in ('hard', 'normal', 'simple'):
        return env_mode
    return 'normal'


def _hard_gate(program):
    """errorstopped hard：软类型警告升格为错误 + 复杂度/风险闸门。返回错误列表。"""
    errs = []
    warns = pybk_types.soft_type_check(program)
    for w in warns:
        errs.append("errorstopped hard 拦截（软类型）：" + w)
    errs.extend(pybk_types.hard_checks(program))
    return errs


def _parse_program(源码):
    """解析 + 引用() 导入 + 宏展开，返回可分析的 Program（不编译、不运行）。"""
    try:
        program = parse(源码)
    except RecursionError:
        # 与 compile_and_run 旧路径一致：前端解析爆栈 → 友好提示（E08_deep_nest 等用例锁此措辞）
        raise PybkCodegenError('表达式或括号嵌套太深，请拆分后再试')
    if program.imports:
        import os
        # PYBK_IMPORT_DIR 允许外部（如 IDE 内联检查）指定「引用()」解析基准目录；
        # 否则与 compile_and_run 旧路径一致，用 _main_file_dir() 解析（argv[1] 为文件时取其目录，
        # 否则退回 cwd），保证「引用()」基准与旧行为逐字一致、不随 --mode 等开关位置漂移。
        _mfd = __import__('pybk_code')._main_file_dir
        base = os.environ.get('PYBK_IMPORT_DIR') or _mfd() or '.'
        fns, inits, classes, macros = __import__('pybk_code')._load_imports(program, base, ['<主文件>'])
        program.fns = fns + (program.fns or [])
        program.go_body = inits + (program.go_body or [])
        program.classes = classes + (program.classes or [])
        program.macros = macros + (program.macros or [])
    if program.macros:                        # 宏：编译期内联展开（须在代码生成之前）
        __import__('pybk_front').expand_macros(program)
    return program


def _walk_nodes(obj):
    """深度遍历 AST 节点（dataclass / list / tuple / dict），产出所有节点。"""
    if isinstance(obj, (list, tuple, set)):
        for x in obj:
            yield from _walk_nodes(x)
        return
    if isinstance(obj, dict):
        for x in obj.values():
            yield from _walk_nodes(x)
        return
    if hasattr(obj, '__dataclass_fields__'):
        for f in obj.__dataclass_fields__:
            yield from _walk_nodes(getattr(obj, f, None))
        yield obj


def _names_of(seq):
    """props / static_fields 形如 [(名, 默认表达式), ...]，也可能已是 [名, ...]。两种都吃。"""
    out = []
    for x in (seq or []):
        if isinstance(x, (list, tuple)) and x:
            out.append(str(x[0]))
        elif isinstance(x, str):
            out.append(x)
    return out


def _fn_sym(f):
    return {'name': f.name,
            'params': [str(p) for p in (f.params or [])],
            'optional': sorted((getattr(f, 'defaults', None) or {}).keys()),
            'line': getattr(f, 'line', None)}


def _extract_symbols(program):
    """从已解析的 Program 抽一张符号表出来，给 IDE 补全和 AI 用。

    只跑 parse()，不跑 codegen —— 比 --check 轻得多，补全可以高频调。
    编辑中的文件常常语法未完成，所以调用方要能在解析失败时优雅回退。
    """
    # 全局变量：vg./vg_ro. 是全局声明机制，任何嵌套深度下声明的都是全局，
    # 所以不需要做作用域分析，递归找到 VgAssign/IpAssign/AssignIndex 即可。
    globals_, locks, deletes = {}, [], []
    for n in _walk_nodes(program.go_body):
        t = type(n).__name__
        if t in ('VgAssign', 'IpAssign', 'AssignIndex'):
            if n.name and n.name not in globals_:
                globals_[n.name] = getattr(n, 'line', None)
        elif t == 'GoldDel':
            if n.kind == 'gold':
                locks.append(n.name)
            elif n.kind == 'del':
                deletes.append(n.name)

    imports = []
    for x in (program.imports or []):
        if isinstance(x, (list, tuple)) and x:
            imports.append({'name': str(x[0]),
                            'line': x[1] if len(x) > 1 else None})
        elif isinstance(x, str):
            imports.append({'name': x, 'line': None})

    return {
        'ok': True,
        'meta': program.meta,
        'mode': program.mode,
        'globals': [{'name': k, 'line': v} for k, v in globals_.items()],
        'locks': locks,
        'deletes': deletes,
        'functions': [_fn_sym(f) for f in (program.fns or [])],
        'macros': [{'name': m.name, 'params': [str(p) for p in (m.params or [])],
                    'line': getattr(m, 'line', None)} for m in (program.macros or [])],
        'classes': [{
            'name': c.name, 'line': c.line, 'parent': c.parent,
            'props': _names_of(c.props),
            'ctor_params': [str(p) for p in (c.ctor_params or [])],
            'static_fields': _names_of(c.static_fields),
            'methods': [_fn_sym(m) for m in (c.methods or [])],
            'static_methods': [_fn_sym(m) for m in (c.static_methods or [])],
        } for c in (program.classes or [])],
        'imports': imports,
    }


def _完整编译(源码, 静态检查=False):
    """解析 + 代码生成（不产出 .c 文件、不 gcc、不运行）。
    被 --check 用：静态错误在这一步全部暴露。"""
    program = _parse_program(源码)
    cg = __import__('pybk_code').Codegen()
    if 静态检查:
        cg.static_check = True
    return cg.generate(program)


def _read_trace(path):
    """读取 PYBOOK_M7_TRACE 落下的 GC 轨迹文件；不存在返回空列表。"""
    try:
        with open(path, encoding='utf-8', errors='replace') as f:
            return f.read().splitlines()
    except FileNotFoundError:
        return []


def _determinism_check(src, program, seed):
    """D：确定性工具。

    同种子把程序跑两遍（强制 知命=mode7 + 固定 PYBOOK_SEED），比对两份信号：
      ① 程序 stdout——任何输入驱动的差别（含 RNG 未播种）都会在这里暴露；
      ② GC 内存轨迹——运行时经 PYBOOK_M7_TRACE 记录每次 GC 事件的
         相位/类型/存活/晋升/各意图计数（pause 是 wall-clock，比对时剥掉）。
    两份都一致 → 程序行为可复现；任一份不一致 → 揪出隐藏的非确定性
    （RNG 未播种 / set·dict 迭代顺序 / 依赖指针地址 / 多线程竞态等）。
    """
    import tempfile, re
    import io as _io
    os.environ['PYBOOK_MEMMODE'] = '7'     # 强制以 mode7 跑，零源码改动
    os.environ['PYBOOK_SEED'] = str(seed)  # 固定随机源，rd.* 序列可复现
    tmp1 = os.path.join(tempfile.gettempdir(), 'm7det_%d_a.log' % os.getpid())
    tmp2 = os.path.join(tempfile.gettempdir(), 'm7det_%d_b.log' % os.getpid())
    for t in (tmp1, tmp2):
        if os.path.exists(t):
            os.remove(t)
    outs = []
    runs = []
    # 抓程序自身 stdout（确定性信号①），不打印到屏幕
    for tf in (tmp1, tmp2):
        os.environ['PYBOOK_M7_TRACE'] = tf
        cap = _io.StringIO()
        old = sys.stdout
        sys.stdout = cap
        try:
            compile_and_run_once(src, program=program)
            runs.append(0)
        except (PybkError, PybkCodegenError) as e:
            runs.append(2)
            if len(runs) == 2:
                sys.stdout = old
                print('确定性检查：第二次运行编译失败：' + str(e), file=sys.stderr)
                return 1
        except RuntimeError as e:
            runs.append(1)
            outs.append('[运行异常] ' + str(e))
            sys.stdout = old
            continue
        except RecursionError:
            runs.append(1)
            outs.append('[嵌套过深]')
            sys.stdout = old
            continue
        sys.stdout = old
        outs.append(cap.getvalue())
    t1, t2 = _read_trace(tmp1), _read_trace(tmp2)
    # pause 是 wall-clock，跨运行不可复现，比对时剥掉它
    strip = lambda lines: [re.sub(r'pause=\d+', 'pause=X', ln) for ln in lines]
    s1, s2 = strip(t1), strip(t2)
    out_same = (outs[0] == outs[1])
    trace_same = (s1 == s2)
    if out_same and trace_same and runs[0] == runs[1]:
        print('确定性通过 ✅：同种子(%d) 两次运行的 输出 与 GC 内存轨迹 均逐字节一致' % seed)
        print('  轨迹事件数：%d（每次 GC 一行：相位/类型/存活/晋升/各意图计数）' % len(s1))
        return 0
    # 不一致：逐项报告
    print('确定性失败 ❌：两次运行不一致（种子 %d）' % seed, file=sys.stderr)
    if runs[0] != runs[1]:
        print('  退出状态不同：runA=%s runB=%s' % (runs[0], runs[1]), file=sys.stderr)
    if not out_same:
        print('  程序输出(stdout)不同：', file=sys.stderr)
        for i, (a, b) in enumerate(zip(outs[0].splitlines(), outs[1].splitlines())):
            if a != b:
                print('    第 %d 行  runA: %r' % (i + 1, a), file=sys.stderr)
                print('    第 %d 行  runB: %r' % (i + 1, b), file=sys.stderr)
                break
    if not trace_same:
        print('  GC 轨迹不同：', file=sys.stderr)
        for i, (a, b) in enumerate(zip(s1, s2)):
            if a != b:
                print('    第 %d 行  runA: %s' % (i + 1, a), file=sys.stderr)
                print('    第 %d 行  runB: %s' % (i + 1, b), file=sys.stderr)
                break
        else:
            if len(s1) != len(s2):
                print('    轨迹长度不同：runA=%d 行 runB=%d 行' % (len(s1), len(s2)), file=sys.stderr)
    return 1


def main():
    argv = sys.argv[1:]
    check = False
    symbols = False
    paths = []
    arg_mode = None
    determinism = False          # D：确定性工具开关
    det_seed = 1                # D：两次运行共用的固定随机种子
    for a in argv:
        if a == '--check':
            check = True
        elif a == '--symbols':
            symbols = True
        elif a == '--check-json':
            check = 'json'
        elif a == '--version':
            print(PYBOOK_VERSION)
            return
        elif a.startswith('--mode='):
            arg_mode = a[len('--mode='):]
            if arg_mode not in ('hard', 'normal', 'simple'):
                die(f"--mode 只支持 hard / normal / simple，收到：{arg_mode}")
        elif a == '--determinism-check':
            determinism = True
        elif a.startswith('--seed='):
            try:
                det_seed = int(a[len('--seed='):])
            except ValueError:
                die(f"--seed 需要整数，收到：{a[len('--seed='):]}")
        elif a.startswith('-'):
            die(f"未知选项: {a}")
        else:
            paths.append(a)
    if not paths:
        die("用法: python pybk_main.py [--check|--check-json] [--mode=hard|normal|simple] 程序.pybk")
    try:
        src = open(paths[0], encoding="utf-8-sig").read()
    except FileNotFoundError:
        die(f"找不到文件: {paths[0]}")
    env_mode = os.environ.get('PYBOOK_MODE')

    # --symbols：只解析、不代码生成，输出一张 JSON 符号表（IDE 补全 / AI 读符号用）。
    # 编辑中的文件常常语法未完成，解析失败时也只吐一行 {"ok": false, ...}，
    # 由调用方回退到自己的兜底路径 —— 不要在这里吐 traceback。
    if symbols:
        try:
            program = _parse_program(src)
            print(json.dumps(_extract_symbols(program), ensure_ascii=False))
        except (PybkError, PybkCodegenError) as e:
            import re
            m = re.search(r'第 (\d+) 行', str(e))
            print(json.dumps({'ok': False, 'line': int(m.group(1)) if m else None,
                              'message': str(e)}, ensure_ascii=False))
            sys.exit(1)
        except RecursionError:
            print(json.dumps({'ok': False, 'line': None,
                              'message': '表达式或嵌套太深，请拆分后再试'},
                             ensure_ascii=False))
            sys.exit(1)
        return

    if check:
        warnings = []
        errs = []
        try:
            program = _parse_program(src)
            mode = _resolve_mode(program.mode, arg_mode, env_mode)
            if mode != 'simple':
                # 软类型检查：只收集警告，不影响编译成败（simple 彻底关掉）
                warnings = pybk_types.soft_type_check(program)
            if mode == 'hard':
                errs = _hard_gate(program)
            cg = __import__('pybk_code').Codegen()
            cg.static_check = True
            cg.generate(program)
        except (PybkError, PybkCodegenError) as e:
            msg = str(e)
            if check == 'json':
                import re
                m = re.search(r'第 (\d+) 行', msg)
                print(json.dumps({"ok": False,
                                  "line": int(m.group(1)) if m else None,
                                  "message": msg,
                                  "warnings": warnings}, ensure_ascii=False))
            else:
                print("编译失败: " + msg)
                _print_warnings(warnings)
            sys.exit(1)
        except RecursionError:
            msg = "表达式或嵌套太深，请拆分后再试"
            if check == 'json':
                print(json.dumps({"ok": False, "line": None, "message": msg,
                                 "warnings": warnings}, ensure_ascii=False))
            else:
                print("编译失败: " + msg)
            sys.exit(1)
        # 模式闸门（语法/语义已通过，看软类型升格 + 复杂度）
        if errs:
            if check == 'json':
                print(json.dumps({"ok": False, "line": None,
                                 "message": "\n".join(errs),
                                 "warnings": warnings}, ensure_ascii=False))
            else:
                print("编译失败（errorstopped " + mode + "）：")
                for e in errs:
                    print("  " + e)
            sys.exit(1)
        if check == 'json':
            print(json.dumps({"ok": True,
                             "message": "编译通过（语法+语义；未 gcc 未运行）",
                             "warnings": warnings}, ensure_ascii=False))
        else:
            print("编译通过（语法 + 语义检查；未 gcc 未运行）")
            _print_warnings(warnings)
        return

    # D：确定性工具——同种子跑两遍，比对 GC 内存轨迹
    if determinism:
        try:
            program = _parse_program(src)
        except (PybkError, PybkCodegenError) as e:
            die(str(e))
        except RecursionError:
            die("表达式或嵌套太深，请拆分后再试")
        sys.exit(_determinism_check(src, program, det_seed))

    # 正常编译运行路径：同样强制 errorstopped 模式（hard 必拦，normal/simple 原样跑）
    try:
        program = _parse_program(src)
        mode = _resolve_mode(program.mode, arg_mode, env_mode)
        if mode == 'hard':
            errs = _hard_gate(program)
            if errs:
                die("编译失败（errorstopped hard）：\n  " + "\n  ".join(errs))
        compile_and_run(src, program=program)
    except PybkError as e:          # 前端语法/词法错误
        die(str(e))
    except PybkCodegenError as e:   # 语义/编译错误
        die(str(e))
    except RuntimeError as e:       # 程序运行时错误
        die(str(e))
    except RecursionError:
        die("表达式或嵌套太深，请拆分后再试")


main()
