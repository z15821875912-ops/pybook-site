"""PYbook 编译后端。

流程：compile_and_run(src)
    pybk_front.tokenize → parse → 遍历 AST 生成 C（调 pybook_rt 运行时）
    → 写 out.c → gcc -O2 -o app.exe out.c pybook_rt.c → 运行 app.exe

要点：
    标识符（可含中文）改安全名：变量 v_1..、函数 f_1..，映射表以注释写在
    out.c 顶部；变量预声明为 Value v_N = rt_none()，赋值一律 rt_assign，
    读取一律 rt_chk 包裹；and/or 用语句提升实现短路；cd 块按 priority
    稳定排序提到本层最前（无并发）；GOING 体即 C 的 main 体。
    语义错误（未声明变量、ret 进 GOING、重复函数、函数未定义/参数个数
    不符、整数字面量超 64 位）抛 PybkCodegenError，按 AST 的 line 字段
    报 "第 N 行: 原因"。
仅用 Python 标准库。
"""

import os
import re
import shutil
import subprocess
import sys
import time

from pybk_front import (tokenize, parse, parse_module, expand_macros,
                        module_ns_prefix, resolve_module_path, rewrite_namespace)
import pybk_clib

# ---------------- --watch 热重载入口 ----------------
# pybk_main.py 保持不动：这里在 import 期识别 --watch 并把文件路径顶到 argv[1]，
# pybk_main 随后照常读文件、调 compile_and_run；watch 循环由 compile_and_run 接管。
_WATCH_MODE = False
if len(sys.argv) >= 2 and sys.argv[1] == '--watch':
    if len(sys.argv) < 3:
        print('用法: python pybk_main.py --watch 文件.pybk', file=sys.stderr)
        sys.exit(1)
    sys.argv = [sys.argv[0]] + sys.argv[2:]
    _WATCH_MODE = True
from pybk_front import (
    NumLit, StrLit, BoolLit, VarRef, BinOp, Unary, Call, InputExpr,
    Ret, VgAssign, IpAssign, NsShow, Around, Aging, CdBlock, VcChain,
    FnDef, Program, GoldDel, ListLit, Index, AssignIndex, MemoryMode, DeviceMode, JitMode,
    HmStmt, ClassDef, Member, MethodCall, AssignMember, AssignStatic, CtorExpr, StaticCall, StaticRef,
    HmDraw, HmLive, HmFrame, HmPlay, GoStmt, GO_DIRECTIONS, GAME_CALLS, LIB_CALLS,
    HmBlockDef, HmUse, HmPageStmt, TestCheck,
    BreakStmt, ForIn, StrParts,
    WhileStmt, ContinueStmt,
    Slice,
    Comp,
    MultiAssign,
    DictLit,
    SetLit,
    Ternary, DictComp,
    Lambda,
    TryCatch, OnError, Throw, hint_for)

SPRITE_HELPERS_C = r'''

/* 绘(列表)：精灵属性读取（缺属性 → 带序号报错） */
static Value _pbk_sprop(Value obj, const char *name, long long idx)
{
    RtObject *o;
    size_t k;
    if (!IS_OBJ(obj)) {
        fprintf(stderr, "运行时错误: 绘 第 %lld 个元素不是对象\n");
        exit(1);
    }
    o = AS_OBJ(obj);
    for (k = 0; k < o->nprops; k++)
        if (strcmp(o->names[k], name) == 0)
            return o->vals[k];
    fprintf(stderr, "运行时错误: 绘 第 %lld 个元素缺少属性 %s\n", idx + 1, name);
    exit(1);
}
static Value _pbk_half(Value v, long long idx)
{
    if (IS_INT(v))
        return rt_int(AS_INT(v) / 2);
    if (IS_FLT(v))
        return rt_int((long long)(AS_FLT(v) / 2));
    fprintf(stderr, "运行时错误: 绘 第 %lld 个元素的宽/高需要是数字\n", idx + 1);
    exit(1);
}
'''

# ---- 标量化热循环的算术助手 ----
# 标量化把「每圈装箱一次」变成「整圈零装箱」，代价是算术改由 C 原生类型做。
# 原生 C 的整数运算是静默回绕，而 PYbook 的 rt_add/rt_sub/rt_mul 溢出即报错
# （「溢出」），rt_mod/rt_fdiv 除零也报错。这里补一套语义一致的助手，
# 让标量路径和老路径**逐位一致**（包括错误行为）。
PK_HELPERS_C = r'''
/* 整数算术：溢出即报错（与 rt_add / rt_sub / rt_mul 同义） */
static long long pk_add_ov(long long a, long long b)
{ long long r; if (__builtin_add_overflow(a, b, &r)) rt_die("溢出"); return r; }
static long long pk_sub_ov(long long a, long long b)
{ long long r; if (__builtin_sub_overflow(a, b, &r)) rt_die("溢出"); return r; }
static long long pk_mul_ov(long long a, long long b)
{ long long r; if (__builtin_mul_overflow(a, b, &r)) rt_die("溢出"); return r; }
/* 取模：除数符号同余（与 rt_mod 同义）；除零报错；LLONG_MIN % -1 恒为 0 */
static long long pk_modz(long long a, long long b)
{
    if (b == 0) rt_die("除以零");
    if (b == -1) return 0;
    long long r = a % b;
    if (r != 0 && ((r < 0) != (b < 0))) r += b;
    return r;
}
/* 整除：向下取整（与 rt_fdiv 同义）；除零报错；商溢出报错 */
static long long pk_fdivz(long long a, long long b)
{
    if (b == 0) rt_die("除以零");
    if (b == -1 && a == LLONG_MIN) rt_die("溢出");
    long long q = a / b;
    if (a % b != 0 && ((a < 0) != (b < 0))) q--;
    return q;
}
/* 真除法：结果一律 float，除零报错（与 rt_div 同义） */
static double pk_divz(double a, double b)
{
    if (b == 0.0) rt_die("除以零");
    return a / b;
}
'''

NL_CHAR = chr(10)   # net.send 自动补的行尾字符

# ---- 网页 UI 控件运行时（按钮/输入框/滑条）；CTXNAME 替换为画布 ctx 变量名 ----
_UI_RUNTIME = r"""window.__pybkUI = { focus: null, drag: null, text: {}, val: {} };
window.__pybkUI_KEY = function(e) {
  if (!window.__pybkUI.focus) return;
  var t = window.__pybkUI.text[window.__pybkUI.focus] || '';
  if (e.key === 'Backspace') { window.__pybkUI.text[window.__pybkUI.focus] = t.slice(0, -1); }
  else if (e.key.length === 1 && !e.ctrlKey && !e.metaKey) { window.__pybkUI.text[window.__pybkUI.focus] = t + e.key; }
};
window.__pybkUI_BTN = function(ctx, x, y, w, h, label) {
  var mx = window.__pybkMX || 0, my = window.__pybkMY || 0;
  var over = mx >= x && mx <= x + w && my >= y && my <= y + h;
  ctx.fillStyle = over ? 'rgb(90,170,255)' : 'rgb(60,120,220)';
  ctx.fillRect(x, y, w, h);
  ctx.fillStyle = '#ffffff';
  ctx.font = '16px sans-serif';
  var tw = ctx.measureText(label).width;
  ctx.fillText(label, x + w / 2 - tw / 2, y + h / 2 + 6);
  return (over && window.__pybkMH) ? 1 : 0;
};
window.__pybkUI_INP = function(ctx, id, x, y, w, h) {
  var mx = window.__pybkMX || 0, my = window.__pybkMY || 0;
  var over = mx >= x && mx <= x + w && my >= y && my <= y + h;
  if (window.__pybkMH && over) window.__pybkUI.focus = id;
  var focused = window.__pybkUI.focus === id;
  var txt = window.__pybkUI.text[id] || '';
  ctx.fillStyle = '#ffffff'; ctx.fillRect(x, y, w, h);
  ctx.strokeStyle = focused ? '#50fa7b' : '#8899bb'; ctx.lineWidth = 2;
  ctx.strokeRect(x, y, w, h);
  ctx.fillStyle = '#222222'; ctx.font = '15px sans-serif';
  var caret = (focused && (Math.floor(Date.now() / 400) % 2 === 0)) ? '|' : '';
  ctx.fillText(txt + caret, x + 8, y + h / 2 + 5);
  return txt;
};
window.__pybkUI_SLD = function(ctx, id, x, y, w, lo, hi, val) {
  var mx = window.__pybkMX || 0, my = window.__pybkMY || 0;
  var over = mx >= x - 10 && mx <= x + w + 10 && my >= y - 12 && my <= y + 12;
  if (window.__pybkUI.val[id] === undefined) window.__pybkUI.val[id] = val;
  if (window.__pybkMH && over) window.__pybkUI.drag = id;
  if (window.__pybkUI.drag === id) {
    if (!window.__pybkMD) window.__pybkUI.drag = null;
    else { var t = (mx - x) / w; t = Math.max(0, Math.min(1, t)); window.__pybkUI.val[id] = lo + t * (hi - lo); }
  }
  var v = window.__pybkUI.val[id];
  var kn = x + w * (v - lo) / (hi - lo);
  ctx.strokeStyle = '#8899bb'; ctx.lineWidth = 4;
  ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + w, y); ctx.stroke();
  ctx.fillStyle = '#50fa7b';
  ctx.beginPath(); ctx.arc(kn, y, 8, 0, Math.PI * 2); ctx.fill();
  ctx.fillStyle = '#ffffff'; ctx.font = '13px sans-serif';
  ctx.fillText(String(Math.round(v * 100) / 100), x + w + 14, y + 5);
  return v;
};"""

def _find_gcc():
    import os
    for c in (r'C:\Users\zhuli\mingw64\bin\x86_64-w64-mingw32-gcc.exe',
              r'C:\Users\zhuli\mingw64\bin\gcc.exe',
              r'C:\Users\zhuli\Desktop\gcc.exe'):
        if os.path.isfile(c):
            return c
    return 'gcc'
FALLBACK_GCC = _find_gcc()
RT_CACHE_DIR = 'rt_cache'                 # 运行时 .o 预编译缓存目录
RT_CFLAGS = ['-O3', '-march=native']   # 运行时编译参数（改这里必须同步 RT_CFLAGS_TAG）
RT_CFLAGS_TAG = '-o3n'   # 上面这组参数的名字，进 .o 缓存文件名：换参数就改它，旧缓存自动失效
EXE_CACHE_DIR = 'exe_cache'               # 可执行文件缓存：源码没变就直接跑，跳过生成 C + gcc 链接

# PYBOOK_NO_CACHE=1：完全不碰 exe 缓存（不读、不写、不修剪）。
# 给测试/CI 用——测试要的是「源码→结果」可复现，不该被上一次跑剩的 exe 影响；
# 而且在安全删除受限的环境里，修剪缓存会把整个进程打死（safe-delete fail-closed）。
NO_EXE_CACHE = os.environ.get('PYBOOK_NO_CACHE') == '1'

# rm.around 热点标量化：**默认开**。
#   PYBOOK_SCALAR=0  → 关掉（退回「每圈装箱回写」的老路径）。
# 逃生门留着：万一某个程序在标量路径上出怪事，一个环境变量就能回到老行为。
SCALAR_ON = os.environ.get('PYBOOK_SCALAR', '1') != '0'

# 参与缓存指纹的编译器/运行时源码：这些文件一改，旧 exe 就必须作废
# （例如改了 pybook_rt.c 的 GC，缓存里还是旧 exe 就等于没改）
_CACHE_DEPS = (
    'pybk_code.py', 'pybk_front.py',
    'pybook_rt.c', 'pybook_rt.h', 'pybook_lib.c', 'pybook_lib.h',
    'pybook_file.c', 'pybook_music.c', 'pybook_net.c', 'pybook_hw3d.c',
    'pybook_np.c', 'pybook_tb.c', 'pybook_mt.c', 'pybook_json.c',
    'pybook_gpu.c', 'pybook_gpu.h',
    'pybook_plot.c',
    'pybook_csv.c', 'pybook_mm.c', 'mathplus.c', 'mathplus.h',
    'pybook_la.c', 'pybook_la.h',
    'pybook_obj.c', 'pybook_wire.c',
    'pybook_bits.c', 'pybook_ui.c', 'pybook_m3d.c', 'pybook_m3d.h',
    'pybook_smoke.c', 'pybook_smoke.h',
    'pybook_sym.c', 'pybook_sym.h',
    'pybook_re.c', 'pybook_re_engine.h',
    'pybook_crypto.c', 'pybook_crypto.h',
)


_IMPORT_RE = None


def _import_names(text: str) -> list:
    """源码里的 引用("x") / import("x") 名字列表（正则，容忍空格与两种引号）。"""
    global _IMPORT_RE
    if _IMPORT_RE is None:
        import re as _re
        _IMPORT_RE = _re.compile(r'(?:引用|import)\s*\(\s*["\']([^"\']+)["\']\s*\)')
    return [m.group(1) for m in _IMPORT_RE.finditer(text)]


def _fingerprint_imports(h, base: str, names: list, seen: set):
    """把引用链上的模块文件内容喂进指纹。

    整条链都扫（传递依赖）：模块里的模块改了同样要让缓存失效——老实现只扫主
    文件的直接引用，改了库里的库照样命中旧缓存（跑出来是旧代码）。
    路径按「引用方所在目录」解析：lib/助手.pybk 里的 引用("兄弟") → lib/兄弟.pybk。"""
    for name in names:
        p = resolve_module_path(base, name)
        if not p or p in seen or not os.path.isfile(p):
            continue
        seen.add(p)
        try:
            with open(p, 'rb') as fp:
                h.update(fp.read())
            with open(p, encoding='utf-8-sig') as fp:
                txt = fp.read()
        except OSError:
            continue
        _fingerprint_imports(h, os.path.dirname(p) or '.', _import_names(txt), seen)


def _fingerprint_clibs(h, main_dir: str):
    """同目录 C 库的文件进指纹。

    改了 .c/.h 必须重编（否则跑的是旧 exe）；新增/删除一个 .c 也会改变
    暴露出来的函数集合，同样要失效。这里只签「路径+修改时间+大小」，不读
    内容 —— 指纹每轮都要算，读全文太慢。
    """
    cs, hs = pybk_clib.candidate_files(main_dir)
    for p in sorted(cs) + sorted(hs):
        try:
            st = os.stat(p)
            h.update(('%s:%d:%d' % (p, st.st_mtime_ns, st.st_size)).encode())
        except OSError:
            h.update((p + ':missing').encode())


def _attach_clibs(gen, main_dir: str):
    """把同目录 C 库的函数表挂到 codegen 上。

    规则：
      - 主程序所在目录的 .c（排除 PYbook 自己的运行时文件）自动成为「用户 C 库」
      - 函数原型从同目录 .h/.c 自动解析，不用写 ffi.声明
      - 同名不同签名 → 编译期报错（别把冲突留给 gcc 去炸）
      - 名字撞上 PYbook 运行时内部符号 → 报错（会重复定义）
    返回发现的 Clib 列表（后面要编成 .o 参与链接）。"""
    clibs = pybk_clib.discover(main_dir)
    if not clibs:
        return []
    table, conflicts = pybk_clib.collect(clibs)
    if conflicts:
        nm, _a, _b = conflicts[0]
        raise PybkCodegenError(
            f'同目录的 C 库里有同名但签名不同的函数 {nm}\n'
            f'  为什么：两个库都导出这个名字，链接期才知道冲突就晚了\n'
            f'  怎么改：让两个库用同一个签名；或者给其中一个换个函数名')
    for nm in table:
        if nm.startswith('rt_') or nm.startswith('pybook_'):
            raise PybkCodegenError(
                f'C 库函数名 {nm} 撞上了 PYbook 运行时的内部符号\n'
                f'  为什么：rt_/pybook_ 前缀是运行时内部保留的\n'
                f'  怎么改：把 C 那边的函数改成别的名字（比如 my_{nm}）')
    gen.clib_decls = table
    gen.clib_names = sorted(table)
    gen.clib_files = [c.c_path for c in clibs]
    gen.clib_list = clibs
    gen.clib_proto = [pybk_clib.proto_text(nm, rt, ps)
                      for nm, (_rc, rt, ps) in sorted(table.items())]
    return clibs


def _compile_clib(clib, gcc, game_flags, sdl_flags, main_dir):
    """把用户的 C 库编成 .o（带缓存：源或它声明的头变了就重编）。"""
    base = os.path.splitext(os.path.basename(clib.c_path))[0]
    o_path = os.path.join(RT_CACHE_DIR, 'clib_' + base + RT_CFLAGS_TAG + '.o')
    dep = os.path.getmtime(clib.c_path)
    for h in clib.headers:
        try:
            dep = max(dep, os.path.getmtime(h))
        except OSError:
            pass
    if not os.path.exists(o_path) or os.path.getmtime(o_path) < dep:
        tmp_o = f'{o_path}.tmp{os.getpid()}'
        # -I main_dir：用户的 .c 里 #include "我的库.h" 能找到
        # -I .         ：仓库根，允许 #include "pybook_rt.h"（用 PYbook 运行时）
        cc = subprocess.run([gcc, *RT_CFLAGS, '-I', main_dir, '-I', '.',
                             '-c', clib.c_path, '-o', tmp_o] + game_flags + sdl_flags,
                            capture_output=True, text=True, errors='replace')
        if cc.returncode != 0:
            raise PybkCodegenError(
                'gcc 编译失败（同目录 C 库 ' + os.path.basename(clib.c_path) + '）：\n'
                + (cc.stderr or cc.stdout))
        os.replace(tmp_o, o_path)
    return o_path


def _src_fingerprint(src: str) -> str:
    """源码 + 引用库 + 同目录 C 库 + 编译器/运行时 的指纹。任一处变了 key 就变，缓存自动失效。"""
    import hashlib
    h = hashlib.sha256()
    h.update(src.encode('utf-8'))
    # 被 引用("xxx") 拉进来的库文件也算（改了库不重编 = 跑旧代码）
    main_dir = _main_file_dir()
    _fingerprint_imports(h, main_dir, _import_names(src), set())
    # 同目录的 C 库（.c/.h）也算
    _fingerprint_clibs(h, main_dir)
    # 编译器与运行时：用「路径+修改时间+大小」签名（比读全文快，且改了必然变）
    # 行为开关也进指纹：PYBOOK_SCALAR 改变生成的 C（标量化），不进指纹会命中
    # 无标量的旧 exe——开关像没按一样（2026-10-24 实测踩坑）。
    # 记的是**实际生效值**（默认开），不是环境变量原文：否则「不设」和「设成 1」
    # 会算出两个 key，白白多一份 exe 缓存。
    h.update(('SCALAR=' + ('1' if SCALAR_ON else '0')).encode())
    for f in _CACHE_DEPS:
        try:
            st = os.stat(f)
            h.update(('%s:%d:%d' % (f, st.st_mtime_ns, st.st_size)).encode())
        except OSError:
            h.update((f + ':missing').encode())
    return h.hexdigest()[:20]


def _prune_exe_cache(limit=60):
    """缓存超量时删最旧的几个。沙箱的 safe-delete 可能让 remove 失败，忽略即可。"""
    try:
        files = [os.path.join(EXE_CACHE_DIR, f) for f in os.listdir(EXE_CACHE_DIR)
                 if f.startswith('prog_') and f.endswith('.exe')]
        files.sort(key=lambda p: os.path.getmtime(p))
        for p in files[:max(0, len(files) - limit)]:
            try:
                os.remove(p)
            except OSError:
                pass
    except OSError:
        pass

INT_MIN, INT_MAX = -(2 ** 63), 2 ** 63 - 1

BIN_OPS = {
    '+': 'rt_add', '-': 'rt_sub', '*': 'rt_mul', '/': 'rt_div',
    '%': 'rt_mod', '//': 'rt_fdiv',
    '==': 'rt_eq', '!=': 'rt_ne',
    '<': 'rt_lt', '>': 'rt_gt', '<=': 'rt_le', '>=': 'rt_ge',
    'in': 'rt_in', 'not_in': 'rt_not_in',
}


class PybkCodegenError(Exception):
    """后端语义错误 / 编译失败，消息带行号或附 gcc 输出。"""


def cstr(s: str) -> str:
    """语言字符串 → C 字符串字面量（内容按 UTF-8 原样保留）。"""
    buf = ['"']
    for ch in s:
        if ch == '\\':
            buf.append('\\\\')
        elif ch == '"':
            buf.append('\\"')
        elif ch == '\n':
            buf.append('\\n')
        elif ch == '\t':
            buf.append('\\t')
        elif ch == '\r':
            buf.append('\\r')
        else:
            buf.append(ch)
    buf.append('"')
    return ''.join(buf)


class _PkAbort(Exception):
    pass


class Codegen:
    def __init__(self):
        self.vmap = {}        # 语言变量名 -> v_N
        self.fmap = {}        # 语言函数名 -> f_N
        self.hw_used = False  # 用过 hw.*（out.c 需要发射 rt_hw_* 原型）
        self.nv = 0
        self.nf = 0
        self.nt = 0           # 临时变量计数（_t/_n/_i 共用，保证唯一）
        self.fns = {}         # 语言函数名 -> 参数个数
        self.hm_block_c = {}  # web.块 组件名 -> (C 函数名, 参数个数)
        self.缺省参数 = {}    # 函数名 -> [默认值节点或 None]（对齐参数位）
        self.out = []
        self.depth = 0
        self.static_check = False  # --check 静态分析开关（字面量类型/取值检查，仅 --check 开启）
        self.declared = set()  # 当前函数内可读的名字（预扫描赋值 ∪ 参数 ∪ 循环 at）
        self._已赋值 = set()   # 真正生成过赋值的名字（区别于 emit_locals 的预声明：
                               # rm.around 标量化靠它判断"进圈前是否已有旧值"）
        self.in_going = False
        self.hm_used = False
        self.test_used = False  # 出现过 查() 测试语句（决定退出码=失败数）
        self.page_begun = False  # 是否已发射 rt_page_begin
        self._pk_iv = None       # 标量化循环的 C 计数变量名
        self._pk_on = SCALAR_ON   # 热点标量化开关（默认开；PYBOOK_SCALAR=0 关掉）
        self._pk_lv = None       # 标量化循环的 PYbook 循环变量名
        self._pk_live = None     # (候选集, 类型表)
        # ---- 静态数值域追踪（标量化要用）----
        # _vg_kind：变量名 -> 'i' 整数 | 'f' 浮点。只在主程序（GOING 块）里记，
        #   因为函数体是在 main 之前生成的，函数里的赋值是"运行期才发生"的，
        #   记进主程序的类型表会把圈前的类型算错。
        # _fn_vars：任何函数体里被赋过值的变量名。这些变量圈前的类型不可信
        #   （函数可能在循环前改过它），标量分析一律当 'u'（未知）处理。
        self._vg_kind = {}
        self._fn_vars = set()      # 别的函数赋过的变量名
        self._fn_kinds = {}        # 别的函数给这些变量赋的数值域集合
        self._fn_assign = {}       # 函数名 → (变量名集合, 数值域集合表)
        self._cur_fn = None        # 当前正在生成的函数名（None = 主程序）
        self._pk_helpers = False   # 发过标量循环 → out.c 里要带算术助手
        self.c_libs = []         # ffi.链接("user32") 等额外链接库
        self.draw_n = 0          # web.draw.始 计数 → canvas/ctx 的序号
        self.in_draw = None      # 当前打开的画布序号（web.draw.始..终 之间非 None）
        self._canvas_size = {}   # 画布序号 -> (宽, 高)；web.draw.始(宽,高) 可调，缺省 400×300
        self.loop_depth = 0      # 循环嵌套深度（break 只能在循环内使用的检查用）
        self.catch_depth = 0     # catch 处理器嵌套深度（裸 throw 只能在 catch 里用）
        self.hm_frames = []      # 待播放的帧：每帧是 [('raw', js) / ('val', 临时名)] 计划
        self._frame_plan = None  # 收集帧体时非 None：raw/draw_val 改写入计划
        self.play_n = 0          # web.播放 计数（页内多段播放时 JS 全局名去重）
        self.live_n = 0          # web.实时 计数（页内多块实时时 JS 全局名去重）
        self.wait_n = 0          # web.waitsec 计数（页内多个等待时 DOM id 去重）
        self.spr_helpers_on = None   # 【热修】绘() 精灵辅助开关：generate() 会判 is None
        self._live_sfx = None    # 正在编译的实时块后缀（js_expr 里 按键/按过 用）
        self._live_declared = set()  # 当前实时块里可用的 JS 变量名
        self._live_loop = 0      # 实时块里的循环深度（break 检查用）
        self.go_n = 0            # go 计数（同上）
        self.classes = {}        # 类名 -> ClassDef
        self.vtypes = {}         # 变量名 -> 类名（vg.x = lb.类名(...) 推断）
        self.cur_class = None    # 正在编译的方法所属类
        self.method_ids = {}     # 实例方法名 -> 整数分发器 id
        self.static_init_calls = []  # 启动时要调用的静态字段初始化函数
        # ---- ffi.* FFI（底层窗口）----
        self.c_includes = []     # ffi.包含(...) 的头文件
        self.c_libs = []         # ffi.链接(...) 的库 -> 链接时 -l
        self.c_decls = {}        # C 函数签名：名 -> (返回类, 返回类型, [(参数类, 参数类型), ...])
        self.c_ffi_proto = []        # 原型文本（去重，发射到生成文件头）
        self.c_raw = []          # ffi.码(...) 原样 C 代码（文件作用域逃生门）
        # ---- 同目录 C 库（.c 扔进主程序所在目录即可用，不用写 ffi.声明）----
        self.clib_decls = {}     # 名 -> (返回类, 返回类型, [(参数类, 参数类型)])
        self.clib_proto = []     # 原型文本（发射到生成文件头）
        self.clib_names = []     # 可用函数名（报「函数未定义」时列出来）
        self.clib_files = []     # 用户 .c 文件（编译成 .o 参与链接）
        self.clib_list = []      # Clib 对象（编译阶段要知道每个 .c 声明了哪些头）
        # 在 __init__ 里挂，而不是等到编译阶段才挂：
        # IDE 的 --check 静态检查路径也 new Codegen()（只生成 C、不 gcc），
        # 那条路挂不上 C 库就会把「调用 C 库函数」误报成「函数未定义」。
        _attach_clibs(self, _main_file_dir())

    # ---- 基础 ----

    def err(self, node, msg):
        raise PybkCodegenError(f'第 {node.line} 行：{msg}' + hint_for(msg))

    # ---- 静态分析：--check 字面量级类型/取值检查（轻量档，只查字面量，零误报）----
    def _lit_type(self, n):
        if isinstance(n, NumLit):
            return 'num'
        if isinstance(n, BoolLit):
            return 'bool'
        if isinstance(n, StrLit):
            return 'str'
        return None

    def _lit_desc(self, n):
        t = self._lit_type(n)
        if t == 'num':
            return '数字'
        if t == 'bool':
            return '布尔'
        if t == 'str':
            return '字符串'
        return '未知类型'

    def _static_check_binop(self, e):
        if not self.static_check:
            return
        lt = self._lit_type(e.left)
        rt = self._lit_type(e.right)
        if lt is None or rt is None:
            return  # 任一非字面量 -> 不查（避免误报）
        if e.op in ('+', '-', '/', '%', '//'):
            # 一边字符串一边数字/布尔 -> 类型错配（如 1 + "abc"）；* 留作字符串重复，不拦
            if e.op != '*' and (lt == 'str') != (rt == 'str'):
                self.err(e, f"类型错配：{self._lit_desc(e.left)} 和 {self._lit_desc(e.right)} 不能直接做 {e.op} 运算（PYbook 不隐式互转）")
            # 字面量除零 / 取模零
            if e.op in ('/', '%', '//') and rt == 'num' and isinstance(e.right, NumLit) and e.right.value == 0:
                self.err(e, f"字面量除零：除数写死成了 0，{self._lit_desc(e.left)} {e.op} 0 运行时会崩")
        elif e.op in ('<', '>', '<=', '>='):
            if (lt == 'str') != (rt == 'str'):
                self.err(e, f"类型错配：{self._lit_desc(e.left)} 和 {self._lit_desc(e.right)} 不能做 {e.op} 比较（PYbook 不隐式互转）")
        # == / != / and / or 不查（任何类型都可比/可逻辑）

    def emit(self, line):
        self.out.append('    ' * self.depth + line if line else '')

    def vname(self, name):
        if name not in self.vmap:
            self.nv += 1
            self.vmap[name] = f'v_{self.nv}'
        return self.vmap[name]

    def fname(self, name):
        if name not in self.fmap:
            self.nf += 1
            self.fmap[name] = f'f_{self.nf}'
        return self.fmap[name]

    def newtemp(self, prefix='_t'):
        self.nt += 1
        return f'{prefix}{self.nt}'

    def check_declared(self, ref: VarRef):
        if ref.name not in self.declared:
            self.err(ref, f"变量 '{ref.name}' 未声明（规则：写用 vg.名 = 值 声明；"
                          f"函数内只能读参数和自己赋过的变量——要先 vg.名 = 赋值 再用；"
                          f"检查是否拼写错误）")

    # ---- 表达式：返回 (前置语句列表, C 表达式文本) ----
    # 需要控制流的构造（and/or）把语句提升到前置列表，保证短路语义，
    # 且能嵌在 ns.show 参数等任何表达式位置。

    def expr(self, e):
        if isinstance(e, VarRef) and e.name in ('frame', 'sec')                 and e.name not in self.declared:
            # 内置帧数/秒数：插值和表达式里裸写 frame / sec 都可用
            return [], (f'rt_frames()' if e.name == 'frame' else f'rt_secs()')
        if isinstance(e, NumLit):
            if isinstance(e.value, float):
                return [], f'rt_float({e.value!r})'
            if not (INT_MIN <= e.value <= INT_MAX):
                self.err(e, f'整数字面量 {e.value} 超出 64 位有符号范围')
            return [], f'rt_int({e.value}LL)'
        if isinstance(e, StrLit):
            return [], f'rt_str({cstr(e.value)})'
        if isinstance(e, Call) and e.name == '空' and not e.args:
            return [], 'rt_none()'
        if isinstance(e, Call) and e.name in ('PK_BOX_I', 'PK_BOX_F'):
            nm = e.args[0].value
            return ([], f'rt_int(S_{self.vname(nm)})') if e.name.endswith('I')                 else ([], f'rt_float(S_{self.vname(nm)})')
        if isinstance(e, Call) and e.name == 'PK_LOOP_I':
            return [], f'rt_at({self._pk_iv})'   # 值域：循环变量装箱
        if isinstance(e, BoolLit):
            return [], f'rt_bool({1 if e.value else 0})'
        if isinstance(e, VarRef):
            if e.name not in self.declared and e.name in self.fns:
                # mec 函数值：裸写函数名（不是变量）→ 求值为它的名字（可传给 mec.apply/map 等）
                return [], f'rt_str({cstr(e.name)})'
            self.check_declared(e)
            return [], f'rt_chk({self.vname(e.name)})'
        if isinstance(e, InputExpr):
            return [], f'rt_input({cstr(e.prompt)})'
        if isinstance(e, Unary):
            if self.static_check and e.op == '-' and isinstance(e.operand, StrLit):
                self.err(e, "类型错配：字符串不能取负（- 只用于数字）")
            s, c = self.expr(e.operand)
            if e.op == '-':
                return s, f'rt_neg({c})'
            if e.op == 'not':
                return s, f'rt_not({c})'
            self.err(e, f"不支持的一元运算符 '{e.op}'")
        if isinstance(e, BinOp):
            if e.op in ('and', 'or'):
                return self.short_circuit(e)
            if e.op not in BIN_OPS:
                self.err(e, f"不支持的运算符 '{e.op}'")
            self._static_check_binop(e)
            ls, lc = self.expr(e.left)
            rs, rc = self.expr(e.right)
            stmts = ls + rs
            # 带前置语句的操作数物化成临时，左右求值顺序确定为从左到右
            if ls:
                lc = self.materialize(stmts, lc)
            if rs:
                rc = self.materialize(stmts, rc)
            return stmts, f'{BIN_OPS[e.op]}({lc}, {rc})'
        if isinstance(e, ListLit):
            t = self.newtemp()
            stmts = [f'Value {t} = rt_list_new();']
            for it in e.items:
                s, c = self.expr(it)
                stmts += s
                stmts.append(f'rt_push(&{t}, {c});')
            return stmts, t
        if isinstance(e, Index):
            bs, bc = self.expr(e.base)
            is_, ic = self.expr(e.index)
            if bs:
                bc = self.materialize(bs, bc)
            stmts = bs + is_
            return stmts, f'rt_index({bc}, {ic})'
        if isinstance(e, SetLit):
            # 集合 = 无值字典（键=元素、值=1）：去重/哈希/in 全部复用字典基建。
            # rt_in 已有 IS_DICT 分支，`x in 集合` 免费可用。
            t = self.newtemp('_st')
            stmts = [f'Value {t} = rt_dict_new();']
            for it in e.items:
                s1, c1 = self.expr(it)
                stmts += s1
                c1 = self.materialize(stmts, c1)
                stmts.append(f'rt_dict_set(&{t}, {c1}, rt_int(1));')
            return stmts, t
        if isinstance(e, DictLit):
            t = self.newtemp('_dc')
            stmts = [f'Value {t} = rt_dict_new();']
            for kk, vv in e.pairs:
                s1, c1 = self.expr(kk)
                stmts += s1
                s2, c2 = self.expr(vv)
                stmts += s2
                c1 = self.materialize(stmts, c1)
                c2 = self.materialize(stmts, c2)
                stmts.append(f'rt_dict_set(&{t}, {c1}, {c2});')
            return stmts, t
        if isinstance(e, StrParts):
            return self._interp_concat(e)
        if isinstance(e, Ternary):
            cs, cc = self.expr(e.cond)
            t = self.newtemp('_t3')
            stmts = cs
            stmts.append(f'Value {t} = rt_none();')
            stmts.append(f'if (rt_cond({cc})) {{')
            as_, ac = self.expr(e.then)
            stmts += as_
            ac = self.materialize(stmts, ac)
            stmts.append(f'{t} = {ac};')
            stmts.append('} else {')
            bs, bc = self.expr(e.els)
            stmts += bs
            bc = self.materialize(stmts, bc)
            stmts.append(f'{t} = {bc};')
            stmts.append('}')
            return stmts, t
        if isinstance(e, DictComp):
            dt = self.newtemp('_dc')
            stmts = [f'Value {dt} = rt_dict_new();']
            is_, ic = self.expr(e.iter)
            stmts += is_
            itv = self.materialize(stmts, ic)
            saved = self.vmap.pop(e.vars[0], None)
            slot = self.vname(e.vars[0])
            iv = self.newtemp('_ci')
            stmts.append(f'for (long long {iv} = 0; {iv} < rt_iter_len_ll({itv}); {iv}++) {{')
            stmts.append(f'Value {slot} = (IS_DICT({itv}) ? rt_dict_key_at({itv}, {iv}) : rt_index({itv}, rt_at({iv})));')
            had = e.vars[0] in self.declared
            self.declared.add(e.vars[0])
            slot2 = None
            saved2 = None
            had2 = False
            if len(e.vars) == 2:
                saved2 = self.vmap.pop(e.vars[1], None)
                slot2 = self.vname(e.vars[1])
                stmts.append(f'Value {slot2} = (IS_DICT({itv}) ? rt_index({itv}, {slot}) : rt_index({slot}, rt_int(1LL)));')
                had2 = e.vars[1] in self.declared
                self.declared.add(e.vars[1])
            ks_, kc = self.expr(e.key)
            stmts += ks_
            kc = self.materialize(stmts, kc)
            vs_, vc = self.expr(e.val)
            stmts += vs_
            vc = self.materialize(stmts, vc)
            if e.cond is not None:
                cs2, cc2 = self.expr(e.cond)
                stmts += cs2
                cc2 = self.materialize(stmts, cc2)
                stmts.append(f'if (rt_cond({cc2})) rt_dict_set(&{dt}, {kc}, {vc});')
            else:
                stmts.append(f'rt_dict_set(&{dt}, {kc}, {vc});')
            if not had:
                self.declared.discard(e.vars[0])
            if saved is not None:
                self.vmap[e.vars[0]] = saved
            else:
                self.vmap.pop(e.vars[0], None)
            if len(e.vars) == 2:
                if not had2:
                    self.declared.discard(e.vars[1])
                if saved2 is not None:
                    self.vmap[e.vars[1]] = saved2
                else:
                    self.vmap.pop(e.vars[1], None)
            stmts.append('}')
            return stmts, dt
        if isinstance(e, Slice):
            bs, bc = self.expr(e.base)
            if bs:
                bc = self.materialize(bs, bc)
            stmts = bs
            MISS = '-2147483648'          # 段缺省哨兵（C 侧判 INT_MIN）
            def _段(x, miss):
                if x is None:
                    return miss
                s2, c2 = self.expr(x)
                stmts.extend(s2)
                if s2:
                    return self.materialize(stmts, c2)
                return c2
            a = _段(e.start, MISS)
            b = _段(e.stop, MISS)
            c = _段(e.step, MISS)
            return stmts, f'rt_list_slice({bc}, {a}, {b}, {c})'
        if isinstance(e, Comp):
            lt = self.newtemp('_lc')
            stmts = [f'Value {lt} = rt_list_new();']
            is_, ic = self.expr(e.iter)
            stmts += is_
            itv = self.materialize(stmts, ic)
            saved = self.vmap.pop(e.var, None)
            slot = self.vname(e.var)
            iv = self.newtemp('_ci')
            stmts.append(f'for (long long {iv} = 0; {iv} < rt_list_len_ll({itv}); {iv}++) {{')
            stmts.append(f'Value {slot} = rt_index({itv}, rt_at({iv}));')
            had = e.var in self.declared
            self.declared.add(e.var)
            es_, ec = self.expr(e.expr)
            stmts += es_
            if es_:
                ec = self.materialize(stmts, ec)
            if e.cond is not None:
                cs_, cc = self.expr(e.cond)
                stmts += cs_
                cc = self.materialize(stmts, cc)
                stmts.append(f'if (rt_cond({cc})) rt_push(&{lt}, {ec});')
            else:
                stmts.append(f'rt_push(&{lt}, {ec});')
            if not had:
                self.declared.discard(e.var)
            if saved is not None:
                self.vmap[e.var] = saved
            else:
                self.vmap.pop(e.var, None)
            stmts.append('}')
            return stmts, lt
        if isinstance(e, Call):
            if e.name in ('add', 'remove', 'len', 'touch'):
                e = Call({'add': '添加', 'remove': '删掉', 'len': '长度',
                          'touch': '碰到'}[e.name], e.args, e.line)
            if e.name in GAME_CALLS:          # 游戏零件内置：key/win/clear/color/box/show/wait/end
                return self.gen_game_call(e)
            if e.name == 'tm.stop':           # tm.stop(秒) / tm.stop(数值, "s"/"ms")
                if len(e.args) not in (1, 2):
                    self.err(e, 'tm.stop 的写法：tm.stop(秒) 或 tm.stop(数值, "s"/"ms")')
                stmts = []
                args = []
                for a in e.args:
                    s2, c2 = self.expr(a)
                    stmts += s2
                    args.append(self.materialize(stmts, c2))
                unit = args[1] if len(args) == 2 else 'rt_str("s")'
                return stmts, f'rt_lib_tm_stop({args[0]}, {unit})'
            if e.name in LIB_CALLS:           # 标准库：te/mt/rd/list/file
                return self.gen_lib_call(e)
            if e.name in ('按键', '按过'):
                self.err(e, f'{e.name}() 只能在 web.实时 块里用（网页实时模式的键盘监测）')
            if e.name == '错误类型':              # 内置：错误类型()：当前错误类型（catch/finally 里用）
                if len(e.args) != 0:
                    self.err(e, '错误类型 不需要参数')
                return [], 'rt_str(rt_err_type())'
            if e.name in ('添加', '长度'):        # 内置：添加(列表, 值) / 长度(列表或字符串)
                if e.name == '长度':
                    if len(e.args) != 1:
                        self.err(e, '长度 需要 1 个参数')
                    s, c = self.expr(e.args[0])
                    return s, f'rt_len({c})'
                if len(e.args) != 2:
                    self.err(e, '添加 的写法：list.添加(列表名, 值)')
                a0 = e.args[0]
                if isinstance(a0, VarRef):
                    self.check_declared(a0)
                    st0, c0 = self.expr(a0)
                    tgt = f'&{self.vname(a0.name)}'
                elif isinstance(a0, (Member, Index)):
                    # 成员/下标形式（obj.表 等）：rt_push 只改列表内部不动句柄，
                    # 落到临时变量后取地址同样生效
                    st0, c0 = self.expr(a0)
                    mt_ = self.materialize(st0, c0)
                    st0.append(f'Value {mt_}_p = {mt_};')
                    tgt = f'&{mt_}_p'
                else:
                    self.err(e, '添加 的写法：list.添加(列表名, 值)')
                s, c = self.expr(e.args[1])
                return st0 + s, f'rt_push({tgt}, {c})'
            if e.name == '删掉':
                if len(e.args) != 2 or not isinstance(e.args[0], VarRef):
                    self.err(e, '删掉 的写法：删掉(列表名, 元素)')
                self.check_declared(e.args[0])
                s, c = self.expr(e.args[1])
                return s, f'rt_list_remove({self.vname(e.args[0].name)}, {c})'
            if e.name == '碰到':
                if len(e.args) != 2:
                    self.err(e, '碰到 需要 2 个参数：碰到(a, b)')
                stmts = []
                args = []
                for a in e.args:
                    s2, c2 = self.expr(a)
                    stmts += s2
                    args.append(self.materialize(stmts, c2))
                return stmts, f'rt_touch({args[0]}, {args[1]})'
            if e.name == 'sum':                 # 内置：sum(表) 求和（空表=0）
                if len(e.args) != 1:
                    self.err(e, 'sum 的写法：sum(表)')
                s, c = self.expr(e.args[0])
                return s, f'rt_lib_mt_sum({c})'
            if e.name == 'range':               # 内置：range(止)/range(起,止)/range(起,止,步) → 列表
                if len(e.args) not in (1, 2, 3):
                    self.err(e, 'range 的写法：range(止) / range(起, 止) / range(起, 止, 步)')
                stmts = []
                args = []
                for a in e.args:
                    s2, c2 = self.expr(a)
                    stmts += s2
                    args.append(self.materialize(stmts, c2))
                if len(args) == 1:
                    args = ['rt_int(0)', args[0], 'rt_int(1)']
                elif len(args) == 2:
                    args = [args[0], args[1], 'rt_int(1)']
                return stmts, f'rt_np_range({args[0]}, {args[1]}, {args[2]})'
            if e.name not in self.fns:
                if e.name in self.declared:
                    # mec lambda 语法糖：变量当函数调用 → rt_mec_apply(变量, 参数表)
                    s0 = []
                    a0 = []
                    for a in e.args:
                        sa, ca = self.expr(a)
                        s0 += sa
                        a0.append(self.materialize(s0, ca))
                    lt = self.newtemp()
                    s0.append(f'Value {lt} = rt_list_new();')
                    for c in a0:
                        s0.append(f'rt_push(&{lt}, {c});')
                    return s0, f'rt_mec_apply({self.vname(e.name)}, {lt})'
                if e.name in self.clib_decls:
                    # 同目录 C 库里的函数：走 FFI 桥，跟 ffi.调用 同一套转换
                    return self.gen_clib_call(e)
                self.err(e, f"函数 '{e.name}' 未定义（规则：func 名(参数) {{...}} 定义；"
                          f"引用(\"模块\") 合并模块函数；标准库前缀 mt./te./list./dict./rd.——"
                          f"检查是否拼写错误或漏了前缀）"
                          + (f"\n  同目录的 C 库里有这些函数：{', '.join(self.clib_names[:12])}"
                             if self.clib_names else ""))
            期望 = self.fns[e.name]
            if len(e.args) > 期望:
                self.err(e, f"函数 '{e.name}' 最多 {期望} 个参数，得到 {len(e.args)} 个")
            stmts = []
            args = []
            for a in e.args:
                s, c = self.expr(a)
                stmts += s
                args.append(self.materialize(stmts, c))
            if len(args) < 期望:               # 缺参用默认值补齐（默认值在调用处求值）
                缺省 = self.缺省参数.get(e.name, [])
                给了 = len(args)                # 循环里 args 会变长，先记下用户真正给的数量
                for 槽 in range(len(args), 期望):
                    节点 = 缺省[槽] if 槽 < len(缺省) else None
                    if 节点 is None:
                        self.err(e, f"函数 '{e.name}' 至少要 {槽 + 1} 个参数，实际给了 {给了} 个"
                                    f"（第 {槽 + 1} 个参数没有默认值，不能省）")
                    s, c = self.expr(节点)
                    stmts += s
                    args.append(self.materialize(stmts, c))
            return stmts, f'{self.fname(e.name)}({", ".join(args)})'
        if isinstance(e, Member):
            st, base = self.expr(e.base)
            return st, f'rt_obj_get_prop({base}, {cstr(e.attr)})'
        if isinstance(e, MethodCall):
            return self.gen_methodcall(e)
        if isinstance(e, CtorExpr):
            return self.gen_ctor(e)
        if isinstance(e, StaticCall):
            cd = self.classes.get(e.class_name)
            if cd is None:
                self.err(e, f"未定义的类 '{e.class_name}'")
            full = e.class_name + '.' + e.name
            if full not in self.fns:
                self.err(e, f"类 '{e.class_name}' 没有静态方法 '{e.name}'")
            stmts = []
            args = []
            for a in e.args:
                s2, c2 = self.expr(a)
                stmts += s2
                args.append(self.materialize(stmts, c2))
            return stmts, f'{self.fname(full)}({", ".join(args)})'
        if isinstance(e, StaticRef):
            cd = self.classes.get(e.class_name)
            if cd is None:
                self.err(e, f"未定义的类 '{e.class_name}'")
            idx = self._static_field_index(e.class_name, e.name)
            if idx is None:
                self.err(e, f"类 '{e.class_name}' 没有静态字段 '{e.name}'")
            return [], f'RT_S_{e.class_name}_{idx}'
        if isinstance(e, Lambda):
            # mec lambda：预扫描已编号（e.n），降级为顶层函数 __mec_lam_N，
            # 表达式求值为它的函数名（字符串），配合 mec.apply / 变量调用语法糖使用
            return [], f'rt_str({cstr(f"__mec_lam_{e.n}")})'
        self.err(e, f'不支持的表达式节点 {type(e).__name__}')

    # ---- 游戏零件内置调用（键监听 / 终端画布） ----

    # 标准库：语言名 → C 函数名（te/mt/rd 在 pybook_lib.c，
    # list 扩展在 pybook_rt.c，file 在 pybook_file.c）
    LIB_C_NAMES = {
        'set.添加': 'rt_set_add', 'set.删掉': 'rt_set_del', 'set.含': 'rt_set_has',
        'set.长度': 'rt_set_len', 'set.列表': 'rt_set_items', 'set.新': 'rt_set_new',
        'te.split': 'rt_lib_te_split', 'te.replace': 'rt_lib_te_replace',
        'te.trim': 'rt_lib_te_trim', 'te.upper': 'rt_lib_te_upper',
        'te.lower': 'rt_lib_te_lower', 'te.has': 'rt_lib_te_has',
        'te.len': 'rt_lib_te_len', 'te.cut': 'rt_lib_te_cut',
        'te.join': 'rt_lib_te_join', 'te.chr': 'rt_lib_te_chr',
        # smoke.*（Smokeroor）
        'smoke.check': 'rt_smoke_check', 'smoke.deleted': 'rt_smoke_deleted',
        'smoke.locked': 'rt_smoke_locked', 'smoke.type': 'rt_smoke_type',
        'smoke.mem': 'rt_smoke_mem', 'smoke.leak': 'rt_smoke_leak',
        'smoke.dangling': 'rt_smoke_dangling', 'smoke.roots': 'rt_smoke_roots',
        'smoke.heap': 'rt_smoke_heap', 'smoke.errors': 'rt_smoke_errors',
        'smoke.mode': 'rt_smoke_mode', 'smoke.selftest': 'rt_smoke_selftest',
        'smoke.gc_stats': 'rt_smoke_gc_stats', 'smoke.frame_end': 'rt_smoke_frame_end',
        'smoke.expect': 'rt_smoke_expect', 'smoke.require': 'rt_smoke_require',
        # re.*（正则：零依赖自研引擎，实现见 pybook_re.c）
        're.match': 'rt_lib_re_match', 're.find': 'rt_lib_re_find',
        're.sub': 'rt_lib_re_sub', 're.valid': 'rt_lib_re_valid', 're.groups': 'rt_lib_re_groups',
        'mt.sqrt': 'rt_lib_mt_sqrt', 'mt.pow': 'rt_lib_mt_pow',
        'mt.abs': 'rt_lib_mt_abs', 'mt.ceil': 'rt_lib_mt_ceil',
        'mt.floor': 'rt_lib_mt_floor', 'mt.mod': 'rt_lib_mt_mod',
        'mt.max': 'rt_lib_mt_max', 'mt.min': 'rt_lib_mt_min',
        'mt.dist': 'rt_lib_mt_dist', 'mt.prod': 'rt_lib_mt_prod', 'mt.sum': 'rt_lib_mt_sum', 'mt.sin': 'rt_lib_mt_sin',
        'dict.keys': 'rt_dict_keys', 'dict.values': 'rt_dict_values', 'dict.byvalue': 'rt_dict_byvalue',
        # dict.get 与 safe.get 是同一个函数：safe.get 早就有了，但藏在 safe. 前缀下
        # （而且 `safe.get(...)` 会被解析成方法调用而报错），这里用 dict. 前缀重新露出来。
        'dict.get': 'rt_safe_get', 'dict.set': 'rt_dict_put',
        'dict.max': 'rt_dict_max', 'dict.min': 'rt_dict_min',
        'safe.get': 'rt_safe_get', 'safe.at': 'rt_safe_at', 'js.parse': 'rt_js_parse', 'js.dump': 'rt_js_dump', 'csv.parse': 'rt_csv_parse', 'csv.dump': 'rt_csv_dump', 'mm.色': 'rt_mm_color', 'mm.draw_away': 'rt_mm_draw_away', 'mm.贴': 'rt_mm_blt', 'mm.color': 'rt_mm_color', 'mm.blt': 'rt_mm_blt', 'mm.动': 'rt_mm_anim', 'mm.anim': 'rt_mm_anim', 'mm.存': 'rt_mm_save', 'mm.save': 'rt_mm_save', 'mm.读': 'rt_mm_load', 'mm.load': 'rt_mm_load', 'mm.转': 'rt_mm_xform', 'mm.xform': 'rt_mm_xform', 'mm.描边': 'rt_mm_outline', 'mm.outline': 'rt_mm_outline', 'mm.平铺': 'rt_mm_tile', 'mm.tile': 'rt_mm_tile', 'mm.拼': 'rt_mm_paste', 'mm.paste': 'rt_mm_paste', 'mm.渐变': 'rt_mm_grad', 'mm.grad': 'rt_mm_grad', 'mm.反色': 'rt_mm_invert', 'mm.invert': 'rt_mm_invert',
        # 图.* 图表与函数图像 / 表.* 表格（实现见 pybook_plot.c）
        '图.画布': 'rt_plot_canvas',
        'plt.canvas': 'rt_plot_canvas',
        '图.画布色': 'rt_plot_canvasbg',
        'plt.canvasbg': 'rt_plot_canvasbg',
        '图.清': 'rt_plot_clear',
        'plt.clear': 'rt_plot_clear',
        '图.存': 'rt_plot_save',
        'plt.save': 'rt_plot_save',
        '图.尺寸': 'rt_plot_size',
        'plt.size': 'rt_plot_size',
        '图.像素': 'rt_plot_pixel',
        'plt.pixel': 'rt_plot_pixel',
        '图.读像素': 'rt_plot_at',
        'plt.at': 'rt_plot_at',
        '图.线': 'rt_plot_line',
        'plt.line': 'rt_plot_line',
        '图.框': 'rt_plot_rect',
        'plt.rect': 'rt_plot_rect',
        '图.圆': 'rt_plot_circle',
        'plt.circle': 'rt_plot_circle',
        '图.字': 'rt_plot_text',
        'plt.text': 'rt_plot_text',
        '图.轴': 'rt_plot_axis',
        'plt.axis': 'rt_plot_axis',
        '图.折线': 'rt_plot_line2',
        'plt.polyline': 'rt_plot_line2',
        '图.散点': 'rt_plot_scatter',
        'plt.scatter': 'rt_plot_scatter',
        '图.柱状': 'rt_plot_bar',
        'plt.bar': 'rt_plot_bar',
        '图.直方': 'rt_plot_hist',
        'plt.hist': 'rt_plot_hist',
        '图.饼图': 'rt_plot_pie',
        'plt.pie': 'rt_plot_pie',
        '图.图例': 'rt_plot_legend',
        'plt.legend': 'rt_plot_legend',
        '图.色板': 'rt_plot_palette',
        'plt.palette': 'rt_plot_palette',
        '图.试值': 'rt_plot_eval',
        'plt.eval': 'rt_plot_eval',
        # sym 接入：导数 / 切线 / 渐近线 / 面积（实现在 pybook_plot.c，依赖 sym_core_*）
        '图.导数': 'rt_plot_deriv',
        'plt.deriv': 'rt_plot_deriv',
        '图.切线': 'rt_plot_tangent',
        'plt.tangent': 'rt_plot_tangent',
        '图.渐近线': 'rt_plot_asym',
        'plt.asym': 'rt_plot_asym',
        '图.面积': 'rt_plot_area',
        'plt.area': 'rt_plot_area',
        '图.曲线': 'rt_plot_fx',
        'plt.fx': 'rt_plot_fx',
        '图.函数': 'rt_plot_fun',
        'plt.fun': 'rt_plot_fun',
        '表.画': 'rt_tbl_render',
        'tbl.show': 'rt_tbl_render',
        '表.宽': 'rt_tbl_size',
        'tbl.size': 'rt_tbl_size',
        '表.列': 'rt_tbl_col',
        'tbl.col': 'rt_tbl_col',
        '表.行': 'rt_tbl_row',
        'tbl.row': 'rt_tbl_row',
        '表.格': 'rt_tbl_cellat',
        'tbl.cell': 'rt_tbl_cellat',
        '表.转': 'rt_tbl_transpose',
        'tbl.transpose': 'rt_tbl_transpose',
        '表.选': 'rt_tbl_slice',
        'tbl.slice': 'rt_tbl_slice',
        '表.排': 'rt_tbl_sort',
        'tbl.sort': 'rt_tbl_sort',
        '表.并': 'rt_tbl_concat',
        'tbl.concat': 'rt_tbl_concat',
        '表.接': 'rt_tbl_hconcat',
        'tbl.hconcat': 'rt_tbl_hconcat',
        '表.统': 'rt_tbl_stats',
        'tbl.stats': 'rt_tbl_stats',
        '表.补': 'rt_tbl_fill',
        'tbl.fill': 'rt_tbl_fill',  'list.flat': 'rt_list_flat', 'list.zip': 'rt_list_zip', 'list.count': 'rt_list_count',
        # obj.* 3D 建模 -> .obj 落盘（实现在 pybook_obj.c）
        'obj.清': 'rt_obj_clear', 'obj.clear': 'rt_obj_clear',
        'obj.点': 'rt_obj_vertex', 'obj.vertex': 'rt_obj_vertex',
        'obj.面': 'rt_obj_face', 'obj.face': 'rt_obj_face',
        'obj.面4': 'rt_obj_quad', 'obj.quad': 'rt_obj_quad',
        'obj.块': 'rt_obj_box', 'obj.box': 'rt_obj_box',
        'obj.球': 'rt_obj_sphere', 'obj.sphere': 'rt_obj_sphere',
        'obj.柱': 'rt_obj_cyl', 'obj.cyl': 'rt_obj_cyl',
        'obj.存': 'rt_obj_save', 'obj.save': 'rt_obj_save',
        'obj.点数': 'rt_obj_vcount', 'obj.vcount': 'rt_obj_vcount',
        'obj.面数': 'rt_obj_fcount', 'obj.fcount': 'rt_obj_fcount',
        # 接线.* / wire.* 接线式测试（实现在 pybook_wire.c）
        '接线.接': 'rt_wire_tap', 'wire.tap': 'rt_wire_tap',
        '接线.迹': 'rt_wire_trace', 'wire.trace': 'rt_wire_trace',
        '接线.迹数': 'rt_wire_tcount', 'wire.tcount': 'rt_wire_tcount',
        '接线.例': 'rt_wire_case', 'wire.case': 'rt_wire_case',
        '接线.边界': 'rt_wire_edge', 'wire.edge': 'rt_wire_edge',
        '接线.乱序': 'rt_wire_shuffle', 'wire.shuffle': 'rt_wire_shuffle',
        '接线.脏串': 'rt_wire_dirtystr', 'wire.dirtystr': 'rt_wire_dirtystr',
        '接线.脏数': 'rt_wire_dirtynum', 'wire.dirtynum': 'rt_wire_dirtynum',
        '接线.脏表': 'rt_wire_dirtylist', 'wire.dirtylist': 'rt_wire_dirtylist',
        '接线.炸': 'rt_wire_boom', 'wire.boom': 'rt_wire_boom',
        '接线.快照': 'rt_wire_snap', 'wire.snap': 'rt_wire_snap',
        '接线.对照': 'rt_wire_diff', 'wire.diff': 'rt_wire_diff',
        '接线.报': 'rt_wire_report', 'wire.report': 'rt_wire_report',
        '接线.败数': 'rt_wire_fails', 'wire.fails': 'rt_wire_fails',
        '接线.清': 'rt_wire_clear', 'wire.clear': 'rt_wire_clear',
        'mt.cos': 'rt_lib_mt_cos', 'mt.tan': 'rt_lib_mt_tan',
        'mt.pi': 'rt_lib_mt_pi',
        'rd.int': 'rt_lib_rd_int', 'rd.float': 'rt_lib_rd_float',
        'rd.pick': 'rt_lib_rd_pick', 'rd.shuffle': 'rt_lib_rd_shuffle',
        'tb.softmax': 'rt_tb_softmax', 'tb.crossent': 'rt_tb_crossent',
        'tb.crossent_grad': 'rt_tb_crossent_grad', 'tb.argmax': 'rt_tb_argmax',
        'tb.sgd': 'rt_tb_sgd', 'tb.adam': 'rt_tb_adam',
        'tb.shuffle': 'rt_tb_shuffle', 'tb.onehot': 'rt_tb_onehot', 'tb.batch': 'rt_tb_batch',
        'tb.conv2d': 'rt_tb_conv2d', 'tb.conv2d_dx': 'rt_tb_conv2d_dx',
        'tb.conv2d_dk': 'rt_tb_conv2d_dk', 'tb.conv2d_db': 'rt_tb_conv2d_db',
        'tb.maxpool': 'rt_tb_maxpool', 'tb.maxpool_dx': 'rt_tb_maxpool_dx',
        'tb.avgpool': 'rt_tb_avgpool', 'tb.avgpool_dx': 'rt_tb_avgpool_dx',
        'tb.dropout': 'rt_tb_dropout', 'tb.dropout_dx': 'rt_tb_dropout_dx',
        'tb.batchnorm': 'rt_tb_batchnorm', 'tb.batchnorm_dx': 'rt_tb_batchnorm_dx',
        'tb.layernorm': 'rt_tb_layernorm', 'tb.layernorm_dx': 'rt_tb_layernorm_dx',
        'list.sort': 'rt_list_sort', 'list.sorted': 'rt_list_sorted', 'list.rsorted': 'rt_list_rsorted', 'list.reverse': 'rt_list_reverse', 'list.byfield': 'rt_list_byfield',
        'list.unique': 'rt_list_unique', 'list.merge': 'rt_list_merge',
        'list.find': 'rt_list_find', 'list.max': 'rt_list_max',
        'list.min': 'rt_list_min',
        # bs.* 位运算（实现在 pybook_bits.c）
        'bs.and': 'rt_bs_and', 'bs.or': 'rt_bs_or', 'bs.xor': 'rt_bs_xor',
        'bs.not': 'rt_bs_not', 'bs.shl': 'rt_bs_shl', 'bs.shr': 'rt_bs_shr',
        'bs.get': 'rt_bs_get', 'bs.set': 'rt_bs_set',
        'm3.color': 'rt_m3_color', 'm3.texture': 'rt_m3_texture', 'm3.pack': 'rt_m3_pack', 'm3.uv': 'rt_m3_uv',
        'm3.glass': 'rt_m3_glass', 'm3.glow': 'rt_m3_glow', 'm3.metal': 'rt_m3_metal',
        'm3.style': 'rt_m3_style',
        'm3.draw': 'rt_m3_draw', 'm3.drawr': 'rt_m3_drawr',
        'm3.anim': 'rt_m3_anim', 'm3.animr': 'rt_m3_animr',
        'm3.save': 'rt_m3_save', 'm3.load': 'rt_m3_load',
        'm3.merge': 'rt_m3_merge', 'm3.dig': 'rt_m3_dig', 'm3.put': 'rt_m3_put',
        'm3.bounds': 'rt_m3_bounds', 'm3.count': 'rt_m3_count',
        'm3.stair': 'rt_m3_stair', 'm3.slab': 'rt_m3_slab', 'm3.wall': 'rt_m3_wall',
        'm3.pillar': 'rt_m3_pillar', 'm3.roof': 'rt_m3_roof', 'm3.fence': 'rt_m3_fence',
        'bs.popcount': 'rt_bs_popcount', 'bs.band': 'rt_bs_band',
        'bs.mask': 'rt_bs_mask', 'bs.hex': 'rt_bs_hex', 'bs.bin': 'rt_bs_bin',
        'bs.frombin': 'rt_bs_frombin', 'bs.fromhex': 'rt_bs_fromhex',
        '圆': 'rt_game_circle', 'circle': 'rt_game_circle',
        'mt.atan2': 'rt_lib_mt_atan2',
        'hw.open': 'rt_hw_open', 'hw.clearcolor': 'rt_hw_clearcolor',
        'hw.camera': 'rt_hw_camera', 'hw.box': 'rt_hw_box',
        'hw.fog': 'rt_hw_fog', 'hw.far': 'rt_hw_far', 'hw.wire': 'rt_hw_wire',
        # UI 同屏（2026-10）：hw.ui(区域) 指定离屏 UI 贴到画面哪儿，不调就是全屏贴
        'hw.ui': 'rt_hw_ui',
        'hw.fov': 'rt_hw_fov', 'hw.near': 'rt_hw_near',
        'hw.line': 'rt_hw_line', 'hw.light': 'rt_hw_light',
        'hw.sphere': 'rt_hw_sphere', 'hw.cyl': 'rt_hw_cylv',
        'hw.ortho': 'rt_hw_ortho',
        'ui.begin': 'rt_ui_begin', 'ui.row': 'rt_ui_row', 'ui.col': 'rt_ui_col',
        'ui.end': 'rt_ui_end', 'ui.gap': 'rt_ui_gap', 'ui.tag': 'rt_ui_tag',
        'ui.label': 'rt_ui_label', 'ui.button': 'rt_ui_button',
        'ui.input': 'rt_ui_input', 'ui.slider': 'rt_ui_slider',
        'ui.check': 'rt_ui_check', 'ui.table': 'rt_ui_table',
        # 交互注入：让 PYbook 自己脚本化"点一下按钮/拖滑条"，把 ui.* 的
        # **交互**也变成可回归的（原先只能人手点窗口，改状态机没有回归可跑）。
        'ui.测试输入': 'rt_ui_test_input', 'ui.测试输入恢复': 'rt_ui_test_input_reset',
        'ui.矩形': 'rt_ui_rect', 'ui.分组': 'rt_ui_group',
        # 外观风格：圆角 / 字符边框（TUI），后者是"由字符组成的边框"那套
        'ui.样式': 'rt_ui_style', 'ui.字格': 'rt_ui_cell',
        # 离屏：UI 不自己开窗，渲进内存 surface，由 3D 每帧贴上去（3D + UI 同屏）
        'ui.离屏': 'rt_ui_offscreen',
  # 图片：静态图 + 序列动画（实现在 pybook_ui.c；序列时钟用 QPC 而非 tm.now()）
  'ui.图': 'rt_ui_img', 'ui.序列': 'rt_ui_seq',
  # 粒子：UI 里的粒子挂件（占位 + 推进布局，和 ui.图 同级）
  'ui.粒子': 'rt_ui_fx', 'ui.粒子调': 'rt_ui_fx_tune',
        'hw.tex': 'rt_hw_tex', 'hw.texuse': 'rt_hw_texuse', 'hw.uv': 'rt_hw_uv',
        'hw.obj': 'rt_hw_obj', 'hw.objinfo': 'rt_hw_objinfo',
        'hw.objfix': 'rt_hw_objfix', 'hw.objcolor': 'rt_hw_objcolor',
        'hw.objdraw': 'rt_hw_objdraw', 'hw.objdrawr': 'rt_hw_objdrawr',
        'hw.objfree': 'rt_hw_objfree', 'hw.objh': 'rt_hw_objh',
        'hw.push': 'rt_hw_push', 'hw.pop': 'rt_hw_pop',
        'hw.shader': 'rt_hw_shader', 'hw.preset': 'rt_hw_preset',
        'hw.shaderuse': 'rt_hw_shaderuse', 'hw.uni': 'rt_hw_univ',
        'hw.grab': 'rt_hw_grab', 'hw.free': 'rt_hw_free',
        'hw.mdx': 'rt_hw_mdx', 'hw.mdy': 'rt_hw_mdy',
        'np.zeros': 'rt_np_zeros', 'np.range': 'rt_np_range',
        'np.add': 'rt_np_add', 'np.sub': 'rt_np_sub', 'np.mul': 'rt_np_mul',
        'np.scale': 'rt_np_scale', 'np.dot': 'rt_np_dot', 'np.norm': 'rt_np_norm',
        'np.normalize': 'rt_np_normalize', 'np.max': 'rt_np_max', 'np.min': 'rt_np_min',
        'np.sum': 'rt_np_sum', 'np.mean': 'rt_np_mean',
        'np.sin': 'rt_np_sin', 'np.cos': 'rt_np_cos', 'np.sqrt': 'rt_np_sqrt',
        'np.exp': 'rt_np_exp', 'np.log': 'rt_np_log', 'np.log2': 'rt_np_log2',
        'np.log10': 'rt_np_log10', 'np.expm1': 'rt_np_expm1', 'np.log1p': 'rt_np_log1p',
        'np.tan': 'rt_np_tan', 'np.atan': 'rt_np_atan', 'np.cbrt': 'rt_np_cbrt',
        'np.erf': 'rt_np_erf', 'np.erfc': 'rt_np_erfc',
        'np.gamma': 'rt_np_gamma', 'np.lgamma': 'rt_np_lgamma',
        'np.abs': 'rt_np_abs', 'np.floor': 'rt_np_floor', 'np.ceil': 'rt_np_ceil',
        'np.round': 'rt_np_round', 'np.sign': 'rt_np_sign', 'np.pow': 'rt_np_pow',
        'tb.mat': 'rt_tb_mat', 'tb.rand': 'rt_tb_rand',
        'tb.mat32': 'rt_tb_mat32', 'tb.rand32': 'rt_tb_rand32',
        'tb.gpu': 'rt_tb_is_gpu', 'tb.gpuname': 'rt_tb_gpu_name',
        'tb.rows': 'rt_tb_rows', 'tb.cols': 'rt_tb_cols',
        'tb.dot': 'rt_tb_dot', 'tb.tr': 'rt_tb_tr',
        'tb.save': 'rt_tb_save', 'tb.load': 'rt_tb_load',
        # 特殊函数 / 一维极值 / 插值拟合（pybook_lib.c）
        'mt.erf': 'rt_lib_mt_erf',
        'mt.erfc': 'rt_lib_mt_erfc',
        'mt.gamma': 'rt_lib_mt_gamma',
        'mt.lgamma': 'rt_lib_mt_lgamma',
        'mt.zeta': 'rt_lib_mt_zeta',
        'mt.golden_min': 'rt_lib_mt_golden_min',
        'mt.golden_max': 'rt_lib_mt_golden_max',
        'mp.interp_linear': 'rt_lib_mp_interp_linear',
        'mp.interp_cubic': 'rt_lib_mp_interp_cubic',
        'mp.linfit': 'rt_lib_mp_linfit',
        'mp.polyfit': 'rt_lib_mp_polyfit',
        # 数值微积分与求根（pybook_lib.c，依赖运行时回调槽）
        'mt.deriv': 'rt_lib_mt_deriv',
        'mt.integrate': 'rt_lib_mt_integrate',
        'mt.root_bisect': 'rt_lib_mt_root_bisect',
        'mt.root_newton': 'rt_lib_mt_root_newton',
        'mt.root_newton_d': 'rt_lib_mt_root_newton_d',
        'mt.taylor': 'rt_lib_mt_taylor',
        # 随机分布 + 统计补齐 + rd.seed（随机源统一后）
        'mp.rand_exponential': 'rt_lib_mp_rand_exponential',
        'mp.rand_poisson': 'rt_lib_mp_rand_poisson',
        'mp.rand_geom': 'rt_lib_mp_rand_geom',
        'mp.rand_binom': 'rt_lib_mp_rand_binom',
        'mp.rand_gamma': 'rt_lib_mp_rand_gamma',
        'mp.rand_beta': 'rt_lib_mp_rand_beta',
        'mp.rand_lognormal': 'rt_lib_mp_rand_lognormal',
        'mp.rand_logistic': 'rt_lib_mp_rand_logistic',
        'mp.median': 'rt_lib_mp_median',
        'mp.mode': 'rt_lib_mp_mode',
        'mp.quantile': 'rt_lib_mp_quantile',
        'mp.percentile': 'rt_lib_mp_percentile',
        'mp.cov': 'rt_lib_mp_cov',
        'mp.corr': 'rt_lib_mp_corr',
        'mp.cumsum': 'rt_lib_mp_cumsum',
        'mp.diff': 'rt_lib_mp_diff',
        'rd.seed': 'rt_lib_rd_seed',
        # 基础数学补齐（exp/log 族、反三角、双曲、符号与特判）
        'mt.exp': 'rt_lib_mt_exp',
        'mt.expm1': 'rt_lib_mt_expm1',
        'mt.log': 'rt_lib_mt_log',
        'mt.log2': 'rt_lib_mt_log2',
        'mt.log10': 'rt_lib_mt_log10',
        'mt.log1p': 'rt_lib_mt_log1p',
        'mt.asin': 'rt_lib_mt_asin',
        'mt.acos': 'rt_lib_mt_acos',
        'mt.atan': 'rt_lib_mt_atan',
        'mt.sinh': 'rt_lib_mt_sinh',
        'mt.cosh': 'rt_lib_mt_cosh',
        'mt.tanh': 'rt_lib_mt_tanh',
        'mt.asinh': 'rt_lib_mt_asinh',
        'mt.acosh': 'rt_lib_mt_acosh',
        'mt.atanh': 'rt_lib_mt_atanh',
        'mt.cbrt': 'rt_lib_mt_cbrt',
        'mt.hypot': 'rt_lib_mt_hypot',
        'mt.trunc': 'rt_lib_mt_trunc',
        'mt.sign': 'rt_lib_mt_sign',
        'mt.fmod': 'rt_lib_mt_fmod',
        'mt.is_nan': 'rt_lib_mt_is_nan',
        'mt.is_inf': 'rt_lib_mt_is_inf',
        # 线性代数（pybook_la.c）
        'tb.lu': 'rt_lib_tb_lu',
        'tb.solve': 'rt_lib_tb_solve',
        'tb.det': 'rt_lib_tb_det',
        'tb.logdet': 'rt_lib_tb_logdet',
        'tb.inv': 'rt_lib_tb_inv',
        'tb.cond': 'rt_lib_tb_cond',
        'tb.rank': 'rt_lib_tb_rank',
        'tb.qr': 'rt_lib_tb_qr',
        'tb.lstsq': 'rt_lib_tb_lstsq',
        'tb.cholesky': 'rt_lib_tb_cholesky',
        'tb.eig_sym': 'rt_lib_tb_eig_sym',
        'tb.svd': 'rt_lib_tb_svd',
        'mp.mat_lu': 'rt_lib_mp_mat_lu',
        'mp.mat_solve': 'rt_lib_mp_mat_solve',
        'mp.mat_qr': 'rt_lib_mp_mat_qr',
        'mp.mat_svd': 'rt_lib_mp_mat_svd',
        'mp.mat_eig_sym': 'rt_lib_mp_mat_eig_sym',
        'mp.mat_cholesky': 'rt_lib_mp_mat_cholesky',
        'mp.mat_ls': 'rt_lib_mp_mat_ls',
        'mp.mat_rank': 'rt_lib_mp_mat_rank',
        'mp.mat_cond': 'rt_lib_mp_mat_cond',
        'mp.mat_logdet': 'rt_lib_mp_mat_logdet',
        'mp.to_tensor': 'rt_lib_mp_to_tensor',
        'tb.add': 'rt_tb_add', 'tb.mul': 'rt_tb_mul', 'tb.addrow': 'rt_tb_addrow',
        'tb.relu': 'rt_tb_relu', 'tb.relu_grad': 'rt_tb_relu_grad',
        'tb.sigmoid': 'rt_tb_sigmoid', 'tb.sigmoid_grad': 'rt_tb_sigmoid_grad',
        'tb.mse': 'rt_tb_mse', 'tb.mse_grad': 'rt_tb_mse_grad',
        'tb.lin': 'rt_tb_lin', 'tb.lin_dx': 'rt_tb_lin_dx',
        'tb.lin_dw': 'rt_tb_lin_dw', 'tb.lin_db': 'rt_tb_lin_db',
        'tb.step': 'rt_tb_step',
        # tensor.* 张量一等类型（实现在 pybook_rt.c）
        'tensor.get': 'rt_tensor_get', 'tensor.set': 'rt_tensor_set',
        'tensor.slice': 'rt_tensor_slice', 'tensor.from': 'rt_tensor_from_list',
        'tensor.to_list': 'rt_tensor_to_list',
        'tensor.cast': 'rt_tensor_cast_v', 'tensor.prec': 'rt_tensor_prec_v',
        'mp.vec_add': 'rt_lib_mp_vec_add', 'mp.vec_sub': 'rt_lib_mp_vec_sub',
        'mp.vec_scale': 'rt_lib_mp_vec_scale', 'mp.vec_dot': 'rt_lib_mp_vec_dot',
        'mp.vec_norm': 'rt_lib_mp_vec_norm', 'mp.vec_dist': 'rt_lib_mp_vec_dist',
        'mp.vec_cross': 'rt_lib_mp_vec_cross', 'mp.vec_lerp': 'rt_lib_mp_vec_lerp',
        'mp.mat_add': 'rt_lib_mp_mat_add', 'mp.mat_scale': 'rt_lib_mp_mat_scale',
        'mp.mat_mul': 'rt_lib_mp_mat_mul', 'mp.mat_transpose': 'rt_lib_mp_mat_transpose',
        'mp.mat_identity': 'rt_lib_mp_mat_identity', 'mp.mat_det': 'rt_lib_mp_mat_det',
        'mp.mat_inverse': 'rt_lib_mp_mat_inverse', 'mp.mat_vec_mul': 'rt_lib_mp_mat_vec_mul',
        'mp.mean': 'rt_lib_mp_mean', 'mp.var': 'rt_lib_mp_var', 'mp.std': 'rt_lib_mp_std',
        'mp.sum': 'rt_lib_mp_sum', 'mp.minmax': 'rt_lib_mp_minmax', 'mp.linspace': 'rt_lib_mp_linspace',
        'mp.clamp': 'rt_lib_mp_clamp', 'mp.smoothstep': 'rt_lib_mp_smoothstep',
        'mp.lerp': 'rt_lib_mp_lerp', 'mp.radians': 'rt_lib_mp_radians', 'mp.degrees': 'rt_lib_mp_degrees',
        'mp.rand_seed': 'rt_lib_mp_rand_seed', 'mp.rand_u01': 'rt_lib_mp_rand_u01',
        'mp.rand_normal': 'rt_lib_mp_rand_normal',
        'sym.解析': 'rt_lib_sym_parse',
        'sym.求导': 'rt_lib_sym_diff',
        'sym.积分': 'rt_lib_sym_integrate',
        'sym.化简': 'rt_lib_sym_simplify',
        'sym.展开': 'rt_lib_sym_expand',
        'sym.求值': 'rt_lib_sym_eval',
        'sym.变量': 'rt_lib_sym_vars',
        'sym.替换': 'rt_lib_sym_subst',
        'sym.相等': 'rt_lib_sym_equal',
        'sym.求解': 'rt_lib_sym_solve',
        'sym.格式': 'rt_lib_sym_format',
        'sym.解方程组': 'rt_lib_sym_solve_sys',
        'sym.极限': 'rt_lib_sym_limit',
        'sym.级数': 'rt_lib_sym_series',
        'hw.frame': 'rt_hw_frame', 'hw.end': 'rt_hw_end',
        'hw.key': 'rt_hw_key', 'hw.hit': 'rt_hw_hit',
        'hw.mx': 'rt_hw_mx', 'hw.my': 'rt_hw_my',
        'hw.mdown': 'rt_hw_mdown', 'hw.mhit': 'rt_hw_mhit',
        'hw.wininfo': 'rt_hw_wininfo',
        'hw.resize': 'rt_hw_resize',
        'hw.rdown': 'rt_hw_rdown', 'hw.rhit': 'rt_hw_rhit',
        'hw.text': 'rt_hw_text',
        'hw.textc': 'rt_hw_textc', 'hw.rect': 'rt_hw_rect',
        'hw.post': 'rt_hw_post', 'hw.postfx': 'rt_hw_postfx',
        # mec.*（Modernized_code）：apply 的函数体由 generate() 生成进 out.c
        'mec.apply': 'rt_mec_apply', 'mec.kind': 'rt_mec_kind',
        'hw.bloom': 'rt_hw_bloom',
        'hw.particles_clear': 'rt_hw_particles_clear',
        'hw.burst': 'rt_hw_burst', 'hw.particles': 'rt_hw_particles',
        'hw.shadow': 'rt_hw_shadow', 'hw.shadowres': 'rt_hw_shadowres',
        'hw.shadowarea': 'rt_hw_shadowarea', 'hw.shadowbias': 'rt_hw_shadowbias',
        'hw.shadowcenter': 'rt_hw_shadowcenter',
        'hw.wheel': 'rt_hw_wheel',
        '圆': 'rt_game_circle', 'circle': 'rt_game_circle',
        'mt.atan2': 'rt_lib_mt_atan2',
        'mt.clamp': 'rt_lib_mp_clamp', 'mt.lerp': 'rt_lib_mp_lerp',
        'te.str': 'rt_lib_te_str',
        'net.listen': 'rt_net_listen', 'net.accept': 'rt_net_accept',
        'net.connect': 'rt_net_connect', 'net.recv': 'rt_net_read',
        'net.readline': 'rt_net_read_block', 'net.send': 'rt_net_write',
        'net.close': 'rt_net_close',
        'net.udp': 'rt_net_udp', 'net.sendto': 'rt_net_sendto',
        'net.recvfrom': 'rt_net_recvfrom', 'net.recvfrom_wait': 'rt_net_recvfrom_block',
        # crypto.*（实现在 pybook_crypto.c）
        'crypto.随机': 'rt_crypto_random', 'crypto.random': 'rt_crypto_random',
        'crypto.摘要': 'rt_crypto_digest', 'crypto.digest': 'rt_crypto_digest',
        'crypto.派生': 'rt_crypto_derive', 'crypto.derive': 'rt_crypto_derive',
        'crypto.签名': 'rt_crypto_sign', 'crypto.sign': 'rt_crypto_sign',
        'crypto.加密': 'rt_crypto_encrypt', 'crypto.encrypt': 'rt_crypto_encrypt',
        'crypto.解密': 'rt_crypto_decrypt', 'crypto.decrypt': 'rt_crypto_decrypt',
        # te.读行 / te.试读行（实现在 pybook_file.c；中文名走别名表）
        'te.readline': 'rt_te_readline', 'te.tryline': 'rt_te_tryline',
        # chat.*（实现在 pybook_net.c）
        'chat.中继': 'rt_chat_relay', 'chat.relay': 'rt_chat_relay',
        'chat.加入': 'rt_chat_join', 'chat.join': 'rt_chat_join',
        'chat.说': 'rt_chat_say', 'chat.say': 'rt_chat_say',
        'chat.听': 'rt_chat_listen', 'chat.listen': 'rt_chat_listen',
        'chat.跑': 'rt_chat_run', 'chat.run': 'rt_chat_run',
        'http.get': 'rt_http_get', 'http.code': 'rt_http_code',
        'http.listen': 'rt_http_listen', 'http.serve': 'rt_http_serve',
        'http.req': 'rt_http_req', 'http.resp': 'rt_http_resp',
        'http.post': 'rt_http_post',
        'http.err': 'rt_http_err', 'http.header': 'rt_http_header',
        'http.headers': 'rt_http_headers', 'http.config': 'rt_http_config',
        'file.read': 'rt_file_read', 'file.write': 'rt_file_write',
        'file.add': 'rt_file_add', 'file.exists': 'rt_file_exists',
        'file.lines': 'rt_file_lines', 'file.del': 'rt_file_del',
        'file.size': 'rt_file_size', 'file.list': 'rt_file_list',
        'file.split': 'rt_file_split', 'file.join': 'rt_file_join',
        'tm.now': 'rt_lib_tm_now',
        '音.正弦': 'rt_mu_sine', '音.三角': 'rt_mu_tri',
        '音.快': 'rt_mu_quick',
        '音.放': 'rt_mu_play', '音.停': 'rt_mu_stop',
        '音.音': 'rt_mu_note', '音.奏': 'rt_mu_away', '音.谱': 'rt_mu_play_list', '音.音量': 'rt_mu_volume_set', '音.包络': 'rt_mu_env_set', '音.包络值': 'rt_mu_env_at', '音.乐器': 'rt_mu_instr_set', '音.乐器表': 'rt_mu_instr_list', '音.演': 'rt_mu_play_instr', 
        'mu.sine': 'rt_mu_sine', 'mu.tri': 'rt_mu_tri', 'mu.quick': 'rt_mu_quick',
        'mu.play': 'rt_mu_play', 'mu.stop': 'rt_mu_stop',
        'mu.note': 'rt_mu_note', 'mu.away': 'rt_mu_away', 'mu.play_list': 'rt_mu_play_list',
        '调色板.红': 'rt_lib_pal_hong', '调色板.橙': 'rt_lib_pal_cheng',
        '调色板.黄': 'rt_lib_pal_huang', '调色板.绿': 'rt_lib_pal_lv',
        '调色板.青': 'rt_lib_pal_qing', '调色板.蓝': 'rt_lib_pal_lan',
        '调色板.紫': 'rt_lib_pal_zi', '调色板.白': 'rt_lib_pal_bai',
        '调色板.黑': 'rt_lib_pal_hei', '调色板.灰': 'rt_lib_pal_hui',
        '调色板.粉': 'rt_lib_pal_fen', '调色板.金': 'rt_lib_pal_jin',
    }

    # ---- ffi.* FFI: low-level window (compile-time expansion to real C calls) ----

    def _ffi_classify(self, t, node):
        """C type -> conversion class int/flt/str/ptr/void. Returns (class, normalized)."""
        t = re.sub(r'\s+', ' ', t.strip()).replace('*', ' * ')
        t = re.sub(r'\s+', ' ', t).strip()
        tl = t.lower()
        if '(' in t or ')' in t:
            self.err(node, 'ffi.声明 暂不支持函数指针参数\n'
                           '  为什么：函数指针签名太复杂，自动解析会出错\n'
                           '  怎么改：用 ffi.码(...) 手写一个 C 包装函数，再声明包装函数')
        if 'struct' in tl or 'union' in tl or 'enum' in tl:
            self.err(node, f'ffi.声明 暂不支持结构体/联合/枚举传值：{t}\n'
                           '  为什么：这类值没有对应的 PYbook 值类型\n'
                           '  怎么改：用指针传（void*），到 C 那边自己解引用')
        if t == 'void':
            return 'void', t
        if t.endswith('*'):
            base = t[:-1].strip().replace('const', '').strip()
            return ('str' if base == 'char' else 'ptr'), t
        if re.search(r'\b(double|float)\b', tl):
            return 'flt', t
        return 'int', t

    def _ffi_params(self, ps, node):
        ps = ps.strip()
        if not ps or ps == 'void':
            return []
        out = []
        for p in ps.split(','):
            p = p.strip()
            if not p:
                self.err(node, 'ffi.声明 的参数表里有空项\n'
                               '  为什么：逗号之间要有参数类型\n'
                               '  怎么改：删掉多余逗号；没有参数就写 (void) 或 ()')
            toks = p.replace('*', ' * ').split()
            last = toks[-1]
            if (len(toks) >= 2 and re.fullmatch(r'[A-Za-z_]\w*', last)
                    and not re.search(r'\b(double|float|int|long|short|char|void|unsigned|signed|size_t|bool)\b', last)
                    and not last.endswith('_t')):
                ptype = ' '.join(toks[:-1])   # trailing token is a param name, drop it
            else:
                ptype = ' '.join(toks)
            cls, norm = self._ffi_classify(ptype, node)
            out.append((cls, norm))
        return out

    def _register_c_decl(self, sig, node):
        """Parse 'ret name(param types, ...)' and register. Idempotent for same sig."""
        sig = sig.strip().rstrip(';')
        m = re.match(r'^([\w \t*]+?)\s+(\w+)\s*\(([^()]*)\)$', sig.replace('*', ' * '))
        if not m:
            self.err(node, f'ffi.声明 的签名读不懂：{sig!r}\n'
                           '  为什么：格式是「返回类型 函数名(参数类型, ...)」，类型只认 C 基本类型和指针\n'
                           '  怎么改：例如 ffi.声明("int strlen(char*)")；返回类型和函数名之间要有空格')
        ret_t, name, ps = m.group(1).strip(), m.group(2), m.group(3)
        ret_cls, ret_norm = self._ffi_classify(ret_t, node)
        params = self._ffi_params(ps, node)
        decl = (ret_cls, ret_norm, params)
        prev = self.c_decls.get(name)
        if prev:
            if prev != decl:
                self.err(node, f'C 函数 {name} 之前声明过，且和这次不一样\n'
                               '  为什么：同一个函数两种签名，编译器不知道听谁的\n'
                               '  怎么改：删掉一个 ffi.声明，保持全文件一致')
            return decl
        self.c_decls[name] = decl
        self.c_ffi_proto.append(f'{ret_norm} {name}(' + ', '.join(t for _, t in params) + ');')
        return decl

    def _collect_c_decls(self, program):
        """Pre-scan: register every ffi.声明 first (functions may compile before the decl)."""
        stack = [program]
        seen = set()
        while stack:
            n = stack.pop()
            if id(n) in seen:
                continue
            seen.add(id(n))
            if isinstance(n, list):
                stack.extend(n)
            elif isinstance(n, Call) and n.name == 'ffi.声明':
                if n.args and isinstance(n.args[0], StrLit):
                    self._register_c_decl(n.args[0].value, n)
            elif hasattr(n, '__dict__'):
                stack.extend(vars(n).values())

    def gen_c_ffi(self, e):
        """ffi.包含 / ffi.链接 / ffi.声明 / ffi.码 / ffi.调用."""
        op = e.name
        if op != 'ffi.调用':
            a = e.args[0]
            if not isinstance(a, StrLit):
                self.err(e, f'{op} 的参数必须是文本字面量（直接写在引号里）\n'
                            '  为什么：它在编译期生效，参数不能是变量\n'
                            '  怎么改：写成字面量，如 ffi.声明("int puts(char*)")')
            s = a.value.strip()
            if op == 'ffi.包含':
                self.c_includes.append(s)
            elif op == 'ffi.链接':
                self.c_libs.append(s)
            elif op == 'ffi.声明':
                self._register_c_decl(s, e)
            else:
                self.c_raw.append(s)          # ffi.码: raw C at file scope
            return [], 'rt_none()'

        a0 = e.args[0]
        if not isinstance(a0, StrLit):
            self.err(e, 'ffi.调用 的第一个参数（函数名）必须是文本字面量\n'
                        '  为什么：编译期要知道调哪个函数、参数怎么转\n'
                        '  怎么改：写 ffi.调用("strlen", ...)；函数名不能用变量')
        fname = a0.value.strip()
        if fname not in self.c_decls:
            self.err(e, f'C 函数 {fname} 没声明过就调用\n'
                        '  为什么：不知道参数和返回类型，编译器没法生成调用\n'
                        f'  怎么改：先 ffi.声明("返回类型 {fname}(参数类型...)")，再 ffi.调用')
        ret_cls, ret_t, params = self.c_decls[fname]
        if len(e.args) - 1 != len(params):
            self.err(e, f'{fname} 声明了 {len(params)} 个参数，这里给了 {len(e.args) - 1} 个\n'
                        '  为什么：ffi.调用 的参数要和 ffi.声明 严格对上（类型也按声明转）\n'
                        '  怎么改：对照 ffi.声明 的参数表补/删参数')
        stmts = []
        cargs = []
        for (pcls, ptype), a in zip(params, e.args[1:]):
            st, c = self.expr(a)
            stmts += st
            c = self.materialize(stmts, c)
            conv = {'int': 'rt_ffi_int', 'flt': 'rt_ffi_flt',
                    'str': 'rt_ffi_str', 'ptr': 'rt_ffi_ptr'}[pcls]
            cargs.append(f'(({ptype}){conv}({c}))')
        call = f'{fname}({", ".join(cargs)})'
        if ret_cls == 'void':
            return stmts, f'((void)({call}), rt_none())'
        if ret_cls == 'int':
            return stmts, f'rt_int((long long)({call}))'
        if ret_cls == 'flt':
            return stmts, f'rt_float((double)({call}))'
        if ret_cls == 'str':
            return stmts, f'rt_ffi_str_ret({call})'
        return stmts, f'rt_int((long long)(uintptr_t)({call}))'

    def gen_clib_call(self, e):
        """调用同目录 C 库里的函数。

        跟 ffi.调用 走同一套 FFI 桥（rt_ffi_int / rt_ffi_flt / rt_ffi_str /
        rt_ffi_ptr / rt_ffi_str_ret），区别只是签名不是手写 ffi.声明 来的，
        而是从同目录 .c/.h 里自动解析出来的。
        """
        fname = e.name
        ret_cls, _ret_t, params = self.clib_decls[fname]
        if len(e.args) != len(params):
            self.err(e, f'C 库函数 {fname} 要 {len(params)} 个参数，这里给了 {len(e.args)} 个\n'
                        f'  为什么：签名是从 C 原型自动解析的，参数个数必须对上\n'
                        f'  怎么改：补齐参数；或把 C 那边的签名改成可变参（...）再手写 ffi.声明')
        stmts = []
        cargs = []
        for (pcls, ptype), a in zip(params, e.args):
            st, c = self.expr(a)
            stmts += st
            c = self.materialize(stmts, c)
            conv = {'int': 'rt_ffi_int', 'flt': 'rt_ffi_flt',
                    'str': 'rt_ffi_str', 'ptr': 'rt_ffi_ptr'}[pcls]
            cargs.append(f'(({ptype}){conv}({c}))')
        call = f'{fname}({", ".join(cargs)})'
        if ret_cls == 'void':
            return stmts, f'((void)({call}), rt_none())'
        if ret_cls == 'int':
            return stmts, f'rt_int((long long)({call}))'
        if ret_cls == 'flt':
            return stmts, f'rt_float((double)({call}))'
        if ret_cls == 'str':
            return stmts, f'rt_ffi_str_ret({call})'
        return stmts, f'rt_int((long long)(uintptr_t)({call}))'

    def gen_lib_call(self, e):
        # 测试.*（测试框架标准库）：断言走 rt_test_check，复用 查() 的失败计数/退出码
        if e.name.startswith('测试.'):
            return self.gen_test_call(e)
        # ffi.* (low-level window): expand into real C calls
        if e.name.startswith('ffi.'):
            return self.gen_c_ffi(e)
        # smoke.*（Smokeroor）：它的职责就是"检查变量现在什么状态"，参数绝不能被
        # rt_chk 拦下 —— 否则传参那一步就报"用已删除变量"，smoke.check 反而收不到
        # 最需要检查的那些变量（已删除/悬垂）。这里一律走原始槽。
        if e.name.startswith('smoke.'):
            stmts = []
            args = []
            for a in e.args:
                if isinstance(a, VarRef):
                    self.check_declared(a)
                    args.append(self.vname(a.name))   # 不包 rt_chk
                else:
                    s, c = self.expr(a)
                    stmts += s
                    args.append(self.materialize(stmts, c))
            return stmts, '%s(%s)' % (self.LIB_C_NAMES[e.name], ", ".join(args))
        # hw.text / hw.textc：最后一个参数是文本，可能带 $( ) 插值，要先拼成
        # C 字符串再 materialize（其余参数都是数值表达式）。hw.text 是 4 参、
        # hw.textc 是 7 参，所以按"末位参数"判，别写死下标 3。
        if e.name in ('hw.text', 'hw.textc'):
            stmts = []
            args = []
            for k4, a4 in enumerate(e.args):
                if k4 == len(e.args) - 1 and isinstance(a4, StrParts):
                    s4, c4 = self._interp_concat(a4)
                    stmts += s4
                    args.append(self.materialize(stmts, c4))
                    continue
                s5, c5 = self.expr(a4)
                stmts += s5
                args.append(self.materialize(stmts, c5))
            return stmts, '%s(%s)' % (self.LIB_C_NAMES[e.name], ", ".join(args))

        # 网页专用控件：ui.按钮 / ui.输入框 / ui.滑条 —— 只能写在 web.实时 块里。
        # 注意别写成 startswith('ui.')：桌面 GUI 的 ui.begin / ui.button / ui.input
        # 是另一套（实现在 pybook_ui.c），要放它们走下面的通用分发。
        if e.name in ('ui.按钮', 'ui.输入框', 'ui.滑条'):
            self.err(e, f'{e.name} 只在网页模式支持（写在 web.实时 块里）')
        # net.send 发一行：codegen 层自动补换行（rt_net_write 只发原样字节，
        # 这也是 C 层自测能构造半包场景的基础）
        if e.name == 'net.send':
            if len(e.args) != 2:
                self.err(e, 'net.send 需要 2 个参数')
            st_h, c_h = self.expr(e.args[0])
            st_t, c_t = self.expr(e.args[1])
            stmts = st_h + st_t
            tmp = self.materialize(stmts, f'rt_add({c_t}, rt_str({cstr(NL_CHAR)}))')
            return stmts, f'rt_net_write({c_h}, {tmp})'
        c_func = self.LIB_C_NAMES[e.name]
        if e.name.startswith('hw.'):
            self.hw_used = True
        want = LIB_CALLS[e.name]
        # (最少,最多) 形式的入口：少给的要补空盒。判据是「want 是不是元组」，
        # 不能用 want[1] > len(args) —— 用户给满参数时那条为假，会掉回定长校验。
        isopt = isinstance(want, tuple)
        opt = isopt and want[1] > len(e.args)
        if e.name == 'hw.box' and len(e.args) == 12:
            pass                        # 带绕 x/y/z 旋转的写法：走 rt_hw_boxn
        elif e.name == 'hw.cyl' and len(e.args) == 10:
            pass                        # cyl 带自定义边数的写法：走 rt_hw_cylv
        elif e.name == 'hw.uni' and 2 <= len(e.args) <= 5:
            pass                        # uni("名字", a[, b[, c[, d]]])：1~4 个分量
        elif e.name == 'hw.ui' and len(e.args) in (0, 1, 4):
            pass                        # ui() / ui(侧栏宽) / ui(x,y,w,h) 都走 rt_hw_ui
        elif not isopt and len(e.args) != want:
            self.err(e, f'{e.name} 需要 {want} 个参数，得到 {len(e.args)} 个')
        stmts = []
        args = []
        for a in e.args:
            s, c = self.expr(a)
            stmts += s
            args.append(self.materialize(stmts, c))
        if e.name == 'hw.box' and len(e.args) == 12:
            # rt_hw_boxn(nargs, (Value[]){ ... }) —— 复合字面量，C99
            return stmts, (f'rt_hw_boxn(12, (Value[]){{ {", ".join(args)} }})')
        if e.name == 'hw.cyl':
            # rt_hw_cylv(nargs, (Value[]){ ... }) —— 9 参或 10 参都走这里
            return stmts, (f'rt_hw_cylv({len(args)}, (Value[]){{ {", ".join(args)} }})')
        if e.name == 'hw.uni':
            # rt_hw_univ(nargs, (Value[]){ ... }) —— 2~5 个实参都走这里
            return stmts, (f'rt_hw_univ({len(args)}, (Value[]){{ {", ".join(args)} }})')
        if e.name == 'hw.ui':
            # rt_hw_ui(nargs, (Value[]){ ... }) —— 0/1/4 个实参都走这里。
            # 0 参写 NULL：空的 (Value[]){ } 不是 C99，得给个能编的写法。
            if not args:
                return stmts, 'rt_hw_ui(0, NULL)'
            return stmts, (f'rt_hw_ui({len(args)}, (Value[]){{ {", ".join(args)} }})')
        if opt:
            # (最少,最多) 形式的入口且用户少给了参数：补空盒，C 层认这个当「没给」
            args += ['rt_none()'] * (want[1] - len(args))
        return stmts, f'{c_func}({", ".join(args)})'

    def gen_test_call(self, e):
        """测试.* 断言：全部走 rt_test_check（查() 同款失败计数 + 退出码）。
        置位 self.test_used，让生成的 main 返回 rt_test_summary()（失败数当退出码）。"""
        self.test_used = True
        name = e.name
        stmts = []
        if name in ('测试.断言相等', '测试.断言不等'):
            if len(e.args) != 2:
                self.err(e, name + ' 需要 2 个参数（期望, 实际）')
            sa, ca = self.expr(e.args[0])
            sb, cb = self.expr(e.args[1])
            stmts += sa + sb
            a = self.materialize(stmts, ca)
            b = self.materialize(stmts, cb)
            op = 'rt_eq' if name == '测试.断言相等' else 'rt_ne'
            stmts.append(f'rt_test_check(rt_cond({op}({a}, {b})), {cstr(name)});')
        elif name in ('测试.断言真', '测试.断言假'):
            if len(e.args) != 1:
                self.err(e, name + ' 需要 1 个参数')
            s, c = self.expr(e.args[0])
            stmts += s
            v = self.materialize(stmts, c)
            cond = f'rt_cond({v})' if name == '测试.断言真' else f'!rt_cond({v})'
            stmts.append(f'rt_test_check({cond}, {cstr(name)});')
        elif name == '测试.断言抛出':
            if len(e.args) != 1:
                self.err(e, name + ' 需要 1 个参数（应当抛错的 表达式）')
            s, c = self.expr(e.args[0])
            # 复用 gen_trycatch 的 setjmp 机制：表达式抛错 → _threw=1。
            # 注意：子表达式的求值语句 s 必须放在 setjmp 块【内部】，
            # 否则 rt_div(1,0) 这类会在块外先算出来、抛错时还没进 try（曾经踩过）。
            stmts.append('{')
            stmts.append('  void *_ep = rt_err_push();')
            stmts.append('  int _threw = 0;')
            stmts.append('  if (setjmp(*(jmp_buf *)_ep) == 0) {')
            for x in s:
                stmts.append('    ' + x)
            stmts.append('    (void)(%s);' % c)
            stmts.append('    rt_err_pop(_ep);')
            stmts.append('  } else {')
            stmts.append('    _threw = 1;')
            stmts.append('    rt_err_pop(_ep);')
            stmts.append('  }')
            stmts.append('  rt_test_check(_threw, %s);' % cstr(name))
            stmts.append('}')
        else:
            self.err(e, '未知测试调用：' + name)
        return stmts, 'rt_int(0)'

    def gen_sprites_draw(self, e):
        """绘(列表)：降级成对 rt_game_img_scaled 的逐元素循环。

        语义 = 对每个元素做 图缩(e.x - 宽/2, e.y - 高/2, e.宽, e.高, e.图)；
        元素缺 x/y/宽/高/图 任一属性 → _pbk_sprop 运行时报错并带是第几个元素。"""
        if len(e.args) != 1 or not isinstance(e.args[0], VarRef):
            self.err(e, '绘 的写法：绘(列表名)')
        self.check_declared(e.args[0])
        st, lst = self.expr(e.args[0])
        i = self.newtemp('_si')
        n = self.newtemp('_sn')
        el = self.newtemp('_se')
        lines = list(st)
        lines.append('{')
        lines.append(f'    long long {n} = AS_INT(rt_len({lst}));')
        lines.append(f'    long long {i};')
        lines.append(f'    for ({i} = 0; {i} < {n}; {i}++) {{')
        lines.append(f'        Value {el} = rt_index({lst}, rt_int({i}));')
        lines.append(f'        Value _sx = _pbk_sprop({el}, "x", {i});')
        lines.append(f'        Value _sy = _pbk_sprop({el}, "y", {i});')
        lines.append(f'        Value _sw = _pbk_sprop({el}, "宽", {i});')
        lines.append(f'        Value _sh = _pbk_sprop({el}, "高", {i});')
        lines.append(f'        Value _sp = _pbk_sprop({el}, "图", {i});')
        lines.append(f'        rt_game_img_scaled(rt_sub(_sx, _pbk_half(_sw, {i})), '
                      f'rt_sub(_sy, _pbk_half(_sh, {i})), _sw, _sh, _sp);')
        lines.append('    }')
        lines.append('}')
        return lines, 'rt_none()'

    def gen_game_call(self, e: Call):
        """游戏零件 → rt_game_*（运行时现行命名）。

        key/hit 的键名要字符串字面量（免运行时拆盒）；
        win 的标题要字符串字面量（rt_game_win 第三参是 const char*）；
        clear() 无参 → 用上一条 color(字面量,...) 记下的颜色清屏
        （老脚本 color(...); clear() 的写法），带 3 个参数则直接透传；
        wait(ms) → rt_game_frame()（帧末闸门：泵事件 + 键状态翻页 + 约60FPS，
        运行时已无裸 sleep 的 rt_wait）。"""
        name = e.name
        want = GAME_CALLS[name]
        if name == 'clear' and len(e.args) == 3:
            want = 3                        # clear(r,g,b) 直接透传的新写法
        if name == 'color' and len(e.args) == 1:
            want = 1                        # color(列表) 重载：参数是 [r,g,b] 列表
        if len(e.args) != want:
            self.err(e, f"{name} 需要 {want} 个参数，得到 {len(e.args)} 个")

        if name == 'color' and len(e.args) == 1:
            # color(列表)：取列表的 0/1/2 号元素当 R/G/B。列表来自 vg_ro 或
            # 调色板.颜色名（rt_lib_pal_*，返回新建 [r,g,b] 列表）；
            # 非列表仍走 rt_index 的既有报错（照旧退出），行为不变。
            st, c = self.expr(e.args[0])
            t = self.newtemp('_pal')
            for x in st:
                self.emit(x)
            self.emit(f'Value {t} = {c};')
            return [], (f'rt_game_color(rt_index({t}, rt_int(0LL)), '
                        f'rt_index({t}, rt_int(1LL)), rt_index({t}, rt_int(2LL)))')

        if name == '绘':
            return self.gen_sprites_draw(e)

        if name in ('key', 'hit'):
            a = e.args[0]
            if not isinstance(a, StrLit):
                self.err(e, f'{name} 的键名必须是字符串字面量，如 {name}("space")')
            return [], f'rt_game_{name}({cstr(a.value)})'

        if name == 'dirkeys':
            return [], 'rt_dirkeys()'
        if name == 'frame':
            return [], 'rt_frames()'
        if name == 'sec':
            return [], 'rt_secs()'

        if name in ('字', '图', '图缩', '线', '点'):   # 中文名字面量 → C 函数名映射
            c_name = {'字': 'rt_game_text', '图': 'rt_game_img',
                      '图缩': 'rt_game_img_scaled',
                      '线': 'rt_game_line', '点': 'rt_game_dot',
                      '圆': 'rt_game_circle', 'circle': 'rt_game_circle'}[name]
            stmts = []
            args = []
            for k2, a in enumerate(e.args):
                if k2 == 2 and isinstance(a, StrParts) and name in ('字', '图'):
                    s3, c3 = self._interp_concat(a)       # "得分 $分" / "$x+1" → rt_add 链
                    stmts += s3
                    args.append(self.materialize(stmts, c3))
                    continue
                s2, c2 = self.expr(a)
                stmts += s2
                args.append(self.materialize(stmts, c2))
            return stmts, f'{c_name}({", ".join(args)})'

        if name == 'win':
            title = e.args[2]
            if not isinstance(title, StrLit):
                self.err(e, 'win 的窗口标题必须是字符串字面量')
            st = []
            vs = []
            for a in e.args[:2]:
                s2, c2 = self.expr(a)
                st += s2
                vs.append(self.materialize(st, c2))
            return st, f'rt_game_win({vs[0]}, {vs[1]}, {cstr(title.value)})'

        if name == 'color':
            lits = []
            for a in e.args:
                if not isinstance(a, NumLit) or isinstance(a.value, float):
                    lits = None
                    break
                lits.append(int(a.value))
            if lits is not None:
                self._last_color = tuple(lits)   # 供无参 clear() 使用

        if name == 'clear' and want == 0:
            r, g, b = getattr(self, '_last_color', (0, 0, 0))
            # ★ 必须装箱成 Value。这里原来直接写 rt_game_clear(11, 14, 20)，
            #   而 Value 是 typedef uint64_t —— 传裸整数在 C 里**合法且无警告**，
            #   编译器不吭声，运行时 game_num 收到的是没打标的位模式，读出 0，
            #   于是每个程序的 color(...) + clear() 背景都被清成纯黑。
            #   实测：清 (11,14,20) 的窗口，出图 100% 是 (0,0,0)。
            return [], f'rt_game_clear(rt_int({r}LL), rt_int({g}LL), rt_int({b}LL))'

        if name == 'wait':
            s2, _c2 = self.expr(e.args[0])    # 参数照常求值（保持语法检查），时长交给帧闸门
            return s2, 'rt_game_frame()'

        stmts = []
        args = []
        for a in e.args:
            s2, c2 = self.expr(a)
            stmts += s2
            args.append(self.materialize(stmts, c2))
        return stmts, f'rt_game_{name}({", ".join(args)})'

    def materialize(self, stmts, c):
        t = self.newtemp()
        stmts.append(f'Value {t} = {c};')
        return t

    def short_circuit(self, e):
        ls, lc = self.expr(e.left)
        rs, rc = self.expr(e.right)
        t = self.newtemp()
        stmts = list(ls)
        stmts.append(f'Value {t} = rt_none();')
        if e.op == 'and':      # A 为假取 A，否则取 B
            stmts.append(f'if (rt_cond({lc})) {{')
            stmts += ['    ' + x for x in rs]
            stmts.append(f'    {t} = {rc};')
            stmts.append('} else {')
            stmts.append(f'    {t} = {lc};')
            stmts.append('}')
        else:                  # or：A 为真取 A，否则取 B
            stmts.append(f'if (rt_cond({lc})) {{')
            stmts.append(f'    {t} = {lc};')
            stmts.append('} else {')
            stmts += ['    ' + x for x in rs]
            stmts.append(f'    {t} = {rc};')
            stmts.append('}')
        return stmts, t

    # ---- ④ 逃逸分析喂相位：未标注意图的函数内局部，由编译器自动推断 ----
    # 递归遍历语句/表达式节点，收集"逃逸"的局部变量名（被存进容器 / 被返回）。
    # 逃逸的变量不能当帧内短活，要升为 共享；其余默认 帧（帧内短活，相位边界即收）。
    # 为何安全：mode7 是非移动 GC（标记-清除 + 可达性），被容器引用的对象靠可达性
    # 一定存活，所以"默认 帧"绝不会误杀活对象——逃逸分析只决定"无引用垃圾何时收"。
    _ESC_STORE_NAMES = ('添加', 'set.添加', 'dict.set', 'tensor.set', 'obj.存')

    def _walk_nodes(self, node, visit):
        if node is None or isinstance(node, (str, int, float, bool)):
            return
        if isinstance(node, (list, tuple)):
            for x in node:
                self._walk_nodes(x, visit)
            return
        if hasattr(node, '__dataclass_fields__'):
            visit(node)
            for fld in node.__dataclass_fields__.values():
                self._walk_nodes(getattr(node, fld.name), visit)

    def _escape_vars(self, body):
        escaped = set()

        def visit(node):
            if isinstance(node, Ret) and isinstance(node.expr, VarRef):
                escaped.add(node.expr.name)
            elif isinstance(node, AssignMember) and isinstance(node.expr, VarRef):
                escaped.add(node.expr.name)
            elif isinstance(node, AssignIndex) and isinstance(node.expr, VarRef):
                escaped.add(node.expr.name)
            elif isinstance(node, Call) and isinstance(node.name, str):
                if node.name in self._ESC_STORE_NAMES:
                    for a in node.args[1:]:
                        if isinstance(a, VarRef):
                            escaped.add(a.name)
                elif node.name.startswith(('dict.', 'set.', 'tensor.', 'obj.')):
                    for a in node.args[1:]:
                        if isinstance(a, VarRef):
                            escaped.add(a.name)

        for s in body:
            self._walk_nodes(s, visit)
        return escaped

    # ---- 静态数值域：'i' 整数 | 'f' 浮点 | 'u' 未知 ----
    # 用途：rm.around 标量化要决定标量用 long long 还是 double。
    # 只有"确定"的域才敢用 —— 'u' 一律退回老路径，宁可慢也不算错。
    def _kind_of(self, e):
        """表达式的静态数值域。'u' = 类型不可知（调用、容器元素、未知来源…）。"""
        if isinstance(e, NumLit):
            return 'f' if isinstance(e.value, float) else 'i'
        if isinstance(e, BoolLit):
            return 'i'
        if isinstance(e, VarRef):
            return self._vg_kind.get(e.name, 'u')
        if isinstance(e, Unary) and e.op == '-':
            return self._kind_of(e.operand)
        if isinstance(e, BinOp):
            lk = self._kind_of(e.left)
            rk = self._kind_of(e.right)
            if e.op == '/':
                return 'f'                     # 真除法结果恒为浮点
            if e.op in ('%', '//'):
                return 'i' if (lk == 'i' and rk == 'i') else 'u'
            if e.op in ('==', '!=', '<', '>', '<=', '>=', 'and', 'or'):
                return 'i'                     # 比较/逻辑结果是布尔
            if 'u' in (lk, rk):
                return 'u'
            return 'f' if 'f' in (lk, rk) else 'i'
        return 'u'

    # ---- 语句 ----

    def stmt(self, s):
        if isinstance(s, VgAssign):
            if self._pk_live and s.name in self._pk_live[0]:
                code, k = self._pk_scalar_expr(s.expr)
                want = self._pk_live[1].get(s.name, 'i')
                if k != want:
                    code = f'(long long)({code})' if want == 'i' else f'(double)({code})'
                self.emit(f'S_{self.vname(s.name)} = {code};')
                return
            st, c = self.expr(s.expr)
            for x in st:
                self.emit(x)
            self.emit(f'rt_assign(&{self.vname(s.name)}, {c});')
            ta = getattr(s, 'type_annot', None)
            if ta in ('帧', '关卡', '共享', '图'):
                intent = {'帧': 1, '关卡': 2, '共享': 3, '图': 4}[ta]
                self.emit(f'rt_intent_tag({self.vname(s.name)}, {intent});')
            else:
                # ④ 逃逸分析喂相位：未标注意图时由编译器自动推断，兑现"不写也快"。
                # 模块层变量默认 共享（长活全局）；函数内局部默认 帧（帧内短活），
                # 但若逃逸（被存进容器 / 被返回）则升 共享（跨相位长活）。
                if self.in_going:
                    intent = 3
                else:
                    intent = 3 if s.name in getattr(self, '_fn_escaped', set()) else 1
                self.emit(f'rt_intent_tag({self.vname(s.name)}, {intent});')
            self._已赋值.add(s.name)
            # 静态数值域：记下这个变量此刻是什么类型。标量化靠它决定
            # 圈前旧值的读法（int 还是 float），读错会把 1.5 截成 1。
            self._vg_kind[s.name] = self._kind_of(s.expr)
            if isinstance(s.expr, CtorExpr):
                self.vtypes[s.name] = s.expr.class_name
        elif isinstance(s, MultiAssign):
            # 解包：a, b = 列表（一个列表值拆给多个目标）
            if len(s.values) == 1 and len(s.targets) > 1:
                st, c = self.expr(s.values[0])
                for x in st:
                    self.emit(x)
                src = self.newtemp()
                self.emit(f'Value {src} = {c};')
                for i, tg in enumerate(s.targets):
                    vi = self.newtemp()
                    self.emit(f'Value {vi} = rt_index({src}, rt_int({i}));')
                    if isinstance(tg, str):
                        self.emit(f'rt_assign(&{self.vname(tg)}, {vi});')
                    else:
                        self.check_declared(VarRef(tg.base.name, tg.line))
                        sti, ic = self.expr(tg.index)
                        for x in sti:
                            self.emit(x)
                        self.emit(f'rt_setindex(&{self.vname(tg.base.name)}, {ic}, {vi});')
                return
            # 右边先全部求值（交换语义正确），再逐个赋值
            vals = []
            for v in s.values:
                st, c = self.expr(v)
                for x in st:
                    self.emit(x)
                t = self.newtemp()          # 必须先物化：交换语义依赖右边先算完
                self.emit(f'Value {t} = {c};')
                vals.append(t)
            for tg, c in zip(s.targets, vals):
                if isinstance(tg, str):
                    self.emit(f'rt_assign(&{self.vname(tg)}, {c});')
                else:   # Index 目标：t[j] = 值
                    self.check_declared(VarRef(tg.base.name, tg.line))
                    sti, ic = self.expr(tg.index)
                    for x in sti:
                        self.emit(x)
                    self.emit(f'rt_setindex(&{self.vname(tg.base.name)}, {ic}, {c});')
        elif isinstance(s, IpAssign):
            self.emit(f'rt_assign(&{self.vname(s.name)}, rt_input({cstr(s.prompt)}));')
        elif isinstance(s, MemoryMode):
            self.emit(f'rt_set_memmode({s.mode});')
        elif isinstance(s, DeviceMode):
            self.emit(f'rt_device_set({s.backend}, {s.threads});')
        elif isinstance(s, JitMode):
            self.emit('/* jit 文件头指令：VM 专属加速，C 后端忽略 */')
        elif isinstance(s, Call):               # 语句形态的调用（如 list.添加(...)）
            st, c = self.expr(s)
            for x in st:
                self.emit(x)
            self.emit(f'{c};')
        elif isinstance(s, MethodCall):         # 语句形态的方法调用：对象.方法(...)
            st, c = self.expr(s)
            for x in st:
                self.emit(x)
            self.emit(f'{c};')
        elif isinstance(s, AssignStatic):       # lb.类.静态字段 = 表达式
            cd = self.classes.get(s.class_name)
            if cd is None:
                self.err(s, f"未定义的类 '{s.class_name}'")
            idx = self._static_field_index(s.class_name, s.name)
            if idx is None:
                self.err(s, f"类 '{s.class_name}' 没有静态字段 '{s.name}'")
            st, c = self.expr(s.expr)
            for x in st:
                self.emit(x)
            self.emit(f'RT_S_{s.class_name}_{idx} = {c};')
        elif isinstance(s, StaticCall):         # 语句形态的静态方法调用：lb.类.方法(...)
            st, c = self.expr(s)
            for x in st:
                self.emit(x)
            self.emit(f'{c};')
        elif isinstance(s, AssignIndex):
            self.check_declared(VarRef(s.name, s.line))
            st, ic = self.expr(s.index)
            for x in st:
                self.emit(x)
            st2, vc = self.expr(s.expr)
            for x in st2:
                self.emit(x)
            self.emit(f'rt_setindex(&{self.vname(s.name)}, {ic}, {vc});')
        elif isinstance(s, AssignMember):
            st, obj_c = self.expr(s.base)
            for x in st:
                self.emit(x)
            st2, c = self.expr(s.expr)
            for x in st2:
                self.emit(x)
            self.emit(f'rt_obj_set_prop({obj_c}, {cstr(s.attr)}, {c});')
        elif isinstance(s, GoldDel):
            self.check_declared(VarRef(s.name, s.line))
            # NaN-boxing 后 8 字节盒子里没有 flags 字段：锁定走槽侧表（rt_gold），
            # 删除把盒子改写成删除位样（rt_destroy），行为与旧 flags |= 逐字对应。
            # 注意：函数名必须与 pybook_rt.c 里定义的一致——曾经写成
            # rt_slot_lock/rt_slot_del，导致 lock/del 生成的代码根本编不过。
            fn = 'rt_gold' if s.kind == 'gold' else 'rt_destroy'
            self.emit(f'{fn}(&{self.vname(s.name)});')
        elif isinstance(s, NsShow):
            if s.vc_cond is not None:        # 短vc：vc:条件?(替代内容)
                st, c = self.expr(s.vc_cond)
                for x in st:
                    self.emit(x)
                self.emit(f'if (rt_cond({c})) {{')
                self.depth += 1
                self._emit_show_parts(s, s.parts, s.magic)
                self.depth -= 1
                self.emit('} else {')
                self.depth += 1
                self._emit_show_parts(s, s.vc_alt, [])   # magic 只作用于主内容
                self.depth -= 1
                self.emit('}')
            else:
                self._emit_show_parts(s, s.parts, s.magic)
        elif isinstance(s, TestCheck):
            self.test_used = True
            st, c_e = self.expr(s.cond)
            for x in st:
                self.emit(x)
            self.emit(f'rt_test_check(rt_cond({c_e}), {cstr(s.name)});')
        elif isinstance(s, HmStmt):
            self.gen_hm(s)
        elif isinstance(s, HmUse):
            self.gen_hm_use(s)
        elif isinstance(s, HmPageStmt):
            self.gen_hm_page(s)
        elif isinstance(s, HmDraw):
            self.gen_draw(s)
        elif isinstance(s, HmFrame):
            self.gen_frame(s)
        elif isinstance(s, HmPlay):
            self.gen_play(s)
        elif isinstance(s, HmLive):
            self.gen_live(s)
        elif isinstance(s, GoStmt):
            self.gen_go(s)
        elif isinstance(s, Around):
            if not (self._pk_on and self.try_scalar_around(s)):
                self.gen_around(s)
        elif isinstance(s, ForIn):
            self.gen_forin(s)
        elif isinstance(s, TryCatch):
            self.gen_trycatch(s)
        elif isinstance(s, OnError):
            self.gen_onerror(s)
        elif isinstance(s, Throw):
            self.gen_throw(s)
        elif isinstance(s, Aging):
            self.emit('for (;;) {')
            self.depth += 1
            st, c = self.expr(s.cond)
            for x in st:
                self.emit(x)
            self.emit(f'if (rt_cond({c})) break;')
            self.loop_depth += 1
            self.block(s.body)
            self.loop_depth -= 1
            self.depth -= 1
            self.emit('}')
        elif isinstance(s, WhileStmt):
            self.gen_while(s)
        elif isinstance(s, VcChain):
            self.gen_vc(s.arms)
        elif isinstance(s, BreakStmt):
            # PYbook 的 if/vc 链不生成 switch，C 的 break 在这里语义一致：
            # 跳出最近一层 loop（around/aging/while 的 for）
            if self.loop_depth == 0:
                self.err(s, 'break 只能在循环内使用')
            self.emit('break;')
        elif isinstance(s, ContinueStmt):
            # C 的 continue 语义与 PYbook 一致：跳到最近一层循环的下一轮。
            # 生成的循环都是 for(;;)/for(...)，continue 回到条件判断处重新求值，
            # 所以 while「先判条件再进循环体」的语义不会被跳过。
            if self.loop_depth == 0:
                self.err(s, 'continue 只能在循环内使用')
            self.emit('continue;')
        elif isinstance(s, CdBlock):
            # 单个 cd 落到这里（正常路径已被 block() 摘走）：按位置展开
            self.block(s.body)
        elif isinstance(s, Ret):
            if self.in_going:
                self.err(s, 'ret 不能出现在 GOING 里（规则：ret 只在 func 里用；'
                            'GOING 是主流程，把要复用的逻辑放进 func）')
            if s.expr is None:
                self.emit('rt_scope_leave();')
                self.emit('return rt_none();')
            else:
                st, c = self.expr(s.expr)
                for x in st:
                    self.emit(x)
                self.emit('rt_scope_leave();')
                self.emit(f'return {c};')
        else:
            self.err(s, f'不支持的语句节点 {type(s).__name__}')

    def _emit_show_parts(self, s, parts, magic):
        """一次 ns.show 的完整发射：magic 头 + TEXT/VAR/EXPR 部件 + 收尾。"""
        if magic:
            self.emit(f'rt_magic({cstr(",".join(magic))});')
        for kind, val in parts:
            if kind == 'TEXT':
                self.emit(f'rt_show_text({cstr(val)});')
            elif kind == 'EXPR':
                st, c = self.expr(val)
                for x in st:
                    self.emit(x)
                self.emit(f'rt_show_value({c});')
            else:
                st, c = self.expr(VarRef(val, s.line))
                for x in st:
                    self.emit(x)
                self.emit(f'rt_show_value({c});')
        self.emit('rt_show_end();')

    def block(self, stmts):
        """一层语句：cd 块按 priority 升序稳定排序提到本层最前，其余按书写顺序。"""
        cds = [s for s in stmts if isinstance(s, CdBlock)]
        rest = [s for s in stmts if not isinstance(s, CdBlock)]
        ordered = sorted(cds, key=lambda c: c.priority) + rest
        self.depth += 1
        for s in ordered:
            行 = getattr(s, 'line', None)
            if 行:
                self.emit(f'g_cur_line = {int(行)};')   # 运行时报错带行号
            self.stmt(s)
            # 语句边界：GC 只在这里回收（@5/@6）。求值途中绝不回收，
            # 否则没登记为根的临时值会被收走 → 悬挂指针。
            if not isinstance(s, Ret):
                self.emit('rt_gc_poll();')
        self.depth -= 1

    # ---- hm 网页输出分支 ----

    # rt_page_para_open 只接受运行时 page_style_css 的 token 方言（b/i/u/d/
    # c=R,G,B/bk=R,G,B/fm/fl/fr/l/m/r，翻译结果与 hm 样式表一一对应）。
    # f.名称 / fs.数字 两个 hm 专属样式在冻结版 pybook_rt.c 里没有对应
    # token（未知 token 会 rt_die），编译器无法下发，这里过滤——见验收说明。
    _HM_STYLE_DROP = ('f.', 'fs.')

    def hm_style(self, s) -> str:
        return ','.join(
            t for t in (item.strip() for item in s.magic)
            if t and not t.startswith(self._HM_STYLE_DROP))

    def _hm_parts(self, parts, line):
        """部件 → [(前置语句, Value C 表达式)]：TEXT→rt_str，VAR/EXPR→求值。"""
        out = []
        for kind, val in parts:
            if kind == 'TEXT':
                out.append(([], f'rt_str({cstr(val)})'))
            elif kind == 'EXPR':
                out.append(self.expr(val))
            else:
                out.append(self.expr(VarRef(val, line)))
        return out

    def _hm_concat(self, s):
        """parts 拼成一个 Value 字符串（rt_add 串联，运行时 malloc 不回收）。"""
        acc = None
        for st, c in self._hm_parts(s.parts, s.line):
            for x in st:
                self.emit(x)
            acc = c if acc is None else f'rt_add({acc}, {c})'
        return acc or 'rt_str("")'

    def _hm_concat_arg(self, part):
        """单个 part（表达式节点）转 JS 字面量（供 storage 等使用）。"""
        if isinstance(part, tuple) and part[0] == 'TEXT':
            return chr(39) + part[1].replace(chr(39), '') + chr(39)
        # 表达式节点：走 C 值再烘进页面不现实——web.storage 只支持常量
        if hasattr(part, 'value'):
            return chr(39) + str(part.value) + chr(39)
        return chr(39) + chr(39)

    def gen_hm(self, s):
        self.hm_used = True
        if not self.page_begun:      # 首条 hm 语句先落页面骨架头
            title = getattr(self, 'program_meta', '') or 'PYbook 页面'
            self.emit(f'rt_page_begin({cstr(title)});')
            self.page_begun = True
        if s.kind == 'line':
            self.emit('rt_page_hr();')
        elif s.kind == 'img':
            self.emit(f'rt_page_img({cstr(s.arg)});')
        elif s.kind == 'link':
            if s.parts and all(k == 'TEXT' for k, _v in s.parts):
                text_c = cstr(''.join(v for _k, v in s.parts))
            else:
                text_c = f'rt_str_of({self._hm_concat(s)})'
            self.emit(f'rt_page_link({text_c}, {cstr(s.arg)});')
        elif s.kind in ('big', 'mid'):
            level = 1 if s.kind == 'big' else 2
            self.emit(f'rt_page_h(rt_str_of({self._hm_concat(s)}), {level});')
        elif s.kind == 'show':
            self.emit(f'rt_page_para_open({cstr(self.hm_style(s))});')
            for st, c in self._hm_parts(s.parts, s.line):
                for x in st:
                    self.emit(x)
                self.emit(f'rt_page_value({c});')
            self.emit('rt_page_para_close();')
        elif s.kind == 'textbox':
            q = chr(39)
            self.raw('<input id=' + q + 'pybk_tb_' + s.arg + q + ' placeholder=' + q + s.parts[0][1] + q + ' style=' + q + 'font-size:16px;padding:6px 10px;border-radius:8px;border:1px solid #555;background:#14141c;color:#eee' + q + '>' + '\n')
            if s.magic and s.magic[0]:
                bid = s.magic[0]
                self.raw('<scr' + 'ipt>document.getElementById(' + q + 'pybk_tb_' + s.arg + q + ').addEventListener(' + q + 'keydown' + q + ',function(e){if(e.key===' + q + 'Enter' + q + '){window.__pybkBTN[' + q + bid + q + ']=1;}});</scr' + 'ipt>' + '\n')

        elif s.kind == 'button':
            q = chr(39)
            self.raw('<button id=' + q + 'pybk_btn_' + s.arg + q + ' style=' + q + 'font-size:16px;padding:6px 14px;border-radius:8px;border:0;background:#50fa7b;color:#111;cursor:pointer' + q + '>' + s.parts[0][1] + '</button>' + '\n')
            self.raw('<script>document.getElementById(' + q + 'pybk_btn_' + s.arg + q + ').addEventListener(' + q + 'mousedown' + q + ',function(){window.__pybkBTN[' + q + s.arg + q + ']=1;});document.addEventListener(' + q + 'mouseup' + q + ',function(){window.__pybkBTN[' + q + s.arg + q + ']=0;});</script>' + '\n')
        elif s.kind == 'audio':
            q = chr(39)
            self.raw('<audio id=' + q + 'pybk_audio' + q + ' src=' + q + s.parts[0][1] + q + ' preload=' + q + 'auto' + q + '></audio>' + '\n')
        elif s.kind == 'audio_stop':
            q = chr(39)
            self.raw('<script>var _a=document.getElementById(' + q + 'pybk_audio' + q + ');if(_a){_a.pause();_a.currentTime=0;}</script>' + '\n')
        elif s.kind == 'set':
            self.err(s, 'web.置 只能在 web.实时 块里用（页面烤完输入框才存在）')
        elif s.kind == 'align':
            self.raw('<div style=text-align:' + s.parts[0][1] + '>' + '\n')
        elif s.kind == 'gap':
            self.raw('<div style=height:' + s.parts[0][1] + 'px></div>' + '\n')
        elif s.kind == 'open':
            self.raw('<script>window.open(' + chr(39) + s.arg + chr(39) + ',' + chr(39) + '_blank' + chr(39) + ');</script>' + '\n')
        elif s.kind == 'style':
            self.raw('<style>' + s.arg + '</style>' + '\n')
        elif s.kind == 'storage':
            karg = self._hm_concat_arg(s.parts[0])
            varg = self._hm_concat_arg(s.parts[1])
            js = 'try{localStorage.setItem(' + karg + ',' + varg + ');}catch(e){}'
            self.raw('<scr' + 'ipt>' + js + '</scr' + 'ipt>' + '\n')
        elif s.kind == 'waitsec':
            self.raw('<div id=pybk_wait' + str(self.wait_n) + '></div>' + '\n')
            self.raw('<scr' + 'ipt>var w' + str(self.wait_n) + '=' + s.parts[0][1] + ';setInterval(function(){w' + str(self.wait_n) + '-=0.1;if(w' + str(self.wait_n) + '<=0)clearInterval(this)},100);</scr' + 'ipt>' + '\n')
            self.wait_n = getattr(self, 'wait_n', 0) + 1
        elif s.kind == 'title':
            self.raw('<script>document.title=' + chr(39) + s.arg + chr(39) + ';</script>' + '\n')
        else:
            self.err(s, f'未知的 web 语句 web.{s.kind}')

    # ---- web.draw 画布绘图 ----

    def raw(self, js):
        if self._frame_plan is not None:   # 帧体：JS 片段先进计划，web.播放 时统一发射
            self._frame_plan.append(('raw', js))
        else:
            self.emit(f'rt_page_raw({cstr(js)});')

    def draw_val(self, t):
        if self._frame_plan is not None:
            self._frame_plan.append(('val', t))
        else:
            self.emit(f'rt_page_text(rt_str_of({t}));')

    def _draw_param(self, e):
        st, c = self.expr(e)
        for x in st:
            self.emit(x)
        t = self.newtemp('_d')
        self.emit(f'Value {t} = {c};')
        return t

    def gen_draw(self, s):
        self.hm_used = True
        if not self.page_begun:      # 画布同样要落在页面骨架里
            title = getattr(self, 'program_meta', '') or 'PYbook 页面'
            self.emit(f'rt_page_begin({cstr(title)});')
            self.page_begun = True
        if s.cmd == 'begin':
            if self.in_draw is not None:
                self.err(s, 'web.draw.始 嵌套：上一块画布还没用 web.draw.终 结束')
            self.draw_n += 1
            self.in_draw = self.draw_n
            n = str(self.draw_n)
            w, h = 400, 300
            if len(s.params) == 2 and isinstance(s.params[0], NumLit) \
                    and isinstance(s.params[1], NumLit):
                w, h = s.params[0].value, s.params[1].value
            self._canvas_size[self.in_draw] = (w, h)
            self.raw('<canvas id="pybook-canvas-' + n + '" width="' + str(w)
                     + '" height="' + str(h) + '"></canvas>\n')
            self.raw('<script>\nconst ctx' + n + ' = document.getElementById(\'pybook-canvas-' + n + '\').getContext(\'2d\');\n')
            return
        if self.in_draw is None:
            self.err(s, f'web.draw.{s.cmd} 必须在 web.draw.始 之后使用')
        ctx = f'ctx{self.in_draw}'
        temps = []
        for k2, e2 in enumerate(s.params):
            if s.cmd == 'text' and k2 == 2 and isinstance(e2, StrParts):
                s3, c3 = self._interp_concat(e2)
                stmts += s3
                t = self.newtemp('_d')
                self.emit(f'Value {t} = {self.materialize(stmts, c3)};')
                temps.append(t)
            else:
                temps.append(self._draw_param(e2))
        if s.cmd == 'color':
            self.raw(ctx + ".fillStyle = 'rgb(")
            self.draw_val(temps[0])
            self.raw(',')
            self.draw_val(temps[1])
            self.raw(',')
            self.draw_val(temps[2])
            self.raw(")';\n")
            self.raw(ctx + ".strokeStyle = 'rgb(")
            self.draw_val(temps[0])
            self.raw(',')
            self.draw_val(temps[1])
            self.raw(',')
            self.draw_val(temps[2])
            self.raw(")';\n")
        elif s.cmd == 'circle':
            self.raw(ctx + '.beginPath();')
            self.raw(ctx + '.arc(')
            self.draw_val(temps[0])
            self.raw(',')
            self.draw_val(temps[1])
            self.raw(',')
            self.draw_val(temps[2])
            self.raw(',0,Math.PI*2);')
            self.raw(ctx + '.fill();')
            self.raw('\n')
        elif s.cmd == 'rect':
            self.raw(ctx + '.fillRect(')
            self.draw_val(temps[0])
            self.raw(',')
            self.draw_val(temps[1])
            self.raw(',')
            self.draw_val(temps[2])
            self.raw(',')
            self.draw_val(temps[3])
            self.raw(');\n')
        elif s.cmd == 'line':
            self.raw(ctx + '.beginPath();')
            self.raw(ctx + '.moveTo(')
            self.draw_val(temps[0])
            self.raw(',')
            self.draw_val(temps[1])
            self.raw(');\n')
            self.raw(ctx + '.lineTo(')
            self.draw_val(temps[2])
            self.raw(',')
            self.draw_val(temps[3])
            self.raw(');\n')
            self.raw(ctx + '.stroke();')
            self.raw('\n')
        elif s.cmd == 'clear':
            self.raw(ctx + ".fillStyle = 'rgb(")
            self.draw_val(temps[0])
            self.raw(',')
            self.draw_val(temps[1])
            self.raw(',')
            self.draw_val(temps[2])
            self.raw(")';\n")
            cw, ch = self._canvas_size.get(self.in_draw, (400, 300))
            self.raw(ctx + f'.fillRect(0, 0, {cw}, {ch});\n')
        elif s.cmd == 'text':
            self.raw(ctx + '.font = "')
            self.draw_val(temps[3])
            self.raw("px 'Microsoft YaHei UI', sans-serif\";\n")
            self.raw(ctx + '.fillText("')
            self.draw_val(temps[2])
            self.raw('", ')
            self.draw_val(temps[0])
            self.raw(',')
            self.draw_val(temps[1])
            self.raw(');\n')
        elif s.cmd in ('img_draw', 'img_scaled'):
            self.err(s, 'web.draw.图/图缩 要写在 web.实时 块里用（图片是异步加载的，静态画布画不上）')
        elif s.cmd == 'end':
            self.raw('</script>\n')
            self.in_draw = None
        else:
            self.err(s, f'未知的画布命令 {s.cmd}')

    # ---- web.帧 / web.播放 / go：帧动画与画布整体移动（仅原生模式）----

    def _need_canvas(self, s, what):
        if not self.in_going:
            self.err(s, f'{what} 只能写在 GOING 里')
        if self.in_draw is None:
            self.err(s, f'{what} 必须写在 web.draw.始 和 web.draw.终 之间')

    def gen_frame(self, s: HmFrame):
        """web.帧：把帧体的绘图语句收集成 JS 片段计划。

        参数表达式照常在当下求值（C 临时变量随语句位置发射），JS 文本
        存进计划，等 web.播放 时再包进 pybk_frames 数组统一发射。"""
        self.hm_used = True
        self._need_canvas(s, 'web.帧')
        for st in s.body:
            if isinstance(st, Call) and st.name == '绘':
                self.err(st, '绘 只能在窗口模式或 web.实时 里用（网页静态画布不支持精灵）')
            if not isinstance(st, HmDraw):
                self.err(st, 'web.帧 块里只能放 web.draw.* 绘图语句')
            if st.cmd in ('begin', 'end'):
                self.err(st, 'web.帧 里不能用 web.draw.始/终')
        plan = []
        self._frame_plan = plan
        for st in s.body:
            self.gen_draw(st)
        self._frame_plan = None
        self.hm_frames.append(plan)

    def gen_play(self, s: HmPlay):
        """web.播放(速度)：发射 pybk_frames 函数数组 + setInterval 循环。"""
        self.hm_used = True
        self._need_canvas(s, 'web.播放')
        if not self.hm_frames:
            self.err(s, 'web.播放 前必须至少有一个 web.帧')
        ctx = f'ctx{self.in_draw}'
        speed = self._draw_param(s.speed)
        self.play_n += 1
        sfx = '' if self.play_n == 1 else str(self.play_n)   # 多段播放时 JS 名去重
        fs, fi = f'pybk_frames{sfx}', f'pybk_frame{sfx}'
        self.raw(f'const {fs} = [\n')
        last = len(self.hm_frames) - 1
        for k, plan in enumerate(self.hm_frames):
            self.raw('function() {')
            for kind, x in plan:
                if kind == 'raw':
                    self.raw(x)
                else:
                    self.draw_val(x)
            self.raw('}' + (',\n' if k < last else '\n'))
        self.raw('];\n')
        self.raw(f'let {fi} = 0;\n')
        pw, ph = self._canvas_size.get(self.in_draw, (400, 300))
        self.raw('setInterval(function() {\n')
        self.raw(f'{ctx}.clearRect(0, 0, {pw}, {ph});\n')
        self.raw(f'{fs}[{fi} % {fs}.length]();\n')
        self.raw(f'{fi}++;\n')
        self.raw('}, 1000 / ')
        self.draw_val(speed)
        self.raw(');\n')
        self.hm_frames = []          # 已播放的帧清空：下一段播放只含其后的帧

    # ---- web.实时：浏览器里逐帧实时跑的块（PYbook→JavaScript 小编译器）----

    def gen_live(self, s: HmLive):
        """web.实时 { ... }：把块里的语句编译成 JS，写进当前画布的 <script>，
        setInterval 每秒 60 帧（或 web.实时(帧率)）循环执行。

        键盘：按键("left")=按住没放；按过("space")=这一帧刚按下（帧末清空）。
        变量：块里赋值过的名字成为 JS 变量；名字在 GOING 前文赋值过的，
        生成页面时把当时的值烤成初始值（数字）。"""
        self.hm_used = True
        if not self.page_begun:
            title = getattr(self, 'program_meta', '') or 'PYbook 页面'
            self.emit(f'rt_page_begin({cstr(title)});')
            self.page_begun = True
        self._need_canvas(s, 'web.实时')
        if self._frame_plan is not None:
            self.err(s, 'web.实时 不能写在 web.帧 里面')
        self.live_n += 1
        sfx = '' if self.live_n == 1 else str(self.live_n)
        self._live_sfx = sfx

        # 1) 收集块内赋值过的变量名（含嵌套），按首次出现顺序成为 JS 变量
        names = []

        def scan(sts):
            for st in sts:
                if isinstance(st, (VgAssign, AssignIndex)):
                    if st.name not in names:
                        names.append(st.name)
                elif isinstance(st, VcChain):
                    for _c, b in st.arms:
                        scan(b)
                elif isinstance(st, Around):
                    scan(st.body)

        scan(s.body)

        # 2) 键盘基建：keys=按住表，pressed=本帧刚按下集合（帧末清空）
        self.raw(f'const PYBK_KEYS{sfx} = {{}};\n')
        self.raw(f'const PYBK_PRESSED{sfx} = new Set();\n')
        self.raw(f'function PYBK_KEYMAP{sfx}(n) {{ var m = '
                 '{left:"ArrowLeft", right:"ArrowRight", up:"ArrowUp", down:"ArrowDown", '
                 'space:" ", enter:"Enter", esc:"Escape", '
                 '左:"ArrowLeft", 右:"ArrowRight", 上:"ArrowUp", 下:"ArrowDown", '
                 '空格:" ", 回车:"Enter"}; return m[n] !== undefined ? m[n] : n; }\n')
        self.raw(f'function PYBK_NUM{sfx}(v) {{ var n = parseFloat(v); '
                 f'if (!isNaN(n)) return n; '
                 f'try {{ var a = JSON.parse(v); if (Array.isArray(a)) return a; }} catch (e) {{}} '
                 f'return v; }}\n')
        self.raw(f'document.addEventListener("keydown", function(e) {{ '
                 f'if (!PYBK_KEYS{sfx}[e.key]) PYBK_PRESSED{sfx}.add(e.key); '
                 f'PYBK_KEYS{sfx}[e.key] = true; '
                 f'if (e.key.indexOf("Arrow") === 0 || e.key === " ") e.preventDefault(); }});\n')
        self.raw(f'document.addEventListener("keyup", function(e) {{ '
                 f'PYBK_KEYS{sfx}[e.key] = false; }});\n')
        # 鼠标：位置/按下/抬起（逻辑坐标按画布尺寸换算）
        mw, mh = self._canvas_size.get(self.in_draw, (400, 300))
        self.raw(('(function(){ var cv = document.getElementById("pybook-canvas-' + str(self.in_draw) + '");'
                 ' function hw_mm(e){ var r = cv.getBoundingClientRect();'
                 f' window.__pybkMX = (e.clientX - r.left) * {mw} / r.width;'
                 f' window.__pybkMY = (e.clientY - r.top) * {mh} / r.height; }}'
                 ' cv.addEventListener("mousemove", hw_mm);'
                 ' cv.addEventListener("mousedown", function(e){ hw_mm(e);'
                 ' window.__pybkMD = true; window.__pybkMH = true; window.__pybkCLICK = true; });'
                 ' document.addEventListener("mouseup", function(){ window.__pybkMD = false; });'
                 '})();\n'))
        # UI 控件运行时（按钮/输入框/滑条），CTXNAME 替换为本块 ctx 名
        self.raw(_UI_RUNTIME.replace('CTXNAME', 'ctx' + str(self.in_draw)))
        self.raw(f'window.__pybkBTN{sfx} = {{}};' + chr(10));        self.raw(f'window.__pybkTB{sfx} = {{}};' + chr(10));        self.raw(f'function PYBK_STR{sfx}(v) {{ return (typeof v === "object") ? JSON.stringify(v) : String(v); }}' + chr(10));        self.raw(f'function PYBK_STRLEN{sfx}(v) {{ var sv = (typeof v === "object") ? JSON.stringify(v) : String(v); var n2 = 0; for (var _i = 0; _i < sv.length; _i++) {{ n2 += (sv.charCodeAt(_i) & 0xF800) === 0xD800 ? 0 : 1; }} return n2; }}' + chr(10));        self.raw(f'setInterval(function() {{ var ins = document.querySelectorAll("[id^=pybk_tb_]"); for (var i2 = 0; i2 < ins.length; i2++) {{ window.__pybkTB{sfx}[ins[i2].id.replace("pybk_tb_", "")] = ins[i2].value; }} }}, 100);' + chr(10));
        # 2.5) 图片资源预加载：实时块里 web.draw.图/图缩 用到的路径先建 Image
        imgs = []

        def scan_img(sts):
            for st in sts:
                if isinstance(st, HmDraw) and st.cmd in ('img_draw', 'img_scaled'):
                    pth = st.params[-1]
                    if not isinstance(pth, StrLit):
                        self.err(st, 'web.draw.图/图缩 的文件名必须是字符串字面量，'
                                     '如 web.draw.图(10, 10, "飞机.png")')
                    if pth.value not in imgs:
                        imgs.append(pth.value)
                elif isinstance(st, VcChain):
                    for _c, b in st.arms:
                        scan_img(b)
                elif isinstance(st, (Around, ForIn)):
                    scan_img(st.body)

        scan_img(s.body)
        self.raw(f'const PYBK_IMGS{sfx} = {{}};\n')
        for pth in imgs:
            self.raw(f'PYBK_IMGS{sfx}[{cstr(pth)}] = new Image(); '
                     f'PYBK_IMGS{sfx}[{cstr(pth)}].src = {cstr(pth)};\n')

        # 3) JS 变量声明：块内赋值过的 ∪ GOING 前文声明过的；后者的初始值
        #    用 PYBK_NUM("…") 包住运行时烤进来的文本——数字转数，其余原样
        js_names = list(names)
        for name in self.vmap:
            if name in self.declared and name not in js_names:
                js_names.append(name)
        self._live_declared = set(js_names)
        for name in js_names:
            if name in self.vmap and name in self.declared:
                t = self.newtemp('_lv')
                self.emit(f'Value {t} = rt_chk({self.vname(name)});')
                self.raw(f'let V_{name} = PYBK_NUM{sfx}("')
                self.emit(f'rt_page_text(rt_str_of({t}));')
                self.raw('");\n')
            else:
                self.raw(f'let V_{name} = 0;\n')

        # 4) 帧函数：块体逐句翻译，帧末清空"刚按下"集合
        self.raw(f'function PYBK_LIVE{sfx}() {{\n')
        lines = []
        lines.append(f'__pybkCLICK{sfx} = (window.__pybkCLICK{sfx} === true);')
        lines.append(f'window.__pybkCLICK{sfx} = false;')
        self._live_loop = 0
        for st in s.body:
            self.live_stmt(st, lines)
        lines.append(f'PYBK_PRESSED{sfx}.clear();')
        lines.append('window.__pybkMH = false;')
        for ln_js in lines:
            self.raw('  ' + ln_js + '\n')
        self.raw('}\n')

        # 5) 驱动：先跑一帧再定时循环（固定步长，和显示器刷新率无关）
        fps = 60 if s.fps is None else int(s.fps)
        self.raw(f'PYBK_LIVE{sfx}();\n')
        self.raw(f'setInterval(PYBK_LIVE{sfx}, 1000 / {fps});\n')
        self._live_sfx = None
        self._live_declared = set()

    def live_stmt(self, s, lines):
        if isinstance(s, Call) and s.name in ('add', 'remove'):
            s = Call({'add': '添加', 'remove': '删掉'}[s.name], s.args, s.line)
        if isinstance(s, Call) and s.name == '绘':
            self.live_sprites(s, lines)
            return
        if isinstance(s, VgAssign):
            if s.name not in self._live_declared:
                self.err(s, f'web.实时 里用的变量 {s.name} 没有赋值过（写在块里或 GOING 前文）')
            lines.append(f'V_{s.name} = {self.js_expr(s.expr)};')
        elif isinstance(s, AssignIndex):
            if s.name not in self._live_declared:
                self.err(s, f'web.实时 里用的变量 {s.name} 没有赋值过')
            lines.append(f'V_{s.name}[{self.js_expr(s.index)}] = {self.js_expr(s.expr)};')
        elif isinstance(s, Call):
            if s.name == '添加':
                if len(s.args) != 2 or not isinstance(s.args[0], VarRef):
                    self.err(s, '实时块里 添加 的写法：添加(列表名, 值)')
                if s.args[0].name not in self._live_declared:
                    self.err(s, f'web.实时 里用的变量 {s.args[0].name} 没有赋值过')
                lines.append(f'V_{s.args[0].name}.push({self.js_expr(s.args[1])});')
            elif s.name == '删掉':
                if len(s.args) != 2 or not isinstance(s.args[0], VarRef):
                    self.err(s, '实时块里 删掉 的写法：删掉(列表名, 元素)')
                if s.args[0].name not in self._live_declared:
                    self.err(s, f'web.实时 里用的变量 {s.args[0].name} 没有赋值过')
                lines.append(f'V_{s.args[0].name}.splice(V_{s.args[0].name}.indexOf({self.js_expr(s.args[1])}), 1);')
            else:
                lines.append(f'{self.js_expr(s)};')
        elif isinstance(s, AssignMember):
            base = self.js_expr(s.base)
            if s.base not in () and isinstance(s.base, VarRef)                     and s.base.name not in self._live_declared:
                self.err(s, f'web.实时 里用的变量 {s.base.name} 没有赋值过')
            lines.append(f'{base}[{self.js_expr(StrLit(s.attr, s.line))}] = {self.js_expr(s.expr)};')
        elif isinstance(s, VcChain):
            self.live_vc(s.arms, lines)
        elif isinstance(s, Around):
            varname = getattr(s, 'var', 'at')
            self._live_declared.add(varname)
            self._live_loop += 1
            lines.append(f'for (let V_{varname} = 0; V_{varname} < '
                         f'{self.js_expr(s.times)}; V_{varname}++) {{')
            for st in s.body:
                self.live_stmt(st, lines)
            self._live_loop -= 1
            lines.append('}')
        elif isinstance(s, ForIn):
            self._live_declared.add(s.var)
            self._live_loop += 1
            self._live_for_n = getattr(self, '_live_for_n', 0) + 1
            i_name = f'_i{self._live_for_n}'
            lines.append(f'for (let {i_name} = 0; {i_name} < {self.js_expr(s.iter)}.length; {i_name}++) {{')
            lines.append(f'const V_{s.var} = {self.js_expr(s.iter)}[{i_name}];')
            for st in s.body:
                self.live_stmt(st, lines)
            self._live_loop -= 1
            lines.append('}')
        elif isinstance(s, BreakStmt):
            if self._live_loop == 0:
                self.err(s, 'break 只能在实时块的 rm.around 里使用')
            lines.append('break;')
        elif isinstance(s, HmDraw):
            lines.extend(self.live_draw(s))
        elif isinstance(s, NsShow):
            if s.vc_cond is not None:
                self.err(s, 'web.实时 里 ns 的 vc:条件?(替代) 写法暂不支持')
            pieces = []
            for kind, val in s.parts:
                if kind == 'TEXT':
                    pieces.append(cstr(val))
                elif kind == 'EXPR':
                    pieces.append(self.js_expr(val))
                else:
                    if val not in self._live_declared:
                        self.err(s, f'web.实时 里用的变量 {val} 没有赋值过')
                    pieces.append('V_' + val)
            lines.append('console.log(' + (' + '.join(pieces) if pieces else '""') + ');')
        elif isinstance(s, HmStmt) and s.kind == 'set':
            i_e = self.js_expr(s.parts[0])
            v_e = self.js_expr(s.parts[1])
            lines.append(f'__pybkTB{self._live_sfx}[{i_e}] = ({v_e});')
            lines.append(f'(function(){{ var el = document.getElementById("pybk_tb_" + {i_e}); if (el) el.value = ({v_e}); }})();')
        elif isinstance(s, Aging):
            self.err(s, 'web.实时 块里不用 rm.aging——块本身就是循环，块里的语句每帧跑一遍')
        elif isinstance(s, (WhileStmt, ContinueStmt)):
            self.err(s, f'web.实时 块里不支持 {type(s).__name__}——'
                        '实时块每帧从头跑一遍，块里不需要自己写循环')
        elif isinstance(s, (HmFrame, HmPlay, GoStmt)):
            self.err(s, 'web.实时 块里不能用 web.帧/播放/go')
        elif isinstance(s, IpAssign):
            self.err(s, 'web.实时 里不能用 ip（页面生成完才在浏览器里跑，收不了输入）')
        else:
            self.err(s, f'web.实时 里暂时不支持这类语句（{type(s).__name__}）')

    def live_vc(self, arms, lines):
        cond, body = arms[0]
        rest = arms[1:]
        if cond is None:               # 结尾的 else 缺省分支
            for st in body:
                self.live_stmt(st, lines)
            return
        lines.append(f'if ({self.js_expr(cond)}) {{')
        for st in body:
            self.live_stmt(st, lines)
        if not rest:
            lines.append('}')
            return
        lines.append('} else {')
        self.live_vc(rest, lines)
        lines.append('}')

    def _js_ctx(self):
        return f'ctx{self.in_draw}'

    def _interp_concat(self, sp):
        """StrParts → (前置语句, C 表达式)：rt_str / rt_str_of 的 rt_add 链。
        $变量、$表达式（EXPR 部件）都支持。"""
        stmts = []
        acc = None
        for kind, val in sp.parts:
            if kind == 'TEXT':
                c = f'rt_str({cstr(val)})'
            elif kind == 'EXPR':
                s2, c2 = self.expr(val)
                stmts += s2
                c2 = self.materialize(stmts, c2)
                c = f'rt_str(rt_str_of({c2}))'
            else:
                seg = val.split('.')
                if len(seg) == 1 and seg[0] in ('frame', 'sec') and seg[0] not in self.declared:
                    值 = f'rt_frames()' if seg[0] == 'frame' else f'rt_secs()'
                    c = f'rt_str(rt_str_of({值}))'
                    acc = c if acc is None else f'rt_add({acc}, {c})'
                    continue
                if seg[0] not in self.declared:
                    self.err(sp, f'插值用的变量 {seg[0]} 没有赋值过'
                                 f'（规则：先 vg.{seg[0]} = 值 再 "$…{seg[0]}…"；'
                                 f'插值里可写 $(表达式) 但字符串里不能再嵌引号）')
                c = f'rt_chk({self.vname(seg[0])})'
                for attr in seg[1:]:
                    c = f'rt_obj_get_prop({c}, {cstr(attr)})'
                c = f'rt_str(rt_str_of({c}))'
            acc = c if acc is None else f'rt_add({acc}, {c})'
        return stmts, (acc or 'rt_str("")')

    _JS_MATH1 = {'mt.sqrt': 'Math.sqrt', 'mt.abs': 'Math.abs', 'mt.ceil': 'Math.ceil',
                 'mt.floor': 'Math.floor', 'mt.sin': 'Math.sin', 'mt.cos': 'Math.cos',
                 'mt.tan': 'Math.tan'}

    def js_expr(self, e):
        if isinstance(e, NumLit):
            return repr(e.value)
        if isinstance(e, StrLit):
            return cstr(e.value)
        if isinstance(e, Call) and e.name == '空' and not e.args:
            return 'null'
        if isinstance(e, BoolLit):
            return 'true' if e.value else 'false'
        if isinstance(e, VarRef):
            if e.name not in self._live_declared:
                self.err(e, f'web.实时 里用的变量 {e.name} 没有赋值过（写在块里或 GOING 前文）')
            return 'V_' + e.name
        if isinstance(e, Unary):
            if e.op == '-':
                return '(-' + self.js_expr(e.operand) + ')'
            if e.op == 'not':
                return '!(' + self.js_expr(e.operand) + ')'
            self.err(e, f"不支持的一元运算符 '{e.op}'")
        if isinstance(e, BinOp):
            if e.op == 'and':
                return f'({self.js_expr(e.left)} && {self.js_expr(e.right)})'
            if e.op == 'or':
                return f'({self.js_expr(e.left)} || {self.js_expr(e.right)})'
            if e.op == '//':
                return f'Math.floor(({self.js_expr(e.left)}) / ({self.js_expr(e.right)}))'
            if e.op in ('+', '-', '*', '/', '%', '==', '!=', '<', '>', '<=', '>='):
                return f'({self.js_expr(e.left)} {e.op} {self.js_expr(e.right)})'
            self.err(e, f"web.实时 里不支持的运算符 '{e.op}'")
        if isinstance(e, ListLit):
            return '[' + ', '.join(self.js_expr(it) for it in e.items) + ']'
        if isinstance(e, Index):
            return f'({self.js_expr(e.base)})[{self.js_expr(e.index)}]'
        if isinstance(e, StrParts):
            out = []
            for kind, val in e.parts:
                if kind == 'TEXT':
                    out.append(cstr(val))
                elif kind == 'EXPR':
                    out.append('(' + self.js_expr(val) + ')')
                else:
                    if val.split('.')[0] not in self._live_declared:
                        self.err(e, f'插值用的变量 {val} 没有赋值过')
                    out.append('V_' + val)
            return '(' + ' + '.join(out) + ')'
        if isinstance(e, Member):
            return f'({self.js_expr(e.base)})[{self.js_expr(StrLit(e.attr, e.line))}]'
        if isinstance(e, CtorExpr):
            cd = self.classes.get(e.class_name)
            if cd is None:
                self.err(e, f"未定义的类 '{e.class_name}'")
            kw = dict(e.kwargs)
            for i, p in enumerate(getattr(cd, 'ctor_params', [])):
                if i < len(e.pos_args):
                    kw[p] = e.pos_args[i]
            fields = []
            chain = []
            c = e.class_name; seen = set()
            while c is not None and c not in seen:
                seen.add(c); chain.append(c)
                c = self.classes.get(c).parent if c in self.classes else None
            chain.reverse()
            for cname in chain:
                for pname, default in self.classes.get(cname).props:
                    vex = kw.pop(pname) if pname in kw else default
                    if vex is None:
                        fields.append(f'{self.js_expr(StrLit(pname, e.line))}: 0')
                    else:
                        fields.append(f'{self.js_expr(StrLit(pname, e.line))}: {self.js_expr(vex)}')
            for pname, vex in kw.items():
                fields.append(f'{self.js_expr(StrLit(pname, e.line))}: {self.js_expr(vex)}')
            return '{' + ', '.join(fields) + '}'
        if isinstance(e, StaticCall):
            self.err(e, 'web.实时 暂不支持静态方法调用')
        if isinstance(e, StaticRef):
            self.err(e, 'web.实时 暂不支持静态字段读取')
        if isinstance(e, MethodCall):
            self.err(e, 'web.实时 里暂时不支持方法调用（对象属性读写可以用）')
        if isinstance(e, Call):
            name = {'add': '添加', 'remove': '删掉', 'len': '长度', 'touch': '碰到',
                    'key': '按键', 'hit': '按过'}.get(e.name, e.name)
            args = e.args
            if name in ('按键', '按过'):
                if len(args) != 1:
                    self.err(e, f'{name} 需要 1 个参数，如 {name}("left")')
                k = self.js_expr(args[0])
                if name == '按键':
                    return f'(PYBK_KEYS{self._live_sfx}[PYBK_KEYMAP{self._live_sfx}({k})] === true)'
                return f'PYBK_PRESSED{self._live_sfx}.has(PYBK_KEYMAP{self._live_sfx}({k}))'
            if name == '长度':
                if len(args) != 1:
                    self.err(e, '长度 需要 1 个参数')
                return f'({self.js_expr(args[0])}).length'
            if name in ('圆', 'circle'):
                if len(args) != 3:
                    self.err(e, '圆 需要 3 个参数：圆(x, y, r)')
                cx = self._js_ctx()
                return (f'(function(x, y, r) {{ for (let dy = -r; dy <= r; dy++) {{ '
                        f'const w = Math.floor(Math.sqrt(r * r - dy * dy)); '
                        f'{cx}.fillRect(x - w, y + dy, w * 2, 1); }} }})'
                        f'({self.js_expr(args[0])}, {self.js_expr(args[1])}, {self.js_expr(args[2])})')
            if name == 'mx':
                return '(window.__pybkMX || 0)'
            if name == 'my':
                return '(window.__pybkMY || 0)'

            if name == 'mdown':
                return 'window.__pybkMD ? 1 : 0'
            if name == 'mhit':
                return '(window.__pybkMH ? 1 : 0)'
            if name == 'ui.按钮':
                if len(args) != 5:
                    self.err(e, 'ui.按钮 需要 5 个参数：ui.按钮(x, y, 宽, 高, 文本)')
                return ('__pybkUI_BTN(' + self._js_ctx() + ', ' + self.js_expr(args[0]) + ', ' + self.js_expr(args[1]) + ', ' + self.js_expr(args[2]) + ', ' + self.js_expr(args[3]) + ', ' + self.js_expr(args[4]) + ')')
            if name == 'ui.输入框':
                if len(args) != 5:
                    self.err(e, 'ui.输入框 需要 5 个参数：ui.输入框(编号, x, y, 宽, 高)')
                return ('__pybkUI_INP(' + self._js_ctx() + ', ' + self.js_expr(args[0]) + ', ' + self.js_expr(args[1]) + ', ' + self.js_expr(args[2]) + ', ' + self.js_expr(args[3]) + ', ' + self.js_expr(args[4]) + ')')
            if name == 'ui.滑条':
                if len(args) != 6:
                    self.err(e, 'ui.滑条 需要 6 个参数：ui.滑条(编号, x, y, 宽, 最小, 最大)')
                return ('__pybkUI_SLD(' + self._js_ctx() + ', ' + self.js_expr(args[0]) + ', ' + self.js_expr(args[1]) + ', ' + self.js_expr(args[2]) + ', ' + self.js_expr(args[3]) + ', ' + self.js_expr(args[4]) + ', ' + self.js_expr(args[5]) + ', (' + self.js_expr(args[4]) + ' + ' + self.js_expr(args[5]) + ') / 2)')
            if name in ('音.正弦', '音.三角'):
                if len(args) != 2:
                    self.err(e, f'{name} 需要 2 个参数：{name}(频率, 毫秒)')
                typ = 'sine' if name == '音.正弦' else 'triangle'
                return (f'(function(f, ms) {{ const ac = window.__pybkAC || '
                        f'(window.__pybkAC = new (window.AudioContext || window.webkitAudioContext)()); '
                        f'const o = ac.createOscillator(), g = ac.createGain(); '
                        f'o.type = \"{typ}\"; o.frequency.value = f; g.gain.value = 0.2; '
                        f'o.connect(g); g.connect(ac.destination); '
                        f'o.start(); o.stop(ac.currentTime + ms / 1000); }})'
                        f'({self.js_expr(args[0])}, {self.js_expr(args[1])})')
            if name == '线':
                if len(args) != 4:
                    self.err(e, '线 需要 4 个参数：线(x1, y1, x2, y2)')
                return (f'(function(x1, y1, x2, y2) {{ {self._js_ctx()}.beginPath(); '
                        f'{self._js_ctx()}.moveTo(x1, y1); {self._js_ctx()}.lineTo(x2, y2); '
                        f'{self._js_ctx()}.stroke(); }})'
                        f'({self.js_expr(args[0])}, {self.js_expr(args[1])}, '
                        f'{self.js_expr(args[2])}, {self.js_expr(args[3])})')
            if name == '点':
                if len(args) != 2:
                    self.err(e, '点 需要 2 个参数：点(x, y)')
                return (f'(function(x, y) {{ {self._js_ctx()}.fillRect(x - 2, y - 2, 4, 4); }})'
                        f'({self.js_expr(args[0])}, {self.js_expr(args[1])})')
            if name == '音.放':
                if len(args) != 1:
                    self.err(e, '音.放 需要 1 个参数：音.放(\"文件.mp3\")')
                return (f'(function(p) {{ const a = new Audio(p); '
                        f'window.__pybkAudio = a; a.play(); }})({self.js_expr(args[0])})')
            if name == '音.停':
                if args:
                    self.err(e, '音.停 不带参数')
                return '(function() { if (window.__pybkAudio) window.__pybkAudio.pause(); })()'
            if name == '音.音':
                if len(args) != 3:
                    self.err(e, '音.音 需要 3 个参数：音.音(名, 频率, 波形)')
                return ('(function(n,f,w){(window.__pybkNotes||(window.__pybkNotes={}))[n]={f:f,w:w};})'
                        '(' + self.js_expr(args[0]) + ',' + self.js_expr(args[1]) + ',' + self.js_expr(args[2]) + ')')
            if name in ('音.谱', '音.奏'):
                if name == '音.谱' and len(args) != 2:
                    self.err(e, '音.谱 需要 2 个参数：音.谱(表, 速度)')
                if name == '音.奏' and len(args) != 3:
                    self.err(e, '音.奏 需要 3 个参数：音.奏(表, 文件名, 速度)')
                L = self.js_expr(args[0])
                if name == '音.奏':
                    bpm = self.js_expr(args[2])
                    fn = self.js_expr(args[1])
                else:
                    bpm = self.js_expr(args[1])
                    fn = '""'
                js = ('(function(L,bpm,fn){'
                      'const AC=window.__pybkAC||(window.__pybkAC=new (window.AudioContext||window.webkitAudioContext)());'
                      'const spb=60/(bpm||120);'
                      'const midi=function(s){const m={"C":0,"D":2,"E":4,"F":5,"G":7,"A":9,"B":11};'
                      'let i=0,c=s[i++];if(!(c in m))return null;let v=m[c];'
                      'if(s[i]==="#"){v++;i++;}else if(s[i]==="b"){v--;i++;}'
                      'let o=parseInt(s.slice(i));if(isNaN(o))return null;return (o+1)*12+v;};'
                      'const N=window.__pybkNotes||{};'
                      'for(const row of (L||[])){let ct=AC.currentTime+0.06;'
                      'const toks=String(row).trim().split(/\\s+/).filter(Boolean);'
                      'for(const raw of toks){let parts=raw.split(":");let tok=parts[0];'
                      'let dur=(parts[1]?parseFloat(parts[1]):1)*spb;'
                      'if(tok==="."||tok==="_"||tok==="r"){ct+=dur;continue;}'
                      'let fr=null,w=0;if(N[tok]){fr=N[tok].f;w=N[tok].w;}'
                      'else{const mm=midi(tok);if(mm!=null)fr=440*Math.pow(2,(mm-69)/12);}'
                      'if(fr){const o=AC.createOscillator(),g=AC.createGain();'
                      'o.type=(w===1?"triangle":(w===2?"sawtooth":"sine"));'
                      'o.frequency.value=fr;g.gain.value=0.16;o.connect(g);g.connect(AC.destination);'
                      'o.start(ct);o.stop(ct+dur*0.95);}ct+=dur;}}return fn;})(')
                return js + L + ',' + bpm + ',' + fn + ')'
            if name == '碰到':
                if len(args) != 2:
                    self.err(e, '碰到 需要 2 个参数：碰到(a, b)')
                return (f'(function(a, b) {{ return Math.abs(a.x - b.x) * 2 < a.宽 + b.宽 '
                        f'&& Math.abs(a.y - b.y) * 2 < a.高 + b.高; }})'
                        f'({self.js_expr(args[0])}, {self.js_expr(args[1])})')
            if name == 'mt.pi':
                if args:
                    self.err(e, 'mt.pi 不带参数')
                return 'Math.PI'
            if name == 'mt.pow':
                if len(args) != 2:
                    self.err(e, 'mt.pow 需要 2 个参数')
                return f'Math.pow({self.js_expr(args[0])}, {self.js_expr(args[1])})'
            if name == 'mt.mod':
                if len(args) != 2:
                    self.err(e, 'mt.mod 需要 2 个参数')
                return f'(({self.js_expr(args[0])}) % ({self.js_expr(args[1])}))'
            if name in ('mt.max', 'mt.min'):
                if len(args) != 1:
                    self.err(e, f'{name} 需要 1 个参数（列表）')
                fn = 'Math.max' if name == 'mt.max' else 'Math.min'
                return f'{fn}(...({self.js_expr(args[0])}))'
            if name == 'mt.prod':
                if len(args) != 1:
                    self.err(e, 'mt.prod 需要 1 个参数（列表）')
                return f'({self.js_expr(args[0])}).reduce(function(a, b) {{ return a * b; }}, 1)'
            if name in self._JS_MATH1:
                if len(args) != 1:
                    self.err(e, f'{name} 需要 1 个参数')
                return f'{self._JS_MATH1[name]}({self.js_expr(args[0])})'
            if name == 'rd.int':
                if len(args) != 2:
                    self.err(e, 'rd.int 需要 2 个参数')
                a, b = self.js_expr(args[0]), self.js_expr(args[1])
                return f'(({a}) + Math.floor(Math.random() * (({b}) - ({a}) + 1)))'
            if name == 'rd.float':
                if args:
                    self.err(e, 'rd.float 不带参数')
                return 'Math.random()'
            if name == 'rd.pick':
                if len(args) != 1:
                    self.err(e, 'rd.pick 需要 1 个参数（列表）')
                return (f'(function(L) {{ return L[Math.floor(Math.random() * L.length)]; }})'
                        f'({self.js_expr(args[0])})')
            if name == 'web.click':
                return f'__pybkCLICK{self._live_sfx}'
            if name == 'web.mx':
                return f'(__pybkMX{self._live_sfx} || 0)'
            if name == 'web.my':
                return f'(__pybkMY{self._live_sfx} || 0)'
            if name == 'web.text':
                if len(e.args) != 1:
                    self.err(e, 'web.text(id) 需要 1 个参数')
                return f'(__pybkTB[{self.js_expr(e.args[0])}] || "")'
            if name == 'web.存':
                if len(e.args) != 2:
                    self.err(e, 'web.存(键, 缺省值) 需要 2 个参数')
                k = self.js_expr(e.args[0])
                d = self.js_expr(e.args[1])
                return (f'(function(){{ try {{ var v = localStorage.getItem({k});'
                        f' return v === null ? ({d}) : PYBK_NUM{self._live_sfx}(v); }}'
                        f' catch (err) {{ return ({d}); }} }})())')
            if name == 'web.down':
                if len(e.args) != 1:
                    self.err(e, 'web.down(id) 需要 1 个参数')
                return f'(__pybkBTN[{self.js_expr(e.args[0])}] || 0)'
            if name in GAME_CALLS:
                self.err(e, f'web.实时 里不能用游戏函数 {name}(...)（那是窗口模式的零件，网页里用 按键/按过）')
            if name == 'te.str':
                if len(e.args) != 1:
                    self.err(e, 'te.str 需要 1 个参数')
                return f'PYBK_STR({self.js_expr(e.args[0])})'
            if name == 'te.len':
                if len(e.args) != 1:
                    self.err(e, 'te.len 需要 1 个参数')
                return f'PYBK_STRLEN({self.js_expr(e.args[0])})'
            if name == 'mt.floor':
                if len(e.args) != 1:
                    self.err(e, 'mt.floor 需要 1 个参数')
                return f'Math.floor({self.js_expr(e.args[0])})'
            if name == 'mt.round':
                if len(e.args) != 1:
                    self.err(e, 'mt.round 需要 1 个参数')
                return f'Math.round({self.js_expr(e.args[0])})'
            if name in LIB_CALLS:
                self.err(e, f'web.实时 里暂时不支持 {name}(...)（网页实时模式只带 list/mt/rd/te.str 的一部分）')
            self.err(e, f"web.实时 里不知道 '{name}' 是什么（自定义函数暂不能在实时块里调用）")
        self.err(e, f'web.实时 里不支持的表达式：{type(e).__name__}')

    def live_sprites(self, s, lines):
        """绘(列表) 的网页实时实现：JS 遍历列表，逐精灵懒加载图片并 drawImage。

        元素缺 x/y/宽/高/图 任一属性 → throw（带是第几个元素）；
        图片走 PYBK_IMGS 缓存懒加载：运行时发现新路径就建 Image，
        第一帧没加载完（complete=false）就跳过，下一帧自然补上。"""
        if len(s.args) != 1 or not isinstance(s.args[0], VarRef):
            self.err(s, '绘 的写法：绘(列表名)')
        if s.args[0].name not in self._live_declared:
            self.err(s, f'web.实时 里用的变量 {s.args[0].name} 没有赋值过')
        im = f'PYBK_IMGS{self._live_sfx}'
        ctx = self._js_ctx()
        lines += [
            '(function () {',
            f'  var _l = V_{s.args[0].name};',
            '  var _need = ["x", "y", "宽", "高", "图"];',
            '  for (var _i = 0; _i < _l.length; _i++) {',
            '    var _e = _l[_i];',
            '    for (var _k = 0; _k < _need.length; _k++) {',
            '      if (!(_need[_k] in _e)) { throw "绘：第 " + (_i + 1) + " 个元素缺少属性 " + _need[_k]; }',
            '    }',
            '    var _pth = _e["图"];',
            f'    var _im = {im}[_pth];',
            f'    if (_im === undefined) {{ _im = new Image(); _im.src = _pth; {im}[_pth] = _im; }}',
            '    if (_im.complete && _im.naturalWidth > 0) {',
            f'      {ctx}.drawImage(_im, _e["x"] - _e["宽"] / 2, _e["y"] - _e["高"] / 2,',
            '                      _e["宽"], _e["高"]);',
            '    }',
            '  }',
            '})();',
        ]

    def live_draw(self, s):
        """web.draw.* 在实时块里：参数是 JS 表达式（不烤值），每帧重新求值。"""
        ctx = f'ctx{self.in_draw}'
        if s.cmd in ('begin', 'end'):
            self.err(s, 'web.实时 里不能用 web.draw.始/终')
        p = [self.js_expr(x) for x in s.params]
        out = []
        if s.cmd == 'color':
            out.append(f"{ctx}.fillStyle = 'rgb(' + ({p[0]}) + ',' + ({p[1]}) + ',' + ({p[2]}) + ')';")
            out.append(f"{ctx}.strokeStyle = {ctx}.fillStyle;")
        elif s.cmd == 'clear':
            out.append(f"{ctx}.fillStyle = 'rgb(' + ({p[0]}) + ',' + ({p[1]}) + ',' + ({p[2]}) + ')';")
            lcw, lch = self._canvas_size.get(self.in_draw, (400, 300))
            out.append(f'{ctx}.fillRect(0, 0, {lcw}, {lch});')
        elif s.cmd == 'circle':
            out.append(f'{ctx}.beginPath();')
            out.append(f'{ctx}.arc({p[0]}, {p[1]}, {p[2]}, 0, Math.PI * 2);')
            out.append(f'{ctx}.fill();')
        elif s.cmd == 'rect':
            out.append(f'{ctx}.fillRect({p[0]}, {p[1]}, {p[2]}, {p[3]});')
        elif s.cmd == 'line':
            out.append(f'{ctx}.beginPath();')
            out.append(f'{ctx}.moveTo({p[0]}, {p[1]});')
            out.append(f'{ctx}.lineTo({p[2]}, {p[3]});')
            out.append(f'{ctx}.stroke();')
        elif s.cmd == 'text':
            out.append(ctx + '.font = (' + p[3] + ') + "px \'Microsoft YaHei UI\', sans-serif";')
            out.append(f'{ctx}.fillText(({p[2]}), ({p[0]}), ({p[1]}));')
        elif s.cmd == 'img_draw':
            im = f'PYBK_IMGS{self._live_sfx}[{p[2]}]'
            out.append(f'var _pim = {im};')
            out.append(f'if (_pim.complete && _pim.naturalWidth > 0) '
                       f'{ctx}.drawImage(_pim, ({p[0]}), ({p[1]}));')
        elif s.cmd == 'img_scaled':
            im = f'PYBK_IMGS{self._live_sfx}[{p[4]}]'
            out.append(f'var _pim = {im};')
            out.append(f'if (_pim.complete && _pim.naturalWidth > 0) '
                       f'{ctx}.drawImage(_pim, ({p[0]}), ({p[1]}), ({p[2]}), ({p[3]}));')
        else:
            self.err(s, f'未知的画布命令 {s.cmd}')
        return out

    _GO_MOVE = {'右': ('X', ''), 'left': ('X', '-'), '左': ('X', '-'),
                'right': ('X', ''), '上': ('Y', '-'), 'up': ('Y', '-'),
                '下': ('Y', '+'), 'down': ('Y', '+')}

    def gen_go(self, s: GoStmt):
        """go(方向, 距离, 速度)：CSS transition + translate 平移整个画布。"""
        self.hm_used = True
        self._need_canvas(s, 'go')
        dist = self._draw_param(s.distance)
        speed = self._draw_param(s.speed)
        self.go_n += 1
        cv = 'pybk_canvas' if self.go_n == 1 else f'pybk_canvas{self.go_n}'
        axis, sign = self._GO_MOVE[s.direction]
        self.raw(f"const {cv} = document.getElementById('pybook-canvas-{self.in_draw}');\n")
        self.raw(f"{cv}.style.transition = 'transform ")
        self.draw_val(speed)
        self.raw("s';\n")
        self.raw(f"{cv}.style.transform = 'translate{axis}({sign}")
        self.draw_val(dist)
        self.raw("px)';\n")

    # ---- Godot 级热点优化：rm.around 标量化 ----
    # 分析循环体里"只做数值算术"的变量，整圈用 C 原生标量 S_x 携带，
    # 出口装回盒子；任何不支持的形态整圈回退 gen_around 老路径。

    def _pk_subst(self, e, lv, cands, kinds):
        """值域替换：候选读 → PK_BOX，循环变量读 → PK_LOOP_I。"""
        import copy
        def walk(x):
            if isinstance(x, VarRef):
                if x.name in cands:
                    k = kinds.get(x.name, 'i')
                    return Call('PK_BOX_' + k.upper(), [StrLit(x.name, x.line)], x.line)
                if x.name == lv:
                    return Call('PK_LOOP_I', [StrLit('i', x.line)], x.line)
                return x
            if isinstance(x, BinOp):
                x.left = walk(x.left)
                x.right = walk(x.right)
                return x
            if isinstance(x, Unary):
                x.operand = walk(x.operand)
                return x
            if isinstance(x, Index):
                x.base = walk(x.base)
                x.index = walk(x.index)
                return x
            if isinstance(x, Call):
                x.args = [walk(a) for a in x.args]
                return x
            if isinstance(x, ListLit):
                x.items = [walk(it) for it in x.items]
                return x
            if isinstance(x, VgAssign):
                x.expr = walk(x.expr)
                return x
            if isinstance(x, AssignIndex):
                x.expr = walk(x.expr)
                x.index = walk(x.index)
                return x
            if isinstance(x, VcChain):
                x.arms = [(walk(c) if c is not None else None, [walk(y) for y in b])
                          for c, b in x.arms]
                return x
            if isinstance(x, Around):
                x.times = walk(x.times) if getattr(x, 'times', None) is not None else x.times
                x.body = [walk(y) for y in x.body]
                return x
            if isinstance(x, NsShow):
                x.parts = [(k2, walk(v2) if k2 == 'EXPR' else v2) for k2, v2 in x.parts]
                return x
            if isinstance(x, TestCheck):
                x.cond = walk(x.cond)
                return x
            if isinstance(x, StrParts):
                newp = []
                for kind, val in x.parts:
                    if kind == 'VAR' and val in cands:
                        k = kinds.get(val, 'i')
                        newp.append(('EXPR', Call('PK_BOX_' + k.upper(), [StrLit(val, x.line)], x.line)))
                    elif kind == 'EXPR':
                        newp.append((kind, walk(val)))
                    else:
                        newp.append((kind, val))
                x.parts = newp
                return x
            return x
        return walk(copy.deepcopy(e))

    # ---- 标量化分析：数值域 ----
    def _scan_fn_body(self, body):
        """一个函数体里被赋过值的变量名 → 该变量被赋的数值域集合。

        数值域用「不看变量」的保守推断（读别的变量一律当 'u' 未知）：
        函数里 `vg.s = 1` → {'i'}（还是整数，安全）；
        `vg.s = 1.5` 或 `vg.s = 别的` → 含 'f'/'u' → 圈前类型不可信。
        """
        names = set()
        kinds = {}

        def kind_of(e):
            if isinstance(e, NumLit):
                if isinstance(e.value, float):
                    return 'f'
                return 'i' if -(2 ** 63) <= e.value < 2 ** 63 else 'u'
            if isinstance(e, BoolLit):
                return 'i'
            if isinstance(e, Unary) and e.op == '-':
                return kind_of(e.operand)
            if isinstance(e, BinOp):
                lk = kind_of(e.left)
                rk = kind_of(e.right)
                if e.op == '/':
                    return 'f'
                if e.op in ('%', '//'):
                    return 'i' if (lk == 'i' and rk == 'i') else 'u'
                if e.op in ('==', '!=', '<', '>', '<=', '>=', 'and', 'or'):
                    return 'i'
                if 'u' in (lk, rk):
                    return 'u'
                return 'f' if 'f' in (lk, rk) else 'i'
            return 'u'

        def visit(node):
            if isinstance(node, VgAssign):
                nm = getattr(node, 'name', None)
                if isinstance(nm, str):
                    names.add(nm)
                    kinds.setdefault(nm, set()).add(kind_of(node.expr))
            elif isinstance(node, AssignIndex):
                nm = getattr(node, 'name', None)
                if isinstance(nm, str):
                    names.add(nm)
                    kinds.setdefault(nm, set()).add('u')   # 容器元素：类型不定
        for s in body or []:
            self._walk_nodes(s, visit)
        return names, kinds

    def _collect_fn_vars(self, program, extra_fns=()):
        """每个函数体里被赋过值的变量名（名字 → (变量名集合, 数值域集合表)）。

        用途：标量化要判断"圈前这个变量是 int 还是 float"。如果**别的**函数
        在圈前可能改过它，编译期无从知道 → 圈前类型不可信 → 不可标量化。
        """
        out = {}
        for f in (program.fns or []):
            out[f.name] = self._scan_fn_body(f.body)
        for f in extra_fns:
            out[f.name] = self._scan_fn_body(f.body)
        for cd in (program.classes or []):
            for m in (cd.methods or []) + (cd.static_methods or []):
                out[cd.name + '.' + m.name] = self._scan_fn_body(m.body)
        return out

    def _enter_fn_scope(self, fname):
        """进入某个函数的生成：圈前类型只看这个函数自己的赋值。

        别的函数赋过的变量 → 圈前类型可能已被改掉 → 记进 _fn_vars / _fn_kinds。
        """
        self._cur_fn = fname
        names = set()
        kinds = {}
        for g, (ns, ks) in self._fn_assign.items():
            if g == fname:
                continue
            names |= ns
            for n, kk in ks.items():
                kinds.setdefault(n, set()).update(kk)
        self._fn_vars = names
        self._fn_kinds = kinds

    def _pk_pre_kind(self, name):
        """圈前某变量的数值域：'i' 整数 | 'f' 浮点 | 'u'（不可信 → 不可标量化）。

        'u' 的三种来源：
          ① 这个变量在**别的**函数体里被赋过值 —— 那个函数可能在本圈之前改过
             它，编译期无从知道圈前它到底是 int 还是 float
             （除非函数赋的数值域跟这里一致，那就还是那个类型，安全）；
          ② 这个变量在本圈前压根没被赋过值（圈里首次赋值）；
          ③ 圈前赋值的是"类型不可知"的东西（函数返回值、容器元素…）。
        """
        k = self._vg_kind.get(name, 'u')
        if k == 'u':
            return 'u'
        if name in self._fn_vars and self._fn_kinds.get(name) != {k}:
            return 'u'                       # 函数里可能把它改成别的类型
        return k

    def _pk_now_kind(self, kinds, name):
        """圈内当前数值域：圈前值 → 圈内每次赋值后更新。"""
        k = kinds.get(name)
        if k is None:
            k = self._pk_pre_kind(name)
        return k

    def _pk_rhs_kind(self, e, lv, kinds, disq, box_reads, self_reads,
                     self_name=None):
        """表达式在标量域里的数值域：'i' | 'f' | 'u'。

        self_name 不为 None = 「这是给 self_name 赋值」：此时读 self_name 算
        **标量读**（走 S_x），不算盒子读；其余变量的读都要过盒子，记进 box_reads
        （见 _pk_emit：盒子在圈内是旧值，读到它的候选变量不能标量化）。
        """
        if isinstance(e, NumLit):
            if isinstance(e.value, float):
                return 'f'
            # 超出 int64 的整数字面量在 PYbook 里是 BIGINT，标量装不下 → 'u'
            if not (-(2 ** 63) <= e.value < 2 ** 63):
                return 'u'
            return 'i'
        if isinstance(e, BoolLit):
            return 'i'
        if isinstance(e, VarRef):
            if e.name == lv:
                return 'i'                          # 循环变量：整数
            if e.name == self_name:
                self_reads.add(e.name)
                return self._pk_now_kind(kinds, e.name)
            box_reads.add(e.name)                   # 别的变量 → 走盒子
            return self._pk_now_kind(kinds, e.name)
        if isinstance(e, Unary) and e.op == '-':
            return self._pk_rhs_kind(e.operand, lv, kinds, disq, box_reads,
                                     self_reads, self_name)
        if isinstance(e, BinOp):
            lk = self._pk_rhs_kind(e.left, lv, kinds, disq, box_reads,
                                   self_reads, self_name)
            rk = self._pk_rhs_kind(e.right, lv, kinds, disq, box_reads,
                                   self_reads, self_name)
            if e.op == '/':
                return 'f'                          # 真除法结果恒为浮点
            if e.op in ('%', '//'):
                return 'i' if (lk == 'i' and rk == 'i') else 'u'
            if e.op in ('==', '!=', '<', '>', '<=', '>=', 'and', 'or'):
                return 'i'                          # 比较/逻辑结果是布尔
            if 'u' in (lk, rk):
                return 'u'
            return 'f' if 'f' in (lk, rk) else 'i'
        if isinstance(e, Index):
            if isinstance(e.base, VarRef):
                disq.add(e.base.name)               # 下标读到的元素类型不可知
            self._pk_rhs_kind(e.index, lv, kinds, disq, box_reads,
                              self_reads, self_name)
            return 'u'                              # 元素可能是任何类型
        if isinstance(e, Call) and e.name == '长度':
            if isinstance(e.args[0], VarRef):
                disq.add(e.args[0].name)             # 传给 长度 的是列表
            return 'i'
        self._pk_abort('表达式含不支持形态 ' + type(e).__name__)
        return 'u'

    def _pk_walk_stmts(self, sts, lv, kinds, disq, assigned,
                       box_reads, self_reads, flags):
        """遍历循环体，给出候选集 / 数值域表 / 淘汰集 / 逃逸标志。

        flags：
          'ctrl' —— 有 break：跳出循环会跳过圈末回写
          'alloc'—— 圈里调了内建/方法：可能分配 → GC 轮询不能降频
        """
        for st in sts:
            if isinstance(st, VgAssign):
                if st.name == lv:
                    self._pk_abort('循环变量被赋值')
                prev = self._pk_now_kind(kinds, st.name)
                k = self._pk_rhs_kind(st.expr, lv, kinds, disq, box_reads,
                                      self_reads, self_name=st.name)
                assigned.add(st.name)
                if isinstance(st.expr, Index) and isinstance(st.expr.base, VarRef):
                    disq.add(st.expr.base.name)
                if k == 'u':
                    disq.add(st.name)                # 类型不可知 → 不可标量化
                elif prev != 'u' and prev != k:
                    disq.add(st.name)                # 圈内类型变了 → 标量装不下
                kinds[st.name] = k if k != 'u' else prev
            elif isinstance(st, AssignIndex):
                disq.add(st.name)                    # 写列表的变量不是标量候选
                self._pk_rhs_kind(st.expr, lv, kinds, disq, box_reads, self_reads)
                self._pk_rhs_kind(st.index, lv, kinds, disq, box_reads, self_reads)
            elif isinstance(st, VcChain):
                for cond, body in st.arms:
                    if cond is not None:
                        self._pk_rhs_kind(cond, lv, kinds, disq, box_reads,
                                          self_reads)
                    self._pk_walk_stmts(body, lv, kinds, disq, assigned,
                                        box_reads, self_reads, flags)
            elif isinstance(st, Around):
                # 嵌套循环：内外层的标量/盒子同步关系太多，精确分析易错 → 整圈退回
                self._pk_abort('嵌套循环')
            elif isinstance(st, NsShow):
                for kind, val in st.parts:
                    if kind == 'VAR':
                        box_reads.add(val)            # show 读的是盒子里的值
                    elif kind == 'EXPR':
                        self._pk_rhs_kind(val, lv, kinds, disq, box_reads,
                                          self_reads)
            elif isinstance(st, TestCheck):
                self._pk_rhs_kind(st.cond, lv, kinds, disq, box_reads, self_reads)
            elif isinstance(st, (BreakStmt, Call)):
                if isinstance(st, Call):
                    if st.name not in self.fns:
                        # 内建调用就在圈里执行，可能分配 → GC 轮询不能降频。
                        # 用户函数不设标志：它是独立的 C 函数，函数体自己每句轮询。
                        flags.add('alloc')
                    for a in st.args:
                        self._pk_rhs_kind(a, lv, kinds, disq, box_reads, self_reads)
                else:
                    flags.add('ctrl')                # break 会跳过圈末回写
            elif isinstance(st, (MethodCall, StaticCall)):
                flags.add('alloc')                   # 方法调用可能分配
            else:
                self._pk_abort('语句 ' + type(st).__name__)

    def _pk_abort(self, why):
        raise _PkAbort(why)

    def try_scalar_around(self, s: Around):
        """成功：发出标量化循环并返回 True；任何不支持：返回 False 走老路径。"""
        try:
            return self._pk_emit(s)
        except _PkAbort:
            return False

    def _pk_emit(self, s: Around):
        import copy
        lv = getattr(s, 'var', 'at')
        kinds = {}
        disq = set()
        assigned = set()
        box_reads = set()
        self_reads = set()
        flags = set()
        self._pk_walk_stmts(s.body, lv, kinds, disq, assigned,
                            box_reads, self_reads, flags)
        # ---- 整圈退回老路径的情况（退回 = gen_around，语义绝对正确）----
        # 'ctrl'：有 break —— 跳出循环会跳过圈末回写，值就丢了。
        #
        # 注：圈内调**用户函数**不用退回 —— PYbook 的函数是独立作用域
        # （生成的 C 里每个函数各有自己的 Value 局部量），函数里的 vg.名
        # 是函数自己的局部变量，改不到圈里的候选变量。
        if 'ctrl' in flags:
            return False
        # ---- 候选集 ----
        # 圈里被赋过值、没被淘汰（类型不可知 / 类型中途变了 / 是容器）、且不是循环变量。
        cands = {x for x in assigned - disq if x != lv}
        # 圈内容器（盒子）读过的候选不能标量化：盒子在整圈期间是旧值，
        # 读方会拿到过期数据（老路径每圈同步，读方拿到的是当轮新值）。
        cands -= box_reads
        # 圈前必须有旧值：自读取值（x = x + 1）要用圈前的值起算。
        # 圈前没被赋过值的变量，此刻盒子是 rt_none()，读它必然抛"需要整数"。
        for x in list(cands):
            if x in self_reads and x not in self._已赋值:
                cands.discard(x)
        if not cands:
            return False                        # 没有可标量化变量：老路径更省事
        kinds = {k: v for k, v in kinds.items() if k in cands}

        body = [self._pk_subst(x, lv, cands, kinds) for x in copy.deepcopy(s.body)]
        st0, cv0 = self.expr(s.times)
        for x in st0:
            self.emit(x)
        tv = self.newtemp()
        nv = self.newtemp('_n')
        iv = self.newtemp('_i')
        # ⚠ 进栈：_pk_iv / _pk_lv / _pk_live 是"当前这一层循环的计数器"，嵌套时
        #   必须先存下外层的值、退出时还原。原来退出时写死成 None，会把外层循环的
        #   计数器一起清掉（嵌套循环里读 at 就读到错的那层，静默算错）。
        saved_iv   = self._pk_iv
        saved_lv   = self._pk_lv
        saved_live = self._pk_live
        self._pk_iv = iv
        self._pk_lv = lv
        self.emit(f'Value {tv} = {cv0};')
        self.emit(f'long long {nv} = rt_loop_count({tv});')
        # ---- 整圈包一层块 ----
        # S_ 声明在 for 之外（要活到圈末回写），若不包块，同一个函数里两个并列
        # 循环都用同一个变量 → S_x 重复定义（gcc: redefinition）。
        # 这正是 1.0.3 关掉标量化时记下的老问题；包块解决它。
        self.emit('{')
        self.depth += 1
        # ---- 圈外初始化：整圈只读一次盒子，圈内零装箱 ----
        # 自读取值的变量（x = x + 1）要用圈前的旧值起算 → 读一次盒子；
        # 不自读的变量（x = 5）圈前旧值会被覆盖 → 直接置 0，连盒子都不碰
        #（顺带避开"圈前值是个列表，读它会抛需要整数"）。
        # 0 圈时不读盒子 —— 老路径 0 圈也不读。
        for name in sorted(cands):
            vn = self.vname(name)
            if name in self_reads:
                if kinds.get(name, 'i') == 'f':
                    self.emit(f'double S_{vn} = ({nv} > 0) ? '
                              f'(IS_FLT({vn}) ? AS_FLT({vn}) : (double)rt_to_ll({vn})) : 0.0;')
                else:
                    self.emit(f'long long S_{vn} = ({nv} > 0) ? '
                              f'(IS_FLT({vn}) ? (long long)AS_FLT({vn}) : rt_to_ll({vn})) : 0;')
            else:
                if kinds.get(name, 'i') == 'f':
                    self.emit(f'double S_{vn} = 0.0;')
                else:
                    self.emit(f'long long S_{vn} = 0;')
        self.emit(f'for (long long {iv} = 0; {iv} < {nv}; {iv}++) {{')
        self.depth += 1
        self.loop_depth += 1
        self._pk_live = (cands, kinds)
        for st in body:
            self._pk_stmt(st)
        # ---- GC 轮询 ----
        # rt_gc_poll 在 memmode 6（增量 GC）下是「推进一小片」，每圈一次才跟得上
        # 垃圾产生速度。标量档圈内零分配（纯标量运算），垃圾产生慢 → 可以降频；
        # 一旦圈里有内建调用（可能分配），就保持每圈轮询，别让增量 GC 掉队。
        if 'builtin' not in flags:
            self.emit(f'if ({iv} == 0 || ({iv} & 1023) == 1023) rt_gc_poll();')
        else:
            self.emit('rt_gc_poll();')
        self.loop_depth -= 1
        self.depth -= 1
        self.emit('}')
        # ---- 圈末一次性装回（0 圈不装回）----
        for name in sorted(cands):
            vn = self.vname(name)
            box = f'rt_float(S_{vn})' if kinds.get(name, 'i') == 'f' else f'rt_int(S_{vn})'
            self.emit(f'if ({nv} > 0) rt_assign(&{vn}, {box});')
        self.depth -= 1
        self.emit('}')
        self._pk_iv   = saved_iv
        self._pk_lv   = saved_lv
        self._pk_live = saved_live
        self._pk_helpers = True
        return True

    def _pk_stmt(self, st):
        if isinstance(st, VgAssign) and st.name in self._pk_live[0]:
            code, k = self._pk_scalar_expr(st.expr)
            want = self._pk_live[1].get(st.name, 'i')
            if k != want:
                code = f'(long long)({code})' if want == 'i' else f'(double)({code})'
            self.emit(f'S_{self.vname(st.name)} = {code};')
            # 圈后这个变量的类型 = 标量的类型（圈末就按它装回盒子）
            self._vg_kind[st.name] = want
            return
        if isinstance(st, Around):
            if not self.try_scalar_around(st):
                self.gen_around(st)
            return
        self.stmt(st)

    def _pk_scalar_expr(self, e):
        """标量域渲染：返回 (C 代码, 'i'|'f')。"""
        if isinstance(e, VarRef):
            if e.name in self._pk_live[0]:
                return (f'S_{self.vname(e.name)}', self._pk_live[1].get(e.name, 'i'))
            if e.name == self._pk_lv:
                return (self._pk_iv, 'i')
            return (f'rt_to_ll({self.vname(e.name)})', 'i')
        if isinstance(e, Call) and e.name in ('PK_BOX_I', 'PK_BOX_F'):
            nm = e.args[0].value
            return (f'S_{self.vname(nm)}', 'i' if e.name.endswith('I') else 'f')
        if isinstance(e, Call) and e.name == 'PK_LOOP_I':
            return (self._pk_iv, 'i')
        if isinstance(e, NumLit):
            return (repr(e.value), 'f' if isinstance(e.value, float) else 'i')
        if isinstance(e, BoolLit):
            return ('0' if e.value else '1', 'i')
        if isinstance(e, Unary) and e.op == '-':
            a, k = self._pk_scalar_expr(e.operand)
            return (f'(-{a})', k)
        if isinstance(e, BinOp):
            a, ka = self._pk_scalar_expr(e.left)
            b, kb = self._pk_scalar_expr(e.right)
            if e.op == '/':
                # 真除法：结果恒为 float，除零要报错（与 rt_div 同义）
                return (f'pk_divz((double)({a}), (double)({b}))', 'f')
            if e.op == '//':
                return (f'pk_fdivz((long long)({a}), (long long)({b}))', 'i')
            if e.op == '%':
                return (f'pk_modz((long long)({a}), (long long)({b}))', 'i')
            if e.op in ('and', 'or'):
                js = '&&' if e.op == 'and' else '||'
                return (f'(({a}) {js} ({b}))', 'i')
            if e.op in ('==', '!=', '<', '>', '<=', '>='):
                return (f'(({a}) {e.op} ({b}))', 'i')
            k = 'f' if 'f' in (ka, kb) else 'i'
            if k == 'i':
                # 整数加减乘要跟 rt_add/rt_sub/rt_mul 一样：溢出即报错，不静默回绕
                fn = {'+': 'pk_add_ov', '-': 'pk_sub_ov', '*': 'pk_mul_ov'}.get(e.op)
                if fn:
                    return (f'{fn}((long long)({a}), (long long)({b}))', 'i')
            return (f'(({a}) {e.op} ({b}))', k)
        if isinstance(e, (Index, Call)) and self._pk_live:
            e2 = self._pk_subst(e, self._pk_lv, self._pk_live[0], self._pk_live[1])
            st, cv = self.expr(e2)
            for x in st:
                self.emit(x)
            return (f'rt_to_ll({cv})', 'i')
        self._pk_abort('标量表达式 ' + type(e).__name__)
        return ('0', 'i')

    def gen_while(self, s: WhileStmt):
        """while(条件){...}：条件为真就继续下一轮。

        生成的形状是 for(;;) { 条件; if(!rt_cond(c)) break; 体 }：
        条件在**每轮开头**求值一次，和「先判条件再进循环体」的语义一致。
        （rm.aging.while 那个是反过来的：条件为真才退出，别混。）

        用 for(;;) 而不是 while(1) + 内层 if，是为了 C 的 break/continue
        语义天然对上：body 里的 break 跳出这一层，continue 回到条件判断处。"""
        self.emit('for (;;) {')
        self.depth += 1
        st, c = self.expr(s.cond)
        for x in st:
            self.emit(x)
        self.emit(f'if (!rt_cond({c})) break;')
        self.loop_depth += 1
        self.block(s.body)
        self.loop_depth -= 1
        self.depth -= 1
        self.emit('}')

    def gen_around(self, s: Around):

        varname = getattr(s, 'var', 'at')
        st, c = self.expr(s.times)
        for x in st:
            self.emit(x)
        tv = self.newtemp()
        nv = self.newtemp('_n')
        iv = self.newtemp('_i')
        self.emit(f'Value {tv} = {c};')
        # 次数解码收进运行时 rt_loop_count（INT 直取；整值浮点截断；其余报
        # "rm.around 次数不是整数"），与旧的 tag/as 分支链逐字同义。
        self.emit(f'long long {nv} = rt_loop_count({tv});')
        self.emit(f'for (long long {iv} = 0; {iv} < {nv}; {iv}++) {{')
        self.emit(f'    Value {self.vname(varname)} = rt_at({iv});')
        self.depth += 1
        self.declared.add(varname)
        self.loop_depth += 1
        # ⚠ 同 _pk_emit：at 在表达式里是按 self._pk_iv 展开的（见 _pk_at），
        #   而 _pk_iv 原本只在"标量化"循环里维护。普通循环不进栈的话，嵌套时
        #   at 会读到**外层**残留的计数器 —— 不报错，直接给你错数
        #   （实测 3x3 矩阵乘每行都变成对角线值）。这里进栈，退出时还原。
        saved_iv = self._pk_iv
        self._pk_iv = iv
        self.block(s.body)
        self._pk_iv = saved_iv
        self.loop_depth -= 1
        self.declared.discard(varname)
        self.depth -= 1
        self.emit('}')

    def gen_onerror(self, s: OnError):
        """onerror err {...}：包住 GOING 其余全部语句（parse 层已重排进 s.body）。"""
        self.gen_trycatch(TryCatch(s.body, s.var, s.handler, s.line))

    def gen_trycatch(self, s: TryCatch):
        """try {...} catch [e [, t]] [:类型] {...} [finally {...}]：setjmp 包装。

        生成的形状（finally 必须每条路都跑，包括 handler 自己又抛的那种）：

          { ep1 = push();
            if (setjmp(ep1) == 0) { 主体; pop(ep1); finally; }
            else { handled = 0;
                   ready(); unwind(ep1);      // longjmp 跳过了 rt_scope_leave，这里还原
                   if (类型对得上) { ep2 = push();
                                    if (setjmp(ep2) == 0) { e=..; t=..; handler; pop(ep2); handled=1; }
                                    else { pop(ep2); }    // handler 里又抛了：留给外层
                                    pop(ep1); }
                   else { pop(ep1); }          // 类型对不上：本层不接
                   finally;
                   if (!handled) rt_err_raise(); }   // 没接住 → 继续往外抛
          }
        """
        p = self.newtemp('_ep')
        p2 = self.newtemp('_ep2')
        slot = self.vname(s.var) if s.var else None
        slot2 = self.vname(s.var2) if s.var2 else None
        fin = s.fin or []
        has_catch = bool(s.handler)

        self.emit('{')
        self.depth += 1
        self.emit(f'void *{p} = rt_err_push();')
        self.emit(f'if (setjmp(*(jmp_buf *){p}) == 0) {{')
        self.depth += 1
        self.block(s.body)
        self.emit(f'rt_err_pop({p});')
        self.block(fin)                            # finally：正常路也要跑
        self.depth -= 1
        self.emit('} else {')
        self.depth += 1
        self.emit('volatile int _handled = 0;')
        self.emit('rt_err_ready();')              # handler 里还能再抛
        self.emit(f'rt_err_unwind({p});')          # longjmp 跳过了 rt_scope_leave，这里还原
        if has_catch:
            cond = f'rt_err_type_is({cstr(s.etype)})' if s.etype else 'rt_err_type_is(0)'
            self.emit(f'if ({cond}) {{')
            self.depth += 1
            self.emit(f'void *{p2} = rt_err_push();')
            self.emit(f'if (setjmp(*(jmp_buf *){p2}) == 0) {{')
            self.depth += 1
            had = had2 = False
            if slot:
                had = s.var in self.declared
                self.emit(f'Value {slot} = rt_str(rt_err_msg());')
                self.declared.add(s.var)
            if slot2:
                had2 = s.var2 in self.declared
                self.emit(f'Value {slot2} = rt_str(rt_err_type());')
                self.declared.add(s.var2)
            self.catch_depth += 1
            self.block(s.handler)
            self.catch_depth -= 1
            if slot and not had:
                self.declared.discard(s.var)
            if slot2 and not had2:
                self.declared.discard(s.var2)
            self.emit(f'rt_err_pop({p2});')
            self.emit('_handled = 1;')
            self.depth -= 1
            self.emit('} else {')
            self.depth += 1
            self.emit(f'rt_err_pop({p2});')        # handler 里又抛了：错留给外层
            self.depth -= 1
            self.emit('}')
            self.emit(f'rt_err_pop({p});')
            self.depth -= 1
            self.emit('} else {')
            self.depth += 1
            self.emit(f'rt_err_pop({p});')          # 类型对不上：本层不接，交给外层
            self.depth -= 1
            self.emit('}')
        else:
            self.emit(f'rt_err_pop({p});')          # 只有 finally：本层不接
        self.block(fin)                            # finally：三条路都会跑
        if has_catch:
            self.emit('if (!_handled) { rt_err_raise(); }')
        else:
            self.emit('rt_err_raise();')
        self.depth -= 1
        self.emit('}')
        self.depth -= 1
        self.emit('}')

    def gen_throw(self, s: Throw):
        """throw / throw "消息" / throw "消息", "类型"：抛一个可捕获的错误。

        不带参数的 throw 是**重抛**：把手上正在接的那个错原样抛给外层
        （消息和类型都不变）。它只能写在 catch 里——别处没有「手上的错」。"""
        if s.msg is None:
            if self.catch_depth <= 0:
                self.err(s, 'throw（不带参数）是重抛，只能写在 catch 里；'
                            '要抛新的错就写 throw "消息"')
            self.emit('rt_err_rethrow();')
            return
        st, c = self.expr(s.msg)
        for x in st:
            self.emit(x)
        if s.etype is not None:
            st2, c2 = self.expr(s.etype)
            for x in st2:
                self.emit(x)
        else:
            c2 = 'rt_none()'
        self.emit(f'rt_throw({c}, {c2});')

    def gen_forin(self, s: ForIn):
        """for x in 列表 { ... }：逐元素循环。

        元素是 Value 副本（对象共享本体，改属性所有人可见）；循环变量用
        全新槽位遮蔽外层同名变量，循环结束后恢复外层映射。"""
        st, c = self.expr(s.iter)
        for x in st:
            self.emit(x)
        # ⚠ 迭代对象存在临时槽里，而临时槽默认**不生根**（只有具名变量才
        #   rt_root_add）→ GC 一跑就可能把它回收，表现为 for-in 随机段错误
        #   （实测同一份代码连跑 3 次崩 2 次，退出码 3221225477）。
        #   这里开一个根作用域把它登记进去，循环结束退作用域。
        self.emit('rt_scope_enter();')
        tv = self.newtemp()
        self.emit(f'Value {tv} = {c};')
        self.emit(f'rt_root_add(&{tv});')
        saved = self.vmap.pop(s.var, None)
        slot = self.vname(s.var)
        saved2 = self.vmap.pop(s.var2, None) if s.var2 else None
        slot2 = self.vname(s.var2) if s.var2 else None
        had2 = s.var2 in self.declared if s.var2 else False
        iv = self.newtemp('_i')
        # 长度每圈现取：循环里 删掉(...) 也不会越界
        self.emit(f'for (long long {iv} = 0; {iv} < rt_iter_len_ll({tv}); {iv}++) {{')
        self.depth += 1
        self.emit(f'Value {slot} = (IS_DICT({tv}) ? rt_dict_key_at({tv}, {iv}) : rt_index({tv}, rt_at({iv})));')
        if s.var2:
            self.emit(f'Value {slot2} = (IS_DICT({tv}) ? rt_index({tv}, {slot}) : rt_index({slot}, rt_int(1LL)));')
            self.declared.add(s.var2)
        had = s.var in self.declared
        self.declared.add(s.var)
        self.loop_depth += 1
        self.block(s.body)
        self.loop_depth -= 1
        if not had:
            self.declared.discard(s.var)   # 遮蔽退出：只收回循环自己的声明，不动外层
        if s.var2:
            if not had2:
                self.declared.discard(s.var2)
            if saved2 is not None:
                self.vmap[s.var2] = saved2
            else:
                self.vmap.pop(s.var2, None)
        self.depth -= 1
        self.emit('}')
        self.emit('rt_scope_leave();')   # 配上面的 rt_scope_enter：释放迭代对象的根
        if saved is not None:
            self.vmap[s.var] = saved
        else:
            self.vmap.pop(s.var, None)
        if s.var2:
            if saved2 is not None:
                self.vmap[s.var2] = saved2
            else:
                self.vmap.pop(s.var2, None)

    def gen_vc(self, arms, nested=False):
        cond, body = arms[0]
        rest = arms[1:]
        if cond is None:               # 结尾的 vc- 缺省分支
            self.block(body)
            return
        st, c = self.expr(cond)
        for x in st:
            self.emit(x)
        self.emit(f'if (rt_cond({c})) {{')
        self.block(body)
        if not rest:
            self.emit('}')
            return
        self.emit('} else {')
        self.depth += 1
        self.gen_vc(rest, nested=True)
        self.depth -= 1
        self.emit('}')

    # ---- 函数 / 程序 ----

    @staticmethod
    def scan_assigned(stmts, acc):
        """按书写顺序收集本函数内会被赋值的变量名（含嵌套块），供预声明。"""
        for s in stmts:
            if isinstance(s, (VgAssign, IpAssign)):
                if s.name not in acc:
                    acc.append(s.name)
            elif isinstance(s, MultiAssign):
                for tg in s.targets:
                    if isinstance(tg, str) and tg not in acc:
                        acc.append(tg)   # 下标目标（Index）的基变量不算新声明
            elif isinstance(s, Around):
                Codegen.scan_assigned(s.body, acc)
            elif isinstance(s, ForIn):
                Codegen.scan_assigned(s.body, acc)
            elif isinstance(s, Aging):
                Codegen.scan_assigned(s.body, acc)
            elif isinstance(s, WhileStmt):
                Codegen.scan_assigned(s.body, acc)
            elif isinstance(s, CdBlock):
                Codegen.scan_assigned(s.body, acc)
            elif isinstance(s, VcChain):
                for _c, b in s.arms:
                    Codegen.scan_assigned(b, acc)
            elif isinstance(s, (TryCatch, OnError)):
                Codegen.scan_assigned(s.body, acc)
                Codegen.scan_assigned(s.handler, acc)
                if getattr(s, 'fin', None):
                    Codegen.scan_assigned(s.fin, acc)
        return acc

    def emit_locals(self, params, body):
        """规则 3：每个变量预声明 Value v_N = rt_none();（参数除外），
        并把槽地址登记为 GC 根——@5/@6 靠根集追踪可达对象。"""
        for name in self.scan_assigned(body, []):
            if name not in params:
                self.emit(f'Value {self.vname(name)} = rt_none();')
                self.emit(f'rt_root_add(&{self.vname(name)});')
                self.declared.add(name)

    def gen_fn(self, f: FnDef):
        if not hasattr(self, '_defined_fns'):
            self._defined_fns = set()
        if f.name in self._defined_fns:
            self.err(f, f"函数 '{f.name}' 重复定义")
        self._defined_fns.add(f.name)
        self.fns[f.name] = len(f.params)
        默认 = getattr(f, 'defaults', None) or {}
        self.缺省参数[f.name] = [默认.get(p) for p in f.params]
        params = ', '.join(f'Value {self.vname(p)}' for p in f.params) or 'void'
        self.declared = set(f.params)
        self.in_going = False
        self._enter_fn_scope(f.name)
        self.emit(f'Value {self.fname(f.name)}({params}) {{')
        self.depth += 1
        self.emit('rt_scope_enter();')      # GC 根作用域（支持递归嵌套）
        for p in f.params:                  # 参数也是 C 局部量，同样要登记
            self.emit(f'rt_root_add(&{self.vname(p)});')
        self.emit_locals(set(f.params), f.body)
        self._fn_escaped = self._escape_vars(f.body)   # ④ 逃逸分析：本函数内逃逸的局部变量
        self.block(f.body)
        self._fn_escaped = set()
        self.emit('rt_scope_leave();')
        self.emit('return rt_none();')      # 兜底
        self.depth -= 1
        self.emit('}')
        self.emit('')

    # ---- mec.apply 动态分发表（编译器生成进 out.c）----
    def gen_mec_apply(self):
        self.emit('/* mec.apply：mec 库的 lambda/函数动态分发（编译器生成） */')
        self.emit('Value rt_mec_apply(Value fv, Value av) {')
        self.depth += 1
        self.emit('RtList *A = AS_LIST(av);')
        # 部分应用：fv = [函数名, 预填参数...] → 预填拼到实参前面
        self.emit('if (IS_LIST(fv)) {')
        self.emit('    RtList *P = AS_LIST(fv);')
        self.emit('    Value nv = rt_list_new();')
        self.emit('    for (size_t i = 1; i < P->len; i++) rt_push(&nv, P->items[i]);')
        self.emit('    for (size_t i = 0; i < A->len; i++) rt_push(&nv, A->items[i]);')
        self.emit('    fv = P->items[0];')
        self.emit('    av = nv;')
        self.emit('    A = AS_LIST(av);')
        self.emit('}')
        self.emit('const char *nm = rt_str_of(fv);')
        for name, arity in list(self.fns.items()):
            args = ', '.join(f'A->items[{i}]' for i in range(arity))
            self.emit(f'if (strcmp(nm, "{name}") == 0) {{')
            self.emit(f'    if (A->len != {arity}) '
                      f'rt_die("mec.apply: {name} 需要 {arity} 个参数，得到 %d", (int)A->len);')
            self.emit(f'    return {self.fname(name)}({args});')
            self.emit('}')
        self.emit('rt_die("mec.apply: 未知函数 %s", nm);')
        self.emit('return rt_none();')
        self.depth -= 1
        self.emit('}')
        self.emit('')

    # ---- web.块（页面组件）：块 = 一个 void C 函数，调用点展开实参 ----

    def gen_hm_block(self, bd: HmBlockDef):
        cname, _np = self.hm_block_c[bd.name]
        saved = (self.declared, self.vtypes, self.in_going)
        saved_hm = (self.hm_used, self.page_begun)   # 块体不许污染全局页面标志
        self.declared = set(bd.params)
        self.vtypes = {}
        self.in_going = False
        params = ', '.join(f'Value {self.vname(p)}' for p in bd.params) or 'void'
        self.emit(f'static void {cname}({params}) {{')
        self.depth += 1
        self.emit('rt_scope_enter();')
        title = getattr(self, 'program_meta', '') or 'PYbook 页面'
        self.emit(f'rt_page_begin({cstr(title)});')  # 幂等：页面已开则是 no-op
        self.page_begun = True                       # 体内的 gen_hm 不再重复发
        for p in bd.params:
            self.emit(f'rt_root_add(&{self.vname(p)});')
        for st in bd.body:
            self.stmt(st)
        self.emit('rt_scope_leave();')
        self.depth -= 1
        self.emit('}')
        self.emit('')
        self.declared, self.vtypes, self.in_going = saved
        self.hm_used, self.page_begun = saved_hm

    def gen_hm_use(self, s: HmUse):
        if s.name not in self.hm_block_c:
            self.err(s, f"web.{s.name} 不是已定义的组件"
                        "（web.块 须在文件顶层定义）")
        cname, nparams = self.hm_block_c[s.name]
        if len(s.args) != nparams:
            self.err(s, f"web.{s.name} 需要 {nparams} 个参数，实际 {len(s.args)} 个")
        self.hm_used = True
        if not self.page_begun:      # 组件是页面第一条语句时也要先落骨架
            title = getattr(self, 'program_meta', '') or 'PYbook 页面'
            self.emit(f'rt_page_begin({cstr(title)});')
            self.page_begun = True
        args = []
        for a in s.args:
            st, c = self.expr(a)
            for x in st:
                self.emit(x)
            args.append(c)
        self.emit(f'{cname}({", ".join(args)});')

    def gen_hm_page(self, s: HmPageStmt):
        """web.页("名") { ... }：切换到子页缓冲烤内容，烤完切回主页。"""
        self.hm_used = True
        self.emit(f'rt_page_open({cstr(s.name)}, {cstr(s.name)});')
        saved = self.page_begun           # 子页骨架由 rt_page_open 负责
        self.page_begun = True
        for st in s.body:
            self.stmt(st)
        self.emit('rt_page_back();')
        self.page_begun = saved

    # ---- lb 类（OOP）----

    def collect_class(self, cd):
        if cd.name in self.classes:
            self.err(cd, f"类 '{cd.name}' 重复定义")
        self.classes[cd.name] = cd
        for m in cd.methods:
            full = cd.name + '.' + m.name
            if full in self.fns:
                self.err(m, f"方法 '{full}' 重复定义")
            self.fns[full] = len(self._method_full_params(cd, m, False))   # slot0 = self
            self._method_id(m.name)
        for m in cd.static_methods:
            full = cd.name + '.' + m.name
            if full in self.fns:
                self.err(m, f"静态方法 '{full}' 重复定义")
            self.fns[full] = len(m.params)       # 无 self

    def c_proto(self, name, params):
        args = ', '.join(f'Value {self.vname(p)}' for p in params) or 'void'
        return f'Value {self.fname(name)}({args});'

    def gen_class(self, cd):
        saved_cc = self.cur_class
        self.cur_class = cd.name
        # 静态字段：文件级全局（先声明，供下面的静态方法体引用；C 不允许用
        # 函数调用初始化 static，故只零初始化，真正的默认值由 rt_cls_init 在启动时写）
        for i, (fname, default) in enumerate(cd.static_fields):
            self.emit(f'static Value RT_S_{cd.name}_{i};')
        for m in cd.methods:
            self.gen_method(cd, m, False)
        self.cur_class = None          # 静态方法里禁止 self
        for m in cd.static_methods:
            self.gen_method(cd, m, True)
        # 启动初始化：默认值（含无默认值时的 rt_none()）
        if cd.static_fields:
            self.emit(f'static void rt_cls_init_{cd.name}(void) {{')
            self.depth += 1
            saved_vmap = self.vmap; saved_decl = self.declared
            self.vmap = {}; self.declared = set()
            for i, (fname, default) in enumerate(cd.static_fields):
                self.emit(f'RT_S_{cd.name}_{i} = rt_none();')
                if default is not None:
                    st, c = self.expr(default)
                    for x in st: self.emit(x)
                    self.emit(f'RT_S_{cd.name}_{i} = {c};')
            self.vmap = saved_vmap; self.declared = saved_decl
            self.depth -= 1
            self.emit('}')
            self.static_init_calls.append(f'rt_cls_init_{cd.name}();')
        self.cur_class = saved_cc

    def gen_dispatchers(self):
        """为每个实例方法名生成运行时多态分发器（按对象实际类沿继承链向上找最近实现）。"""
        method_names = set()
        for cd in self.classes.values():
            for m in cd.methods:
                if m.name != '构造':          # 构造体是内部构造钩子，不对外多态分发
                    method_names.add(m.name)

        def depth(c):
            d = 0; x = c; seen = set()
            while x in self.classes and self.classes[x].parent is not None and x not in seen:
                seen.add(x); x = self.classes[x].parent; d += 1
            return d
        self.emit('/* 类继承：类名 -> 父类名 */')
        self.emit('static const char* rt_parent_of(const char* cls) {')
        self.depth += 1
        for cd in self.classes.values():
            if cd.parent:
                self.emit(f'if (strcmp(cls, {cstr(cd.name)}) == 0) return {cstr(cd.parent)};')
        self.emit('return "";')
        self.depth -= 1
        self.emit('}')
        self.emit('static int rt_inst_of(const char* x, const char* c) {')
        self.depth += 1
        self.emit('while (x && *x) { if (strcmp(x, c) == 0) return 1; x = rt_parent_of(x); }')
        self.emit('return 0;')
        self.depth -= 1
        self.emit('}')
        self.emit('')
        for M in sorted(method_names):
            mid = self._method_id(M)
            definers = [c for c in self.classes if any(m.name == M for m in self.classes[c].methods)]
            definers.sort(key=lambda c: -depth(c))
            arity = len(self._resolve_method(definers[0], M).params) if definers else 0
            params = ', '.join(f'Value _a{i}' for i in range(arity))
            head = f'static Value rt_disp_{mid}(Value _self, {params})' if arity > 0 else f'static Value rt_disp_{mid}(Value _self)'
            self.emit(head + ' {')
            self.depth += 1
            self.emit('const char* _c = rt_obj_class_name(_self);')
            for c in definers:
                cfn = self.fname(c + '.' + M)
                arglist = ', '.join(['_self'] + [f'_a{i}' for i in range(arity)])
                self.emit(f'if (rt_inst_of(_c, {cstr(c)})) return {cfn}({arglist});')
            self.emit('return rt_none();')
            self.depth -= 1
            self.emit('}')
            self.emit('')

    def gen_method(self, cd, m, is_static=False):
        full = cd.name + '.' + m.name
        params = self._method_full_params(cd, m, is_static)
        self.declared = set(params)
        self.vtypes = {}
        self.in_going = False
        self._enter_fn_scope(full)
        args = ', '.join(f'Value {self.vname(p)}' for p in params)
        self.emit(f'Value {self.fname(full)}({args}) {{')
        self.depth += 1
        self.emit('rt_scope_enter();')
        for p in params:
            self.emit(f'rt_root_add(&{self.vname(p)});')
        self.emit_locals(set(params), m.body)
        self.block(m.body)
        self.emit('rt_scope_leave();')
        self.emit('return rt_none();')
        self.depth -= 1
        self.emit('}')
        self.emit('')

    def gen_methodcall(self, e):
        if isinstance(e.base, VarRef) and e.base.name == 'self':
            if self.cur_class is None:
                self.err(e, 'self 只能在类方法里使用')
            cls = self.cur_class
        elif isinstance(e.base, VarRef):
            cls = self.vtypes.get(e.base.name)
        else:
            cls = None
        found = self._resolve_method(cls, e.name) if cls is not None else None
        if found is None:
            if cls is not None:
                self.err(e, f"类 '{cls}' 及其父类没有方法 '{e.name}'")
            if e.name not in self.method_ids:
                self.err(e, f"方法 '{e.name}' 不存在（对象类型未知，无法静态解析）")
        if found is not None and len(e.args) != len(found.params):
            self.err(e, f"方法 '{e.name}' 需要 {len(found.params)} 个参数，得到 {len(e.args)} 个")
        st, obj_c = self.expr(e.base)
        stmts = list(st)
        args = [obj_c]
        for a in e.args:
            s2, c2 = self.expr(a)
            stmts += s2
            args.append(self.materialize(stmts, c2))
        mid = self._method_id(e.name)
        return stmts, f'rt_disp_{mid}({", ".join(args)})'

    def _resolve_method(self, cls, name):
        c = cls
        seen = set()
        while c is not None and c not in seen:
            seen.add(c)
            cd = self.classes.get(c)
            if cd is None:
                return None
            for m in cd.methods:
                if m.name == name:
                    return m
            c = cd.parent
        return None

    def _method_id(self, name):
        if name not in self.method_ids:
            self.method_ids[name] = len(self.method_ids)
        return self.method_ids[name]

    def _method_full_params(self, cd, m, is_static):
        """方法 C 函数形参表：构造体 `构造` 额外把类的构造形参纳入（供 self.半径=x+y 用）。"""
        if not is_static and m.name == '构造':
            return ['self'] + list(cd.ctor_params)
        if is_static:
            return list(m.params)
        return ['self'] + list(m.params)

    def _static_field_index(self, class_name, field_name):
        cd = self.classes.get(class_name)
        if cd is None:
            return None
        for i, (fn, _d) in enumerate(cd.static_fields):
            if fn == field_name:
                return i
        return None

    def gen_ctor(self, e):
        cd = self.classes.get(e.class_name)
        if cd is None:
            self.err(e, f"未定义的类 '{e.class_name}'")
        argmap = {}
        if e.pos_args:
            if len(e.pos_args) > len(cd.ctor_params):
                self.err(e, f"类 '{e.class_name}' 构造需要 {len(cd.ctor_params)} 个位置参数，得到 {len(e.pos_args)} 个")
            for i, p in enumerate(cd.ctor_params):
                if i < len(e.pos_args):
                    argmap[p] = e.pos_args[i]
        for kn, vex in e.kwargs:
            argmap[kn] = vex
        saved_vmap = self.vmap; saved_decl = self.declared
        self.vmap = dict(self.vmap); self.declared = set(self.declared)
        stmts = []
        cparam_vars = {}
        for p in cd.ctor_params:
            cv = self.newtemp('_cp')
            self.vmap[p] = cv
            self.declared.add(p)
            if p in argmap:
                s2, c2 = self.expr(argmap[p]); stmts += s2
                stmts.append(f'Value {cv} = {c2};')
            else:
                stmts.append(f'Value {cv} = rt_none();')
            cparam_vars[p] = cv
        t = self.newtemp()
        stmts.append(f'Value {t} = rt_obj_new({cstr(e.class_name)});')
        chain = []
        c = e.class_name; seen = set()
        while c is not None and c not in seen:
            seen.add(c); chain.append(c)
            c = self.classes.get(c).parent if c in self.classes else None
        chain.reverse()
        for cname in chain:
            for pname, default in self.classes.get(cname).props:
                if pname in argmap:
                    vex = argmap[pname]
                elif default is not None:
                    vex = default
                else:
                    continue
                s2, c2 = self.expr(vex); stmts += s2
                stmts.append(f'rt_obj_set_prop({t}, {cstr(pname)}, {c2});')
        ctor_method = next((m for m in cd.methods if m.name == '构造'), None)
        if ctor_method is not None:
            cargs = [cparam_vars[p] for p in cd.ctor_params]
            stmts.append(f'{self.fname(e.class_name + ".构造")}({t}{((", " + ", ".join(cargs)) if cargs else "")});')
        self.vmap = saved_vmap; self.declared = saved_decl
        return stmts, t

    def generate(self, program: Program) -> str:
        self._collect_c_decls(program)   # register all ffi.声明 before emitting
        self.program_meta = program.meta
        if program.go_body is None:
            raise PybkCodegenError('GOING 缺失：程序必须包含 GOING 块')
        # mec lambda 预扫描：收集并编号，降级成顶层函数 __mec_lam_N
        mec_lams = []
        _mec_walk_lams(program, mec_lams)
        mec_fns = [FnDef(f'__mec_lam_{L.n}', L.params, L.body, L.line)
                   for L in mec_lams]
        classes = program.classes or []
        for cd in classes:
            self.collect_class(cd)
        # 标量化用：每个函数体赋过哪些变量（圈前类型可信度的依据）
        self._fn_assign = self._collect_fn_vars(program, mec_fns)
        # 预登记全部普通函数：语义表先于函数体生成就绪，函数之间才能互相前向调用
        # （重复定义检查在 gen_fn 里做，这里只登记名字/参数个数/缺省值）
        for f in program.fns:
            self.fns[f.name] = len(f.params)
            默认 = getattr(f, 'defaults', None) or {}
            self.缺省参数[f.name] = [默认.get(p) for p in f.params]
        # 原型声明：类方法与普通函数可互相前向调用
        for f in program.fns:
            self.emit(self.c_proto(f.name, f.params))
        for cd in classes:
            for m in cd.methods:
                self.emit(self.c_proto(cd.name + '.' + m.name,
                                       self._method_full_params(cd, m, False)))
            for m in cd.static_methods:
                self.emit(self.c_proto(cd.name + '.' + m.name,
                                       self._method_full_params(cd, m, True)))
        for f in mec_fns:
            self.emit(self.c_proto(f.name, f.params))
        self.emit('Value rt_mec_apply(Value fv, Value av);')
        self.emit('')
        for cd in classes:
            self.gen_class(cd)
        self.gen_dispatchers()
        for f in program.fns:
            self.gen_fn(f)
        for f in mec_fns:
            self.gen_fn(f)
        self.gen_mec_apply()

        # ---- web.块（页面组件）：先分配 C 名发原型，再逐个生成函数体 ----
        hm_blocks = list((getattr(program, 'hm_blocks', None) or {}).values())
        for bd in hm_blocks:
            if bd.name in self.hm_block_c:
                self.err(bd, f"web.块 '{bd.name}' 重复定义")
            self.hm_block_c[bd.name] = ('hm_blk_' + str(len(self.hm_block_c)),
                                        len(bd.params))
        for bd in hm_blocks:                # 原型：组件互相调用与顺序解耦
            cname, _np = self.hm_block_c[bd.name]
            params = ', '.join(f'Value {self.vname(p)}' for p in bd.params) or 'void'
            self.emit(f'static void {cname}({params});')
        if hm_blocks:
            self.emit('')
        for bd in hm_blocks:
            self.gen_hm_block(bd)

        self.declared = set()
        self.vtypes = {}
        self.in_going = True
        # 主程序作用域：圈前类型只看主程序自己的赋值（函数可能在圈前改过全局）
        self._cur_fn = None
        self._fn_vars = set()
        self._fn_kinds = {}
        for g, (ns, ks) in self._fn_assign.items():
            self._fn_vars |= ns
            for n, kk in ks.items():
                self._fn_kinds.setdefault(n, set()).update(kk)
        self.emit('int main(void) {')
        self.depth += 1
        self.emit('setvbuf(stdout, NULL, _IONBF, 0);   /* 输出即时可见，供交互输入 */')
        # 把 lambda/函数的动态分发表装进运行时，这样库函数（mt.deriv 之类）
        # 也能回调用户的 f。rt_mec_apply 是本文件 gen_mec_apply() 生成的，
        # 每个 C 后端程序都有，所以这行无条件安全。
        self.emit('rt_set_fn_dispatch(rt_mec_apply);')
        self.emit('rt_scope_enter();')      # 主程序也是一层 GC 根作用域
        for _c in self.static_init_calls:
            self.emit(_c)
        self.emit_locals(set(), program.go_body)
        if getattr(program, 'window_open', 0):
            win_i = None
            for k3, st3 in enumerate(program.go_body):
                if isinstance(st3, Call) and st3.name == 'win':
                    win_i = k3
                    break
            if win_i is None:
                raise PybkCodegenError(
                    'window(normal, open) 模式：GOING 里必须调用 win(宽, 高, "标题")'
                    '（它之前的语句只跑一次，之后的语句每帧跑）')
            self.block(program.go_body[:win_i + 1])       # 一次性初始化（含 win）
            self.emit('for (;;) {')
            self.depth += 1
            self.emit('if (rt_cond(rt_game_end())) break;')
            self.block(program.go_body[win_i + 1:])       # 每帧体
            self.emit('rt_game_show();')
            self.emit('rt_game_frame();')
            self.depth -= 1
            self.emit('}')
        else:
            self.block(program.go_body)
        if self.in_draw is not None:      # 缺 web.draw.终：自动补脚本闭合，保证页面有效
            close_c = cstr('</script>\n')
            self.emit(f'rt_page_raw({close_c});')
            self.in_draw = None
        if self.hm_used:
            self.emit('rt_page_save();')   # hm 页面落盘 pybook_page.html
        if self.test_used:
            self.emit('return (int)rt_test_summary();')   # 查() 汇总：失败数当退出码
        self.emit('rt_scope_leave();')
        self.emit('return 0;')
        self.depth -= 1
        self.emit('}')

        header = ['/* PYbook 名字映射（语言名 -> C 名） */']
        meta = ' '.join(str(program.meta).split())
        if meta:
            header.append(f'/* @ {meta} */')
        if self.fmap:
            header.append('/* 函数: ' + ', '.join(f'{k} -> {v}' for k, v in self.fmap.items()) + ' */')
        if self.vmap:
            header.append('/* 变量: ' + ', '.join(f'{k} -> {v}' for k, v in self.vmap.items()) + ' */')

        # ---- ffi.* FFI header artifacts: includes / prototypes / raw C ----
        ffi = ''
        for inc in self.c_includes:
            inc = inc.strip()
            if not (inc.startswith('<') or inc.startswith('"')):
                inc = f'<{inc}>'
            ffi += f'#include {inc}\n'
        if self.c_includes:
            ffi += '\n'
        if self.c_ffi_proto:
            ffi += '/* prototypes from ffi.声明 */\n' + '\n'.join(self.c_ffi_proto) + '\n\n'
        if self.clib_proto:
            ffi += ('/* prototypes from same-folder C libraries '
                    '(%s) */\n' % ', '.join(os.path.basename(x) for x in self.clib_files)
                    + '\n'.join(self.clib_proto) + '\n\n')
        if self.c_raw:
            ffi += '/* ffi.码: raw C (your own responsibility) */\n' + '\n'.join(self.c_raw) + '\n\n'

        return ('\n'.join(header)
                + '\n\n#include <stdio.h>\n#include <stdlib.h>\n#include <string.h>\n#include <setjmp.h>\n#include "pybook_rt.h"\n#include "pybook_lib.h"\n\n'
                + ffi
                + (self.hw_used and gen_hw_protos() or '')
                + gen_ui_protos()
                + (PK_HELPERS_C if self._pk_helpers else '')
                + SPRITE_HELPERS_C                + '\n'.join(self.out))

# ---------------- 3D_highway 原型发射 ----------------

def _mec_walk_lams(node, out):
    """mec lambda 预扫描：递归走 AST 收集 Lambda 节点并按先序编号（node.n = 1,2,3...）。
    必须在 generate() 发射任何东西之前跑一遍（lambda 要降级成顶层 C 函数）。"""
    if isinstance(node, Lambda):
        node.n = len(out) + 1
        out.append(node)
    if isinstance(node, (list, tuple)):
        for x in node:
            _mec_walk_lams(x, out)
    elif isinstance(node, dict):
        for x in node.values():
            _mec_walk_lams(x, out)
    elif node is not None and hasattr(node, '__dataclass_fields__'):
        for k in node.__dataclass_fields__:
            _mec_walk_lams(getattr(node, k, None), out)


def gen_hw_protos() -> str:
    """out.c 需要的 rt_hw_* 原型（实现在 pybook_hw3d.c）。"""
    fns = ['open:3', 'clearcolor:3', 'camera:5', 'box:9', 'frame:0', 'end:0', 'key:1', 'hit:1', 'mx:0', 'my:0', 'mdown:0', 'mhit:0', 'text:4', 'grab:0', 'free:0', 'mdx:0', 'mdy:0',
           'wheel:0', 'textc:7', 'rect:7', 'post:1', 'postfx:2',
           'shadow:1', 'shadowres:1', 'shadowarea:1', 'shadowbias:1', 'shadowcenter:3',
           'bloom:2', 'particles_clear:0', 'burst:11', 'particles:1']
    lines = ['/* 3D_highway（实现在 pybook_hw3d.c） */']
    for f in fns:
        name, n = f.split(':')
        args = ', '.join(['Value'] * int(n)) or 'void'
        lines.append('Value rt_hw_' + name + '(' + args + ');')
    # box 的变长版：hw.box(...) 给 12 个实参时（带绕 x/y/z 旋转）走这里
    lines.append('Value rt_hw_boxn(int nargs, Value *av);')
    # 雾 / 视距 / 线框：编辑器与近景演示用
    lines.append('Value rt_hw_fog(Value, Value);')
    lines.append('Value rt_hw_far(Value);')
    lines.append('Value rt_hw_wire(Value);')
    # UI 同屏：ui.离屏 那块 surface 贴到画面哪儿。0 参 = 全屏，1 参 = 右侧栏宽，4 参 = (x,y,w,h)
    lines.append('Value rt_hw_ui(int nargs, Value *av);')
    # 画线 / 光照：gizmo 坐标轴、真实明暗
    lines.append('Value rt_hw_line(Value, Value, Value, Value, Value, Value, Value, Value, Value);')
    lines.append('Value rt_hw_light(Value, Value, Value, Value);')
    # 球 / 圆柱（cyl 走变长入口，9 或 10 参）
    lines.append('Value rt_hw_sphere(Value, Value, Value, Value, Value, Value, Value);')
    lines.append('Value rt_hw_cylv(int nargs, Value *av);')
    # 视口：竖直视场角 / 近裁剪面
    lines.append('Value rt_hw_fov(Value);')
    lines.append('Value rt_hw_wininfo(void);')
    lines.append('Value rt_hw_resize(Value, Value);')
    lines.append('Value rt_hw_near(Value);')
    lines.append('Value rt_hw_ortho(Value);')
    # 贴图：加载 / 选择 / UV 平铺
    lines.append('Value rt_hw_tex(Value, Value);')
    lines.append('Value rt_hw_texuse(Value);')
    lines.append('Value rt_hw_uv(Value);')
    # 父子层级
    lines.append('Value rt_hw_push(Value, Value, Value, Value, Value, Value);')
    lines.append('Value rt_hw_pop(void);')
    # 可编程管线（GLSL）：编译着色器 / 内置着色器 / 启用 / 设 uniform
    lines.append('Value rt_hw_shader(Value, Value, Value);')
    lines.append('Value rt_hw_preset(Value, Value);')
    lines.append('Value rt_hw_shaderuse(Value);')
    lines.append('Value rt_hw_univ(int nargs, Value *av);')
    # .obj 三角网格：加载 / 查询 / 转轴 / 换色 / 绘制 / 释放
    lines.append('Value rt_hw_obj(Value);')
    lines.append('Value rt_hw_objinfo(Value);')
    lines.append('Value rt_hw_objfix(Value, Value);')
    lines.append('Value rt_hw_objcolor(Value, Value, Value, Value);')
    lines.append('Value rt_hw_objdraw(Value, Value, Value, Value, Value);')
    lines.append('Value rt_hw_objdrawr(Value, Value, Value, Value, Value, Value, Value, Value);')
    lines.append('Value rt_hw_objfree(Value);')
    lines.append('Value rt_hw_objh(Value, Value, Value);')
    lines.append('Value rt_hw_rdown(void);')
    lines.append('Value rt_hw_rhit(void);')
    return '\n'.join(lines) + '\n'

def gen_ui_protos() -> str:
    """out.c 需要的 rt_ui_* 原型（实现在 pybook_ui.c）。

    与 gen_hw_protos 的区别：hw 那批只在用到 3D 时才发，ui 这批无条件发 ——
    未使用的函数原型在 C 里无害，省得再去维护一个 ui_used 标志。"""
    fns = ['begin:3', 'row:0', 'col:0', 'end:0', 'gap:1', 'tag:1',
           'label:2', 'button:1', 'input:1', 'slider:3', 'check:2', 'table:4',
           # 小节容器：面板 + 标题 + 分隔线，治「一堆字幕浮在黑底上」
           'group:1',
           # 外观：圆角（默认）/ 字符边框（TUI 味），以及字符网格步进
           'style:1', 'cell:1',
           # 离屏：UI 渲进内存 surface 交给 3D 贴上去（3D + UI 同屏的唯一可行路径）
           'offscreen:2',
           # 图片：ui.图(路径,宽,高) / ui.序列(模板,首,末,毫秒,宽,高)
           'img:3', 'seq:6',
           # 粒子：ui.粒子(宽,高,每帧发射数,R,G,B) / ui.粒子调(重力,阻力,速度,大小,寿命)
           'fx:6', 'fx_tune:5',
           # 交互注入（2026-08）：让 PYbook 能脚本化"点一下/按住不放"，
           # 把 ui.* 的交互变成可回归的。原先只能人手点窗口。
           'test_input:4', 'test_input_reset:0',
           # 控件矩形回读：ui.tag 钉住的控件，下一帧用 ui.矩形(name) 取回 [x,y,w,h]
           'rect:1']
    lines = ['/* 桌面 GUI（实现在 pybook_ui.c，立即模式 / SDL2 自绘） */']
    for f in fns:
        name, n = f.split(':')
        args = ', '.join(['Value'] * int(n)) or 'void'
        lines.append('Value rt_ui_' + name + '(' + args + ');')
    return '\n'.join(lines) + '\n'


# ---------- 全流程 ----------

# ---------------- 模块系统：引用("名") 的递归加载与合并 ----------------

_MEM_MODE_MAX_DEPTH = 8     # 引用嵌套深度上限（防循环引用拖垮编译器）


def _main_file_dir() -> str:
    """主文件所在目录。pybk_main.py 把 .pybk 路径放在 argv[1]；
    被嵌入调用（argv 不可用）时退回当前目录。
    加强：--check/--check-json 这类旗标占住 argv[1] 时，扫 argv 找第一个
    真实存在的 .pybk 取其目录——否则从别的目录跑检查，引用() 的同目录
    包就"找不到文件"（跨目录检查必踩）。
    PYBK_IMPORT_DIR 排最前：IDE 把待检查源码临时落到系统临时目录，靠它指回
    工程目录。必须与前端类预加载（pybk_front._import_base_dir）用同一个基准，
    否则会报假的「未定义的类」。"""
    env = os.environ.get('PYBK_IMPORT_DIR')
    if env:
        return env
    for _a in sys.argv[1:]:
        if _a.lower().endswith('.pybk') and os.path.isfile(_a):
            return os.path.dirname(os.path.abspath(_a)) or '.'
    if len(sys.argv) >= 2 and os.path.isfile(sys.argv[1]):
        return os.path.dirname(os.path.abspath(sys.argv[1])) or '.'
    return os.getcwd()


def _load_imports(program, base_dir: str, chain: list, merged=None, paths=None, root=None):
    """深度优先加载 program.imports 指向的模块单元。

    返回 (合并后的函数列表, 初始化语句列表, 类列表, 宏列表)：被依赖的模块先合并；
    函数/类/宏重名、循环引用、文件缺失都抛 PybkCodegenError（带行号）。

    merged 记录「本次加载会话里已经合并过的模块」：菱形/共享依赖（A→B、A→C→B）
    只合并一次，避免「函数重复定义」误报——这是大工程下多文件共享同一基础库的常态。

    命名空间：模块实际位于**子目录**里（相对 root，例如 lib/助手.pybk）→ 进命名
    空间「助手_」，它的函数/类/宏/顶层变量一律带前缀（助手_加、lb.助手_数据表），
    模块内部照常写裸名、由编译器改写；就在根目录的模块（助手.pybk）维持平铺的老
    行为，既有工程逐字不变。

    paths 是本条引用链上的实际文件路径（循环引用按路径判，不按名字判——
    "a/助手" 和 "b/助手" 是两个模块，不是一个）。root 是命名空间根目录。"""
    if merged is None:
        merged = set()
    if paths is None:
        paths = []
    if root is None:
        root = base_dir
    if len(chain) > _MEM_MODE_MAX_DEPTH:
        raise PybkCodegenError('引用嵌套超过 8 层：' + ' -> '.join(chain))
    fns: list = []
    init_stmts: list = []
    classes: list = []
    macros: list = []
    for name, ln in (program.imports or []):
        path = resolve_module_path(base_dir, name)
        if not path:
            raise PybkCodegenError(f'第 {ln} 行：引用("") 是空的模块名')
        if path in paths:
            raise PybkCodegenError(
                f'第 {ln} 行：循环引用：' + ' -> '.join(chain + [name]))
        prefix = module_ns_prefix(path, root)
        key = (path, prefix)        # 已合并过（菱形/共享依赖），跳过避免重复定义
        if key in merged:
            continue
        merged.add(key)
        if not os.path.isfile(path):
            raise PybkCodegenError(
                f'第 {ln} 行：找不到文件: {path}\n'
                f'  为什么：引用("{name}") 找的是 {path}（路径相对引用方所在目录）\n'
                f'  怎么改：确认文件在；引用名可带子目录，如 引用("lib/助手")')
        try:
            with open(path, encoding='utf-8-sig') as f:
                sub_src = f.read()
        except OSError as e:
            raise PybkCodegenError(f'第 {ln} 行：读取 {path} 失败：{e}')
        sub_base = os.path.dirname(path) or '.'
        try:
            sub = parse_module(sub_src, sub_base, root)
        except RecursionError:
            raise PybkCodegenError(f'第 {ln} 行：模块 {name} 嵌套太深')
        # 子目录模块进命名空间：顶层定义与内部引用统一加前缀（根目录模块 prefix 为空，原样）
        rewrite_namespace(sub, prefix)
        # 先合并该模块自己的依赖（深度优先），再合并它本身：
        # 依赖的函数/变量先入表，后加载者可以调用先加载者
        sub_fns, sub_inits, sub_classes, sub_macros = _load_imports(
            sub, sub_base, chain + [name], merged, paths + [path], root)
        for cd in sub_classes:
            if any(x.name == cd.name for x in classes):
                raise PybkCodegenError(
                    f'第 {ln} 行：类 {cd.name!r} 在引用的模块里重复定义')
            classes.append(cd)
        for f in sub_fns:
            if any(x.name == f.name for x in fns):
                raise PybkCodegenError(
                    f'第 {ln} 行：函数 {f.name!r} 在引用的模块里重复定义')
            fns.append(f)
        init_stmts.extend(sub_inits)
        for f in (sub.fns or []):
            if any(x.name == f.name for x in fns):
                raise PybkCodegenError(
                    f'第 {ln} 行：函数 {f.name!r} 重复定义（引用合并冲突）\n'
                    f'  为什么：引用("{name}") 里的函数与另一个模块重名\n'
                    f'  怎么改：① 把该模块放进子目录（引用("{prefix.rstrip("_")}/...")），'
                    f'编译期自动加命名空间前缀；② 或给其中一个函数改名')
            fns.append(f)
        init_stmts.extend(sub.go_body or [])   # 模块的顶层 vg → 初始化语句
        for cd in (sub.classes or []):         # 模块的类也并入（大工程可按文件拆类）
            if any(x.name == cd.name for x in classes):
                raise PybkCodegenError(
                    f'第 {ln} 行：类 {cd.name!r} 重复定义（引用合并冲突）')
            classes.append(cd)
        for mc in (sub.macros or []):          # 模块里的 宏 也并入（跨文件复用代码宏）
            if any(x.name == mc.name for x in macros):
                raise PybkCodegenError(
                    f'第 {ln} 行：宏 {mc.name!r} 重复定义（引用合并冲突）')
            macros.append(mc)
    return fns, init_stmts, classes, macros


def _watch_loop(path: str) -> None:
    """--watch 模式：每 0.5 秒检查文件 mtime，变了就重新编译运行一次。
    单次编译失败把 gcc/语法错误完整打到 stderr 后继续等（循环不死）；
    Ctrl+C 退出。"""
    print('[watch] 监视 ' + path + '（每 0.5 秒检查修改；Ctrl+C 退出）', flush=True)
    last_mtime = None
    runs = 0
    while True:
        try:
            mtime = os.path.getmtime(path)
        except OSError:
            mtime = None
        if mtime != last_mtime:
            first = last_mtime is None
            last_mtime = mtime
            if first:
                print('[watch] 初次编译运行', flush=True)
            else:
                runs += 1
                print(f'[watch] 检测到修改，第 {runs} 次重跑', flush=True)
            try:
                with open(path, encoding='utf-8-sig') as f:
                    compile_and_run_once(f.read())
            except KeyboardInterrupt:
                raise
            except Exception as e:   # 语法/编译/运行错误都只报告，watch 不退出
                print(str(e), file=sys.stderr, flush=True)
        time.sleep(0.5)


def compile_and_run(src: str, program=None) -> str:
    """入口：--watch 模式进热重载循环；否则单次编译运行（行为与输出不变）。
    program 若由 pybk_main 预解析（已完成 引用 合并 + 宏展开），则直接复用，跳过重解析。"""
    # 被管道/编辑器调用时输出强制 UTF-8；直接在控制台跑则保留系统编码
    if not sys.stdout.isatty():
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    if not sys.stderr.isatty():
        sys.stderr.reconfigure(encoding='utf-8', errors='replace')
    if _WATCH_MODE:
        _watch_loop(sys.argv[1] if len(sys.argv) >= 2 else '.')
        return ''
    return compile_and_run_once(src, program)


def compile_and_run_once(src: str, program=None, _prepared=False) -> str:
    """单次：源码 → AST → out.c → gcc（.o 缓存 + 链接）→ 运行。

    语义错误抛 PybkCodegenError（带行号）；gcc 失败抛 PybkCodegenError
    （附 gcc 输出）；程序运行时非零退出抛 RuntimeError。
    正常时回显程序输出并作为返回值。

    program 若由调用方预解析并已完成 引用 合并 + 宏展开，传 _prepared=True
    即可跳过 parse / _load_imports / expand_macros（pybk_main 的 errorstopped 模式路径用）。"""
    try:
        if program is None:
            program = parse(src)
            _prepared = False
        else:
            _prepared = True
    except RecursionError:
        raise PybkCodegenError('表达式或括号嵌套太深，请拆分后再试')
    if not _prepared:
        if program.imports:                   # 模块系统：合并被引用文件的函数与变量
            imported_fns, imported_inits, imported_classes, imported_macros = _load_imports(
                program, _main_file_dir(), ['<主文件>'])
            program.fns = imported_fns + (program.fns or [])
            program.go_body = imported_inits + (program.go_body or [])
            program.classes = imported_classes + (program.classes or [])
            program.macros = imported_macros + (program.macros or [])
        if program.macros:                    # 宏：编译期内联展开（须在代码生成之前）
            expand_macros(program)

    # ---- 可执行文件缓存：源码/引用库/编译器/运行时都没变，就直接跑上次的 exe ----
    # 省掉「生成 C + gcc 链接」那几秒（.o 缓存只省运行时编译，这里省得更多）。
    # 注意：hm 网页程序命中缓存时不弹浏览器（那是冷门路径，不值得为它存元数据）。
    cache_key = _src_fingerprint(src)
    cached_exe = os.path.join(EXE_CACHE_DIR, 'prog_%s.exe' % cache_key)
    if not NO_EXE_CACHE:
        os.makedirs(EXE_CACHE_DIR, exist_ok=True)
    if not NO_EXE_CACHE and os.path.isfile(cached_exe):
        try:
            run = subprocess.run([cached_exe if os.name == 'nt' else './' + cached_exe],
                                 capture_output=True, text=True,
                                 encoding='utf-8', errors='replace')
            if run.stdout:
                print(run.stdout, end='')
            if run.returncode != 0:
                if run.stderr:
                    sys.stderr.write(run.stderr)
                raise RuntimeError(f'程序异常退出，退出码 {run.returncode}')
            return run.stdout
        except PermissionError:
            pass            # 杀软正锁着缓存的 exe：落到下面正常编译

    gen = Codegen()
    main_dir = _main_file_dir()
    clibs = gen.clib_list         # 同目录 C 库（Codegen.__init__ 里已挂好）
    c_code = gen.generate(program)
    c_path = f'out_{os.getpid()}_{int(time.time() * 1000) % 1000000}.c'
    with open(c_path, 'w', encoding='utf-8') as f:
        f.write(c_code)

    gcc = shutil.which('gcc') or FALLBACK_GCC
    # 链接出的 exe 会被杀软实时扫描锁住一小段时间；固定名 app.exe 在下一次
    # 编译时要覆盖它 → ld: cannot open output file app.exe: Permission denied。
    # 故改用「每进程唯一」的 exe 名，彻底避开与残留 exe 争用同一文件名；
    # 编译期的短重试只作兜底。
    exe = f'app_{os.getpid()}_{int(time.time() * 1000) % 1000000}.exe'
    game_flags = ['-DRT_GAME_SDL', '-static-libgcc', '-static-libstdc++', '-Wl,-Bstatic,-lwinpthread,-Bdynamic']
    sdl_flags = []
    if os.path.isdir('ucrt64/include/SDL2'):
        sdl_flags = ['-Iucrt64/include', '-Lucrt64/lib']

    # ---- 运行时预编译缓存（.o）：四个几乎不变的 .c 只有过期才重编 ----
    # 缓存在 rt_cache/ 目录；-DRT_GAME_SDL 会改变 pybook_rt.c 的编译产物，
    # 所以游戏模式的 .o 用独立文件名（.sdl.o），与普通模式互不污染。
    os.makedirs(RT_CACHE_DIR, exist_ok=True)
    objs = []
    for c_name in ('pybook_rt.c', 'pybook_lib.c', 'pybook_file.c',
                   'pybook_music.c', 'pybook_net.c', 'pybook_hw3d.c',
                   'pybook_np.c', 'pybook_tb.c', 'pybook_mt.c', 'pybook_json.c', 'pybook_csv.c', 'pybook_mm.c', 'pybook_plot.c', 'mathplus.c', 'pybook_bits.c', 'pybook_ui.c', 'pybook_m3d.c', 'pybook_smoke.c', 'pybook_obj.c', 'pybook_wire.c', 'pybook_gpu.c', 'pybook_la.c', 'pybook_sym.c', 'pybook_re.c', 'pybook_crypto.c'):
        o_path = os.path.join(RT_CACHE_DIR,
                              c_name[:-2] + ('.sdl' if game_flags else '') + RT_CFLAGS_TAG + '.o')
        dep_mtime = os.path.getmtime(c_name)
        h_name = c_name[:-2] + '.h'
        if os.path.exists(h_name):
            dep_mtime = max(dep_mtime, os.path.getmtime(h_name))
        if not os.path.exists(o_path) or os.path.getmtime(o_path) < dep_mtime:
            # 编到临时文件再原子改名（os.replace）：
            # 两个进程同时编同一个 .o 时，链接方不会读到别人写了一半的 .o。
            # 半截 .o 链出来的程序不会编译报错，而是行为诡异地错（实测：
            # 同一对数学用例偶发算错，单独重跑又对），比报错更难查。
            tmp_o = f'{o_path}.tmp{os.getpid()}'
            cc = subprocess.run([gcc, *RT_CFLAGS, '-DMP_RT_BINDING', '-DLA_RT_BINDING', '-DSYM_RT_BINDING', '-c', c_name, '-o', tmp_o]
                                + game_flags + sdl_flags,
                                capture_output=True, text=True, errors='replace')
            if cc.returncode != 0:
                raise PybkCodegenError('gcc 编译失败（运行时 ' + c_name
                                       + '）：\n' + (cc.stderr or cc.stdout))
            os.replace(tmp_o, o_path)
        objs.append(o_path)

    # ---- 用户同目录的 C 库：编成 .o 一起链接 ----
    clib_objs = []
    for cl in clibs:
        clib_objs.append(_compile_clib(cl, gcc, game_flags, sdl_flags, main_dir))

    build = None
    for _attempt in range(4):
        build = subprocess.run([gcc, *RT_CFLAGS] + game_flags + sdl_flags +
                               ['-o', exe, c_path] + objs + clib_objs +
                               ['-lSDL2', '-lwinmm', '-lws2_32', '-lwininet', '-lopengl32', '-lbcrypt']
                               + ['-l' + x for x in gen.c_libs],   # ffi.链接("user32") 等
                               capture_output=True, text=True, errors='replace')
        if build.returncode == 0 or 'Permission denied' not in (build.stderr or ''):
            break
        time.sleep(0.3 * (_attempt + 1))
    if build.returncode != 0:
        _link_hint = build.stderr or build.stdout or ''
        if clib_objs and 'multiple definition' in _link_hint:
            _link_hint += ('\n\n  提示：某个 C 库里的函数名和 PYbook 运行时/标准库的符号重名了'
                           '\n  怎么改：把 C 那边的函数改成别的名字（比如加个 my_ 前缀）')
        elif clib_objs and 'undefined reference' in _link_hint:
            _link_hint += ('\n\n  提示：链接时找不到某个符号 —— 多半是同目录 C 库的 .c 里少写了一个实现，'
                           '或者声明的原型和实现对不上'
                           '\n  怎么改：检查 .c 里是不是每个声明都有对应的函数体')
        raise PybkCodegenError('gcc 编译失败：\n' + _link_hint)

    # 存进 exe 缓存：下次源码没变就能跳过整个编译。失败不影响本次运行。
    if not NO_EXE_CACHE:
        try:
            shutil.copy(exe, cached_exe)
            _prune_exe_cache()
        except OSError:
            pass

    # 注意：这里**不要**用 os.remove 清理本次生成的 exe。沙箱的 safe-delete
    # shim 会拦截 os.remove 并 fail-closed（回收站不可用），把错误打到 stderr，
    # 从而污染那些需要精确比对 stderr 的用例。残留的 app_*.exe 由外部 mv 清理。
    for _attempt in range(4):
        try:
            run = subprocess.run([exe if os.name == 'nt' else './' + exe],
                                 capture_output=True, text=True,
                                 encoding='utf-8', errors='replace')
            break
        except PermissionError:
            # 杀软可能短暂锁住刚链接出的 exe
            if _attempt == 3:
                raise
            time.sleep(0.3 * (_attempt + 1))
    if run.stdout:
        print(run.stdout, end='')
    if run.returncode != 0:
        if run.stderr:
            sys.stderr.write(run.stderr)
        raise RuntimeError(f'程序异常退出，退出码 {run.returncode}')
    if gen.hm_used and os.name == 'nt' and hasattr(os, 'startfile'):
        page = os.path.abspath('pybook_page.html')
        if os.path.exists(page):
            os.startfile(page)      # hm 程序：运行结束后自动弹浏览器
    return run.stdout


# ---------- 自测 ----------

SELF_TEST_SRC = '''@ 测试>样例>一
func 加倍(n) {
    ret n * 2
}
GOING:{
vg.名字 = "世界"
vg.次数 = 3
ns.show(你好 $名字！)/magic(b, c=0,200,255)
rm.around(次数) {
    ns.show(第 $at 圈)
}
if(次数 >= 3) {
    ns.show(次数不少)
}
else {
    ns.show(次数太少)
}
vg.结果 = list.加倍(21)
ns.show(结果=$结果)
}STOP
'''

if __name__ == '__main__':
    output = compile_and_run(SELF_TEST_SRC)
    for frag in ('42', '第 0 圈', '第 1 圈', '第 2 圈', '次数不少', '结果=42'):
        assert frag in output, f'自测失败：输出缺少 {frag!r}，实际 {output!r}'
    print('自测通过：42 / 第 0..2 圈 / 次数不少 / 结果=42 均出现')

    # ---- 帧动画 + go：只生成 C（不运行），核对 JS 骨架 ----
    ANIM_SRC = '''@ 动画>测试>一
GOING:{
web.draw.始
web.帧 {
    web.draw.色(255, 0, 0)
    web.draw.圆(200, 150, 80)
}
web.帧 {
    web.draw.色(0, 0, 255)
    web.draw.方(100, 100, 160, 160)
}
web.播放(2)
go(右, 100, 2)
web.draw.终
}STOP
'''
    anim_c = Codegen().generate(parse(ANIM_SRC))
    for frag in ('pybook-canvas-1',
                 'const pybk_frames = [',
                 'function() {',
                 'setInterval(function() {',
                 'ctx1.clearRect(0, 0, 400, 300);',
                 'pybk_frames[pybk_frame % pybk_frames.length]();',
                 "pybk_canvas.style.transition = 'transform ",
                 "pybk_canvas.style.transform = 'translateX("):
        assert frag in anim_c, f'帧动画自测失败：C 输出缺少 {frag!r}'
    assert anim_c.count('rt_page_raw("function() {")') == 2, 'pybk_frames 应包含两个帧函数'
    print('帧动画自测通过：pybk_frames 数组（两帧）/ setInterval 循环 / CSS transform 均已生成')

    # ---- 键盘监听 + 游戏零件：只生成 C（不运行），核对调用映射 ----
    GAME_SRC = '''@ game>move>fun
GOING:{
win(800, 600, "My Game")
rm.aging.while(end()) {
    if(key("right")) {
        vg.x = x + 5
    }
    show()
    wait(16)
}
}STOP
'''
    game_c = Codegen().generate(parse(GAME_SRC))
    for frag in ('rt_game_win(', 'rt_game_end()', 'rt_game_key("right")',
                 'rt_game_show()', 'rt_game_frame('):
        assert frag in game_c, f'游戏零件自测失败：C 输出缺少 {frag!r}'
    print('游戏零件自测通过：rt_game_win/rt_game_end/rt_game_key/rt_game_show/rt_game_frame 均已生成')
