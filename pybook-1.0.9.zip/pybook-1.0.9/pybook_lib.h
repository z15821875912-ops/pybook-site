/* PYbook 标准库：te（文本）/ mt（数学）/ rd（随机）。
 *
 * 只依赖 pybook_rt 的 Value 盒子体系与 C99 标准库（math.h/stdlib.h/string.h/time.h），
 * 不引入新依赖。前端把 te.split(...) 翻译成 rt_lib_te_split(...) 等 C 调用。
 *
 * 约定：
 *  - 字符串参数一律要求 T_STR，类型不对按运行时错误退出（格式与 pybook_rt 一致）；
 *  - te 的"字符"按 UTF-8 首字节计数（(byte & 0xC0) != 0x80），切/长度均按字符；
 *  - rd 系列首次调用时 srand(time(NULL))，之后不重置；
 *  - 列表参数只要求 T_LIST，元素逐个经 rt_index/rt_setindex 访问（不碰内部结构）。
 *
 * 自测：gcc -O2 -DLIB_SELF_TEST pybook_lib.c pybook_rt.c -o lib_test.exe -I.
 */

#ifndef PYBOOK_LIB_H
#define PYBOOK_LIB_H

#include "pybook_rt.h"

/* ---------- te 文本模块 ---------- */

Value rt_lib_te_split(Value text, Value sep);     /* split(文本, 分隔符) → 列表 */
Value rt_lib_te_replace(Value text, Value old, Value nw); /* 替换所有旧→新 */
Value rt_lib_te_trim(Value text);                 /* 去首尾空白 */
Value rt_lib_te_upper(Value text);                /* 转大写（ASCII） */
Value rt_lib_te_lower(Value text);                /* 转小写（ASCII） */
Value rt_lib_te_has(Value text, Value sub);       /* 包含子串？→ 真/假 */
Value rt_lib_te_len(Value text);                  /* 字符个数（UTF-8 按字符） */
Value rt_lib_te_cut(Value text, Value start, Value stop); /* [起,止) 子串 */
Value rt_lib_te_join(Value list, Value sep);      /* 元素转文本后拼接 */
Value rt_lib_te_chr(Value n);                    /* 码点 → 一个字符（UTF-8）*/

/* ---------- mt 数学模块 ---------- */

Value rt_lib_mt_sqrt(Value n);                    /* 平方根（浮点） */
Value rt_lib_mt_pow(Value base, Value exp);       /* 乘方（浮点） */
Value rt_lib_mt_abs(Value n);                     /* 绝对值（int 保 int） */
Value rt_lib_mt_ceil(Value n);                    /* 向上取整（整数） */
Value rt_lib_mt_floor(Value n);                   /* 向下取整（整数） */
Value rt_lib_mt_mod(Value a, Value b);            /* 取余（Python 语义） */
Value rt_lib_mt_max(Value list);                  /* 列表最大值 */
Value rt_lib_mt_min(Value list);                  /* 列表最小值 */
Value rt_lib_mt_prod(Value list);                 /* 连乘 */
Value rt_lib_mt_sum(Value list);                  /* 求和（空列表=0） */

Value rt_lib_mt_sin(Value angle);                 /* sin（浮点） */
Value rt_lib_mt_cos(Value angle);                 /* cos（浮点） */
Value rt_lib_mt_tan(Value angle);                 /* tan（浮点） */
Value rt_lib_mt_pi(void);                         /* 圆周率常量 */
Value rt_lib_mt_lerp(Value a, Value b, Value t);  /* 线性插值 a+(b-a)*t */
Value rt_lib_mt_dist(Value x1, Value y1, Value x2, Value y2); /* 两点距离 */
Value rt_lib_mt_clamp(Value v, Value lo, Value hi); /* 夹取 [lo,hi]（全整数字面量保 int） */

/* ---------- rd 随机模块 ---------- */

Value rt_lib_rd_int(Value lo, Value hi);          /* [起,止] 随机整数（含两端） */
Value rt_lib_rd_float(void);                      /* [0,1) 随机浮点 */
Value rt_lib_rd_pick(Value list);                 /* 随机取一个元素 */
Value rt_lib_rd_shuffle(Value list);              /* 原地打乱（返回空盒） */
Value rt_lib_rd_seed(Value s);                     /* 播种（rd.* 与 mp.rand_* 同源） */

/* ---------- re 正则模块（零依赖自研引擎，见 pybook_re.c / pybook_re_engine.h） ---------- */

Value rt_lib_re_match(Value pat, Value text);       /* 文本中任意位置是否匹配 → 真/假 */
Value rt_lib_re_find(Value pat, Value text);        /* 所有不重叠匹配串 → 列表 */
Value rt_lib_re_sub(Value pat, Value rep, Value text); /* 全部匹配替换为 rep → 文本 */
Value rt_lib_re_valid(Value pat);                   /* 模式能否编译 → 真/假 */
Value rt_lib_re_groups(Value pat, Value text);      /* 首个匹配的各捕获组 → 列表 */

Value rt_lib_mt_atan2(Value y, Value x);

/* ---- exp/log 族（v2.1 补：此前全库没有 exp 也没有 log）---- */
Value rt_lib_mt_exp(Value a);                     /* mt.exp(x)        e^x */
Value rt_lib_mt_expm1(Value a);                   /* mt.expm1(x)      e^x - 1（x 很小时用） */
Value rt_lib_mt_log(Value a);                     /* mt.log(x)        自然对数，x>0 */
Value rt_lib_mt_log2(Value a);                    /* mt.log2(x) */
Value rt_lib_mt_log10(Value a);                   /* mt.log10(x) */
Value rt_lib_mt_log1p(Value a);                   /* mt.log1p(x)      log(1+x)，x 很小时用 */

/* ---- 反三角（atan2 早已有，补齐 asin/acos/atan）---- */
Value rt_lib_mt_asin(Value a);                    /* mt.asin(x)  |x|<=1 */
Value rt_lib_mt_acos(Value a);                    /* mt.acos(x)  |x|<=1 */
Value rt_lib_mt_atan(Value a);                    /* mt.atan(x) */

/* ---- 双曲 ---- */
Value rt_lib_mt_sinh(Value a);
Value rt_lib_mt_cosh(Value a);
Value rt_lib_mt_tanh(Value a);
Value rt_lib_mt_asinh(Value a);
Value rt_lib_mt_acosh(Value a);                   /* x>=1 */
Value rt_lib_mt_atanh(Value a);                   /* |x|<1 */

/* ---- 根 / 取整 / 符号 / 特判 ---- */
Value rt_lib_mt_cbrt(Value a);                    /* 立方根，负数有意义 */
Value rt_lib_mt_hypot(Value a, Value b);          /* √(x²+y²)，大数不溢出 */
Value rt_lib_mt_trunc(Value n);                   /* 向零取整（floor/ceil 已有） */
Value rt_lib_mt_sign(Value n);                    /* -1 / 0 / 1 */
Value rt_lib_mt_fmod(Value a, Value b);           /* 截断取余（C 语义，与 mt.mod 不同） */
Value rt_lib_mt_is_nan(Value n);                  /* mt.is_nan(x) -> 真/假 */
Value rt_lib_mt_is_inf(Value n);
/* ---- 数值微积分与求根（需要函数值回调；lambda 目前只有 C 后端支持）---- */
Value rt_lib_mt_deriv(Value f, Value x, Value h);                       /* mt.deriv(f,x[,h]) */
Value rt_lib_mt_integrate(Value f, Value a, Value b, Value n);          /* mt.integrate(f,a,b[,n]) */
Value rt_lib_mt_root_bisect(Value f, Value a, Value b, Value tol);     /* mt.root_bisect(f,a,b[,tol]) */
Value rt_lib_mt_root_newton(Value f, Value x0, Value tol, Value mx);    /* mt.root_newton(f,x0[,tol[,最多步]]) */
Value rt_lib_mt_root_newton_d(Value f, Value df, Value x0, Value tol, Value mx); /* mt.root_newton_d(f,df,x0[,tol[,最多步]]) */
Value rt_lib_mt_taylor(Value f, Value x, Value n);                      /* mt.taylor(f,x,n) */
/* ---- 特殊函数：gamma 族 / erf 族 / Riemann zeta ---- */
Value rt_lib_mt_erf(Value x);                     /* mt.erf(x) */
Value rt_lib_mt_erfc(Value x);                    /* mt.erfc(x) */
Value rt_lib_mt_gamma(Value x);                   /* mt.gamma(x)，Γ(x) */
Value rt_lib_mt_lgamma(Value x);                  /* mt.lgamma(x)，ln|Γ(x)| */
Value rt_lib_mt_zeta(Value s);                    /* mt.zeta(s)，s>1 */
/* ---- 一维极值：黄金分割（不依赖梯度，用户只有 f 也有 f'）---- */
Value rt_lib_mt_golden_min(Value f, Value a, Value b, Value tol);  /* mt.golden_min(f,a,b[,tol]) */
Value rt_lib_mt_golden_max(Value f, Value a, Value b, Value tol);  /* mt.golden_max(f,a,b[,tol]) */
/* ---- 插值与拟合（采样点必须严格递增，否则显式报错）---- */
Value rt_lib_mp_interp_linear(Value xs, Value ys, Value q);  /* mp.interp_linear(xs,ys,q) */
Value rt_lib_mp_interp_cubic(Value xs, Value ys, Value q);   /* mp.interp_cubic(xs,ys,q)，Catmull-Rom */
Value rt_lib_mp_linfit(Value xs, Value ys);        /* mp.linfit(xs,ys) -> [斜率,截距,r²] */
Value rt_lib_mp_polyfit(Value xs, Value ys, Value deg);  /* mp.polyfit(xs,ys,deg) -> 升幂系数 */
                  /* mt.is_inf(x) -> 真/假 */
          /* atan2(y, x)，弧度 */

Value rt_lib_te_str(Value v);                    /* 任意值 → 字符串（数字转文本） */

/* ---------- tm 时间模块 ---------- */

Value rt_lib_tm_stop(Value dur, Value unit);      /* tm.stop(秒) 或 tm.stop(毫秒, "ms")：暂停 */
Value rt_lib_tm_now(void);                        /* tm.now()：程序启动至今的毫秒数 */

/* ---------- 音 音乐模块（实现在 pybook_music.c） ---------- */

Value rt_mu_sine(Value freq, Value ms);           /* 音.正弦(频率, 毫秒)：正弦波（播完才返回） */
Value rt_mu_tri(Value freq, Value ms);            /* 音.三角(频率, 毫秒)：三角波 */
Value rt_mu_play(Value path);                     /* 音.放("文件.mp3/.wav")：后台播放（MCI） */
Value rt_mu_stop(void);
Value rt_mu_quick(Value f, Value ms, Value wave);   /* 音.快(频率,毫秒,波形0正弦/1三角/2噪声)：非阻塞音效 */                           /* 音.停()：停止后台播放 */

/* ---------- 音 模块·列表方式做音乐（类比 mm.draw_away） ---------- */
Value rt_mu_note(Value name, Value freq, Value wave);   /* 音.音(名, 频率, 波形)：注册/覆盖自定义音符（波形0正弦/1三角/2噪声） */
Value rt_mu_away(Value rows, Value file, Value bpm);   /* 音.奏(表, "名.wav", 速度)：把乐谱列表渲染成 WAV 落盘 */
Value rt_mu_play_list(Value rows, Value bpm);          /* 音.谱(表, 速度)：把乐谱列表即时播放（阻塞） */

/* ---------- 音 模块·音量 / ADSR / 乐器 ---------- */
Value rt_mu_volume_set(Value v);
Value rt_mu_env_set(Value a, Value d, Value s, Value r);
Value rt_mu_env_at(Value t, Value total);
Value rt_mu_instr_set(Value name);
Value rt_mu_instr_list(void);
Value rt_mu_play_instr(Value note, Value ms);

/* ---------- net 网络模块（TCP 行协议，实现在 pybook_net.c） ---------- */

Value rt_net_listen(Value port);              /* net.listen(端口)：TCP 监听 → 句柄(INT) */
Value rt_net_accept(Value handle);            /* net.accept(句)：阻塞等一个连接 → 新句柄 */
Value rt_net_connect(Value addr, Value port); /* net.connect("地址", 端口)：客户端连接 → 句柄 */
Value rt_net_read(Value handle);              /* net.recv(句)：非阻塞读一行；无完整行 ""；断开 "断" */
Value rt_net_read_block(Value handle);        /* net.readline(句)：阻塞读一行 */
Value rt_net_write(Value handle, Value text); /* net.send(句, 文本)：原样发送字节（语言层 net.send 自动补 
） */
Value rt_http_get(Value url);      /* http.get(网址)：取回正文（https/重定向/chunked 自动）→ 文本 */
Value rt_http_code(void);          /* http.code()：最近一次请求的 HTTP 状态码；传输层失败 = -1 */
Value rt_http_post(Value url, Value body, Value ctype);  /* http.post(网址,体,"类型") */
Value rt_http_err(void);           /* http.err()：最近一次传输层失败的原因；没失败过 = "" */
Value rt_http_header(Value name);  /* http.header("名")：响应头值（头名大小写不敏感）；没有 = "" */
Value rt_http_headers(void);       /* http.headers()：本次响应全部头的小写键字典 */
Value rt_http_config(Value opts);  /* http.config({...})：设默认 超时(秒) / Agent / 头；空字典 = 复位 */
Value rt_http_listen(Value port);  /* http.listen(端口)：HTTP 监听 → 监听句柄（net.close 可关） */
Value rt_http_serve(Value listen); /* http.serve(听)：阻塞等一个完整请求 → 会话句柄 */
Value rt_http_req(Value sess);     /* http.req(会话)：请求字典 {"方法","路径","头","体"} */
Value rt_http_resp(Value sess, Value code, Value body, Value ctype);
                                   /* http.resp(会话,状态码,正文,"类型")：应答并关会话 */
Value rt_net_close(Value handle);             /* net.close(句)：关闭 */
Value rt_net_udp(Value port);                 /* net.udp(端口)：建 UDP 套接字+绑定本地端口 → 句柄 */
Value rt_net_sendto(Value h, Value text, Value addr, Value port); /* net.sendto(句,文本,地址,端口)：发一个数据报 */
Value rt_net_recvfrom(Value h);               /* net.recvfrom(句)：非阻塞收 → [] 或 [文本,来源地址,来源端口] */
Value rt_net_recvfrom_block(Value h);         /* net.recvfrom_wait(句)：阻塞收一个数据报 */

/* ---------- crypto 加密模块（实现在 pybook_crypto.c） ---------- */

Value rt_crypto_random(Value n);              /* crypto.随机(字节数)：随机字节的十六进制串 */
Value rt_crypto_digest(Value data, Value alg);/* crypto.摘要(数据, 算法)：十六进制摘要 */
Value rt_crypto_derive(Value pw, Value salt, Value iters, Value len);
                                              /* crypto.派生(口令,盐,轮数,长度)：PBKDF2 密钥 */
Value rt_crypto_sign(Value key, Value data);  /* crypto.签名(密钥hex,数据)：HMAC-SHA256 */
Value rt_crypto_encrypt(Value key, Value nonce, Value plain);
                                              /* crypto.加密(密钥hex,随机数hex,明文)：ChaCha20 */
Value rt_crypto_decrypt(Value key, Value nonce, Value ct);
                                              /* crypto.解密(密钥hex,随机数hex,密文hex) */

/* ---------- te 终端读行（实现在 pybook_file.c） ---------- */

Value rt_te_readline(Value prompt);           /* te.读行(提示)：阻塞读一行（原始字符串） */
Value rt_te_tryline(void);                    /* te.试读行()：非阻塞；没有完整行返回空串 */
int   rt_te_poll(char *out, int cap);         /* 内部：非阻塞取一行（1/0/-1） */
int   rt_te_pending(void);                    /* 内部：终端里还有没有半行输入 */
int   rt_te_partial(char *out, int cap);      /* 内部：取当前半行内容（重画用） */

/* ---------- chat 聊天库（实现在 pybook_net.c，依赖 pybook_crypto.c） ---------- */

Value rt_chat_relay(Value port);              /* chat.中继(端口)：启动中继并阻塞运行 */
Value rt_chat_join(Value addr, Value port, Value room, Value nick, Value pass);
                                              /* chat.加入(地址,端口,房间,昵称,口令) → 句柄 */
Value rt_chat_say(Value handle, Value text);  /* chat.说(句,文本) */
Value rt_chat_listen(Value handle, Value timeout_ms);
                                              /* chat.听(句,超时毫秒)：恒定 3 元素 [类型,昵称,正文] */
                                              /*   类型 ""=没有 / "断"=断开 / "说""进""离" */
Value rt_chat_run(Value handle);              /* chat.跑(句)：终端 REPL 主循环 */

/* ---------- 调色板（内置常量色表） ---------- */

/* 调色板.颜色名 → 新建的 [r,g,b] 列表；配合 color(列表) 重载使用。
 * 列表按内存约定分配后不回收。 */

Value rt_lib_pal_hong(void);                      /* 红 [255,68,68] */
Value rt_lib_pal_cheng(void);                     /* 橙 [255,150,40] */
Value rt_lib_pal_huang(void);                     /* 黄 [255,220,60] */
Value rt_lib_pal_lv(void);                        /* 绿 [60,200,90] */
Value rt_lib_pal_qing(void);                      /* 青 [60,200,200] */
Value rt_lib_pal_lan(void);                       /* 蓝 [70,130,255] */
Value rt_lib_pal_zi(void);                        /* 紫 [170,90,220] */
Value rt_lib_pal_bai(void);                       /* 白 [240,240,240] */
Value rt_lib_pal_hei(void);                       /* 黑 [20,20,24] */
Value rt_lib_pal_hui(void);                       /* 灰 [140,140,150] */
Value rt_lib_pal_fen(void);                       /* 粉 [255,140,180] */
Value rt_lib_pal_jin(void);                       /* 金 [255,200,60] */

/* ---------- np 数组库（numpybk，实现在 pybook_np.c） ---------- */

Value rt_np_zeros(Value n);                       /* np.zeros(n)：n 个 0 */
Value rt_np_range(Value lo, Value hi, Value step);/* np.range(起,止,步) */
Value rt_np_add(Value a, Value b);                /* 元素级加 */
Value rt_np_sub(Value a, Value b);                /* 元素级减 */
Value rt_np_mul(Value a, Value b);                /* 元素级乘 */
Value rt_np_scale(Value a, Value k);              /* 数乘 */
Value rt_np_dot(Value a, Value b);                /* 点积 */
Value rt_np_norm(Value a);                        /* 模长 */
Value rt_np_normalize(Value a);                   /* 归一化 */
Value rt_np_max(Value a);                         /* 最大 */
Value rt_np_min(Value a);                         /* 最小 */
Value rt_np_sum(Value a);                         /* 总和 */
Value rt_np_mean(Value a);                        /* 平均 */
Value rt_np_sin(Value a);                         /* 元素级 sin */
Value rt_np_cos(Value a);                         /* 元素级 cos */
Value rt_np_sqrt(Value a);                        /* 元素级 sqrt */
Value rt_np_exp(Value a);                         /* 元素级 exp */
Value rt_np_log(Value a);                         /* 元素级 log */
Value rt_np_log2(Value a);                        /* 元素级 log2 */
Value rt_np_log10(Value a);                       /* 元素级 log10 */
Value rt_np_expm1(Value a);                       /* 元素级 exp(x)-1（小 x 不丢精度） */
Value rt_np_log1p(Value a);                       /* 元素级 log(1+x)（小 x 不丢精度） */
Value rt_np_tan(Value a);                         /* 元素级 tan */
Value rt_np_atan(Value a);                        /* 元素级 atan */
Value rt_np_cbrt(Value a);                        /* 元素级立方根 */
Value rt_np_erf(Value a);                         /* 元素级 erf */
Value rt_np_erfc(Value a);                        /* 元素级 erfc */
Value rt_np_gamma(Value a);                       /* 元素级 Γ(x) */
Value rt_np_lgamma(Value a);                      /* 元素级 log|Γ(x)| */
Value rt_np_abs(Value a);                         /* 元素级绝对值 */
Value rt_np_floor(Value a);                       /* 元素级向下取整 */
Value rt_np_ceil(Value a);                        /* 元素级向上取整 */
Value rt_np_round(Value a);                       /* 元素级四舍五入（.5 远离零） */
Value rt_np_sign(Value a);                        /* 元素级符号 */
Value rt_np_pow(Value a, Value b);                /* 元素级幂 */

/* ---------- 特殊函数核心层（实现在 pybook_lib.c，纯 double，不碰运行时） ---------- */
/* 这几个是纯数学函数，任何 C 程序都能直接链；np.* 的批量版也走它们。 */
double lib_gamma(double z);                       /* Γ(z) */
double lib_lgamma(double z);                      /* log|Γ(z)| */
double lib_erf(double x);                         /* 误差函数 */
double lib_erfc(double x);                        /* 互补误差函数 */
double lib_zeta(double s);                        /* 黎曼 ζ(s)，s>1 */

/* ---------- tb 神经网络库（torchbk，实现在 pybook_tb.c） ----------
 * 张量 = 列表的列表（2D 浮点矩阵）。前向 + 手写梯度对 + SGD。 */

Value rt_tb_save(Value path, Value tensors);            /* tb.save(文件, 张量列表)：权重落盘 */
Value rt_tb_load(Value path);                      /* tb.load(文件)：按保存顺序取回张量列表 */
Value rt_tb_mat(Value r, Value c);                 /* 零矩阵 */
Value rt_tb_rand(Value r, Value c);                /* [-1,1] 随机矩阵（初始化权重） */
Value rt_tb_mat32(Value r, Value c);               /* 零矩阵，float32 精度 */
Value rt_tb_rand32(Value r, Value c);              /* [-1,1] 随机矩阵，float32 精度 */
int    rt_tb_on_gpu(void);                         /* 当前后端是不是 GPU（1/0） */
Value  rt_tb_is_gpu(void);                        /* 同上，布尔盒版（给 LIB_CALLS 用） */
Value  rt_tb_gpu_name(void);                      /* 卡名；探测不到时给失败原因 */
Value rt_tb_rows(Value m);                         /* 行数 */
Value rt_tb_cols(Value m);                         /* 列数 */
Value rt_tb_dot(Value a, Value b);                 /* 矩阵乘 */
Value rt_tb_tr(Value m);                           /* 转置 */
Value rt_tb_add(Value a, Value b);                 /* 逐元素加 */
Value rt_tb_mul(Value a, Value b);                 /* 逐元素乘 */
Value rt_tb_addrow(Value m, Value row);            /* 行广播加（偏置） */
Value rt_tb_relu(Value m);                         /* ReLU */
Value rt_tb_sigmoid(Value m);                      /* Sigmoid */
Value rt_tb_lin(Value x, Value w, Value b);        /* 线性层 x@w+b */
Value rt_tb_mse(Value y, Value t);                 /* 均方误差 */
Value rt_tb_relu_grad(Value pre);                  /* d ReLU（传激活前的值） */
Value rt_tb_sigmoid_grad(Value y);                 /* d Sigmoid（传激活后的值） */
Value rt_tb_mse_grad(Value y, Value t);            /* d MSE */
Value rt_tb_lin_dx(Value x, Value w, Value g);     /* 线性层对 x 的梯度 */
Value rt_tb_lin_dw(Value x, Value g);              /* 线性层对 w 的梯度 */
Value rt_tb_lin_db(Value g);                       /* 线性层对 b 的梯度 */
Value rt_tb_step(Value m, Value dm, Value lr);     /* SGD 一步：m - lr*dm */
Value rt_tb_softmax(Value m);
Value rt_js_parse(Value text);               /* js.parse：JSON 文本 -> 值 */
Value rt_js_dump(Value v);                   /* js.dump：值 -> JSON 文本 */
Value rt_csv_parse(Value text);              /* csv.parse：表格文本 -> 二维表 */
Value rt_csv_dump(Value table);              /* csv.dump：二维表 -> 表格文本 */
int  rt_mm_lookup(Value tok, int *r, int *g, int *b);
                                    /* mm 调色板查询：1=不透明 0=透明 -1=未知 */
Value rt_mm_color(Value tok, Value r, Value g, Value b);
                                    /* mm.色：注册/覆盖颜色 token */
Value rt_mm_draw_away(Value rows, Value file, Value scale);
unsigned char *rt_mm_raster(Value rows, long long scale, size_t *W, size_t *H);
int  mm_write_png(const char *name, const unsigned char *rgba, size_t W, size_t H);
                                    /* mm/图.* 共用的 PNG 编码器（实现见 pybook_mm.c）：
                                       RGBA 8888 缓冲 -> PNG 落盘，成功返回 1 */
                                    /* mm 光栅化：token 列表 -> RGBA 缓冲（分配不回收） */
Value rt_mm_blt(Value rows, Value x, Value y, Value scale);
                                    /* mm.贴：窗口模式把列表画到 (x,y)，1 格 = N×N 像素 */

/* ---------- mm 模块·编辑算子（纯计算 + 落盘，VM/C 双后端） ---------- */
Value rt_mm_save(Value rows, Value file);
Value rt_mm_load(Value file);
Value rt_mm_xform(Value rows, Value how);
Value rt_mm_outline(Value rows, Value tok);
Value rt_mm_tile(Value rows, Value nx, Value ny);
Value rt_mm_paste(Value a, Value b, Value how);
Value rt_mm_grad(Value rows, Value c0, Value c1, Value steps);
Value rt_mm_invert(Value rows);


/* ---------- 图. 表. 模块：图表 / 表格 / 函数图像（实现见 pybook_plot.c）---------- */
Value rt_plot_at(Value, Value, Value);
Value rt_plot_axis(Value, Value, Value, Value, Value, Value, Value, Value);
Value rt_plot_bar(Value, Value, Value, Value);
Value rt_plot_canvas(Value, Value);
Value rt_plot_canvasbg(Value, Value, Value);
Value rt_plot_circle(Value, Value, Value, Value, Value, Value);
Value rt_plot_clear(Value, Value);
/* sym 接入：导数 / 切线 / 渐近线 / 面积（见 pybook_plot.c） */
Value rt_plot_deriv(Value, Value, Value, Value, Value);
Value rt_plot_tangent(Value, Value, Value, Value, Value);
Value rt_plot_asym(Value, Value, Value, Value);
Value rt_plot_area(Value, Value, Value, Value, Value, Value);
Value rt_plot_eval(Value, Value);
Value rt_plot_fun(Value, Value, Value, Value, Value, Value);
Value rt_plot_fx(Value, Value, Value, Value, Value, Value);
Value rt_plot_hist(Value, Value, Value, Value);
Value rt_plot_legend(Value, Value, Value, Value);
Value rt_plot_line(Value, Value, Value, Value, Value, Value, Value);
Value rt_plot_line2(Value, Value, Value, Value, Value);
Value rt_plot_palette();
Value rt_plot_pie(Value, Value, Value);
Value rt_plot_pixel(Value, Value, Value, Value);
Value rt_plot_rect(Value, Value, Value, Value, Value, Value, Value);
Value rt_plot_save(Value, Value);
Value rt_plot_scatter(Value, Value, Value, Value, Value);
Value rt_plot_size(Value);
Value rt_plot_text(Value, Value, Value, Value, Value, Value);
Value rt_tbl_cellat(Value, Value, Value);
Value rt_tbl_col(Value, Value);
Value rt_tbl_concat(Value, Value);
Value rt_tbl_fill(Value, Value);
Value rt_tbl_hconcat(Value, Value);
Value rt_tbl_render(Value, Value);
Value rt_tbl_row(Value, Value);
Value rt_tbl_size(Value);
Value rt_tbl_slice(Value, Value, Value);
Value rt_tbl_sort(Value, Value, Value);
Value rt_tbl_stats(Value, Value, Value, Value);
Value rt_tbl_transpose(Value);
                                    /* mm.draw_away：列表渲染落成 PNG，返回文件名 */                      /* 每行 softmax */
/* ---------- obj 模块：3D 建模 -> .obj 落盘（mm 的 3D 姊妹篇，VM/C 双后端） ---------- */
Value rt_obj_clear(void);                          /* obj.清：清空网格 */
Value rt_obj_vertex(Value x, Value y, Value z);    /* obj.点：加顶点，返回顶点号（1 起） */
Value rt_obj_face(Value a, Value b, Value c);      /* obj.面：加三角面（顶点号） */
Value rt_obj_quad(Value a, Value b, Value c, Value d);
                                                   /* obj.面4：加四边面 */
Value rt_obj_box(Value x, Value y, Value z, Value w, Value h, Value d);
                                                   /* obj.块：立方体（一角定位） */
Value rt_obj_sphere(Value x, Value y, Value z, Value r, Value seg);
                                                   /* obj.球：UV 球 */
Value rt_obj_cyl(Value x, Value y, Value z, Value r, Value h, Value seg);
                                                   /* obj.柱：圆柱（沿 +Y） */
Value rt_obj_save(Value file);                     /* obj.存：落成 .obj 文本 */
Value rt_obj_vcount(void);                         /* obj.点数：当前顶点数 */
Value rt_obj_fcount(void);                         /* obj.面数：当前面数 */
/* ---------- wire 模块：接线式测试（联动功能三档验证：通/扰/危） ---------- */
Value rt_wire_tap(Value label);                    /* 接线.接：痕迹打点 */
Value rt_wire_trace(void);                         /* 接线.迹：打点顺序列表 */
Value rt_wire_tcount(void);                        /* 接线.迹数：打点数 */
Value rt_wire_case(Value tier, Value name, Value cond);
                                                   /* 接线.例：登记用例结果（通/扰/危） */
Value rt_wire_edge(Value n);                       /* 接线.边界：边界值集 */
Value rt_wire_shuffle(Value list, Value seed);     /* 接线.乱序：确定性乱序（新表） */
Value rt_wire_dirtystr(Value seed);                /* 接线.脏串：脏字符串 */
Value rt_wire_dirtynum(Value seed);                /* 接线.脏数：脏数字 */
Value rt_wire_dirtylist(Value seed);               /* 接线.脏表：脏列表 */
Value rt_wire_boom(Value kind, Value msg);         /* 接线.炸：故障注入（可捕获） */
Value rt_wire_snap(void);                          /* 接线.快照：[单元,字节,迹,错] */
Value rt_wire_diff(Value snap);                    /* 接线.对照：[Δ单元,Δ字节,Δ迹,Δ错] */
Value rt_wire_report(void);                        /* 接线.报：三档报告，返回失败数 */
Value rt_wire_fails(void);                         /* 接线.败数：失败总数 */
Value rt_wire_clear(void);                         /* 接线.清：清痕迹与计数 */
Value rt_tb_crossent(Value y, Value t);            /* 交叉熵（target=类别下标列） */
Value rt_tb_crossent_grad(Value y, Value t);       /* dL/dy */
Value rt_tb_argmax(Value m);                       /* 每行最大值下标 */
Value rt_tb_sgd(Value w, Value dw, Value lr);      /* SGD 就地更新 */
Value rt_tb_adam(Value w, Value dw, Value m, Value v, Value lr, Value b1, Value b2, Value step);
Value rt_tb_shuffle(Value list, Value seed);       /* 洗牌（新表） */
Value rt_tb_onehot(Value n, Value k);              /* 单热行向量 */
Value rt_tb_batch(Value list, Value i, Value sz);  /* 第 i 批切片 */
/* ---------- tb 训练算子：卷积 / 池化 / 归一化（实现在 pybook_tb.c） ----------
 * 形状约定：特征图 (C*H, W)、卷积核 (O, I*核高*核宽)、输出 (O*OH, OW)，
 * 全部二维张量；输入通道 I 由核的列数除以 核高*核宽 反推。详见 pybook_tb.c 里的
 * 「训练算子」段注释（那里写了为什么用二维而不是四维张量）。
 * 多返回值的算子返回列表，约定同样写在 pybook_tb.c 里。 */
Value rt_tb_conv2d(Value x, Value k, Value kh, Value kw, Value st, Value pad);
Value rt_tb_conv2d_dx(Value x, Value k, Value gy, Value kh, Value kw, Value st, Value pad);
Value rt_tb_conv2d_dk(Value x, Value k, Value gy, Value kh, Value kw, Value st, Value pad);
Value rt_tb_conv2d_db(Value gy, Value outch);
Value rt_tb_maxpool(Value x, Value ph, Value pw, Value st);
Value rt_tb_maxpool_dx(Value x, Value gy, Value ph, Value pw, Value st);
Value rt_tb_avgpool(Value x, Value ph, Value pw, Value st);
Value rt_tb_avgpool_dx(Value x, Value gy, Value ph, Value pw, Value st);
Value rt_tb_dropout(Value x, Value p, Value train, Value mask);
Value rt_tb_dropout_dx(Value gy, Value p, Value train, Value mask);
Value rt_tb_batchnorm(Value x, Value gamma, Value beta, Value mean, Value var,
                      Value train, Value mom, Value eps);
Value rt_tb_batchnorm_dx(Value x, Value gy, Value mean, Value var, Value gamma);
Value rt_tb_layernorm(Value x, Value gamma, Value beta, Value eps);
Value rt_tb_layernorm_dx(Value x, Value gy, Value mean, Value var, Value gamma);

/* ---------- mp 数学扩展（mathplus，实现在 mathplus.c） ---------- */
#include "mathplus.h"


/* ---------- 线性代数（实现在 pybook_la.c） ---------- */
/* 必须排在 mathplus.h 之后、且必须在 C 后端的生成代码编译时可见：
   pybk_code.py 生成 out_*.c，符号靠 pybook_lib.h 这条链带进来，
   只写进 _vm_lib_calls.inc 只服务 VM 后端，C 后端会报 implicit declaration。 */
#include "pybook_la.h"

/* ---------- bs 位运算扩展（实现在 pybook_bits.c） ---------- */
/* 放在这里 = 让 pybook_bits.h 先看到 pybook_rt.h，绑定层随之生效 */
#include "pybook_bits.h"

/* ---------- mec Modernized_code（mec.kind 在 pybook_lib.c） ---------- */
Value rt_mec_kind(Value v);

/* ---------- m3 MyMove3D 体素建模（实现在 pybook_m3d.c） ---------- */
#include "pybook_m3d.h"
#include "pybook_smoke.h"
#include "pybook_sym.h"

#endif /* PYBOOK_LIB_H */
