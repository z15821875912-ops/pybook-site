"""chat 库的端到端互验（真起进程、真走 TCP）：C 端 ↔ 独立 Python 实现互相对话。

验的东西（每一条都必须成立）：
  1) 中继进程能起来并接受连接；
  2) Python 独立实现加入房间后，能收到中继重播的「已在线成员」的加入行，
     并把它解密出来 —— 证明两端密钥派生一致、协议可互通；
  3) C 客户端发的话，Python 能解密出来 —— 证明 C 端加密是对的；
  4) Python 发的话，C 客户端能收到并显示 —— 证明 C 端解密是对的；
  5) 篡改密文 → C 端拒收（校验码不过）；
  6) 篡改校验码 → C 端拒收；
  7) 重放旧消息 → C 端拒收（序号不递增）；
  8) 明文**从不出现在线路上**（中继看见的全是十六进制密文）。

跑法：python 聊天互通验证.py
（需要本仓库根目录就是工作目录；它会临时起中继进程和客户端进程）
"""
import os
import socket
import subprocess
import sys
import time

import importlib.util

ROOT = os.path.dirname(os.path.abspath(__file__))
_spec = importlib.util.spec_from_file_location('chatproto',
                                                os.path.join(ROOT, '聊天协议参考.py'))
proto = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(proto)

PORT = 18873
ROOM = '验证房间'
PASS = '口令'
NICK_C = '甲'          # C 客户端的昵称
NICK_P = '乙'          # Python 客户端的昵称

fails = []
checks = 0


def ck(cond, what, detail=''):
    global checks
    checks += 1
    if not cond:
        fails.append(what)
    print('%s %s%s' % ('ok  ' if cond else 'FAIL', what, ('  -- ' + detail) if detail else ''))


def gen_script(path, text):
    with open(path, 'w', encoding='utf-8', newline='\n') as f:
        f.write(text)


def wait_port(port, timeout=25.0):
    t0 = time.time()
    while time.time() - t0 < timeout:
        try:
            s = socket.create_connection(('127.0.0.1', port), timeout=1.0)
            s.close()
            return True
        except OSError:
            time.sleep(0.2)
    return False


def kill_tree(pr):
    """杀掉整棵进程树。

    pybk_main.py 会再拉起一个编译好的 C 程序（app_*.exe）当子进程；
    只 kill 掉 python 父进程，那个 C 程序会活下来继续占着端口，
    下一个探针就连到了「上一次那个旧中继」——踩过一次，记住。
    """
    if pr is None:
        return
    try:
        subprocess.run(['taskkill', '/T', '/F', '/PID', str(pr.pid)],
                       capture_output=True)
    except Exception:
        pass
    try:
        pr.wait(timeout=8)
    except Exception:
        pass


class LineReader:
    def __init__(self, sock):
        self.sock = sock
        self.buf = b''
        self.raw = b''          # 收到的**全部**字节（用来验「线路里没有明文」）

    def readline(self, timeout=5.0):
        self.sock.settimeout(timeout)
        while b'\n' not in self.buf:
            try:
                chunk = self.sock.recv(4096)
            except socket.timeout:
                return None
            if not chunk:
                return None
            self.buf += chunk
            self.raw += chunk
        line, self.buf = self.buf.split(b'\n', 1)
        return line.decode('utf-8', 'replace')


def main():
    if not proto.selfcheck():
        print('Python 独立实现自校准没过，不继续')
        return 1
    print('Python 独立实现自校准通过')

    # ---- 生成被测脚本 ----
    tmpdir = os.path.join(ROOT, 'build_tmp', 'probe')
    os.makedirs(tmpdir, exist_ok=True)
    relay_py = os.path.join(tmpdir, '_聊天互验_中继.pybk')
    client_py = os.path.join(tmpdir, '_聊天互验_甲.pybk')
    gen_script(relay_py,
               '@ 测试>聊天>中继\nGOING:{\nvg.端口 = %d\nchat.中继(端口)\n}STOP\n' % PORT)
    gen_script(client_py, '''@ 测试>聊天>甲
GOING:{
vg.句 = chat.加入("127.0.0.1", %d, "%s", "%s", "%s")
ns.show("甲已加入")
vg.等到 = 0
vg.发过 = 0
vg.次数 = 0
rm.aging.while(次数 >= 60) {
    vg.收 = chat.听(句, 200)
    if(收[0] == "说") {
        ns.show("甲收到|", 收[1], "|", 收[2])
    }
    if(收[0] == "进") {
        ns.show("甲看到|", 收[1], "|进")
        if(发过 == 0) {
            chat.说(句, "甲发出的消息")
            vg.发过 = 1
        }
    }
    if(收[0] == "断") {
        ns.show("甲看到断")
    }
    vg.次数 = 次数 + 1
}
ns.show("甲结束")
}STOP
''' % (PORT, ROOM, NICK_C, PASS))

    env = dict(os.environ)
    env['PYTHONUTF8'] = '1'
    env['PYTHONIOENCODING'] = 'utf-8'

    relay = subprocess.Popen([sys.executable, 'pybk_main.py', relay_py],
                             stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                             env=env, cwd=ROOT)
    client = None
    try:
        ck(wait_port(PORT), '中继进程起来了，端口 %d 能连' % PORT)

        # ---- C 客户端加入 ----
        client = subprocess.Popen([sys.executable, 'pybk_main.py', client_py],
                                  stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                  env=env, cwd=ROOT)
        time.sleep(3.0)

        # ---- Python 客户端加入 ----
        key = proto.derive_key(PASS, ROOM)
        tag = proto.room_tag(key, ROOM)
        sk = socket.create_connection(('127.0.0.1', PORT), timeout=5.0)
        sk.settimeout(None)
        rd = LineReader(sk)
        sent_raw = []          # 我们发出的**全部**字节（用来验「线路里没有明文」）

        def send_line(text):
            b = (text + '\n').encode('utf-8')
            sent_raw.append(b)
            sk.sendall(b)

        conn_id = b'\x11' * 8

        join = proto.make_line(key, tag, 'J', conn_id, 1, NICK_P, '')
        send_line(join)
        print('info Python 客户端已加入（加入行 %d 字节）' % len(join))

        # 2) 中继会把「已在线成员」的加入行重播给新人 → 应收到甲的加入行
        got_j = None
        t0 = time.time()
        while time.time() - t0 < 6.0:
            line = rd.readline(timeout=1.0)
            if line is None:
                continue
            p = proto.parse_line(line)
            if p['type'] != 'J':
                continue
            if not proto.verify_mac(key, p['tag'], p['type'], p['nonce'], p['ct'], p['mac']):
                continue
            nick, body = proto.open_plain(key, p['nonce'], p['ct'])
            if nick == NICK_C:
                got_j = (nick, body)
                break
        ck(got_j is not None and got_j[0] == NICK_C,
           '中继把已在线成员（%s）的加入行重播给新人' % NICK_C,
           '' if got_j else '没收到')
        ck(got_j is not None and got_j[1] == '', '加入行的正文为空（只有昵称）')

        # 4) Python 发一条合法消息 → C 端应当收到
        legit = proto.make_line(key, tag, 'S', conn_id, 2, NICK_P, '乙的合法消息')
        send_line(legit)

        def line_with(typ, tag_hex, nonce_hex, ct_hex, mac_hex):
            return '%s %s %s %s %s' % (typ, tag_hex, nonce_hex, ct_hex, mac_hex)

        # 5) 篡改密文 → 拒收。
        #    ⚠ 这里的**计数器必须用新的（3）**：如果沿用合法消息的计数器，
        #    防重放会先把它挡掉，这条断言就成了「被防重放挡住」的假通过，
        #    根本测不到「校验码」这条机制（反向验证实测踩过：把校验码整个
        #    去掉，这条断言照样全绿）。计数器换了新的，就只剩校验码能挡它。
        p3 = proto.make_line(key, tag, 'S', conn_id, 3, NICK_P, '乙的合法消息').split(' ')
        ct = bytearray(bytes.fromhex(p3[3]))
        ct[0] ^= 0x01
        send_line(line_with(p3[0], p3[1], p3[2], ct.hex(), p3[4]))

        # 6) 篡改校验码 → 拒收（计数器同样用新的 4：只剩校验码能挡它）
        p4 = proto.make_line(key, tag, 'S', conn_id, 4, NICK_P, '乙的合法消息').split(' ')
        mac = bytearray(bytes.fromhex(p4[4]))
        mac[0] ^= 0x01
        send_line(line_with(p4[0], p4[1], p4[2], p4[3], mac.hex()))

        # 7) 重放刚才那条合法消息 → 拒收
        #    （这条的校验码是**对的**，所以只有防重放能挡它 —— 正好和上面两条互不遮蔽）
        send_line(legit)

        # 3) 收 C 客户端发来的消息并解密
        got_say = None
        t0 = time.time()
        while time.time() - t0 < 10.0:
            line = rd.readline(timeout=1.0)
            if line is None:
                continue
            p = proto.parse_line(line)
            if p['type'] != 'S':
                continue
            if not proto.verify_mac(key, p['tag'], p['type'], p['nonce'], p['ct'], p['mac']):
                continue
            nick, body = proto.open_plain(key, p['nonce'], p['ct'])
            got_say = (nick, body)
            break
        ck(got_say is not None and got_say[0] == NICK_C,
           'C 客户端（%s）发的消息被 Python 解出来' % NICK_C,
           '' if got_say else '没收到')
        ck(got_say is not None and got_say[1] == '甲发出的消息',
           '解出来的正文一字不差', '' if got_say else '')

        # 8) 线路上的字节里不能出现明文（收发两个方向都要查）
        raw = rd.raw + b''.join(sent_raw)
        ck('乙的合法消息'.encode('utf-8') not in raw,
           '线路字节里没有明文「乙的合法消息」（中继只见密文）')
        ck('甲发出的消息'.encode('utf-8') not in raw,
           '线路字节里没有明文「甲发出的消息」')
        ck('验证房间'.encode('utf-8') not in raw,
           '线路字节里没有明文房间名（中继只见不透明的标签）')

        sk.close()
        # ---- 等 C 客户端跑完 ----
        out = client.stdout.read().decode('utf-8', 'replace')
        client.wait(timeout=40)
        client = None
        print('---- C 客户端输出 ----')
        print(out.strip())
        print('----------------------')

        # ns.show 多个参数是用空格连起来的，所以期望串里也有空格
        ck('甲收到| 乙 | 乙的合法消息' in out, 'C 端收到了 Python 的合法消息')
        # 篡改密文 / 篡改校验码 / 重放 这三条都不该被显示出来 →
        # 所以「甲收到|」只能出现一次（这是比数正文更严的检查）
        cnt_any = out.count('甲收到|')
        ck(cnt_any == 1, 'C 端只显示了 1 条消息（篡改密文/篡改校验/重放都被拒收）',
           '出现 %d 次' % cnt_any)
        ck(out.count('甲看到| 乙 |进') == 1, 'C 端只看到 1 次「乙进房」')
        ck('甲结束' in out, 'C 客户端正常跑完')

    finally:
        for pr in (client, relay):
            kill_tree(pr)

    print('\n结果: %d/%d 通过' % (checks - len(fails), checks))
    if fails:
        print('失败项: %s' % fails)
        return 1
    return 0


if __name__ == '__main__':
    sys.exit(main())
