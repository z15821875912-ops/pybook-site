# _gpuroutefit2.py —— 验证「开机自标定」用少数几个尺寸能不能复现全量拟合的路由命中率
#
# 背景：生产端要在探测时现测 2~3 个尺寸，解出每个 kernel 的 (c, s)，
# 这样换卡常量就是这张卡自己的。如果只用少数尺寸标定还能保住 20/20 的
# 命中率，那就值得在生产里做自标定；否则只能退回静态常量。
import math, io

SM = 10
KERNELS = {"4x4": (64, 3), "sh": (64, 4), "8x8": (128, 2)}

rows = []
with open("_gpucal_out.csv", "rb") as fb:
    head = fb.read(4)
enc = "utf-16" if head[:2] in (b"\xff\xfe", b"\xfe\xff") else "utf-8"
with io.open("_gpucal_out.csv", "r", encoding=enc, errors="replace") as f:
    for line in f:
        l = line.strip()
        if not l or l.startswith("#") or l.startswith("kernel"):
            continue
        p = l.split(",")
        if len(p) < 11:
            continue
        rows.append(dict(kern=p[0], M=int(p[1]), N=int(p[2]), K=int(p[3]),
                         ms=float(p[7]), pct=float(p[9])))


def waves(kern, M, N):
    T, bpsm = KERNELS[kern]
    blocks = ((M + T - 1) // T) * ((N + T - 1) // T)
    return max(1, math.ceil(blocks / (SM * bpsm)))


def fit(kern, subset):
    """相对误差加权最小二乘：t = waves*(K*c + s)"""
    a00 = a01 = a11 = b0 = b1 = 0.0
    for r in rows:
        if r["kern"] != kern:
            continue
        if subset and not (r["M"] in subset and r["N"] == r["M"] and r["K"] == r["M"]):
            continue
        y = r["ms"]
        w = 1.0 / (y * y)
        x0 = waves(kern, r["M"], r["N"]) * r["K"]
        x1 = waves(kern, r["M"], r["N"])
        a00 += w * x0 * x0; a01 += w * x0 * x1; a11 += w * x1 * x1
        b0 += w * x0 * y;          b1 += w * x1 * y
    det = a00 * a11 - a01 * a01
    if det == 0:
        return None
    return ((b0 * a11 - b1 * a01) / det, (a00 * b1 - a01 * b0) / det)


shapes, seen = [], set()
for r in rows:
    key = (r["M"], r["N"], r["K"])
    if key not in seen:
        seen.add(key)
        shapes.append(key)


def evaluate(fitted):
    bad, worst, detail = 0, 0.0, []
    for (M, N, K) in shapes:
        picks = {}
        for k in KERNELS:
            c, s = fitted[k]
            picks[k] = waves(k, M, N) * (K * c + s)
        pick = min(picks, key=lambda k: picks[k])
        obs = {}
        for row in rows:
            if (row["M"], row["N"], row["K"]) == (M, N, K):
                obs[row["kern"]] = row["ms"]
        real = min(obs, key=lambda k: obs[k])
        loss = (obs[pick] / obs[real] - 1.0) * 100
        worst = max(worst, loss)
        if pick != real and loss > 3.0:
            bad += 1
        detail.append((M, N, K, pick, real, loss))
    return bad, worst, detail


SUBSETS = {
    "全量(13 个方形尺寸)": None,
    "自标定 A: 256/512/1024": (256, 512, 1024),
    "自标定 B: 512/1024": (512, 1024),
    "自标定 C: 320/512/768/1024": (320, 512, 768, 1024),
    "自标定 D: 256/384/512/768/1024": (256, 384, 512, 768, 1024),
    "自标定 E: 256/512": (256, 512),
    "自标定 F: 256/512/768": (256, 512, 768),
    "自标定 G: 128/256/512": (128, 256, 512),
    "自标定 H: 256/384/512": (256, 384, 512),
}

print("=" * 88)
print("不同标定子集 -> 路由命中率")
results = {}
for name, sub in SUBSETS.items():
    fitted = {k: fit(k, sub) for k in KERNELS}
    bad, worst, detail = evaluate(fitted)
    results[name] = (fitted, detail)
    print("  %-26s 选错(>3%%) %2d/%d   最大损失 %+6.1f%%" % (name, bad, len(shapes), worst))
    for k in KERNELS:
        c, s = fitted[k]
        print("        %-4s c=%.6f ms/K  s=%.5f ms" % (k, c, s))

print()
print("=" * 88)
print("自标定 A 与全量拟合的逐形状对比")
fa = results["自标定 A: 256/512/1024"][1]
fb = results["全量(13 个方形尺寸)"][1]
for x, y in zip(fa, fb):
    mark = "" if x[3] == y[3] else "  <<< 与全量不一致"
    print("  %5dx%-5dx%-5d  自标定A=%-4s(%+6.1f%%)   全量=%-4s(%+6.1f%%)%s"
          % (x[0], x[1], x[2], x[3], x[5], y[3], y[5], mark))
