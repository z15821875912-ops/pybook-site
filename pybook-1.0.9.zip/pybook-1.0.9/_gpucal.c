/* _gpucal.c —— sgemm 三个 kernel 的「填充率 -> 效率」标定 harness
 *
 * 存在的理由：生产路由（pybook_gpu.c）原来把阈值写死成 1060 的 N 值
 * （224 / 1280），换一张卡（SM 数不同）就全错。本 harness 的产出是
 * 「每个 kernel 在给定 blocks/SMs（设备相对量）下的实测效率」，
 * 用来标定新路由模型的常数。
 *
 * 关键口径：
 *   - bps = blocks / SM 数   —— 设备相对量，跨卡可比
 *   - 效率 = 实测 TFLOPS / 本卡 FP32 峰值   —— 峰值由 _gppeak 实测得出
 *   - 每轮轮转 kernel 顺序、多轮取中位数（单轮会被 GPU 动态升频骗）
 *
 * 同时打印一堆 device attribute，专门用来核对「我要用的属性常量对不对」：
 *   SM 数必须是 10（1060），每 SM 最大线程 2048，warp 32，每 SM 寄存器 65536。
 *   对不上就是常量记错了，不能靠猜。
 *
 * 编译：
 *   C:\Users\zhuli\mingw64\bin\x86_64-w64-mingw32-gcc.exe _gpucal.c -o _gpucal.exe -O2 -lm
 * 用法：
 *   _gpucal.exe [轮数] [峰值TFLOPS] [MxNxK ...]
 */
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <math.h>

typedef int      CUresult;
typedef int      CUdevice;
typedef void    *CUcontext;
typedef void    *CUmodule;
typedef void    *CUfunction;
typedef void    *CUstream;
typedef unsigned long long CUdeviceptr;

/* device attribute（CUDA driver API 的 CUdevice_attribute 枚举值） */
#define ATTR_MAX_THREADS_PER_BLOCK          1
#define ATTR_MAX_SHARED_MEMORY_PER_BLOCK     8
#define ATTR_MAX_SHARED_MEMORY_PER_MP       10
#define ATTR_MAX_REGISTERS_PER_BLOCK        12
#define ATTR_MAX_REGISTERS_PER_MP           13
#define ATTR_CLOCK_FREQUENCY                13
#define ATTR_MULTIPROCESSOR_COUNT           16
#define ATTR_WARP_SIZE                      32
#define ATTR_MAX_THREADS_PER_MP             39
#define ATTR_MAX_BLOCKS_PER_MP              36
#define ATTR_CC_MAJOR                       75
#define ATTR_CC_MINOR                       76

#define CU_EVENT_DEFAULT 0

static HMODULE g_dll;
static CUresult (*p_cuInit)(unsigned);
static CUresult (*p_cuDriverGetVersion)(int *);
static CUresult (*p_cuDeviceGetCount)(int *);
static CUresult (*p_cuDeviceGet)(CUdevice *, int);
static CUresult (*p_cuDeviceGetName)(char *, int, CUdevice);
static CUresult (*p_cuDeviceGetAttribute)(int *, int, CUdevice);
static CUresult (*p_cuDevicePrimaryCtxRetain)(CUcontext *, CUdevice);
static CUresult (*p_cuCtxSetCurrent)(CUcontext);
static CUresult (*p_cuCtxSynchronize)(void);
static CUresult (*p_cuModuleLoadData)(CUmodule *, const void *);
static CUresult (*p_cuModuleGetFunction)(CUfunction *, CUmodule *, const char *);
static CUresult (*p_cuMemAlloc_v2)(CUdeviceptr *, size_t);
static CUresult (*p_cuMemFree_v2)(CUdeviceptr);
static CUresult (*p_cuMemcpyHtoD_v2)(CUdeviceptr, const void *, size_t);
static CUresult (*p_cuMemcpyDtoH_v2)(void *, CUdeviceptr, size_t);
static CUresult (*p_cuLaunchKernel)(CUfunction, unsigned, unsigned, unsigned,
                                    unsigned, unsigned, unsigned,
                                    unsigned, CUstream, void **, void **);
static CUresult (*p_cuGetErrorString)(CUresult, const char **);
static CUresult (*p_cuEventCreate)(void **, unsigned);
static CUresult (*p_cuEventRecord)(void *, unsigned);
static CUresult (*p_cuEventSynchronize)(void *);
static CUresult (*p_cuEventElapsedTime)(float *, void *, void *);
static CUresult (*p_cuFuncGetAttribute)(int *, int, CUfunction);
static CUresult (*p_cuOccupancyMaxActiveBlocksPerMultiprocessor)(int *, CUfunction, int, size_t);

static CUcontext g_ctx;
static char      g_err[256];
static int       g_sms = 0;
static double    g_peak = 4.73;          /* 本卡 FP32 峰值（TFLOPS），可由 argv 覆盖 */

static const char *cu_err(CUresult r)
{
    const char *s = NULL;
    if (p_cuGetErrorString && p_cuGetErrorString(r, &s) == 0 && s) return s;
    return "未知 CUDA 错误";
}

static int fail(const char *fmt, ...)
{
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(g_err, sizeof g_err, fmt, ap);
    va_end(ap);
    fprintf(stderr, "[失败] %s\n", g_err);
    return 0;
}

typedef struct {
    const char *tag;
    const char *entry;
    const char *file;
    unsigned    step;
    CUmodule    mod;
    CUfunction  fn;
    int         ok;
} Kern;

/* 只测生产在用的三个（8x8 用带载入预取的生产版） */
static Kern g_k[3] = {
    { "4x4",  "sgemm",        "_ptx_PTX_4X4.ptx",    64, NULL, NULL, 0 },
    { "sh",  "sgemm_shared", "_ptx_PTX_SHARED.ptx", 64, NULL, NULL, 0 },
    { "8x8", "sgemm_8x8",    "_ptx_PTX_8X8.ptx",   128, NULL, NULL, 0 },
};
#define NK 3

static CUdeviceptr g_dA, g_dB, g_dC;
static size_t g_cap;
static void   *g_ev0, *g_ev1;
static float *g_fA, *g_fB, *g_fC;
static size_t g_fcap;
static char   g_ptx[262144];

static int load_ptx(const char *path)
{
    FILE *f = fopen(path, "rb");
    size_t n;
    if (!f) return fail("打不开 PTX 文件 %s", path);
    n = fread(g_ptx, 1, sizeof(g_ptx) - 1, f);
    fclose(f);
    g_ptx[n] = '\0';
    if (n < 100) return fail("PTX 文件 %s 太短", path);
    return 1;
}

static int ensure(size_t bytes)
{
    if (bytes <= g_cap) return 1;
    if (g_cap) { p_cuMemFree_v2(g_dA); p_cuMemFree_v2(g_dB); p_cuMemFree_v2(g_dC); g_cap = 0; }
    if (p_cuMemAlloc_v2(&g_dA, bytes) != 0) return fail("显存分配失败");
    if (p_cuMemAlloc_v2(&g_dB, bytes) != 0) return fail("显存分配失败");
    if (p_cuMemAlloc_v2(&g_dC, bytes) != 0) return fail("显存分配失败");
    g_cap = bytes;
    return 1;
}

static int ensure_host(size_t need)
{
    if (need <= g_fcap) return 1;
    free(g_fA); free(g_fB); free(g_fC);
    g_fA = (float *)malloc(need * sizeof(float));
    g_fB = (float *)malloc(need * sizeof(float));
    g_fC = (float *)malloc(need * sizeof(float));
    if (!g_fA || !g_fB || !g_fC) return 0;
    g_fcap = need;
    return 1;
}

static void grid_of(const Kern *k, int M, int N, unsigned *gx, unsigned *gy)
{
    *gx = (unsigned)((N + (int)k->step - 1) / (int)k->step);
    *gy = (unsigned)((M + (int)k->step - 1) / (int)k->step);
}

static unsigned g_seed = 12345u;
static double frand(void)
{
    g_seed = g_seed * 1103515245u + 12345u;
    return (double)((g_seed >> 9) & 0xFFFF) / 65536.0 - 0.5;
}

/* 计时：inner 次连发摊掉启动开销，多轮取中位数 */
static int time_one(int ki, int M, int N, int K, int inner, double *out_ms)
{
    unsigned gx, gy;
    float el = 0;
    int i, m = M, n = N, k = K;
    CUresult cr;
    void *params[] = { &g_dA, &g_dB, &g_dC, &m, &n, &k };

    grid_of(&g_k[ki], M, N, &gx, &gy);
    cr = p_cuLaunchKernel(g_k[ki].fn, gx, gy, 1, 16, 16, 1, 0, NULL, params, NULL);
    if (cr != 0) return fail("launch 失败（预热）：%s", cu_err(cr));
    if (p_cuCtxSynchronize() != 0) return fail("预热 kernel 出错：%s", cu_err(cr));

    if (p_cuEventRecord(g_ev0, 0) != 0) return fail("event record 失败");
    for (i = 0; i < inner; i++) {
        cr = p_cuLaunchKernel(g_k[ki].fn, gx, gy, 1, 16, 16, 1, 0, NULL, params, NULL);
        if (cr != 0) return fail("launch 失败：%s", cu_err(cr));
    }
    if (p_cuEventRecord(g_ev1, 0) != 0 ||
        p_cuEventSynchronize(g_ev1) != 0 ||
        p_cuEventElapsedTime(&el, g_ev0, g_ev1) != 0 || el <= 0)
        return fail("event 计时失败");
    *out_ms = (double)el / (double)inner;
    return 1;
}

/* 抽样后向误差 */
static double check(int M, int N, int K)
{
    size_t kc = (size_t)M * (size_t)N, i, step;
    int r, q, p;
    double e0 = 0.0;

    if (p_cuMemcpyDtoH_v2(g_fC, g_dC, kc * sizeof(float)) != 0) return -1;
    step = kc > 20000 ? kc / 20000 : 1;
    for (i = 0; i < kc; i += step) {
        double acc = 0.0, mag = 0.0, d, rel;
        r = (int)(i / (size_t)N);
        q = (int)(i % (size_t)N);
        for (p = 0; p < K; p++) {
            double a = (double)g_fA[(size_t)r * K + p];
            double b = (double)g_fB[(size_t)p * N + q];
            acc += a * b;
            mag += fabs(a * b);
        }
        d = fabs((double)g_fC[i] - acc);
        rel = mag > 0 ? d / mag : d;
        if (rel > e0) e0 = rel;
    }
    return e0;
}

static int cmp_dbl(const void *a, const void *b)
{
    double x = *(const double *)a, y = *(const double *)b;
    return (x > y) - (x < y);
}

int main(int argc, char **argv)
{
    int R = argc > 1 ? atoi(argv[1]) : 5;
    int arg0 = 2;
    static int shapes[64][3];
    int nsh = 0;
    int i, s, ki, r, inner;
    double *samples;

    if (argc > 2) { g_peak = atof(argv[2]); arg0 = 3; }
    for (i = arg0; i < argc && nsh < 64; i++) {
        int M, N, K;
        if (sscanf(argv[i], "%dx%dx%d", &M, &N, &K) == 3) {
            shapes[nsh][0] = M; shapes[nsh][1] = N; shapes[nsh][2] = K; nsh++;
        }
    }
    if (nsh == 0) {
        fprintf(stderr, "用法：_gpucal.exe [轮数] [峰值TFLOPS] MxNxK ...\n");
        return 2;
    }

    /* ── 驱动初始化 ── */
    {
        void *p;
        CUdevice dev;
        int v;
        g_dll = LoadLibraryA("nvcuda.dll");
        if (!g_dll) { fail("找不到 nvcuda.dll"); return 1; }
#define LOAD(n, f) do { p = (void *)GetProcAddress(g_dll, n); \
    if (!p) { fail("缺 %s", n); return 1; } \
    memcpy(&(f), &p, sizeof(f)); } while (0)
        LOAD("cuInit", p_cuInit);
        LOAD("cuDriverGetVersion", p_cuDriverGetVersion);
        LOAD("cuDeviceGetCount", p_cuDeviceGetCount);
        LOAD("cuDeviceGet", p_cuDeviceGet);
        LOAD("cuDeviceGetName", p_cuDeviceGetName);
        LOAD("cuDeviceGetAttribute", p_cuDeviceGetAttribute);
        LOAD("cuDevicePrimaryCtxRetain", p_cuDevicePrimaryCtxRetain);
        LOAD("cuCtxSetCurrent", p_cuCtxSetCurrent);
        LOAD("cuCtxSynchronize", p_cuCtxSynchronize);
        LOAD("cuModuleLoadData", p_cuModuleLoadData);
        LOAD("cuModuleGetFunction", p_cuModuleGetFunction);
        LOAD("cuMemFree_v2", p_cuMemFree_v2);
        LOAD("cuMemcpyHtoD_v2", p_cuMemcpyHtoD_v2);
        LOAD("cuMemcpyDtoH_v2", p_cuMemcpyDtoH_v2);
        LOAD("cuLaunchKernel", p_cuLaunchKernel);
        LOAD("cuGetErrorString", p_cuGetErrorString);
        LOAD("cuEventCreate", p_cuEventCreate);
        LOAD("cuEventRecord", p_cuEventRecord);
        LOAD("cuEventSynchronize", p_cuEventSynchronize);
        LOAD("cuEventElapsedTime", p_cuEventElapsedTime);
        p = (void *)GetProcAddress(g_dll, "cuMemAlloc_v2");
        memcpy(&p_cuMemAlloc_v2, &p, sizeof(p));
        p = (void *)GetProcAddress(g_dll, "cuFuncGetAttribute");
        memcpy(&p_cuFuncGetAttribute, &p, sizeof(p));
        p = (void *)GetProcAddress(g_dll, "cuOccupancyMaxActiveBlocksPerMultiprocessor");
        memcpy(&p_cuOccupancyMaxActiveBlocksPerMultiprocessor, &p, sizeof(p));
#undef LOAD
        if (!p_cuMemAlloc_v2) { fail("缺 cuMemAlloc_v2"); return 1; }

        if (p_cuInit(0) != 0) { fail("cuInit 失败"); return 1; }
        if (p_cuDeviceGetCount(&v) != 0 || v < 1) { fail("取不到设备"); return 1; }
        if (p_cuDeviceGet(&dev, 0) != 0) { fail("取不到 0 号设备"); return 1; }
        p_cuDeviceGetName(g_err, 64, dev);
        if (p_cuDevicePrimaryCtxRetain(&g_ctx, dev) != 0) { fail("建不了 context"); return 1; }
        if (p_cuCtxSetCurrent(g_ctx) != 0) { fail("切不过 context"); return 1; }

        printf("# 设备 %s\n", g_err);
        printf("# 属性核对（常量写错这里就会露馅）\n");
        {
            int a;
            struct { int id; const char *name; } lst[] = {
                { ATTR_MULTIPROCESSOR_COUNT,      "SM 数" },
                { ATTR_MAX_THREADS_PER_MP,        "每 SM 最大线程" },
                { ATTR_MAX_BLOCKS_PER_MP,         "每 SM 最大 block" },
                { ATTR_WARP_SIZE,                 "warp 大小" },
                { ATTR_MAX_REGISTERS_PER_MP,      "每 SM 寄存器数" },
                { ATTR_MAX_SHARED_MEMORY_PER_MP,  "每 SM 共享内存" },
                { ATTR_MAX_THREADS_PER_BLOCK,     "每 block 最大线程" },
                { ATTR_MAX_SHARED_MEMORY_PER_BLOCK,"每 block 共享内存" },
                { ATTR_MAX_REGISTERS_PER_BLOCK,   "每 block 寄存器" },
                { ATTR_CLOCK_FREQUENCY,           "时钟 kHz" },
                { ATTR_CC_MAJOR,                  "CC major" },
                { ATTR_CC_MINOR,                  "CC minor" },
            };
            for (i = 0; i < (int)(sizeof(lst)/sizeof(lst[0])); i++) {
                a = -1;
                p_cuDeviceGetAttribute(&a, lst[i].id, dev);
                printf("#   %-18s = %d\n", lst[i].name, a);
                if (lst[i].id == ATTR_MULTIPROCESSOR_COUNT) g_sms = a;
            }
        }
        printf("# 峰值按 %.3f TFLOPS 计\n", g_peak);
        {
            /* 全量扫属性 ID：常量记错是这类活最常见的坑，
             * 与其背文档不如把 1..90 全打出来认。 */
            int id, val;
            printf("# --- 属性全扫描（1..90）---\n");
            for (id = 1; id <= 90; id++) {
                val = -1;
                if (p_cuDeviceGetAttribute(&val, id, dev) == 0 && val != -1)
                    printf("#   attr %2d = %d\n", id, val);
            }
        }
        for (i = 0; i < NK; i++) {
            CUresult r;
            if (!load_ptx(g_k[i].file)) return 1;
            r = p_cuModuleLoadData(&g_k[i].mod, g_ptx);
            if (r != 0) { fail("%s 的 PTX 被拒：%s", g_k[i].file, cu_err(r)); return 1; }
            if (p_cuModuleGetFunction(&g_k[i].fn, g_k[i].mod, g_k[i].entry) != 0) {
                fail("取不到入口 %s", g_k[i].entry); return 1;
            }
            g_k[i].ok = 1;
            {
                /* 每个 kernel 的 occupancy：生产路由要靠它算「每 SM 能驻几个 block」 */
                int regs = -1, shared = -1, occ = -1, mx = -1;
                if (p_cuFuncGetAttribute) {
                    p_cuFuncGetAttribute(&regs, 4, g_k[i].fn);      /* NUM_REGS */
                    p_cuFuncGetAttribute(&shared, 1, g_k[i].fn);   /* SHARED_SIZE_BYTES */
                    p_cuFuncGetAttribute(&mx, 0, g_k[i].fn);       /* MAX_THREADS_PER_BLOCK */
                }
                if (p_cuOccupancyMaxActiveBlocksPerMultiprocessor)
                    p_cuOccupancyMaxActiveBlocksPerMultiprocessor(&occ, g_k[i].fn, 16 * 16, 0);
                printf("#   kernel %-4s 寄存器=%d 共享=%dB 每SM常驻block=%d (每SM线程=%d)\n",
                       g_k[i].tag, regs, shared, occ, occ * 16 * 16);
            }
        }
        if (p_cuEventCreate(&g_ev0, CU_EVENT_DEFAULT) != 0) { fail("建不了 event"); return 1; }
        if (p_cuEventCreate(&g_ev1, CU_EVENT_DEFAULT) != 0) { fail("建不了 event"); return 1; }
    }

    printf("kernel,M,N,K,blocks,bps,waves,ms,TFLOPS,pct_peak,relerr\n");

    samples = (double *)malloc(sizeof(double) * (size_t)NK * (size_t)R);
    if (!samples) { fail("内存不足"); return 1; }

    for (s = 0; s < nsh; s++) {
        int M = shapes[s][0], N = shapes[s][1], K = shapes[s][2];
        size_t na = (size_t)M * K, nb = (size_t)K * N, nc = (size_t)M * N;
        size_t need = (na > nb ? na : nb);
        if (need < nc) need = nc;
        need *= sizeof(float);
        if (!ensure(need)) return 1;
        if (!ensure_host(need / sizeof(float))) { fail("host 内存不足"); return 1; }
        {
            size_t i2;
            for (i2 = 0; i2 < na; i2++) g_fA[i2] = (float)(frand() * 2.0);
            for (i2 = 0; i2 < nb; i2++) g_fB[i2] = (float)(frand() * 2.0);
        }
        if (p_cuMemcpyHtoD_v2(g_dA, g_fA, na * sizeof(float)) != 0) { fail("A 上卡失败"); return 1; }
        if (p_cuMemcpyHtoD_v2(g_dB, g_fB, nb * sizeof(float)) != 0) { fail("B 上卡失败"); return 1; }

        inner = (int)(2000000.0 / (double)(nc + 1));
        if (inner < 3) inner = 3;
        if (inner > 200) inner = 200;

        /* 轮转顺序：每轮换 kernel 起点，谁都不固定抢第一（单轮会被升频骗） */
        for (r = 0; r < R; r++) {
            for (ki = 0; ki < NK; ki++) {
                int k = (ki + r) % NK;
                double ms;
                if (!time_one(k, M, N, K, inner, &ms)) return 1;
                samples[(size_t)k * (size_t)R + (size_t)r] = ms;
            }
        }
        for (ki = 0; ki < NK; ki++) {
            unsigned gx, gy;
            double best_ms = 0, err;
            int nb_blocks, waves;
            double flops = 2.0 * (double)M * (double)N * (double)K;
            double *tmp = samples + (size_t)ki * (size_t)R;

            if (R > 1) qsort(tmp, (size_t)R, sizeof(double), cmp_dbl);
            best_ms = tmp[R / 2];
            grid_of(&g_k[ki], M, N, &gx, &gy);
            nb_blocks = (int)(gx * gy);
            waves = (nb_blocks + g_sms - 1) / g_sms;   /* 粗口径：每 SM 一个 block 一波 */
            err = check(M, N, K);
            {
                double tflops = flops / (best_ms * 1e-3) / 1e12;
                printf("%s,%d,%d,%d,%d,%.3f,%d,%.6f,%.4f,%.2f,%.2e\n",
                       g_k[ki].tag, M, N, K, nb_blocks,
                       (double)nb_blocks / (double)g_sms, waves,
                       best_ms, tflops, tflops / g_peak * 100.0, err);
            }
        }
        fflush(stdout);
    }
    free(samples);
    return 0;
}
