# _patch_gen_posregs.py —— 生成器的 x 位置指针从 %rd22 起排，跟步长寄存器 %rd26/%rd27 撞车。
#
# 现象：TSY*TSX > 4 时（TSY=4/TSX=2 等）生成的 PTX 直接 218。
# 原因：位置指针 %rd(22+i) 与两个步长寄存器 %rd26（S*4）、%rd27（S*W*4）重叠，
# 第 5 个位置就把步长寄存器冲掉了 → 地址全错。
# 修法：位置指针挪到 %rd30 起（%rd4..%rd7、%rd28、%rd29 都是空着的），
#       声明数量按 30 + TSY*TSX + 8 算。
import io, os

P = "build_tmp/probe/_gen_conv_ptx.py"
d = io.open(P, encoding="utf-8", newline="").read()

n = d.count("22 + i")
if n == 0:
    print("没有 22 + i，已经是新版")
    raise SystemExit(0)
print("找到 %d 处位置指针基准" % n)
d = d.replace("22 + i", "30 + i")

old = 'e("    .reg .b64  %%rd<%d>;" % (22 + TSY * TSX + 8))'
new = 'e("    .reg .b64  %%rd<%d>;" % (30 + TSY * TSX + 8))'
if d.count(old) != 1:
    raise SystemExit("锚点 %r 命中 %d 次" % (old, d.count(old)))
d = d.replace(old, new)

tmp = P + ".tmpfix"
with io.open(tmp, "w", encoding="utf-8", newline="") as f:
    f.write(d)
os.replace(tmp, P)
print("位置指针基准 22 -> 30，声明 %d 个 64 位寄存器" % (30 + 8 + 8))
