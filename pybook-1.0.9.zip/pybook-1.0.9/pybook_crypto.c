/* PYbook 标准库：crypto 加密模块（自实现，无第三方依赖）。
 *
 * 对外（语言层）接口：
 *   crypto.随机(字节数)              → 十六进制串（2×字节数 个字符）
 *   crypto.摘要(数据, 算法)          → 十六进制摘要（算法目前只支持 "sha256"）
 *   crypto.派生(口令, 盐, 轮数, 长度) → 十六进制密钥（PBKDF2-HMAC-SHA256）
 *   crypto.签名(密钥hex, 数据)       → 十六进制 HMAC-SHA256（32 字节）
 *   crypto.加密(密钥hex, 随机数hex, 明文) → 十六进制密文（ChaCha20）
 *   crypto.解密(密钥hex, 随机数hex, 密文hex) → 明文
 *
 * 加密原语（字节级，见 pybook_crypto.h）：
 *   SHA-256 / HMAC-SHA256 / PBKDF2 / ChaCha20(RFC 8439) / hex / BCryptGenRandom
 *
 * 为什么自实现（而不是引 OpenSSL）：
 *   1) 项目要无依赖编译：MinGW + MSVC + Linux + macOS 都要能过；
 *   2) 行为一致：同一个口令在 4 个平台派生出同样的密钥，才能跨机互通；
 *   3) 这几个算法都很短，自己写反而没有版本差异带来的坑。
 *
 * 安全边界（写在这里，别在文档里丢掉）：
 *   - ChaCha20 是**流密码**：同一个密钥 + 同一个随机数，绝不能加密两条不同的消息
 *     （密钥流重用 → 两条密文异或就是明文异或）。调用方必须保证随机数不重复。
 *     crypto.加密 把随机数交给调用方，就是为了这个：它没法替你保证唯一性。
 *   - 这里没有前向保密：口令派生出的密钥是静态的，拿到密文+口令就能解；
 *     拿到密文但没口令，解不开（依赖 PBKDF2 的 10 万轮 + 256 位密钥空间）。
 *   - 没有 AEAD 构造：完整性靠单独的 HMAC（crypto.签名），必须自己保证
 *     「先验 MAC 再解密」，否则就是「先解密再验」的 padding-oracle 类漏洞。
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>

#include "pybook_rt.h"
#include "pybook_lib.h"
#include "pybook_crypto.h"

#if defined(_WIN32)
#include <windows.h>
#include <bcrypt.h>
#else
#include <stdio.h>
#endif

/* ---------- 运行时错误出口（与 pybook_net.c 的 net_die 同风格） ---------- */

static void cr_die(const char *fmt, ...)
{
    va_list ap;
    char msg[768];
    va_start(ap, fmt);
    vsnprintf(msg, sizeof msg, fmt, ap);
    va_end(ap);
    rt_die("%s", msg);
}

/* =============================================================================
 * SHA-256（FIPS 180-4）
 * ========================================================================== */

static const uint32_t K256[64] = {
    0x428a2f98u,0x71374491u,0xb5c0fbcfu,0xe9b5dba5u,0x3956c25bu,0x59f111f1u,0x923f82a4u,0xab1c5ed5u,
    0xd807aa98u,0x12835b01u,0x243185beu,0x550c7dc3u,0x72be5d74u,0x80deb1feu,0x9bdc06a7u,0xc19bf174u,
    0xe49b69c1u,0xefbe4786u,0x0fc19dc6u,0x240ca1ccu,0x2de92c6fu,0x4a7484aau,0x5cb0a9dcu,0x76f988dau,
    0x983e5152u,0xa831c66du,0xb00327c8u,0xbf597fc7u,0xc6e00bf3u,0xd5a79147u,0x06ca6351u,0x14292967u,
    0x27b70a85u,0x2e1b2138u,0x4d2c6dfcu,0x53380d13u,0x650a7354u,0x766a0abbu,0x81c2c92eu,0x92722c85u,
    0xa2bfe8a1u,0xa81a664bu,0xc24b8b70u,0xc76c51a3u,0xd192e819u,0xd6990624u,0xf40e3585u,0x106aa070u,
    0x19a4c116u,0x1e376c08u,0x2748774cu,0x34b0bcb5u,0x391c0cb3u,0x4ed8aa4au,0x5b9cca4fu,0x682e6ff3u,
    0x748f82eeu,0x78a5636fu,0x84c87814u,0x8cc70208u,0x90befffau,0xa4506cebu,0xbef9a3f7u,0xc67178f2u
};

#define ROR32(x, n) ((((x) >> (n)) | ((x) << (32 - (n)))) & 0xFFFFFFFFu)
#define ROTL32(x, n) ((((x) << (n)) | ((x) >> (32 - (n)))) & 0xFFFFFFFFu)

/* 大小写不敏感比较：Windows 有 _stricmp，POSIX 是 strcasecmp */
#if defined(_WIN32)
#define CR_STRCMPI(a, b) _stricmp((a), (b))
#else
#include <strings.h>
#define CR_STRCMPI(a, b) strcasecmp((a), (b))
#endif

typedef struct {
    uint32_t h[8];
    unsigned char buf[64];
    size_t   len;        /* buf 里的有效字节数 */
    uint64_t total;      /* 总字节数 */
} Sha256Ctx;

static void sha256_init(Sha256Ctx *c)
{
    c->h[0] = 0x6a09e667u; c->h[1] = 0xbb67ae85u;
    c->h[2] = 0x3c6ef372u; c->h[3] = 0xa54ff53au;
    c->h[4] = 0x510e527fu; c->h[5] = 0x9b05688cu;
    c->h[6] = 0x1f83d9abu; c->h[7] = 0x5be0cd19u;
    c->len = 0;
    c->total = 0;
}

static void sha256_block(Sha256Ctx *c, const unsigned char *p)
{
    uint32_t w[64], a, b, cc, d, e, f, g, hh, t1, t2;
    int i;
    for (i = 0; i < 16; i++) {
        w[i] = ((uint32_t)p[i * 4] << 24) | ((uint32_t)p[i * 4 + 1] << 16) |
               ((uint32_t)p[i * 4 + 2] << 8) | (uint32_t)p[i * 4 + 3];
    }
    for (i = 16; i < 64; i++) {
        uint32_t s0 = ROR32(w[i - 15], 7) ^ ROR32(w[i - 15], 18) ^ (w[i - 15] >> 3);
        uint32_t s1 = ROR32(w[i - 2], 17) ^ ROR32(w[i - 2], 19) ^ (w[i - 2] >> 10);
        w[i] = w[i - 16] + s0 + w[i - 7] + s1;
    }
    a = c->h[0]; b = c->h[1]; cc = c->h[2]; d = c->h[3];
    e = c->h[4]; f = c->h[5]; g = c->h[6]; hh = c->h[7];
    for (i = 0; i < 64; i++) {
        uint32_t S1 = ROR32(e, 6) ^ ROR32(e, 11) ^ ROR32(e, 25);
        uint32_t ch = (e & f) ^ ((~e) & g);
        uint32_t S0 = ROR32(a, 2) ^ ROR32(a, 13) ^ ROR32(a, 22);
        uint32_t maj = (a & b) ^ (a & cc) ^ (b & cc);
        t1 = hh + S1 + ch + K256[i] + w[i];
        t2 = S0 + maj;
        hh = g; g = f; f = e; e = d + t1;
        d = cc; cc = b; b = a; a = t1 + t2;
    }
    c->h[0] += a; c->h[1] += b; c->h[2] += cc; c->h[3] += d;
    c->h[4] += e; c->h[5] += f; c->h[6] += g; c->h[7] += hh;
}

static void sha256_update(Sha256Ctx *c, const unsigned char *p, size_t n)
{
    c->total += (uint64_t)n;
    while (n > 0) {
        size_t take = 64 - c->len;
        if (take > n)
            take = n;
        memcpy(c->buf + c->len, p, take);
        c->len += take;
        p += take;
        n -= take;
        if (c->len == 64) {
            sha256_block(c, c->buf);
            c->len = 0;
        }
    }
}

static void sha256_final(Sha256Ctx *c, unsigned char out[32])
{
    uint64_t bits = c->total * 8;
    unsigned char pad = 0x80;
    unsigned char lenbe[8];
    int i;
    sha256_update(c, &pad, 1);
    pad = 0;
    while (c->len != 56)
        sha256_update(c, &pad, 1);
    for (i = 0; i < 8; i++)
        lenbe[i] = (unsigned char)((bits >> (56 - 8 * i)) & 0xFF);
    sha256_update(c, lenbe, 8);
    for (i = 0; i < 8; i++) {
        out[i * 4]     = (unsigned char)((c->h[i] >> 24) & 0xFF);
        out[i * 4 + 1] = (unsigned char)((c->h[i] >> 16) & 0xFF);
        out[i * 4 + 2] = (unsigned char)((c->h[i] >> 8) & 0xFF);
        out[i * 4 + 3] = (unsigned char)(c->h[i] & 0xFF);
    }
}

void cr_sha256(const unsigned char *data, size_t len, unsigned char out[32])
{
    Sha256Ctx c;
    sha256_init(&c);
    sha256_update(&c, data, len);
    sha256_final(&c, out);
}

/* =============================================================================
 * HMAC-SHA256（RFC 2104）
 * ========================================================================== */

void cr_hmac_sha256(const unsigned char *key, size_t klen,
                    const unsigned char *data, size_t dlen,
                    unsigned char out[32])
{
    unsigned char k[64], ipad[64], opad[64], inner[32];
    Sha256Ctx c;
    size_t i;

    memset(k, 0, sizeof k);
    if (klen > 64)
        cr_sha256(key, klen, k);          /* 密钥过长先哈希 */
    else if (klen)
        memcpy(k, key, klen);
    for (i = 0; i < 64; i++) {
        ipad[i] = (unsigned char)(k[i] ^ 0x36);
        opad[i] = (unsigned char)(k[i] ^ 0x5C);
    }

    sha256_init(&c);
    sha256_update(&c, ipad, 64);
    sha256_update(&c, data, dlen);
    sha256_final(&c, inner);

    sha256_init(&c);
    sha256_update(&c, opad, 64);
    sha256_update(&c, inner, 32);
    sha256_final(&c, out);
}

/* =============================================================================
 * PBKDF2-HMAC-SHA256（RFC 2898）
 * ========================================================================== */

void cr_pbkdf2_sha256(const unsigned char *pw, size_t pwlen,
                      const unsigned char *salt, size_t slen,
                      unsigned long iters, unsigned char *out, size_t outlen)
{
    unsigned char *msg, u[32], t[32], mac[32];
    unsigned int block = 1;
    size_t done = 0;
    unsigned long i;

    if (iters == 0)
        iters = 1;
    msg = (unsigned char *)malloc(slen + 4);
    if (!msg)
        cr_die("crypto：内存不足（PBKDF2 需要 %lu 字节）", (unsigned long)(slen + 4));

    while (done < outlen) {
        size_t take, j;
        if (slen)
            memcpy(msg, salt, slen);
        msg[slen]     = (unsigned char)((block >> 24) & 0xFF);
        msg[slen + 1] = (unsigned char)((block >> 16) & 0xFF);
        msg[slen + 2] = (unsigned char)((block >> 8) & 0xFF);
        msg[slen + 3] = (unsigned char)(block & 0xFF);
        cr_hmac_sha256(pw, pwlen, msg, slen + 4, u);
        memcpy(t, u, 32);
        for (i = 1; i < iters; i++) {
            cr_hmac_sha256(pw, pwlen, u, 32, mac);
            memcpy(u, mac, 32);
            for (j = 0; j < 32; j++)
                t[j] = (unsigned char)(t[j] ^ u[j]);
        }
        take = outlen - done;
        if (take > 32)
            take = 32;
        memcpy(out + done, t, take);
        done += take;
        block++;
    }
    free(msg);
}

/* =============================================================================
 * ChaCha20（RFC 8439）
 * ========================================================================== */

#define QR(a, b, c, d)                       \
    x[a] += x[b]; x[d] ^= x[a]; x[d] = ROTL32(x[d], 16); \
    x[c] += x[d]; x[b] ^= x[c]; x[b] = ROTL32(x[b], 12); \
    x[a] += x[b]; x[d] ^= x[a]; x[d] = ROTL32(x[d], 8);  \
    x[c] += x[d]; x[b] ^= x[c]; x[b] = ROTL32(x[b], 7)

static void chacha20_block(const uint32_t st[16], unsigned char out[64])
{
    uint32_t x[16];
    int i;
    memcpy(x, st, sizeof x);
    for (i = 0; i < 10; i++) {           /* 20 轮 = 10 次双轮 */
        QR(0, 4, 8, 12); QR(1, 5, 9, 13); QR(2, 6, 10, 14); QR(3, 7, 11, 15);
        QR(0, 5, 10, 15); QR(1, 6, 11, 12); QR(2, 7, 8, 13); QR(3, 4, 9, 14);
    }
    for (i = 0; i < 16; i++) {
        uint32_t v = x[i] + st[i];
        out[i * 4]     = (unsigned char)(v & 0xFF);
        out[i * 4 + 1] = (unsigned char)((v >> 8) & 0xFF);
        out[i * 4 + 2] = (unsigned char)((v >> 16) & 0xFF);
        out[i * 4 + 3] = (unsigned char)((v >> 24) & 0xFF);
    }
}

void cr_chacha20(const unsigned char key[32], const unsigned char nonce[12],
                 unsigned long counter,
                 const unsigned char *in, unsigned char *out, size_t len)
{
    uint32_t st[16];
    unsigned char block[64];
    size_t i;

    st[0] = 0x61707865u; st[1] = 0x3320646eu;
    st[2] = 0x79622d32u; st[3] = 0x6b206574u;
    memcpy(st + 4, key, 32);
    st[12] = (uint32_t)(counter & 0xFFFFFFFFu);
    memcpy(st + 13, nonce, 12);

    while (len > 0) {
        size_t take = len < 64 ? len : 64;
        chacha20_block(st, block);
        for (i = 0; i < take; i++)
            out[i] = (unsigned char)(in[i] ^ block[i]);
        in += take;
        out += take;
        len -= take;
        st[12]++;                       /* 块计数器进位（32 位回绕） */
    }
}

/* =============================================================================
 * 随机 / hex / 常量时间比较
 * ========================================================================== */

int cr_random(unsigned char *buf, size_t len)
{
#if defined(_WIN32)
    BCRYPT_ALG_HANDLE alg = NULL;
    NTSTATUS st;
    if (len == 0)
        return 0;
    /* 必须显式开算法提供程序：BCryptGenRandom 的 hAlgorithm 传 NULL
     * 在部分 Windows 版本上直接返回 STATUS_INVALID_HANDLE。 */
    st = BCryptOpenAlgorithmProvider(&alg, BCRYPT_RNG_ALGORITHM, NULL, 0);
    if (st != 0 || alg == NULL)
        return -1;
    st = BCryptGenRandom(alg, (PUCHAR)buf, (ULONG)len, 0);
    BCryptCloseAlgorithmProvider(alg, 0);
    return st == 0 ? 0 : -1;
#else
    FILE *f;
    size_t got;
    if (len == 0)
        return 0;
    f = fopen("/dev/urandom", "rb");
    if (!f)
        return -1;
    got = fread(buf, 1, len, f);
    fclose(f);
    return got == len ? 0 : -1;
#endif
}

void cr_hex(const unsigned char *in, size_t len, char *out)
{
    static const char *hexd = "0123456789abcdef";
    size_t i;
    for (i = 0; i < len; i++) {
        out[i * 2]     = hexd[(in[i] >> 4) & 0x0F];
        out[i * 2 + 1] = hexd[in[i] & 0x0F];
    }
    out[len * 2] = '\0';
}

static int hexval(char ch)
{
    if (ch >= '0' && ch <= '9') return ch - '0';
    if (ch >= 'a' && ch <= 'f') return ch - 'a' + 10;
    if (ch >= 'A' && ch <= 'F') return ch - 'A' + 10;
    return -1;
}

int cr_unhex(const char *in, unsigned char *out, size_t outcap)
{
    size_t n = 0, i, len;
    if (!in)
        return -1;
    len = strlen(in);
    if (len % 2 != 0)
        return -1;
    if (len / 2 > outcap)
        return -1;
    for (i = 0; i < len; i += 2) {
        int hi = hexval(in[i]), lo = hexval(in[i + 1]);
        if (hi < 0 || lo < 0)
            return -1;
        out[n++] = (unsigned char)((hi << 4) | lo);
    }
    return (int)n;
}

int cr_equal(const unsigned char *a, const unsigned char *b, size_t n)
{
    unsigned char d = 0;
    size_t i;
    for (i = 0; i < n; i++)
        d = (unsigned char)(d | (a[i] ^ b[i]));
    return d == 0;
}

/* =============================================================================
 * 语言层接口
 * ========================================================================== */

static const char *cr_str(Value v, const char *who)
{
    if (!IS_STR(v))
        cr_die("%s 需要字符串", who);
    return AS_STR(v) ? AS_STR(v) : "";
}

static long long cr_int(Value v, const char *who)
{
    if (!IS_INT(v))
        cr_die("%s 需要整数", who);
    return AS_INT(v);
}

/* crypto.随机(字节数) → 十六进制串 */
Value rt_crypto_random(Value n)
{
    long long want = cr_int(n, "crypto.随机 的字节数");
    unsigned char *buf;
    char *hex;
    Value r;
    if (want < 0 || want > 4096)
        cr_die("crypto.随机 的字节数要在 0~4096 之间（给了 %lld）", want);
    buf = (unsigned char *)malloc((size_t)(want > 0 ? want : 1));
    hex = (char *)malloc((size_t)(want * 2 + 1));
    if (!buf || !hex)
        cr_die("内存不足");
    if (want > 0 && cr_random(buf, (size_t)want) != 0)
        cr_die("crypto.随机：取随机数失败（系统随机源不可用）");
    cr_hex(buf, (size_t)want, hex);
    r = rt_str(hex);
    free(buf);
    free(hex);
    return r;
}

/* crypto.摘要(数据, 算法) → 十六进制摘要 */
Value rt_crypto_digest(Value data, Value alg)
{
    const char *d = cr_str(data, "crypto.摘要 的数据");
    const char *a = cr_str(alg, "crypto.摘要 的算法");
    unsigned char out[32];
    char hex[65];
    Value r;
    /* 算法名大小写不敏感；目前只实现 sha256 */
    if (CR_STRCMPI(a, "sha256") == 0 || CR_STRCMPI(a, "sha-256") == 0) {
        cr_sha256((const unsigned char *)d, strlen(d), out);
    } else {
        cr_die("crypto.摘要 不支持算法 \"%s\"（目前只有 \"sha256\"）", a);
        return rt_none();      /* 不可达 */
    }
    cr_hex(out, 32, hex);
    r = rt_str(hex);
    return r;
}

/* crypto.派生(口令, 盐, 轮数, 长度) → 十六进制密钥 */
Value rt_crypto_derive(Value pw, Value salt, Value iters, Value len)
{
    const char *p = cr_str(pw, "crypto.派生 的口令");
    const char *s = cr_str(salt, "crypto.派生 的盐");
    long long it = cr_int(iters, "crypto.派生 的轮数");
    long long ln = cr_int(len, "crypto.派生 的长度");
    unsigned char *key;
    char *hex;
    Value r;
    if (it < 1 || it > 10000000)
        cr_die("crypto.派生 的轮数要在 1~10000000 之间（给了 %lld）", it);
    if (ln < 1 || ln > 1024)
        cr_die("crypto.派生 的长度要在 1~1024 字节之间（给了 %lld）", ln);
    key = (unsigned char *)malloc((size_t)ln);
    hex = (char *)malloc((size_t)ln * 2 + 1);
    if (!key || !hex)
        cr_die("内存不足");
    cr_pbkdf2_sha256((const unsigned char *)p, strlen(p),
                     (const unsigned char *)s, strlen(s),
                     (unsigned long)it, key, (size_t)ln);
    cr_hex(key, (size_t)ln, hex);
    r = rt_str(hex);
    free(key);
    free(hex);
    return r;
}

/* crypto.签名(密钥hex, 数据) → 十六进制 HMAC-SHA256 */
Value rt_crypto_sign(Value keyv, Value data)
{
    const char *kh = cr_str(keyv, "crypto.签名 的密钥");
    const char *d = cr_str(data, "crypto.签名 的数据");
    unsigned char key[512], mac[32];
    char hex[65];
    int klen;
    Value r;
    klen = cr_unhex(kh, key, sizeof key);
    if (klen < 0)
        cr_die("crypto.签名 的密钥必须是十六进制字符串（长度成对、只含 0-9a-fA-F）");
    cr_hmac_sha256(key, (size_t)klen, (const unsigned char *)d, strlen(d), mac);
    cr_hex(mac, 32, hex);
    r = rt_str(hex);
    return r;
}

/* 取 32 字节 ChaCha20 密钥（hex → 字节），失败报错 */
static void cr_need_key(const char *kh, const char *who, unsigned char out[32])
{
    int n = cr_unhex(kh, out, 32);
    if (n != 32)
        cr_die("%s 的密钥必须是 32 字节（64 个十六进制字符）", who);
}

/* 取 12 字节随机数（hex → 字节），失败报错 */
static void cr_need_nonce(const char *nh, const char *who, unsigned char out[12])
{
    int n = cr_unhex(nh, out, 12);
    if (n != 12)
        cr_die("%s 的随机数必须是 12 字节（24 个十六进制字符）", who);
}

/* crypto.加密(密钥hex, 随机数hex, 明文) → 十六进制密文 */
Value rt_crypto_encrypt(Value keyv, Value noncev, Value plain)
{
    const char *kh = cr_str(keyv, "crypto.加密 的密钥");
    const char *nh = cr_str(noncev, "crypto.加密 的随机数");
    const char *p = cr_str(plain, "crypto.加密 的明文");
    unsigned char key[32], nonce[12];
    size_t len = strlen(p);
    unsigned char *ct;
    char *hex;
    Value r;
    cr_need_key(kh, "crypto.加密", key);
    cr_need_nonce(nh, "crypto.加密", nonce);
    ct = (unsigned char *)malloc(len > 0 ? len : 1);
    hex = (char *)malloc(len * 2 + 1);
    if (!ct || !hex)
        cr_die("内存不足");
    cr_chacha20(key, nonce, 0, (const unsigned char *)p, ct, len);
    cr_hex(ct, len, hex);
    r = rt_str(hex);
    free(ct);
    free(hex);
    return r;
}

/* crypto.解密(密钥hex, 随机数hex, 密文hex) → 明文 */
Value rt_crypto_decrypt(Value keyv, Value noncev, Value ctv)
{
    const char *kh = cr_str(keyv, "crypto.解密 的密钥");
    const char *nh = cr_str(noncev, "crypto.解密 的随机数");
    const char *ch = cr_str(ctv, "crypto.解密 的密文");
    unsigned char key[32], nonce[12];
    unsigned char *ct, *pt;
    size_t cap, len;
    int n;
    Value r;
    cr_need_key(kh, "crypto.解密", key);
    cr_need_nonce(nh, "crypto.解密", nonce);
    cap = strlen(ch) / 2;
    ct = (unsigned char *)malloc(cap > 0 ? cap : 1);
    pt = (unsigned char *)malloc(cap > 0 ? cap + 1 : 1);
    if (!ct || !pt)
        cr_die("内存不足");
    n = cr_unhex(ch, ct, cap > 0 ? cap : 1);
    if (n < 0)
        cr_die("crypto.解密 的密文必须是十六进制字符串（长度成对、只含 0-9a-fA-F）");
    len = (size_t)n;
    cr_chacha20(key, nonce, 0, ct, pt, len);
    pt[len] = '\0';                /* rt_str 要 C 串：明文可能含 0 字节也不能越界读 */
    r = rt_str((const char *)pt);  /* rt_str 内部拷贝 */
    free(ct);
    free(pt);
    return r;
}

/* ================= 自测（-DLIB_SELF_TEST） =================
 *
 * 单文件就能跑（自带最小运行时桩，不把整个 pybook_rt 拉进来）：
 *   gcc -O2 -DLIB_SELF_TEST pybook_crypto.c -o crypto_test.exe -I. -lbcrypt
 *   crypto_test.exe
 *
 * 用**官方标准向量**，不自证自明：
 *   SHA-256  → FIPS 180-4
 *   HMAC     → RFC 4231
 *   PBKDF2   → RFC 7914 §11
 *   ChaCha20 → RFC 8439 §2.4.2 / A.1 / A.2
 *
 * ChaCha20 的向量在 pybook_crypto_vec.h 里，由仓库根目录的「加密向量生成.py」
 * 从 RFC 8439 原文**机器提取**。
 *
 * 为什么强调「机器提取」：手抄十六进制向量抄错过两次——
 *   1) 把 114 字节明文对应成 128 字节密文，差点把「实现是对的」误判成「实现有 bug」；
 *   2) A.2 #3 的密钥手抄多了一个字符（65 位而不是 64 位），而 cr_unhex 返回 -1
 *      我又没检查，于是拿残留的旧密钥继续算，输出一个「看起来有差别」的密文。
 * 教训一：向量必须由原文机器提取。
 * 教训二：cr_unhex 的返回值**必须**检查（下面 HV() 宏就是干这个的）。
 */
#ifdef LIB_SELF_TEST

#include <stdarg.h>
#include "pybook_crypto_vec.h"

/* ---- 自测用的最小运行时桩（只补 pybook_crypto.c 用到的那几个） ---- */

void rt_die(const char *fmt, ...)
{
    va_list ap;
    va_start(ap, fmt);
    fprintf(stderr, "runtime error: ");
    vfprintf(stderr, fmt, ap);
    fputc('\n', stderr);
    va_end(ap);
    exit(3);
}

Value rt_str(const char *s)
{
    char *p = (char *)malloc(strlen(s ? s : "") + 1);
    if (!p)
        rt_die("内存不足");
    strcpy(p, s ? s : "");
    return MAKE_STR(p);
}

Value rt_none(void) { return MAKE_NONE(); }

Value rt_int(long long x)
{
    return (Value)((uint64_t)(x & 0xFFFFFFFFFFFFULL) | 0x7FF9000000000000ULL);
}

/* ---- 断言 ---- */

static int g_pass = 0, g_fail = 0;

#define CHECK(cond, name)                              \
    do {                                               \
        if (cond) {                                    \
            g_pass++;                                  \
        } else {                                       \
            g_fail++;                                  \
            printf("[失败] %s\n", name);               \
        }                                              \
    } while (0)

/* 比较一段字节的十六进制是否等于期望值 */
static void hexeq(const char *what, const unsigned char *got, size_t n,
                  const char *want)
{
    char buf[512];
    cr_hex(got, n, buf);
    CHECK(strcmp(buf, want) == 0, what);
}

/* 解十六进制向量：**必须**检查返回值（教训二） */
#define HV(hexstr, buf, cap)                                             \
    do {                                                                  \
        int hv_n = cr_unhex((hexstr), (buf), (cap));                       \
        if (hv_n < 0) {                                                   \
            g_fail++;                                                     \
            printf("[失败] 向量 %s 解码失败（十六进制非法或长度不对）\n",  \
                   (hexstr));                                             \
        }                                                                 \
    } while (0)

int main(void)
{
    /* ---------- SHA-256（FIPS 180-4） ---------- */
    {
        unsigned char out[32];
        cr_sha256((const unsigned char *)"", 0, out);
        hexeq("SHA-256(\"\")", out, 32,
              "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855");

        cr_sha256((const unsigned char *)"abc", 3, out);
        hexeq("SHA-256(\"abc\")", out, 32,
              "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad");

        cr_sha256((const unsigned char *)
                  "abcdbcdecdefdefgefghfghighijhijkijkljklmklmnlmnomnopnopq", 56, out);
        hexeq("SHA-256(56 字节)", out, 32,
              "248d6a61d20638b8e5c026930c3e6039a33ce45964ff2167f6ecedd419db06c1");

        {   /* 一百万个 'a' */
            unsigned char *big = (unsigned char *)malloc(1000000);
            if (!big)
                rt_die("内存不足");
            memset(big, 'a', 1000000);
            cr_sha256(big, 1000000, out);
            free(big);
            hexeq("SHA-256(100 万个 a)", out, 32,
                  "cdc76e5c9914fb9281a1c7e284d73e67f1809a48a497200e046d39ccc7112cd0");
        }
    }

    /* ---------- HMAC-SHA256（RFC 4231） ---------- */
    {
        unsigned char out[32], key[131];
        memset(key, 0x0b, 20);
        cr_hmac_sha256(key, 20, (const unsigned char *)"Hi There", 8, out);
        hexeq("HMAC RFC4231 #1", out, 32,
              "b0344c61d8db38535ca8afceaf0bf12b881dc200c9833da726e9376c2e32cff7");

        cr_hmac_sha256((const unsigned char *)"Jefe", 4,
                       (const unsigned char *)"what do ya want for nothing?", 28, out);
        hexeq("HMAC RFC4231 #2", out, 32,
              "5bdcc146bf60754e6a042426089575c75a003f089d2739839dec58b964ec3843");

        memset(key, 0xaa, 131);
        cr_hmac_sha256(key, 131,
                       (const unsigned char *)
                       "Test Using Larger Than Block-Size Key - Hash Key First", 54,
                       out);
        hexeq("HMAC RFC4231 #6（超块长密钥）", out, 32,
              "60e431591ee0b67f0d8a26aacbf5b77f8e0bc6213728c5140546040f0ee37f54");
    }

    /* ---------- PBKDF2-HMAC-SHA256（RFC 7914 §11） ---------- */
    {
        unsigned char dk[32];
        cr_pbkdf2_sha256((const unsigned char *)"password", 8,
                         (const unsigned char *)"salt", 4, 1, dk, 32);
        hexeq("PBKDF2 c=1", dk, 32,
              "120fb6cffcf8b32c43e7225256c4f837a86548c92ccc35480805987cb70be17b");

        cr_pbkdf2_sha256((const unsigned char *)"password", 8,
                         (const unsigned char *)"salt", 4, 2, dk, 32);
        hexeq("PBKDF2 c=2", dk, 32,
              "ae4d0c95af6b46d32d0adff928f06dd02a303f8ef3c251dfd6e2d85a95474c43");

        cr_pbkdf2_sha256((const unsigned char *)"password", 8,
                         (const unsigned char *)"salt", 4, 4096, dk, 32);
        hexeq("PBKDF2 c=4096", dk, 32,
              "c5e478d59288c841aa530db6845c4c8d962893a001ce4e11a4963873aa98134a");

        {   /* 非 32 字节长度：短输出应是长输出的前缀 */
            unsigned char dk20[20], dk40[40];
            cr_pbkdf2_sha256((const unsigned char *)"password", 8,
                             (const unsigned char *)"salt", 4, 1, dk20, 20);
            cr_pbkdf2_sha256((const unsigned char *)"password", 8,
                             (const unsigned char *)"salt", 4, 1, dk40, 40);
            CHECK(memcmp(dk20, dk40, 20) == 0, "PBKDF2 短输出是长输出的前缀");
        }
    }

    /* ---------- ChaCha20（向量见 pybook_crypto_vec.h，RFC 8439） ---------- */
    {
        unsigned char key[32], nonce[12];
        unsigned char pt[256], ct[256], back[256];

        /* §2.4.2 太阳镜例子：114 字节明文，跨两个块 */
        {
            size_t plen, clen;
            HV(VEC_SUN_PLAIN, pt, sizeof pt);
            plen = (size_t)cr_unhex(VEC_SUN_PLAIN, pt, sizeof pt);
            HV(VEC_SUN_CT, ct, sizeof ct);
            clen = (size_t)cr_unhex(VEC_SUN_CT, ct, sizeof ct);
            HV(VEC_SUN_KEY, key, sizeof key);
            HV(VEC_SUN_NONCE, nonce, sizeof nonce);
            cr_chacha20(key, nonce, CTR_SUN, pt, back, plen);
            CHECK(plen == 114 && clen == 114 && memcmp(back, ct, plen) == 0,
                  "ChaCha20 RFC8439 §2.4.2（114 字节 / 两块）");
            cr_chacha20(key, nonce, CTR_SUN, ct, back, plen);
            CHECK(memcmp(back, pt, plen) == 0, "ChaCha20 解回原文");
        }

        /* A.1 #1~#5：块函数密钥流（改一位密钥、计数器 1/2、非零随机数） */
        {
            static const char *names[5] = {"A.1 #1", "A.1 #2", "A.1 #3", "A.1 #4", "A.1 #5"};
            static const char *keyh[5] = {VEC_A1_1_KEY, VEC_A1_2_KEY, VEC_A1_3_KEY,
                                          VEC_A1_4_KEY, VEC_A1_5_KEY};
            static const char *nonceh[5] = {VEC_A1_1_NONCE, VEC_A1_2_NONCE, VEC_A1_3_NONCE,
                                            VEC_A1_4_NONCE, VEC_A1_5_NONCE};
            static const char *ksh[5] = {VEC_A1_1_KS, VEC_A1_2_KS, VEC_A1_3_KS,
                                         VEC_A1_4_KS, VEC_A1_5_KS};
            static const int ctrov[5] = {CTR_A1_1, CTR_A1_2, CTR_A1_3, CTR_A1_4, CTR_A1_5};
            int i;
            for (i = 0; i < 5; i++) {
                HV(keyh[i], key, sizeof key);
                HV(nonceh[i], nonce, sizeof nonce);
                HV(ksh[i], ct, sizeof ct);
                memset(back, 0, 64);
                cr_chacha20(key, nonce, (unsigned long)ctrov[i], back, back, 64);
                CHECK(memcmp(back, ct, 64) == 0, names[i]);
            }
        }

        /* A.2 #3：127 字节明文、计数器 42 → 检验跨块计数器递增 */
        {
            size_t plen, clen;
            HV(VEC_A23_PLAIN, pt, sizeof pt);
            plen = (size_t)cr_unhex(VEC_A23_PLAIN, pt, sizeof pt);
            HV(VEC_A23_CT, ct, sizeof ct);
            clen = (size_t)cr_unhex(VEC_A23_CT, ct, sizeof ct);
            HV(VEC_A23_KEY, key, sizeof key);
            HV(VEC_A23_NONCE, nonce, sizeof nonce);
            cr_chacha20(key, nonce, (unsigned long)CTR_A23, pt, back, plen);
            CHECK(plen == 127 && clen == 127 && memcmp(back, ct, plen) == 0,
                  "ChaCha20 A.2 #3（127 字节 / 计数器 42 / 两块）");
        }
    }
#undef HV

    /* ---------- hex ---------- */
    {
        unsigned char b[4];
        char h[16];
        int n;
        cr_hex((const unsigned char *)"\xde\xad\xbe\xef", 4, h);
        CHECK(strcmp(h, "deadbeef") == 0, "hex 编码");
        n = cr_unhex("DEADBEEF", b, sizeof b);
        CHECK(n == 4 && b[0] == 0xde && b[3] == 0xef, "hex 解码（含大写）");
        CHECK(cr_unhex("abc", b, sizeof b) == -1, "奇数长度 hex 报错");
        CHECK(cr_unhex("zz", b, sizeof b) == -1, "非法字符 hex 报错");
    }

    /* ---------- 随机 ---------- */
    {
        unsigned char a[16], c[16];
        int i, same = 1, nz = 0;
        CHECK(cr_random(a, 16) == 0, "随机取 16 字节成功");
        CHECK(cr_random(c, 16) == 0, "随机再取 16 字节成功");
        for (i = 0; i < 16; i++) {
            if (a[i] != c[i])
                same = 0;
            if (a[i])
                nz++;
        }
        CHECK(!same, "两次随机结果不同");
        CHECK(nz > 0, "随机字节不全为 0");
    }

    /* ---------- 常量时间比较 ---------- */
    {
        unsigned char x[4] = {1, 2, 3, 4}, y[4] = {1, 2, 3, 4}, z[4] = {1, 2, 3, 5};
        CHECK(cr_equal(x, y, 4) == 1, "cr_equal 相等");
        CHECK(cr_equal(x, z, 4) == 0, "cr_equal 不等");
    }

    /* ---------- 语言层接线（rt_crypto_* 走真实实现） ---------- */
    {
        Value k = rt_crypto_derive(rt_str("口令"), rt_str("房间A"), rt_int(1000), rt_int(32));
        Value n = rt_crypto_random(rt_int(12));
        const char *kh = AS_STR(k), *nh = AS_STR(n);
        Value ct = rt_crypto_encrypt(k, n, rt_str("你好，世界"));
        Value pt = rt_crypto_decrypt(k, n, ct);
        const char *c = AS_STR(ct), *p = AS_STR(pt);
        CHECK(kh && strlen(kh) == 64, "crypto.派生 返回 64 个十六进制字符");
        CHECK(nh && strlen(nh) == 24, "crypto.随机 返回 24 个十六进制字符");
        CHECK(c && strlen(c) == 30, "crypto.加密 密文 = 15 字节明文 × 2");
        CHECK(p && strcmp(p, "你好，世界") == 0, "crypto.解密 还原原文");
    }

    printf("加密原语自测：通过 %d 项，失败 %d 项\n", g_pass, g_fail);
    if (g_fail == 0)
        printf("加密原语自测全部通过\n");
    return g_fail == 0 ? 0 : 1;
}

#endif /* LIB_SELF_TEST */
