/* Smokeroor：实战型安全检查（smoke.*，全英文 API）
 *
 * 设计原则：
 *   · 只读查询 —— 不修改任何状态、不分配长期内存
 *   · 零开销 —— 不调用就没有成本（没有全局钩子）
 *   · 状态判断不裸解引用 —— 悬垂指针靠登记表 + 位样识别，不碰野指针
 *
 * 与 pybook_rt.c 的关系：内部状态通过 rt_q_* 接口读（见 pybook_rt.h）。
 */
#include "pybook_smoke.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* ---- 断言计数 ---- */
static long long g_expect_fails = 0;
long long rt_smoke_expect_fails(void) { return g_expect_fails; }

/* 小工具：造一个 2 元列表 */
static Value mk2(Value a, Value b)
{
    Value l = rt_list_new();
    rt_push(&l, a);
    rt_push(&l, b);
    return l;
}

/* 小工具：造一个 3 元列表 */
static Value mk3(Value a, Value b, Value c)
{
    Value l = rt_list_new();
    rt_push(&l, a);
    rt_push(&l, b);
    rt_push(&l, c);
    return l;
}

/* ============ A. 变量级 ============ */

/* smoke.check(v) -> ["OK"] / ["DELETED"] / ["DANGLING"] / ["LOCKED"] */
Value rt_smoke_check(Value v)
{
    int st = rt_q_slotstate(v);
    Value l = rt_list_new();
    if (st == 1)      rt_push(&l, rt_str("DELETED"));
    else if (st == 3) rt_push(&l, rt_str("DANGLING"));
    else              rt_push(&l, rt_str("OK"));
    return l;
}

/* smoke.deleted(v) -> 1/0（已 del 或悬垂别名都算 1） */
Value rt_smoke_deleted(Value v)
{
    int st = rt_q_slotstate(v);
    return rt_int(st == 1 || st == 3 ? 1 : 0);
}

/* smoke.locked(v) -> 1/0
 * 注：锁按槽地址登记，这里给不出槽地址，只报"已 del 就读不了"这一层。
 * 完整的锁查询见 rt_chk 的行为（访问时会 die）。 */
Value rt_smoke_locked(Value v)
{
    return rt_int(rt_q_slotstate(v) == 1 ? 1 : 0);
}

/* smoke.type(v) -> 类型名（英文） */
Value rt_smoke_type(Value v)
{
    return rt_str(rt_q_typename(v));
}

/* ============ B. 内存级 ============ */

/* smoke.mem() -> [单元数, 字节, 模式] */
Value rt_smoke_mem(void)
{
    size_t bytes = 0;
    size_t cells = rt_mem_stats(&bytes);
    return mk3(rt_int((long long)cells),
               rt_int((long long)bytes),
               rt_int(rt_q_mode()));
}

/* smoke.leak() -> 强制 GC 回收的单元数（0=没垃圾；大=疑似泄漏）
 * 会真的跑一次完整 GC（@5/@6），其他模式是空操作。 */
Value rt_smoke_leak(void)
{
    size_t before = rt_mem_stats(NULL);
    rt_gc();
    size_t after = rt_mem_stats(NULL);
    long long freed = (long long)before - (long long)after;
    return rt_int(freed < 0 ? 0 : freed);
}

/* smoke.dangling() -> @self 已释放登记表 [条数, 容量] */
Value rt_smoke_dangling(void)
{
    size_t n = 0, cap = 0;
    rt_q_freed(&n, &cap);
    return mk2(rt_int((long long)n), rt_int((long long)cap));
}

/* smoke.roots() -> GC 根数 */
Value rt_smoke_roots(void)
{
    return rt_int((long long)rt_q_roots());
}

/* smoke.heap() -> [错误数, 悬垂条数, 根数, 模式, 字节]（一次出全体检） */
Value rt_smoke_heap(void)
{
    size_t bytes = 0;
    size_t cells = rt_mem_stats(&bytes);
    size_t fn = 0, fcap = 0;
    long long gcmin = 0, gcmaj = 0;
    rt_q_freed(&fn, &fcap);
    rt_q_gcstats(&gcmin, &gcmaj);
    Value l = rt_list_new();
    rt_push(&l, rt_int(rt_q_errors()));
    rt_push(&l, rt_int((long long)fn));
    rt_push(&l, rt_int((long long)rt_q_roots()));
    rt_push(&l, rt_int(rt_q_mode()));
    rt_push(&l, rt_int((long long)bytes));
    rt_push(&l, rt_int((long long)cells));
    rt_push(&l, rt_int(gcmin));
    rt_push(&l, rt_int(gcmaj));
    return l;
}

/* smoke.gc_stats() -> dict：知命可观测性一手数据
 * 字段：live/bytes/mode/minor/major/pause_ms/promoted/intent_{none,frame,level,shared,graph} */
Value rt_smoke_gc_stats(void)
{
    size_t bytes = 0;
    size_t cells = rt_mem_stats(&bytes);
    long long gcmin = 0, gcmaj = 0, pause = 0, prom = 0;
    int ic[5] = {0, 0, 0, 0, 0};
    rt_q_gcstats(&gcmin, &gcmaj);
    rt_q_gc_lastpause(&pause);
    rt_q_gc_promoted(&prom);
    rt_q_intent_counts(ic);
    Value d = rt_dict_new();
    rt_dict_set(&d, rt_str("live"),        rt_int((long long)cells));
    rt_dict_set(&d, rt_str("bytes"),       rt_int((long long)bytes));
    rt_dict_set(&d, rt_str("mode"),        rt_int(rt_q_mode()));
    rt_dict_set(&d, rt_str("minor"),       rt_int(gcmin));
    rt_dict_set(&d, rt_str("major"),       rt_int(gcmaj));
    rt_dict_set(&d, rt_str("pause_ms"),    rt_int(pause));
    rt_dict_set(&d, rt_str("promoted"),    rt_int(prom));
    rt_dict_set(&d, rt_str("intent_none"),   rt_int(ic[0]));
    rt_dict_set(&d, rt_str("intent_frame"),  rt_int(ic[1]));
    rt_dict_set(&d, rt_str("intent_level"),  rt_int(ic[2]));
    rt_dict_set(&d, rt_str("intent_shared"), rt_int(ic[3]));
    rt_dict_set(&d, rt_str("intent_graph"),  rt_int(ic[4]));
    return d;
}

/* smoke.frame_end()：知命帧边界对齐——引擎每帧末调用，立即触发相位边界回收。
 * 让 GC 暂停只发生在帧间，绝不卡在帧内（配合 rt_phase_end 的"本帧无活动则跳过"）。 */
Value rt_smoke_frame_end(void)
{
    rt_phase_end();
    return rt_none();
}

/* ============ C. 运行时健康 ============ */

/* smoke.errors() -> rt_die 触发次数 */
Value rt_smoke_errors(void)
{
    return rt_int(rt_q_errors());
}

/* smoke.mode() -> 模式名 */
Value rt_smoke_mode(void)
{
    switch (rt_q_mode()) {
    case 0: return rt_str("normal");
    case 1: return rt_str("self");
    case 3: return rt_str("refcount");
    case 4: return rt_str("arena");
    case 5: return rt_str("gc");
    case 6: return rt_str("gen");
    default: return rt_str("unknown");
    }
}

/* smoke.selftest() -> [错误数, 悬垂数, 根数, 模式]（运行时摘要）
 * 注：全量自检（159 项）走 `gcc -DRT_SELF_TEST`，那是编译期的事。 */
Value rt_smoke_selftest(void)
{
    size_t fn = 0, fcap = 0;
    rt_q_freed(&fn, &fcap);
    return mk3(rt_int(rt_q_errors()),
               rt_int((long long)fn),
               rt_int(rt_q_mode()));
}

/* ============ D. 断言 ============ */

/* smoke.expect(条件, 文案)：假则打 ✗ 并计数，**不中断** */
Value rt_smoke_expect(Value cond, Value msg)
{
    long long ok = 0;
    if (IS_INT(cond))      ok = AS_INT(cond);
    else if (IS_BOOL(cond))ok = AS_BOOL(cond) ? 1 : 0;
    else if (IS_FLT(cond)) ok = AS_FLT(cond) != 0.0 ? 1 : 0;
    else                   ok = 1;   /* 非空即真 */
    if (!ok) {
        g_expect_fails++;
        printf("\xe2\x9c\x97 %s\n", rt_str_of(msg));   /* ✗ */
    }
    return rt_int(ok ? 1 : 0);
}

/* smoke.require(条件, 文案)：假则立即中断 */
Value rt_smoke_require(Value cond, Value msg)
{
    long long ok = 0;
    if (IS_INT(cond))      ok = AS_INT(cond);
    else if (IS_BOOL(cond))ok = AS_BOOL(cond) ? 1 : 0;
    else if (IS_FLT(cond)) ok = AS_FLT(cond) != 0.0 ? 1 : 0;
    else                   ok = 1;
    if (!ok) {
        g_expect_fails++;
        fprintf(stderr, "运行时错误: 断言失败：%s\n", rt_str_of(msg));
        exit(1);
    }
    return rt_int(1);
}
