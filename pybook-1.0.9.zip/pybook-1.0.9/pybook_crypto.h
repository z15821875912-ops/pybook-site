/* PYbook 标准库：crypto 加密模块的内部接口（实现见 pybook_crypto.c）。
 *
 * 这里只放「字节级」原语；语言层（crypto.摘要 / crypto.派生 / crypto.加密 …）
 * 在 pybook_crypto.c 里做 UTF-8/hex 的转换后暴露。
 *
 * 全部是自实现，不依赖 OpenSSL：
 *   - SHA-256   （FIPS 180-4）
 *   - HMAC      （RFC 2104）
 *   - PBKDF2    （RFC 2898，HMAC-SHA256 当 PRF）
 *   - ChaCha20  （RFC 8439）
 *   - 密码学随机（Windows: BCryptGenRandom；POSIX: /dev/urandom）
 *
 * 为什么自实现：项目要能在 MinGW + MSVC + Linux + macOS 上无依赖编译，
 * 而且这些算法本身不长，自己写反而能保证每个平台行为完全一致
 * （OpenSSL 的版本差异会让「同样的口令在不同机器上派生出的密钥不同」这种事很难查）。
 */
#ifndef PYBOOK_CRYPTO_H
#define PYBOOK_CRYPTO_H

#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

/* SHA-256：out 32 字节 */
void cr_sha256(const unsigned char *data, size_t len, unsigned char out[32]);

/* HMAC-SHA256：out 32 字节 */
void cr_hmac_sha256(const unsigned char *key, size_t klen,
                    const unsigned char *data, size_t dlen,
                    unsigned char out[32]);

/* PBKDF2-HMAC-SHA256：outlen 字节 */
void cr_pbkdf2_sha256(const unsigned char *pw, size_t pwlen,
                      const unsigned char *salt, size_t slen,
                      unsigned long iters, unsigned char *out, size_t outlen);

/* ChaCha20（RFC 8439）：key 32 字节、nonce 12 字节、32 位块计数器。
 * in/out 可以是同一个指针（原地加密）。 */
void cr_chacha20(const unsigned char key[32], const unsigned char nonce[12],
                 unsigned long counter,
                 const unsigned char *in, unsigned char *out, size_t len);

/* 密码学随机字节。成功返回 0，失败返回 -1。 */
int  cr_random(unsigned char *buf, size_t len);

/* hex 编码（小写）。out 需要 2*len+1 字节。 */
void cr_hex(const unsigned char *in, size_t len, char *out);

/* hex 解码。成功返回字节数，失败返回 -1（奇数长度或非法字符）。 */
int  cr_unhex(const char *in, unsigned char *out, size_t outcap);

/* 常量时间比较：相等返回 1，否则 0（防时序侧信道）。 */
int  cr_equal(const unsigned char *a, const unsigned char *b, size_t n);

#ifdef __cplusplus
}
#endif

#endif /* PYBOOK_CRYPTO_H */
