# -*- coding: utf-8 -*-
"""_mt_extract.py -- mechanically extract pybook's special-function math block
from pybook_lib.c into _mtlib.h, so the accuracy/speed harness compares the
*real* implementation (no hand re-typing).

We grab each wanted top-level definition by name (declaration line -> closing
brace at column 0). Everything grabbed is pure double math: no rt_* / Value
dependency, so it compiles standalone against libm.
"""
import io
import os
import re

BASE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(BASE, '..', 'pybook_lib.c')
DST = os.path.join(BASE, '_mtlib.h')

with io.open(SRC, encoding='utf-8') as f:
    lines = f.read().split('\n')


def grab_def(name):
    """Grab a top-level C definition of `name` by name.

    Start: the line whose stripped form begins with `double name(`,
    `static double name(` or `static const double name[`.
    End:   the last line of that definition (closing brace at column 0, or
           the end of a one-line definition).
    """
    start = None
    for i, ln in enumerate(lines):
        st = ln.strip()
        if (st.startswith('double %s(' % name)
                or st.startswith('static double %s(' % name)
                or st.startswith('static const double %s[' % name)):
            start = i
            break
    if start is None:
        raise SystemExit('definition not found: %s' % name)

    # one-liner? "double f(...) { ... }" all on one line
    if '}' in lines[start] and lines[start].count('{') >= lines[start].count('}'):
        return [lines[start]]

    depth = 0
    for j in range(start, len(lines)):
        depth += lines[j].count('{') - lines[j].count('}')
        if depth <= 0 and j > start:
            return lines[start:j + 1]
    raise SystemExit('unterminated definition: %s' % name)


WANTED = [
    # order matters: helpers must precede their users
    'LG7', 'lanczos_x', 'gamma_pos',
    'lib_gamma', 'lib_lgamma', 'ig_series', 'ig_cfrac',
    'ig_series_half', 'ig_cfrac_half',
    'lib_gammap', 'lib_gammq',
    'lib_erf', 'lib_erfc', 'lib_zeta',
]

parts = []
for fn in WANTED:
    blk = grab_def(fn)
    for ln in blk:
        if re.search(r'\b(rt_|Value|RtTensor|lib_num|lib_die|ns_|printf)\b', ln):
            raise SystemExit('block %s touches runtime:\n%s' % (fn, ln))
    parts.append((fn, blk))

out = [
    '/* _mtlib.h -- AUTO-EXTRACTED from pybook_lib.c by _mt_extract.py.',
    ' * DO NOT EDIT BY HAND.',
    ' * Contains the REAL pybook math implementation (lib_erf/erfc/gamma/lgamma/zeta).',
    ' */',
    '#ifndef _MTLIB_H',
    '#define _MTLIB_H',
    '',
    '#include <math.h>',
    '',
    '#define LIB_PI 3.14159265358979323846',
    '#define LIB_SQRT2PI 2.5066282746310005',
    '#define LIB_EULER_GAMMA 0.5772156649015328606',
    '#define LIB_INV_SQRT_PI 0.5641895835477563',
    '',
]
for fn, blk in parts:
    out.append('/* ---- %s ---- */' % fn)
    out.extend(blk)
    out.append('')
out += ['#endif /* _MTLIB_H */', '']

with io.open(DST, 'w', encoding='utf-8', newline='\n') as f:
    f.write('\n'.join(out))

total = sum(len(b) for _, b in parts)
print('extracted %d functions / %d lines -> _mtlib.h' % (len(parts), total))
for fn, blk in parts:
    print('   %-12s %d lines' % (fn, len(blk)))
