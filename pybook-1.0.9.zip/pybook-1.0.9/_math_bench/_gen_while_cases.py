# -*- coding: utf-8 -*-
"""_gen_while_cases.py —— 把 while/continue 的两条用例写进 tests/cases.py

T29_while_ok               —— 正常语义（stdout 精确比对，六个数全钉死）
T29_continue_outside_err   —— continue 写在循环外 → 三段式报错
"""
import io
import os
import subprocess
import sys

BASE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(BASE)
PY = sys.executable

SPEC = [
    ('_mt_while.pybk', 'T29_while_ok', 'normal',
     'while(条件){...} 与 continue/继续：条件每轮开头求值一次（假条件一次都不进）；'
     'continue 跳到下一轮（不是跳出循环）；break 只跳一层；嵌套 while 里 break 只出内层；'
     'continue 在 rm.around 里同样有效。六个值全部精确比对'
     ),
    (None, 'T29_continue_outside_err', 'error',
     'continue/继续 写在循环外 → 三段式报错（和 break 一样，不静默当普通语句）'),
]

ERR_SRC = '@ pybk>测试>continue在循环外\nGOING:{\nvg.i = 0\ncontinue\n}STOP\n'


def run(src):
    env = {k: v for k, v in os.environ.items() if k != 'COLUMNS'}
    env['PYBOOK_NO_CACHE'] = '1'
    env['PYTHONIOENCODING'] = 'utf-8'
    p = subprocess.run([PY, 'pybk_main.py', src], cwd=ROOT, env=env,
                       capture_output=True, text=True, encoding='utf-8',
                       errors='replace', timeout=300)
    return (p.stdout.replace('\r\n', '\n'), p.stderr.replace('\r\n', '\n'),
            p.returncode)


CASES = os.path.join(ROOT, 'tests', 'cases.py')
cur = io.open(CASES, encoding='utf-8', newline='').read()
eol = '\r\n' if '\r\n' in cur else '\n'

added = []
for srcf, cid, kind, expect in SPEC:
    if srcf is None:
        path = os.path.join(BASE, '_mt_continue_outside.pybk')
        io.open(path, 'w', encoding='utf-8', newline='\n').write(ERR_SRC)
    else:
        path = os.path.join(BASE, srcf)
    src = io.open(path, encoding='utf-8', newline='').read()
    out, err, rc = run(path)
    if kind == 'normal':
        if rc != 0:
            raise SystemExit('%s 退出码 %d\nstderr: %s' % (cid, rc, err))
        if not out.strip():
            raise SystemExit('%s 没有输出？\nstderr: %s' % (cid, err))
        d = ("case(**{'id': %s, 'kind': %s, 'src': %s, 'out': %s, 'err': %s, "
             "'err_contains': [], 'exit': 0, 'expect': %s})"
             % (repr(cid), repr(kind), repr(src), repr(out), repr(err), repr(expect)))
    else:
        if rc == 0:
            raise SystemExit('%s 本该报错，却跑通了' % cid)
        # 三段式报错用例按仓库约定：**不写 err 字段**（措辞会改，锁死会一片红），
        # 只用 err_contains 锁「首行原文 + 有没有三段式」。
        # 编译期错误没有「程序异常退出，退出码 1」那一行（那是运行时错误才带的）。
        d = ("case(**{'id': %s, 'kind': %s, 'src': %s, 'out': '', "
             "'err_contains': ['continue 只能在循环内使用', '为什么：', '怎么改：'], "
             "'exit': 1, 'expect': %s})"
             % (repr(cid), repr(kind), repr(src), repr(expect)))
    # 按 id 覆盖：cases.py 里每条用例是一行 case(**{...})，
    # 同 id 就地替换（这样重跑生成器不会堆重复用例）。
    marker = "case(**{'id': '%s'" % cid
    lines = cur.split(eol)
    hit = [i for i, l in enumerate(lines) if l.startswith(marker)]
    if hit:
        lines[hit[0]] = d
        if len(hit) > 1:
            for i in reversed(hit[1:]):
                del lines[i]
        cur = eol.join(lines)
        action = '覆盖'
    else:
        cur = cur.rstrip('\n') + eol + eol + d + eol
        action = '加上'
    added.append(cid)
    print('  %s %s（stdout %d 行 / stderr %d 行）' % (action, cid, out.count('\n'), err.count('\n')))

if added:
    with io.open(CASES, 'w', encoding='utf-8', newline='') as f:
        f.write(cur)
    print('cases.py 已更新：%s' % '、'.join(added))
else:
    print('cases.py 无需改动')