# -*- coding: utf-8 -*-
"""_probe_while.py —— while/continue 的负例 + VM 后端报错检查。"""
import io
import os
import subprocess
import sys

ROOT = r'C:\Users\zhuli\Desktop\pybook'
TMP = os.path.join(ROOT, '_math_bench', '_probe')

NEG = {
'continue 在循环外': '''@ pybk>探针>continue在循环外
GOING:{
vg.i = 0
continue
}STOP
''',
'continue 在函数顶层': '''@ pybk>探针>continue在函数顶层
func f() {
    continue
}
GOING:{
vg.r = f()
}STOP
''',
'while 缺右括号': '''@ pybk>探针>while缺括号
GOING:{
while(i < 3 {
    vg.i = i + 1
}
}STOP
''',
'while 缺花括号': '''@ pybk>探针>while缺花括号
GOING:{
while(i < 3)
    vg.i = i + 1
}STOP
''',
'while 后缀了东西': '''@ pybk>探针>while后缀
GOING:{
while(i < 3) { }
vg.x = 1
}STOP
''',
}

os.makedirs(TMP, exist_ok=True)
env = {k: v for k, v in os.environ.items() if k != 'COLUMNS'}
env['PYBOOK_NO_CACHE'] = '1'
env['PYTHONIOENCODING'] = 'utf-8'

print('%-22s %-6s %s' % ('负例', '结果', '首条错误'))
print('-' * 100)
for name, src in NEG.items():
    p = os.path.join(TMP, 'neg_' + name + '.pybk')
    io.open(p, 'w', encoding='utf-8', newline='\n').write(src)
    r = subprocess.run([sys.executable, 'pybk_main.py', p], cwd=ROOT, env=env,
                       capture_output=True, text=True, encoding='utf-8',
                       errors='replace', timeout=300)
    if r.returncode == 0:
        print('%-22s %-6s （竟然过了？）' % (name, 'OK'))
    else:
        err = [e for e in (r.stderr or '').strip().split('\n') if e.strip()]
        print('%-22s %-6s %s' % (name, '拦住', ' / '.join(err[:3])[:130]))

print()
print('=' * 100)
print('VM 后端（.pybc）对 while/continue 的报错')
print('=' * 100)
import pybk_bc
for name, src in [('while', '''@ pybk>探针>vm
GOING:{
vg.i = 0
while(i < 3) {
    vg.i = i + 1
}
}STOP
'''), ('continue', '''@ pybk>探针>vm2
GOING:{
rm.around(3) {
    continue
}
}STOP
''')]:
    try:
        pybk_bc.compile_source(src, ROOT)
        print('  %-10s 竟然编过了' % name)
    except Exception as e:
        print('  %-10s %s' % (name, str(e)[:150]))
