# -*- coding: utf-8 -*-
"""_gen_t30_cases.py —— 把「空 字面量 + lambda 当值用」的用例写进 tests/cases.py

T30_none_lambda_ok —— C 后端锁住这两样的行为；
                      VM 侧的同一份程序由 tests/vm_parity.py 逐字对拍。
"""
import io
import os
import subprocess
import sys

BASE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(BASE)
PY = sys.executable

SRC = os.path.join(BASE, '_mt_none_lambda.pybk')
CID = 'T30_none_lambda_ok'
EXPECT = ('空 字面量：赋给变量、跟空比较、放进列表都成立；'
          'lambda 当值用：赋给变量后可以直接调用，函数值还能再套一层调用')


def run(src):
    env = {k: v for k, v in os.environ.items() if k != 'COLUMNS'}
    env['PYBOOK_NO_CACHE'] = '1'
    env['PYTHONIOENCODING'] = 'utf-8'
    p = subprocess.run([PY, 'pybk_main.py', src], cwd=ROOT, env=env,
                       capture_output=True, text=True, encoding='utf-8',
                       errors='replace', timeout=300)
    return (p.stdout.replace('\r\n', '\n'), p.stderr.replace('\r\n', '\n'),
            p.returncode)


CASES = os.path.join(ROOT, 'tests', 'cases.py')
cur = io.open(CASES, encoding='utf-8', newline='').read()
eol = '\r\n' if '\r\n' in cur else '\n'

src = io.open(SRC, encoding='utf-8', newline='').read()
out, err, rc = run(SRC)
if rc != 0:
    raise SystemExit('%s 退出码 %d\nstderr: %s' % (CID, rc, err))
if not out.strip():
    raise SystemExit('%s 没有输出？\nstderr: %s' % (CID, err))

d = ("case(**{'id': %s, 'kind': 'normal', 'src': %s, 'out': %s, 'err': %s, "
     "'err_contains': [], 'exit': 0, 'expect': %s})"
     % (repr(CID), repr(src), repr(out), repr(err), repr(EXPECT)))

marker = "case(**{'id': '%s'" % CID
lines = cur.split(eol)
hit = [i for i, l in enumerate(lines) if l.startswith(marker)]
if hit:
    lines[hit[0]] = d
    for i in reversed(hit[1:]):
        del lines[i]
    cur = eol.join(lines)
    action = '覆盖'
else:
    cur = cur.rstrip('\n') + eol + eol + d + eol
    action = '加上'

with io.open(CASES, 'w', encoding='utf-8', newline='') as f:
    f.write(cur)
print('  %s %s（stdout %d 行）' % (action, CID, out.count('\n')))
print('  期望输出: %r' % out)
