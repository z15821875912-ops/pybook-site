"""把 _vm_lib_calls.inc 里「可选参数」入口的元数从最小值改成真实参数个数。

判据：LIB_CALLS 里写成 (最少,最多) 元组的入口，C 函数的真实参数个数是最多。
表里若写最少，VM 弹的实参就少，函数高位参数是垃圾 —— 真 bug。
（_calc_c.py 的生成器当初把 lo 写进了表项、hi 写进了原型，两边对不上。）
"""
import re
import sys

sys.path.insert(0, '.')
import pybk_front as F

P = '_vm_lib_calls.inc'
raw = open(P, 'rb').read()
text = raw.decode('utf-8')
eol = '\r\n' if '\r\n' in text else '\n'

fixed = 0
for name, want in F.LIB_CALLS.items():
    if not isinstance(want, tuple):
        continue
    lo, hi = want
    pat = re.compile(r'(\{"%s",\s*)%d(,\s*\(\s*void\s*\*\))' % (re.escape(name), lo))
    m = pat.search(text)
    if not m or lo == hi:
        continue
    text = pat.sub(lambda mm: mm.group(1) + str(hi) + mm.group(2), text, count=1)
    fixed += 1
    print('  %-22s %d -> %d' % (name, lo, hi))

if fixed:
    open(P, 'wb').write(text.encode('utf-8'))
print('改了 %d 条' % fixed)
