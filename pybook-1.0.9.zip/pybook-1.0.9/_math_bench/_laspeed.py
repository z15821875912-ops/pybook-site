# -*- coding: utf-8 -*-
"""_laspeed.py -- LAPACK (via NumPy) vs PYbook's own linear algebra.

Reads the exact matrix that _laspeed.c dumped (_la_speed_in.txt), so both
sides work on the same input. Single-threaded on both sides (the C side is
single-thread by construction; here we pin BLAS to 1 thread).
"""
import io
import os
import sys
import time

for v in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS',
          'NUMEXPR_NUM_THREADS', 'VECLIB_MAXIMUM_THREADS'):
    os.environ[v] = '1'

import numpy as np                                          # noqa: E402

BASE = os.path.dirname(os.path.abspath(__file__))
IN = os.path.join(BASE, '_la_speed_in.txt')
if not os.path.exists(IN):
    IN = os.path.join(BASE, '..', '_la_speed_in.txt')

with io.open(IN, encoding='utf-8') as f:
    A = np.array([[float(x) for x in ln.split()] for ln in f if ln.strip()],
                 dtype=np.float64)
N = A.shape[0]
B = A + A.T
b = np.sin(np.arange(N) * 3.7) * 10.0

print('N = %d   numpy %s   BLAS threads pinned to 1' % (N, np.__version__))


def best(fn, rep=3):
    t = []
    for _ in range(rep):
        t0 = time.perf_counter()
        fn()
        t.append(time.perf_counter() - t0)
    return min(t) * 1e3


s = best(lambda: np.linalg.svd(A, full_matrices=False))
print('svd      LAPACK(dgesdd) %8.3f ms   (S[0]=%.6g)'
      % (s, np.linalg.svd(A, full_matrices=False)[1][0]))

print('qr       LAPACK(dgeqrf) %8.3f ms'
      % best(lambda: np.linalg.qr(A, mode='reduced')))

print('eig_sym  LAPACK(dsyevd) %8.3f ms   (v[0]=%.6g)'
      % (best(lambda: np.linalg.eigvalsh(B)), np.linalg.eigvalsh(B)[0]))

print('lstsq    LAPACK(dgelsd) %8.3f ms   (x[0]=%.6g)'
      % (best(lambda: np.linalg.lstsq(A, b, rcond=None)[0]),
         np.linalg.lstsq(A, b, rcond=None)[0][0]))

print('lu+solve LAPACK(dgesv)  %8.3f ms'
      % best(lambda: np.linalg.solve(A, b)))
