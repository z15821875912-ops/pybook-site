# -*- coding: utf-8 -*-
"""_survey2.py —— 带前缀的正确对比：PYbook 的 mt.*/np.*/mp.*/tb.* 覆盖到哪了。"""
import io
import math
import re
from collections import defaultdict

ROOT = r'C:\Users\zhuli\Desktop\pybook'
src = io.open(ROOT + r'\pybk_front.py', encoding='utf-8').read()
body = re.search(r'LIB_CALLS\s*=\s*\{(.*?)\n\}', src, re.S).group(1)
names = set(re.findall(r"'([A-Za-z_][A-Za-z_0-9.]*)'", body))

mt = sorted(x[3:] for x in names if x.startswith('mt.'))
np_ = sorted(x[3:] for x in names if x.startswith('np.'))
mp = sorted(x[3:] for x in names if x.startswith('mp.'))
tb = sorted(x[3:] for x in names if x.startswith('tb.'))
print('mt.* %d   np.* %d   mp.* %d   tb.* %d' % (len(mt), len(np_), len(mp), len(tb)))
print()
print('mt.* :', ' '.join(mt))
print()
print('np.* :', ' '.join(np_))
print()
print('mp.* :', ' '.join(mp))
print()

# Python math 的覆盖
math_names = [x for x in dir(math) if not x.startswith('_') and x not in ('e', 'pi', 'inf', 'nan', 'tau')]
missing = [x for x in math_names if x not in mt and x not in np_ and x not in mp]
print('=' * 60)
print('Python `math` 的 %d 个函数里，PYbook 没有对应实现的：%d 个' % (len(math_names), len(missing)))
print('  ' + '  '.join(missing))
print()

# 特殊函数（mt. 里有 zeta/erf/erfc/gamma/lgamma 吗）
SPECIAL = {
    '贝塞尔 J0/J1/Y0/Y1/I0/I1/K0/K1': ['bessel_j0', 'bessel_j1', 'bessel_y0', 'bessel_y1',
                                       'bessel_i0', 'bessel_i1', 'bessel_k0', 'bessel_k1'],
    'Airy / 椭圆积分 / Legendre / Hermite / Laguerre': ['airy_ai', 'airy_bi', 'elliptic_k',
                                                        'elliptic_e', 'legendre', 'hermite', 'laguerre'],
    'Dirichlet eta / Catalan / 逆伽马 / 指数积分 Ei': ['dirichlet_eta', 'catalan', 'gammaincinv',
                                                       'gammainccinv', 'exponential_integral'],
    'Lambert W / 合取阶乘 / 素数计数': ['lambertw', 'comb', 'perm', 'factorial'],
}
print('=' * 60)
print('特殊函数缺口（PYbook 现在只有 erf/erfc/gamma/lgamma/zeta 这几个）')
for k, v in SPECIAL.items():
    have = [x for x in v if x in mt or x in np_ or x in mp]
    miss = [x for x in v if x not in have]
    print('  %-46s 有 %d，缺 %d：%s' % (k, len(have), len(miss), ' '.join(miss)))
print()

# 随机分布
DIST = ['normal', 'uniform', 'binomial', 'poisson', 'exponential', 'gamma', 'beta',
        'chisquare', 'student_t', 'pareto', 'weibull', 'lognormal', 'rayleigh',
        'randn', 'randint', 'choice', 'permutation']
have_rd = sorted(x[3:] for x in names if x.startswith('rd.'))
print('=' * 60)
print('rd.* 现在只有：%s' % ' '.join(have_rd))
print('缺的分布/接口：%s' % ' '.join(d for d in DIST if d not in have_rd))
print()

# 复数 / 高精度 / 任意精度
for k in ['complex', 'cplx', 'z', 'mpmath', 'bigfloat', 'arbitrary', 'decimal', 'f128',
          'longdouble', 'quad']:
    hit = [x for x in names if k in x.lower()]
    if hit:
        print('  含 "%s" 的入口：%s' % (k, ' '.join(sorted(hit)[:12])))
print()

# 线性代数：mp.* / tb.* 里有 la_* 哪些
la_hits = sorted(x for x in names if any(k in x.lower() for k in ('svd', 'qr', 'eig', 'chol',
                                                                 'lstsq', 'solve', 'inv', 'det',
                                                                 'rank', 'schur', 'norm')))
print('=' * 60)
print('线代相关入口（%d 个）：' % len(la_hits))
print('  ' + ' '.join(la_hits))
