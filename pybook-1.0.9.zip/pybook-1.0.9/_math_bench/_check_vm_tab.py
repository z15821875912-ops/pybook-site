# -*- coding: utf-8 -*-
import io, re

s = io.open('_vm_lib_calls.inc', encoding='utf-8', newline='').read()
lines = s.split(chr(10))
n = re.search(r'G_LIB_CALLS_N\s+(\d+)', s).group(1)
cnt = sum(1 for l in lines if l.strip().startswith('{'))
print('G_LIB_CALLS_N =', n, ' 表项 =', cnt)
print('表头:', [l.strip() for l in lines[:3] if '库调用' in l])
print('np.* 表项 =', sum(1 for l in lines if l.strip().startswith('{"np.')))
print('rt_np_* 原型 =', len(re.findall(r'rt_np_[A-Za-z_0-9]+\s*\(', s)))
