# -*- coding: utf-8 -*-
import io, re
src = io.open(r'C:\Users\zhuli\Desktop\pybook\pybk_front.py', encoding='utf-8').read()
body = re.search(r'LIB_CALLS\s*=\s*\{(.*?)\n\}', src, re.S).group(1)
names = re.findall(r"'([A-Za-z_][A-Za-z_0-9.]*)'", body)

def has(*ks):
    return [n for n in names if any(k in n for k in ks)]

print('含 eig 的入口 :', has('eig'))
print('含 schur 的入口:', has('schur'))
print('pinv/null/kron/expm/logm/sqrtm :', has('pinv', 'null', 'kron', 'expm', 'logm', 'sqrtm'))
print('sort/cumsum/unique/argsort    :', has('sort', 'cumsum', 'unique', 'argsort'))
print('std/var                       :', has('std', 'var'))
print('clip/where/argmin/argmax      :', has('clip', 'where', 'argmin', 'argmax'))
print('concat/stack/reshape         :', has('concat', 'stack', 'reshape', 'transpose'))
print('sparse/稀疏                   :', has('sparse', '稀疏'))
print('complex/复数                  :', has('complex', '复数', 'cplx'))
print()
print('mp.rand_* :', [n for n in names if n.startswith('mp.rand')])
print('rd.*      :', [n for n in names if n.startswith('rd.')])
print()
print('hw.obj* 登记名:', [n for n in names if n.startswith('hw.obj')])
print('hw.* 里带 obj 的:', [n for n in names if 'obj' in n and n.startswith('hw.')])
