/* _mtcmp.c -- PYbook special functions vs C libm: accuracy + speed.
 *
 * Compares the REAL pybook implementation (mechanically extracted from
 * pybook_lib.c into _mtlib.h) against mingw64's libm:
 *
 *   accuracy: erf/erfc  -> libm erf/erfc
 *             gamma     -> libm tgamma
 *             lgamma    -> libm lgamma
 *   zeta    : no libm counterpart; dumped for a Python high-precision check
 *   speed   : ns/call for libm erf vs PYbook lib_erf (isolates algorithm cost)
 *
 * Output is ASCII on purpose (the Windows console is GBK).
 *
 *   gcc _mtcmp.c -o _mtcmp.exe -O2 -lm
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <windows.h>
#include "_mtlib.h"

/* ---------- ordered-int key so we can measure ULP distance ---------- */
static unsigned long long ordk(double d)
{
    unsigned long long i;
    memcpy(&i, &d, sizeof i);
    if (i & 0x8000000000000000ULL)
        return 0x8000000000000000ULL - (i & 0x7FFFFFFFFFFFFFFFULL);
    return 0x8000000000000000ULL + i;
}

static double ulpdiff(double a, double b)
{
    unsigned long long x = ordk(a), y = ordk(b);
    return (double)(x > y ? x - y : y - x);
}

typedef struct {
    double maxrel, relx;
    double maxulp, ulpx;
    double maxabs, absx;
    double maxrel_all;   /* relative error incl. near-zero ref (abs/|ref| w/ floor) */
    double relx_all;
    long long n;
    long long n_skip;
} Stat;

static void st_init(Stat *s)
{
    memset(s, 0, sizeof *s);
    s->maxrel = s->maxulp = s->maxabs = s->maxrel_all = -1.0;
}

static void st_add(Stat *s, double x, double py, double ref, int rel_ok)
{
    double d = fabs(py - ref);
    if (d > s->maxabs) { s->maxabs = d; s->absx = x; }
    if (rel_ok && ref != 0.0) {
        double r = d / fabs(ref);
        if (r > s->maxrel) { s->maxrel = r; s->relx = x; }
    } else {
        s->n_skip++;
    }
    {
        double r2 = d / (fabs(ref) > 1e-300 ? fabs(ref) : 1e-300);
        if (r2 > s->maxrel_all) { s->maxrel_all = r2; s->relx_all = x; }
    }
    {
        double u = ulpdiff(py, ref);
        if (u > s->maxulp) { s->maxulp = u; s->ulpx = x; }
    }
    s->n++;
}

static void st_print(const char *tag, const Stat *s)
{
    printf("%-8s n=%-9lld maxrel=%-11.4e @ x=%-18.13g maxulp=%-9.1f @ x=%-18.13g maxabs=%-11.4e\n",
           tag, s->n, s->maxrel, s->relx, s->maxulp, s->ulpx, s->maxabs);
    if (s->maxrel_all > s->maxrel && s->maxrel_all > 0)
        printf("         (incl near-zero ref: rel=%0.4e @ x=%g, skipped %lld pts)\n",
               s->maxrel_all, s->relx_all, s->n_skip);
}

/* ---------- timing ---------- */
static double now_sec(void)
{
    LARGE_INTEGER f, c;
    QueryPerformanceFrequency(&f);
    QueryPerformanceCounter(&c);
    return (double)c.QuadPart / (double)f.QuadPart;
}

#define BENCH_N 2000000

static volatile double g_sink;

/* Shared bench body: the argument evolves every iteration so the compiler
 * cannot fold the call away (a constant argument made gcc hoist erf() out
 * of the loop entirely and report 0 ns/call). */
#define BENCH_BODY(EXPR)                                   \
    double s = 0.0, x = 0.5, t0, t1;                       \
    int i;                                                  \
    t0 = now_sec();                                        \
    for (i = 0; i < BENCH_N; i++) {                         \
        x += 1.0e-7;                                       \
        s += (EXPR);                                       \
    }                                                      \
    t1 = now_sec();                                        \
    g_sink = s;                                            \
    return (t1 - t0) * 1e9 / (double)BENCH_N;               \

static double bench_erf_libm(void)    { BENCH_BODY(erf(x)) }
static double bench_erf_pybook(void)  { BENCH_BODY(lib_erf(x)) }
static double bench_erfc_libm(void)   { BENCH_BODY(erfc(x)) }
static double bench_erfc_pybook(void) { BENCH_BODY(lib_erfc(x)) }
static double bench_lgamma_libm(void) { BENCH_BODY(lgamma(x)) }
static double bench_lgamma_pybook(void) { BENCH_BODY(lib_lgamma(x)) }
static double bench_sqrt_libm(void)   { BENCH_BODY(sqrt(x)) }
static double bench_tgamma_libm(void) { BENCH_BODY(tgamma(x)) }
static double bench_tgamma_pybook(void) { BENCH_BODY(lib_gamma(x)) }


/* ---------- zeta dump (no libm counterpart) ---------- */
static void dump_zeta(void)
{
    static const double SS[] = {
        2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0, 10.0, 12.0, 15.0, 20.0,
        25.0, 30.0, 40.0, 50.0, 100.0, 1.5, 1.2, 1.1, 1.05, 1.01, 1.005,
        1.001, 1.0001, 0.5, -1.0, 2.5, 3.5, 7.5, 11.5
    };
    size_t i;
    for (i = 0; i < sizeof SS / sizeof SS[0]; i++) {
        double s = SS[i];
        double v = lib_zeta(s);
        printf("ZETA %.17g %.17g\n", s, v);
    }
}

/* ---------- point dump so Python can arbitrate with its own libm ---------- */
static void dump_points(void)
{
    static const double PX[] = {
        0.0, 1e-300, 1e-162, 1e-160, 1e-8, 1e-4, 0.1, 0.2, 0.3, 0.5, 1.0, 1.5,
        2.0, 2.5, 3.0, 4.0, 5.0, 6.0, 8.0, 12.0, 20.0, 26.0, 27.0, 30.0,
        100.0, 142.0, 142.5, 150.0, 171.0
    };
    size_t k;
    for (k = 0; k < sizeof PX / sizeof PX[0]; k++) {
        double x = PX[k];
        printf("PT %.17g %.17g %.17g %.17g %.17g\n", x,
               lib_erf(x), lib_erfc(x), lib_gamma(x), lib_lgamma(x));
    }
}

int main(void)
{
    Stat s_erf, s_erfc, s_gam, s_lgam;
    int i;

    printf("=== PYbook lib_* vs C libm : ACCURACY ===\n");

    /* ---- erf / erfc ---- */
    st_init(&s_erf); st_init(&s_erfc);
    for (i = -60000; i <= 60000; i++) {
        double x = (double)i / 10000.0;          /* -6 .. 6 step 1e-4 */
        st_add(&s_erf, x, lib_erf(x), erf(x), 1);
        st_add(&s_erfc, x, lib_erfc(x), erfc(x), 1);
    }
    {   /* extremes: tails, underflow, tiny */
        static const double EX[] = {
            -30.0, -27.0, -26.0, -20.0, -12.0, -8.0, -6.0, -5.0, -4.0,
            -3.0, -2.0, -1.0, -0.5, -1e-8, -1e-100, -1e-300,
            0.0, 1e-300, 1e-100, 1e-8, 0.5, 1.0, 2.0, 3.0, 4.0, 5.0, 6.0,
            8.0, 12.0, 20.0, 26.0, 27.0, 30.0
        };
        size_t k;
        for (k = 0; k < sizeof EX / sizeof EX[0]; k++) {
            double x = EX[k];
            st_add(&s_erf, x, lib_erf(x), erf(x), 1);
            st_add(&s_erfc, x, lib_erfc(x), erfc(x), 1);
        }
    }
    st_print("erf", &s_erf);
    st_print("erfc", &s_erfc);

    /* ---- gamma ---- */
    st_init(&s_gam);
    for (i = 1; i <= 200000; i++) {              /* 0.00001 .. 2.0 step 1e-5 */
        double x = (double)i / 100000.0;
        st_add(&s_gam, x, lib_gamma(x), tgamma(x), 1);
    }
    for (i = 1; i <= 10000; i++) {               /* 2.0 .. 12.0 step 1e-3 */
        double x = 2.0 + (double)i / 1000.0;
        st_add(&s_gam, x, lib_gamma(x), tgamma(x), 1);
    }
    for (i = 1; i <= 342; i++) {                 /* half-integers up to 171.5 */
        double x = (double)i / 2.0;
        st_add(&s_gam, x, lib_gamma(x), tgamma(x), 1);
    }
    for (i = 1; i <= 41; i++) {                  /* negative half-integers */
        double x = -(double)i / 2.0;
        st_add(&s_gam, x, lib_gamma(x), tgamma(x), 1);
    }
    st_print("gamma", &s_gam);

    /* ---- lgamma ---- */
    st_init(&s_lgam);
    for (i = 1; i <= 200000; i++) {              /* log-spaced 1e-8 .. 1e8 */
        double t = (double)i / 200000.0;
        double x = pow(1e-8, 1.0 - t) * 1e8;     /* 1e-8 -> 1e8 */
        st_add(&s_lgam, x, lib_lgamma(x), lgamma(x), 1);
    }
    for (i = 1; i <= 342; i++) {
        double x = (double)i / 2.0;
        st_add(&s_lgam, x, lib_lgamma(x), lgamma(x), 1);
    }
    for (i = 1; i <= 41; i++) {
        double x = -(double)i / 2.0;
        st_add(&s_lgam, x, lib_lgamma(x), lgamma(x), 1);
    }
    st_print("lgamma", &s_lgam);

    printf("\n=== SPEED (ns/call, %d iterations) ===\n", BENCH_N);
    {
        double a = bench_erf_libm(), b = bench_erf_pybook();
        double c = bench_erfc_libm(), d = bench_erfc_pybook();
        double e = bench_lgamma_libm(), f = bench_lgamma_pybook();
        double g = bench_sqrt_libm();
        double h = bench_tgamma_libm(), ii = bench_tgamma_pybook();
        printf("sqrt   libm=%8.2f ns   (baseline: pure libm call cost)\n", g);
        printf("erf    libm=%8.2f ns   pybook=%8.2f ns   ratio=%6.2fx\n", a, b, b / a);
        printf("erfc   libm=%8.2f ns   pybook=%8.2f ns   ratio=%6.2fx\n", c, d, d / c);
        printf("lgamma libm=%8.2f ns   pybook=%8.2f ns   ratio=%6.2fx\n", e, f, f / e);
        printf("gamma  libm=%8.2f ns   pybook=%8.2f ns   ratio=%6.2fx\n", h, ii, ii / h);
    }

    printf("\n=== ZETA dump (for high-precision check) ===\n");
    dump_zeta();

    printf("\n=== POINT dump (x, erf, erfc, gamma, lgamma) ===\n");
    dump_points();

    printf("\n=== zeta speed (ms/call) ===\n");
    {
        static const double ZS[] = {2.0, 3.0, 10.0, 1.5, 1.1, 1.05, 1.01, 1.001, 1.0001};
        size_t k;
        for (k = 0; k < sizeof ZS / sizeof ZS[0]; k++) {
            double s = ZS[k], t0, t1;
            int rep = (s < 1.5) ? 5 : 200;
            t0 = now_sec();
            for (i = 0; i < rep; i++) { volatile double v = lib_zeta(s); (void)v; }
            t1 = now_sec();
            printf("zeta(%-8g) %10.4f ms/call\n", s, (t1 - t0) * 1e3 / (double)rep);
        }
    }
    return 0;
}
