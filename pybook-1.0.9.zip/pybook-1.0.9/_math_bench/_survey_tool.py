# -*- coding: utf-8 -*-
import io, os, re

ROOT = r'C:\Users\zhuli\Desktop\pybook'
spec = io.open(os.path.join(ROOT, 'PYBOOK_规格.md'), encoding='utf-8').read()
man = io.open(os.path.join(ROOT, '语法手册.md'), encoding='utf-8').read()

print('=' * 72)
print('一、关键字里有没有 while / continue / finally / throw / yield / set / tuple')
print('=' * 72)
kw = re.search(r'### 1\.5 关键字.*?\n```(.*?)```', spec, re.S)
kws = kw.group(1) if kw else ''
for w in ['while', 'continue', 'finally', 'throw', 'yield', 'set', 'tuple', 'global',
          'elif', 'match', 'switch', 'try', 'catch', 'onerror', 'for', 'break', 'func',
          'class', 'import', 'lambda', 'return']:
    print('  %-10s %s' % (w, '在关键字表里' if re.search(r'\b%s\b' % w, kws) else '不在'))

print()
print('=' * 72)
print('二、文档里对 while / continue 的说明')
print('=' * 72)
for kw2 in ['while', 'continue']:
    hits = [l.strip() for l in (spec + man).split('\n') if kw2 in l]
    print('  "%s" 出现 %d 处，前 6 条：' % (kw2, len(hits)))
    for h in hits[:6]:
        print('    ', h[:100])

print()
print('=' * 72)
print('三、工具链侧')
print('=' * 72)
CI = ['.github/workflows', '.gitlab-ci.yml', 'azure-pipelines.yml', '.circleci', 'Jenkinsfile']
print('  CI 配置：', [c for c in CI if os.path.exists(os.path.join(ROOT, c))] or '无')
print('  .gitignore：', '有' if os.path.exists(os.path.join(ROOT, '.gitignore')) else '无')

# 调试器：有没有交互式断点/单步
dbg = io.open(os.path.join(ROOT, 'rt_debug.c'), encoding='utf-8', errors='replace').read()
for kw3 in ['breakpoint', '单步', '断点', 'watchpoint', 'gdb', 'lldb']:
    print('  rt_debug.c 含 "%s": %s' % (kw3, '是' if kw3 in dbg else '否'))

# 有没有 formatter / linter / profiler
for tool in ['black', 'ruff', 'flake8', 'pylint', 'mypy', 'clang-format', 'gprof',
             'perf', 'valgrind', 'cProfile']:
    hits = []
    for dp, dn, fn in os.walk(ROOT):
        if any(x in dp for x in ('.git', 'rt_cache', 'build_tmp')):
            continue
        for f in fn:
            if tool in f:
                hits.append(os.path.join(dp, f))
    if hits:
        print('  找到 %-12s : %s' % (tool, hits[:3]))

# 覆盖率
print('  coverage 相关文件:', [f for dp, dn, fn in os.walk(os.path.join(ROOT, 'tests')) for f in fn
                          if 'cov' in f.lower()][:5] or '无')

print()
print('=' * 72)
print('四、模块系统：引用() 的能力边界')
print('=' * 72)
for l in man.split('\n'):
    if '引用' in l and ('目录' in l or '参数' in l or '包' in l):
        print('  ', l.strip()[:110])

print()
print('=' * 72)
print('五、IDE 并存情况')
print('=' * 72)
for f in ['ide.py', '编辑器.py', '编辑器.c']:
    p = os.path.join(ROOT, f)
    if os.path.exists(p):
        head = io.open(p, encoding='utf-8', errors='replace').read(400).split('\n')
        print('  %-12s %8d 字节  首行: %s' % (f, os.path.getsize(p), head[0][:60]))
old = os.path.join(ROOT, '归档')
for dp, dn, fn in os.walk(old):
    for f in fn:
        if 'IDE' in dp or 'ide' in f.lower():
            print('   归档里:', os.path.join(dp, f).replace(ROOT, '.'))
            break
    break
