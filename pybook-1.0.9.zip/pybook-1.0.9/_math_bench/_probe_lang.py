# -*- coding: utf-8 -*-
"""_probe_lang.py —— 语言核心特性实测探针：每个特性写一个小程序，编译+运行，看它到底行不行。"""
import io
import os
import subprocess
import sys

ROOT = r'C:\Users\zhuli\Desktop\pybook'
TMP = os.path.join(ROOT, '_math_bench', '_probe')

PROBES = {
'继承(单继承)': '''@ pybk>探针>继承
lb.基 {
    vg.值 = 1
    func 取() { ret self.值 }
}
lb.子 : 基 {
    func 取2() { ret self.值 + 1 }
}
GOING:{
vg.甲 = lb.子()
vg.r = 甲.取()
}STOP
''',
'静态方法': '''@ pybk>探针>静态
lb.工具 {
    静 func 加(a, b) { ret a + b }
    静 vg.常数 = 42
}
GOING:{
vg.r = lb.工具.加(1, 2)
}STOP
''',
'运算符重载': '''@ pybk>探针>运算符重载
lb.数 {
    vg.值 = 0
    func 加(其他) { ret self.值 }
}
GOING:{
vg.r = 1
}STOP
''',
'生成器 yield': '''@ pybk>探针>生成器
func 数() {
    vg.i = 0
    while(i < 3) {
        yield i
    }
}
GOING:{
vg.r = 1
}STOP
''',
'装饰器': '''@ pybk>探针>装饰器
func 装(f) {
    ret f
}
@装
func g() {
    ret 1
}
GOING:{
vg.r = 1
}STOP
''',
'async/await': '''@ pybk>探针>异步
GOING:{
vg.r = await 1
}STOP
''',
'finally': '''@ pybk>探针>finally
GOING:{
try {
    vg.r = 1
} catch e {
    vg.r = 2
} finally {
    vg.r = 3
}
}STOP
''',
'异常类型/重抛': '''@ pybk>探针>异常类型
GOING:{
try {
    vg.r = mt.zeta(1)
} catch e {
    if(e == "级数发散") {
        vg.r = 1
    }
    throw e
}
}STOP
''',
'set 集合': '''@ pybk>探针>集合
GOING:{
vg.s = {1, 2, 3}
vg.r = 1
}STOP
''',
'元组': '''@ pybk>探针>元组
GOING:{
vg.t = (1, 2)
vg.r = 1
}STOP
''',
'字符串方法式': '''@ pybk>探针>字符串方法
GOING:{
vg.r = "abc".upper()
}STOP
''',
'全局 global': '''@ pybk>探针>global
func f() {
    global g
    g = 1
}
GOING:{
vg.r = 1
}STOP
''',
'while 循环': '''@ pybk>探针>while
GOING:{
vg.i = 0
while(i < 3) {
    vg.i = i + 1
}
vg.r = i
}STOP
''',
'continue': '''@ pybk>探针>continue
GOING:{
vg.i = 0
while(i < 3) {
    vg.i = i + 1
    continue
}
vg.r = i
}STOP
''',
'闭包捕获': '''@ pybk>探针>闭包
func 外(n) {
    func 内() { ret n + 1 }
    ret 内
}
GOING:{
vg.f = 外(10)
vg.r = f()
}STOP
''',
'多返回值': '''@ pybk>探针>多返回值
func f() {
    ret 1, 2
}
GOING:{
vg.r = 1
}STOP
''',
'字典推导+推导式': '''@ pybk>探针>推导式
GOING:{
vg.偶 = [x for x in [1,2,3,4] if x % 2 == 0]
vg.表 = {k: v for k, v in {"a": 1}}
vg.r = 1
}STOP
''',
'嵌套函数+递归': '''@ pybk>探针>递归
func 阶乘(n) {
    if(n <= 1) {
        ret 1
    }
    ret n * 阶乘(n - 1)
}
GOING:{
vg.r = 阶乘(5)
}STOP
''',
}

os.makedirs(TMP, exist_ok=True)
env = {k: v for k, v in os.environ.items() if k != 'COLUMNS'}
env['PYBOOK_NO_CACHE'] = '1'
env['PYTHONIOENCODING'] = 'utf-8'

print('%-14s %-6s %s' % ('特性', '结果', '首条错误 / 说明'))
print('-' * 96)
for name, src in PROBES.items():
    p = os.path.join(TMP, name.replace('/', '_') + '.pybk')
    io.open(p, 'w', encoding='utf-8', newline='\n').write(src)
    r = subprocess.run([sys.executable, 'pybk_main.py', p], cwd=ROOT, env=env,
                       capture_output=True, text=True, encoding='utf-8',
                       errors='replace', timeout=300)
    if r.returncode == 0:
        print('%-14s %-6s %s' % (name, 'OK', (r.stdout or '').strip().replace('\n', ' / ')[:60]))
    else:
        err = (r.stderr or '').strip().split('\n')
        msg = ' / '.join([e for e in err if e.strip()][:2])[:150]
        print('%-14s %-6s %s' % (name, '缺', msg))
