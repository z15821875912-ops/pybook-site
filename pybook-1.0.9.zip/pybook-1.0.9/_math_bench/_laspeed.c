/* _laspeed.c -- PYbook's own linear algebra vs LAPACK (via NumPy), same matrix.
 *
 * Links pybook_la.c's core layer directly (no PYbook runtime): la_svd /
 * la_qr / la_eig_sym / la_lstsq are pure double* functions.
 *
 * Dumps the test matrix to _la_speed_in.txt so the Python side runs LAPACK on
 * *the same* input (one source of truth, no "both sides generated their own
 * random matrix and hopefully matched" risk).
 *
 *   gcc _laspeed.c pybook_la.c -o _laspeed.exe -O3 -march=native -lm
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <windows.h>
#include "../pybook_la.h"

#define N 200

static double now_sec(void)
{
    LARGE_INTEGER f, c;
    QueryPerformanceFrequency(&f);
    QueryPerformanceCounter(&c);
    return (double)c.QuadPart / (double)f.QuadPart;
}

/* deterministic matrix, reproducible in Python with the same formula.
 * The extra i*j*0.37 term is deliberate: sin(a+b) alone factorises into
 * u*v^T + p*q^T, i.e. rank exactly 2 -- a degenerate input that makes the
 * SVD/eigen timings meaningless and turns lstsq into a near-singular mess. */
static void fill(double *a, int m, int n)
{
    int i, j;
    for (i = 0; i < m; i++)
        for (j = 0; j < n; j++)
            a[(size_t)i * n + j] =
                sin(i * 12.9898 + j * 78.233 + i * j * 0.37) * 43758.5453;
}

int main(void)
{
    double *A = (double *)malloc(sizeof(double) * N * N);
    double *B = (double *)malloc(sizeof(double) * N * N);   /* symmetric */
    double *b = (double *)malloc(sizeof(double) * N);
    double *U = (double *)malloc(sizeof(double) * N * N);
    double *Vt = (double *)malloc(sizeof(double) * N * N);
    double *R = (double *)malloc(sizeof(double) * N * N);
    double *V = (double *)malloc(sizeof(double) * N * N);
    double *tau = (double *)malloc(sizeof(double) * N);
    double *S = (double *)malloc(sizeof(double) * N);
    double *vals = (double *)malloc(sizeof(double) * N);
    double *vecs = (double *)malloc(sizeof(double) * N * N);
    double *x = (double *)malloc(sizeof(double) * N);
    int    *piv = (int *)malloc(sizeof(int) * N);
    int     i, j, rep;
    double t0, t1, best;

    if (!A || !B || !b || !U || !Vt || !R || !V || !tau || !S || !vals || !vecs || !x) {
        fprintf(stderr, "oom\n");
        return 2;
    }

    fill(A, N, N);
    for (i = 0; i < N; i++)
        for (j = 0; j < N; j++)
            B[(size_t)i * N + j] = A[(size_t)i * N + j] + A[(size_t)j * N + i];
    for (i = 0; i < N; i++)
        b[i] = sin(i * 3.7) * 10.0;

    /* dump the exact input for the NumPy side */
    {
        FILE *f = fopen("_la_speed_in.txt", "w");
        if (!f) { fprintf(stderr, "cannot write _la_speed_in.txt\n"); return 2; }
        for (i = 0; i < N; i++)
            for (j = 0; j < N; j++)
                fprintf(f, "%.17g%c", A[(size_t)i * N + j], j == N - 1 ? '\n' : ' ');
        fclose(f);
    }

    printf("N = %d\n", N);

    /* ---- SVD (one-sided Jacobi) ---- */
    best = 1e30;
    for (rep = 0; rep < 3; rep++) {
        t0 = now_sec();
        la_svd(A, U, S, Vt, N, N, 60);
        t1 = now_sec();
        if (t1 - t0 < best) best = t1 - t0;
    }
    printf("svd      pybook %8.3f ms   (S[0]=%.6g)\n", best * 1e3, S[0]);

    /* ---- QR (Householder) ---- */
    best = 1e30;
    for (rep = 0; rep < 3; rep++) {
        t0 = now_sec();
        la_qr(A, R, V, tau, N, N);
        t1 = now_sec();
        if (t1 - t0 < best) best = t1 - t0;
    }
    printf("qr       pybook %8.3f ms\n", best * 1e3);

    /* ---- symmetric eigen (cyclic Jacobi) ---- */
    best = 1e30;
    for (rep = 0; rep < 3; rep++) {
        t0 = now_sec();
        la_eig_sym(B, vals, vecs, N, 100);
        t1 = now_sec();
        if (t1 - t0 < best) best = t1 - t0;
    }
    printf("eig_sym  pybook %8.3f ms   (v[0]=%.6g)\n", best * 1e3, vals[0]);

    /* ---- least squares (via SVD) ---- */
    best = 1e30;
    for (rep = 0; rep < 3; rep++) {
        t0 = now_sec();
        la_lstsq(A, b, x, N, N);
        t1 = now_sec();
        if (t1 - t0 < best) best = t1 - t0;
    }
    printf("lstsq    pybook %8.3f ms   (x[0]=%.6g)\n", best * 1e3, x[0]);

    /* ---- LU + solve ---- */
    best = 1e30;
    for (rep = 0; rep < 3; rep++) {
        double bb[N];
        t0 = now_sec();
        la_lu(A, R, piv, N);
        memcpy(bb, b, sizeof bb);
        la_lu_solve(R, piv, bb, N, 1);
        t1 = now_sec();
        if (t1 - t0 < best) best = t1 - t0;
    }
    printf("lu+solve pybook %8.3f ms\n", best * 1e3);

    free(A); free(B); free(b); free(U); free(Vt); free(R); free(V);
    free(tau); free(S); free(vals); free(vecs); free(x); free(piv);
    return 0;
}
