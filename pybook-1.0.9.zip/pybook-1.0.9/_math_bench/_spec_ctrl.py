# -*- coding: utf-8 -*-
import io
s = io.open(r'C:\Users\zhuli\Desktop\pybook\PYBOOK_规格.md', encoding='utf-8').read().split('\n')
keys = []
for i, l in enumerate(s, 1):
    if l.startswith('#'):
        keys.append((i, l.strip()))
for k, (i, t) in enumerate(keys):
    if t.startswith('### 4.2') or t.startswith('### 4.3') or t.startswith('### 3.2') or t.startswith('### 3.1'):
        j = keys[k + 1][0] if k + 1 < len(keys) else len(s) + 1
        print('>>>', t)
        for x in range(i - 1, min(j - 1, len(s))):
            print('%4d %s' % (x + 1, s[x]))
        print('-' * 70)
