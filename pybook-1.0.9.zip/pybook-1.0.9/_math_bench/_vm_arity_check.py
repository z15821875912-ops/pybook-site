"""核对 VM 库表（_vm_lib_calls.inc）的元数与 LIB_CALLS 的最大元数是否一致。

背景：_vm_lib_calls.inc 的表项 arity 决定 VM 弹几个实参、怎么调 C 函数。
C 函数的真实参数个数是「最多」那个（hi），少给的那几个由编译器补空盒。
表里若写成 lo，VM 就会拿垃圾当高位参数 —— 这是真 bug。
"""
import re
import sys

sys.path.insert(0, '.')
import pybk_front as F

t = open('_vm_lib_calls.inc', encoding='utf-8').read()
rows = {}
for m in re.finditer(r'\{"([^"]+)",\s*(\d+),', t):
    rows[m.group(1)] = int(m.group(2))

print('表项总数', len(rows))
bad = []
for name, want in F.LIB_CALLS.items():
    if not isinstance(want, tuple):
        continue
    lo, hi = want
    a = rows.get(name)
    if a is None:
        continue
    if a != hi:
        bad.append((name, lo, hi, a))
print('元数与 C 函数真实参数个数不符的表项：')
for name, lo, hi, a in bad:
    print('   %-22s LIB_CALLS=(%d,%d)  表里写的=%d' % (name, lo, hi, a))
print('合计', len(bad))
