# -*- coding: utf-8 -*-
"""_mtfinal.py —— PYbook 特殊函数的**权威判决**。

被测对象 = pybook_lib.c 里的**真实现**（机械抽取 -> _mtlib.h -> _mtlib.dll -> ctypes），
不是 Python 里另抄的一份公式。所以改了 C 实现，这个脚本立刻反映。

裁判 = Windows UCRT libm（Python 的 math 模块就是它，和 MSVC 同源）。

跑法：
    python -B _mt_extract.py
    gcc -shared -o _mtlib.dll _mtlib_dll.c -O3 -march=native -lm
    python -B _mtfinal.py
"""
import ctypes
import math
import os
import sys

BASE = os.path.dirname(os.path.abspath(__file__))
DLL = os.path.join(BASE, '_mtlib.dll')
if not os.path.exists(DLL):
    sys.exit('缺少 _mtlib.dll：先跑 _mt_extract.py 再编 _mtlib_dll.c')

_dll = ctypes.CDLL(DLL)
for _n in ('gamma', 'lgamma', 'erf', 'erfc', 'zeta'):
    _f = getattr(_dll, 'mtlib_' + _n)
    _f.argtypes = [ctypes.c_double]
    _f.restype = ctypes.c_double
    globals()['py_' + _n] = _f


def logspace(a, b, n):
    return [a ** (1.0 - i / n) * b ** (i / n) for i in range(n + 1)]


def sweep(fn, ref, xs, far_thresh=0.1):
    """两套指标：
       rel_far : |a-b|/|b|，只在 |b| > far_thresh（远离 lgamma 的零点）时统计
       abs_all : |a-b|，全部点（近零区唯一有意义的指标）"""
    far = (0.0, None)
    ab = (0.0, None)
    skip = 0
    for x in xs:
        try:
            a = fn(x)
            b = ref(x)
        except Exception:
            skip += 1
            continue
        if not (math.isfinite(a) and math.isfinite(b)):
            skip += 1
            continue
        d = abs(a - b)
        if d > ab[0]:
            ab = (d, x)
        if b != 0.0 and abs(b) > far_thresh:
            r = d / abs(b)
            if r > far[0]:
                far = (r, x)
    return far, ab, skip


print('=' * 74)
print('PYbook 特殊函数（pybook_lib.c 真实现）vs UCRT libm')
print('=' * 74)

ERF_XS = ([-6.0 + 1e-4 * i for i in range(120001)]
          + [1e-8, 1e-160, 1e-300, -1e-8, -1e-300])
ERFC_XS = ([-6.0 + 1e-4 * i for i in range(120001)]
           + [6.5, 8.0, 10.0, 12.0, 15.0, 20.0, 25.0, 26.0, 27.0])
GAM_XS = ([0.001 + 1e-5 * i for i in range(1200000)]
          + [0.5 * i for i in range(1, 343)]
          + [-0.5 * i for i in range(1, 42)]
          + [130.0 + 0.001 * i for i in range(42000)])
LG_XS = (logspace(1e-12, 1e8, 120000)
         + [0.001 + 1e-5 * i for i in range(120000)]
         + [0.5 * i for i in range(1, 343)]
         + [-0.5 * i for i in range(1, 42)])

print('%-8s %-14s %-14s %-14s %s'
      % ('函数', '最大相对误差', '@ x', '最大绝对误差', '@ x'))
for name, fn, ref, xs in (
        ('erf', py_erf, math.erf, ERF_XS),
        ('erfc', py_erfc, math.erfc, ERFC_XS),
        ('gamma', py_gamma, math.gamma, GAM_XS),
        ('lgamma', py_lgamma, math.lgamma, LG_XS)):
    (fr, frx), (ab, abx), skip = sweep(fn, ref, xs)
    print('%-8s %-14.3e %-14.6g %-14.3e %.6g'
          % (name, fr, frx, ab, abx))

print()
print('--- 曾经坏掉的两段（现在该有答案了）---')
print('%-12s %-24s %-24s %-24s' % ('z', 'pybook gamma', 'UCRT gamma', 'pybook lgamma'))
for z in (1e-300, 1e-160, 1e-100, 1e-16, 1e-8, 1.0, 140.0, 142.0, 142.5,
          150.0, 171.0, 171.5, 172.0):
    try:
        g = py_gamma(z)
    except Exception:
        g = float('nan')
    try:
        lg = py_lgamma(z)
    except Exception:
        lg = float('nan')
    try:
        tg = math.gamma(z)
    except Exception:
        tg = float('nan')
    print('%-12g %-24s %-24s %-24s' % (z, g, tg, lg))

print()
print('--- 相对误差（gamma / lgamma）---')
for z in (1e-16, 1e-8, 0.001, 0.5, 1.0, 2.0, 10.0, 100.0, 140.0, 142.5, 160.0, 171.0):
    try:
        g = py_gamma(z)
        tg = math.gamma(z)
        grel = abs(g - tg) / abs(tg) if math.isfinite(g) and math.isfinite(tg) else float('nan')
    except Exception:
        grel = float('nan')
    lg = py_lgamma(z)
    tl = math.lgamma(z)
    lrel = abs(lg - tl) / abs(tl) if tl else float('nan')
    print('z=%-10g gamma rel=%-12.3e lgamma rel=%-12.3e' % (z, grel, lrel))


# ---------------- zeta ----------------
# 参考：偶数 s 用精确闭式；靠近 1 用 Laurent 展开（Stieltjes 常数）；
#       其余用 N=10^6 的 Euler-Maclaurin（跟 pybook 的 N 规则不同）。
ZETA_EVEN = {2: (1, 6), 4: (1, 90), 6: (1, 945), 8: (1, 9450), 10: (1, 93555),
             12: (691, 638512875), 14: (2, 18243225), 16: (3617, 325641566250)}
STIELTJ = [0.5772156649015328606065120900824024310421,
           -0.0728158454836767248605863758749013191377,
           -0.0096903631928723184845303869672122964793,
           0.0020538344203033458661600465427533842854,
           0.0023253700654673000574681701775260680009,
           0.0007933238173010627017533348774444448307,
           -0.0002387693454301996098724218419080042777837,
           -0.000527289567057751046074097505478858281996,
           -0.000352123353803039509602052165001208741729,
           -0.00003439477441808804817791462379822739,
           0.000205332814909064794683722289237065302]


def zeta_ref(s):
    if s == int(s) and int(s) % 2 == 0 and int(s) in ZETA_EVEN:
        c, d = ZETA_EVEN[int(s)]
        return c * math.pi ** int(s) / d
    eps = s - 1.0
    if 0 < abs(eps) < 1e-3:
        v = 1.0 / eps
        for n, g in enumerate(STIELTJ):
            v += (-1) ** n * g * eps ** n / math.factorial(n)
        return v
    N = 1000000
    total = 0.0
    for i in range(1, N):
        total += float(i) ** (-s)
    t = float(N) ** (-s)
    total += 0.5 * t + t * N / (s - 1.0)
    ps = s
    BF = [1.0 / 12.0, -1.0 / 720.0, 1.0 / 30240.0,
          -1.0 / 1209600.0, 1.0 / 47900160.0, -691.0 / 1307674368000.0]
    for k in range(6):
        if k > 0:
            for i in range(2):
                ps *= (s + 2.0 * k - 1.0 + i)
        total += BF[k] * ps * (float(N) ** (-s - 2.0 * k - 1.0))
    return total


print()
print('--- zeta：pybook Euler-Maclaurin vs 独立参照 ---')
print('%-12s %-24s %-24s %-12s %s'
      % ('s', 'pybook', 'reference', 'rel err', 'N used'))
for s in (2.0, 4.0, 6.0, 8.0, 10.0, 1.5, 1.2, 1.1, 1.05, 1.01, 1.001, 1.0001):
    N = min(max(int(10.0 / (s - 1.0) + 16.0), 20), 4000000)
    v = py_zeta(s)
    r = zeta_ref(s)
    print('%-12g %-24.17g %-24.17g %-12.3e %d'
          % (s, v, r, abs(v - r) / abs(r), N))

print()
print('--- zeta N 上限截断区（s→1，N 被夹在 4,000,000）---')
for s in (1.000001, 1.0000001, 1.00000001, 1.0000000001, 1.000000000001):
    v = py_zeta(s)
    r = zeta_ref(s)
    print('%-14g pybook=%-24.17g ref=%-24.17g rel err=%.3e'
          % (s, v, r, abs(v - r) / abs(r)))
