/* _mtlib_dll.c — 把 pybook_lib.c 里抽出来的**真实现**编成 DLL，给 Python 用 ctypes 调。
 *
 * 为什么要绕这一圈：此前 _mtfinal.py 在 Python 里另抄了一份 pybook 的公式，
 * 改了 C 实现它就跟不上了 —— 两份实现漂移，测出来的数就不代表真东西。
 * 现在测量链路上只有一份实现：
 *     pybook_lib.c --(机械抽取)--> _mtlib.h --(本文件)--> _mtlib.dll --(ctypes)--> Python
 *
 *   gcc -shared -o _mtlib.dll _mtlib_dll.c -O3 -march=native -lm
 */
#include "_mtlib.h"

__declspec(dllexport) double mtlib_gamma(double z)  { return lib_gamma(z); }
__declspec(dllexport) double mtlib_lgamma(double z) { return lib_lgamma(z); }
__declspec(dllexport) double mtlib_erf(double x)   { return lib_erf(x); }
__declspec(dllexport) double mtlib_erfc(double x)  { return lib_erfc(x); }
__declspec(dllexport) double mtlib_zeta(double s)  { return lib_zeta(s); }
