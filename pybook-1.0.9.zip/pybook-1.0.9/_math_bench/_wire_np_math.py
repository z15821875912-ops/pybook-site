# -*- coding: utf-8 -*-
"""_wire_np_math.py —— 把 19 个 np.* 逐元素超越函数接进五张表。

    pybk_front.py      LIB_CALLS     名字 -> 参数个数
    pybk_code.py       LIB_C_NAMES   名字 -> C 函数名
    pybook_lib.h       原型
    _vm_lib_calls.inc  原型 + 分发表（VM 后端查表用）

pybk_front.py / pybk_code.py / pybook_lib.h 三处**已经手工接好了**（本脚本不碰），
这里只补 _vm_lib_calls.inc 的原型 + 表项 + 两处计数，然后逐条复查五处标记。

家法照 _wire_math3.py：原型按最多参数个数写，表项只登记最少个数。
**逐条幂等**：每条单独判存在再决定插不插。
"""
import io
import os
import re
import sys

BASE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(BASE)

# (前端名, 最少, 最多, C 函数名)
ALL = [
    ('np.exp',    1, 1, 'rt_np_exp'),
    ('np.log',    1, 1, 'rt_np_log'),
    ('np.log2',   1, 1, 'rt_np_log2'),
    ('np.log10',  1, 1, 'rt_np_log10'),
    ('np.expm1',  1, 1, 'rt_np_expm1'),
    ('np.log1p',  1, 1, 'rt_np_log1p'),
    ('np.tan',    1, 1, 'rt_np_tan'),
    ('np.atan',   1, 1, 'rt_np_atan'),
    ('np.cbrt',   1, 1, 'rt_np_cbrt'),
    ('np.erf',    1, 1, 'rt_np_erf'),
    ('np.erfc',   1, 1, 'rt_np_erfc'),
    ('np.gamma',  1, 1, 'rt_np_gamma'),
    ('np.lgamma', 1, 1, 'rt_np_lgamma'),
    ('np.abs',    1, 1, 'rt_np_abs'),
    ('np.floor',  1, 1, 'rt_np_floor'),
    ('np.ceil',   1, 1, 'rt_np_ceil'),
    ('np.round',  1, 1, 'rt_np_round'),
    ('np.sign',   1, 1, 'rt_np_sign'),
    ('np.pow',    2, 2, 'rt_np_pow'),
]


def rd(p):
    return io.open(os.path.join(ROOT, p), encoding='utf-8', newline='').read()


def wr(p, t):
    with io.open(os.path.join(ROOT, p), 'w', encoding='utf-8', newline='') as f:
        f.write(t)


P = '_vm_lib_calls.inc'
t = rd(P)
e = '\r\n' if '\r\n' in t else '\n'

decl_anchor = 'Value rt_np_sqrt(Value);' + e
row_anchor = '    {"np.zeros", 1, (void *)rt_np_zeros},' + e
if decl_anchor not in t or row_anchor not in t:
    raise SystemExit('%s: 锚点找不到（文件结构变了？）' % P)

todo_d = [x for x in ALL if ('Value %s(' % x[3]) not in t]
todo_r = [x for x in ALL if ('{"%s",' % x[0]) not in t]

if todo_d:
    i = t.index(decl_anchor) + len(decl_anchor)
    decls = ''.join('Value %s(%s);%s' % (c, ', '.join(['Value'] * hi), e)
                    for _n, _lo, hi, c in todo_d)
    t = t[:i] + decls + t[i:]
if todo_r:
    j = t.index(row_anchor) + len(row_anchor)
    rows = ''.join('    {"%s", %d, (void *)%s},%s' % (n, lo, c, e)
                   for n, lo, _hi, c in todo_r)
    t = t[:j] + rows + t[j:]

if todo_d or todo_r:
    # 表头注释里的计数 + G_LIB_CALLS_N 都要跟上真实表项数
    n_rows = len(re.findall(r'^\s*\{"', t, re.M))
    t = re.sub(r'(\d+) 个库调用', lambda m: '%d 个库调用' % n_rows, t, count=1)
    t = re.sub(r'#define G_LIB_CALLS_N \d+',
               '#define G_LIB_CALLS_N %d' % n_rows, t, count=1)
    wr(P, t)
    print('%s：补上原型 %d 条 / 表项 %d 条，总表项 %d（行尾 %s）'
          % (P, len(todo_d), len(todo_r), n_rows, 'CRLF' if e == '\r\n' else 'LF'))
else:
    print('%s：已齐全' % P)

# ---------------- 收尾复查：19 条 × 5 处标记 ----------------
front = rd('pybk_front.py')
code = rd('pybk_code.py')
hdr = rd('pybook_lib.h')
inc = rd(P)
bad = []
for n, lo, hi, c in ALL:
    for f, s, mark in (('pybk_front.py', front, "'%s'" % n),
                       ('pybk_code.py', code, "'%s': '%s'" % (n, c)),
                       ('pybook_lib.h', hdr, c + '('),
                       ('_vm_lib_calls.inc', inc, '{"%s", %d,' % (n, lo)),
                       ('_vm_lib_calls.inc', inc, 'Value %s(' % c)):
        if mark not in s:
            bad.append('%s 缺 %s 的 %r' % (f, n, mark))
if bad:
    print('\n'.join(bad))
    sys.exit(1)
print('  %d 个入口 × 5 处标记，全部齐全' % len(ALL))
