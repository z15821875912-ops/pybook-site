# -*- coding: utf-8 -*-
"""_gen_np_cases.py —— 把两个新用例编码进 tests/cases.py

    _mt_edge.pybk -> T22_special_edge_ok   （锁死修好的那三个 bug 的边界行为）
    _mt_np.pybk   -> T22_np_math_ok        （锁死新增的 19 个 np.* 批量入口）

做法照 _gen_math_cases.py：跑一遍拿真实 stdout，再原样编码成精确比对串。
逐条幂等：cases.py 里已经有同 id 的就跳过。
"""
import io
import os
import subprocess
import sys

BASE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(BASE)
PY = sys.executable

SPEC = [
    ('_mt_edge.pybk', 'T22_special_edge_ok', 'normal',
     '特殊函数边界：gamma/lgamma 在 0<z<1.1e-16（原来返回 inf）和 z>=142.4'
     '（中间幂溢出也返回 inf）两段现在都给出正确值；'
     'lgamma 在小 z 不再因除数左结合丢掉 1e-8 级精度'),
    ('_mt_np.pybk', 'T22_np_math_ok', 'normal',
     'np.* 批量超越函数：erf/erfc/gamma/lgamma 的批量值与 mt.* 逐个调用一致，'
     '外加 exp 族 / 三角 / cbrt / abs / floor / ceil / round / sign / pow'),
]


def run(src):
    env = {k: v for k, v in os.environ.items() if k != 'COLUMNS'}
    env['PYBOOK_NO_CACHE'] = '1'
    p = subprocess.run([PY, 'pybk_main.py', src], cwd=ROOT, env=env,
                       capture_output=True, text=True, encoding='utf-8',
                       errors='replace', timeout=300)
    return (p.stdout.replace('\r\n', '\n'), p.stderr.replace('\r\n', '\n'),
            p.returncode)


CASES = os.path.join(ROOT, 'tests', 'cases.py')
cur = io.open(CASES, encoding='utf-8', newline='').read()
eol = '\r\n' if '\r\n' in cur else '\n'

added = []
for srcf, cid, kind, expect in SPEC:
    if ("'id': '%s'" % cid) in cur:
        print('  已有 %s，跳过' % cid)
        continue
    path = os.path.join(BASE, srcf)
    src = io.open(path, encoding='utf-8', newline='').read()
    out, err, rc = run(path)
    if kind == 'normal' and rc != 0:
        raise SystemExit('%s 退出码 %d\nstderr: %s' % (cid, rc, err))
    if not out.strip():
        raise SystemExit('%s 没有输出，断言全没过？\nstderr: %s' % (cid, err))
    d = ("case(**{'id': %s, 'kind': %s, 'src': %s, 'out': %s, 'err': %s, "
         "'err_contains': [], 'expect': %s})"
         % (repr(cid), repr(kind), repr(src), repr(out), repr(err), repr(expect)))
    cur = cur.rstrip('\n') + eol + eol + d + eol
    added.append(cid)
    print('  加上 %s（stdout %d 行）' % (cid, out.count('\n')))

if added:
    with io.open(CASES, 'w', encoding='utf-8', newline='') as f:
        f.write(cur)
    print('cases.py 已更新：%s' % '、'.join(added))
else:
    print('cases.py 无需改动')
