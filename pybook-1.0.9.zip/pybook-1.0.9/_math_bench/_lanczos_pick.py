# -*- coding: utf-8 -*-
"""_lanczos_pick.py -- 挑一个真正准确的 lgamma/gamma 写法（别凭推导下结论）。

候选（每个都是**完整**实现，不是「形式×形状」的叉乘，避免配错）：

  1 now          pybook 现状：t=z+6.5, A=c0+Σc_n/(z+n-1)（左结合）, log 形式
  2 divfix       同 1，但除数写成 z+(n-1)
  3 nr_lg7       t=z+7.5, ser=c0+Σc_n/(z+n), A=ser/z, NR 的 log 形式
  4 gamma_log    t=z+6.5, A=c0+Σc_n/(z+n-1), 先算 Γ 再取 log
  5 gamma_log_nr t=z+7.5, ser, A=ser/z, 先算 Γ 再取 log
  6 gamma_log_divfix   4 + 反射（0<z<1 用 lgamma(z+1)-log z）

指标：
  rel_far   |a-b|/|b|，只在 |lgamma| > 0.1（远离零点）时统计
  abs_all   |a-b|，全部点（近零区唯一有意义的指标）
  rel_all   |a-b|/|b| 全部点（含零点附近，会爆）
裁判 = Python math.lgamma（Windows UCRT libm）。
"""
import math

LG7 = [0.99999999999980993, 676.5203681218851, -1259.1392167224028,
       771.32342877765313, -176.61502916214059, 12.507343278686905,
       -0.13857109526572012, 9.9843695780195716e-6, 1.5056327351493116e-7]
SQRT2PI = 2.5066282746310005


def _ser_left(z):
    """pybook 现在的除数写法：(z+i)-1.0，左结合。"""
    x = LG7[0]
    for i in range(1, 9):
        x += LG7[i] / (z + i - 1.0)
    return x


def _ser_paren(z):
    x = LG7[0]
    for i in range(1, 9):
        x += LG7[i] / (z + (i - 1.0))
    return x


def _ser_nr(z):
    x = LG7[0]
    for i in range(1, 9):
        x += LG7[i] / (z + float(i))
    return x


def _lg_gamma_then_log(t, A, z):
    """先算 Γ 再取 log：Γ 在 [1.46,∞) 上最小也有 0.885，不会接近 0，
    所以 log 不会像「先算 log 再相消」那样在零点附近丢精度。"""
    return math.log(SQRT2PI * (t ** (z - 0.5)) * math.exp(-t) * A)


def c_now(z):
    if z <= 0:
        return math.inf
    t = z + 6.5
    return math.log(SQRT2PI) + (z - 0.5) * math.log(t) - t + math.log(_ser_left(z))


def c_divfix(z):
    if z <= 0:
        return math.inf
    t = z + 6.5
    return math.log(SQRT2PI) + (z - 0.5) * math.log(t) - t + math.log(_ser_paren(z))


def c_nr_lg7(z):
    if z <= 0:
        return math.inf
    t = z + 7.5
    A = _ser_nr(z) / z
    return (z + 0.5) * math.log(t) - t + math.log(SQRT2PI * A)


def c_gamma_log(z):
    if z <= 0:
        return math.inf
    t = z + 6.5
    return _lg_gamma_then_log(t, _ser_paren(z), z)


def c_gamma_log_nr(z):
    if z <= 0:
        return math.inf
    t = z + 7.5
    A = _ser_nr(z) / z
    return _lg_gamma_then_log(t, A, z)


def c_gamma_log_divfix(z):
    if z <= 0:
        return math.inf
    if z < 1.0:                       # 反射到 z+1，避开小 z 的相消
        return c_gamma_log_divfix(z + 1.0) - math.log(z)
    t = z + 6.5
    return _lg_gamma_then_log(t, _ser_paren(z), z)


# ---------------- 最终方案（准备写进 pybook_lib.c 的那版） ----------------
LIB_SQRT2PI = 2.5066282746310005


def final_gamma_pos(z):
    """Γ(z)，z>0。z≳140 时先把 z 往下挪，连乘补回来（避开中间幂溢出）。"""
    acc = 1.0
    if z > 140.0:
        if z > 171.7:
            return math.inf
        while z > 140.0:
            acc *= (z - 1.0)
            z -= 1.0
    t = z + 6.5
    ser = _ser_paren(z)
    return acc * (LIB_SQRT2PI * (t ** (z - 0.5)) * math.exp(-t) * ser)


def final_lgamma_pos(z):
    """log|Γ(z)|，z>0。z<140 且不太小时先算 Γ 再取 log（避开过零处的相消）。"""
    if 1e-150 < z < 140.0:
        return math.log(final_gamma_pos(z))
    t = z + 6.5
    ser = _ser_paren(z)
    return math.log(LIB_SQRT2PI) + (z - 0.5) * math.log(t) - t + math.log(ser)


def final_gamma(z):
    if z > 0.0:
        return final_gamma_pos(z)
    s = math.sin(math.pi * z)
    if s == 0.0:
        return math.nan
    return math.pi / (s * final_gamma_pos(1.0 - z))


def final_lgamma(z):
    if z > 0.0:
        return final_lgamma_pos(z)
    s = math.sin(math.pi * z)
    if s == 0.0:
        return math.inf
    return math.log(math.pi / abs(s)) - final_lgamma_pos(1.0 - z)


CANDS = [
    ('1 now        (pybook 现状)', c_now),
    ('2 divfix     (只修除数结合)', c_divfix),
    ('3 nr_lg7     (NR 结构+LG7)', c_nr_lg7),
    ('4 gamma_log  (先Γ后log)', c_gamma_log),
    ('5 gamma_log_nr', c_gamma_log_nr),
    ('6 gamma_log_divfix+反射', c_gamma_log_divfix),
    ('7 FINAL      (最终方案)', final_lgamma),
]



def logspace(a, b, n):
    return [a ** (1.0 - i / n) * b ** (i / n) for i in range(n + 1)]


XS = (logspace(1e-12, 1e-2, 4000)          # 小 z：除零 bug 所在区
      + [0.001 + 0.0005 * i for i in range(20000)]   # 0.001..10
      + [0.5 * i for i in range(1, 343)]             # 半整数
      + logspace(10.0, 1e8, 30000))          # 大 z


def sweep(fn):
    far = (0.0, None)
    ab = (0.0, None)
    allrel = (0.0, None)
    for x in XS:
        try:
            a = fn(x)
            b = math.lgamma(x)
        except Exception:
            continue
        if not math.isfinite(a) or not math.isfinite(b):
            continue
        d = abs(a - b)
        if d > ab[0]:
            ab = (d, x)
        r = d / abs(b) if b else float('inf')
        if r > allrel[0]:
            allrel = (r, x)
        if abs(b) > 0.1 and r > far[0]:
            far = (r, x)
    return far, ab, allrel


print('lgamma 候选实现 vs UCRT math.lgamma（x ∈ [1e-12, 1e8]，%d 个采样点）' % len(XS))
print('%-30s %-12s %-11s %-12s %-11s %-12s %s'
      % ('候选', 'rel_far', '@x', 'abs_all', '@x', 'rel_all', '@x'))
for name, fn in CANDS:
    (fr, frx), (ab, abx), (ar, arx) = sweep(fn)
    print('%-30s %-12.3e %-11.4g %-12.3e %-11.4g %-12.3e %.4g'
          % (name, fr, frx, ab, abx, ar, arx))

print()
print('小 z 逐点（除零 bug 所在区）：UCRT = -ln(z) 附近')
print('%-30s %s' % ('候选', '  '.join('z=%.0e' % z for z in (1e-16, 1e-12, 1e-8, 1e-4))))
for name, fn in CANDS:
    row = []
    for z in (1e-16, 1e-12, 1e-8, 1e-4):
        try:
            v = fn(z)
        except Exception:
            v = float('nan')
        row.append('%9.5g' % v)
    print('%-30s %s' % (name, '  '.join(row)))
print('%-30s %s' % ('UCRT 参照', '  '.join('%9.5g' % math.lgamma(z)
                                            for z in (1e-16, 1e-12, 1e-8, 1e-4))))

print()
print('零点附近（lgamma(2)=0，lgamma(1.4616)=-0.1215）：绝对误差')
for name, fn in CANDS:
    row = []
    for x in (1.461632144968362, 1.9995, 2.0, 2.0005):
        try:
            a = fn(x)
            d = abs(a - math.lgamma(x))
        except Exception:
            d = float('nan')
        row.append('%.2e' % d)
    print('%-30s %s' % (name, '  '.join(row)))

# ---------------- gamma 本体：最终方案 vs UCRT math.gamma ----------------
print()
print('=' * 78)
print('gamma 本体：最终方案 vs UCRT math.gamma')
GX = ([0.001 + 0.001 * i for i in range(12000)]        # 0.001..12
      + [0.5 * i for i in range(1, 343)]              # 半整数 → 171
      + [-0.5 * i for i in range(1, 40)]              # 负半整数（反射分支）
      + [130.0 + 0.01 * i for i in range(4300)])      # 130..173（含溢出边界）


def sweep_g(fn):
    far = (0.0, None)
    ab = (0.0, None)
    for x in GX:
        try:
            a = fn(x)
            b = math.gamma(x)
        except Exception:
            continue
        if not math.isfinite(a) or not math.isfinite(b):
            continue
        d = abs(a - b)
        if d > ab[0]:
            ab = (d, x)
        if b != 0 and abs(b) > 1e-250:
            r = d / abs(b)
            if r > far[0]:
                far = (r, x)
    return far, ab


for name, fn in (('pybook 现状(左结合+pow)', c_now), ('最终方案', final_gamma)):
    if name.startswith('pybook'):
        def old_gamma(z):
            if z > 0:
                t = z + 6.5
                return math.sqrt(2 * math.pi) * (t ** (z - 0.5)) * math.exp(-t) * _ser_left(z)
            s = math.sin(math.pi * z)
            return math.pi / (s * old_gamma(1.0 - z))
        fn = old_gamma
    (fr, frx), (ab, abx) = sweep_g(fn)
    print('%-26s 相对误差 %.3e @ x=%.6g    绝对误差 %.3e @ x=%.6g'
          % (name, fr, frx, ab, abx))

print()
print('大 z 边界（142 附近就是 pow 中间量溢出的地方）：')
print('%-10s %-26s %-26s %s' % ('z', 'pybook 现状', '最终方案', 'UCRT'))
for z in (140.0, 141.0, 142.0, 142.5, 143.0, 150.0, 160.0, 171.0):
    def old_gamma(z):
        if z > 0:
            t = z + 6.5
            return math.sqrt(2 * math.pi) * (t ** (z - 0.5)) * math.exp(-t) * _ser_left(z)
        s = math.sin(math.pi * z)
        return math.pi / (s * old_gamma(1.0 - z))
    try:
        o = '%.8g' % old_gamma(z)
    except Exception:
        o = 'inf'
    print('%-10g %-26s %-26s %.8g' % (z, o, '%.8g' % final_gamma(z), math.gamma(z)))

