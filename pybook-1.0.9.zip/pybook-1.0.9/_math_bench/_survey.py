# -*- coding: utf-8 -*-
"""_survey.py —— 盘一盘 PYbook 现在到底有哪些入口，跟 Python/NumPy 的数学面比，缺口在哪。"""
import io
import math
import re
import sys
from collections import defaultdict

ROOT = r'C:\Users\zhuli\Desktop\pybook'

src = io.open(ROOT + r'\pybk_front.py', encoding='utf-8').read()
m = re.search(r'LIB_CALLS\s*=\s*\{(.*?)\n\}', src, re.S)
body = m.group(1)
names = re.findall(r"'([A-Za-z_][A-Za-z_0-9.]*)'", body)

by_pre = defaultdict(list)
for n in names:
    pre = n.split('.')[0] if '.' in n else '(顶层)'
    by_pre[pre].append(n)

print('=' * 66)
print('PYbook 库入口总数：%d   模块数：%d' % (len(names), len(by_pre)))
print('=' * 66)
for pre in sorted(by_pre, key=lambda p: -len(by_pre[p])):
    print('  %-10s %3d' % (pre, len(by_pre[pre])))

# ---- 数学面覆盖：Python math 模块 ----
math_names = [x for x in dir(math) if not x.startswith('_')]
have = set(names)
miss_math = sorted(x for x in math_names if x not in have)
print()
print('=' * 66)
print('Python `math` 模块 %d 个函数，PYbook 里**没有同名**的 %d 个：' % (len(math_names), len(miss_math)))
print('=' * 66)
print('  ' + '  '.join(miss_math))

# 关键单点函数单独点名（这些是真正被用得多的）
KEY = ['exp', 'log', 'log2', 'log10', 'pow', 'sqrt', 'cbrt', 'hypot', 'fmod',
       'sin', 'cos', 'tan', 'asin', 'acos', 'atan', 'atan2', 'sinh', 'cosh', 'tanh',
       'asinh', 'acosh', 'atanh', 'exp2', 'expm1', 'log1p', 'degrees', 'radians',
       'erf', 'erfc', 'gamma', 'lgamma', 'ceil', 'floor', 'trunc', 'round', 'isfinite',
       'isnan', 'isinf', 'copysign', 'fabs', 'frexp', 'ldexp', 'modf', 'nextafter',
       'comb', 'perm', 'factorial', 'isqrt', 'gcd', 'lcm', 'dist', 'prod', 'fsum',
       'fma', 'remainder', 'ulp']
miss_key = [x for x in KEY if x not in have]
print()
print('常用单点数学函数里缺 %d 个：%s' % (len(miss_key), '  '.join(miss_key)))

# ---- 特殊函数 ----
SPECIAL = ['bessel_j0', 'bessel_j1', 'bessel_y0', 'bessel_y1', 'bessel_i0', 'bessel_i1',
           'bessel_k0', 'bessel_k1', 'airy', 'airy_ai', 'airy_bi', 'legendre', 'chebyshev',
           'hermite', 'laguerre', 'gegenbauer', 'elliptic_k', 'elliptic_e', 'elliptic_pi',
           'zeta', 'eta', 'dirichlet_eta', 'liouville', 'sinc', 'lambertw', 'lambert_w']
miss_spec = [x for x in SPECIAL if x not in have]
print('特殊函数缺 %d 个：%s' % (len(miss_spec), '  '.join(miss_spec)))

# ---- 数值线性代数高级面 ----
LA = ['svd', 'qr', 'cholesky', 'eig', 'eigh', 'eigvals', 'eigvalsh', 'lstsq', 'solve',
      'inv', 'det', 'norm', 'cond', 'rank', 'pinv', 'lu', 'qr', 'null_space', 'orth',
      'kron', 'outer', 'inner', 'trace', 'expm', 'logm', 'sqrtm', 'power', 'schur',
      'rcond', 'residual', 'diagonal', 'tril', 'triu', 'eye', 'identity', 'diag',
      'hessenberg', 'hessenberg_similarity', 'adjoint', 'hermitian', 'transpose']
miss_la = [x for x in LA if x not in have and ('la.' + x) not in have]
print('线代高级面缺 %d 个：%s' % (len(miss_la), '  '.join(miss_la)))

# ---- NumPy ufunc 面 ----
np_ufunc = ['exp', 'log', 'sqrt', 'sin', 'cos', 'tan', 'arcsin', 'arccos', 'arctan',
            'sinh', 'cosh', 'tanh', 'arcsinh', 'arccosh', 'arctanh', 'abs', 'absolute',
            'sign', 'floor', 'ceil', 'round', 'trunc', 'exp2', 'expm1', 'log1p', 'log2',
            'log10', 'rint', 'reciprocal', 'positive', 'negative', 'square', 'cbrt',
            'maximum', 'minimum', 'clip', 'where', 'cumsum', 'cumprod', 'diff', 'sort',
            'argsort', 'unique', 'concatenate', 'stack', 'vstack', 'hstack', 'reshape',
            'transpose', 'dot', 'outer', 'inner', 'matmul', 'trace', 'det', 'inv',
            'linalg', 'percentile', 'quantile', 'median', 'mean', 'std', 'var', 'sum',
            'prod', 'min', 'max', 'argmin', 'argmax', 'any', 'all', 'searchsorted',
            'repeat', 'tile', 'pad', 'isin', 'isnan', 'isinf', 'isfinite', 'around',
            'real', 'imag', 'angle', 'conj', 'real_if_close', 'deg2rad', 'rad2deg',
            'logaddexp', 'logaddexp2', 'mod', 'remainder', 'fmod', 'divmod', 'hypot',
            'nextafter', 'spacing', 'copysign', 'float_power', 'power']
have_np = set('np.' + n for n in names)
miss_np = [x for x in np_ufunc if x not in have and 'np.' + x not in have_np]
print('NumPy ufunc/常用函数里缺 %d 个：%s' % (len(miss_np), '  '.join(miss_np)))

# ---- 随机数面 ----
rd = sorted(x for x in names if x.startswith('rd.'))
print()
print('随机数 rd.* 现有 %d 个：%s' % (len(rd), ' '.join(rd)))
np_random = ['random', 'randint', 'randn', 'normal', 'uniform', 'binomial',
             'poisson', 'exponential', 'gamma', 'beta', 'chisquare', 'shuffle',
             'permutation', 'choice', 'standard_normal', 'random_sample', 'bytes']
miss_rd = [x for x in np_random if 'rd.' + x not in have]
print('随机数缺 %d 个：%s' % (len(miss_rd), '  '.join(miss_rd)))
