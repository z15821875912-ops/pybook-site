# -*- coding: utf-8 -*-
import io, re, sys

s = io.open('pybk_front.py', encoding='utf-8').read()
m = re.search(r'LIB_CALLS\s*=\s*\{(.*?)\n\}', s, re.S)
body = m.group(1)
ents = re.findall(r"'np\.([A-Za-z_0-9]+)'", body)
print('pybk_front.py LIB_CALLS 里 np.* 入口数', len(ents))
print(sorted(ents))

c = io.open('pybk_code.py', encoding='utf-8').read()
m2 = re.search(r'LIB_C_NAMES\s*=\s*\{(.*?)\n\}', c, re.S)
names = re.findall(r"'np\.([A-Za-z_0-9]+)'", m2.group(1))
print('pybk_code.py LIB_C_NAMES 里 np.* 登记名', len(names))

h = io.open('pybook_lib.h', encoding='utf-8').read()
protos = re.findall(r'rt_np_([A-Za-z_0-9]+)\s*\(', h)
print('pybook_lib.h 里 rt_np_* 原型', len(protos))

inc = io.open('_vm_lib_calls.inc', encoding='utf-8').read()
tab = re.findall(r'np\.([A-Za-z_0-9]+)', inc)
print('_vm_lib_calls.inc 里 np.* 表项', len(tab))
n = re.search(r'G_LIB_CALLS_N\s+(\d+)', inc)
print('G_LIB_CALLS_N =', n.group(1) if n else '?')
