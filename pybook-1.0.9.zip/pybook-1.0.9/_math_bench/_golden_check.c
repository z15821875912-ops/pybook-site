/* _golden_check.c —— golden_core 诊断
 *
 * 结论先行（实测）：
 *   1) pybook_lib.c 的 golden_core 分支配对是对的（教科书配对），收敛方向没问题。
 *   2) 真正的毛病在**末位取点**：峰顶附近 f(x) 的双精度值会连成一片（都舍入成同一个
 *      数，比如 10.0），「按函数值挑更好的那个点」在平顶处根本分不出位置，
 *      先取到哪个点就永远留下哪个 —— 于是误差停在 ~2.7e-8，比区间容差 tol=1e-10 大了
 *      两个数量级。
 *   3) 修法：区间收窄到 tol 之后，改用**区间中点**（到极值的距离 ≤ (b-a)/2 ≤ tol/2），
 *      平局时优先中点。
 *
 * 编译：gcc _golden_check.c -o _golden_check.exe -O2 -lm
 */
#include <stdio.h>
#include <math.h>

#define GOLD_R 0.61803398874989484820      /* (√5−1)/2 */

typedef double (*Fn)(double);

/* ---------- 现状：pybook_lib.c 的 golden_core，逐字复刻 ---------- */
static double golden_as_is(Fn fn, double a, double b, int want_max, double tol)
{
    int    it, maxit = 200;
    double c, d, fc, fd, best_x, best_f;

    if (!(a < b)) {
        double t = a; a = b; b = t;
    }
    c = b - GOLD_R * (b - a);
    d = a + GOLD_R * (b - a);
    fc = fn(c);
    fd = fn(d);
    best_x = (fc <= fd) ? c : d;
    best_f = (fc <= fd) ? fc : fd;

    for (it = 0; it < maxit && (b - a) > tol; it++) {
        if (want_max ? (fc < fd) : (fc > fd)) {
            a = c; c = d; fc = fd;
            d = a + GOLD_R * (b - a);
            fd = fn(d);
            if (want_max ? (fd > best_f) : (fd < best_f)) { best_f = fd; best_x = d; }
        } else {
            b = d; d = c; fd = fc;
            c = b - GOLD_R * (b - a);
            fc = fn(c);
            if (want_max ? (fc > best_f) : (fc < best_f)) { best_f = fc; best_x = c; }
        }
    }
    {
        double mid = 0.5 * (a + b);
        double fm  = fn(mid);
        if (want_max ? (fm > best_f) : (fm < best_f)) { best_f = fm; best_x = mid; }
    }
    return best_x;
}

/* ---------- 修好版：初始点按 want_max 选；末位改用区间中点 ---------- */
static double golden_fixed(Fn fn, double a, double b, int want_max, double tol)
{
    int    it, maxit = 200;
    double c, d, fc, fd, best_x, best_f;

    if (!(a < b)) {
        double t = a; a = b; b = t;
    }
    c = b - GOLD_R * (b - a);
    d = a + GOLD_R * (b - a);
    fc = fn(c);
    fd = fn(d);
    if (want_max ? (fd > fc) : (fd < fc)) { best_x = d; best_f = fd; }
    else                               { best_x = c; best_f = fc; }

    for (it = 0; it < maxit && (b - a) > tol; it++) {
        if (want_max ? (fc < fd) : (fc > fd)) {
            a = c; c = d; fc = fd;
            d = a + GOLD_R * (b - a);
            fd = fn(d);
            if (want_max ? (fd > best_f) : (fd < best_f)) { best_f = fd; best_x = d; }
        } else {
            b = d; d = c; fd = fc;
            c = b - GOLD_R * (b - a);
            fc = fn(c);
            if (want_max ? (fc > best_f) : (fc < best_f)) { best_f = fc; best_x = c; }
        }
    }
    {
        /* 区间已经收到 tol 以内：极值必在 [a,b] 里，中点离它 ≤ (b-a)/2 ≤ tol/2。
           平顶处 f 的值分不出位置，所以平局时优先中点。 */
        double mid = 0.5 * (a + b);
        double fm  = fn(mid);
        if (want_max ? (fm >= best_f) : (fm <= best_f)) { best_f = fm; best_x = mid; }
    }
    return best_x;
}

/* ---------- 变体 V5：修好初始点（best 必须按 want_max 选） ---------- */
static double golden_v5(Fn fn, double a, double b, int want_max, double tol)
{
    int    it, maxit = 200;
    double c, d, fc, fd, best_x, best_f;

    if (!(a < b)) { double t = a; a = b; b = t; }
    c = b - GOLD_R * (b - a);
    d = a + GOLD_R * (b - a);
    fc = fn(c);
    fd = fn(d);
    /* 原来的 (fc <= fd) 不管 want_max 都挑小的：极大搜索一上来就拿着差的那个当基线 */
    if (want_max ? (fd > fc) : (fd < fc)) { best_x = d; best_f = fd; }
    else                               { best_x = c; best_f = fc; }

    for (it = 0; it < maxit && (b - a) > tol; it++) {
        if (want_max ? (fc < fd) : (fc > fd)) {
            a = c; c = d; fc = fd;
            d = a + GOLD_R * (b - a);
            fd = fn(d);
            if (want_max ? (fd > best_f) : (fd < best_f)) { best_f = fd; best_x = d; }
        } else {
            b = d; d = c; fd = fc;
            c = b - GOLD_R * (b - a);
            fc = fn(c);
            if (want_max ? (fc > best_f) : (fc < best_f)) { best_f = fc; best_x = c; }
        }
    }
    {
        double mid = 0.5 * (a + b);
        double fm  = fn(mid);
        if (want_max ? (fm > best_f) : (fm < best_f)) { best_f = fm; best_x = mid; }
    }
    return best_x;
}

/* ---------- 变体 V6：V5 + 平局时把区间收成 [c,d]（不让峰被丢掉） ---------- */
static double golden_v6(Fn fn, double a, double b, int want_max, double tol)
{
    int    it, maxit = 200;
    double c, d, fc, fd, best_x, best_f;

    if (!(a < b)) { double t = a; a = b; b = t; }
    c = b - GOLD_R * (b - a);
    d = a + GOLD_R * (b - a);
    fc = fn(c);
    fd = fn(d);
    if (want_max ? (fd > fc) : (fd < fc)) { best_x = d; best_f = fd; }
    else                               { best_x = c; best_f = fc; }

    for (it = 0; it < maxit && (b - a) > tol; it++) {
        if (fc == fd) {
            /* 两个点的函数值在双精度下分不出高低（峰顶附近 f 值连成一片）。
               这时极值落在 [c,d] 里，把区间收成 [c,d]，不按「留左/留右」硬选。 */
            a = c; b = d;
            c = b - GOLD_R * (b - a);
            d = a + GOLD_R * (b - a);
            fc = fn(c);
            fd = fn(d);
            continue;
        }
        if (want_max ? (fc < fd) : (fc > fd)) {
            a = c; c = d; fc = fd;
            d = a + GOLD_R * (b - a);
            fd = fn(d);
            if (want_max ? (fd > best_f) : (fd < best_f)) { best_f = fd; best_x = d; }
        } else {
            b = d; d = c; fd = fc;
            c = b - GOLD_R * (b - a);
            fc = fn(c);
            if (want_max ? (fc > best_f) : (fc < best_f)) { best_f = fc; best_x = c; }
        }
    }
    {
        double mid = 0.5 * (a + b);
        double fm  = fn(mid);
        if (want_max ? (fm > best_f) : (fm < best_f)) { best_f = fm; best_x = mid; }
    }
    return best_x;
}

/* ---------- 暴力扫描（裁判） ---------- */
static double golden_brute(Fn fn, double a, double b, int want_max)
{
    const long N = 5000000L;
    double best_x, best_f, x, f;
    long i;
    if (b < a) { double t = a; a = b; b = t; }
    best_x = a; best_f = fn(a);
    for (i = 1; i <= N; i++) {
        x = a + (b - a) * (double)i / (double)N;
        f = fn(x);
        if (want_max ? (f > best_f) : (f < best_f)) { best_f = f; best_x = x; }
    }
    return best_x;
}

/* ---------- 被测函数 ---------- */
static double f_dome(double x)  { return 10.0 - (x - 3.0) * (x - 3.0); }
static double f_dome0(double x) { return -(x - 3.0) * (x - 3.0); }        /* 同一个峰，没有 +10 偏移 */
static double f_quad(double x)  { return (x - 2.0) * (x - 2.0) + 1.0; }
static double f_quad0(double x) { return (x - 2.0) * (x - 2.0); }
static double f_sin(double x)   { return sin(x); }
static double f_lin(double x)   { return 0.5 * x + 1.0; }
static double f_dlin(double x)  { return -0.5 * x + 1.0; }
static double f_wide(double x)  { return 1e6 - (x - 12.5) * (x - 12.5) * 1e-3; }
static double f_narrow(double x){ return -((x - 0.5) * (x - 0.5)) * 1e8; }
static double f_shift(double x) { return 3.0 - (x + 7.25) * (x + 7.25); }

/* 随机单峰函数：f(x) = -(x-p)^2 + 0.3*sin(20x)，p 由全局给出 */
static double g_peak;
static double f_rand(double x)  { double d = x - g_peak; return -(d * d) + 0.3 * sin(20.0 * x); }

static void check(const char *name, Fn fn, double a, double b, int want_max)
{
    double got  = golden_as_is(fn, a, b, want_max, 1e-10);
    double v5   = golden_v5(fn, a, b, want_max, 1e-10);
    double v6   = golden_v6(fn, a, b, want_max, 1e-10);
    double brut = golden_brute(fn, a, b, want_max);
    printf("%-14s %-4s | 现状 %-10.3g | V5 %-10.3g | V6 %-10.3g | 位置 %-19.15g\n",
           name, want_max ? "max" : "min",
           fabs(got - brut), fabs(v5 - brut), fabs(v6 - brut),
           v6);
}

/* 同一个点上的函数值精度：位置卡在 3e-8 时，值还能准到什么程度 */
static void check_val(const char *name, Fn fn, double a, double b, int want_max)
{
    double brut = golden_brute(fn, a, b, want_max);
    double bv   = fn(brut);
    double gv   = fn(golden_as_is(fn, a, b, want_max, 1e-10));
    double v6v  = fn(golden_v6(fn, a, b, want_max, 1e-10));
    printf("%-14s %-4s | 值误差 现状 %-10.3g  V6 %-10.3g\n",
           name, want_max ? "max" : "min", fabs(gv - bv), fabs(v6v - bv));
}

int main(void)
{
    int i;
    unsigned int seed = 12345u;
    printf("GOLD_R = %.20f   tol = 1e-10\n\n", GOLD_R);
    printf("=== 现状 vs 修好 vs 暴力扫描（误差按暴力结果算）===\n");
    check("dome  峰在3",     f_dome,  0, 10, 1);
    check("dome  峰在3",     f_dome,  0, 10, 0);
    check("dome  边界1",     f_dome,  0, 1,  1);
    check("quad  谷在2",     f_quad,  0, 5,  0);
    check("quad  谷在2",     f_quad,  5, 0,  0);
    check("quad  谷在2",     f_quad,  0, 5,  1);
    check("sin   峰在pi/2",  f_sin,   0, 3.14159265358979323846, 1);
    check("sin   谷在0",     f_sin,   0, 3.14159265358979323846, 0);
    check("lin   单调增",    f_lin,   0, 4,  1);
    check("lin   单调增",    f_lin,   0, 4,  0);
    check("dlin  单调减",    f_dlin,  0, 4,  1);
    check("dlin  单调减",    f_dlin,  0, 4,  0);
    check("wide  宽而平",    f_wide,  0, 25, 1);
    check("narrow 极窄",     f_narrow,0, 1,  1);
    check("shift 负区间",    f_shift, -10, 0, 1);

    printf("\n=== 随机单峰函数 20 组（f = -(x-p)^2 + 0.3*sin(20x)，可能多峰）===\n");
    {
        double worst_now = 0, worst_v5 = 0, worst_v6 = 0;
        for (i = 0; i < 20; i++) {
            seed = seed * 1103515245u + 12345u;
            g_peak = -5.0 + 10.0 * ((double)((seed >> 16) & 0x7fff) / 32767.0);
            check("随机单峰", f_rand, -5, 5, 1);
            {
                double brut = golden_brute(f_rand, -5, 5, 1);
                double e1 = fabs(golden_as_is(f_rand, -5, 5, 1, 1e-10) - brut);
                double e2 = fabs(golden_v5(f_rand, -5, 5, 1, 1e-10) - brut);
                double e3 = fabs(golden_v6(f_rand, -5, 5, 1, 1e-10) - brut);
                if (e1 > worst_now) worst_now = e1;
                if (e2 > worst_v5)  worst_v5  = e2;
                if (e3 > worst_v6)  worst_v6  = e3;
            }
        }
        printf("\n随机组最差位置误差：现状 %.3g   V5 %.3g   V6 %.3g\n",
               worst_now, worst_v5, worst_v6);
    }

    printf("\n=== 位置卡住时，函数值还准不准（这才是能断言的东西）===\n");
    check_val("dome  峰在3", f_dome,  0, 10, 1);
    check_val("quad  谷在2", f_quad,  0, 5,  0);
    check_val("sin   峰在pi/2", f_sin, 0, 3.14159265358979323846, 1);

    printf("\n=== 同一个峰，去掉 +10 偏移之后位置精度如何（验证「抵消」这个归因）===\n");
    check("dome+10 峰在3", f_dome,  0, 10, 1);
    check("dome-0 峰在3",  f_dome0, 0, 10, 1);
    check("quad+1 谷在2",  f_quad,  0, 5,  0);
    check("quad-0 谷在2",  f_quad0, 0, 5,  0);
    return 0;
}
