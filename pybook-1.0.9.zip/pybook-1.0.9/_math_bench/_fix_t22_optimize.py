# -*- coding: utf-8 -*-
"""_fix_t22_optimize.py —— 重写 tests/cases.py 里的 T22_optimize_ok

起因（实测，见 _math_bench/_golden_check.c）：
    mt.golden_max(dome, 0, 10)（dome = 10-(x-3)^2）返回的位置离真峰差 2.66e-08，
    差过原断言的 1e-8。根因不是搜索写错了，而是**函数值的分辨率**：
    f(x)=10-(x-3)^2 在 |x-3| < 3e-8 时全部舍入成同一个 double 10.0，
    「比较 f(c) 和 f(d) 谁大」在峰顶附近已经失效，区间只能收到 ~3e-8。
    去掉常量偏移（写成 -(x-3)*(x-3)）位置精度立刻回到 3.2e-12。
    返回点的**函数值**则始终是精确最优的（与暴力扫描比，误差 0）。

所以断言改成断言「能做到的东西」：
    - 位置精度：改用无抵消的函数，1e-8 照样钉死（还能顺手钉住净峰/净谷）；
    - 带抵消的函数：断言函数值精确最优（1e-12），位置只做 1e-6 的粗查。
    这不是把断言放松，是把断言换到真正能测出实现好坏的那个量上。

跑法：python -B _math_bench\_fix_t22_optimize.py
"""
import io
import os
import subprocess
import sys

BASE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(BASE)
PY = sys.executable
CID = 'T22_optimize_ok'
SRCF = '_mt_optimize.pybk'

EXPECT = ('黄金分割：抛物线/倒抛物线/正弦的极值点都落在真值上；端点写反结果一致；'
          '容差变大结果变粗（说明可选参数 tol 真的起作用）；零宽区间不崩。'
          '位置断言用「无常量抵消」的函数（净峰/净谷，1e-8 钉得死）；'
          '带抵消的 dome/quad 只断言**函数值**精确最优（1e-12）——'
          '因为 10-(x-3)^2 在 |x-3|<3e-8 时 f 全舍入成同一个 10.0，'
          '位置分辨率被函数自身卡在 ~3e-8，这是值比较法的天花板，不是实现的问题'
          '（实测 _math_bench/_golden_check.c：位置 2.66e-08，函数值误差 0）')


def run(src):
    env = {k: v for k, v in os.environ.items() if k != 'COLUMNS'}
    env['PYBOOK_NO_CACHE'] = '1'
    p = subprocess.run([PY, 'pybk_main.py', src], cwd=ROOT, env=env,
                       capture_output=True, text=True, encoding='utf-8',
                       errors='replace', timeout=300)
    return (p.stdout.replace('\r\n', '\n'), p.stderr.replace('\r\n', '\n'),
            p.returncode)


CASES = os.path.join(ROOT, 'tests', 'cases.py')
cur = io.open(CASES, encoding='utf-8', newline='').read()
eol = '\r\n' if '\r\n' in cur else '\n'

path = os.path.join(BASE, SRCF)
src = io.open(path, encoding='utf-8', newline='').read()
out, err, rc = run(path)
if rc != 0:
    raise SystemExit('跑 %s 失败，退出码 %d\nstderr: %s' % (SRCF, rc, err))
if not out.strip():
    raise SystemExit('%s 没有输出，断言全没过？\nstderr: %s' % (SRCF, err))

d = ("case(**{'id': %s, 'kind': %s, 'src': %s, 'out': %s, 'err': %s, "
     "'err_contains': [], 'exit': 0, 'expect': %s})"
     % (repr(CID), repr('normal'), repr(src), repr(out), repr(err), repr(EXPECT)))

lines = cur.split(eol)
hit = [i for i, l in enumerate(lines) if l.startswith("case(**{'id': '%s'" % CID)]
if len(hit) != 1:
    raise SystemExit('在 cases.py 里找到 %d 处 %s，期望恰好 1 处' % (len(hit), CID))
lines[hit[0]] = d

with io.open(CASES, 'w', encoding='utf-8', newline='') as f:
    f.write(eol.join(lines))

print('%s 已重写，stdout %d 行：' % (CID, out.count('\n')))
for l in out.split('\n'):
    if l.strip():
        print('    ' + l)
