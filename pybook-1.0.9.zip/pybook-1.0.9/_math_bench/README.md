# `_math_bench/` —— PYbook 数学能力对拍台

回答一个问题：**「PYbook 的 math 能不能做到 C 的水平」**。
全部结论都由这里的对拍件实测得出，不是推断。

裁判统一用 **Windows UCRT libm**（Python 的 `math` 模块就是它，和 MSVC 同源）——
MSVC 的 libm 比 MinGW 的 libm 精度高，所以拿 UCRT 当裁判比拿 MinGW 当更严。
（MinGW 的 `erf(1e-300)` 自己就返回 0，拿它当裁判会把对的判成错的。）

线性代数一侧用 **NumPy 2.4.6**（底层就是 LAPACK），BLAS 线程锁到 1，两边都单线程。

**单一真相源**：特殊函数不是「手抄一份公式再比」，而是从 `pybook_lib.c` **机械抽取**真实现
→ `_mtlib.h` → 编成 DLL → Python 侧 ctypes 调**真实现**。测的就是跑的那份代码。

---

## 文件

| 文件 | 干什么 |
|---|---|
| `_mt_extract.py` | 从 `pybook_lib.c` **机械抽取** `lib_gamma/lgamma/erf/erfc/zeta` 等到 `_mtlib.h`（生成物）。不手抄，避免抄错导致测的不是真实现 |
| `_mtlib_dll.c` | 把抽取出来的真实现编成 DLL（`mtlib_gamma/lgamma/erf/erfc/zeta`），给 ctypes 调 |
| `_mtfinal.py` | 特殊函数的**权威判决**：ctypes 调 DLL 里的真实现，跟 UCRT 对比；附 zeta 的独立参照与 N 上限截断区 |
| `_mtcmp.c` | 特殊函数 **精度 + 速度** 对拍 C harness：pybook 自写实现 vs libm，扫网格 + 算 ULP 距离 |
| `_laspeed.c` | pybook 线代核心层（`pybook_la.c`）的**速度**：直接链核心层，测 `la_svd/la_qr/la_eig_sym/la_lstsq` |
| `_laspeed.py` | 同一矩阵上跑 LAPACK（NumPy），跟 C 侧对表 |
| `_mtbench.pybk` | PYbook **语言层**速度：`mt.*` 在 `rm.around` 循环里每次调用的真实成本 |
| `_lanczos_pick.py` | **7 种 Lanczos 候选写法评测**：小 z / 中 z / 半整数 / 大 z 四段，两套指标（rel_far 远离零点 / abs_all 全程） |
| `_golden_check.c` | `golden_core` 三方对照：现实现 / 暴力扫描 / 变体。定位「位置精度天花板」的根因 |
| `_wire_np_math.py` | `np.*` 19 个批量超越函数入口的接线（幂等，5 处表面各 35 项对齐） |
| `_gen_np_cases.py` | 把 `_mt_edge.pybk` / `_mt_np.pybk` 编码进 `tests/cases.py`（逐条幂等） |
| `_fix_t22_optimize.py` | 重写 `tests/cases.py` 里的 `T22_optimize_ok`（断言改成能达成的量） |
| `_count_np.py` / `_check_vm_tab.py` | 交叉校验：`np.*` 五处表面各多少项、VM 调用表与 `G_LIB_CALLS_N` 是否一致 |
| `_survey.py` / `_survey2.py` / `_survey3.py` | 覆盖面盘点：库入口按前缀分布，跟 Python `math` / NumPy / scipy 的数学面对比找缺口 |
| `_survey_lang.py` / `_probe_lang.py` / `_spec_ctrl.py` / `_spec_dump.py` / `_survey_tool.py` | 语言核心与工具链盘点：18 个语言特性逐个编译试跑 + 规格条款摘录 + CI/调试器/IDE/仓库卫生核查 |
| `_probe_while.py` / `_gen_while_cases.py` / `_mt_while.pybk` | `while`/`continue` 的负例探针与用例生成（写进 `tests/cases.py` 的 `T29_*`） |
| `_vm_probe.pybk` / `_vm_arity_check.py` / `_fix_vm_arity.py` | VM 后端拉平的探针与库表元数核对/修正（`mt.deriv` 等 7 条可选参数入口的 arity 写错） |
| `_mt_none_lambda.pybk` / `_gen_t30_cases.py` | `空` 字面量 + lambda 当值用的用例源码与生成器（`tests/cases.py` 的 `T30_*`） |
| `_exc_probe.pybk` | 异常补齐的**语义探针**（10 条路径：try/catch、finally 三路、throw 带类型、按类型捕获、类型不符外抛、重抛、handler 里再抛、错误类型()）—— C 与 VM 两边逐字节一致（各 678 字节） |
| `_exc_probe2.pybk` / `_exc_probe3.pybk` / `_exc_probe4.pybk` | 异常边界探针：for-in 里出错后的作用域还原 + onerror 兜底 / 类型不符且无外层（应带原消息退出 1）/ 裸 throw 写在 catch 外（应编译期拦） |
| `_mt_edge.pybk` / `_mt_np.pybk` / `_mt_optimize.pybk` / `_gm_probe3.pybk` | 回归用例的 PYbook 源码（`.pybk` 是物化产物，真相源在 `tests/cases.py`） |

---

## 跑法

```powershell
cd _math_bench

# 特殊函数：抽取 → 编 DLL → 跑
python -B _mt_extract.py
gcc -shared -o _mtlib.dll _mtlib_dll.c -O3 -march=native -lm
python -B _mtfinal.py            # 权威精度判决

# 精度 + 速度对拍
gcc _mtcmp.c -o _mtcmp.exe -O3 -march=native -lm
.\_mtcmp.exe

# 黄金分割三方对照
gcc _golden_check.c -o _golden_check.exe -O2 -lm
.\_golden_check.exe

# 线代速度
gcc _laspeed.c ..\pybook_la.c -o _laspeed.exe -O3 -march=native -lm
.\_laspeed.exe
python -B _laspeed.py

# 语言层速度（要从仓库根跑）
cd ..
python -B pybk_main.py _math_bench\_mtbench.pybk
```

`gcc` = `C:\Users\zhuli\mingw64\bin\x86_64-w64-mingw32-gcc.exe`。

---

## 结论摘要（2026-10-24 实测）

### 线性代数：**精度就是 LAPACK 水平，速度不是**

- 精度：NumPy 当裁判，**261 项检查全过，最大相对误差 2.108e-14**
  （SVD 2.1e-14 / 特征值 9.3e-15 / QR 4.7e-16 / Cholesky 2.0e-16 / det 3.9e-15 / rank 精确）
- 速度（200×200、单线程、同一矩阵）：

  | 算子 | pybook | LAPACK | 差距 |
  |---|---|---|---|
  | svd | 226 ms | 10.2 ms (dgesdd) | **22×** |
  | qr | 5.05 ms | 3.61 ms (dgeqrf) | 1.4× |
  | eig_sym | 207 ms | 2.10 ms (dsyevd) | **99×** |
  | lstsq | 273 ms | 4.92 ms (dgelsd) | **56×** |
  | lu+solve | 0.94 ms | 0.31 ms (dgesv) | 3.0× |

  差距的来源是算法档次：pybook 是教科书级 Jacobi（单边 Jacobi SVD / 循环 Jacobi 特征值），
  LAPACK 是分治三对角化 + 隐式 QR。

### 特殊函数：修完 3 个 bug 后，精度进到 1e-13~1e-15

最大相对误差（vs UCRT，**修前 → 修后**）：

| 函数 | 修前 | 修后 | 备注 |
|---|---|---|---|
| erf | **1.0**（x=1e-300 直接返回 0） | **1.045e-15** | 走 a=1/2 专用快路，顺带更准 |
| erfc | 7.213e-14 | **5.771e-15** | 深尾 376 → 49 ULP |
| gamma | **inf**（z ≳ 142.4） | **9.095e-14** | z≥171.7 时 Γ 本身溢出，inf 是对的 |
| lgamma | 5.832e-10 | **2.664e-14** | 过零处绝对误差 1.5e-15 |
| zeta | ≤1.0e-13 | ≤1.0e-13（未动） | s→1+ 时相对误差仍 2.4e-16，**没有精度悬崖** |

**修掉的 3 个 bug**（都在 `pybook_lib.c` 的 Lanczos 段）：

1. `lanczos_x` 里 `z + i - 1.0` 是**左结合** → `(z+1)-1.0`。z 很小时先算 `z+i`（舍入成 i）
   再减 1；z < 2⁻⁵³ 时分母直接变 0 → 除零 → `inf`。
   `mt.gamma` / `mt.lgamma` 在 `0 < z < 1.11e-16` 返回 **inf**（真值 1/z 完全可表示）。
   改成 `z + (double)(i-1)`。
2. `pow(t, z-0.5)` 这个**中间量**在 z ≳ 142.4 溢出 → `mt.gamma(z)` 在 z ≥ 142.4 返回
   **inf**，而 Γ(z) 本身一直可表示到 z=171.6（Γ(171)=7.26e306）。
   改成 z>140 时先下推到 140 再连乘补回来（`acc *= (z-1.0)`）。
3. `mt.erf` 在 `x = 1e-300` 返回 0（真值 1e-300）。x² 下溢后没走对那一段。

**一个被实测推翻的判断**：动手前用 `_lanczos_pick.py` 评了 **7 种候选写法**，
结论是**现状的 `t = z+6.5` 反而比教科书的 `t = z+7.5` 略准**（rel_far 2.857e-14 vs 3.637e-14）。
所以没有按最初的推断去改偏移，改的是真正的那条除数。
另一个候选「先算 Γ 再取 log」能把过零处绝对误差从 1.5e-15 降到 8.9e-16，但**慢一倍**，
于是保持快路径不换（判断与取舍都记在 `pybook_lib.c` 的注释里）。

### 速度：算法成本有输有赢，语言层几乎免费

C 层（`-O3 -march=native`，2M 次，同一窗口）：

| 函数 | libm | pybook | 比 |
|---|---|---|---|
| erf | 7.57 ns | 31.40 ns | 慢 4.15× |
| erfc | 20.41 ns | 35.05 ns | 慢 1.72× |
| gamma | 23.43 ns | 42.75 ns | 慢 1.82× |
| **lgamma** | 50.83 ns | **21.63 ns** | **快 2.3×** |

PYbook 语言层（3M 次，空循环 93 ms 作基线；跨次抖动 ~20%，别当精确值看）：

| | 总耗时 | 扣掉循环 | vs 同窗口 C 层 |
|---|---|---|---|
| mt.sqrt | 94 ms | ~0 | — |
| mt.erf | 203 ms | 37 ns/次 | C 层 31.4 ns → 语言层开销 ≈ 5 ns |
| mt.erfc | 172 ms | 26 ns/次 | C 层 35.1 ns（两套 harness 结构不同，跨 harness 比只对量级） |
| mt.lgamma | 156 ms | 21 ns/次 | C 层 21.6 ns → 语言层开销 ≈ 0 |
| mt.gamma | 188 ms | 32 ns/次 | C 层 42.8 ns（同上） |

结论：**差距来自算法本身，不是语言层**。`mt.*` 每次调用的运行时开销只有 0~12 ns
（两套 harness 结构不同、CPU 频率有抖动，所以跨 harness 的绝对差值只能看量级）。

### `mt.golden_min/max` 的**位置精度有天花板**（最容易误判成 bug）

搜索靠比较 `f(c)` / `f(d)` 谁大来收区间，而**函数值本身有分辨率**。
`_golden_check.c` 三方对照实测：

| 被求极值的函数 | 返回点的位置误差 | 返回点的函数值误差 |
|---|---|---|
| `10 - (x-3)^2`（带常量偏移） | **2.66e-08** | **0**（精确最优） |
| `-(x-3)^2`（去掉偏移） | 3.2e-12 | 0 |
| `(x-2)^2 + 1` | 8.74e-09 | 0 |
| `(x-2)^2`（去掉偏移） | 3.2e-12 | 0 |

原因：`10-(x-3)^2` 在 `|x-3| < 3e-8` 时 f 全部舍入成同一个 double `10.0`，
「谁大谁小」在峰顶附近已经失效，区间只能收到 ~3e-8。
**要位置精度就把被求极值的函数写成峰顶附近不发生抵消的形状；要断言结果就断言函数值。**

（另修了 `golden_core` 一处真 bug：初始「最好点」不分 want_max，
原来的 `(fc <= fd) ? c : d` 不管求极小还是极大都挑小的那个。）

### zeta 性能（s→1 时 N=10/(s-1) 线性增长）

ζ(2) 0.0010 ms → ζ(1.01) 0.024 ms → ζ(1.001) 0.26 ms → ζ(1.0001) 2.5 ms。
精度不受影响：s=1+1e-12 时相对误差仍只有 2.4e-16（**没有精度悬崖**，实测推翻过这个猜想）。
s ≤ 1 直接报错，不做解析延拓（ζ(-1) = -1/12 取不到）。

---

## 复现提示

- **测性能绝对值跨运行不可比**（动态升频 + 并发进程）。只信同一窗口内的相对比较。
- `_mtcmp.exe` 里的 `erf` 基准一开始报 0 ns/次，是 gcc 把常量参数的 `erf()` 折叠掉了；
  现在用逐次变化的参数 + `volatile` 汇出兜底。
- `_laspeed.c` 的测试矩阵**不能**用 `sin(i*a + j*b)`：那个式子能拆成 `u·vᵀ + p·qᵀ`，
  矩阵恰好秩 2，会让 SVD/特征值计时失真、lstsq 变病态。现在多了 `i*j*0.37` 一项破掉这个结构。
- `rt_cache/` 里预编译的 `.o` 是**游戏模式**（`.sdl-o3n.o`）的产物；普通程序走的是
  `-o3n.o`（无 `.sdl`），两者不通用。
