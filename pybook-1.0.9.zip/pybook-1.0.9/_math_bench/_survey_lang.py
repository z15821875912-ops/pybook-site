# -*- coding: utf-8 -*-
"""_survey_lang.py —— 语言核心 / 工具链的能力盘点：有什么、缺什么。"""
import io
import os
import re

ROOT = r'C:\Users\zhuli\Desktop\pybook'

def read(p):
    return io.open(os.path.join(ROOT, p), encoding='utf-8', errors='replace').read()

code = read('pybk_code.py')      # C 后端编译器
bc = read('pybk_bc.py')          # VM 字节码后端编译器
front = read('pybk_front.py')    # 前端（解析/词法）
rt = read('pybook_rt.h')

print('=' * 70)
print('一、语言核心特性（C 后端 pybk_code.py 里有没有对应实现）')
print('=' * 70)
FEAT = {
    'if/else':          [r'\bif\b\s*\(', r'\belse\b'],
    'for 循环':          [r'\bfor\b'],
    'while 循环':        [r'\bwhile\b'],
    'break':            [r'\bbreak\b'],
    'continue':         [r'\bcontinue\b'],
    '函数 func':         [r'\bfunc\b'],
    'lambda':           [r'\blambda\b'],
    'class 类':         [r'\bclass\b'],
    '继承 extends':      [r'\bextends\b', r'\binherit'],
    'try/catch 异常':    [r'\btry\b\s*\{', r'\bcatch\b', r'\bexcept\b'],
    'throw/raise':      [r'\bthrow\b', r'\braise\b'],
    'switch/match':     [r'\bswitch\b', r'\bmatch\b\s*\('],
    'enum 枚举':         [r'\benum\b'],
    '装饰器 @':          [r'@装饰', r'decorator'],
    '运算符重载':        [r'__add__|op_add|运算符重载'],
    'yield/生成器':      [r'\byield\b'],
    'async/await':      [r'\basync\b', r'\bawait\b'],
    '类型标注':          [r'->\s*[A-Za-z]', r':\s*int\b'],
    '结构体 struct':     [r'\bstruct\b'],
    '接口 interface':   [r'\binterface\b'],
    '模块 import':      [r'\bimport\b', r'引用\('],
    '包 package':       [r'\bpackage\b'],
    '全局 global':      [r'\bglobal\b'],
    '静态成员 static':   [r'\bstatic\b'],
    '属性 property':     [r'\bproperty\b', r'@属性'],
}
for name, pats in FEAT.items():
    hit = []
    for p in pats:
        if re.search(p, code):
            hit.append(p)
    mark = '有' if hit else '缺'
    print('  %-16s %s   %s' % (name, mark, ' '.join(hit[:3])[:80]))

print()
print('=' * 70)
print('二、两个后端的能力差距（VM 后端 pybk_bc.py）')
print('=' * 70)
# VM 后端支持哪些语句
vm_kw = ['lambda', 'class', 'extends', 'func', 'for', 'while', '引用', 'jit', 'tensor']
for k in vm_kw:
    print('  VM 后端含 "%s" 的次数: %d' % (k, bc.count(k)))
print()
print('  文档里承认的 VM 后端缺口关键词：')
for kw in ['VM 后端', '字节码后端', '.pybc']:
    idx = read('PYBOOK_AI.md').find(kw)
    print('    "%s" 在 PYBOOK_AI.md 出现 %d 次' % (kw, read('PYBOOK_AI.md').count(kw)))

print()
print('=' * 70)
print('三、工具链现状')
print('=' * 70)
tools = {
    'C 后端编译器': ['pybk_code.py', 'pybk_front.py', 'pybk_types.py'],
    'VM 字节码后端': ['pybk_bc.py', 'pyvm.c'],
    'JIT': ['JIT_DESIGN.md'],
    'IDE/编辑器': ['ide.py', '编辑器.py', '编辑器.c'],
    '测试框架': [os.path.join('tests', 'run_tests.py'), os.path.join('tests', 'cases.py')],
    '项目/工程': ['pybk_project.py', 'pybk_build.py'],
    '调试运行时': ['rt_debug.c'],
    '文档': ['PYBOOK_AI.md', '语法手册.md', 'PYBOOK_规格.md', 'ARCHITECTURE.md', '库教程.md'],
}
for k, v in tools.items():
    ex = [f for f in v if os.path.exists(os.path.join(ROOT, f))]
    print('  %-14s %s' % (k, ('有：' + ', '.join(ex)) if ex else '缺'))

print()
print('  旧版 IDE 目录：', os.path.isdir(os.path.join(ROOT, '归档', '旧版IDE')))
for d in ['tests', '发布打包_102', '归档', 'games', '基准', 'shots_rl']:
    p = os.path.join(ROOT, d)
    if os.path.isdir(p):
        n = len([x for x in os.listdir(p)])
        print('  目录 %-14s %d 个条目' % (d, n))

print()
print('=' * 70)
print('四、根目录卫生')
print('=' * 70)
files = os.listdir(ROOT)
stray_c = [f for f in files if f.startswith('out_') and f.endswith('.c')]
stray_py = [f for f in files if f.startswith('_') and f.endswith('.py')]
stray_exe = [f for f in files if f.endswith('.exe')]
print('  根目录 out_*.c 残留      : %d' % len(stray_c))
print('  根目录 _*.py 临时脚本    : %d' % len(stray_py))
print('  根目录 *.exe             : %d' % len(stray_exe))
print('  根目录文件总数           : %d' % len(files))
allf = []
for dp, dn, fn in os.walk(ROOT):
    if any(x in dp for x in ('.git', 'rt_cache', 'build_tmp', 'node_modules')):
        continue
    for f in fn:
        allf.append(os.path.join(dp, f))
print('  仓库文件总数(不含 .git/缓存): %d' % len(allf))

print()
print('=' * 70)
print('五、运行时数值类型')
print('=' * 70)
for t in ['RTK_INT', 'RTK_BIGINT', 'RTK_FLT', 'RTK_TENSOR', 'RTK_DICT', 'RTK_LIST', 'RTK_OBJ']:
    print('  %-12s %d' % (t, rt.count(t)))
print('  有 float32/decimal 吗: ', '是' if ('float32' in rt or 'decimal' in rt) else '否')
