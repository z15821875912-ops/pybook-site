/* PYbook v2 运行时库——NaN-boxing 万能盒 Value 的实现（与 pybook_rt.h 配套）。
 *
 * Value 是一个 64 位盒子：浮点直接存原始位样（最快路径），其余类型装进
 * IEEE754 NaN 的未用载荷位（位样布局见 pybook_rt.h 头注释）。
 * 旧 struct Value 的 flags 字段去向：
 *   F_LOCKED → 槽地址侧表（锁定是"槽"的状态；rt_gold 写）；
 *   F_DELETED → 槽内盒子整体改写成 DELETED 位样（随值旅行，rt_chk 拦截）；
 *   F_RC → 载荷位 47（本版预留，永不置位）。
 * 整数快路径 48 位；更大的整数自动转 BIGINT 堆盒，64 位全范围保真。
 *
 * 内存约定：所有 malloc 之后一律不 free，脚本结束由进程统一归还；
 * 字符串不可变，Value 的赋值/传参只拷 8 字节盒子不拷内容。
 * 例外：@self（完全手动）模式下 rt_destroy 会真正 free——已释放指针登记在案
 * （最多 1024 个），共享别名二次 delete 不会 double-free；悬空访问后果自负。
 * 错误约定：所有运行时错误向 stderr 输出 "运行时错误: 原因" 后 exit(1)。
 *
 * 模块分工：te/mt/rd 在 pybook_lib.c（rt_lib_*，本文件不得重复定义），
 * file 在 pybook_file.c（rt_file_*，同上），其余全部在本文件。
 *
 * 游戏零件（rt_game_*）：SDL2 头文件在包含路径里即自动启用真实现；否则
 * 编译"未启用"桩——调用时给出明确报错，库自测等无 SDL 构建照样能链接。
 *
 * 自测（覆盖本库全部函数的正常 + 边界：溢出/除零/空列表/类型错误/锁删，
 * 报错分支没法在本进程里"接住"（rt_* 直接 exit(1)），所以拉起自身作为
 * 子进程跑指定用例，验证退出码为 1 且 stderr 带对应消息；同时冒烟链接
 * 进来的 pybook_lib.c（te/mt/rd）与 pybook_file.c（file））：
 *   gcc -O2 -DRT_SELF_TEST pybook_rt.c pybook_lib.c pybook_file.c
 *       -o rt_test.exe -I. -Iucrt64/include -Lucrt64/lib -lSDL2
 * 附加玩法：rt_test.exe game —— 开一个 SDL 窗口跑 120 帧图形演示。
 */

#if defined(__MINGW32__) && !defined(__USE_MINGW_ANSI_STDIO)
#define __USE_MINGW_ANSI_STDIO 1   /* 保证 %lld / %g 按 C99 语义工作 */
#endif

#include <errno.h>
#include <limits.h>
#include <math.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>       /* clock()：GC 暂停时长度量（可观测性，C） */

#include "pybook_rt.h"
#include "pybook_gpu.h"   /* rt_device_set 要问驱动有没有卡；GPU 后端本体在 pybook_gpu.c */

/* ================= 内部工具 ================= */

/* 内存模式全局开关：0=@normal 1=@self（3=引用计数预留，暂未实现）。
 * 单线程语言：只在主执行流里被读写，无并发访问点，因此不加锁。 */
static int g_memmode = 0;

/* 统一的运行时错误出口 */
long long g_cur_line = 0;   /* 当前执行的源码行（编译器在每条语句前写入） */

void rt_die(const char *fmt, ...);
/* Smokeroor 用：运行时出错计数（rt_die 每次触发 +1）。查询接口见文件末尾 rt_q_*。 */
static long long g_err_count = 0;

/* ---- try/catch 与 onerror 的跳转机制 ----
 * 链式错误点：try 每层登记一个 jmp_buf；rt_die 改为 longjmp 到最近一层。
 * g_err_msg 携带错误文本（catch 的 e / onerror 的 err 读它）。
 * g_err_type 携带错误类型（catch e, t / catch e:类型 用它）。 */
#include <setjmp.h>
#include <string.h>

/* GC 根栈（真正定义在文件后面的 GC 段，这里先声明）：
 * 错误点要记下进入本层时的作用域深度——longjmp 会跳过 try 块里的
 * rt_scope_leave()，不还原的话作用域栈会错层，后面的 rt_scope_leave()
 * 弹错层级 → 变量被提前回收 → 随机段错误。 */
static Value **g_roots = NULL;
static size_t  g_roots_n = 0, g_roots_cap = 0;
static size_t *g_scope = NULL;
static size_t  g_scope_n = 0, g_scope_cap = 0;

typedef struct ErrPoint {
    jmp_buf             jb;
    struct ErrPoint    *prev;
    size_t              scope_n;   /* 进入本层时的 GC 作用域栈深度 */
    jmp_buf            *ext;       /* 非空：longjmp 落在这个外部 jmp_buf 上（VM 后端用） */
} ErrPoint;

static ErrPoint *g_err_top = NULL;
static char      g_err_msg[1024] = "";
static char      g_err_type[128] = "";
static int       g_err_active = 0;   /* 本层已接过一次错：handler 里再抛要往外走 */

ErrPoint *rt_err_push(void)
{
    ErrPoint *p = (ErrPoint *)malloc(sizeof *p);
    if (!p)
        rt_die("内存不足");
    p->prev = g_err_top;
    p->scope_n = g_scope_n;
    p->ext = NULL;
    g_err_top = p;
    return p;
}

/* 错误点落在调用方自己的 jmp_buf 上：VM 后端的 setjmp 在解释器栈帧里，
 * 不能用本文件内部那块 jmp_buf（那样 longjmp 会跳回一个已经退出的帧）。 */
ErrPoint *rt_err_push_ext(void *jb)
{
    ErrPoint *p = (ErrPoint *)malloc(sizeof *p);
    if (!p)
        rt_die("内存不足");
    p->prev = g_err_top;
    p->scope_n = g_scope_n;
    p->ext = (jmp_buf *)jb;
    g_err_top = p;
    return p;
}

void rt_err_pop(struct ErrPoint *pv)
{
    ErrPoint *p = (ErrPoint *)pv;
    if (g_err_top == p)
        g_err_top = p->prev;
    free(p);
    g_err_active = 0;    /* 本层 try/onerror 处理完毕：新错误再次可捕获 */
}

/* 连同它上面的层一起弹掉（VM 后端用：解释器回调嵌套后，
 * 上层的错误点可能已经失效，不能只弹一层）。 */
void rt_err_pop_to(struct ErrPoint *pv)
{
    ErrPoint *p = (ErrPoint *)pv;
    while (g_err_top != NULL && g_err_top != p) {
        ErrPoint *q = g_err_top;
        g_err_top = q->prev;
        free(q);
    }
    if (g_err_top == p) {
        g_err_top = p->prev;
        free(p);
    }
    g_err_active = 0;
}

const char *rt_err_msg(void) { return g_err_msg; }
const char *rt_err_type(void) { return g_err_type[0] ? g_err_type : "运行时"; }

/* 类型匹配：t 为空或 "*" 恒真（catch 不带类型 = 来者不拒）。 */
int rt_err_type_is(const char *t)
{
    if (!t || !t[0] || strcmp(t, "*") == 0)
        return 1;
    return strcmp(g_err_type[0] ? g_err_type : "运行时", t) == 0;
}

/* 重新武装：handler 开跑前调一次，让 handler 里再抛的错能被 handler
 * 自己的错误点接住（而不是直接退出程序）。 */
void rt_err_ready(void) { g_err_active = 0; }

/* longjmp 之后把 GC 作用域栈还原到进入本层时的深度 */
void rt_err_unwind(struct ErrPoint *pv)
{
    ErrPoint *p = (ErrPoint *)pv;
    while (g_scope_n > p->scope_n) {
        if (g_scope_n)
            g_roots_n = g_scope[--g_scope_n];
    }
}

/* 出错出口：有 catch 层 → 跳过去；否则打印并退出 */
void rt_err_raise(void)
{
    if (g_err_top != NULL && !g_err_active) {
        g_err_active = 1;
        if (g_err_top->ext)
            longjmp(*g_err_top->ext, 1);
        longjmp(g_err_top->jb, 1);
    }
    fprintf(stderr, "运行时错误: %s\n", g_err_msg[0] ? g_err_msg : "未知");
    exit(1);
}

/* 用户显式抛错：throw "消息" / throw "消息", "类型"。
 * type 为空盒（rt_none）时类型记「运行时」。 */
void rt_throw(Value msg, Value type)
{
    char *m = rt_str_of(msg);
    char *t = (!IS_NONE(type)) ? rt_str_of(type) : NULL;
    g_err_count++;
    if (g_cur_line > 0)
        snprintf(g_err_msg, sizeof g_err_msg, "第 %lld 行: %s",
                 (long long)g_cur_line, m ? m : "");
    else
        snprintf(g_err_msg, sizeof g_err_msg, "%s", m ? m : "");
    snprintf(g_err_type, sizeof g_err_type, "%s", (t && t[0]) ? t : "运行时");
    rt_err_raise();
}

/* 重抛：把手上正在接的那个错原样抛给外层（catch 里裸 throw 用）。
 * 消息和类型都不改，只是换一层接。 */
void rt_err_rethrow(void)
{
    rt_err_raise();
}

/* ── 报错三段式：运行时错误的修复建议 ─────────────────────────────────
 * 按子串匹配、命中即停；只在原文案后**追加**，不改原文案
 * （自测和 Smokeroor 都是 strstr 子串匹配，追加不影响已有断言）。 */
static const char *rt_hint_for(const char *msg)
{
    if (strstr(msg, "用已删除变量"))
        return "\n  为什么：变量已经 del 掉了（@self 模式下别名共享同一份内存，del 后所有别名一起失效）"
               "\n  怎么改：删了就别再访问；要继续用就别 del；@self 的别名要一起作废";
    if (strstr(msg, "下标越界"))
        return "\n  为什么：索引超出范围（负数从尾数算：-1 是最后一个）"
               "\n  怎么改：用 表.at(i, 默认值) 越界不炸，或先 长度(表) 检查";
    if (strstr(msg, "下标必须是整数"))
        return "\n  为什么：索引只收整数（文本/浮点都算不了位置）"
               "\n  怎么改：浮点先取整再用；文本要先转成数字";
    if (strstr(msg, "除以零"))
        return "\n  为什么：除数是 0，数学上没有意义"
               "\n  怎么改：除之前检查除数；或用 mt. 家族的安全除法（看 PYBOOK_AI.md）";
    if (strstr(msg, "溢出"))
        return "\n  为什么：整数算出了 64 位范围（约 ±922 亿亿）"
               "\n  怎么改：改用浮点（写 2.0 不写 2）；大数拆步算；或用科学计数量级";
    if (strstr(msg, "字典里没有这个键"))
        return "\n  为什么：键不在字典里（键是精确匹配，大小写/空格都算）"
               "\n  怎么改：用 字典.get(键, 默认值) 没有就给默认；或先确认键存在再取";
    if (strstr(msg, "变量已锁定"))
        return "\n  为什么：变量被 del 或 gold 锁住了，锁上就不能再改（没有解锁）"
               "\n  怎么改：换个变量存新值；确认是不是误 del 了";
    if (strstr(msg, "需要整数"))
        return "\n  为什么：这个位置只收整数"
               "\n  怎么改：写整数；浮点先转整；文本先转数字";
    if (strstr(msg, "列表为空"))
        return "\n  为什么：空列表里没有元素可取"
               "\n  怎么改：先 长度(表) > 0 再取；或用 表.at(i, 默认值) 兜底";
    if (strstr(msg, "内存不足"))
        return "\n  为什么：分配内存失败（对象太大或真的用完了）"
               "\n  怎么改：减少一次分配的量；循环里少造临时大对象";
    if (strstr(msg, "类型不可"))
        return "\n  为什么：两个值的类型不配这个运算（比如文本不能乘文本）"
               "\n  怎么改：先转类型；用 smoke.type(x) 看看它到底是什么";
    if (strstr(msg, "属性") && strstr(msg, "不存在"))
        return "\n  为什么：对象没有这个属性（拼错或真没建）"
               "\n  怎么改：查拼写；新属性先赋一次值就会建出来";
    if (strstr(msg, "这里需要一个列表"))
        return "\n  为什么：这个操作只吃列表"
               "\n  怎么改：用 [] 包起来；或查是不是传错了变量";
    return NULL;
}

/* 内置错误的类型标签：按消息子串判定（和 rt_hint_for 同一套路）。
 * 用户用 throw 显式抛的错，类型由 throw 自己给（默认也是「运行时」）。 */
static const char *rt_type_for(const char *msg)
{
    if (strstr(msg, "除以零"))            return "除零";
    if (strstr(msg, "下标"))              return "下标";
    if (strstr(msg, "类型不可"))          return "类型";
    if (strstr(msg, "需要整数"))          return "类型";
    if (strstr(msg, "这里需要一个列表"))  return "类型";
    if (strstr(msg, "变量已锁定"))        return "锁定";
    if (strstr(msg, "用已删除变量"))      return "删除";
    if (strstr(msg, "字典里没有这个键"))  return "键";
    if (strstr(msg, "列表为空"))          return "空";
    if (strstr(msg, "内存不足"))          return "内存";
    return "运行时";
}

void rt_die(const char *fmt, ...)
{

    va_list ap;
    char msg[896];
    g_err_count++;                    /* Smokeroor：smoke.errors() 读它 */
    va_start(ap, fmt);
    vsnprintf(msg, sizeof msg, fmt, ap);
    va_end(ap);
    if (g_cur_line > 0)
        snprintf(g_err_msg, sizeof g_err_msg, "第 %lld 行: %s",
                 (long long)g_cur_line, msg);
    else
        snprintf(g_err_msg, sizeof g_err_msg, "%s", msg);
    snprintf(g_err_type, sizeof g_err_type, "%s", rt_type_for(msg));
    /* 报错三段式：追加「为什么 / 怎么改」（原文案不动，追加安全） */
    {
        const char *hint = rt_hint_for(msg);
        if (hint) {
            size_t len = strlen(g_err_msg);
            if (len < sizeof g_err_msg - 1)
                snprintf(g_err_msg + len, sizeof g_err_msg - len, "%s", hint);
        }
    }
    rt_err_raise();
}

/* ---- 函数值回调（见 pybook_rt.h 的说明）---- */
static RtFnDispatch g_fn_dispatch = NULL;

void rt_set_fn_dispatch(RtFnDispatch f)
{
    g_fn_dispatch = f;
}

Value rt_call_value(Value fnval, Value args)
{
    if (!g_fn_dispatch)
        rt_die("这个函数需要一个函数值（lambda），但当前后端没有回调能力\n"
               "  为什么：函数值的分发表由用户程序在启动时装进运行时；"
               "字节码后端（.pybc）目前还没有这套机制\n"
               "  怎么改：用 C 后端运行这个程序（python -B main.py 程序.pybk）；"
               "或者把这个计算展开写成不依赖回调的写法");
    return g_fn_dispatch(fnval, args);
}

/* 单参便捷式。参数包成临时列表再交给分发器 —— 分发器只认列表，
   两边（用户直接调 mec.apply 与库函数回调）走的是同一条路，不会分叉。 */
Value rt_call1(Value fnval, Value x)
{
    Value a = rt_list_new();
    rt_push(&a, x);
    return rt_call_value(fnval, a);
}

/* ── 锁定侧表：F_LOCKED 的家 ──
 * 8 字节盒子里没有 flags 的位置，而"锁定"是槽的状态，所以按槽地址登记
 * （教学规模：每个程序锁定的变量屈指可数，固定 256 格线性查找足够；
 * 记录只增不删——语言里没有"解锁"）。 */
static struct { uint64_t box; } g_locks[256];
static int g_nlocks = 0;

static int slot_is_locked(Value *slot)
{
    uint64_t key = (uint64_t)(uintptr_t)slot;
    for (int i = 0; i < g_nlocks; i++)
        if (g_locks[i].box == key)
            return 1;
    return 0;
}

static void slot_lock(Value *slot)
{
    if (slot_is_locked(slot))
        return;
    if (g_nlocks >= (int)(sizeof g_locks / sizeof g_locks[0]))
        rt_die("锁定的变量太多（上限 %d 个）", (int)(sizeof g_locks / sizeof g_locks[0]));
    g_locks[g_nlocks++].box = (uint64_t)(uintptr_t)slot;
}

/* @self 模式的已释放指针登记表：free 过的地址都记下来，共享别名（两个名字
 * 拷贝了同一个盒子）二次 delete 时查表命中就跳过 free，只打删除标志——
 * "悬空访问后果自负"不等于"进程因 double-free 崩溃"。表满后不再登记
 * （方向保守：宁可泄漏到进程退出，也不二次 free）。 */
#define RT_FREED_CAP 1024
static const void *g_freed[RT_FREED_CAP];
static size_t g_freed_n = 0;

static int ptr_registered(const void *p)
{
    if (p == NULL)
        return 1;   /* NULL 无需释放 */
    for (size_t i = 0; i < g_freed_n; i++)
        if (g_freed[i] == p)
            return 1;
    return 0;
}

static void register_freed(const void *p)
{
    if (p != NULL && g_freed_n < RT_FREED_CAP)
        g_freed[g_freed_n++] = p;
}

/* ================= Memoryment 地基：统一堆单元（@3@4@5@6 共用） =================
 * 布局："头在载荷前"——每次分配 = sizeof(RtCell) + nbytes，返回的是载荷指针，
 * 于是 AS_STR / AS_LIST / AS_OBJ 这些宏一个都不用改，只在分配与释放处接管：
 *      [ RtCell 头 ][ 载荷：char 数组 / RtList / RtObject / long long ]
 * 所有"装得进 Value"的堆对象（字符串、列表、对象、BIGINT）都走这里并登记进
 * 全局双向链 g_all，供 @5 清除、@6 分代与统计遍历。
 * 不进链的辅助 malloc：显示文本（rt_str_of）、对象属性名——它们由宿主单元
 * 托管，随宿主一起释放。
 * 回收语义按模式分派（见 rt_set_memmode）：
 *   0 @normal 不回收（进程退出统一归还）  1 @self 手动 del 真释放
 *   3 @3 引用计数   4 @4 竞技场整块归还   5 @5 标记清除   6 @6 分代+增量
 */
typedef struct RtCell RtCell;
typedef struct RtArena RtArena;

struct RtCell {
    uint32_t rc;             /* 引用计数（@3 起用） */
    uint8_t  kind;           /* RTK_STR / LIST / OBJ / BIGINT */
    uint8_t  mark;           /* GC 标记位（@5/@6） */
    uint8_t  gen;            /* 分代：0=新生代 1=老年代（@6） */
    uint8_t  gray;           /* 已在增量标记的 gray 栈里（@6） */
    uint8_t  intent;         /* 知命意图：0未标 1帧 2关卡 3共享 4图（仅 @7 用） */
    uint8_t  m7_age;         /* 知命代际年龄：连活 minor 次数（仅 @7 用，晋升依据） */
    RtArena *owner;          /* 非 NULL：块内分配（@4 竞技场），随块回收 */
    RtCell  *next, *prev;    /* g_all 双向链 */
};

#define RTK_STR    0
#define RTK_LIST   1
#define RTK_OBJ    2
#define RTK_BIGINT 3
#define RTK_DICT   4
#define RTK_TENSOR 5

/* 字典：载荷是 [键, 值] 对列表（插入序保留），键任意值 */
typedef struct {
    Value pairs;
    long long *hk;        /* 哈希桶：存 pairs 下标 +1；0=空；懒建（>=32 键才启用） */
    long long hcap;       /* 桶容量（2 的幂） */
    long long hused;      /* 占用数 */
    int hdirty;           /* 删除后失效，下次操作重建 */
} RtDict;

/* ---- 字典哈希索引：数值/字符串键 O(1)；其他类型同桶退化，正确性由 rt_eq 保证 ---- */
static unsigned long long rt_dict_mix(unsigned long long x)
{
    x ^= x >> 33; x *= 0xff51afd7ed558ccdULL;
    x ^= x >> 33; x *= 0xc4ceb9fe1a85ec53ULL;
    x ^= x >> 33;
    return x;
}

static unsigned long long rt_dict_key_hash(Value k)
{
    if (IS_STR(k)) {
        const char *s = AS_STR(k) ? AS_STR(k) : "";
        unsigned long long h = 1469598103934665603ULL;
        while (*s) { h ^= (unsigned char)*s++; h *= 1099511628211ULL; }
        return rt_dict_mix(h);
    }
    if (IS_INT(k)) return rt_dict_mix((unsigned long long)AS_INT(k));
    if (IS_FLT(k)) {
        double d = AS_FLT(k);
        unsigned long long b;
        if (d == 0.0) d = 0.0;
        memcpy(&b, &d, sizeof b);
        return rt_dict_mix(b);
    }
    if (IS_BOOL(k)) return rt_dict_mix((unsigned long long)AS_BOOL(k));
    return 0;
}

static void dict_hrebuild(RtDict *D, long long ncap)
{
    
    long long *nk = (long long *)malloc((size_t)ncap * sizeof(long long));
    if (!nk) { D->hk = NULL; D->hcap = 0; return; }
    for (long long i = 0; i < ncap; i++) nk[i] = 0;
    RtList *L = AS_LIST(D->pairs);
    long long used = 0;
    for (size_t i = 0; L && i < L->len; i++) {
        RtList *pair = AS_LIST(L->items[i]);
        if (!pair || pair->len != 2) continue;
        unsigned long long h = rt_dict_key_hash(pair->items[0]);
        size_t slot = (size_t)((unsigned long long)h & (unsigned long long)(ncap - 1));
        while (nk[slot] != 0) slot = (slot + 1) & (size_t)(ncap - 1);
        nk[slot] = (long long)i + 1;
        used++;
    }
    free(D->hk);
    D->hk = nk;
    D->hcap = ncap;
    D->hused = used;
    D->hdirty = 0;
}

static void dict_hmaybe_grow(RtDict *D)
{
    if (D->hcap == 0) {
        if (AS_LIST(D->pairs)->len >= 32)
            dict_hrebuild(D, 128);
        return;
    }
    if ((D->hused + 1) * 4 > D->hcap * 3)
        dict_hrebuild(D, D->hcap * 2);
}

static void dict_hinsert(RtDict *D, Value key, size_t pidx)
{
    
    dict_hmaybe_grow(D);
    if (D->hcap == 0) return;
    unsigned long long h = rt_dict_key_hash(key);
    size_t mask = (size_t)D->hcap - 1, slot = (size_t)(h & (unsigned long long)mask);
    while (D->hk[slot] != 0) slot = (slot + 1) & mask;
    D->hk[slot] = (long long)pidx + 1;
    D->hused++;
}

static size_t dict_hfind(RtDict *D, Value key, int *found)
{
    
    if (D->hdirty)
        dict_hrebuild(D, D->hcap ? D->hcap : 128);
    *found = 0;
    if (D->hcap == 0) {
        RtList *L = AS_LIST(D->pairs);          /* 小字典：直接线性 */
        if (L)
            for (size_t k2 = 0; k2 < L->len; k2++) {
                RtList *pair = AS_LIST(L->items[k2]);
                if (pair && pair->len == 2 && rt_cond(rt_eq(pair->items[0], key))) {
                    *found = 1;
                    return k2;
                }
            }
        return 0;
    }
    unsigned long long h = rt_dict_key_hash(key);
    size_t mask = (size_t)D->hcap - 1, slot = (size_t)(h & (unsigned long long)mask);
    RtList *L = AS_LIST(D->pairs);
    while (D->hk[slot] != 0) {
        long long pi = D->hk[slot];
        if (pi > 0 && L && (size_t)pi <= L->len) {
            RtList *pair = AS_LIST(L->items[pi - 1]);
            if (pair && pair->len == 2 && rt_cond(rt_eq(pair->items[0], key))) {
                *found = 1;
                return (size_t)(pi - 1);
            }
        }
        slot = (slot + 1) & mask;
    }
    return 0;
}

/* @4 竞技场：按块 bump 分配，整块归还（块内单元不单独 free） */
struct RtArena {
    RtArena *next;
    size_t   used, cap;
    char    *mem;
};
#define RT_ARENA_CHUNK (64u * 1024u)

static RtCell  *g_all   = NULL;   /* 全部存活单元 */
static size_t   g_live  = 0;      /* 存活单元数 */
static size_t   g_bytes = 0;      /* 近似占用（头+载荷），GC 阈值判断用 */
static RtArena *g_arena = NULL;   /* @4 当前块链 */

/* 单元入链/摘链 */
static void cell_link(RtCell *c)
{
    c->prev = NULL;
    c->next = g_all;
    if (g_all)
        g_all->prev = c;
    g_all = c;
    g_live++;
}

static void cell_unlink(RtCell *c)
{
    if (c->prev)
        c->prev->next = c->next;
    else
        g_all = c->next;
    if (c->next)
        c->next->prev = c->prev;
    c->next = c->prev = NULL;
    if (g_live)
        g_live--;
}

/* @4：从竞技场当前块 bump 一段；不够就新开一块 */
static void *arena_bump(size_t n)
{
    n = (n + 15u) & ~(size_t)15u;                 /* 16 字节对齐 */
    if (n > RT_ARENA_CHUNK) {
        /* 大于块尺寸：单独开一块专属大块 */
        RtArena *a = (RtArena *)malloc(sizeof(RtArena));
        if (!a)
            rt_die("内存不足");
        a->cap = n;
        a->used = n;
        a->mem = (char *)malloc(n);
        if (!a->mem)
            rt_die("内存不足");
        a->next = g_arena;
        g_arena = a;
        return a->mem;
    }
    if (!g_arena || g_arena->used + n > g_arena->cap) {
        RtArena *a = (RtArena *)malloc(sizeof(RtArena));
        if (!a)
            rt_die("内存不足");
        a->cap = RT_ARENA_CHUNK;
        a->used = 0;
        a->mem = (char *)malloc(RT_ARENA_CHUNK);
        if (!a->mem)
            rt_die("内存不足");
        a->next = g_arena;
        g_arena = a;
    }
    void *p = g_arena->mem + g_arena->used;
    g_arena->used += n;
    return p;
}

/* 取"当前块"（给单元记 owner 用） */
static RtArena *arena_current(void) { return g_arena; }

static void remember(RtCell *container, Value val);   /* @6 写屏障，定义见 Memoryment 段 */
static void gc_insert_barrier(Value container, Value newval);  /* @6 增量标记：新增引用 */
static void gc_delete_barrier(Value oldval);                   /* @6 增量标记：覆盖旧引用 */
static int  g_major_phase;               /* 前置声明：heap_alloc 的黑分配要用；定义见下 */
static size_t g_alloc_since_gc;          /* 前置声明：heap_alloc 要累加；定义见下 */
static size_t g_m7_alloc;               /* 前置声明：知命压力计数（含 heap_raw 大块），仅 mode7 用 */

/* 统一的 Value 级分配：带 RtCell 头，返回载荷指针。
 * 注意：这里**不**触发回收——表达式求值途中的临时值没有登记为根，
 * 若在分配时收集，会把正在使用的临时对象收走。回收只在语句边界
 * （生成代码调 rt_gc_poll）发生，见 Memoryment 段说明。 */
static void *heap_alloc(int kind, size_t nbytes)
{
    RtCell *c;
    if (g_memmode == 4) {                          /* @4：竞技场 */
        c = (RtCell *)arena_bump(sizeof(RtCell) + nbytes);
        c->owner = arena_current();
    } else {
        c = (RtCell *)malloc(sizeof(RtCell) + nbytes);
        if (!c)
            rt_die("内存不足");
        c->owner = NULL;
    }
    c->rc   = 1;
    c->kind = (uint8_t)kind;
    /* @6 增量标记期间：新对象生来就是黑的（不用标记器再扫一遍）。
       否则它出现时标记器早扫过那个位置，永远标不上 → 被当垃圾收走。 */
    c->mark = (g_memmode == 6 && g_major_phase != 0) ? 1 : 0;
    c->gen  = 0;
    c->gray = 0;
    c->intent = 0;          /* 新单元默认未标意图 */
    c->m7_age = 0;          /* 知命代际年龄归零 */
    cell_link(c);
    g_bytes += sizeof(RtCell) + nbytes;
    g_alloc_since_gc += sizeof(RtCell) + nbytes;   /* @6 触发计数 */
    if (g_memmode == 7) g_m7_alloc += sizeof(RtCell) + nbytes;  /* 知命压力计数 */
    return (void *)(c + 1);
}

/* 辅助裸内存（列表 items 等）：跟随当前模式，块内分配则随块回收 */
static void *heap_raw(size_t nbytes)
{
    if (g_memmode == 4)
        return arena_bump(nbytes);
    void *p = malloc(nbytes);
    if (g_memmode == 7) g_m7_alloc += nbytes;   /* 知命压力计数：大块数据也计入 */
    if (!p)
        rt_die("内存不足");
    return p;
}

static void heap_raw_free(void *p, RtCell *owner_hint)
{
    /* 块内分配的内存不单独 free；只有 malloc 来的才 free */
    if (p && (!owner_hint || !owner_hint->owner))
        free(p);
}

/* 辅助裸内存扩容：块内分配不能 realloc（bump 区没有伸缩余地），
 * 改为"新开一段 + 拷贝旧内容"，旧段留在块里随整块回收。 */
static void *heap_raw_grow(void *p, RtCell *owner_hint, size_t oldn, size_t newn)
{
    if (owner_hint && owner_hint->owner) {
        void *np = arena_bump(newn);
        if (p && oldn)
            memcpy(np, p, oldn);
        return np;
    }
    void *np = realloc(p, newn);
    if (!np)
        rt_die("内存不足");
    return np;
}

/* 由 Value 找到它的单元头（未装箱的 INT/FLOAT/BOOL/NONE 没有单元） */
static RtCell *cell_of(Value v)
{
    if (IS_STR(v) || IS_BIGINT(v))
        return ((RtCell *)AS_STR(v)) - 1;
    if (IS_LIST(v))
        return ((RtCell *)AS_LIST(v)) - 1;
    if (IS_OBJ(v))
        return ((RtCell *)AS_OBJ(v)) - 1;
    return NULL;
}

static void rt_retain(Value v);
static void rt_release(Value v);
static void cell_drop(RtCell *c, int drop_children);

/* 递归释放子对象：列表元素、对象属性值（BIGINT/字符串无子对象） */
static void cell_drop_children(RtCell *c)
{
    if (c->kind == RTK_LIST) {
        RtList *L = (RtList *)((void *)(c + 1));
        if (L->items)
            for (size_t i = 0; i < L->len; i++)
                rt_release(L->items[i]);
    } else if (c->kind == RTK_OBJ) {
        RtObject *o = (RtObject *)((void *)(c + 1));
        for (size_t i = 0; i < o->nprops; i++)
            rt_release(o->vals[i]);
    } else if (c->kind == RTK_DICT) {
        RtDict *D = (RtDict *)((void *)(c + 1));
        rt_release(D->pairs);
    }
}

/* 真正释放一个单元：先放子对象，再摘链、释放载荷自带内存、最后释放自己。
 * drop_children=0 用于 GC 的 sweep——它自己就遍历链表逐个回收，子对象会
 * 被单独处理；此时再递归 release 会踩到已经 free 掉的子单元（访问违例）。
 * drop_children=1 用于 @3 归零回收和 del 语句：那两条路径必须连子对象一起放。 */
static void cell_drop(RtCell *c, int drop_children)
{
    if (!c)
        return;
    if (drop_children)
        cell_drop_children(c);
    if (c->kind == RTK_LIST) {
        RtList *L = (RtList *)((void *)(c + 1));
        heap_raw_free(L->items, c);
        L->items = NULL;
    } else if (c->kind == RTK_OBJ) {
        RtObject *o = (RtObject *)((void *)(c + 1));
        for (size_t i = 0; i < o->nprops; i++)
            free(o->names[i]);          /* 属性名是普通 malloc，随宿主回收 */
        free(o->names);
        free(o->vals);
        o->names = NULL;
        o->vals = NULL;
    } else if (c->kind == RTK_TENSOR) {
        RtTensor *T = (RtTensor *)((void *)(c + 1));
        free(T->dims);                  /* 维度数组：malloc 裸内存，GC 必须显式释放 */
        free(T->data);                  /* 数据缓冲区：calloc 裸内存，GC 必须显式释放 */
        T->dims = NULL;
        T->data = NULL;
    }
    cell_unlink(c);
    if (!c->owner)
        free(c);                        /* 块内单元随块回收，不单独 free */
}

static void rt_retain(Value v)
{
    RtCell *c = cell_of(v);
    if (c)
        c->rc++;
}

/* 引用计数减一；只有 @3 会在归零时立即释放（其余模式由 GC/竞技场/进程接管） */
static void rt_release(Value v)
{
    RtCell *c = cell_of(v);
    if (!c)
        return;
    if (c->rc > 0)
        c->rc--;
    if (c->rc == 0 && g_memmode == 3)
        cell_drop(c, 1);
}

/* malloc 一份字符串拷贝（@normal 永不 free；@3 计数归零、@5/@6 GC 时回收） */
static char *dup_str(const char *s)
{
    size_t n = strlen(s) + 1;
    char *p = (char *)heap_alloc(RTK_STR, n);
    memcpy(p, s, n);
    return p;
}

/* 普通字符串拷贝：给"不是 Value"的辅助文本用（对象属性名等）。
 * 它不进堆链、不参与引用计数与 GC，由宿主单元持有，随宿主 free 掉。 */
static char *dup_str_plain(const char *s)
{
    size_t n = strlen(s) + 1;
    char *p = (char *)malloc(n);
    if (!p)
        rt_die("内存不足");
    memcpy(p, s, n);
    return p;
}

/* 数字包括 bool 与 BIGINT 堆盒（按数值参与） */
static int is_num(Value v)
{
    return IS_INT(v) || IS_BIGINT(v) || IS_FLT(v) || IS_BOOL(v);
}

/* 按整数值取出：INT 快路径 / BIGINT 堆盒解引用 / BOOL 0/1。
 * 调用点都先经过 is_num 检查，末尾的 rt_die 只是兜底。 */
static long long as_int(Value v)
{
    if (IS_INT(v))
        return AS_INT(v);
    if (IS_BIGINT(v))
        return *(long long *)AS_STR(v);
    if (IS_BOOL(v))
        return (long long)AS_BOOL(v);
    rt_die("需要整数");
    return 0;
}

/* 按浮点值取出 */
static double as_flt(Value v)
{
    if (IS_FLT(v))
        return AS_FLT(v);
    return (double)as_int(v);
}

/* UTF-8 按字符计数（续字节 10xxxxxx 不算新字符） */
static long long utf8_count(const char *s)
{
    long long n = 0;
    for (; *s; s++)
        if (((unsigned char)*s & 0xC0) != 0x80)
            n++;
    return n;
}

/* 从 s 起跳过 want 个字符，返回落点指针（越界停在串尾） */
static const char *utf8_at(const char *s, long long want)
{
    long long n = 0;
    while (*s) {
        if (((unsigned char)*s & 0xC0) != 0x80) {
            if (n == want)
                break;
            n++;
        }
        s++;
    }
    return s;
}

/* ================= 构造 ================= */

Value rt_int(long long x)
{
    if (x >= RT_INT_FAST_MIN && x <= RT_INT_FAST_MAX)
        return 0x7FF9000000000000ULL | ((uint64_t)x & 0xFFFFFFFFFFFFULL);
    /* 快路径装不下：malloc 一个 long long 堆盒，载荷位放数据指针，
     * 64 位全范围保真（LLONG_MAX/LLONG_MIN 字面量依赖这一点）。 */
    long long *block = (long long *)heap_alloc(RTK_BIGINT, sizeof(long long));
    *block = x;
    return 0x7FFB000000000000ULL | (uint64_t)(uintptr_t)block;
}

Value rt_float(double x)
{
    if (x != x) {   /* NaN：规范化到盒子区间之外（头 16 位 0x7FF0/0xFFF0），
                     * 否则原始位样会被 IS_FLT 误判成装箱值。保符号，丢载荷位。 */
        return signbit(x) ? 0xFFF0000000000001ULL : 0x7FF0000000000001ULL;
    }
    uint64_t bits;
    __builtin_memcpy(&bits, &x, sizeof bits);
    return bits;
}

Value rt_bool(int x)
{
    return MAKE_BOOL(x);
}

Value rt_str(const char *s)
{
    return MAKE_STR(dup_str(s ? s : ""));   /* 拷贝一份，永不回收 */
}

Value rt_none(void)
{
    return RT_NIL_BOX;
}

/* INT/BIGINT/BOOL 盒 → long long 的统一解码出口 */
long long rt_to_ll(Value v)
{
    if (IS_INT(v) || IS_BIGINT(v) || IS_BOOL(v))
        return as_int(v);
    rt_die("需要整数");
    return 0;
}

/* ================= 变量：赋值 / 检查 / 锁定 ================= */

void rt_assign(Value *dst, Value nv)
{
    if (slot_is_locked(dst))
        rt_die("变量已锁定");
    if (IS_DEL(*dst))
        rt_die("用已删除变量");
    if (g_memmode == 3) {
        rt_retain(nv);      /* 先保新的再放旧的：x = x 这种自赋值不会归零 */
        rt_release(*dst);
    }
    gc_delete_barrier(*dst);          /* @6 增量标记：覆盖前保住旧值 */
    *dst = nv;   /* 8 字节盒子赋值；字符串只拷指针不拷内容 */
    if (g_memmode == 7)
        rt_ref_barrier(dst);   /* ③ 迁移安全屏障：引用建立的唯一收敛点 */
}

Value rt_chk(Value v)
{
    if (IS_DEL(v))
        rt_die("用已删除变量");
    /* @self 的悬垂指针：del 会真 free，共享别名（两个名字同一份内存）还拿着
     * 旧指针。登记表里查得到 → 说明这个地址已经释放过，报错而不是踩野指针。
     * 只在 @self 模式查（g_memmode == 1）；其他模式 del 只打位样，不真释放。
     * g_freed_n == 0 时短路，零开销。 */
    if (g_memmode == 1 && g_freed_n > 0) {
        RtCell *c = cell_of(v);
        if (c && ptr_registered((void *)(c + 1)))
            rt_die("用已删除变量");
    }
    return v;
}

void rt_gold(Value *dst)
{
    if (IS_DEL(*dst))
        rt_die("用已删除变量");
    slot_lock(dst);
}

/* ================= 内存管理模式（Memoryment） =================
 * 六档语义（数字由前端映射后传进来：@1→0 @2→1 @3→3 @4→4 @5→5 @6→6）：
 *   0 @normal  不回收：内存由进程退出统一归还（最快，适合短小程序）
 *   1 @self    完全手动：del 立即真释放，别名二次 del 不崩（后果自负）
 *   3 @3       引用计数：槽位/容器持有即 +1，覆盖与 del 即 -1，归零即回收。
 *              收不了循环引用（那是 @5 的活）
 *   4 @4       竞技场：bump 分配，单对象不释放，rt_arena_reset() 整块归还
 *   5 @5       标记清除：从根集（登记的变量槽）追踪可达对象，回收其余。
 *              能收循环引用；暂停时间随堆大小增长
 *   6 @6       分代 + 增量：新对象在新生代，存活下来的晋升老年代；
 *              minor GC 只扫新生代（老→新引用靠写屏障记入 Remember Set）；
 *              完整标记切成小片（rt_gc_step），把长暂停摊到每一帧
 *   7 @7 knewany 知命自适应：按对象的"意图标签"分寿命档，相位门控只在该收的边界整收——
 *              帧(1)/关卡(2)/未标(0)：相位边界即早收；共享(3)/图(4)：跨相位存活，每8相位一次 major 全收（含循环）。
 */

static FILE *g_m7_trace;            /* 前向声明：确定性工具（D）轨迹文件，定义在文件后面 */
static void m7_trace_shutdown(void); /* 前向声明：退出时终态全收并关文件（D） */

void rt_set_memmode(int mode)
{
    /* 确定性工具（D）：PYBOOK_MEMMODE 环境变量可在首次调用时强制内存档
     * （如 --determinism-check 强制 7=知命），不改程序源码即可把任意程序跑成 mode7。
     * 只在第一调用生效，之后程序自身的 Memoryment 指令照常。 */
    static int g_mm_env_done = 0;
    if (!g_mm_env_done) {
        g_mm_env_done = 1;
        const char *e = getenv("PYBOOK_MEMMODE");
        if (e && *e) {
            int m = atoi(e);
            if (m == 0 || m == 1 || m == 3 || m == 4 || m == 5 || m == 6 || m == 7)
                mode = m;
        }
    }
    if (mode != 0 && mode != 1 && mode != 3 && mode != 4 && mode != 5 && mode != 6 && mode != 7)
        rt_die("内存管理模式不支持（%d）", mode);
    g_memmode = mode;
    /* 确定性工具（D）：进入 mode7 且设了 PYBOOK_M7_TRACE，立即打开轨迹文件并注册
     * 退出时终态全收——保证即使运行期一次 GC 都没触发，也能记录终态存活分布。 */
    if (mode == 7 && !g_m7_trace) {
        const char *tf = getenv("PYBOOK_M7_TRACE");
        if (tf && *tf) {
            g_m7_trace = fopen(tf, "w");
            if (g_m7_trace) {
                setvbuf(g_m7_trace, NULL, _IONBF, 0);
                static int g_trace_atexit_done = 0;
                if (!g_trace_atexit_done) {
                    g_trace_atexit_done = 1;
                    atexit(m7_trace_shutdown);
                }
            }
        }
    }
}

/* ---- 设备后端旋钮（文件头 device auto|cpu|gpu）----
 * 语义（前端只查语法、不查硬件；能不能上卡一律运行时探测）：
 *   device cpu  N  强制 CPU，N 个工作线程
 *   device gpu     强制上卡。探测不到卡就 rt_die 明确报错 ——
 *                   用户明写了 gpu，静默退回 CPU 等于骗人
 *   device auto    有卡就用卡，没有就用 CPU（探测一次，结果固定下来）
 * 一旦定下来就不再看有没有卡，保证同一程序前后行为一致。 */
static int g_dev_backend = 0;   /* 0=auto 1=cpu 2=gpu（rt_device_set 之后是 1 或 2） */
static int g_dev_threads = 0;   /* 0=未指定 */

void rt_device_set(int backend, int threads)
{
    if (backend != 0 && backend != 1 && backend != 2)
        rt_die("设备后端不支持（%d）", backend);
    if (threads < 0 || threads > 1024)
        rt_die("device 线程数须在 0~1024（0=按机器逻辑处理器数），收到 %d", threads);
    if (backend == 2) {
        /* 显式要卡：探测不到就必须报错，不许悄悄跑 CPU */
        if (!gpu_probe())
            gpu_die_unavailable();
    } else if (backend == 0) {
        /* auto：探测一次定终身 */
        backend = gpu_probe() ? 2 : 1;
    }
    g_dev_backend = backend;
    g_dev_threads = threads;
}

int rt_device_backend(void)
{
    return g_dev_backend;
}

int rt_device_threads(void)
{
    return g_dev_threads;
}

/* ── GC 根集 ──────────────────────────────────────────────────────────────
 * PYbook 的变量是生成代码里的 C 局部量（Value v_N），GC 没法自己枚举它们，
 * 所以由代码生成器在每个变量声明后调 rt_root_add(&v_N) 把槽地址登记进来；
 * 函数/GOING 块进出用 rt_scope_enter / rt_scope_leave 划分作用域（支持递归）。
 * （g_roots / g_scope 的定义在本文件前面的「try/catch 跳转机制」段里，
 *   那边也要用它们还原 longjmp 跳过的作用域。） */

void rt_scope_enter(void)
{
    if (g_scope_n == g_scope_cap) {
        g_scope_cap = g_scope_cap ? g_scope_cap * 2 : 32;
        g_scope = (size_t *)realloc(g_scope, g_scope_cap * sizeof(size_t));
        if (!g_scope)
            rt_die("内存不足");
    }
    g_scope[g_scope_n++] = g_roots_n;
}

void rt_root_add(Value *slot)
{
    if (g_roots_n == g_roots_cap) {
        g_roots_cap = g_roots_cap ? g_roots_cap * 2 : 64;
        g_roots = (Value **)realloc(g_roots, g_roots_cap * sizeof(Value *));
        if (!g_roots)
            rt_die("内存不足");
    }
    g_roots[g_roots_n++] = slot;
}

void rt_scope_leave(void)
{
    if (g_scope_n)
        g_roots_n = g_scope[--g_scope_n];
}

/* ── 标记：用显式 gray 栈代替递归，既避免深结构爆栈，也天然支持分片 ── */
static RtCell **g_gray = NULL;
static size_t   g_gray_n = 0, g_gray_cap = 0;

static void gray_push_raw(RtCell *c)   /* 只入栈，调用方负责 mark */
{
    if (g_gray_n == g_gray_cap) {
        g_gray_cap = g_gray_cap ? g_gray_cap * 2 : 128;
        g_gray = (RtCell **)realloc(g_gray, g_gray_cap * sizeof(RtCell *));
        if (!g_gray)
            rt_die("内存不足");
    }
    g_gray[g_gray_n++] = c;
}

static void gray_push(RtCell *c)
{
    if (!c || c->mark)
        return;
    c->mark = 1;
    c->gray = 1;              /* 灰＝在栈里待扫；弹出时清成 0 表示黑＝已扫完 */
    gray_push_raw(c);
}

/* 从 gray 栈里处理最多 budget 个单元；返回是否还有剩余。
 * young_only=1 用于 minor GC：**展开自己**（否则 remset 里老年代容器的
 * 新生代子对象会漏标），但子对象若是老年代就只标记、不入栈——
 * 老年代→新生代的引用已由写屏障记在 Remember Set 里，不必顺着老年代往下摸。
 * 这样 minor 才不会退化成半个全堆标记。 */
static int gray_step(size_t budget, int young_only)
{
    while (g_gray_n && budget--) {
        RtCell *c = g_gray[--g_gray_n];
        c->gray = 0;                  /* 出栈＝黑（已扫完） */
        if (c->kind == RTK_LIST) {
            RtList *L = (RtList *)((void *)(c + 1));
            for (size_t i = 0; i < L->len; i++) {
                RtCell *ch = cell_of(L->items[i]);
                if (!ch || ch->mark)
                    continue;
                ch->mark = 1;
                if (young_only && ch->gen != 0)
                    continue;             /* 老年代：标记住就行，不往下走 */
                gray_push_raw(ch);
            }
        } else if (c->kind == RTK_OBJ) {
            RtObject *o = (RtObject *)((void *)(c + 1));
            for (size_t i = 0; i < o->nprops; i++) {
                RtCell *ch = cell_of(o->vals[i]);
                if (!ch || ch->mark)
                    continue;
                ch->mark = 1;
                if (young_only && ch->gen != 0)
                    continue;
                gray_push_raw(ch);
            }
        } else if (c->kind == RTK_DICT) {
            RtDict *D = (RtDict *)((void *)(c + 1));
            gray_push(cell_of(D->pairs));
        }
    }
    return g_gray_n > 0;
}

static void mark_roots(void)
{
    for (size_t i = 0; i < g_roots_n; i++)
        if (g_roots[i])
            gray_push(cell_of(*g_roots[i]));
}

/* ── @6 写屏障：老年代容器写入新生代值时，把容器记入 Remember Set ── */
static RtCell **g_remset = NULL;
static size_t   g_remset_n = 0, g_remset_cap = 0;

static void remember(RtCell *container, Value val)
{
    if (g_memmode != 6 || !container || container->gen != 1)
        return;
    RtCell *vc = cell_of(val);
    if (!vc || vc->gen != 0)
        return;                       /* 只有 old→young 才需要记 */
    for (size_t i = 0; i < g_remset_n; i++)
        if (g_remset[i] == container)
            return;                   /* 已记录 */
    if (g_remset_n == g_remset_cap) {
        g_remset_cap = g_remset_cap ? g_remset_cap * 2 : 64;
        g_remset = (RtCell **)realloc(g_remset, g_remset_cap * sizeof(RtCell *));
        if (!g_remset)
            rt_die("内存不足");
    }
    g_remset[g_remset_n++] = container;
}

/* ── 清除：摘链并回收未标记单元（only_young=1 时只清新生代） ── */
static size_t sweep(int only_young)
{
    size_t freed = 0;
    RtCell *c = g_all;
    while (c) {
        RtCell *nx = c->next;
        if (!c->mark && (!only_young || c->gen == 0)) {
            if (c->owner) {           /* 块内单元：只摘链，内存随块回收 */
                cell_unlink(c);
            } else {
                cell_drop(c, 0);      /* GC 路径：子对象由 sweep 独立回收，不递归 */
            }
            freed++;
        } else {
            c->mark = 0;
            if (only_young && c->gen == 0)
                c->gen = 1;           /* 新生代存活者晋升老年代 */
        }
        c = nx;
    }
    return freed;
}

/* @6 的增量完整标记：分阶段推进，标记做完后一次性清除 */
static int  g_major_phase = 0;        /* 0=空闲 1=标记中 2=待清除 */
static size_t g_gc_threshold = 1024 * 1024;      /* @5 触发阈值 */
static size_t g_knewany_phase = 1024 * 1024;     /* @7 knewany 相位窗口阈值（看人自适应） */
static size_t g_nursery_threshold = 2 * 1024 * 1024;  /* @6 minor 触发阈值（2MB：256KB 时 GC 太频繁，纯分配慢 60 倍）*/
static size_t g_major_threshold = 16 * 1024 * 1024; /* @6 major 触发阈值（要远大于 minor，否则 minor 永远轮不到） */
/* GC 统计（性能剖析用）：minor 次数 / major 次数。smoke.heap() 读它们。 */
static long long g_gc_minor_n = 0, g_gc_major_n = 0;
static long long g_m7_last_pause_ms = 0;   /* 上次 GC 暂停时长（毫秒，可观测性 C） */
static long long g_m7_promoted = 0;        /* 代际晋升累计次数（可观测性 C） */
static FILE *g_m7_trace = NULL;            /* 确定性工具（D）：PYBOOK_M7_TRACE 指向的文件，记录每次 GC 事件 */
static void m7_trace_shutdown(void);       /* 进程退出时终态全收并关闭轨迹文件（D） */
/* 分配量计数（@6 触发用）：每次分配累加，GC 后归零。
   用它触发比用 g_bytes 可靠 —— g_bytes 含老年代，minor 回收新生代后它不降，
   会让阈值判断永远成立（实测触发 13808 次 minor）。 */
static size_t g_alloc_since_gc = 0;

/* ── @6 增量标记的写屏障 ─────────────────────────────────────────
 * 增量标记（g_major_phase != 0）期间程序继续跑，会出两类漏标：
 *   ① 新分配对象：标记器已经扫过它该出现的位置 → 永远标不上 → 被当垃圾收走
 *   ② 已扫完的对象被挂上新引用：新引的对象同样标不上
 * 对策（黑分配 + Yuasa 删除屏障 + Dijkstra 插入屏障）：
 *   · heap_alloc 里增量期间直接 c->mark = 1 —— 新对象生来是黑的，不用标
 *   · 覆盖旧引用前 gc_delete_barrier(旧值)：把旧值标灰，保住"标记开始时
 *     可达的对象"活过本轮（下一轮再回收）
 *   · 新增引用时 gc_insert_barrier(容器, 新值)：容器已是黑、新值是白，
 *     就把容器重新标灰，让它再展开一次
 * gray 字段区分"灰（在栈里待扫）"与"黑（已扫完）"，避免重复入栈。 */

/* 插入屏障：容器写入新引用时，容器已黑、新值仍白 → 把容器重新标灰 */
static void gc_insert_barrier(Value container, Value newval)
{
    if (g_memmode != 6 || g_major_phase == 0)
        return;
    RtCell *cc = cell_of(container);
    RtCell *nc = cell_of(newval);
    if (!cc || !nc)
        return;
    if (!cc->mark || nc->mark)
        return;              /* 父还没扫过（会扫到），或新值已标 → 不用管 */
    if (cc->gray)
        return;              /* 已在 gray 栈里，不重复入栈 */
    cc->gray = 1;
    gray_push_raw(cc);
}

/* 删除屏障：覆盖旧引用前，把旧值标灰（保住快照里可达的对象） */
static void gc_delete_barrier(Value oldval)
{
    if (g_memmode != 6 || g_major_phase == 0)
        return;
    RtCell *oc = cell_of(oldval);
    if (oc && !oc->mark) {
        oc->mark = 1;
        oc->gray = 1;
        gray_push_raw(oc);
    }
}

/* 推进一小片 GC 工作（@6 增量）；返回本片是否做了事 */
int rt_gc_step(void)
{
    if (g_memmode != 6)
        return 0;
    if (g_major_phase == 1) {
        if (gray_step(256, 0))        /* major：全堆标记 */
            return 1;
        g_major_phase = 2;
        return 1;
    }
    if (g_major_phase == 2) {
        g_gc_major_n++;
        sweep(0);
        for (size_t i = 0; i < g_remset_n; i++)
            g_remset[i] = NULL;
        g_remset_n = 0;
        g_major_phase = 0;
        g_nursery_threshold = (g_bytes > 2 * 1024 * 1024 ? g_bytes : 2 * 1024 * 1024) * 2;
        g_major_threshold = (g_bytes > 16 * 1024 * 1024 ? g_bytes : 16 * 1024 * 1024) * 2;
        return 1;
    }
    return 0;
}

/* minor GC（@6）：只清新生代，根集 + Remember Set 作为根 */
static void gc_minor(void)
{
    g_gc_minor_n++;
    mark_roots();
    for (size_t i = 0; i < g_remset_n; i++)
        if (g_remset[i])
            gray_push(g_remset[i]);
    while (gray_step(1000, 1))        /* minor：只标新生代 */
        ;
    sweep(1);
    /* 清掉已失效的 Remember Set 项（对应容器已被回收） */
    size_t k = 0;
    for (size_t i = 0; i < g_remset_n; i++)
        if (g_remset[i] && g_remset[i]->gen == 1)
            g_remset[k++] = g_remset[i];
    g_remset_n = k;
}

/* ================= @7 知命自适应：意图标签 + 相位门控 + tenure 路由 + 压力自适应 + 代际晋升 ================= */
/* 意图标签：0未标 1帧 2关卡 3共享 4图（存在 RtCell.intent） */
/* 升级加强（2026-10-25）：① 相位边界由"固定 2000 语句"改为"分配压力自适应"——
   自上次 GC 起的分配字节超 g_m7_threshold 即提前收，阈值按垃圾比例自调（垃圾多→调低收更勤）；
   ② 代际晋升：未标对象连活 M7_PROMOTE_AFTER 次 minor 后自动升 共享，minor 不再扫它（tenure 路由）。
   二者都确定（分配序列确定→边界确定），不破坏既有意图语义。 */
#define M7_INTENT_NONE   0
#define M7_INTENT_FRAME  1   /* 帧：一次画面/tick 内有效，边界即扔 */
#define M7_INTENT_LEVEL  2   /* 关卡：一关内有效 */
#define M7_INTENT_SHARED 3   /* 共享：跨相位长活，minor 不收 */
#define M7_INTENT_GRAPH  4   /* 图：含循环的引用图，minor 不收，major 才收 */
#define M7_PHASE_STMTS   2000   /* 最大相位长度（语句数硬上限，保证零分配时也终会回收） */
#define M7_MAJOR_EVERY   8      /* 每 8 个相位做一次 major 全收 */
#define M7_PROMOTE_AFTER 3      /* 未标对象连活这么多次 minor 后，自动晋升为 共享(长活) */

static unsigned long g_m7_phase  = 0;   /* 已结束的相位数 */
static unsigned long g_m7_stmts  = 0;   /* 当前相位内的语句计数（硬上限用） */
static int           g_m7_pending = 0;   /* 到边界，待收（仍等语句边界安全点） */
static size_t        g_m7_threshold = 256 * 1024;  /* 压力自适应阈值：自上次 GC 起的分配字节数超此即提前收 */
static size_t        g_m7_alloc = 0;             /* 知命压力计数：heap_alloc + heap_raw 全量字节，仅 mode7 累加/重置 */

/* 给一个值打意图标签（赋值语句后由生成代码调用；C 自测可直接调） */
void rt_intent_tag(Value v, int intent)
{
    if (intent < 0 || intent > 4)
        return;
    RtCell *c = cell_of(v);
    if (c)
        c->intent = (uint8_t)intent;
}

/* ③ 迁移安全屏障（知命）：对象策略"迁移"（代际晋级 / 意图改写 / 槽位复用）
 * 的最大工程风险是搬家后旧引用失效、悬垂指针。本函数把"引用必须可达且有效"
 * 这条不变量钉死在唯一入口——每次赋值（引用建立）都经过它。
 * 当前 mode7 是非移动 GC（标记-清除、指针稳定），屏障今天是无操作；但它是
 * 将来若引入压缩/搬家 GC 时解析转发指针的唯一钩子，调用方零改动。
 * 仅在 mode7 下生效：其他模式的赋值零开销。 */
void rt_ref_barrier(Value *slot)
{
    (void)slot;   /* 非移动 GC：无需动作；此处是可插入转发解析/有效性校验的唯一钩子 */
}

/* 策略迁移的"唯一 sanctioned 入口"：改变一个对象的寿命策略（意图标签）。
 * 与 rt_ref_barrier 配套——所有"搬家/改策略"都走这里，便于将来在迁移时
 * 同步更新引用。今天等价于 rt_intent_tag，但语义上是"迁移"而非"打标"。 */
void rt_intent_migrate(Value v, int new_intent)
{
    rt_intent_tag(v, new_intent);
}

/* 相位边界回收：major=1 全堆（含 共享/图，能收循环），major=0 只收 帧/关卡/未标 */
static void m7_collect(int major)
{
    size_t dropped = 0, kept = 0;
    clock_t t0 = clock();    /* 暂停时长度量（可观测性 C） */
    mark_roots();
    while (gray_step(1000, 0))    /* 全堆标记（非 young_only），循环引用靠标记识别 */
        ;
    RtCell *c = g_all;
    while (c) {
        RtCell *nx = c->next;
        if (!c->mark) {
            if (!major && (c->intent == M7_INTENT_SHARED || c->intent == M7_INTENT_GRAPH))
                ;  /* 跨相位存活：minor 不动它 */
            else {
                cell_drop(c, 0);   /* sweep：子对象由后续遍历独立回收，不递归 */
                dropped++;
            }
        } else {
            kept++;
        }
        c = nx;
    }
    /* 清标记 + 代际晋升（仅未标且存活者）：连活 K 次 minor → 升 共享 */
    for (c = g_all; c; c = c->next) {
        if (c->mark) {
            if (c->intent == M7_INTENT_NONE) {
                c->m7_age++;
                if (c->m7_age >= M7_PROMOTE_AFTER) {
                    c->intent = M7_INTENT_SHARED;  /* 晋升为长活，minor 不再扫 */
                    g_m7_promoted++;               /* 可观测性 C：代际晋升计数 */
                }
            }
        }
        c->mark = 0;
    }
    /* 压力自适应：按本次垃圾比例自调下一相位阈值（整数运算，确定） */
    if (dropped + kept > 0) {
        long long garb = (long long)dropped * 100 / (long long)(dropped + kept);
        if (garb > 40)
            g_m7_threshold = g_m7_threshold * 4 / 5;            /* 垃圾多→收更勤 */
        else if (garb < 10)
            g_m7_threshold = g_m7_threshold * 3 / 2;            /* 垃圾少→收更稀 */
        if (g_m7_threshold < 32 * 1024)        g_m7_threshold = 32 * 1024;       /* 下限 */
        if (g_m7_threshold > 8 * 1024 * 1024)  g_m7_threshold = 8 * 1024 * 1024; /* 上限 */
    }
    g_m7_last_pause_ms = (long long)((clock() - t0) * 1000 / CLOCKS_PER_SEC);  /* 暂停时长 */
    /* 确定性工具（D）：记录本次 GC 事件到轨迹文件（相位/类型/存活/晋升/各意图数） */
    if (g_m7_trace) {
        int ic[5] = {0, 0, 0, 0, 0};
        RtCell *c2;
        for (c2 = g_all; c2; c2 = c2->next) {
            int it = c2->intent;
            if (it < 0 || it > 4)
                it = 0;
            ic[it]++;
        }
        fprintf(g_m7_trace,
                "P%lu %s live=%zu promoted=%lld "
                "none=%d frame=%d level=%d shared=%d graph=%d pause=%lld\n",
                g_m7_phase, major ? "MAJOR" : "MINOR",
                g_live, g_m7_promoted,
                ic[0], ic[1], ic[2], ic[3], ic[4], g_m7_last_pause_ms);
        fflush(g_m7_trace);
    }
    g_m7_alloc = 0;        /* 重置知命压力计数（含 heap_raw） */
    g_m7_stmts = 0;         /* 重置相位语句计数 */
    if (major)
        g_gc_major_n++;
    else
        g_gc_minor_n++;
}

/* 确定性工具（D）：进程退出时由 atexit 调用——终态全收并关闭轨迹文件。
 * 即便程序运行期一次 GC 都没触发，也至少记录终态存活分布，让 --determinism-check 有可比较的轨迹。 */
static void m7_trace_shutdown(void)
{
    if (g_m7_trace) {
        if (g_memmode == 7)
            m7_collect(1);          /* 终态 major 全收，记录最后存活分布 */
        fclose(g_m7_trace);
        g_m7_trace = NULL;
    }
}

/* 手动触发一次完整回收（@5/@6 立即收；@7 做 major 全收；@0/@1/@3/@4 是空操作） */
void rt_gc(void)
{
    if (g_memmode == 5) {
        mark_roots();
        while (gray_step(1000, 0))    /* @5：全堆标记 */
            ;
        sweep(0);
        g_gc_threshold = (g_bytes > 1024 * 1024 ? g_bytes : 1024 * 1024) * 2;
    } else if (g_memmode == 6) {
        if (g_major_phase == 0) {
            mark_roots();
            g_major_phase = 1;
        }
        while (rt_gc_step())
            ;
    } else if (g_memmode == 7) {
        m7_collect(1);   /* 手动触发 = major 全收（含共享/图，能收循环） */
    }
}

/* @4：整块归还竞技场（块内所有单元一起死） */
void rt_arena_reset(void)
{
    for (RtArena *a = g_arena; a; ) {
        RtArena *nx = a->next;
        /* 先摘掉属于这块的所有单元，再放块内存 */
        RtCell *c = g_all;
        while (c) {
            RtCell *nx2 = c->next;
            if (c->owner == a)
                cell_unlink(c);
            c = nx2;
        }
        free(a->mem);
        free(a);
        a = nx;
    }
    g_arena = NULL;
    g_bytes = 0;
    for (RtCell *c = g_all; c; c = c->next)
        g_bytes += 64;   /* 非块内单元的粗略估算（重置后通常只剩它们） */
}

/* 内存统计：返回存活单元数；bytes/live 供调试输出 */
size_t rt_mem_stats(size_t *bytes)
{
    if (bytes)
        *bytes = g_bytes;
    return g_live;
}

/* 语句边界的 GC 轮询：由生成代码在每条语句之后调用。
 * 之所以不放在 heap_alloc 里：求值 a+b 时会先分配出临时对象，而临时值
 * 没有登记为 GC 根，若在分配途中就回收，等于把正在用的对象收走（悬挂指针）。
 * 只在语句边界回收，就能保证"一次求值期间绝不回收"。 */
void rt_gc_poll(void)
{
    if (g_memmode == 5) {
        if (g_bytes > g_gc_threshold)
            rt_gc();
    } else if (g_memmode == 6) {
        if (g_major_phase != 0) {
            rt_gc_step();             /* 增量推进一小片 */
            return;
        }
        if (g_alloc_since_gc > g_major_threshold) {
            /* 老年代攒太多了：启动一次全堆增量标记。
               只在这里"点火"，标记由后续 poll 一片片推进——
               一口气跑完就不叫增量了（长暂停正是 @6 要避免的）。 */
            mark_roots();
            g_major_phase = 1;
            g_alloc_since_gc = 0;
            return;
        }
        if (g_alloc_since_gc > g_nursery_threshold) {
            gc_minor();
            g_alloc_since_gc = 0;
        }
    } else if (g_memmode == 7) {
        /* 相位门控：一个相位（分配窗口）内绝不回收，只累计步数 + 分配压力 */
        g_m7_stmts++;
        /* 边界触发：分配压力超自适应阈值（提前收），或达到语句硬上限（兜底） */
        if (!g_m7_pending &&
            (g_m7_alloc >= g_m7_threshold || g_m7_stmts >= M7_PHASE_STMTS)) {
            g_m7_pending = 1;     /* 到边界，标记待收；此刻仍在求值途中，先不收 */
        }
        if (g_m7_pending) {       /* 本 poll 恰是语句边界，安全回收 */
            g_m7_pending = 0;
            g_m7_phase++;
            m7_collect(g_m7_phase % M7_MAJOR_EVERY == 0);  /* 每8相位 major 全收 */
        }
    }
}

/* ④/B 帧边界对齐（知命）：引擎在每帧/tick 末显式调用，迫使相位边界立即回收，
 * 保证 GC 暂停只发生在帧间、绝不卡在帧内（真·帧内零停顿，语义对齐引擎）。
 * 若本帧无任何分配活动（g_m7_stmts/g_m7_alloc 都为 0）则跳过，避免空转浪费。
 * mode7 外是空操作（其他模式不按相位管理）。 */
void rt_phase_end(void)
{
    if (g_memmode != 7)
        return;
    if (g_m7_stmts == 0 && g_m7_alloc == 0)
        return;   /* 本帧无活动，无需回收 */
    g_m7_pending = 1;
    g_m7_phase++;
    m7_collect(g_m7_phase % M7_MAJOR_EVERY == 0);  /* 帧末回收；每8帧一次 major 全收 */
}

/* delete 的实际执行体：
 * @self：先登记再真正释放（共享同一内存的其他别名会悬空，访问后果自负；
 *        但同一指针的二次 free 由登记表拦下，别名 delete 不崩溃）
 * @3：   引用计数减一（归零即回收）
 * @4：   随竞技场整体回收（这里只打删除标志）
 * @5/@6：交给 GC（这里只打删除标志）
 * @normal：只打删除标志，内存由进程退出统一回收
 * 幂等性：对同一变量第二次 delete 在开头的 IS_DEL 检查处报 "用已删除变量"。 */
void rt_destroy(Value *v)
{
    if (IS_DEL(*v))
        rt_die("用已删除变量");
    RtCell *c = cell_of(*v);
    if (c) {
        void *payload = (void *)(c + 1);
        if (g_memmode == 1 && !ptr_registered(payload)) {
            register_freed(payload);
            cell_drop(c, 1);        /* 真释放：含列表 items 与对象属性名 */
        } else if (g_memmode == 3) {
            rt_release(*v);         /* 计数减一，归零即回收 */
        }
    }
    *v = RT_DELETED_BOX;
}

/* ================= 算术 ================= */

/* rt_add / rt_sub / rt_mul 的公共实现 */
static Value arith(Value a, Value b, char op)
{
    if (IS_TENSOR(a) && IS_TENSOR(b)) {      /* 张量逐元素加减乘除 */
        RtTensor *x = rt_as_tensor(a), *y = rt_as_tensor(b);
        if (x->ndim != y->ndim)
            rt_die("张量逐元素运算：维数必须相同");
        for (int k = 0; k < x->ndim; k++)
            if (x->dims[k] != y->dims[k])
                rt_die("张量逐元素运算：形状必须一致（%d vs %d）", x->dims[k], y->dims[k]);
        size_t n = 1;
        for (int k = 0; k < x->ndim; k++) n *= (size_t)x->dims[k];
        /* 任一输入是 float32 → 输出也是 float32（逐元素运算不提升精度） */
        int prec = (x->prec == TENSOR_F32 || y->prec == TENSOR_F32)
                       ? TENSOR_F32 : TENSOR_F64;
        Value out = rt_tensor_new_p(x->ndim, x->dims, prec);
        RtTensor *o = rt_as_tensor(out);
        for (size_t i = 0; i < n; i++) {
            double u = x->data[i], w = y->data[i];
            double r = (op == '+') ? u + w : (op == '-') ? u - w
                      : (op == '*') ? u * w : (w == 0 ? rt_die("张量除法除以 0"), 0.0 : u / w);
            o->data[i] = rt_tensor_round(prec, r);
        }
        return out;
    }
    if (IS_TENSOR(a) || IS_TENSOR(b))
        rt_die("张量只能和同形张量做逐元素运算（矩阵乘请用 ** ）");
    if (IS_STR(a) && IS_STR(b)) {
        if (op != '+')
            rt_die(op == '-' ? "类型不可相减" : "类型不可相乘");
        size_t la = strlen(AS_STR(a)), lb = strlen(AS_STR(b));
        char *r = (char *)heap_alloc(RTK_STR, la + lb + 1);
        memcpy(r, AS_STR(a), la);
        memcpy(r + la, AS_STR(b), lb);
        r[la + lb] = '\0';
        return MAKE_STR(r);
    }
    if (is_num(a) && is_num(b)) {
        if (IS_FLT(a) || IS_FLT(b)) {
            double x = as_flt(a), y = as_flt(b);
            return rt_float(op == '+' ? x + y : op == '-' ? x - y : x * y);
        }
        long long x = as_int(a), y = as_int(b), r = 0;
        int ov = op == '+' ? __builtin_add_overflow(x, y, &r)
               : op == '-' ? __builtin_sub_overflow(x, y, &r)
               :             __builtin_mul_overflow(x, y, &r);
        if (ov)
            rt_die("溢出");
        return rt_int(r);   /* 结果落在快路径外自动转 BIGINT */
    }
    rt_die(op == '+' ? "类型不可相加" : op == '-' ? "类型不可相减" : "类型不可相乘");
    return rt_none();   /* 不可达 */
}

Value rt_add(Value a, Value b) { return arith(a, b, '+'); }
Value rt_sub(Value a, Value b) { return arith(a, b, '-'); }
Value rt_mul(Value a, Value b) { return arith(a, b, '*'); }

Value rt_div(Value a, Value b)
{
    if (!is_num(a) || !is_num(b))
        rt_die("类型不可相除");
    if (IS_FLT(b) ? AS_FLT(b) == 0.0 : as_int(b) == 0)
        rt_die("除以零");
    return rt_float(as_flt(a) / as_flt(b));   /* 真除法，结果一律 float */
}

Value rt_fdiv(Value a, Value b)
{
    if (!is_num(a) || !is_num(b))
        rt_die("类型不可整除");
    if (!IS_FLT(a) && !IS_FLT(b)) {
        long long x = as_int(a), y = as_int(b);
        if (y == 0)
            rt_die("除以零");
        if (x == LLONG_MIN && y == -1)
            rt_die("溢出");   /* 商 2^63 超出 long long */
        long long q = x / y;  /* C 的 / 向零取整，下面修成向下取整 */
        if (x % y != 0 && ((x < 0) != (y < 0)))
            q--;
        return rt_int(q);
    }
    double y = as_flt(b);
    if (y == 0.0)
        rt_die("除以零");
    return rt_float(floor(as_flt(a) / y));
}

Value rt_mod(Value a, Value b)
{
    if (!is_num(a) || !is_num(b))
        rt_die("类型不可取模");
    if (!IS_FLT(a) && !IS_FLT(b)) {
        long long x = as_int(a), y = as_int(b);
        if (y == 0)
            rt_die("除以零");
        if (y == -1)
            return rt_int(0);   /* LLONG_MIN % -1 在 C 里未定义；数学上余数恒为 0 */
        long long r = x % y;    /* C 的 % 符号跟被除数，下面修成跟除数 */
        if (r != 0 && ((r < 0) != (y < 0)))
            r += y;
        return rt_int(r);
    }
    double x = as_flt(a), y = as_flt(b);
    if (y == 0.0)
        rt_die("除以零");
    double r = fmod(x, y);
    if (r != 0.0 && ((r < 0.0) != (y < 0.0)))
        r += y;
    return rt_float(r);
}

Value rt_neg(Value a)
{
    if (IS_FLT(a))
        return rt_float(-AS_FLT(a));
    if (IS_INT(a) || IS_BIGINT(a) || IS_BOOL(a)) {
        long long r;
        if (__builtin_sub_overflow((long long)0, as_int(a), &r))
            rt_die("溢出");   /* -LLONG_MIN 溢出 */
        return rt_int(r);
    }
    rt_die("负号只能用于数字");
    return rt_none();   /* 不可达 */
}

/* ================= 真值与逻辑 ================= */

int rt_cond(Value v)
{
    if (IS_DEL(v))  return 0;   /* 删除占位按假（正常流在 rt_chk 就被拦下了） */
    if (IS_NONE(v)) return 0;
    if (IS_INT(v) || IS_BIGINT(v)) return as_int(v) != 0;
    if (IS_FLT(v))  return AS_FLT(v) != 0.0;
    if (IS_BOOL(v)) return AS_BOOL(v) != 0;
    if (IS_STR(v)) {
        const char *s = AS_STR(v);
        return s != NULL && s[0] != '\0';
    }
    if (IS_LIST(v)) return AS_LIST(v) != NULL && AS_LIST(v)->len > 0;
    if (IS_OBJ(v))  return 1;   /* 对象存在即为真（恒真） */
    return 0;
}

Value rt_not(Value a) { return rt_bool(!rt_cond(a)); }

/* ================= 比较 ================= */

/* 深度相等比较（== / != / list.unique / list.find 共用）。
 * Python 语义永不报错：不同类型就是不相等；列表递归；对象比指针身份。 */
static int values_equal(Value a, Value b)
{
    if (IS_TENSOR(a) || IS_TENSOR(b)) {
        if (!IS_TENSOR(a) || !IS_TENSOR(b))
            return 0;
        RtTensor *x = rt_as_tensor(a), *y = rt_as_tensor(b);
        if (x->ndim != y->ndim)
            return 0;
        for (int k = 0; k < x->ndim; k++)
            if (x->dims[k] != y->dims[k])
                return 0;
        size_t n = 1;
        for (int k = 0; k < x->ndim; k++) n *= (size_t)x->dims[k];
        for (size_t i = 0; i < n; i++)
            if (x->data[i] != y->data[i])
                return 0;
        return 1;
    }
    if (IS_OBJ(a) || IS_OBJ(b)) {
        if (!IS_OBJ(a) || !IS_OBJ(b))
            return 0;   /* 对象与其他类型：判不等 */
        return AS_OBJ(a) == AS_OBJ(b);   /* 指针身份：同一对象才相等 */
    }
    if (IS_LIST(a) || IS_LIST(b)) {
        if (!IS_LIST(a) || !IS_LIST(b))
            return 0;
        RtList *A = AS_LIST(a), *B = AS_LIST(b);
        if (A == B)
            return 1;
        if (!A || !B)
            return A == B;
        if (A->len != B->len)
            return 0;
        for (size_t i = 0; i < A->len; i++)
            if (!values_equal(A->items[i], B->items[i]))
                return 0;
        return 1;
    }
    if (IS_NONE(a) && IS_NONE(b))
        return 1;
    if (is_num(a) && is_num(b)) {
        if (IS_FLT(a) || IS_FLT(b))
            return as_flt(a) == as_flt(b);
        return as_int(a) == as_int(b);
    }
    if (IS_STR(a) && IS_STR(b))
        return strcmp(AS_STR(a) ? AS_STR(a) : "", AS_STR(b) ? AS_STR(b) : "") == 0;
    return 0;
}

/* 三态比较（< > <= >= 与 list 排序/max/min 共用）：-1 / 0 / 1；
 * 不可比较（混类型）直接报错退出——== 宽容、< 严格，两者刻意不同。 */
static int compare_values(Value a, Value b)
{
    if (IS_TENSOR(a) || IS_TENSOR(b))
        rt_die("张量不可排序比较（< > <= >=）");
    if (IS_OBJ(a) || IS_OBJ(b)) {
        if (!IS_OBJ(a) || !IS_OBJ(b))
            rt_die("类型不可比较");   /* 对象与数字/字符串之间无排序 */
        return (AS_OBJ(a) > AS_OBJ(b)) - (AS_OBJ(a) < AS_OBJ(b));   /* 指针身份 */
    }
    if (is_num(a) && is_num(b)) {
        if (IS_FLT(a) || IS_FLT(b)) {
            double x = as_flt(a), y = as_flt(b);
            return (x > y) - (x < y);
        }
        long long x = as_int(a), y = as_int(b);
        return (x > y) - (x < y);
    }
    if (IS_STR(a) && IS_STR(b)) {
        int c = strcmp(AS_STR(a) ? AS_STR(a) : "", AS_STR(b) ? AS_STR(b) : "");
        return (c > 0) - (c < 0);
    }
    if (IS_NONE(a) && IS_NONE(b))
        return 0;
    rt_die("类型不可比较");
    return 0;   /* 不可达 */
}

Value rt_eq(Value a, Value b) { return rt_bool(values_equal(a, b)); }
Value rt_ne(Value a, Value b) { return rt_bool(!values_equal(a, b)); }
Value rt_lt(Value a, Value b) { return rt_bool(compare_values(a, b) <  0); }
Value rt_gt(Value a, Value b) { return rt_bool(compare_values(a, b) >  0); }
Value rt_le(Value a, Value b) { return rt_bool(compare_values(a, b) <= 0); }
Value rt_ge(Value a, Value b) { return rt_bool(compare_values(a, b) >= 0); }

/* ================= 显示（rt_str_of） ================= */

char *rt_str_of(Value v)
{
    char buf[64];
    if (IS_INT(v) || IS_BIGINT(v)) {
        snprintf(buf, sizeof buf, "%lld", as_int(v));
        return dup_str(buf);
    }
    if (IS_FLT(v)) {
        snprintf(buf, sizeof buf, "%.15g", AS_FLT(v));   /* %g 自动去掉多余尾零 */
        return dup_str(buf);
    }
    if (IS_BOOL(v))
        return dup_str(AS_BOOL(v) ? "true" : "false");
    if (IS_TENSOR(v))
        return rt_tensor_str(rt_as_tensor(v));
    if (IS_OBJ(v)) {
        RtObject *o = AS_OBJ(v);
        const char *cn = (o && o->cls) ? o->cls : "";
        size_t n = strlen(cn) + 16;
        char *out = (char *)malloc(n);
        if (!out)
            rt_die("内存不足");
        snprintf(out, n, "[%s 对象]", cn);
        return out;   /* 如 "[狗 对象]" */
    }
    if (IS_STR(v))
        return AS_STR(v) ? AS_STR(v) : (char *)"";   /* 原样：直接返回内部指针 */
    if (IS_DICT(v)) {
        RtDict *D = (RtDict *)AS_DICT(v);
        RtList *L = D ? AS_LIST(D->pairs) : NULL;
        size_t cap = 64 + (L ? L->len * 40 : 0);
        size_t used = 0;
        char *out = (char *)malloc(cap);
        if (!out)
            rt_die("内存不足");
        out[used++] = '{';
        if (L) {
            for (size_t i = 0; i < L->len; i++) {
                RtList *pair = AS_LIST(L->items[i]);
                if (!pair || pair->len != 2)
                    continue;
                const char *ks = rt_str_of(pair->items[0]);
                const char *vs = rt_str_of(pair->items[1]);
                size_t need = strlen(ks) + strlen(vs) + 8;
                if (used + need >= cap) {
                    cap = cap * 2 + need;
                    out = (char *)realloc(out, cap);
                    if (!out)
                        rt_die("内存不足");
                }
                if (i) {
                    out[used++] = ',';
                    out[used++] = ' ';
                }
                out[used++] = '"';
                size_t pl = strlen(ks);
                memcpy(out + used, ks, pl);
                used += pl;
                out[used++] = '"';
                out[used++] = ':';
                out[used++] = ' ';
                pl = strlen(vs);
                memcpy(out + used, vs, pl);
                used += pl;
            }
        }
        out[used++] = '}';
        out[used] = 0;
        return out;
    }
    if (IS_LIST(v)) {
        RtList *L = AS_LIST(v);
        size_t cap = 64 + (L ? L->len * 24 : 0);
        size_t used = 0;
        char *out = (char *)malloc(cap);
        if (!out)
            rt_die("内存不足");
        out[used++] = '[';
        if (L) {
            for (size_t i = 0; i < L->len; i++) {
                const char *piece = rt_str_of(L->items[i]);
                size_t need = strlen(piece) + 3;
                if (used + need >= cap) {
                    cap = cap * 2 + need;
                    out = (char *)realloc(out, cap);
                    if (!out)
                        rt_die("内存不足");
                }
                if (i) {
                    out[used++] = ',';
                    out[used++] = ' ';
                }
                size_t pl = strlen(piece);
                memcpy(out + used, piece, pl);
                used += pl;
            }
        }
        if (used + 2 >= cap) {
            cap = used + 2;
            out = (char *)realloc(out, cap);
            if (!out)
                rt_die("内存不足");
        }
        out[used++] = ']';
        out[used] = '\0';
        return out;
    }
    return dup_str("空");   /* 空盒 / 删除占位等 */
}

/* ================= 容器（列表核心） ================= */

/* 取列表结构；删除状态/类型不符直接报错 */
static RtList *as_list(Value v, const char *ctx)
{
    if (IS_DEL(v))
        rt_die("用已删除变量");
    if (!IS_LIST(v) || AS_LIST(v) == NULL)
        rt_die("%s：目标不是列表", ctx);
    return AS_LIST(v);
}

/* 下标归一化：只收 INT/BOOL；负数从尾数；越界报错 */
static size_t norm_index(size_t len, Value idx, const char *ctx)
{
    if (!IS_INT(idx) && !IS_BOOL(idx))
        rt_die("%s：下标必须是整数", ctx);
    long long i = as_int(idx);
    if (i < 0)
        i += (long long)len;
    if (i < 0 || (size_t)i >= len)
        rt_die("%s：下标越界", ctx);
    return (size_t)i;
}

static RtDict *as_dict(Value v, const char *who)
{
    if (IS_DEL(v))
        rt_die("用已删除变量");
    if (!IS_DICT(v) || AS_DICT(v) == NULL)
        rt_die("%s：目标不是字典", who);
    return (RtDict *)AS_DICT(v);
}

Value rt_dict_new(void)
{
    RtDict *D = (RtDict *)heap_alloc(RTK_DICT, sizeof(RtDict));
    D->pairs = rt_list_new();
    /* ⚠ 这四个哈希字段**必须**显式清零 —— heap_alloc 走的是 malloc（@4 走 arena_bump），
     * 都**不做零初始化**，里面装的是堆上的垃圾。
     * 不清零的后果（实测，血案）：dict_hfind 一上来就 `if (D->hdirty)` / `if (D->hcap == 0)`，
     * 垃圾 hcap 非 0 时它会走进哈希路径去解引用**垃圾指针** D->hk[slot] → 段错误。
     * 表现为"同一份 exe 连跑 10 次崩 3 次"—— 因为新页从 OS 来是干净的（多数时候侥幸为 0），
     * 复用被释放过的内存时就炸。与 Memoryment 模式无关（不是 GC 的锅）。 */
    D->hk     = NULL;
    D->hcap   = 0;
    D->hused  = 0;
    D->hdirty = 0;
    return MAKE_DICT(D);
}

/* ---- set 集合：无值字典（键=元素、值=1）。与 rt_in 的 IS_DICT 分支天然互通 ---- */
Value rt_set_new(void)
{
    return rt_dict_new();
}

Value rt_set_add(Value st, Value v)
{
    rt_dict_set(&st, v, rt_int(1));
    return st;
}

Value rt_set_del(Value st, Value v)
{
    Value r = rt_dict_del(st, v);
    return r;
}

Value rt_set_has(Value st, Value v)
{
    return rt_int(rt_dict_has(st, v));      /* 通用库调用包装期望 Value 返回 */
}

Value rt_set_len(Value st)
{
    return rt_len(st);
}

Value rt_set_items(Value st)
{
    return rt_dict_keys(st);
}

Value rt_list_new(void)
{
    RtList *L = (RtList *)heap_alloc(RTK_LIST, sizeof(RtList));
    L->len = 0;
    L->cap = 4;
    L->items = (Value *)heap_raw(L->cap * sizeof(Value));
    return MAKE_LIST(L);
}

Value rt_push(Value *dst, Value v)
{
    if (slot_is_locked(dst))
        rt_die("变量已锁定");
    if (IS_DEL(*dst))
        rt_die("用已删除变量");
    if (!IS_LIST(*dst) || AS_LIST(*dst) == NULL)
        rt_die("添加：目标不是列表");
    RtList *L = AS_LIST(*dst);
    if (L->len == L->cap) {
        size_t oldn = L->cap * sizeof(Value);
        L->cap *= 2;
        L->items = (Value *)heap_raw_grow(L->items, cell_of(*dst), oldn,
                                          L->cap * sizeof(Value));
    }
    L->items[L->len++] = v;
    if (g_memmode == 3)
        rt_retain(v);          /* 列表持有元素引用 */
    if (g_memmode == 6) {
        remember(cell_of(*dst), v);       /* old→young 写屏障 */
        gc_insert_barrier(*dst, v);       /* @6 增量标记：容器已黑则重新标灰 */
    }
    return rt_none();
}

long long rt_list_len_ll(Value lst)
{
    if (!IS_LIST(lst) || AS_LIST(lst) == NULL)
        rt_die("这里需要一个列表");
    return (long long)AS_LIST(lst)->len;
}

Value rt_list_remove(Value lst, Value item)
{
    if (IS_DICT(lst))
        return rt_dict_del(lst, item);
    if (IS_DEL(lst))
        rt_die("用已删除变量");
    if (!IS_LIST(lst) || AS_LIST(lst) == NULL)
        rt_die("删掉：目标不是列表");
    RtList *L = AS_LIST(lst);
    for (size_t i = 0; i < L->len; i++) {
        if (rt_cond(rt_eq(L->items[i], item))) {
            if (g_memmode == 3)
                rt_release(L->items[i]);   /* 与 rt_push 的 retain 对称 */
            if (i < L->len - 1)
                memmove(L->items + i, L->items + i + 1,
                        (L->len - i - 1) * sizeof(Value));
            L->len--;
            return rt_int(1);
        }
    }
    return rt_int(0);
}

static Value rt_tensor_row(Value m, Value i);   /* 前向声明：定义在张量区块（static） */

Value rt_index(Value lst, Value idx)
{
    if (IS_DEL(lst))
        rt_die("用已删除变量");
    if (IS_TENSOR(lst))                       /* 张量：单下标取行（1D 取元素） */
        return rt_tensor_row(lst, idx);
    if (IS_DICT(lst)) {                       /* 字典：按键取值，键不存在 → 报错 */
        RtDict *D = (RtDict *)AS_DICT(lst);
        int found = 0;
        size_t pidx = dict_hfind(D, idx, &found);
        if (found) {
            RtList *L = AS_LIST(D->pairs);
            RtList *pair = AS_LIST(L->items[pidx]);
            return pair->items[1];
        }
        rt_die("字典里没有这个键");
    }
    if (IS_STR(lst)) {                        /* 字符串下标：按 UTF-8 字符取 */
        const char *s = AS_STR(lst) ? AS_STR(lst) : "";
        long long n = utf8_count(s);
        long long i = norm_index((size_t)n, idx, "下标");
        s = utf8_at(s, i);
        size_t len = 1;
        while (s[len] && ((unsigned char)s[len] & 0xC0) == 0x80)
            len++;
        char one[8];
        memcpy(one, s, len);
        one[len] = '\0';
        return rt_str(one);
    }
    RtList *L = as_list(lst, "下标");
    size_t k = norm_index(L->len, idx, "下标");
    return L->items[k];
}

/* 切片 lst[a:b:step]：任一段可为 INT_MIN 哨兵（缺省）。语义与 Python 对齐。 */
Value rt_list_slice(Value lst, Value av, Value bv, Value cv)
{
    if (IS_DEL(lst))
        rt_die("用已删除变量");
    if (IS_TENSOR(lst))            /* 张量切片：单维切片作用在行上，列段缺省为全部 */
        return rt_tensor_slice(lst, av, bv, rt_none(), rt_none());
    RtList *L = as_list(lst, "切片");
    long long n = (long long)L->len;
    const long long MISS = -2147483647LL - 1;
    long long a = IS_INT(av) ? as_int(av) : MISS;
    long long b = IS_INT(bv) ? as_int(bv) : MISS;
    long long st = IS_INT(cv) ? as_int(cv) : MISS;
    if (st == MISS) st = 1;
    if (st == 0)
        rt_die("切片：步长不能为 0");
    long long i, stop;
    Value out = rt_list_new();
    if (st > 0) {
        i    = (a == MISS) ? 0  : (a < 0 ? a + n : a);
        stop = (b == MISS) ? n  : (b < 0 ? b + n : b);
        if (i < 0) i = 0;
        if (i > n) i = n;
        if (stop < 0) stop = 0;
        if (stop > n) stop = n;
        for (; i < stop; i += st)
            rt_push(&out, L->items[i]);
    } else {
        i    = (a == MISS) ? n - 1 : (a < 0 ? a + n : a);
        stop = (b == MISS) ? -1    : (b < 0 ? b + n : b);
        if (i > n - 1) i = n - 1;
        if (stop < -1) stop = -1;
        for (; i > stop; i += st)
            if (i >= 0 && i < n)
                rt_push(&out, L->items[i]);
    }
    return out;
}

/* in 运算：列表按相等线性查找；两边都是字符串时按子串判断 */
Value rt_in(Value item, Value lst)
{
    if (IS_DICT(lst))
        return rt_int(rt_dict_has(lst, item));
    if (IS_STR(lst) && IS_STR(item))
        return rt_int(strstr(AS_STR(lst) ? AS_STR(lst) : "",
                             AS_STR(item) ? AS_STR(item) : "") != NULL);
    RtList *L = as_list(lst, "in");
    for (size_t k = 0; k < L->len; k++)
        if (rt_cond(rt_eq(L->items[k], item)))
            return rt_int(1);
    return rt_int(0);
}

Value rt_not_in(Value item, Value lst)
{
    return rt_cond(rt_in(item, lst)) ? rt_int(0) : rt_int(1);
}

void rt_setindex(Value *lst, Value idx, Value v)
{
    if (IS_DEL(*lst))
        rt_die("用已删除变量");
    if (slot_is_locked(lst))
        rt_die("变量已锁定");
    if (IS_TENSOR(*lst))                      /* 张量单下标赋值走 tb.set / T[i,j]=v */
        rt_die("张量不支持单下标赋值，请用 T[i,j] = 值 或 tb.set");
    if (IS_DICT(*lst)) {                      /* 字典：键存在覆盖，不存在追加 */
        RtDict *D = (RtDict *)AS_DICT(*lst);
        int found = 0;
        size_t pidx = dict_hfind(D, idx, &found);
        if (found) {
            RtList *L = AS_LIST(D->pairs);
            RtList *pair = AS_LIST(L->items[pidx]);
            if (g_memmode == 3) {
                rt_retain(v);
                rt_release(pair->items[1]);
            }
            gc_delete_barrier(pair->items[1]);   /* @6 增量标记 */
            pair->items[1] = v;
            gc_insert_barrier(*lst, v);          /* @6 增量标记 */
            return;
        }
        Value pair = rt_list_new();
        rt_push(&pair, idx);
        rt_push(&pair, v);
        rt_push(&D->pairs, pair);
        dict_hinsert(D, idx, AS_LIST(D->pairs)->len - 1);
        return;
    }
    if (!IS_LIST(*lst) || AS_LIST(*lst) == NULL)
        rt_die("下标赋值：目标不是列表");
    RtList *L = AS_LIST(*lst);
    size_t k = norm_index(L->len, idx, "下标赋值");
    if (g_memmode == 3) {
        rt_retain(v);            /* 先保新后放旧 */
        rt_release(L->items[k]);
    }
    gc_delete_barrier(L->items[k]);       /* @6 增量标记：覆盖前保住旧值 */
    L->items[k] = v;
    if (g_memmode == 6) {
        remember(cell_of(*lst), v);
        gc_insert_barrier(*lst, v);       /* @6 增量标记：容器已黑则重新标灰 */
    }
}

/* ================= 字典操作（set/get/has/del/长度/键序） ================= */

Value rt_dict_set(Value *d, Value k, Value v)
{
    if (!IS_DICT(*d))
        rt_die("字典赋值：目标不是字典");
    RtDict *D = (RtDict *)AS_DICT(*d);
    int found = 0;
    size_t pidx = dict_hfind(D, k, &found);
    if (found) {
        RtList *L = AS_LIST(D->pairs);
        RtList *pair = AS_LIST(L->items[pidx]);
        if (g_memmode == 3) {              /* 保新放旧（与 rt_setindex 一致） */
            rt_retain(v);
            rt_release(pair->items[1]);
        }
        gc_delete_barrier(pair->items[1]);       /* @6 增量标记 */
        pair->items[1] = v;
        gc_insert_barrier(*d, v);                /* @6 增量标记 */
        return rt_none();
    }
    Value pair = rt_list_new();
    rt_push(&pair, k);
    rt_push(&pair, v);
    rt_push(&D->pairs, pair);
    dict_hinsert(D, k, AS_LIST(D->pairs)->len - 1);
    return rt_none();
}

long long rt_dict_len_ll(Value d)
{
    RtDict *D = as_dict(d, "长度");
    RtList *L = AS_LIST(D->pairs);
    return L ? (long long)L->len : 0;
}

Value rt_dict_key_at(Value d, long long i)
{
    RtDict *D = as_dict(d, "字典遍历");
    RtList *L = AS_LIST(D->pairs);
    if (!L || i < 0 || (size_t)i >= L->len)
        rt_die("字典遍历：下标越界");
    RtList *pair = AS_LIST(L->items[i]);
    return pair ? pair->items[0] : rt_none();
}

Value rt_dict_get(Value d, Value k)
{
    RtDict *D = as_dict(d, "字典取值");
    int found = 0;
    size_t pidx = dict_hfind(D, k, &found);
    if (found) {
        RtList *L = AS_LIST(D->pairs);
        RtList *pair = AS_LIST(L->items[pidx]);
        return pair->items[1];
    }
    rt_die("字典里没有这个键");
    rt_die("字典里没有这个键");
}

long long rt_dict_has(Value d, Value k)
{
    RtDict *D = as_dict(d, "in");
    int found = 0;
    dict_hfind(D, k, &found);
    return found == 1 ? 1 : 0;
    return 0;
}

Value rt_dict_del(Value d, Value k)
{
    RtDict *D = as_dict(d, "删掉");
    int found = 0;
    size_t pidx = dict_hfind(D, k, &found);
    if (!found)
        rt_die("删掉：字典里没有这个键");
    RtList *L = AS_LIST(D->pairs);
    Value pv = L->items[pidx];
    rt_list_remove(D->pairs, pv);
    D->hdirty = 1;                          /* 下标移位：哈希待重建 */
    return rt_none();
    rt_die("删掉：字典里没有这个键");
}

long long rt_iter_len_ll(Value v)
{
    if (IS_DICT(v))
        return rt_dict_len_ll(v);
    return rt_list_len_ll(v);
}

Value rt_dict_keys(Value d)
{
    RtDict *D = as_dict(d, "dict.keys");
    RtList *L = AS_LIST(D->pairs);
    Value out = rt_list_new();
    for (size_t k2 = 0; L && k2 < L->len; k2++) {
        RtList *pair = AS_LIST(L->items[k2]);
        if (pair && pair->len == 2)
            rt_push(&out, pair->items[0]);
    }
    return out;
}

Value rt_dict_values(Value d)
{
    RtDict *D = as_dict(d, "dict.values");
    RtList *L = AS_LIST(D->pairs);
    Value out = rt_list_new();
    for (size_t k2 = 0; L && k2 < L->len; k2++) {
        RtList *pair = AS_LIST(L->items[k2]);
        if (pair && pair->len == 2)
            rt_push(&out, pair->items[1]);
    }
    return out;
}
/* 安全访问：字典.get(键, 缺省)——键不存在给缺省而不炸 */
Value rt_safe_get(Value d, Value k, Value 缺省)
{
    if (!IS_DICT(d) || AS_DICT(d) == NULL)
        return 缺省;
    RtDict *D = (RtDict *)AS_DICT(d);
    RtList *L = AS_LIST(D->pairs);
    for (size_t k2 = 0; L && k2 < L->len; k2++) {
        RtList *pair = AS_LIST(L->items[k2]);
        if (pair && pair->len == 2 && rt_cond(rt_eq(pair->items[0], k)))
            return pair->items[1];
    }
    return 缺省;
}

/* 安全访问：表.at(下标, 缺省)——越界给缺省而不炸；也兼容字符串按字符取 */
Value rt_safe_at(Value lst, Value idx, Value 缺省)
{
    if (IS_LIST(lst)) {
        RtList *L = AS_LIST(lst);
        if (!L || !IS_INT(idx) && !IS_BOOL(idx))
            return 缺省;
        long long i = as_int(idx);
        if (i < 0) i += (long long)L->len;
        if (i < 0 || (size_t)i >= L->len)
            return 缺省;
        return L->items[i];
    }
    if (IS_DICT(lst))
        return rt_safe_get(lst, idx, 缺省);
    if (IS_STR(lst)) {
        long long n = (long long)utf8_count(AS_STR(lst) ? AS_STR(lst) : "");
        long long i = IS_INT(idx) ? as_int(idx) : -1;
        if (i < 0) i += n;
        if (i < 0 || i >= n)
            return 缺省;
        return rt_index(lst, idx);
    }
    return 缺省;
}



Value rt_len(Value v)
{
    if (IS_TENSOR(v))
        return rt_int((long long)rt_as_tensor(v)->dims[0]);
    if (IS_DICT(v))
        return rt_int(rt_dict_len_ll(v));
    if (IS_LIST(v))
        return rt_int((long long)(AS_LIST(v) ? AS_LIST(v)->len : 0));
    if (IS_STR(v))
        return rt_int(utf8_count(AS_STR(v) ? AS_STR(v) : ""));
    rt_die("长度 只能用于列表或字符串");
    return rt_none();   /* 不可达 */
}

/* ================= 列表扩展（sort/reverse/unique/merge/find/max/min） ================= */

/* qsort 比较器：数字按值、字符串按字典序、对象按指针；混类型在 compare_values 里报错退出 */
static int list_cmp_qsort(const void *pa, const void *pb)
{
    return compare_values(*(const Value *)pa, *(const Value *)pb);
}

/* 排序出新表（原表不动），升序 */
/* 降序出新表 */
Value rt_list_rsorted(Value lst)
{
    Value out = rt_list_sorted(lst);
    RtList *L = AS_LIST(out);
    size_t n = L->len;
    for (size_t k = 0; k < n / 2; k++) {
        Value t = L->items[k];
        L->items[k] = L->items[n - 1 - k];
        L->items[n - 1 - k] = t;
    }
    return out;
}

static char g_byfield名[128];       /* qsort 比较器无上下文，借静态传递字段名 */

static int byfield_cmp(const void *pa, const void *pb)
{
    Value av = rt_none(), bv = rt_none();
    Value a = *(const Value *)pa, b = *(const Value *)pb;
    if (IS_OBJ(a)) {
        RtObject *o = AS_OBJ(a);
        for (size_t i = 0; o && i < o->nprops; i++)
            if (!strcmp(o->names[i], g_byfield名)) { av = o->vals[i]; break; }
    }
    if (IS_OBJ(b)) {
        RtObject *o = AS_OBJ(b);
        for (size_t i = 0; o && i < o->nprops; i++)
            if (!strcmp(o->names[i], g_byfield名)) { bv = o->vals[i]; break; }
    }
    return compare_values(av, bv);
}

/* 对象列表按字段排序：方向 1=升序，-1=降序；出新表 */
Value rt_list_byfield(Value lst, Value 名v, Value dirv)
{
    RtList *L = as_list(lst, "按字段排序");
    if (!IS_STR(名v))
        rt_die("按字段排序：字段名必须是字符串");
    snprintf(g_byfield名, sizeof g_byfield名, "%s", AS_STR(名v));
    Value out = rt_list_new();
    for (size_t k = 0; k < L->len; k++)
        rt_push(&out, L->items[k]);
    qsort(AS_LIST(out)->items, AS_LIST(out)->len, sizeof(Value), byfield_cmp);
    if (as_int(dirv) < 0) {
        size_t n = AS_LIST(out)->len;
        for (size_t k = 0; k < n / 2; k++) {
            Value t = AS_LIST(out)->items[k];
            AS_LIST(out)->items[k] = AS_LIST(out)->items[n - 1 - k];
            AS_LIST(out)->items[n - 1 - k] = t;
        }
    }
    return out;
}

/* list.flat：一层展平 [[1,2],[3]] -> [1,2,3] */
Value rt_list_flat(Value lst)
{
    if (!IS_LIST(lst) || AS_LIST(lst) == NULL)
        rt_die("list.flat 需要列表");
    Value out = rt_list_new();
    RtList *L = AS_LIST(lst);
    for (size_t i = 0; i < L->len; i++) {
        if (!IS_LIST(L->items[i]) || AS_LIST(L->items[i]) == NULL)
            rt_die("list.flat：第 %zu 个元素不是列表", i + 1);
        RtList *inner = AS_LIST(L->items[i]);
        for (size_t j = 0; j < inner->len; j++)
            rt_push(&out, inner->items[j]);
    }
    return out;
}

/* list.zip：两表按位配对成 [[a0,b0],[a1,b1],...]，取短的长度 */
Value rt_list_zip(Value a, Value b)
{
    if (!IS_LIST(a) || !IS_LIST(b) || AS_LIST(a) == NULL || AS_LIST(b) == NULL)
        rt_die("list.zip 需要两个列表");
    RtList *A = AS_LIST(a), *B = AS_LIST(b);
    size_t n = A->len < B->len ? A->len : B->len;
    Value out = rt_list_new();
    for (size_t i = 0; i < n; i++) {
        Value pair = rt_list_new();
        rt_push(&pair, A->items[i]);
        rt_push(&pair, B->items[i]);
        rt_push(&out, pair);
    }
    return out;
}

/* list.count：值在列表里出现的次数（== 语义） */
Value rt_list_count(Value lst, Value v)
{
    if (!IS_LIST(lst) || AS_LIST(lst) == NULL)
        rt_die("list.count 需要列表");
    RtList *L = AS_LIST(lst);
    long long n = 0;
    for (size_t i = 0; i < L->len; i++)
        if (rt_cond(rt_eq(L->items[i], v)))
            n++;
    return rt_int(n);
}

Value rt_list_sorted(Value lst)
{
    RtList *L = as_list(lst, "sorted");
    Value out = rt_list_new();
    for (size_t k = 0; k < L->len; k++)
        rt_push(&out, L->items[k]);
    qsort(AS_LIST(out)->items, AS_LIST(out)->len, sizeof(Value), list_cmp_qsort);
    return out;
}

/* 字典按键值排序后取出键列表：方向 1=按值升序，-1=按值降序 */
static int dict_byvalue_cmp(const void *pa, const void *pb)
{
    RtList *A = AS_LIST(*(const Value *)pa);
    RtList *B = AS_LIST(*(const Value *)pb);
    return compare_values(A && A->len == 2 ? A->items[1] : rt_none(),
                          B && B->len == 2 ? B->items[1] : rt_none());
}

Value rt_dict_byvalue(Value d, Value dirv)
{
    RtDict *D = as_dict(d, "dict.byvalue");
    RtList *L = AS_LIST(D->pairs);
    Value pairs = rt_list_new();
    for (size_t k = 0; L && k < L->len; k++)
        rt_push(&pairs, L->items[k]);
    qsort(AS_LIST(pairs)->items, AS_LIST(pairs)->len, sizeof(Value), dict_byvalue_cmp);
    Value out = rt_list_new();
    long long n = (long long)AS_LIST(pairs)->len;
    int desc = (as_int(dirv) < 0);
    for (long long k = 0; k < n; k++) {
        RtList *pair = AS_LIST(AS_LIST(pairs)->items[desc ? n - 1 - k : k]);
        if (pair && pair->len == 2)
            rt_push(&out, pair->items[0]);
    }
    return out;
}

/* dict.set(字典, 键, 值)：写字典，返回同一个字典（方便连写）。
   ⚠ rt_dict_set 要的是 Value*，但它只改**堆上的 RtDict**（改已有 pair 的值 /
   往 pairs 追加），不会替换 Value 本身 —— 所以这里拿一份副本当"地址"用是安全的，
   调用方手上的字典照样被改。这样就不必像 添加() 那样在代码生成器里特判传地址。 */
Value rt_dict_put(Value d, Value k, Value v)
{
    if (!IS_DICT(d))
        rt_die("dict.set：第一个参数不是字典");
    Value tmp = d;
    rt_dict_set(&tmp, k, v);
    return tmp;
}

/* dict.max(字典) / dict.min(字典)：返回**值最大 / 最小的那个键**。
   dict.byvalue 也能做，但它返回整个排序后的键列表、还得再取 [0]；
   这里直接给键 —— "取出现最多的词""取最高分的人"就是一行。
   实现直接复用 dict.byvalue 的排序（已测过的代码），别自己再写一遍比较。
   空字典返回空值。 */
static Value _dict_extreme(Value d, const char *who, int want_max)
{
    Value ks = rt_dict_byvalue(d, want_max ? rt_int(-1) : rt_int(0));
    (void)who;
    if (!IS_LIST(ks) || rt_list_len_ll(ks) == 0)
        return rt_none();
    return rt_index(ks, rt_int(0));
}

Value rt_dict_max(Value d) { return _dict_extreme(d, "dict.max", 1); }
Value rt_dict_min(Value d) { return _dict_extreme(d, "dict.min", 0); }

Value rt_list_sort(Value lst)
{
    RtList *L = as_list(lst, "排序");
    qsort(L->items, L->len, sizeof(Value), list_cmp_qsort);
    return lst;   /* 原地排序，返回原列表 */
}

Value rt_list_reverse(Value lst)
{
    RtList *L = as_list(lst, "倒序");
    if (L->len > 1) {
        size_t i = 0, j = L->len - 1;
        while (i < j) {
            Value t = L->items[i];
            L->items[i] = L->items[j];
            L->items[j] = t;
            i++;
            j--;
        }
    }
    return lst;   /* 原地倒序，返回原列表 */
}

Value rt_list_unique(Value lst)
{
    RtList *L = as_list(lst, "去重");
    Value out = rt_list_new();
    for (size_t i = 0; i < L->len; i++) {
        int seen = 0;
        for (size_t j = 0; j < AS_LIST(out)->len; j++) {
            if (values_equal(L->items[i], AS_LIST(out)->items[j])) {
                seen = 1;   /* 重复：保留首次出现的，跳过 */
                break;
            }
        }
        if (!seen)
            rt_push(&out, L->items[i]);
    }
    return out;
}

Value rt_list_merge(Value a, Value b)
{
    RtList *A = as_list(a, "合并");
    RtList *B = as_list(b, "合并");
    Value out = rt_list_new();
    for (size_t i = 0; i < A->len; i++)
        rt_push(&out, A->items[i]);
    for (size_t i = 0; i < B->len; i++)
        rt_push(&out, B->items[i]);
    return out;
}

Value rt_list_find(Value lst, Value val)
{
    RtList *L = as_list(lst, "查找");
    for (size_t i = 0; i < L->len; i++)
        if (values_equal(L->items[i], val))
            return rt_int((long long)i);
    return rt_int(-1);   /* 找不到 */
}

Value rt_list_max(Value lst)
{
    RtList *L = as_list(lst, "max");
    if (L->len == 0)
        rt_die("列表为空");
    Value best = L->items[0];
    for (size_t i = 1; i < L->len; i++)
        if (compare_values(L->items[i], best) > 0)
            best = L->items[i];
    return best;
}

Value rt_list_min(Value lst)
{
    RtList *L = as_list(lst, "min");
    if (L->len == 0)
        rt_die("列表为空");
    Value best = L->items[0];
    for (size_t i = 1; i < L->len; i++)
        if (compare_values(L->items[i], best) < 0)
            best = L->items[i];
    return best;
}

/* ================= 对象（属性袋） ================= */

/* 取属性袋；删除状态/类型不符直接报错 */
static RtObject *as_object(Value v, const char *ctx)
{
    if (IS_DEL(v))
        rt_die("用已删除变量");
    if (!IS_OBJ(v) || AS_OBJ(v) == NULL)
        rt_die("%s：目标不是对象", ctx);
    return AS_OBJ(v);
}

/* ================= 张量（RT_TENSOR，OBJ 子类型） ================= */

int rt_is_tensor(Value v)
{
    if (!IS_OBJ(v))
        return 0;
    RtCell *c = (RtCell *)((v) & RT_PTR_MASK) - 1;
    return c->kind == RTK_TENSOR;
}

RtTensor *rt_as_tensor(Value v)
{
    return (RtTensor *)((v) & RT_PTR_MASK);
}

/* 新建 ndim 维张量，各维长度 dims[]，数据清零。prec 见 pybook_rt.h。
 * rt_tensor_new 是 rt_tensor_new_p(..., TENSOR_F64) 的快捷方式，
 * 老代码一行不用改，行为与以前逐位一致。 */
Value rt_tensor_new_p(int ndim, const int *dims, int prec)
{
    size_t total = 1;
    for (int k = 0; k < ndim; k++) {
        if (dims[k] < 0)
            rt_die("张量维度不能为负");
        total *= (size_t)dims[k];
    }
    RtTensor *t = (RtTensor *)heap_alloc(RTK_TENSOR, sizeof(RtTensor));
    t->ndim = ndim;
    t->prec = (prec == TENSOR_F32) ? TENSOR_F32 : TENSOR_F64;
    t->dims = (int *)malloc((size_t)ndim * sizeof(int));
    for (int k = 0; k < ndim; k++)
        t->dims[k] = dims[k];
    t->data = (double *)calloc(total ? total : 1, sizeof(double));
    if (!t->data)
        rt_die("张量内存不足");
    /* 知命压力计数：张量 dims/data 走裸 malloc/calloc，不途经 heap_raw，
       这里在 mode7 下补计，压力自适应相位才能感知大张量分配并提前回收。
       注意不能改成走 heap_raw——mode4 竞技场下 heap_raw 返回块内内存，
       cell_drop 里 free(T->dims) 会误伤；此处只补计数、不动分配路径。 */
    if (g_memmode == 7)
        g_m7_alloc += (size_t)ndim * sizeof(int) + (total ? total : 1) * sizeof(double);
    return MAKE_OBJ(t);
}

Value rt_tensor_new(int ndim, const int *dims)
{
    return rt_tensor_new_p(ndim, dims, TENSOR_F64);
}

/* 写入路径：float32 张量一律先舍入到 float32 再存。
 * 这样缓冲里每个值都严格可被 float32 精确表示，上卡/下卡都是无损的。 */
double rt_tensor_round(int prec, double v)
{
    return (prec == TENSOR_F32) ? (double)(float)v : v;
}

static long tensor_flat(RtTensor *t, Value i, Value j)
{
    if (t->ndim == 1) {
        long idx = norm_index((size_t)t->dims[0], i, "张量下标");
        return (long)idx;
    }
    size_t front = 1, last = (size_t)t->dims[t->ndim - 1];
    for (int k = 0; k < t->ndim - 1; k++)
        front *= (size_t)t->dims[k];
    long r = norm_index(front, i, "张量行下标");
    long c = norm_index(last, j, "张量列下标");
    return r * (long)last + c;
}

Value rt_tensor_get(Value m, Value i, Value j)
{
    if (!rt_is_tensor(m))
        rt_die("张量取值：目标不是张量");
    RtTensor *t = rt_as_tensor(m);
    long off = tensor_flat(t, i, j);
    return rt_float(t->data[off]);
}

Value rt_tensor_set(Value m, Value i, Value j, Value v)
{
    if (!rt_is_tensor(m))
        rt_die("张量赋值：目标不是张量");
    RtTensor *t = rt_as_tensor(m);
    long off = tensor_flat(t, i, j);
    t->data[off] = rt_tensor_round(t->prec, as_flt(v));
    return v;
}

int rt_tensor_prec(Value m)
{
    if (!rt_is_tensor(m))
        rt_die("tensor.prec：参数不是张量");
    return rt_as_tensor(m)->prec;
}

/* ---- 语言层包装（给 tensor.* 的 LIB_CALLS 用）----
 * 对外说人话：32 / 64；内部才是 TENSOR_F32 / TENSOR_F64。
 * 库入口一律 Value 进 Value 出，签名跟内核里的 C 版对不上是常见坑，
 * 所以这里明确分两层，别图省事直接把 C 版塞进 LIB_CALLS 表。 */
Value rt_tensor_prec_v(Value m)
{
    return rt_int(rt_tensor_prec(m) == TENSOR_F32 ? 32 : 64);
}

Value rt_tensor_cast_v(Value m, Value pv)
{
    long long p;
    if (!is_num(pv))
        rt_die("tensor.cast：第二个参数要是 32 或 64");
    p = rt_to_ll(pv);
    if (p != 32 && p != 64)
        rt_die("tensor.cast：精度只能是 32（float32）或 64（float64），收到 %lld", p);
    return rt_tensor_cast(m, p == 32 ? TENSOR_F32 : TENSOR_F64);
}

Value rt_tensor_cast(Value m, int prec)
{
    if (!rt_is_tensor(m))
        rt_die("tensor.cast：参数不是张量");
    if (prec != TENSOR_F32 && prec != TENSOR_F64)
        rt_die("tensor.cast：精度只能是 0（float64）或 1（float32），收到 %d", prec);
    RtTensor *t = rt_as_tensor(m);
    prec = (prec == TENSOR_F32) ? TENSOR_F32 : TENSOR_F64;
    if (t->prec == prec)
        return m;
    size_t n = 1;
    for (int k = 0; k < t->ndim; k++)
        n *= (size_t)t->dims[k];
    for (size_t i = 0; i < n; i++)
        t->data[i] = rt_tensor_round(prec, t->data[i]);
    t->prec = prec;
    return m;
}

/* 取第 r 行作为新的 1D 张量（数据共享底层缓冲的副本，独立长度） */
static Value rt_tensor_row(Value m, Value i)
{
    RtTensor *t = rt_as_tensor(m);
    long r = norm_index((size_t)t->dims[0], i, "张量行下标");
    int cols = (t->ndim >= 2) ? t->dims[1] : 1;
    int d[1] = { cols };
    Value row = rt_tensor_new_p(1, d, t->prec);
    RtTensor *rt = rt_as_tensor(row);
    for (int c = 0; c < cols; c++)
        rt->data[c] = t->data[r * cols + c];
    return row;
}

Value rt_tensor_slice(Value m, Value r0, Value r1, Value c0, Value c1)
{
    if (!rt_is_tensor(m))
        rt_die("张量切片：目标不是张量");
    RtTensor *t = rt_as_tensor(m);
    long rows = (t->ndim >= 1) ? t->dims[0] : 0;
    long cols = 1;                      /* 行距 = 其余维之积（首维整块行拷） */
    for (int k = 1; k < t->ndim; k++)
        cols *= (long)t->dims[k];
    const long MISS = -2147483647LL - 1;
    long a  = (IS_NONE(r0) || !IS_INT(r0)) ? MISS : as_int(r0);
    long b  = (IS_NONE(r1) || !IS_INT(r1)) ? MISS : as_int(r1);
    long cc = (IS_NONE(c0) || !IS_INT(c0)) ? MISS : as_int(c0);
    long d  = (IS_NONE(c1) || !IS_INT(c1)) ? MISS : as_int(c1);
    long ra = (a == MISS) ? 0 : (a < 0 ? a + rows : a);
    long rb = (b == MISS) ? rows : (b < 0 ? b + rows : b);
    long ca = (cc == MISS) ? 0 : (cc < 0 ? cc + cols : cc);
    long cb = (d == MISS) ? cols : (d < 0 ? d + cols : d);
    if (ra < 0) ra = 0; if (ra > rows) ra = rows;
    if (rb < 0) rb = 0; if (rb > rows) rb = rows;
    if (ca < 0) ca = 0; if (ca > cols) ca = cols;
    if (cb < 0) cb = 0; if (cb > cols) cb = cols;
    /* 反序边界得空切片（对齐 Python/NumPy 语义）——曾经这里会算出负维度，
     * 让 rt_tensor_new_p 抛「张量维度不能为负」：内部守卫消息漏到用户面，
     * 且 T[i:j]（j<i）在循环里会直接杀掉整个程序。2026-10-12 接线式测试抓出。 */
    if (rb < ra) rb = ra;
    if (cb < ca) cb = ca;
    /* 保维切片：4D 行切片返回 4D（行数变，其余维原样）——
     * 之前固定出 2D，会把 (N,1,28,28) 批量张量踩扁成 (批,28) */
    int on = (t->ndim >= 2) ? t->ndim : 1;
    int nd[8];
    nd[0] = (int)(rb - ra);
    for (int k = 1; k < on; k++)
        nd[k] = t->dims[k];
    Value out = rt_tensor_new_p(on, nd, t->prec);
    RtTensor *o = rt_as_tensor(out);
    for (long i = ra; i < rb; i++)
        for (long j = ca; j < cb; j++)
            o->data[(i - ra) * (long)cols + (j - ca)] = t->data[i * cols + j];
    return out;
}

int rt_tensor_rows(Value m)
{
    return rt_as_tensor(m)->dims[0];
}

int rt_tensor_cols(Value m)
{
    RtTensor *t = rt_as_tensor(m);
    return (t->ndim >= 2) ? t->dims[1] : 1;
}

/* 嵌套列表（列表的列表，元素为数字）→ 张量。校验矩形。
 * prec 见 pybook_rt.h：TENSOR_F32 时每个元素在写入前就舍入到 float32。 */
Value rt_tensor_from_list_p(Value nested, int prec)
{
    if (!IS_LIST(nested) || AS_LIST(nested) == NULL)
        rt_die("tensor 字面量需要嵌套列表");
    RtList *rows = AS_LIST(nested);
    size_t nrows = rows->len;
    if (nrows == 0)
        rt_die("tensor 字面量至少有一行");
    /* 1D：元素是数字 */
    if (!IS_LIST(rows->items[0])) {
        int d[1] = { (int)nrows };
        Value t = rt_tensor_new_p(1, d, prec);
        RtTensor *rt = rt_as_tensor(t);
        for (size_t i = 0; i < nrows; i++)
            rt->data[i] = rt_tensor_round(prec, as_flt(rows->items[i]));
        return t;
    }
    /* 2D：每行是等长的数字列表 */
    size_t ncols = AS_LIST(rows->items[0])->len;
    for (size_t i = 1; i < nrows; i++) {
        if (!IS_LIST(rows->items[i]) || AS_LIST(rows->items[i])->len != ncols)
            rt_die("tensor 字面量各行长度必须一致（第 %zu 行不一致）", i);
    }
    int d[2] = { (int)nrows, (int)ncols };
    Value t = rt_tensor_new_p(2, d, prec);
    RtTensor *rt = rt_as_tensor(t);
    for (size_t i = 0; i < nrows; i++) {
        RtList *row = AS_LIST(rows->items[i]);
        for (size_t j = 0; j < ncols; j++)
            rt->data[i * ncols + j] = rt_tensor_round(prec, as_flt(row->items[j]));
    }
    return t;
}

Value rt_tensor_from_list(Value nested)
{
    return rt_tensor_from_list_p(nested, TENSOR_F64);
}

Value rt_tensor_to_list(Value m)
{
    RtTensor *t = rt_as_tensor(m);
    Value out = rt_list_new();
    if (t->ndim == 1) {
        for (int i = 0; i < t->dims[0]; i++)
            rt_push(&out, rt_float(t->data[i]));
    } else {
        for (int i = 0; i < t->dims[0]; i++) {
            Value row = rt_list_new();
            for (int j = 0; j < t->dims[1]; j++)
                rt_push(&row, rt_float(t->data[i * t->dims[1] + j]));
            rt_push(&out, row);
        }
    }
    return out;
}

char *rt_tensor_str(const RtTensor *t)
{
    /* 估算长度 */
    size_t cap = 64;
    for (int i = 0; i < t->dims[0]; i++)
        cap += 16 * (size_t)(t->ndim >= 2 ? t->dims[1] : 1) + 8;
    char *buf = (char *)malloc(cap);
    size_t len = 0;
    buf[0] = '\0';
    for (int i = 0; i < t->dims[0]; i++) {
        if (i) { buf[len++] = '\n'; buf[len] = '\0'; }
        for (int j = 0; j < (t->ndim >= 2 ? t->dims[1] : 1); j++) {
            long off = (t->ndim >= 2) ? (i * t->dims[1] + j) : i;
            double v = t->data[off];
            len += (size_t)snprintf(buf + len, cap - len, "%s%g", j ? " " : "", v);
        }
    }
    return buf;
}

Value rt_obj_new(const char *cls)
{
    RtObject *o = (RtObject *)heap_alloc(RTK_OBJ, sizeof(RtObject));
    o->cls = (char *)(cls ? cls : "");   /* 指向常量，永不回收 */
    o->nprops = 0;
    o->names = NULL;    o->vals = NULL;
    return MAKE_OBJ(o);
}

void rt_obj_set_prop(Value obj, const char *name, Value v)
{
    if (IS_TENSOR(obj))
        rt_die("张量不支持属性赋值（用 T[i,j] = 值 取元素）");
    RtObject *o = as_object(obj, "属性赋值");
    const char *key = name ? name : "";
    RtCell *oc = cell_of(obj);          /* 写屏障用：整个函数都要使 */
    for (size_t i = 0; i < o->nprops; i++) {
        if (strcmp(o->names[i], key) == 0) {
            if (g_memmode == 3) {
                rt_retain(v);            /* 先保新的，再放旧的（自赋值也安全） */
                rt_release(o->vals[i]);
            }
            o->vals[i] = v;              /* 已有则覆盖 */
            if (g_memmode == 6)
                remember(oc ? oc : cell_of(obj), v);
            return;
        }
    }
    /* 没有则追加（教学规模 +1 扩容足够） */
    o->names = (char **)heap_raw_grow(o->names, oc,
                                      o->nprops * sizeof(char *),
                                      (o->nprops + 1) * sizeof(char *));
    o->vals = (Value *)heap_raw_grow(o->vals, oc,
                                     o->nprops * sizeof(Value),
                                     (o->nprops + 1) * sizeof(Value));
    o->names[o->nprops] = dup_str_plain(key);   /* 属性名是辅助文本，非 Value */
    o->vals[o->nprops] = v;
    if (g_memmode == 3)
        rt_retain(v);
    o->nprops++;
}

Value rt_obj_get_prop(Value obj, const char *name)
{
    if (IS_TENSOR(obj))
        rt_die("张量不支持属性读取（用 T[i,j] 取元素）");
    RtObject *o = as_object(obj, "属性读取");
    const char *key = name ? name : "";
    for (size_t i = 0; i < o->nprops; i++)
        if (strcmp(o->names[i], key) == 0)
            return o->vals[i];
    rt_die("属性 '%s' 不存在", key);
    return rt_none();   /* 不可达 */
}

/* 碰到(a, b)：两个对象的 AABB 碰撞。x/y 是中心，需要 x/y/宽/高 属性。 */
static double touch_num(Value v, const char *who)
{
    if (IS_INT(v) || IS_BIGINT(v))
        return (double)as_int(v);
    if (IS_BOOL(v))
        return (double)AS_BOOL(v);
    if (IS_FLT(v))
        return AS_FLT(v);
    rt_die("碰到：%s 需要是数字", who);
    return 0;
}

Value rt_touch(Value a, Value b)
{
    double ax = touch_num(rt_obj_get_prop(a, "x"), "x");
    double ay = touch_num(rt_obj_get_prop(a, "y"), "y");
    double aw = touch_num(rt_obj_get_prop(a, "宽"), "宽");
    double ah = touch_num(rt_obj_get_prop(a, "高"), "高");
    double bx = touch_num(rt_obj_get_prop(b, "x"), "x");
    double by = touch_num(rt_obj_get_prop(b, "y"), "y");
    double bw = touch_num(rt_obj_get_prop(b, "宽"), "宽");
    double bh = touch_num(rt_obj_get_prop(b, "高"), "高");
    double dx = ax - bx;
    double dy = ay - by;
    if (dx < 0)
        dx = -dx;
    if (dy < 0)
        dy = -dy;
    return rt_bool(dx * 2 < aw + bw && dy * 2 < ah + bh);
}

const char *rt_obj_class_name(Value obj)
{
    RtObject *o = as_object(obj, "类名");
    return o->cls ? o->cls : "";
}

/* ================= 样式 token（rt_magic 与网页段落样式共用） ================= */

/* 取下一个逗号分隔的样式项：返回起点，*len 为长度，*p 停在分隔符/串尾
 * （c=R,G/B=bk=R,G,B 的后两个分量由 read_channel 继续吃，所以不能提前跳逗号） */
static const char *style_token(const char **p, size_t *len)
{
    const char *start = *p;
    const char *q = start;
    while (*q && *q != ',')
        q++;
    *len = (size_t)(q - start);
    *p = q;
    return start;
}

/* 解析一个 0..255 的颜色分量，失败按"不支持的样式"报错 */
static int parse_channel(const char *start, const char *end)
{
    char tmp[16];
    size_t len = (size_t)(end - start);
    if (len == 0 || len >= sizeof tmp)
        rt_die("不支持的样式（颜色分量缺失或过长）");
    memcpy(tmp, start, len);
    tmp[len] = '\0';
    char *stop;
    long v = strtol(tmp, &stop, 10);
    if (stop != tmp + len || v < 0 || v > 255)
        rt_die("不支持的样式 %s", tmp);
    return (int)v;
}

/* 紧跟着读取 ",G" / ",B" 颜色项中的一个 */
static int read_channel(const char **pp, const char *ctx)
{
    const char *p = *pp;
    if (*p != ',')
        rt_die("不支持的样式 %s", ctx);   /* 缺少后续颜色分量 */
    p++;
    const char *start = p;
    while (*p && *p != ',')
        p++;
    *pp = p;
    return parse_channel(start, p);
}

/* 把当前项拷进报错用的小缓冲（过长截断） */
static void token_text(char *tok, size_t cap, const char *start, size_t len)
{
    size_t n = len < cap - 1 ? len : cap - 1;
    memcpy(tok, start, n);
    tok[n] = '\0';
}

/* 解析 "fs.数字" 的字号：纯数字 1..999，否则报错（网页端要用，不能放坏值进去） */
static int parse_font_size(const char *start, size_t len, const char *ctx)
{
    if (len == 0 || len > 3)
        rt_die("不支持的样式 %s", ctx);
    int v = 0;
    for (size_t i = 0; i < len; i++) {
        if (start[i] < '0' || start[i] > '9')
            rt_die("不支持的样式 %s", ctx);
        v = v * 10 + (start[i] - '0');
    }
    if (v == 0)
        rt_die("不支持的样式 %s", ctx);
    return v;
}

/* ================= 终端显示（show 的运行时） ================= */

/* 显示行缓冲（支持 l/fl、m/fm、r/fr 对齐）：show 系列先把片段拼进来，show_end 一次输出 */
static char g_line[65536];
static size_t g_len = 0;
static int g_align = 0;        /* 0=左(l/fl) 1=居中(m/fm) 2=右(r/fr) */
static int g_magic_used = 0;   /* 本行是否用过 magic（show_end 决定要不要发 \033[0m） */

static void line_append(const char *s)
{
    size_t n = strlen(s ? s : "");
    if (g_len + n >= sizeof g_line)
        rt_die("一行太长");
    memcpy(g_line + g_len, s, n + 1);
    g_len += n;
}

void rt_magic(const char *csv)
{
    const char *p = csv ? csv : "";
    g_magic_used = 1;   /* 空样式串也算用过 magic：show_end 照发重置序列 */
    for (;;) {
        size_t len;
        const char *start = style_token(&p, &len);

        char tok[64];
        token_text(tok, sizeof tok, start, len);

        if (len == 0) {
            /* 连续逗号/结尾逗号产生的空项：跳过 */
        }
        else if (len == 1 && start[0] == 'b')      line_append("\033[1m");  /* 加粗 */
        else if (len == 1 && start[0] == 'i')      line_append("\033[3m");  /* 斜体 */
        else if (len == 1 && start[0] == 'u')      line_append("\033[4m");  /* 下划线 */
        else if (len == 1 && start[0] == 'd')      line_append("\033[9m");  /* 删除线 */
        else if (len >= 2 && start[0] == 'c' && start[1] == '=') {
            int r = parse_channel(start + 2, p);
            int g = read_channel(&p, tok);
            int b = read_channel(&p, tok);
            char esc[32];
            snprintf(esc, sizeof esc, "\033[38;2;%d;%d;%dm", r, g, b);
            line_append(esc);                                          /* 前景色 */
        }
        else if (len >= 3 && start[0] == 'b' && start[1] == 'k' && start[2] == '=') {
            int r = parse_channel(start + 3, p);
            int g = read_channel(&p, tok);
            int b = read_channel(&p, tok);
            char esc[32];
            snprintf(esc, sizeof esc, "\033[48;2;%d;%d;%dm", r, g, b);
            line_append(esc);                                          /* 背景色 */
        }
        else if (len >= 2 && start[0] == 'f' && start[1] == '.') {
            if (len == 2)
                rt_die("不支持的样式 %s", tok);   /* f. 后面必须有字体名 */
            /* 字体名：终端改不了字体，接受并忽略（网页端生效） */
        }
        else if (len >= 3 && start[0] == 'f' && start[1] == 's' && start[2] == '.') {
            parse_font_size(start + 3, len - 3, tok);   /* 字号：同上，只校验 */
        }
        else if (len == 1 && start[0] == 'l') g_align = 0;             /* 左对齐 */
        else if (len == 2 && start[0] == 'f' && start[1] == 'l') g_align = 0;
        else if (len == 1 && start[0] == 'm') g_align = 1;             /* 居中 */
        else if (len == 2 && start[0] == 'f' && start[1] == 'm') g_align = 1;
        else if (len == 1 && start[0] == 'r') g_align = 2;             /* 右对齐 */
        else if (len == 2 && start[0] == 'f' && start[1] == 'r') g_align = 2;
        else
            rt_die("不支持的样式 %s", tok);

        if (*p == '\0')
            break;
        p++;   /* 跳过逗号，读下一项 */
    }
}

void rt_show_text(const char *s) { line_append(s ? s : ""); }

Value rt_show_value(Value v)
{
    line_append(rt_str_of(v));
    return v;
}

void rt_show_end(void)
{
    /* 可见长度：跳过 ANSI 转义序列 \033[...m（中文按字节近似） */
    size_t vis = 0;
    for (size_t i = 0; i < g_len;) {
        if (g_line[i] == '\033') {
            i++;
            if (i < g_len && g_line[i] == '[') {
                i++;
                while (i < g_len && g_line[i] != 'm')
                    i++;
                if (i < g_len)
                    i++;
            }
        } else {
            vis++;
            i++;
        }
    }
    const char *cols = getenv("COLUMNS");
    int width = cols ? atoi(cols) : 80;
    if (width < 10)
        width = 10;
    if (width > 200)
        width = 200;
    int pad = 0;
    if (g_align == 1)
        pad = (width - (int)vis) / 2;
    else if (g_align == 2)
        pad = width - (int)vis;
    if (pad < 0)
        pad = 0;
    for (int i = 0; i < pad; i++)
        fputc(' ', stdout);
    fwrite(g_line, 1, g_len, stdout);
    if (g_magic_used)
        fputs("\033[0m", stdout);   /* 只在本行用过 magic 时发重置序列 */
    fputc('\n', stdout);
    g_magic_used = 0;
    g_len = 0;
    g_align = 0;
}

Value rt_input(const char *prompt)
{
    if (prompt && *prompt) {
        fputs(prompt, stdout);
        fflush(stdout);
    }
    /* 读一整行（按块拼接；缓冲同样不回收，脚本结束由进程回收） */
    size_t cap = 128, len = 0;
    char *line = (char *)malloc(cap);
    if (!line)
        rt_die("内存不足");
    for (;;) {
        int c = getchar();
        if (c == EOF || c == '\n')
            break;
        if (len + 2 > cap) {
            cap *= 2;
            line = (char *)realloc(line, cap);
            if (!line)
                rt_die("内存不足");
        }
        line[len++] = (char)c;
    }
    line[len] = '\0';
    if (len > 0 && line[len - 1] == '\r')
        line[--len] = '\0';   /* 兼容 CRLF */

    /* 先按整数、再按浮点解析（忽略首尾空白，必须整行都是数字） */
    const char *b = line, *e = line + len;
    while (b < e && (*b == ' ' || *b == '\t'))
        b++;
    while (e > b && (e[-1] == ' ' || e[-1] == '\t'))
        e--;
    if (b < e) {
        char *stop;
        errno = 0;
        long long iv = strtoll(b, &stop, 10);
        if (stop == e && errno != ERANGE)
            return rt_int(iv);
        errno = 0;
        double fv = strtod(b, &stop);
        /* 必须吃满整行、至少含一个数字、且是有限值——挡掉 "inf"/"nan"/"0x1p3" */
        int has_digit = 0;
        for (const char *q = b; q < e; q++)
            if (*q >= '0' && *q <= '9') { has_digit = 1; break; }
        if (stop == e && has_digit && isfinite(fv))
            return rt_float(fv);
    }
    return rt_str(line);   /* 不是数字就整行按字符串（保留用户输入原样） */
}

/* ---- 查() 测试语句的运行时 ---- */
static long long g_chk_pass = 0, g_chk_fail = 0;

void rt_test_check(int cond, const char *name)
{
    if (cond) {
        g_chk_pass++;
    } else {
        g_chk_fail++;
        fprintf(stderr, "查失败: %s\n", name ? name : "(未命名)");
    }
}

long long rt_test_summary(void)
{
    if (g_chk_pass + g_chk_fail > 0)
        printf("查：%lld 通过，%lld 失败\n", g_chk_pass, g_chk_fail);
    return g_chk_fail;
}

long long pk_mod(long long a, long long b)
{
    long long rr = a % b;
    if (rr != 0 && ((rr < 0) != (b < 0)))
        rr += b;
    return rr;
}

long long pk_fdiv(long long a, long long b)
{
    long long q = a / b;
    long long rr = a % b;
    if (rr != 0 && ((rr < 0) != (b < 0)))
        q--;
    return q;
}

/* ================= 网页输出（hm 的运行时） ================= */

/* 网页缓冲（malloc 增长，分配不回收；save 后清长度复用内存） */
static char  *g_page = NULL;
static size_t g_page_len = 0, g_page_cap = 0;
static int    g_page_begun = 0;

/* ---- 多页支持（web.页）：页表 + 页栈 ----
 * g_page_file 是当前页的文件名（""=主页 pybook_page.html）。
 * rt_page_open 把当前缓冲连同名/标志存入页表，切到目标页；rt_page_back
 * 沿栈切回。rt_page_save 时主页照常落盘，页表里所有 begun 的子页逐个
 * 写成 pybook_page_<名>.html。 */

#define PAGE_STACK_MAX 16

#ifdef _WIN32
#  define WIN32_LEAN_AND_MEAN
#  include <windows.h>       /* MultiByteToWideChar/_wfopen：UTF-8 文件名落盘 */
#endif

typedef struct { char *file; char *buf; size_t len, cap; int begun; } PageSlot;
static PageSlot *g_slots = NULL;
static int       g_nslots = 0, g_slots_cap = 0;
static char     *g_page_file = NULL;             /* 当前页名（""=主页） */
static char     *g_pstack[PAGE_STACK_MAX];       /* 打开前的页名栈 */
static int       g_psp = 0;

static void page_stash(void)
{
    const char *f = g_page_file ? g_page_file : "";
    PageSlot *s = NULL;
    for (int i = 0; i < g_nslots; i++)
        if (strcmp(g_slots[i].file, f) == 0) { s = &g_slots[i]; break; }
    if (!s) {
        if (g_nslots == g_slots_cap) {
            g_slots_cap = g_slots_cap ? g_slots_cap * 2 : 4;
            g_slots = (PageSlot *)realloc(g_slots, (size_t)g_slots_cap * sizeof(PageSlot));
            if (!g_slots)
                rt_die("网页输出：页表内存不足");
        }
        s = &g_slots[g_nslots++];
        s->file = NULL;
        s->buf = NULL;
        s->len = s->cap = 0;
        s->begun = 0;
    }
    free(s->file);
    s->file = strdup(f);
    free(s->buf);
    s->buf = g_page;
    s->len = g_page_len;
    s->cap = g_page_cap;
    s->begun = g_page_begun;
    g_page = NULL;
    g_page_len = g_page_cap = 0;
    g_page_begun = 0;
}

static void page_load(const char *file)
{
    for (int i = 0; i < g_nslots; i++) {
        if (strcmp(g_slots[i].file, file) == 0) {
            g_page = g_slots[i].buf;              /* 接管缓冲（指针移出，不释放） */
            g_page_len = g_slots[i].len;
            g_page_cap = g_slots[i].cap;
            g_page_begun = g_slots[i].begun;
            free(g_slots[i].file);
            g_slots[i] = g_slots[g_nslots - 1];
            g_nslots--;
            break;
        }
    }
    free(g_page_file);
    g_page_file = strdup(file ? file : "");
}

void rt_page_open(const char *file, const char *title)
{
    if (g_psp >= PAGE_STACK_MAX)
        rt_die("网页输出：web.页 嵌套太深（最多 16 层）");
    g_pstack[g_psp++] = strdup(g_page_file ? g_page_file : "");
    page_stash();
    page_load(file ? file : "");
    rt_page_begin(title);        /* 新页写骨架；表里 begun 的老页幂等跳过 */
}

void rt_page_back(void)
{
    page_stash();
    if (g_psp > 0) {
        char *f = g_pstack[--g_psp];
        page_load(f);
        free(f);
    }
}


static void page_append_n(const char *s, size_t n)
{
    if (g_page_len + n + 1 > g_page_cap) {
        g_page_cap = g_page_cap ? g_page_cap : 1024;
        while (g_page_len + n + 1 > g_page_cap)
            g_page_cap *= 2;
        g_page = (char *)realloc(g_page, g_page_cap);
        if (!g_page)
            rt_die("内存不足");
    }
    memcpy(g_page + g_page_len, s, n);
    g_page_len += n;
    g_page[g_page_len] = '\0';
}

static void page_append(const char *s) { page_append_n(s ? s : "", strlen(s ? s : "")); }

/* 用户文本进页面的唯一通道：& < > " 全部转义，永远变不成可执行标签 */
static void page_append_esc(const char *s)
{
    for (const char *p = s ? s : ""; *p; p++) {
        switch (*p) {
        case '&': page_append_n("&amp;", 5); break;
        case '<': page_append_n("&lt;", 4); break;
        case '>': page_append_n("&gt;", 4); break;
        case '"': page_append_n("&quot;", 6); break;
        default:  page_append_n(p, 1); break;
        }
    }
}

/* 段落样式组装用的临时缓冲（同页缓冲策略） */
static char  *g_scratch = NULL;
static size_t g_scratch_len = 0, g_scratch_cap = 0;

static void scratch_reset(void)
{
    g_scratch_len = 0;
    if (g_scratch)
        g_scratch[0] = '\0';
}

static void scratch_append_n(const char *s, size_t n)
{
    if (g_scratch_len + n + 1 > g_scratch_cap) {
        g_scratch_cap = g_scratch_cap ? g_scratch_cap : 256;
        while (g_scratch_len + n + 1 > g_scratch_cap)
            g_scratch_cap *= 2;
        g_scratch = (char *)realloc(g_scratch, g_scratch_cap);
        if (!g_scratch)
            rt_die("内存不足");
    }
    memcpy(g_scratch + g_scratch_len, s, n);
    g_scratch_len += n;
    g_scratch[g_scratch_len] = '\0';
}

static void scratch_append(const char *s) { scratch_append_n(s, strlen(s)); }

/* hm 段落样式（与 rt_magic 同一套 token）→ CSS，"; " 连接：
 * b/i/u/d → font-weight / font-style / text-decoration(underline|line-through)
 * c=R,G,B → color:rgb(...)      bk=R,G,B → background-color:rgb(...)
 * f.字体 → font-family:'字体'   fs.数字 → font-size:数字px
 * l/fl、m/fm、r/fr → text-align:left/center/right
 * 未知 token → "不支持的样式" 退出。样式串由编译器生成，不做 HTML 转义。 */
static void page_style_css(const char *style)
{
    scratch_reset();
    const char *p = style ? style : "";
    if (*p == '\0')
        return;
    int first = 1;
    for (;;) {
        size_t len;
        const char *start = style_token(&p, &len);

        char tok[64];
        token_text(tok, sizeof tok, start, len);

        const char *css = NULL;
        char rgb[96];
        if (len == 0) {
            /* 空项跳过 */
        }
        else if (len == 1 && start[0] == 'b')                    css = "font-weight:bold";
        else if (len == 1 && start[0] == 'i')                    css = "font-style:italic";
        else if (len == 1 && start[0] == 'u')                    css = "text-decoration:underline";
        else if (len == 1 && start[0] == 'd')                    css = "text-decoration:line-through";
        else if (len == 1 && start[0] == 'm')                    css = "text-align:center";
        else if (len == 2 && start[0] == 'f' && start[1] == 'm') css = "text-align:center";
        else if (len == 1 && start[0] == 'r')                    css = "text-align:right";
        else if (len == 2 && start[0] == 'f' && start[1] == 'r') css = "text-align:right";
        else if (len == 1 && start[0] == 'l')                    css = "text-align:left";
        else if (len == 2 && start[0] == 'f' && start[1] == 'l') css = "text-align:left";
        else if (len >= 2 && start[0] == 'c' && start[1] == '=') {
            int r = parse_channel(start + 2, p);
            int g = read_channel(&p, tok);
            int b = read_channel(&p, tok);
            snprintf(rgb, sizeof rgb, "color:rgb(%d,%d,%d)", r, g, b);
            css = rgb;
        }
        else if (len >= 3 && start[0] == 'b' && start[1] == 'k' && start[2] == '=') {
            int r = parse_channel(start + 3, p);
            int g = read_channel(&p, tok);
            int b = read_channel(&p, tok);
            snprintf(rgb, sizeof rgb, "background-color:rgb(%d,%d,%d)", r, g, b);
            css = rgb;
        }
        else if (len >= 2 && start[0] == 'f' && start[1] == '.') {
            if (len == 2)
                rt_die("不支持的样式 %s", tok);
            snprintf(rgb, sizeof rgb, "font-family:'%.*s'", (int)(len - 2), start + 2);
            css = rgb;
        }
        else if (len >= 3 && start[0] == 'f' && start[1] == 's' && start[2] == '.') {
            int px = parse_font_size(start + 3, len - 3, tok);
            snprintf(rgb, sizeof rgb, "font-size:%dpx", px);
            css = rgb;
        }
        else
            rt_die("不支持的样式 %s", tok);

        if (css != NULL) {
            if (!first)
                scratch_append("; ");
            scratch_append(css);
            first = 0;
        }

        if (*p == '\0')
            break;
        p++;   /* 跳过逗号，读下一项 */
    }
}

void rt_page_begin(const char *title)
{
    if (g_page_begun)
        return;              /* 幂等：web.块 函数体开头也会调，二次调用不许清页 */
    g_page_len = 0;          /* 重新开始：清掉上一页内容（缓冲内存保留复用） */
    g_page_begun = 1;
    page_append("<!DOCTYPE html>\n<html lang=\"zh\">\n<head>\n"
                "<meta charset=\"utf-8\">\n<title>");
    page_append_esc(title ? title : "");
    page_append("</title>\n<style>\n"
                "body{background:#1e1e2e;color:#cdd6f4;"
                "font-family:\"Microsoft YaHei UI\",sans-serif;"
                "padding:40px;line-height:1.6}\n"
                "a{color:#89dceb}\n"
                "table.pybk-t{border-collapse:collapse;margin:10px 0}"
                "table.pybk-t th,table.pybk-t td{border:1px solid #45475a;padding:6px 14px;text-align:left}"
                "table.pybk-t tr:nth-child(even){background:#181825}"
                "</style>\n</head>\n<body>\n");
}

void rt_page_para_open(const char *style)
{
    if (!g_page_begun)
        rt_die("网页输出：请先调用 hm.begin");
    if (style && *style) {
        page_style_css(style);
        page_append("<p style=\"");
        page_append(g_scratch);
        page_append("\">\n");
    } else {
        page_append("<p>\n");
    }
}

void rt_page_text(const char *raw)
{
    page_append_esc(raw);
}

void rt_page_raw(const char *raw)
{
    page_append(raw ? raw : "");   /* 不转义：<canvas>/<script> 等页面结构用 */
}

void rt_page_value(Value v)
{
    rt_page_text(rt_str_of(v));
}

/* web.表格(二维列表)：第一行做表头，真 DOM 表格（可选中/复制/无障碍） */
void rt_page_table(Value v)
{
    if (!IS_LIST(v) || AS_LIST(v) == NULL)
        rt_die("web.表格 需要二维列表（列表的列表）");
    RtList *rows = AS_LIST(v);
    page_append("<table class=\"pybk-t\">");
    for (size_t r = 0; r < rows->len; r++) {
        Value rv = rows->items[r];
        if (!IS_LIST(rv) || AS_LIST(rv) == NULL)
            rt_die("web.表格 第 %zu 行不是列表", r + 1);
        RtList *cells = AS_LIST(rv);
        page_append("<tr>");
        for (size_t c = 0; c < cells->len; c++) {
            page_append(r == 0 ? "<th>" : "<td>");
            page_append_esc(rt_str_of(cells->items[c]));
            page_append(r == 0 ? "</th>" : "</td>");
        }
        page_append("</tr>");
    }
    page_append("</table>");
}

void rt_page_para_close(void)
{
    page_append("</p>\n");
}

void rt_page_h(const char *raw, int level)
{
    int lv = (level >= 2) ? 2 : 1;   /* v2 只有 h1/h2，更大的级别按 h2 处理 */
    page_append(lv == 1 ? "<h1>" : "<h2>");
    page_append_esc(raw ? raw : "");
    page_append(lv == 1 ? "</h1>\n" : "</h2>\n");
}

void rt_page_img(const char *file)
{
    page_append("<img src=\"");
    page_append_esc(file ? file : "");
    page_append("\">\n");
}

void rt_page_hr(void)
{
    page_append("<hr>\n");
}

void rt_page_link(const char *text, const char *url)
{
    page_append("<a href=\"");
    page_append_esc(url ? url : "");
    page_append("\">");
    page_append_esc(text ? text : "");
    page_append("</a>\n");
}

static void page_write_current(void)
{
    const char *f = g_page_file ? g_page_file : "";
    char path[300];
    if (!*f)
        snprintf(path, sizeof path, "pybook_page.html");
    else
        snprintf(path, sizeof path, "pybook_page_%s.html", f);
    FILE *fp = NULL;
#ifdef _WIN32
    /* 文件名是 UTF-8：fopen 收 ANSI 码页会乱码，转宽字符用 _wfopen */
    {   wchar_t wpath[300];
        if (MultiByteToWideChar(CP_UTF8, 0, path, -1, wpath, 300) > 0)
            fp = _wfopen(wpath, L"wb");
    }
    if (!fp)
        fp = fopen(path, "wb");
#else
    fp = fopen(path, "wb");
#endif
    if (!fp)
        rt_die("网页输出：无法写 %s", path);
    if (fwrite(g_page, 1, g_page_len, fp) != g_page_len) {
        fclose(fp);
        rt_die("网页输出：写 %s 失败", path);
    }
    fclose(fp);
}

void rt_page_save(void)
{
    int any = g_page_begun;
    for (int i = 0; i < g_nslots; i++)
        if (g_slots[i].begun)
            any = 1;
    if (!any)
        rt_die("网页输出：请先调用 hm.begin");
    if (g_page_begun) {
        page_append("</body>\n</html>\n");
        page_write_current();
        g_page_begun = 0;                 /* 已落盘：别让页表再写一遍 */
        g_page_len = 0;
    }
    page_stash();                                 /* 当前页收好，统一从页表落盘 */
    while (g_nslots > 0) {
        char fcopy[128];
        snprintf(fcopy, sizeof fcopy, "%s", g_slots[g_nslots - 1].file);
        page_load(fcopy);                         /* 接管缓冲并移出页表 */
        if (g_page_begun) {
            page_append("</body>\n</html>\n");
            page_write_current();
        }
        free(g_page);
        g_page = NULL;
        g_page_len = g_page_cap = 0;
        g_page_begun = 0;
    }
    free(g_page_file);
    g_page_file = NULL;
}

/* ================= 游戏零件：SDL2 像素窗口版 =================
 * SDL2 头文件在包含路径里（-Iucrt64/include）→ 编译真实现；
 * 否则编译"未启用"桩：调用时给出明确报错，其他构建不受 SDL 依赖拖累。
 * 注意：SDL.h 会经 SDL_main.h 把 main 重定义成 SDL_main → 必须在包含之前
 * #define SDL_MAIN_HANDLED，并在初始化时调用 SDL_SetMainReady()。 */

#if defined(RT_GAME_SDL)
#  define RT_HAVE_SDL 1        /* 显式要求游戏引擎：强制启用 */
#elif defined(__has_include)
#  if __has_include(<SDL2/SDL.h>)
#    define RT_HAVE_SDL 1
#  else
#    define RT_HAVE_SDL 0
#  endif
#else
#  define RT_HAVE_SDL 0
#endif

#if RT_HAVE_SDL

#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#define SDL_MAIN_HANDLED
#include <SDL2/SDL.h>

/* 内部状态 */
static SDL_Window   *g_sdl_win = NULL;    /* 游戏窗口 */
static SDL_Renderer *g_sdl_ren = NULL;    /* 渲染器 */
static void rt_shot_init(void);            /* 无头出图初始化（实现见 rt_game_show 附近） */

/* ---- 离屏模式（ui.离屏）：让 UI 和 3D 同屏的唯一可行路径 ----
 *
 * 为什么需要它：UI 走 SDL_Renderer，3D 走 GL，两个后缓冲互不可见。实测
 *（_probe_glui.c / _probe_glui3.c）：
 *   · 默认 SDL_CreateRenderer(ACCELERATED) 在 GL 窗口上选 **direct3d** 后端，
 *     GL 画成蓝色之后 SDL_RenderReadPixels 仍读回 SDL 自己的红色 —— 各画各的；
 *   · 强制 opengl 后端也不行：SDL 会**自己再建一个 GL context**
 *     （实测 0x10001 vs 我们自己的 0x30000），SDL_GL_BindTexture 拿回来的
 *     "纹理名"是垃圾，挂在它上面的 FBO 直接不完整。
 *   所以合成只能走 CPU：UI 渲进一块内存 surface，3D 每帧把它上传成纹理贴上去。
 *   代价实测（_probe_uisoft.c，880x560，400 FillRect + 90 RenderCopy）：
 *     GPU 0.170 ms/帧 → 软件 1.229 ms/帧，只多约 1 ms。
 *   而 UI 的大头是 stb 文字光栅化，本来就在 CPU 上，软件渲染反而省了
 *   每个字形往纹理上传那一趟。 */
static SDL_Surface *g_sdl_off = NULL;     /* 离屏目标（NULL = 普通窗口模式） */
static int g_off_mode     = 0;            /* 1 = 离屏，UI 不自己开窗 */
static int g_ui_mx = 0, g_ui_my = 0, g_ui_mdown = 0;  /* 离屏模式的鼠标（由 3D 喂） */

/* 桌面 GUI 引擎（pybook_ui.c）的帧末钩子：一帧的分组序号从这里重新数。
   放在这里是因为一帧可能有多列 ui.begin，只有 show 才知道帧的边界。 */
extern void rt_ui_new_frame(void);

/* 无头验收用的帧数上限（PYBOOK_FRAME_LIMIT），默认 0 = 不限。
   定义放在这里是因为 rt_game_win / rt_game_frame / rt_game_end 都要用，
   而它们三个在文件里的位置分得很开。详细说明见 rt_game_end。 */
static int g_frame_limit = 0;
static int g_frame_no = 0;
static int g_frame_limit_warned = 0;
static Uint8 g_kprev[256], g_kcur[256];   /* 键盘状态：上一帧 / 当前（rt_game_hit 用） */
static int   g_quit = 0;                  /* 用户是否点了 X */

/* 当前画图颜色（rt_game_color 记，clear/box/dot/line 共用），默认黑 */
static int g_pen_r = 0, g_pen_g = 0, g_pen_b = 0;
static int g_log_w = 800, g_log_h = 600;   /* 逻辑尺寸（鼠标坐标换算） */
static Uint8 g_mprev = 0, g_mcur = 0;      /* 鼠标左键：上一帧 / 当前（rt_game_mhit 用） */

static int sdl_u8(int x)              /* 颜色分量截到 0..255 */
{
    return x < 0 ? 0 : x > 255 ? 255 : x;
}

/* 游戏零件的数字参数：INT/BIGINT/BOOL 直取，FLOAT 截断，其余报错 */
static long long game_num(Value v, const char *who)
{
    if (IS_INT(v) || IS_BIGINT(v))
        return as_int(v);
    if (IS_BOOL(v))
        return (long long)AS_BOOL(v);
    if (IS_FLT(v))
        return (long long)AS_FLT(v);
    rt_die("%s 需要数字参数", who);
    return 0;
}

/* 键名 → 虚拟键码；支持方向键/空格/回车/ESC/Shift、单字母 a-z 和中文键名。
 * 字母键 VK_A..VK_Z 恰好是大写 ASCII。未知键名返回 0（按"没按"处理）。 */
static int game_key_code(const char *name)
{
    static const struct { const char *n; int vk; } TAB[] = {
        {"right", VK_RIGHT}, {"left", VK_LEFT},
        {"up", VK_UP},       {"down", VK_DOWN},
        {"space", VK_SPACE}, {"enter", VK_RETURN},
        {"esc", VK_ESCAPE},  {"shift", VK_SHIFT},
        {"右", VK_RIGHT},    {"左", VK_LEFT},
        {"上", VK_UP},       {"下", VK_DOWN},
        {"空格", VK_SPACE},  {"回车", VK_RETURN},
    };
    if (name == NULL)
        return 0;
    for (size_t i = 0; i < sizeof(TAB) / sizeof(TAB[0]); i++)
        if (strcmp(TAB[i].n, name) == 0)
            return TAB[i].vk;
    if (name[1] == '\0' && name[0] >= 'a' && name[0] <= 'z')
        return name[0] - 'a' + 'A';
    return 0;
}

/* 泵一遍事件队列：SDL_QUIT（点 X）置 g_quit。
 * rt_game_end / rt_game_key / rt_game_hit / rt_game_frame 每次被调用都跑一次，
 * 窗口不会"无响应"。 */
/* 文本输入缓冲。
   ⚠ 关键点：SDL_TEXTINPUT 给的是**输入法合成之后**的 UTF-8 结果，
   所以中文输入（IME）不需要我们自己做候选词合成 —— 只要开 SDL_StartTextInput，
   中文就能直接打进来。退格 / 回车单独记次数，按帧消费。 */
#define GAME_TYPED_MAX 256
static char g_typed[GAME_TYPED_MAX];
static int  g_typed_n = 0;
static int  g_backspace = 0;
static int  g_enter = 0;

static void game_pump(void)
{
    SDL_Event ev;
    while (SDL_PollEvent(&ev)) {
        if (ev.type == SDL_QUIT)
            g_quit = 1;
        else if (ev.type == SDL_TEXTINPUT) {
            const char *t = ev.text.text;
            for (int i = 0; t[i] && g_typed_n < GAME_TYPED_MAX - 1; i++)
                g_typed[g_typed_n++] = t[i];
            g_typed[g_typed_n] = '\0';
        } else if (ev.type == SDL_KEYDOWN) {
            if (ev.key.keysym.sym == SDLK_BACKSPACE)
                g_backspace++;
            else if (ev.key.keysym.sym == SDLK_RETURN ||
                     ev.key.keysym.sym == SDLK_KP_ENTER)
                g_enter++;
        }
    }
}

/* 取走本帧输入的文本（取走即清空）。非 static —— pybook_ui.c 用。 */
const char *game_take_text(void)
{
    static char buf[GAME_TYPED_MAX];
    memcpy(buf, g_typed, (size_t)g_typed_n + 1);
    g_typed_n = 0;
    g_typed[0] = '\0';
    return buf;
}

int game_take_backspace(void)
{
    int n = g_backspace;
    g_backspace = 0;
    return n;
}

int game_take_enter(void)
{
    int n = g_enter;
    g_enter = 0;
    return n;
}

/* ui.离屏(宽, 高)：UI 不开窗，渲进一块内存 surface，交给 3D 每帧贴上去。
 *
 * 典型写法（3D 全屏 + UI 浮在上面）：
 *     hw.open(880, 560, "3D + UI")
 *     ui.离屏(880, 560)
 *     rm.aging.while(hw.end()) {
 *         hw.box(...)                  # 3D 记录图元
 *         ui.begin(...)                # UI 照常写，绘进离屏 surface
 *         ...
 *         ui.end()
 *         hw.frame()                   # 3D 渲完自动把离屏 surface 贴上去
 *     }
 *
 * ★ 离屏模式下 UI 的背景是**透明的**（谁也不动它就一直是透明）：
 *   全屏贴时靠 alpha 混合，UI 面板浮在 3D 场景上，3D 从面板底下透出来。
 *   想要不透明底就用 ui.分组(标题) —— 它会给那块面板填一层实色圆角底。
 *
 * 尺寸必须和 3D 窗口一致（或至少不大于它）：贴上去是按 1:1 像素对齐的。
 */
Value rt_ui_offscreen(Value wv, Value hv)
{
    int w = (int)game_num(wv, "ui.离屏 的宽");
    int h = (int)game_num(hv, "ui.离屏 的高");
    if (w < 1) w = 1;
    if (h < 1) h = 1;

    SDL_SetMainReady();
    if (SDL_Init(SDL_INIT_VIDEO) != 0)
        rt_die("SDL 初始化失败: %s", SDL_GetError());

    if (g_sdl_ren != NULL) {              /* 从窗口模式切过来 / 重复调用：先收旧的 */
        SDL_DestroyRenderer(g_sdl_ren);
        g_sdl_ren = NULL;
    }
    if (g_sdl_off != NULL) {
        SDL_FreeSurface(g_sdl_off);
        g_sdl_off = NULL;
    }
    if (g_sdl_win != NULL) {              /* 离屏模式下 UI 不该有窗口 */
        SDL_DestroyWindow(g_sdl_win);
        g_sdl_win = NULL;
    }

    /* ARGB8888：和 3D 那边 glTexImage2D(GL_BGRA) 对得上，省一次通道转换 */
    g_sdl_off = SDL_CreateRGBSurfaceWithFormat(0, w, h, 32, SDL_PIXELFORMAT_ARGB8888);
    if (g_sdl_off == NULL)
        rt_die("ui.离屏：创建离屏 surface 失败: %s", SDL_GetError());
    SDL_FillRect(g_sdl_off, NULL, 0x00000000u);   /* 透明底 */

    g_sdl_ren = SDL_CreateSoftwareRenderer(g_sdl_off);
    if (g_sdl_ren == NULL)
        rt_die("ui.离屏：创建软件渲染器失败: %s", SDL_GetError());

    g_off_mode = 1;
    g_log_w = w;
    g_log_h = h;
    SDL_StartTextInput();          /* 收 SDL_TEXTINPUT：中文 IME 也靠它 */
    memset(g_kprev, 0, sizeof g_kprev);
    memset(g_kcur, 0, sizeof g_kcur);
    g_quit = 0;
    rt_shot_init();
    {   /* 帧数上限：和 rt_game_win 同一套（默认 0 = 不限，老行为不变） */
        const char *fl = getenv("PYBOOK_FRAME_LIMIT");
        g_frame_limit = (fl && *fl) ? atoi(fl) : 0;
        if (g_frame_limit < 0) g_frame_limit = 0;
        g_frame_no = 0;
        g_frame_limit_warned = 0;
    }
    return rt_none();
}

/* ---- 给 pybook_hw3d.c 用的桥（不注册给 PYbook，程序不直接调）---- */

/* 离屏 surface 及其尺寸：3D 每帧把它上传成纹理贴上去。
   传 NULL 表示这一帧没有 UI 要贴（纯 3D）。 */
void *rt_ui_surface(void)   { return (void *)g_sdl_off; }
int   rt_ui_surface_w(void) { return (g_sdl_off != NULL) ? g_sdl_off->w : 0; }
int   rt_ui_surface_h(void) { return (g_sdl_off != NULL) ? g_sdl_off->h : 0; }
int   rt_ui_is_offscreen(void) { return g_off_mode; }

/* 离屏模式下 UI 没有自己的窗口，鼠标得由 3D 那边的窗口喂进来。
   3D 的窗口坐标换算成逻辑坐标由这一层负责（两边窗口尺寸可能不同）。 */
void rt_ui_mouse_feed(int wx, int wy, int winw, int winh, int down)
{
    if (g_log_w > 0) g_ui_mx = (winw > 0) ? (int)((long long)wx * g_log_w / winw) : wx;
    if (g_log_h > 0) g_ui_my = (winh > 0) ? (int)((long long)wy * g_log_h / winh) : wy;
    g_ui_mdown = down ? 1 : 0;
}

/* 离屏模式的帧步进：由 pybook_hw3d.c 在每帧末调一次。
   干的事就是 rt_game_frame 在窗口模式下干的那两件 —— 抽事件、翻鼠标边沿 ——
   不做的话 rt_game_mhit 读的 g_mcur/g_mprev 永远是初值，
   UI 的"点一下"就永远不成立（不报错，只是点了没反应）。
   ★ 调在帧末，所以喂进来的鼠标对**下一帧**的 UI 生效，差一帧。
   这和 ui.矩形 本来就要读上一帧的矩形是同一个量级，可以接受。 */
void rt_ui_frame_step(void)
{
    game_pump();
    g_mprev = g_mcur;
    g_mcur = g_ui_mdown;
    /* ★ 分组序号必须在这里清零。
     *   rt_ui_new_frame 原来只有 rt_game_show（2D 窗口模式）调，
     *   离屏模式下没人调 —— 于是 g_grp_slot 一路累加，第 N 帧读的是第 N+1 号槽，
     *   而那一槽要到本帧结尾才写。永远是空 → 永远是 0 →
     *   ui.分组 的面板高度判据 `if (ph > 0)` 不成立，**面板底一帧都不画**
     *   （标题竖条和文字照画，所以看上去像"标题有、底板没了"）。
     *   帧末重数是唯一正确的时机：一帧可以有多列 ui.begin，只有帧边界才知道帧在哪。 */
    rt_ui_new_frame();

    /* ★ 离屏 surface 每帧必须清回全透明（2026-10-18 修，一个静默很久的真 bug）。
     *
     * 症状：ui.离屏 模式下，**半透明**像素会逐帧累积，几帧之后趋近不透明。
     *   实测（探针 _UI图a3D.pybk + pybook_hw3d.c 的 PYBOOK_UI_DUMP 诊断口）：
     *     一张 alpha=128 的纯红图，surface 里逐帧变成
     *       (110,30,30,128) -> (164,44,44,191) -> (191,51,51,223) -> …
     *     收敛到 (219,…) / A=255，等于完全不透明。
     *   根因：SDL_FillRect(g_sdl_off, …) 全仓库只出现在 rt_ui_offscreen 里
     *   **创建时那一次**，每帧没有任何地方清 —— 半透明的 alpha 就在往自己身上叠。
     *
     * 为什么之前没暴露：上半年的 3D+UI 验收用的 UI 全是**不透明**的
     * （控件底 alpha=255、文字 alpha=255），每帧在同一批像素上重画，
     * 旧值被新值直接覆盖，累积与否**像素完全一样**。
     * 第一个把半透明像素放进离屏 surface 的东西（ui.图 的 alpha 区、
     * 圆角抗锯齿边缘、投影）一进来就把它顶出来了。
     *
     * 清在这里安全：rt_hw_frame 的顺序是 贴 UI -> 截图 -> swap -> rt_ui_frame_step，
     * 贴和截图都已经跑完；下一帧的 UI 绘制才开始写这个 surface。 */
    if (g_off_mode && g_sdl_off != NULL)
        SDL_FillRect(g_sdl_off, NULL, 0x00000000u);
}

Value rt_game_win(Value wv, Value hv, const char *title)
{
    int w = (int)game_num(wv, "game.win 的宽");
    int h = (int)game_num(hv, "game.win 的高");
    SDL_SetMainReady();               /* 配合 SDL_MAIN_HANDLED：main 归用户 */
    if (SDL_Init(SDL_INIT_VIDEO) != 0)
        rt_die("SDL 初始化失败: %s", SDL_GetError());
    if (g_sdl_win != NULL) {          /* 重复开窗：先收掉旧的 */
        SDL_DestroyRenderer(g_sdl_ren);
        SDL_DestroyWindow(g_sdl_win);
        g_sdl_ren = NULL;
        g_sdl_win = NULL;
    }
    g_off_mode = 0;                   /* 回到窗口模式：离屏的那块 surface 收掉 */
    if (g_sdl_off != NULL) {
        SDL_FreeSurface(g_sdl_off);
        g_sdl_off = NULL;
    }
    g_sdl_win = SDL_CreateWindow(title && *title ? title : "PYbook",
                                 SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
                                 w, h, SDL_WINDOW_SHOWN | SDL_WINDOW_RESIZABLE);
    if (g_sdl_win == NULL)
        rt_die("创建窗口失败: %s", SDL_GetError());
    g_sdl_ren = SDL_CreateRenderer(g_sdl_win, -1, SDL_RENDERER_ACCELERATED);
    if (g_sdl_ren == NULL)            /* 没有加速后端就退回软渲染 */
        g_sdl_ren = SDL_CreateRenderer(g_sdl_win, -1, 0);
    if (g_sdl_ren == NULL)
        rt_die("创建渲染器失败: %s", SDL_GetError());
    SDL_RenderSetLogicalSize(g_sdl_ren, w, h);
    SDL_StartTextInput();          /* 收 SDL_TEXTINPUT：中文 IME 也靠它 */   /* 逻辑尺寸 = 窗口尺寸，缩放不变形 */
    g_log_w = w;
    g_log_h = h;
    memset(g_kprev, 0, sizeof g_kprev);
    memset(g_kcur, 0, sizeof g_kcur);
    g_quit = 0;
    rt_shot_init();              /* 无头出图：环境变量没设就是零开销的空函数体 */
    {   /* 无头帧数上限（默认不限，老脚本行为不变） */
        const char *fl = getenv("PYBOOK_FRAME_LIMIT");
        g_frame_limit = (fl && *fl) ? atoi(fl) : 0;
        if (g_frame_limit < 0) g_frame_limit = 0;
        g_frame_no = 0;
        g_frame_limit_warned = 0;
    }
    return rt_none();
}

Value rt_game_clear(Value rv, Value gv, Value bv)
{
    if (g_sdl_ren == NULL)
        rt_die("game.clear：还没开窗口（先调用 game.win）");
    SDL_SetRenderDrawColor(g_sdl_ren, sdl_u8((int)game_num(rv, "game.clear 的 R")),
                           sdl_u8((int)game_num(gv, "game.clear 的 G")),
                           sdl_u8((int)game_num(bv, "game.clear 的 B")), 255);
    SDL_RenderClear(g_sdl_ren);
    return rt_none();
}

Value rt_game_color(Value rv, Value gv, Value bv)
{
    g_pen_r = sdl_u8((int)game_num(rv, "game.color 的 R"));
    g_pen_g = sdl_u8((int)game_num(gv, "game.color 的 G"));
    g_pen_b = sdl_u8((int)game_num(bv, "game.color 的 B"));
    return rt_none();
}

Value rt_game_box(Value xv, Value yv, Value wv, Value hv)
{
    if (g_sdl_ren == NULL)
        rt_die("game.box：还没开窗口（先调用 game.win）");
    SDL_Rect rc;
    rc.x = (int)game_num(xv, "game.box 的 x");
    rc.y = (int)game_num(yv, "game.box 的 y");
    rc.w = (int)game_num(wv, "game.box 的宽");
    rc.h = (int)game_num(hv, "game.box 的高");
    SDL_SetRenderDrawColor(g_sdl_ren, g_pen_r, g_pen_g, g_pen_b, 255);
    SDL_RenderFillRect(g_sdl_ren, &rc);
    return rt_none();
}

unsigned char *rt_mm_raster(Value rows, long long scale, size_t *W, size_t *H);

Value rt_mm_blt(Value rows, Value x, Value y, Value scale)
{
    if (g_sdl_ren == NULL)
        rt_die("mm.贴：还没开窗口（先调用 win）");
    size_t W = 0, H = 0;
    unsigned char *px = rt_mm_raster(rows, rt_to_ll(scale), &W, &H);
    SDL_Texture *tex = SDL_CreateTexture(g_sdl_ren, SDL_PIXELFORMAT_ABGR8888,
                                         SDL_TEXTUREACCESS_STREAMING, (int)W, (int)H);
    if (!tex)
        rt_die("mm.贴：创建纹理失败");
    SDL_SetTextureBlendMode(tex, SDL_BLENDMODE_BLEND);
    SDL_UpdateTexture(tex, NULL, px, (int)(W * 4));
    SDL_Rect dst;
    dst.x = (int)rt_to_ll(x);
    dst.y = (int)rt_to_ll(y);
    dst.w = (int)W;
    dst.h = (int)H;
    SDL_RenderCopy(g_sdl_ren, tex, NULL, &dst);
    SDL_DestroyTexture(tex);
    return rt_none();
}

Value rt_mm_anim(Value frames, Value x, Value y, Value scale, Value fps)
{
    if (g_sdl_ren == NULL)
        rt_die("mm.动：还没开窗口（先调用 win）");
    if (!IS_LIST(frames) || AS_LIST(frames) == NULL)
        rt_die("mm.动 需要帧列表（装着各帧像素列表的列表）");
    RtList *F = AS_LIST(frames);
    if (F->len == 0)
        rt_die("mm.动：帧列表是空的");
    long long fpsv = rt_to_ll(fps);
    if (fpsv < 1) fpsv = 1;
    long long idx = (long long)((SDL_GetTicks() / (unsigned)(1000 / fpsv)) % (unsigned)F->len);
    rt_mm_blt(F->items[idx], x, y, scale);
    return rt_none();
}

Value rt_game_dot(Value xv, Value yv)
{
    return rt_game_box(xv, yv, rt_int(4), rt_int(4));   /* 点 = 4×4 像素的小方块 */
}

Value rt_game_line(Value x1v, Value y1v, Value x2v, Value y2v)
{
    if (g_sdl_ren == NULL)
        rt_die("game.line：还没开窗口（先调用 game.win）");
    SDL_SetRenderDrawColor(g_sdl_ren, g_pen_r, g_pen_g, g_pen_b, 255);
    SDL_RenderDrawLine(g_sdl_ren,
                       (int)game_num(x1v, "game.line 的 x1"), (int)game_num(y1v, "game.line 的 y1"),
                       (int)game_num(x2v, "game.line 的 x2"), (int)game_num(y2v, "game.line 的 y2"));
    return rt_none();
}

/* ---- 字 / 图 / 图缩：中文文字与 PNG 贴图（stb 单头文件，零新增依赖） ---- */

#define STB_TRUETYPE_IMPLEMENTATION
#include "stb_truetype.h"
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

static stbtt_fontinfo g_ttf;      /* 比例中文字体（雅黑），惰性加载，数据常驻 */
static stbtt_fontinfo g_ttf_mono; /* 等宽中文字体（宋体），字符网格用 */
static stbtt_fontinfo *g_font = NULL;   /* 当前在用的那个 */
static int g_ttf_ok = 0;
static unsigned char *g_mono_data = NULL;
static int g_mono_ok = 0;
static void game_txt_flush(void);   /* 定义在下面「文本纹理缓存」处（切字体要清它） */
static int  g_use_mono = 0;

static void game_font_init(void)
{
    static const char *CAND[] = {
        "C:\\Windows\\Fonts\\msyh.ttc",    /* 微软雅黑 */
        "C:\\Windows\\Fonts\\msyh.ttf",
        "C:\\Windows\\Fonts\\simhei.ttf",  /* 黑体 */
        "C:\\Windows\\Fonts\\simsun.ttc",  /* 宋体 */
    };
    if (g_ttf_ok)
        return;
    for (int i = 0; i < (int)(sizeof CAND / sizeof CAND[0]); i++) {
        FILE *fp = fopen(CAND[i], "rb");
        if (fp == NULL)
            continue;
        fseek(fp, 0, SEEK_END);
        long n = ftell(fp);
        fseek(fp, 0, SEEK_SET);
        unsigned char *data = (unsigned char *)malloc((size_t)n);
        if (data != NULL && fread(data, 1, (size_t)n, fp) == (size_t)n) {
            int off = stbtt_GetFontOffsetForIndex(data, 0);
            if (off >= 0 && stbtt_InitFont(&g_ttf, data, off)) {
                g_ttf_ok = 1;          /* data 故意不释放：光栅化还要读 */
                if (g_font == NULL)
                    g_font = &g_ttf;
                fclose(fp);
                return;
            }
        }
        free(data);
        fclose(fp);
    }
    rt_die("game.字：在系统字体目录找不到中文字体（msyh/simhei/simsun）");
}

/* ---- 切到等宽中文字体（字符网格 / TUI 边框用）----
 *
 * 为什么非换字体不可：微软雅黑是**比例**字体。实测（16px 字号）制表符
 * ┌ ─ │ ┐ 的步进虽然都是 14px，可字形画得比步进窄 ——
 * `─` 的笔画只有约 10px，`│` 的笔画只有 13px（而格子高 16）。
 * 于是横排重复同一个字符每 14px 断 4px，竖排每格断 3px，
 * "由字符组成的边框"画出来是一串虚线。
 *
 * 宋体正好反过来：ASCII 定宽、CJK 全角、制表符按字宽设计，横竖都接得上。
 * 切换必须清文本纹理缓存 —— 里面是旧字体栅格化的位图。
 * 找不到等宽字体不算致命错：UI 退化成有断口的字符框，功能照常。
 */
int rt_game_font_mono(int on)
{
    if (!on) {
        if (g_mono_ok && g_use_mono) {
            g_font = &g_ttf;
            g_use_mono = 0;
            game_txt_flush();
        }
        return 1;
    }
    if (!g_mono_ok) {
        static const char *MCAND[] = {
            "C:\\Windows\\Fonts\\simsun.ttc",     /* 宋体：定宽 ASCII + 全角中文 */
            "C:\\Windows\\Fonts\\NSimSun.ttf",
            "C:\\Windows\\Fonts\\mingliub.ttc",   /* 明体（繁体机器上的退路） */
        };
        for (int i = 0; i < (int)(sizeof MCAND / sizeof MCAND[0]); i++) {
            FILE *fp = fopen(MCAND[i], "rb");
            if (fp == NULL)
                continue;
            fseek(fp, 0, SEEK_END);
            long n = ftell(fp);
            fseek(fp, 0, SEEK_SET);
            unsigned char *data = (unsigned char *)malloc((size_t)n);
            if (data != NULL && fread(data, 1, (size_t)n, fp) == (size_t)n) {
                int off = stbtt_GetFontOffsetForIndex(data, 0);
                if (off >= 0 && stbtt_InitFont(&g_ttf_mono, data, off)) {
                    g_mono_ok = 1;
                    g_mono_data = data;          /* 故意不释放 */
                    break;
                }
            }
            free(data);
            fclose(fp);
        }
    }
    if (!g_mono_ok)
        return 0;
    game_font_init();                  /* 比例字体也得在，切换回去要用 */
    g_font = &g_ttf_mono;
    g_use_mono = 1;
    game_txt_flush();
    return 1;
}

/* UTF-8 解一个码点，*adv 返回字节数 */
static unsigned game_utf8(const char *s, int i, int *adv)
{
    unsigned char c = (unsigned char)s[i];
    unsigned cp = c;
    *adv = 1;
    if (c >= 0xF0) {
        cp = ((c & 7u) << 18) | ((s[i + 1] & 63u) << 12) | ((s[i + 2] & 63u) << 6) | (s[i + 3] & 63u);
        *adv = 4;
    } else if (c >= 0xE0) {
        cp = ((c & 15u) << 12) | ((s[i + 1] & 63u) << 6) | (s[i + 2] & 63u);
        *adv = 3;
    } else if (c >= 0xC0) {
        cp = ((c & 31u) << 6) | (s[i + 1] & 63u);
        *adv = 2;
    }
    return cp;
}

/* 文本纹理缓存：键 = 字号|颜色|内容（换分数字会换内容，上限逐出最旧） */
#define TXT_CACHE_MAX 160
typedef struct { char *key; SDL_Texture *tex; int w, h; } TxtEnt;
static TxtEnt g_txt[TXT_CACHE_MAX];
static int g_txt_n = 0;

/* 清空文本纹理缓存。**换字体后必须调** ——
   缓存里是旧字体栅格化出来的位图，不清的话切换后画出来还是旧字形。 */
static void game_txt_flush(void)
{
    for (int i = 0; i < g_txt_n; i++) {
        if (g_txt[i].tex != NULL)
            SDL_DestroyTexture(g_txt[i].tex);
        free(g_txt[i].key);
    }
    g_txt_n = 0;
}

static SDL_Texture *game_text_tex(const char *s, int px, int *ow, int *oh)
{
    game_font_init();
    if (px < 6)
        px = 6;
    if (px > 220)
        px = 220;
    float scale = stbtt_ScaleForPixelHeight(g_font, (float)px);
    int ascent = 0, descent = 0, gap = 0;
    stbtt_GetFontVMetrics(g_font, &ascent, &descent, &gap);
    int base = (int)(ascent * scale) + 1;

    int W = 4;
    for (int i = 0; s[i];) {
        int adv = 1;
        unsigned cp = game_utf8(s, i, &adv);
        int a = 0, l = 0;
        stbtt_GetCodepointHMetrics(g_font, (int)cp, &a, &l);
        W += (int)(a * scale) + 2;
        i += adv;
    }
    int H = px + 4;
    unsigned char *pix = (unsigned char *)calloc((size_t)W * H * 4, 1);
    if (pix == NULL)
        rt_die("game.字：内存不足");
    int penx = 1;
    for (int i = 0; s[i];) {
        int adv = 1;
        unsigned cp = game_utf8(s, i, &adv);
        int bw = 0, bh = 0, ox = 0, oy = 0;
        unsigned char *bmp = stbtt_GetCodepointBitmap(g_font, scale, scale, (int)cp, &bw, &bh, &ox, &oy);
        if (bmp != NULL) {
            for (int j = 0; j < bh; j++) {
                int ty = base + oy + j;    /* oy 常为负：字形向上伸展 */
                if (ty < 0 || ty >= H)
                    continue;
                for (int k = 0; k < bw; k++) {
                    int tx = penx + ox + k;
                    if (tx < 0 || tx >= W)
                        continue;
                    size_t o = ((size_t)ty * W + tx) * 4;
                    pix[o] = (unsigned char)g_pen_r;
                    pix[o + 1] = (unsigned char)g_pen_g;
                    pix[o + 2] = (unsigned char)g_pen_b;
                    pix[o + 3] = bmp[j * bw + k];
                }
            }
            stbtt_FreeBitmap(bmp, NULL);
        }
        int a2 = 0, l2 = 0;
        stbtt_GetCodepointHMetrics(g_font, (int)cp, &a2, &l2);
        penx += (int)(a2 * scale);
        i += adv;
    }
    SDL_Surface *sur = SDL_CreateRGBSurfaceWithFormatFrom(pix, W, H, 32, W * 4,
                                                          SDL_PIXELFORMAT_RGBA32);
    SDL_Texture *tex = SDL_CreateTextureFromSurface(g_sdl_ren, sur);
    SDL_FreeSurface(sur);
    free(pix);
    if (tex == NULL)
        rt_die("game.字：建纹理失败: %s", SDL_GetError());
    SDL_SetTextureBlendMode(tex, SDL_BLENDMODE_BLEND);
    *ow = W;
    *oh = H;
    return tex;
}

/* GUI 布局要量文字宽度：只累加 advance，不生成纹理（比 game_text_tex 轻）。
   非 static —— pybook_ui.c 要用。 */
int game_text_width(const char *s, int px)
{
    game_font_init();
    if (s == NULL)
        return 0;
    if (px < 6)
        px = 6;
    if (px > 220)
        px = 220;
    float scale = stbtt_ScaleForPixelHeight(g_font, (float)px);
    int W = 4;
    for (int i = 0; s[i];) {
        int adv = 1;
        unsigned cp = game_utf8(s, i, &adv);
        int a = 0, l = 0;
        stbtt_GetCodepointHMetrics(g_font, (int)cp, &a, &l);
        W += (int)(a * scale) + 2;
        i += adv;
    }
    return W;
}

/* 字符串的**真实步进**（各字形 advance 之和，不含 game_text_width 的排版余量）。
   game_text_width 是纹理宽度 = 4 + Σ(advance + 2)，单字符也要 +6。
   字符网格必须用这个：拿 game_text_width 当步进，角画到 x+8、横线却从 x+14 起，
   中间凭空多 6px 断口（实测，截图放大才看得见）。 */
int game_text_advance(const char *s, int px)
{
    game_font_init();
    if (s == NULL)
        return 0;
    if (px < 6)
        px = 6;
    if (px > 220)
        px = 220;
    float scale = stbtt_ScaleForPixelHeight(g_font, (float)px);
    int total = 0;
    for (int i = 0; s[i];) {
        int adv = 1;
        unsigned cp = game_utf8(s, i, &adv);
        int a = 0, l = 0;
        stbtt_GetCodepointHMetrics(g_font, (int)cp, &a, &l);
        total += (int)(a * scale);
        i += adv;
    }
    return total;
}

Value rt_game_text(Value xv, Value yv, Value tv, Value sv)
{
    if (g_sdl_ren == NULL)
        rt_die("game.字：还没开窗口（先调用 win）");
    int x = (int)game_num(xv, "game.字 的 x");
    int y = (int)game_num(yv, "game.字 的 y");
    int px = (int)game_num(sv, "game.字 的字号");
    char *s = rt_str_of(tv);
    char head[48];
    snprintf(head, sizeof head, "%d|%02x%02x%02x|", px, g_pen_r, g_pen_g, g_pen_b);
    size_t klen = strlen(head) + strlen(s) + 1;
    char *key = (char *)malloc(klen);
    if (key == NULL)
        rt_die("game.字：内存不足");
    snprintf(key, klen, "%s%s", head, s);

    SDL_Texture *tex = NULL;
    int tw = 0, th = 0;
    for (int i = 0; i < g_txt_n; i++) {
        if (strcmp(g_txt[i].key, key) == 0) {
            tex = g_txt[i].tex;
            tw = g_txt[i].w;
            th = g_txt[i].h;
            break;
        }
    }
    if (tex == NULL) {
        tex = game_text_tex(s, px, &tw, &th);
        if (g_txt_n == TXT_CACHE_MAX) {          /* 满了：逐出最旧的一条 */
            SDL_DestroyTexture(g_txt[0].tex);
            free(g_txt[0].key);
            memmove(g_txt, g_txt + 1, sizeof(TxtEnt) * (TXT_CACHE_MAX - 1));
            g_txt_n--;
        }
        g_txt[g_txt_n].key = key;
        g_txt[g_txt_n].tex = tex;
        g_txt[g_txt_n].w = tw;
        g_txt[g_txt_n].h = th;
        g_txt_n++;
    } else {
        free(key);
    }
    SDL_Rect dst;
    dst.x = x;
    dst.y = y;
    dst.w = tw;
    dst.h = th;
    SDL_RenderCopy(g_sdl_ren, tex, NULL, &dst);
    /* s 是 rt_str_of 的结果（可能是 Value 内部指针）：按运行时约定不回收 */
    return rt_none();
}

/* 图片缓存：路径 -> 纹理（加载一次常驻）
 *
 * ★ 2026-10-18 从「48 槽 + 满了 rt_die」改成「256 槽 + LRU 淘汰」。
 *   起因是 UI 要放序列动画：ui.序列 一套动画 8~24 帧，两套就顶满 48 槽，
 *   而原来的行为是**直接退出程序**（不是"画不出来"），序列根本没法用。
 *   淘汰最久未用的纹理，最坏情况是下次用到时重新解码一次 ——
 *   一次性开销，但绝不退出程序。槽位从 48 涨到 256 的代价是每槽 40 字节。
 *
 * ★ 必须记归属渲染器：SDL_Texture 绑定在**创建它的那个 SDL_Renderer** 上，
 *   而 rt_ui_offscreen 会 SDL_DestroyRenderer 再 SDL_CreateSoftwareRenderer
 *   造一个新的（窗口模式 <-> 离屏模式切换就是换对象，pybook_rt.c:3504）。
 *   拿旧渲染器的纹理往新渲染器上 RenderCopy，SDL 直接报
 *   "Texture was not created with this renderer"，整屏图片全丢。
 *   所以这里比对 g_sdl_ren，发现换过就把整张缓存作废重载。 */
#define IMG_CACHE_MAX 256
typedef struct { char *path; SDL_Texture *tex; int w, h; unsigned long used; } ImgEnt;
static ImgEnt g_img[IMG_CACHE_MAX];
static int g_img_n = 0;
static unsigned long g_img_tick = 0;
static SDL_Renderer *g_img_ren = NULL;   /* 缓存归属的渲染器 */

static void game_img_drop(void)
{
    for (int i = 0; i < g_img_n; i++) {
        if (g_img[i].tex)
            SDL_DestroyTexture(g_img[i].tex);
        free(g_img[i].path);
        g_img[i].path = NULL;
        g_img[i].tex = NULL;
    }
    g_img_n = 0;
}

static SDL_Texture *game_img_tex(const char *path, int *ow, int *oh)
{
    if (g_img_ren != g_sdl_ren) {      /* 渲染器换了：旧纹理全部作废 */
        game_img_drop();
        g_img_ren = g_sdl_ren;
    }
    for (int i = 0; i < g_img_n; i++) {
        if (g_img[i].path != NULL && strcmp(g_img[i].path, path) == 0) {
            g_img[i].used = ++g_img_tick;      /* LRU：命中就刷新 */
            *ow = g_img[i].w;
            *oh = g_img[i].h;
            return g_img[i].tex;
        }
    }
    /* UTF-8 路径 → UTF-16 → _wfopen（fopen 会按 ANSI 代码页误读中文路径） */
    wchar_t wpath[1024];
    if (MultiByteToWideChar(CP_UTF8, 0, path ? path : "", -1, wpath, 1024) <= 0)
        rt_die("game.图：路径转码失败 %s", path);
    FILE *fp = _wfopen(wpath, L"rb");
    if (fp == NULL)
        rt_die("game.图：无法加载图片 %s", path);
    int w = 0, h = 0, n = 0;
    unsigned char *data = stbi_load_from_file(fp, &w, &h, &n, 4);
    fclose(fp);
    if (data == NULL)
        rt_die("game.图：图片解码失败 %s", path);
    SDL_Surface *sur = SDL_CreateRGBSurfaceWithFormatFrom(data, w, h, 32, w * 4,
                                                          SDL_PIXELFORMAT_RGBA32);
    SDL_Texture *tex = SDL_CreateTextureFromSurface(g_sdl_ren, sur);
    SDL_FreeSurface(sur);
    stbi_image_free(data);
    if (tex == NULL)
        rt_die("game.图：建纹理失败: %s", SDL_GetError());
    SDL_SetTextureBlendMode(tex, SDL_BLENDMODE_BLEND);
    if (g_img_n == IMG_CACHE_MAX) {
        /* 满槽：淘汰最久没用的那个，腾出来放新图。
           用尾槽补洞（g_img[lru] = g_img[--g_img_n]），保持 [0, g_img_n) 紧凑。 */
        int lru = 0;
        for (int i = 1; i < g_img_n; i++)
            if (g_img[i].used < g_img[lru].used)
                lru = i;
        SDL_DestroyTexture(g_img[lru].tex);
        free(g_img[lru].path);
        g_img[lru] = g_img[--g_img_n];
    }
    g_img[g_img_n].path = strdup(path);
    g_img[g_img_n].tex = tex;
    g_img[g_img_n].w = w;
    g_img[g_img_n].h = h;
    g_img[g_img_n].used = ++g_img_tick;
    g_img_n++;
    *ow = w;
    *oh = h;
    return tex;
}

Value rt_game_img(Value xv, Value yv, Value pv)
{
    if (g_sdl_ren == NULL)
        rt_die("game.图：还没开窗口（先调用 win）");
    int x = (int)game_num(xv, "game.图 的 x");
    int y = (int)game_num(yv, "game.图 的 y");
    char *p = rt_str_of(pv);
    int w = 0, h = 0;
    SDL_Texture *tex = game_img_tex(p, &w, &h);
    SDL_Rect dst;
    dst.x = x;
    dst.y = y;
    dst.w = w;
    dst.h = h;
    SDL_RenderCopy(g_sdl_ren, tex, NULL, &dst);
    return rt_none();
}

Value rt_game_img_scaled(Value xv, Value yv, Value wv, Value hv, Value pv)
{
    if (g_sdl_ren == NULL)
        rt_die("game.图缩：还没开窗口（先调用 win）");
    int x = (int)game_num(xv, "game.图缩 的 x");
    int y = (int)game_num(yv, "game.图缩 的 y");
    int w = (int)game_num(wv, "game.图缩 的宽");
    int h = (int)game_num(hv, "game.图缩 的高");
    char *p = rt_str_of(pv);
    int tw = 0, th = 0;
    SDL_Texture *tex = game_img_tex(p, &tw, &th);
    SDL_Rect dst;
    dst.x = x;
    dst.y = y;
    dst.w = w;
    dst.h = h;
    SDL_RenderCopy(g_sdl_ren, tex, NULL, &dst);
    return rt_none();
}

/* 图翻(x, y, w, h, 路径, 翻转)：翻转非 0 时水平镜像（角色朝左用） */
Value rt_game_img_flip(Value xv, Value yv, Value wv, Value hv, Value pv, Value fv)
{
    if (g_sdl_ren == NULL)
        rt_die("game.图翻：还没开窗口（先调用 win）");
    int x = (int)game_num(xv, "game.图翻 的 x");
    int y = (int)game_num(yv, "game.图翻 的 y");
    int w = (int)game_num(wv, "game.图翻 的宽");
    int h = (int)game_num(hv, "game.图翻 的高");
    char *p = rt_str_of(pv);
    int flip = (int)game_num(fv, "game.图翻 的翻转");
    int tw = 0, th = 0;
    SDL_Texture *tex = game_img_tex(p, &tw, &th);
    SDL_Rect dst;
    dst.x = x;
    dst.y = y;
    dst.w = w < 0 ? -w : w;
    dst.h = h;
    SDL_RenderCopyEx(g_sdl_ren, tex, NULL, &dst, 0, NULL,
                     flip ? SDL_FLIP_HORIZONTAL : SDL_FLIP_NONE);
    return rt_none();
}

/* GUI 引擎（pybook_ui.c）要直接画矩形边框 —— rt_game_box 只能填实心，
   描边得自己调 SDL。g_sdl_ren / g_log_w / g_log_h 都是本文件 static，
   所以给三个访问口。 */
SDL_Renderer *game_renderer(void) { return g_sdl_ren; }
int game_width(void)  { return g_log_w; }
int game_height(void) { return g_log_h; }

/* 桌面 GUI 引擎（pybook_ui.c）要贴图 —— game_img_tex 是本文件 static，给个访问口。
   UI 那边拿到纹理后直接 SDL_RenderCopy(game_renderer(), ...)，
   离屏模式下 game_renderer() 返回的是绑到 ARGB8888 surface 的软件渲染器，
   所以这一条路对「2D 窗口」和「3D 同屏」两种模式都成立，不用写第二套。
   缓存的 renderer 归属检测在 game_img_tex 里，跨模式切换自动作废重载。 */
SDL_Texture *game_img_tex_pub(const char *path, int *w, int *h)
{
    if (g_sdl_ren == NULL)
        rt_die("贴图：还没开窗口（先调用 win 或 ui.离屏）");
    return game_img_tex(path, w, h);
}

#ifdef _WIN32
#  include <direct.h>          /* _mkdir：出图目录逐级建 */
#else
#  include <sys/stat.h>
#  include <sys/types.h>
#endif

/* ================= 无头出图（环境变量驱动，验收/截图用）=================
   存在的理由：SDL_Renderer 这条路（game.* 与整条 ui.* GUI）原本**没有任何
   截图能力** —— UI 引擎连"控件画对了没有"都无法程序化验证，只能人眼看窗口，
   改一行布局也没法回归。变量名与语义和 pybook_hw3d.c 那套完全一致，
   唯一区别是读回源：这里是 SDL_RenderReadPixels，3D 那边是 glReadPixels。
     PYBOOK_SHOT_DIR     出图目录（设了才开）
     PYBOOK_SHOT_EVERY   每多少帧存一张（默认 20）
     PYBOOK_SHOT_MAX     最多存几张（默认 8）
     PYBOOK_SHOT_PREFIX  文件名前缀（默认 "ui"）
   环境变量不设就一行都不跑，对跑真游戏的程序零开销。

   存 BMP 的理由和 3D 那边一样：零依赖、最好写。SDL 读回的是 RGBA，
   BMP 是 BGR 且行自底向上，所以要翻通道、倒着写行。 */
static int  g_shot_on    = 0;
static int  g_shot_every = 20;
static int  g_shot_max   = 8;
static int  g_shot_taken = 0;
static int  g_shot_seen  = 0;
static char g_shot_dir[400] = {0};
static char g_shot_pre[32]  = "ui";

static void rt_shot_u16(FILE *f, unsigned v)
{
    unsigned char b[2] = { (unsigned char)(v & 0xFF), (unsigned char)((v >> 8) & 0xFF) };
    fwrite(b, 1, 2, f);
}

static void rt_shot_u32(FILE *f, unsigned long v)
{
    unsigned char b[4] = { (unsigned char)(v & 0xFF), (unsigned char)((v >> 8) & 0xFF),
                           (unsigned char)((v >> 16) & 0xFF), (unsigned char)((v >> 24) & 0xFF) };
    fwrite(b, 1, 4, f);
}

/* rgba：W*H*4，按 SDL_PIXELFORMAT_RGBA32 的字节序（R,G,B,A，恒定不随端序变）。
   BMP 是 BGR 且自底向上，所以逐像素翻通道 + 倒序出行。 */
static int rt_shot_write_bmp(const char *path, int W, int H, const unsigned char *rgba)
{
    FILE *f = fopen(path, "wb");
    if (f == NULL) {
        fprintf(stderr, "[shot] 打不开 %s（目录不存在或不可写？）\n", path);
        return 0;
    }
    int pad  = (4 - (W * 3) % 4) % 4;
    unsigned long stride = (unsigned long)(W * 3 + pad);
    unsigned long img    = stride * (unsigned long)H;

    fwrite("BM", 1, 2, f);
    rt_shot_u32(f, 54 + img);
    rt_shot_u16(f, 0);  rt_shot_u16(f, 0);
    rt_shot_u32(f, 54);                       /* 像素数据偏移 */
    rt_shot_u32(f, 40);                       /* BITMAPINFOHEADER */
    rt_shot_u32(f, (unsigned long)W);
    rt_shot_u32(f, (unsigned long)H);         /* 正高度 = 行自底向上 */
    rt_shot_u16(f, 1);  rt_shot_u16(f, 24);   /* 1 色 / 24 位 */
    rt_shot_u32(f, 0);                        /* BI_RGB 未压缩 */
    rt_shot_u32(f, img);
    rt_shot_u32(f, 2835); rt_shot_u32(f, 2835);   /* 72 dpi */
    rt_shot_u32(f, 0);  rt_shot_u32(f, 0);

    unsigned char *line = (unsigned char *)malloc((size_t)W * 3 + 4);
    if (line == NULL) { fclose(f); return 0; }
    for (int y = H - 1; y >= 0; y--) {         /* SDL 的 y=0 在上，BMP 要反过来 */
        const unsigned char *src = rgba + (size_t)y * W * 4;
        int n = 0;
        for (int x = 0; x < W; x++) {
            line[n++] = src[x * 4 + 2];        /* B */
            line[n++] = src[x * 4 + 1];        /* G */
            line[n++] = src[x * 4 + 0];        /* R */
        }
        fwrite(line, 1, (size_t)n, f);
        for (int k = 0; k < pad; k++)
            fputc(0, f);
    }
    free(line);
    fclose(f);
    return 1;
}

static void rt_shot_init(void)
{
    const char *d = getenv("PYBOOK_SHOT_DIR");
    g_shot_on = 0;
    if (d == NULL || *d == 0)
        return;
    snprintf(g_shot_dir, sizeof g_shot_dir, "%s", d);
    const char *e = getenv("PYBOOK_SHOT_EVERY");
    const char *m = getenv("PYBOOK_SHOT_MAX");
    const char *p = getenv("PYBOOK_SHOT_PREFIX");
    if (e && *e) g_shot_every = atoi(e);
    if (m && *m) g_shot_max   = atoi(m);
    if (p && *p) snprintf(g_shot_pre, sizeof g_shot_pre, "%s", p);
    if (g_shot_every < 1) g_shot_every = 1;
    if (g_shot_max   < 1) g_shot_max   = 1;
    g_shot_on = 1;
    g_shot_seen = 0;
    g_shot_taken = 0;
#ifdef _WIN32
    {   /* 逐级 mkdir -p */
        char tmp[400];
        snprintf(tmp, sizeof tmp, "%s", g_shot_dir);
        for (char *q = tmp + 1; *q; q++) {
            if (*q == '/' || *q == '\\') { *q = 0; _mkdir(tmp); *q = '/'; }
        }
        _mkdir(tmp);
    }
#else
    { char tmp[400]; snprintf(tmp, sizeof tmp, "%s", g_shot_dir);
      for (char *q = tmp + 1; *q; q++) {
          if (*q == '/') { *q = 0; mkdir(tmp, 0755); *q = '/'; }
      }
      mkdir(tmp, 0755); }
#endif
    fprintf(stderr, "[shot] 出图目录 %s  每 %d 帧一张，最多 %d 张（前缀 %s）\n",
            g_shot_dir, g_shot_every, g_shot_max, g_shot_pre);
}

static void rt_shot_maybe(void)
{
    if (!g_shot_on || g_shot_taken >= g_shot_max)
        return;
    /* ★ g_shot_seen 从 0 起，所以**第一张图就是第 1 帧**，不是第 every 帧。
     *   配上「ui.分组 的底板按设计首帧没有」（高度取上一帧缓存），
     *   很容易拿第 1 张去跟另一份程序的第 7 张比，得出「底板根本没画」的错结论。
     *   比对两张图之前先确认帧号一致。详见 pybook_ui.c 的 rt_ui_group 注释。 */
    if ((g_shot_seen++ % g_shot_every) != 0)
        return;
    int W = g_log_w, H = g_log_h;
    if (W <= 0 || H <= 0)
        return;
    unsigned char *px = (unsigned char *)malloc((size_t)W * H * 4);
    if (px == NULL)
        return;
    /* RGBA32 在 SDL2 里恒定是内存里的 R,G,B,A 字节序，不随主机端序变，
       所以下面翻通道时不用猜端序。 */
    if (SDL_RenderReadPixels(g_sdl_ren, NULL, SDL_PIXELFORMAT_RGBA32, px, W * 4) != 0) {
        fprintf(stderr, "[shot] SDL_RenderReadPixels 失败：%s\n", SDL_GetError());
        free(px);
        return;
    }
    char path[520];
    snprintf(path, sizeof path, "%s/%s_%03d.bmp", g_shot_dir, g_shot_pre, g_shot_taken);
    if (rt_shot_write_bmp(path, W, H, px)) {
        fprintf(stderr, "[shot] %s  (%dx%d)\n", path, W, H);
        g_shot_taken++;
    }
    free(px);
}

Value rt_game_show(void)
{
    if (g_sdl_ren == NULL)
        rt_die("game.show：还没开窗口（先调用 game.win）");
    rt_shot_maybe();
    rt_ui_new_frame();          /* 帧末通知 UI：一帧的分组序号从这里重新数 */
    SDL_RenderPresent(g_sdl_ren);
    return rt_none();
}

/* ---- 圆 与 鼠标（俯视角游戏零件）---- */

/* 圆(x, y, r)：当前画笔色的实心圆（扫描线填充） */
Value rt_game_circle(Value xv, Value yv, Value rv)
{
    if (g_sdl_ren == NULL)
        rt_die("game.circle：还没开窗口（先调用 game.win）");
    int cx = (int)game_num(xv, "game.circle 的 x");
    int cy = (int)game_num(yv, "game.circle 的 y");
    int r = (int)game_num(rv, "game.circle 的 r");
    if (r < 1)
        r = 1;
    SDL_SetRenderDrawColor(g_sdl_ren, g_pen_r, g_pen_g, g_pen_b, 255);
    for (int dy = -r; dy <= r; dy++) {
        double w2 = (double)r * r - (double)dy * dy;
        int w = (int)sqrt(w2);
        SDL_RenderDrawLine(g_sdl_ren, cx - w, cy + dy, cx + w, cy + dy);
    }
    return rt_none();
}

/* 鼠标逻辑坐标：窗口坐标按逻辑尺寸折算（窗口拉伸/最大化都准） */
Value rt_game_mx(void)
{
    if (g_sdl_ren == NULL)
        rt_die("game.mx：还没开窗口（先调用 game.win）");
    if (g_off_mode)                   /* 离屏：UI 没有窗口，鼠标由 3D 那边的窗口喂进来 */
        return rt_int(g_ui_mx);
    int wx, wy, winW, winH;
    SDL_GetMouseState(&wx, &wy);
    SDL_GetWindowSize(g_sdl_win, &winW, &winH);
    if (winW < 1)
        winW = 1;
    if (winH < 1)
        winH = 1;
    return rt_int((long long)(wx * g_log_w / winW));
}

Value rt_game_my(void)
{
    if (g_sdl_ren == NULL)
        rt_die("game.my：还没开窗口（先调用 game.win）");
    if (g_off_mode)
        return rt_int(g_ui_my);
    int wx, wy, winW, winH;
    SDL_GetMouseState(&wx, &wy);
    SDL_GetWindowSize(g_sdl_win, &winW, &winH);
    if (winH < 1)
        winH = 1;
    return rt_int((long long)(wy * g_log_h / winH));
}

/* 鼠标左键按住 */
Value rt_game_mdown(void)
{
    if (g_sdl_ren == NULL)
        rt_die("game.mdown：还没开窗口（先调用 game.win）");
    if (g_off_mode)
        return rt_int(g_ui_mdown);
    game_pump();
    return rt_int((SDL_GetMouseState(NULL, NULL) & SDL_BUTTON_LMASK) ? 1 : 0);
}

/* 鼠标左键刚按下（本帧一次性） */
Value rt_game_mhit(void)
{
    if (g_sdl_ren == NULL)
        rt_die("game.mhit：还没开窗口（先调用 game.win）");
    game_pump();
    return rt_int((g_mcur && !g_mprev) ? 1 : 0);
}

Value rt_game_key(const char *name)
{
    int vk = game_key_code(name);
    if (vk == 0)
        return rt_int(0);   /* 未知键名按"没按"处理 */
    game_pump();
    return rt_int((GetAsyncKeyState(vk) & 0x8000) ? 1 : 0);
}

Value rt_game_hit(const char *name)
{
    int vk = game_key_code(name);
    if (vk == 0)
        return rt_int(0);
    return rt_int((g_kcur[vk & 255] && !g_kprev[vk & 255]) ? 1 : 0);
}

static long long g_frames_run = 0;   /* 框架模式累计帧数（frame / sec 内置用） */

static int dirkey_down(const char *name)
{
    int vk = game_key_code((char *)name);
    return (vk && (GetAsyncKeyState(vk) & 0x8000)) ? 1 : 0;
}

Value rt_dirkeys(void)
{
    game_pump();
    int dx = (dirkey_down("d") + dirkey_down("right"))
           - (dirkey_down("a") + dirkey_down("left"));
    int dy = (dirkey_down("s") + dirkey_down("down"))
           - (dirkey_down("w") + dirkey_down("up"));
    Value out = rt_list_new();
    rt_push(&out, rt_int(dx));
    rt_push(&out, rt_int(dy));
    return out;
}

Value rt_frames(void) { game_pump(); return rt_int(g_frames_run); }
Value rt_secs(void)  { game_pump(); return rt_float(g_frames_run / 60.0); }

/* 3D 帧计数（rt_hw_frame 每帧调用）：让 frame()/sec() 在 3D_highway 里也走起来。
   以前计数只在 2D rt_game_frame 里递增，3D 程序 frame/sec 恒为 0。 */
void rt_frame_tick(void) { g_frames_run++; }


Value rt_game_frame(void)
{
    g_frames_run++;   /* frame / sec 内置计数 */
    game_pump();
    memcpy(g_kprev, g_kcur, sizeof g_kcur);   /* cur → prev（给 rt_game_hit 用） */
    for (int i = 0; i < 256; i++)             /* 刷新当前键盘状态 */
        g_kcur[i] = (GetAsyncKeyState(i) & 0x8000) ? 1 : 0;
    g_mprev = g_mcur;                         /* 鼠标左键状态翻页（rt_game_mhit 用） */
    g_mcur = (SDL_GetMouseState(NULL, NULL) & SDL_BUTTON_LMASK) ? 1 : 0;
    /* 约 60 FPS。但无头验收模式（设了 PYBOOK_FRAME_LIMIT）下没人看动画，
       睡 16ms 纯属白等 10 帧就要 160ms —— 直接不睡，帧闸门该做的
       键盘/鼠标状态翻页和事件泵照常做。 */
    if (g_frame_limit <= 0)
        SDL_Delay(16);
    return rt_none();
}

Value rt_game_end(void)
{
    game_pump();
    /* 无头模式的帧数上限：PYBOOK_FRAME_LIMIT=N
       为什么非加不可：window(normal, open) 框架模式的循环退出条件只有两个 ——
       窗口被关（要真人点 X）或按住 ESC（要物理键盘）。CI / 截图探针 / 回归里
       两者一个都没有，程序就会永远跑下去，验收根本收不了尾。
       设了它就跑满 N 帧后走和点 X 完全一样的正常退出路径，不影响交互程序：
       默认 0 = 不限，老脚本行为一个字都不变。 */
    if (g_frame_limit > 0 && ++g_frame_no >= g_frame_limit) {
        if (!g_frame_limit_warned) {
            g_frame_limit_warned = 1;
            fprintf(stderr, "[frame] 到达 PYBOOK_FRAME_LIMIT=%d，正常退出\n", g_frame_limit);
        }
        return rt_bool(1);
    }
    if (g_quit)
        return rt_bool(1);
    /* 点 X 之外，按住 ESC 也算想结束（退出约定） */
    return rt_bool((GetAsyncKeyState(VK_ESCAPE) & 0x8000) ? 1 : 0);
}

Value rt_game_bye(void)
{
    if (g_sdl_ren != NULL) {
        SDL_DestroyRenderer(g_sdl_ren);
        g_sdl_ren = NULL;
    }
    if (g_sdl_win != NULL) {
        SDL_Delay(500);   /* 留半秒让最后一帧被看见 */
        SDL_DestroyWindow(g_sdl_win);
        g_sdl_win = NULL;
    }
    SDL_Quit();
    return rt_none();
}

#else /* 未启用 SDL2：游戏零件编译"未启用"桩 */
Value rt_mm_blt(Value rows, Value x, Value y, Value scale)
{
    (void)rows; (void)x; (void)y; (void)scale;
    rt_die("mm.贴 需要窗口模式（本机构建未启用 SDL）");
}

Value rt_mm_anim(Value frames, Value x, Value y, Value scale, Value fps)
{
    (void)frames; (void)x; (void)y; (void)scale; (void)fps;
    rt_die("mm.动 需要窗口模式（本机构建未启用 SDL）");
}


#define RT_GAME_OFF_MSG "游戏引擎需要 SDL2（构建时加 -Iucrt64/include -Lucrt64/lib -lSDL2）"

static void game_off(void) { rt_die("%s", RT_GAME_OFF_MSG); }

Value rt_game_win(Value w, Value h, const char *title) { (void)w; (void)h; (void)title; game_off(); return rt_none(); }
Value rt_game_clear(Value r, Value g, Value b) { (void)r; (void)g; (void)b; game_off(); return rt_none(); }
Value rt_game_color(Value r, Value g, Value b) { (void)r; (void)g; (void)b; game_off(); return rt_none(); }
Value rt_game_box(Value x, Value y, Value w, Value h) { (void)x; (void)y; (void)w; (void)h; game_off(); return rt_none(); }
Value rt_game_dot(Value x, Value y) { (void)x; (void)y; game_off(); return rt_none(); }
Value rt_game_line(Value x1, Value y1, Value x2, Value y2) { (void)x1; (void)y1; (void)x2; (void)y2; game_off(); return rt_none(); }
Value rt_game_show(void) { game_off(); return rt_none(); }
Value rt_game_key(const char *name) { (void)name; game_off(); return rt_none(); }
Value rt_game_hit(const char *name) { (void)name; game_off(); return rt_none(); }
Value rt_game_frame(void) { game_off(); return rt_none(); }
Value rt_game_end(void) { game_off(); return rt_none(); }
Value rt_game_bye(void) { game_off(); return rt_none(); }
Value rt_game_circle(Value x, Value y, Value r) { (void)x; (void)y; (void)r; game_off(); return rt_none(); }
Value rt_game_mx(void) { game_off(); return rt_none(); }
Value rt_game_my(void) { game_off(); return rt_none(); }
Value rt_game_mdown(void) { game_off(); return rt_none(); }
Value rt_game_mhit(void) { game_off(); return rt_none(); }
Value rt_game_text(Value x, Value y, Value t, Value s) { (void)x; (void)y; (void)t; (void)s; game_off(); return rt_none(); }
Value rt_game_img(Value x, Value y, Value p) { (void)x; (void)y; (void)p; game_off(); return rt_none(); }
Value rt_game_img_scaled(Value x, Value y, Value w, Value h, Value p) { (void)x; (void)y; (void)w; (void)h; (void)p; game_off(); return rt_none(); }

#endif /* RT_HAVE_SDL */

/* ================= FFI bridge (ffi.* low-level window) =================
 * ffi.调用 expands to real C calls at compile time; this only boxes/unboxes Value.
 * The door to the outside: bad C signatures crash - the price of the open window. */

long long rt_ffi_int(Value v)
{
    if (IS_INT(v) || IS_BOOL(v)) return AS_INT(v);
    if (IS_FLT(v))               return (long long)AS_FLT(v);
    if (IS_STR(v)) {
        char *end = NULL;
        long long r = strtoll(AS_STR(v), &end, 10);
        if (end && *end == '\0') return r;
        rt_die("FFI \u53c2\u6570\uff1a\u6587\u672c\u8f6c\u4e0d\u4e86\u6574\u6570");
    }
    rt_die("FFI \u53c2\u6570\uff1a\u8fd9\u4e2a\u503c\u5f53\u4e0d\u4e86 C \u6574\u6570\uff08\u7528 smoke.type \u770b\u770b\u662f\u4ec0\u4e48\uff09");
    return 0;
}

double rt_ffi_flt(Value v)
{
    if (IS_FLT(v))               return AS_FLT(v);
    if (IS_INT(v) || IS_BOOL(v)) return (double)AS_INT(v);
    if (IS_STR(v)) {
        char *end = NULL;
        double r = strtod(AS_STR(v), &end);
        if (end && *end == '\0') return r;
        rt_die("FFI \u53c2\u6570\uff1a\u6587\u672c\u8f6c\u4e0d\u4e86\u5c0f\u6570");
    }
    rt_die("FFI \u53c2\u6570\uff1a\u8fd9\u4e2a\u503c\u5f53\u4e0d\u4e86 C \u5c0f\u6570\uff08\u7528 smoke.type \u770b\u770b\u662f\u4ec0\u4e48\uff09");
    return 0.0;
}

char *rt_ffi_str(Value v)
{
    if (IS_STR(v))  return AS_STR(v);
    if (IS_DEL(v))  rt_die("\u7528\u5df2\u5220\u9664\u53d8\u91cf");
    if (IS_NONE(v)) return NULL;
    return rt_str_of(v);
}

void *rt_ffi_ptr(Value v)
{
    if (IS_NONE(v))              return NULL;
    if (IS_INT(v) || IS_BOOL(v)) return (void *)(uintptr_t)AS_INT(v);
    if (IS_STR(v))               return (void *)AS_STR(v);
    if (IS_FLT(v))               return (void *)(uintptr_t)(long long)AS_FLT(v);
    rt_die("FFI \u53c2\u6570\uff1a\u6307\u9488\u53ea\u6536\u6574\u6570\u5730\u5740 / \u6587\u672c / \u7a7a");
    return NULL;
}

/* C char* return -> PYbook string box (copied; NULL -> none) */
Value rt_ffi_str_ret(const char *s)
{
    return s ? rt_str(s) : rt_none();
}

/* ================= Smokeroor 查询接口（只读内部状态，给 smoke.* 用） ================= */

int rt_q_mode(void) { return g_memmode; }

long long rt_q_errors(void) { return g_err_count; }

void rt_q_freed(size_t *n, size_t *cap)
{
    if (n) *n = g_freed_n;
    if (cap) *cap = (size_t)RT_FREED_CAP;
}

size_t rt_q_roots(void) { return g_roots_n; }

int rt_q_locks(void) { return g_nlocks; }

/* 类型名（英文，对齐 smoke.type 的返回） */
const char *rt_q_typename(Value v)
{
    if (IS_DEL(v))    return "DELETED";
    if (IS_INT(v) || IS_BOOL(v)) return "INT";
    if (IS_FLT(v))    return "FLT";
    if (IS_STR(v))    return "STR";
    if (IS_BIGINT(v)) return "BIGINT";
    if (IS_LIST(v))   return "LIST";
    if (IS_DICT(v))   return "DICT";
    if (IS_TENSOR(v)) return "TENSOR";
    if (IS_OBJ(v))    return "OBJ";
    return "NONE";
}

/* 变量当前状态：0=OK 1=DELETED 2=LOCKED 3=DANGLING（@self 别名踩已释放地址） */
int rt_q_slotstate(Value v)
{
    if (IS_DEL(v))
        return 1;
    RtCell *c = cell_of(v);
    if (c && g_memmode == 1 && g_freed_n > 0 && ptr_registered((void *)(c + 1)))
        return 3;
    return 0;
}

/* GC 统计：minor 次数 / major 次数（性能剖析用） */
void rt_q_gcstats(long long *minor, long long *major)
{
    if (minor) *minor = g_gc_minor_n;
    if (major) *major = g_gc_major_n;
}

/* 知命可观测性：上次 GC 暂停时长（毫秒） */
void rt_q_gc_lastpause(long long *ms)
{
    if (ms) *ms = g_m7_last_pause_ms;
}

/* 知命可观测性：代际晋升累计次数 */
void rt_q_gc_promoted(long long *n)
{
    if (n) *n = g_m7_promoted;
}

/* 知命可观测性：按意图标签统计当前存活单元数（counts[5]：0未标1帧2关卡3共享4图） */
void rt_q_intent_counts(int counts[5])
{
    for (int i = 0; i < 5; i++) counts[i] = 0;
    for (RtCell *c = g_all; c; c = c->next) {
        int it = (int)c->intent;
        if (it < 0 || it > 4) it = 0;
        counts[it]++;
    }
}

/* ================= 自测（-DRT_SELF_TEST） ================= */

#ifdef RT_SELF_TEST

#include "pybook_lib.h"   /* rt_lib_te_* / rt_lib_mt_* / rt_lib_rd_* 冒烟 */
#include <unistd.h>       /* dup / dup2 / close：捕获 stdout 核对字节输出 */

static int g_pass = 0, g_fails = 0;

static void check(int cond, const char *name)
{
    if (cond) {
        g_pass++;
        printf("[通过] %s\n", name);
    } else {
        g_fails++;
        printf("[失败] %s\n", name);
    }
}

/* ---- 取值小助手 ---- */

static int is_i(Value v, long long x) { return IS_INT(v) && AS_INT(v) == x; }
static int is_f(Value v, double x)    { return IS_FLT(v) && AS_FLT(v) == x; }
static int is_s(Value v, const char *s) { return IS_STR(v) && strcmp(AS_STR(v), s) == 0; }
static int is_b(Value v, int b)       { return IS_BOOL(v) && AS_BOOL(v) == (b ? 1 : 0); }

/* ---- stdout 捕获（Windows 文本模式会把 \n 写成 \r\n，比对前去掉 \r） ---- */

static FILE *s_tmp;
static int s_saved_fd;

static void capture_start(void)
{
    fflush(stdout);
    s_saved_fd = dup(1);
    s_tmp = tmpfile();
    dup2(fileno(s_tmp), 1);
}

static void capture_finish(char *buf, size_t cap)
{
    fflush(stdout);
    dup2(s_saved_fd, 1);
    close(s_saved_fd);
    rewind(s_tmp);
    size_t n = fread(buf, 1, cap - 1, s_tmp);
    buf[n] = '\0';
    fclose(s_tmp);
    char *w = buf, *r = buf;
    while (*r) {
        if (*r != '\r')
            *w++ = *r;
        r++;
    }
    *w = '\0';
}

/* ---- 报错分支用例表：子进程模式跑指定用例，验证 exit(1) + stderr 消息 ---- */

static void e_add_ovf(void)      { (void)rt_add(rt_int(LLONG_MAX), rt_int(1)); }
static void e_sub_ovf(void)      { (void)rt_sub(rt_int(LLONG_MIN), rt_int(1)); }
static void e_mul_ovf(void)      { (void)rt_mul(rt_int(LLONG_MAX), rt_int(2)); }
static void e_div_zero(void)     { (void)rt_div(rt_int(1), rt_int(0)); }
static void e_div_fzero(void)    { (void)rt_div(rt_int(1), rt_float(0.0)); }
static void e_fdiv_zero(void)    { (void)rt_fdiv(rt_int(7), rt_int(0)); }
static void e_fdiv_ovf(void)     { (void)rt_fdiv(rt_int(LLONG_MIN), rt_int(-1)); }
static void e_mod_zero(void)     { (void)rt_mod(rt_int(7), rt_int(0)); }
static void e_neg_ovf(void)      { (void)rt_neg(rt_int(LLONG_MIN)); }
static void e_add_type(void)     { (void)rt_add(rt_str("a"), rt_int(1)); }
static void e_neg_type(void)     { (void)rt_neg(rt_str("x")); }
static void e_cmp_type(void)     { (void)rt_lt(rt_int(1), rt_str("a")); }
static void e_locked_assign(void)
{
    Value x = rt_int(1);
    rt_gold(&x);
    rt_assign(&x, rt_int(2));
}
static void e_locked_push(void)
{
    Value lst = rt_list_new();
    rt_gold(&lst);
    rt_push(&lst, rt_int(1));
}
static void e_del_read(void)
{
    Value x = rt_int(1);
    rt_destroy(&x);
    (void)rt_chk(x);
}
static void e_del_assign(void)
{
    Value x = rt_int(1);
    rt_destroy(&x);
    rt_assign(&x, rt_int(2));
}
static void e_index_oob(void)
{
    Value lst = rt_list_new();
    rt_push(&lst, rt_int(1));
    (void)rt_index(lst, rt_int(5));
}
static void e_prop_missing(void)
{
    Value o = rt_obj_new("猫");
    (void)rt_obj_get_prop(o, "身高");
}
static void e_memmode(void)      { rt_set_memmode(9); }   /* 0/1/3/4/5/6 之外 */
static void e_magic_bad(void)    { rt_magic("b,x1"); }
static void e_len_type(void)     { (void)rt_len(rt_int(5)); }
static void e_sqrt_neg(void)     { (void)rt_lib_mt_sqrt(rt_int(-9)); }
static void e_page_nobegin(void) { rt_page_para_open("b"); }
#if RT_HAVE_SDL
static void e_game_nowin(void)   { (void)rt_game_box(rt_int(0), rt_int(0), rt_int(1), rt_int(1)); }
#define E_GAME_MSG "还没开窗口"
#else
static void e_game_nowin(void)   { (void)rt_game_box(rt_int(0), rt_int(0), rt_int(1), rt_int(1)); }
#define E_GAME_MSG "游戏引擎需要 SDL2"
#endif

typedef struct {
    const char *name;
    void (*fn)(void);
    const char *msg;   /* 期望出现在 stderr 里的片段 */
} ErrCase;

static const ErrCase g_errtab[] = {
    { "add 溢出",            e_add_ovf,       "溢出" },
    { "sub 溢出",            e_sub_ovf,       "溢出" },
    { "mul 溢出",            e_mul_ovf,       "溢出" },
    { "div 除以零",          e_div_zero,      "除以零" },
    { "div 浮点除以零",      e_div_fzero,     "除以零" },
    { "fdiv 除以零",         e_fdiv_zero,     "除以零" },
    { "fdiv LLONG_MIN//-1",  e_fdiv_ovf,      "溢出" },
    { "mod 除以零",          e_mod_zero,      "除以零" },
    { "neg -LLONG_MIN 溢出", e_neg_ovf,       "溢出" },
    { "add 类型不匹配",      e_add_type,      "类型不可相加" },
    { "neg 类型不匹配",      e_neg_type,      "负号只能用于数字" },
    { "< 类型不匹配",        e_cmp_type,      "类型不可比较" },
    { "锁定后赋值",          e_locked_assign, "变量已锁定" },
    { "锁定后 push",         e_locked_push,   "变量已锁定" },
    { "删除后读取",          e_del_read,      "用已删除变量" },
    { "删除后赋值",          e_del_assign,    "用已删除变量" },
    { "下标越界",            e_index_oob,     "下标越界" },
    { "属性不存在",          e_prop_missing,  "属性 '身高' 不存在" },
    { "内存模式未实现",      e_memmode,       "内存管理模式不支持" },
    { "未知样式",            e_magic_bad,     "不支持的样式 x1" },
    { "长度类型不匹配",      e_len_type,      "长度 只能用于列表或字符串" },
    { "sqrt 负数",           e_sqrt_neg,      "负数" },
    { "网页未 begin",        e_page_nobegin,  "请先调用" },
    { "游戏未开窗",          e_game_nowin,    E_GAME_MSG },
};

/* 报错分支验证：拉起自身 "err N"，确认退出码 1 且 stderr 带对应消息 */
static void expect_die(const char *argv0, int idx)
{
    char exe[512], cmd[1200], err[1024];
    snprintf(exe, sizeof exe, "%s", (argv0 && *argv0) ? argv0 : "rt_test.exe");
    for (char *p = exe; *p; p++)
        if (*p == '/')
            *p = '\\';   /* system() 走 cmd.exe，需要 Windows 路径分隔符 */
    snprintf(cmd, sizeof cmd, "\"%s\" err %d 2>._rt_err.tmp", exe, idx);
    fflush(stdout);
    fflush(stderr);
    int rc = system(cmd);
    size_t n = 0;
    FILE *fp = fopen("._rt_err.tmp", "rb");
    if (fp) {
        n = fread(err, 1, sizeof err - 1, fp);
        fclose(fp);
    }
    err[n] = '\0';
    remove("._rt_err.tmp");
    const ErrCase *c = &g_errtab[idx];
    if (rc == 1 && strstr(err, "运行时错误: ") != NULL && strstr(err, c->msg) != NULL) {
        g_pass++;
        printf("[通过] 报错：%s\n", c->name);
    } else {
        g_fails++;
        printf("[失败] 报错：%s（退出码 %d，stderr=%.120s）\n", c->name, rc, err);
    }
}

/* ---- SDL 图形演示（rt_test.exe game 时进入；默认自测不开窗口） ---- */

#if RT_HAVE_SDL
static int game_demo(void)
{
    rt_game_win(rt_int(320), rt_int(240), "PYbook 游戏自测");
    int frame;
    for (frame = 0; frame < 120; frame++) {
        if (rt_cond(rt_game_end()))
            break;
        rt_game_clear(rt_int(30), rt_int(30), rt_int(60));
        rt_game_color(rt_int(0), rt_int(255), rt_int(0));
        rt_game_box(rt_int(frame * 2), rt_int(100), rt_int(40), rt_int(40));
        rt_game_color(rt_int(255), rt_int(200), rt_int(0));
        rt_game_dot(rt_int(160), rt_int(120));
        rt_game_line(rt_int(0), rt_int(0), rt_int(319), rt_int(239));
        rt_game_show();
        if (rt_cond(rt_game_key("esc")))
            break;
        rt_game_frame();
    }
    printf("游戏演示：跑了 %d 帧，end=%d hit(space)=%d key(z)=%d\n",
           frame, (int)rt_to_ll(rt_game_end()),
           (int)rt_to_ll(rt_game_hit("space")), (int)rt_to_ll(rt_game_key("z")));
    rt_game_bye();
    return 0;
}
#else
static int game_demo(void)
{
    printf("本构建未启用 SDL2（缺 -Iucrt64/include），无法跑图形演示\n");
    return 0;
}
#endif

int main(int argc, char **argv)
{
    /* ---- 子进程模式：跑指定报错用例，必然 exit(1) ---- */
    if (argc >= 3 && strcmp(argv[1], "err") == 0) {
        int k = atoi(argv[2]);
        if (k < 0 || k >= (int)(sizeof g_errtab / sizeof g_errtab[0]))
            return 9;
        g_errtab[k].fn();
        printf("子进程没有触发错误：%s\n", g_errtab[k].name);
        return 9;
    }
    /* ---- SDL 图形演示模式 ---- */
    if (argc >= 2 && strcmp(argv[1], "game") == 0)
        return game_demo();

    /* ================= 构造 / 取值往返 ================= */
    {
        Value v = rt_int(42);
        check(is_i(v, 42) && RT_TYPE(v) == 1, "构造：int 42 往返");
        v = rt_int(-42);
        check(is_i(v, -42), "构造：负 int 往返");
        v = rt_int(RT_INT_FAST_MAX);
        check(IS_INT(v) && rt_to_ll(v) == RT_INT_FAST_MAX, "构造：快路径上界 2^47-1 仍是 INT");
        v = rt_int(RT_INT_FAST_MAX + 1);
        check(IS_BIGINT(v) && RT_TYPE(v) == 3 && rt_to_ll(v) == RT_INT_FAST_MAX + 1,
              "构造：2^47 自动转 BIGINT 且值保真");
        v = rt_int(LLONG_MAX);
        check(IS_BIGINT(v) && rt_to_ll(v) == LLONG_MAX, "构造：LLONG_MAX 走 BIGINT 保真");
        v = rt_int(LLONG_MIN);
        check(IS_BIGINT(v) && rt_to_ll(v) == LLONG_MIN, "构造：LLONG_MIN 走 BIGINT 保真");
        v = rt_float(3.14);
        check(IS_FLT(v) && !RT_IS_BOX(v) && AS_FLT(v) == 3.14, "构造：float 原始位样直接存（不装箱）");
        check(v != RT_DELETED_BOX && !IS_DEL(v), "构造：float 不与 DELETED 位样混淆");
        check(is_f(rt_float(0.0), 0.0) && IS_FLT(rt_float(0.0)), "构造：0.0 是浮点");
        check(IS_FLT(rt_float(1.0 / 0.0)) && AS_FLT(rt_float(1.0 / 0.0)) > 0, "构造：+Inf 仍是浮点");
        Value nan = rt_float(0.0 / 0.0);
        check(IS_FLT(nan) && isnan(AS_FLT(nan)) && rt_cond(nan) == 1,
              "构造：NaN 规范化（不被误判成装箱值，真值同 Python 的真）");
        check(is_b(rt_bool(1), 1) && is_b(rt_bool(0), 0) && is_b(rt_bool(7), 1), "构造：bool 非 0 即真");
        v = rt_str("你好");
        check(is_s(v, "你好") && RT_TYPE(v) == 4, "构造：str malloc 拷贝");
        check(AS_STR(rt_str("x")) != AS_STR(rt_str("x")), "构造：str 各自独立拷贝");
        check(IS_NONE(rt_none()) && RT_TYPE(rt_none()) == 0 && rt_none() == RT_NIL_BOX,
              "构造：none 是 canonical 空盒");
        check(rt_to_ll(rt_bool(1)) == 1 && rt_to_ll(rt_int(9)) == 9,
              "构造：rt_to_ll 统一出口（INT/BOOL）");
    }

    /* ================= 算术 ================= */
    {
        check(is_i(rt_add(rt_int(2), rt_int(3)), 5), "算术：2+3=5");
        check(is_i(rt_add(rt_bool(1), rt_bool(1)), 2), "算术：true+true=2（bool 按数值）");
        check(is_f(rt_add(rt_int(1), rt_float(2.5)), 3.5), "算术：int+float=float");
        check(is_s(rt_add(rt_str("你好"), rt_str("！")), "你好！"), "算术：str+str 拼接");
        check(is_f(rt_div(rt_int(7), rt_int(2)), 3.5), "算术：7/2=3.5（真除法一律 float）");
        check(is_i(rt_fdiv(rt_int(7), rt_int(2)), 3), "算术：7//2=3");
        check(is_i(rt_fdiv(rt_int(-7), rt_int(2)), -4), "算术：-7//2=-4（Python 向下取整）");
        check(is_i(rt_fdiv(rt_int(7), rt_int(-2)), -4), "算术：7//-2=-4（Python 向下取整）");
        check(is_f(rt_fdiv(rt_float(-7.0), rt_float(2.0)), -4.0), "算术：浮点 // 向下取整");
        check(is_i(rt_mod(rt_int(7), rt_int(3)), 1), "算术：7%3=1");
        check(is_i(rt_mod(rt_int(-7), rt_int(3)), 2), "算术：-7%3=2（符号跟除数）");
        check(is_i(rt_mod(rt_int(7), rt_int(-3)), -2), "算术：7%-3=-2（符号跟除数）");
        check(is_i(rt_mod(rt_int(LLONG_MIN), rt_int(-1)), 0), "算术：LLONG_MIN%-1=0（避开 C 未定义）");
        check(is_f(rt_mod(rt_float(-7.5), rt_float(2.0)), 0.5), "算术：浮点取模符号跟除数");
        check(is_i(rt_neg(rt_int(-5)), 5), "算术：负号");
        check(is_f(rt_neg(rt_float(2.5)), -2.5), "算术：浮点负号");
        check(is_b(rt_not(rt_int(0)), 1) && is_b(rt_not(rt_str("a")), 0), "算术：逻辑非");
        /* 超快路径的加法自动升级 BIGINT：2^46 + 2^46 = 2^47 */
        Value big = rt_add(rt_int(RT_INT_FAST_MAX - 1), rt_int(3));
        check(IS_BIGINT(big) && rt_to_ll(big) == RT_INT_FAST_MAX + 2,
              "算术：快路径溢出结果自动转 BIGINT 保真");
    }

    /* ================= 比较 ================= */
    {
        check(is_b(rt_eq(rt_int(1), rt_int(1)), 1), "比较：1==1");
        check(is_b(rt_eq(rt_int(1), rt_float(1.0)), 1), "比较：1==1.0（跨类型数值）");
        check(is_b(rt_eq(rt_bool(1), rt_int(1)), 1), "比较：true==1");
        check(is_b(rt_eq(rt_str("a"), rt_str("a")), 1), "比较：\"a\"==\"a\"");
        check(is_b(rt_eq(rt_int(1), rt_str("1")), 0), "比较：1==\"1\" 为假且不报错");
        check(is_b(rt_ne(rt_int(1), rt_int(2)), 1), "比较：1!=2");
        check(is_b(rt_eq(rt_none(), rt_none()), 1), "比较：空盒==空盒");
        Value l1 = rt_list_new(), l2 = rt_list_new();
        rt_push(&l1, rt_int(1));
        rt_push(&l1, rt_str("x"));
        rt_push(&l2, rt_int(1));
        rt_push(&l2, rt_str("x"));
        check(is_b(rt_eq(l1, l2), 1), "比较：列表深度相等");
        rt_push(&l2, rt_int(2));
        check(is_b(rt_eq(l1, l2), 0), "比较：长度不同判不等");
        Value o1 = rt_obj_new("猫"), o2 = rt_obj_new("猫");
        check(is_b(rt_eq(o1, o1), 1) && is_b(rt_eq(o1, o2), 0), "比较：对象按指针身份");
        check(is_b(rt_lt(rt_int(1), rt_int(2)), 1) && is_b(rt_lt(rt_int(2), rt_int(1)), 0),
              "比较：1<2");
        check(is_b(rt_lt(rt_str("a"), rt_str("b")), 1), "比较：\"a\"<\"b\" 字典序");
        check(is_b(rt_le(rt_int(1), rt_float(1.0)), 1) && is_b(rt_ge(rt_int(2), rt_float(1.5)), 1),
              "比较：<= >= 跨类型数值");
    }

    /* ================= 真值（五个假值） ================= */
    {
        check(rt_cond(rt_none()) == 0, "真值：空盒为假");
        check(rt_cond(rt_int(0)) == 0, "真值：0 为假");
        check(rt_cond(rt_float(0.0)) == 0, "真值：0.0 为假");
        check(rt_cond(rt_str("")) == 0, "真值：\"\" 为假");
        check(rt_cond(rt_bool(0)) == 0, "真值：false 为假");
        check(rt_cond(rt_int(-1)) && rt_cond(rt_float(0.5)) && rt_cond(rt_str("0")) &&
              rt_cond(rt_bool(1)), "真值：非零数字/非空串为真");
        Value lst = rt_list_new();
        check(rt_cond(lst) == 0, "真值：空列表为假");
        rt_push(&lst, rt_int(1));
        check(rt_cond(lst) == 1, "真值：非空列表为真");
        check(rt_cond(rt_obj_new("X")) == 1, "真值：对象恒真");
    }

    /* ================= 显示（rt_str_of / show / input） ================= */
    {
        char *t = rt_str_of(rt_int(-42));
        check(strcmp(t, "-42") == 0, "显示：int 十进制");
        t = rt_str_of(rt_float(3.5));
        check(strcmp(t, "3.5") == 0, "显示：float %.15g 去尾零");
        t = rt_str_of(rt_float(0.1 + 0.2));
        check(strcmp(t, "0.3") == 0, "显示：0.1+0.2 显示 0.3");
        t = rt_str_of(rt_bool(1));
        check(strcmp(t, "true") == 0, "显示：true");
        t = rt_str_of(rt_none());
        check(strcmp(t, "空") == 0, "显示：none 显示\"空\"");
        t = rt_str_of(rt_str("abc"));
        check(strcmp(t, "abc") == 0, "显示：str 原样");
        Value lst = rt_list_new();
        rt_push(&lst, rt_int(1));
        rt_push(&lst, rt_str("a"));
        rt_push(&lst, rt_bool(1));
        t = rt_str_of(lst);
        check(strcmp(t, "[1, a, true]") == 0, "显示：列表深度展开");
        Value nest = rt_list_new();
        rt_push(&nest, rt_int(2));
        rt_push(&nest, rt_int(3));
        Value outer = rt_list_new();
        rt_push(&outer, rt_int(1));
        rt_push(&outer, nest);
        t = rt_str_of(outer);
        check(strcmp(t, "[1, [2, 3]]") == 0, "显示：嵌套列表");
        t = rt_str_of(rt_obj_new("狗"));
        check(strcmp(t, "[狗 对象]") == 0, "显示：对象");
        /* show_value 原样返回该值（行缓冲随后由 show_end 收尾，不留残段） */
        char got1[64];
        capture_start();
        int shown = rt_cond(rt_show_value(rt_int(1)));
        rt_show_end();
        capture_finish(got1, sizeof got1);
        check(shown == 1 && strcmp(got1, "1\n") == 0, "显示：show_value 原样返回该值");

        /* show 行缓冲 + magic：普通行不带重置序列，magic 行带 */
        char got[512];
        capture_start();
        rt_show_value(rt_int(42));
        rt_show_end();
        capture_finish(got, sizeof got);
        check(strcmp(got, "42\n") == 0, "显示：普通行不加 \\033[0m（按规范只输出换行）");

        capture_start();
        rt_magic("b,c=255,0,0");
        rt_show_text("hi");
        rt_show_end();
        capture_finish(got, sizeof got);
        check(strcmp(got, "\033[1m\033[38;2;255;0;0mhi\033[0m\n") == 0,
              "显示：magic(b,c=) 输出转义序列并在行尾重置");

        capture_start();
        rt_magic("");
        rt_show_end();
        capture_finish(got, sizeof got);
        check(strcmp(got, "\033[0m\n") == 0, "显示：空 magic 也算用过（行尾重置）");

        capture_start();
        rt_magic("f.宋体,fs.16,bk=0,0,0");
        rt_show_text("字");
        rt_show_end();
        capture_finish(got, sizeof got);
        check(strcmp(got, "\033[48;2;0;0;0m字\033[0m\n") == 0,
              "显示：f./fs. 在终端接受并忽略，bk= 生效");

        /* 右对齐：COLUMNS=20，可见宽度 2 → 补 18 空格 */
        _putenv("COLUMNS=20");
        capture_start();
        rt_magic("fr");
        rt_show_text("ab");
        rt_show_end();
        capture_finish(got, sizeof got);
        check(strcmp(got, "                  ab\033[0m\n") == 0, "显示：fr 右对齐按 COLUMNS 补空格");

        /* 居中对齐（沿用 COLUMNS=20：可见宽度 2 → 左补 9 空格） */
        capture_start();
        rt_magic("fm");
        rt_show_text("ab");
        rt_show_end();
        capture_finish(got, sizeof got);
        check(strcmp(got, "         ab\033[0m\n") == 0, "显示：fm 居中");
        _putenv("COLUMNS=80");
    }

    /* ================= 输入 ================= */
    {
        FILE *in = fopen("_rt_in.tmp", "wb");
        if (in) {
            fputs("42\n  -7 \n3.5\nabc 12\n", in);
            fclose(in);
        }
        char got[256];
        capture_start();
        freopen("_rt_in.tmp", "r", stdin);
        Value a = rt_input("n?");
        Value b = rt_input("");
        Value c = rt_input("f?");
        Value d = rt_input("s?");
        capture_finish(got, sizeof got);
        check(is_i(a, 42) && is_i(b, -7), "输入：整行数字按 int（含首尾空白）");
        check(is_f(c, 3.5), "输入：小数按 float");
        check(is_s(d, "abc 12"), "输入：非数字整行按字符串（保留原样）");
        check(strcmp(got, "n?f?s?") == 0, "输入：提示符输出、空提示符不输出");
        freopen("CONIN$", "r", stdin);   /* 还原控制台 stdin，释放临时文件 */
        remove("_rt_in.tmp");
    }

    /* ================= 容器（列表） ================= */
    {
        Value lst = rt_list_new();
        check(IS_LIST(lst) && is_i(rt_len(lst), 0), "列表：新建为空");
        for (int i = 1; i <= 10; i++)
            rt_push(&lst, rt_int(i));
        check(is_i(rt_len(lst), 10), "列表：push 自动扩容到 10 个");
        check(is_i(rt_index(lst, rt_int(0)), 1) && is_i(rt_index(lst, rt_int(9)), 10),
              "列表：下标读");
        check(is_i(rt_index(lst, rt_int(-1)), 10), "列表：负下标从尾数");
        rt_setindex(&lst, rt_int(4), rt_int(99));
        check(is_i(rt_index(lst, rt_int(4)), 99), "列表：下标写");
        check(is_s(rt_index(rt_str("你好a"), rt_int(1)), "好"), "列表：字符串按 UTF-8 字符取");
        check(is_i(rt_len(rt_str("中文ab")), 4), "列表：字符串长度按 UTF-8 字符");

        Value nums = rt_list_new();
        rt_push(&nums, rt_int(3));
        rt_push(&nums, rt_int(1));
        rt_push(&nums, rt_float(2.5));
        rt_push(&nums, rt_int(2));
        rt_list_sort(nums);
        check(is_i(rt_index(nums, rt_int(0)), 1) && is_i(rt_index(nums, rt_int(1)), 2) &&
              is_f(rt_index(nums, rt_int(2)), 2.5) && is_i(rt_index(nums, rt_int(3)), 3),
              "列表：sort 数字混型按值（原地，元素类型保留）");
        Value strs = rt_list_new();
        rt_push(&strs, rt_str("梨"));
        rt_push(&strs, rt_str("苹果"));
        rt_push(&strs, rt_str("白"));
        rt_list_sort(strs);
        /* 字典序 = UTF-8 字节序：梨(E6..) < 白(E7..) < 苹果(E8..) */
        check(is_s(rt_index(strs, rt_int(0)), "梨") && is_s(rt_index(strs, rt_int(2)), "苹果"),
              "列表：sort 字符串按字典序（UTF-8 字节序）");
        rt_list_reverse(nums);
        check(is_i(rt_index(nums, rt_int(0)), 3) && is_i(rt_index(nums, rt_int(3)), 1),
              "列表：reverse 原地倒序");

        Value dup = rt_list_new();
        rt_push(&dup, rt_int(1));
        rt_push(&dup, rt_int(1));
        rt_push(&dup, rt_str("a"));
        rt_push(&dup, rt_int(1));
        rt_push(&dup, rt_str("a"));
        Value uniq = rt_list_unique(dup);
        check(is_i(rt_len(uniq), 2) && is_i(rt_index(uniq, rt_int(0)), 1) &&
              is_s(rt_index(uniq, rt_int(1)), "a"),
              "列表：unique 深度判重保留首现");
        Value inner1 = rt_list_new(), inner2 = rt_list_new();
        rt_push(&inner1, rt_int(9));
        rt_push(&inner2, rt_int(9));
        Value dl = rt_list_new();
        rt_push(&dl, inner1);
        rt_push(&dl, inner2);
        rt_push(&dl, rt_int(7));
        check(is_i(rt_len(rt_list_unique(dl)), 2), "列表：unique 嵌套列表深度相等");

        Value m1 = rt_list_new(), m2 = rt_list_new();
        rt_push(&m1, rt_int(1));
        rt_push(&m1, rt_int(2));
        rt_push(&m2, rt_int(3));
        Value merged = rt_list_merge(m1, m2);
        check(is_i(rt_len(merged), 3) && is_i(rt_index(merged, rt_int(2)), 3),
              "列表：merge 先 a 后 b");

        check(is_i(rt_list_find(merged, rt_int(3)), 2) &&
              is_i(rt_list_find(merged, rt_int(9)), -1),
              "列表：find 命中/找不到 -1");
        check(is_i(rt_list_find(dl, inner2), 0), "列表：find 按深度相等匹配嵌套列表");

        check(is_i(rt_list_max(nums), 3) && is_i(rt_list_min(nums), 1),
              "列表：max/min 数字混型（返回原元素）");
        Value ss = rt_list_new();
        rt_push(&ss, rt_str("梨"));
        rt_push(&ss, rt_str("苹果"));
        check(is_s(rt_list_max(ss), "苹果"), "列表：max 字符串按字典序");
    }

    /* ================= 对象 ================= */
    {
        Value o = rt_obj_new("猫");
        rt_obj_set_prop(o, "名", rt_str("旺财"));
        rt_obj_set_prop(o, "岁", rt_int(2));
        check(is_s(rt_obj_get_prop(o, "名"), "旺财"), "对象：属性读写");
        rt_obj_set_prop(o, "名", rt_str("咪咪"));
        check(is_s(rt_obj_get_prop(o, "名"), "咪咪"), "对象：已有属性覆盖");
        check(strcmp(rt_obj_class_name(o), "猫") == 0, "对象：类名");
        check(is_i(rt_obj_get_prop(o, "岁"), 2), "对象：第二个属性完好");
        /* 引用语义：同一对象两个名字 */
        Value alias = o;
        rt_obj_set_prop(alias, "岁", rt_int(3));
        check(is_i(rt_obj_get_prop(o, "岁"), 3), "对象：引用语义（别名共享）");
    }

    /* ================= 锁定 / 删除（正常路径） ================= */
    {
        Value x = rt_int(1);
        rt_gold(&x);
        check(is_i(rt_chk(x), 1), "锁定：锁定后读取不受影响");
        check(slot_is_locked(&x), "锁定：槽已登记侧表");
        rt_gold(&x);   /* 重复锁定应幂等 */
        check(g_nlocks >= 1, "锁定：重复 gold 幂等");

        Value y = rt_int(7);
        Value copy = y;
        rt_destroy(&y);
        check(IS_DEL(y) && RT_TYPE(y) == 7, "删除：槽改写为 DELETED 位样");
        check(is_i(copy, 7), "删除：删除前拷走的旧拷贝不受影响");
        check(is_i(rt_chk(copy), 7), "删除：旧拷贝仍可正常使用");

        /* @self 模式真释放 + 别名登记表不 double-free */
        rt_set_memmode(1);
        Value s = rt_str("手动管理的字符串");
        Value alias = s;
        rt_destroy(&s);
        rt_destroy(&alias);   /* 同一块内存的第二次 delete：登记表命中，只标记 */
        check(IS_DEL(s) && IS_DEL(alias), "删除：@self 别名二次 delete 不崩溃");
        Value lst = rt_list_new();
        rt_push(&lst, rt_str("元素"));
        rt_destroy(&lst);     /* 释放列表结构 + items 数组 */
        check(IS_DEL(lst), "删除：@self 列表释放");
        rt_set_memmode(0);

        /* ---- @3 引用计数：归零即回收；容器持有元素不被回收 ---- */
        rt_set_memmode(3);
        {
            size_t b = rt_mem_stats(NULL);
            Value a = rt_str("引用计数");
            check(rt_mem_stats(NULL) == b + 1, "@3：新串登记为 1 个单元");
            rt_release(a);                    /* 交出构造时的那份引用 */
            check(rt_mem_stats(NULL) == b, "@3：引用归零立即回收");

            Value lst2 = rt_list_new();
            Value e = rt_str("元素");
            rt_push(&lst2, e);                /* 列表持有 → 元素 +1 */
            rt_release(e);                    /* 交出构造那份，列表仍持有 */
            check(rt_mem_stats(NULL) == b + 2, "@3：列表持有元素，元素不被回收");
            rt_release(lst2);                 /* 列表回收 → 连带释放元素 */
            check(rt_mem_stats(NULL) == b, "@3：列表回收时连带释放其元素");
        }
        rt_set_memmode(0);

        /* ---- @4 竞技场：整块分配、整块归还 ---- */
        rt_set_memmode(4);
        {
            size_t b = rt_mem_stats(NULL);
            for (int i = 0; i < 100; i++) {
                Value t = rt_str("竞技场");
                (void)t;
            }
            check(rt_mem_stats(NULL) == b + 100, "@4：竞技场分配 100 个单元");
            rt_arena_reset();
            check(rt_mem_stats(NULL) == b, "@4：整块归还后块内单元全部消失");
        }
        rt_set_memmode(0);

        /* ---- @5 标记清除：回收不可达、保留可达 ---- */
        rt_set_memmode(5);
        {
            Value root = rt_none();
            rt_scope_enter();
            rt_root_add(&root);
            rt_gc();                          /* 先归一化：清掉此前遗留的不可达单元 */
            size_t b = rt_mem_stats(NULL);
            for (int i = 0; i < 50; i++) {
                Value g = rt_str("不可达");
                (void)g;                      /* 没登记为根 → 垃圾 */
            }
            check(rt_mem_stats(NULL) == b + 50, "@5：50 个不可达对象已分配");
            rt_gc();
            check(rt_mem_stats(NULL) == b, "@5：GC 回收全部不可达对象");
            rt_assign(&root, rt_str("可达"));
            rt_gc();
            check(rt_mem_stats(NULL) == b + 1, "@5：可达对象应被保留");
            rt_scope_leave();
        }
        rt_set_memmode(0);

        /* ---- @6 分代 + 增量：minor GC、晋升、写屏障 ---- */
        rt_set_memmode(6);
        {
            Value root = rt_none();
            Value lst3 = rt_none();
            rt_scope_enter();
            rt_root_add(&root);
            rt_root_add(&lst3);
            gc_minor();                       /* 先归一化：清掉此前遗留的年轻单元 */
            size_t b = rt_mem_stats(NULL);
            for (int i = 0; i < 20; i++) {
                Value g = rt_str("新生代垃圾");
                (void)g;
            }
            rt_assign(&root, rt_str("存活对象"));
            rt_assign(&lst3, rt_list_new());
            gc_minor();                       /* 只清新生代 */
            check(rt_mem_stats(NULL) == b + 2, "@6：minor GC 清掉新生代垃圾、保留根可达对象");
            check(cell_of(root)->gen == 1, "@6：存活对象晋升老年代");
            check(cell_of(lst3)->gen == 1, "@6：存活列表晋升老年代");

            /* 写屏障：老年代列表放进新生代对象，minor GC 不该把它收走 */
            Value y = rt_str("新生代元素");
            rt_push(&lst3, y);                /* old→young：触发写屏障 */
            gc_minor();
            check(rt_mem_stats(NULL) == b + 3, "@6：写屏障保住 old→young 引用");
            check(cell_of(rt_index(lst3, rt_int(0)))->kind == RTK_STR, "@6：该元素仍可读");

            check(rt_gc_step() == 0, "@6：空闲时增量步进无事可做");
            rt_scope_leave();
        }
        rt_set_memmode(0);
    }

    /* ================= @7 知命自适应：意图标签 + 相位门控 + tenure 路由 ================= */
    rt_set_memmode(7);
    {
        /* 归一化：先做一次 major，清掉此前遗留的不可达单元 */
        m7_collect(1);
        size_t b = rt_mem_stats(NULL);

        /* 四个不可达对象，分别打不同意图 */
        Value f  = rt_str("帧垃圾");   rt_intent_tag(f,  1);
        Value lv = rt_str("关卡垃圾"); rt_intent_tag(lv, 2);
        Value sh = rt_str("共享");     rt_intent_tag(sh, 3);
        Value gr = rt_str("图");       rt_intent_tag(gr, 4);
        Value un = rt_str("未标");     /* 无标签，intent=0 */
        check(rt_mem_stats(NULL) == b + 5, "@7：5 个不可达对象已分配");

        /* 相位内：rt_gc_poll 不回收（零停顿） */
        rt_gc_poll(); rt_gc_poll(); rt_gc_poll();
        check(rt_mem_stats(NULL) == b + 5, "@7：相位内 rt_gc_poll 绝不回收（零停顿）");

        /* 走完一个相位（到达相位边界 → minor）：收 帧(1)/关卡(2)/未标(0)，留 共享(3)/图(4) */
        for (int i = 0; i < M7_PHASE_STMTS + 2; i++) rt_gc_poll();
        check(rt_mem_stats(NULL) == b + 2, "@7：minor 回收 帧/关卡/未标，保留 共享/图（跨相位存活）");

        /* 再走 7 个相位 → 第 8 个为 major（每 8 相位一次 major）→ 共享/图 也被收 */
        for (int p = 0; p < 7; p++)
            for (int i = 0; i < M7_PHASE_STMTS + 2; i++) rt_gc_poll();
        check(rt_mem_stats(NULL) == b, "@7：major（每8相位）回收 共享/图，全部清空");

        /* 张量回收：mode7 下大量张量被回收，且其 dims/data 裸内存一并释放（不泄漏） */
        m7_collect(1);                       /* 再归一化 */
        size_t bt = rt_mem_stats(NULL);
        for (int i = 0; i < 2000; i++) {
            int d[2] = {3, 4};
            Value T = rt_tensor_new_p(2, d, TENSOR_F64);
            rt_intent_tag(T, 1);            /* 当帧对象，边界即收 */
            if (i % 500 == 0) {             /* 周期性跨相位，验证 tenure 路由 */
                for (int k = 0; k < M7_PHASE_STMTS + 2; k++) rt_gc_poll();
            }
        }
        for (int i = 0; i < M7_PHASE_STMTS + 2; i++) rt_gc_poll();  /* 收掉残余帧张量 */
        check(rt_mem_stats(NULL) == bt, "@7：2000 张量（帧意图）跨相位后全部回收，裸内存无泄漏");

        /* 手动 rt_gc() 在 @7 下做 major 全收 */
        Value keep = rt_str("长活"); rt_intent_tag(keep, 3);
        m7_collect(0);                      /* minor：共享应留 */
        check(rt_mem_stats(NULL) == bt + 1, "@7：minor 后共享对象仍存活（manual minor）");
        rt_gc();                            /* 手动 rt_gc → major */
        check(rt_mem_stats(NULL) == bt, "@7：手动 rt_gc() 做 major 全收");

        /* 升级加强①：压力自适应——大分配提前触发相位边界（不必等满 2000 语句） */
        m7_collect(1);
        g_m7_threshold = 256 * 1024;       /* 复位默认，测试确定 */
        {
            size_t bp = rt_mem_stats(NULL);
            int d[1] = { 1024 * 1024 };
            Value big = rt_tensor_new_p(1, d, TENSOR_F64);  /* ~8MB 未标，制造分配压力 */
            rt_intent_tag(big, 0);
            rt_gc_poll();                   /* 还没跨 2000 语句，但 bytes 远超阈值 → 立刻边界 */
            check(rt_mem_stats(NULL) == bp, "@7：压力自适应——大分配触发早期相位边界并回收未标垃圾");
        }

        /* 升级加强①：阈值随垃圾比例自调（高垃圾 → 阈值下调，收得更勤） */
        g_m7_threshold = 256 * 1024;
        {
            size_t t0 = g_m7_threshold;
            for (int i = 0; i < 50; i++) { Value g = rt_str("garbage"); rt_intent_tag(g, 0); }
            m7_collect(0);                  /* minor：50 个全是垃圾 → 比例约 100% */
            check(g_m7_threshold < t0, "@7：高垃圾比例后阈值下调（自适应更勤）");
        }

        /* 升级加强②：代际晋升——未标对象连活 K 次 minor 后自动升 共享(3) */
        m7_collect(1);
        {
            Value obj = rt_str("晋升候选");  /* intent=0 未标 */
            rt_root_add(&obj);              /* 注册为根 → 跨 minor 存活 */
            for (int p = 0; p < M7_PROMOTE_AFTER; p++)
                for (int i = 0; i < M7_PHASE_STMTS + 2; i++) rt_gc_poll();
            check(cell_of(obj)->intent == 3, "@7：未标对象连活 K 次 minor 后升为 共享(3)（代际晋升）");
            m7_collect(1);
        }

        /* 升级加强③：迁移安全屏障——策略迁移（晋级/复用）后引用仍有效，无悬垂 */
        {
            Value mv = rt_str("策略迁移对象");
            rt_root_add(&mv);
            void *p0 = (void *)cell_of(mv);          /* 记下引用地址 */
            /* 连跑多次 minor：对象跨相位存活、意图从 未标 晋级为 共享（策略迁移） */
            for (int p = 0; p < M7_PROMOTE_AFTER; p++)
                for (int i = 0; i < M7_PHASE_STMTS + 2; i++) rt_gc_poll();
            void *p1 = (void *)cell_of(mv);          /* 迁移后再次取地址 */
            check(p0 == p1, "@7：迁移安全屏障——晋级后引用地址不变（无悬垂指针）");
            check(strcmp(rt_str_of(mv), "策略迁移对象") == 0,
                  "@7：迁移安全屏障——晋级后引用仍可正确读值");
            /* 槽位复用（角色重生式）：旧槽位覆盖成新对象，引用经屏障后有效可读 */
            rt_assign(&mv, rt_str("复用后的新对象"));
            rt_ref_barrier(&mv);                     /* 引用建立必经屏障 */
            check(strcmp(rt_str_of(mv), "复用后的新对象") == 0,
                  "@7：迁移安全屏障——槽位复用后引用有效可读（无野指针）");
            m7_collect(1);
        }
    }

    /* ============== 升级加强B：帧边界对齐引擎 ============== */
    {
        /* B1：rt_phase_end() 在帧/tick 末显式调用，立即触发相位边界回收
         *     —— GC 暂停只发生在帧间，绝不卡在帧内（真·帧内零停顿）。 */
        rt_scope_enter();
        m7_collect(1);
        size_t bf = rt_mem_stats(NULL);
        for (int i = 0; i < 50; i++) { Value g = rt_str("帧边界垃圾"); rt_intent_tag(g, 1); }
        check(rt_mem_stats(NULL) == bf + 50, "@7/B：帧意图垃圾已分配（制造帧内分配活动）");
        rt_phase_end();   /* 模拟引擎在帧末调用 */
        check(rt_mem_stats(NULL) == bf, "@7/B：rt_phase_end() 帧末立即回收帧意图垃圾（帧内零停顿）");

        /* B2：本帧没有任何分配活动（g_m7_stmts/g_m7_alloc 都为 0）则跳过，
         *     相位不前进、不空转回收。 */
        m7_collect(1);
        g_m7_stmts = 0;
        g_m7_alloc = 0;
        unsigned long ph0 = g_m7_phase;
        rt_phase_end();
        check(g_m7_phase == ph0, "@7/B：rt_phase_end 本帧无活动则跳过（相位不前进、不空转）");

        /* B3：smoke.frame_end() 走 rt_phase_end，同样触发帧末回收。 */
        m7_collect(1);
        size_t bf2 = rt_mem_stats(NULL);
        for (int i = 0; i < 30; i++) { Value g = rt_str("帧末垃圾"); rt_intent_tag(g, 1); }
        rt_smoke_frame_end();
        check(rt_mem_stats(NULL) == bf2, "@7/B：smoke.frame_end() 同样触发帧末回收");
        rt_scope_leave();
    }

    /* ============== 升级加强C：GC 可观测 ============== */
    {
        rt_scope_enter();
        /* 先制造一次带晋升的回收，让 promoted / pause_ms 取得非零值 */
        m7_collect(1);
        Value pobj = rt_str("可观测晋升候选");   /* intent=0 未标 */
        rt_root_add(&pobj);
        for (int p = 0; p < M7_PROMOTE_AFTER; p++)
            for (int i = 0; i < M7_PHASE_STMTS + 2; i++) rt_gc_poll();
        long long prom = 0; rt_q_gc_promoted(&prom);
        check(prom >= 1, "@7/C：rt_q_gc_promoted 记录代际晋升次数（promoted>=1）");
        long long pause = 0; rt_q_gc_lastpause(&pause);
        check(pause >= 0, "@7/C：rt_q_gc_lastpause 返回非负暂停时长（毫秒）");

        /* smoke.gc_stats 字典字段完整性 */
        m7_collect(1);
        Value d = rt_smoke_gc_stats();
        check(IS_DICT(d), "@7/C：smoke.gc_stats 返回 dict");
        check(is_i(rt_dict_get(d, rt_str("mode")), 7), "@7/C：gc_stats.mode==7（知命）");
        check(is_i(rt_dict_get(d, rt_str("promoted")), prom), "@7/C：gc_stats.promoted 与 rt_q_gc_promoted 一致");
        check(IS_INT(rt_dict_get(d, rt_str("live"))), "@7/C：gc_stats.live 字段为 int");
        check(IS_INT(rt_dict_get(d, rt_str("pause_ms"))), "@7/C：gc_stats.pause_ms 字段为 int");
        check(IS_INT(rt_dict_get(d, rt_str("intent_shared"))), "@7/C：gc_stats.intent_shared 字段为 int");
        check(IS_INT(rt_dict_get(d, rt_str("intent_frame"))), "@7/C：gc_stats.intent_frame 字段为 int");
        check(IS_INT(rt_dict_get(d, rt_str("intent_none"))), "@7/C：gc_stats.intent_none 字段为 int");
        check(IS_INT(rt_dict_get(d, rt_str("intent_level"))), "@7/C：gc_stats.intent_level 字段为 int");
        check(IS_INT(rt_dict_get(d, rt_str("intent_graph"))), "@7/C：gc_stats.intent_graph 字段为 int");
        rt_scope_leave();
    }

    rt_set_memmode(0);

    /* ================= 网页缓冲 ================= */
    {
        rt_page_begin("我的<页面>");
        rt_page_para_open("b,c=200,100,0");
        rt_page_text("分数：");
        rt_page_value(rt_int(42));
        rt_page_para_close();
        rt_page_para_open("");
        rt_page_text("5<6 & \"引号\"");
        rt_page_para_close();
        rt_page_h("标题", 1);
        rt_page_img("<猫>.png");
        rt_page_hr();
        rt_page_link("点>我", "a&b");
        check(g_page != NULL && strcmp(g_page,
              "<!DOCTYPE html>\n<html lang=\"zh\">\n<head>\n"
              "<meta charset=\"utf-8\">\n<title>我的&lt;页面&gt;</title>\n"
              "<style>\n"
              "body{background:#1e1e2e;color:#cdd6f4;"
              "font-family:\"Microsoft YaHei UI\",sans-serif;"
              "padding:40px;line-height:1.6}\n"
              "a{color:#89dceb}\n"
              "</style>\n</head>\n<body>\n"
              "<p style=\"font-weight:bold; color:rgb(200,100,0)\">\n"
              "分数：42</p>\n"
              "<p>\n"
              "5&lt;6 &amp; &quot;引号&quot;</p>\n"
              "<h1>标题</h1>\n"
              "<img src=\"&lt;猫&gt;.png\">\n"
              "<hr>\n"
              "<a href=\"a&amp;b\">点&gt;我</a>\n") == 0,
              "网页：骨架 + 样式翻译 + 全量 HTML 转义");
        rt_page_para_open("i,bk=0,0,0,fs.14,fm,f.楷体");
        check(strstr(g_page, "<p style=\"font-style:italic; background-color:rgb(0,0,0); "
                              "font-size:14px; text-align:center; font-family:'楷体'\">") != NULL,
              "网页：i/bk/fs/fm/f. 全套 token 翻译成 CSS");
        rt_page_para_close();
        rt_page_save();
        check(g_page_len == 0 && !g_page_begun, "网页：save 后缓冲清空可复用");
        /* 落盘内容 = 缓冲 + 骨架尾 */
        FILE *fp = fopen("pybook_page.html", "rb");
        int file_ok = 0;
        if (fp) {
            char buf[4096];
            size_t n = fread(buf, 1, sizeof buf - 1, fp);
            buf[n] = '\0';
            fclose(fp);
            file_ok = strcmp(buf,
                     "<!DOCTYPE html>\n<html lang=\"zh\">\n<head>\n"
                     "<meta charset=\"utf-8\">\n<title>我的&lt;页面&gt;</title>\n"
                     "<style>\n"
                     "body{background:#1e1e2e;color:#cdd6f4;"
                     "font-family:\"Microsoft YaHei UI\",sans-serif;"
                     "padding:40px;line-height:1.6}\n"
                     "a{color:#89dceb}\n"
                     "</style>\n</head>\n<body>\n"
                     "<p style=\"font-weight:bold; color:rgb(200,100,0)\">\n"
                     "分数：42</p>\n"
                     "<p>\n"
                     "5&lt;6 &amp; &quot;引号&quot;</p>\n"
                     "<h1>标题</h1>\n"
                     "<img src=\"&lt;猫&gt;.png\">\n"
                     "<hr>\n"
                     "<a href=\"a&amp;b\">点&gt;我</a>\n"
                     "<p style=\"font-style:italic; background-color:rgb(0,0,0); "
                     "font-size:14px; text-align:center; font-family:'楷体'\">\n"
                     "</p>\n"
                     "</body>\n</html>\n") == 0;
        }
        check(file_ok, "网页：save 落盘内容完整（UTF-8 二进制写）");
        remove("pybook_page.html");   /* 测试产物不留在工作区 */
    }

    /* ================= 随机（链接进来的 rd 模块） ================= */
    {
        int in_range = 1, saw_lo = 0, saw_hi = 0;
        for (int i = 0; i < 2000; i++) {
            Value r = rt_lib_rd_int(rt_int(3), rt_int(7));
            long long x = rt_to_ll(r);
            if (x < 3 || x > 7)
                in_range = 0;
            if (x == 3) saw_lo = 1;
            if (x == 7) saw_hi = 1;
        }
        check(in_range, "随机：2000 次 rd.int 都在 [3,7]");
        check(saw_lo && saw_hi, "随机：rd.int 含两端");
        Value rf = rt_lib_rd_float();
        check(IS_FLT(rf) && AS_FLT(rf) >= 0.0 && AS_FLT(rf) < 1.0, "随机：rd.float 在 [0,1)");
        Value pool = rt_list_new();
        rt_push(&pool, rt_int(10));
        rt_push(&pool, rt_int(20));
        int pick_ok = 1;
        for (int i = 0; i < 100; i++) {
            Value p = rt_lib_rd_pick(pool);
            if (!is_i(p, 10) && !is_i(p, 20))
                pick_ok = 0;
        }
        check(pick_ok, "随机：rd.pick 取自原列表");
        Value deck = rt_list_new();
        for (int i = 1; i <= 6; i++)
            rt_push(&deck, rt_int(i));
        rt_lib_rd_shuffle(deck);
        long long sum = 0;
        for (long long i = 0; i < 6; i++)
            sum += rt_to_ll(rt_index(deck, rt_int(i)));
        check(sum == 21, "随机：rd.shuffle 元素集合不变");
    }

    /* ================= 标准库冒烟（te/mt） ================= */
    {
        Value parts = rt_lib_te_split(rt_str("a,b,c"), rt_str(","));
        check(is_i(rt_len(parts), 3) && is_s(rt_index(parts, rt_int(2)), "c"), "te：split");
        check(is_f(rt_lib_mt_sqrt(rt_int(144)), 12.0), "mt：sqrt(144)=12");
        check(is_f(rt_lib_mt_pi(), 3.14159265358979), "mt：pi");
    }

    /* ================= 文件模块冒烟（file） ================= */
    {
        Value path = rt_str("_rt_file.tmp");
        rt_file_write(path, rt_str("第一行\n第二行"));
        check(rt_cond(rt_file_exists(path)) != 0, "file：写后存在");
        check(is_s(rt_file_read(path), "第一行\n第二行"), "file：读回原文");
        Value lines = rt_file_lines(path);
        check(is_i(rt_len(lines), 2) && is_s(rt_index(lines, rt_int(1)), "第二行"),
              "file：按行切分");
        rt_file_del(path);
        check(rt_cond(rt_file_exists(path)) == 0, "file：删除后不存在");
    }

    /* ================= 报错分支（子进程验证） ================= */
    {
        for (int i = 0; i < (int)(sizeof g_errtab / sizeof g_errtab[0]); i++)
            expect_die(argv[0], i);
    }

    printf("\n自测：通过 %d 项，失败 %d 项\n", g_pass, g_fails);
    if (g_fails == 0)
        printf("自测全部通过。\n");
    else
        printf("自测失败 %d 项！\n", g_fails);
    return g_fails ? 1 : 0;
}
#endif /* RT_SELF_TEST */

/* rm.around 循环辅助 */
long long rt_loop_count(Value v)
{
    if (IS_INT(v))
        return AS_INT(v);
    if (IS_BOOL(v))
        return AS_BOOL(v);
    if (IS_FLT(v)) {
        double f = AS_FLT(v);
        if (f == (long long)f)
            return (long long)f;
    }
    rt_die("rm.around 次数不是整数");
    return 0;
}

Value rt_at(long long i)
{
    return rt_int(i);
}

