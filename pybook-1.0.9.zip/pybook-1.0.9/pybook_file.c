/* PYbook 标准库：file 文件模块（UTF-8 读写）。
 *
 * 编码约定：文件内容一律按 UTF-8 字节读写（"rb"/"wb" 二进制模式，
 * 不做换行翻译；rt_file_lines 自行按 \n 切行并去掉行尾 \r）。
 * 路径是 UTF-8 字符串，经 MultiByteToWideChar 转 UTF-16 后走 _wfopen/
 * _wremove，中文路径不会因 ANSI 代码页而乱码。
 *
 * 函数清单（声明见 pybook_rt.h 的 file 模块段）：
 *   rt_file_read(路径)          → 读全部文本（字符串）
 *   rt_file_write(路径, 内容)   → 覆盖写（空盒）
 *   rt_file_add(路径, 内容)     → 追加写（空盒）
 *   rt_file_exists(路径)        → 存在？（真/假）
 *   rt_file_lines(路径)         → 按行读成列表（每行一个字符串）
 *   rt_file_del(路径)           → 删除文件（空盒）
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <windows.h>

#include "pybook_rt.h"

/* 运行时错误出口：格式与 pybook_rt 的 rt_die 一致 */
static void file_die(const char *fmt, ...)
{
    va_list ap;
    fprintf(stderr, "runtime error: ");
    va_start(ap, fmt);
    vfprintf(stderr, fmt, ap);
    va_end(ap);
    fputc(10, stderr);
    exit(1);
}

/* UTF-8 路径 → FILE*。mode 形如 "rb"/"wb"/"ab"。 */
static FILE *file_fopen(const char *path, const char *mode)
{
    wchar_t wpath[1024], wmode[8];
    if (!MultiByteToWideChar(CP_UTF8, 0, path ? path : "", -1,
                             wpath, (int)(sizeof wpath / sizeof wpath[0])))
        return NULL;
    if (!MultiByteToWideChar(CP_UTF8, 0, mode, -1,
                             wmode, (int)(sizeof wmode / sizeof wmode[0])))
        return NULL;
    return _wfopen(wpath, wmode);
}

/* UTF-8 路径 → 删除。成功返回 0。 */
static int file_remove(const char *path)
{
    wchar_t wpath[1024];
    if (!MultiByteToWideChar(CP_UTF8, 0, path ? path : "", -1,
                             wpath, (int)(sizeof wpath / sizeof wpath[0])))
        return -1;
    return _wremove(wpath);
}

static const char *file_str(Value v, const char *who)
{
    if (!IS_STR(v))
        file_die("%s 需要字符串", who);
    return AS_STR(v) ? AS_STR(v) : "";
}

/* 读整个文件到 malloc 缓冲（含 NUL）；失败/不存在 → NULL。 */
static char *file_slurp(const char *path, size_t *out_len)
{
    FILE *fp = file_fopen(path, "rb");
    char *buf;
    long sz;
    if (!fp)
        return NULL;
    if (fseek(fp, 0, SEEK_END) != 0 || (sz = ftell(fp)) < 0) {
        fclose(fp);
        return NULL;
    }
    rewind(fp);
    buf = (char *)malloc((size_t)sz + 1);
    if (!buf) {
        fclose(fp);
        file_die("内存不足");
    }
    if (sz > 0 && fread(buf, 1, (size_t)sz, fp) != (size_t)sz) {
        free(buf);
        fclose(fp);
        return NULL;
    }
    buf[sz] = '\0';
    fclose(fp);
    if (out_len)
        *out_len = (size_t)sz;
    return buf;
}

Value rt_file_read(Value path)
{
    const char *p = file_str(path, "file.read 的路径");
    char *buf = file_slurp(p, NULL);
    Value r;
    if (!buf)
        file_die("file.read：无法打开文件 %s", p);
    r = rt_str(buf);
    free(buf);          /* rt_str 内部会拷贝（见 rt_str 实现），缓冲可还 */
    return r;
}

static Value file_write_impl(Value path, Value content, const char *mode)
{
    const char *p = file_str(path, "file.write 的路径");
    const char *data = file_str(content, "file.write 的内容");
    FILE *fp = file_fopen(p, mode);
    size_t len = strlen(data);
    if (!fp)
        file_die("file.write：无法打开文件 %s", p);
    if (len > 0 && fwrite(data, 1, len, fp) != len)
        file_die("file.write：写入文件 %s 失败", p);
    fclose(fp);
    return rt_none();
}

Value rt_file_write(Value path, Value content)
{
    return file_write_impl(path, content, "wb");
}

Value rt_file_add(Value path, Value content)
{
    return file_write_impl(path, content, "ab");
}

Value rt_file_exists(Value path)
{
    const char *p = file_str(path, "file.exists 的路径");
    FILE *fp = file_fopen(p, "rb");
    if (fp)
        fclose(fp);
    return rt_bool(fp != NULL);
}

Value rt_file_lines(Value path)
{
    const char *p = file_str(path, "file.lines 的路径");
    size_t len = 0;
    char *buf = file_slurp(p, &len);
    Value lst = rt_list_new();
    size_t i = 0, start = 0;
    if (!buf)
        file_die("file.lines：无法打开文件 %s", p);
    if (len == 0) {
        free(buf);
        return lst;                    /* 空文件 → 空列表 */
    }
    while (i <= len) {
        if (i == len || buf[i] == '\n') {
            size_t end = i;
            Value line;
            char *one;
            if (end > start && buf[end - 1] == '\r')
                end--;                 /* 去掉 \r\n 的 \r */
            one = (char *)malloc(end - start + 1);
            if (!one)
                file_die("内存不足");
            memcpy(one, buf + start, end - start);
            one[end - start] = '\0';
            line = rt_str(one);
            free(one);
            rt_push(&lst, line);
            start = i + 1;
        }
        i++;
    }
    free(buf);
    return lst;
}

Value rt_file_del(Value path)
{
    const char *p = file_str(path, "file.del 的路径");
    if (file_remove(p) != 0)
        file_die("file.del：无法删除文件 %s", p);
    return rt_none();
}

/* ---------- 以下为 teamwork 库所需：size / list / split / join ---------- */

Value rt_file_size(Value path)
{
    const char *p = file_str(path, "file.size 的路径");
    FILE *fp = file_fopen(p, "rb");
    long sz;
    if (!fp)
        file_die("file.size：无法打开文件 %s", p);
    if (fseek(fp, 0, SEEK_END) != 0 || (sz = ftell(fp)) < 0) {
        fclose(fp);
        file_die("file.size：无法取得大小 %s", p);
    }
    fclose(fp);
    return rt_int(sz);
}

/* file.list(目录) → 列表的列表：[名字, 大小, "文件"|"目录"]，按名字排序 */
Value rt_file_list(Value dir)
{
    const char *p = file_str(dir, "file.list 的目录");
    wchar_t wdir[1024], pattern[1100];
    WIN32_FIND_DATAW fd;
    HANDLE h;
    Value lst = rt_list_new();

    if (!MultiByteToWideChar(CP_UTF8, 0, p ? p : "", -1,
                             wdir, (int)(sizeof wdir / sizeof wdir[0])))
        file_die("file.list：目录路径过长 %s", p);
    /* 去掉末尾反斜杠再拼 \* */
    {
        size_t n = wcslen(wdir);
        while (n > 0 && (wdir[n - 1] == L'\\' || wdir[n - 1] == L'/'))
            wdir[--n] = 0;
    }
    swprintf(pattern, sizeof pattern / sizeof pattern[0], L"%s\\*", wdir);
    h = FindFirstFileW(pattern, &fd);
    if (h == INVALID_HANDLE_VALUE)
        file_die("file.list：无法打开目录 %s", p);
    do {
        char name[1024];
        Value row;
        if (wcscmp(fd.cFileName, L".") == 0 || wcscmp(fd.cFileName, L"..") == 0)
            continue;
        if (!WideCharToMultiByte(CP_UTF8, 0, fd.cFileName, -1, name,
                                 (int)sizeof name, NULL, NULL))
            continue;
        row = rt_list_new();
        rt_push(&row, rt_str(name));
        if (fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) {
            rt_push(&row, rt_int(0));
            rt_push(&row, rt_str("目录"));
        } else {
            long long sz = ((long long)fd.nFileSizeHigh << 32) | fd.nFileSizeLow;
            rt_push(&row, rt_int((long long)sz));
            rt_push(&row, rt_str("文件"));
        }
        rt_push(&lst, row);
    } while (FindNextFileW(h, &fd));
    FindClose(h);
    return lst;
}

/* file.split(路径, 每卷字节数) → 分卷路径列表。命名：原名.partNN */
Value rt_file_split(Value path, Value chunk)
{
    const char *p = file_str(path, "file.split 的路径");
    long long csz;
    FILE *in, *out;
    char *buf;
    Value lst = rt_list_new();
    int idx = 0;
    size_t nread;

    if (IS_INT(chunk))
        csz = AS_INT(chunk);
    else if (IS_FLT(chunk))
        csz = (long long)AS_FLT(chunk);
    else
        file_die("file.split 的分块大小需要数字");
    if (csz <= 0)
        file_die("file.split 的分块大小必须 > 0");

    in = file_fopen(p, "rb");
    if (!in)
        file_die("file.split：无法打开文件 %s", p);
    buf = (char *)malloc((size_t)csz);
    if (!buf) {
        fclose(in);
        file_die("内存不足");
    }
    while ((nread = fread(buf, 1, (size_t)csz, in)) > 0) {
        char outpath[1200];
        snprintf(outpath, sizeof outpath, "%s.part%02d", p, idx);
        out = file_fopen(outpath, "wb");
        if (!out) {
            free(buf);
            fclose(in);
            file_die("file.split：无法创建分卷 %s", outpath);
        }
        if (fwrite(buf, 1, nread, out) != nread) {
            fclose(out);
            free(buf);
            fclose(in);
            file_die("file.split：写入分卷失败 %s", outpath);
        }
        fclose(out);
        rt_push(&lst, rt_str(outpath));
        idx++;
    }
    free(buf);
    fclose(in);
    return lst;
}

/* file.join(分卷列表, 输出路径) → 空盒 */
Value rt_file_join(Value parts, Value outp)
{
    const char *dst = file_str(outp, "file.join 的输出路径");
    FILE *out;
    Value n;
    long long i, cnt;

    if (!IS_LIST(parts))
        file_die("file.join 的分卷列表需要列表");
    out = file_fopen(dst, "wb");
    if (!out)
        file_die("file.join：无法创建输出 %s", dst);
    n = rt_len(parts);
    cnt = IS_INT(n) ? AS_INT(n) : 0;
    for (i = 0; i < cnt; i++) {
        Value item = rt_index(parts, rt_int(i));
        const char *pp;
        FILE *in;
        char buf[65536];
        size_t r;
        if (!IS_STR(item)) {
            fclose(out);
            file_die("file.join：第 %lld 个分卷不是字符串", (long long)i);
        }
        pp = AS_STR(item);
        in = file_fopen(pp, "rb");
        if (!in) {
            fclose(out);
            file_die("file.join：无法打开分卷 %s", pp);
        }
        while ((r = fread(buf, 1, sizeof buf, in)) > 0) {
            if (fwrite(buf, 1, r, out) != r) {
                fclose(in);
                fclose(out);
                file_die("file.join：写入输出失败 %s", dst);
            }
        }
        fclose(in);
    }
    fclose(out);
    return rt_none();
}
/* =============================================================================
 * 终端读行（te.读行 / te.试读行）
 *
 * 为什么要有这个：项目原先**没有任何终端输入能力**（file.* 只读写文件，te.* 是
 * 字符串工具，input() 会把数字行解析成整数）。要让两台机器在终端里对话，
 * 必须自己打 REPL 的地基 —— 读用户敲的一行。
 *
 * 两条路径（按 stdin 是不是控制台自动选）：
 *
 *   控制台：原始模式 + ReadConsoleInput
 *     - 关掉 ENABLE_LINE_INPUT / ENABLE_ECHO_INPUT，自己做回显与退格，
 *       这样才能做到「按一个键就立刻看到」并且在收到网络消息时能重画当前输入行；
 *     - 绝不能直接调 ReadConsoleInput：它在输入缓冲为空时**会阻塞**
 *       （实测空缓冲上阻塞了 78ms 才返回）。所以必须先用
 *       GetNumberOfConsoleInputEvents 问一句「有没有事件」，为 0 就不读。
 *       这道闸是「不阻塞」的全部保证。
 *
 *   管道 / 重定向文件：PeekNamedPipe + ReadFile
 *     - PeekNamedPipe 报告当前可读字节数，为 0 就是「暂时没有」，不阻塞；
 *     - 写端关闭时 PeekNamedPipe 报 ERROR_BROKEN_PIPE → 视为文件尾。
 *
 * 返回约定（与 net.recv 的「断」一致）：
 *   正常 → 该行文本（可能是空串）
 *   文件尾 → "断"
 *   te.试读行：暂时没有完整行 → ""
 *
 * 已知副作用：te.读行 / te.试读行 会把控制台切到原始模式，进程退出时恢复。
 *   同一脚本里不要再混用 input()（它按行读，和原始模式冲突）。
 * ========================================================================== */

#define TERM_LINE_MAX  4096
#define TERM_RAW_MAX   (TERM_LINE_MAX / 2)

typedef struct {
    int     inited;
    int     is_console;
    int     raw_set;            /* 我们改过控制台模式（退出时要还原） */
    DWORD   saved_mode;
    HANDLE  hin;
    wchar_t wbuf[TERM_RAW_MAX]; /* 控制台路径：当前行（UTF-16，代理对天然能拼） */
    int     wlen;
    wchar_t hi_surrogate;       /* 上一个高位代理，等低位代理拼成完整字符 */
    char    bbuf[TERM_LINE_MAX];/* 管道路径：字节缓冲 */
    int     blen;
    int     eof;
} TermState;

static TermState g_term;

/* 进程退出时把控制台模式还原回去 */
static void term_restore_mode(void)
{
    if (g_term.raw_set && g_term.hin != INVALID_HANDLE_VALUE) {
        SetConsoleMode(g_term.hin, g_term.saved_mode);
        g_term.raw_set = 0;
    }
}

static void term_init(void)
{
    HANDLE h;
    DWORD mode = 0;
    if (g_term.inited)
        return;
    g_term.inited = 1;
    h = GetStdHandle(STD_INPUT_HANDLE);
    if (h == INVALID_HANDLE_VALUE) {
        g_term.hin = INVALID_HANDLE_VALUE;
        g_term.is_console = 0;
        return;
    }
    g_term.hin = h;
    /* GetConsoleMode 只在真控制台句柄上成功；管道/文件会失败 → 走管道路径 */
    if (!GetConsoleMode(h, &mode)) {
        g_term.is_console = 0;
        return;
    }
    g_term.is_console = 1;
    g_term.saved_mode = mode;
    /* 原始模式：保留 PROCESSED_INPUT（Ctrl+C 仍然能中断程序），
       关掉 LINE_INPUT（不要控制台自己做行编辑）和 ECHO_INPUT（回显我们自己来，
       否则会和自己的回显叠加成双份字符）。 */
    {
        DWORD raw = mode & ~(ENABLE_LINE_INPUT | ENABLE_ECHO_INPUT);
        if (SetConsoleMode(h, raw))
            g_term.raw_set = 1;
        atexit(term_restore_mode);
    }
}

/* 把一个 UTF-16 码元写成 UTF-8 字节并输出（回显用） */
static void term_echo_wchar(WCHAR ch)
{
    char buf[8];
    int n = WideCharToMultiByte(CP_UTF8, 0, &ch, 1, buf, (int)sizeof buf, NULL, NULL);
    if (n > 0) {
        fwrite(buf, 1, (size_t)n, stdout);
        fflush(stdout);
    }
}

/* 控制台路径：非阻塞取一行。返回 1=取到，0=还没有，-1=输入结束 */
static int term_poll_console(char *out, int cap)
{
    INPUT_RECORD recs[128];
    DWORD n = 0, count = 0;
    DWORD i;
    int got = 0;

    for (;;) {
        /* 这道闸是关键：事件数为 0 就**不要**调 ReadConsoleInput（它会阻塞） */
        if (!GetNumberOfConsoleInputEvents(g_term.hin, &count) || count == 0)
            break;
        if (count > 128)
            count = 128;
        if (!ReadConsoleInput(g_term.hin, recs, count, &n) || n == 0)
            break;
        for (i = 0; i < n && !got; i++) {
            WCHAR ch;
            WORD vk;
            if (recs[i].EventType != KEY_EVENT)
                continue;
            if (!recs[i].Event.KeyEvent.bKeyDown)
                continue;               /* keyup 忽略 */
            ch = recs[i].Event.KeyEvent.uChar.UnicodeChar;
            vk = recs[i].Event.KeyEvent.wVirtualKeyCode;
            if (vk == VK_RETURN || ch == '\r' || ch == '\n') {
                int bytes = WideCharToMultiByte(CP_UTF8, 0, g_term.wbuf, g_term.wlen,
                                                out, cap - 1, NULL, NULL);
                if (bytes < 0)
                    bytes = 0;
                out[bytes] = '\0';
                g_term.wlen = 0;
                g_term.hi_surrogate = 0;
                got = 1;
                break;
            }
            if (vk == VK_BACK || ch == '\b') {
                if (g_term.wlen > 0)
                    g_term.wlen--;
                fwrite("\b \b", 1, 3, stdout);
                fflush(stdout);
                continue;
            }
            if (ch == 0x15) {           /* Ctrl+U：清空当前行 */
                while (g_term.wlen > 0) {
                    g_term.wlen--;
                    fwrite("\b \b", 1, 3, stdout);
                }
                fflush(stdout);
                continue;
            }
            if (ch < 0x20 || ch == 0x7F)
                continue;               /* 其余控制字符：忽略 */
            /* 代理对：高位先存着，等低位来了再一起回显 */
            if (ch >= 0xD800 && ch <= 0xDBFF) {
                g_term.hi_surrogate = ch;
                if (g_term.wlen < TERM_RAW_MAX)
                    g_term.wbuf[g_term.wlen++] = ch;
                continue;
            }
            if (g_term.hi_surrogate) {
                term_echo_wchar(g_term.hi_surrogate);
                g_term.hi_surrogate = 0;
            }
            if (g_term.wlen < TERM_RAW_MAX)
                g_term.wbuf[g_term.wlen++] = ch;
            term_echo_wchar(ch);
        }
        if (got)
            break;
    }
    return got;
}

/* 管道路径：非阻塞取一行。返回 1=取到，0=还没有，-1=文件尾 */
static int term_poll_pipe(char *out, int cap)
{
    HANDLE h = g_term.hin;
    char tmp[4096];
    DWORD got = 0;
    int i;

    if (!g_term.eof) {
        DWORD avail = 0;
        if (PeekNamedPipe(h, NULL, 0, NULL, &avail, NULL)) {
            if (avail > 0) {
                DWORD want = avail < sizeof tmp ? avail : (DWORD)sizeof tmp;
                if (!ReadFile(h, tmp, want, &got, NULL) || got == 0)
                    g_term.eof = 1;
            }
        } else {
            DWORD e = GetLastError();
            if (e == ERROR_BROKEN_PIPE) {
                g_term.eof = 1;         /* 写端关了 → 文件尾 */
            } else {
                /* 普通文件：ReadFile 一次读到 EOF（不阻塞） */
                if (!ReadFile(h, tmp, (DWORD)sizeof tmp, &got, NULL) || got == 0)
                    g_term.eof = 1;
            }
        }
        if (got > 0) {
            if (g_term.blen + (int)got > TERM_LINE_MAX)
                got = (DWORD)(TERM_LINE_MAX - g_term.blen);
            memcpy(g_term.bbuf + g_term.blen, tmp, got);
            g_term.blen += (int)got;
        }
    }
    for (i = 0; i < g_term.blen; i++) {
        if (g_term.bbuf[i] == '\n') {
            int len = i;
            if (len > 0 && g_term.bbuf[len - 1] == '\r')
                len--;
            if (len > cap - 1)
                len = cap - 1;
            memcpy(out, g_term.bbuf, (size_t)len);
            out[len] = '\0';
            memmove(g_term.bbuf, g_term.bbuf + i + 1, (size_t)(g_term.blen - i - 1));
            g_term.blen -= i + 1;
            return 1;
        }
    }
    /* 文件尾且缓冲里还有残余（最后一行没有换行符）→ 当成一行吐出来 */
    if (g_term.eof && g_term.blen > 0) {
        int len = g_term.blen;
        if (len > cap - 1)
            len = cap - 1;
        memcpy(out, g_term.bbuf, (size_t)len);
        out[len] = '\0';
        g_term.blen = 0;
        return 1;
    }
    return g_term.eof ? -1 : 0;
}

/* 统一入口：1=取到一行，0=暂时没有，-1=输入结束 */
static int term_poll(char *out, int cap)
{
    term_init();
    if (g_term.is_console)
        return term_poll_console(out, cap);
    return term_poll_pipe(out, cap);
}

/* 内部：非阻塞取一行（chat.跑 用它做「边收边发」）。
 * 返回 1=取到一行，0=暂时没有，-1=输入结束 */
int rt_te_poll(char *out, int cap)
{
    return term_poll(out, cap);
}

/* 内部：终端缓冲里还有没有半行输入（chat.跑 用它决定要不要重画当前输入行） */
int rt_te_pending(void)
{
    term_init();
    return g_term.is_console ? (g_term.wlen > 0) : (g_term.blen > 0);
}

/* 内部：把当前半行内容取出来（重画用）；返回取到的字节数 */
int rt_te_partial(char *out, int cap)
{
    int n = 0;
    term_init();
    if (g_term.is_console) {
        n = WideCharToMultiByte(CP_UTF8, 0, g_term.wbuf, g_term.wlen,
                                 out, cap - 1, NULL, NULL);
        if (n < 0)
            n = 0;
        out[n] = '\0';
    }
    return n;
}

/* te.读行(提示) —— 阻塞读一行；提示为 "" 就不打印。
 * 文件尾返回 "断"（和 net.recv 的约定一致）。 */
Value rt_te_readline(Value prompt)
{
    char line[TERM_LINE_MAX];
    const char *p = "";
    int r;

    if (IS_STR(prompt) && AS_STR(prompt))
        p = AS_STR(prompt);
    if (*p) {
        fputs(p, stdout);
        fflush(stdout);
    }
    for (;;) {
        r = term_poll(line, (int)sizeof line);
        if (r == 1) {
            if (g_term.is_console) {
                /* 自己回显的：换行要补上（终端里已回显了字符，但没回显换行） */
                fputs("\r\n", stdout);
                fflush(stdout);
            }
            return rt_str(line);
        }
        if (r < 0)
            return rt_str("断");
        Sleep(10);
    }
}

/* te.试读行() —— 非阻塞：暂时没有完整行返回 ""，文件尾返回 "断" */
Value rt_te_tryline(void)
{
    char line[TERM_LINE_MAX];
    int r = term_poll(line, (int)sizeof line);
    if (r == 1) {
        if (g_term.is_console) {
            fputs("\r\n", stdout);
            fflush(stdout);
        }
        return rt_str(line);
    }
    if (r < 0)
        return rt_str("断");
    return rt_str("");
}
