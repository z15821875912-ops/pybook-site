# _patch_gpu_overlap.py —— 第四跳第二阶段：主机侧 double<->float 转换与 PCIe 搬运重叠
#
# 病根（1060 实测，2048x2048x2048 端到端 23.2ms）：
#   主机侧转换 double->float   ~9.0 ms   (39%)
#   PCIe 搬运 (H2D+D2H 32MB)   ~6.4 ms   (28%)
#   kernel 本身                ~5.8 ms   (25%)   <- 只有四分之一！
#   也就是说「张量运算速度」的大头根本不在 GPU 上，而在主机侧的数据搬运。
#   卡越快，kernel 越短，这部分占比越大 —— **换张更快的卡，端到端利用率反而更低**，
#   这就是「别的卡只有 10~20%」的真正来源。
#
# 方案：分段转换 + 异步 DMA。
#   页锁定 host 内存上的 cuMemcpyHtoDAsync 发完就返回，DMA 在后台跑，
#   于是「转换第 i 段」可以和「搬运第 i-1 段」重叠。
#   端到端从 转换+搬运 串行 变成 max(转换, 搬运) ≈ 快 1.4~1.6 倍。
#   异步入口缺失时自动退回同步版本（不重叠，但结果完全一样）。
#
# 纪律：锚点唯一、原子替换、幂等、保留 CRLF。
import io, os, sys


def crlf(s):
    return s.replace("\r\n", "\n").replace("\n", "\r\n")


def read(path):
    with io.open(path, "r", encoding="utf-8", newline="") as f:
        return f.read()


def write_atomic(path, text):
    tmp = path + ".tmpfix"
    with io.open(tmp, "w", encoding="utf-8", newline="") as f:
        f.write(text)
    os.replace(tmp, path)


def sub(text, old, new, tag):
    old = crlf(old)
    new = crlf(new)
    n = text.count(old)
    if n != 1:
        print("锚点 %s 出现 %d 次（要求恰好 1 次）—— 补丁中止，不写盘" % (tag, n))
        sys.exit(1)
    return text.replace(old, new)


src = read("pybook_gpu.c")
changed = []

if "gpu_h2d_cast" in src:
    print("重叠补丁已在，跳过。")
else:
    # C1: 异步拷贝入口（可选）
    c1 = "static CUresult (*p_cuMemcpyHtoD_v2)(CUdeviceptr, const void *, size_t);\n"
    c1_new = c1 + """static CUresult (*p_cuMemcpyDtoH_v2)(void *, CUdeviceptr, size_t);
/* 异步版：重叠搬运用（CUDA 4.0+ 都有，缺了就退回同步版） */
static CUresult (*p_cuMemcpyHtoDAsync_v2)(CUdeviceptr, const void *, size_t, void *);
static CUresult (*p_cuMemcpyDtoHAsync_v2)(void *, CUdeviceptr, size_t, void *);
"""
    src = sub(src, c1, c1_new, "C1 异步拷贝 typedef")
    changed.append("C1")

    # C2: 装载
    c2 = '    LOAD_V2("cuMemcpyHtoD", "cuMemcpyHtoD_v2", p_cuMemcpyHtoD_v2);\n'
    c2_new = c2 + """    LOAD_V2("cuMemcpyDtoH", "cuMemcpyDtoH_v2", p_cuMemcpyDtoH_v2);
    LOAD_OPT("cuMemcpyHtoDAsync_v2", p_cuMemcpyHtoDAsync_v2);
    LOAD_OPT("cuMemcpyDtoHAsync_v2", p_cuMemcpyDtoHAsync_v2);
"""
    src = sub(src, c2, c2_new, "C2 异步拷贝装载")
    changed.append("C2")

    # C3: 上卡段：改成分段转换 + 异步搬运
    c3 = """    {   /* double 缓冲 -> float32 暂存，顺带就是精度降到位的地方 */
        float *pa = (float *)g_hA, *pb = (float *)g_hB;
        size_t i;
        for (i = 0; i < ka; i++) pa[i] = (float)A[i];
        for (i = 0; i < kb; i++) pb[i] = (float)B[i];
    }
    r = p_cuMemcpyHtoD_v2(g_dA, (void *)g_hA, ka * sizeof(float));
    if (r != 0) { gpu_fail("A 上卡失败：%s", cu_err(r)); goto out; }
    r = p_cuMemcpyHtoD_v2(g_dB, (void *)g_hB, kb * sizeof(float));
    if (r != 0) { gpu_fail("B 上卡失败：%s", cu_err(r)); goto out; }
"""
    c3_new = """    /* 上卡：分段把 double 转成 float 写进页锁定暂存区，同时异步搬到显存。
     * 分段是为了让「第 i 段的转换」和「第 i-1 段的 DMA」在时间上重叠 ——
     * 页锁定内存上的异步拷贝发完就返回，DMA 在后台跑。
     * 不分段的话就是 转换(9ms) + 搬运(3ms) 串行，分段后约等于 max(两者)。 */
    if (!gpu_h2d_cast(A, g_dA, ka, (float *)g_hA)) goto out;
    if (!gpu_h2d_cast(B, g_dB, kb, (float *)g_hB)) goto out;
"""
    src = sub(src, c3, c3_new, "C3 上卡分段")
    changed.append("C3")

    # C4: 下卡段：分段异步取回 + 边到边转
    c4 = """    r = p_cuMemcpyDtoH_v2((void *)g_hC, g_dC, kc * sizeof(float));
    if (r != 0) { gpu_fail("C 下卡失败：%s", cu_err(r)); goto out; }
    {   /* 下卡的是 float32，写回 double 缓冲（f32 张量里每个值都仍可被 float32 精确表示） */
        const float *pc = (const float *)g_hC;
        size_t       i;
        for (i = 0; i < kc; i++) C[i] = (double)pc[i];
    }
"""
    c4_new = """    /* 下卡：同样分段。异步取回第 i 段时，同步第 i-1 段并把它转成 double 写回，
     * 于是「取回」和「转换」也重叠了。 */
    if (!gpu_d2h_cast(g_dC, (const float *)g_hC, C, kc)) goto out;
"""
    src = sub(src, c4, c4_new, "C4 下卡分段")
    changed.append("C4")

    # C5: 两个函数的实现（放在 gpu_sgemm_f32 之前）
    c5 = "int gpu_sgemm_f32(const double *A, const double *B, double *C,\n"
    c5_new = r'''/* ─────────────── 主机侧转换与 PCIe 搬运重叠 ───────────────
 *
 * 为什么要分段：主机侧 double->float 转换是访存受限的（1060 实测 4M 个元素
 * 约 3~5 ms，memcpy 同流量只要 3.4 ms），而 PCIe 搬运又要再花一份时间。
 * 串行做就是 两份时间相加；页锁定内存上的异步拷贝发完就返回，于是把数据
 * 切成段，「转第 i 段」和「搬第 i-1 段」能重叠，端到端约等于 max(两者)。
 *
 * 为什么不用多线程：实测这台机器 4 线程只比单线程快 1.25 倍（内存带宽就
 * 20 GB/s），线程开销反而吃掉了收益 —— 分段重叠更划算，也不引入线程池。
 *
 * 分段粒度：1 MB（262144 个 float）起步，向上取整到 4 的倍数（16 字节对齐）。
 */
#define GPU_CAST_CHUNK_MIN (1u << 18)

/* 把 src 的 n 个 double 转成 float 写进页锁定暂存区 stage，同时搬到显存 dst。
 * 返回 1 成功；0 失败（原因见 gpu_last_error）。 */
static int gpu_h2d_cast(const double *src, CUdeviceptr dst, size_t n, float *stage)
{
    size_t   chunk, done;
    CUresult r;

    if (n == 0)
        return 1;
    chunk = (n + 7) / 8;
    if (chunk < GPU_CAST_CHUNK_MIN)
        chunk = GPU_CAST_CHUNK_MIN;
    chunk = (chunk + 3) & ~(size_t)3;

    for (done = 0; done < n; done += chunk) {
        size_t cnt = (done + chunk <= n) ? chunk : (n - done);
        size_t i;
        for (i = 0; i < cnt; i++)
            stage[done + i] = (float)src[done + i];
        if (p_cuMemcpyHtoDAsync_v2)
            r = p_cuMemcpyHtoDAsync_v2(dst + (CUdeviceptr)(done * sizeof(float)),
                                       (void *)(stage + done),
                                       cnt * sizeof(float), NULL);
        else
            r = p_cuMemcpyHtoD_v2(dst + (CUdeviceptr)(done * sizeof(float)),
                                  (void *)(stage + done), cnt * sizeof(float));
        if (r != 0) {
            gpu_fail("上卡失败：%s", cu_err(r));
            return 0;
        }
    }
    return 1;
}

/* 从显存取回 n 个 float 到页锁定暂存区 stage，同时转成 double 写进 dst。
 * 异步取回第 i 段的同时处理第 i-1 段；最后一段等完再转。
 * 用两个 event 乒乓（每段建销一个 event 太贵，event 创建本身要几十微秒）。 */
static int gpu_d2h_cast(CUdeviceptr src, const float *stage, double *dst, size_t n)
{
    size_t   chunk, done;
    CUresult r;
    void    *ev0 = NULL, *ev1 = NULL;
    int      use_async = 0;
    int      idx;

    if (n == 0)
        return 1;
    chunk = (n + 7) / 8;
    if (chunk < GPU_CAST_CHUNK_MIN)
        chunk = GPU_CAST_CHUNK_MIN;
    chunk = (chunk + 3) & ~(size_t)3;

    if (p_cuMemcpyDtoHAsync_v2 && p_cuEventCreate && p_cuEventRecord &&
        p_cuEventSynchronize && p_cuEventDestroy) {
        if (p_cuEventCreate(&ev0, 0) == 0 && p_cuEventCreate(&ev1, 0) == 0)
            use_async = 1;
        else {
            if (ev0) { p_cuEventDestroy(ev0); ev0 = NULL; }
            if (ev1) { p_cuEventDestroy(ev1); ev1 = NULL; }
        }
    }

    for (done = 0, idx = 0; done < n; done += chunk, idx++) {
        size_t cnt = (done + chunk <= n) ? chunk : (n - done);
        size_t i;
        if (use_async) {
            void *ev_now = (idx & 1) ? ev1 : ev0;     /* 乒乓 */
            void *ev_old = (idx & 1) ? ev0 : ev1;
            int   have_old = (done > 0);
            r = p_cuMemcpyDtoHAsync_v2((void *)(stage + done),
                                       src + (CUdeviceptr)(done * sizeof(float)),
                                       cnt * sizeof(float), NULL);
            if (r != 0) { gpu_fail("下卡失败：%s", cu_err(r)); goto fail; }
            if (p_cuEventRecord(ev_now, NULL) != 0) {
                gpu_fail("下卡事件记录失败");
                goto fail;
            }
            if (have_old) {
                size_t prev = done - chunk;
                size_t pcnt = (prev + chunk <= n) ? chunk : (n - prev);
                if (p_cuEventSynchronize(ev_old) != 0) {
                    gpu_fail("下卡同步失败");
                    goto fail;
                }
                for (i = 0; i < pcnt; i++)
                    dst[prev + i] = (double)stage[prev + i];
            }
        } else {
            /* 没有异步入口：退回同步取回（不重叠，但结果一样） */
            r = p_cuMemcpyDtoH_v2((void *)(stage + done),
                                  src + (CUdeviceptr)(done * sizeof(float)),
                                  cnt * sizeof(float));
            if (r != 0) { gpu_fail("下卡失败：%s", cu_err(r)); goto fail; }
            for (i = 0; i < cnt; i++)
                dst[done + i] = (double)stage[done + i];
        }
    }
    if (use_async) {
        /* 最后一段：等它到齐再转（最后一段用的是 idx 为偶数还是奇数决定的事件） */
        size_t rest = n % chunk;
        size_t prev = rest ? (n - rest) : (n - chunk);
        size_t pcnt = n - prev;
        size_t i;
        int    last_idx = (int)((n + chunk - 1) / chunk) - 1;
        void  *ev_last = (last_idx & 1) ? ev1 : ev0;
        if (p_cuEventSynchronize(ev_last) != 0) {
            gpu_fail("下卡同步失败");
            goto fail;
        }
        for (i = 0; i < pcnt; i++)
            dst[prev + i] = (double)stage[prev + i];
    }
    if (ev0) p_cuEventDestroy(ev0);
    if (ev1) p_cuEventDestroy(ev1);
    return 1;
fail:
    if (ev0) p_cuEventDestroy(ev0);
    if (ev1) p_cuEventDestroy(ev1);
    return 0;
}

''' + c5
    src = sub(src, c5, c5_new, "C5 重叠实现")
    changed.append("C5")

    write_atomic("pybook_gpu.c", src)
    print("重叠补丁完成：", ",".join(changed))
