# LookAround 日志

- 开启：2026-10-07 13:44:44
- 目录：`C:\Users\zhuli\Desktop\pybook`

> 由 `pybktl lookaround` 生成：记录文件改动、运行与运行时错误。

## 2026-10-07 13:44:44 — LookAround 已开启

- 监控目录：`C:\Users\zhuli\Desktop\pybook`
- 该文件夹里运行 `pybktl run`/`smoke`/`build`/`check` 会自动记录
- 文本文件改动会记录内容 diff
- 本窗口按 Ctrl+C 停止；查看历史用 `pybktl lookaround log`

## 2026-10-07 13:44:55 — 改动 pybk_project.py

- 事件：modified
- 文件：`pybk_project.py`
- 大小：10637 → 10764 字节
- mtime：2026-10-07 13:44:47
- diff：
```diff
--- before
+++ after
@@ -259,7 +259,9 @@
     if len(sys.argv) < 2:
         print("用法: python pybk_project.py <PYBOOK.toml>")
         sys.exit(1)
+    print("[dbg] start analyze", file=sys.stderr, flush=True)
     res = analyze(sys.argv[1])
+    print("[dbg] analyze returned", file=sys.stderr, flush=True)
     print(f"入口: {res['entry']}  ({res['entry_path']})")
     print(f"模块数: {len(res['modules'])}")
     for n, info in res['modules'].items():
```

## 2026-10-07 13:44:56 — 运行 _err_demo.pybk  ❌ 运行时错误

- 命令：`pybktl check _err_demo.pybk`
- 退出码：1
- 输出：
```
{"ok": false, "line": 12, "message": "第 12 行：字面量除零：除数写死成了 0，数字 / 0 运行时会崩\n  为什么：除数写死成了 0，运行时会直接崩\n  怎么改：检查除数：它应该是个变量或非零的常数"}
```
- 错误（人话）：
> {"ok": false, "line": 12, "message": "第 12 行：字面量除零：除数写死成了 0，数字 / 0 运行时会崩\n  为什么：除数写死成了 0，运行时会直接崩\n  怎么改：检查除数：它应该是个变量或非零的常数"}
- 错误（原文，供排查）：
```
{"ok": false, "line": 12, "message": "第 12 行：字面量除零：除数写死成了 0，数字 / 0 运行时会崩\n  为什么：除数写死成了 0，运行时会直接崩\n  怎么改：检查除数：它应该是个变量或非零的常数"}
```

## 2026-10-07 13:44:57 — 运行 _broken.pybk  ❌ 运行时错误

- 命令：`pybktl check _broken.pybk`
- 退出码：1
- 输出：
```
{"ok": false, "line": 3, "message": "第 3 行：期望 'NAME'，实际是 '查'\n  为什么：`查` 是保留字（69 个之一），不能当变量名/函数名\n  怎么改：换个名字，比如 vg.查数；完整保留字表见 PYBOOK_AI.md"}
```
- 错误（人话）：
> {"ok": false, "line": 3, "message": "第 3 行：期望 'NAME'，实际是 '查'\n  为什么：`查` 是保留字（69 个之一），不能当变量名/函数名\n  怎么改：换个名字，比如 vg.查数；完整保留字表见 PYBOOK_AI.md"}
- 错误（原文，供排查）：
```
{"ok": false, "line": 3, "message": "第 3 行：期望 'NAME'，实际是 '查'\n  为什么：`查` 是保留字（69 个之一），不能当变量名/函数名\n  怎么改：换个名字，比如 vg.查数；完整保留字表见 PYBOOK_AI.md"}
```

## 2026-10-07 13:45:09 — 运行 _ffi_final.pybk

- 命令：`pybktl check _ffi_final.pybk`
- 退出码：0
- 输出：
```
{"ok": true, "message": "编译通过（语法+语义；未 gcc 未运行）"}
```
