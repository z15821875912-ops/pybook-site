"""PYbook 语言前端：词法分析 + 语法分析。

一行一个语句，块用花括号，标识符允许中文。
只做认字和建 AST：不查变量声明、不查类型、不生成任何 C。
仅用 Python 标准库。

实现说明：ns.show(...) 的内容是不加引号的裸文本（可含 ！、$ 等非 Token 字符），
所以词法器遇到非法字符先产出 ERR 占位符而不是立刻抛错；语法器在正常解析路径上
遇到 ERR 才报错（带行号），而在裸文本区域里按源码位置整段跳过。
"""

import dataclasses
import os
import re
import copy
from dataclasses import dataclass, field


# ---------------------------------------------------------------- Token

@dataclass
class Token:
    kind: str    # 'NUM' 'STR' 'NAME' 'KW' 'OP' 'AT' 'EOF'
    value: str
    line: int


KEYWORDS = {
    'net',
    'GOING', 'STOP', 'vg', 'vg_ro', 'ns', 'rm', 'when', 'func', 'ip', 'vc',
    'lock', 'del', 'list', 'show', 'input', 'ret', 'at', 'try', 'catch', 'onerror',
    'finally', 'throw',
    'and', 'or', 'not', 'true', 'false', '真', '假', '空', 'none', 'Memoryment', 'web', 'js', 'csv', '查', 'mm',
    'lb', '静', 'self', 'te', 'mt', 'rd', 'file', 'if', 'elif', 'else', 'while',
    '引用', 'break', '断', 'continue', '继续', 'for', 'in', 'window', 'tm', '音', '调色板',
    'import', 'mu', 'palette', 'macro', '宏', 'http',
    'ON', 'hw', 'np', 'tb', 'mp', 'ui', 'bs', 'tw', 'data', 'm3', 'smoke', 'ffi', 'tensor',
    'lambda', 'mec', 'errorstopped', 'device', 'jit', 'sym', 'language',
}

# ── language 旋钮：中英双拼词汇表 ─────────────────────────────────────────
#
# language english（默认）：只认 KEYWORDS 里的关键字 + LIB_PREFIXES 里的前缀
# language 中文：额外启用下面这两套中文拼写（英文写法照旧可用，便于混写/渐进迁移）
#
# 规范名永远是英文：AST / C 后端 / VM 后端拿到的一律是规范名，中文只在两处起作用——
#   ① 词法层：中文拼写认成关键字（而不是普通标识符）
#   ② 比较前：把中文拼写折回规范名（parser 的 at/expect/语句分派都按规范名比）
# 所以「加中文拼写」是纯前端改动，后端零回归。
#
# 历史上就存在的中文关键字（真/假/空/查/断/继续/引用/宏/音/调色板）两种模式都认：
# 它们本来就是规范名，不在下面两张表里——那不是「翻译出来的别名」。

ZH_KEYWORDS = {          # 规范名 → 中文拼写
    'if': '如果', 'elif': '否则如果', 'else': '否则',
    'while': '循环', 'for': '遍历', 'in': '属于',
    'func': '函数', 'ret': '返回', 'lambda': '匿名',
    'try': '尝试', 'catch': '捕获', 'finally': '最终', 'throw': '抛出',
    'onerror': '出错', 'and': '与', 'or': '或', 'not': '非',
    'self': '自身', 'show': '显示', 'input': '输入', 'import': '导入',
    'GOING': '开始', 'STOP': '结束', 'lock': '锁', 'del': '删除',
    'Memoryment': '内存', 'window': '窗口', '静': '静态',
}

ZH_PREFIXES = {         # 规范前缀 → 中文拼写
    # 标准库模块
    'te': '文本', 'mt': '数学', 'rd': '随机', 'list': '列表', 'dict': '字典',
    'file': '文件', 'tm': '时间', 'net': '网络', 'http': '接口', 'chat': '聊天',
    'crypto': '加密', 'hw': '硬件', 'np': '数值', 'tensor': '张量', 'tb': '张量库',
    'mp': '矩阵', 'ui': '界面', 'js': '脚本', 'csv': '分隔表', 'mm': '素材',
    'bs': '位运算', 'm3': '模型', 'smoke': '冒烟', 're': '正则', 'mec': '机制',
    'set': '集合', 'obj': '物体', 'sym': '符号', 'ffi': '外部接口',
    # 语法前缀（声明标记一类）
    'vg': '变量', 'vg_ro': '只读', 'ns': '命名空间', 'rm': '重复', 'lb': '类',
    'ip': '输入项', 'web': '网页',
}

# 中文拼写 → 规范名（词法层认字 + parser 折回规范名共用它）
ZH_CANON = {}
for _d in (ZH_KEYWORDS, ZH_PREFIXES):
    for _can, _zh in _d.items():
        ZH_CANON[_zh] = _can
del _d, _can, _zh

# 中文前缀 → 规范前缀（只含前缀，不含关键字）：英文模式下用它认「你写了中文前缀」
ZH_PREFIX_REV = {zh: can for can, zh in ZH_PREFIXES.items()}

# 中文模式下额外认成关键字的词：**只收「英文里本来就是关键字」的**那些中文拼写。
#
# 为什么不能一股脑全收：英文里 dict/re/crypto/chat/set 这些是**普通标识符**
# （能当变量名），中文拼写（字典/正则/加密/聊天/集合）要跟它们对齐，
# 否则中文模式会比英文模式多出一堆保留字——同一个词，两边行为不一样。
# 前缀拼写是不是关键字，不影响它能不能当库前缀用（两条分派路径都认）。
ZH_KW_SET = frozenset(zh for zh, can in ZH_CANON.items() if can in KEYWORDS)

# 中文模式下的「短语」：英文里是**两个关键字连写**（not in），中文习惯写成一个词
# （不属于）。词法层遇到这些词时**拆成两个关键字 token**——后面的比较逻辑一个字都不用改，
# 「非 属于」这种分开写的写法也照样能用（两边等价）。
ZH_PHRASE_SPLIT = {
    '不属于': ('非', '属于'),
    '非属于': ('非', '属于'),
}


def _kw_set(lang: str):
    """本语言模式认成关键字的词：英文模式只有 KEYWORDS，中文模式再加上中文拼写。"""
    return (KEYWORDS | ZH_KW_SET) if lang == 'zh' else KEYWORDS

# 项目语言模式：主文件的 language 指令设定，被 引用 的模块默认继承；
# 模块自己再写 language 只管自己那一份。
_LANG_MODE = 'en'


def _detect_lang(src: str):
    """扫源码找 language 指令，返回 'en' / 'zh' / None（本文件没写）。

    必须在**词法之前**就知道语言：中文拼写要不要认成关键字，是词法层的事。
    所以这里做一次行级预扫（只看行首的 language 指令，# 注释行跳过）；
    多个 language 指令时**最后一个有效的**说了算（与语法层逐条校验对得上）。
    值不认识时跳过——不猜，交给语法层的 parse_language() 报准确的错。
    """
    found = None
    for raw in src.split('\n'):
        line = raw.strip()
        if not line or line.startswith('#') or line.startswith('/*'):
            continue
        parts = line.split()
        if len(parts) < 2 or parts[0] != 'language':
            continue
        val = parts[1]
        if val == 'english':
            found = 'en'
        elif val == '中文':
            found = 'zh'
        # 别的值不认：留给语法层报错（这里静默跳过，模式先按「没写」算）
    return found


# 两字符运算符必须先于单字符判断
TWO_OPS = ('==', '!=', '<=', '>=', '//', '**')
SINGLE_OPS = set('.(){}=+-*/%<>,:[]?')


class PybkError(Exception):
    """PYbook 词法/语法错误，信息带行号，自动追加三段式建议。"""
    def __init__(self, text, lang=None):
        # text 形如 "第 N 行：<msg>"；提取 <msg> 交给 hint_for 做子串匹配后拼回。
        # 已经是三段式（含 为什么/怎么改）的不再重复追加。
        # lang = 本文件语言模式（'en'/'zh'）——中文模式下中文拼写**就是保留字**，
        # 提示不能说「你没写 language 中文」，得说「它撞了保留字」。
        m = re.match(r"^第 \d+ 行：(.*)$", text, re.S)
        msg = m.group(1) if m else text
        if "为什么" in msg or "怎么改" in msg:
            super().__init__(text)
        else:
            super().__init__(text + hint_for(msg, lang))


# ── 报错三段式：错了什么 + 为什么 + 怎么改 ────────────────────────────
# err() 自动附加修复建议（人和 AI 都吃这套）。按子串匹配、命中即停；
# 只在原文案后**追加**，不改原文案（自测/Smokeroor 都是子串匹配，追加安全）。
_HINTS = [
    ("变量声明必须以 vg. 开头",
     "两种可能：① 名字撞了保留字（查/真/假/空/断/引用/音/调色板 或 vg/mt/tm/smoke 等 39 个前缀）；② GOING 块里写了 表[i] = 值",
     "① 换个名字避开保留字（比如 vg.查验数）；② 下标赋值写 vg.表[i] = 值，或者把赋值包进 func 里"),
    ("未声明",
     "函数内只能读参数和自己赋过的变量；GOING 块里的变量要先 vg. 声明；拼错名字也报这个",
     "先写 vg.名 = 值 声明；函数要用的就当参数传进去；再检查一遍拼写"),
    ("无法确定",
     "方法调用 a.b() 需要能推出 a 是哪个类",
     "计时用 tm.now()（不是 时间.秒()）；对象用 lb.类名(...) 赋值来定类；或者改成普通函数调用"),
    ("不是合法的语句开头",
     "两种可能：① if/while/func 的块结束后直接跟了语句；② 字符串里的引号提前把字符串收尾了",
     "① 块的 } 后空一行再写；GOING 结尾写 }STOP（要紧挨着）；② 字符串里写引号就转义（反斜杠+引号），或用「」"),
    ("非法字符",
     "PYbook 字符串支持转义：反斜杠 后跟 n/r/t/引号/反斜杠 = 换行/回车/制表/引号/反斜杠",
     "反斜杠n 换行、反斜杠r 回车、反斜杠t 制表、反斜杠+引号 引号、反斜杠反斜杠 反斜杠；老写法 te.chr(10) 仍兼容"),
    ("找不到文件",
     "引用(\"名字\") 找的是 名字.pybk（名字可带子目录，如 \"lib/助手\"）",
     "确认文件在（路径相对引用方所在目录）、名字别拼错（带不带 .pybk 都行）；"
     "mt./smoke. 这类内置前缀不用引用"),
    ("没有这个 API",
     "库函数名是英文（tm/te/smoke/hw/m3/list/dict...），语句才是中文",
     "查 PYBOOK_AI.md 的库清单；比如计时是 tm.now()、造字符是 te.chr()"),
    ("未定义",
     "函数没定义或拼错了；也可能是撞了保留字",
     "func 名(参数) {...} 先定义再调；标准库要加前缀（mt./te./list.）；最后查拼写"),
    ("嵌套太深",
     "表达式或括号嵌套超出了编译器限制",
     "拆成多步：vg.中间 = 先算一部分，再往下算"),
    ("ns.show 参数里有空项",
     "ns.show 里某个插值项解析出来是空的——常见是 $ 后面跟的变量没声明，或结尾多了个逗号冒出空项",
     "检查每个 $变量 都声明过；ns.show(\"a=$a\") 结尾别多写逗号"),
    ("张量二维切片 T[a:b,c:d] 的每一段上下界都要显式写出",
     "张量切片 T[a:b,c:d] 的四边界必须都写出来，PYbook 不推断省略的上下界",
     "写全 T[0:2, 0:3]；想取一整行就写 T[0:1, 0:列数]"),
    ("张量切片暂不支持步长",
     "PYbook 张量切片 T[a:b,c:d] 只支持连续区间，不能写第三个步长（和 Python 的 [a:b:c] 不同）",
     "要隔行取就先整片取出来用循环挑；或取连续块 T[a:b, c:d]"),
    ("张量多下标只支持 T[i,j] 或 T[a:b,c:d] 两种形式",
     "二维张量下标只认单点 T[i,j] 或切片 T[a:b,c:d]，其它写法（三下标、混用）不认",
     "单元素用 T[i,j]；一片用 T[a:b,c:d]；更高维暂不支持"),
    ("break 只能在循环内使用",
     "break 只能写在 for/while 循环体里；裸写在 GOING 或 func 顶层会让编译器不知道跳去哪",
     "把 break 挪进 for/while 的 { } 内；想提前结束函数用 ret"),
    ("continue 只能在循环内使用",
     "continue 只能写在 for/while 循环体里；裸写在 GOING 或 func 顶层会让编译器不知道跳去哪",
     "把 continue 挪进 for/while 的 { } 内；想跳过本轮就写在判断之后、循环体末尾之前"),
    ("Memoryment 后要 @normal、@self 或 @数字",
     "@ 后面的内存管理模式只认 normal / self / 1~6，其它字不认",
     "写 @normal（默认）或 @self（自管），或 @1~@6 选分级策略；别写范围外的字"),
    ("不应再有内容",
     "一个程序的 GOING:{...}STOP 是主入口的结束，它后面不能再跟语句或另一个 GOING；模块文件里同理",
     "把所有要执行的代码放进 GOING 块里；模块文件里把代码收进 func / 用 引用 拆到别的文件"),
    ("jit 只支持 on / off",
     "jit 文件头旋钮只有 on（可跟阈值）或 off 两档，其它字不认",
     "写 jit on（可加 jit on 8）或 jit off；别写其它字"),
    ("jit 阈值",
     "jit on 后面跟的阈值须是 1~1000000 的整数（批量架构下阈值是「总闸」）",
     "写 jit on 8 这种整数；不写阈值就按批量架构自动决定"),
    ("jit on 后面最多跟一个阈值",
     "jit on 只接受一个可选阈值数字，多写的没有语义",
     "一行只写一个阈值：jit on 8"),
    ("jit off 不带参数",
     "jit off 是关开关，后面不能再跟任何东西",
     "单独写一行 jit off 即可"),
    ("language 只支持",
     "语言旋钮只有两档：language english（默认）/ language 中文",
     "写 language english 或 language 中文，放在文件顶部（GOING 之前）"),
    ("language 只能写在文件顶部",
     "language 是文件头指令：整份文件一个语言模式，中途不能改",
     "把 language 挪到文件最上面（GOING 之前），全文件只写一次"),
    ("language 档位不一致",
     "同一个文件里写了两个不同的 language 档位",
     "language 全文件只留一个（放文件顶部），后面的删掉"),
    ("这里是 引用",
     "引用(\"名\") 的写法：名字要带引号、是字符串，不能用裸名字或 import 关键字",
     "写 引用(\"我的模块\")（带不带 .pybk 都行）；模块可放子目录，引用(\"lib/我的模块\")"),
    ("重抛",
     "不带内容的 throw 是「重抛」：把手上正在接的那个错原样抛给外层",
     "写在 catch 块里；别处没有「手上的错」可抛——要抛新的错就写 throw \"消息\""),
    ("finally 只能跟在 try/catch 后面",
     "finally 是 try/catch 的收尾块，必须紧跟在它们后面，不能单独出现",
     "写成 try { } catch e { } finally { } 三段连着写"),
    ("try 后面要跟 catch 或 finally",
     "try 必须有收尾：要么 catch 接住错，要么 finally 做收尾清理",
     "写成 try { } catch e { }，或 try { } finally { }"),
    ("错误类型写一个名字",
     "catch 后面跟的类型要是一个名字或一段字符串",
     "写成 catch e:除零 { }（或 catch e:\"除零\" { }）"),
    ("参数",
     "调用时的参数个数和 func 定义不符（按位置传，不能多不能少）",
     "对照 func 定义的参数个数；可选参数用默认值写法"),
    ("只在网页模式支持",
     "这个控件只存在于网页实时模式",
     "写在 web.实时 块里；桌面窗口用 ui.begin/ui.button 那一套"),
    ("只能在 web.实时 块里用",
     "按键/实时监听只在网页实时模式生效",
     "挪进 web.实时 块；桌面窗口自己用变量记状态"),
    ("类型错配",
     "一边是字符串、一边是数字，PYbook 不会隐式互转",
     "文本拼接用 te.str(数字) 先转成文本；纯数字运算就别混进字符串"),
    ("字面量除零",
     "除数写死成了 0，运行时会直接崩",
     "检查除数：它应该是个变量或非零的常数"),
    ("字符串未闭合",
     "行尾或换行把字符串截断了，没有配对的闭引号",
     "检查字符串两头是不是都写了引号；别让字符串跨行；需要换行用「」或 te.chr(10)"),
    ("缺少右括号",
     "括号、方括号或花括号有一边没写全，左右不配对",
     "数一下 ( 和 )、[ 和 ]、{ 和 } 是不是一样多；编辑器一般能高亮配对"),
    ("没有属性",
     "那个类没有这个属性名（拼错，或忘了在 lb.类 里声明 vg.属性=默认）",
     "检查属性名拼写；确认在 lb.类 { vg.属性=默认 } 里声明过该属性"),
    ("Memoryment 模式",
     "@N 只支持 1~6 以及 normal/self 这几种内存管理模式",
     "写 @1（普通）到 @6（分代+增量），或 @normal / @self；别写范围外的数字"),
    ("web.块 里不能用",
     "组件/子页只渲染静态页面内容，动画类语句要写在 GOING 或主页画布里",
     "把 帧/播放/实时/draw/嵌套页 移到 GOING；子页内容用 web.页 单独定义"),
    ("web.页 里不能用",
     "子页只烤页面内容，动画类的语句要写在主页的画布段里",
     "把 帧/播放/实时/draw 移到主页 GOING 的画布段；子页用 web.页 嵌套"),
    ("web.块 只能定义在文件顶层",
     "web.组件 是页面模板，必须和 func 同级定义在文件顶层",
     "把 web.块 从 GOING 或别的块里拿出来，放到和 func 并列的位置"),
    ("web. 后只能是",
     "web. 后面跟的不是合法的网页组件名",
     "用 big/mid/show/img/line/link/draw/帧/播放/实时 等，或先 web.组件名(参数){...} 定义"),
    ("go 的方向只能是",
     "go 平移画布只认 右/左/上/下（或 right/left/up/down）",
     "把方向写成 右 或 right、左 或 left 等合法值"),
    ("key 的键名必须是字符串字面量",
     "key 的按键名必须写成引号里的字符串",
     "写 key(\"right\") 而不是 key(right)"),
    ("不支持的键名",
     "那个按键名不在支持列表里",
     "用 right/left/up/down/space/字母 a-z/enter/esc/shift 或中文 右/左/上/下/空格/回车"),
    ("插值表达式里不能用逗号",
     "插值里写逗号会让编译器分不清是几个参数",
     "先把逗号两边的结果各自存进变量，再在 ns.show 里显示这些变量"),
    ("$ 后的表达式无法解析",
     "$ 后面要跟一个变量名或简单表达式",
     "$ 后直接写变量名（如 $分）；复杂结果先存进变量再显示"),
    ("缺少完整的 r,g,b 三段",
     "/magic(c=..., ...) 需要完整的 红,绿,蓝 三段颜色值",
     "写全 /magic(c=255,0,0)，三段都用 0~255 的数字"),
    ("magic 项不能为空",
     "/magic(...) 里至少要有颜色或样式内容",
     "写 /magic(b) 加粗 或 /magic(c=255,0,0) 上色，别留空"),
    ("hw 模块需要先在文件顶部写 ON 3D_highway",
     "hw.* 是 3D 高速渲染模块，必须先声明开启才能用",
     "在文件顶部（@ 行之后、GOING 之前）写一行 ON 3D_highway"),
    ("没有函数",
     "那个库前缀下没有这个名字的函数（拼错或前缀不对）",
     "查 PYBOOK_AI.md 的库清单确认函数名和前缀（如 tm./te./list./mt.）"),
    ("重复定义",
     "同一个名字被定义了两次（可能是宏，也可能是函数）",
     "给其中一个换个名字，或删掉多余的定义；"
     "若两个模块各有同名函数，把其中一个模块放进子目录（引用(\"lib/名\")），"
     "编译期会自动给它加命名空间前缀（名_函数）"),
    ("tm.stop 的用法不对",
     "tm.stop 只接受两种写法",
     "写 tm.stop(秒) 或 tm.stop(数值, \"s\"/\"ms\")"),
    ("device 只支持",
     "设备后端旋钮只有三档：auto（默认，探测到卡就用卡）/ cpu / gpu",
     "写 device auto、device cpu，或 device cpu 4（4 个工作线程）"),
    ("device gpu：当前",
     "「有没有卡」是运行时才知道的事，编译期只查语法。"
     "gpu 档探测不到可用 GPU 会直接报错，不会偷偷跑 CPU —— "
     "那等于骗你写了 device gpu 却没上卡",
     "改成 device cpu（可带线程数）或 device auto；"
     "想真上卡就确认机器上有 NVIDIA 显卡、驱动装好了（PYbook 用 CUDA 驱动 API，"
     "不需要装 CUDA Toolkit）"),
    ("device cpu 的线程数",
     "线程数须是 1~1024 的整数（实际会被钳到 MT_MAXT=16 以内）",
     "写 device cpu 4 这样；不写数字就按机器的逻辑处理器数"),
    ("只有 device cpu 能带线程数",
     "线程数只对 cpu 档有意义：auto 表示「让程序自己选」，gpu 档由驱动自己调度",
     "要指定线程数就写 device cpu 4；想交给程序决定就只写 device auto"),
    ("device cpu 后面最多跟一个线程数",
     "device 这行只接受「档位 + 可选的一个整数」，多写的 token 没有语义",
     "一行只写一个线程数：device cpu 4；要换线程数就改这一行再跑一次"),
    ("device 后面要写后端档位",
     "光写 device 没说清跑在哪个后端 —— auto（自动）/ cpu（显式 CPU）/ gpu（显式上卡）",
     "写 device auto、device cpu，或 device cpu 4（4 个工作线程）"),
    ("函数名不合法",
     "func 的名字只能是标识符（字母或下划线开头），撞了保留字或用了符号开头都不行",
     "换个以字母或下划线开头的名字；别用保留字当函数名（完整表见 PYBOOK_AI.md）"),
    ("宏名不合法",
     "宏名要像变量名一样是标识符，如 宏 行(参数)，不能含空格或符号",
     "改成 宏 行(参数){...} 这种写法"),
    ("宏/macro 定义必须以 宏 或 macro 开头",
     "宏定义的关键字是 宏 或 macro，写法或大小写不对编译器认不出",
     "写 宏 名(参数){...} 或 macro 名(参数){...}"),
    ("类体缺少收尾的 }",
     "类的花括号没闭合，编译器读到文件尾还没看到 }",
     "检查 lb.类 { ... } 的 } 有没有写全"),
    ("类体里只能是",
     "类体里只能写 属性(vg.名)/静态(静 vg.名)/方法(func 名)/静态方法(静 func 名)，普通语句不行",
     "把业务逻辑挪进 func 方法里，类体只放声明和方法"),
    ("张量多下标赋值只支持 T[i,j] = 值",
     "二维张量多重赋值只能写成 T[i,j] = 值（一个点），不支持更多下标",
     "二维张量用 T[i,j] = 值；更高维先切片取出再赋值"),
    ("仅支持 T[i] = 值 或 T[i,j] = 值",
     "张量赋值只支持一维 T[i]=值 和二维 T[i,j]=值，切片批量赋值还没开通",
     "单个元素用 T[i]=值 或 T[i,j]=值；要改一片就先 tensor.slice 取出来改"),
    ("多重赋值左右个数不匹配",
     "像 a, b = 1, 2, 3 这种左右个数对不上",
     "左边几个变量，右边就给几个值；或者一行只赋一个变量"),
    ("类型注解需要一个类型名",
     "冒号后面要跟类型名（数字 / 字符串 / 列表 / 列表(数字) 等），不能空着或写错",
     "写 vg.x: 数字 = 0 或 func f(x: 数字)；不确定就先不写注解"),
    ("STOP 必须紧跟在 } 之后",
     "GOING 块的结束写成 }STOP，STOP 要和 } 在同一行、紧贴着",
     "把 STOP 提到和 } 同一行：}STOP"),
    ("文件必须包含恰好一个 GOING 块",
     "一个 .pybk 文件里只能有一个 GOING:{...}STOP 作主入口",
     "删掉多余的 GOING；或把逻辑收进 func / 用 引用 拆到别的文件"),
    ("模块文件顶层只能是 引用/func/vg/lb/Memoryment/device",
     "被 引用() 的模块文件，顶层只能放这些定义，不能写直接执行的语句",
     "把要执行的代码放进引用方的 GOING；模块里只写 func/lb 等定义"),
    ("目前只有 3D_highway 模块",
     "ON 后面目前只认 3D_highway 这一个模块名",
     "写 ON 3D_highway；其它模块名还没实现"),
    ("errorstopped 只支持 hard / normal / simple",
     "errorstopped 文件头旋钮只有这三档（可加 豁免 函数名 后缀）",
     "写 errorstopped normal（或 hard / simple）；加豁免写 errorstopped hard 豁免 我的函数"),
    ("ffi. 开头的底层指令",
     "文件顶层只接受 ffi.包含/ffi.链接/ffi.声明/ffi.码/ffi.调用 这几条底层指令",
     "写 ffi.声明(返回类型 名(参数类型)) 这类；普通代码用 func 写"),
]


def hint_for(msg: str, lang: str = None) -> str:
    """报错三段式的后两段（为什么 / 怎么改）。没命中返回空串。

    lang：本文件语言模式（'en'/'zh'）。缺省取**项目语言模式** _LANG_MODE
    （代码生成期在另一个模块里抛错，那边拿不到本文件的模式，用项目模式最准）。
    """
    lang = lang or _LANG_MODE
    if "为什么" in msg or "怎么改" in msg:
        return ""
    # 动态识别：词法层报「期望 'NAME'，实际是 'X'」——十有八九 X 撞了保留字
    m = re.search(r"实际是 '([^']+)'", msg)
    if m:
        bad = m.group(1)
        if bad in ZH_CANON:
            if lang == 'zh':
                return _zh_reserved_hint(bad)
            return _zh_kw_hint(bad)
        if bad in KEYWORDS:
            return (f"\n  为什么：`{bad}` 是保留字（{len(KEYWORDS)} 个之一），不能当变量名/函数名"
                    f"\n  怎么改：换个名字，比如 vg.{bad}数；完整保留字表见 PYBOOK_AI.md")
        g = _zh_glue_hint(bad)
        if g:
            return g
        return (f"\n  为什么：这里该写合法的名字或关键字，但来了个 `{bad}`"
                f"\n  怎么改：对照 PYBOOK_AI.md 语法速查；保留字不能当名字用")
    for m2 in re.finditer(r"'([^']+)'", msg):   # 引号里裹着的中文关键字
        if m2.group(1) in ZH_CANON:
            if lang == 'zh':
                return _zh_reserved_hint(m2.group(1))
            return _zh_kw_hint(m2.group(1))
        g = _zh_glue_hint(m2.group(1))
        if g:
            return g
    for pat, why, fix in _HINTS:
        if pat in msg:
            return f"\n  为什么：{why}\n  怎么改：{fix}"
    return ""


def _zh_glue_hint(bad: str) -> str:
    """中文关键字和后面的名字**粘成了一个词**（如 `返回x`）时的提示。

    中文没有词间空格，词法层按整词切分，`返回x` 会切成一个标识符——
    这跟英文里 `returnx` 是一个标识符是同一回事（英文 `return x` 也得加空格），
    但中文用户更容易踩，所以给一条定点提示，别让人以为「中文关键字坏了」。
    """
    for zh in sorted(ZH_KW_SET, key=len, reverse=True):
        if bad.startswith(zh) and len(bad) > len(zh) and _is_id_start(bad[len(zh)]):
            rest = bad[len(zh):]
            return (f"\n  为什么：`{bad}` 像是中文关键字 `{zh}` 和名字 `{rest}` 粘在一起了"
                    f"（中文关键字后面没有空格，词法层分不开这两个词）"
                    f"\n  怎么改：在关键字和名字之间加空格，写成 `{zh} {rest}`；"
                    f"括号也能隔开（`{zh}(...)`）")
    return ""


def _zh_reserved_hint(zh: str) -> str:
    """中文模式下的中文拼写撞了保留字（比如拿 `列表` 当变量名）。

    注意：英文模式下 `list` 也是保留字，所以 `vg.list` 在两边**都**不行——
    这是对等行为，不是中文模式多出来的限制。提示要说清这个，别让人以为中文更严。
    """
    return (f"\n  为什么：`{zh}` 是中文关键字（{ZH_CANON[zh]}），"
            f"language 中文 模式下它是**保留字**，不能当变量名/函数名"
            f"（英文模式下对应的 `{ZH_CANON[zh]}` 同样是保留字，两边对等）"
            f"\n  怎么改：换个名字，比如 vg.{zh}数；"
            f"或者把文件顶部改成 language english（那时它是普通标识符）")


def _zh_kw_hint(zh: str) -> str:
    """中文关键字在英文语言模式下被误用时的提示（两种误用都覆盖）。"""
    return (f"\n  为什么：`{zh}` 是中文关键字（{ZH_CANON[zh]}），"
            f"当前文件没写 language 中文，中文关键字不生效"
            f"\n  怎么改：① 想用中文写程序：在文件顶部加一行 language 中文"
            f"；② 想拿它当变量名/函数名：换个不撞关键字的名字")


def _is_digit(c: str) -> bool:
    return '0' <= c <= '9'


def _is_id_start(c: str) -> bool:
    return (c == '_' or 'a' <= c <= 'z' or 'A' <= c <= 'Z'
            or '\u4e00' <= c <= '\u9fff')


def _is_id_char(c: str) -> bool:
    return _is_id_start(c) or _is_digit(c)


def _lex(src: str, lang: str = 'en') -> list:
    """返回 (kind, value, line, pos) 四元组列表，pos 是 Token 起始偏移。

    lang='zh'（language 中文）时额外把中文拼写认成关键字——见 ZH_CANON。"""
    kws = _kw_set(lang)
    toks = []
    i, n, line = 0, len(src), 1
    while i < n:
        c = src[i]
        if c == '\n':
            line += 1
            i += 1
            continue
        if c in ' \t\r':
            i += 1
            continue
        if c == '#':                      # 注释到行末
            while i < n and src[i] != '\n':
                i += 1
            continue
        if src[i:i + 2] == '/*':          # C 风格块注释（AI 从 C/JS 抄代码常写）：到 */ 为止
            end = src.find('*/', i + 2)
            if end < 0:
                toks.append(('ERR', '/*', line, i))
                i += 2
                continue
            line += src.count('\n', i, end)
            i = end + 2
            continue
        if c == '@':
            toks.append(('AT', '@', line, i))
            i += 1
            continue
        if c == '"':
            j = i + 1
            val = []
            closed = False
            while j < n:
                ch = src[j]
                if ch == '\n':
                    break
                if ch == '"':
                    closed = True
                    break
                if ch == '\\' and j + 1 < n:
                    nxt = src[j + 1]
                    if nxt == 'n':
                        val.append('\n')
                    elif nxt == 'r':
                        val.append('\r')
                    elif nxt == 't':
                        val.append('\t')
                    elif nxt == '\\':
                        val.append('\\')
                    elif nxt == '"':
                        val.append('"')
                    elif nxt == "'":
                        val.append("'")
                    else:
                        val.append('\\')
                        val.append(nxt)   # 未知转义原样保留（兼容 Windows 路径等）
                    j += 2
                    continue
                val.append(ch)
                j += 1
            if not closed:
                raise PybkError(f"第 {line} 行：字符串未闭合")
            toks.append(('STR', ''.join(val), line, i))
            i = j + 1
            continue
        if _is_digit(c):                  # 整数或小数
            j = i
            while j < n and _is_digit(src[j]):
                j += 1
            if j + 1 < n and src[j] == '.' and _is_digit(src[j + 1]):
                j += 1
                while j < n and _is_digit(src[j]):
                    j += 1
            toks.append(('NUM', src[i:j], line, i))
            i = j
            continue
        if _is_id_start(c):               # 标识符 / 关键字（允许中文）
            j = i
            while j < n and _is_id_char(src[j]):
                j += 1
            w = src[i:j]
            if lang == 'zh' and w in ZH_PHRASE_SPLIT:
                # 中文短语（not in → 不属于）：拆成两个关键字 token
                for _pt in ZH_PHRASE_SPLIT[w]:
                    toks.append(('KW', _pt, line, i))
                i = j
                continue
            toks.append(('KW' if w in kws else 'NAME', w, line, i))
            i = j
            continue
        if src[i:i + 2] in TWO_OPS:
            toks.append(('OP', src[i:i + 2], line, i))
            i += 2
            continue
        if c in SINGLE_OPS:
            toks.append(('OP', c, line, i))
            i += 1
            continue
        # 非法字符：占位，交给上层在正确位置报错（见文件头说明）
        toks.append(('ERR', c, line, i))
        i += 1
    last_line = toks[-1][2] if toks else 1   # EOF 行号锚定在最后一条真实代码行
    toks.append(('EOF', '', last_line, i))
    return toks


def tokenize(src: str, lang: str = 'en') -> list[Token]:
    """返回 Token 流。ns.show(...) 的裸文本里可能含任意字符（$、！等），
    它们在词法层是 ERR 占位符；tokenize 无上下文、无法判断是否在裸文本区，
    因此这里跳过 ERR，非法字符的完整校验由 parse() 带行号抛出。"""
    toks = _lex(src, lang)
    return [Token(k, v, ln) for k, v, ln, _ in toks if k != 'ERR']


# ---------------------------------------------------------------- AST

@dataclass
class NumLit:  value: int | float; line: int
@dataclass
class StrLit:  value: str; line: int
@dataclass
class StrParts: parts: list; line: int                 # "得分 $分" 插值：[(TEXT/VAR, ...)]
@dataclass
class BoolLit: value: bool; line: int
@dataclass
class VarRef:  name: str; line: int
@dataclass
class BinOp:   op: str; left: object; right: object; line: int   # + - * / % // == != < > <= >= and or
@dataclass
class Unary:   op: str; operand: object; line: int               # - not
@dataclass
class Call:    name: str; args: list; line: int                  # list.名字(实参)
@dataclass
class InputExpr: prompt: str; line: int                          # input("提示")
@dataclass
class Ret:     expr: object; line: int                           # ret 表达式 或裸 ret
@dataclass
class VgAssign: name: str; expr: object; line: int; type_annot: str = None  # vg.名=表达式（可选 :类型 注解）
@dataclass
class IpAssign: name: str; prompt: str; line: int                # vg(ip).名=input("提示")
@dataclass
class GoldDel: kind: str; name: str; line: int                   # lock(名) / del(名)
@dataclass
class MemoryMode: mode: int; line: int                           # Memoryment@模式  0=自动 1=手动
@dataclass
class DeviceMode: backend: int; threads: int; line: int          # device auto|cpu|gpu [N]  0=auto 1=cpu 2=gpu
@dataclass
class JitMode: on: int; threshold: int; line: int                # jit on|off [阈值]  VM JIT 旋钮（C 后端忽略）
@dataclass
class NsShow:  parts: list; magic: list; line: int; vc_cond: object = None; vc_alt: list = field(default_factory=list)   # 短vc：vc:条件?(替代内容)
@dataclass
class HmStmt:  kind: str; parts: list; arg: str; magic: list; line: int   # 网页输出分支：kind='big'/'mid'/'show'/'img'/'line'/'link'
@dataclass
class HmDraw: cmd: str; params: list; line: int
# cmd: 'begin' 'end' 'color' 'circle' 'rect' 'line' 'clear' 'text' 'img_draw' 'img_scaled'
# params: 各命令的参数表达式列表
@dataclass
class HmFrame: body: list; line: int            # web.帧 {...}：一帧动画（块内是 web.draw.* 语句）
@dataclass
class HmPlay:  speed: object; line: int         # web.播放(速度)：以 速度(帧/秒) 循环播放之前的所有帧
@dataclass
class HmLive:  body: list; fps: object; line: int  # web.实时 {...}：浏览器里逐帧实时跑的块（fps=None 默认 60）
@dataclass
class HmBlockDef: name: str; params: list; body: list; line: int  # web.块 名字(参数) {...}：页面组件定义
@dataclass
class HmUse:    name: str; args: list; line: int   # web.名字(实参)：展开已定义的组件
@dataclass
class TestCheck: cond: object; name: str; line: int  # 查(条件, "名字")：测试断言
@dataclass
class HmPageStmt: name: str; body: list; line: int  # web.页("名") {...}：子页面（烤成独立 HTML）
@dataclass
class GoStmt:  direction: str; distance: object; speed: object; line: int
# direction: '右'/'左'/'上'/'下'（或 right/left/up/down）；distance/speed 是表达式
@dataclass
class ClassDef: name: str; props: list; methods: list; line: int; parent: str = None; ctor_params: list = field(default_factory=list); static_fields: list = field(default_factory=list); static_methods: list = field(default_factory=list)          # props: [(属性名, 默认表达式或 None)]
@dataclass
class Member:   base: object; attr: str; line: int                        # 表达式位置：实例.属性（可链式）
@dataclass
class MethodCall: base: object; name: str; args: list; line: int          # 实例.方法(实参)

# 方法式字符串糖：成员方法名 → 库调用名（键=方法名，值=完整库名，参数个数=库参数）
# x.大写() → te.大写(x)：第一个参数是接收者自身，所以匹配条件是 len(args) == 库参数-1
_LIB_PREFIXES = {'set', 'list', 'dict', 'te', 'mt', 'mp', 'np', 'tb', 'rd',
                 'file', 'csv', 'js', 'net', 'http', 'tm', 'bs', 're', 'sym',
                 'safe', 'smoke', 'obj', '表', '图', '接线', '测试', 'sym'}

_STR_METHODS = {
    '长度': 'te.len', 'len': 'te.len',
    '大写': 'te.upper', 'upper': 'te.upper',
    '小写': 'te.lower', 'lower': 'te.lower',
    '去空': 'te.trim', 'trim': 'te.trim',
    '切分': 'te.split', 'split': 'te.split',
    '替换': 'te.replace', 'replace': 'te.replace',
    '含': 'te.has', 'has': 'te.has',
    '截取': 'te.cut', 'cut': 'te.cut',
    '拼接': 'te.join', 'join': 'te.join',
    '文本': 'te.str', 'str': 'te.str',
}
@dataclass
class AssignMember: base: object; attr: str; expr: object; line: int      # self.属性/vg.实例.属性 = 表达式
@dataclass
class AssignStatic: class_name: str; name: str; expr: object; line: int    # lb.类名.静态字段 = 表达式
@dataclass
class CtorExpr: class_name: str; line: int; pos_args: list = field(default_factory=list); kwargs: list = field(default_factory=list)
@dataclass
class StaticCall: class_name: str; name: str; args: list; line: int
@dataclass
class StaticRef: class_name: str; name: str; line: int                  # lb.类名(属性=值, ...)
@dataclass
class Around:  times: object; body: list; line: int; var: str = 'at'   # rm.around(X)[-> 名]{...}
@dataclass
class ForIn:   var: str; iter: object; body: list; line: int; var2: str = None
@dataclass
class TryCatch:
    body: list; var: str; handler: list; line: int
    var2: str = None      # catch e, t：t 拿错误类型
    etype: str = None     # catch e:类型：只捕获该类型的错
    fin: list = None      # finally {...}（None = 没有 finally）
@dataclass
class OnError:  body: list; var: str; handler: list; line: int   # onerror err {...}：整个程序兜底
@dataclass
class Throw:
    msg: object; etype: object; line: int   # throw / throw "消息" / throw "消息", "类型"
     # for x in 列表 / for 键, 值 in 字典 {...}：逐个取元素（列表可装对象）
@dataclass
class Aging:   cond: object; body: list; line: int               # rm.aging.while(条件){...}
@dataclass
class WhileStmt: cond: object; body: list; line: int             # while(条件){...}：条件为真才继续
@dataclass
class BreakStmt: line: int                                       # break/断：跳出当前层循环
@dataclass
class ContinueStmt: line: int                                   # continue/继续：跳到当前层循环的下一轮
@dataclass
class CdBlock: priority: int; body: list; line: int              # when {...}if(数字)
@dataclass
class VcChain: arms: list; line: int                             # [(条件或None, body), ...]
@dataclass
class FnDef:   name: str; params: list; body: list; line: int; defaults: dict = None; param_types: dict = None; return_type: str = None
     # defaults: {参数名: 默认值节点}——调用可省略尾参
@dataclass
class MacroDef: name: str; params: list; body: list; line: int   # 宏 名(参数){...}：编译期内联展开（非函数调用）
@dataclass
class Lambda:  params: list; body: list; line: int; n: int = 0
     # mec lambda：lambda(参数) { 语句 } 表达式，求值为可调用值（函数名）
     # n = 生成期编号（编译器预扫描时填），降级为顶层 C 函数 __mec_lam_n
@dataclass
class ListLit: items: list; line: int                           # [表达式, ...]
@dataclass
class Index:   base: object; index: object; line: int           # 名字[表达式]
@dataclass
class Slice:   base: object; start: object; stop: object; step: object; line: int   # 名字[a:b:step]，任一段可缺省
@dataclass
class DictLit: pairs: list; line: int                    # {"键": 值, ...}（键为任意表达式）
@dataclass
class SetLit: items: list; line: int                     # {值, 值, ...} 集合字面量
@dataclass
class DictComp: key: object; val: object; vars: list; iter: object; cond: object; line: int
                                                              # {键: 值 for k[, v] in 源 if 条件}
@dataclass
class Ternary: cond: object; then: object; els: object; line: int   # 条件 ? 成立 : 不成立
@dataclass
class Comp:    expr: object; var: str; iter: object; cond: object; line: int    # [表达式 for x in 列表 if 条件]
@dataclass
class MultiAssign: targets: list; values: list; line: int       # vg.a, vg.b = 值1, 值2（右边先算完，支持交换）
@dataclass
class AssignIndex: name: str; index: object; expr: object; line: int   # vg_ro.名[i]=表达式
@dataclass
class Program: meta: str; fns: list; go_body: list; classes: list = None; imports: list = None; macros: list = None; mode: str = None; hard_allow: list = None   # 引用("名") → [(名, 行号)]；宏 名(参数){...} → [MacroDef]；mode = errorstopped 严格度（hard/normal/simple，None 等同 normal）；hard_allow = hard 豁免名单（函数名）


# ---------------------------------------------------------------- 语法分析

CMP_OPS = ('==', '!=', '<', '>', '<=', '>=')

GO_DIRECTIONS = ('右', '左', '上', '下', 'right', 'left', 'up', 'down')

# 游戏零件内置调用：名字 -> 参数个数（key/win/clear/color/box/show/wait/end）
GAME_CALLS = {'key': 1, 'hit': 1, 'win': 3, 'clear': 0, 'color': 3,
              'box': 4, 'show': 0, 'wait': 1, 'end': 0,
              '字': 4, '图': 3, '图缩': 5, '图翻': 6, '绘': 1,
              '线': 4, '点': 2,
              'text': 4, 'img': 3, 'imgs': 5, 'line': 4, 'dot': 2,
              '圆': 3, 'circle': 3, 'mx': 0, 'my': 0, 'mdown': 0, 'mhit': 0,
              'dirkeys': 0, 'frame': 0, 'sec': 0}

# 标准库模块调用：全名（前缀.函数）-> 参数个数。
# te/mt/rd 实现在 pybook_lib.c（rt_lib_te_* 等），list 扩展见 pybook_rt.h，
# file 见 pybook_file.c。前端解析成 Call('te.split', ...) 普通节点。
LIB_PREFIXES = ('te', 'mt', 'rd', 'list', 'file', 'tm', '音', '调色板', 'mu', 'palette', 'http', 'net', 'chat', 'crypto', 'hw', 'np', 'tb', 'mp', 'ui', 'dict', 'js', 'csv', 'mm', 'bs', 'm3', 'smoke', 're', 'ffi', 'mec', 'tensor', '测试', 'obj', '接线', 'wire', 'sym', '图', '表', 'plt', 'tbl', 'set', 'vg', 'vg_ro', 'ns', 'rm', 'lb', 'ip', 'web')

# ── 中英别名：同一库函数可「中文名」也可「英文名」调用 ───────────────────────
# 规范名仍是 LIB_CALLS 里的键（英文或中文）。这里把「另一种语言形态」重定向到规范名，
# 解析时 _lib_call / parse_list_call 会先查 LIB_ALIASES，所以生成代码完全不变（C 后端零回归）。
# 纯英文模块（te/mt/list/...）自动按 token 翻译出中文别名；sym 是中文规范名，显式补英文别名。
# obj/mm/接线/音/调色板/图/表 等模块本身已是中英双键，无需再别名。
_LIB_ALIAS_TOK = {
    # 通用
    'and': '与', 'or': '或', 'xor': '异或', 'not': '非', 'shl': '左移', 'shr': '右移',
    'popcount': '位数', 'band': '位与', 'mask': '掩码', 'hex': '十六进制', 'bin': '二进制',
    'frombin': '从二进制', 'fromhex': '从十六进制',
    'sine': '正弦', 'tri': '三角', 'play': '播放', 'stop': '停止',
    'get': '取', 'set': '设', 'at': '于', 'int': '整数', 'float': '浮点', 'pick': '抽取',
    'shuffle': '乱序', 'seed': '种子', 'parse': '解析', 'dump': '导出',
    'listen': '监听', 'accept': '接受', 'connect': '连接', 'recv': '接收',
    'readline': '读行', 'send': '发送', 'close': '关闭', 'code': '码', 'err': '错误',
    'header': '头', 'headers': '头集', 'config': '配置',
    'check': '检查', 'deleted': '已删除', 'locked': '已锁', 'type': '类型', 'mem': '内存',
    'leak': '泄漏', 'dangling': '悬空', 'roots': '根', 'heap': '堆', 'errors': '错误',
    'mode': '模式', 'selftest': '自检', 'expect': '期望', 'require': '要求',
    # 字符串 te.*
    'split': '分割', 'replace': '替换', 'trim': '去空格', 'upper': '转大写',
    'lower': '转小写', 'has': '包含', 'len': '长度', 'cut': '截取', 'join': '连接',
    'chr': '字符', 'str': '转文本', 'tryline': '试读行',
    # 数学 mt.*
    'sqrt': '开方', 'pow': '乘方', 'abs': '绝对值', 'ceil': '向上取整', 'floor': '向下取整',
    'mod': '取模', 'max': '最大', 'min': '最小', 'prod': '连乘', 'sum': '求和',
    'sin': '正弦', 'cos': '余弦', 'tan': '正切', 'pi': '圆周率', 'lerp': '插值',
    'dist': '距离', 'clamp': '钳制', 'deriv': '求导', 'integrate': '积分', 'root': '求根',
    'bisect': '二分', 'newton': '牛顿', 'taylor': '泰勒', 'exp': '指数', 'expm1': '指数减一',
    'log': '对数', 'log2': '对数2', 'log10': '对数10', 'log1p': '对数加一',
    'asin': '反正弦', 'acos': '反余弦', 'atan': '反正切', 'atan2': '反正切2',
    'sinh': '双曲正弦', 'cosh': '双曲余弦', 'tanh': '双曲正切',
    'asinh': '反双曲正弦', 'acosh': '反双曲余弦', 'atanh': '反双曲正切',
    'cbrt': '立方根', 'hypot': '勾股', 'trunc': '向零取整', 'sign': '符号',
    'fmod': '浮点取模', 'is_nan': '是否NaN', 'is_inf': '是否无穷',
    'lgamma': '对数伽马', 'erf': '误差函数', 'erfc': '互补误差函数',
    'gamma': '伽马函数', 'zeta': '黎曼ζ', 'golden': '黄金分割', 'interp': '插值',
    'linfit': '线性拟合', 'polyfit': '多项式拟合', 'rand': '随机', 'median': '中位数',
    'mode': '众数', 'quantile': '分位数', 'percentile': '百分位数', 'cov': '协方差',
    'corr': '相关性', 'cumsum': '累积和', 'diff': '差分',
    # 列表 list.* / dict.*
    'sort': '排序', 'sorted': '排序后', 'rsorted': '逆序排序后', 'reverse': '反转',
    'unique': '去重', 'merge': '合并', 'byfield': '按字段', 'find': '查找',
    'flat': '展平', 'zip': '配对', 'count': '计数', 'keys': '键集', 'values': '值集',
    'byvalue': '按值',
    # 数组 np.* / tensor.*
    'zeros': '零矩阵', 'range': '范围', 'add': '加', 'sub': '减', 'mul': '乘',
    'scale': '缩放', 'dot': '点乘', 'norm': '范数', 'normalize': '归一化', 'mean': '均值',
    'mat': '矩阵', 'vec': '向量', 'cross': '叉乘', 'transpose': '转置',
    'identity': '单位', 'inverse': '逆', 'det': '行列式', 'eig': '特征', 'svd': '奇异值',
    'lu': 'LU分解', 'qr': 'QR分解', 'lstsq': '最小二乘', 'cholesky': '乔列斯基',
    'cond': '条件数', 'rank': '秩', 'logdet': '对数行列式', 'solve': '求解',
    'from': '从', 'to_list': '转列表', 'cast': '转换', 'prec': '精度', 'slice': '切片',
    'read': '读', 'write': '写', 'exists': '存在', 'lines': '行集', 'del': '删除',
    'size': '大小', 'list': '列出',
    # 3D / UI / 测试 hw.* ui.*
    'open': '打开', 'clearcolor': '清屏色', 'camera': '相机', 'box': '盒', 'fog': '雾',
    'far': '远', 'wire': '线框', 'line': '线', 'light': '光', 'sphere': '球', 'cyl': '柱',
    'fov': '视场角', 'near': '近', 'ortho': '正交', 'tex': '贴图', 'texuse': '用贴图',
    'uv': 'UV', 'push': '压入', 'pop': '弹出', 'shader': '着色器', 'preset': '预设',
    'shaderuse': '用着色器', 'uni': 'uniform', 'frame': '帧', 'end': '结束', 'key': '按键',
    'hit': '命中', 'mx': '鼠标X', 'my': '鼠标Y', 'mdown': '鼠标按下', 'mhit': '鼠标命中',
    'rdown': '右键按下', 'rhit': '右键命中', 'text': '文字', 'textc': '居中文字',
    'rect': '矩形', 'post': '后处理', 'postfx': '后效', 'obj': '物体', 'objinfo': '物体信息',
    'objfix': '物体修正', 'objcolor': '物体颜色', 'objdraw': '物体绘制',
    'objdrawr': '物体旋转绘制', 'objfree': '物体释放', 'objh': '物体高度', 'bloom': '泛光',
    'particles': '粒子', 'particles_clear': '粒子清空', 'burst': '爆发', 'shadow': '阴影',
    'shadowres': '阴影分辨率', 'shadowarea': '阴影区域', 'shadowbias': '阴影偏移',
    'shadowcenter': '阴影中心', 'grab': '抓取', 'free': '释放', 'wheel': '滚轮',
    'wininfo': '窗口信息', 'resize': '调整大小', 'begin': '开始', 'row': '行', 'col': '列',
    'gap': '间距', 'tag': '标签', 'label': '标签', 'button': '按钮', 'input': '输入',
    'slider': '滑条', 'check': '勾选', 'table': '表格',
    # 张量/线性代数 tb.* / mp.*
    'mat32': '矩阵32', 'rand32': '随机32', 'gpu': '显卡', 'gpuname': '显卡名',
    'rows': '行数', 'cols': '列数', 'tr': '转置', 'addrow': '加行', 'relu': '线性整流',
    'relu_grad': '线性整流梯度', 'sigmoid': 'S型', 'sigmoid_grad': 'S型梯度',
    'mse': '均方误差', 'mse_grad': '均方误差梯度', 'lin': '线性层', 'lin_dx': '线性层输入梯度',
    'lin_dw': '线性层权重梯度', 'lin_db': '线性层偏置梯度', 'step': '步',
    'softmax': '柔性最大', 'softmax_grad': '柔性最大梯度', 'crossent': '交叉熵',
    'crossent_grad': '交叉熵梯度', 'argmax': '最大下标', 'sgd': '随机梯度下降',
    'adam': 'Adam优化', 'onehot': '独热', 'batch': '批次', 'conv2d': '二维卷积',
    'conv2d_dx': '二维卷积输入梯度', 'conv2d_dk': '二维卷积核梯度',
    'conv2d_db': '二维卷积偏置梯度', 'maxpool': '最大池化', 'maxpool_dx': '最大池化输入梯度',
    'avgpool': '平均池化', 'avgpool_dx': '平均池化输入梯度', 'dropout': '丢弃',
    'dropout_dx': '丢弃输入梯度', 'batchnorm': '批归一化', 'batchnorm_dx': '批归一化梯度',
    'layernorm': '层归一化', 'layernorm_dx': '层归一化梯度',
    'interp_linear': '线性插值', 'interp_cubic': '三次插值', 'rand_exponential': '指数随机',
    'rand_poisson': '泊松随机', 'rand_geom': '几何随机', 'rand_binom': '二项随机',
    'rand_gamma': '伽马随机', 'rand_beta': '贝塔随机', 'rand_lognormal': '对数正态随机',
    'rand_logistic': '逻辑随机', 'rand_seed': '随机种子', 'rand_u01': '01均匀随机',
    'rand_normal': '正态随机', 'vec_add': '向量加', 'vec_sub': '向量减',
    'vec_scale': '向量缩放', 'vec_dot': '向量点乘', 'vec_norm': '向量范数',
    'vec_dist': '向量距离', 'vec_cross': '向量叉乘', 'vec_lerp': '向量插值',
    'mat_add': '矩阵加', 'mat_scale': '矩阵缩放', 'mat_mul': '矩阵乘',
    'mat_transpose': '矩阵转置', 'mat_identity': '矩阵单位', 'mat_det': '矩阵行列式',
    'mat_inverse': '矩阵逆', 'mat_vec_mul': '矩阵向量乘', 'mat_lu': '矩阵LU',
    'mat_solve': '矩阵求解', 'mat_qr': '矩阵QR', 'mat_svd': '矩阵奇异值',
    'mat_eig_sym': '矩阵对称特征', 'mat_cholesky': '矩阵乔列斯基', 'mat_ls': '矩阵最小二乘',
    'mat_rank': '矩阵秩', 'mat_cond': '矩阵条件数', 'mat_logdet': '矩阵对数行列式',
    'to_tensor': '转张量', 'var': '方差', 'std': '标准差', 'minmax': '最值',
    'linspace': '线性空间', 'smoothstep': '平滑阶跃', 'radians': '转弧度', 'degrees': '转角度',
}


def _zh_name(name: str) -> str:
    """把下划线分隔的英文函数名按 token 翻成中文（未登录的 token 原样保留）。"""
    return ''.join(_LIB_ALIAS_TOK.get(t, t) for t in name.split('_'))


LIB_ALIASES = {}
_LIB_ALIASES_BUILT = False


def _ensure_aliases() -> None:
    """惰性构建别名表（只在首次解析前跑一次）。纯英文模块自动生成中文别名；
    sym 是中文规范名，显式补英文别名。obj/mm/接线 等本就中英双键，跳过。"""
    global LIB_ALIASES, _LIB_ALIASES_BUILT
    if _LIB_ALIASES_BUILT:
        return
    zh_prefixes = set()
    for k in LIB_CALLS:
        _, n = k.split('.', 1)
        if any(ord(c) > 127 for c in n):
            zh_prefixes.add(k.split('.', 1)[0])
    for k in LIB_CALLS:
        p, n = k.split('.', 1)
        if p in zh_prefixes:
            continue  # 这些模块已有中文规范名（且常配英文键），不走自动翻译
        if any(ord(c) > 127 for c in n):
            continue
        zh = _zh_name(n)
        if not zh or zh == n:
            continue
        alias = p + '.' + zh
        if alias in LIB_CALLS or alias in LIB_ALIASES:
            continue
        LIB_ALIASES[alias] = k
    # sym 是中文规范名，补英文别名（英文输入 → 中文规范名）
    LIB_ALIASES.update({
        'sym.parse': 'sym.解析', 'sym.diff': 'sym.求导', 'sym.integrate': 'sym.积分',
        'sym.simplify': 'sym.化简', 'sym.expand': 'sym.展开', 'sym.eval': 'sym.求值',
        'sym.vars': 'sym.变量', 'sym.subst': 'sym.替换', 'sym.equal': 'sym.相等',
        'sym.solve': 'sym.求解', 'sym.format': 'sym.格式',
        'sym.solve_system': 'sym.解方程组', 'sym.limit': 'sym.极限', 'sym.series': 'sym.级数',
    })
    # re 是英文规范名，补中文别名（中文输入 → 英文规范名）
    LIB_ALIASES.update({
        're.匹配': 're.match', 're.查找': 're.find', 're.替换': 're.sub',
        're.有效': 're.valid', 're.分组': 're.groups',
    })
    _LIB_ALIASES_BUILT = True


LIB_CALLS = {
    # mec.*（Modernized_code：lambda 分发 + 类型查询，实现在生成代码 rt_mec_apply / pybook_lib.c）
    'mec.apply': 2, 'mec.kind': 1,
    'te.split': 2, 'te.replace': 3, 'te.trim': 1, 'te.upper': 1, 'te.lower': 1,
    'te.has': 2, 'te.len': 1, 'te.cut': 3, 'te.join': 2, 'te.chr': 1,
    # smoke.*（Smokeroor：实战型安全检查，全英文 API）
    'smoke.check': 1, 'smoke.deleted': 1, 'smoke.locked': 1, 'smoke.type': 1,
    'smoke.mem': 0, 'smoke.leak': 0, 'smoke.dangling': 0, 'smoke.roots': 0,
    'smoke.heap': 0, 'smoke.errors': 0, 'smoke.mode': 0, 'smoke.selftest': 0,
    'smoke.gc_stats': 0, 'smoke.frame_end': 0,
    'smoke.expect': 2, 'smoke.require': 2,
    # re.*（正则：零依赖自研引擎，实现见 pybook_re.c）
    're.match': 2, 're.find': 2, 're.sub': 3, 're.valid': 1, 're.groups': 2,
    # ffi.*（底层窗口：直接调 C 函数/系统 API——编译期展开成 C 调用）
    'ffi.包含': 1, 'ffi.链接': 1, 'ffi.声明': 1, 'ffi.码': 1, 'ffi.调用': 1,   # ffi.调用 实际变参，元数检查特判
    'mt.sqrt': 1, 'mt.pow': 2, 'mt.abs': 1, 'mt.ceil': 1, 'mt.floor': 1,
    'mt.mod': 2, 'mt.max': 1, 'mt.min': 1, 'mt.prod': 1, 'mt.sum': 1, 'mt.sin': 1,
    'mt.cos': 1, 'mt.tan': 1, 'mt.pi': 0,
    'mt.lerp': 3, 'mt.dist': 4, 'mt.clamp': 3,
    'rd.int': 2, 'rd.float': 0, 'rd.pick': 1, 'rd.shuffle': 1,
    'list.sort': 1, 'list.sorted': 1, 'list.rsorted': 1, 'list.reverse': 1, 'list.unique': 1, 'list.merge': 2, 'list.byfield': 3,
    'list.find': 2, 'list.max': 1, 'list.min': 1,
    'file.read': 1, 'file.write': 2, 'file.add': 2, 'file.exists': 1,
    'file.lines': 1, 'file.del': 1,
    'file.size': 1, 'file.list': 1, 'file.split': 2, 'file.join': 2,
    'tm.stop': 2, 'tm.now': 0,
    'net.listen': 1, 'net.accept': 1, 'net.connect': 2,
    'net.recv': 1, 'net.readline': 1, 'net.send': 2, 'net.close': 1,
    'net.udp': 1, 'net.sendto': 4, 'net.recvfrom': 1, 'net.recvfrom_wait': 1,
    # crypto.*（加密：SHA-256 / HMAC / PBKDF2 / ChaCha20，实现见 pybook_crypto.c）
    'crypto.随机': 1, 'crypto.random': 1,
    'crypto.摘要': 2, 'crypto.digest': 2,
    'crypto.派生': 4, 'crypto.derive': 4,
    'crypto.签名': 2, 'crypto.sign': 2,
    'crypto.加密': 3, 'crypto.encrypt': 3,
    'crypto.解密': 3, 'crypto.decrypt': 3,
    # te.读行 / te.试读行（终端读行；中文名由别名表自动生成：读行 / 试读行）
    'te.readline': 1, 'te.tryline': 0,
    # chat.*（跨网终端聊天：中继 + 端到端加密客户端，实现见 pybook_net.c）
    'chat.中继': 1, 'chat.relay': 1,
    'chat.加入': 5, 'chat.join': 5,
    'chat.说': 2, 'chat.say': 2,
    'chat.听': 2, 'chat.listen': 2,
    'chat.跑': 1, 'chat.run': 1,
    'http.get': 1, 'http.code': 0,
    'http.listen': 1, 'http.serve': 1, 'http.req': 1, 'http.resp': 4,
    'http.post': 3,
    # 客户端配套：err / header / headers 读上一次请求的结果，config 设默认超时与请求头
    'http.err': 0, 'http.header': 1, 'http.headers': 0, 'http.config': 1,
    'mu.sine': 2, 'mu.tri': 2, 'mu.play': 1, 'mu.stop': 0,
    'hw.open': 3, 'hw.clearcolor': 3, 'hw.camera': 5, 'hw.box': 9,
    'hw.fog': 2, 'hw.far': 1, 'hw.wire': 1,
    'hw.line': 9, 'hw.light': 4,
    'hw.sphere': 7, 'hw.cyl': 9, 'hw.fov': 1, 'hw.near': 1, 'hw.ortho': 1,
    'hw.tex': 2, 'hw.texuse': 1, 'hw.uv': 1,
    'hw.push': 6, 'hw.pop': 0,
    'hw.shader': 3, 'hw.preset': 2, 'hw.shaderuse': 1, 'hw.uni': 2,
    'hw.frame': 0, 'hw.end': 0, 'hw.key': 1, 'hw.hit': 1,
    'hw.mx': 0, 'hw.my': 0, 'hw.mdown': 0, 'hw.mhit': 0,
    'hw.rdown': 0, 'hw.rhit': 0, 'hw.text': 4,
    'hw.textc': 7, 'hw.rect': 7,
    'hw.post': 1, 'hw.postfx': 2,
    'hw.obj': 1, 'hw.objinfo': 1, 'hw.objfix': 2, 'hw.objcolor': 4,
    'hw.objdraw': 5, 'hw.objdrawr': 8, 'hw.objfree': 1, 'hw.objh': 3,
    'hw.bloom': 2,
    'hw.particles_clear': 0, 'hw.burst': 11, 'hw.particles': 1,
    'hw.shadow': 1, 'hw.shadowres': 1, 'hw.shadowarea': 1,
    'hw.shadowbias': 1, 'hw.shadowcenter': 3,
    'ui.begin': 3, 'ui.row': 0, 'ui.col': 0, 'ui.end': 0, 'ui.gap': 1,
    'ui.tag': 1, 'ui.label': 2, 'ui.button': 1, 'ui.input': 1,
    'ui.slider': 3, 'ui.check': 2, 'ui.table': 4,
    # 交互注入（2026-08 新增）：让 PYbook 自己脚本化"点一下/按住不放"，
    # 把 ui.* 的交互也变成可回归的。原先只能人手点窗口，UI 状态机改了没回归可跑。
    'ui.测试输入': 4, 'ui.测试输入恢复': 0, 'ui.矩形': 1, 'ui.分组': 1,
    'ui.样式': 1, 'ui.字格': 1,
    # 离屏（3D + UI 同屏）：UI 不开窗，渲进内存 surface 交给 3D 贴上去
    'ui.离屏': 2,
    # 图片：静态图 + 序列动画（序列模板里必须带 %d 帧号占位符）
    'ui.图': 3, 'ui.序列': 6,
    # 粒子：ui.粒子(宽,高,每帧发射数,R,G,B) / ui.粒子调(重力,阻力,速度,大小,寿命)
    'ui.粒子': 6, 'ui.粒子调': 5,
    # hw.ui：0 参 = 全屏贴；1 参 = 右侧栏宽；4 参 = (x,y,w,h) 子矩形
    'hw.ui': (0, 4),
    'hw.grab': 0, 'hw.free': 0, 'hw.mdx': 0, 'hw.mdy': 0, 'hw.wheel': 0,
    'hw.wininfo': 0, 'hw.resize': 2,
    'np.zeros': 1, 'np.range': 3, 'np.add': 2, 'np.sub': 2, 'np.mul': 2,
    'np.scale': 2, 'np.dot': 2, 'np.norm': 1, 'np.normalize': 1,
    'np.max': 1, 'np.min': 1, 'np.sum': 1, 'np.mean': 1,
    'np.sin': 1, 'np.cos': 1, 'np.sqrt': 1,
    # np.* 逐元素超越函数批量版（实现在 pybook_np.c）：统计/拟合场景不用逐个循环了
    'np.exp': 1, 'np.log': 1, 'np.log2': 1, 'np.log10': 1,
    'np.expm1': 1, 'np.log1p': 1,
    'np.tan': 1, 'np.atan': 1, 'np.cbrt': 1,
    'np.erf': 1, 'np.erfc': 1, 'np.gamma': 1, 'np.lgamma': 1,
    'np.abs': 1, 'np.floor': 1, 'np.ceil': 1, 'np.round': 1, 'np.sign': 1,
    'np.pow': 2,
    'te.str': 1, 'dict.keys': 1, 'dict.values': 1, 'dict.byvalue': 2,
    'dict.get': 3, 'dict.set': 3, 'dict.max': 1, 'dict.min': 1,
    # bs.* 位运算（实现在 pybook_bits.c）
    'bs.and': 2, 'bs.or': 2, 'bs.xor': 2, 'bs.not': 1,
    'bs.shl': 2, 'bs.shr': 2, 'bs.get': 2, 'bs.set': 3,
    'bs.popcount': 1, 'bs.band': 1, 'bs.mask': 1,
    'bs.hex': 1, 'bs.bin': 1, 'bs.frombin': 1, 'bs.fromhex': 1,
    # m3.* MyMove3D 体素建模
    'm3.color': 4, 'm3.texture': 2, 'm3.pack': 1, 'm3.uv': 1,
    'm3.glass': 5, 'm3.glow': 4, 'm3.metal': 4, 'm3.style': 5,
    'm3.draw': 5, 'm3.drawr': 8,
    'm3.anim': 6, 'm3.animr': 9,
    'm3.save': 2, 'm3.load': 1,
    'm3.merge': 5, 'm3.dig': 4, 'm3.put': 5,
    'm3.bounds': 1, 'm3.count': 1,
    'm3.stair': 3, 'm3.slab': 3, 'm3.wall': 4, 'm3.pillar': 2,
    'm3.roof': 3, 'm3.fence': 2,
    'set.新': 0, 'set.添加': 2, 'set.删掉': 2, 'set.含': 2, 'set.长度': 1, 'set.列表': 1,
    'safe.get': 3, 'js.parse': 1, 'js.dump': 1, 'csv.parse': 1, 'csv.dump': 1, 'mm.色': 4, 'mm.color': 4, 'mm.draw_away': 3, 'mm.贴': 4, 'mm.blt': 4, 'mm.动': 5, 'mm.anim': 5, 'mm.存': 2, 'mm.save': 2, 'mm.读': 1, 'mm.load': 1, 'mm.转': 2, 'mm.xform': 2, 'mm.描边': 2, 'mm.outline': 2, 'mm.平铺': 3, 'mm.tile': 3, 'mm.拼': 3, 'mm.paste': 3, 'mm.渐变': 4, 'mm.grad': 4, 'mm.反色': 1, 'mm.invert': 1,  'list.flat': 1, 'list.zip': 2, 'list.count': 2, 'safe.at': 3,
    # obj.* 3D 建模 -> .obj 落盘（mm 的 3D 姊妹篇；VM/C 双后端）
    'obj.清': 0, 'obj.clear': 0,
    'obj.点': 3, 'obj.vertex': 3,
    'obj.面': 3, 'obj.face': 3,
    'obj.面4': 4, 'obj.quad': 4,
    'obj.块': 6, 'obj.box': 6,
    'obj.球': 5, 'obj.sphere': 5,
    'obj.柱': 6, 'obj.cyl': 6,
    'obj.存': 1, 'obj.save': 1,
    'obj.点数': 0, 'obj.vcount': 0,
    'obj.面数': 0, 'obj.fcount': 0,
    # 接线.* / wire.* 接线式测试（联动功能三档验证：通/扰/危；VM/C 双后端）
    '接线.接': 1, 'wire.tap': 1,
    '接线.迹': 0, 'wire.trace': 0,
    '接线.迹数': 0, 'wire.tcount': 0,
    '接线.例': 3, 'wire.case': 3,
    '接线.边界': 1, 'wire.edge': 1,
    '接线.乱序': 2, 'wire.shuffle': 2,
    '接线.脏串': 1, 'wire.dirtystr': 1,
    '接线.脏数': 1, 'wire.dirtynum': 1,
    '接线.脏表': 1, 'wire.dirtylist': 1,
    '接线.炸': 2, 'wire.boom': 2,
    '接线.快照': 0, 'wire.snap': 0,
    '接线.对照': 1, 'wire.diff': 1,
    '接线.报': 0, 'wire.report': 0,
    '接线.败数': 0, 'wire.fails': 0,
    '接线.清': 0, 'wire.clear': 0,
    'ui.按钮': 5, 'ui.输入框': 5, 'ui.滑条': 6,
    'tb.mat': 2, 'tb.rand': 2, 'tb.rows': 1, 'tb.cols': 1,
    # float32 一等公民 + 设备查询（GPU 通路只吃 f32；tb.gpu 让程序自己问跑在哪）
    'tb.mat32': 2, 'tb.rand32': 2, 'tb.gpu': 0, 'tb.gpuname': 0,
    'tb.dot': 2, 'tb.tr': 1, 'tb.add': 2, 'tb.mul': 2, 'tb.addrow': 2,
    'tb.relu': 1, 'tb.relu_grad': 1, 'tb.sigmoid': 1, 'tb.sigmoid_grad': 1,
    'tb.mse': 2, 'tb.mse_grad': 2,
    'tb.lin': 3, 'tb.lin_dx': 3, 'tb.lin_dw': 2, 'tb.lin_db': 1,
    'tb.step': 3,
    'tb.softmax': 1, 'tb.crossent': 2, 'tb.crossent_grad': 2, 'tb.argmax': 1,
    'tb.sgd': 3, 'tb.adam': 8,
    'tb.shuffle': 2, 'tb.onehot': 2, 'tb.batch': 3,
    'tb.save': 2, 'tb.load': 1,
    # ---- tb 训练算子：卷积/池化/归一化（实现在 pybook_tb.c）----
    'tb.conv2d': 6, 'tb.conv2d_dx': 7, 'tb.conv2d_dk': 7, 'tb.conv2d_db': 2,
    'tb.maxpool': 4, 'tb.maxpool_dx': 5, 'tb.avgpool': 4, 'tb.avgpool_dx': 5,
    'tb.dropout': 4, 'tb.dropout_dx': 4,
    'tb.batchnorm': 8, 'tb.batchnorm_dx': 5,
    'tb.layernorm': 4, 'tb.layernorm_dx': 5,


    # ---- 数值微积分与求根（(最少,最多) = 可选参数，缺省由 codegen 补空盒）----
    'mt.deriv': (2, 3),
    'mt.integrate': (3, 4),
    'mt.root_bisect': (3, 4),
    'mt.root_newton': (2, 4),
    'mt.root_newton_d': (3, 5),
    'mt.taylor': (3, 3),

    # ---- 特殊函数（gamma 族 / erf 族 / Riemann zeta）----
    'mt.lgamma': 1,

    # ---- 特殊函数（gamma 族 / erf 族 / Riemann zeta）----
    'mt.erf': 1,
    'mt.erfc': 1,
    'mt.gamma': 1,
    'mt.zeta': 1,

    # ---- 一维极值：黄金分割（不依赖梯度）----
    'mt.golden_min': (2, 4),
    'mt.golden_max': (2, 4),

    # ---- 插值与拟合（采样点必须严格递增，否则显式报错）----
    'mp.interp_linear': 3,
    'mp.interp_cubic': 3,
    'mp.linfit': 2,
    'mp.polyfit': 3,

    # ---- 随机分布（与 mp.rand_*/rd.* 共用同一个 xorshift128）----
    'mp.rand_exponential': 1,
    'mp.rand_poisson': 1,
    'mp.rand_geom': 1,
    'mp.rand_binom': 2,
    'mp.rand_gamma': 2,
    'mp.rand_beta': 2,
    'mp.rand_lognormal': 2,
    'mp.rand_logistic': 2,

    # ---- 统计补齐（此前只有 mean/var/std/minmax/sum）----
    'mp.median': 1,
    'mp.mode': 1,
    'mp.quantile': 2,
    'mp.percentile': 2,
    'mp.cov': 2,
    'mp.corr': 2,
    'mp.cumsum': 1,
    'mp.diff': 1,
    'rd.seed': 1,

    # ---- 符号数学 sym.*（表达式树：解析/求导/积分/化简/展开/求值，见 pybook_sym.c）----
    # 全部 字符串进、字符串出（求值出数值）；不会积返回空串，与报错区分
    'sym.解析': 1,
    'sym.求导': 2,
    'sym.积分': 2,
    'sym.化简': 1,
    'sym.展开': 1,
    'sym.求值': 2,        # (公式, 绑定串)：无绑定传 ""，如 sym.求值("2^10", "")
    'sym.变量': 1,
    'sym.替换': 3,
    'sym.相等': 2,
    'sym.求解': 2,        # (方程, 变量)：解单变量多项式，升序实根
    'sym.格式': 2,        # (表达式, 模式)：plain/latex/unicode 渲染
    'sym.解方程组': 2,    # (方程串, 变量串)：线性方程组精确解
    'sym.极限': 3,        # (表达式, 变量, 点)：点可写数字/pi/e/算式或 inf/-inf
    'sym.级数': 4,        # (表达式, 变量, 点, 阶数)：泰勒展开 + O 余项

    # ---- 基础数学补齐：exp/log 族、反三角、双曲、符号与特判（v2.0 只有 sin/cos/tan/atan2，连 exp 和 log 都没有）----
    'mt.exp': 1,
    'mt.expm1': 1,
    'mt.log': 1,
    'mt.log2': 1,
    'mt.log10': 1,
    'mt.log1p': 1,
    'mt.asin': 1,
    'mt.acos': 1,
    'mt.atan': 1,
    'mt.sinh': 1,
    'mt.cosh': 1,
    'mt.tanh': 1,
    'mt.asinh': 1,
    'mt.acosh': 1,
    'mt.atanh': 1,
    'mt.cbrt': 1,
    'mt.hypot': 2,
    'mt.trunc': 1,
    'mt.sign': 1,
    'mt.fmod': 2,
    'mt.is_nan': 1,
    'mt.is_inf': 1,

    # ---- 线性代数（核心在 pybook_la.c，与 NumPy.linalg 对照到 2e-14）----
    'tb.lu': 1,
    'tb.solve': 2,
    'tb.det': 1,
    'tb.logdet': 1,
    'tb.inv': 1,
    'tb.cond': 1,
    'tb.rank': 1,
    'tb.qr': 1,
    'tb.lstsq': 2,
    'tb.cholesky': 1,
    'tb.eig_sym': 1,
    'tb.svd': 1,
    'mp.vec_add': 2, 'mp.vec_sub': 2, 'mp.vec_scale': 2, 'mp.vec_dot': 2,

    # ---- 线性代数的扁平列表面（内部先包成张量再算，与 tb.* 同一份实现）----
    'mp.mat_lu': 2,
    'mp.mat_solve': 3,
    'mp.mat_qr': 3,
    'mp.mat_svd': 3,
    'mp.mat_eig_sym': 2,
    'mp.mat_cholesky': 2,
    'mp.mat_ls': 4,
    'mp.mat_rank': 2,
    'mp.mat_cond': 2,
    'mp.mat_logdet': 2,
    'mp.to_tensor': 3,
    'mp.vec_norm': 1, 'mp.vec_dist': 2, 'mp.vec_cross': 2, 'mp.vec_lerp': 3,
    'mp.mat_add': 4, 'mp.mat_scale': 4, 'mp.mat_mul': 5, 'mp.mat_transpose': 3,
    'mp.mat_identity': 1, 'mp.mat_det': 2, 'mp.mat_inverse': 2, 'mp.mat_vec_mul': 4,
    'mp.mean': 1, 'mp.var': 2, 'mp.std': 2, 'mp.sum': 1, 'mp.minmax': 1,
    'mp.linspace': 3,
    'mp.clamp': 3, 'mp.smoothstep': 3, 'mp.lerp': 3, 'mp.radians': 1, 'mp.degrees': 1,
    'mp.rand_seed': 1, 'mp.rand_u01': 0, 'mp.rand_normal': 2,
    'mt.atan2': 2,
    '音.正弦': 2, '音.三角': 2, '音.放': 1, '音.停': 0, '音.快': 3,
    '音.音': 3, '音.奏': 3, '音.谱': 2, '音.音量': 1, '音.包络': 4, '音.包络值': 2, '音.乐器': 1, '音.乐器表': 0, '音.演': 2, 
    # 调色板.颜色名：零参调用，返回新建的 [r,g,b] 列表（内置常量色表）
    '调色板.红': 0, '调色板.橙': 0, '调色板.黄': 0, '调色板.绿': 0,
    '调色板.青': 0, '调色板.蓝': 0, '调色板.紫': 0, '调色板.白': 0,
    '调色板.黑': 0, '调色板.灰': 0, '调色板.粉': 0, '调色板.金': 0,
    # tensor.* 张量一等类型（实现在 pybook_rt.c：rt_tensor_get/set/slice/from_list/to_list）
    'tensor.get': 3, 'tensor.set': 4, 'tensor.slice': 5,
    'tensor.from': 1, 'tensor.to_list': 1,
    'tensor.cast': 2, 'tensor.prec': 1,
    # 测试.*（测试框架标准库：断言走 rt_test_check，复用 查() 的失败计数/退出码）
    '测试.断言相等': 2, '测试.断言不等': 2, '测试.断言真': 1, '测试.断言假': 1,
    '测试.断言抛出': 1,
    # ---- 图.* 图表与函数图像 / 表.* 表格（实现见 pybook_plot.c）----

    '图.画布': 2,
    'plt.canvas': 2,
    '图.画布色': 3,
    'plt.canvasbg': 3,
    '图.清': 2,
    'plt.clear': 2,
    '图.存': 2,
    'plt.save': 2,
    '图.尺寸': 1,
    'plt.size': 1,
    '图.像素': 4,
    'plt.pixel': 4,
    '图.读像素': 3,
    'plt.at': 3,
    '图.线': 7,
    'plt.line': 7,
    '图.框': 7,
    'plt.rect': 7,
    '图.圆': 6,
    'plt.circle': 6,
    '图.字': 6,
    'plt.text': 6,
    '图.轴': 8,
    'plt.axis': 8,
    '图.折线': 5,
    'plt.polyline': 5,
    '图.散点': 5,
    'plt.scatter': 5,
    '图.柱状': 4,
    'plt.bar': 4,
    '图.直方': 4,
    'plt.hist': 4,
    '图.饼图': 3,
    'plt.pie': 3,
    '图.图例': 4,
    'plt.legend': 4,
    '图.色板': 0,
    'plt.palette': 0,
    '图.试值': 2,
    'plt.eval': 2,
    # sym 接入：导数 / 切线 / 渐近线 / 面积（见 pybook_plot.c）
    '图.导数': 5,
    'plt.deriv': 5,
    '图.切线': 5,
    'plt.tangent': 5,
    '图.渐近线': 4,
    'plt.asym': 4,
    '图.面积': 6,
    'plt.area': 6,
    '图.曲线': 6,
    'plt.fx': 6,
    '图.函数': 6,
    'plt.fun': 6,
    '表.画': 2,
    'tbl.show': 2,
    '表.宽': 1,
    'tbl.size': 1,
    '表.列': 2,
    'tbl.col': 2,
    '表.行': 2,
    'tbl.row': 2,
    '表.格': 3,
    'tbl.cell': 3,
    '表.转': 1,
    'tbl.transpose': 1,
    '表.选': 3,
    'tbl.slice': 3,
    '表.排': 3,
    'tbl.sort': 3,
    '表.并': 2,
    'tbl.concat': 2,
    '表.接': 2,
    'tbl.hconcat': 2,
    '表.统': 4,
    'tbl.stats': 4,
    '表.补': 2,
    'tbl.fill': 2,
}

# key(...) 合法键名：英文键名 + 中文键名 + 单字母 a-z
KEY_NAMES = ({'right', 'left', 'up', 'down', 'space', 'enter', 'esc', 'shift',
              '右', '左', '上', '下', '空格', '回车'}
             | {chr(c) for c in range(ord('a'), ord('z') + 1)})


class _Parser:
    def __init__(self, src: str, base: str = None, root: str = None,
                 lang: str = None):
        self.src = src
        # 引用() 的解析基准目录 / 命名空间根目录（都缺省时用主文件所在目录）
        self._import_base = base
        self._import_root = root
        self._class_props = {}     # 类名 -> 属性名集合（语义检查用）
        self._class_defs = {}      # 类名 -> ClassDef（继承链解析用）
        self._pending_ctors = []   # CtorExpr 节点，parse_program 末尾统一校验
        self._hoisted_classes = [] # 语句位置的单行类定义（提升到程序类表）
        self._frame_count = 0      # 已解析的 web.帧 数（web.播放 语义检查用）
        self.hm_blocks = {}        # 组件名 -> HmBlockDef（web.块 定义，先定义后使用）
        self._mem_self = False     # 当前是否处于 @self 内存模式（控制 vg. 声明可省）
        self._hw_on = False        # 3D_highway 模块：ON 3D_highway 之后才可用 hw.*
        self._mode = None          # errorstopped 严格度：hard/normal/simple（None 等同 normal）
        self._hard_allow = None    # hard 豁免名单（errorstopped 行尾「豁免 函数名1, 函数名2」）
        self._window_open = False  # window(normal, open) 框架模式
        self.loop_depth = 0        # 循环嵌套深度（break 只能在循环内使用的检查用）
        # 语言模式：文件自己的 language 指令 > 项目语言（主文件定的，模块继承）
        self.lang = lang or _detect_lang(src) or _LANG_MODE
        self.toks = _lex(src, self.lang)
        self.i = 0

    # ---- 基础工具 ----

    def cur(self):
        return self.toks[self.i]

    def kind(self):
        return self.toks[self.i][0]

    def val(self):
        return self.toks[self.i][1]

    def line(self):
        return self.toks[self.i][2]

    def err(self, msg: str):
        raise PybkError(f"第 {self.line()} 行：{msg}", self.lang)

    def advance(self):
        k, v, ln, _p = self.toks[self.i]
        if k == 'ERR':
            raise PybkError(f"第 {ln} 行：非法字符 {v!r}")
        self.i += 1
        return self.toks[self.i - 1]

    def expect(self, kind: str, value=None):
        k, v, ln, _p = self.cur()
        if k == 'ERR':
            raise PybkError(f"第 {ln} 行：非法字符 {v!r}")
        if k != kind or (value is not None and self._canon(v) != value):
            want = value if value is not None else kind
            self.err(f"期望 {want!r}，实际是 {v if v else k!r}")
        return self.advance()

    def _kwset(self):
        """本文件当前模式认成关键字的词（插值等子解析器也要用同一套）。"""
        return _kw_set(self.lang)

    def _canon(self, v: str) -> str:
        """中文模式：中文拼写折回规范名（英文模式原样返回）。

        规范名是英文——parser 里所有比较都按规范名做，所以折回之后
        「如果」和「if」走同一条代码路径，后端也只见过规范名。"""
        if self.lang != 'zh':
            return v
        return ZH_CANON.get(v, v)

    def at(self, kind: str, value=None) -> bool:
        k, v, _ln, _p = self.cur()
        return k == kind and (value is None or self._canon(v) == value)

    def sync_to(self, pos: int):
        """跳过起始位置在 pos 之前的所有 Token（越过裸文本区域用）。"""
        while self.toks[self.i][0] != 'EOF' and self.toks[self.i][3] < pos:
            self.i += 1

    def scan_raw(self, start: int, what: str):
        """从源码 start 位置扫到配对的 ')'（支持括号嵌套），返回 (文本, 右括号偏移)。

        扫描时必须跳过字符串字面量和 # 注释：它们里面的 ( ) 不是括号。
        不跳的话 ns.show("(") 这种一行就能把整份程序算成「缺少右括号」，
        而且报错指到 ns.show 调用上，跟真正写错的地方八竿子打不着；
        ns.show("a)b") 也会在 ')' 处被提前截断成 "a"。
        转义（反斜杠 + 字符）要跟着一起跳过，否则 \" 会把串提前关掉。
        """
        depth = 0
        i = start
        n = len(self.src)
        while i < n:
            ch = self.src[i]
            if ch == '"':
                i += 1
                while i < n and self.src[i] != '"':
                    if self.src[i] == '\\':
                        i += 1
                    i += 1
                i += 1                    # 越过闭引号（没闭合也交给词法层去报）
                continue
            if ch == '#':
                while i < n and self.src[i] != '\n':
                    i += 1
                continue
            if ch == '(':
                depth += 1
            elif ch == ')':
                if depth == 0:
                    return self.src[start:i], i
                depth -= 1
            i += 1
        raise PybkError(f"第 {self.line()} 行：{what} 缺少右括号 )")

    # ---- 文件 ----

    def parse_program(self, require_going: bool = True) -> Program:
        """require_going=True 主文件（GOING 必须有）；False 模块单元
        （被引用的 .pybk：GOING 可有可无、有也被忽略；允许顶层 vg）。"""
        self.require_going = require_going
        meta = '未命名'
        # language 是编译期旋钮：允许写在 @ 元信息行**之前**（语言模式要在词法前定，
        # 放第一行最自然）。这里先吃掉它，后面的 @ 元信息行照旧当元信息行；
        # 反过来写也行（@ 在前、language 在后 → 走下面语句循环里的 language 分支）。
        if self.at('KW', 'language'):
            self.parse_language()
        if self.at('AT'):               # @ 元信息行可选：不写按未命名处理
            at = self.expect('AT')
            nl = self.src.find('\n', at[3])
            meta_end = len(self.src) if nl < 0 else nl
            meta = self.src[at[3] + 1:meta_end].strip()
            self.sync_to(meta_end)      # 跳过 @ 行上被切出的杂散 Token
        fns = []
        mems = []
        classes = []
        imports = []
        macros = []
        pending_decorators = []   # @名 收集器：紧随其后的 func 被包
        init_stmts = []   # 模块模式的顶层 vg：编译器把它们合并进主文件当初始化
        require_going = getattr(self, 'require_going', True)
        while True:
            if self.at('EOF'):
                if require_going:
                    self.err("文件必须包含恰好一个 GOING 块")
                break                   # 模块单元到文件尾正常结束
            if self.at('AT', '@') and self.toks[self.i + 1][0] == 'NAME' and \
                    self.toks[self.i + 2][:2] == ('OP', '>'):
                # @ 元信息行（@ 分类>名>版）出现在顶层循环里（如 Memoryment@7 写在它前面）：
                # 原来会死于「GOING 之后不应有内容」之外的莫名错，现在就地认领、更新 meta。
                at = self.expect('AT')
                nl = self.src.find('\n', at[3])
                meta_end = len(self.src) if nl < 0 else nl
                self.meta = self.src[at[3] + 1:meta_end].strip()
                self.sync_to(meta_end)
                continue
            if self.at('AT', '@') and self.toks[self.i + 1][0] == 'NAME'                     and not (self.toks[self.i + 2][0] == 'OP' and self.toks[self.i + 2][1] == '>'):
                # 装饰器：@宏名 换行 func 名(...){...} —— 编译期糖。
                # 语义：函数体首插入 Call(宏名, [文本(函数名)])，
                # 既有的宏展开器会把宏体就地展开进函数体——宏的形参
                # 收到的是函数名字符串，配合 $插值/宏语句即可做 前奏+尾声。
                at_ln = self.cur()[2]
                self.advance()
                dname = self.expect('NAME')[1]
                if self.at('OP', '('):
                    self.advance()
                    if not self.at('OP', ')'):
                        self.parse_expr()
                        while self.at('OP', ','):
                            self.advance()
                            self.parse_expr()
                    self.expect('OP', ')')
                pending_decorators.append((dname, at_ln))
                continue
            if self.at('KW', 'lb'):
                classes.append(self.parse_class())
            elif self.at('KW', 'func'):
                f = self.parse_func()
                while pending_decorators:
                    dname, dln = pending_decorators.pop()
                    f.body.insert(0, Call(dname, [StrLit(f.name, f.line)], dln))
                fns.append(f)
            elif self.at('KW', '宏') or self.at('KW', 'macro'):
                macros.append(self.parse_macro())
            elif self.at('KW', 'Memoryment'):
                mems.append(self.parse_memoryment())
            elif self.at('KW', 'window'):
                self.parse_window()
            elif self.at('KW', 'ON'):
                self.parse_on()
            elif self.at('KW', 'errorstopped'):
                self.parse_errorstopped()
            elif self.at('KW', 'device'):
                mems.append(self.parse_device())
            elif self.at('KW', 'jit'):
                mems.append(self.parse_jit())
            elif self.at('KW', 'language'):
                self.parse_language()      # 纯编译期旋钮：不产生 AST 节点
            elif self.at('KW', '引用'):
                imports.append(self.parse_import())
            elif self.at('KW', 'web'):
                self.parse_hm_blockdef()
            elif self.at('KW', 'ffi'):
                # top-level ffi.* directives (low-level window): compile-time, file head
                stmt = self.parse_expr()
                if not (isinstance(stmt, Call) and stmt.name.startswith('ffi.')):
                    self.err("顶层只接受 ffi. 开头的底层指令：ffi.包含/ffi.链接/ffi.声明/ffi.码/ffi.调用")
                init_stmts.append(stmt)
            elif not require_going and (self.at('KW', 'vg') or self.at('KW', 'vg_ro')):
                is_ro = self.at('KW', 'vg_ro')
                init_stmts.append(self.parse_vg('vg_ro' if is_ro else 'vg'))
            elif self.at('KW', 'GOING'):
                if require_going:
                    break          # 主文件：跳出循环，GOING 由循环后统一解析
                go_body = self.parse_going()
                if not self.at('EOF'):
                    self.err("模块文件里 GOING 之后不应再有内容")
                break
            else:
                if require_going:
                    # 中文模式下「函数f」这类粘连会吃掉整个定义（词法层分不开），
                    # 只报「没有 GOING 块」会让人完全摸不着头脑——把粘连点破。
                    _k2, _v2 = self.cur()[0], self.cur()[1]
                    _g = _zh_glue_hint(_v2) if _k2 == 'NAME' else ''
                    if _g:
                        self.err("文件必须包含恰好一个 GOING 块\n  " + _g.strip())
                    self.err("文件必须包含恰好一个 GOING 块")
                self.err("模块文件顶层只能是 引用/func/vg/lb/Memoryment/device/language")
        if require_going:
            go_body = self._重排onerror(self.parse_going())
            go_body = mems + init_stmts + go_body   # top-level ffi.* lands in front of GOING
            if not self.at('EOF'):
                self.err("GOING 块之后不应再有内容")
        else:
            go_body = mems + init_stmts   # 模块初始化语句（vg 顶层赋值）
        self._class_defs.update({cd.name: cd for cd in classes})
        self._class_defs.update({cd.name: cd for cd in (self._hoisted_classes or [])})
        for node in self._pending_ctors:      # 语义检查：类须存在、属性名须一致（含继承）
            if node.class_name not in self._class_defs:
                raise PybkError(f"第 {node.line} 行：未定义的类 {node.class_name!r}")
            eff = set(self._eff_props(node.class_name))
            for kwn, _e in node.kwargs:
                if kwn not in eff:
                    raise PybkError(
                        f"第 {node.line} 行：类 {node.class_name!r} 没有属性 {kwn!r}")
        classes.extend(self._hoisted_classes)  # 语句位置定义的单行类并入类表
        prog = Program(meta, fns, go_body, classes)
        prog.imports = imports
        prog.macros = macros
        prog.hm_blocks = self.hm_blocks
        prog.window_open = 1 if self._window_open else 0
        prog.mode = getattr(self, '_mode', None)   # errorstopped 文件头指令（None=normal）
        prog.hard_allow = getattr(self, '_hard_allow', None)   # hard 豁免名单（函数名）
        return prog

    def parse_language(self):
        """language english | language 中文：语言模式旋钮（文件头指令）。

        纯编译期：语言模式在**词法之前**就定了（见 _detect_lang），词法层
        已经按这个模式认过字了。所以本指令不进 AST——没有运行期语义，
        也不生成任何 C 代码（后端完全看不见它）。

        校验两件事：档位认不认识；本文件出现多个 language 时档位是否一致
        （不一致说明用户以为「后写的覆盖前面的」，实际不是那样，报错更清楚）。
        """
        tok = self.expect('KW', 'language')
        kwlen = len(tok[1])                       # 'language' 长度
        nl = self.src.find('\n', self.toks[self.i - 1][3])
        end = len(self.src) if nl < 0 else nl
        rest = self.src[self.toks[self.i - 1][3] + kwlen:end].strip()
        self.sync_to(end)                         # 行尾杂散 Token 整段跳过
        head = rest.split()
        # 报错行号指到 language 指令自己那一行（self.err 用的是「当前 Token」的行号，
        # 而指令行已经被整段跳过了，会指到下一行——差一行就找不着地方了）。
        if not head or head[0] not in ('english', '中文'):
            raise PybkError(f"第 {tok[2]} 行：language 只支持 english / 中文，收到：{rest!r}")
        if len(head) > 1:
            raise PybkError(f"第 {tok[2]} 行：language 后面只能跟一个档位，收到：{rest!r}")
        want = 'zh' if head[0] == '中文' else 'en'
        if want != self.lang:
            raise PybkError(f"第 {tok[2]} 行：同一文件里 language 档位不一致"
                            f"（本文件按 {self.lang} 解析，这一行写的是 {head[0]}）")
        return None

    def parse_on(self):
        """ON 3D_highway：模块开关。ON 之后到行尾整段扫过（模仿 @ 元信息行，
        避免词法器把 3D_highway 切成数字），去空白后必须等于 3D_highway。"""
        ln = self.expect('KW', 'ON')[2]
        nl = self.src.find('\n', self.toks[self.i - 1][3])
        end = len(self.src) if nl < 0 else nl
        rest = self.src[self.toks[self.i - 1][3] + 2:end].strip()
        self.sync_to(end)           # 行尾的杂散 Token（如被切碎的标识符）整段跳过
        if rest != '3D_highway':
            self.err(f"目前只有 3D_highway 模块")
        self._hw_on = True

    def parse_errorstopped(self):
        """errorstopped hard|normal|simple：严格度旋钮（文件头指令，模仿 ON）。
        整行扫过，取 hard / normal / simple 之一；缺省 normal。
        优先级：文件头 errorstopped > 编译器 --mode > 环境变量 PYBOOK_MODE。"""
        tok = self.expect('KW', 'errorstopped')
        kwlen = len(tok[1])                       # 'errorstopped' 长度
        nl = self.src.find('\n', self.toks[self.i - 1][3])
        end = len(self.src) if nl < 0 else nl
        rest = self.src[self.toks[self.i - 1][3] + kwlen:end].strip()
        self.sync_to(end)                         # 行尾杂散 Token 整段跳过
        head = rest.split(None, 1)
        if not head or head[0] not in ('hard', 'normal', 'simple'):
            self.err(f"errorstopped 只支持 hard / normal / simple（可选后缀：豁免 函数名1, 函数名2），收到：{rest!r}")
        self._mode = head[0]
        self._hard_allow = None
        if len(head) == 2:                    # errorstopped hard 豁免 函数1, 函数2：整行扫过，不进词法器
            tail = head[1].strip()
            for kw in ('豁免', 'allow'):
                if tail == kw or tail.startswith(kw + ' ') or tail.startswith(kw + '\t'):
                    names = tail[len(kw):].strip()
                    self._hard_allow = [x.strip() for x in names.replace('，', ',').split(',') if x.strip()]
                    break
            else:
                self.err(f"errorstopped 后只支持档位或「豁免 函数名1, 函数名2」，收到：{rest!r}")

    def parse_device(self):
        """device auto|cpu|gpu [线程数]：设备后端旋钮（文件头指令，模仿 ON / errorstopped）。

        整行扫过（auto/cpu/gpu 都是普通标识符，不走词法器）。
        返回 DeviceMode 节点 —— 跟 MemoryMode 一样走「语句」路线，两条后端各自
        emit 成 rt_device_set()，语义天然一致；且会被前置到 GOING 开头，
        保证在第一次用到线程池之前就设好。

        档位：auto(0) 默认=探测到卡就用卡 / cpu(1) 显式 CPU / gpu(2) 显式上卡。
        编译期只查语法，不查硬件 —— 有没有卡一律运行时探测：
          · gpu 档探测不到卡 → 运行时报错，绝不静默退回 CPU（用户明写了 gpu）
          · auto 档探测不到卡 → 老老实实走 CPU
        线程数：只允许跟在 cpu 后面，0=按机器逻辑处理器数（省略时的默认）。
        """
        tok = self.expect('KW', 'device')
        kwlen = len(tok[1])                        # 'device' 长度
        nl = self.src.find('\n', self.toks[self.i - 1][3])
        end = len(self.src) if nl < 0 else nl
        rest = self.src[self.toks[self.i - 1][3] + kwlen:end].strip()
        self.sync_to(end)                          # 行尾杂散 Token 整段跳过
        if not rest:
            self.err("device 后面要写后端档位：auto / cpu / gpu"
                     "（cpu 可再跟一个线程数，如 device cpu 4）")
        parts = rest.split()
        backend = parts[0]
        if backend not in ('auto', 'cpu', 'gpu'):
            self.err(f"device 只支持 auto / cpu / gpu，收到：{backend!r}")
        threads = 0
        if len(parts) > 1:
            if backend != 'cpu':
                self.err(f"只有 device cpu 能带线程数，收到：{rest!r}")
            if len(parts) > 2:
                self.err(f"device cpu 后面最多跟一个线程数，收到：{rest!r}")
            if not parts[1].isdigit():
                self.err(f"device cpu 的线程数要是整数，收到：{parts[1]!r}")
            threads = int(parts[1])
            if threads < 1 or threads > 1024:
                self.err(f"device cpu 的线程数须在 1~1024，收到 {threads}")
        return DeviceMode({'auto': 0, 'cpu': 1, 'gpu': 2}[backend], threads, tok[2])

    def parse_jit(self):
        """jit on|off [阈值]：VM JIT 旋钮（文件头指令，模仿 device / errorstopped）。

        整行扫过。on=开（阈值缺省 200）/ off=关；阈值 = 函数被调用这么多次后
        批量编译上原生代码（1~1000000）。
        编译成 GOING 首条 JIT 语句（opcode 0x38）送达 pyvm——JIT 触发挂在 CALL 上，
        主程序开头执行本语句时还没有任何调用，时序上永远赶得上。
        优先级：文件头 jit > 命令行 --jit/--no-jit > 环境变量 PYVM_JIT > 默认关。
        JIT 是 VM 专属加速，C 后端编译时忽略本指令（行为与不写一样）。"""
        tok = self.expect('KW', 'jit')
        kwlen = len(tok[1])                       # 'jit' 长度
        nl = self.src.find('\n', self.toks[self.i - 1][3])
        end = len(self.src) if nl < 0 else nl
        rest = self.src[self.toks[self.i - 1][3] + kwlen:end].strip()
        self.sync_to(end)                          # 行尾杂散 Token 整段跳过
        parts = rest.split()
        if not parts or parts[0] not in ('on', 'off'):
            self.err(f"jit 只支持 on / off（on 可再跟阈值 1~1000000，如 jit on 16），收到：{rest!r}")
        on = 1 if parts[0] == 'on' else 0
        threshold = 200
        if len(parts) > 1:
            if not on:
                self.err(f"jit off 不带参数，收到：{rest!r}")
            if len(parts) > 2:
                self.err(f"jit on 后面最多跟一个阈值，收到：{rest!r}")
            if not parts[1].isdigit():
                self.err(f"jit 阈值要是整数，收到：{parts[1]!r}")
            threshold = int(parts[1])
            if threshold < 1 or threshold > 1000000:
                self.err(f"jit 阈值须在 1~1000000，收到 {threshold}")
        return JitMode(on, threshold, tok[2])

    def parse_import(self):
        """引用("名字")：加载 名字.pybk；名字可含子目录（如 "lib/助手"）；必须在 GOING 之前。"""
        ln = self.cur()[2]
        if not (self.at('KW', '引用') or self.at('KW', 'import')):
            self.err('这里是 引用("名") / import("名")')
        self.advance()
        self.expect('OP', '(')
        name = self.expect('STR')[1]
        self.expect('OP', ')')
        self._preload_module_classes(name, ln, _PRELOAD_SEEN,
                                     self._import_base, self._import_root)
        return (name, ln)

    def _preload_module_classes(self, name, ln, seen, base=None, root=None):
        """把模块（及其引用链）的类属性表并进本文件的语义检查，
        主文件里才能通过 类名(属性=...) 构造器的存在性检查。
        路径/解析问题在这里静默放过——正式报错由代码生成期的合并逻辑给出。

        base：解析本模块的基准目录（默认取主文件所在目录）。递归进子模块时
        换成**该模块自己的目录**——这样 lib/助手.pybk 里的 引用("工具") 找的是
        lib/工具.pybk，而不是主文件旁边的 工具.pybk（老实现在这一直是错的：
        整条引用链都按主文件目录找，子目录里的模块根本引不到同目录的兄弟）。
        root：命名空间的根目录（主文件所在目录），用来判断模块算不算「子目录模块」。"""
        if base is None:
            base = root if root is not None else _import_base_dir()
        if root is None:
            root = base
        path = resolve_module_path(base, name)
        if not path or path in seen:
            return
        seen.add(path)
        try:
            with open(path, encoding='utf-8-sig') as fh:
                sub = _parse_module_raw(fh.read(), os.path.dirname(path) or '.', root)
        except Exception:
            return
        # 子目录模块进命名空间：类名带前缀，主文件写 lb.助手_数据表(...)
        rewrite_namespace(sub, module_ns_prefix(path, root))
        sub_base = os.path.dirname(path) or '.'
        # 注意：sub.imports 的元素是 (名字, 行号) 元组，递归时要取 [0]
        for sub_name in getattr(sub, 'imports', None) or []:
            self._preload_module_classes(
                sub_name[0] if isinstance(sub_name, tuple) else sub_name,
                ln, seen, sub_base, root)
        for cd in (sub.classes or []):
            # 类的存在性检查读的是 _class_defs——引用进来的模块类也必须登记，
            # 否则消费方的 lb.类名() 报「未定义的类」（mec/一切带类的包都踩过）。
            if cd.name not in self._class_defs:
                self._class_defs[cd.name] = cd
            if cd.name not in self._class_props:
                self._class_props[cd.name] = [p for p, _d in cd.props]

    # ---- 软类型注解（可选类型标注：只记录、不强制，喂给 --check-json 的软检查）----
    def _parse_type_name(self):
        """读一个类型名：标识符，可选后跟 (内层类型,...)。返回拼好的拼写，如 数字 / 列表(数字)。"""
        if self.cur()[0] == 'NAME':
            base = self.expect('NAME')[1]
        elif self.cur()[0] == 'KW':
            base = self.expect('KW')[1]
        else:
            self.err('类型注解需要一个类型名（如 数字 / 字符串 / 列表）')
        if self.at('OP', '('):
            self.advance()
            args = []
            if not self.at('OP', ')'):
                args.append(self._parse_type_name())
                while self.at('OP', ','):
                    self.advance()
                    args.append(self._parse_type_name())
            self.expect('OP', ')')
            base += '(' + ','.join(args) + ')'
        return base

    def _parse_type(self):
        """当前在 `:` 处读类型注解；不在则返回 None。"""
        if not self.at('OP', ':'):
            return None
        self.advance()
        return self._parse_type_name()

    def _parse_return_type(self):
        """当前在 `->` 处读返回类型注解；不在则返回 None（`->` 在词法层是两个 token: - 与 >）。"""
        if self.at('OP', '-') and self.toks[self.i + 1][:2] == ('OP', '>'):
            self.advance()   # -
            self.advance()   # >
            return self._parse_type_name()
        return None

    def parse_func(self) -> FnDef:
        ln = self.expect('KW', 'func')[2]
        ntok = self.cur()
        if ntok[0] == 'KW' and self._canon(ntok[1]) not in LIB_PREFIXES:
            self.err('函数名不合法')
        if ntok[0] not in ('NAME', 'KW'):   # KW 放行：func mec.map(...) 的 mec 是前缀关键字
            self.err('函数名不合法')
        name = ntok[1]
        self.advance()
        if self.at('OP', '.'):                 # mec 库风格：func mec.名(参数) {...}
            self.advance()
            name = name + '.' + self.expect('NAME')[1]
        self.expect('OP', '(')
        params = []
        defaults = {}
        param_types = {}
        if not self.at('OP', ')'):
            pname = self.expect('NAME')[1]
            pt = self._parse_type()
            if pt is not None:
                param_types[pname] = pt
            params.append(pname)
            if self.at('OP', '='):             # 默认值
                self.advance()
                defaults[pname] = self.parse_expr()
            while self.at('OP', ','):
                self.advance()
                pname = self.expect('NAME')[1]
                pt = self._parse_type()
                if pt is not None:
                    param_types[pname] = pt
                params.append(pname)
                if self.at('OP', '='):
                    self.advance()
                    defaults[pname] = self.parse_expr()
        self.expect('OP', ')')
        return_type = self._parse_return_type()
        if self.at('OP', '='):                 # 单行函数：func f(x) = 表达式
            self.advance()
            # 用 set() 而不是 None 当默认：顶层 func 解析完会把外层值写回来，
            # 若留成 None，之后 GOING 里任何 "表[i] = 值" 都会在 `nm in None` 上崩。
            外层参数 = getattr(self, '_fn参数', set())
            self._fn参数 = set(params)
            body = [Ret(self.parse_expr(), ln)]
            self._fn参数 = 外层参数
            return FnDef(name, params, body, ln, defaults, param_types, return_type)
        外层参数 = getattr(self, '_fn参数', set())
        self._fn参数 = set(params)          # 参数名允许直接下标赋值（冒泡等场景）
        body, _ = self._block()
        self._fn参数 = 外层参数
        return FnDef(name, params, body, ln, defaults, param_types, return_type)

    def parse_macro(self) -> 'MacroDef':
        """宏 名(参数) { ...语句... }：编译期把参数替换后就地展开成语句（非函数调用）。"""
        kw = self.cur()
        if kw[0] == 'KW' and kw[1] in ('宏', 'macro'):
            ln = kw[2]
            self.advance()
        else:
            self.err('宏/macro 定义必须以 宏 或 macro 开头')
        ntok = self.cur()
        if ntok[0] != 'NAME':
            self.err('宏名不合法（应为标识符，如 宏 行(...)）')
        name = ntok[1]
        self.advance()
        self.expect('OP', '(')
        params = []
        if not self.at('OP', ')'):
            params.append(self.expect('NAME')[1])
            while self.at('OP', ','):
                self.advance()
                params.append(self.expect('NAME')[1])
        self.expect('OP', ')')
        dup = set()
        for p in params:
            if p in dup:
                self.err(f"宏 {name!r} 的参数 {p!r} 重复")
            dup.add(p)
        body, _ = self._block()
        return MacroDef(name, params, body, ln)

    def parse_class(self):
        """lb.类名[(构造形参,...)] [ : 父类] { vg.属性[=默认]; 静 vg.静态字段=默认; func 方法(...){...}; 静 func 静态方法(...){...} }"""
        ln = self.expect('KW', 'lb')[2]
        self.expect('OP', '.')
        name = self.expect('NAME')[1]
        if name in self._class_props:
            self.err(f"类 {name!r} 重复定义")
        ctor_params = []
        if self.at('OP', '('):
            self.advance()
            if not self.at('OP', ')'):
                while True:
                    ctor_params.append(self.expect('NAME')[1])
                    if not self.at('OP', ','):
                        break
                    self.advance()
            self.expect('OP', ')')
        parent = None
        if self.at('OP', ':'):
            self.advance()
            parent = self.expect('NAME')[1]
        self.expect('OP', '{')
        props = []
        methods = []
        static_fields = []
        static_methods = []
        while not self.at('OP', '}'):
            if self.at('EOF'):
                self.err("类体缺少收尾的 }")
            is_static = self.at('KW', '静')
            if is_static:
                self.advance()
            if self.at('KW', 'vg') or self.at('KW', 'vg_ro'):
                self.advance()
                self.expect('OP', '.')
                pname = self.expect('NAME')[1]
                default = None
                if self.at('OP', '='):
                    self.advance()
                    default = self.parse_expr()
                if is_static:
                    static_fields.append((pname, default))
                else:
                    props.append((pname, default))
            elif self.at('KW', 'func'):
                m = self.parse_func()
                if is_static:
                    static_methods.append(m)
                else:
                    methods.append(m)
            else:
                self.err("类体里只能是 属性(vg.名)/静态(静 vg.名)/方法(func 名)/静态方法(静 func 名)")
        self.expect('OP', '}')
        self._class_props[name] = {p for p, _d in props}
        if parent is not None:
            self._class_props.setdefault(parent, set())
        self._class_defs[name] = ClassDef(name, props, methods, ln, parent, ctor_params, static_fields, static_methods)
        return self._class_defs[name]

    def _eff_props(self, class_name):
        """本类及全部父类的属性名（去重，子类在后）。"""
        seen = set(); out = []
        c = class_name; guard = 0
        while c is not None and guard < 1000:
            guard += 1
            cd = self._class_defs.get(c)
            if cd is None:
                break
            for p, _ in cd.props:
                if p not in seen:
                    seen.add(p); out.append(p)
            c = cd.parent
        return out

    def parse_class_oneline(self, ln):
        """语句位置的单行类定义：lb.名(属性=默认值, ...)。

        生成与多行 lb.名{ vg.属性=默认值 ... } 完全相同的 ClassDef
        （props 带默认值、methods 为空）；expression 位置的 lb.名(...)
        仍是构造实例，由 parse_primary 负责，互不影响。"""
        self.expect('KW', 'lb')
        self.expect('OP', '.')
        name = self.expect('NAME')[1]
        if name in self._class_props:
            self.err(f"类 {name!r} 重复定义")
        self.expect('OP', '(')
        props = []
        while not self.at('OP', ')'):
            pname = self.expect('NAME')[1]
            self.expect('OP', '=')
            props.append((pname, self.parse_expr()))
            if not self.at('OP', ','):
                break
            self.advance()
        self.expect('OP', ')')
        self._class_props[name] = {p for p, _d in props}
        return ClassDef(name, props, [], ln)

    def parse_self_assign(self):
        """self.属性 = 表达式（支持 self.a.b = ... 链式）"""
        ln = self.expect('KW', 'self')[2]
        base = VarRef('self', ln)
        while self.at('OP', '.'):
            self.advance()
            _k2, v2, l2, _p2 = self.expect('NAME')
            prev, base = base, Member(base, v2, l2)
        self.expect('OP', '=')
        return AssignMember(prev, base.attr, self.parse_expr(), ln)

    def _重排onerror(self, stmts):
        """onerror 包裹 GOING 中它之后的全部语句（嵌套进 body）。"""
        out = []
        i = 0
        while i < len(stmts):
            st = stmts[i]
            if isinstance(st, OnError):
                内层 = self._重排onerror(stmts[i + 1:])
                if 内层:
                    st.body = 内层
                out.append(st)
                return out        # onerror 之后不再有兄弟
            out.append(st)
            i += 1
        return out

    def parse_going(self) -> list:
        self.expect('KW', 'GOING')
        if self.at('OP', ':'):
            self.advance()
        body, rb_line = self._block()
        stop = self.expect('KW', 'STOP')
        if stop[2] != rb_line:
            self.err("STOP 必须紧跟在 } 之后（同一行）")
        return body

    # ---- 语句 ----

    def _block(self):
        self.expect('OP', '{')
        body = []
        while not self.at('OP', '}'):
            if self.at('EOF'):
                self.err("块缺少收尾的 }")
            node = self.parse_stmt()
            if isinstance(node, ClassDef):
                # 语句位置的单行类定义是声明：提升到程序类表，不留在语句流里
                self._hoisted_classes.append(node)
            else:
                body.append(node)
        rb = self.expect('OP', '}')
        return body, rb[2]

    def parse_stmt(self):
        k, v, _ln, _p = self.cur()
        ov = v                           # 用户原文（报错一律用它，别用折回后的规范名）
        if k == 'KW':
            v = self._canon(v)           # 中文模式折回规范名，下面的比较都按规范名
            if v == 'language':
                self.err("language 只能写在文件顶部（GOING 之前），不能在语句里用")
            if v == 'Memoryment':
                return self.parse_memoryment()
            if v == 'vg':
                return self.parse_vg('vg')
            if v == 'vg_ro':
                return self.parse_vg('vg_ro')
            if v == 'ns':
                return self.parse_ns()
            if v == '查':
                ln2 = self.cur()[2]
                self.advance()
                self.expect('OP', '(')
                cond = self.parse_expr()
                self.expect('OP', ',')
                name = self.expect('STR')[1]
                self.expect('OP', ')')
                return TestCheck(cond, name, ln2)
            if v == 'web':
                return self.parse_hm()
            if v == 'rm':
                return self.parse_rm()
            if v == 'when':
                return self.parse_when()
            if v == 'try':
                return self.parse_trycatch()
            if v == 'throw':
                return self.parse_throw()
            if v == 'finally':
                self.err("finally 只能跟在 try/catch 后面")
            if v == 'onerror':
                return self.parse_onerror()
            if v == 'if':
                return self.parse_branch()
            if v == 'while':
                return self.parse_while()
            if v == 'for':
                return self.parse_forin()
            if v in ('break', '断'):
                return self.parse_break(_ln)
            if v in ('continue', '继续'):
                return self.parse_continue(_ln)
            if v == 'ret':
                return self.parse_ret()
            if v in ('lock', 'del'):
                return self.parse_goldel()
            if v == 'set' and self.toks[self.i + 1][:2] == ('OP', '.')                     and self.toks[self.i + 2][0] == 'NAME':
                return self.parse_set_call(_ln)
            if v == 'list' and self.toks[self.i + 1][:2] == ('OP', '.') \
                    and self.toks[self.i + 2][0] == 'NAME' \
                    and self.toks[self.i + 3][:2] == ('OP', '('):
                return self.parse_list_call(_ln)
            if v in ('tw', 'data') and self.toks[self.i + 1][:2] == ('OP', '.') \
                    and self.toks[self.i + 2][0] == 'NAME' \
                    and self.toks[self.i + 3][:2] == ('OP', '('):
                return self.parse_pref_call(v, _ln)
            if v == 'lb' and self.toks[self.i + 1][:2] == ('OP', '.') \
                    and self.toks[self.i + 2][0] == 'NAME' \
                    and self.toks[self.i + 3][:2] == ('OP', '.'):
                e = self.parse_expr()          # lb.类名.静态方法(实参) 作为语句
                if isinstance(e, StaticCall):
                    return e
                if isinstance(e, StaticRef) and self.at('OP', '='):
                    self.advance()              # 吃掉 =
                    return AssignStatic(e.class_name, e.name, self.parse_expr(), e.line)
                self.err(f"不是合法的语句开头：{ov!r}")
            if v == 'lb' and self.toks[self.i + 1][:2] == ('OP', '.') \
                    and self.toks[self.i + 2][0] == 'NAME' \
                    and self.toks[self.i + 3][:2] == ('OP', '('):
                return self.parse_class_oneline(_ln)   # 单行类定义（带默认值）
            if v == 'self':                    # self.属性 = 表达式
                return self.parse_self_assign()
            if v in GAME_CALLS and self.toks[self.i + 1][:2] == ('OP', '('):
                self.advance()                 # show(...)：内置调用名撞关键字的只有它
                return self._game_call(v, _ln)
            if v in LIB_PREFIXES and v != 'list' and self.toks[self.i + 1][:2] == ('OP', '.'):
                e = self.parse_expr()          # te/file 等语句（list 已由上面单独处理）
                if isinstance(e, Call):
                    return e                   # 含 mec.名(...) 用户库函数语句；名字对错交代码生成期
                self.err(f"不是合法的语句开头：{ov!r}")
        if k == 'NAME':                        # 实例.方法(实参) 语句
            if v == 'go' and self.toks[self.i + 1][:2] == ('OP', '('):
                return self.parse_go()         # go(方向, 距离, 速度)：画布整体移动
            nxt = self.toks[self.i + 1][:2]
            if nxt[0] == 'OP' and nxt[1] in ('+', '-', '*', '/', '%')                     and self.toks[self.i + 2][:2] == ('OP', '='):
                self.advance()                 # 名字
                self.advance()                 # 复合运算符的第一半
                self.advance()                 # =
                return VgAssign(v, BinOp(nxt[1], VarRef(v, _ln), self.parse_expr(), _ln), _ln)
            if self._mem_self:                 # @self 模式：允许裸声明（vg. 可省）
                if nxt == ('OP', '='):
                    nm = self.expect('NAME')[1]
                    self.advance()
                    return VgAssign(nm, self.parse_expr(), _ln)
                if nxt == ('OP', '['):
                    nm = self.expect('NAME')[1]
                    self.advance()
                    idx = self.parse_expr()
                    self.expect('OP', ']')
                    self.expect('OP', '=')
                    return AssignIndex(nm, idx, self.parse_expr(), _ln)
            elif nxt == ('OP', '='):
                self.advance()                 # 名字
                tannot = self._parse_type()
                self.advance()                 # =
                return VgAssign(v, self.parse_expr(), _ln, tannot)   # 裸赋值：自动声明
            elif nxt == ('OP', '['):
                nm = self.expect('NAME')[1]
                self.advance()                       # 吃掉 [
                d1 = self._parse_one_dim()
                if self.at('OP', ','):              # 多维赋值：T[i,j] = v
                    self.advance()
                    d2 = self._parse_one_dim()
                    self.expect('OP', ']')
                    if d1[0] != 'i' or d2[0] != 'i':
                        self.err('张量多下标赋值只支持 T[i,j] = 值')
                    self.expect('OP', '=')
                    return Call('tensor.set',
                                [VarRef(nm, _ln), d1[1], d2[1], self.parse_expr()], _ln)
                self.expect('OP', ']')
                if d1[0] != 'i':
                    self.err('仅支持 T[i] = 值 或 T[i,j] = 值（张量切片赋值暂未开放）')
                idx = d1[1]
                if self._mem_self:
                    self.expect('OP', '=')
                    return AssignIndex(nm, idx, self.parse_expr(), _ln)
                if nm in getattr(self, '_fn参数', ()) and not self.at('OP', ','):
                    self.expect('OP', '=')
                    return AssignIndex(nm, idx, self.parse_expr(), _ln)
                if self.at('OP', ','):
                    targets = [Index(VarRef(nm, _ln), idx, _ln)]
                    while self.at('OP', ','):
                        self.advance()
                        k3, v3, _l3, _p3 = self.expect('NAME')
                        targets.append(self._多目标(v3, _ln))
                    self.expect('OP', '=')
                    values = [self.parse_expr()]
                    while self.at('OP', ','):
                        self.advance()
                        values.append(self.parse_expr())
                    if len(values) != len(targets):
                        self.err(f'第 {_ln} 行：多重赋值左右个数不匹配：'
                                 f'{len(targets)} 个目标，{len(values)} 个值')
                    return MultiAssign(targets, values, _ln)
                self.err(f"第 {_ln} 行：变量声明必须以 vg. 开头"
                         f"（规则：新变量写 vg.名 = 值；已声明的变量在其后可裸名赋值；"
                         f"函数参数的元素可直接 表[i] = 值；"
                         f"当前非 self 模式，文件头写 Memoryment@self 可放开限制）")
            elif nxt == ('OP', ','):          # a, b = b, a：裸多重赋值/交换
                self.advance()                # 吃掉首个变量名
                targets = [v]
                while self.at('OP', ','):
                    self.advance()
                    targets.append(self.expect('NAME')[1])
                self.expect('OP', '=')
                values = [self.parse_expr()]
                while self.at('OP', ','):
                    self.advance()
                    values.append(self.parse_expr())
                if len(values) != len(targets) and len(values) != 1:
                    self.err(f'第 {_ln} 行：多重赋值左右个数不匹配：'
                             f'{len(targets)} 个目标，{len(values)} 个值')
                return MultiAssign(targets, values, _ln)
            e = self.parse_expr()
            if isinstance(e, MethodCall):
                return e
            if isinstance(e, Call):
                return e                       # 语句形态的调用：win(...) / 添加(...) / 自定义函数 干活(...)
                # 名字对不对不在这里判 —— 留给代码生成期，那里有完整的 fns 表，
                # 能报出"函数 'X' 未定义"，比这里一律拒掉友好得多。
                # （原实现只放行 GAME_CALLS/LIB_CALLS/内置几个名字，
                #  导致用户自己写的 func 不能当语句调用：干活() 报"不是合法的语句开头"，
                #  必须写 vg.丢弃 = 干活() —— 标准库里的 pool_clear/wc切 全被卡住。）
            if isinstance(e, Member) and self.at('OP', '='):
                self.advance()                 # 实例.属性 = 表达式（含 for-in 循环变量）
                return AssignMember(e.base, e.attr, self.parse_expr(), _ln)
            self.err(f"不是合法的语句开头：{v!r}")
        self.err(f"不是合法的语句开头：{ov if ov else k!r}")

    def parse_goldel(self):
        _k, v, ln, _p = self.advance()
        kind = 'gold' if self._canon(v) == 'lock' else 'del'
        self.expect('OP', '(')
        name = self.expect('NAME')[1]
        self.expect('OP', ')')
        return GoldDel(kind, name, ln)

    def parse_memoryment(self):
        ln = self.expect('KW', 'Memoryment')[2]
        self.expect('AT')
        k, v, _l, _p = self.cur()
        if k in ('NAME', 'KW') and v in ('normal', 'self', 'knewany'):
            mode = 0 if v == 'normal' else (1 if v == 'self' else 7)
            self.advance()
        elif k == 'NUM':
            n = int(v)
            # @1→0 普通  @2→1 手动  @3 引用计数  @4 竞技场  @5 标记清除  @6 分代+增量  @7→7 knewany 看人自适应
            mode = {1: 0, 2: 1, 3: 3, 4: 4, 5: 5, 6: 6, 7: 7}.get(n)
            if mode is None:
                raise PybkError(f"第 {ln} 行：Memoryment 模式 {n} 不支持"
                                f"（支持 1/2/3/4/5/6/7/normal/self/knewany）")
            self.advance()
        else:
            self.err("Memoryment 后要 @normal、@self、@knewany 或 @数字")

        self._mem_self = (mode == 1)
        return MemoryMode(mode, ln)


    def parse_window(self):
        """window(normal, open)：窗口框架模式。

        normal=桌面窗口（web 模式以后另加）；open=框架接管循环：
        GOING 里 win(宽, 高, "标题") 之前的语句只跑一次（初始化），
        之后的语句每帧跑一遍（框架自动 end 退出 / show / 60FPS）；
        全文件允许省略 vg. 前缀。"""
        ln = self.expect('KW', 'window')[2]
        self.expect('OP', '(')
        _k, a1, _l, _p = self.expect('NAME')
        if a1 != 'normal':
            self.err("window 的第一个参数目前只支持 normal（桌面窗口）")
        self.expect('OP', ',')
        _k, a2, _l2, _p2 = self.expect('NAME')
        if a2 != 'open':
            self.err("window 的第二个参数目前只支持 open（框架接管循环）")
        self.expect('OP', ')')
        self._window_open = True
        self._mem_self = True   # 框架模式：赋值可省 vg. 前缀
    def parse_vg(self, kw='vg'):
        ln = self.expect('KW', kw)[2]
        if self.at('OP', '(') and self.toks[self.i + 1][0] == 'KW' \
                and self._canon(self.toks[self.i + 1][1]) == 'ip':
            self.advance()                      # (
            self.advance()                      # ip
            self.expect('OP', ')')
            self.expect('OP', '.')
            name = self.expect('NAME')[1]
            self.expect('OP', '=')
            self.expect('KW', 'input')
            self.expect('OP', '(')
            prompt = self.expect('STR')[1]
            self.expect('OP', ')')
            return IpAssign(name, prompt, ln)
        self.expect('OP', '.')
        name = self.expect('NAME')[1]
        tannot = self._parse_type()
        if self.kind() == 'OP' and self.val() in ('+', '-', '*', '/', '%', '//')                 and self.toks[self.i + 1][:2] == ('OP', '='):
            运 = self.val()
            self.advance()                    # 运算符
            self.advance()                    # =
            return VgAssign(name, BinOp(运, VarRef(name, ln), self.parse_expr(), ln), ln)
        if self.at('OP', ','):                # vg.a, vg.b = 值1, 值2：一行多定义
            targets = [name]
            while self.at('OP', ','):
                self.advance()
                self.expect('KW', kw)         # 逗号后每个目标都带 vg.
                self.expect('OP', '.')
                targets.append(self.expect('NAME')[1])
            self.expect('OP', '=')
            values = [self.parse_expr()]
            while self.at('OP', ','):
                self.advance()
                values.append(self.parse_expr())
            if len(values) != len(targets) and len(values) != 1:
                self.err(f'多重赋值左右个数不匹配：{len(targets)} 个目标，{len(values)} 个值')
            return MultiAssign(targets, values, ln)
        if self.at('OP', '['):                # 名字[下标] = 表达式
            self.advance()
            idx = self.parse_expr()
            self.expect('OP', ']')
            self.expect('OP', '=')
            return AssignIndex(name, idx, self.parse_expr(), ln)
        if self.at('OP', '.'):                # vg.实例.属性 = 表达式（支持链式）
            base = VarRef(name, ln)
            while self.at('OP', '.'):
                self.advance()
                _k2, v2, l2, _p2 = self.expect('NAME')
                prev, base = base, Member(base, v2, l2)
            self.expect('OP', '=')
            return AssignMember(prev, base.attr, self.parse_expr(), ln)
        self.expect('OP', '=')
        return VgAssign(name, self.parse_expr(), ln, tannot)

    def _unescape(self, s):
        """把反斜杠转义解码成真字符（n换行 r回车 t制表 反斜杠 引号 单引号）；未知转义原样保留。"""
        out = []
        i = 0
        n = len(s)
        while i < n:
            ch = s[i]
            if ch == '\\' and i + 1 < n:
                nxt = s[i + 1]
                if nxt == 'n':
                    out.append('\n')
                elif nxt == 'r':
                    out.append('\r')
                elif nxt == 't':
                    out.append('\t')
                elif nxt == '\\':
                    out.append('\\')
                elif nxt == '"':
                    out.append('"')
                elif nxt == "'":
                    out.append("'")
                else:
                    out.append('\\')
                    out.append(nxt)
                i += 2
            else:
                out.append(ch)
                i += 1
        return ''.join(out)

    def parse_ns(self):
        ln = self.expect('KW', 'ns')[2]
        self.expect('OP', '.')
        self.expect('KW', 'show')
        lp = self.expect('OP', '(')
        raw, end = self.scan_raw(lp[3] + 1, 'ns.show')
        # 多参数：顶层逗号（引号外、括号外）切分 → 各段独立插值，输出以空格相连
        段s = self._切顶层逗号(raw, ln)
        if len(段s) > 1:
            parts = []
            for i, 段 in enumerate(段s):
                if i:
                    parts.append(('TEXT', ' '))
                if 段.startswith('"') and 段.endswith('"') and len(段) >= 2:
                    parts += self._split_content(self._unescape(段[1:-1]), ln)
                else:
                    子 = _Parser(段)
                    parts.append(('EXPR', 子.parse_expr()))
        elif not raw.startswith('"') and '$' not in raw and re.search(r'[()\[]', raw):
            # 含括号/方括号才按表达式处理（如 te.join(表, " ")、list.max(数据)）；
            # 其余一律按文字显示（兼容旧式 ns.show(据点失守...) 写法）
            # 单段且像表达式（含括号/运算符/in）→ 按表达式显示；
            # 解析失败自动退回裸文本（兼容旧式 ns.show(据点失守！) 写法）
            try:
                子 = _Parser(raw)
                parts = [('EXPR', 子.parse_expr())]
            except PybkError:
                parts = self._split_content(raw, ln)
        else:
            # 注：raw 里的 / 是插值表达式的除号（/magic 在右括号之后，互不冲突）
            if raw.startswith('"') and raw.endswith('"') and len(raw) >= 2:
                parts = self._split_content(self._unescape(raw[1:-1]), ln)
            else:
                parts = self._split_content(raw, ln)
        self.sync_to(end)
        self.expect('OP', ')')
        magic = []
        j = end + 1
        while j < len(self.src) and self.src[j] in ' \t':
            j += 1
        if self.src[j:j + 1] == '/':            # 可选的 /magic(...)
            self.expect('OP', '/')
            m = self.expect('NAME')
            if m[1] != 'magic':
                self.err(f"ns.show 后只能接 /magic，实际是 {m[1]!r}")
            mlp = self.expect('OP', '(')
            mraw, mend = self.scan_raw(mlp[3] + 1, 'magic')
            magic = self._split_magic(mraw, ln)
            self.sync_to(mend)
            self.expect('OP', ')')
        vc_cond, vc_alt = None, []
        if self.at('KW', 'vc') and self.toks[self.i + 1][:2] == ('OP', ':'):
            self.advance()                      # vc
            self.expect('OP', ':')
            vc_cond = self._or()                # 条件在 ? 之前；不能用 parse_expr——它会把 ? 当三元吃掉
            self.expect('OP', '?')
            lp = self.expect('OP', '(')
            raw, end = self.scan_raw(lp[3] + 1, 'vc: 替代内容')
            vc_alt = self._split_content(raw, ln)   # 规则与主内容一致
            self.sync_to(end)
            self.expect('OP', ')')
        return NsShow(parts, magic, ln, vc_cond, vc_alt)

    def parse_hm_blockdef(self):
        """web.块 名字(参数, ...) { web.* 语句 ... }：页面组件定义（顶层）。
        体里允许段落/标题/图片/控件等页面语句与嵌套 web.组件调用；
        不允许 帧/播放/实时/再定义块（那些依赖 GOING 语境）。"""
        ln = self.expect('KW', 'web')[2]
        self.expect('OP', '.')
        _k, v, _l, _p = self.advance()
        if v != '块':
            self.err(f"顶层 web. 后只能是 块（组件定义），实际是 web.{v!r}")
        name = self.expect('NAME')[1]
        if name in self.hm_blocks:
            self.err(f"第 {ln} 行：web.块 {name!r} 重复定义")
        self.expect('OP', '(')
        params = []
        if not self.at('OP', ')'):
            params.append(self.expect('NAME')[1])
            while self.at('OP', ','):
                self.advance()
                params.append(self.expect('NAME')[1])
        self.expect('OP', ')')
        body, _ = self._block()
        for st in body:
            if isinstance(st, (HmFrame, HmPlay, HmLive, HmDraw, HmPageStmt)):
                raise PybkError(f"第 {st.line} 行：web.块 里不能用 帧/播放/实时/draw/页"
                                "（组件只烤当前页内容，动画写在 GOING，子页用 web.页）")
        self.hm_blocks[name] = HmBlockDef(name, params, body, ln)

    def parse_hm(self):
        """网页输出分支：web.big/mid/show/img/line/link/draw/帧/播放。

        big/mid/show 的内容走 ns.show 同一套裸文本规则（scan_raw 括号嵌套
        计数、$插值/表达式、$吸收）；/magic 只有 show 支持。$名字 的"须已
        声明"检查沿用下游既有路径（VAR 部件原样上交）。帧/播放 组成帧动画。"""
        ln = self.expect('KW', 'web')[2]
        self.expect('OP', '.')
        _k, v, _l, _p = self.advance()
        if v == 'draw':                         # web.draw.始/色/圆/方/线/终：画布绘图
            self.expect('OP', '.')
            _dk, dv, _dl, _dp = self.advance()
            draw_map = {'始': ('begin', 0), '终': ('end', 0),
                        '色': ('color', 3), '圆': ('circle', 3),
                        '方': ('rect', 4), '线': ('line', 4),
                        '清': ('clear', 3),
                        '字': ('text', 4),
                        '图': ('img_draw', 3), '图缩': ('img_scaled', 5),
                        'begin': ('begin', 0), 'end': ('end', 0),
                        'color': ('color', 3), 'circle': ('circle', 3),
                        'rect': ('rect', 4), 'line': ('line', 4),
                        'clear': ('clear', 3), 'text': ('text', 4),
                        'img': ('img_draw', 3), 'imgs': ('img_scaled', 5)}
            if dv not in draw_map:
                self.err(f"web.draw. 后只能是 始/色/圆/方/线/清/字/图/图缩/终，实际是 {dv!r}")
            cmd, arity = draw_map[dv]
            if dv in ('始', 'begin') and self.at('OP', '('):
                # web.draw.始(宽, 高)：画布尺寸可选，缺省 400×300
                self.advance()
                w = self.expect('NUM')[1]
                self.expect('OP', ',')
                h = self.expect('NUM')[1]
                self.expect('OP', ')')
                if not (w.isdigit() and h.isdigit()):
                    self.err(f"第 {ln} 行：web.draw.始(宽, 高) 必须是正整数")
                iw, ih = int(w), int(h)
                if not (16 <= iw <= 4096 and 16 <= ih <= 4096):
                    self.err(f"第 {ln} 行：画布尺寸超范围（16..4096），得到 {iw}×{ih}")
                return HmDraw('begin', [NumLit(iw, ln), NumLit(ih, ln)], ln)
            if arity == 0 and self.at('OP', '('):
                self.err(f"web.draw.{dv} 不带括号和参数")
            params = []
            if arity:
                self.expect('OP', '(')
                params.append(self.parse_expr())
                while self.at('OP', ','):
                    self.advance()
                    params.append(self.parse_expr())
                self.expect('OP', ')')
                if len(params) != arity:
                    self.err(f"web.draw.{dv} 需要 {arity} 个参数，实际 {len(params)} 个")
            if cmd == 'text' and len(params) == 4 and isinstance(params[2], StrLit)                     and '$' in params[2].value:
                params = list(params)
                params[2] = StrParts(self._split_interp(params[2].value, ln), ln)
            return HmDraw(cmd, params, ln)
        if v in ('帧', 'frame'):                # web.帧 { web.draw.* ... }：一帧动画
            if self.at('OP', '('):              # 可选 (速度数字)：定稿语法，AST 不保存
                self.advance()
                self.expect('NUM')
                self.expect('OP', ')')
            body, _ = self._block()
            self._frame_count += 1
            return HmFrame(body, ln)
        if v == '实时':                         # web.实时 { ... }：浏览器实时循环（可选 (帧率)）
            fps = None
            if self.at('OP', '('):
                self.advance()
                fps = self.expect('NUM')[1]
                if not fps.isdigit():
                    self.err('web.实时(帧率) 里必须是正整数')
                fps = int(fps)
                if fps <= 0:
                    self.err('web.实时(帧率) 必须是正整数')
                self.expect('OP', ')')
            body, _ = self._block()
            return HmLive(body, fps, ln)
        if v in ('播放', 'play'):               # web.播放(速度)：循环播放之前的所有帧
            if self._frame_count == 0:
                self.err('web.播放 前必须至少有一个 web.帧')
            self.expect('OP', '(')
            speed = self.parse_expr()
            self.expect('OP', ')')
            return HmPlay(speed, ln)
        if v == 'line':                         # 独立语句：无参数无括号
            return HmStmt('line', [], '', [], ln)
        if v in ('img', 'link'):
            self.expect('OP', '(')
            if v == 'img':
                arg = self.expect('STR')[1]     # web.img("文件名")
                parts = []
            else:                               # web.link("显示文字", "网址")
                text = self.expect('STR')[1]
                self.expect('OP', ',')
                arg = self.expect('STR')[1]
                parts = [('TEXT', text)]
            self.expect('OP', ')')
            return HmStmt(v, parts, arg, [], ln)
        if v in ('big', 'mid', 'show'):
            lp = self.expect('OP', '(')
            raw, end = self.scan_raw(lp[3] + 1, f'web.{v}')
            parts = self._split_content(raw, ln)
            self.sync_to(end)
            self.expect('OP', ')')
            magic = []
            j = end + 1
            while j < len(self.src) and self.src[j] in ' \t':
                j += 1
            if self.src[j:j + 1] == '/':
                if v != 'show':
                    self.err(f"web.{v} 不支持 /magic（只有 web.show 支持）")
                self.expect('OP', '/')
                m = self.expect('NAME')
                if m[1] != 'magic':
                    self.err(f"web.show 的 / 后只能接 magic，实际是 {m[1]!r}")
                mlp = self.expect('OP', '(')
                mraw, mend = self.scan_raw(mlp[3] + 1, 'magic')
                magic = self._split_magic(mraw, ln)
                self.sync_to(mend)
                self.expect('OP', ')')
            return HmStmt(v, parts, '', magic, ln)
        if v == 'click':                        # web.click：画布被点击（表达式）
            return Call('web.click', [], ln)
        if v == 'mx':
            return Call('web.mx', [], ln)
        if v == 'my':
            return Call('web.my', [], ln)
            self.expect('OP', '(')
        if v == 'textbox':                      # web.textbox(占位, id)
            self.expect('OP', '(')
            tip = self.expect('STR')[1]
            self.expect('OP', ',')
            name = self.expect('STR')[1]
            bind = None
            if self.at('OP', ','):               # 第三参：回车触发的按钮 id
                self.advance()
                bind = self.expect('STR')[1]
            self.expect('OP', ')')
            return HmStmt('textbox', [('TEXT', tip)], name, [bind] if bind else [], ln)
        if v == 'button':                       # web.button(文字, id) → <button>
            self.expect('OP', '(')
            text = self.expect('STR')[1]
            self.expect('OP', ',')
            name = self.expect('STR')[1]
            self.expect('OP', ')')
            return HmStmt('button', [('TEXT', text)], name, [], ln)
        if v == 'audio':                        # web.audio("文件") 或 web.audio.stop()
            if self.at('OP', '.') and self.toks[self.i + 1][1] == 'stop':
                self.advance(); self.advance()
                self.expect('OP', '(')
                self.expect('OP', ')')
                return HmStmt('audio_stop', [], '', [], ln)
            self.expect('OP', '(')
            src = self.expect('STR')[1]
            self.expect('OP', ')')
            return HmStmt('audio', [('TEXT', src)], '', [], ln)
        if v == 'align':                        # web.align("center")
            self.expect('OP', '(')
            mode = self.expect('STR')[1]
            self.expect('OP', ')')
            return HmStmt('align', [('TEXT', mode)], '', [], ln)
        if v == 'gap':                          # web.gap(像素)
            self.expect('OP', '(')
            arg = self.expect('NUM')[1]
            self.expect('OP', ')')
            return HmStmt('gap', [('TEXT', arg)], '', [], ln)
        if v == 'open':                         # web.open("网址")
            self.expect('OP', '(')
            arg = self.expect('STR')[1]
            self.expect('OP', ')')
            return HmStmt('open', [], arg, [], ln)
        if v == 'style':                        # web.style("css")
            self.expect('OP', '(')
            arg = self.expect('STR')[1]
            self.expect('OP', ')')
            return HmStmt('style', [], arg, [], ln)
        if v == 'storage':                      # web.storage("键", "值")
            self.expect('OP', '(')
            k = self.parse_expr()
            self.expect('OP', ',')
            v2 = self.parse_expr()
            self.expect('OP', ')')
            return HmStmt('storage', [k, v2], '', [], ln)
        if v == 'waitsec':                      # web.waitsec(秒)：暂停 N 秒（生成 setInterval 显示）
            self.expect('OP', '(')
            arg = self.expect('NUM')[1]
            self.expect('OP', ')')
            return HmStmt('waitsec', [('TEXT', arg)], '', [], ln)
        if v == 'title':                        # web.title("标题")
            self.expect('OP', '(')
            arg = self.expect('STR')[1]
            self.expect('OP', ')')
            return HmStmt('title', [], arg, [], ln)
        if v == '置':                           # web.置("id", 值)：回写输入框（实时块用）
            self.expect('OP', '(')
            a = self.parse_expr()
            self.expect('OP', ',')
            b = self.parse_expr()
            self.expect('OP', ')')
            return HmStmt('set', [a, b], '', [], ln)
        if v == '页':                           # web.页("名") { 页面语句 }：烤成独立网页
            self.expect('OP', '(')
            name = self.expect('STR')[1]
            self.expect('OP', ')')
            if any(ch in name for ch in '/\\:*?"<>|') or not name:
                self.err(f"web.页 名字不能为空且不能含 /\\:*?\"<>|，实际是 {name!r}")
            body, _ = self._block()
            for st in body:
                if isinstance(st, (HmFrame, HmPlay, HmLive, HmDraw, HmPageStmt)):
                    raise PybkError(
                        f"第 {st.line} 行：web.页 里不能用 帧/播放/实时/draw/嵌套页"
                        "（子页只烤页面内容，动画写在主页的画布段里）")
            return HmPageStmt(name, body, ln)
        if v in self.hm_blocks:                 # web.组件名(实参)：展开已定义的块
            d = self.hm_blocks[v]
            args = []
            if self.at('OP', '('):
                self.advance()
                if not self.at('OP', ')'):
                    args.append(self.parse_expr())
                    while self.at('OP', ','):
                        self.advance()
                        args.append(self.parse_expr())
                self.expect('OP', ')')
            if len(args) != len(d.params):
                self.err(f"第 {ln} 行：web.{v} 需要 {len(d.params)} 个参数，实际 {len(args)} 个")
            return HmUse(v, args, ln)
        if v == '块':
            self.err(f"第 {ln} 行：web.块 只能定义在文件顶层（func 旁边），不能写在 GOING 或块里")
        self.err(f"web. 后只能是 big/mid/show/img/line/link/draw/帧/播放/实时"
                 f"/click/mx/my/textbox/button/audio/align/gap/open/style/title"
                 f"或已定义的组件名，实际是 {v!r}")

    def parse_go(self):
        """go(方向, 距离, 速度)：把画布整体平移。

        方向是 中文 右/左/上/下 或英文 right/left/up/down；距离与速度是表达式。"""
        ln = self.expect('NAME', 'go')[2]
        self.expect('OP', '(')
        _k, d, _l, _p = self.expect('NAME')
        if d not in GO_DIRECTIONS:
            self.err("go 的方向只能是 右/左/上/下（或 right/left/up/down）")
        self.expect('OP', ',')
        dist = self.parse_expr()
        self.expect('OP', ',')
        speed = self.parse_expr()
        self.expect('OP', ')')
        return GoStmt(d, dist, speed, ln)

    def _game_call(self, name: str, ln: int) -> Call:
        """游戏零件内置调用：key("right")、win(800,600,"名")、clear() 等。

        参数个数按 GAME_CALLS 校验；key 的实参必须是字符串字面量
        且键名合法（right/left/up/down/space/a-z/enter/esc/shift 或中文）。"""
        self.expect('OP', '(')
        args = []
        if not self.at('OP', ')'):
            args.append(self.parse_expr())
            while self.at('OP', ','):
                self.advance()
                args.append(self.parse_expr())
        self.expect('OP', ')')
        # 圆 → circle：走后端默认英文名分支 rt_game_circle（对整文件保存回滚免疫）
        name = {'text': '字', 'img': '图', 'imgs': '图缩', 'line': '线',
                'dot': '点', '圆': 'circle'}.get(name, name)
        want = GAME_CALLS[name]
        if name == 'color' and len(args) in (1, 3):
            want = len(args)   # color 重载：color(r,g,b) 与 color(列表) 并存
        if len(args) != want:
            raise PybkError(f"第 {ln} 行：{name} 需要 {want} 个参数，实际 {len(args)} 个")
        if name == 'key':
            a = args[0]
            if not isinstance(a, StrLit):
                raise PybkError(f'第 {ln} 行：key 的键名必须是字符串字面量')
            if a.value not in KEY_NAMES:
                raise PybkError(f'第 {ln} 行：不支持的键名 {a.value!r}')
        return self._maybe_interp(name, args, ln)

    def _maybe_interp(self, name, args, ln):
        """字 的文本参数支持 $插值："得分 $分" → StrParts。"""
        if name in ('字', '图') and isinstance(args[2], StrLit)                 and '$' in args[2].value:
            args = list(args)
            args[2] = StrParts(self._split_interp(args[2].value, ln), ln)
        return Call(name, args, ln)

    def _split_interp(self, s: str, ln: int) -> list:
        """$名字（可含中文/下划线/点）切成 [(TEXT/VAR, ...)]。"""
        parts = []
        buf = []
        i = 0
        while i < len(s):
            ch = s[i]
            if ch == '$' and i + 1 < len(s) and s[i + 1] == '$':
                buf.append('$')               # $$ → 字面 $
                i += 2
                continue
            if ch == '$' and i + 1 < len(s) and s[i + 1] == '(':
                if buf:
                    parts.append(('TEXT', ''.join(buf)))
                    buf = []
                深度 = 0
                j = i + 1
                while j < len(s):
                    if s[j] == '(':
                        深度 += 1
                    elif s[j] == ')':
                        深度 -= 1
                        if 深度 == 0:
                            break
                    j += 1
                子 = _Parser(s[i + 2:j])
                parts.append(('EXPR', 子.parse_expr()))
                i = j + 1
                continue
            if ch == '$' and i + 1 < len(s) and (s[i + 1].isalnum() or s[i + 1] in '_.'):
                if buf:
                    parts.append(('TEXT', ''.join(buf)))
                    buf = []
                j = i + 1
                while j < len(s) and (s[j].isalnum() or s[j] in '_.'):
                    j += 1
                name = s[i + 1:j]
                # $名.尾缀：尾缀是纯英文短段且到字符串末尾 → 是文件扩展名不是属性
                #（"兵$帧图.png" 读帧图；"生命 $侠.血" 的 .血 是中文仍是属性）
                if '.' in name:
                    base, _, tail = name.rpartition('.')
                    if tail.isascii() and tail.isalpha() and len(tail) <= 4 and j == len(s):
                        name = base
                        j = i + 1 + len(base)
                parts.append(('VAR', name))
                i = j
            else:
                buf.append(ch)
                i += 1
        if buf:
            parts.append(('TEXT', ''.join(buf)))
        return parts

    def _切顶层逗号(self, raw: str, ln: int) -> list:
        """按引号外、括号外的顶层逗号切分 ns.show 的内容。"""
        段s = []
        buf = []
        引号 = False
        深度 = 0
        i = 0
        while i < len(raw):
            c = raw[i]
            if 引号:
                if c == 92 and i + 1 < len(raw):
                    buf.append(c)
                    buf.append(raw[i + 1])
                    i += 2
                    continue
                if c == '"':
                    引号 = False
                buf.append(c)
            elif c == '"':
                引号 = True
                buf.append(c)
            elif c in '([{':
                深度 += 1
                buf.append(c)
            elif c in ')]}':
                深度 -= 1
                buf.append(c)
            elif c == ',' and 深度 == 0:
                段s.append(''.join(buf).strip())
                buf = []
            else:
                buf.append(c)
            i += 1
        段s.append(''.join(buf).strip())
        # 只在"有多个段、其中某段空"时报错（ns.show(a,,b) 这种手滑）。
        # 整个 show() 空着是合法写法：输出一个空行（与 Python print() 一致）。
        if len(段s) > 1 and any(not 段 for 段 in 段s):
            self.err('ns.show 参数里有空项')
        return 段s

    def _split_content(self, raw: str, ln: int) -> list:
        """裸文本切成 ('TEXT', 串) / ('VAR', 名) / ('EXPR', 节点) 交错列表。

        $ 后先尝试完整的表达式（如 $at+1、$n / 2），失败退回单标识符。"""
        parts = []
        buf = []
        i = 0
        while i < len(raw):
            c = raw[i]
            if c == '$':
                span, part = self._interp_expr(raw[i + 1:], ln)
                if buf:
                    parts.append(('TEXT', ''.join(buf)))
                    buf = []
                parts.append(part)
                i += 1 + span
            else:
                buf.append(c)
                i += 1
        if buf:
            parts.append(('TEXT', ''.join(buf)))
        return parts

    # $ 插值表达式允许出现的字符（遇白名单外字符即截断；) 永远结束整行）
    # 双引号放进白名单：$d["a"] 这类字符串下标才能在插值里求值（单引号 PYbook 不支持）
    _INTERP_CHARS = set('+-*/%<>=!. 	[]()"')

    def _interp_expr(self, text: str, ln: int):
        """把 $ 后面的文本尽量解析成表达式，返回 (消费字符数, part)。

        表达式里的后续 $ 会自动吸收：$s+$s 等价于 s + s。
        策略：截出白名单前缀 → 去掉内部 $ → 分词 → 从 1 个 token 开始
        逐个加长试解析，取"完整消化所有 token"的最长成功。"""
        cut = 0
        while cut < len(text) and (_is_id_char(text[cut])
                                   or text[cut] in self._INTERP_CHARS
                                   or text[cut] == '$'):
            cut += 1
        # 内部 $ 替换成空格（1:1 等宽替换，坐标不变；相邻 $变量 不会粘连）
        stripped_s = text[:cut].replace('$', ' ')
        body = []
        try:
            toks = list(_lex(stripped_s, self.lang))
        except PybkError:
            toks = []      # 引号未闭合等：退回单标识符保底，不炸整行
        for t in toks:
            if t[0] in ('EOF', 'ERR'):
                break
            body.append(t)
        # at 是 rm.around 的内置圈数：插值表达式里当作普通变量名
        body = [('NAME', v, l, c)
                if (k2 == 'KW' and self._canon(v) in ('at', 'self')) else (k2, v, l, c)
                for (k2, v, l, c) in body]
        # 保底：按旧规则取最大标识符（表达式全部失败时退回它）
        j = 0
        while j < len(text) and _is_id_char(text[j]):
            j += 1
        ident = text[:j]
        if cut < len(text) and text[cut] == ',':
            raise PybkError(f"第 {ln} 行：插值表达式里不能用逗号")
        if not body:
            if ident == 'at':
                return j, ('VAR', 'at')
            if ident and ident not in self._kwset():
                return j, ('VAR', ident)
            raise PybkError(f"第 {ln} 行：插值里不能直接使用 {ident!r}"
                            f"（规则：先 vg.名 = {ident}，再 \"$名\"；"
                            f"或直接写 $(表达式)，如 \"$(长度(表))\"）")
        best_k, best_node = 0, None
        for k in range(1, len(body) + 1):
            p = _Parser.__new__(_Parser)
            p.src = ''
            p.lang = self.lang          # 子解析器跟主文件同一个语言模式
            p.toks = body[:k] + [('EOF', '', ln, 10 ** 6)]
            p.i = 0
            try:
                node = p.parse_expr()
            except PybkError:
                continue
            if p.i >= k:
                best_k, best_node = k, node
        if best_k == 0:
            if ident and ident not in self._kwset():
                return j, ('VAR', ident)
            raise PybkError(f"第 {ln} 行：$ 后的表达式无法解析：{stripped_s!r}")
        last = body[best_k - 1]
        span = last[3] + len(str(last[1]))   # 等宽替换，坐标即原坐标
        node = self._reline(best_node, ln)
        had_inner_dollar = '$' in text[:span]
        if best_k == 1 and body[0][0] == 'NAME' and not had_inner_dollar:
            return span, ('VAR', body[0][1])
        return span, ('EXPR', node)

    @staticmethod
    def _reline(node, ln):
        """把解析出的表达式节点（含嵌套）的行号统一改成正确的行号。"""
        import dataclasses as _dc
        def fix(n):
            if n is None or isinstance(n, (str, int, float, bool)):
                return n
            if _dc.is_dataclass(n) and hasattr(n, 'line'):
                n.line = ln
                for f in n.__dataclass_fields__:
                    v = getattr(n, f)
                    if isinstance(v, list):
                        for x in v:
                            fix(x)
                    else:
                        fix(v)
        fix(node)
        return node

    def _split_magic(self, raw: str, ln: int) -> list:
        """magic 项按逗号切分，但 c=255,0,0 这类颜色值自带逗号：
        含 = 的段后面必须紧跟两段数字，三段合并回一个项。"""
        pieces = [s.strip() for s in raw.split(',')]
        items = []
        i = 0
        while i < len(pieces):
            p = pieces[i]
            if '=' in p:
                if i + 2 >= len(pieces):
                    raise PybkError(f"第 {ln} 行：magic 项 {p!r} 缺少完整的 r,g,b 三段")
                p = f"{p},{pieces[i + 1].strip()},{pieces[i + 2].strip()}"
                i += 3
            else:
                i += 1
            if not p:
                raise PybkError(f"第 {ln} 行：magic 项不能为空")
            items.append(p)
        return items

    def parse_rm(self):
        ln = self.expect('KW', 'rm')[2]
        self.expect('OP', '.')
        _k, v2, _l2, _p2 = self.advance()
        v2 = {'围绕': 'around', '遍历': 'around'}.get(self._canon(v2), self._canon(v2))   # rm 子语法中文别名（ZH 表未覆盖 around）
        if v2 == 'around':
            self.expect('OP', '(')
            times = self.parse_expr()
            self.expect('OP', ')')
            var = 'at'
            if self.at('OP', '-') and self.toks[self.i + 1][:2] == ('OP', '>'):
                self.advance()                 # -
                self.advance()                 # >
                var = self.expect('NAME')[1]   # 自定义计数器名
            self.loop_depth += 1
            body, _ = self._block()
            self.loop_depth -= 1
            return Around(times, body, ln, var)
        if v2 == 'aging':
            self.expect('OP', '.')
            self.expect('KW', 'while')
            self.expect('OP', '(')
            cond = self.parse_expr()
            self.expect('OP', ')')
            self.loop_depth += 1
            body, _ = self._block()
            self.loop_depth -= 1
            return Aging(cond, body, ln)
        self.err(f"rm. 后只能是 around 或 aging，实际是 {v2!r}")

    def parse_break(self, ln):
        """break/断：跳出当前层循环。后面不跟任何内容；
        不在任何循环里 → 立即报错（err 自带当前行号）。"""
        if self.loop_depth == 0:
            self.err("break 只能在循环内使用")
        self.advance()
        return BreakStmt(ln)

    def parse_while(self):
        """while(条件){...}：条件为真就继续下一轮。

        和 rm.aging.while 正好相反：那个是「直到…才停」（条件为真才退出），
        这个是「当…时」（条件为假才退出）。名字都带 while，语义却相反，
        写之前先想清楚要哪个。
        """
        ln = self.expect('KW', 'while')[2]
        paren = False
        if self.at('OP', '('):
            self.advance()
            paren = True
        cond = self.parse_expr()
        if paren:
            self.expect('OP', ')')
        self.loop_depth += 1
        body, _ = self._block()
        self.loop_depth -= 1
        return WhileStmt(cond, body, ln)

    def parse_continue(self, ln):
        """continue/继续：跳到当前层循环的下一轮（重新求值循环条件）。
        不在任何循环里 → 立即报错。"""
        if self.loop_depth == 0:
            self.err("continue 只能在循环内使用")
        self.advance()
        return ContinueStmt(ln)

    def parse_when(self):
        ln = self.expect('KW', 'when')[2]
        body, _ = self._block()
        self.expect('KW', 'if')
        self.expect('OP', '(')
        k, v, _l, _p = self.cur()
        if k != 'NUM' or not v.isdigit():
            self.err("when 的 if(...) 里必须是整数")
        self.advance()
        self.expect('OP', ')')
        return CdBlock(int(v), body, ln)

    def parse_branch(self):
        ln = self.expect('KW', 'if')[2]
        # 两种写法：如果(条件){...} 经典带括号；中文模式另支持 如果 条件 {...} 无括号
        def _cond():
            paren = False
            if self.at('OP', '('):
                self.advance()
                paren = True
            c = self.parse_expr()
            if paren:
                self.expect('OP', ')')
            return c
        cond = _cond()
        body, _ = self._block()
        arms = [(cond, body)]
        while self.at('KW', 'elif'):
            self.advance()
            c = _cond()
            b, _ = self._block()
            arms.append((c, b))
        if self.at('KW', 'else'):
            self.advance()
            b, _ = self._block()
            arms.append((None, b))
        return VcChain(arms, ln)

    def parse_trycatch(self):
        """try {...} catch [e [, t]] [:类型] {...} [finally {...}]

        - catch 不写变量 = 接住什么都行；
        - catch e, t：e 拿错误消息，t 拿错误类型；
        - catch e:类型：只接这个类型的错（类型对不上就原样往外抛）；
        - finally {...}：正常走完 / 接住了错 / 没接住错，三条路都会跑一遍。
        """
        ln = self.expect('KW', 'try')[2]
        body, _ = self._block()
        var = var2 = None
        etype = None
        handler = []
        if self.at('KW', 'catch'):
            self.advance()
            if self.at('NAME'):
                var = self.expect('NAME')[1]
                if self.at('OP', ','):            # catch e, t：t 拿错误类型
                    self.advance()
                    var2 = self.expect('NAME')[1]
            if self.at('OP', ':'):               # catch e:类型：只接这个类型
                self.advance()
                etype = self.parse_err_type()
            handler, _ = self._block()
        fin = None
        if self.at('KW', 'finally'):
            self.advance()
            fin, _ = self._block()
        if not handler and fin is None:
            raise PybkError(f"第 {ln} 行：try 后面要跟 catch 或 finally（至少要有一个）")
        return TryCatch(body, var, handler, ln, var2, etype, fin)

    def parse_err_type(self):
        """错误类型标签：裸名字（当类型名本身用）或字符串字面量。"""
        k, v, _ln, _p = self.cur()
        if k == 'STR':
            self.advance()
            if not v:
                self.err("错误类型不能是空字符串")
            return v
        if k == 'NAME':
            self.advance()
            return v
        self.err("错误类型写一个名字或一段字符串（如 catch e:除零 { }）")

    def parse_throw(self):
        """throw / throw "消息" / throw "消息", "类型"：抛一个可捕获的错误。

        不带参数的 throw = 重抛：把手上正在接的那个错原样抛给外层。
        它只能写在 catch 里（别处没有「手上的错」可抛），由代码生成期拦。
        """
        ln = self.expect('KW', 'throw')[2]
        k, v, nl, _p = self.cur()
        bare = (k == 'EOF' or nl != ln
                or (k == 'OP' and v == '}')
                or (k == 'KW' and self._canon(v) == 'STOP'))
        if bare:
            return Throw(None, None, ln)
        msg = self.parse_expr()
        etype = None
        if self.at('OP', ','):
            self.advance()
            etype = self.parse_expr()
        return Throw(msg, etype, ln)

    def parse_onerror(self):
        """onerror err {...}：本文件的兜底 catch（放 GOING 顶层，包裹其后全部语句）"""
        ln = self.expect('KW', 'onerror')[2]
        var = None
        if self.at('NAME'):
            var = self.expect('NAME')[1]
        handler, _ = self._block()
        return OnError([], var, handler, ln)

    def parse_forin(self):
        """for x in 列表 { ... }：逐个取元素，元素叫 x（列表可装对象）。"""
        ln = self.expect('KW', 'for')[2]
        _k, name, _l, _p = self.expect('NAME')
        vg2 = None
        if self.at('OP', ','):                # for 键, 值 in 字典 {...}
            self.advance()
            vg2 = self.expect('NAME')[1]
        self.expect('KW', 'in')
        it = self.parse_expr()
        self.loop_depth += 1                 # break 允许在 for-in 里用
        body, _ = self._block()
        self.loop_depth -= 1
        return ForIn(name, it, body, ln, vg2)

    def parse_ret(self):
        ln = self.expect('KW', 'ret')[2]
        k, v, nl, _p = self.cur()
        bare = (k == 'EOF' or nl != ln
                or (k == 'OP' and v == '}')
                or (k == 'KW' and self._canon(v) == 'STOP'))
        if bare:
            return Ret(None, ln)
        return Ret(self.parse_expr(), ln)

    # ---- 表达式（优先级低到高：or → and → 比较 → + - → * / % // → 一元）----

    def parse_expr(self):
        return self._ternary()

    def _ternary(self):
        c = self._or()
        if self.at('OP', '?'):
            ln = self.advance()[2]
            a = self.parse_expr()
            self.expect('OP', ':')
            b = self._ternary()
            return Ternary(c, a, b, ln)
        return c

    def _or(self):
        l = self._and()
        while self.at('KW', 'or'):
            ln = self.advance()[2]
            l = BinOp('or', l, self._and(), ln)
        return l

    def _and(self):
        l = self._cmp()
        while self.at('KW', 'and'):
            ln = self.advance()[2]
            l = BinOp('and', l, self._cmp(), ln)
        return l

    def _cmp(self):
        l = self._add()
        while True:
            if self.kind() == 'OP' and self.val() in CMP_OPS:
                ln = self.advance()[2]
                l = BinOp(self.toks[self.i - 1][1], l, self._add(), ln)
            elif self.at('KW', 'in'):
                ln = self.advance()[2]
                l = BinOp('in', l, self._add(), ln)
            elif self.at('KW', 'not') and self.toks[self.i + 1][0] == 'KW' \
                    and self._canon(self.toks[self.i + 1][1]) == 'in':
                ln = self.advance()[2]
                self.advance()
                l = BinOp('not_in', l, self._add(), ln)
            else:
                return l

    def _add(self):
        l = self._mul()
        while self.kind() == 'OP' and self.val() in ('+', '-'):
            ln = self.advance()[2]
            l = BinOp(self.toks[self.i - 1][1], l, self._mul(), ln)
        return l

    def _mul(self):
        l = self._unary()
        while self.kind() == 'OP' and self.val() in ('*', '/', '%', '//', '**'):
            _k, op, ln, _p = self.advance()      # 行号取运算符所在行（不是表达式的下一行）
            r = self._unary()
            if op == '**':
                # 张量矩阵乘：A ** B  →  tb.dot(A, B)（tb.dot 已实现多线程）
                l = Call('tb.dot', [l, r], ln)
            else:
                l = BinOp(op, l, r, ln)
        return l

    def _unary(self):
        if self.at('OP', '-'):
            ln = self.advance()[2]
            return Unary('-', self._unary(), ln)
        if self.at('KW', 'not'):
            ln = self.advance()[2]
            return Unary('not', self._unary(), ln)
        return self._primary()

    def _多目标(self, name, ln):
        """多重赋值的单个目标：名字 或 名字[下标]。"""
        if self.at('OP', '['):
            self.advance()
            idx = self.parse_expr()
            self.expect('OP', ']')
            return Index(VarRef(name, ln), idx, ln)
        return name

    def _parse_one_dim(self):
        """解析 [ ] 里的一段：裸表达式（普通下标）或 a:b[:c] 切片。
        返回 ('i', expr) 或 ('s', start, stop, step)，段可缺省（None）。"""
        if self.at('OP', ':'):
            start = None
        else:
            start = self.parse_expr()
            if not self.at('OP', ':'):
                return ('i', start)            # 普通下标
        self.advance()                          # 吃掉冒号
        stop = None
        if not self.at('OP', ':') and not self.at('OP', ',') and not self.at('OP', ']'):
            stop = self.parse_expr()
        step = None
        if self.at('OP', ':'):
            self.advance()
            if not self.at('OP', ',') and not self.at('OP', ']'):
                step = self.parse_expr()
        return ('s', start, stop, step)

    def _parse_bracketed_subscript(self, ln):
        """[ 已 consume 后调用：解析 [ ... ] 内部，结束时已 consume ]。
        检测逗号 → 返回 ('multi', 段1, 段2)；否则返回单段 ('i'/'s', ...)。"""
        d1 = self._parse_one_dim()
        if self.at('OP', ','):
            self.advance()
            d2 = self._parse_one_dim()
            self.expect('OP', ']')
            return ('multi', d1, d2)
        self.expect('OP', ']')
        return d1

    def _suffixes(self, e, ln):
        """表达式后缀循环：[下标]、.属性、.方法(实参) 可任意叠加（天然支持链式）。"""
        while True:
            if self.at('OP', '['):
                self.advance()
                sub = self._parse_bracketed_subscript(ln)
                if isinstance(sub, tuple) and sub[0] == 'multi':
                    d1, d2 = sub[1], sub[2]
                    if d1[0] == 'i' and d2[0] == 'i':
                        e = Call('tensor.get', [e, d1[1], d2[1]], ln)
                    elif d1[0] == 's' and d2[0] == 's':
                        if any(x is None for x in (d1[1], d1[2], d2[1], d2[2])):
                            self.err('张量二维切片 T[a:b,c:d] 的每一段上下界都要显式写出')
                        if d1[3] is not None or d2[3] is not None:
                            self.err('张量切片暂不支持步长')
                        e = Call('tensor.slice', [e, d1[1], d1[2], d2[1], d2[2]], ln)
                    else:
                        self.err('张量多下标只支持 T[i,j] 或 T[a:b,c:d] 两种形式')
                    continue
                if sub[0] == 'i':
                    e = Index(e, sub[1], ln)
                else:
                    e = Slice(e, sub[1], sub[2], sub[3], ln)
            elif self.at('OP', '.'):
                self.advance()
                _k2, v2, l2, _p2 = self.cur()
                if _k2 == 'KW' and v2 == 'at':
                    self.advance()             # .at 是方法名，虽然 at 是关键字
                else:
                    if self.at('NAME'):
                        _k2, v2, l2, _p2 = self.advance()
                    else:
                        _k2, v2, l2, _p2 = self.expect('KW')   # 中文前缀拼写做方法名
                e = Member(e, v2, l2)
                if self.at('OP', '('):        # 方法调用后缀
                    self.advance()
                    args = []
                    if not self.at('OP', ')'):
                        args.append(self.parse_expr())
                        while self.at('OP', ','):
                            self.advance()
                            args.append(self.parse_expr())
                    self.expect('OP', ')')
                    if isinstance(e.base, VarRef) and self._canon(e.base.name) == 'dict':
                        e = Call('dict.' + e.attr, args, l2)   # dict.keys/values → 库调用
                    elif isinstance(e.base, VarRef) and self._canon(e.base.name) == 'set':
                        # set.方法(...) → set 库调用（集合=无值字典）
                        _SET_MAP = {'添加': 'set.添加', 'add': 'set.添加',
                                    '删掉': 'set.删掉', 'remove': 'set.删掉', 'discard': 'set.删掉',
                                    '含': 'set.含', 'has': 'set.含', 'contains': 'set.含',
                                    '长度': 'set.长度', 'len': 'set.长度', 'size': 'set.长度',
                                    '列表': 'set.列表', 'items': 'set.列表',
                                    '新': 'set.新', 'new': 'set.新'}
                        if e.attr not in _SET_MAP:
                            self.err(l2, f"set 没有 '{e.attr}'（可用：新/添加/删掉/含/长度/列表）")
                        e = Call(_SET_MAP[e.attr], args, l2)
                    elif e.attr in _STR_METHODS                             and not (isinstance(e.base, VarRef) and e.base.name in _LIB_PREFIXES):
                        # 方法式字符串糖：x.大写() → te.大写(x)（te 库 9 个单/多参函数
                        # 白得方法形态；对象方法优先级更高，不受影响——只有解析器
                        # 走到这的才转库调用）。参数个数交给 LIB_CALLS 检查兜底。
                        # set/list/dict 等库前缀不走此糖（set.含 是集合操作不是字符串）
                        e = Call(_STR_METHODS[e.attr], [e.base] + args, l2)
                    elif e.attr in ('get', 'at') and len(args) in (1, 2)                             and (isinstance(e.base, VarRef)
                                 or isinstance(e.base, (ListLit, DictLit, Slice, Index))):
                        # 安全访问器：x.at(i, 缺省) / x.get(键, 缺省) → 库调用
                        # 对象变量/字面量/切片/下标结果都可用（MethodCall 走类方法路径）
                        e = Call('safe.' + e.attr, [e.base] + args, l2)
                    else:
                        e = MethodCall(e.base, e.attr, args, l2)
            else:
                return e

    def _primary(self):
        k, v, ln, _p = self.cur()
        if k == 'KW' and self._canon(v) == 'lambda':
            # mec lambda：lambda(参数...) { 语句... } → Lambda 表达式（可调用值）
            self.advance()
            self.expect('OP', '(')
            params = []
            if not self.at('OP', ')'):
                params.append(self.expect('NAME')[1])
                while self.at('OP', ','):
                    self.advance()
                    params.append(self.expect('NAME')[1])
            self.expect('OP', ')')
            body, _end = self._block()
            return Lambda(params, body, ln)
        if k in ('NAME', 'KW') and self._canon(v) in GAME_CALLS \
                and self.toks[self.i + 1][:2] == ('OP', '('):
            self.advance()                     # key/win/clear/color/box/show/wait/end(...)
            return self._game_call(self._canon(v), ln)
        if k == 'KW' and self._canon(v) == 'web':
            # 表达式位置：web.click() / web.mx() / web.my() / web.text("id") / web.down("id")
            self.advance()
            self.expect('OP', '.')
            _wk, wv, _wl, _wp = self.advance()
            if wv in ('click', 'mx', 'my'):
                self.expect('OP', '(')
                self.expect('OP', ')')
                return Call('web.' + wv, [], ln)
            if wv in ('text', 'down'):
                self.expect('OP', '(')
                argw = self.parse_expr()
                self.expect('OP', ')')
                return Call('web.' + wv, [argw], ln)
            if wv == '存':
                self.expect('OP', '(')
                kw = self.parse_expr()
                self.expect('OP', ',')
                dv = self.parse_expr()
                self.expect('OP', ')')
                return Call('web.存', [kw, dv], ln)
            self.err(f'web.{wv} 不能用在表达式里')
        if k == 'KW' and v in ('调色板', 'palette') \
                and self.toks[self.i + 1][:2] == ('OP', '.') \
                and self.toks[self.i + 2][0] == 'NAME':
            # 调色板.颜色名：零参 LIB 调用，返回新建的 [r,g,b] 列表
            # （不带括号也能用——色表是常量，直接当列表值）
            self.advance()
            self.expect('OP', '.')
            cname = self.expect('NAME')[1]
            if v == 'palette':
                cname = {'red': '红', 'orange': '橙', 'yellow': '黄', 'green': '绿',
                         'cyan': '青', 'blue': '蓝', 'purple': '紫', 'white': '白',
                         'black': '黑', 'gray': '灰', 'pink': '粉', 'gold': '金'
                         }.get(cname, cname)
            full = '调色板.' + cname
            if full not in LIB_CALLS:
                self.err(f"调色板 里没有颜色 {cname!r}")
            args = []
            if self.at('OP', '('):      # 允许 调色板.红() / palette.red() 带括号
                self.advance()
                self.expect('OP', ')')
            return Call(full, args, ln)
        if k == 'KW' and self._canon(v) == 'list' \
                and self.toks[self.i + 1][:2] == ('OP', '.') \
                and self.toks[self.i + 2][0] == 'NAME' \
                and self.toks[self.i + 3][:2] == ('OP', '('):
            return self.parse_list_call(ln)
        if k == 'KW' and v in ('tw', 'data') \
                and self.toks[self.i + 1][:2] == ('OP', '.') \
                and self.toks[self.i + 2][0] == 'NAME' \
                and self.toks[self.i + 3][:2] == ('OP', '('):
            return self.parse_pref_call(v, ln)
        _pv = self._canon(v)                   # 中文模式折回规范前缀名
        if k == 'KW' and _pv in LIB_PREFIXES and _pv not in ('list', 'lb') \
                and self.toks[self.i + 1][:2] == ('OP', '.') \
                and self.toks[self.i + 2][0] in ('NAME', 'KW') \
                and self.toks[self.i + 3][:2] == ('OP', '('):
            if _pv == 'mu':                    # mu.sine → 音.正弦（前端翻译）
                _pv = '音'
            return self._lib_call(_pv, ln)     # te.split(...) / file.read(...) 等
        if k == 'KW' and _pv in ('vg', 'vg_ro') \
                and self.toks[self.i + 1][:2] == ('OP', '.') \
                and self.toks[self.i + 2][0] in ('NAME', 'KW') \
                and self.toks[self.i + 3][:2] != ('OP', '('):
            # 声明前缀的读形态：变量.x = 右值里的 x（vg 只在写侧有意义）
            self.advance()
            self.expect('OP', '.')
            _nv = self.advance()[1]
            return self._suffixes(VarRef(_nv, ln), ln)
        if k == 'NUM':
            self.advance()
            return NumLit(float(v) if '.' in v else int(v), ln)
        if k == 'STR':
            self.advance()
            if '$' in v:                       # 含 $ 的字符串 = 插值串（赋值时求值）
                return self._suffixes(StrParts(self._split_interp(v, ln), ln), ln)
            return self._suffixes(StrLit(v, ln), ln)
        if k == 'NAME' and v in ('frame', 'sec')                 and self.toks[self.i + 1][:2] not in (('OP', '.'), ('OP', '='), ('OP', '(')):
            return Call(v, [], ln)             # frame / sec：内置帧数/秒数
        if k == 'KW' and v == 'at':            # rm.around 的循环计数器
            self.advance()
            return VarRef('at', ln)
        if k == 'KW' and self._canon(v) == 'self':   # self：方法内的当前实例
            self.advance()
            return self._suffixes(VarRef('self', ln), ln)
        if k == 'KW' and self._canon(v) == 'lb':     # lb.类名(属性=值, ...) 构造实例
            ln2 = self.advance()[2]
            self.expect('OP', '.')
            cname = self.expect('NAME')[1]
            if self.at('OP', '.'):                 # lb.类名.静态成员 / 静态方法
                self.advance()
                mname = self.expect('NAME')[1]
                if self.at('OP', '('):
                    self.advance()
                    args = []
                    if not self.at('OP', ')'):
                        args.append(self.parse_expr())
                        while self.at('OP', ','):
                            self.advance()
                            args.append(self.parse_expr())
                    self.expect('OP', ')')
                    return StaticCall(cname, mname, args, ln2)
                return StaticRef(cname, mname, ln2)
            self.expect('OP', '(')                # 构造实例：lb.类名(位置实参 / 关键字实参)
            pos_args = []
            kwargs = []
            if not self.at('OP', ')'):
                while True:
                    if self.at('NAME') and self.toks[self.i + 1][:2] == ('OP', '='):
                        kwn = self.expect('NAME')[1]
                        self.expect('OP', '=')
                        kwargs.append((kwn, self.parse_expr()))
                    else:
                        pos_args.append(self.parse_expr())
                    if not self.at('OP', ','):
                        break
                    self.advance()
            self.expect('OP', ')')
            node = CtorExpr(cname, ln2, pos_args, kwargs)
            pend = getattr(self, '_pending_ctors', None)   # 插值子解析器没有该属性
            if pend is not None:
                pend.append(node)
            return node
        if k == 'KW' and v in ('true', '真'):
            self.advance()
            return BoolLit(True, ln)
        if k == 'KW' and v in ('空', 'none'):
            self.advance()
            return Call('空', [], ln)
        if k == 'KW' and v == '假':
            self.advance()
            return BoolLit(False, ln)
        if k == 'KW' and v == 'false':
            self.advance()
            return BoolLit(False, ln)
        if k == 'KW' and self._canon(v) == 'input':
            self.advance()
            self.expect('OP', '(')
            prompt = self.expect('STR')[1]
            self.expect('OP', ')')
            return InputExpr(prompt, ln)
        if k == 'OP' and v == '{':            # 字典 {"键": 值} / 集合 {值, 值}（允许尾逗号）
            self.advance()
            # 集合字面量探测：{ 或 , 之后紧跟 }（空集）或第一个元素后没有 : （值集）
            # —— 有 : 才是字典。空 {} 归字典（历史行为，空集用 set.新()）。
            if not self.at('OP', '}'):
                _save = self.i
                _probe = True
                try:
                    self.parse_expr()
                    _probe = not self.at('OP', ':')
                except Exception:
                    self.i = _save
                    _probe = False
                self.i = _save
                if _probe:
                    items = []
                    while not self.at('OP', '}'):
                        items.append(self.parse_expr())
                        if not self.at('OP', ','):
                            break
                        self.advance()
                    self.expect('OP', '}')
                    return self._suffixes(SetLit(items, ln), ln)
            pairs = []
            while not self.at('OP', '}'):
                kk = self.parse_expr()
                self.expect('OP', ':')
                vv = self.parse_expr()
                pairs.append((kk, vv))
                if self.at('KW', 'for'):      # 字典推导 {k: v for k, v in 源 if 条件}
                    self.advance()
                    变 = [self.expect('NAME')[1]]
                    if self.at('OP', ','):
                        self.advance()
                        变.append(self.expect('NAME')[1])
                    self.expect('KW', 'in')
                    it = self.parse_expr()
                    cond = None
                    if self.at('KW', 'if'):
                        self.advance()
                        cond = self.parse_expr()
                    self.expect('OP', '}')
                    return DictComp(kk, vv, 变, it, cond, ln)
                if not self.at('OP', ','):
                    break
                self.advance()
            self.expect('OP', '}')
            return self._suffixes(DictLit(pairs, ln), ln)
        if k == 'OP' and v == '[':            # 列表字面量 / 推导式（允许尾逗号 [1, 2,]）
            self.advance()
            if self.at('OP', ']'):
                self.advance()
                return ListLit([], ln)
            first = self.parse_expr()
            if self.at('KW', 'for'):          # [表达式 for x in 列表 if 条件]
                self.advance()
                var = self.expect('NAME')[1]
                self.expect('KW', 'in')
                it = self.parse_expr()
                cond = None
                if self.at('KW', 'if'):
                    self.advance()
                    cond = self.parse_expr()
                self.expect('OP', ']')
                return Comp(first, var, it, cond, ln)
            items = [first]
            while self.at('OP', ','):
                self.advance()
                if self.at('OP', ']'):
                    break
                items.append(self.parse_expr())
            self.expect('OP', ']')
            return self._suffixes(ListLit(items, ln), ln)
        # 英文语言模式下写了中文前缀（文本.分割(...)）：给一条可操作的提示。
        # 只在「后面跟的点号 + 确实是这个库的函数」时才报——普通变量的方法调用
        # 照旧当变量处理，不给英文模式的既有行为添堵。
        if k == 'NAME' and self.lang != 'zh' and v in ZH_PREFIX_REV \
                and self.toks[self.i + 1][:2] == ('OP', '.') \
                and self.toks[self.i + 2][0] in ('NAME', 'KW') \
                and self.toks[self.i + 3][:2] == ('OP', '('):
            _pn = self.toks[self.i + 2][1]
            _pf = ZH_PREFIX_REV[v] + '.' + _pn
            if _pf in LIB_CALLS or _pf in LIB_ALIASES:
                raise PybkError(
                    f"第 {ln} 行：{v!r} 是中文前缀（{ZH_PREFIX_REV[v]}），"
                    f"当前文件没写 language 中文，中文前缀不生效"
                    f"\n  为什么：中文前缀只在 language 中文 模式下才认"
                    f"\n  怎么改：① 想用中文写程序：在文件顶部加一行 language 中文"
                    f"；② 想用英文：写 {ZH_PREFIX_REV[v]}.{_pn}(...)")
        # 库前缀也可作普通标识符（如 func 测试()），故允许 NAME 形态命中 LIB_PREFIXES：
        # 这样 测试.断言相等 能解析成库调用，而 测试 本身仍可作变量/函数名（不抢成保留字）。
        # 中文模式下中文前缀（集合./文本./数学.…）被词法层认成 KW——
        # 前缀调用必须同时放行 KW，否则 36 个中文前缀在表达式位置全部失效。
        if k in ('NAME', 'KW') and self._canon(v) in LIB_PREFIXES \
                and self.toks[self.i + 1][:2] == ('OP', '.') \
                and self.toks[self.i + 2][0] in ('NAME', 'KW') \
                and self.toks[self.i + 3][:2] == ('OP', '('):
            return self._lib_call(self._canon(v), ln)
        if k == 'NAME':
            self.advance()
            e = self._suffixes(VarRef(v, ln), ln)
            if self.at('OP', '('):      # 裸函数调用：名(实参)——模块函数/普通函数
                self.advance()
                args = []
                if not self.at('OP', ')'):
                    args.append(self.parse_expr())
                    while self.at('OP', ','):
                        self.advance()
                        args.append(self.parse_expr())
                self.expect('OP', ')')
                e = Call(v, args, ln)
                e = self._suffixes(e, ln)   # f(x)[0] / f(x).属性 / f(x).方法(...) 链式
            return e
        if k == 'OP' and v == '(':
            self.advance()
            e = self.parse_expr()
            self.expect('OP', ')')
            return e
        if k == 'ERR':
            raise PybkError(f"第 {ln} 行：非法字符 {v!r}")
        self.err(f"不是合法的表达式：{v if v else k!r}")

    def _lib_call(self, prefix: str, ln: int) -> Call:
        """标准库模块调用：te.split(文本, 分隔符) → Call('te.split', [...])。

        名字 = 前缀.函数（见 LIB_CALLS），参数个数在解析期校验；
        后端按全名映射到 rt_lib_* / rt_list_* / rt_file_*。"""
        if prefix == 'hw' and not getattr(self, '_hw_on', False):
            raise PybkError(f"第 {ln} 行：hw 模块需要先在文件顶部写 ON 3D_highway")
        self.advance()                      # 前缀关键字
        self.expect('OP', '.')
        nt = self.cur()
        if nt[0] not in ('NAME', 'KW'):   # 允许关键字做函数名（file.del 等）
            self.err(f'标准库 {prefix} 的函数名不合法')
        name = nt[1]
        self.advance()
        if prefix == '音':
            name = {'sine': '正弦', 'tri': '三角', 'play': '放', 'stop': '停',
                    'note': '音', 'away': '奏', 'play_list': '谱', 'quick': '快'}.get(name, name)
        full = prefix + '.' + name
        full = LIB_ALIASES.get(full, full)
        if full not in LIB_CALLS and prefix != 'mec':
            raise PybkError(f"第 {ln} 行：标准库 {prefix} 没有函数 {name!r}")
        self.expect('OP', '(')
        args = []
        if not self.at('OP', ')'):
            args.append(self.parse_expr())
            while self.at('OP', ','):
                self.advance()
                args.append(self.parse_expr())
        self.expect('OP', ')')
        if full not in LIB_CALLS:
            return Call(full, args, ln)      # mec.名(...)：用户库函数（func mec.名 定义），名字对不对交代码生成期判
        if full == 'hw.text' and len(args) == 4 and isinstance(args[3], StrLit) and '$' in args[3].value:
            args = list(args)
            args[3] = StrParts(self._split_interp(args[3].value, ln), ln)
        want = LIB_CALLS[full]
        if isinstance(want, tuple):
            # (最少, 最多)：可选参数。缺省的那几个由 codegen 补空盒（rt_none），
            # C 层认空盒当「用户没给」。既有入口的值都是 int，走不到这里。
            lo, hi = want
            if not (lo <= len(args) <= hi):
                # self.err 已经在前面加了「第 N 行：」，这里不要再写一遍
                self.err(f"{full} 需要 {lo}~{hi} 个参数，实际 {len(args)} 个")
            return Call(full, args, ln)
        if full == 'tm.stop':
            if len(args) not in (1, 2):
                raise PybkError(f"第 {ln} 行：tm.stop 的用法不对")
        elif full == 'hw.camera' and len(args) == 4:
            args.append(NumLit(0, ln))   # 旧写法 camera(x,y,z,朝) → 俯仰 0
        elif full == 'hw.box' and len(args) == 12:
            pass                          # box(x,y,z,w,h,d,r,g,b, 绕x,绕y,绕z)：带旋转
        elif full == 'hw.cyl' and len(args) == 10:
            pass                          # cyl(x,y,z,下半径,高,上半径, 边数, r,g,b)：自定义边数
        elif full == 'hw.uni' and 2 <= len(args) <= 5:
            pass                          # uni("名字", a[, b[, c[, d]]])：1~4 个分量
        elif full == 'hw.ui':
            # 只认 0 / 1 / 4 个实参。上面 LIB_CALLS 里的 (0,4) 是给 codegen 补参用的，
            # 2 或 3 个会一路溜到 C 层才炸 —— 编译期就该拦下来。
            if len(args) not in (0, 1, 4):
                raise PybkError(
                    f"第 {ln} 行：hw.ui 的用法：hw.ui() 全屏贴 / "
                    f"hw.ui(侧栏宽) / hw.ui(x, y, w, h)")
        elif full == 'ffi.调用':
            if len(args) < 1:
                raise PybkError(f"第 {ln} 行：ffi.调用 的写法：ffi.调用(\"函数名\", 参数...)，至少要给函数名"
                                f"\n  为什么：第一个参数是 C 函数名，后面跟它要的参数"
                                f"\n  怎么改：先 ffi.声明(\"返回类型 名(参数类型...)\") 再 ffi.调用(\"名\", ...)")
        elif len(args) != want:
            raise PybkError(f"第 {ln} 行：{full} 需要 {want} 个参数，实际 {len(args)} 个")
        if full == 'hw.text' and isinstance(args[3], StrParts):
            pass   # $ 插值已在参数解析时转为 StrParts
        return Call(full, args, ln)

    def parse_list_call(self, ln: int) -> Call:
        """list. 前缀调用：内置列表操作(添加/长度) / 标准库(list.sort 等) / 用户函数。

        list.添加(列表, 值) / list.长度(x) → Call('添加'/'长度')（后端特判）；
        list.sort(...) 等 → Call('list.sort')（走标准库）；
        其余 list.名字(...) → Call('名字')（用户函数调用）。"""
        self.advance()                      # list 关键字
        self.expect('OP', '.')
        name = self.expect('NAME')[1]
        full = 'list.' + name
        full = LIB_ALIASES.get(full, full)
        if full in LIB_CALLS:
            self.expect('OP', '(')
            args = []
            if not self.at('OP', ')'):
                args.append(self.parse_expr())
                while self.at('OP', ','):
                    self.advance()
                    args.append(self.parse_expr())
            self.expect('OP', ')')
            if len(args) != LIB_CALLS[full]:
                raise PybkError(f"第 {ln} 行：{full} 需要 {LIB_CALLS[full]} 个参数，实际 {len(args)} 个")
            return Call(full, args, ln)
        self.expect('OP', '(')
        args = []
        if not self.at('OP', ')'):
            args.append(self.parse_expr())
            while self.at('OP', ','):
                self.advance()
                args.append(self.parse_expr())
        self.expect('OP', ')')
        return Call(name, args, ln)

    def parse_set_call(self, ln: int) -> Call:
        """set. 前缀调用：集合操作（集合=无值字典，去重免费）。

        set.添加(集合, 值) → 添加(集合, 值)（字典句柄 push 无效——改为 dict 语义）
        集合实际是 dict（键=元素、值=1），所以：
          set.添加(s, v) → Call('rt_dict_set 包装')；这里转成 dict 内建调用形态。
        """
        self.advance()
        self.expect('OP', '.')
        name = self.expect('NAME')[1]
        self.expect('OP', '(')
        args = []
        if not self.at('OP', ')'):
            args.append(self.parse_expr())
            while self.at('OP', ','):
                self.advance()
                args.append(self.parse_expr())
        self.expect('OP', ')')
        if name in ('添加', 'add') and len(args) == 2:
            return Call('set.添加', args, ln)
        if name in ('删掉', 'remove', 'discard') and len(args) == 2:
            return Call('set.删掉', args, ln)
        if name in ('含', 'has', 'contains') and len(args) == 2:
            return Call('set.含', args, ln)
        if name in ('长度', 'len', 'size') and len(args) == 1:
            return Call('set.长度', args, ln)
        if name in ('列表', 'items', 'to_list') and len(args) == 1:
            return Call('set.列表', args, ln)
        if name in ('新', 'new') and len(args) == 0:
            return Call('set.新', args, ln)
        raise PybkError(f"第 {ln} 行：set 没有 '{name}'（可用：新/添加/删掉/含/长度/列表）")

    def parse_pref_call(self, prefix: str, ln: int) -> Call:
        """tw./data. 等库前缀调用 → Call(前缀 + '_' + 名字)。

        tw.new(名) → Call('tw_new')；data.load(x) → Call('data_load')。
        点号只是外衣，底层仍是 引用(\"teamwork\") / 引用(\"data\") 提供的扁平用户函数。"""
        self.advance()                      # 前缀关键字
        self.expect('OP', '.')
        name = self.expect('NAME')[1]
        self.expect('OP', '(')
        args = []
        if not self.at('OP', ')'):
            args.append(self.parse_expr())
            while self.at('OP', ','):
                self.advance()
                args.append(self.parse_expr())
        self.expect('OP', ')')
        return Call(prefix + '_' + name, args, ln)


# 跨文件预加载的「已访问」集合：每次顶层解析（主文件或单模块发现）开始时重置，
# 但递归解析子模块（_parse_module_raw）不重置，从而保证 a→b→a 这类循环依赖
# 能在全局层面被检测到，避免 _preload_module_classes 无限递归。
_PRELOAD_SEEN = set()


def parse(src: str) -> Program:
    global _PRELOAD_SEEN, _LANG_MODE
    _PRELOAD_SEEN = set()
    _LANG_MODE = _detect_lang(src) or 'en'   # 主文件定项目语言，被 引用 的模块继承
    _ensure_aliases()
    return _Parser(src).parse_program()


# ---------------------------------------------------------------- 自测


def parse_module(src: str, base: str = None, root: str = None,
                 root_file: bool = False) -> Program:
    """解析被引用的模块单元：GOING 可有可无（有也被编译器忽略），
    顶层允许 vg 变量声明。Program.imports 记录它自己的 引用(...)。

    base：该模块自己所在目录（它内部的 引用("x") 相对它找，不是相对主文件）；
    root：命名空间根目录（主文件所在目录）；
    root_file：这是不是「工程入口」——是的话由它定项目语言（模块默认继承它）。"""
    global _PRELOAD_SEEN, _LANG_MODE
    _PRELOAD_SEEN = set()
    if root_file:
        _LANG_MODE = _detect_lang(src) or 'en'
    _ensure_aliases()
    return _Parser(src, base, root).parse_program(require_going=False)


def _parse_module_raw(src: str, base: str = None, root: str = None) -> Program:
    """供 _preload_module_classes 递归解析子模块：不重置全局 _PRELOAD_SEEN，
    从而让已访问集合在整条引用链上共享、能切断循环依赖。"""
    _ensure_aliases()
    return _Parser(src, base, root).parse_program(require_going=False)


# ---------------------------------------------------------------- 模块路径与命名空间
#
# 引用("名")       → 顶级模块：成员平铺进全局命名空间（历史行为，逐字不变）
# 引用("目录/名")  → 子目录模块：开一个命名空间「名_」，成员以「名_成员」暴露
#
# 判据看的是模块**实际在哪**（相对主程序所在目录），不是引用时怎么写：
# 同一个 lib/助手.pybk 无论被写成 引用("lib/助手") 还是从 lib/ 里的兄弟模块
# 写 引用("助手")，前缀都是 助手_ —— 同一个文件的名字不因谁引用它而变。
#
# 前缀用下划线而不是点号：点号在 PYbook 里已经是「库前缀」（lb./mt./tw./list.）
# 的语法位，用户命名空间再占点号会跟 §3 的消歧规则打架；「名_成员」是合法标识符，
# 函数、类、宏、模块级变量都能带前缀——C 后端与 VM 后端都零语法改动就能用。
#
# 根目录下的模块不加前缀是有意的：既有工程（引用("摆杆")、引用("mec")…）一个字
# 都不用改，行为逐字不变。子目录模块走命名空间，即「路径即命名空间」。

def module_path_norm(name: str) -> str:
    """引用名 → 规范化路径片段（统一用 / 作分隔、去首尾空白）。"""
    return (name or '').replace('\\', '/').strip()


def module_rel_path(path: str, root: str) -> str:
    """模块实际路径 → 相对根目录的路径（统一用 / 作分隔）。"""
    try:
        rel = os.path.relpath(os.path.abspath(path), os.path.abspath(root or '.'))
    except ValueError:            # 跨盘符时 relpath 会抛（Windows）
        rel = os.path.abspath(path)
    return rel.replace('\\', '/')


def module_ns_prefix(path: str, root: str) -> str:
    """模块实际路径 → 命名空间前缀。

    相对根目录**在子目录里**的模块（lib/助手.pybk）→ '助手_'（带命名空间）；
    就在根目录的模块（助手.pybk）→ ''（平铺，老行为不变）。

    判据看的是文件**实际在哪**，不是引用时怎么写：lib/助手.pybk 无论被写成
    引用("lib/助手") 还是从 lib/ 里的兄弟模块写 引用("助手")，前缀都是 '助手_'——
    同一个文件的名字不会因为谁引用它而变。"""
    rel = module_rel_path(path, root)
    base = rel.rsplit('/', 1)[-1]
    if base.lower().endswith('.pybk'):
        base = base[:-5]
    if not base or '/' not in rel:
        return ''
    return base + '_'


def resolve_module_path(base_dir: str, name: str) -> str:
    """引用名 → 实际文件路径（base_dir + 相对路径）。

    name 可含子目录（'lib/助手'）、可带可不带 .pybk；分隔符 / 与 \\ 都认。"""
    n = module_path_norm(name)
    if not n:
        return ''
    if not n.lower().endswith('.pybk'):
        n += '.pybk'
    return os.path.join(base_dir or '.', *n.split('/'))


def _import_base_dir() -> str:
    """引用() 的基准目录：PYBK_IMPORT_DIR > argv 里第一个真实存在的 .pybk 所在目录 > 当前目录。

    --check/--check-json 这类旗标会占住 argv[1]，只认 argv[1] 的老式探测会退化成
    进程 cwd——从别的目录跑检查时，被引用模块就「找不到」，类全部未定义
    （跨目录检查大坑）。

    PYBK_IMPORT_DIR 排第一：IDE 把待检查的源码临时落到系统临时目录，靠这个变量
    指回工程目录。合并期（_load_imports）认它，类预加载期也必须认——
    两边基准不一致会报假的「未定义的类」。"""
    import sys
    env = os.environ.get('PYBK_IMPORT_DIR')
    if env:
        return env
    for _a in sys.argv[1:]:
        if _a.lower().endswith('.pybk') and os.path.isfile(_a):
            return os.path.dirname(os.path.abspath(_a)) or '.'
    return os.getcwd()


def _ns_collect_vg(stmts, out):
    """收集语句块里声明的变量名（vg.x= / vg(x).x= / vg_ro.x[i]= / 多重赋值）。"""
    for st in stmts or []:
        if st is None:
            continue
        if isinstance(st, (VgAssign, IpAssign, AssignIndex)):
            out.add(st.name)
        elif isinstance(st, MultiAssign):
            out.update(st.targets or [])
        _ns_walk_blocks(st, lambda body: _ns_collect_vg(body, out))


def _ns_walk_blocks(node, fn):
    """把节点里所有「子语句块」交给 fn（用于递归进入 if/while/for/try 的块）。"""
    cls = type(node)
    if cls is VcChain:                      # 特例：arms 是 (条件, 语句列表) 元组列表
        for item in (node.arms or []):
            if isinstance(item, tuple) and len(item) == 2:
                fn(item[1])
        return
    for f in _STMT_LIST_FIELDS.get(cls, ()) or ():
        v = getattr(node, f, None)
        if isinstance(v, list):
            fn(v)


# 语句节点清单（改写器据此区分「语句」与「表达式」：语句走 stmt()，
# 表达式走通用字段遍历）。列表顺序无关，只要类型齐全。
_NS_STMT_CLASSES = (
    VgAssign, IpAssign, GoldDel, MemoryMode, DeviceMode, JitMode, NsShow,
    HmStmt, HmDraw, HmFrame, HmPlay, HmLive, HmBlockDef, HmUse, TestCheck,
    HmPageStmt, GoStmt, Around, ForIn, TryCatch, OnError, Throw, Aging,
    WhileStmt, BreakStmt, ContinueStmt, CdBlock, VcChain, Ret, FnDef,
    MacroDef, Lambda, ClassDef, MultiAssign, AssignIndex, AssignMember,
    AssignStatic,
)


class _NsRewriter:
    """把模块内部指向「本模块顶层定义」的裸名改写成带命名空间的限定名。

    scope 是当前作用域里已知的局部名（函数形参 + 函数内 vg 声明 + 循环变量）：
    局部名优先、绝不改写——同名遮蔽时以局部为准。
    top 表示「还在模块顶层」：模块顶层声明的 vg 变量要带前缀，
    函数里的同名变量是局部变量、不带前缀。"""

    def __init__(self, prefix, own_fns, own_cls, own_mac, own_vars):
        self.p = prefix
        self.own_fns = own_fns
        self.own_cls = own_cls
        self.own_mac = own_mac
        self.own_vars = own_vars
        self.own = own_fns | own_cls | own_mac

    # ---- 名字改写 ----
    def _qual(self, name, scope):
        if name in self.own and name not in scope:
            return self.p + name
        return name

    def _qual_var(self, name, scope, top):
        """模块顶层变量：只有还在顶层时才带前缀（函数内的同名是局部变量）。"""
        if top and name in self.own_vars and name not in scope:
            return self.p + name
        return name

    # ---- 语句 ----
    def stmts(self, stmts, scope, top=False):
        for st in stmts or []:
            self.stmt(st, scope, top)

    def stmt(self, st, scope, top):
        if st is None:
            return
        cls = type(st)
        if cls is VgAssign or cls is IpAssign or cls is AssignIndex:
            st.name = self._qual_var(st.name, scope, top)
        elif cls is MultiAssign:
            st.targets = [self._qual_var(t, scope, top) for t in (st.targets or [])]
        elif cls is Call:
            st.name = self._qual(st.name, scope)
        elif cls is CtorExpr:
            if st.class_name in self.own_cls:
                st.class_name = self.p + st.class_name
        elif cls is StaticCall or cls is StaticRef or cls is AssignStatic:
            if st.class_name in self.own_cls:
                st.class_name = self.p + st.class_name
        elif cls is FnDef:                 # 嵌套函数定义（模块内少见）
            st.name = self.p + st.name
        elif cls is Lambda:
            lscope = set(st.params or [])
            _ns_collect_vg(st.body or [], lscope)
            self.stmts(st.body or [], lscope, top=False)
        # 表达式/块字段统一递归
        for k, v in list(st.__dict__.items()):
            if k == 'line':
                continue
            self._field(v, scope, top)

    def _parts(self, parts, scope, top):
        """插值部件列表（('TEXT',串)/('VAR',名)/('EXPR',节点)）就地改写。"""
        for i, part in enumerate(parts or []):
            if isinstance(part, tuple) and len(part) == 2:
                kind, val = part
                if kind == 'VAR' and isinstance(val, str):
                    parts[i] = (kind, self._qual_var(val, scope, top))
                elif kind == 'EXPR':
                    self._field(val, scope, top)

    def _field(self, v, scope, top):
        """递归处理一个字段值（表达式节点 / 语句 / 列表 / 元组）。"""
        if v is None or isinstance(v, (int, float, str, bool)):
            return
        if isinstance(v, list):
            if _is_parts_list(v):
                self._parts(v, scope, top)
                return
            for item in v:
                if isinstance(item, tuple):
                    for sub in item:
                        self._field(sub, scope, top)
                else:
                    self._field(item, scope, top)
            return
        if isinstance(v, tuple):
            for item in v:
                self._field(item, scope, top)
            return
        if isinstance(v, _NS_STMT_CLASSES):
            self.stmt(v, scope, top)
            return
        cls = type(v)
        if cls is VarRef:
            if v.name in self.own and v.name not in scope:
                v.name = self.p + v.name
            elif top and v.name in self.own_vars and v.name not in scope:
                v.name = self.p + v.name
            return
        if cls is Call:
            v.name = self._qual(v.name, scope)
            for a in (v.args or []):
                self._field(a, scope, top)
            return
        if cls is CtorExpr:
            if v.class_name in self.own_cls:
                v.class_name = self.p + v.class_name
            for a in (v.pos_args or []):
                self._field(a, scope, top)
            for _k, a in (v.kwargs or []):
                self._field(a, scope, top)
            return
        if cls is StaticCall or cls is StaticRef or cls is AssignStatic:
            if v.class_name in self.own_cls:
                v.class_name = self.p + v.class_name
        if cls is StrParts:
            self._parts(v.parts, scope, top)
        if cls is NsShow:
            self._parts(v.parts, scope, top)
            self._parts(v.magic, scope, top)
            self._parts(v.vc_alt, scope, top)
        if cls is HmStmt:
            self._parts(v.parts, scope, top)
            self._parts(v.magic, scope, top)
        if hasattr(v, '__dict__'):
            for k, sub in list(v.__dict__.items()):
                if k == 'line':
                    continue
                self._field(sub, scope, top)


def _is_parts_list(v) -> bool:
    """判断是不是插值部件列表（元素是 ('TEXT'/'VAR'/'EXPR', 值) 元组）。

    ClassDef.props 是 [(属性名, 默认表达式)] 元组列表——第一项也是 str，
    所以这里按「首项 kind 必须是这三种之一」来区分，不靠「是不是元组」。"""
    if not v or not isinstance(v[0], tuple) or len(v[0]) != 2:
        return False
    return v[0][0] in ('TEXT', 'VAR', 'EXPR')


def rewrite_namespace(prog, prefix):
    """给模块自身的顶层定义与内部引用加命名空间前缀。

    prefix 为空（顶级模块）→ 原样返回，既有工程行为逐字不变。"""
    if not prefix:
        return prog
    p = prefix
    own_fns = {f.name for f in (prog.fns or [])}
    own_cls = {c.name for c in (prog.classes or [])}
    own_mac = {m.name for m in (prog.macros or [])}
    own_vars = set()
    _ns_collect_vg(prog.go_body or [], own_vars)

    # 1) 顶层定义改名
    for f in (prog.fns or []):
        f.name = p + f.name
    for c in (prog.classes or []):
        c.name = p + c.name
        if c.parent in own_cls:
            c.parent = p + c.parent
    for m in (prog.macros or []):
        m.name = p + m.name

    # 2) 内部引用改写
    rw = _NsRewriter(p, own_fns, own_cls, own_mac, own_vars)
    rw.stmts(prog.go_body or [], set(), top=True)
    for f in (prog.fns or []):
        scope = set(f.params or [])
        _ns_collect_vg(f.body or [], scope)
        rw.stmts(f.body or [], scope, top=False)
        for _k, d in (f.defaults or {}).items():
            rw._field(d, scope, False)
    for c in (prog.classes or []):
        cscope = set(c.ctor_params or [])
        for _pn, pe in (c.props or []):
            rw._field(pe, cscope, False)
        for _fn, fe in (c.static_fields or []):
            rw._field(fe, cscope, False)
        for m in list(c.methods or []) + list(c.static_methods or []):
            mscope = set(m.params or [])
            _ns_collect_vg(m.body or [], mscope)
            rw.stmts(m.body or [], mscope, top=False)
            for _k, d in (m.defaults or {}).items():
                rw._field(d, mscope, False)
    for m in (prog.macros or []):
        rw.stmts(m.body or [], set(m.params or []), top=False)
    return prog


# ---------------------------------------------------------------- 宏内联展开
#
# 宏（MacroDef）在编译期把调用就地展开成语句：调用处 `名(实参)` 被替换成
# 宏体、宏体里所有参数引用换成对应实参的 AST（深拷贝）。这是「代码宏」而非
# 函数调用——零调用开销，能批量生成重复代码（UI 行、注册表、重复逻辑等）。
#
# 展开是纯 AST 级替换（不是文本替换），所以不存在 C 宏那种「参数被多次求值 /
# 运算符优先级」的坑：每个参数在宏体里出现几次，就拿到几份独立的深拷贝。
#
# 支持：宏体里再调用别的宏（嵌套展开）；不支持递归（会无限循环，已用栈防护报错）。
# 宏只能当「语句」调用（调用结果不产出值），当表达式用会报「未声明函数」。

# 各语句节点里「装着语句列表」的字段名；VcChain.arms 是特例：(条件, 语句列表) 元组列表
_STMT_LIST_FIELDS = {
    Program: ['go_body'],
    FnDef: ['body'],
    Lambda: ['body'],
    Around: ['body'],
    ForIn: ['body'],
    Aging: ['body'],
    CdBlock: ['body'],
    VcChain: ['arms'],           # 特例，_expand_in_stmt 单独处理
    TryCatch: ['body', 'handler'],
    OnError: ['body', 'handler'],
    HmFrame: ['body'],
    HmLive: ['body'],
    HmPageStmt: ['body'],
    HmBlockDef: ['body'],
}


def _subst_text_interp(text, pmap):
    """插值文本里的 $名 / $(名)：名字命中宏参数 → 切成 TEXT/EXPR 段
    （表达式为实参 AST 深拷贝）。没命中的 $ 原样保留。"""
    segs = []
    buf = []
    i, n = 0, len(text)
    while i < n:
        ch = text[i]
        if ch == '$' and i + 1 < n:
            nxt = text[i + 1]
            if nxt == '(':
                j = text.find(')', i + 2)
                if j != -1:
                    inner = text[i + 2:j].strip()
                    if inner in pmap:
                        if buf:
                            segs.append(('TEXT', ''.join(buf)))
                            buf = []
                        segs.append(('EXPR', copy.deepcopy(pmap[inner])))
                        i = j + 1
                        continue
            elif nxt.isalpha() or nxt == '_' or ord(nxt) > 127:
                j = i + 1
                while j < n and (text[j].isalnum() or text[j] == '_' or ord(text[j]) > 127):
                    j += 1
                name = text[i + 1:j]
                if name in pmap:
                    arg = pmap[name]
                    if buf:
                        segs.append(('TEXT', ''.join(buf)))
                        buf = []
                    if isinstance(arg, VarRef):
                        segs.append(('VAR', arg.name))
                    else:
                        segs.append(('EXPR', copy.deepcopy(arg)))
                    i = j
                    continue
        buf.append(ch)
        i += 1
    if buf:
        segs.append(('TEXT', ''.join(buf)))
    return segs


def _subst_parts(parts, pmap):
    """插值部件（TEXT/VAR/EXPR 元组列表）的宏参数替换。"""
    outp = []
    for part in parts:
        if isinstance(part, tuple) and len(part) == 2:
            kind, val = part[0], part[1]
            if kind == 'VAR' and isinstance(val, str) and val in pmap:
                arg = pmap[val]
                if isinstance(arg, VarRef):
                    outp.append(('VAR', arg.name))
                else:
                    outp.append(('EXPR', copy.deepcopy(arg)))
                continue
            if kind == 'EXPR':
                outp.append(tuple(_subst(x, pmap) for x in part))
                continue
            if kind == 'TEXT' and isinstance(val, str) and '$' in val:
                segs = _subst_text_interp(val, pmap)
                if segs:
                    outp.extend(segs)
                continue
        outp.append(part)
    return outp


def _subst(node, pmap):
    """深拷贝 node 并把所有「参数引用」替换成对应实参 AST。pmap: 参数名 -> 实参节点。"""
    if node is None or isinstance(node, (int, float, str, bool)):
        return node
    if isinstance(node, list):
        return [_subst(x, pmap) for x in node]
    if isinstance(node, tuple):
        return tuple(_subst(x, pmap) for x in node)
    if isinstance(node, VarRef):
        if node.name in pmap:
            return copy.deepcopy(pmap[node.name])
        return node
    # 插值部件（ns.show / web.* / 字符串插值）：$参数 / $参数(...) 也要替换——
    # 字符串是替换终点，通用的 dict 遍历到不了 ('VAR', 名) 元组的名字里。
    if isinstance(node, (NsShow, HmStmt, StrParts)):
        if isinstance(getattr(node, 'parts', None), list):
            node.parts = _subst_parts(node.parts, pmap)
        for k, v in list(node.__dict__.items()):
            if k in ('line', 'parts'):
                continue
            setattr(node, k, _subst(v, pmap))
        return node
    if hasattr(node, '__dict__'):
        # 左值名替换：宏体里 `参数 = ...` / `表[参数] = ...` / `for 参数 in ...`
        if isinstance(node, (VgAssign,)) and node.name in pmap:
            arg = pmap[node.name]
            if isinstance(arg, VarRef):
                node.name = arg.name
        if isinstance(node, AssignIndex) and node.name in pmap:
            arg = pmap[node.name]
            if isinstance(arg, VarRef):
                node.name = arg.name
        if isinstance(node, ForIn) and node.var in pmap:
            arg = pmap[node.var]
            if isinstance(arg, VarRef):
                node.var = arg.name
        # 调用名替换：宏体里 `参数(...)` 把参数当函数名用
        if isinstance(node, Call) and node.name in pmap:
            arg = pmap[node.name]
            if isinstance(arg, VarRef):
                node.name = arg.name
        for k, v in list(node.__dict__.items()):
            if k == 'line':
                continue
            setattr(node, k, _subst(v, pmap))
        return node
    return node


def _expand_call(call, macro, table, stack):
    if macro.name in stack:
        raise PybkError(
            f"第 {call.line} 行：宏 {macro.name!r} 不能递归展开（会无限循环）"
            f"\n  为什么：宏体里又调用了自己\n  怎么改：把递归逻辑改成函数 func，或拆成不互相调用的多个宏")
    if len(call.args) != len(macro.params):
        raise PybkError(
            f"第 {call.line} 行：宏 {macro.name!r} 需要 {len(macro.params)} 个参数，"
            f"实际传了 {len(call.args)} 个")
    pmap = {p: copy.deepcopy(a) for p, a in zip(macro.params, call.args)}
    new_stack = stack + [macro.name]
    out = []
    for st in macro.body:
        st2 = copy.deepcopy(st)
        st2 = _subst(st2, pmap)
        _expand_in_stmt(st2, table, new_stack)        # 宏体里的 if/while/... 块内再展开
        if isinstance(st2, Call) and st2.name in table:  # 宏体里直接调用另一个宏
            out.extend(_expand_call(st2, table[st2.name], table, new_stack))
        else:
            out.append(st2)
    return out


def _expand_in_stmt(st, table, stack):
    """递归进入 st 内部的语句块，就地展开其中的宏调用。"""
    cls = type(st)
    fields = _STMT_LIST_FIELDS.get(cls)
    if fields is None:
        return
    if cls is VcChain:
        st.arms = [(cond, _expand_list(body, table, stack))
                   for cond, body in st.arms]
    else:
        for f in fields:
            setattr(st, f, _expand_list(getattr(st, f), table, stack))


def _expand_list(stmts, table, stack):
    out = []
    for st in stmts:
        if isinstance(st, Call) and st.name in table:
            out.extend(_expand_call(st, table[st.name], table, stack))
        else:
            _expand_in_stmt(st, table, stack)
            out.append(st)
    return out


def expand_macros(program: Program):
    """就地展开整个程序里的所有宏调用。program.macros 须已含主文件 + 导入的宏。"""
    macros = program.macros or []
    fn_names = {f.name for f in (program.fns or [])}
    table = {}
    for m in macros:
        if m.name in fn_names:
            raise PybkError(
                f"第 {m.line} 行：宏名 {m.name!r} 与函数名冲突"
                f"\n  为什么：同名时编译器分不清是调用函数还是展开宏\n  怎么改：给宏换个名字（如加 宏 后缀）")
        if m.name in table:
            raise PybkError(f"第 {m.line} 行：宏 {m.name!r} 重复定义")
        table[m.name] = m
    program.go_body = _expand_list(program.go_body or [], table, [])
    for fn in (program.fns or []):
        fn.body = _expand_list(fn.body or [], table, [])
    return program


def _show(n, ind=0):
    pad = '  ' * ind
    if n is None or isinstance(n, (int, float, str, bool)):
        print(pad + repr(n))
        return
    if isinstance(n, list):
        for x in n:
            _show(x, ind)
        return
    if isinstance(n, tuple):
        if len(n) == 2 and n[0] in ('TEXT', 'VAR'):
            print(pad + repr(n))
            return
        cond, body = n
        print(pad + ('分支 else:' if cond is None else '分支:'))
        if cond is not None:
            _show(cond, ind + 1)
        _show(body, ind + 1)
        return
    if dataclasses.is_dataclass(n):
        head = [type(n).__name__]
        subs = []
        for f in dataclasses.fields(n):
            v = getattr(n, f.name)
            if isinstance(v, (list, tuple)) or dataclasses.is_dataclass(v):
                subs.append((f.name, v))
            else:
                head.append(f"{f.name}={v!r}")
        print(pad + ' '.join(head))
        for name, v in subs:
            print(pad + '  ' + name + ':')
            _show(v, ind + 2)


if __name__ == '__main__':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass

    SAMPLE = '''@ 我的>第一个>程序
# 注释一行
func 加倍(n) {
    ret n * 2
}
GOING:{
vg.名字 = "世界"
vg.次数 = 3
ns.show(你好 $名字！)/magic(b, c=0,200,255)
rm.around(次数) {
    ns.show(第 $at 圈)
}
if (次数 >= 3) {
    ns.show(次数不少)
}
else {
    ns.show(次数太少)
}
vg.结果 = list.加倍(21)
ns.show(结果=$结果)
}STOP
'''

    toks = tokenize(SAMPLE)
    print(f"样例共切成 {len(toks)} 个 Token（含 EOF），行号范围 1..{toks[-1].line}")
    prog = parse(SAMPLE)
    _show(prog)

    # ---- 结构断言 ----
    assert prog.meta == '我的>第一个>程序'
    assert len(prog.fns) == 1
    fv = prog.fns[0]
    assert (fv.name, fv.params) == ('加倍', ['n'])
    assert fv.body[0].expr == BinOp('*', VarRef('n', 4), NumLit(2, 4), 4)

    g = prog.go_body
    assert isinstance(g[0], VgAssign) and g[0].name == '名字'
    ns1 = g[2]
    assert ns1.parts == [('TEXT', '你好 '), ('VAR', '名字'), ('TEXT', '！')]
    assert ns1.magic == ['b', 'c=0,200,255']
    around = g[3]
    assert around.body[0].parts == [('TEXT', '第 '), ('VAR', 'at'), ('TEXT', ' 圈')]
    vc = g[4]
    assert isinstance(vc, VcChain) and len(vc.arms) == 2
    assert vc.arms[0][0] == BinOp('>=', VarRef('次数', 13), NumLit(3, 13), 13)
    assert vc.arms[1][0] is None
    call = g[5].expr
    assert call == Call('加倍', [NumLit(21, 19)], 19)
    assert g[6].parts == [('TEXT', '结果='), ('VAR', '结果')]
    assert toks[-1].kind == 'EOF'

    # ---- 附加用例：when 块、ip 输入赋值、if/elif/else 三段链、裸 ret、// 运算 ----
    EXTRA = '''@ 附加>测试>用例
func 啥也不干() {
    ret
}
GOING: {
vg(ip).名字 = input("你叫什么名字？")
when {
    ns.show(走这条路)
} if (2)
if (1 == 1) {
    ns.show(一)
}
elif (2 <= 1) {
    ns.show(二)
}
else {
    ns.show(其他)
}
vg.商 = list.整除(7, 2)
}STOP
'''
    ex = parse(EXTRA)
    assert ex.go_body[0] == IpAssign('名字', '你叫什么名字？', 6)
    cd = ex.go_body[1]
    assert isinstance(cd, CdBlock) and cd.priority == 2 and cd.body[0].parts == [('TEXT', '走这条路')]
    vc2 = ex.go_body[2]
    assert [c is None for c, _b in vc2.arms] == [False, False, True]
    assert isinstance(ex.fns[0].body[0], Ret) and ex.fns[0].body[0].expr is None
    assert ex.go_body[3].expr.args == [NumLit(7, 19), NumLit(2, 19)]

    # ---- 错误处理：非法字符和语法错误都要带行号 ----
    for bad in ('@ a>b>c\nGOING:{\nvg.x = ？\n}STOP\n',
                '@ a>b>c\nGOING:{\nfv\n',
                '@ a>b>c\nGOING:{ } STOPX\n'):
        try:
            parse(bad)
        except PybkError as e:
            assert '第 ' in str(e)
        else:
            raise AssertionError(f"应当报错却没有：{bad!r}")

    # ---- hm 网页输出分支 ----
    HM = '''@ 测>网页>分支
GOING:{
web.big(欢迎来到 $名字 的主页)
web.mid(第二章)
web.show(你好 $名字！得分 $分数 / 2)/magic(b, c=0,200,255)
web.show(普通段落没有 magic)
web.img("风景.png")
web.line
web.link("访问教程", "https://pybook.example.com")
}STOP
'''
    hm_prog = parse(HM)
    g = hm_prog.go_body
    assert [s.kind for s in g] == ['big', 'mid', 'show', 'show', 'img', 'line', 'link']
    assert g[0].parts == [('TEXT', '欢迎来到 '), ('VAR', '名字'), ('TEXT', ' 的主页')]
    assert g[0].arg == '' and g[0].magic == []
    assert g[2].parts == [('TEXT', '你好 '), ('VAR', '名字'), ('TEXT', '！得分 '),
                          ('EXPR', BinOp('/', VarRef('分数', 5), NumLit(2, 5), 5))]
    assert g[2].magic == ['b', 'c=0,200,255']
    assert g[3].magic == []                          # /magic 可省
    assert g[4].parts == [] and g[4].arg == '风景.png' and g[4].magic == []
    assert g[5].kind == 'line' and g[5].parts == [] and g[5].arg == '' and g[5].magic == []
    assert g[6].parts == [('TEXT', '访问教程')] and g[6].arg == 'https://pybook.example.com'
    assert g[6].magic == []

    # hm 错误路径：缺右括号 / / 后接非 magic / link 只给一个参数，均带行号
    for bad in ('@ a>b>c\nGOING:{\nweb.big(没有右括号\n',
                '@ a>b>c\nGOING:{\nweb.show(段落)/bold\n',
                '@ a>b>c\nGOING:{\nweb.link("只有文字")\n',
                '@ a>b>c\nGOING:{\nweb.mid(标题)/magic(b)\n'):
        try:
            parse(bad)
        except PybkError as e:
            assert '第 ' in str(e), str(e)
        else:
            raise AssertionError(f"应当报错却没有：{bad!r}")

    # ---- web.块（页面组件）：定义/使用/嵌套调用/错误路径 ----
    BLK = '''@ 测>组件>解析
web.块 卡片(标题, 内容) {
    web.mid($标题)
    web.show($标题：$内容)
    web.line
}
web.块 货架(名称) {
    web.卡片(名称, "欢迎选购")
}
GOING:{
    vg.x = 1
    web.卡片("水果", "苹果")
    web.货架("西瓜")
}STOP
'''
    bp = parse(BLK)
    assert list(bp.hm_blocks) == ['卡片', '货架']
    assert bp.hm_blocks['卡片'].params == ['标题', '内容']
    assert len(bp.hm_blocks['卡片'].body) == 3
    u0 = bp.go_body[1]
    assert isinstance(u0, HmUse) and u0.name == '卡片' and len(u0.args) == 2
    assert isinstance(bp.go_body[2], HmUse) and bp.go_body[2].name == '货架'
    inner = bp.hm_blocks['货架'].body[0]
    assert isinstance(inner, HmUse) and inner.name == '卡片' and len(inner.args) == 2

    for bad, frag in (
            ('@ a>b>c\nGOING:{\nvg.x = 1\nweb.卡片("x")\n}STOP\n', '或已定义的组件名'),
            ('@ a>b>c\nweb.块 卡(标题) {\n    web.mid(标题)\n}\nGOING:{\nvg.x = 1\nweb.卡("x", "y")\n}STOP\n',
             '需要 1 个参数'),
            ('@ a>b>c\nweb.块 卡(标题) {\n    web.mid(标题)\n    web.块 内(a) {\n        web.mid(a)\n    }\n}\n'
             'GOING:{\nvg.x = 1\n}STOP\n', '只能定义在文件顶层'),
            ('@ a>b>c\nweb.块 卡(标题) {\n    web.帧 { web.draw.色(1,2,3) }\n}\nGOING:{\nvg.x = 1\n}STOP\n',
             '帧/播放/实时'),
            ('@ a>b>c\nweb.块 卡(标题) {\n    web.draw.色(1,2,3)\n}\nGOING:{\nvg.x = 1\n}STOP\n',
             'draw/页')):
        try:
            parse(bad)
        except PybkError as e:
            assert '第 ' in str(e) and frag in str(e), (bad, str(e))
        else:
            raise AssertionError(f'应当报错却没有：{bad!r}')

    # ---- web.页（子页面）与 web.draw.始(宽,高) ----
    PG = '''@ 测>多页>解析
GOING:{
    web.big(主页内容)
    web.页("特惠") {
        web.big(今日特惠)
        web.link("回主页", "pybook_page.html")
    }
    web.draw.始(800, 200)
    web.帧 { web.draw.色(1,2,3) }
    web.播放(5)
    web.draw.终
}STOP
'''
    pg = parse(PG)
    page_i = [k for k, s in enumerate(pg.go_body) if isinstance(s, HmPageStmt)]
    assert len(page_i) == 1
    pgs = pg.go_body[page_i[0]]
    assert pgs.name == '特惠' and len(pgs.body) == 2
    dn = [s for s in pg.go_body if isinstance(s, HmDraw) and s.cmd == 'begin']
    assert len(dn) == 1 and [q.value for q in dn[0].params] == [800, 200]

    for bad, frag in (
            ('@ a>b>c\nGOING:{\nvg.x = 1\nweb.页("a") {\nweb.页("b") {\nweb.mid(嵌套)\n}\n}\n}STOP\n',
             '嵌套页'),
            ('@ a>b>c\nweb.块 卡(a) {\n    web.页("b") {\n        web.mid(a)\n    }\n}\n'
             'GOING:{\nvg.x = 1\n}STOP\n', '页'),
            ('@ a>b>c\nGOING:{\nvg.x = 1\nweb.页("a/b") {\nweb.mid(x)\n}\n}STOP\n', '不能含'),
            ('@ a>b>c\nGOING:{\nvg.x = 1\nweb.draw.始(800)\nweb.draw.终\n}STOP\n', "期望 ','"),
            ('@ a>b>c\nGOING:{\nvg.x = 1\nweb.draw.始(10000, 200)\nweb.draw.终\n}STOP\n', '超范围'),
            ('@ a>b>c\nGOING:{\nvg.x = 1\nweb.draw.始(80.5, 200)\nweb.draw.终\n}STOP\n', '正整数')):
        try:
            parse(bad)
        except PybkError as e:
            assert '第 ' in str(e) and frag in str(e), (bad, str(e))
        else:
            raise AssertionError(f'应当报错却没有：{bad!r}')

    # ---- lb 类（OOP）分支 ----
    CLS = '''@ 游戏>类>试炼
lb.狗 {
    vg.名字
    vg.血量 = 100
    func 叫() {
        ns.show($self.名字：汪汪汪！)/magic(b)
    }
    func 受伤(点数) {
        self.血量 = self.血量 - 点数
    }
}
GOING:{
vg.旺财 = lb.狗(名字="旺财", 血量=100)
旺财.叫()
旺财.受伤(30)
vg_ro.队伍 = [旺财]
ns.show($队伍[0].名字 报到)
}STOP
'''
    cp = parse(CLS)
    assert len(cp.classes) == 1
    dog = cp.classes[0]
    assert dog.name == '狗' and dog.line == 2
    assert [(n, d) for n, d in dog.props] == [('名字', None), ('血量', NumLit(100, 4))]
    assert [m.name for m in dog.methods] == ['叫', '受伤']
    jiao = dog.methods[0]
    assert jiao.params == [] and jiao.body[0].magic == ['b']
    assert jiao.body[0].parts == [('EXPR', Member(VarRef('self', 6), '名字', 6)),
                                  ('TEXT', '：汪汪汪！')]
    shang = dog.methods[1]
    assert shang.params == ['点数']
    assert shang.body[0] == AssignMember(VarRef('self', 9), '血量',
                                         BinOp('-',
                                               Member(VarRef('self', 9), '血量', 9),
                                               VarRef('点数', 9), 9), 9)
    gg = cp.go_body
    assert gg[0] == VgAssign('旺财', CtorExpr('狗', 13, [],
                                             [('名字', StrLit('旺财', 13)),
                                              ('血量', NumLit(100, 13))]), 13)
    assert gg[1] == MethodCall(VarRef('旺财', 14), '叫', [], 14)
    assert gg[2] == MethodCall(VarRef('旺财', 15), '受伤', [NumLit(30, 15)], 15)
    assert gg[3] == VgAssign('队伍', ListLit([VarRef('旺财', 16)], 16), 16)
    assert gg[4].parts == [('EXPR', Member(Index(VarRef('队伍', 17), NumLit(0, 17), 17),
                                           '名字', 17)),
                           ('TEXT', ' 报到')]

    # ---- 短vc：ns.show(主)vc:条件?(替代) ----
    SV = '''@ 测>短vc>解析
GOING:{
vg.分数 = 75
ns.show(及格)/magic(b, c=0,200,0)vc:分数 >= 60?(不及格 $分数 分)
ns.show(无后缀)
}STOP
'''
    sv = parse(SV).go_body
    assert sv[1].vc_cond == BinOp('>=', VarRef('分数', 4), NumLit(60, 4), 4)
    assert sv[1].vc_alt == [('TEXT', '不及格 '), ('VAR', '分数'), ('TEXT', ' 分')]
    assert sv[1].magic == ['b', 'c=0,200,0']
    assert sv[2].vc_cond is None and sv[2].vc_alt == []

    # ---- 模块系统：引用("名") 与 parse_module ----
    MAIN_M = '''@ 主>模块>测试
引用("工具箱")
引用("数学库")
func 广播() {
    ns.show(广播)
}
GOING:{
ns.show($版本)
}STOP
'''
    mp = parse(MAIN_M)
    assert mp.imports == [("工具箱", 2), ("数学库", 3)], mp.imports
    MOD_M = '''@ 工具箱>数学>v1
vg.版本 = 1
func 加(a, b) { ret a + b }
func double(n) { ret n * 2 }
GOING:{
ns.show(模块自己的GOING会被忽略)
}STOP
'''
    mod = parse_module(MOD_M)
    assert mod.imports == []
    assert [(f.name, f.params) for f in mod.fns] == [('加', ['a', 'b']), ('double', ['n'])]
    assert len(mod.go_body) == 1 and isinstance(mod.go_body[0], VgAssign)
    try:
        parse('@ a>b>c\nGOING:{\n}\n引用("晚了")\nSTOP\n')
    except PybkError as e:
        assert '第 ' in str(e)
    else:
        raise AssertionError("GOING 之后的引用应当报错")


    # 类错误路径：未知属性名 / 未定义的类 / 重复定义，均带行号
    for bad, frag in (
            ('@ a>b>c\nlb.狗 { vg.名字 }\nGOING:{\nvg.d = lb.狗(毛色=1)\n}STOP\n', '毛色'),
            ('@ a>b>c\nGOING:{\nvg.d = lb.猫()\n}STOP\n', '猫'),
            ('@ a>b>c\nlb.狗 { vg.名字 }\nlb.狗 { vg.年龄 }\nGOING:{\n}STOP\n', '重复')):
        try:
            parse(bad)
        except PybkError as e:
            assert '第 ' in str(e) and frag in str(e), (bad, str(e))
        else:
            raise AssertionError(f"应当报错却没有：{bad!r}")

    # 类系统新特性：继承 / 构造形参 / 静态成员/类方法 解析无误且字段落位正确
    _prog = parse('''@ a>b>c
lb.动物 {
    func 叫(){ }
}
lb.狗 : 动物 {
    func 叫(){ }
}
lb.点(x, y) {
    vg.x = x
    func 构造(){ self.r = x + y }
}
lb.圆 {
    静 vg.n = 0
    静 func 加(){ }
}
GOING:{
    vg.d = lb.狗()
    vg.p = lb.点(1, 2)
    lb.圆.加()
}STOP
''')
    _cls = {c.name: c for c in _prog.classes}
    assert _cls['狗'].parent == '动物', _cls['狗'].parent
    assert _cls['点'].ctor_params == ['x', 'y'], _cls['点'].ctor_params
    assert _cls['点'].methods[0].name == '构造', _cls['点'].methods[0].name
    assert _cls['圆'].static_fields and _cls['圆'].static_fields[0][0] == 'n', _cls['圆'].static_fields
    assert _cls['圆'].static_methods and _cls['圆'].static_methods[0].name == '加', _cls['圆'].static_methods

    # ---- 帧动画 / go 移动 ----
    AN = '''@ 动画>解析>测试
GOING:{
web.draw.始
web.帧 {
    web.draw.色(255, 0, 0)
    web.draw.圆(200, 150, 80)
}
web.帧(5) {
    web.draw.色(0, 0, 255)
    web.draw.方(100, 100, 160, 160)
}
web.播放(2)
go(右, 100, 2)
web.draw.终
}STOP
'''
    an = parse(AN).go_body
    assert isinstance(an[0], HmDraw) and an[0].cmd == 'begin'
    assert isinstance(an[1], HmFrame) and len(an[1].body) == 2
    assert an[1].body[0] == HmDraw('color', [NumLit(255, 5), NumLit(0, 5), NumLit(0, 5)], 5)
    assert isinstance(an[2], HmFrame) and an[2].body[1].cmd == 'rect'
    assert an[3] == HmPlay(NumLit(2, 12), 12)
    assert an[4] == GoStmt('右', NumLit(100, 13), NumLit(2, 13), 13)
    assert isinstance(an[5], HmDraw) and an[5].cmd == 'end'
    g2 = parse('@ a>b>c\nGOING:{\ngo(down, 2 + 3, 0.5)\n}STOP\n').go_body
    assert g2[0] == GoStmt('down', BinOp('+', NumLit(2, 3), NumLit(3, 3), 3),
                           NumLit(0.5, 3), 3)
    # web.播放 前没有帧 → 语义错误带行号
    try:
        parse('@ a>b>c\nGOING:{\nweb.播放(2)\n}STOP\n')
    except PybkError as e:
        assert '第 3 行' in str(e) and 'web.帧' in str(e), str(e)
    else:
        raise AssertionError('web.播放 缺帧应当报错')
    # go 方向非法 → 报错带行号
    try:
        parse('@ a>b>c\nGOING:{\ngo(斜, 1, 1)\n}STOP\n')
    except PybkError as e:
        assert '第 3 行' in str(e) and '方向' in str(e), str(e)
    else:
        raise AssertionError('go 方向校验应当报错')

    # ---- 键盘监听与游戏零件 ----
    GM = '''@ game>move>fun
GOING:{
win(800, 600, "My Game")
vg.x = 100
vg.spd = 5
rm.aging.while(end()) {
    clear()
    color(30, 30, 60)
    box(0, 0, 800, 600)
    color(0, 255, 0)
    box(x, y, 50, 50)
    if (key("right")) {
        vg.x = x + spd
    }
    if (key("space") and key("up")) {
        vg.y = y - spd
    }
    show()
    wait(16)
}
}STOP
'''
    gm = parse(GM).go_body
    assert gm[0] == Call('win', [NumLit(800, 3), NumLit(600, 3), StrLit('My Game', 3)], 3)
    aging = gm[3]
    assert isinstance(aging, Aging)
    assert aging.cond == Call('end', [], 6)
    vc0 = aging.body[5]
    assert vc0.arms[0][0] == Call('key', [StrLit('right', 12)], 12)
    vc1 = aging.body[6]
    assert vc1.arms[0][0] == BinOp('and', Call('key', [StrLit('space', 15)], 15),
                                   Call('key', [StrLit('up', 15)], 15), 15)
    assert aging.body[7] == Call('show', [], 18)
    assert aging.body[8] == Call('wait', [NumLit(16, 19)], 19)
    # 全部字母键都合法；中文键名合法
    for kname in 'abcdefghijklmnopqrstuvwxyz':
        c = parse('@ a>b>c\nGOING:{\nvg.b = key("' + kname + '")\n}STOP\n').go_body[0].expr
        assert c == Call('key', [StrLit(kname, 3)], 3)
    c = parse('@ a>b>c\nGOING:{\nvg.b = key("右")\n}STOP\n').go_body[0].expr
    assert c.args[0].value == '右'
    # 错误路径：键名不是字符串 / 键名不合法 / 参数个数不对，均带行号
    for bad, frag in (
            ('@ a>b>c\nGOING:{\nvg.b = key(右)\n}STOP\n', '字符串字面量'),
            ('@ a>b>c\nGOING:{\nvg.b = key("空格2")\n}STOP\n', '不支持的键名'),
            ('@ a>b>c\nGOING:{\nvg.b = key("right", 1)\n}STOP\n', '1 个参数'),
            ('@ a>b>c\nGOING:{\nclear(1)\n}STOP\n', '0 个参数'),
            ('@ a>b>c\nGOING:{\nwin(800, 600)\n}STOP\n', '3 个参数')):
        try:
            parse(bad)
        except PybkError as e:
            assert '第 3 行' in str(e) and frag in str(e), (bad, str(e))
        else:
            raise AssertionError(f'应当报错却没有：{bad!r}')

    print()
    print("自测通过：分支链(if/elif/else)、when 块、$插值切分、裸 ret、web 网页分支、web.块 组件、lb 类(OOP)、"
          "帧动画/go、key 与游戏零件、模块引用/parse_module 均正确，错误均带行号。")
